    // elementwise: add over BLOCK=16, masked
    .li       s1, #47
    .li       s2, #262144
    .li       s3, #278528
    .li       s4, #294912
    .li       s5, #0
loop:
    // offs = pid * BLOCK + arange(0, BLOCK)
    .li       s6, #16
    s.mul        s7, s5, s6                      // pid * BLOCK
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s7
    v.add        v2, v0, v1                      // offs
    // mask = offs < n
    v.splat      v0, s1
    v.cmp.lt     p1, v2, v0
    // The offsets are contiguous, so a plain vector load reaches
    // them: ISA sec 9.1 gives lane i the address base + i*sz. No
    // gather is needed, and emitting one would cost per-lane
    // addressing for nothing.
    s.shli       s6, s7, #2                      // byte offset = pid*BLOCK*4
    s.add        s7, s2, s6                      // &x[pid*BLOCK]
    s.add        s8, s3, s6                      // &y[pid*BLOCK]
    s.add        s9, s4, s6                      // &out[pid*BLOCK]
    // other= is a value, not an absence (sec 12). The
    // masked-off lanes keep what the register already held,
    // so it has to be set first.
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v0, [s7, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s8, #0]
    vf.add       v2, v0, v1
    @p1 v.st.w       [s9, #0], v2
    s.addi       s6, s5, #1
    s.mov        s5, s6
    .li       s6, #3
    s.cmp.lt     s7, s5, s6
    br.nz        s7, loop

exit
