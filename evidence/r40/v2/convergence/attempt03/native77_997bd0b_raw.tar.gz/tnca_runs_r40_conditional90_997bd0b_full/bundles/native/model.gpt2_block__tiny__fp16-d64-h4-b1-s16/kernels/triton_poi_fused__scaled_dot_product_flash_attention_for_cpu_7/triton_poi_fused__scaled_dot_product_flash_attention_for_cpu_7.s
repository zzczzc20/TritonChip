    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #4
    v.add        v4, v1, v0
    v.movi       v0, #0
    v.movi       v1, #0
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    v.movi       v6, #0
    @p1 v.sel        v7, v5, v4
    v.cmp.lt     p2, v4, v0
    v.sub        v5, v1, v4
    v.lshr       v8, v7, v3
    v.cmp.lt     p3, v4, v1
    @p3 v.sel        v3, v5, v4
    v.sub        v5, v2, v8
    v.movi       v7, #15
    v.movi       v9, #3
    @p1 v.sel        v10, v5, v8
    v.and        v5, v3, v7
    s.rdspecial  s2, arg_base
    v.sub        v3, v0, v4
    v.sub        v7, v6, v10
    v.cmp.lt     p1, v10, v6
    v.movi       v8, #16
    @p1 v.sel        v11, v7, v10
    v.sub        v7, v1, v5
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    @p2 v.sel        v10, v3, v4
    v.and        v3, v11, v9
    @p3 v.sel        v9, v7, v5
    v.movi       v5, #1024
    v.sub        v7, v6, v3
    v.cmp.lt     p3, v8, v1
    v.cmp.lt     p4, v4, v5
    @p1 v.sel        v4, v7, v3
    v.movi       v3, #4
    v.movi       v5, #64
    s.ld.d       s4, [s2, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.movi       v7, #6
    v.sub        v11, v1, v8
    s.shli       s2, s1, #1                      // element offset -> bytes (x2)
    v.lshr       v1, v10, v7
    v.movi       v7, #256
    v.cmp.lt     p1, v8, v2
    v.sub        v10, v2, v8
    v.mul        v2, v4, v7
    v.sub        v4, v0, v1
    @p3 v.sel        v7, v11, v8
    v.sub        v7, v6, v3
    @p2 v.sel        v11, v4, v1
    v.sub        v1, v0, v5
    s.add        s1, s4, s2                      // &out_ptr0[...]
    v.mul        v4, v11, v8
    v.cmp.lt     p2, v3, v6
    v.cmp.lt     p3, v5, v0
    v.add        v0, v9, v4
    @p1 v.sel        v4, v10, v8
    @p2 v.sel        v4, v7, v3
    v.add        v3, v0, v2
    @p3 v.sel        v0, v1, v5
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s3, v3]               // index is in elements (ISA sec 9.1)
    vf.cvt.f32.f16 v1, v0
    @p4 v.st.h       [s1, #0], v1
__rctx_next:
    exit
