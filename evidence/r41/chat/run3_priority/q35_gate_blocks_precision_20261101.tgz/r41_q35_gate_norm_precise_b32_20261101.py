#!/usr/bin/env python3
"""Isolated first attention gated RMS norm, same captured CPU operands."""
import json,sys,time
from pathlib import Path
import torch
from safetensors.torch import load_file,save_file
h=Path.home();tree=h/'r41_q35_multiturn_diag_20261031';sys.path[:0]=[str(tree/'tools/models'),str(tree),str(tree/'python'),str(tree/'compiler/python'),str(tree/'tools/asm')]
import chat
chat.L.use_tnca(str(tree));args=chat.parser().parse_args(['--model','q35','--device','cpu','--threads','4','--bucket','256','--new-tokens','1'])
start=time.monotonic();app=chat.ChatApplication(args);src=load_file(str(h/'r41_q35_first_delta_cpu_20261031_diag/states.safetensors'));x=src['norm_input_core'];z=src['norm_input_z'];expected=src['linear_attn.norm'];norm=app.model.model.language_model.layers[0].linear_attn.norm
stage,dev=chat.L.place(norm,'tnca','eager')
with torch.no_grad():got=stage(x.to(dev),z.to(dev)).detach().cpu().contiguous().clone()
if got.shape!=expected.shape or got.dtype!=expected.dtype:raise ValueError('shape or dtype mismatch')
f=expected.float();g=got.float();d=(f-g).abs();r={'schema':'r41-q35-gated-norm-tlm/1','scope':'isolated one-op DP TLM with non-default emulate_precision_casts=True on CPU-captured attention-core and gate operands, not full graph or board','shape':list(got.shape),'elements':got.numel(),'bit_mismatches':int((got.view(torch.int16)!=expected.view(torch.int16)).sum()),'relative_l2':float((f-g).norm()/f.norm().clamp_min(1e-30)),'max_abs':float(d.max()),'seconds':time.monotonic()-start}
out=h/'r41_q35_gate_norm_precise_b32_20261101_diag';out.mkdir(exist_ok=False);save_file({'got':got,'expected':expected.clone(),'core':x.clone(),'gate':z.clone()},str(out/'states.safetensors'));(out/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
