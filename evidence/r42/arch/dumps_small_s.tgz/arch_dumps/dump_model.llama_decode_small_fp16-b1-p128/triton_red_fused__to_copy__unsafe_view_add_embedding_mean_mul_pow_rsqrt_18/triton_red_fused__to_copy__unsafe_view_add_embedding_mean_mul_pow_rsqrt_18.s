    s.rdspecial  s1, arg_base
    v.movi       v0, #0
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v1, #0
    v.movi       v2, #0
    s.movz       s3, #0
    v.iota       v3                              // arange(0, VLEN)
    s.rdspecial  s4, arg_base
    s.movz       s4, #128
    s.movz       s5, #16
    s.addi       s6, s3, #0
    s.ld.d       s7, [s2, #0]                    // one element, not a vector
    s.lshri      s8, s7, #32
    s.ld.d       s9, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.movi       v4, #0
    s.ld.d       s10, [s1, #16]                  // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s11, [s1, #24]                  // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s12, [s1, #32]                  // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s13, [s1, #40]                  // out_ptr1: device_ptr64 at arg_base+40
    v.insert     v0, s7, #0
    v.insert     v1, s8, #0
    v.insert     v0, s7, #1
    v.insert     v1, s8, #1
    v.insert     v0, s7, #2
    v.insert     v1, s8, #2
    v.insert     v0, s7, #3
    v.insert     v1, s8, #3
    v.insert     v0, s7, #4
    v.insert     v1, s8, #4
    v.insert     v0, s7, #5
    v.insert     v1, s8, #5
    v.insert     v0, s7, #6
    v.insert     v1, s8, #6
    v.insert     v0, s7, #7
    v.insert     v1, s8, #7
    v.insert     v0, s7, #8
    v.insert     v1, s8, #8
    v.insert     v0, s7, #9
    v.insert     v1, s8, #9
    v.insert     v0, s7, #10
    v.insert     v1, s8, #10
    v.insert     v0, s7, #11
    v.insert     v1, s8, #11
    v.insert     v0, s7, #12
    v.insert     v1, s8, #12
    v.insert     v0, s7, #13
    v.insert     v1, s8, #13
    v.insert     v0, s7, #14
    v.insert     v1, s8, #14
    v.insert     v0, s7, #15
    v.insert     v1, s8, #15
    v.mov        v4, v2
for_1:
    s.cmp.ge     s1, s6, s4
    br.nz        s1, endfor_2
    v.splat      v2, s6
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s6
    v.iota       v7                              // arange(0, VLEN)
    v.extract    s1, v1, #0
    s.muli       s7, s6, #2
    s.muli       s8, s6, #2
    v.add        v8, v2, v5
    v.movi       v2, #0
    v.splat      v5, s4
    v.add        v9, v6, v7
    v.movi       v6, #0
    v.splat      v7, s4
    v.extract    s14, v0, #0
    s.shli       s15, s1, #32
    v.extract    s1, v1, #1
    s.or         s16, s14, s15
    v.cmp.ge     p1, v8, v2
    v.cmp.lt     p2, v8, v5
    v.cmp.ge     p3, v9, v6
    v.cmp.lt     p4, v9, v7
    v.movi       v2, #0
    v.extract    s14, v0, #1
    s.shli       s15, s1, #32
    s.add        s1, s10, s7
    p.and        p5, p1, p2
    s.add        s7, s11, s8
    p.and        p1, p3, p4
    s.cmp.ge     s8, s16, s3
    v.extract    s16, v1, #2
    s.or         s17, s14, s15
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v5, [s1, #0]
    v.extract    s1, v0, #2
    s.shli       s14, s16, #32
    s.cmp.ge     s15, s17, s3
    s.or         s16, s1, s14
    v.extract    s1, v0, #3
    s.cmp.ge     s14, s16, s3
    v.splat      v6, s6
    v.extract    s16, v1, #3
    v.movi       v7, #128
    v.add        v8, v6, v3
    s.shli       s17, s16, #32
    s.or         s16, s1, s17
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v6, [s7, #0]
    v.insert     v2, s8, #0
    v.cmp.lt     p1, v8, v7
    v.extract    s1, v1, #4
    v.insert     v2, s15, #1
    s.movz       s7, #0
    v.extract    s8, v0, #4
    v.insert     v2, s14, #2
    s.shli       s14, s1, #32
    s.cmp.ge     s1, s16, s7
    v.extract    s15, v1, #5
    s.or         s16, s8, s14
    v.insert     v2, s1, #3
    v.extract    s1, v0, #5
    s.shli       s8, s15, #32
    s.cmp.ge     s14, s16, s7
    vf.cvt.f16.f32 v7, v5
    v.extract    s15, v1, #6
    s.or         s16, s1, s8
    v.insert     v2, s14, #4
    v.extract    s1, v0, #6
    s.shli       s8, s15, #32
    s.cmp.ge     s14, s16, s7
    v.extract    s15, v1, #7
    s.or         s16, s1, s8
    v.insert     v2, s14, #5
    v.extract    s1, v0, #7
    s.shli       s8, s15, #32
    s.cmp.ge     s14, s16, s7
    vf.cvt.f16.f32 v5, v6
    v.extract    s15, v1, #8
    s.or         s16, s1, s8
    v.insert     v2, s14, #6
    v.extract    s1, v0, #8
    s.shli       s8, s15, #32
    s.cmp.ge     s14, s16, s7
    v.extract    s15, v1, #9
    s.or         s16, s1, s8
    v.insert     v2, s14, #7
    v.extract    s1, v0, #9
    s.shli       s8, s15, #32
    s.cmp.ge     s14, s16, s7
    v.extract    s15, v1, #10
    s.or         s16, s1, s8
    v.insert     v2, s14, #8
    v.extract    s1, v0, #10
    s.shli       s8, s15, #32
    s.cmp.ge     s14, s16, s7
    v.extract    s15, v1, #11
    s.or         s16, s1, s8
    v.insert     v2, s14, #9
    v.extract    s1, v0, #11
    s.shli       s8, s15, #32
    s.cmp.ge     s14, s16, s7
    v.extract    s15, v1, #12
    s.or         s16, s1, s8
    v.insert     v2, s14, #10
    v.extract    s1, v0, #12
    s.shli       s8, s15, #32
    s.cmp.ge     s14, s16, s7
    v.extract    s15, v1, #13
    s.or         s16, s1, s8
    v.insert     v2, s14, #11
    v.extract    s1, v0, #13
    s.shli       s8, s15, #32
    s.cmp.ge     s14, s16, s7
    v.extract    s7, v1, #14
    s.or         s15, s1, s8
    s.movz       s1, #0
    v.insert     v2, s14, #12
    v.extract    s8, v0, #14
    s.shli       s14, s7, #32
    s.cmp.ge     s7, s15, s1
    v.extract    s15, v1, #15
    v.extract    s16, v1, #0
    s.or         s17, s8, s14
    v.insert     v2, s7, #13
    v.extract    s7, v0, #15
    s.shli       s8, s15, #32
    v.extract    s14, v0, #0
    s.shli       s15, s16, #32
    s.cmp.ge     s16, s17, s1
    v.extract    s17, v1, #1
    s.or         s18, s7, s8
    s.or         s7, s14, s15
    s.movz       s8, #512
    v.insert     v2, s16, #14
    v.movi       v6, #0
    v.extract    s14, v0, #1
    s.shli       s15, s17, #32
    s.cmp.ge     s16, s18, s1
    s.cmp.lt     s1, s7, s8
    v.extract    s7, v1, #2
    s.or         s17, s14, s15
    v.insert     v2, s16, #15
    v.insert     v6, s1, #0
    v.extract    s1, v0, #2
    s.shli       s14, s7, #32
    s.cmp.lt     s7, s17, s8
    v.extract    s15, v1, #3
    s.or         s16, s1, s14
    v.insert     v6, s7, #1
    v.extract    s1, v0, #3
    s.shli       s7, s15, #32
    s.cmp.lt     s14, s16, s8
    v.extract    s15, v1, #4
    s.or         s16, s1, s7
    v.insert     v6, s14, #2
    v.extract    s1, v0, #4
    s.shli       s7, s15, #32
    s.cmp.lt     s14, s16, s8
    v.extract    s15, v1, #5
    s.or         s16, s1, s7
    v.insert     v6, s14, #3
    v.extract    s1, v0, #5
    s.shli       s7, s15, #32
    s.cmp.lt     s14, s16, s8
    v.extract    s15, v1, #6
    s.or         s16, s1, s7
    v.insert     v6, s14, #4
    v.extract    s1, v0, #6
    s.shli       s7, s15, #32
    s.cmp.lt     s14, s16, s8
    v.extract    s15, v1, #7
    s.or         s16, s1, s7
    v.insert     v6, s14, #5
    v.extract    s1, v0, #7
    s.cmp.lt     s7, s16, s8
    v.movi       v9, #0
    s.shli       s14, s15, #32
    v.insert     v6, s7, #6
    v.cmp.ne     p2, v2, v9
    v.extract    s7, v1, #8
    s.or         s15, s1, s14
    v.extract    s1, v0, #8
    s.shli       s14, s7, #32
    s.cmp.lt     s7, s15, s8
    v.extract    s15, v1, #9
    s.or         s16, s1, s14
    v.insert     v6, s7, #7
    v.extract    s1, v0, #9
    s.shli       s7, s15, #32
    s.cmp.lt     s14, s16, s8
    v.extract    s15, v1, #10
    s.or         s16, s1, s7
    v.insert     v6, s14, #8
    v.extract    s1, v0, #10
    s.shli       s7, s15, #32
    s.cmp.lt     s14, s16, s8
    v.extract    s8, v1, #11
    s.or         s15, s1, s7
    s.movz       s1, #512
    v.insert     v6, s14, #9
    v.extract    s7, v0, #11
    s.shli       s14, s8, #32
    s.cmp.lt     s8, s15, s1
    v.extract    s15, v1, #12
    s.or         s16, s7, s14
    v.insert     v6, s8, #10
    v.extract    s7, v0, #12
    s.shli       s8, s15, #32
    s.cmp.lt     s14, s16, s1
    v.extract    s15, v1, #13
    s.or         s16, s7, s8
    v.insert     v6, s14, #11
    v.extract    s7, v0, #13
    s.shli       s8, s15, #32
    s.cmp.lt     s14, s16, s1
    v.extract    s15, v1, #14
    s.or         s16, s7, s8
    v.insert     v6, s14, #12
    v.extract    s7, v0, #14
    s.shli       s8, s15, #32
    s.cmp.lt     s14, s16, s1
    v.extract    s15, v1, #15
    s.or         s16, s7, s8
    v.insert     v6, s14, #13
    v.extract    s7, v0, #15
    s.shli       s8, s15, #32
    s.cmp.lt     s14, s16, s1
    s.or         s15, s7, s8
    v.insert     v6, s14, #14
    s.cmp.lt     s7, s15, s1
    v.movi       v2, #0
    v.insert     v6, s7, #15
    v.movi       v9, #1
    s.movz       s1, #0
    v.cmp.ne     p3, v6, v2
    p.and        p4, p2, p3
    @p4 v.sel        v6, v2, v9
    v.reduce.or  s7, v6
    s.cmp.eq     s8, s7, s1
    br.nz        s8, assert_ok_3
    trap         #677351
assert_ok_3:
    v.extract    s1, v1, #0
    v.extract    s7, v0, #0
    s.shli       s8, s1, #32
    v.extract    s1, v1, #1
    s.or         s14, s7, s8
    s.movz       s7, #128
    v.extract    s8, v0, #1
    s.shli       s15, s1, #32
    s.mul        s1, s14, s7
    v.extract    s14, v1, #2
    s.or         s16, s8, s15
    v.extract    s8, v0, #2
    s.shli       s15, s14, #32
    s.mul        s14, s16, s7
    v.extract    s16, v1, #3
    v.movi       v2, #0
    v.movi       v6, #0
    s.or         s17, s8, s15
    s.lshri      s8, s1, #32
    v.extract    s15, v0, #3
    s.shli       s18, s16, #32
    s.mul        s16, s17, s7
    v.insert     v2, s1, #0
    v.extract    s1, v1, #4
    v.insert     v6, s8, #0
    s.or         s8, s15, s18
    s.lshri      s15, s14, #32
    v.extract    s17, v0, #4
    s.shli       s18, s1, #32
    s.mul        s1, s8, s7
    v.insert     v2, s14, #1
    v.extract    s8, v1, #5
    v.insert     v6, s15, #1
    s.or         s14, s17, s18
    s.lshri      s15, s16, #32
    v.extract    s17, v0, #5
    s.shli       s18, s8, #32
    s.mul        s8, s14, s7
    v.insert     v2, s16, #2
    v.extract    s14, v1, #6
    v.insert     v6, s15, #2
    s.or         s15, s17, s18
    s.lshri      s16, s1, #32
    v.extract    s17, v0, #6
    s.shli       s18, s14, #32
    s.mul        s14, s15, s7
    v.insert     v2, s1, #3
    v.extract    s1, v1, #7
    v.insert     v6, s16, #3
    s.or         s15, s17, s18
    s.lshri      s16, s8, #32
    v.extract    s17, v0, #7
    s.shli       s18, s1, #32
    s.mul        s1, s15, s7
    v.insert     v2, s8, #4
    v.extract    s8, v1, #8
    v.insert     v6, s16, #4
    s.or         s15, s17, s18
    s.lshri      s16, s14, #32
    v.extract    s17, v0, #8
    s.shli       s18, s8, #32
    s.mul        s8, s15, s7
    v.extract    s7, v1, #9
    v.insert     v2, s14, #5
    v.insert     v6, s16, #5
    s.or         s14, s17, s18
    s.movz       s15, #128
    s.lshri      s16, s1, #32
    v.extract    s17, v0, #9
    s.shli       s18, s7, #32
    s.mul        s7, s14, s15
    v.insert     v2, s1, #6
    v.extract    s1, v1, #10
    v.insert     v6, s16, #6
    s.or         s14, s17, s18
    s.lshri      s16, s8, #32
    v.extract    s17, v0, #10
    s.shli       s18, s1, #32
    s.mul        s1, s14, s15
    v.insert     v2, s8, #7
    v.extract    s8, v1, #11
    v.insert     v6, s16, #7
    s.or         s14, s17, s18
    s.lshri      s16, s7, #32
    v.extract    s17, v0, #11
    s.shli       s18, s8, #32
    s.mul        s8, s14, s15
    v.insert     v2, s7, #8
    v.extract    s7, v1, #12
    v.insert     v6, s16, #8
    s.or         s14, s17, s18
    s.lshri      s16, s1, #32
    v.extract    s17, v0, #12
    s.shli       s18, s7, #32
    s.mul        s7, s14, s15
    v.insert     v2, s1, #9
    v.extract    s1, v1, #13
    v.insert     v6, s16, #9
    s.or         s14, s17, s18
    s.lshri      s16, s8, #32
    v.extract    s17, v0, #13
    s.shli       s18, s1, #32
    s.mul        s1, s14, s15
    v.insert     v2, s8, #10
    v.extract    s8, v1, #14
    v.insert     v6, s16, #10
    s.or         s14, s17, s18
    s.lshri      s16, s7, #32
    v.extract    s17, v0, #14
    s.shli       s18, s8, #32
    s.mul        s8, s14, s15
    v.insert     v2, s7, #11
    v.extract    s7, v1, #15
    v.insert     v6, s16, #11
    s.or         s14, s17, s18
    s.lshri      s16, s1, #32
    v.extract    s17, v0, #15
    s.shli       s18, s7, #32
    s.mul        s7, s14, s15
    v.insert     v2, s1, #12
    v.insert     v6, s16, #12
    s.or         s1, s17, s18
    s.lshri      s14, s8, #32
    v.extract    s16, v8, #0
    s.mul        s17, s1, s15
    v.insert     v2, s8, #13
    v.insert     v6, s14, #13
    s.shli       s1, s16, #32
    s.lshri      s8, s7, #32
    v.extract    s14, v8, #1
    s.ashri      s15, s1, #32
    v.insert     v2, s7, #14
    v.insert     v6, s8, #14
    v.movi       v9, #0
    v.movi       v10, #0
    s.shli       s1, s14, #32
    s.lshri      s7, s17, #32
    s.lshri      s8, s15, #32
    v.extract    s14, v8, #2
    s.ashri      s16, s1, #32
    v.insert     v2, s17, #15
    v.insert     v6, s7, #15
    v.insert     v9, s15, #0
    v.insert     v10, s8, #0
    s.shli       s1, s14, #32
    s.lshri      s7, s16, #32
    v.extract    s8, v8, #3
    s.ashri      s14, s1, #32
    v.insert     v9, s16, #1
    v.insert     v10, s7, #1
    s.shli       s1, s8, #32
    s.lshri      s7, s14, #32
    v.extract    s8, v8, #4
    s.ashri      s15, s1, #32
    v.insert     v9, s14, #2
    v.insert     v10, s7, #2
    s.shli       s1, s8, #32
    s.lshri      s7, s15, #32
    v.extract    s8, v8, #5
    s.ashri      s14, s1, #32
    v.insert     v9, s15, #3
    v.insert     v10, s7, #3
    s.shli       s1, s8, #32
    s.lshri      s7, s14, #32
    v.extract    s8, v8, #6
    s.ashri      s15, s1, #32
    v.insert     v9, s14, #4
    v.insert     v10, s7, #4
    s.shli       s1, s8, #32
    s.lshri      s7, s15, #32
    v.extract    s8, v8, #7
    s.ashri      s14, s1, #32
    v.insert     v9, s15, #5
    v.insert     v10, s7, #5
    s.shli       s1, s8, #32
    s.lshri      s7, s14, #32
    v.extract    s8, v8, #8
    s.ashri      s15, s1, #32
    v.insert     v9, s14, #6
    v.insert     v10, s7, #6
    s.shli       s1, s8, #32
    s.lshri      s7, s15, #32
    v.extract    s8, v8, #9
    s.ashri      s14, s1, #32
    v.insert     v9, s15, #7
    v.insert     v10, s7, #7
    s.shli       s1, s8, #32
    s.lshri      s7, s14, #32
    v.extract    s8, v8, #10
    s.ashri      s15, s1, #32
    v.insert     v9, s14, #8
    v.insert     v10, s7, #8
    s.shli       s1, s8, #32
    s.lshri      s7, s15, #32
    v.extract    s8, v8, #11
    s.ashri      s14, s1, #32
    v.insert     v9, s15, #9
    v.insert     v10, s7, #9
    s.shli       s1, s8, #32
    s.lshri      s7, s14, #32
    v.extract    s8, v8, #12
    s.ashri      s15, s1, #32
    v.insert     v9, s14, #10
    v.insert     v10, s7, #10
    s.shli       s1, s8, #32
    s.lshri      s7, s15, #32
    v.extract    s8, v8, #13
    s.ashri      s14, s1, #32
    v.insert     v9, s15, #11
    v.insert     v10, s7, #11
    s.shli       s1, s8, #32
    s.lshri      s7, s14, #32
    v.extract    s8, v8, #14
    s.ashri      s15, s1, #32
    v.insert     v9, s14, #12
    v.insert     v10, s7, #12
    s.shli       s1, s8, #32
    s.lshri      s7, s15, #32
    v.extract    s8, v8, #15
    s.ashri      s14, s1, #32
    v.insert     v9, s15, #13
    v.insert     v10, s7, #13
    s.shli       s1, s8, #32
    s.lshri      s7, s14, #32
    s.ashri      s8, s1, #32
    v.insert     v9, s14, #14
    v.insert     v10, s7, #14
    s.lshri      s1, s8, #32
    v.insert     v9, s8, #15
    v.insert     v10, s1, #15
    v.extract    s1, v6, #0
    v.extract    s7, v9, #0
    v.extract    s8, v10, #0
    v.extract    s14, v2, #0
    s.shli       s15, s8, #32
    s.shli       s8, s1, #32
    v.extract    s1, v10, #1
    v.extract    s16, v6, #1
    s.or         s17, s7, s15
    s.or         s7, s14, s8
    v.movi       v8, #0
    v.extract    s8, v9, #1
    s.shli       s14, s1, #32
    v.extract    s1, v2, #1
    s.shli       s15, s16, #32
    s.add        s16, s17, s7
    v.extract    s7, v10, #2
    v.extract    s17, v6, #2
    s.or         s18, s8, s14
    s.or         s8, s1, s15
    v.movi       v11, #0
    v.insert     v8, s16, #0
    v.extract    s1, v9, #2
    s.shli       s14, s7, #32
    v.extract    s7, v2, #2
    s.shli       s15, s17, #32
    s.lshri      s17, s16, #32
    s.add        s16, s18, s8
    v.extract    s8, v10, #3
    s.or         s18, s1, s14
    v.extract    s1, v6, #3
    s.or         s14, s7, s15
    v.insert     v11, s17, #0
    v.insert     v8, s16, #1
    v.extract    s7, v9, #3
    s.shli       s15, s8, #32
    v.extract    s8, v2, #3
    s.shli       s17, s1, #32
    s.lshri      s1, s16, #32
    s.add        s16, s18, s14
    v.extract    s14, v10, #4
    s.or         s18, s7, s15
    v.extract    s7, v6, #4
    s.or         s15, s8, s17
    v.insert     v11, s1, #1
    v.insert     v8, s16, #2
    v.extract    s1, v9, #4
    s.shli       s8, s14, #32
    v.extract    s14, v2, #4
    s.shli       s17, s7, #32
    s.lshri      s7, s16, #32
    s.add        s16, s18, s15
    v.extract    s15, v10, #5
    s.or         s18, s1, s8
    v.extract    s1, v6, #5
    s.or         s8, s14, s17
    v.insert     v11, s7, #2
    v.insert     v8, s16, #3
    v.extract    s7, v9, #5
    s.shli       s14, s15, #32
    v.extract    s15, v2, #5
    s.shli       s17, s1, #32
    s.lshri      s1, s16, #32
    s.add        s16, s18, s8
    v.extract    s8, v10, #6
    s.or         s18, s7, s14
    v.extract    s7, v6, #6
    s.or         s14, s15, s17
    v.insert     v11, s1, #3
    v.insert     v8, s16, #4
    v.extract    s1, v9, #6
    s.shli       s15, s8, #32
    v.extract    s8, v2, #6
    s.shli       s17, s7, #32
    s.lshri      s7, s16, #32
    s.add        s16, s18, s14
    v.extract    s14, v10, #7
    s.or         s18, s1, s15
    v.extract    s1, v6, #7
    s.or         s15, s8, s17
    v.insert     v11, s7, #4
    v.insert     v8, s16, #5
    v.extract    s7, v9, #7
    s.shli       s8, s14, #32
    v.extract    s14, v2, #7
    s.shli       s17, s1, #32
    s.lshri      s1, s16, #32
    s.add        s16, s18, s15
    v.extract    s15, v10, #8
    s.or         s18, s7, s8
    v.extract    s7, v6, #8
    s.or         s8, s14, s17
    v.insert     v11, s1, #5
    v.insert     v8, s16, #6
    v.extract    s1, v9, #8
    s.shli       s14, s15, #32
    v.extract    s15, v2, #8
    s.shli       s17, s7, #32
    s.lshri      s7, s16, #32
    s.add        s16, s18, s8
    v.extract    s8, v10, #9
    s.or         s18, s1, s14
    v.extract    s1, v6, #9
    s.or         s14, s15, s17
    v.insert     v11, s7, #6
    v.insert     v8, s16, #7
    v.extract    s7, v9, #9
    s.shli       s15, s8, #32
    v.extract    s8, v2, #9
    s.shli       s17, s1, #32
    s.lshri      s1, s16, #32
    s.add        s16, s18, s14
    v.extract    s14, v10, #10
    s.or         s18, s7, s15
    v.extract    s7, v6, #10
    s.or         s15, s8, s17
    v.insert     v11, s1, #7
    v.insert     v8, s16, #8
    v.extract    s1, v9, #10
    s.shli       s8, s14, #32
    v.extract    s14, v2, #10
    s.shli       s17, s7, #32
    s.lshri      s7, s16, #32
    s.add        s16, s18, s15
    v.extract    s15, v10, #11
    s.or         s18, s1, s8
    v.extract    s1, v6, #11
    s.or         s8, s14, s17
    v.insert     v11, s7, #8
    v.insert     v8, s16, #9
    v.extract    s7, v9, #11
    s.shli       s14, s15, #32
    v.extract    s15, v2, #11
    s.shli       s17, s1, #32
    s.lshri      s1, s16, #32
    s.add        s16, s18, s8
    v.extract    s8, v10, #12
    s.or         s18, s7, s14
    v.extract    s7, v6, #12
    s.or         s14, s15, s17
    v.insert     v11, s1, #9
    v.insert     v8, s16, #10
    v.extract    s1, v9, #12
    s.shli       s15, s8, #32
    v.extract    s8, v2, #12
    s.shli       s17, s7, #32
    s.lshri      s7, s16, #32
    s.add        s16, s18, s14
    v.extract    s14, v10, #13
    s.or         s18, s1, s15
    v.extract    s1, v6, #13
    s.or         s15, s8, s17
    v.insert     v11, s7, #10
    v.insert     v8, s16, #11
    v.extract    s7, v9, #13
    s.shli       s8, s14, #32
    v.extract    s14, v2, #13
    s.shli       s17, s1, #32
    s.lshri      s1, s16, #32
    s.add        s16, s18, s15
    v.extract    s15, v10, #14
    s.or         s18, s7, s8
    v.extract    s7, v6, #14
    s.or         s8, s14, s17
    v.insert     v11, s1, #11
    v.insert     v8, s16, #12
    v.extract    s1, v9, #14
    s.shli       s14, s15, #32
    v.extract    s15, v2, #14
    s.shli       s17, s7, #32
    s.lshri      s7, s16, #32
    s.add        s16, s18, s8
    v.extract    s8, v10, #15
    s.or         s18, s1, s14
    v.extract    s1, v6, #15
    s.or         s14, s15, s17
    v.insert     v11, s7, #12
    v.insert     v8, s16, #13
    v.extract    s7, v9, #15
    s.shli       s15, s8, #32
    v.extract    s8, v2, #15
    s.shli       s17, s1, #32
    s.lshri      s1, s16, #32
    s.add        s16, s18, s14
    s.or         s14, s7, s15
    s.or         s7, s8, s17
    v.insert     v11, s1, #13
    v.insert     v8, s16, #14
    s.lshri      s1, s16, #32
    s.add        s8, s14, s7
    v.insert     v11, s1, #14
    v.insert     v8, s8, #15
    v.movi       v2, #31
    s.lshri      s1, s8, #32
    v.movi       v6, #1
    v.insert     v11, s1, #15
    v.ashr       v9, v8, v2
    v.movi       v2, #0
    s.movz       s1, #0
    v.cmp.ne     p2, v11, v9
    @p2 v.sel        v9, v6, v2
    v.reduce.or  s7, v9
    s.cmp.eq     s8, s7, s1
    br.nz        s8, narrow_ok_4
    trap         #677220
narrow_ok_4:
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s9, v8]               // index is in elements (ISA sec 9.1)
    v.movi       v6, #0
    s.movz       s1, #1
    vf.cvt.f16.f32 v8, v2
    vf.add       v2, v8, v7
    vf.add       v7, v2, v5
    vf.mul       v2, v7, v7
    vf.add       v5, v4, v2
    @p1 v.sel        v6, v5, v4
    v.mov        v4, v6
    s.add        s6, s6, s5
    br.nz        s1, for_1
endfor_2:
    s.ld.d       s1, [s2, #0]                    // one element, not a vector
    v.movi       v0, #0
    v.movi       v1, #0
    vf.reduce.add.b v2, v4
    v.movi       v4, #0
    s.addi       s2, s3, #0
    vf.add       v5, v2, v4
    s.lshri      s3, s1, #32
    v.insert     v0, s1, #0
    v.insert     v1, s3, #0
    v.insert     v0, s1, #1
    v.insert     v1, s3, #1
    v.insert     v0, s1, #2
    v.insert     v1, s3, #2
    v.insert     v0, s1, #3
    v.insert     v1, s3, #3
    v.insert     v0, s1, #4
    v.insert     v1, s3, #4
    v.insert     v0, s1, #5
    v.insert     v1, s3, #5
    v.insert     v0, s1, #6
    v.insert     v1, s3, #6
    v.insert     v0, s1, #7
    v.insert     v1, s3, #7
    v.insert     v0, s1, #8
    v.insert     v1, s3, #8
    v.insert     v0, s1, #9
    v.insert     v1, s3, #9
    v.insert     v0, s1, #10
    v.insert     v1, s3, #10
    v.insert     v0, s1, #11
    v.insert     v1, s3, #11
    v.insert     v0, s1, #12
    v.insert     v1, s3, #12
    v.insert     v0, s1, #13
    v.insert     v1, s3, #13
    v.insert     v0, s1, #14
    v.insert     v1, s3, #14
    v.insert     v0, s1, #15
    v.insert     v1, s3, #15
for_5:
    s.cmp.ge     s1, s2, s4
    br.nz        s1, endfor_6
    v.splat      v2, s2
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v6, s2
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s1, #128
    v.extract    s3, v1, #0
    v.splat      v8, s2
    s.muli       s6, s2, #2
    s.muli       s7, s2, #2
    v.add        v9, v2, v4
    v.movi       v2, #0
    v.splat      v4, s1
    v.add        v10, v6, v7
    v.movi       v6, #0
    v.splat      v7, s1
    v.extract    s1, v0, #0
    s.shli       s8, s3, #32
    v.extract    s3, v1, #1
    v.add        v11, v8, v3
    v.movi       v8, #128
    s.shli       s14, s2, #1                     // element offset -> bytes (x2)
    s.or         s15, s1, s8
    s.movz       s1, #0
    v.cmp.ge     p1, v9, v2
    v.cmp.lt     p2, v9, v4
    v.cmp.ge     p3, v10, v6
    v.cmp.lt     p4, v10, v7
    v.movi       v2, #0
    v.extract    s8, v0, #1
    s.shli       s16, s3, #32
    s.add        s3, s10, s6
    p.and        p5, p1, p2
    s.add        s6, s11, s7
    p.and        p1, p3, p4
    s.add        s7, s12, s14                    // &in_ptr4[...]
    s.cmp.ge     s17, s15, s1
    v.cmp.lt     p2, v11, v8
    s.or         s15, s8, s16
    v.extract    s8, v1, #2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v4, [s3, #0]
    v.extract    s3, v0, #2
    s.shli       s16, s8, #32
    s.cmp.ge     s8, s15, s1
    s.or         s15, s3, s16
    v.extract    s3, v1, #3
    s.cmp.ge     s16, s15, s1
    s.shli       s15, s3, #32
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v6, [s6, #0]
    v.extract    s3, v0, #3
    vf.cvt.f16.f32 v7, v4
    s.or         s6, s3, s15
    v.extract    s3, v1, #4
    s.cmp.ge     s15, s6, s1
    s.shli       s6, s3, #32
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s7, #0]
    v.insert     v2, s17, #0
    v.extract    s3, v0, #4
    v.extract    s7, v1, #5
    v.insert     v2, s8, #1
    s.or         s8, s3, s6
    v.extract    s3, v0, #5
    v.insert     v2, s16, #2
    s.shli       s6, s7, #32
    s.cmp.ge     s7, s8, s1
    v.insert     v2, s15, #3
    v.extract    s8, v1, #6
    s.or         s15, s3, s6
    v.insert     v2, s7, #4
    v.extract    s3, v0, #6
    s.shli       s6, s8, #32
    s.cmp.ge     s7, s15, s1
    s.or         s8, s3, s6
    v.insert     v2, s7, #5
    s.cmp.ge     s3, s8, s1
    vf.cvt.f16.f32 v8, v6
    v.extract    s6, v1, #7
    v.extract    s7, v0, #7
    s.shli       s8, s6, #32
    v.insert     v2, s3, #6
    vf.cvt.f16.f32 v6, v4
    v.extract    s3, v1, #8
    s.or         s6, s7, s8
    v.extract    s7, v0, #8
    s.shli       s8, s3, #32
    s.cmp.ge     s3, s6, s1
    v.extract    s6, v1, #9
    s.or         s15, s7, s8
    v.insert     v2, s3, #7
    v.extract    s3, v0, #9
    s.shli       s7, s6, #32
    s.cmp.ge     s6, s15, s1
    v.extract    s8, v1, #10
    s.or         s15, s3, s7
    v.insert     v2, s6, #8
    v.extract    s3, v0, #10
    s.shli       s6, s8, #32
    s.cmp.ge     s7, s15, s1
    v.extract    s1, v1, #11
    s.or         s8, s3, s6
    s.movz       s3, #0
    v.insert     v2, s7, #9
    v.extract    s6, v0, #11
    s.shli       s7, s1, #32
    s.cmp.ge     s1, s8, s3
    v.extract    s8, v1, #12
    s.or         s15, s6, s7
    v.insert     v2, s1, #10
    v.extract    s1, v0, #12
    s.shli       s6, s8, #32
    s.cmp.ge     s7, s15, s3
    v.extract    s8, v1, #13
    s.or         s15, s1, s6
    v.insert     v2, s7, #11
    v.extract    s1, v0, #13
    s.shli       s6, s8, #32
    s.cmp.ge     s7, s15, s3
    v.extract    s8, v1, #14
    s.or         s15, s1, s6
    v.insert     v2, s7, #12
    v.extract    s1, v0, #14
    s.shli       s6, s8, #32
    s.cmp.ge     s7, s15, s3
    v.extract    s8, v1, #15
    v.extract    s15, v1, #0
    s.or         s16, s1, s6
    v.insert     v2, s7, #13
    v.extract    s1, v0, #15
    s.shli       s6, s8, #32
    v.extract    s7, v0, #0
    s.shli       s8, s15, #32
    s.cmp.ge     s15, s16, s3
    v.extract    s16, v1, #1
    s.or         s17, s1, s6
    s.or         s1, s7, s8
    s.movz       s6, #512
    v.insert     v2, s15, #14
    v.movi       v4, #0
    v.extract    s7, v0, #1
    s.shli       s8, s16, #32
    s.cmp.ge     s15, s17, s3
    s.cmp.lt     s3, s1, s6
    v.extract    s1, v1, #2
    s.or         s16, s7, s8
    v.insert     v2, s15, #15
    v.insert     v4, s3, #0
    v.extract    s3, v0, #2
    s.shli       s7, s1, #32
    s.cmp.lt     s1, s16, s6
    v.extract    s8, v1, #3
    s.or         s15, s3, s7
    v.insert     v4, s1, #1
    v.extract    s1, v0, #3
    s.shli       s3, s8, #32
    s.cmp.lt     s7, s15, s6
    v.extract    s8, v1, #4
    s.or         s15, s1, s3
    v.insert     v4, s7, #2
    v.extract    s1, v0, #4
    s.shli       s3, s8, #32
    s.cmp.lt     s7, s15, s6
    v.extract    s8, v1, #5
    s.or         s15, s1, s3
    v.insert     v4, s7, #3
    v.extract    s1, v0, #5
    s.shli       s3, s8, #32
    s.cmp.lt     s7, s15, s6
    v.extract    s8, v1, #6
    s.or         s15, s1, s3
    v.insert     v4, s7, #4
    v.extract    s1, v0, #6
    s.shli       s3, s8, #32
    s.cmp.lt     s7, s15, s6
    v.extract    s8, v1, #7
    s.or         s15, s1, s3
    v.insert     v4, s7, #5
    v.extract    s1, v0, #7
    s.cmp.lt     s3, s15, s6
    v.movi       v9, #0
    s.shli       s7, s8, #32
    v.insert     v4, s3, #6
    v.cmp.ne     p1, v2, v9
    v.extract    s3, v1, #8
    s.or         s8, s1, s7
    v.extract    s1, v0, #8
    s.shli       s7, s3, #32
    s.cmp.lt     s3, s8, s6
    v.extract    s8, v1, #9
    s.or         s15, s1, s7
    v.insert     v4, s3, #7
    v.extract    s1, v0, #9
    s.shli       s3, s8, #32
    s.cmp.lt     s7, s15, s6
    v.extract    s8, v1, #10
    s.or         s15, s1, s3
    v.insert     v4, s7, #8
    v.extract    s1, v0, #10
    s.shli       s3, s8, #32
    s.cmp.lt     s7, s15, s6
    v.extract    s6, v1, #11
    s.or         s8, s1, s3
    s.movz       s1, #512
    v.insert     v4, s7, #9
    v.extract    s3, v0, #11
    s.shli       s7, s6, #32
    s.cmp.lt     s6, s8, s1
    v.extract    s8, v1, #12
    s.or         s15, s3, s7
    v.insert     v4, s6, #10
    v.extract    s3, v0, #12
    s.shli       s6, s8, #32
    s.cmp.lt     s7, s15, s1
    v.extract    s8, v1, #13
    s.or         s15, s3, s6
    v.insert     v4, s7, #11
    v.extract    s3, v0, #13
    s.shli       s6, s8, #32
    s.cmp.lt     s7, s15, s1
    v.extract    s8, v1, #14
    s.or         s15, s3, s6
    v.insert     v4, s7, #12
    v.extract    s3, v0, #14
    s.shli       s6, s8, #32
    s.cmp.lt     s7, s15, s1
    v.extract    s8, v1, #15
    s.or         s15, s3, s6
    v.insert     v4, s7, #13
    v.extract    s3, v0, #15
    s.shli       s6, s8, #32
    s.cmp.lt     s7, s15, s1
    s.or         s8, s3, s6
    v.insert     v4, s7, #14
    s.cmp.lt     s3, s8, s1
    v.movi       v2, #0
    v.insert     v4, s3, #15
    v.movi       v9, #1
    s.movz       s1, #0
    v.cmp.ne     p3, v4, v2
    p.and        p4, p1, p3
    @p4 v.sel        v4, v2, v9
    v.reduce.or  s3, v4
    s.cmp.eq     s6, s3, s1
    br.nz        s6, assert_ok_7
    trap         #677351
assert_ok_7:
    v.extract    s1, v1, #0
    v.extract    s3, v0, #0
    s.shli       s6, s1, #32
    v.extract    s1, v1, #1
    s.or         s7, s3, s6
    s.movz       s3, #128
    v.extract    s6, v0, #1
    s.shli       s8, s1, #32
    s.mul        s1, s7, s3
    v.extract    s7, v1, #2
    s.or         s15, s6, s8
    v.extract    s6, v0, #2
    s.shli       s8, s7, #32
    s.mul        s7, s15, s3
    v.extract    s15, v1, #3
    v.movi       v2, #0
    v.movi       v4, #0
    s.or         s16, s6, s8
    s.lshri      s6, s1, #32
    v.extract    s8, v0, #3
    s.shli       s17, s15, #32
    s.mul        s15, s16, s3
    v.insert     v2, s1, #0
    v.extract    s1, v1, #4
    v.insert     v4, s6, #0
    s.or         s6, s8, s17
    s.lshri      s8, s7, #32
    v.extract    s16, v0, #4
    s.shli       s17, s1, #32
    s.mul        s1, s6, s3
    v.insert     v2, s7, #1
    v.extract    s6, v1, #5
    v.insert     v4, s8, #1
    s.or         s7, s16, s17
    s.lshri      s8, s15, #32
    v.extract    s16, v0, #5
    s.shli       s17, s6, #32
    s.mul        s6, s7, s3
    v.insert     v2, s15, #2
    v.extract    s7, v1, #6
    v.insert     v4, s8, #2
    s.or         s8, s16, s17
    s.lshri      s15, s1, #32
    v.extract    s16, v0, #6
    s.shli       s17, s7, #32
    s.mul        s7, s8, s3
    v.insert     v2, s1, #3
    v.extract    s1, v1, #7
    v.insert     v4, s15, #3
    s.or         s8, s16, s17
    s.lshri      s15, s6, #32
    v.extract    s16, v0, #7
    s.shli       s17, s1, #32
    s.mul        s1, s8, s3
    v.insert     v2, s6, #4
    v.extract    s6, v1, #8
    v.insert     v4, s15, #4
    s.or         s8, s16, s17
    s.lshri      s15, s7, #32
    v.extract    s16, v0, #8
    s.shli       s17, s6, #32
    s.mul        s6, s8, s3
    v.extract    s3, v1, #9
    v.insert     v2, s7, #5
    v.insert     v4, s15, #5
    s.or         s7, s16, s17
    s.movz       s8, #128
    s.lshri      s15, s1, #32
    v.extract    s16, v0, #9
    s.shli       s17, s3, #32
    s.mul        s3, s7, s8
    v.insert     v2, s1, #6
    v.extract    s1, v1, #10
    v.insert     v4, s15, #6
    s.or         s7, s16, s17
    s.lshri      s15, s6, #32
    v.extract    s16, v0, #10
    s.shli       s17, s1, #32
    s.mul        s1, s7, s8
    v.insert     v2, s6, #7
    v.extract    s6, v1, #11
    v.insert     v4, s15, #7
    s.or         s7, s16, s17
    s.lshri      s15, s3, #32
    v.extract    s16, v0, #11
    s.shli       s17, s6, #32
    s.mul        s6, s7, s8
    v.insert     v2, s3, #8
    v.extract    s3, v1, #12
    v.insert     v4, s15, #8
    s.or         s7, s16, s17
    s.lshri      s15, s1, #32
    v.extract    s16, v0, #12
    s.shli       s17, s3, #32
    s.mul        s3, s7, s8
    v.insert     v2, s1, #9
    v.extract    s1, v1, #13
    v.insert     v4, s15, #9
    s.or         s7, s16, s17
    s.lshri      s15, s6, #32
    v.extract    s16, v0, #13
    s.shli       s17, s1, #32
    s.mul        s1, s7, s8
    v.insert     v2, s6, #10
    v.extract    s6, v1, #14
    v.insert     v4, s15, #10
    s.or         s7, s16, s17
    s.lshri      s15, s3, #32
    v.extract    s16, v0, #14
    s.shli       s17, s6, #32
    s.mul        s6, s7, s8
    v.insert     v2, s3, #11
    v.extract    s3, v1, #15
    v.insert     v4, s15, #11
    s.or         s7, s16, s17
    s.lshri      s15, s1, #32
    v.extract    s16, v0, #15
    s.shli       s17, s3, #32
    s.mul        s3, s7, s8
    v.insert     v2, s1, #12
    v.insert     v4, s15, #12
    s.or         s1, s16, s17
    s.lshri      s7, s6, #32
    v.extract    s15, v11, #0
    s.mul        s16, s1, s8
    v.insert     v2, s6, #13
    v.insert     v4, s7, #13
    s.shli       s1, s15, #32
    s.lshri      s6, s3, #32
    v.extract    s7, v11, #1
    s.ashri      s8, s1, #32
    v.insert     v2, s3, #14
    v.insert     v4, s6, #14
    v.movi       v9, #0
    v.movi       v10, #0
    s.shli       s1, s7, #32
    s.lshri      s3, s16, #32
    s.lshri      s6, s8, #32
    v.extract    s7, v11, #2
    s.ashri      s15, s1, #32
    v.insert     v2, s16, #15
    v.insert     v4, s3, #15
    v.insert     v9, s8, #0
    v.insert     v10, s6, #0
    s.shli       s1, s7, #32
    s.lshri      s3, s15, #32
    v.extract    s6, v11, #3
    s.ashri      s7, s1, #32
    v.insert     v9, s15, #1
    v.insert     v10, s3, #1
    s.shli       s1, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s6, v11, #4
    s.ashri      s8, s1, #32
    v.insert     v9, s7, #2
    v.insert     v10, s3, #2
    s.shli       s1, s6, #32
    s.lshri      s3, s8, #32
    v.extract    s6, v11, #5
    s.ashri      s7, s1, #32
    v.insert     v9, s8, #3
    v.insert     v10, s3, #3
    s.shli       s1, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s6, v11, #6
    s.ashri      s8, s1, #32
    v.insert     v9, s7, #4
    v.insert     v10, s3, #4
    s.shli       s1, s6, #32
    s.lshri      s3, s8, #32
    v.extract    s6, v11, #7
    s.ashri      s7, s1, #32
    v.insert     v9, s8, #5
    v.insert     v10, s3, #5
    s.shli       s1, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s6, v11, #8
    s.ashri      s8, s1, #32
    v.insert     v9, s7, #6
    v.insert     v10, s3, #6
    s.shli       s1, s6, #32
    s.lshri      s3, s8, #32
    v.extract    s6, v11, #9
    s.ashri      s7, s1, #32
    v.insert     v9, s8, #7
    v.insert     v10, s3, #7
    s.shli       s1, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s6, v11, #10
    s.ashri      s8, s1, #32
    v.insert     v9, s7, #8
    v.insert     v10, s3, #8
    s.shli       s1, s6, #32
    s.lshri      s3, s8, #32
    v.extract    s6, v11, #11
    s.ashri      s7, s1, #32
    v.insert     v9, s8, #9
    v.insert     v10, s3, #9
    s.shli       s1, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s6, v11, #12
    s.ashri      s8, s1, #32
    v.insert     v9, s7, #10
    v.insert     v10, s3, #10
    s.shli       s1, s6, #32
    s.lshri      s3, s8, #32
    v.extract    s6, v11, #13
    s.ashri      s7, s1, #32
    v.insert     v9, s8, #11
    v.insert     v10, s3, #11
    s.shli       s1, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s6, v11, #14
    s.ashri      s8, s1, #32
    v.insert     v9, s7, #12
    v.insert     v10, s3, #12
    s.shli       s1, s6, #32
    s.lshri      s3, s8, #32
    v.extract    s6, v11, #15
    s.ashri      s7, s1, #32
    v.insert     v9, s8, #13
    v.insert     v10, s3, #13
    s.shli       s1, s6, #32
    s.lshri      s3, s7, #32
    s.ashri      s6, s1, #32
    v.insert     v9, s7, #14
    v.insert     v10, s3, #14
    s.lshri      s1, s6, #32
    v.insert     v9, s6, #15
    v.insert     v10, s1, #15
    v.extract    s1, v4, #0
    v.extract    s3, v9, #0
    v.extract    s6, v10, #0
    v.extract    s7, v2, #0
    s.shli       s8, s6, #32
    s.shli       s6, s1, #32
    v.extract    s1, v10, #1
    v.extract    s15, v4, #1
    s.or         s16, s3, s8
    s.or         s3, s7, s6
    v.movi       v11, #0
    v.extract    s6, v9, #1
    s.shli       s7, s1, #32
    v.extract    s1, v2, #1
    s.shli       s8, s15, #32
    s.add        s15, s16, s3
    v.extract    s3, v10, #2
    v.extract    s16, v4, #2
    s.or         s17, s6, s7
    s.or         s6, s1, s8
    v.movi       v12, #0
    v.insert     v11, s15, #0
    v.extract    s1, v9, #2
    s.shli       s7, s3, #32
    v.extract    s3, v2, #2
    s.shli       s8, s16, #32
    s.lshri      s16, s15, #32
    s.add        s15, s17, s6
    v.extract    s6, v10, #3
    s.or         s17, s1, s7
    v.extract    s1, v4, #3
    s.or         s7, s3, s8
    v.insert     v12, s16, #0
    v.insert     v11, s15, #1
    v.extract    s3, v9, #3
    s.shli       s8, s6, #32
    v.extract    s6, v2, #3
    s.shli       s16, s1, #32
    s.lshri      s1, s15, #32
    s.add        s15, s17, s7
    v.extract    s7, v10, #4
    s.or         s17, s3, s8
    v.extract    s3, v4, #4
    s.or         s8, s6, s16
    v.insert     v12, s1, #1
    v.insert     v11, s15, #2
    v.extract    s1, v9, #4
    s.shli       s6, s7, #32
    v.extract    s7, v2, #4
    s.shli       s16, s3, #32
    s.lshri      s3, s15, #32
    s.add        s15, s17, s8
    v.extract    s8, v10, #5
    s.or         s17, s1, s6
    v.extract    s1, v4, #5
    s.or         s6, s7, s16
    v.insert     v12, s3, #2
    v.insert     v11, s15, #3
    v.extract    s3, v9, #5
    s.shli       s7, s8, #32
    v.extract    s8, v2, #5
    s.shli       s16, s1, #32
    s.lshri      s1, s15, #32
    s.add        s15, s17, s6
    v.extract    s6, v10, #6
    s.or         s17, s3, s7
    v.extract    s3, v4, #6
    s.or         s7, s8, s16
    v.insert     v12, s1, #3
    v.insert     v11, s15, #4
    v.extract    s1, v9, #6
    s.shli       s8, s6, #32
    v.extract    s6, v2, #6
    s.shli       s16, s3, #32
    s.lshri      s3, s15, #32
    s.add        s15, s17, s7
    v.extract    s7, v10, #7
    s.or         s17, s1, s8
    v.extract    s1, v4, #7
    s.or         s8, s6, s16
    v.insert     v12, s3, #4
    v.insert     v11, s15, #5
    v.extract    s3, v9, #7
    s.shli       s6, s7, #32
    v.extract    s7, v2, #7
    s.shli       s16, s1, #32
    s.lshri      s1, s15, #32
    s.add        s15, s17, s8
    v.extract    s8, v10, #8
    s.or         s17, s3, s6
    v.extract    s3, v4, #8
    s.or         s6, s7, s16
    v.insert     v12, s1, #5
    v.insert     v11, s15, #6
    v.extract    s1, v9, #8
    s.shli       s7, s8, #32
    v.extract    s8, v2, #8
    s.shli       s16, s3, #32
    s.lshri      s3, s15, #32
    s.add        s15, s17, s6
    v.extract    s6, v10, #9
    s.or         s17, s1, s7
    v.extract    s1, v4, #9
    s.or         s7, s8, s16
    v.insert     v12, s3, #6
    v.insert     v11, s15, #7
    v.extract    s3, v9, #9
    s.shli       s8, s6, #32
    v.extract    s6, v2, #9
    s.shli       s16, s1, #32
    s.lshri      s1, s15, #32
    s.add        s15, s17, s7
    v.extract    s7, v10, #10
    s.or         s17, s3, s8
    v.extract    s3, v4, #10
    s.or         s8, s6, s16
    v.insert     v12, s1, #7
    v.insert     v11, s15, #8
    v.extract    s1, v9, #10
    s.shli       s6, s7, #32
    v.extract    s7, v2, #10
    s.shli       s16, s3, #32
    s.lshri      s3, s15, #32
    s.add        s15, s17, s8
    v.extract    s8, v10, #11
    s.or         s17, s1, s6
    v.extract    s1, v4, #11
    s.or         s6, s7, s16
    v.insert     v12, s3, #8
    v.insert     v11, s15, #9
    v.extract    s3, v9, #11
    s.shli       s7, s8, #32
    v.extract    s8, v2, #11
    s.shli       s16, s1, #32
    s.lshri      s1, s15, #32
    s.add        s15, s17, s6
    v.extract    s6, v10, #12
    s.or         s17, s3, s7
    v.extract    s3, v4, #12
    s.or         s7, s8, s16
    v.insert     v12, s1, #9
    v.insert     v11, s15, #10
    v.extract    s1, v9, #12
    s.shli       s8, s6, #32
    v.extract    s6, v2, #12
    s.shli       s16, s3, #32
    s.lshri      s3, s15, #32
    s.add        s15, s17, s7
    v.extract    s7, v10, #13
    s.or         s17, s1, s8
    v.extract    s1, v4, #13
    s.or         s8, s6, s16
    v.insert     v12, s3, #10
    v.insert     v11, s15, #11
    v.extract    s3, v9, #13
    s.shli       s6, s7, #32
    v.extract    s7, v2, #13
    s.shli       s16, s1, #32
    s.lshri      s1, s15, #32
    s.add        s15, s17, s8
    v.extract    s8, v10, #14
    s.or         s17, s3, s6
    v.extract    s3, v4, #14
    s.or         s6, s7, s16
    v.insert     v12, s1, #11
    v.insert     v11, s15, #12
    v.extract    s1, v9, #14
    s.shli       s7, s8, #32
    v.extract    s8, v2, #14
    s.shli       s16, s3, #32
    s.lshri      s3, s15, #32
    s.add        s15, s17, s6
    v.extract    s6, v10, #15
    s.or         s17, s1, s7
    v.extract    s1, v4, #15
    s.or         s7, s8, s16
    v.insert     v12, s3, #12
    v.insert     v11, s15, #13
    v.extract    s3, v9, #15
    s.shli       s8, s6, #32
    v.extract    s6, v2, #15
    s.shli       s16, s1, #32
    s.lshri      s1, s15, #32
    s.add        s15, s17, s7
    s.or         s7, s3, s8
    s.or         s3, s6, s16
    v.insert     v12, s1, #13
    v.insert     v11, s15, #14
    s.lshri      s1, s15, #32
    s.add        s6, s7, s3
    v.insert     v12, s1, #14
    v.insert     v11, s6, #15
    v.movi       v2, #31
    s.lshri      s1, s6, #32
    v.movi       v4, #1
    v.insert     v12, s1, #15
    v.ashr       v9, v11, v2
    v.movi       v2, #0
    s.movz       s1, #0
    v.cmp.ne     p1, v12, v9
    @p1 v.sel        v9, v4, v2
    v.reduce.or  s3, v9
    s.cmp.eq     s6, s3, s1
    br.nz        s6, narrow_ok_8
    trap         #677220
narrow_ok_8:
    .li       s1, #1124073472
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #925353388
    v.splat      v9, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v10, v2                         // ISA 8.8: <= 2**-22 relative
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.h v12, [s9, v11]             // index is in elements (ISA sec 9.1)
    .li       s1, #1077936128
    v.splat      v11, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s1, s13, s14                    // &out_ptr1[...]
    s.movz       s3, #1
    vf.cvt.f16.f32 v13, v12
    vf.add       v12, v13, v7
    .li       s6, #3204448256
    v.splat      v7, s6                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v13, v12, v8
    vf.fms       v8, v2, v10, v4
    vf.fms       v2, v10, v8, v10
    vf.neg       v4, v2                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v2, v4, v10
    vf.mul       v4, v5, v2                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v2, v4, v9
    v.rsqrt.approx v4, v2                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v8, v4, v4
    vf.mul       v9, v4, v7
    vf.fms       v7, v2, v8, v11
    vf.mul       v2, v9, v7                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v7, v2, v4
    v.extract    s6, v7, #0
    v.splat      v2, s6
    vf.mul       v4, v13, v2
    vf.mul       v2, v4, v6
    vf.cvt.f32.f16 v4, v2
    @p2 v.st.h       [s1, #0], v4
    s.add        s2, s2, s5
    br.nz        s3, for_5
endfor_6:
    exit
    exit
