    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // out_ptr1: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // out_ptr3: device_ptr64 at arg_base+24
    s.rdspecial  s1, arg_base
    s.ld.d       s7, [s1, #48]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s8, #512
    s.mul        s9, s1, s8
    s.add        s1, s7, s9                      // this context's own scratch
    s.addi       s7, s1, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s8, #0
    s.st.d       [s7, #0], s2
    s.movz       s8, #1024
    s.st.d       [s7, #8], s8
    s.movz       s8, #144
    s.st.d       [s7, #16], s8
    s.movz       s8, #288
    s.st.d       [s7, #48], s8
    s.movz       s8, #2
    s.st.d       [s7, #56], s8
    .li       s8, #68719476737
    s.st.d       [s7, #88], s8
    .li       s8, #1108101562368
    s.st.d       [s7, #104], s8
    fence.release.device
    td.load      d0, [s7]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s7, #1
    s.movz       s8, #0
    s.movz       s9, #144
    s.movz       s10, #16
    v.splat      v0, s4
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v2, #128
    v.movi       v3, #0
    v.movi       v4, #1
    v.cmp.lt     p1, v0, v3
    v.cmp.lt     p2, v2, v3
    v.sub        v4, v3, v0
    @p1 v.sel        v5, v4, v0
    v.sub        v0, v3, v2
    @p2 v.sel        v4, v0, v2
    v.movi       v0, #127
    v.and        v2, v5, v0
    v.sub        v0, v3, v2
    @p1 v.sel        v3, v0, v2
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v2, s7
    v.cmp.lt     p1, v0, v2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v0, [s3, v3]               // index is in elements (ISA sec 9.1)
    s.addi       s3, s8, #0
    .li       s7, #4286578688
    v.splat      v2, s7                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v3, #0
    v.mov        v3, v2
for_1:
    s.cmp.ge     s7, s3, s9
    br.nz        s7, endfor_2
    v.splat      v4, s3
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s7, #144
    s.movz       s11, #1024
    s.muli       s12, s4, #288
    v.add        v6, v4, v5
    v.movi       v4, #0
    v.splat      v5, s7
    v.splat      v7, s4
    v.movi       v8, #0
    v.splat      v9, s11
    s.muli       s7, s3, #2
    v.cmp.ge     p1, v6, v4
    v.cmp.lt     p2, v6, v5
    v.cmp.ge     p3, v7, v8
    v.cmp.lt     p4, v7, v9
    s.add        s11, s2, s12
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s12, s11, s7
    p.and        p2, p5, p1
    v.splat      v4, s3
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v5, [s12, #0]
    v.extract    s7, v0, #0
    .li       s11, #1031798784
    v.splat      v6, s11                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v7, v4, v1
    v.splat      v4, s7
    v.movi       v8, #0
    v.movi       v9, #144
    v.cmp.le     p1, v7, v4
    @p1 v.sel        v4, v8, v2
    v.cmp.lt     p1, v7, v9
    v.movi       v7, #0
    s.add        s7, s3, s10
    s.movz       s11, #1
    vf.cvt.bf16.f32 v8, v5
    vf.mul       v5, v8, v6
    vf.add       v6, v5, v4
    vf.max.prop  v4, v3, v6
    @p1 v.sel        v5, v4, v3
    v.mov        v7, v5
    v.mov        v3, v7
    s.mov        s3, s7
    br.nz        s11, for_1
endfor_2:
    v.movi       v4, #1
    v.movi       v5, #0
    vf.cmp.uo    p1, v3, v3
    v.movi       v6, #0
    @p1 v.sel        v7, v4, v5
    vf.reduce.max.b v4, v3
    .li       s3, #2143289344
    v.splat      v3, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.reduce.or.b v5, v7
    v.movi       v7, #0
    v.movi       v8, #0
    v.cmp.ne     p1, v5, v6
    @p1 v.sel        v5, v3, v4
    v.movi       v3, #0
    s.addi       s3, s8, #0
    vf.add       v4, v5, v7
    v.mov        v3, v8
for_3:
    s.cmp.ge     s7, s3, s9
    br.nz        s7, endfor_4
    v.splat      v5, s3
    v.iota       v6                              // arange(0, VLEN)
    s.movz       s7, #144
    s.movz       s11, #1024
    s.muli       s12, s4, #288
    v.add        v9, v5, v6
    v.movi       v5, #0
    v.splat      v6, s7
    v.splat      v10, s4
    v.movi       v11, #0
    v.splat      v12, s11
    s.muli       s7, s3, #2
    v.cmp.ge     p1, v9, v5
    v.cmp.lt     p2, v9, v6
    v.cmp.ge     p3, v10, v11
    v.cmp.lt     p4, v10, v12
    s.add        s11, s2, s12
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s12, s11, s7
    p.and        p2, p5, p1
    v.splat      v5, s3
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v6, [s12, #0]
    v.extract    s7, v0, #0
    .li       s11, #1031798784
    v.splat      v9, s11                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v10, v5, v1
    v.splat      v5, s7
    v.extract    s7, v4, #0
    .li       s11, #1069066811
    v.splat      v11, s11                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.le     p1, v10, v5
    @p1 v.sel        v5, v8, v2
    v.splat      v12, s7
    .li       s7, #1060205080
    v.splat      v13, s7                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.mul        s7, s4, s9
    v.movi       v14, #144
    vf.cvt.bf16.f32 v15, v6
    v.cmp.lt     p1, v10, v14
    s.add        s11, s3, s7
    v.movi       v6, #0
    s.shli       s12, s11, #2                    // element offset -> bytes (x4)
    vf.mul       v14, v15, v9
    s.add        s11, s5, s12                    // &out_ptr1[...]
    v.splat      v9, s7
    s.add        s7, s3, s10
    s.movz       s12, #1
    vf.add       v15, v14, v5
    v.add        v5, v10, v9
    vf.sub       v5, v15, v12
    vf.mul       v9, v5, v11
    v.exp2.approx v10, v9                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v12, v5, v11, v9                // the exact rounding error of x*log2(e)
    vf.mul       v5, v12, v13
    vf.fma       v9, v10, v5, v10                // 2**t * 2**d
    vf.cmp.o     p2, v9, v9
    @p2 v.sel        v5, v9, v10
    vf.add       v9, v3, v5
    @p1 v.st.w       [s11, #0], v5
    @p1 v.sel        v5, v9, v3
    v.mov        v6, v5
    v.mov        v3, v6
    s.mov        s3, s7
    br.nz        s12, for_3
endfor_4:
    vf.reduce.add.b v0, v3
    vf.add       v2, v0, v7
    s.addi       s2, s1, #256                    // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s2, #0], s5
    s.movz       s1, #1024
    s.st.d       [s2, #8], s1
    s.movz       s1, #144
    s.st.d       [s2, #16], s1
    s.movz       s1, #576
    s.st.d       [s2, #48], s1
    s.movz       s1, #4
    s.st.d       [s2, #56], s1
    .li       s1, #68719476737
    s.st.d       [s2, #88], s1
    .li       s1, #2207613190144
    s.st.d       [s2, #104], s1
    fence.release.device
    td.load      d1, [s2]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s8, #0
for_5:
    s.cmp.ge     s2, s1, s9
    br.nz        s2, endfor_6
    v.extract    s2, v2, #0
    v.splat      v0, s1
    v.splat      v3, s2
    v.iota       v4                              // arange(0, VLEN)
    s.movz       s2, #144
    v.rcp.approx v5, v3                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #1024
    s.muli       s7, s4, #576
    v.add        v6, v0, v4
    v.movi       v0, #0
    v.splat      v4, s2
    v.splat      v7, s4
    v.movi       v8, #0
    v.splat      v9, s3
    s.muli       s2, s1, #4
    v.cmp.ge     p1, v6, v0
    v.cmp.lt     p2, v6, v4
    v.cmp.ge     p3, v7, v8
    v.cmp.lt     p4, v7, v9
    s.add        s3, s5, s7
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    .li       s7, #1065353216
    v.splat      v0, s7                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s7, s3, s2
    p.and        p2, p5, p1
    fence.acq_rel.device
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v4, [s7, #0]
    s.mul        s2, s4, s9
    v.splat      v6, s1
    v.movi       v7, #144
    s.add        s3, s1, s10
    v.add        v8, v6, v1
    s.add        s7, s1, s2
    vf.fms       v6, v3, v5, v0
    s.shli       s8, s7, #1                      // element offset -> bytes (x2)
    v.splat      v0, s2
    s.add        s2, s6, s8                      // &out_ptr3[...]
    s.movz       s7, #1
    vf.fms       v3, v5, v6, v5
    v.cmp.lt     p1, v8, v7
    v.add        v6, v8, v0
    vf.neg       v0, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v0, v0
    @p2 v.sel        v3, v0, v5
    vf.mul       v0, v4, v3                      // a/y as a refined reciprocal (ISA has no divide)
    vf.cvt.f32.bf16 v3, v0
    @p1 v.st.h       [s2, #0], v3
    s.mov        s1, s3
    br.nz        s7, for_5
endfor_6:
__rctx_next:
    exit
