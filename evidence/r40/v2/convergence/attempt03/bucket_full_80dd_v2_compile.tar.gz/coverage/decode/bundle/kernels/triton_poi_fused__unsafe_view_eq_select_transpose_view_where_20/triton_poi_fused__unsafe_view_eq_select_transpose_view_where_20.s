    s.rdspecial  s1, arg_base
    s.movz       s2, #16
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.rdspecial  s4, role_id
    s.rdspecial  s5, npid.x
    s.ld.d       s6, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s7, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s8, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s9, [s1, #32]                   // out_ptr0: device_ptr64 at arg_base+32
__rctx_program:
    s.mul        s1, s4, s2
    v.iota       v0                              // arange(0, VLEN)
    .li       s10, #147456
    v.splat      v1, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v2, #0
    v.movi       v3, #1
    v.splat      v4, s1
    v.sub        v5, v2, v1
    v.cmp.lt     p1, v1, v2
    v.add        v6, v4, v0
    @p1 v.sel        v0, v5, v1
    v.movi       v4, #0
    v.sub        v5, v2, v6
    v.cmp.lt     p2, v6, v2
    v.movi       v7, #0
    @p2 v.sel        v8, v5, v6
    s.movz       s10, #31
idiv_1:
    v.splat      v5, s10
    v.shl        v9, v7, v3
    v.cmp.lt     p3, v7, v2
    v.lshr       v10, v8, v5
    v.shl        v11, v3, v5
    s.subi       s11, s10, #1
    v.and        v5, v10, v3
    s.movz       s12, #0
    v.or         v10, v9, v5
    v.cmp.geu    p4, v10, v0
    p.or         p5, p3, p4
    v.sub        v5, v10, v0
    @p5 v.sel        v9, v11, v2
    @p5 v.sel        v11, v5, v10
    v.or         v5, v4, v9
    v.mov        v7, v11
    v.mov        v4, v5
    s.mov        s10, s11
    s.cmp.ge     s11, s10, s12
    br.nz        s11, idiv_1
    v.movi       v0, #0
    v.movi       v3, #6
    v.movi       v5, #64
    v.sub        v7, v0, v6
    v.cmp.lt     p3, v6, v0
    v.movi       v8, #576
    @p3 v.sel        v9, v7, v6
    v.movi       v7, #0
    v.sub        v10, v2, v4
    v.lshr       v2, v9, v3
    v.sub        v3, v0, v5
    v.sub        v9, v7, v8
    v.sub        v11, v0, v2
    p.xor        p4, p2, p1
    v.cmp.lt     p1, v5, v0
    @p3 v.sel        v0, v11, v2
    v.cmp.lt     p2, v8, v7
    @p4 v.sel        v2, v10, v4
    v.sub        v4, v7, v0
    v.cmp.lt     p3, v0, v7
    v.movi       v10, #1
    @p1 v.sel        v10, v3, v5
    v.movi       v3, #1
    @p3 v.sel        v10, v4, v0
    @p2 v.sel        v0, v9, v8
    v.movi       v4, #0
    v.movi       v8, #0
    s.movz       s10, #31
idiv_2:
    v.splat      v9, s10
    v.shl        v11, v8, v3
    v.cmp.lt     p1, v8, v7
    v.lshr       v12, v10, v9
    v.shl        v13, v3, v9
    s.subi       s11, s10, #1
    v.and        v9, v12, v3
    s.movz       s12, #0
    v.or         v12, v11, v9
    v.cmp.geu    p2, v12, v0
    p.or         p4, p1, p2
    v.sub        v9, v12, v0
    @p4 v.sel        v11, v13, v7
    @p4 v.sel        v13, v9, v12
    v.or         v9, v4, v11
    v.mov        v8, v13
    v.mov        v4, v9
    s.mov        s10, s11
    s.cmp.ge     s11, s10, s12
    br.nz        s11, idiv_2
    v.movi       v0, #0
    v.movi       v3, #63
    s.movz       s10, #36864
    v.splat      v4, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.sub        v9, v0, v6
    v.cmp.lt     p1, v6, v0
    v.movi       v10, #0
    @p1 v.sel        v11, v9, v6
    v.sub        v9, v7, v8
    v.sub        v7, v0, v5
    v.and        v12, v11, v3
    v.sub        v3, v10, v6
    v.sub        v11, v10, v4
    v.sub        v13, v0, v12
    v.cmp.lt     p2, v5, v0
    @p3 v.sel        v0, v9, v8
    v.cmp.lt     p3, v6, v10
    v.movi       v8, #1
    @p2 v.sel        v8, v7, v5
    v.cmp.lt     p2, v4, v10
    @p1 v.sel        v7, v13, v12
    v.movi       v8, #1
    @p3 v.sel        v9, v3, v6
    @p2 v.sel        v3, v11, v4
    v.movi       v4, #0
    v.movi       v11, #0
    s.movz       s10, #31
idiv_3:
    v.splat      v12, s10
    v.shl        v13, v11, v8
    v.cmp.lt     p1, v11, v10
    v.lshr       v14, v9, v12
    v.shl        v15, v8, v12
    s.subi       s11, s10, #1
    v.and        v12, v14, v8
    s.movz       s12, #0
    v.or         v14, v13, v12
    v.cmp.geu    p4, v14, v3
    p.or         p5, p1, p4
    v.sub        v12, v14, v3
    @p5 v.sel        v13, v15, v10
    @p5 v.sel        v15, v12, v14
    v.or         v12, v4, v13
    v.mov        v11, v15
    v.mov        v4, v12
    s.mov        s10, s11
    s.cmp.ge     s11, s10, s12
    br.nz        s11, idiv_3
    v.sub        v3, v10, v4
    p.xor        p1, p3, p2
    v.movi       v8, #0
    @p1 v.sel        v9, v3, v4
    v.movi       v3, #3
    v.movi       v4, #4
    v.sub        v10, v8, v9
    v.cmp.lt     p1, v9, v8
    v.movi       v11, #0
    @p1 v.sel        v12, v10, v9
    v.sub        v9, v8, v4
    v.sub        v10, v11, v6
    v.and        v13, v12, v3
    v.sub        v3, v11, v1
    v.cmp.lt     p2, v4, v8
    v.sub        v12, v8, v13
    v.cmp.lt     p3, v6, v11
    v.movi       v8, #1
    @p2 v.sel        v8, v9, v4
    v.cmp.lt     p2, v1, v11
    @p1 v.sel        v4, v12, v13
    v.movi       v8, #1
    @p3 v.sel        v9, v10, v6
    @p2 v.sel        v6, v3, v1
    v.movi       v1, #0
    v.movi       v3, #0
    s.movz       s10, #31
idiv_4:
    v.splat      v10, s10
    v.shl        v12, v3, v8
    v.cmp.lt     p1, v3, v11
    v.lshr       v13, v9, v10
    v.shl        v14, v8, v10
    s.subi       s11, s10, #1
    v.and        v10, v13, v8
    s.movz       s12, #0
    v.or         v13, v12, v10
    v.cmp.geu    p2, v13, v6
    p.or         p4, p1, p2
    v.sub        v10, v13, v6
    @p4 v.sel        v12, v14, v11
    @p4 v.sel        v14, v10, v13
    v.or         v10, v1, v12
    v.mov        v3, v14
    v.mov        v1, v10
    s.mov        s10, s11
    s.cmp.ge     s11, s10, s12
    br.nz        s11, idiv_4
    s.ld.d       s10, [s6, #0]                   // one element, not a vector
    v.movi       v1, #1
    v.movi       v6, #0
    v.movi       v8, #0
    v.shl        v9, v0, v1
    s.addi       s11, s3, #4
    v.sub        v0, v11, v3
    @p3 v.sel        v1, v0, v3
    s.lshri      s12, s10, #32
    v.ld.gather.w v0, [s3, v9]                   // index is in elements (ISA sec 9.1)
    s.lshri      s13, s10, #32
    s.lshri      s14, s10, #32
    s.lshri      s15, s10, #32
    s.lshri      s16, s10, #32
    v.ld.gather.w v3, [s11, v9]                  // index is in elements (ISA sec 9.1)
    v.insert     v6, s10, #0
    v.insert     v8, s12, #0
    s.lshri      s11, s10, #32
    v.insert     v6, s10, #1
    v.insert     v8, s13, #1
    s.lshri      s12, s10, #32
    v.insert     v6, s10, #2
    v.insert     v8, s14, #2
    s.lshri      s13, s10, #32
    v.insert     v6, s10, #3
    v.insert     v8, s15, #3
    s.lshri      s14, s10, #32
    v.insert     v6, s10, #4
    v.insert     v8, s16, #4
    s.lshri      s15, s10, #32
    v.insert     v6, s10, #5
    v.insert     v8, s11, #5
    s.lshri      s11, s10, #32
    v.insert     v6, s10, #6
    v.insert     v8, s12, #6
    s.lshri      s12, s10, #32
    v.insert     v6, s10, #7
    v.insert     v8, s13, #7
    s.lshri      s13, s10, #32
    v.insert     v6, s10, #8
    v.insert     v8, s14, #8
    s.lshri      s14, s10, #32
    v.insert     v6, s10, #9
    v.insert     v8, s15, #9
    s.lshri      s15, s10, #32
    v.insert     v6, s10, #10
    v.insert     v8, s11, #10
    s.lshri      s11, s10, #32
    v.insert     v6, s10, #11
    v.insert     v8, s12, #11
    v.extract    s12, v3, #0
    v.insert     v6, s10, #12
    v.insert     v8, s13, #12
    v.mul        v9, v4, v5
    v.insert     v6, s10, #13
    v.insert     v8, s14, #13
    v.extract    s13, v0, #0
    v.insert     v6, s10, #14
    v.insert     v8, s15, #14
    s.shli       s14, s12, #32
    v.insert     v6, s10, #15
    v.insert     v8, s11, #15
    v.extract    s10, v3, #1
    v.extract    s11, v6, #0
    v.extract    s12, v8, #0
    v.extract    s15, v8, #1
    s.shli       s16, s12, #32
    s.shli       s12, s1, #1                     // element offset -> bytes (x2)
    s.or         s1, s13, s14
    s.or         s13, s11, s16
    v.add        v4, v7, v9
    v.movi       v5, #0
    v.extract    s11, v0, #1
    s.shli       s14, s10, #32
    v.extract    s10, v6, #1
    s.shli       s16, s15, #32
    s.add        s15, s8, s12                    // &in_ptr3[...]
    s.cmp.eq     s17, s1, s13
    v.extract    s1, v3, #2
    s.or         s13, s11, s14
    v.extract    s11, v8, #2
    s.or         s14, s10, s16
    v.ld.gather.h v7, [s7, v4]                   // index is in elements (ISA sec 9.1)
    v.extract    s10, v0, #2
    s.shli       s16, s1, #32
    s.shli       s1, s11, #32
    s.cmp.eq     s11, s13, s14
    v.extract    s13, v6, #2
    s.or         s14, s10, s16
    v.extract    s10, v3, #3
    s.or         s16, s13, s1
    v.extract    s1, v0, #3
    s.shli       s13, s10, #32
    s.cmp.eq     s10, s14, s16
    s.or         s14, s1, s13
    v.movi       v4, #0
    v.ld.gather.h v9, [s8, v1]                   // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v1, v7
    v.cmp.eq     p1, v2, v4
    s.movz       s1, #64
    v.extract    s1, v8, #3
    v.extract    s13, v6, #3
    s.shli       s16, s1, #32
    s.or         s1, s13, s16
    s.cmp.eq     s13, s14, s1
    v.ld.h       v2, [s15, #0]
    v.insert     v5, s17, #0
    vf.cvt.f16.f32 v4, v9
    v.extract    s1, v3, #4
    v.insert     v5, s11, #1
    v.extract    s11, v0, #4
    s.shli       s14, s1, #32
    v.insert     v5, s10, #2
    s.or         s1, s11, s14
    v.insert     v5, s13, #3
    vf.cvt.f16.f32 v7, v2
    v.extract    s10, v8, #4
    v.extract    s11, v6, #4
    s.shli       s13, s10, #32
    v.extract    s10, v3, #5
    v.extract    s14, v8, #5
    s.or         s15, s11, s13
    v.extract    s11, v0, #5
    s.shli       s13, s10, #32
    v.extract    s10, v6, #5
    s.shli       s16, s14, #32
    s.cmp.eq     s14, s1, s15
    v.extract    s1, v3, #6
    v.extract    s15, v8, #6
    s.or         s17, s11, s13
    s.or         s11, s10, s16
    v.insert     v5, s14, #4
    v.extract    s10, v0, #6
    s.shli       s13, s1, #32
    v.extract    s1, v6, #6
    s.shli       s14, s15, #32
    s.cmp.eq     s15, s17, s11
    v.extract    s11, v3, #7
    v.extract    s16, v8, #7
    s.or         s17, s10, s13
    s.or         s10, s1, s14
    v.insert     v5, s15, #5
    v.extract    s1, v0, #7
    s.shli       s13, s11, #32
    v.extract    s11, v6, #7
    s.shli       s14, s16, #32
    s.cmp.eq     s15, s17, s10
    v.extract    s10, v3, #8
    v.extract    s16, v8, #8
    s.or         s17, s1, s13
    s.or         s1, s11, s14
    v.insert     v5, s15, #6
    v.extract    s11, v0, #8
    s.shli       s13, s10, #32
    v.extract    s10, v6, #8
    s.shli       s14, s16, #32
    s.cmp.eq     s15, s17, s1
    v.extract    s1, v3, #9
    v.extract    s16, v8, #9
    s.or         s17, s11, s13
    s.or         s11, s10, s14
    v.insert     v5, s15, #7
    v.extract    s10, v0, #9
    s.shli       s13, s1, #32
    v.extract    s1, v6, #9
    s.shli       s14, s16, #32
    s.cmp.eq     s15, s17, s11
    v.extract    s11, v3, #10
    v.extract    s16, v8, #10
    s.or         s17, s10, s13
    s.or         s10, s1, s14
    v.insert     v5, s15, #8
    v.extract    s1, v0, #10
    s.shli       s13, s11, #32
    v.extract    s11, v6, #10
    s.shli       s14, s16, #32
    s.cmp.eq     s15, s17, s10
    v.extract    s10, v3, #11
    v.extract    s16, v8, #11
    s.or         s17, s1, s13
    s.or         s1, s11, s14
    v.insert     v5, s15, #9
    v.extract    s11, v0, #11
    s.shli       s13, s10, #32
    v.extract    s10, v6, #11
    s.shli       s14, s16, #32
    s.cmp.eq     s15, s17, s1
    v.extract    s1, v3, #12
    v.extract    s16, v8, #12
    s.or         s17, s11, s13
    s.or         s11, s10, s14
    v.insert     v5, s15, #10
    v.extract    s10, v0, #12
    s.shli       s13, s1, #32
    v.extract    s1, v6, #12
    s.shli       s14, s16, #32
    s.cmp.eq     s15, s17, s11
    v.extract    s11, v3, #13
    v.extract    s16, v8, #13
    s.or         s17, s10, s13
    s.or         s10, s1, s14
    v.insert     v5, s15, #11
    v.extract    s1, v0, #13
    s.shli       s13, s11, #32
    v.extract    s11, v6, #13
    s.shli       s14, s16, #32
    s.cmp.eq     s15, s17, s10
    v.extract    s10, v3, #14
    v.extract    s16, v8, #14
    s.or         s17, s1, s13
    s.or         s1, s11, s14
    v.insert     v5, s15, #12
    v.extract    s11, v0, #14
    s.shli       s13, s10, #32
    v.extract    s10, v6, #14
    s.shli       s14, s16, #32
    s.cmp.eq     s15, s17, s1
    v.extract    s1, v3, #15
    v.extract    s16, v8, #15
    s.or         s17, s11, s13
    s.or         s11, s10, s14
    v.insert     v5, s15, #13
    v.extract    s10, v0, #15
    s.shli       s13, s1, #32
    v.extract    s1, v6, #15
    s.shli       s14, s16, #32
    s.cmp.eq     s15, s17, s11
    s.or         s11, s10, s13
    s.or         s10, s1, s14
    v.insert     v5, s15, #14
    s.cmp.eq     s1, s11, s10
    v.movi       v0, #0
    v.insert     v5, s1, #15
    s.add        s1, s9, s12                     // &out_ptr0[...]
    v.cmp.ne     p2, v5, v0
    @p2 v.sel        v0, v1, v4
    @p1 v.sel        v1, v0, v7
    vf.cvt.f32.f16 v0, v1
    v.st.h       [s1, #0], v0
__rctx_next:
    s.addi       s1, s4, #4                      // the next program of this context: + 4
    s.cmp.lt     s10, s1, s5
    s.mov        s4, s1
    br.nz        s10, __rctx_program
    exit
