    s.rdspecial  s1, arg_base
    s.movz       s2, #16
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #1
    s.movz       s5, #0
    s.movz       s6, #128
    s.movz       s7, #32
    s.rdspecial  s8, role_id
    s.rdspecial  s9, npid.x
    s.ld.d       s10, [s1, #8]                   // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s11, [s1, #16]                  // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s12, [s1, #24]                  // out_ptr1: device_ptr64 at arg_base+24
__rctx_program:
    s.shli       s1, s8, #3                      // element offset -> bytes (x8)
    v.movi       v0, #0
    v.movi       v1, #1
    v.iota       v2                              // arange(0, VLEN)
    s.add        s13, s3, s1                     // &in_ptr0[...]
    v.splat      v3, s4
    v.movi       v4, #16
    v.shl        v5, v0, v1
    v.movi       v0, #0
    v.movi       v1, #0
    v.movi       v6, #0
    v.movi       v7, #0
    s.addi       s1, s13, #4
    v.cmp.lt     p1, v2, v3
    v.splat      v3, s8
    v.add        v3, v2, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s13, v5]              // index is in elements (ISA sec 9.1)
    s.addi       s13, s5, #0
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v8, [s1, v5]               // index is in elements (ISA sec 9.1)
    v.mov        v1, v0
    v.mov        v7, v6
for_1:
    s.cmp.ge     s1, s13, s6
    br.nz        s1, endfor_2
    v.extract    s1, v8, #0
    v.extract    s14, v4, #0
    s.shli       s15, s1, #32
    s.movz       s1, #512
    s.or         s16, s14, s15
    v.movi       v0, #0
    v.movi       v5, #0
    s.cmp.ge     s14, s16, s5
    s.cmp.lt     s15, s16, s1
    v.insert     v0, s14, #0
    v.movi       v6, #0
    v.insert     v5, s15, #0
    v.movi       v9, #0
    v.cmp.ne     p1, v0, v6
    v.movi       v0, #1
    v.cmp.ne     p2, v5, v9
    p.and        p3, p1, p2
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s4
    @p3 v.sel        v10, v9, v0
    v.splat      v0, s13
    v.cmp.lt     p1, v5, v6
    @p1 v.reduce.or  s1, v10
    v.splat      v5, s13
    s.cmp.eq     s14, s1, s5
    v.add        v6, v0, v2
    v.add        v0, v5, v3
    s.add        s1, s2, s13
    br.nz        s14, assert_ok_3
    trap         #677351
assert_ok_3:
    v.extract    s1, v6, #0
    s.mul        s14, s16, s6
    s.shli       s15, s1, #32
    v.extract    s1, v6, #1
    s.ashri      s16, s15, #32
    v.movi       v5, #0
    v.movi       v9, #0
    v.movi       v10, #0
    v.movi       v11, #0
    s.shli       s15, s1, #32
    s.lshri      s1, s14, #32
    s.lshri      s17, s16, #32
    v.extract    s18, v6, #2
    s.ashri      s19, s15, #32
    v.insert     v5, s14, #0
    v.insert     v9, s1, #0
    v.insert     v10, s16, #0
    v.insert     v11, s17, #0
    s.shli       s1, s18, #32
    s.lshri      s14, s19, #32
    v.extract    s15, v6, #3
    s.ashri      s16, s1, #32
    v.insert     v10, s19, #1
    v.insert     v11, s14, #1
    s.shli       s1, s15, #32
    s.lshri      s14, s16, #32
    v.extract    s15, v6, #4
    s.ashri      s17, s1, #32
    v.insert     v10, s16, #2
    v.insert     v11, s14, #2
    s.shli       s1, s15, #32
    s.lshri      s14, s17, #32
    v.extract    s15, v6, #5
    s.ashri      s16, s1, #32
    v.insert     v10, s17, #3
    v.insert     v11, s14, #3
    s.shli       s1, s15, #32
    s.lshri      s14, s16, #32
    v.extract    s15, v6, #6
    s.ashri      s17, s1, #32
    v.insert     v10, s16, #4
    v.insert     v11, s14, #4
    s.shli       s1, s15, #32
    s.lshri      s14, s17, #32
    v.extract    s15, v6, #7
    s.ashri      s16, s1, #32
    v.insert     v10, s17, #5
    v.insert     v11, s14, #5
    s.shli       s1, s15, #32
    s.lshri      s14, s16, #32
    v.extract    s15, v6, #8
    s.ashri      s17, s1, #32
    v.insert     v10, s16, #6
    v.insert     v11, s14, #6
    s.shli       s1, s15, #32
    s.lshri      s14, s17, #32
    v.extract    s15, v6, #9
    s.ashri      s16, s1, #32
    v.insert     v10, s17, #7
    v.insert     v11, s14, #7
    s.shli       s1, s15, #32
    s.lshri      s14, s16, #32
    v.extract    s15, v6, #10
    s.ashri      s17, s1, #32
    v.insert     v10, s16, #8
    v.insert     v11, s14, #8
    s.shli       s1, s15, #32
    s.lshri      s14, s17, #32
    v.extract    s15, v6, #11
    s.ashri      s16, s1, #32
    v.insert     v10, s17, #9
    v.insert     v11, s14, #9
    s.shli       s1, s15, #32
    s.lshri      s14, s16, #32
    v.extract    s15, v6, #12
    s.ashri      s17, s1, #32
    v.insert     v10, s16, #10
    v.insert     v11, s14, #10
    s.shli       s1, s15, #32
    s.lshri      s14, s17, #32
    v.extract    s15, v6, #13
    s.ashri      s16, s1, #32
    v.insert     v10, s17, #11
    v.insert     v11, s14, #11
    s.shli       s1, s15, #32
    s.lshri      s14, s16, #32
    v.extract    s15, v6, #14
    s.ashri      s17, s1, #32
    v.insert     v10, s16, #12
    v.insert     v11, s14, #12
    s.shli       s1, s15, #32
    s.lshri      s14, s17, #32
    v.extract    s15, v6, #15
    v.extract    s16, v0, #0
    s.ashri      s18, s1, #32
    v.insert     v10, s17, #13
    v.insert     v11, s14, #13
    s.shli       s1, s15, #32
    s.shli       s14, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v0, #1
    s.ashri      s17, s1, #32
    s.ashri      s1, s14, #32
    v.insert     v10, s18, #14
    v.insert     v11, s15, #14
    v.movi       v12, #0
    v.movi       v13, #0
    s.shli       s14, s16, #32
    s.lshri      s15, s17, #32
    s.lshri      s16, s1, #32
    v.extract    s18, v0, #2
    s.ashri      s19, s14, #32
    v.insert     v10, s17, #15
    v.insert     v11, s15, #15
    v.insert     v12, s1, #0
    v.insert     v13, s16, #0
    s.shli       s1, s18, #32
    s.lshri      s14, s19, #32
    v.extract    s15, v0, #3
    s.ashri      s16, s1, #32
    v.insert     v12, s19, #1
    v.insert     v13, s14, #1
    s.shli       s1, s15, #32
    s.lshri      s14, s16, #32
    v.extract    s15, v0, #4
    s.ashri      s17, s1, #32
    v.insert     v12, s16, #2
    v.insert     v13, s14, #2
    s.shli       s1, s15, #32
    s.lshri      s14, s17, #32
    v.extract    s15, v0, #5
    s.ashri      s16, s1, #32
    v.insert     v12, s17, #3
    v.insert     v13, s14, #3
    s.shli       s1, s15, #32
    s.lshri      s14, s16, #32
    v.extract    s15, v0, #6
    s.ashri      s17, s1, #32
    v.insert     v12, s16, #4
    v.insert     v13, s14, #4
    s.shli       s1, s15, #32
    s.lshri      s14, s17, #32
    v.extract    s15, v0, #7
    s.ashri      s16, s1, #32
    v.insert     v12, s17, #5
    v.insert     v13, s14, #5
    s.shli       s1, s15, #32
    s.lshri      s14, s16, #32
    v.extract    s15, v0, #8
    s.ashri      s17, s1, #32
    v.insert     v12, s16, #6
    v.insert     v13, s14, #6
    s.shli       s1, s15, #32
    s.lshri      s14, s17, #32
    v.extract    s15, v0, #9
    s.ashri      s16, s1, #32
    v.insert     v12, s17, #7
    v.insert     v13, s14, #7
    s.shli       s1, s15, #32
    s.lshri      s14, s16, #32
    v.extract    s15, v0, #10
    s.ashri      s17, s1, #32
    v.insert     v12, s16, #8
    v.insert     v13, s14, #8
    s.shli       s1, s15, #32
    s.lshri      s14, s17, #32
    v.extract    s15, v0, #11
    s.ashri      s16, s1, #32
    v.insert     v12, s17, #9
    v.insert     v13, s14, #9
    s.shli       s1, s15, #32
    s.lshri      s14, s16, #32
    v.extract    s15, v0, #12
    s.ashri      s17, s1, #32
    v.insert     v12, s16, #10
    v.insert     v13, s14, #10
    s.shli       s1, s15, #32
    s.lshri      s14, s17, #32
    v.extract    s15, v0, #13
    s.ashri      s16, s1, #32
    v.insert     v12, s17, #11
    v.insert     v13, s14, #11
    s.shli       s1, s15, #32
    s.lshri      s14, s16, #32
    v.extract    s15, v0, #14
    s.ashri      s17, s1, #32
    v.insert     v12, s16, #12
    v.insert     v13, s14, #12
    s.shli       s1, s15, #32
    s.lshri      s14, s17, #32
    v.extract    s15, v0, #15
    v.extract    s16, v9, #0
    s.ashri      s18, s1, #32
    v.insert     v12, s17, #13
    v.insert     v13, s14, #13
    s.shli       s1, s15, #32
    v.extract    s14, v5, #0
    s.shli       s15, s16, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v9, #0
    s.ashri      s19, s1, #32
    s.or         s1, s14, s15
    v.insert     v12, s18, #14
    v.insert     v13, s16, #14
    v.movi       v14, #0
    v.movi       v15, #0
    v.extract    s14, v5, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    s.lshri      s17, s1, #32
    v.extract    s18, v9, #0
    s.or         s20, s14, s15
    v.insert     v12, s19, #15
    v.insert     v13, s16, #15
    v.insert     v14, s1, #0
    v.insert     v15, s17, #0
    v.extract    s1, v5, #0
    s.shli       s14, s18, #32
    s.lshri      s15, s20, #32
    v.extract    s16, v9, #0
    s.or         s17, s1, s14
    v.insert     v14, s20, #1
    v.insert     v15, s15, #1
    v.extract    s1, v5, #0
    s.shli       s14, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v9, #0
    s.or         s18, s1, s14
    v.insert     v14, s17, #2
    v.insert     v15, s15, #2
    v.extract    s1, v5, #0
    s.shli       s14, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v9, #0
    s.or         s17, s1, s14
    v.insert     v14, s18, #3
    v.insert     v15, s15, #3
    v.extract    s1, v5, #0
    s.shli       s14, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v9, #0
    s.or         s18, s1, s14
    v.insert     v14, s17, #4
    v.insert     v15, s15, #4
    v.extract    s1, v5, #0
    s.shli       s14, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v9, #0
    s.or         s17, s1, s14
    v.insert     v14, s18, #5
    v.insert     v15, s15, #5
    v.extract    s1, v5, #0
    s.shli       s14, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v9, #0
    s.or         s18, s1, s14
    v.insert     v14, s17, #6
    v.insert     v15, s15, #6
    v.extract    s1, v5, #0
    s.shli       s14, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v9, #0
    s.or         s17, s1, s14
    v.insert     v14, s18, #7
    v.insert     v15, s15, #7
    v.extract    s1, v5, #0
    s.shli       s14, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v9, #0
    s.or         s18, s1, s14
    v.insert     v14, s17, #8
    v.insert     v15, s15, #8
    v.extract    s1, v5, #0
    s.shli       s14, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v9, #0
    s.or         s17, s1, s14
    v.insert     v14, s18, #9
    v.insert     v15, s15, #9
    v.extract    s1, v5, #0
    s.shli       s14, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v9, #0
    s.or         s18, s1, s14
    v.insert     v14, s17, #10
    v.insert     v15, s15, #10
    v.extract    s1, v5, #0
    s.shli       s14, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v9, #0
    s.or         s17, s1, s14
    v.insert     v14, s18, #11
    v.insert     v15, s15, #11
    v.extract    s1, v5, #0
    s.shli       s14, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v9, #0
    s.or         s18, s1, s14
    v.insert     v14, s17, #12
    v.insert     v15, s15, #12
    v.extract    s1, v5, #0
    s.shli       s14, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v9, #0
    v.extract    s17, v9, #0
    s.or         s19, s1, s14
    v.insert     v14, s18, #13
    v.insert     v15, s15, #13
    v.extract    s1, v5, #0
    s.shli       s14, s16, #32
    v.extract    s15, v5, #0
    s.shli       s16, s17, #32
    s.lshri      s17, s19, #32
    v.extract    s18, v9, #0
    s.or         s20, s1, s14
    s.or         s1, s15, s16
    v.insert     v14, s19, #14
    v.insert     v15, s17, #14
    v.movi       v16, #0
    v.movi       v17, #0
    v.extract    s14, v5, #0
    s.shli       s15, s18, #32
    s.lshri      s16, s20, #32
    s.lshri      s17, s1, #32
    v.extract    s18, v9, #0
    s.or         s19, s14, s15
    v.insert     v14, s20, #15
    v.insert     v15, s16, #15
    v.insert     v16, s1, #0
    v.insert     v17, s17, #0
    v.extract    s1, v5, #0
    s.shli       s14, s18, #32
    s.lshri      s15, s19, #32
    v.extract    s16, v9, #0
    s.or         s17, s1, s14
    v.insert     v16, s19, #1
    v.insert     v17, s15, #1
    v.extract    s1, v5, #0
    s.shli       s14, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v9, #0
    s.or         s18, s1, s14
    v.insert     v16, s17, #2
    v.insert     v17, s15, #2
    v.extract    s1, v5, #0
    s.shli       s14, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v9, #0
    s.or         s17, s1, s14
    v.insert     v16, s18, #3
    v.insert     v17, s15, #3
    v.extract    s1, v5, #0
    s.shli       s14, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v9, #0
    s.or         s18, s1, s14
    v.insert     v16, s17, #4
    v.insert     v17, s15, #4
    v.extract    s1, v5, #0
    s.shli       s14, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v9, #0
    s.or         s17, s1, s14
    v.insert     v16, s18, #5
    v.insert     v17, s15, #5
    v.extract    s1, v5, #0
    s.shli       s14, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v9, #0
    s.or         s18, s1, s14
    v.insert     v16, s17, #6
    v.insert     v17, s15, #6
    v.extract    s1, v5, #0
    s.shli       s14, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v9, #0
    s.or         s17, s1, s14
    v.insert     v16, s18, #7
    v.insert     v17, s15, #7
    v.extract    s1, v5, #0
    s.shli       s14, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v9, #0
    s.or         s18, s1, s14
    v.insert     v16, s17, #8
    v.insert     v17, s15, #8
    v.extract    s1, v5, #0
    s.shli       s14, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v9, #0
    s.or         s17, s1, s14
    v.insert     v16, s18, #9
    v.insert     v17, s15, #9
    v.extract    s1, v5, #0
    s.shli       s14, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v9, #0
    s.or         s18, s1, s14
    v.insert     v16, s17, #10
    v.insert     v17, s15, #10
    v.extract    s1, v5, #0
    s.shli       s14, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v9, #0
    s.or         s17, s1, s14
    v.insert     v16, s18, #11
    v.insert     v17, s15, #11
    v.extract    s1, v5, #0
    s.shli       s14, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v9, #0
    s.or         s18, s1, s14
    v.extract    s1, v11, #0
    v.extract    s14, v15, #0
    v.insert     v16, s17, #12
    v.insert     v17, s15, #12
    v.extract    s15, v5, #0
    s.shli       s17, s16, #32
    s.lshri      s16, s18, #32
    v.extract    s19, v9, #0
    s.shli       s20, s1, #32
    s.shli       s1, s14, #32
    s.or         s14, s15, s17
    v.extract    s15, v10, #0
    v.insert     v16, s18, #13
    v.extract    s17, v14, #0
    v.insert     v17, s16, #13
    v.extract    s16, v11, #1
    s.shli       s18, s19, #32
    s.or         s19, s15, s20
    v.extract    s15, v15, #1
    s.or         s20, s17, s1
    v.extract    s1, v5, #0
    s.shli       s17, s16, #32
    s.shli       s16, s15, #32
    s.or         s15, s1, s18
    s.lshri      s1, s14, #32
    s.add        s18, s19, s20
    v.extract    s19, v10, #1
    v.insert     v16, s14, #14
    v.extract    s14, v14, #1
    v.insert     v17, s1, #14
    v.extract    s1, v11, #2
    v.movi       v5, #0
    v.movi       v9, #0
    s.or         s20, s19, s17
    v.extract    s17, v15, #2
    s.or         s19, s14, s16
    s.lshri      s14, s15, #32
    s.shli       s16, s1, #32
    s.shli       s1, s17, #32
    s.add        s17, s20, s19
    s.lshri      s19, s18, #32
    v.insert     v16, s15, #15
    v.extract    s15, v10, #2
    v.insert     v17, s14, #15
    v.extract    s14, v14, #2
    v.insert     v5, s18, #0
    v.extract    s18, v11, #3
    v.insert     v9, s19, #0
    v.extract    s19, v15, #3
    s.or         s20, s15, s16
    s.or         s15, s14, s1
    s.lshri      s1, s17, #32
    v.extract    s14, v10, #3
    s.shli       s16, s18, #32
    s.shli       s18, s19, #32
    s.add        s19, s20, s15
    v.extract    s15, v14, #3
    v.insert     v5, s17, #1
    v.extract    s17, v11, #4
    v.insert     v9, s1, #1
    v.extract    s1, v15, #4
    s.or         s20, s14, s16
    s.or         s14, s15, s18
    s.lshri      s15, s19, #32
    v.extract    s16, v10, #4
    s.shli       s18, s17, #32
    s.shli       s17, s1, #32
    s.add        s1, s20, s14
    v.extract    s14, v14, #4
    v.insert     v5, s19, #2
    v.extract    s19, v11, #5
    v.insert     v9, s15, #2
    v.extract    s15, v15, #5
    s.or         s20, s16, s18
    s.or         s16, s14, s17
    s.lshri      s14, s1, #32
    v.extract    s17, v10, #5
    s.shli       s18, s19, #32
    s.shli       s19, s15, #32
    s.add        s15, s20, s16
    v.extract    s16, v14, #5
    v.insert     v5, s1, #3
    v.extract    s1, v11, #6
    v.insert     v9, s14, #3
    v.extract    s14, v15, #6
    s.or         s20, s17, s18
    s.or         s17, s16, s19
    s.lshri      s16, s15, #32
    v.extract    s18, v10, #6
    s.shli       s19, s1, #32
    s.shli       s1, s14, #32
    s.add        s14, s20, s17
    v.extract    s17, v14, #6
    v.insert     v5, s15, #4
    v.extract    s15, v11, #7
    v.insert     v9, s16, #4
    v.extract    s16, v15, #7
    s.or         s20, s18, s19
    s.or         s18, s17, s1
    s.lshri      s1, s14, #32
    v.extract    s17, v10, #7
    s.shli       s19, s15, #32
    s.shli       s15, s16, #32
    s.add        s16, s20, s18
    v.extract    s18, v14, #7
    v.insert     v5, s14, #5
    v.extract    s14, v11, #8
    v.insert     v9, s1, #5
    v.extract    s1, v15, #8
    s.or         s20, s17, s19
    s.or         s17, s18, s15
    s.lshri      s15, s16, #32
    v.extract    s18, v10, #8
    s.shli       s19, s14, #32
    s.shli       s14, s1, #32
    s.add        s1, s20, s17
    v.extract    s17, v14, #8
    v.insert     v5, s16, #6
    v.extract    s16, v11, #9
    v.insert     v9, s15, #6
    v.extract    s15, v15, #9
    s.or         s20, s18, s19
    s.or         s18, s17, s14
    s.lshri      s14, s1, #32
    v.extract    s17, v10, #9
    s.shli       s19, s16, #32
    s.shli       s16, s15, #32
    s.add        s15, s20, s18
    v.extract    s18, v14, #9
    v.insert     v5, s1, #7
    v.extract    s1, v11, #10
    v.insert     v9, s14, #7
    v.extract    s14, v15, #10
    s.or         s20, s17, s19
    s.or         s17, s18, s16
    s.lshri      s16, s15, #32
    v.extract    s18, v10, #10
    s.shli       s19, s1, #32
    s.shli       s1, s14, #32
    s.add        s14, s20, s17
    v.extract    s17, v14, #10
    v.insert     v5, s15, #8
    v.extract    s15, v11, #11
    v.insert     v9, s16, #8
    v.extract    s16, v15, #11
    s.or         s20, s18, s19
    s.or         s18, s17, s1
    s.lshri      s1, s14, #32
    v.extract    s17, v10, #11
    s.shli       s19, s15, #32
    s.shli       s15, s16, #32
    s.add        s16, s20, s18
    v.extract    s18, v14, #11
    v.insert     v5, s14, #9
    v.extract    s14, v11, #12
    v.insert     v9, s1, #9
    v.extract    s1, v15, #12
    s.or         s20, s17, s19
    s.or         s17, s18, s15
    s.lshri      s15, s16, #32
    v.extract    s18, v10, #12
    s.shli       s19, s14, #32
    s.shli       s14, s1, #32
    s.add        s1, s20, s17
    v.extract    s17, v14, #12
    v.insert     v5, s16, #10
    v.extract    s16, v11, #13
    v.insert     v9, s15, #10
    v.extract    s15, v15, #13
    s.or         s20, s18, s19
    s.or         s18, s17, s14
    s.lshri      s14, s1, #32
    v.extract    s17, v10, #13
    s.shli       s19, s16, #32
    s.shli       s16, s15, #32
    s.add        s15, s20, s18
    v.extract    s18, v14, #13
    v.insert     v5, s1, #11
    v.extract    s1, v11, #14
    v.insert     v9, s14, #11
    v.extract    s14, v15, #14
    s.or         s20, s17, s19
    s.or         s17, s18, s16
    s.lshri      s16, s15, #32
    v.extract    s18, v10, #14
    s.shli       s19, s1, #32
    s.shli       s1, s14, #32
    s.add        s14, s20, s17
    v.extract    s17, v14, #14
    v.insert     v5, s15, #12
    v.extract    s15, v11, #15
    v.insert     v9, s16, #12
    v.extract    s16, v15, #15
    s.or         s20, s18, s19
    v.extract    s18, v13, #0
    s.or         s19, s17, s1
    v.extract    s1, v17, #0
    s.shli       s17, s15, #32
    s.shli       s15, s16, #32
    s.shli       s16, s18, #32
    s.shli       s18, s1, #32
    s.add        s1, s20, s19
    s.lshri      s19, s14, #32
    v.insert     v5, s14, #13
    v.extract    s14, v10, #15
    v.insert     v9, s19, #13
    v.extract    s19, v14, #15
    s.or         s20, s14, s17
    v.extract    s14, v12, #0
    s.or         s17, s19, s15
    v.extract    s15, v16, #0
    s.or         s19, s14, s16
    v.extract    s14, v13, #1
    s.or         s16, s15, s18
    v.extract    s15, v17, #1
    s.shli       s18, s14, #32
    s.shli       s14, s15, #32
    s.add        s15, s20, s17
    s.lshri      s17, s1, #32
    s.add        s20, s19, s16
    v.extract    s16, v12, #1
    v.insert     v5, s1, #14
    v.extract    s1, v16, #1
    v.insert     v9, s17, #14
    v.extract    s17, v13, #2
    v.movi       v10, #0
    v.movi       v11, #0
    s.or         s19, s16, s18
    v.extract    s16, v17, #2
    s.or         s18, s1, s14
    s.lshri      s1, s15, #32
    s.shli       s14, s17, #32
    s.shli       s17, s16, #32
    s.add        s16, s19, s18
    s.lshri      s18, s20, #32
    v.insert     v5, s15, #15
    v.extract    s15, v12, #2
    v.insert     v9, s1, #15
    v.extract    s1, v16, #2
    v.insert     v10, s20, #0
    v.extract    s19, v13, #3
    v.insert     v11, s18, #0
    v.extract    s18, v17, #3
    s.or         s20, s15, s14
    s.or         s14, s1, s17
    s.lshri      s1, s16, #32
    v.extract    s15, v12, #3
    s.shli       s17, s19, #32
    s.shli       s19, s18, #32
    s.add        s18, s20, s14
    v.extract    s14, v16, #3
    v.insert     v10, s16, #1
    v.extract    s16, v13, #4
    v.insert     v11, s1, #1
    v.extract    s1, v17, #4
    s.or         s20, s15, s17
    s.or         s15, s14, s19
    s.lshri      s14, s18, #32
    v.extract    s17, v12, #4
    s.shli       s19, s16, #32
    s.shli       s16, s1, #32
    s.add        s1, s20, s15
    v.extract    s15, v16, #4
    v.insert     v10, s18, #2
    v.extract    s18, v13, #5
    v.insert     v11, s14, #2
    v.extract    s14, v17, #5
    s.or         s20, s17, s19
    s.or         s17, s15, s16
    s.lshri      s15, s1, #32
    v.extract    s16, v12, #5
    s.shli       s19, s18, #32
    s.shli       s18, s14, #32
    s.add        s14, s20, s17
    v.extract    s17, v16, #5
    v.insert     v10, s1, #3
    v.extract    s1, v13, #6
    v.insert     v11, s15, #3
    v.extract    s15, v17, #6
    s.or         s20, s16, s19
    s.or         s16, s17, s18
    s.lshri      s17, s14, #32
    v.extract    s18, v12, #6
    s.shli       s19, s1, #32
    s.shli       s1, s15, #32
    s.add        s15, s20, s16
    v.extract    s16, v16, #6
    v.insert     v10, s14, #4
    v.extract    s14, v13, #7
    v.insert     v11, s17, #4
    v.extract    s17, v17, #7
    s.or         s20, s18, s19
    s.or         s18, s16, s1
    s.lshri      s1, s15, #32
    v.extract    s16, v12, #7
    s.shli       s19, s14, #32
    s.shli       s14, s17, #32
    s.add        s17, s20, s18
    v.extract    s18, v16, #7
    v.insert     v10, s15, #5
    v.extract    s15, v13, #8
    v.insert     v11, s1, #5
    v.extract    s1, v17, #8
    s.or         s20, s16, s19
    s.or         s16, s18, s14
    s.lshri      s14, s17, #32
    v.extract    s18, v12, #8
    s.shli       s19, s15, #32
    s.shli       s15, s1, #32
    s.add        s1, s20, s16
    v.extract    s16, v16, #8
    v.insert     v10, s17, #6
    v.extract    s17, v13, #9
    v.insert     v11, s14, #6
    v.extract    s14, v17, #9
    s.or         s20, s18, s19
    s.or         s18, s16, s15
    s.lshri      s15, s1, #32
    v.extract    s16, v12, #9
    s.shli       s19, s17, #32
    s.shli       s17, s14, #32
    s.add        s14, s20, s18
    v.extract    s18, v16, #9
    v.insert     v10, s1, #7
    v.extract    s1, v13, #10
    v.insert     v11, s15, #7
    v.extract    s15, v17, #10
    s.or         s20, s16, s19
    s.or         s16, s18, s17
    s.lshri      s17, s14, #32
    v.extract    s18, v12, #10
    s.shli       s19, s1, #32
    s.shli       s1, s15, #32
    s.add        s15, s20, s16
    v.extract    s16, v16, #10
    v.insert     v10, s14, #8
    v.extract    s14, v13, #11
    v.insert     v11, s17, #8
    v.extract    s17, v17, #11
    s.or         s20, s18, s19
    s.or         s18, s16, s1
    s.lshri      s1, s15, #32
    v.extract    s16, v12, #11
    s.shli       s19, s14, #32
    s.shli       s14, s17, #32
    s.add        s17, s20, s18
    v.extract    s18, v16, #11
    v.insert     v10, s15, #9
    v.extract    s15, v13, #12
    v.insert     v11, s1, #9
    v.extract    s1, v17, #12
    s.or         s20, s16, s19
    s.or         s16, s18, s14
    s.lshri      s14, s17, #32
    v.extract    s18, v12, #12
    s.shli       s19, s15, #32
    s.shli       s15, s1, #32
    s.add        s1, s20, s16
    v.extract    s16, v16, #12
    v.insert     v10, s17, #10
    v.extract    s17, v13, #13
    v.insert     v11, s14, #10
    v.extract    s14, v17, #13
    s.or         s20, s18, s19
    s.or         s18, s16, s15
    s.lshri      s15, s1, #32
    v.extract    s16, v12, #13
    s.shli       s19, s17, #32
    s.shli       s17, s14, #32
    s.add        s14, s20, s18
    v.extract    s18, v16, #13
    v.insert     v10, s1, #11
    v.extract    s1, v13, #14
    v.insert     v11, s15, #11
    v.movi       v14, #31
    v.extract    s15, v17, #14
    s.or         s20, s16, s19
    s.or         s16, s18, s17
    s.lshri      s17, s14, #32
    v.extract    s18, v12, #14
    s.shli       s19, s1, #32
    s.shli       s1, s15, #32
    v.ashr       v15, v5, v14
    s.add        s15, s20, s16
    v.extract    s16, v16, #14
    v.movi       v14, #1
    v.movi       v18, #0
    v.insert     v10, s14, #12
    v.extract    s14, v13, #15
    v.insert     v11, s17, #12
    v.extract    s17, v17, #15
    s.or         s20, s18, s19
    s.or         s18, s16, s1
    s.lshri      s1, s15, #32
    v.extract    s16, v12, #15
    s.shli       s19, s14, #32
    s.shli       s14, s17, #32
    v.cmp.ne     p1, v9, v15
    s.add        s17, s20, s18
    v.extract    s18, v16, #15
    @p1 v.sel        v9, v14, v18
    v.insert     v10, s15, #13
    v.insert     v11, s1, #13
    s.or         s1, s16, s19
    s.or         s15, s18, s14
    s.lshri      s14, s17, #32
    s.add        s16, s1, s15
    v.reduce.or  s1, v9
    s.movz       s15, #0
    v.insert     v10, s17, #14
    v.insert     v11, s14, #14
    s.lshri      s14, s16, #32
    s.cmp.eq     s17, s1, s15
    v.insert     v10, s16, #15
    v.insert     v11, s14, #15
    br.nz        s17, narrow_ok_4
    trap         #677220
narrow_ok_4:
    v.movi       v9, #31
    v.movi       v12, #1
    v.movi       v13, #0
    v.ashr       v14, v10, v9
    v.cmp.ne     p1, v11, v14
    @p1 v.sel        v9, v12, v13
    v.reduce.or  s1, v9
    s.cmp.eq     s14, s1, s15
    br.nz        s14, narrow_ok_5
    trap         #677220
narrow_ok_5:
    v.movi       v9, #128
    v.movi       v11, #0
    v.movi       v12, #0
    v.cmp.lt     p1, v6, v9
    v.cmp.lt     p2, v0, v9
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v13, [s10, v5]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v9
    s.add        s1, s13, s7
    s.movz       s14, #1
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v5, [s10, v10]             // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v6, v13
    v.cmp.lt     p2, v0, v9
    vf.mul       v0, v6, v6
    vf.add       v6, v1, v0
    vf.cvt.f16.f32 v0, v5
    @p1 v.sel        v5, v6, v1
    vf.mul       v6, v0, v0
    v.mov        v11, v5
    vf.add       v0, v7, v6
    @p2 v.sel        v5, v0, v7
    v.mov        v12, v5
    v.mov        v1, v11
    v.mov        v7, v12
    s.mov        s13, s1
    br.nz        s14, for_1
endfor_2:
    vf.reduce.add.b v0, v1
    vf.reduce.add.b v1, v7
    v.movi       v5, #0
    s.addi       s1, s5, #0
    vf.add       v6, v0, v1
    vf.add       v0, v6, v5
for_6:
    s.cmp.ge     s13, s1, s6
    br.nz        s13, endfor_7
    v.splat      v1, s1
    v.splat      v5, s1
    v.extract    s13, v8, #0
    s.add        s14, s2, s1
    v.extract    s15, v4, #0
    s.shli       s16, s13, #32
    v.add        v6, v1, v2
    v.add        v1, v5, v3
    v.movi       v5, #128
    s.shli       s13, s1, #1                     // element offset -> bytes (x2)
    s.shli       s17, s14, #1                    // element offset -> bytes (x2)
    s.or         s18, s15, s16
    s.movz       s15, #0
    s.movz       s16, #512
    s.add        s19, s11, s13                   // &in_ptr2[...]
    s.add        s13, s11, s17                   // &in_ptr2[...]
    v.movi       v7, #0
    v.movi       v9, #0
    v.cmp.lt     p1, v6, v5
    v.cmp.lt     p2, v1, v5
    s.cmp.ge     s17, s18, s15
    s.cmp.lt     s20, s18, s16
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v10, [s19, #0]
    v.movi       v11, #0
    v.movi       v12, #0
    v.movi       v13, #1
    s.movz       s16, #1
    v.iota       v14                             // arange(0, VLEN)
    v.splat      v15, s16
    v.cmp.lt     p1, v14, v15
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s13, #0]
    v.insert     v7, s17, #0
    v.insert     v9, s20, #0
    vf.cvt.f16.f32 v15, v10
    v.cmp.ne     p2, v7, v11
    v.cmp.ne     p3, v9, v12
    p.and        p4, p2, p3
    @p4 v.sel        v7, v12, v13
    @p1 v.reduce.or  s13, v7
    s.cmp.eq     s16, s13, s15
    vf.cvt.f16.f32 v7, v14
    br.nz        s16, assert_ok_8
    trap         #677351
assert_ok_8:
    s.movz       s13, #128
    v.extract    s15, v6, #0
    s.mul        s16, s18, s13
    s.shli       s13, s15, #32
    v.extract    s15, v6, #1
    s.ashri      s17, s13, #32
    v.movi       v9, #0
    v.movi       v10, #0
    v.movi       v11, #0
    v.movi       v12, #0
    s.shli       s13, s15, #32
    s.lshri      s15, s16, #32
    s.lshri      s18, s17, #32
    v.extract    s19, v6, #2
    s.ashri      s20, s13, #32
    v.insert     v9, s16, #0
    v.insert     v10, s15, #0
    v.insert     v11, s17, #0
    v.insert     v12, s18, #0
    s.shli       s13, s19, #32
    s.lshri      s15, s20, #32
    v.extract    s16, v6, #3
    s.ashri      s17, s13, #32
    v.insert     v11, s20, #1
    v.insert     v12, s15, #1
    s.shli       s13, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v6, #4
    s.ashri      s18, s13, #32
    v.insert     v11, s17, #2
    v.insert     v12, s15, #2
    s.shli       s13, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v6, #5
    s.ashri      s17, s13, #32
    v.insert     v11, s18, #3
    v.insert     v12, s15, #3
    s.shli       s13, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v6, #6
    s.ashri      s18, s13, #32
    v.insert     v11, s17, #4
    v.insert     v12, s15, #4
    s.shli       s13, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v6, #7
    s.ashri      s17, s13, #32
    v.insert     v11, s18, #5
    v.insert     v12, s15, #5
    s.shli       s13, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v6, #8
    s.ashri      s18, s13, #32
    v.insert     v11, s17, #6
    v.insert     v12, s15, #6
    s.shli       s13, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v6, #9
    s.ashri      s17, s13, #32
    v.insert     v11, s18, #7
    v.insert     v12, s15, #7
    s.shli       s13, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v6, #10
    s.ashri      s18, s13, #32
    v.insert     v11, s17, #8
    v.insert     v12, s15, #8
    s.shli       s13, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v6, #11
    s.ashri      s17, s13, #32
    v.insert     v11, s18, #9
    v.insert     v12, s15, #9
    s.shli       s13, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v6, #12
    s.ashri      s18, s13, #32
    v.insert     v11, s17, #10
    v.insert     v12, s15, #10
    s.shli       s13, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v6, #13
    s.ashri      s17, s13, #32
    v.insert     v11, s18, #11
    v.insert     v12, s15, #11
    s.shli       s13, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v6, #14
    s.ashri      s18, s13, #32
    v.insert     v11, s17, #12
    v.insert     v12, s15, #12
    s.shli       s13, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v6, #15
    v.extract    s17, v1, #0
    s.ashri      s19, s13, #32
    v.insert     v11, s18, #13
    v.insert     v12, s15, #13
    s.shli       s13, s16, #32
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v1, #1
    s.ashri      s18, s13, #32
    s.ashri      s13, s15, #32
    v.insert     v11, s19, #14
    v.insert     v12, s16, #14
    v.movi       v13, #0
    v.movi       v14, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    s.lshri      s17, s13, #32
    v.extract    s19, v1, #2
    s.ashri      s20, s15, #32
    v.insert     v11, s18, #15
    v.insert     v12, s16, #15
    v.insert     v13, s13, #0
    v.insert     v14, s17, #0
    s.shli       s13, s19, #32
    s.lshri      s15, s20, #32
    v.extract    s16, v1, #3
    s.ashri      s17, s13, #32
    v.insert     v13, s20, #1
    v.insert     v14, s15, #1
    s.shli       s13, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v1, #4
    s.ashri      s18, s13, #32
    v.insert     v13, s17, #2
    v.insert     v14, s15, #2
    s.shli       s13, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v1, #5
    s.ashri      s17, s13, #32
    v.insert     v13, s18, #3
    v.insert     v14, s15, #3
    s.shli       s13, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v1, #6
    s.ashri      s18, s13, #32
    v.insert     v13, s17, #4
    v.insert     v14, s15, #4
    s.shli       s13, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v1, #7
    s.ashri      s17, s13, #32
    v.insert     v13, s18, #5
    v.insert     v14, s15, #5
    s.shli       s13, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v1, #8
    s.ashri      s18, s13, #32
    v.insert     v13, s17, #6
    v.insert     v14, s15, #6
    s.shli       s13, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v1, #9
    s.ashri      s17, s13, #32
    v.insert     v13, s18, #7
    v.insert     v14, s15, #7
    s.shli       s13, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v1, #10
    s.ashri      s18, s13, #32
    v.insert     v13, s17, #8
    v.insert     v14, s15, #8
    s.shli       s13, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v1, #11
    s.ashri      s17, s13, #32
    v.insert     v13, s18, #9
    v.insert     v14, s15, #9
    s.shli       s13, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v1, #12
    s.ashri      s18, s13, #32
    v.insert     v13, s17, #10
    v.insert     v14, s15, #10
    s.shli       s13, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v1, #13
    s.ashri      s17, s13, #32
    v.insert     v13, s18, #11
    v.insert     v14, s15, #11
    s.shli       s13, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v1, #14
    s.ashri      s18, s13, #32
    v.insert     v13, s17, #12
    v.insert     v14, s15, #12
    s.shli       s13, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v1, #15
    v.extract    s17, v10, #0
    s.ashri      s19, s13, #32
    v.insert     v13, s18, #13
    v.insert     v14, s15, #13
    s.shli       s13, s16, #32
    v.extract    s15, v9, #0
    s.shli       s16, s17, #32
    s.lshri      s17, s19, #32
    v.extract    s18, v10, #0
    s.ashri      s20, s13, #32
    s.or         s13, s15, s16
    v.insert     v13, s19, #14
    v.insert     v14, s17, #14
    v.movi       v16, #0
    v.movi       v17, #0
    v.extract    s15, v9, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s20, #32
    s.lshri      s18, s13, #32
    v.extract    s19, v10, #0
    s.or         s21, s15, s16
    v.insert     v13, s20, #15
    v.insert     v14, s17, #15
    v.insert     v16, s13, #0
    v.insert     v17, s18, #0
    v.extract    s13, v9, #0
    s.shli       s15, s19, #32
    s.lshri      s16, s21, #32
    v.extract    s17, v10, #0
    s.or         s18, s13, s15
    v.insert     v16, s21, #1
    v.insert     v17, s16, #1
    v.extract    s13, v9, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v10, #0
    s.or         s19, s13, s15
    v.insert     v16, s18, #2
    v.insert     v17, s16, #2
    v.extract    s13, v9, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v10, #0
    s.or         s18, s13, s15
    v.insert     v16, s19, #3
    v.insert     v17, s16, #3
    v.extract    s13, v9, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v10, #0
    s.or         s19, s13, s15
    v.insert     v16, s18, #4
    v.insert     v17, s16, #4
    v.extract    s13, v9, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v10, #0
    s.or         s18, s13, s15
    v.insert     v16, s19, #5
    v.insert     v17, s16, #5
    v.extract    s13, v9, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v10, #0
    s.or         s19, s13, s15
    v.insert     v16, s18, #6
    v.insert     v17, s16, #6
    v.extract    s13, v9, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v10, #0
    s.or         s18, s13, s15
    v.insert     v16, s19, #7
    v.insert     v17, s16, #7
    v.extract    s13, v9, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v10, #0
    s.or         s19, s13, s15
    v.insert     v16, s18, #8
    v.insert     v17, s16, #8
    v.extract    s13, v9, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v10, #0
    s.or         s18, s13, s15
    v.insert     v16, s19, #9
    v.insert     v17, s16, #9
    v.extract    s13, v9, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v10, #0
    s.or         s19, s13, s15
    v.insert     v16, s18, #10
    v.insert     v17, s16, #10
    v.extract    s13, v9, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v10, #0
    s.or         s18, s13, s15
    v.insert     v16, s19, #11
    v.insert     v17, s16, #11
    v.extract    s13, v9, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v10, #0
    s.or         s19, s13, s15
    v.insert     v16, s18, #12
    v.insert     v17, s16, #12
    v.extract    s13, v9, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v10, #0
    v.extract    s18, v10, #0
    s.or         s20, s13, s15
    v.insert     v16, s19, #13
    v.insert     v17, s16, #13
    v.extract    s13, v9, #0
    s.shli       s15, s17, #32
    v.extract    s16, v9, #0
    s.shli       s17, s18, #32
    s.lshri      s18, s20, #32
    v.extract    s19, v10, #0
    s.or         s21, s13, s15
    s.or         s13, s16, s17
    v.insert     v16, s20, #14
    v.insert     v17, s18, #14
    v.movi       v18, #0
    v.movi       v19, #0
    v.extract    s15, v9, #0
    s.shli       s16, s19, #32
    s.lshri      s17, s21, #32
    s.lshri      s18, s13, #32
    v.extract    s19, v10, #0
    s.or         s20, s15, s16
    v.insert     v16, s21, #15
    v.insert     v17, s17, #15
    v.insert     v18, s13, #0
    v.insert     v19, s18, #0
    v.extract    s13, v9, #0
    s.shli       s15, s19, #32
    s.lshri      s16, s20, #32
    v.extract    s17, v10, #0
    s.or         s18, s13, s15
    v.insert     v18, s20, #1
    v.insert     v19, s16, #1
    v.extract    s13, v9, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v10, #0
    s.or         s19, s13, s15
    v.insert     v18, s18, #2
    v.insert     v19, s16, #2
    v.extract    s13, v9, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v10, #0
    s.or         s18, s13, s15
    v.insert     v18, s19, #3
    v.insert     v19, s16, #3
    v.extract    s13, v9, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v10, #0
    s.or         s19, s13, s15
    v.insert     v18, s18, #4
    v.insert     v19, s16, #4
    v.extract    s13, v9, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v10, #0
    s.or         s18, s13, s15
    v.insert     v18, s19, #5
    v.insert     v19, s16, #5
    v.extract    s13, v9, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v10, #0
    s.or         s19, s13, s15
    v.insert     v18, s18, #6
    v.insert     v19, s16, #6
    v.extract    s13, v9, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v10, #0
    s.or         s18, s13, s15
    v.insert     v18, s19, #7
    v.insert     v19, s16, #7
    v.extract    s13, v9, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v10, #0
    s.or         s19, s13, s15
    v.insert     v18, s18, #8
    v.insert     v19, s16, #8
    v.extract    s13, v9, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v10, #0
    s.or         s18, s13, s15
    v.insert     v18, s19, #9
    v.insert     v19, s16, #9
    v.extract    s13, v9, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v10, #0
    s.or         s19, s13, s15
    v.insert     v18, s18, #10
    v.insert     v19, s16, #10
    v.extract    s13, v9, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v10, #0
    s.or         s18, s13, s15
    v.insert     v18, s19, #11
    v.insert     v19, s16, #11
    v.extract    s13, v9, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v10, #0
    s.or         s19, s13, s15
    v.extract    s13, v12, #0
    v.extract    s15, v17, #0
    v.insert     v18, s18, #12
    v.insert     v19, s16, #12
    v.extract    s16, v9, #0
    s.shli       s18, s17, #32
    s.lshri      s17, s19, #32
    v.extract    s20, v10, #0
    s.shli       s21, s13, #32
    s.shli       s13, s15, #32
    s.or         s15, s16, s18
    v.extract    s16, v11, #0
    v.insert     v18, s19, #13
    v.extract    s18, v16, #0
    v.insert     v19, s17, #13
    v.extract    s17, v12, #1
    s.shli       s19, s20, #32
    s.or         s20, s16, s21
    v.extract    s16, v17, #1
    s.or         s21, s18, s13
    v.extract    s13, v9, #0
    s.shli       s18, s17, #32
    s.shli       s17, s16, #32
    s.or         s16, s13, s19
    s.lshri      s13, s15, #32
    s.add        s19, s20, s21
    v.extract    s20, v11, #1
    v.insert     v18, s15, #14
    v.extract    s15, v16, #1
    v.insert     v19, s13, #14
    v.extract    s13, v12, #2
    v.movi       v9, #0
    v.movi       v10, #0
    s.or         s21, s20, s18
    v.extract    s18, v17, #2
    s.or         s20, s15, s17
    s.lshri      s15, s16, #32
    s.shli       s17, s13, #32
    s.shli       s13, s18, #32
    s.add        s18, s21, s20
    s.lshri      s20, s19, #32
    v.insert     v18, s16, #15
    v.extract    s16, v11, #2
    v.insert     v19, s15, #15
    v.extract    s15, v16, #2
    v.insert     v9, s19, #0
    v.extract    s19, v12, #3
    v.insert     v10, s20, #0
    v.extract    s20, v17, #3
    s.or         s21, s16, s17
    s.or         s16, s15, s13
    s.lshri      s13, s18, #32
    v.extract    s15, v11, #3
    s.shli       s17, s19, #32
    s.shli       s19, s20, #32
    s.add        s20, s21, s16
    v.extract    s16, v16, #3
    v.insert     v9, s18, #1
    v.extract    s18, v12, #4
    v.insert     v10, s13, #1
    v.extract    s13, v17, #4
    s.or         s21, s15, s17
    s.or         s15, s16, s19
    s.lshri      s16, s20, #32
    v.extract    s17, v11, #4
    s.shli       s19, s18, #32
    s.shli       s18, s13, #32
    s.add        s13, s21, s15
    v.extract    s15, v16, #4
    v.insert     v9, s20, #2
    v.extract    s20, v12, #5
    v.insert     v10, s16, #2
    v.extract    s16, v17, #5
    s.or         s21, s17, s19
    s.or         s17, s15, s18
    s.lshri      s15, s13, #32
    v.extract    s18, v11, #5
    s.shli       s19, s20, #32
    s.shli       s20, s16, #32
    s.add        s16, s21, s17
    v.extract    s17, v16, #5
    v.insert     v9, s13, #3
    v.extract    s13, v12, #6
    v.insert     v10, s15, #3
    v.extract    s15, v17, #6
    s.or         s21, s18, s19
    s.or         s18, s17, s20
    s.lshri      s17, s16, #32
    v.extract    s19, v11, #6
    s.shli       s20, s13, #32
    s.shli       s13, s15, #32
    s.add        s15, s21, s18
    v.extract    s18, v16, #6
    v.insert     v9, s16, #4
    v.extract    s16, v12, #7
    v.insert     v10, s17, #4
    v.extract    s17, v17, #7
    s.or         s21, s19, s20
    s.or         s19, s18, s13
    s.lshri      s13, s15, #32
    v.extract    s18, v11, #7
    s.shli       s20, s16, #32
    s.shli       s16, s17, #32
    s.add        s17, s21, s19
    v.extract    s19, v16, #7
    v.insert     v9, s15, #5
    v.extract    s15, v12, #8
    v.insert     v10, s13, #5
    v.extract    s13, v17, #8
    s.or         s21, s18, s20
    s.or         s18, s19, s16
    s.lshri      s16, s17, #32
    v.extract    s19, v11, #8
    s.shli       s20, s15, #32
    s.shli       s15, s13, #32
    s.add        s13, s21, s18
    v.extract    s18, v16, #8
    v.insert     v9, s17, #6
    v.extract    s17, v12, #9
    v.insert     v10, s16, #6
    v.extract    s16, v17, #9
    s.or         s21, s19, s20
    s.or         s19, s18, s15
    s.lshri      s15, s13, #32
    v.extract    s18, v11, #9
    s.shli       s20, s17, #32
    s.shli       s17, s16, #32
    s.add        s16, s21, s19
    v.extract    s19, v16, #9
    v.insert     v9, s13, #7
    v.extract    s13, v12, #10
    v.insert     v10, s15, #7
    v.extract    s15, v17, #10
    s.or         s21, s18, s20
    s.or         s18, s19, s17
    s.lshri      s17, s16, #32
    v.extract    s19, v11, #10
    s.shli       s20, s13, #32
    s.shli       s13, s15, #32
    s.add        s15, s21, s18
    v.extract    s18, v16, #10
    v.insert     v9, s16, #8
    v.extract    s16, v12, #11
    v.insert     v10, s17, #8
    v.extract    s17, v17, #11
    s.or         s21, s19, s20
    s.or         s19, s18, s13
    s.lshri      s13, s15, #32
    v.extract    s18, v11, #11
    s.shli       s20, s16, #32
    s.shli       s16, s17, #32
    s.add        s17, s21, s19
    v.extract    s19, v16, #11
    v.insert     v9, s15, #9
    v.extract    s15, v12, #12
    v.insert     v10, s13, #9
    v.extract    s13, v17, #12
    s.or         s21, s18, s20
    s.or         s18, s19, s16
    s.lshri      s16, s17, #32
    v.extract    s19, v11, #12
    s.shli       s20, s15, #32
    s.shli       s15, s13, #32
    s.add        s13, s21, s18
    v.extract    s18, v16, #12
    v.insert     v9, s17, #10
    v.extract    s17, v12, #13
    v.insert     v10, s16, #10
    v.extract    s16, v17, #13
    s.or         s21, s19, s20
    s.or         s19, s18, s15
    s.lshri      s15, s13, #32
    v.extract    s18, v11, #13
    s.shli       s20, s17, #32
    s.shli       s17, s16, #32
    s.add        s16, s21, s19
    v.extract    s19, v16, #13
    v.insert     v9, s13, #11
    v.extract    s13, v12, #14
    v.insert     v10, s15, #11
    v.extract    s15, v17, #14
    s.or         s21, s18, s20
    s.or         s18, s19, s17
    s.lshri      s17, s16, #32
    v.extract    s19, v11, #14
    s.shli       s20, s13, #32
    s.shli       s13, s15, #32
    s.add        s15, s21, s18
    v.extract    s18, v16, #14
    v.insert     v9, s16, #12
    v.extract    s16, v12, #15
    v.insert     v10, s17, #12
    v.extract    s17, v17, #15
    s.or         s21, s19, s20
    v.extract    s19, v14, #0
    s.or         s20, s18, s13
    v.extract    s13, v19, #0
    s.shli       s18, s16, #32
    s.shli       s16, s17, #32
    s.shli       s17, s19, #32
    s.shli       s19, s13, #32
    s.add        s13, s21, s20
    s.lshri      s20, s15, #32
    v.insert     v9, s15, #13
    v.extract    s15, v11, #15
    v.insert     v10, s20, #13
    v.extract    s20, v16, #15
    s.or         s21, s15, s18
    v.extract    s15, v13, #0
    s.or         s18, s20, s16
    v.extract    s16, v18, #0
    s.or         s20, s15, s17
    v.extract    s15, v14, #1
    s.or         s17, s16, s19
    v.extract    s16, v19, #1
    s.shli       s19, s15, #32
    s.shli       s15, s16, #32
    s.add        s16, s21, s18
    s.lshri      s18, s13, #32
    s.add        s21, s20, s17
    v.extract    s17, v13, #1
    v.insert     v9, s13, #14
    v.extract    s13, v18, #1
    v.insert     v10, s18, #14
    v.extract    s18, v14, #2
    v.movi       v11, #0
    v.movi       v12, #0
    s.or         s20, s17, s19
    v.extract    s17, v19, #2
    s.or         s19, s13, s15
    s.lshri      s13, s16, #32
    s.shli       s15, s18, #32
    s.shli       s18, s17, #32
    s.add        s17, s20, s19
    s.lshri      s19, s21, #32
    v.insert     v9, s16, #15
    v.extract    s16, v13, #2
    v.insert     v10, s13, #15
    v.extract    s13, v18, #2
    v.insert     v11, s21, #0
    v.extract    s20, v14, #3
    v.insert     v12, s19, #0
    v.extract    s19, v19, #3
    s.or         s21, s16, s15
    s.or         s15, s13, s18
    s.lshri      s13, s17, #32
    v.extract    s16, v13, #3
    s.shli       s18, s20, #32
    s.shli       s20, s19, #32
    s.add        s19, s21, s15
    v.extract    s15, v18, #3
    v.insert     v11, s17, #1
    v.extract    s17, v14, #4
    v.insert     v12, s13, #1
    v.extract    s13, v19, #4
    s.or         s21, s16, s18
    s.or         s16, s15, s20
    s.lshri      s15, s19, #32
    v.extract    s18, v13, #4
    s.shli       s20, s17, #32
    s.shli       s17, s13, #32
    s.add        s13, s21, s16
    v.extract    s16, v18, #4
    v.insert     v11, s19, #2
    v.extract    s19, v14, #5
    v.insert     v12, s15, #2
    v.extract    s15, v19, #5
    s.or         s21, s18, s20
    s.or         s18, s16, s17
    s.lshri      s16, s13, #32
    v.extract    s17, v13, #5
    s.shli       s20, s19, #32
    s.shli       s19, s15, #32
    s.add        s15, s21, s18
    v.extract    s18, v18, #5
    v.insert     v11, s13, #3
    v.extract    s13, v14, #6
    v.insert     v12, s16, #3
    v.extract    s16, v19, #6
    s.or         s21, s17, s20
    s.or         s17, s18, s19
    s.lshri      s18, s15, #32
    v.extract    s19, v13, #6
    s.shli       s20, s13, #32
    s.shli       s13, s16, #32
    s.add        s16, s21, s17
    v.extract    s17, v18, #6
    v.insert     v11, s15, #4
    v.extract    s15, v14, #7
    v.insert     v12, s18, #4
    v.extract    s18, v19, #7
    s.or         s21, s19, s20
    s.or         s19, s17, s13
    s.lshri      s13, s16, #32
    v.extract    s17, v13, #7
    s.shli       s20, s15, #32
    s.shli       s15, s18, #32
    s.add        s18, s21, s19
    v.extract    s19, v18, #7
    v.insert     v11, s16, #5
    v.extract    s16, v14, #8
    v.insert     v12, s13, #5
    v.extract    s13, v19, #8
    s.or         s21, s17, s20
    s.or         s17, s19, s15
    s.lshri      s15, s18, #32
    v.extract    s19, v13, #8
    s.shli       s20, s16, #32
    s.shli       s16, s13, #32
    s.add        s13, s21, s17
    v.extract    s17, v18, #8
    v.insert     v11, s18, #6
    v.extract    s18, v14, #9
    v.insert     v12, s15, #6
    v.extract    s15, v19, #9
    s.or         s21, s19, s20
    s.or         s19, s17, s16
    s.lshri      s16, s13, #32
    v.extract    s17, v13, #9
    s.shli       s20, s18, #32
    s.shli       s18, s15, #32
    s.add        s15, s21, s19
    v.extract    s19, v18, #9
    v.insert     v11, s13, #7
    v.extract    s13, v14, #10
    v.insert     v12, s16, #7
    v.extract    s16, v19, #10
    s.or         s21, s17, s20
    s.or         s17, s19, s18
    s.lshri      s18, s15, #32
    v.extract    s19, v13, #10
    s.shli       s20, s13, #32
    s.shli       s13, s16, #32
    s.add        s16, s21, s17
    v.extract    s17, v18, #10
    v.insert     v11, s15, #8
    v.extract    s15, v14, #11
    v.insert     v12, s18, #8
    v.extract    s18, v19, #11
    s.or         s21, s19, s20
    s.or         s19, s17, s13
    s.lshri      s13, s16, #32
    v.extract    s17, v13, #11
    s.shli       s20, s15, #32
    s.shli       s15, s18, #32
    s.add        s18, s21, s19
    v.extract    s19, v18, #11
    v.insert     v11, s16, #9
    v.extract    s16, v14, #12
    v.insert     v12, s13, #9
    v.extract    s13, v19, #12
    s.or         s21, s17, s20
    s.or         s17, s19, s15
    s.lshri      s15, s18, #32
    v.extract    s19, v13, #12
    s.shli       s20, s16, #32
    s.shli       s16, s13, #32
    s.add        s13, s21, s17
    v.extract    s17, v18, #12
    v.insert     v11, s18, #10
    v.extract    s18, v14, #13
    v.insert     v12, s15, #10
    v.extract    s15, v19, #13
    s.or         s21, s19, s20
    s.or         s19, s17, s16
    s.lshri      s16, s13, #32
    v.extract    s17, v13, #13
    s.shli       s20, s18, #32
    s.shli       s18, s15, #32
    s.add        s15, s21, s19
    v.extract    s19, v18, #13
    v.insert     v11, s13, #11
    v.extract    s13, v14, #14
    v.insert     v12, s16, #11
    v.movi       v16, #31
    v.extract    s16, v19, #14
    s.or         s21, s17, s20
    s.or         s17, s19, s18
    s.lshri      s18, s15, #32
    v.extract    s19, v13, #14
    s.shli       s20, s13, #32
    s.shli       s13, s16, #32
    v.ashr       v17, v9, v16
    s.add        s16, s21, s17
    v.extract    s17, v18, #14
    v.movi       v16, #1
    v.movi       v20, #0
    v.insert     v11, s15, #12
    v.extract    s15, v14, #15
    v.insert     v12, s18, #12
    v.extract    s18, v19, #15
    s.or         s21, s19, s20
    s.or         s19, s17, s13
    s.lshri      s13, s16, #32
    v.extract    s17, v13, #15
    s.shli       s20, s15, #32
    s.shli       s15, s18, #32
    v.cmp.ne     p1, v10, v17
    s.add        s18, s21, s19
    v.extract    s19, v18, #15
    @p1 v.sel        v10, v16, v20
    v.insert     v11, s16, #13
    v.insert     v12, s13, #13
    s.or         s13, s17, s20
    s.or         s16, s19, s15
    s.lshri      s15, s18, #32
    s.add        s17, s13, s16
    v.reduce.or  s13, v10
    s.movz       s16, #0
    v.insert     v11, s18, #14
    v.insert     v12, s15, #14
    s.lshri      s15, s17, #32
    s.cmp.eq     s18, s13, s16
    v.insert     v11, s17, #15
    v.insert     v12, s15, #15
    br.nz        s18, narrow_ok_9
    trap         #677220
narrow_ok_9:
    v.movi       v10, #31
    v.movi       v13, #1
    v.movi       v14, #0
    v.ashr       v16, v11, v10
    v.cmp.ne     p1, v12, v16
    @p1 v.sel        v10, v13, v14
    v.reduce.or  s13, v10
    s.cmp.eq     s15, s13, s16
    br.nz        s15, narrow_ok_10
    trap         #677220
narrow_ok_10:
    v.cmp.lt     p1, v6, v5
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v10, [s10, v9]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v5
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v9, [s10, v11]             // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v11, v10
    vf.cvt.f16.f32 v10, v9
    .li       s13, #1124073472
    v.splat      v9, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v12, v9                         // ISA 8.8: <= 2**-22 relative
    .li       s13, #1065353216
    v.splat      v13, s13                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v14, v9, v12, v13
    vf.fms       v9, v12, v14, v12
    vf.neg       v13, v9                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v13, v13
    @p1 v.sel        v9, v13, v12
    vf.mul       v12, v0, v9                     // a/y as a refined reciprocal (ISA has no divide)
    .li       s13, #925353388
    v.splat      v9, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v13, v12, v9
    v.rsqrt.approx v9, v13                       // ISA 8.8: <= 2**-22 relative
    vf.mul       v12, v9, v9
    .li       s13, #1077936128
    v.splat      v14, s13                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v16, v13, v12, v14
    .li       s13, #3204448256
    v.splat      v12, s13                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v13, v9, v12
    vf.mul       v12, v13, v16                   // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v12, v12
    @p1 v.sel        v13, v12, v9
    v.extract    s13, v13, #0
    v.splat      v9, s13
    vf.mul       v12, v11, v9
    vf.mul       v11, v10, v9
    vf.mul       v9, v12, v15
    vf.mul       v10, v11, v7
    s.mul        s13, s8, s6
    v.splat      v7, s13
    v.add        v11, v6, v7
    s.add        s15, s1, s13
    v.add        v11, v1, v7
    s.add        s16, s14, s13
    vf.cvt.f32.f16 v7, v9
    vf.cvt.f32.f16 v9, v10
    v.cmp.lt     p1, v6, v5
    s.shli       s13, s15, #1                    // element offset -> bytes (x2)
    s.add        s14, s12, s13                   // &out_ptr1[...]
    @p1 v.st.h       [s14, #0], v7
    v.cmp.lt     p1, v1, v5
    s.shli       s13, s16, #1                    // element offset -> bytes (x2)
    s.add        s14, s12, s13                   // &out_ptr1[...]
    @p1 v.st.h       [s14, #0], v9
    s.add        s13, s1, s7
    s.mov        s1, s13
    s.movz       s13, #1
    br.nz        s13, for_6
endfor_7:
__rctx_next:
    s.addi       s1, s8, #4                      // the next program of this context: + 4
    s.cmp.lt     s13, s1, s9
    s.mov        s8, s1
    br.nz        s13, __rctx_program
    exit
