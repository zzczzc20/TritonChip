    s.rdspecial  s1, arg_base
    s.movz       s2, #256
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #0
    s.rdspecial  s5, role_id
    s.rdspecial  s6, npid.x
    s.ld.d       s7, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s8, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s9, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s10, [s1, #32]                  // out_ptr0: device_ptr64 at arg_base+32
__rctx_program:
    v.movi       v0, #2048
    v.movi       v1, #0
    v.iota       v2                              // arange(0, VLEN)
    v.movi       v3, #16
    v.movi       v4, #32
    v.movi       v5, #48
    v.movi       v6, #64
    v.movi       v7, #80
    v.movi       v8, #96
    v.movi       v9, #112
    v.sub        v10, v1, v0
    v.cmp.lt     p1, v0, v1
    // tiled element-wise program: 256 lanes as 2 tiles of 128 (3 tensor-engine transfers, one load buffer(s))
    s.mul        s1, s5, s2
    s.addi       s11, s4, #0
    v.add        v11, v2, v3
    v.add        v3, v2, v4
    v.add        v4, v2, v5
    v.add        v5, v2, v6
    v.add        v6, v2, v7
    v.add        v7, v2, v8
    v.add        v8, v2, v9
    @p1 v.sel        v9, v10, v0
    v.movi       v0, #2047
tiles_1:
    // tile 0 of the iteration: lanes t0 + 0
    s.add        s12, s1, s11
    // tile 1 of the iteration: lanes t0 + 128
    s.addi       s13, s11, #128
    v.splat      v9, s12
    s.add        s14, s1, s13
    v.add        v10, v9, v2
    v.add        v12, v9, v11
    v.add        v13, v9, v3
    v.add        v14, v9, v4
    v.add        v15, v9, v5
    v.add        v16, v9, v6
    v.add        v17, v9, v7
    v.add        v18, v9, v8
    v.sub        v9, v1, v10
    v.sub        v19, v1, v12
    v.sub        v20, v1, v13
    v.sub        v21, v1, v14
    v.sub        v22, v1, v15
    v.sub        v23, v1, v16
    v.sub        v24, v1, v17
    v.cmp.lt     p1, v10, v1
    v.cmp.lt     p2, v12, v1
    @p1 v.sel        v25, v9, v10
    @p2 v.sel        v9, v19, v12
    v.splat      v10, s14
    v.sub        v12, v1, v18
    v.and        v19, v25, v0
    v.and        v25, v9, v0
    s.shli       s13, s12, #1
    v.sub        v9, v1, v19
    v.sub        v26, v1, v25
    s.add        s12, s3, s13
    @p1 v.sel        v27, v9, v19
    v.cmp.lt     p1, v13, v1
    @p1 v.sel        v9, v20, v13
    @p2 v.sel        v13, v26, v25
    v.cmp.lt     p2, v14, v1
    @p2 v.sel        v19, v21, v14
    v.and        v14, v9, v0
    v.ld.h       v9, [s12, #0]
    v.and        v20, v19, v0
    v.sub        v19, v1, v14
    v.sub        v21, v1, v20
    @p1 v.sel        v25, v19, v14
    v.cmp.lt     p1, v15, v1
    @p1 v.sel        v14, v22, v15
    @p2 v.sel        v15, v21, v20
    v.cmp.lt     p2, v16, v1
    @p2 v.sel        v19, v23, v16
    v.and        v16, v14, v0
    v.and        v14, v19, v0
    v.sub        v19, v1, v16
    v.ld.h       v20, [s12, #32]
    v.sub        v21, v1, v14
    @p1 v.sel        v22, v19, v16
    v.cmp.lt     p1, v17, v1
    @p1 v.sel        v16, v24, v17
    @p2 v.sel        v17, v21, v14
    v.cmp.lt     p2, v18, v1
    @p2 v.sel        v14, v12, v18
    v.and        v12, v16, v0
    s.add        s15, s8, s13
    v.and        v16, v14, v0
    v.sub        v14, v1, v12
    vf.cvt.f16.f32 v18, v9
    v.sub        v9, v1, v16
    @p1 v.sel        v19, v14, v12
    v.ld.h       v12, [s12, #64]
    @p2 v.sel        v14, v9, v16
    vf.cvt.f16.f32 v9, v20
    v.add        v16, v10, v2
    v.add        v20, v10, v11
    v.add        v21, v10, v3
    v.add        v23, v10, v4
    v.add        v24, v10, v5
    v.add        v26, v10, v6
    v.add        v28, v10, v7
    v.add        v29, v10, v8
    v.sub        v10, v1, v16
    v.cmp.lt     p1, v16, v1
    v.ld.h       v30, [s12, #96]
    vf.cvt.f16.f32 v31, v12
    @p1 v.sel        v12, v10, v16
    v.ld.h       v10, [s12, #128]
    vf.cvt.f16.f32 v16, v30
    v.and        v30, v12, v0
    v.ld.h       v12, [s12, #160]
    vf.cvt.f16.f32 v32, v10
    v.sub        v10, v1, v30
    v.ld.h       v33, [s12, #192]
    vf.cvt.f16.f32 v34, v12
    @p1 v.sel        v12, v10, v30
    v.ld.h       v10, [s12, #224]
    vf.cvt.f16.f32 v30, v33
    v.sub        v33, v1, v20
    v.sub        v35, v1, v21
    v.cmp.lt     p1, v20, v1
    v.cmp.lt     p2, v21, v1
    @p1 v.sel        v36, v33, v20
    v.and        v20, v36, v0
    v.sub        v33, v1, v20
    v.ld.gather.h v36, [s7, v27]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v37, v10
    @p2 v.sel        v10, v35, v21
    @p1 v.sel        v21, v33, v20
    v.and        v20, v10, v0
    v.ld.gather.h v10, [s7, v13]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v33, v36
    v.sub        v35, v1, v20
    v.ld.gather.h v36, [s7, v25]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v38, v10
    @p2 v.sel        v10, v35, v20
    v.ld.gather.h v20, [s7, v15]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v35, v36
    v.cmp.lt     p1, v23, v1
    v.ld.gather.h v36, [s7, v22]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v39, v20
    v.sub        v20, v1, v23
    v.ld.gather.h v40, [s7, v17]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v41, v36
    @p1 v.sel        v36, v20, v23
    v.ld.gather.h v20, [s7, v19]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v23, v40
    v.and        v40, v36, v0
    v.ld.gather.h v36, [s7, v14]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v42, v20
    v.sub        v20, v1, v24
    v.cmp.lt     p2, v24, v1
    v.sub        v43, v1, v40
    @p2 v.sel        v44, v20, v24
    @p1 v.sel        v20, v43, v40
    v.and        v24, v44, v0
    v.sub        v40, v1, v24
    v.ld.h       v43, [s15, #0]
    vf.cvt.f16.f32 v44, v36
    v.sub        v36, v1, v26
    v.cmp.lt     p1, v26, v1
    @p2 v.sel        v45, v40, v24
    @p1 v.sel        v24, v36, v26
    v.ld.h       v26, [s15, #32]
    v.and        v36, v24, v0
    v.ld.h       v24, [s15, #64]
    v.sub        v40, v1, v36
    v.ld.h       v46, [s15, #96]
    @p1 v.sel        v47, v40, v36
    v.ld.h       v36, [s15, #128]
    v.cmp.lt     p1, v28, v1
    v.ld.h       v40, [s15, #160]
    v.sub        v48, v1, v28
    v.ld.h       v49, [s15, #192]
    @p1 v.sel        v50, v48, v28
    v.ld.h       v28, [s15, #224]
    v.sub        v48, v1, v29
    v.cmp.lt     p2, v29, v1
    v.and        v51, v50, v0
    @p2 v.sel        v50, v48, v29
    s.shli       s12, s14, #1
    v.sub        v29, v1, v51
    v.and        v48, v50, v0
    s.add        s14, s3, s12
    @p1 v.sel        v50, v29, v51
    vf.cvt.f16.f32 v29, v43
    vf.cvt.f16.f32 v43, v26
    vf.cvt.f16.f32 v26, v24
    v.sub        v24, v1, v48
    vf.cvt.f16.f32 v51, v46
    s.add        s15, s8, s12
    @p2 v.sel        v46, v24, v48
    vf.cvt.f16.f32 v24, v36
    vf.cvt.f16.f32 v36, v40
    vf.cvt.f16.f32 v40, v49
    v.ld.h       v48, [s14, #0]
    vf.cvt.f16.f32 v49, v28
    v.ld.h       v28, [s14, #32]
    vf.cvt.f16.f32 v52, v48
    v.ld.gather.h v48, [s9, v27]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v27, v28
    v.ld.h       v28, [s14, #64]
    v.ld.gather.h v53, [s9, v13]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v13, v28
    v.ld.h       v28, [s14, #96]
    v.ld.gather.h v54, [s9, v25]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v25, v28
    v.ld.h       v28, [s14, #128]
    v.ld.gather.h v55, [s9, v15]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v15, v28
    v.ld.h       v28, [s14, #160]
    v.ld.gather.h v56, [s9, v22]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v22, v28
    v.ld.h       v28, [s14, #192]
    v.ld.gather.h v57, [s9, v17]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v17, v28
    v.ld.h       v28, [s14, #224]
    vf.cvt.f16.f32 v58, v48
    vf.cvt.f16.f32 v48, v53
    vf.cvt.f16.f32 v53, v54
    vf.cvt.f16.f32 v54, v55
    vf.cvt.f16.f32 v55, v56
    vf.cvt.f16.f32 v56, v57
    v.ld.gather.h v57, [s9, v19]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v19, v28
    v.ld.gather.h v28, [s9, v14]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v14, v57
    v.ld.gather.h v57, [s7, v12]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v59, v28
    v.ld.gather.h v28, [s7, v21]                 // index is in elements (ISA sec 9.1)
    vf.mul       v60, v18, v33
    vf.cvt.f16.f32 v18, v57
    v.ld.gather.h v33, [s7, v10]                 // index is in elements (ISA sec 9.1)
    vf.mul       v57, v9, v38
    vf.cvt.f16.f32 v9, v28
    v.ld.gather.h v28, [s7, v20]                 // index is in elements (ISA sec 9.1)
    vf.mul       v38, v31, v35
    vf.cvt.f16.f32 v31, v33
    v.ld.gather.h v33, [s7, v45]                 // index is in elements (ISA sec 9.1)
    vf.mul       v35, v16, v39
    vf.cvt.f16.f32 v16, v28
    v.ld.gather.h v28, [s7, v47]                 // index is in elements (ISA sec 9.1)
    vf.mul       v39, v32, v41
    vf.cvt.f16.f32 v32, v33
    v.ld.gather.h v33, [s7, v50]                 // index is in elements (ISA sec 9.1)
    vf.mul       v41, v34, v23
    vf.cvt.f16.f32 v23, v28
    v.ld.gather.h v28, [s7, v46]                 // index is in elements (ISA sec 9.1)
    vf.mul       v34, v30, v42
    vf.mul       v30, v37, v44
    vf.mul       v37, v29, v58
    vf.mul       v29, v43, v48
    vf.mul       v42, v26, v53
    vf.mul       v26, v51, v54
    vf.mul       v43, v24, v55
    vf.cvt.f16.f32 v24, v33
    vf.mul       v33, v36, v56
    v.ld.h       v36, [s15, #0]
    vf.cvt.f16.f32 v44, v28
    vf.mul       v28, v40, v14
    vf.mul       v14, v49, v59
    vf.add       v40, v60, v37
    v.ld.h       v37, [s15, #32]
    vf.add       v48, v57, v29
    v.ld.h       v29, [s15, #64]
    vf.add       v49, v38, v42
    v.ld.h       v38, [s15, #96]
    vf.add       v42, v35, v26
    v.ld.h       v26, [s15, #128]
    vf.add       v35, v39, v43
    v.ld.h       v39, [s15, #160]
    vf.add       v43, v41, v33
    v.ld.h       v33, [s15, #192]
    vf.add       v41, v34, v28
    v.ld.h       v28, [s15, #224]
    vf.add       v34, v30, v14
    vf.cvt.f32.f16 v14, v40
    vf.cvt.f32.f16 v30, v48
    vf.cvt.f32.f16 v40, v49
    vf.cvt.f32.f16 v48, v42
    vf.cvt.f32.f16 v42, v35
    vf.cvt.f32.f16 v35, v43
    vf.cvt.f32.f16 v43, v41
    vf.cvt.f32.f16 v41, v34
    s.add        s14, s10, s13
    vf.cvt.f16.f32 v34, v36
    vf.cvt.f16.f32 v36, v37
    vf.cvt.f16.f32 v37, v29
    v.st.h       [s14, #0], v14
    vf.cvt.f16.f32 v14, v38
    vf.cvt.f16.f32 v29, v26
    vf.cvt.f16.f32 v26, v39
    vf.cvt.f16.f32 v38, v33
    vf.cvt.f16.f32 v33, v28
    vf.mul       v28, v52, v18
    vf.mul       v18, v27, v9
    vf.mul       v9, v13, v31
    vf.mul       v13, v25, v16
    vf.mul       v16, v15, v32
    vf.mul       v15, v22, v23
    vf.mul       v22, v17, v24
    vf.mul       v17, v19, v44
    v.st.h       [s14, #32], v30
    v.st.h       [s14, #64], v40
    v.st.h       [s14, #96], v48
    v.st.h       [s14, #128], v42
    v.st.h       [s14, #160], v35
    v.st.h       [s14, #192], v43
    v.st.h       [s14, #224], v41
    v.ld.gather.h v19, [s9, v12]                 // index is in elements (ISA sec 9.1)
    s.add        s13, s10, s12
    v.ld.gather.h v12, [s9, v21]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v21, v19
    vf.mul       v19, v34, v21
    vf.add       v21, v28, v19
    v.ld.gather.h v19, [s9, v10]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v10, v12
    vf.cvt.f32.f16 v12, v21
    vf.mul       v21, v36, v10
    vf.add       v10, v18, v21
    v.ld.gather.h v18, [s9, v20]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v20, v19
    vf.cvt.f32.f16 v19, v10
    vf.mul       v10, v37, v20
    vf.add       v20, v9, v10
    v.ld.gather.h v9, [s9, v45]                  // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v10, v18
    vf.cvt.f32.f16 v18, v20
    vf.mul       v20, v14, v10
    vf.add       v10, v13, v20
    v.ld.gather.h v13, [s9, v47]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v14, v9
    vf.cvt.f32.f16 v9, v10
    vf.mul       v10, v29, v14
    vf.add       v14, v16, v10
    v.ld.gather.h v10, [s9, v50]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v16, v13
    vf.cvt.f32.f16 v13, v14
    vf.mul       v14, v26, v16
    vf.add       v16, v15, v14
    v.ld.gather.h v14, [s9, v46]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v15, v10
    vf.cvt.f32.f16 v10, v16
    vf.mul       v16, v38, v15
    vf.add       v15, v22, v16
    vf.cvt.f16.f32 v16, v14
    v.st.h       [s13, #0], v12
    vf.cvt.f32.f16 v12, v15
    vf.mul       v14, v33, v16
    vf.add       v15, v17, v14
    vf.cvt.f32.f16 v14, v15
    v.st.h       [s13, #32], v19
    v.st.h       [s13, #64], v18
    v.st.h       [s13, #96], v9
    v.st.h       [s13, #128], v13
    v.st.h       [s13, #160], v10
    v.st.h       [s13, #192], v12
    v.st.h       [s13, #224], v14
    s.addi       s11, s11, #256
    s.cmp.lt     s12, s11, s2
    br.nz        s12, tiles_1
endtiles_2:
__rctx_next:
    s.addi       s1, s5, #4                      // the next program of this context: + 4
    s.cmp.lt     s11, s1, s6
    s.mov        s5, s1
    br.nz        s11, __rctx_program
    exit
