    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // out_ptr1: device_ptr64 at arg_base+32
    s.movz       s1, #1
    s.rdspecial  s8, arg_base
    s.ld.d       s9, [s8, #56]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s8, role_id
    s.movz       s10, #256
    s.mul        s11, s8, s10
    s.add        s8, s9, s11                     // this context's own scratch
    s.addi       s9, s8, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s8, #0
    s.st.d       [s9, #0], s5
    s.movz       s8, #64
    s.st.d       [s9, #8], s8
    s.movz       s8, #192
    s.st.d       [s9, #16], s8
    s.movz       s8, #384
    s.st.d       [s9, #48], s8
    s.movz       s8, #2
    s.st.d       [s9, #56], s8
    .li       s8, #68719476737
    s.st.d       [s9, #88], s8
    .li       s8, #8589934592
    s.st.d       [s9, #104], s8
    fence.release.device
    td.load      d0, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s8, #0
    s.movz       s9, #192
    s.movz       s10, #16
    v.splat      v0, s4
    v.iota       v0                              // arange(0, VLEN)
    s.shli       s11, s4, #3                     // element offset -> bytes (x8)
    s.add        s12, s2, s11                    // &in_ptr0[...]
    v.movi       v1, #0
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s1
    v.cmp.lt     p1, v2, v3
    v.movi       v2, #1
    v.shl        v3, v1, v2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s12, v3]              // index is in elements (ISA sec 9.1)
    s.addi       s1, s12, #4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v2, [s1, v3]               // index is in elements (ISA sec 9.1)
    s.addi       s1, s8, #0
    v.movi       v3, #0
    v.movi       v4, #0
    v.mov        v4, v3
for_1:
    s.cmp.ge     s2, s1, s9
    br.nz        s2, endfor_2
    v.splat      v3, s1
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s2, #192
    s.movz       s11, #64
    s.muli       s12, s4, #384
    v.add        v6, v3, v5
    v.movi       v3, #0
    v.splat      v5, s2
    v.splat      v7, s4
    v.movi       v8, #0
    v.splat      v9, s11
    s.muli       s2, s1, #2
    v.extract    s11, v2, #0
    v.extract    s13, v2, #0
    v.cmp.ge     p1, v6, v3
    v.cmp.lt     p2, v6, v5
    v.cmp.ge     p3, v7, v8
    v.cmp.lt     p4, v7, v9
    v.extract    s14, v1, #0
    s.shli       s15, s11, #32
    v.extract    s11, v1, #0
    s.shli       s16, s13, #32
    s.add        s13, s5, s12
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.or         s12, s14, s15
    s.movz       s14, #0
    s.or         s15, s11, s16
    s.movz       s11, #640
    s.add        s16, s13, s2
    p.and        p2, p5, p1
    v.movi       v3, #0
    v.movi       v5, #0
    s.cmp.ge     s2, s12, s14
    s.cmp.lt     s12, s15, s11
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v6, [s16, #0]
    v.insert     v3, s2, #0
    v.movi       v7, #0
    v.insert     v5, s12, #0
    v.movi       v8, #0
    v.cmp.ne     p1, v3, v7
    v.splat      v3, s1
    v.cmp.ne     p2, v5, v8
    v.movi       v5, #0
    p.and        p3, p1, p2
    v.add        v7, v3, v0
    v.movi       v3, #1
    v.movi       v8, #192
    @p3 v.sel        v9, v5, v3
    v.cmp.lt     p1, v7, v8
    s.movz       s2, #1
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v5, s2
    s.movz       s2, #0
    vf.cvt.f16.f32 v8, v6
    v.cmp.lt     p2, v3, v5
    @p2 v.reduce.or  s11, v9
    s.cmp.eq     s12, s11, s2
    br.nz        s12, assert_ok_3
    trap         #677351
assert_ok_3:
    v.extract    s2, v2, #0
    v.extract    s11, v1, #0
    s.shli       s12, s2, #32
    s.movz       s2, #192
    s.or         s13, s11, s12
    v.extract    s11, v7, #0
    s.mul        s12, s13, s2
    s.shli       s2, s11, #32
    v.extract    s11, v7, #1
    s.ashri      s13, s2, #32
    v.movi       v3, #0
    v.movi       v5, #0
    v.movi       v6, #0
    v.movi       v9, #0
    s.shli       s2, s11, #32
    s.lshri      s11, s12, #32
    s.lshri      s14, s13, #32
    v.extract    s15, v7, #2
    s.ashri      s16, s2, #32
    v.insert     v3, s12, #0
    v.insert     v5, s11, #0
    v.insert     v6, s13, #0
    v.insert     v9, s14, #0
    s.shli       s2, s15, #32
    s.lshri      s11, s16, #32
    v.extract    s12, v7, #3
    s.ashri      s13, s2, #32
    v.insert     v6, s16, #1
    v.insert     v9, s11, #1
    s.shli       s2, s12, #32
    s.lshri      s11, s13, #32
    v.extract    s12, v7, #4
    s.ashri      s14, s2, #32
    v.insert     v6, s13, #2
    v.insert     v9, s11, #2
    s.shli       s2, s12, #32
    s.lshri      s11, s14, #32
    v.extract    s12, v7, #5
    s.ashri      s13, s2, #32
    v.insert     v6, s14, #3
    v.insert     v9, s11, #3
    s.shli       s2, s12, #32
    s.lshri      s11, s13, #32
    v.extract    s12, v7, #6
    s.ashri      s14, s2, #32
    v.insert     v6, s13, #4
    v.insert     v9, s11, #4
    s.shli       s2, s12, #32
    s.lshri      s11, s14, #32
    v.extract    s12, v7, #7
    s.ashri      s13, s2, #32
    v.insert     v6, s14, #5
    v.insert     v9, s11, #5
    s.shli       s2, s12, #32
    s.lshri      s11, s13, #32
    v.extract    s12, v7, #8
    s.ashri      s14, s2, #32
    v.insert     v6, s13, #6
    v.insert     v9, s11, #6
    s.shli       s2, s12, #32
    s.lshri      s11, s14, #32
    v.extract    s12, v7, #9
    s.ashri      s13, s2, #32
    v.insert     v6, s14, #7
    v.insert     v9, s11, #7
    s.shli       s2, s12, #32
    s.lshri      s11, s13, #32
    v.extract    s12, v7, #10
    s.ashri      s14, s2, #32
    v.insert     v6, s13, #8
    v.insert     v9, s11, #8
    s.shli       s2, s12, #32
    s.lshri      s11, s14, #32
    v.extract    s12, v7, #11
    s.ashri      s13, s2, #32
    v.insert     v6, s14, #9
    v.insert     v9, s11, #9
    s.shli       s2, s12, #32
    s.lshri      s11, s13, #32
    v.extract    s12, v7, #12
    s.ashri      s14, s2, #32
    v.insert     v6, s13, #10
    v.insert     v9, s11, #10
    s.shli       s2, s12, #32
    s.lshri      s11, s14, #32
    v.extract    s12, v7, #13
    s.ashri      s13, s2, #32
    v.insert     v6, s14, #11
    v.insert     v9, s11, #11
    s.shli       s2, s12, #32
    s.lshri      s11, s13, #32
    v.extract    s12, v7, #14
    s.ashri      s14, s2, #32
    v.insert     v6, s13, #12
    v.insert     v9, s11, #12
    s.shli       s2, s12, #32
    s.lshri      s11, s14, #32
    v.extract    s12, v7, #15
    v.extract    s13, v5, #0
    s.ashri      s15, s2, #32
    v.insert     v6, s14, #13
    v.insert     v9, s11, #13
    s.shli       s2, s12, #32
    v.extract    s11, v3, #0
    s.shli       s12, s13, #32
    s.lshri      s13, s15, #32
    v.extract    s14, v5, #0
    s.ashri      s16, s2, #32
    s.or         s2, s11, s12
    v.insert     v6, s15, #14
    v.insert     v9, s13, #14
    v.movi       v7, #0
    v.movi       v10, #0
    v.extract    s11, v3, #0
    s.shli       s12, s14, #32
    s.lshri      s13, s16, #32
    s.lshri      s14, s2, #32
    v.extract    s15, v5, #0
    s.or         s17, s11, s12
    v.insert     v6, s16, #15
    v.insert     v9, s13, #15
    v.insert     v7, s2, #0
    v.insert     v10, s14, #0
    v.extract    s2, v3, #0
    s.shli       s11, s15, #32
    s.lshri      s12, s17, #32
    v.extract    s13, v5, #0
    s.or         s14, s2, s11
    v.insert     v7, s17, #1
    v.insert     v10, s12, #1
    v.extract    s2, v3, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v5, #0
    s.or         s15, s2, s11
    v.insert     v7, s14, #2
    v.insert     v10, s12, #2
    v.extract    s2, v3, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v5, #0
    s.or         s14, s2, s11
    v.insert     v7, s15, #3
    v.insert     v10, s12, #3
    v.extract    s2, v3, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v5, #0
    s.or         s15, s2, s11
    v.insert     v7, s14, #4
    v.insert     v10, s12, #4
    v.extract    s2, v3, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v5, #0
    s.or         s14, s2, s11
    v.insert     v7, s15, #5
    v.insert     v10, s12, #5
    v.extract    s2, v3, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v5, #0
    s.or         s15, s2, s11
    v.insert     v7, s14, #6
    v.insert     v10, s12, #6
    v.extract    s2, v3, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v5, #0
    s.or         s14, s2, s11
    v.insert     v7, s15, #7
    v.insert     v10, s12, #7
    v.extract    s2, v3, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v5, #0
    s.or         s15, s2, s11
    v.insert     v7, s14, #8
    v.insert     v10, s12, #8
    v.extract    s2, v3, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v5, #0
    s.or         s14, s2, s11
    v.insert     v7, s15, #9
    v.insert     v10, s12, #9
    v.extract    s2, v3, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v5, #0
    s.or         s15, s2, s11
    v.insert     v7, s14, #10
    v.insert     v10, s12, #10
    v.extract    s2, v3, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v5, #0
    s.or         s14, s2, s11
    v.insert     v7, s15, #11
    v.insert     v10, s12, #11
    v.extract    s2, v3, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v5, #0
    s.or         s15, s2, s11
    v.insert     v7, s14, #12
    v.insert     v10, s12, #12
    v.extract    s2, v3, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v5, #0
    s.or         s14, s2, s11
    v.insert     v7, s15, #13
    v.insert     v10, s12, #13
    v.extract    s2, v3, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    s.or         s13, s2, s11
    v.insert     v7, s14, #14
    v.insert     v10, s12, #14
    s.lshri      s2, s13, #32
    v.insert     v7, s13, #15
    v.insert     v10, s2, #15
    v.extract    s2, v9, #0
    v.extract    s11, v6, #0
    v.extract    s12, v10, #0
    s.shli       s13, s2, #32
    v.extract    s2, v7, #0
    s.shli       s14, s12, #32
    v.extract    s12, v9, #1
    v.extract    s15, v10, #1
    s.or         s16, s11, s13
    s.or         s11, s2, s14
    v.movi       v3, #0
    v.extract    s2, v6, #1
    s.shli       s13, s12, #32
    v.extract    s12, v7, #1
    s.shli       s14, s15, #32
    s.add        s15, s16, s11
    v.extract    s11, v9, #2
    v.extract    s16, v10, #2
    s.or         s17, s2, s13
    s.or         s2, s12, s14
    v.movi       v5, #0
    v.insert     v3, s15, #0
    v.extract    s12, v6, #2
    s.shli       s13, s11, #32
    v.extract    s11, v7, #2
    s.shli       s14, s16, #32
    s.lshri      s16, s15, #32
    s.add        s15, s17, s2
    v.extract    s2, v9, #3
    s.or         s17, s12, s13
    v.extract    s12, v10, #3
    s.or         s13, s11, s14
    v.insert     v5, s16, #0
    v.insert     v3, s15, #1
    v.extract    s11, v6, #3
    s.shli       s14, s2, #32
    v.extract    s2, v7, #3
    s.shli       s16, s12, #32
    s.lshri      s12, s15, #32
    s.add        s15, s17, s13
    v.extract    s13, v9, #4
    s.or         s17, s11, s14
    v.extract    s11, v10, #4
    s.or         s14, s2, s16
    v.insert     v5, s12, #1
    v.insert     v3, s15, #2
    v.extract    s2, v6, #4
    s.shli       s12, s13, #32
    v.extract    s13, v7, #4
    s.shli       s16, s11, #32
    s.lshri      s11, s15, #32
    s.add        s15, s17, s14
    v.extract    s14, v9, #5
    s.or         s17, s2, s12
    v.extract    s2, v10, #5
    s.or         s12, s13, s16
    v.insert     v5, s11, #2
    v.insert     v3, s15, #3
    v.extract    s11, v6, #5
    s.shli       s13, s14, #32
    v.extract    s14, v7, #5
    s.shli       s16, s2, #32
    s.lshri      s2, s15, #32
    s.add        s15, s17, s12
    v.extract    s12, v9, #6
    s.or         s17, s11, s13
    v.extract    s11, v10, #6
    s.or         s13, s14, s16
    v.insert     v5, s2, #3
    v.insert     v3, s15, #4
    v.extract    s2, v6, #6
    s.shli       s14, s12, #32
    v.extract    s12, v7, #6
    s.shli       s16, s11, #32
    s.lshri      s11, s15, #32
    s.add        s15, s17, s13
    v.extract    s13, v9, #7
    s.or         s17, s2, s14
    v.extract    s2, v10, #7
    s.or         s14, s12, s16
    v.insert     v5, s11, #4
    v.insert     v3, s15, #5
    v.extract    s11, v6, #7
    s.shli       s12, s13, #32
    v.extract    s13, v7, #7
    s.shli       s16, s2, #32
    s.lshri      s2, s15, #32
    s.add        s15, s17, s14
    v.extract    s14, v9, #8
    s.or         s17, s11, s12
    v.extract    s11, v10, #8
    s.or         s12, s13, s16
    v.insert     v5, s2, #5
    v.insert     v3, s15, #6
    v.extract    s2, v6, #8
    s.shli       s13, s14, #32
    v.extract    s14, v7, #8
    s.shli       s16, s11, #32
    s.lshri      s11, s15, #32
    s.add        s15, s17, s12
    v.extract    s12, v9, #9
    s.or         s17, s2, s13
    v.extract    s2, v10, #9
    s.or         s13, s14, s16
    v.insert     v5, s11, #6
    v.insert     v3, s15, #7
    v.extract    s11, v6, #9
    s.shli       s14, s12, #32
    v.extract    s12, v7, #9
    s.shli       s16, s2, #32
    s.lshri      s2, s15, #32
    s.add        s15, s17, s13
    v.extract    s13, v9, #10
    s.or         s17, s11, s14
    v.extract    s11, v10, #10
    s.or         s14, s12, s16
    v.insert     v5, s2, #7
    v.insert     v3, s15, #8
    v.extract    s2, v6, #10
    s.shli       s12, s13, #32
    v.extract    s13, v7, #10
    s.shli       s16, s11, #32
    s.lshri      s11, s15, #32
    s.add        s15, s17, s14
    v.extract    s14, v9, #11
    s.or         s17, s2, s12
    v.extract    s2, v10, #11
    s.or         s12, s13, s16
    v.insert     v5, s11, #8
    v.insert     v3, s15, #9
    v.extract    s11, v6, #11
    s.shli       s13, s14, #32
    v.extract    s14, v7, #11
    s.shli       s16, s2, #32
    s.lshri      s2, s15, #32
    s.add        s15, s17, s12
    v.extract    s12, v9, #12
    s.or         s17, s11, s13
    v.extract    s11, v10, #12
    s.or         s13, s14, s16
    v.insert     v5, s2, #9
    v.insert     v3, s15, #10
    v.extract    s2, v6, #12
    s.shli       s14, s12, #32
    v.extract    s12, v7, #12
    s.shli       s16, s11, #32
    s.lshri      s11, s15, #32
    s.add        s15, s17, s13
    v.extract    s13, v9, #13
    s.or         s17, s2, s14
    v.extract    s2, v10, #13
    s.or         s14, s12, s16
    v.insert     v5, s11, #10
    v.insert     v3, s15, #11
    v.extract    s11, v6, #13
    s.shli       s12, s13, #32
    v.extract    s13, v7, #13
    s.shli       s16, s2, #32
    s.lshri      s2, s15, #32
    s.add        s15, s17, s14
    v.extract    s14, v9, #14
    s.or         s17, s11, s12
    v.extract    s11, v10, #14
    s.or         s12, s13, s16
    v.insert     v5, s2, #11
    v.insert     v3, s15, #12
    v.extract    s2, v6, #14
    s.shli       s13, s14, #32
    v.extract    s14, v7, #14
    s.shli       s16, s11, #32
    s.lshri      s11, s15, #32
    s.add        s15, s17, s12
    v.extract    s12, v9, #15
    s.or         s17, s2, s13
    v.extract    s2, v10, #15
    s.or         s13, s14, s16
    v.insert     v5, s11, #12
    v.insert     v3, s15, #13
    v.extract    s11, v6, #15
    s.shli       s14, s12, #32
    v.extract    s12, v7, #15
    s.shli       s16, s2, #32
    s.lshri      s2, s15, #32
    s.add        s15, s17, s13
    s.or         s13, s11, s14
    s.or         s11, s12, s16
    v.insert     v5, s2, #13
    v.insert     v3, s15, #14
    s.lshri      s2, s15, #32
    s.add        s12, s13, s11
    v.insert     v5, s2, #14
    v.insert     v3, s12, #15
    v.movi       v6, #31
    s.lshri      s2, s12, #32
    v.movi       v7, #1
    v.insert     v5, s2, #15
    v.ashr       v9, v3, v6
    v.movi       v6, #0
    s.movz       s2, #0
    v.cmp.ne     p2, v5, v9
    @p2 v.sel        v5, v7, v6
    v.reduce.or  s11, v5
    s.cmp.eq     s12, s11, s2
    br.nz        s12, narrow_ok_4
    trap         #677220
narrow_ok_4:
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v5, [s3, v3]               // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    s.add        s2, s1, s10
    s.movz       s11, #1
    vf.cvt.f16.f32 v6, v5
    vf.add       v5, v6, v8
    vf.mul       v6, v5, v5
    vf.add       v5, v4, v6
    @p1 v.sel        v6, v5, v4
    v.mov        v3, v6
    v.mov        v4, v3
    s.mov        s1, s2
    br.nz        s11, for_1
endfor_2:
    vf.reduce.add.b v3, v4
    v.movi       v4, #0
    s.addi       s1, s8, #0
    vf.add       v5, v3, v4
for_5:
    s.cmp.ge     s2, s1, s9
    br.nz        s2, endfor_6
    v.splat      v3, s1
    v.iota       v4                              // arange(0, VLEN)
    s.movz       s2, #192
    s.movz       s8, #64
    s.muli       s11, s4, #384
    v.add        v6, v3, v4
    v.movi       v3, #0
    v.splat      v4, s2
    v.splat      v7, s4
    v.movi       v8, #0
    v.splat      v9, s8
    v.splat      v10, s1
    s.muli       s2, s1, #2
    v.extract    s8, v2, #0
    v.extract    s12, v2, #0
    v.cmp.ge     p1, v6, v3
    v.cmp.lt     p2, v6, v4
    v.cmp.ge     p3, v7, v8
    v.cmp.lt     p4, v7, v9
    v.extract    s13, v1, #0
    s.shli       s14, s8, #32
    v.extract    s8, v1, #0
    s.shli       s15, s12, #32
    v.add        v3, v10, v0
    v.movi       v4, #192
    s.add        s12, s5, s11
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.or         s11, s13, s14
    s.shli       s13, s1, #1                     // element offset -> bytes (x2)
    s.or         s14, s8, s15
    s.movz       s8, #0
    s.add        s15, s12, s2
    s.movz       s2, #640
    p.and        p2, p5, p1
    s.add        s12, s6, s13                    // &in_ptr3[...]
    v.movi       v6, #0
    v.movi       v7, #0
    v.cmp.lt     p1, v3, v4
    s.cmp.ge     s13, s11, s8
    s.cmp.lt     s8, s14, s2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s15, #0]
    v.movi       v8, #0
    v.movi       v9, #0
    v.movi       v10, #0
    v.movi       v11, #1
    s.movz       s2, #1
    v.iota       v12                             // arange(0, VLEN)
    v.splat      v13, s2
    s.movz       s2, #0
    v.cmp.lt     p2, v12, v13
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s12, #0]
    v.insert     v6, s13, #0
    v.insert     v7, s8, #0
    vf.cvt.f16.f32 v13, v4
    v.cmp.ne     p3, v6, v8
    v.cmp.ne     p4, v7, v9
    p.and        p5, p3, p4
    @p5 v.sel        v4, v10, v11
    @p2 v.reduce.or  s8, v4
    s.cmp.eq     s11, s8, s2
    vf.cvt.f16.f32 v4, v12
    br.nz        s11, assert_ok_7
    trap         #677351
assert_ok_7:
    v.extract    s2, v2, #0
    v.extract    s8, v1, #0
    s.shli       s11, s2, #32
    s.movz       s2, #192
    s.or         s12, s8, s11
    v.extract    s8, v3, #0
    s.mul        s11, s12, s2
    s.shli       s2, s8, #32
    v.extract    s8, v3, #1
    s.ashri      s12, s2, #32
    v.movi       v6, #0
    v.movi       v7, #0
    v.movi       v8, #0
    v.movi       v9, #0
    s.shli       s2, s8, #32
    s.lshri      s8, s11, #32
    s.lshri      s13, s12, #32
    v.extract    s14, v3, #2
    s.ashri      s15, s2, #32
    v.insert     v6, s11, #0
    v.insert     v7, s8, #0
    v.insert     v8, s12, #0
    v.insert     v9, s13, #0
    s.shli       s2, s14, #32
    s.lshri      s8, s15, #32
    v.extract    s11, v3, #3
    s.ashri      s12, s2, #32
    v.insert     v8, s15, #1
    v.insert     v9, s8, #1
    s.shli       s2, s11, #32
    s.lshri      s8, s12, #32
    v.extract    s11, v3, #4
    s.ashri      s13, s2, #32
    v.insert     v8, s12, #2
    v.insert     v9, s8, #2
    s.shli       s2, s11, #32
    s.lshri      s8, s13, #32
    v.extract    s11, v3, #5
    s.ashri      s12, s2, #32
    v.insert     v8, s13, #3
    v.insert     v9, s8, #3
    s.shli       s2, s11, #32
    s.lshri      s8, s12, #32
    v.extract    s11, v3, #6
    s.ashri      s13, s2, #32
    v.insert     v8, s12, #4
    v.insert     v9, s8, #4
    s.shli       s2, s11, #32
    s.lshri      s8, s13, #32
    v.extract    s11, v3, #7
    s.ashri      s12, s2, #32
    v.insert     v8, s13, #5
    v.insert     v9, s8, #5
    s.shli       s2, s11, #32
    s.lshri      s8, s12, #32
    v.extract    s11, v3, #8
    s.ashri      s13, s2, #32
    v.insert     v8, s12, #6
    v.insert     v9, s8, #6
    s.shli       s2, s11, #32
    s.lshri      s8, s13, #32
    v.extract    s11, v3, #9
    s.ashri      s12, s2, #32
    v.insert     v8, s13, #7
    v.insert     v9, s8, #7
    s.shli       s2, s11, #32
    s.lshri      s8, s12, #32
    v.extract    s11, v3, #10
    s.ashri      s13, s2, #32
    v.insert     v8, s12, #8
    v.insert     v9, s8, #8
    s.shli       s2, s11, #32
    s.lshri      s8, s13, #32
    v.extract    s11, v3, #11
    s.ashri      s12, s2, #32
    v.insert     v8, s13, #9
    v.insert     v9, s8, #9
    s.shli       s2, s11, #32
    s.lshri      s8, s12, #32
    v.extract    s11, v3, #12
    s.ashri      s13, s2, #32
    v.insert     v8, s12, #10
    v.insert     v9, s8, #10
    s.shli       s2, s11, #32
    s.lshri      s8, s13, #32
    v.extract    s11, v3, #13
    s.ashri      s12, s2, #32
    v.insert     v8, s13, #11
    v.insert     v9, s8, #11
    s.shli       s2, s11, #32
    s.lshri      s8, s12, #32
    v.extract    s11, v3, #14
    s.ashri      s13, s2, #32
    v.insert     v8, s12, #12
    v.insert     v9, s8, #12
    s.shli       s2, s11, #32
    s.lshri      s8, s13, #32
    v.extract    s11, v3, #15
    v.extract    s12, v7, #0
    s.ashri      s14, s2, #32
    v.insert     v8, s13, #13
    v.insert     v9, s8, #13
    s.shli       s2, s11, #32
    v.extract    s8, v6, #0
    s.shli       s11, s12, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v7, #0
    s.ashri      s15, s2, #32
    s.or         s2, s8, s11
    v.insert     v8, s14, #14
    v.insert     v9, s12, #14
    v.movi       v10, #0
    v.movi       v11, #0
    v.extract    s8, v6, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    s.lshri      s13, s2, #32
    v.extract    s14, v7, #0
    s.or         s16, s8, s11
    v.insert     v8, s15, #15
    v.insert     v9, s12, #15
    v.insert     v10, s2, #0
    v.insert     v11, s13, #0
    v.extract    s2, v6, #0
    s.shli       s8, s14, #32
    s.lshri      s11, s16, #32
    v.extract    s12, v7, #0
    s.or         s13, s2, s8
    v.insert     v10, s16, #1
    v.insert     v11, s11, #1
    v.extract    s2, v6, #0
    s.shli       s8, s12, #32
    s.lshri      s11, s13, #32
    v.extract    s12, v7, #0
    s.or         s14, s2, s8
    v.insert     v10, s13, #2
    v.insert     v11, s11, #2
    v.extract    s2, v6, #0
    s.shli       s8, s12, #32
    s.lshri      s11, s14, #32
    v.extract    s12, v7, #0
    s.or         s13, s2, s8
    v.insert     v10, s14, #3
    v.insert     v11, s11, #3
    v.extract    s2, v6, #0
    s.shli       s8, s12, #32
    s.lshri      s11, s13, #32
    v.extract    s12, v7, #0
    s.or         s14, s2, s8
    v.insert     v10, s13, #4
    v.insert     v11, s11, #4
    v.extract    s2, v6, #0
    s.shli       s8, s12, #32
    s.lshri      s11, s14, #32
    v.extract    s12, v7, #0
    s.or         s13, s2, s8
    v.insert     v10, s14, #5
    v.insert     v11, s11, #5
    v.extract    s2, v6, #0
    s.shli       s8, s12, #32
    s.lshri      s11, s13, #32
    v.extract    s12, v7, #0
    s.or         s14, s2, s8
    v.insert     v10, s13, #6
    v.insert     v11, s11, #6
    v.extract    s2, v6, #0
    s.shli       s8, s12, #32
    s.lshri      s11, s14, #32
    v.extract    s12, v7, #0
    s.or         s13, s2, s8
    v.insert     v10, s14, #7
    v.insert     v11, s11, #7
    v.extract    s2, v6, #0
    s.shli       s8, s12, #32
    s.lshri      s11, s13, #32
    v.extract    s12, v7, #0
    s.or         s14, s2, s8
    v.insert     v10, s13, #8
    v.insert     v11, s11, #8
    v.extract    s2, v6, #0
    s.shli       s8, s12, #32
    s.lshri      s11, s14, #32
    v.extract    s12, v7, #0
    s.or         s13, s2, s8
    v.insert     v10, s14, #9
    v.insert     v11, s11, #9
    v.extract    s2, v6, #0
    s.shli       s8, s12, #32
    s.lshri      s11, s13, #32
    v.extract    s12, v7, #0
    s.or         s14, s2, s8
    v.insert     v10, s13, #10
    v.insert     v11, s11, #10
    v.extract    s2, v6, #0
    s.shli       s8, s12, #32
    s.lshri      s11, s14, #32
    v.extract    s12, v7, #0
    s.or         s13, s2, s8
    v.insert     v10, s14, #11
    v.insert     v11, s11, #11
    v.extract    s2, v6, #0
    s.shli       s8, s12, #32
    s.lshri      s11, s13, #32
    v.extract    s12, v7, #0
    s.or         s14, s2, s8
    v.insert     v10, s13, #12
    v.insert     v11, s11, #12
    v.extract    s2, v6, #0
    s.shli       s8, s12, #32
    s.lshri      s11, s14, #32
    v.extract    s12, v7, #0
    s.or         s13, s2, s8
    v.insert     v10, s14, #13
    v.insert     v11, s11, #13
    v.extract    s2, v6, #0
    s.shli       s8, s12, #32
    s.lshri      s11, s13, #32
    s.or         s12, s2, s8
    v.insert     v10, s13, #14
    v.insert     v11, s11, #14
    s.lshri      s2, s12, #32
    v.insert     v10, s12, #15
    v.insert     v11, s2, #15
    v.extract    s2, v9, #0
    v.extract    s8, v8, #0
    v.extract    s11, v11, #0
    s.shli       s12, s2, #32
    v.extract    s2, v10, #0
    s.shli       s13, s11, #32
    v.extract    s11, v9, #1
    v.extract    s14, v11, #1
    s.or         s15, s8, s12
    s.or         s8, s2, s13
    v.movi       v6, #0
    v.extract    s2, v8, #1
    s.shli       s12, s11, #32
    v.extract    s11, v10, #1
    s.shli       s13, s14, #32
    s.add        s14, s15, s8
    v.extract    s8, v9, #2
    v.extract    s15, v11, #2
    s.or         s16, s2, s12
    s.or         s2, s11, s13
    v.movi       v7, #0
    v.insert     v6, s14, #0
    v.extract    s11, v8, #2
    s.shli       s12, s8, #32
    v.extract    s8, v10, #2
    s.shli       s13, s15, #32
    s.lshri      s15, s14, #32
    s.add        s14, s16, s2
    v.extract    s2, v9, #3
    s.or         s16, s11, s12
    v.extract    s11, v11, #3
    s.or         s12, s8, s13
    v.insert     v7, s15, #0
    v.insert     v6, s14, #1
    v.extract    s8, v8, #3
    s.shli       s13, s2, #32
    v.extract    s2, v10, #3
    s.shli       s15, s11, #32
    s.lshri      s11, s14, #32
    s.add        s14, s16, s12
    v.extract    s12, v9, #4
    s.or         s16, s8, s13
    v.extract    s8, v11, #4
    s.or         s13, s2, s15
    v.insert     v7, s11, #1
    v.insert     v6, s14, #2
    v.extract    s2, v8, #4
    s.shli       s11, s12, #32
    v.extract    s12, v10, #4
    s.shli       s15, s8, #32
    s.lshri      s8, s14, #32
    s.add        s14, s16, s13
    v.extract    s13, v9, #5
    s.or         s16, s2, s11
    v.extract    s2, v11, #5
    s.or         s11, s12, s15
    v.insert     v7, s8, #2
    v.insert     v6, s14, #3
    v.extract    s8, v8, #5
    s.shli       s12, s13, #32
    v.extract    s13, v10, #5
    s.shli       s15, s2, #32
    s.lshri      s2, s14, #32
    s.add        s14, s16, s11
    v.extract    s11, v9, #6
    s.or         s16, s8, s12
    v.extract    s8, v11, #6
    s.or         s12, s13, s15
    v.insert     v7, s2, #3
    v.insert     v6, s14, #4
    v.extract    s2, v8, #6
    s.shli       s13, s11, #32
    v.extract    s11, v10, #6
    s.shli       s15, s8, #32
    s.lshri      s8, s14, #32
    s.add        s14, s16, s12
    v.extract    s12, v9, #7
    s.or         s16, s2, s13
    v.extract    s2, v11, #7
    s.or         s13, s11, s15
    v.insert     v7, s8, #4
    v.insert     v6, s14, #5
    v.extract    s8, v8, #7
    s.shli       s11, s12, #32
    v.extract    s12, v10, #7
    s.shli       s15, s2, #32
    s.lshri      s2, s14, #32
    s.add        s14, s16, s13
    v.extract    s13, v9, #8
    s.or         s16, s8, s11
    v.extract    s8, v11, #8
    s.or         s11, s12, s15
    v.insert     v7, s2, #5
    v.insert     v6, s14, #6
    v.extract    s2, v8, #8
    s.shli       s12, s13, #32
    v.extract    s13, v10, #8
    s.shli       s15, s8, #32
    s.lshri      s8, s14, #32
    s.add        s14, s16, s11
    v.extract    s11, v9, #9
    s.or         s16, s2, s12
    v.extract    s2, v11, #9
    s.or         s12, s13, s15
    v.insert     v7, s8, #6
    v.insert     v6, s14, #7
    v.extract    s8, v8, #9
    s.shli       s13, s11, #32
    v.extract    s11, v10, #9
    s.shli       s15, s2, #32
    s.lshri      s2, s14, #32
    s.add        s14, s16, s12
    v.extract    s12, v9, #10
    s.or         s16, s8, s13
    v.extract    s8, v11, #10
    s.or         s13, s11, s15
    v.insert     v7, s2, #7
    v.insert     v6, s14, #8
    v.extract    s2, v8, #10
    s.shli       s11, s12, #32
    v.extract    s12, v10, #10
    s.shli       s15, s8, #32
    s.lshri      s8, s14, #32
    s.add        s14, s16, s13
    v.extract    s13, v9, #11
    s.or         s16, s2, s11
    v.extract    s2, v11, #11
    s.or         s11, s12, s15
    v.insert     v7, s8, #8
    v.insert     v6, s14, #9
    v.extract    s8, v8, #11
    s.shli       s12, s13, #32
    v.extract    s13, v10, #11
    s.shli       s15, s2, #32
    s.lshri      s2, s14, #32
    s.add        s14, s16, s11
    v.extract    s11, v9, #12
    s.or         s16, s8, s12
    v.extract    s8, v11, #12
    s.or         s12, s13, s15
    v.insert     v7, s2, #9
    v.insert     v6, s14, #10
    v.extract    s2, v8, #12
    s.shli       s13, s11, #32
    v.extract    s11, v10, #12
    s.shli       s15, s8, #32
    s.lshri      s8, s14, #32
    s.add        s14, s16, s12
    v.extract    s12, v9, #13
    s.or         s16, s2, s13
    v.extract    s2, v11, #13
    s.or         s13, s11, s15
    v.insert     v7, s8, #10
    v.insert     v6, s14, #11
    v.extract    s8, v8, #13
    s.shli       s11, s12, #32
    v.extract    s12, v10, #13
    s.shli       s15, s2, #32
    s.lshri      s2, s14, #32
    s.add        s14, s16, s13
    v.extract    s13, v9, #14
    s.or         s16, s8, s11
    v.extract    s8, v11, #14
    s.or         s11, s12, s15
    v.insert     v7, s2, #11
    v.insert     v6, s14, #12
    v.extract    s2, v8, #14
    s.shli       s12, s13, #32
    v.extract    s13, v10, #14
    s.shli       s15, s8, #32
    s.lshri      s8, s14, #32
    s.add        s14, s16, s11
    v.extract    s11, v9, #15
    s.or         s16, s2, s12
    v.extract    s2, v11, #15
    s.or         s12, s13, s15
    v.insert     v7, s8, #12
    v.insert     v6, s14, #13
    v.extract    s8, v8, #15
    s.shli       s13, s11, #32
    v.extract    s11, v10, #15
    s.shli       s15, s2, #32
    s.lshri      s2, s14, #32
    s.add        s14, s16, s12
    s.or         s12, s8, s13
    s.or         s8, s11, s15
    v.insert     v7, s2, #13
    v.insert     v6, s14, #14
    s.lshri      s2, s14, #32
    s.add        s11, s12, s8
    v.insert     v7, s2, #14
    v.insert     v6, s11, #15
    v.movi       v8, #31
    s.lshri      s2, s11, #32
    v.movi       v9, #1
    v.insert     v7, s2, #15
    v.ashr       v10, v6, v8
    v.movi       v8, #0
    s.movz       s2, #0
    v.cmp.ne     p2, v7, v10
    @p2 v.sel        v7, v9, v8
    v.reduce.or  s8, v7
    s.cmp.eq     s11, s8, s2
    br.nz        s11, narrow_ok_8
    trap         #677220
narrow_ok_8:
    .li       s2, #1128267776
    v.splat      v7, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1065353216
    v.splat      v8, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #925353388
    v.splat      v9, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v10, v7                         // ISA 8.8: <= 2**-22 relative
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v11, [s3, v6]              // index is in elements (ISA sec 9.1)
    .li       s2, #1077936128
    v.splat      v6, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #3204448256
    v.splat      v12, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.mul        s2, s4, s9
    s.add        s8, s1, s10
    s.movz       s11, #1
    s.add        s12, s1, s2
    s.shli       s13, s12, #1                    // element offset -> bytes (x2)
    s.add        s12, s7, s13                    // &out_ptr1[...]
    vf.cvt.f16.f32 v14, v11
    vf.add       v11, v14, v13
    v.splat      v13, s2
    v.add        v14, v3, v13
    vf.fms       v3, v7, v10, v8
    vf.fms       v7, v10, v3, v10
    vf.neg       v3, v7                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v3, v3
    @p2 v.sel        v7, v3, v10
    vf.mul       v3, v5, v7                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v7, v3, v9
    v.rsqrt.approx v3, v7                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v8, v3, v3
    vf.mul       v9, v3, v12
    vf.fms       v10, v7, v8, v6
    vf.mul       v6, v9, v10                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v6, v6
    @p2 v.sel        v7, v6, v3
    v.extract    s2, v7, #0
    v.splat      v3, s2
    vf.mul       v6, v11, v3
    vf.mul       v3, v6, v4
    vf.cvt.f32.f16 v4, v3
    @p1 v.st.h       [s12, #0], v4
    s.mov        s1, s8
    br.nz        s11, for_5
endfor_6:
__rctx_next:
    exit
