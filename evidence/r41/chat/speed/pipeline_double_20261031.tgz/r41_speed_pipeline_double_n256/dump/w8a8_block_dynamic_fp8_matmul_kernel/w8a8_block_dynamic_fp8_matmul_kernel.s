    s.rdspecial  s1, arg_base
    s.movz       s2, #127
    s.ld.sw      s3, [s1, #32]                   // N: i32 at arg_base+32
    s.movz       s4, #0
    s.movz       s5, #128
    s.rdspecial  s6, pid.x
    s.cmp.lt     s7, s5, s4
    s.movz       s8, #8
    s.sub        s9, s4, s7
    s.rdspecial  s7, pid.y
    s.movz       s10, #1
    s.xor        s11, s5, s9
    s.addi       s12, s4, #0
    s.add        s13, s3, s2
    s.ld.d       s14, [s1, #0]                   // A: device_ptr64 at arg_base+0
    s.cmp.lt     s15, s13, s4
    s.sub        s16, s11, s9
    s.sub        s11, s4, s15
    s.addi       s15, s4, #0
    s.xor        s16, s13, s11
    s.xor        s13, s11, s9
    s.sub        s9, s16, s11
    s.lshri      s11, s9, #7
    s.xor        s16, s11, s13
    s.muli       s17, s11, #128
    s.sub        s11, s16, s13
    s.ld.d       s13, [s1, #8]                   // B: device_ptr64 at arg_base+8
    s.mul        s16, s6, s11
    s.mul        s6, s11, s8
    s.sub        s11, s9, s17
    s.add        s9, s16, s7
    s.cmp.lt     s7, s6, s4
    s.cmp.lt     s11, s9, s4
    s.sub        s16, s4, s7
    s.sub        s7, s4, s11
    s.xor        s11, s6, s16
    s.xor        s17, s9, s7
    s.sub        s18, s11, s16
    s.sub        s11, s17, s7
    s.cmp.eq     s17, s18, s10
    s.ld.d       s19, [s1, #16]                  // C: device_ptr64 at arg_base+16
    s.ld.d       s20, [s1, #24]                  // Bs: device_ptr64 at arg_base+24
    s.ld.sw      s21, [s1, #40]                  // K: i32 at arg_base+40
    s.ld.sw      s22, [s1, #56]                  // stride_bn: i32 at arg_base+56
    s.ld.sw      s23, [s1, #64]                  // stride_cm: i32 at arg_base+64
    s.ld.sw      s24, [s1, #72]                  // stride_bs_n: i32 at arg_base+72
    s.mov        s12, s11
    br.nz        s17, sdiv_done_1
    s.movz       s1, #0
    s.movz       s17, #31
    s.mov        s12, s1
    s.addi       s1, s17, #0
sdiv_2:
    s.lshr       s17, s11, s1
    s.shli       s25, s15, #1
    s.andi       s26, s17, #1
    s.shl        s17, s10, s1
    s.or         s27, s25, s26
    s.subi       s25, s1, #1
    s.cmp.geu    s26, s27, s18
    s.sub        s28, s4, s26
    s.and        s26, s18, s28
    s.and        s29, s17, s28
    s.sub        s17, s27, s26
    s.or         s26, s12, s29
    s.mov        s15, s17
    s.mov        s12, s26
    s.mov        s1, s25
    s.cmp.ge     s17, s1, s4
    br.nz        s17, sdiv_2
sdiv_done_1:
    s.xor        s1, s7, s16
    s.movz       s4, #0
    s.xor        s7, s12, s1
    s.cmp.lt     s11, s6, s4
    s.sub        s12, s7, s1
    s.cmp.lt     s1, s9, s4
    s.sub        s7, s4, s11
    s.mul        s11, s12, s8
    s.sub        s12, s4, s1
    s.xor        s1, s6, s7
    s.xor        s6, s9, s12
    s.sub        s9, s1, s7
    s.sub        s1, s10, s11
    s.sub        s7, s6, s12
    s.addi       s6, s4, #0
    s.cmp.eq     s15, s9, s10
    s.min.s      s16, s1, s8
    s.addi       s1, s4, #0
    s.mov        s6, s7
    br.nz        s15, sdiv_done_3
    s.movz       s8, #0
    s.movz       s15, #31
    s.mov        s6, s8
    s.addi       s8, s15, #0
sdiv_4:
    s.lshr       s15, s7, s8
    s.shli       s17, s1, #1
    s.andi       s18, s15, #1
    s.movz       s15, #1
    s.or         s25, s17, s18
    s.shl        s17, s15, s8
    s.cmp.geu    s15, s25, s9
    s.subi       s18, s8, #1
    s.sub        s26, s4, s15
    s.and        s15, s9, s26
    s.and        s27, s17, s26
    s.sub        s17, s25, s15
    s.or         s15, s6, s27
    s.mov        s1, s17
    s.mov        s6, s15
    s.mov        s8, s18
    s.cmp.ge     s15, s8, s4
    br.nz        s15, sdiv_4
sdiv_done_3:
    s.xor        s6, s1, s12
    s.cmp.lt     s1, s16, s4
    s.sub        s7, s6, s12
    s.sub        s6, s4, s1
    s.cmp.lt     s1, s7, s4
    s.xor        s8, s16, s6
    s.sub        s9, s4, s1
    s.sub        s1, s8, s6
    s.xor        s6, s7, s9
    s.movz       s8, #1
    s.sub        s12, s6, s9
    s.addi       s6, s4, #0
    s.cmp.eq     s15, s1, s8
    s.addi       s17, s4, #0
    s.mov        s6, s12
    br.nz        s15, sdiv_done_5
    s.movz       s4, #0
    s.movz       s15, #31
    s.mov        s6, s4
    s.addi       s4, s15, #0
sdiv_6:
    s.lshr       s15, s12, s4
    s.shli       s18, s17, #1
    s.andi       s25, s15, #1
    s.movz       s15, #0
    s.or         s26, s18, s25
    s.shl        s18, s8, s4
    s.cmp.geu    s25, s26, s1
    s.subi       s27, s4, #1
    s.sub        s28, s15, s25
    s.and        s25, s1, s28
    s.and        s29, s18, s28
    s.sub        s18, s26, s25
    s.or         s25, s6, s29
    s.mov        s17, s18
    s.mov        s6, s25
    s.mov        s4, s27
    s.cmp.ge     s18, s4, s15
    br.nz        s18, sdiv_6
sdiv_done_5:
    s.movz       s1, #0
    s.xor        s4, s17, s9
    s.cmp.lt     s6, s16, s1
    s.cmp.lt     s12, s7, s1
    s.sub        s15, s1, s6
    s.sub        s6, s1, s12
    s.xor        s12, s16, s15
    s.xor        s16, s7, s6
    s.sub        s7, s12, s15
    s.sub        s12, s4, s9
    s.sub        s4, s16, s6
    s.addi       s9, s1, #0
    s.cmp.eq     s16, s7, s8
    s.add        s8, s11, s12
    s.addi       s11, s1, #0
    s.mov        s9, s4
    br.nz        s16, sdiv_done_7
    s.movz       s12, #0
    s.movz       s16, #31
    s.mov        s9, s12
    s.addi       s12, s16, #0
sdiv_8:
    s.lshr       s16, s4, s12
    s.shli       s17, s11, #1
    s.andi       s18, s16, #1
    s.movz       s16, #1
    s.or         s25, s17, s18
    s.shl        s17, s16, s12
    s.cmp.geu    s16, s25, s7
    s.subi       s18, s12, #1
    s.sub        s26, s1, s16
    s.and        s16, s7, s26
    s.and        s27, s17, s26
    s.sub        s17, s25, s16
    s.or         s16, s9, s27
    s.mov        s11, s17
    s.mov        s9, s16
    s.mov        s12, s18
    s.cmp.ge     s16, s12, s1
    br.nz        s16, sdiv_8
sdiv_done_7:
    s.xor        s1, s6, s15
    v.iota       v0                              // arange(0, VLEN)
    s.xor        s4, s9, s1
    v.movi       v1, #16
    s.sub        s6, s4, s1
    v.movi       v2, #32
    s.mul        s1, s6, s5
    v.movi       v3, #48
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v5, #64
    v.movi       v6, #80
    v.splat      v7, s1
    v.movi       v8, #96
    v.iota       v9                              // arange(0, VLEN)
    v.movi       v10, #112
    v.add        v11, v7, v0
    v.splat      v12, s3
    v.movi       v13, #0
    v.add        v14, v0, v1
    v.add        v1, v0, v2
    v.add        v2, v0, v3
    v.add        v0, v4, v5
    v.add        v3, v4, v6
    v.add        v5, v4, v8
    v.add        v4, v9, v10
    v.sub        v6, v13, v11
    v.sub        v8, v13, v12
    v.cmp.lt     p1, v11, v13
    v.cmp.lt     p2, v12, v13
    v.add        v9, v7, v14
    v.add        v10, v7, v1
    v.add        v1, v7, v2
    v.add        v2, v7, v0
    v.add        v0, v7, v3
    v.add        v3, v7, v5
    v.add        v5, v7, v4
    v.movi       v4, #1
    @p1 v.sel        v7, v6, v11
    @p2 v.sel        v6, v8, v12
    v.movi       v8, #0
    v.movi       v11, #0
    s.movz       s4, #31
idiv_9:
    v.splat      v14, s4
    v.shl        v15, v11, v4
    v.cmp.lt     p2, v11, v13
    v.lshr       v16, v7, v14
    v.shl        v17, v4, v14
    s.subi       s6, s4, #1
    v.and        v14, v16, v4
    s.movz       s7, #0
    v.or         v16, v15, v14
    v.cmp.geu    p3, v16, v6
    p.or         p4, p2, p3
    v.sub        v14, v16, v6
    @p4 v.sel        v15, v17, v13
    @p4 v.sel        v17, v14, v16
    v.or         v14, v8, v15
    v.mov        v11, v17
    v.mov        v8, v14
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_9
    v.movi       v4, #0
    v.sub        v6, v13, v11
    v.movi       v7, #1
    v.sub        v8, v4, v9
    v.sub        v13, v4, v12
    v.cmp.lt     p2, v9, v4
    v.cmp.lt     p3, v12, v4
    @p1 v.sel        v14, v6, v11
    @p2 v.sel        v6, v8, v9
    @p3 v.sel        v8, v13, v12
    v.movi       v9, #0
    v.movi       v11, #0
    s.movz       s4, #31
idiv_10:
    v.splat      v13, s4
    v.shl        v15, v11, v7
    v.cmp.lt     p1, v11, v4
    v.lshr       v16, v6, v13
    v.shl        v17, v7, v13
    s.subi       s6, s4, #1
    v.and        v13, v16, v7
    v.or         v16, v15, v13
    v.cmp.geu    p3, v16, v8
    p.or         p4, p1, p3
    v.sub        v13, v16, v8
    @p4 v.sel        v15, v17, v4
    @p4 v.sel        v17, v13, v16
    v.or         v13, v9, v15
    v.mov        v11, v17
    v.mov        v9, v13
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_10
    v.movi       v6, #0
    v.sub        v7, v4, v11
    v.movi       v4, #1
    v.sub        v8, v6, v10
    v.sub        v9, v6, v12
    v.cmp.lt     p1, v10, v6
    v.cmp.lt     p3, v12, v6
    @p2 v.sel        v13, v7, v11
    @p1 v.sel        v7, v8, v10
    @p3 v.sel        v8, v9, v12
    v.movi       v9, #0
    v.movi       v10, #0
    s.movz       s4, #31
idiv_11:
    v.splat      v11, s4
    v.shl        v15, v10, v4
    v.cmp.lt     p2, v10, v6
    v.lshr       v16, v7, v11
    v.shl        v17, v4, v11
    s.subi       s6, s4, #1
    v.and        v11, v16, v4
    s.movz       s7, #0
    v.or         v16, v15, v11
    v.cmp.geu    p3, v16, v8
    p.or         p4, p2, p3
    v.sub        v11, v16, v8
    @p4 v.sel        v15, v17, v6
    @p4 v.sel        v17, v11, v16
    v.or         v11, v9, v15
    v.mov        v10, v17
    v.mov        v9, v11
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_11
    v.movi       v4, #0
    v.sub        v7, v6, v10
    v.movi       v6, #1
    v.sub        v8, v4, v1
    v.sub        v9, v4, v12
    v.cmp.lt     p2, v1, v4
    v.cmp.lt     p3, v12, v4
    @p1 v.sel        v11, v7, v10
    @p2 v.sel        v7, v8, v1
    @p3 v.sel        v1, v9, v12
    v.movi       v8, #0
    v.movi       v9, #0
    s.movz       s4, #31
idiv_12:
    v.splat      v10, s4
    v.shl        v15, v9, v6
    v.cmp.lt     p1, v9, v4
    v.lshr       v16, v7, v10
    v.shl        v17, v6, v10
    s.subi       s6, s4, #1
    v.and        v10, v16, v6
    v.or         v16, v15, v10
    v.cmp.geu    p3, v16, v1
    p.or         p4, p1, p3
    v.sub        v10, v16, v1
    @p4 v.sel        v15, v17, v4
    @p4 v.sel        v17, v10, v16
    v.or         v10, v8, v15
    v.mov        v9, v17
    v.mov        v8, v10
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_12
    v.movi       v1, #0
    v.sub        v6, v4, v9
    v.movi       v4, #1
    v.sub        v7, v1, v2
    v.sub        v8, v1, v12
    v.cmp.lt     p1, v2, v1
    v.cmp.lt     p3, v12, v1
    @p2 v.sel        v10, v6, v9
    @p1 v.sel        v6, v7, v2
    @p3 v.sel        v2, v8, v12
    v.movi       v7, #0
    v.movi       v8, #0
    s.movz       s4, #31
idiv_13:
    v.splat      v9, s4
    v.shl        v15, v8, v4
    v.cmp.lt     p2, v8, v1
    v.lshr       v16, v6, v9
    v.shl        v17, v4, v9
    s.subi       s6, s4, #1
    v.and        v9, v16, v4
    s.movz       s7, #0
    v.or         v16, v15, v9
    v.cmp.geu    p3, v16, v2
    p.or         p4, p2, p3
    v.sub        v9, v16, v2
    @p4 v.sel        v15, v17, v1
    @p4 v.sel        v17, v9, v16
    v.or         v9, v7, v15
    v.mov        v8, v17
    v.mov        v7, v9
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_13
    v.movi       v2, #0
    v.sub        v4, v1, v8
    v.movi       v1, #1
    v.sub        v6, v2, v0
    v.sub        v7, v2, v12
    v.cmp.lt     p2, v0, v2
    v.cmp.lt     p3, v12, v2
    @p1 v.sel        v9, v4, v8
    @p2 v.sel        v4, v6, v0
    @p3 v.sel        v0, v7, v12
    v.movi       v6, #0
    v.movi       v7, #0
    s.movz       s4, #31
idiv_14:
    v.splat      v8, s4
    v.shl        v15, v7, v1
    v.cmp.lt     p1, v7, v2
    v.lshr       v16, v4, v8
    v.shl        v17, v1, v8
    s.subi       s6, s4, #1
    v.and        v8, v16, v1
    v.or         v16, v15, v8
    v.cmp.geu    p3, v16, v0
    p.or         p4, p1, p3
    v.sub        v8, v16, v0
    @p4 v.sel        v15, v17, v2
    @p4 v.sel        v17, v8, v16
    v.or         v8, v6, v15
    v.mov        v7, v17
    v.mov        v6, v8
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_14
    v.movi       v0, #0
    v.sub        v1, v2, v7
    v.movi       v2, #1
    v.sub        v4, v0, v3
    v.sub        v6, v0, v12
    v.cmp.lt     p1, v3, v0
    v.cmp.lt     p3, v12, v0
    @p2 v.sel        v8, v1, v7
    @p1 v.sel        v1, v4, v3
    @p3 v.sel        v3, v6, v12
    v.movi       v4, #0
    v.movi       v6, #0
    s.movz       s4, #31
idiv_15:
    v.splat      v7, s4
    v.shl        v15, v6, v2
    v.cmp.lt     p2, v6, v0
    v.lshr       v16, v1, v7
    v.shl        v17, v2, v7
    s.subi       s6, s4, #1
    v.and        v7, v16, v2
    s.movz       s7, #0
    v.or         v16, v15, v7
    v.cmp.geu    p3, v16, v3
    p.or         p4, p2, p3
    v.sub        v7, v16, v3
    @p4 v.sel        v15, v17, v0
    @p4 v.sel        v17, v7, v16
    v.or         v7, v4, v15
    v.mov        v6, v17
    v.mov        v4, v7
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_15
    v.movi       v1, #0
    v.sub        v2, v0, v6
    v.movi       v0, #1
    v.sub        v3, v1, v5
    v.sub        v4, v1, v12
    v.cmp.lt     p2, v5, v1
    v.cmp.lt     p3, v12, v1
    @p1 v.sel        v7, v2, v6
    @p2 v.sel        v2, v3, v5
    @p3 v.sel        v3, v4, v12
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s4, #31
idiv_16:
    v.splat      v6, s4
    v.shl        v12, v5, v0
    v.cmp.lt     p1, v5, v1
    v.lshr       v15, v2, v6
    v.shl        v16, v0, v6
    s.subi       s6, s4, #1
    v.and        v6, v15, v0
    v.or         v15, v12, v6
    v.cmp.geu    p3, v15, v3
    p.or         p4, p1, p3
    v.sub        v6, v15, v3
    @p4 v.sel        v12, v16, v1
    @p4 v.sel        v16, v6, v15
    v.or         v6, v4, v12
    v.mov        v5, v16
    v.mov        v4, v6
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_16
    v.sub        v0, v1, v5
    v.movi       v1, #0
    v.movi       v2, #0
    @p2 v.sel        v3, v0, v5
    v.movi       v0, #0
    v.movi       v4, #0
    v.sub        v5, v1, v14
    v.sub        v6, v2, v13
    v.sub        v12, v0, v11
    v.cmp.lt     p1, v14, v1
    v.cmp.lt     p2, v13, v2
    v.cmp.lt     p3, v11, v0
    @p1 v.sel        v15, v5, v14
    v.movi       v5, #7
    @p2 v.sel        v16, v6, v13
    v.movi       v6, #7
    @p3 v.sel        v17, v12, v11
    v.movi       v12, #7
    v.lshr       v18, v15, v5
    v.lshr       v5, v16, v6
    v.lshr       v6, v17, v12
    v.movi       v12, #128
    v.sub        v15, v1, v18
    v.movi       v16, #128
    v.sub        v17, v2, v5
    v.movi       v19, #128
    v.sub        v20, v0, v6
    v.movi       v21, #128
    v.sub        v22, v1, v12
    @p1 v.sel        v23, v15, v18
    v.sub        v15, v2, v16
    @p2 v.sel        v18, v17, v5
    v.sub        v5, v0, v19
    @p3 v.sel        v17, v20, v6
    v.cmp.lt     p1, v12, v1
    v.cmp.lt     p2, v16, v2
    v.cmp.lt     p3, v19, v0
    s.movz       s4, #16
    s.movz       s6, #32
    s.movz       s7, #48
    s.movz       s9, #64
    v.sub        v0, v4, v10
    s.movz       s11, #80
    s.movz       s12, #96
    v.sub        v1, v4, v21
    s.movz       s15, #112
    v.movi       v2, #7
    v.movi       v6, #1
    v.movi       v6, #0
    @p1 v.sel        v20, v22, v12
    v.cmp.lt     p1, v10, v4
    v.sub        v12, v6, v9
    @p1 v.sel        v20, v0, v10
    v.movi       v0, #7
    v.movi       v22, #1
    v.lshr       v22, v20, v2
    v.movi       v2, #0
    @p2 v.sel        v20, v15, v16
    v.cmp.lt     p2, v9, v6
    v.sub        v15, v2, v8
    @p2 v.sel        v16, v12, v9
    v.movi       v12, #7
    v.movi       v20, #1
    v.lshr       v20, v16, v0
    v.movi       v0, #0
    @p3 v.sel        v16, v5, v19
    v.cmp.lt     p3, v8, v2
    v.sub        v5, v0, v7
    @p3 v.sel        v16, v15, v8
    v.movi       v15, #7
    v.movi       v19, #1
    v.lshr       v19, v16, v12
    v.sub        v12, v4, v22
    v.movi       v16, #1
    v.movi       v16, #1
    @p1 v.sel        v16, v12, v22
    v.cmp.lt     p1, v7, v0
    @p1 v.sel        v12, v5, v7
    v.movi       v5, #128
    v.movi       v22, #1
    v.lshr       v22, v12, v15
    v.sub        v12, v6, v20
    @p2 v.sel        v15, v12, v20
    v.movi       v12, #128
    v.cmp.lt     p2, v21, v4
    v.movi       v4, #0
    @p2 v.sel        v20, v1, v21
    v.movi       v1, #7
    v.sub        v20, v4, v3
    v.cmp.lt     p2, v3, v4
    v.movi       v21, #1
    @p2 v.sel        v21, v20, v3
    v.lshr       v20, v21, v1
    v.sub        v1, v2, v19
    @p3 v.sel        v21, v1, v19
    v.movi       v1, #128
    v.cmp.lt     p3, v5, v6
    v.sub        v19, v6, v5
    @p3 v.sel        v6, v19, v5
    s.add        s16, s21, s2
    s.movz       s2, #0
    v.sub        v5, v0, v22
    s.cmp.lt     s17, s16, s2
    v.movi       v6, #128
    s.sub        s18, s2, s17
    @p1 v.sel        v19, v5, v22
    v.sub        v5, v4, v20
    v.cmp.lt     p1, v12, v2
    s.xor        s17, s16, s18
    s.cmp.lt     s16, s5, s2
    v.sub        v22, v2, v12
    s.sub        s25, s17, s18
    s.sub        s17, s2, s16
    @p2 v.sel        v2, v5, v20
    v.sub        v5, v0, v1
    v.cmp.lt     p2, v1, v0
    v.sub        v0, v4, v6
    v.cmp.lt     p3, v6, v4
    v.splat      v4, s24
    @p1 v.sel        v20, v22, v12
    s.lshri      s16, s25, #7
    s.xor        s24, s18, s17
    s.muli       s18, s16, #128
    s.xor        s26, s5, s17
    s.xor        s27, s16, s24
    @p2 v.sel        v12, v5, v1
    @p3 v.sel        v1, v0, v6
    v.mul        v0, v23, v4
    v.mul        v1, v18, v4
    v.mul        v5, v17, v4
    v.mul        v6, v16, v4
    v.mul        v12, v15, v4
    v.mul        v15, v21, v4
    v.mul        v16, v19, v4
    v.mul        v17, v2, v4
    s.sub        s16, s26, s17
    s.sub        s16, s25, s18
    s.sub        s16, s27, s24
    s.addi       s17, s2, #0
    s.addi       s18, s2, #0
    s.addi       s24, s2, #0
    s.addi       s25, s20, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_25:
    s.cmp.ge     s20, s17, s16
    br.nz        s20, endfor_26
    s.mul        s20, s17, s5
    s.muli       s26, s18, #2
    v.iota       v2                              // arange(0, VLEN)
    s.rdspecial  s27, arg_base
    s.add        s28, s2, s4                     // the tile origin
    s.sub        s29, s21, s20
    s.add        s20, s14, s26
    s.add        s30, s2, s29                    // the tile origin
    s.ld.d       s31, [s27, #80]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.splat      v4, s30
    s.movz       s27, #0
    v.splat      v18, s28
    v.cmp.lt     p1, v2, v4
    s.add        s28, s27, s29                   // the tile origin
    s.addi       s30, s26, #32
    v.add        v4, v2, v18
    v.splat      v18, s28
    s.add        s32, s14, s30
    s.add        s30, s27, s6                    // the tile origin
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v19, [s20, #0]
    s.addi       s20, s31, #0
    v.cmp.lt     p1, v4, v18
    v.splat      v4, s30
    s.addi       s30, s26, #64
    v.splat      v18, s28
    v.add        v20, v2, v4
    s.addi       s33, s31, #64
    s.add        s34, s14, s30
    v.cmp.lt     p2, v20, v18
    s.add        s30, s27, s7                    // the tile origin
    s.addi       s35, s26, #96
    v.splat      v4, s30
    v.splat      v18, s28
    v.st.w       [s20, #0], v19
    fence.acq_rel.device
    v.add        v19, v2, v4
    s.addi       s20, s31, #128
    s.add        s30, s14, s35
    s.add        s35, s27, s9                    // the tile origin
    s.addi       s36, s26, #128
    v.splat      v4, s35
    v.splat      v20, s28
    s.addi       s35, s31, #192
    v.add        v21, v2, v4
    s.add        s37, s14, s36
    s.add        s36, s27, s11                   // the tile origin
    s.addi       s27, s26, #160
    v.splat      v4, s36
    v.splat      v22, s28
    s.addi       s28, s31, #256
    v.add        v23, v2, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s32, #0]
    v.cmp.lt     p1, v19, v18
    s.add        s32, s14, s27
    s.addi       s27, s26, #192
    s.addi       s36, s31, #320
    s.add        s38, s14, s27
    v.st.w       [s33, #0], v4
    fence.acq_rel.device
    s.movz       s27, #0
    s.addi       s33, s31, #384
    s.add        s39, s27, s12                   // the tile origin
    v.splat      v4, s39
    s.add        s39, s27, s29                   // the tile origin
    v.add        v18, v2, v4
    v.splat      v4, s39
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v19, [s34, #0]
    v.cmp.lt     p2, v21, v20
    v.st.w       [s20, #0], v19
    fence.acq_rel.device
    s.add        s20, s27, s15                   // the tile origin
    s.addi       s27, s26, #224
    v.splat      v19, s20
    v.splat      v20, s39
    s.add        s20, s14, s27
    v.add        v21, v2, v19
    s.addi       s26, s31, #448
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v2, [s30, #0]
    v.cmp.lt     p1, v23, v22
    v.st.w       [s35, #0], v2
    fence.acq_rel.device
    s.addi       s27, s31, #0
    s.addi       s30, s31, #512
    s.addi       s34, s31, #64
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s37, #0]
    v.cmp.lt     p2, v18, v4
    s.addi       s35, s31, #576
    v.st.w       [s28, #0], v2
    fence.acq_rel.device
    s.addi       s28, s31, #128
    s.addi       s37, s31, #640
    s.addi       s39, s31, #192
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v2, [s32, #0]
    v.cmp.lt     p1, v21, v20
    s.addi       s32, s31, #704
    v.st.w       [s36, #0], v2
    fence.acq_rel.device
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s38, #0]
    s.addi       s38, s31, #256
    v.st.w       [s33, #0], v2
    fence.acq_rel.device
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v2, [s20, #0]
    s.addi       s20, s31, #768
    v.st.w       [s26, #0], v2
    fence.acq_rel.device
    v.ld.w       v2, [s27, #0]
    s.addi       s27, s31, #832
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s30, #0], v4
    fence.acq_rel.device
    v.ld.w       v2, [s34, #0]
    s.addi       s34, s31, #896
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s35, #0], v4
    fence.acq_rel.device
    v.ld.w       v2, [s28, #0]
    s.addi       s28, s31, #960
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s37, #0], v4
    fence.acq_rel.device
    v.ld.w       v2, [s39, #0]
    s.addi       s39, s31, #1024
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s32, #0], v4
    fence.acq_rel.device
    v.ld.w       v2, [s38, #0]
    s.addi       s38, s31, #1088
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s20, #0], v4
    fence.acq_rel.device
    v.ld.w       v2, [s36, #0]
    s.addi       s36, s31, #1152
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s27, #0], v4
    fence.acq_rel.device
    v.ld.w       v2, [s33, #0]
    s.addi       s33, s31, #1216
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s34, #0], v4
    fence.acq_rel.device
    v.ld.w       v2, [s26, #0]
    s.addi       s26, s31, #1280
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s28, #0], v4
    fence.acq_rel.device
    v.ld.w       v2, [s30, #0]
    s.addi       s30, s31, #1344
    vf.abs       v4, v2
    v.st.w       [s39, #0], v4
    fence.acq_rel.device
    v.ld.w       v2, [s35, #0]
    s.addi       s35, s31, #1408
    vf.abs       v4, v2
    v.st.w       [s38, #0], v4
    fence.acq_rel.device
    v.movi       v2, #0
    v.ld.w       v4, [s37, #0]
    s.addi       s37, s31, #1472
    vf.abs       v18, v4
    v.st.w       [s36, #0], v18
    fence.acq_rel.device
    v.ld.w       v4, [s32, #0]
    vf.abs       v18, v4
    v.st.w       [s33, #0], v18
    fence.acq_rel.device
    v.ld.w       v4, [s20, #0]
    vf.abs       v18, v4
    v.st.w       [s26, #0], v18
    fence.acq_rel.device
    v.ld.w       v4, [s27, #0]
    vf.abs       v18, v4
    .li       s20, #1138753536
    v.splat      v4, s20                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v19, v4                         // ISA 8.8: <= 2**-22 relative
    v.st.w       [s30, #0], v18
    fence.acq_rel.device
    .li       s20, #1065353216
    v.splat      v18, s20                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.ld.w       v20, [s34, #0]
    vf.fms       v21, v4, v19, v18
    vf.fms       v22, v19, v21, v19
    vf.abs       v21, v20
    vf.neg       v20, v22                        // Newton step: r0*(2 - x*r0)
    v.st.w       [s35, #0], v21
    fence.acq_rel.device
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v21, v20, v19
    v.ld.w       v19, [s28, #0]
    vf.abs       v20, v19
    v.st.w       [s37, #0], v20
    fence.acq_rel.device
    v.ld.w       v19, [s39, #0]
    .li       s20, #730643660
    v.splat      v20, s20                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.ld.w       v22, [s38, #0]
    v.splat      v23, s22
    v.ld.w       v24, [s36, #0]
    vf.max.ieee  v25, v19, v22
    v.mul        v19, v14, v23
    v.mul        v22, v13, v23
    v.ld.w       v26, [s33, #0]
    vf.max.ieee  v27, v25, v24
    v.mul        v24, v11, v23
    v.mul        v25, v10, v23
    v.ld.w       v28, [s26, #0]
    vf.max.ieee  v29, v27, v26
    v.splat      v26, s22
    v.mul        v27, v9, v23
    v.ld.w       v23, [s30, #0]
    vf.max.ieee  v30, v29, v28
    v.mul        v28, v8, v26
    v.mul        v29, v7, v26
    v.ld.w       v31, [s35, #0]
    vf.max.ieee  v32, v30, v23
    v.mul        v23, v3, v26
    v.ld.w       v26, [s37, #0]
    vf.max.ieee  v30, v32, v31
    vf.max.ieee  v31, v30, v26
    vf.reduce.max.b v26, v31
    // one value per row into one vector (ISA 0x09)
    v.extract    s20, v26, #0
    v.insert     v2, s20, #0
    v.insert     v2, s20, #1
    s.add        s26, s2, s29
    v.insert     v2, s20, #2
    // tl.dot 16x128 by 128x128 FP8, B as W's rows written transposed by the engine (ISA sec 9E, tensor_transpose_8bit)
    s.addi       s27, s31, #1536
    v.insert     v2, s20, #3
    v.insert     v2, s20, #4
    s.addi       s28, s31, #1600
    v.insert     v2, s20, #5
    v.insert     v2, s20, #6
    s.addi       s29, s31, #1664
    v.insert     v2, s20, #7
    v.insert     v2, s20, #8
    s.addi       s30, s31, #1728
    v.insert     v2, s20, #9
    v.insert     v2, s20, #10
    s.addi       s32, s31, #1792
    v.insert     v2, s20, #11
    v.insert     v2, s20, #12
    s.addi       s33, s31, #1856
    v.insert     v2, s20, #13
    v.insert     v2, s20, #14
    s.addi       s34, s31, #1920
    v.insert     v2, s20, #15
    v.iota       v26                             // arange(0, VLEN)
    s.movz       s20, #0
    v.movi       v30, #0
    s.cmp.ge     s35, s26, s20
    s.addi       s36, s31, #1984
    v.ld.gather.w v31, [s25, v0]                 // index is in elements (ISA sec 9.1)
    v.movi       v32, #0
    vf.mul       v33, v2, v21                    // a/y: faithful quotient
    v.extract    s37, v14, #0
    vf.fms       v34, v33, v4, v2
    v.splat      v2, s37
    vf.fms       v4, v34, v21, v33
    v.add        v21, v2, v26
    vf.neg       v2, v4                          // a/y: one correction to the IEEE quotient
    v.sub        v4, v14, v21
    v.ld.gather.w v21, [s25, v1]                 // index is in elements (ISA sec 9.1)
    vf.cmp.o     p1, v2, v2
    v.reduce.or  s38, v4
    @p1 v.sel        v4, v2, v33
    v.extract    s39, v13, #0
    s.cmp.eq     s40, s38, s20
    v.splat      v2, s39
    v.add        v33, v2, v26
    v.sub        v2, v13, v33
    v.ld.gather.w v33, [s25, v5]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v34, [s25, v6]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v35, [s25, v12]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v36, [s25, v15]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v37, [s25, v16]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v38, [s25, v17]                // index is in elements (ISA sec 9.1)
    v.st.w       [s27, #0], v19
    v.extract    s27, v11, #0
    v.splat      v19, s27
    v.add        v39, v19, v26
    v.sub        v19, v11, v39
    v.st.w       [s28, #0], v22
    s.cmp.ge     s28, s37, s20
    s.and        s38, s40, s28
    v.reduce.or  s28, v2
    s.and        s40, s38, s35
    s.cmp.eq     s38, s28, s20
    v.st.w       [s29, #0], v24
    s.cmp.ge     s28, s39, s20
    s.and        s29, s38, s28
    v.reduce.or  s28, v19
    s.and        s38, s29, s35
    s.cmp.eq     s29, s28, s20
    v.st.w       [s30, #0], v25
    v.extract    s28, v10, #0
    v.splat      v2, s28
    v.st.w       [s32, #0], v27
    v.add        v19, v2, v26
    s.cmp.ge     s30, s27, s20
    v.sub        v2, v10, v19
    s.and        s32, s29, s30
    s.and        s29, s32, s35
    v.st.w       [s33, #0], v28
    v.reduce.or  s30, v2
    s.cmp.eq     s32, s30, s20
    v.st.w       [s34, #0], v29
    s.cmp.ge     s30, s28, s20
    s.and        s33, s32, s30
    v.st.w       [s36, #0], v23
    fence.acq_rel.device
    v.extract    s30, v9, #0
    v.extract    s32, v8, #0
    v.splat      v2, s30
    v.splat      v19, s32
    v.insert     v30, s40, #0
    v.add        v22, v2, v26
    v.add        v2, v19, v26
    v.insert     v32, s37, #0
    v.extract    s34, v7, #0
    v.sub        v19, v9, v22
    v.insert     v30, s38, #1
    v.splat      v22, s34
    v.reduce.or  s36, v19
    v.sub        v19, v8, v2
    v.insert     v32, s39, #1
    v.extract    s37, v3, #0
    v.add        v2, v22, v26
    v.insert     v30, s29, #2
    v.splat      v22, s37
    s.cmp.eq     s29, s36, s20
    s.cmp.ge     s36, s30, s20
    s.and        s20, s33, s35
    v.reduce.or  s33, v19
    s.movz       s38, #0
    v.sub        v19, v7, v2
    s.and        s39, s29, s36
    v.insert     v32, s27, #2
    v.add        v2, v22, v26
    v.insert     v30, s20, #3
    s.cmp.eq     s20, s33, s38
    s.cmp.ge     s27, s32, s38
    s.and        s29, s39, s35
    v.reduce.or  s33, v19
    v.sub        v19, v3, v2
    s.and        s36, s20, s27
    v.insert     v32, s28, #3
    v.insert     v30, s29, #4
    s.cmp.eq     s20, s33, s38
    s.cmp.ge     s27, s34, s38
    s.and        s28, s36, s35
    v.reduce.or  s29, v19
    s.and        s33, s20, s27
    v.insert     v32, s30, #4
    v.insert     v30, s28, #5
    s.cmp.eq     s20, s29, s38
    s.cmp.ge     s27, s37, s38
    s.and        s28, s33, s35
    s.and        s29, s20, s27
    v.insert     v32, s32, #5
    v.insert     v30, s28, #6
    s.and        s20, s29, s35
    v.insert     v32, s34, #6
    v.insert     v30, s20, #7
    s.add        s20, s13, s24
    s.addi       s27, s31, #2048                 // TensorMap 0: W's rows for a transposed FP8 B
    .li       s28, #2147483647
    s.movz       s29, #1
    .li       s30, #137438953488
    .li       s32, #7705171329024
    s.addi       s33, s31, #2304
    s.addi       s34, s31, #3328                 // TensorMap 1: the gathered fallback B tile
    s.movz       s35, #32
    s.movz       s36, #16
    .li       s38, #68719476768
    s.addi       s39, s31, #2816
    v.insert     v32, s37, #7
    s.addi       s37, s31, #3584                 // TensorMap 2: the gathered fallback B tile
    s.st.d       [s27, #0], s20
    v.extract    s20, v30, #0
    s.st.d       [s27, #8], s28
    s.movz       s28, #0
    s.st.d       [s27, #16], s26
    s.st.d       [s27, #48], s22
    s.st.d       [s27, #56], s29
    s.st.d       [s27, #88], s30
    s.st.d       [s27, #104], s32
    fence.release.device
    td.load      d0, [s27]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.st.d       [s34, #0], s33
    s.st.d       [s34, #8], s35
    s.st.d       [s34, #16], s36
    s.st.d       [s34, #48], s36
    s.st.d       [s34, #56], s29
    s.st.d       [s34, #88], s38
    s.st.d       [s34, #104], s32
    fence.release.device
    td.load      d1, [s34]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.st.d       [s37, #0], s39
    s.st.d       [s37, #8], s35
    s.st.d       [s37, #16], s36
    s.st.d       [s37, #48], s36
    s.st.d       [s37, #56], s29
    s.st.d       [s37, #88], s38
    s.st.d       [s37, #104], s32
    fence.release.device
    td.load      d2, [s37]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s20, x8dot_done_27
    s.addi       s27, s31, #1536
    s.addi       s29, s28, #0
    v.ld.w       v2, [s27, #0]
    s.add        s27, s13, s24
x8dot_row_28:
    s.addi       s30, s26, #0
    v.movi       v19, #0
    s.sub        s32, s30, s29
    s.add        s30, s27, s29
    v.splat      v22, s32
    s.shli       s32, s29, #4
    s.addi       s34, s29, #1
    v.cmp.gt     p1, v22, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s30, v2]             // index is in elements (ISA sec 9.1)
    s.add        s30, s33, s32
    v.st.b       [s30, #0], v19
    fence.acq_rel.device
    s.mov        s29, s34
    s.cmp.lt     s30, s29, s35
    br.nz        s30, x8dot_row_28
x8dot_done_27:
    v.splat      v2, s20
    v.movi       v19, #0
    mb.arm       s20, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s27, v32, #0
    v.extract    s29, v30, #1
    v.cmp.ne     p1, v2, v19
    v.cmp.eq     p2, v2, v19
    s.mov        s32, s28                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s28                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s32, s20            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s32, s27                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s28                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s32, s20          // predicated off still completes once (ISA sec 9A.3)
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s29, x8dot_done_29
    s.movz       s27, #0
    s.addi       s28, s31, #1600
    s.addi       s30, s27, #0
    v.ld.w       v2, [s28, #0]
    s.add        s27, s13, s24
    s.addi       s28, s31, #2816
x8dot_row_30:
    s.addi       s32, s26, #0
    v.movi       v19, #0
    s.sub        s33, s32, s30
    s.add        s32, s27, s30
    v.splat      v22, s33
    s.shli       s33, s30, #4
    s.addi       s34, s30, #1
    v.cmp.gt     p1, v22, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s32, v2]             // index is in elements (ISA sec 9.1)
    s.add        s32, s28, s33
    s.movz       s33, #32
    v.st.b       [s32, #0], v19
    fence.acq_rel.device
    s.mov        s30, s34
    s.cmp.lt     s32, s30, s33
    br.nz        s32, x8dot_row_30
x8dot_done_29:
    v.extract    s27, v4, #0
    v.splat      v2, s29
    v.splat      v19, s27
    v.movi       v22, #0
    mb.arm       s27, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    vf.max.ieee  v23, v19, v20
    s.movz       s28, #0
    v.extract    s29, v32, #1
    s.addi       s30, s31, #512
    v.cmp.ne     p1, v2, v22
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.cmp.eq     p2, v2, v22
    s.mov        s32, s28                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s28                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s32, s27            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s32, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s28                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s32, s27          // predicated off still completes once (ISA sec 9A.3)
    v.ld.w       v2, [s30, #0]
    v.extract    s28, v4, #1
    v.movi       v22, #24
    v.splat      v24, s28
    v.movi       v25, #128
    s.addi       s28, s31, #3840                 // 512 bytes of repack scratch
    vf.max.ieee  v26, v24, v20
    s.addi       s29, s28, #0
    v.extract    s32, v4, #2
    s.addi       s33, s28, #32
    v.splat      v24, s32
    v.rcp.approx v27, v26                        // ISA 8.8: <= 2**-22 relative
    vf.max.ieee  v28, v24, v20
    v.rcp.approx v24, v28                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v29, v23, v19, v18
    vf.fms       v39, v19, v29, v19
    vf.neg       v29, v39                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v29, v29
    @p1 v.sel        v39, v29, v19
    vf.fms       v19, v26, v27, v18
    vf.fms       v29, v27, v19, v27
    vf.neg       v19, v29                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v29, v19, v27
    vf.mul       v19, v2, v39                    // a/y: faithful quotient
    vf.fms       v27, v19, v23, v2
    vf.fms       v2, v28, v24, v18
    vf.fms       v23, v27, v39, v19
    vf.fms       v27, v24, v2, v24
    vf.neg       v2, v23                         // a/y: one correction to the IEEE quotient
    vf.neg       v23, v27                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v27, v2, v19
    vf.cmp.o     p1, v23, v23
    @p1 v.sel        v2, v23, v24
    v.lshr       v19, v27, v22
    vf.cvt.f32.e4m3 v23, v27
    s.addi       s32, s28, #64
    v.and        v24, v19, v25
    s.addi       s34, s31, #512
    v.or         v19, v23, v24                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s35, v4, #3
    v.st.b       [s29, #0], v19
    v.splat      v19, s35
    v.ld.w       v23, [s30, #0]
    vf.max.ieee  v24, v19, v20
    v.rcp.approx v19, v24                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v27, v23, v29                   // a/y: faithful quotient
    vf.fms       v39, v27, v26, v23
    vf.fms       v23, v39, v29, v27
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.fms       v23, v24, v19, v18
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v29, v26, v27
    vf.fms       v26, v19, v23, v19
    v.lshr       v23, v29, v22
    vf.cvt.f32.e4m3 v27, v29
    s.addi       s29, s28, #96
    v.and        v29, v23, v25
    vf.neg       v23, v26                        // Newton step: r0*(2 - x*r0)
    v.or         v26, v27, v29                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s35, v4, #4
    v.st.b       [s33, #0], v26
    vf.cmp.o     p1, v23, v23
    v.splat      v26, s35
    @p1 v.sel        v27, v23, v19
    v.ld.w       v19, [s30, #0]
    vf.max.ieee  v23, v26, v20
    v.rcp.approx v26, v23                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v19, v2                    // a/y: faithful quotient
    vf.fms       v39, v29, v28, v19
    vf.fms       v19, v39, v2, v29
    vf.neg       v2, v19                         // a/y: one correction to the IEEE quotient
    vf.fms       v19, v23, v26, v18
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v28, v2, v29
    vf.fms       v2, v26, v19, v26
    v.lshr       v19, v28, v22
    vf.cvt.f32.e4m3 v29, v28
    s.addi       s30, s28, #128
    v.and        v28, v19, v25
    vf.neg       v19, v2                         // Newton step: r0*(2 - x*r0)
    v.or         v2, v29, v28                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s33, v4, #5
    v.st.b       [s32, #0], v2
    vf.cmp.o     p1, v19, v19
    v.splat      v2, s33
    @p1 v.sel        v28, v19, v26
    vf.max.ieee  v19, v2, v20
    v.ld.w       v2, [s34, #0]
    v.rcp.approx v26, v19                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v2, v27                    // a/y: faithful quotient
    vf.fms       v39, v29, v24, v2
    vf.fms       v2, v39, v27, v29
    vf.fms       v24, v19, v26, v18
    vf.neg       v27, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v26, v24, v26
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v24, v27, v29
    vf.neg       v27, v2                         // Newton step: r0*(2 - x*r0)
    v.lshr       v2, v24, v22
    vf.cvt.f32.e4m3 v29, v24
    s.addi       s32, s28, #160
    v.and        v24, v2, v25
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v2, v27, v26
    v.or         v26, v29, v24                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s33, v4, #6
    s.addi       s35, s31, #512
    v.st.b       [s29, #0], v26
    v.splat      v24, s33
    v.ld.w       v26, [s34, #0]
    vf.max.ieee  v27, v24, v20
    v.rcp.approx v24, v27                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v26, v28                   // a/y: faithful quotient
    vf.fms       v39, v29, v23, v26
    vf.fms       v23, v39, v28, v29
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.fms       v23, v27, v24, v18
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v28, v26, v29
    vf.fms       v26, v24, v23, v24
    v.lshr       v23, v28, v22
    vf.cvt.f32.e4m3 v29, v28
    s.addi       s29, s28, #192
    v.and        v28, v23, v25
    vf.neg       v23, v26                        // Newton step: r0*(2 - x*r0)
    v.or         v26, v29, v28                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s33, v4, #7
    v.st.b       [s30, #0], v26
    vf.cmp.o     p1, v23, v23
    v.splat      v26, s33
    @p1 v.sel        v28, v23, v24
    v.ld.w       v23, [s34, #0]
    vf.max.ieee  v24, v26, v20
    v.rcp.approx v26, v24                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v23, v2                    // a/y: faithful quotient
    vf.fms       v39, v29, v19, v23
    vf.fms       v19, v39, v2, v29
    vf.neg       v2, v19                         // a/y: one correction to the IEEE quotient
    vf.fms       v19, v24, v26, v18
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v23, v2, v29
    vf.fms       v2, v26, v19, v26
    v.lshr       v19, v23, v22
    vf.cvt.f32.e4m3 v29, v23
    s.addi       s30, s28, #224
    v.and        v23, v19, v25
    vf.neg       v19, v2                         // Newton step: r0*(2 - x*r0)
    v.or         v2, v29, v23                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s33, v4, #8
    v.st.b       [s32, #0], v2
    vf.cmp.o     p1, v19, v19
    v.splat      v2, s33
    @p1 v.sel        v23, v19, v26
    vf.max.ieee  v19, v2, v20
    v.ld.w       v2, [s35, #0]
    v.rcp.approx v26, v19                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v2, v28                    // a/y: faithful quotient
    vf.fms       v39, v29, v27, v2
    vf.fms       v2, v39, v28, v29
    vf.fms       v27, v19, v26, v18
    vf.neg       v28, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v26, v27, v26
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v29
    vf.neg       v28, v2                         // Newton step: r0*(2 - x*r0)
    v.lshr       v2, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s32, s28, #256
    v.and        v27, v2, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v2, v28, v26
    v.or         v26, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s33, v4, #9
    s.addi       s34, s31, #512
    v.st.b       [s29, #0], v26
    v.splat      v26, s33
    v.ld.w       v27, [s35, #0]
    vf.max.ieee  v28, v26, v20
    v.rcp.approx v26, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v27, v23                   // a/y: faithful quotient
    vf.fms       v39, v29, v24, v27
    vf.fms       v24, v39, v23, v29
    vf.neg       v23, v24                        // a/y: one correction to the IEEE quotient
    vf.fms       v24, v28, v26, v18
    vf.cmp.o     p1, v23, v23
    @p1 v.sel        v27, v23, v29
    vf.fms       v23, v26, v24, v26
    v.lshr       v24, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s29, s28, #288
    v.and        v27, v24, v25
    vf.neg       v24, v23                        // Newton step: r0*(2 - x*r0)
    v.or         v23, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s33, v4, #10
    v.st.b       [s30, #0], v23
    vf.cmp.o     p1, v24, v24
    v.splat      v23, s33
    @p1 v.sel        v27, v24, v26
    v.ld.w       v24, [s35, #0]
    vf.max.ieee  v26, v23, v20
    v.rcp.approx v23, v26                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v24, v2                    // a/y: faithful quotient
    vf.fms       v39, v29, v19, v24
    vf.fms       v19, v39, v2, v29
    vf.neg       v2, v19                         // a/y: one correction to the IEEE quotient
    vf.fms       v19, v26, v23, v18
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v24, v2, v29
    vf.fms       v2, v23, v19, v23
    v.lshr       v19, v24, v22
    vf.cvt.f32.e4m3 v29, v24
    s.addi       s30, s28, #320
    v.and        v24, v19, v25
    vf.neg       v19, v2                         // Newton step: r0*(2 - x*r0)
    v.or         v2, v29, v24                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s33, v4, #11
    v.st.b       [s32, #0], v2
    vf.cmp.o     p1, v19, v19
    v.splat      v2, s33
    @p1 v.sel        v24, v19, v23
    vf.max.ieee  v19, v2, v20
    v.ld.w       v2, [s34, #0]
    v.rcp.approx v23, v19                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v2, v27                    // a/y: faithful quotient
    vf.fms       v39, v29, v28, v2
    vf.fms       v2, v39, v27, v29
    vf.fms       v27, v19, v23, v18
    vf.neg       v28, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v23, v27, v23
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v29
    vf.neg       v28, v2                         // Newton step: r0*(2 - x*r0)
    v.lshr       v2, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s32, s28, #352
    v.and        v27, v2, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v2, v28, v23
    v.or         v23, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s33, v4, #12
    s.addi       s35, s31, #512
    v.st.b       [s29, #0], v23
    v.splat      v23, s33
    v.ld.w       v27, [s34, #0]
    vf.max.ieee  v28, v23, v20
    v.rcp.approx v23, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v27, v24                   // a/y: faithful quotient
    vf.fms       v39, v29, v26, v27
    vf.fms       v26, v39, v24, v29
    vf.neg       v24, v26                        // a/y: one correction to the IEEE quotient
    vf.fms       v26, v28, v23, v18
    vf.cmp.o     p1, v24, v24
    @p1 v.sel        v27, v24, v29
    vf.fms       v24, v23, v26, v23
    v.lshr       v26, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s29, s28, #384
    v.and        v27, v26, v25
    vf.neg       v26, v24                        // Newton step: r0*(2 - x*r0)
    v.or         v24, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s33, v4, #13
    v.st.b       [s30, #0], v24
    vf.cmp.o     p1, v26, v26
    v.splat      v24, s33
    @p1 v.sel        v27, v26, v23
    v.ld.w       v23, [s34, #0]
    vf.max.ieee  v26, v24, v20
    v.rcp.approx v24, v26                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v23, v2                    // a/y: faithful quotient
    vf.fms       v39, v29, v19, v23
    vf.fms       v19, v39, v2, v29
    vf.neg       v2, v19                         // a/y: one correction to the IEEE quotient
    vf.fms       v19, v26, v24, v18
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v23, v2, v29
    vf.fms       v2, v24, v19, v24
    v.lshr       v19, v23, v22
    vf.cvt.f32.e4m3 v29, v23
    s.addi       s30, s28, #416
    v.and        v23, v19, v25
    vf.neg       v19, v2                         // Newton step: r0*(2 - x*r0)
    v.or         v2, v29, v23                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s33, v4, #14
    v.st.b       [s32, #0], v2
    vf.cmp.o     p1, v19, v19
    v.splat      v2, s33
    @p1 v.sel        v23, v19, v24
    vf.max.ieee  v19, v2, v20
    v.ld.w       v2, [s35, #0]
    v.rcp.approx v24, v19                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v2, v27                    // a/y: faithful quotient
    vf.fms       v39, v29, v28, v2
    vf.fms       v2, v39, v27, v29
    vf.fms       v27, v19, v24, v18
    vf.neg       v28, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v24, v27, v24
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v29
    vf.neg       v28, v2                         // Newton step: r0*(2 - x*r0)
    v.lshr       v2, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s32, s28, #448
    v.and        v27, v2, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v2, v28, v24
    v.or         v24, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s33, v4, #15
    s.addi       s34, s31, #512
    v.st.b       [s29, #0], v24
    v.splat      v24, s33
    v.ld.w       v27, [s35, #0]
    vf.max.ieee  v28, v24, v20
    v.rcp.approx v24, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v27, v23                   // a/y: faithful quotient
    vf.fms       v39, v29, v26, v27
    vf.fms       v26, v39, v23, v29
    vf.neg       v23, v26                        // a/y: one correction to the IEEE quotient
    vf.fms       v26, v28, v24, v18
    vf.cmp.o     p1, v23, v23
    @p1 v.sel        v27, v23, v29
    vf.fms       v23, v24, v26, v24
    v.lshr       v26, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s29, s28, #480
    v.and        v27, v26, v25
    vf.neg       v26, v23                        // Newton step: r0*(2 - x*r0)
    v.or         v23, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #576
    v.st.b       [s30, #0], v23
    v.extract    s30, v4, #0
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v24
    v.ld.w       v24, [s35, #0]
    v.splat      v26, s30
    vf.max.ieee  v27, v26, v20
    v.rcp.approx v26, v27                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v24, v2                    // a/y: faithful quotient
    vf.fms       v39, v29, v19, v24
    vf.fms       v19, v39, v2, v29
    vf.neg       v2, v19                         // a/y: one correction to the IEEE quotient
    vf.fms       v19, v27, v26, v18
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v24, v2, v29
    v.lshr       v2, v24, v22
    vf.cvt.f32.e4m3 v29, v24
    vf.fms       v24, v26, v19, v26
    v.and        v19, v2, v25
    s.addi       s30, s28, #16
    v.or         v2, v29, v19                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v19, v24                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s32, #0], v2
    v.extract    s32, v4, #1
    vf.cmp.o     p1, v19, v19
    v.splat      v2, s32
    @p1 v.sel        v24, v19, v26
    v.ld.w       v19, [s34, #0]
    vf.max.ieee  v26, v2, v20
    v.rcp.approx v2, v26                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v19, v23                   // a/y: faithful quotient
    vf.fms       v39, v29, v28, v19
    vf.fms       v19, v39, v23, v29
    vf.neg       v23, v19                        // a/y: one correction to the IEEE quotient
    vf.fms       v19, v26, v2, v18
    vf.cmp.o     p1, v23, v23
    @p1 v.sel        v28, v23, v29
    vf.fms       v23, v2, v19, v2
    v.lshr       v19, v28, v22
    vf.cvt.f32.e4m3 v29, v28
    s.addi       s32, s28, #48
    v.and        v28, v19, v25
    vf.neg       v19, v23                        // Newton step: r0*(2 - x*r0)
    v.or         v23, v29, v28                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s34, v4, #2
    v.st.b       [s29, #0], v23
    vf.cmp.o     p1, v19, v19
    v.splat      v23, s34
    @p1 v.sel        v28, v19, v2
    vf.max.ieee  v2, v23, v20
    v.ld.w       v19, [s33, #0]
    v.rcp.approx v23, v2                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v19, v24                   // a/y: faithful quotient
    vf.fms       v39, v29, v27, v19
    vf.fms       v19, v39, v24, v29
    vf.fms       v24, v2, v23, v18
    vf.neg       v27, v19                        // a/y: one correction to the IEEE quotient
    vf.fms       v19, v23, v24, v23
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v24, v27, v29
    vf.neg       v27, v19                        // Newton step: r0*(2 - x*r0)
    v.lshr       v19, v24, v22
    vf.cvt.f32.e4m3 v29, v24
    s.addi       s29, s28, #80
    v.and        v24, v19, v25
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v19, v27, v23
    v.or         v23, v29, v24                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s34, v4, #3
    s.addi       s35, s31, #576
    v.st.b       [s30, #0], v23
    v.splat      v23, s34
    v.ld.w       v24, [s33, #0]
    vf.max.ieee  v27, v23, v20
    v.rcp.approx v23, v27                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v24, v28                   // a/y: faithful quotient
    vf.fms       v39, v29, v26, v24
    vf.fms       v24, v39, v28, v29
    vf.neg       v26, v24                        // a/y: one correction to the IEEE quotient
    vf.fms       v24, v27, v23, v18
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v28, v26, v29
    vf.fms       v26, v23, v24, v23
    v.lshr       v24, v28, v22
    vf.cvt.f32.e4m3 v29, v28
    s.addi       s30, s28, #112
    v.and        v28, v24, v25
    vf.neg       v24, v26                        // Newton step: r0*(2 - x*r0)
    v.or         v26, v29, v28                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s34, v4, #4
    v.st.b       [s32, #0], v26
    vf.cmp.o     p1, v24, v24
    v.splat      v26, s34
    @p1 v.sel        v28, v24, v23
    v.ld.w       v23, [s33, #0]
    vf.max.ieee  v24, v26, v20
    v.rcp.approx v26, v24                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v23, v19                   // a/y: faithful quotient
    vf.fms       v39, v29, v2, v23
    vf.fms       v2, v39, v19, v29
    vf.neg       v19, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v24, v26, v18
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v23, v19, v29
    vf.fms       v19, v26, v2, v26
    v.lshr       v2, v23, v22
    vf.cvt.f32.e4m3 v29, v23
    s.addi       s32, s28, #144
    v.and        v23, v2, v25
    vf.neg       v2, v19                         // Newton step: r0*(2 - x*r0)
    v.or         v19, v29, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s33, v4, #5
    v.st.b       [s29, #0], v19
    vf.cmp.o     p1, v2, v2
    v.splat      v19, s33
    @p1 v.sel        v23, v2, v26
    vf.max.ieee  v2, v19, v20
    v.ld.w       v19, [s35, #0]
    v.rcp.approx v26, v2                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v19, v28                   // a/y: faithful quotient
    vf.fms       v39, v29, v27, v19
    vf.fms       v19, v39, v28, v29
    vf.fms       v27, v2, v26, v18
    vf.neg       v28, v19                        // a/y: one correction to the IEEE quotient
    vf.fms       v19, v26, v27, v26
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v29
    vf.neg       v28, v19                        // Newton step: r0*(2 - x*r0)
    v.lshr       v19, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s29, s28, #176
    v.and        v27, v19, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v26
    v.or         v26, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s33, v4, #6
    s.addi       s34, s31, #576
    v.st.b       [s30, #0], v26
    v.splat      v26, s33
    v.ld.w       v27, [s35, #0]
    vf.max.ieee  v28, v26, v20
    v.rcp.approx v26, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v27, v23                   // a/y: faithful quotient
    vf.fms       v39, v29, v24, v27
    vf.fms       v24, v39, v23, v29
    vf.neg       v23, v24                        // a/y: one correction to the IEEE quotient
    vf.fms       v24, v28, v26, v18
    vf.cmp.o     p1, v23, v23
    @p1 v.sel        v27, v23, v29
    vf.fms       v23, v26, v24, v26
    v.lshr       v24, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s30, s28, #208
    v.and        v27, v24, v25
    vf.neg       v24, v23                        // Newton step: r0*(2 - x*r0)
    v.or         v23, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s33, v4, #7
    v.st.b       [s32, #0], v23
    vf.cmp.o     p1, v24, v24
    v.splat      v23, s33
    @p1 v.sel        v27, v24, v26
    v.ld.w       v24, [s35, #0]
    vf.max.ieee  v26, v23, v20
    v.rcp.approx v23, v26                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v24, v19                   // a/y: faithful quotient
    vf.fms       v39, v29, v2, v24
    vf.fms       v2, v39, v19, v29
    vf.neg       v19, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v26, v23, v18
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v24, v19, v29
    vf.fms       v19, v23, v2, v23
    v.lshr       v2, v24, v22
    vf.cvt.f32.e4m3 v29, v24
    s.addi       s32, s28, #240
    v.and        v24, v2, v25
    vf.neg       v2, v19                         // Newton step: r0*(2 - x*r0)
    v.or         v19, v29, v24                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s33, v4, #8
    v.st.b       [s29, #0], v19
    vf.cmp.o     p1, v2, v2
    v.splat      v19, s33
    @p1 v.sel        v24, v2, v23
    vf.max.ieee  v2, v19, v20
    v.ld.w       v19, [s34, #0]
    v.rcp.approx v23, v2                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v19, v27                   // a/y: faithful quotient
    vf.fms       v39, v29, v28, v19
    vf.fms       v19, v39, v27, v29
    vf.fms       v27, v2, v23, v18
    vf.neg       v28, v19                        // a/y: one correction to the IEEE quotient
    vf.fms       v19, v23, v27, v23
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v29
    vf.neg       v28, v19                        // Newton step: r0*(2 - x*r0)
    v.lshr       v19, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s29, s28, #272
    v.and        v27, v19, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v23
    v.or         v23, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s33, v4, #9
    s.addi       s35, s31, #576
    v.st.b       [s30, #0], v23
    v.splat      v23, s33
    v.ld.w       v27, [s34, #0]
    vf.max.ieee  v28, v23, v20
    v.rcp.approx v23, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v27, v24                   // a/y: faithful quotient
    vf.fms       v39, v29, v26, v27
    vf.fms       v26, v39, v24, v29
    vf.neg       v24, v26                        // a/y: one correction to the IEEE quotient
    vf.fms       v26, v28, v23, v18
    vf.cmp.o     p1, v24, v24
    @p1 v.sel        v27, v24, v29
    vf.fms       v24, v23, v26, v23
    v.lshr       v26, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s30, s28, #304
    v.and        v27, v26, v25
    vf.neg       v26, v24                        // Newton step: r0*(2 - x*r0)
    v.or         v24, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s33, v4, #10
    v.st.b       [s32, #0], v24
    vf.cmp.o     p1, v26, v26
    v.splat      v24, s33
    @p1 v.sel        v27, v26, v23
    v.ld.w       v23, [s34, #0]
    vf.max.ieee  v26, v24, v20
    v.rcp.approx v24, v26                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v23, v19                   // a/y: faithful quotient
    vf.fms       v39, v29, v2, v23
    vf.fms       v2, v39, v19, v29
    vf.neg       v19, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v26, v24, v18
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v23, v19, v29
    vf.fms       v19, v24, v2, v24
    v.lshr       v2, v23, v22
    vf.cvt.f32.e4m3 v29, v23
    s.addi       s32, s28, #336
    v.and        v23, v2, v25
    vf.neg       v2, v19                         // Newton step: r0*(2 - x*r0)
    v.or         v19, v29, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s33, v4, #11
    v.st.b       [s29, #0], v19
    vf.cmp.o     p1, v2, v2
    v.splat      v19, s33
    @p1 v.sel        v23, v2, v24
    vf.max.ieee  v2, v19, v20
    v.ld.w       v19, [s35, #0]
    v.rcp.approx v24, v2                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v19, v27                   // a/y: faithful quotient
    vf.fms       v39, v29, v28, v19
    vf.fms       v19, v39, v27, v29
    vf.fms       v27, v2, v24, v18
    vf.neg       v28, v19                        // a/y: one correction to the IEEE quotient
    vf.fms       v19, v24, v27, v24
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v29
    vf.neg       v28, v19                        // Newton step: r0*(2 - x*r0)
    v.lshr       v19, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s29, s28, #368
    v.and        v27, v19, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v24
    v.or         v24, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s33, v4, #12
    s.addi       s34, s31, #576
    v.st.b       [s30, #0], v24
    v.splat      v24, s33
    v.ld.w       v27, [s35, #0]
    vf.max.ieee  v28, v24, v20
    v.rcp.approx v24, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v27, v23                   // a/y: faithful quotient
    vf.fms       v39, v29, v26, v27
    vf.fms       v26, v39, v23, v29
    vf.neg       v23, v26                        // a/y: one correction to the IEEE quotient
    vf.fms       v26, v28, v24, v18
    vf.cmp.o     p1, v23, v23
    @p1 v.sel        v27, v23, v29
    vf.fms       v23, v24, v26, v24
    v.lshr       v26, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s30, s28, #400
    v.and        v27, v26, v25
    vf.neg       v26, v23                        // Newton step: r0*(2 - x*r0)
    v.or         v23, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s33, v4, #13
    v.st.b       [s32, #0], v23
    vf.cmp.o     p1, v26, v26
    v.splat      v23, s33
    @p1 v.sel        v27, v26, v24
    v.ld.w       v24, [s35, #0]
    vf.max.ieee  v26, v23, v20
    v.rcp.approx v23, v26                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v24, v19                   // a/y: faithful quotient
    vf.fms       v39, v29, v2, v24
    vf.fms       v2, v39, v19, v29
    vf.neg       v19, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v26, v23, v18
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v24, v19, v29
    vf.fms       v19, v23, v2, v23
    v.lshr       v2, v24, v22
    vf.cvt.f32.e4m3 v29, v24
    s.addi       s32, s28, #432
    v.and        v24, v2, v25
    vf.neg       v2, v19                         // Newton step: r0*(2 - x*r0)
    v.or         v19, v29, v24                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s33, v4, #14
    v.st.b       [s29, #0], v19
    vf.cmp.o     p1, v2, v2
    v.splat      v19, s33
    @p1 v.sel        v24, v2, v23
    vf.max.ieee  v2, v19, v20
    v.ld.w       v19, [s34, #0]
    v.rcp.approx v23, v2                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v19, v27                   // a/y: faithful quotient
    vf.fms       v39, v29, v28, v19
    vf.fms       v19, v39, v27, v29
    vf.fms       v27, v2, v23, v18
    vf.neg       v28, v19                        // a/y: one correction to the IEEE quotient
    vf.fms       v19, v23, v27, v23
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v29
    vf.neg       v28, v19                        // Newton step: r0*(2 - x*r0)
    v.lshr       v19, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s29, s28, #464
    v.and        v27, v19, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v23
    v.or         v23, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s33, v4, #15
    s.addi       s35, s31, #576
    v.st.b       [s30, #0], v23
    v.splat      v23, s33
    v.ld.w       v27, [s34, #0]
    vf.max.ieee  v28, v23, v20
    v.rcp.approx v23, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v27, v24                   // a/y: faithful quotient
    vf.fms       v39, v29, v26, v27
    vf.fms       v26, v39, v24, v29
    vf.neg       v24, v26                        // a/y: one correction to the IEEE quotient
    vf.fms       v26, v28, v23, v18
    vf.cmp.o     p1, v24, v24
    @p1 v.sel        v27, v24, v29
    vf.fms       v24, v23, v26, v23
    v.lshr       v26, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s30, s28, #496
    v.and        v27, v26, v25
    vf.neg       v26, v24                        // Newton step: r0*(2 - x*r0)
    v.or         v24, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s32, #0], v24
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v24, v26, v23
    v.ld.w       v23, [s34, #0]
    s.addi       s32, s28, #64
    s.addi       s33, s28, #128
    s.addi       s34, s28, #192
    vf.mul       v26, v23, v19                   // a/y: faithful quotient
    vf.fms       v27, v26, v2, v23
    vf.fms       v2, v27, v19, v26
    vf.neg       v19, v2                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v2, v19, v26
    v.lshr       v19, v2, v22
    vf.cvt.f32.e4m3 v23, v2
    v.and        v2, v19, v25
    v.or         v19, v23, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s29, #0], v19
    s.addi       s29, s28, #256
    v.ld.w       v2, [s35, #0]
    s.addi       s35, s28, #320
    vf.mul       v19, v2, v24                    // a/y: faithful quotient
    vf.fms       v23, v19, v28, v2
    vf.fms       v2, v23, v24, v19
    vf.neg       v23, v2                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v23, v23
    @p1 v.sel        v2, v23, v19
    v.lshr       v19, v2, v22
    vf.cvt.f32.e4m3 v23, v2
    v.and        v2, v19, v25
    v.or         v19, v23, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s30, #0], v19
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    s.addi       s30, s28, #384
    v.ld.w       v2, [s28, #0]
    s.addi       s36, s28, #448
    v.mov        v56, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s32, #0]
    v.extract    s28, v30, #2
    v.mov        v57, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s33, #0]
    v.mov        v58, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s34, #0]
    v.mov        v59, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s29, #0]
    v.mov        v60, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s35, #0]
    v.mov        v61, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s30, #0]
    v.mov        v62, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s36, #0]
    v.mov        v63, v2                         // hand off through the shared window (sec 7.3)
    mb.wait      s20
    mb.arm       s29, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s29
    mb.wait      s29
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s28, x8dot_done_31
    s.movz       s30, #0
    s.addi       s32, s31, #1664
    s.addi       s33, s30, #0
    v.ld.w       v2, [s32, #0]
    s.add        s30, s13, s24
    s.addi       s32, s31, #2304
x8dot_row_32:
    s.addi       s34, s26, #0
    v.movi       v19, #0
    s.sub        s35, s34, s33
    s.add        s34, s30, s33
    v.splat      v23, s35
    s.shli       s35, s33, #4
    s.addi       s36, s33, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s34, v2]             // index is in elements (ISA sec 9.1)
    s.add        s34, s32, s35
    s.movz       s35, #32
    v.st.b       [s34, #0], v19
    fence.acq_rel.device
    s.mov        s33, s36
    s.cmp.lt     s34, s33, s35
    br.nz        s34, x8dot_row_32
x8dot_done_31:
    v.splat      v2, s28
    v.movi       v19, #0
    mb.arm       s28, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s30, #0
    v.extract    s32, v32, #2
    v.cmp.ne     p1, v2, v19
    v.cmp.eq     p2, v2, v19
    s.mov        s33, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s33, s28            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s33, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s33, s28          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s27
    mb.arm       s32, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s33, v30, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s32
    mb.wait      s32
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s33, x8dot_done_33
    s.addi       s34, s31, #1728
    s.addi       s35, s30, #0
    v.ld.w       v2, [s34, #0]
    s.add        s34, s13, s24
    s.addi       s36, s31, #2816
x8dot_row_34:
    s.addi       s37, s26, #0
    v.movi       v19, #0
    s.sub        s38, s37, s35
    s.add        s37, s34, s35
    v.splat      v23, s38
    s.shli       s38, s35, #4
    s.addi       s39, s35, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s37, v2]             // index is in elements (ISA sec 9.1)
    s.add        s37, s36, s38
    s.movz       s38, #32
    v.st.b       [s37, #0], v19
    fence.acq_rel.device
    s.mov        s35, s39
    s.cmp.lt     s37, s35, s38
    br.nz        s37, x8dot_row_34
x8dot_done_33:
    v.splat      v2, s33
    v.movi       v19, #0
    mb.arm       s33, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s34, v32, #3
    v.cmp.ne     p1, v2, v19
    v.cmp.eq     p2, v2, v19
    s.mov        s35, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s35, s33            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s35, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s35, s33          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s28
    mb.arm       s34, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s35, v30, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s34
    mb.wait      s34
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s35, x8dot_done_35
    s.addi       s36, s31, #1792
    s.addi       s37, s30, #0
    v.ld.w       v2, [s36, #0]
    s.add        s30, s13, s24
    s.addi       s36, s31, #2304
x8dot_row_36:
    s.addi       s38, s26, #0
    v.movi       v19, #0
    s.sub        s39, s38, s37
    s.add        s38, s30, s37
    v.splat      v23, s39
    s.shli       s39, s37, #4
    s.addi       s40, s37, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s38, v2]             // index is in elements (ISA sec 9.1)
    s.add        s38, s36, s39
    s.movz       s39, #32
    v.st.b       [s38, #0], v19
    fence.acq_rel.device
    s.mov        s37, s40
    s.cmp.lt     s38, s37, s39
    br.nz        s38, x8dot_row_36
x8dot_done_35:
    v.splat      v2, s35
    v.movi       v19, #0
    mb.arm       s30, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s35, #0
    v.extract    s36, v32, #4
    v.cmp.ne     p1, v2, v19
    v.cmp.eq     p2, v2, v19
    s.mov        s37, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s37, s30            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s37, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s37, s30          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s33
    mb.arm       s36, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s37, v30, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s36
    mb.wait      s36
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s37, x8dot_done_37
    s.addi       s38, s31, #1856
    s.addi       s39, s35, #0
    v.ld.w       v2, [s38, #0]
    s.add        s38, s13, s24
    s.addi       s40, s31, #2816
x8dot_row_38:
    s.addi       s41, s26, #0
    v.movi       v19, #0
    s.sub        s42, s41, s39
    s.add        s41, s38, s39
    v.splat      v23, s42
    s.shli       s42, s39, #4
    s.addi       s43, s39, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s41, v2]             // index is in elements (ISA sec 9.1)
    s.add        s41, s40, s42
    s.movz       s42, #32
    v.st.b       [s41, #0], v19
    fence.acq_rel.device
    s.mov        s39, s43
    s.cmp.lt     s41, s39, s42
    br.nz        s41, x8dot_row_38
x8dot_done_37:
    v.splat      v2, s37
    v.movi       v19, #0
    mb.arm       s37, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s38, v32, #5
    v.cmp.ne     p1, v2, v19
    v.cmp.eq     p2, v2, v19
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s39, s37            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s39, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s39, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s30
    mb.arm       s38, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s39, v30, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s38
    mb.wait      s38
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s39, x8dot_done_39
    s.addi       s40, s31, #1920
    s.addi       s41, s35, #0
    v.ld.w       v2, [s40, #0]
    s.add        s35, s13, s24
    s.addi       s40, s31, #2304
x8dot_row_40:
    s.addi       s42, s26, #0
    v.movi       v19, #0
    s.sub        s43, s42, s41
    s.add        s42, s35, s41
    v.splat      v23, s43
    s.shli       s43, s41, #4
    s.addi       s44, s41, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s42, v2]             // index is in elements (ISA sec 9.1)
    s.add        s42, s40, s43
    s.movz       s43, #32
    v.st.b       [s42, #0], v19
    fence.acq_rel.device
    s.mov        s41, s44
    s.cmp.lt     s42, s41, s43
    br.nz        s42, x8dot_row_40
x8dot_done_39:
    v.splat      v2, s39
    v.movi       v19, #0
    mb.arm       s35, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s39, #0
    v.extract    s40, v32, #6
    v.cmp.ne     p1, v2, v19
    v.cmp.eq     p2, v2, v19
    s.mov        s41, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s41, s35            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s41, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s41, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s40, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s41, v30, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s40
    mb.wait      s40
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s41, x8dot_done_41
    s.addi       s42, s31, #1984
    s.addi       s43, s39, #0
    v.ld.w       v2, [s42, #0]
    s.add        s42, s13, s24
    s.addi       s44, s31, #2816
x8dot_row_42:
    s.addi       s45, s26, #0
    v.movi       v19, #0
    s.sub        s46, s45, s43
    s.add        s45, s42, s43
    v.splat      v23, s46
    s.shli       s46, s43, #4
    s.addi       s47, s43, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s45, v2]             // index is in elements (ISA sec 9.1)
    s.add        s45, s44, s46
    s.movz       s46, #32
    v.st.b       [s45, #0], v19
    fence.acq_rel.device
    s.mov        s43, s47
    s.cmp.lt     s45, s43, s46
    br.nz        s45, x8dot_row_42
x8dot_done_41:
    v.splat      v2, s41
    v.movi       v19, #0
    mb.arm       s41, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s42, v32, #7
    v.cmp.ne     p1, v2, v19
    v.cmp.eq     p2, v2, v19
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s43, s41            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s43, s41          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s43, v30, #0
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s42
    mb.wait      s42
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s43, x8dot_done_43
    s.addi       s44, s31, #1536
    s.add        s45, s13, s24
    s.addi       s46, s39, #0
    v.ld.w       v2, [s44, #0]
    s.addi       s39, s45, #32
    s.addi       s44, s31, #2304
x8dot_row_44:
    s.addi       s45, s26, #-32
    v.movi       v19, #0
    s.sub        s47, s45, s46
    s.add        s45, s39, s46
    v.splat      v23, s47
    s.shli       s47, s46, #4
    s.addi       s48, s46, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s45, v2]             // index is in elements (ISA sec 9.1)
    s.add        s45, s44, s47
    s.movz       s47, #32
    v.st.b       [s45, #0], v19
    fence.acq_rel.device
    s.mov        s46, s48
    s.cmp.lt     s45, s46, s47
    br.nz        s45, x8dot_row_44
x8dot_done_43:
    v.splat      v2, s43
    v.movi       v19, #0
    mb.arm       s39, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s43, #0
    v.extract    s44, v32, #0
    s.movz       s45, #32
    v.cmp.ne     p1, v2, v19
    v.cmp.eq     p2, v2, v19
    s.mov        s46, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s46, s39            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s46, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s46, s39          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s41
    mb.arm       s44, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s46, v30, #1
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s44
    mb.wait      s44
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s46, x8dot_done_45
    s.addi       s47, s31, #1600
    s.add        s48, s13, s24
    s.addi       s49, s43, #0
    v.ld.w       v2, [s47, #0]
    s.addi       s47, s48, #32
    s.addi       s48, s31, #2816
x8dot_row_46:
    s.addi       s50, s26, #-32
    v.movi       v19, #0
    s.sub        s51, s50, s49
    s.add        s50, s47, s49
    v.splat      v23, s51
    s.shli       s51, s49, #4
    s.addi       s52, s49, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s50, v2]             // index is in elements (ISA sec 9.1)
    s.add        s50, s48, s51
    v.st.b       [s50, #0], v19
    fence.acq_rel.device
    s.mov        s49, s52
    s.cmp.lt     s50, s49, s45
    br.nz        s50, x8dot_row_46
x8dot_done_45:
    v.extract    s47, v4, #0
    v.splat      v2, s46
    v.splat      v19, s47
    v.movi       v23, #0
    mb.arm       s46, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    vf.max.ieee  v24, v19, v20
    v.extract    s47, v32, #1
    s.addi       s48, s31, #640
    v.cmp.ne     p1, v2, v23
    v.cmp.eq     p2, v2, v23
    v.rcp.approx v2, v24                         // ISA 8.8: <= 2**-22 relative
    s.mov        s49, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s49, s46            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s49, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s49, s46          // predicated off still completes once (ISA sec 9A.3)
    v.ld.w       v19, [s48, #0]
    v.extract    s43, v4, #1
    s.addi       s45, s31, #4352                 // 512 bytes of repack scratch
    v.splat      v23, s43
    s.addi       s43, s45, #0
    v.extract    s47, v4, #2
    vf.max.ieee  v26, v23, v20
    v.splat      v23, s47
    s.addi       s47, s45, #32
    vf.max.ieee  v27, v23, v20
    v.rcp.approx v23, v26                        // ISA 8.8: <= 2**-22 relative
    v.rcp.approx v28, v27                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v29, v24, v2, v18
    vf.fms       v39, v2, v29, v2
    vf.neg       v29, v39                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v29, v29
    @p1 v.sel        v39, v29, v2
    vf.fms       v2, v26, v23, v18
    vf.fms       v29, v23, v2, v23
    vf.neg       v2, v29                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v29, v2, v23
    vf.mul       v2, v19, v39                    // a/y: faithful quotient
    vf.fms       v23, v2, v24, v19
    vf.fms       v19, v27, v28, v18
    vf.fms       v24, v23, v39, v2
    vf.fms       v23, v28, v19, v28
    vf.neg       v19, v24                        // a/y: one correction to the IEEE quotient
    vf.neg       v24, v23                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v23, v19, v2
    vf.cmp.o     p1, v24, v24
    @p1 v.sel        v2, v24, v28
    v.lshr       v19, v23, v22
    vf.cvt.f32.e4m3 v24, v23
    s.addi       s49, s45, #64
    v.and        v23, v19, v25
    s.addi       s50, s31, #640
    v.or         v19, v24, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s51, v4, #3
    v.st.b       [s43, #0], v19
    v.splat      v19, s51
    v.ld.w       v23, [s48, #0]
    vf.max.ieee  v24, v19, v20
    v.rcp.approx v19, v24                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v28, v23, v29                   // a/y: faithful quotient
    vf.fms       v39, v28, v26, v23
    vf.fms       v23, v39, v29, v28
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.fms       v23, v24, v19, v18
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v29, v26, v28
    vf.fms       v26, v19, v23, v19
    v.lshr       v23, v29, v22
    vf.cvt.f32.e4m3 v28, v29
    s.addi       s43, s45, #96
    v.and        v29, v23, v25
    vf.neg       v23, v26                        // Newton step: r0*(2 - x*r0)
    v.or         v26, v28, v29                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s51, v4, #4
    v.st.b       [s47, #0], v26
    vf.cmp.o     p1, v23, v23
    v.splat      v26, s51
    @p1 v.sel        v28, v23, v19
    v.ld.w       v19, [s48, #0]
    vf.max.ieee  v23, v26, v20
    v.rcp.approx v26, v23                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v19, v2                    // a/y: faithful quotient
    vf.fms       v39, v29, v27, v19
    vf.fms       v19, v39, v2, v29
    vf.neg       v2, v19                         // a/y: one correction to the IEEE quotient
    vf.fms       v19, v23, v26, v18
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v27, v2, v29
    vf.fms       v2, v26, v19, v26
    v.lshr       v19, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s47, s45, #128
    v.and        v27, v19, v25
    vf.neg       v19, v2                         // Newton step: r0*(2 - x*r0)
    v.or         v2, v29, v27                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s48, v4, #5
    v.st.b       [s49, #0], v2
    vf.cmp.o     p1, v19, v19
    v.splat      v2, s48
    @p1 v.sel        v27, v19, v26
    vf.max.ieee  v19, v2, v20
    v.ld.w       v2, [s50, #0]
    v.rcp.approx v26, v19                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v2, v28                    // a/y: faithful quotient
    vf.fms       v39, v29, v24, v2
    vf.fms       v2, v39, v28, v29
    vf.fms       v24, v19, v26, v18
    vf.neg       v28, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v26, v24, v26
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v24, v28, v29
    vf.neg       v28, v2                         // Newton step: r0*(2 - x*r0)
    v.lshr       v2, v24, v22
    vf.cvt.f32.e4m3 v29, v24
    s.addi       s48, s45, #160
    v.and        v24, v2, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v2, v28, v26
    v.or         v26, v29, v24                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s49, v4, #6
    s.addi       s51, s31, #640
    v.st.b       [s43, #0], v26
    v.splat      v24, s49
    v.ld.w       v26, [s50, #0]
    vf.max.ieee  v28, v24, v20
    v.rcp.approx v24, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v26, v27                   // a/y: faithful quotient
    vf.fms       v39, v29, v23, v26
    vf.fms       v23, v39, v27, v29
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.fms       v23, v28, v24, v18
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v27, v26, v29
    vf.fms       v26, v24, v23, v24
    v.lshr       v23, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s43, s45, #192
    v.and        v27, v23, v25
    vf.neg       v23, v26                        // Newton step: r0*(2 - x*r0)
    v.or         v26, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s49, v4, #7
    v.st.b       [s47, #0], v26
    vf.cmp.o     p1, v23, v23
    v.splat      v26, s49
    @p1 v.sel        v27, v23, v24
    v.ld.w       v23, [s50, #0]
    vf.max.ieee  v24, v26, v20
    v.rcp.approx v26, v24                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v23, v2                    // a/y: faithful quotient
    vf.fms       v39, v29, v19, v23
    vf.fms       v19, v39, v2, v29
    vf.neg       v2, v19                         // a/y: one correction to the IEEE quotient
    vf.fms       v19, v24, v26, v18
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v23, v2, v29
    vf.fms       v2, v26, v19, v26
    v.lshr       v19, v23, v22
    vf.cvt.f32.e4m3 v29, v23
    s.addi       s47, s45, #224
    v.and        v23, v19, v25
    vf.neg       v19, v2                         // Newton step: r0*(2 - x*r0)
    v.or         v2, v29, v23                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s49, v4, #8
    v.st.b       [s48, #0], v2
    vf.cmp.o     p1, v19, v19
    v.splat      v2, s49
    @p1 v.sel        v23, v19, v26
    vf.max.ieee  v19, v2, v20
    v.ld.w       v2, [s51, #0]
    v.rcp.approx v26, v19                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v2, v27                    // a/y: faithful quotient
    vf.fms       v39, v29, v28, v2
    vf.fms       v2, v39, v27, v29
    vf.fms       v27, v19, v26, v18
    vf.neg       v28, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v26, v27, v26
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v29
    vf.neg       v28, v2                         // Newton step: r0*(2 - x*r0)
    v.lshr       v2, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s48, s45, #256
    v.and        v27, v2, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v2, v28, v26
    v.or         v26, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s49, v4, #9
    s.addi       s50, s31, #640
    v.st.b       [s43, #0], v26
    v.splat      v26, s49
    v.ld.w       v27, [s51, #0]
    vf.max.ieee  v28, v26, v20
    v.rcp.approx v26, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v27, v23                   // a/y: faithful quotient
    vf.fms       v39, v29, v24, v27
    vf.fms       v24, v39, v23, v29
    vf.neg       v23, v24                        // a/y: one correction to the IEEE quotient
    vf.fms       v24, v28, v26, v18
    vf.cmp.o     p1, v23, v23
    @p1 v.sel        v27, v23, v29
    vf.fms       v23, v26, v24, v26
    v.lshr       v24, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s43, s45, #288
    v.and        v27, v24, v25
    vf.neg       v24, v23                        // Newton step: r0*(2 - x*r0)
    v.or         v23, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s49, v4, #10
    v.st.b       [s47, #0], v23
    vf.cmp.o     p1, v24, v24
    v.splat      v23, s49
    @p1 v.sel        v27, v24, v26
    v.ld.w       v24, [s51, #0]
    vf.max.ieee  v26, v23, v20
    v.rcp.approx v23, v26                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v24, v2                    // a/y: faithful quotient
    vf.fms       v39, v29, v19, v24
    vf.fms       v19, v39, v2, v29
    vf.neg       v2, v19                         // a/y: one correction to the IEEE quotient
    vf.fms       v19, v26, v23, v18
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v24, v2, v29
    vf.fms       v2, v23, v19, v23
    v.lshr       v19, v24, v22
    vf.cvt.f32.e4m3 v29, v24
    s.addi       s47, s45, #320
    v.and        v24, v19, v25
    vf.neg       v19, v2                         // Newton step: r0*(2 - x*r0)
    v.or         v2, v29, v24                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s49, v4, #11
    v.st.b       [s48, #0], v2
    vf.cmp.o     p1, v19, v19
    v.splat      v2, s49
    @p1 v.sel        v24, v19, v23
    vf.max.ieee  v19, v2, v20
    v.ld.w       v2, [s50, #0]
    v.rcp.approx v23, v19                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v2, v27                    // a/y: faithful quotient
    vf.fms       v39, v29, v28, v2
    vf.fms       v2, v39, v27, v29
    vf.fms       v27, v19, v23, v18
    vf.neg       v28, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v23, v27, v23
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v29
    vf.neg       v28, v2                         // Newton step: r0*(2 - x*r0)
    v.lshr       v2, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s48, s45, #352
    v.and        v27, v2, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v2, v28, v23
    v.or         v23, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s49, v4, #12
    s.addi       s51, s31, #640
    v.st.b       [s43, #0], v23
    v.splat      v23, s49
    v.ld.w       v27, [s50, #0]
    vf.max.ieee  v28, v23, v20
    v.rcp.approx v23, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v27, v24                   // a/y: faithful quotient
    vf.fms       v39, v29, v26, v27
    vf.fms       v26, v39, v24, v29
    vf.neg       v24, v26                        // a/y: one correction to the IEEE quotient
    vf.fms       v26, v28, v23, v18
    vf.cmp.o     p1, v24, v24
    @p1 v.sel        v27, v24, v29
    vf.fms       v24, v23, v26, v23
    v.lshr       v26, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s43, s45, #384
    v.and        v27, v26, v25
    vf.neg       v26, v24                        // Newton step: r0*(2 - x*r0)
    v.or         v24, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s49, v4, #13
    v.st.b       [s47, #0], v24
    vf.cmp.o     p1, v26, v26
    v.splat      v24, s49
    @p1 v.sel        v27, v26, v23
    v.ld.w       v23, [s50, #0]
    vf.max.ieee  v26, v24, v20
    v.rcp.approx v24, v26                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v23, v2                    // a/y: faithful quotient
    vf.fms       v39, v29, v19, v23
    vf.fms       v19, v39, v2, v29
    vf.neg       v2, v19                         // a/y: one correction to the IEEE quotient
    vf.fms       v19, v26, v24, v18
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v23, v2, v29
    vf.fms       v2, v24, v19, v24
    v.lshr       v19, v23, v22
    vf.cvt.f32.e4m3 v29, v23
    s.addi       s47, s45, #416
    v.and        v23, v19, v25
    vf.neg       v19, v2                         // Newton step: r0*(2 - x*r0)
    v.or         v2, v29, v23                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s49, v4, #14
    v.st.b       [s48, #0], v2
    vf.cmp.o     p1, v19, v19
    v.splat      v2, s49
    @p1 v.sel        v23, v19, v24
    vf.max.ieee  v19, v2, v20
    v.ld.w       v2, [s51, #0]
    v.rcp.approx v24, v19                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v2, v27                    // a/y: faithful quotient
    vf.fms       v39, v29, v28, v2
    vf.fms       v2, v39, v27, v29
    vf.fms       v27, v19, v24, v18
    vf.neg       v28, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v24, v27, v24
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v29
    vf.neg       v28, v2                         // Newton step: r0*(2 - x*r0)
    v.lshr       v2, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s48, s45, #448
    v.and        v27, v2, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v2, v28, v24
    v.or         v24, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s49, v4, #15
    s.addi       s50, s31, #640
    v.st.b       [s43, #0], v24
    v.splat      v24, s49
    v.ld.w       v27, [s51, #0]
    vf.max.ieee  v28, v24, v20
    v.rcp.approx v24, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v27, v23                   // a/y: faithful quotient
    vf.fms       v39, v29, v26, v27
    vf.fms       v26, v39, v23, v29
    vf.neg       v23, v26                        // a/y: one correction to the IEEE quotient
    vf.fms       v26, v28, v24, v18
    vf.cmp.o     p1, v23, v23
    @p1 v.sel        v27, v23, v29
    vf.fms       v23, v24, v26, v24
    v.lshr       v26, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s43, s45, #480
    v.and        v27, v26, v25
    vf.neg       v26, v23                        // Newton step: r0*(2 - x*r0)
    v.or         v23, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s31, #704
    v.st.b       [s47, #0], v23
    v.extract    s47, v4, #0
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v24
    v.ld.w       v24, [s51, #0]
    v.splat      v26, s47
    vf.max.ieee  v27, v26, v20
    v.rcp.approx v26, v27                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v24, v2                    // a/y: faithful quotient
    vf.fms       v39, v29, v19, v24
    vf.fms       v19, v39, v2, v29
    vf.neg       v2, v19                         // a/y: one correction to the IEEE quotient
    vf.fms       v19, v27, v26, v18
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v24, v2, v29
    v.lshr       v2, v24, v22
    vf.cvt.f32.e4m3 v29, v24
    vf.fms       v24, v26, v19, v26
    v.and        v19, v2, v25
    s.addi       s47, s45, #16
    v.or         v2, v29, v19                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v19, v24                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v2
    v.extract    s48, v4, #1
    vf.cmp.o     p1, v19, v19
    v.splat      v2, s48
    @p1 v.sel        v24, v19, v26
    v.ld.w       v19, [s50, #0]
    vf.max.ieee  v26, v2, v20
    v.rcp.approx v2, v26                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v19, v23                   // a/y: faithful quotient
    vf.fms       v39, v29, v28, v19
    vf.fms       v19, v39, v23, v29
    vf.neg       v23, v19                        // a/y: one correction to the IEEE quotient
    vf.fms       v19, v26, v2, v18
    vf.cmp.o     p1, v23, v23
    @p1 v.sel        v28, v23, v29
    vf.fms       v23, v2, v19, v2
    v.lshr       v19, v28, v22
    vf.cvt.f32.e4m3 v29, v28
    s.addi       s48, s45, #48
    v.and        v28, v19, v25
    vf.neg       v19, v23                        // Newton step: r0*(2 - x*r0)
    v.or         v23, v29, v28                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s50, v4, #2
    v.st.b       [s43, #0], v23
    vf.cmp.o     p1, v19, v19
    v.splat      v23, s50
    @p1 v.sel        v28, v19, v2
    vf.max.ieee  v2, v23, v20
    v.ld.w       v19, [s49, #0]
    v.rcp.approx v23, v2                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v19, v24                   // a/y: faithful quotient
    vf.fms       v39, v29, v27, v19
    vf.fms       v19, v39, v24, v29
    vf.fms       v24, v2, v23, v18
    vf.neg       v27, v19                        // a/y: one correction to the IEEE quotient
    vf.fms       v19, v23, v24, v23
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v24, v27, v29
    vf.neg       v27, v19                        // Newton step: r0*(2 - x*r0)
    v.lshr       v19, v24, v22
    vf.cvt.f32.e4m3 v29, v24
    s.addi       s43, s45, #80
    v.and        v24, v19, v25
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v19, v27, v23
    v.or         v23, v29, v24                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s50, v4, #3
    s.addi       s51, s31, #704
    v.st.b       [s47, #0], v23
    v.splat      v23, s50
    v.ld.w       v24, [s49, #0]
    vf.max.ieee  v27, v23, v20
    v.rcp.approx v23, v27                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v24, v28                   // a/y: faithful quotient
    vf.fms       v39, v29, v26, v24
    vf.fms       v24, v39, v28, v29
    vf.neg       v26, v24                        // a/y: one correction to the IEEE quotient
    vf.fms       v24, v27, v23, v18
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v28, v26, v29
    vf.fms       v26, v23, v24, v23
    v.lshr       v24, v28, v22
    vf.cvt.f32.e4m3 v29, v28
    s.addi       s47, s45, #112
    v.and        v28, v24, v25
    vf.neg       v24, v26                        // Newton step: r0*(2 - x*r0)
    v.or         v26, v29, v28                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s50, v4, #4
    v.st.b       [s48, #0], v26
    vf.cmp.o     p1, v24, v24
    v.splat      v26, s50
    @p1 v.sel        v28, v24, v23
    v.ld.w       v23, [s49, #0]
    vf.max.ieee  v24, v26, v20
    v.rcp.approx v26, v24                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v23, v19                   // a/y: faithful quotient
    vf.fms       v39, v29, v2, v23
    vf.fms       v2, v39, v19, v29
    vf.neg       v19, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v24, v26, v18
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v23, v19, v29
    vf.fms       v19, v26, v2, v26
    v.lshr       v2, v23, v22
    vf.cvt.f32.e4m3 v29, v23
    s.addi       s48, s45, #144
    v.and        v23, v2, v25
    vf.neg       v2, v19                         // Newton step: r0*(2 - x*r0)
    v.or         v19, v29, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s49, v4, #5
    v.st.b       [s43, #0], v19
    vf.cmp.o     p1, v2, v2
    v.splat      v19, s49
    @p1 v.sel        v23, v2, v26
    vf.max.ieee  v2, v19, v20
    v.ld.w       v19, [s51, #0]
    v.rcp.approx v26, v2                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v19, v28                   // a/y: faithful quotient
    vf.fms       v39, v29, v27, v19
    vf.fms       v19, v39, v28, v29
    vf.fms       v27, v2, v26, v18
    vf.neg       v28, v19                        // a/y: one correction to the IEEE quotient
    vf.fms       v19, v26, v27, v26
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v29
    vf.neg       v28, v19                        // Newton step: r0*(2 - x*r0)
    v.lshr       v19, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s43, s45, #176
    v.and        v27, v19, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v26
    v.or         v26, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s49, v4, #6
    s.addi       s50, s31, #704
    v.st.b       [s47, #0], v26
    v.splat      v26, s49
    v.ld.w       v27, [s51, #0]
    vf.max.ieee  v28, v26, v20
    v.rcp.approx v26, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v27, v23                   // a/y: faithful quotient
    vf.fms       v39, v29, v24, v27
    vf.fms       v24, v39, v23, v29
    vf.neg       v23, v24                        // a/y: one correction to the IEEE quotient
    vf.fms       v24, v28, v26, v18
    vf.cmp.o     p1, v23, v23
    @p1 v.sel        v27, v23, v29
    vf.fms       v23, v26, v24, v26
    v.lshr       v24, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s47, s45, #208
    v.and        v27, v24, v25
    vf.neg       v24, v23                        // Newton step: r0*(2 - x*r0)
    v.or         v23, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s49, v4, #7
    v.st.b       [s48, #0], v23
    vf.cmp.o     p1, v24, v24
    v.splat      v23, s49
    @p1 v.sel        v27, v24, v26
    v.ld.w       v24, [s51, #0]
    vf.max.ieee  v26, v23, v20
    v.rcp.approx v23, v26                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v24, v19                   // a/y: faithful quotient
    vf.fms       v39, v29, v2, v24
    vf.fms       v2, v39, v19, v29
    vf.neg       v19, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v26, v23, v18
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v24, v19, v29
    vf.fms       v19, v23, v2, v23
    v.lshr       v2, v24, v22
    vf.cvt.f32.e4m3 v29, v24
    s.addi       s48, s45, #240
    v.and        v24, v2, v25
    vf.neg       v2, v19                         // Newton step: r0*(2 - x*r0)
    v.or         v19, v29, v24                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s49, v4, #8
    v.st.b       [s43, #0], v19
    vf.cmp.o     p1, v2, v2
    v.splat      v19, s49
    @p1 v.sel        v24, v2, v23
    vf.max.ieee  v2, v19, v20
    v.ld.w       v19, [s50, #0]
    v.rcp.approx v23, v2                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v19, v27                   // a/y: faithful quotient
    vf.fms       v39, v29, v28, v19
    vf.fms       v19, v39, v27, v29
    vf.fms       v27, v2, v23, v18
    vf.neg       v28, v19                        // a/y: one correction to the IEEE quotient
    vf.fms       v19, v23, v27, v23
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v29
    vf.neg       v28, v19                        // Newton step: r0*(2 - x*r0)
    v.lshr       v19, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s43, s45, #272
    v.and        v27, v19, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v23
    v.or         v23, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s49, v4, #9
    s.addi       s51, s31, #704
    v.st.b       [s47, #0], v23
    v.splat      v23, s49
    v.ld.w       v27, [s50, #0]
    vf.max.ieee  v28, v23, v20
    v.rcp.approx v23, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v27, v24                   // a/y: faithful quotient
    vf.fms       v39, v29, v26, v27
    vf.fms       v26, v39, v24, v29
    vf.neg       v24, v26                        // a/y: one correction to the IEEE quotient
    vf.fms       v26, v28, v23, v18
    vf.cmp.o     p1, v24, v24
    @p1 v.sel        v27, v24, v29
    vf.fms       v24, v23, v26, v23
    v.lshr       v26, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s47, s45, #304
    v.and        v27, v26, v25
    vf.neg       v26, v24                        // Newton step: r0*(2 - x*r0)
    v.or         v24, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s49, v4, #10
    v.st.b       [s48, #0], v24
    vf.cmp.o     p1, v26, v26
    v.splat      v24, s49
    @p1 v.sel        v27, v26, v23
    v.ld.w       v23, [s50, #0]
    vf.max.ieee  v26, v24, v20
    v.rcp.approx v24, v26                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v23, v19                   // a/y: faithful quotient
    vf.fms       v39, v29, v2, v23
    vf.fms       v2, v39, v19, v29
    vf.neg       v19, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v26, v24, v18
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v23, v19, v29
    vf.fms       v19, v24, v2, v24
    v.lshr       v2, v23, v22
    vf.cvt.f32.e4m3 v29, v23
    s.addi       s48, s45, #336
    v.and        v23, v2, v25
    vf.neg       v2, v19                         // Newton step: r0*(2 - x*r0)
    v.or         v19, v29, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s49, v4, #11
    v.st.b       [s43, #0], v19
    vf.cmp.o     p1, v2, v2
    v.splat      v19, s49
    @p1 v.sel        v23, v2, v24
    vf.max.ieee  v2, v19, v20
    v.ld.w       v19, [s51, #0]
    v.rcp.approx v24, v2                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v19, v27                   // a/y: faithful quotient
    vf.fms       v39, v29, v28, v19
    vf.fms       v19, v39, v27, v29
    vf.fms       v27, v2, v24, v18
    vf.neg       v28, v19                        // a/y: one correction to the IEEE quotient
    vf.fms       v19, v24, v27, v24
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v29
    vf.neg       v28, v19                        // Newton step: r0*(2 - x*r0)
    v.lshr       v19, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s43, s45, #368
    v.and        v27, v19, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v24
    v.or         v24, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s49, v4, #12
    s.addi       s50, s31, #704
    v.st.b       [s47, #0], v24
    v.splat      v24, s49
    v.ld.w       v27, [s51, #0]
    vf.max.ieee  v28, v24, v20
    v.rcp.approx v24, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v27, v23                   // a/y: faithful quotient
    vf.fms       v39, v29, v26, v27
    vf.fms       v26, v39, v23, v29
    vf.neg       v23, v26                        // a/y: one correction to the IEEE quotient
    vf.fms       v26, v28, v24, v18
    vf.cmp.o     p1, v23, v23
    @p1 v.sel        v27, v23, v29
    vf.fms       v23, v24, v26, v24
    v.lshr       v26, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s47, s45, #400
    v.and        v27, v26, v25
    vf.neg       v26, v23                        // Newton step: r0*(2 - x*r0)
    v.or         v23, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s49, v4, #13
    v.st.b       [s48, #0], v23
    vf.cmp.o     p1, v26, v26
    v.splat      v23, s49
    @p1 v.sel        v27, v26, v24
    v.ld.w       v24, [s51, #0]
    vf.max.ieee  v26, v23, v20
    v.rcp.approx v23, v26                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v24, v19                   // a/y: faithful quotient
    vf.fms       v39, v29, v2, v24
    vf.fms       v2, v39, v19, v29
    vf.neg       v19, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v26, v23, v18
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v24, v19, v29
    vf.fms       v19, v23, v2, v23
    v.lshr       v2, v24, v22
    vf.cvt.f32.e4m3 v29, v24
    s.addi       s48, s45, #432
    v.and        v24, v2, v25
    vf.neg       v2, v19                         // Newton step: r0*(2 - x*r0)
    v.or         v19, v29, v24                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s49, v4, #14
    v.st.b       [s43, #0], v19
    vf.cmp.o     p1, v2, v2
    v.splat      v19, s49
    @p1 v.sel        v24, v2, v23
    vf.max.ieee  v2, v19, v20
    v.ld.w       v19, [s50, #0]
    v.rcp.approx v23, v2                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v19, v27                   // a/y: faithful quotient
    vf.fms       v39, v29, v28, v19
    vf.fms       v19, v39, v27, v29
    vf.fms       v27, v2, v23, v18
    vf.neg       v28, v19                        // a/y: one correction to the IEEE quotient
    vf.fms       v19, v23, v27, v23
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v29
    vf.neg       v28, v19                        // Newton step: r0*(2 - x*r0)
    v.lshr       v19, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s43, s45, #464
    v.and        v27, v19, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v23
    v.or         v23, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s49, v4, #15
    s.addi       s51, s31, #704
    v.st.b       [s47, #0], v23
    v.splat      v23, s49
    v.ld.w       v27, [s50, #0]
    vf.max.ieee  v28, v23, v20
    v.rcp.approx v23, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v27, v24                   // a/y: faithful quotient
    vf.fms       v39, v29, v26, v27
    vf.fms       v26, v39, v24, v29
    vf.neg       v24, v26                        // a/y: one correction to the IEEE quotient
    vf.fms       v26, v28, v23, v18
    vf.cmp.o     p1, v24, v24
    @p1 v.sel        v27, v24, v29
    vf.fms       v24, v23, v26, v23
    v.lshr       v26, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s47, s45, #496
    v.and        v27, v26, v25
    vf.neg       v26, v24                        // Newton step: r0*(2 - x*r0)
    v.or         v24, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s48, #0], v24
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v24, v26, v23
    v.ld.w       v23, [s50, #0]
    s.addi       s48, s45, #64
    s.addi       s49, s45, #128
    s.addi       s50, s45, #192
    vf.mul       v26, v23, v19                   // a/y: faithful quotient
    vf.fms       v27, v26, v2, v23
    vf.fms       v2, v27, v19, v26
    vf.neg       v19, v2                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v2, v19, v26
    v.lshr       v19, v2, v22
    vf.cvt.f32.e4m3 v23, v2
    v.and        v2, v19, v25
    v.or         v19, v23, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s43, #0], v19
    s.addi       s43, s45, #256
    v.ld.w       v2, [s51, #0]
    s.addi       s51, s45, #320
    vf.mul       v19, v2, v24                    // a/y: faithful quotient
    vf.fms       v23, v19, v28, v2
    vf.fms       v2, v23, v24, v19
    vf.neg       v23, v2                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v23, v23
    @p1 v.sel        v2, v23, v19
    v.lshr       v19, v2, v22
    vf.cvt.f32.e4m3 v23, v2
    v.and        v2, v19, v25
    v.or         v19, v23, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    s.addi       s47, s45, #384
    v.ld.w       v2, [s45, #0]
    s.addi       s52, s45, #448
    v.mov        v56, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s48, #0]
    v.extract    s45, v30, #2
    v.mov        v57, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s49, #0]
    v.mov        v58, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s50, #0]
    v.mov        v59, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s43, #0]
    v.mov        v60, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s51, #0]
    v.mov        v61, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s47, #0]
    v.mov        v62, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s52, #0]
    v.mov        v63, v2                         // hand off through the shared window (sec 7.3)
    mb.wait      s39
    mb.arm       s43, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s43
    mb.wait      s43
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s45, x8dot_done_47
    s.movz       s47, #0
    s.addi       s48, s31, #1664
    s.add        s49, s13, s24
    s.addi       s50, s47, #0
    v.ld.w       v2, [s48, #0]
    s.addi       s47, s49, #32
    s.addi       s48, s31, #2304
x8dot_row_48:
    s.addi       s49, s26, #-32
    v.movi       v19, #0
    s.sub        s51, s49, s50
    s.add        s49, s47, s50
    v.splat      v23, s51
    s.shli       s51, s50, #4
    s.addi       s52, s50, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s49, v2]             // index is in elements (ISA sec 9.1)
    s.add        s49, s48, s51
    s.movz       s51, #32
    v.st.b       [s49, #0], v19
    fence.acq_rel.device
    s.mov        s50, s52
    s.cmp.lt     s49, s50, s51
    br.nz        s49, x8dot_row_48
x8dot_done_47:
    v.splat      v2, s45
    v.movi       v19, #0
    mb.arm       s45, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s47, #0
    v.extract    s48, v32, #2
    s.movz       s49, #32
    v.cmp.ne     p1, v2, v19
    v.cmp.eq     p2, v2, v19
    s.mov        s50, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s50, s45            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s50, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s50, s45          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s46
    mb.arm       s48, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s50, v30, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s48
    mb.wait      s48
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s50, x8dot_done_49
    s.addi       s51, s31, #1728
    s.add        s52, s13, s24
    s.addi       s53, s47, #0
    v.ld.w       v2, [s51, #0]
    s.addi       s51, s52, #32
    s.addi       s52, s31, #2816
x8dot_row_50:
    s.addi       s54, s26, #-32
    v.movi       v19, #0
    s.sub        s55, s54, s53
    s.add        s54, s51, s53
    v.splat      v23, s55
    s.shli       s55, s53, #4
    s.addi       s56, s53, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s54, v2]             // index is in elements (ISA sec 9.1)
    s.add        s54, s52, s55
    v.st.b       [s54, #0], v19
    fence.acq_rel.device
    s.mov        s53, s56
    s.cmp.lt     s54, s53, s49
    br.nz        s54, x8dot_row_50
x8dot_done_49:
    v.splat      v2, s50
    v.movi       v19, #0
    mb.arm       s50, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s51, v32, #3
    v.cmp.ne     p1, v2, v19
    v.cmp.eq     p2, v2, v19
    s.mov        s52, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s52, s50            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s52, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s52, s50          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s45
    mb.arm       s49, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s51, v30, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s49
    mb.wait      s49
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s51, x8dot_done_51
    s.addi       s52, s31, #1792
    s.add        s53, s13, s24
    s.addi       s54, s47, #0
    v.ld.w       v2, [s52, #0]
    s.addi       s47, s53, #32
    s.addi       s52, s31, #2304
x8dot_row_52:
    s.addi       s53, s26, #-32
    v.movi       v19, #0
    s.sub        s55, s53, s54
    s.add        s53, s47, s54
    v.splat      v23, s55
    s.shli       s55, s54, #4
    s.addi       s56, s54, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s53, v2]             // index is in elements (ISA sec 9.1)
    s.add        s53, s52, s55
    s.movz       s55, #32
    v.st.b       [s53, #0], v19
    fence.acq_rel.device
    s.mov        s54, s56
    s.cmp.lt     s53, s54, s55
    br.nz        s53, x8dot_row_52
x8dot_done_51:
    v.splat      v2, s51
    v.movi       v19, #0
    mb.arm       s47, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s51, #0
    v.extract    s52, v32, #4
    s.movz       s53, #32
    v.cmp.ne     p1, v2, v19
    v.cmp.eq     p2, v2, v19
    s.mov        s54, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s54, s47            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s54, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s54, s47          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s50
    mb.arm       s52, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s54, v30, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s52
    mb.wait      s52
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s54, x8dot_done_53
    s.addi       s55, s31, #1856
    s.add        s56, s13, s24
    s.addi       s57, s51, #0
    v.ld.w       v2, [s55, #0]
    s.addi       s55, s56, #32
    s.addi       s56, s31, #2816
x8dot_row_54:
    s.addi       s58, s26, #-32
    v.movi       v19, #0
    s.sub        s59, s58, s57
    s.add        s58, s55, s57
    v.splat      v23, s59
    s.shli       s59, s57, #4
    s.addi       s60, s57, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s58, v2]             // index is in elements (ISA sec 9.1)
    s.add        s58, s56, s59
    v.st.b       [s58, #0], v19
    fence.acq_rel.device
    s.mov        s57, s60
    s.cmp.lt     s58, s57, s53
    br.nz        s58, x8dot_row_54
x8dot_done_53:
    v.splat      v2, s54
    v.movi       v19, #0
    mb.arm       s54, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s55, v32, #5
    v.cmp.ne     p1, v2, v19
    v.cmp.eq     p2, v2, v19
    s.mov        s56, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s56, s54            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s56, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s56, s54          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s47
    mb.arm       s53, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s55, v30, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s53
    mb.wait      s53
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s55, x8dot_done_55
    s.addi       s56, s31, #1920
    s.add        s57, s13, s24
    s.addi       s58, s51, #0
    v.ld.w       v2, [s56, #0]
    s.addi       s51, s57, #32
    s.addi       s56, s31, #2304
x8dot_row_56:
    s.addi       s57, s26, #-32
    v.movi       v19, #0
    s.sub        s59, s57, s58
    s.add        s57, s51, s58
    v.splat      v23, s59
    s.shli       s59, s58, #4
    s.addi       s60, s58, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s57, v2]             // index is in elements (ISA sec 9.1)
    s.add        s57, s56, s59
    s.movz       s59, #32
    v.st.b       [s57, #0], v19
    fence.acq_rel.device
    s.mov        s58, s60
    s.cmp.lt     s57, s58, s59
    br.nz        s57, x8dot_row_56
x8dot_done_55:
    v.splat      v2, s55
    v.movi       v19, #0
    mb.arm       s51, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s55, #0
    v.extract    s56, v32, #6
    s.movz       s57, #32
    v.cmp.ne     p1, v2, v19
    v.cmp.eq     p2, v2, v19
    s.mov        s58, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s59, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s58, s51            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s58, s56                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s59, s57                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s58, s51          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s54
    mb.arm       s56, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s58, v30, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s56
    mb.wait      s56
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s58, x8dot_done_57
    s.addi       s59, s31, #1984
    s.add        s60, s13, s24
    s.addi       s20, s55, #0
    v.ld.w       v2, [s59, #0]
    s.addi       s27, s60, #32
    s.addi       s28, s31, #2816
x8dot_row_58:
    s.addi       s29, s26, #-32
    v.movi       v19, #0
    s.sub        s30, s29, s20
    s.add        s29, s27, s20
    v.splat      v23, s30
    s.shli       s30, s20, #4
    s.addi       s32, s20, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s29, v2]             // index is in elements (ISA sec 9.1)
    s.add        s29, s28, s30
    v.st.b       [s29, #0], v19
    fence.acq_rel.device
    s.mov        s20, s32
    s.cmp.lt     s29, s20, s57
    br.nz        s29, x8dot_row_58
x8dot_done_57:
    v.splat      v2, s58
    v.movi       v19, #0
    mb.arm       s20, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s27, v32, #7
    v.cmp.ne     p1, v2, v19
    v.cmp.eq     p2, v2, v19
    s.mov        s28, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s29, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s28, s20            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s28, s27                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s29, s57                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s28, s20          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s51
    mb.arm       s27, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s28, v30, #0
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s27
    mb.wait      s27
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s28, x8dot_done_59
    s.addi       s29, s31, #1536
    s.add        s30, s13, s24
    s.addi       s32, s55, #0
    v.ld.w       v2, [s29, #0]
    s.addi       s29, s30, #64
    s.addi       s30, s31, #2304
x8dot_row_60:
    s.addi       s33, s26, #-64
    v.movi       v19, #0
    s.sub        s34, s33, s32
    s.add        s33, s29, s32
    v.splat      v23, s34
    s.shli       s34, s32, #4
    s.addi       s35, s32, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s33, v2]             // index is in elements (ISA sec 9.1)
    s.add        s33, s30, s34
    s.movz       s34, #32
    v.st.b       [s33, #0], v19
    fence.acq_rel.device
    s.mov        s32, s35
    s.cmp.lt     s33, s32, s34
    br.nz        s33, x8dot_row_60
x8dot_done_59:
    v.splat      v2, s28
    v.movi       v19, #0
    mb.arm       s28, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s29, #0
    v.extract    s30, v32, #0
    s.movz       s32, #64
    v.cmp.ne     p1, v2, v19
    v.cmp.eq     p2, v2, v19
    s.mov        s33, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s29                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s33, s28            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s33, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s33, s28          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s20
    mb.arm       s30, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s33, v30, #1
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s30
    mb.wait      s30
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s33, x8dot_done_61
    s.addi       s34, s31, #1600
    s.add        s35, s13, s24
    s.addi       s36, s29, #0
    v.ld.w       v2, [s34, #0]
    s.addi       s34, s35, #64
    s.addi       s35, s31, #2816
x8dot_row_62:
    s.addi       s37, s26, #-64
    v.movi       v19, #0
    s.sub        s38, s37, s36
    s.add        s37, s34, s36
    v.splat      v23, s38
    s.shli       s38, s36, #4
    s.addi       s39, s36, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s37, v2]             // index is in elements (ISA sec 9.1)
    s.add        s37, s35, s38
    s.movz       s38, #32
    v.st.b       [s37, #0], v19
    fence.acq_rel.device
    s.mov        s36, s39
    s.cmp.lt     s37, s36, s38
    br.nz        s37, x8dot_row_62
x8dot_done_61:
    v.extract    s34, v4, #0
    v.splat      v2, s33
    v.splat      v19, s34
    v.movi       v23, #0
    mb.arm       s33, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    vf.max.ieee  v24, v19, v20
    v.extract    s34, v32, #1
    s.addi       s35, s31, #768
    v.cmp.ne     p1, v2, v23
    v.cmp.eq     p2, v2, v23
    v.rcp.approx v2, v24                         // ISA 8.8: <= 2**-22 relative
    s.mov        s36, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s29                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s36, s33            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s36, s33          // predicated off still completes once (ISA sec 9A.3)
    v.ld.w       v19, [s35, #0]
    v.extract    s29, v4, #1
    s.addi       s32, s31, #4864                 // 512 bytes of repack scratch
    v.splat      v23, s29
    s.addi       s29, s32, #0
    v.extract    s34, v4, #2
    vf.max.ieee  v26, v23, v20
    v.splat      v23, s34
    s.addi       s34, s32, #32
    vf.max.ieee  v27, v23, v20
    v.rcp.approx v23, v26                        // ISA 8.8: <= 2**-22 relative
    v.rcp.approx v28, v27                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v29, v24, v2, v18
    vf.fms       v39, v2, v29, v2
    vf.neg       v29, v39                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v29, v29
    @p1 v.sel        v39, v29, v2
    vf.fms       v2, v26, v23, v18
    vf.fms       v29, v23, v2, v23
    vf.neg       v2, v29                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v29, v2, v23
    vf.mul       v2, v19, v39                    // a/y: faithful quotient
    vf.fms       v23, v2, v24, v19
    vf.fms       v19, v27, v28, v18
    vf.fms       v24, v23, v39, v2
    vf.fms       v23, v28, v19, v28
    vf.neg       v19, v24                        // a/y: one correction to the IEEE quotient
    vf.neg       v24, v23                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v23, v19, v2
    vf.cmp.o     p1, v24, v24
    @p1 v.sel        v2, v24, v28
    v.lshr       v19, v23, v22
    vf.cvt.f32.e4m3 v24, v23
    s.addi       s36, s32, #64
    v.and        v23, v19, v25
    s.addi       s37, s31, #768
    v.or         v19, v24, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s38, v4, #3
    v.st.b       [s29, #0], v19
    v.splat      v19, s38
    v.ld.w       v23, [s35, #0]
    vf.max.ieee  v24, v19, v20
    v.rcp.approx v19, v24                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v28, v23, v29                   // a/y: faithful quotient
    vf.fms       v39, v28, v26, v23
    vf.fms       v23, v39, v29, v28
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.fms       v23, v24, v19, v18
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v29, v26, v28
    vf.fms       v26, v19, v23, v19
    v.lshr       v23, v29, v22
    vf.cvt.f32.e4m3 v28, v29
    s.addi       s29, s32, #96
    v.and        v29, v23, v25
    vf.neg       v23, v26                        // Newton step: r0*(2 - x*r0)
    v.or         v26, v28, v29                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s38, v4, #4
    v.st.b       [s34, #0], v26
    vf.cmp.o     p1, v23, v23
    v.splat      v26, s38
    @p1 v.sel        v28, v23, v19
    v.ld.w       v19, [s35, #0]
    vf.max.ieee  v23, v26, v20
    v.rcp.approx v26, v23                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v19, v2                    // a/y: faithful quotient
    vf.fms       v39, v29, v27, v19
    vf.fms       v19, v39, v2, v29
    vf.neg       v2, v19                         // a/y: one correction to the IEEE quotient
    vf.fms       v19, v23, v26, v18
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v27, v2, v29
    vf.fms       v2, v26, v19, v26
    v.lshr       v19, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s34, s32, #128
    v.and        v27, v19, v25
    vf.neg       v19, v2                         // Newton step: r0*(2 - x*r0)
    v.or         v2, v29, v27                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s35, v4, #5
    v.st.b       [s36, #0], v2
    vf.cmp.o     p1, v19, v19
    v.splat      v2, s35
    @p1 v.sel        v27, v19, v26
    vf.max.ieee  v19, v2, v20
    v.ld.w       v2, [s37, #0]
    v.rcp.approx v26, v19                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v2, v28                    // a/y: faithful quotient
    vf.fms       v39, v29, v24, v2
    vf.fms       v2, v39, v28, v29
    vf.fms       v24, v19, v26, v18
    vf.neg       v28, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v26, v24, v26
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v24, v28, v29
    vf.neg       v28, v2                         // Newton step: r0*(2 - x*r0)
    v.lshr       v2, v24, v22
    vf.cvt.f32.e4m3 v29, v24
    s.addi       s35, s32, #160
    v.and        v24, v2, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v2, v28, v26
    v.or         v26, v29, v24                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s36, v4, #6
    s.addi       s38, s31, #768
    v.st.b       [s29, #0], v26
    v.splat      v24, s36
    v.ld.w       v26, [s37, #0]
    vf.max.ieee  v28, v24, v20
    v.rcp.approx v24, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v26, v27                   // a/y: faithful quotient
    vf.fms       v39, v29, v23, v26
    vf.fms       v23, v39, v27, v29
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.fms       v23, v28, v24, v18
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v27, v26, v29
    vf.fms       v26, v24, v23, v24
    v.lshr       v23, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s29, s32, #192
    v.and        v27, v23, v25
    vf.neg       v23, v26                        // Newton step: r0*(2 - x*r0)
    v.or         v26, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s36, v4, #7
    v.st.b       [s34, #0], v26
    vf.cmp.o     p1, v23, v23
    v.splat      v26, s36
    @p1 v.sel        v27, v23, v24
    v.ld.w       v23, [s37, #0]
    vf.max.ieee  v24, v26, v20
    v.rcp.approx v26, v24                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v23, v2                    // a/y: faithful quotient
    vf.fms       v39, v29, v19, v23
    vf.fms       v19, v39, v2, v29
    vf.neg       v2, v19                         // a/y: one correction to the IEEE quotient
    vf.fms       v19, v24, v26, v18
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v23, v2, v29
    vf.fms       v2, v26, v19, v26
    v.lshr       v19, v23, v22
    vf.cvt.f32.e4m3 v29, v23
    s.addi       s34, s32, #224
    v.and        v23, v19, v25
    vf.neg       v19, v2                         // Newton step: r0*(2 - x*r0)
    v.or         v2, v29, v23                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s36, v4, #8
    v.st.b       [s35, #0], v2
    vf.cmp.o     p1, v19, v19
    v.splat      v2, s36
    @p1 v.sel        v23, v19, v26
    vf.max.ieee  v19, v2, v20
    v.ld.w       v2, [s38, #0]
    v.rcp.approx v26, v19                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v2, v27                    // a/y: faithful quotient
    vf.fms       v39, v29, v28, v2
    vf.fms       v2, v39, v27, v29
    vf.fms       v27, v19, v26, v18
    vf.neg       v28, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v26, v27, v26
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v29
    vf.neg       v28, v2                         // Newton step: r0*(2 - x*r0)
    v.lshr       v2, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s35, s32, #256
    v.and        v27, v2, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v2, v28, v26
    v.or         v26, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s36, v4, #9
    s.addi       s37, s31, #768
    v.st.b       [s29, #0], v26
    v.splat      v26, s36
    v.ld.w       v27, [s38, #0]
    vf.max.ieee  v28, v26, v20
    v.rcp.approx v26, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v27, v23                   // a/y: faithful quotient
    vf.fms       v39, v29, v24, v27
    vf.fms       v24, v39, v23, v29
    vf.neg       v23, v24                        // a/y: one correction to the IEEE quotient
    vf.fms       v24, v28, v26, v18
    vf.cmp.o     p1, v23, v23
    @p1 v.sel        v27, v23, v29
    vf.fms       v23, v26, v24, v26
    v.lshr       v24, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s29, s32, #288
    v.and        v27, v24, v25
    vf.neg       v24, v23                        // Newton step: r0*(2 - x*r0)
    v.or         v23, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s36, v4, #10
    v.st.b       [s34, #0], v23
    vf.cmp.o     p1, v24, v24
    v.splat      v23, s36
    @p1 v.sel        v27, v24, v26
    v.ld.w       v24, [s38, #0]
    vf.max.ieee  v26, v23, v20
    v.rcp.approx v23, v26                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v24, v2                    // a/y: faithful quotient
    vf.fms       v39, v29, v19, v24
    vf.fms       v19, v39, v2, v29
    vf.neg       v2, v19                         // a/y: one correction to the IEEE quotient
    vf.fms       v19, v26, v23, v18
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v24, v2, v29
    vf.fms       v2, v23, v19, v23
    v.lshr       v19, v24, v22
    vf.cvt.f32.e4m3 v29, v24
    s.addi       s34, s32, #320
    v.and        v24, v19, v25
    vf.neg       v19, v2                         // Newton step: r0*(2 - x*r0)
    v.or         v2, v29, v24                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s36, v4, #11
    v.st.b       [s35, #0], v2
    vf.cmp.o     p1, v19, v19
    v.splat      v2, s36
    @p1 v.sel        v24, v19, v23
    vf.max.ieee  v19, v2, v20
    v.ld.w       v2, [s37, #0]
    v.rcp.approx v23, v19                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v2, v27                    // a/y: faithful quotient
    vf.fms       v39, v29, v28, v2
    vf.fms       v2, v39, v27, v29
    vf.fms       v27, v19, v23, v18
    vf.neg       v28, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v23, v27, v23
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v29
    vf.neg       v28, v2                         // Newton step: r0*(2 - x*r0)
    v.lshr       v2, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s35, s32, #352
    v.and        v27, v2, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v2, v28, v23
    v.or         v23, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s36, v4, #12
    s.addi       s38, s31, #768
    v.st.b       [s29, #0], v23
    v.splat      v23, s36
    v.ld.w       v27, [s37, #0]
    vf.max.ieee  v28, v23, v20
    v.rcp.approx v23, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v27, v24                   // a/y: faithful quotient
    vf.fms       v39, v29, v26, v27
    vf.fms       v26, v39, v24, v29
    vf.neg       v24, v26                        // a/y: one correction to the IEEE quotient
    vf.fms       v26, v28, v23, v18
    vf.cmp.o     p1, v24, v24
    @p1 v.sel        v27, v24, v29
    vf.fms       v24, v23, v26, v23
    v.lshr       v26, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s29, s32, #384
    v.and        v27, v26, v25
    vf.neg       v26, v24                        // Newton step: r0*(2 - x*r0)
    v.or         v24, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s36, v4, #13
    v.st.b       [s34, #0], v24
    vf.cmp.o     p1, v26, v26
    v.splat      v24, s36
    @p1 v.sel        v27, v26, v23
    v.ld.w       v23, [s37, #0]
    vf.max.ieee  v26, v24, v20
    v.rcp.approx v24, v26                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v23, v2                    // a/y: faithful quotient
    vf.fms       v39, v29, v19, v23
    vf.fms       v19, v39, v2, v29
    vf.neg       v2, v19                         // a/y: one correction to the IEEE quotient
    vf.fms       v19, v26, v24, v18
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v23, v2, v29
    vf.fms       v2, v24, v19, v24
    v.lshr       v19, v23, v22
    vf.cvt.f32.e4m3 v29, v23
    s.addi       s34, s32, #416
    v.and        v23, v19, v25
    vf.neg       v19, v2                         // Newton step: r0*(2 - x*r0)
    v.or         v2, v29, v23                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s36, v4, #14
    v.st.b       [s35, #0], v2
    vf.cmp.o     p1, v19, v19
    v.splat      v2, s36
    @p1 v.sel        v23, v19, v24
    vf.max.ieee  v19, v2, v20
    v.ld.w       v2, [s38, #0]
    v.rcp.approx v24, v19                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v2, v27                    // a/y: faithful quotient
    vf.fms       v39, v29, v28, v2
    vf.fms       v2, v39, v27, v29
    vf.fms       v27, v19, v24, v18
    vf.neg       v28, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v24, v27, v24
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v29
    vf.neg       v28, v2                         // Newton step: r0*(2 - x*r0)
    v.lshr       v2, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s35, s32, #448
    v.and        v27, v2, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v2, v28, v24
    v.or         v24, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s36, v4, #15
    s.addi       s37, s31, #768
    v.st.b       [s29, #0], v24
    v.splat      v24, s36
    v.ld.w       v27, [s38, #0]
    vf.max.ieee  v28, v24, v20
    v.rcp.approx v24, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v27, v23                   // a/y: faithful quotient
    vf.fms       v39, v29, v26, v27
    vf.fms       v26, v39, v23, v29
    vf.neg       v23, v26                        // a/y: one correction to the IEEE quotient
    vf.fms       v26, v28, v24, v18
    vf.cmp.o     p1, v23, v23
    @p1 v.sel        v27, v23, v29
    vf.fms       v23, v24, v26, v24
    v.lshr       v26, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s29, s32, #480
    v.and        v27, v26, v25
    vf.neg       v26, v23                        // Newton step: r0*(2 - x*r0)
    v.or         v23, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s36, s31, #832
    v.st.b       [s34, #0], v23
    v.extract    s34, v4, #0
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v24
    v.ld.w       v24, [s38, #0]
    v.splat      v26, s34
    vf.max.ieee  v27, v26, v20
    v.rcp.approx v26, v27                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v24, v2                    // a/y: faithful quotient
    vf.fms       v39, v29, v19, v24
    vf.fms       v19, v39, v2, v29
    vf.neg       v2, v19                         // a/y: one correction to the IEEE quotient
    vf.fms       v19, v27, v26, v18
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v24, v2, v29
    v.lshr       v2, v24, v22
    vf.cvt.f32.e4m3 v29, v24
    vf.fms       v24, v26, v19, v26
    v.and        v19, v2, v25
    s.addi       s34, s32, #16
    v.or         v2, v29, v19                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v19, v24                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s35, #0], v2
    v.extract    s35, v4, #1
    vf.cmp.o     p1, v19, v19
    v.splat      v2, s35
    @p1 v.sel        v24, v19, v26
    v.ld.w       v19, [s37, #0]
    vf.max.ieee  v26, v2, v20
    v.rcp.approx v2, v26                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v19, v23                   // a/y: faithful quotient
    vf.fms       v39, v29, v28, v19
    vf.fms       v19, v39, v23, v29
    vf.neg       v23, v19                        // a/y: one correction to the IEEE quotient
    vf.fms       v19, v26, v2, v18
    vf.cmp.o     p1, v23, v23
    @p1 v.sel        v28, v23, v29
    vf.fms       v23, v2, v19, v2
    v.lshr       v19, v28, v22
    vf.cvt.f32.e4m3 v29, v28
    s.addi       s35, s32, #48
    v.and        v28, v19, v25
    vf.neg       v19, v23                        // Newton step: r0*(2 - x*r0)
    v.or         v23, v29, v28                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s37, v4, #2
    v.st.b       [s29, #0], v23
    vf.cmp.o     p1, v19, v19
    v.splat      v23, s37
    @p1 v.sel        v28, v19, v2
    vf.max.ieee  v2, v23, v20
    v.ld.w       v19, [s36, #0]
    v.rcp.approx v23, v2                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v19, v24                   // a/y: faithful quotient
    vf.fms       v39, v29, v27, v19
    vf.fms       v19, v39, v24, v29
    vf.fms       v24, v2, v23, v18
    vf.neg       v27, v19                        // a/y: one correction to the IEEE quotient
    vf.fms       v19, v23, v24, v23
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v24, v27, v29
    vf.neg       v27, v19                        // Newton step: r0*(2 - x*r0)
    v.lshr       v19, v24, v22
    vf.cvt.f32.e4m3 v29, v24
    s.addi       s29, s32, #80
    v.and        v24, v19, v25
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v19, v27, v23
    v.or         v23, v29, v24                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s37, v4, #3
    s.addi       s38, s31, #832
    v.st.b       [s34, #0], v23
    v.splat      v23, s37
    v.ld.w       v24, [s36, #0]
    vf.max.ieee  v27, v23, v20
    v.rcp.approx v23, v27                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v24, v28                   // a/y: faithful quotient
    vf.fms       v39, v29, v26, v24
    vf.fms       v24, v39, v28, v29
    vf.neg       v26, v24                        // a/y: one correction to the IEEE quotient
    vf.fms       v24, v27, v23, v18
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v28, v26, v29
    vf.fms       v26, v23, v24, v23
    v.lshr       v24, v28, v22
    vf.cvt.f32.e4m3 v29, v28
    s.addi       s34, s32, #112
    v.and        v28, v24, v25
    vf.neg       v24, v26                        // Newton step: r0*(2 - x*r0)
    v.or         v26, v29, v28                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s37, v4, #4
    v.st.b       [s35, #0], v26
    vf.cmp.o     p1, v24, v24
    v.splat      v26, s37
    @p1 v.sel        v28, v24, v23
    v.ld.w       v23, [s36, #0]
    vf.max.ieee  v24, v26, v20
    v.rcp.approx v26, v24                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v23, v19                   // a/y: faithful quotient
    vf.fms       v39, v29, v2, v23
    vf.fms       v2, v39, v19, v29
    vf.neg       v19, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v24, v26, v18
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v23, v19, v29
    vf.fms       v19, v26, v2, v26
    v.lshr       v2, v23, v22
    vf.cvt.f32.e4m3 v29, v23
    s.addi       s35, s32, #144
    v.and        v23, v2, v25
    vf.neg       v2, v19                         // Newton step: r0*(2 - x*r0)
    v.or         v19, v29, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s36, v4, #5
    v.st.b       [s29, #0], v19
    vf.cmp.o     p1, v2, v2
    v.splat      v19, s36
    @p1 v.sel        v23, v2, v26
    vf.max.ieee  v2, v19, v20
    v.ld.w       v19, [s38, #0]
    v.rcp.approx v26, v2                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v19, v28                   // a/y: faithful quotient
    vf.fms       v39, v29, v27, v19
    vf.fms       v19, v39, v28, v29
    vf.fms       v27, v2, v26, v18
    vf.neg       v28, v19                        // a/y: one correction to the IEEE quotient
    vf.fms       v19, v26, v27, v26
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v29
    vf.neg       v28, v19                        // Newton step: r0*(2 - x*r0)
    v.lshr       v19, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s29, s32, #176
    v.and        v27, v19, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v26
    v.or         v26, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s36, v4, #6
    s.addi       s37, s31, #832
    v.st.b       [s34, #0], v26
    v.splat      v26, s36
    v.ld.w       v27, [s38, #0]
    vf.max.ieee  v28, v26, v20
    v.rcp.approx v26, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v27, v23                   // a/y: faithful quotient
    vf.fms       v39, v29, v24, v27
    vf.fms       v24, v39, v23, v29
    vf.neg       v23, v24                        // a/y: one correction to the IEEE quotient
    vf.fms       v24, v28, v26, v18
    vf.cmp.o     p1, v23, v23
    @p1 v.sel        v27, v23, v29
    vf.fms       v23, v26, v24, v26
    v.lshr       v24, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s34, s32, #208
    v.and        v27, v24, v25
    vf.neg       v24, v23                        // Newton step: r0*(2 - x*r0)
    v.or         v23, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s36, v4, #7
    v.st.b       [s35, #0], v23
    vf.cmp.o     p1, v24, v24
    v.splat      v23, s36
    @p1 v.sel        v27, v24, v26
    v.ld.w       v24, [s38, #0]
    vf.max.ieee  v26, v23, v20
    v.rcp.approx v23, v26                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v24, v19                   // a/y: faithful quotient
    vf.fms       v39, v29, v2, v24
    vf.fms       v2, v39, v19, v29
    vf.neg       v19, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v26, v23, v18
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v24, v19, v29
    vf.fms       v19, v23, v2, v23
    v.lshr       v2, v24, v22
    vf.cvt.f32.e4m3 v29, v24
    s.addi       s35, s32, #240
    v.and        v24, v2, v25
    vf.neg       v2, v19                         // Newton step: r0*(2 - x*r0)
    v.or         v19, v29, v24                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s36, v4, #8
    v.st.b       [s29, #0], v19
    vf.cmp.o     p1, v2, v2
    v.splat      v19, s36
    @p1 v.sel        v24, v2, v23
    vf.max.ieee  v2, v19, v20
    v.ld.w       v19, [s37, #0]
    v.rcp.approx v23, v2                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v19, v27                   // a/y: faithful quotient
    vf.fms       v39, v29, v28, v19
    vf.fms       v19, v39, v27, v29
    vf.fms       v27, v2, v23, v18
    vf.neg       v28, v19                        // a/y: one correction to the IEEE quotient
    vf.fms       v19, v23, v27, v23
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v29
    vf.neg       v28, v19                        // Newton step: r0*(2 - x*r0)
    v.lshr       v19, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s29, s32, #272
    v.and        v27, v19, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v23
    v.or         v23, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s36, v4, #9
    s.addi       s38, s31, #832
    v.st.b       [s34, #0], v23
    v.splat      v23, s36
    v.ld.w       v27, [s37, #0]
    vf.max.ieee  v28, v23, v20
    v.rcp.approx v23, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v27, v24                   // a/y: faithful quotient
    vf.fms       v39, v29, v26, v27
    vf.fms       v26, v39, v24, v29
    vf.neg       v24, v26                        // a/y: one correction to the IEEE quotient
    vf.fms       v26, v28, v23, v18
    vf.cmp.o     p1, v24, v24
    @p1 v.sel        v27, v24, v29
    vf.fms       v24, v23, v26, v23
    v.lshr       v26, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s34, s32, #304
    v.and        v27, v26, v25
    vf.neg       v26, v24                        // Newton step: r0*(2 - x*r0)
    v.or         v24, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s36, v4, #10
    v.st.b       [s35, #0], v24
    vf.cmp.o     p1, v26, v26
    v.splat      v24, s36
    @p1 v.sel        v27, v26, v23
    v.ld.w       v23, [s37, #0]
    vf.max.ieee  v26, v24, v20
    v.rcp.approx v24, v26                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v23, v19                   // a/y: faithful quotient
    vf.fms       v39, v29, v2, v23
    vf.fms       v2, v39, v19, v29
    vf.neg       v19, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v26, v24, v18
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v23, v19, v29
    vf.fms       v19, v24, v2, v24
    v.lshr       v2, v23, v22
    vf.cvt.f32.e4m3 v29, v23
    s.addi       s35, s32, #336
    v.and        v23, v2, v25
    vf.neg       v2, v19                         // Newton step: r0*(2 - x*r0)
    v.or         v19, v29, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s36, v4, #11
    v.st.b       [s29, #0], v19
    vf.cmp.o     p1, v2, v2
    v.splat      v19, s36
    @p1 v.sel        v23, v2, v24
    vf.max.ieee  v2, v19, v20
    v.ld.w       v19, [s38, #0]
    v.rcp.approx v24, v2                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v19, v27                   // a/y: faithful quotient
    vf.fms       v39, v29, v28, v19
    vf.fms       v19, v39, v27, v29
    vf.fms       v27, v2, v24, v18
    vf.neg       v28, v19                        // a/y: one correction to the IEEE quotient
    vf.fms       v19, v24, v27, v24
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v29
    vf.neg       v28, v19                        // Newton step: r0*(2 - x*r0)
    v.lshr       v19, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s29, s32, #368
    v.and        v27, v19, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v24
    v.or         v24, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s36, v4, #12
    s.addi       s37, s31, #832
    v.st.b       [s34, #0], v24
    v.splat      v24, s36
    v.ld.w       v27, [s38, #0]
    vf.max.ieee  v28, v24, v20
    v.rcp.approx v24, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v27, v23                   // a/y: faithful quotient
    vf.fms       v39, v29, v26, v27
    vf.fms       v26, v39, v23, v29
    vf.neg       v23, v26                        // a/y: one correction to the IEEE quotient
    vf.fms       v26, v28, v24, v18
    vf.cmp.o     p1, v23, v23
    @p1 v.sel        v27, v23, v29
    vf.fms       v23, v24, v26, v24
    v.lshr       v26, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s34, s32, #400
    v.and        v27, v26, v25
    vf.neg       v26, v23                        // Newton step: r0*(2 - x*r0)
    v.or         v23, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s36, v4, #13
    v.st.b       [s35, #0], v23
    vf.cmp.o     p1, v26, v26
    v.splat      v23, s36
    @p1 v.sel        v27, v26, v24
    v.ld.w       v24, [s38, #0]
    vf.max.ieee  v26, v23, v20
    v.rcp.approx v23, v26                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v24, v19                   // a/y: faithful quotient
    vf.fms       v39, v29, v2, v24
    vf.fms       v2, v39, v19, v29
    vf.neg       v19, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v26, v23, v18
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v24, v19, v29
    vf.fms       v19, v23, v2, v23
    v.lshr       v2, v24, v22
    vf.cvt.f32.e4m3 v29, v24
    s.addi       s35, s32, #432
    v.and        v24, v2, v25
    vf.neg       v2, v19                         // Newton step: r0*(2 - x*r0)
    v.or         v19, v29, v24                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s36, v4, #14
    v.st.b       [s29, #0], v19
    vf.cmp.o     p1, v2, v2
    v.splat      v19, s36
    @p1 v.sel        v24, v2, v23
    vf.max.ieee  v2, v19, v20
    v.ld.w       v19, [s37, #0]
    v.rcp.approx v23, v2                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v19, v27                   // a/y: faithful quotient
    vf.fms       v39, v29, v28, v19
    vf.fms       v19, v39, v27, v29
    vf.fms       v27, v2, v23, v18
    vf.neg       v28, v19                        // a/y: one correction to the IEEE quotient
    vf.fms       v19, v23, v27, v23
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v29
    vf.neg       v28, v19                        // Newton step: r0*(2 - x*r0)
    v.lshr       v19, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s29, s32, #464
    v.and        v27, v19, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v23
    v.or         v23, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s36, v4, #15
    s.addi       s38, s31, #832
    v.st.b       [s34, #0], v23
    v.splat      v23, s36
    v.ld.w       v27, [s37, #0]
    vf.max.ieee  v28, v23, v20
    v.rcp.approx v23, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v27, v24                   // a/y: faithful quotient
    vf.fms       v39, v29, v26, v27
    vf.fms       v26, v39, v24, v29
    vf.neg       v24, v26                        // a/y: one correction to the IEEE quotient
    vf.fms       v26, v28, v23, v18
    vf.cmp.o     p1, v24, v24
    @p1 v.sel        v27, v24, v29
    vf.fms       v24, v23, v26, v23
    v.lshr       v26, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s34, s32, #496
    v.and        v27, v26, v25
    vf.neg       v26, v24                        // Newton step: r0*(2 - x*r0)
    v.or         v24, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v24
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v24, v26, v23
    v.ld.w       v23, [s37, #0]
    s.addi       s35, s32, #64
    s.addi       s36, s32, #128
    s.addi       s37, s32, #192
    vf.mul       v26, v23, v19                   // a/y: faithful quotient
    vf.fms       v27, v26, v2, v23
    vf.fms       v2, v27, v19, v26
    vf.neg       v19, v2                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v2, v19, v26
    v.lshr       v19, v2, v22
    vf.cvt.f32.e4m3 v23, v2
    v.and        v2, v19, v25
    v.or         v19, v23, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s29, #0], v19
    s.addi       s29, s32, #256
    v.ld.w       v2, [s38, #0]
    s.addi       s38, s32, #320
    vf.mul       v19, v2, v24                    // a/y: faithful quotient
    vf.fms       v23, v19, v28, v2
    vf.fms       v2, v23, v24, v19
    vf.neg       v23, v2                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v23, v23
    @p1 v.sel        v2, v23, v19
    v.lshr       v19, v2, v22
    vf.cvt.f32.e4m3 v23, v2
    v.and        v2, v19, v25
    v.or         v19, v23, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s34, #0], v19
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    s.addi       s34, s32, #384
    v.ld.w       v2, [s32, #0]
    s.addi       s39, s32, #448
    v.mov        v56, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s35, #0]
    v.extract    s32, v30, #2
    v.mov        v57, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s36, #0]
    v.mov        v58, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s37, #0]
    v.mov        v59, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s29, #0]
    v.mov        v60, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s38, #0]
    v.mov        v61, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s34, #0]
    v.mov        v62, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s39, #0]
    v.mov        v63, v2                         // hand off through the shared window (sec 7.3)
    mb.wait      s28
    mb.arm       s29, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s29
    mb.wait      s29
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s32, x8dot_done_63
    s.movz       s34, #0
    s.addi       s35, s31, #1664
    s.add        s36, s13, s24
    s.addi       s37, s34, #0
    v.ld.w       v2, [s35, #0]
    s.addi       s34, s36, #64
    s.addi       s35, s31, #2304
x8dot_row_64:
    s.addi       s36, s26, #-64
    v.movi       v19, #0
    s.sub        s38, s36, s37
    s.add        s36, s34, s37
    v.splat      v23, s38
    s.shli       s38, s37, #4
    s.addi       s39, s37, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s36, v2]             // index is in elements (ISA sec 9.1)
    s.add        s36, s35, s38
    s.movz       s38, #32
    v.st.b       [s36, #0], v19
    fence.acq_rel.device
    s.mov        s37, s39
    s.cmp.lt     s36, s37, s38
    br.nz        s36, x8dot_row_64
x8dot_done_63:
    v.splat      v2, s32
    v.movi       v19, #0
    mb.arm       s32, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s34, #0
    v.extract    s35, v32, #2
    s.movz       s36, #64
    v.cmp.ne     p1, v2, v19
    v.cmp.eq     p2, v2, v19
    s.mov        s37, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s37, s32            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s37, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s37, s32          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s33
    mb.arm       s35, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s37, v30, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s35
    mb.wait      s35
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s37, x8dot_done_65
    s.addi       s38, s31, #1728
    s.add        s39, s13, s24
    s.addi       s40, s34, #0
    v.ld.w       v2, [s38, #0]
    s.addi       s38, s39, #64
    s.addi       s39, s31, #2816
x8dot_row_66:
    s.addi       s41, s26, #-64
    v.movi       v19, #0
    s.sub        s42, s41, s40
    s.add        s41, s38, s40
    v.splat      v23, s42
    s.shli       s42, s40, #4
    s.addi       s43, s40, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s41, v2]             // index is in elements (ISA sec 9.1)
    s.add        s41, s39, s42
    s.movz       s42, #32
    v.st.b       [s41, #0], v19
    fence.acq_rel.device
    s.mov        s40, s43
    s.cmp.lt     s41, s40, s42
    br.nz        s41, x8dot_row_66
x8dot_done_65:
    v.splat      v2, s37
    v.movi       v19, #0
    mb.arm       s37, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s38, v32, #3
    v.cmp.ne     p1, v2, v19
    v.cmp.eq     p2, v2, v19
    s.mov        s39, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s39, s37            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s39, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s39, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s32
    mb.arm       s36, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s38, v30, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s36
    mb.wait      s36
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s38, x8dot_done_67
    s.addi       s39, s31, #1792
    s.add        s40, s13, s24
    s.addi       s41, s34, #0
    v.ld.w       v2, [s39, #0]
    s.addi       s34, s40, #64
    s.addi       s39, s31, #2304
x8dot_row_68:
    s.addi       s40, s26, #-64
    v.movi       v19, #0
    s.sub        s42, s40, s41
    s.add        s40, s34, s41
    v.splat      v23, s42
    s.shli       s42, s41, #4
    s.addi       s43, s41, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s40, v2]             // index is in elements (ISA sec 9.1)
    s.add        s40, s39, s42
    s.movz       s42, #32
    v.st.b       [s40, #0], v19
    fence.acq_rel.device
    s.mov        s41, s43
    s.cmp.lt     s40, s41, s42
    br.nz        s40, x8dot_row_68
x8dot_done_67:
    v.splat      v2, s38
    v.movi       v19, #0
    mb.arm       s34, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s38, #0
    v.extract    s39, v32, #4
    s.movz       s40, #64
    v.cmp.ne     p1, v2, v19
    v.cmp.eq     p2, v2, v19
    s.mov        s41, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s41, s34            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s41, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s41, s34          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s39, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s41, v30, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s39
    mb.wait      s39
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s41, x8dot_done_69
    s.addi       s42, s31, #1856
    s.add        s43, s13, s24
    s.addi       s44, s38, #0
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s43, #64
    s.addi       s43, s31, #2816
x8dot_row_70:
    s.addi       s45, s26, #-64
    v.movi       v19, #0
    s.sub        s46, s45, s44
    s.add        s45, s42, s44
    v.splat      v23, s46
    s.shli       s46, s44, #4
    s.addi       s47, s44, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s45, v2]             // index is in elements (ISA sec 9.1)
    s.add        s45, s43, s46
    s.movz       s46, #32
    v.st.b       [s45, #0], v19
    fence.acq_rel.device
    s.mov        s44, s47
    s.cmp.lt     s45, s44, s46
    br.nz        s45, x8dot_row_70
x8dot_done_69:
    v.splat      v2, s41
    v.movi       v19, #0
    mb.arm       s41, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s42, v32, #5
    v.cmp.ne     p1, v2, v19
    v.cmp.eq     p2, v2, v19
    s.mov        s43, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s43, s41            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s43, s41          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s34
    mb.arm       s40, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s42, v30, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s40
    mb.wait      s40
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s42, x8dot_done_71
    s.addi       s43, s31, #1920
    s.add        s44, s13, s24
    s.addi       s45, s38, #0
    v.ld.w       v2, [s43, #0]
    s.addi       s38, s44, #64
    s.addi       s43, s31, #2304
x8dot_row_72:
    s.addi       s44, s26, #-64
    v.movi       v19, #0
    s.sub        s46, s44, s45
    s.add        s44, s38, s45
    v.splat      v23, s46
    s.shli       s46, s45, #4
    s.addi       s47, s45, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s44, v2]             // index is in elements (ISA sec 9.1)
    s.add        s44, s43, s46
    s.movz       s46, #32
    v.st.b       [s44, #0], v19
    fence.acq_rel.device
    s.mov        s45, s47
    s.cmp.lt     s44, s45, s46
    br.nz        s44, x8dot_row_72
x8dot_done_71:
    v.splat      v2, s42
    v.movi       v19, #0
    mb.arm       s38, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s42, #0
    v.extract    s43, v32, #6
    s.movz       s44, #64
    v.cmp.ne     p1, v2, v19
    v.cmp.eq     p2, v2, v19
    s.mov        s45, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s45, s38            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s45, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s45, s38          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s41
    mb.arm       s43, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s45, v30, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s43
    mb.wait      s43
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s45, x8dot_done_73
    s.addi       s46, s31, #1984
    s.add        s47, s13, s24
    s.addi       s48, s42, #0
    v.ld.w       v2, [s46, #0]
    s.addi       s46, s47, #64
    s.addi       s47, s31, #2816
x8dot_row_74:
    s.addi       s49, s26, #-64
    v.movi       v19, #0
    s.sub        s50, s49, s48
    s.add        s49, s46, s48
    v.splat      v23, s50
    s.shli       s50, s48, #4
    s.addi       s52, s48, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s49, v2]             // index is in elements (ISA sec 9.1)
    s.add        s49, s47, s50
    s.movz       s50, #32
    v.st.b       [s49, #0], v19
    fence.acq_rel.device
    s.mov        s48, s52
    s.cmp.lt     s49, s48, s50
    br.nz        s49, x8dot_row_74
x8dot_done_73:
    v.splat      v2, s45
    v.movi       v19, #0
    mb.arm       s45, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s46, v32, #7
    v.cmp.ne     p1, v2, v19
    v.cmp.eq     p2, v2, v19
    s.mov        s47, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s47, s45            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s47, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s47, s45          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s38
    mb.arm       s44, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s46, v30, #0
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s44
    mb.wait      s44
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s46, x8dot_done_75
    s.addi       s47, s31, #1536
    s.add        s48, s13, s24
    s.addi       s49, s42, #0
    v.ld.w       v2, [s47, #0]
    s.addi       s42, s48, #96
    s.addi       s47, s31, #2304
x8dot_row_76:
    s.addi       s48, s26, #-96
    v.movi       v19, #0
    s.sub        s50, s48, s49
    s.add        s48, s42, s49
    v.splat      v23, s50
    s.shli       s50, s49, #4
    s.addi       s52, s49, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s48, v2]             // index is in elements (ISA sec 9.1)
    s.add        s48, s47, s50
    s.movz       s50, #32
    v.st.b       [s48, #0], v19
    fence.acq_rel.device
    s.mov        s49, s52
    s.cmp.lt     s48, s49, s50
    br.nz        s48, x8dot_row_76
x8dot_done_75:
    v.splat      v2, s46
    v.movi       v19, #0
    mb.arm       s42, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s46, #0
    v.extract    s47, v32, #0
    s.movz       s48, #96
    v.cmp.ne     p1, v2, v19
    v.cmp.eq     p2, v2, v19
    s.mov        s49, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s49, s42            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s49, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s49, s42          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s45
    mb.arm       s47, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s49, v30, #1
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s47
    mb.wait      s47
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s49, x8dot_done_77
    s.addi       s50, s31, #1600
    s.add        s52, s13, s24
    s.addi       s53, s46, #0
    v.ld.w       v2, [s50, #0]
    s.addi       s50, s52, #96
    s.addi       s52, s31, #2816
x8dot_row_78:
    s.addi       s54, s26, #-96
    v.movi       v19, #0
    s.sub        s55, s54, s53
    s.add        s54, s50, s53
    v.splat      v23, s55
    s.shli       s55, s53, #4
    s.addi       s56, s53, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s54, v2]             // index is in elements (ISA sec 9.1)
    s.add        s54, s52, s55
    s.movz       s55, #32
    v.st.b       [s54, #0], v19
    fence.acq_rel.device
    s.mov        s53, s56
    s.cmp.lt     s54, s53, s55
    br.nz        s54, x8dot_row_78
x8dot_done_77:
    v.extract    s50, v4, #0
    v.splat      v2, s49
    v.splat      v19, s50
    v.movi       v23, #0
    mb.arm       s49, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    vf.max.ieee  v24, v19, v20
    v.extract    s50, v32, #1
    s.addi       s52, s31, #896
    v.cmp.ne     p1, v2, v23
    v.cmp.eq     p2, v2, v23
    v.rcp.approx v2, v24                         // ISA 8.8: <= 2**-22 relative
    s.mov        s53, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s53, s49            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s53, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s53, s49          // predicated off still completes once (ISA sec 9A.3)
    v.ld.w       v19, [s52, #0]
    v.extract    s46, v4, #1
    s.addi       s48, s31, #5376                 // 512 bytes of repack scratch
    v.splat      v23, s46
    s.addi       s46, s48, #0
    v.extract    s50, v4, #2
    vf.max.ieee  v26, v23, v20
    v.splat      v23, s50
    s.addi       s50, s48, #32
    vf.max.ieee  v27, v23, v20
    v.rcp.approx v23, v26                        // ISA 8.8: <= 2**-22 relative
    v.rcp.approx v28, v27                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v29, v24, v2, v18
    vf.fms       v39, v2, v29, v2
    vf.neg       v29, v39                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v29, v29
    @p1 v.sel        v39, v29, v2
    vf.fms       v2, v26, v23, v18
    vf.fms       v29, v23, v2, v23
    vf.neg       v2, v29                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v29, v2, v23
    vf.mul       v2, v19, v39                    // a/y: faithful quotient
    vf.fms       v23, v2, v24, v19
    vf.fms       v19, v27, v28, v18
    vf.fms       v24, v23, v39, v2
    vf.fms       v23, v28, v19, v28
    vf.neg       v19, v24                        // a/y: one correction to the IEEE quotient
    vf.neg       v24, v23                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v23, v19, v2
    vf.cmp.o     p1, v24, v24
    @p1 v.sel        v2, v24, v28
    v.lshr       v19, v23, v22
    vf.cvt.f32.e4m3 v24, v23
    s.addi       s53, s48, #64
    v.and        v23, v19, v25
    s.addi       s54, s31, #896
    v.or         v19, v24, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s55, v4, #3
    v.st.b       [s46, #0], v19
    v.splat      v19, s55
    v.ld.w       v23, [s52, #0]
    vf.max.ieee  v24, v19, v20
    v.rcp.approx v19, v24                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v28, v23, v29                   // a/y: faithful quotient
    vf.fms       v39, v28, v26, v23
    vf.fms       v23, v39, v29, v28
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.fms       v23, v24, v19, v18
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v29, v26, v28
    vf.fms       v26, v19, v23, v19
    v.lshr       v23, v29, v22
    vf.cvt.f32.e4m3 v28, v29
    s.addi       s46, s48, #96
    v.and        v29, v23, v25
    vf.neg       v23, v26                        // Newton step: r0*(2 - x*r0)
    v.or         v26, v28, v29                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s55, v4, #4
    v.st.b       [s50, #0], v26
    vf.cmp.o     p1, v23, v23
    v.splat      v26, s55
    @p1 v.sel        v28, v23, v19
    v.ld.w       v19, [s52, #0]
    vf.max.ieee  v23, v26, v20
    v.rcp.approx v26, v23                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v19, v2                    // a/y: faithful quotient
    vf.fms       v39, v29, v27, v19
    vf.fms       v19, v39, v2, v29
    vf.neg       v2, v19                         // a/y: one correction to the IEEE quotient
    vf.fms       v19, v23, v26, v18
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v27, v2, v29
    vf.fms       v2, v26, v19, v26
    v.lshr       v19, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s50, s48, #128
    v.and        v27, v19, v25
    vf.neg       v19, v2                         // Newton step: r0*(2 - x*r0)
    v.or         v2, v29, v27                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s52, v4, #5
    v.st.b       [s53, #0], v2
    vf.cmp.o     p1, v19, v19
    v.splat      v2, s52
    @p1 v.sel        v27, v19, v26
    vf.max.ieee  v19, v2, v20
    v.ld.w       v2, [s54, #0]
    v.rcp.approx v26, v19                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v2, v28                    // a/y: faithful quotient
    vf.fms       v39, v29, v24, v2
    vf.fms       v2, v39, v28, v29
    vf.fms       v24, v19, v26, v18
    vf.neg       v28, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v26, v24, v26
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v24, v28, v29
    vf.neg       v28, v2                         // Newton step: r0*(2 - x*r0)
    v.lshr       v2, v24, v22
    vf.cvt.f32.e4m3 v29, v24
    s.addi       s52, s48, #160
    v.and        v24, v2, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v2, v28, v26
    v.or         v26, v29, v24                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s53, v4, #6
    s.addi       s55, s31, #896
    v.st.b       [s46, #0], v26
    v.splat      v24, s53
    v.ld.w       v26, [s54, #0]
    vf.max.ieee  v28, v24, v20
    v.rcp.approx v24, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v26, v27                   // a/y: faithful quotient
    vf.fms       v39, v29, v23, v26
    vf.fms       v23, v39, v27, v29
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.fms       v23, v28, v24, v18
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v27, v26, v29
    vf.fms       v26, v24, v23, v24
    v.lshr       v23, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s46, s48, #192
    v.and        v27, v23, v25
    vf.neg       v23, v26                        // Newton step: r0*(2 - x*r0)
    v.or         v26, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s53, v4, #7
    v.st.b       [s50, #0], v26
    vf.cmp.o     p1, v23, v23
    v.splat      v26, s53
    @p1 v.sel        v27, v23, v24
    v.ld.w       v23, [s54, #0]
    vf.max.ieee  v24, v26, v20
    v.rcp.approx v26, v24                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v23, v2                    // a/y: faithful quotient
    vf.fms       v39, v29, v19, v23
    vf.fms       v19, v39, v2, v29
    vf.neg       v2, v19                         // a/y: one correction to the IEEE quotient
    vf.fms       v19, v24, v26, v18
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v23, v2, v29
    vf.fms       v2, v26, v19, v26
    v.lshr       v19, v23, v22
    vf.cvt.f32.e4m3 v29, v23
    s.addi       s50, s48, #224
    v.and        v23, v19, v25
    vf.neg       v19, v2                         // Newton step: r0*(2 - x*r0)
    v.or         v2, v29, v23                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s53, v4, #8
    v.st.b       [s52, #0], v2
    vf.cmp.o     p1, v19, v19
    v.splat      v2, s53
    @p1 v.sel        v23, v19, v26
    vf.max.ieee  v19, v2, v20
    v.ld.w       v2, [s55, #0]
    v.rcp.approx v26, v19                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v2, v27                    // a/y: faithful quotient
    vf.fms       v39, v29, v28, v2
    vf.fms       v2, v39, v27, v29
    vf.fms       v27, v19, v26, v18
    vf.neg       v28, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v26, v27, v26
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v29
    vf.neg       v28, v2                         // Newton step: r0*(2 - x*r0)
    v.lshr       v2, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s52, s48, #256
    v.and        v27, v2, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v2, v28, v26
    v.or         v26, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s53, v4, #9
    s.addi       s54, s31, #896
    v.st.b       [s46, #0], v26
    v.splat      v26, s53
    v.ld.w       v27, [s55, #0]
    vf.max.ieee  v28, v26, v20
    v.rcp.approx v26, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v27, v23                   // a/y: faithful quotient
    vf.fms       v39, v29, v24, v27
    vf.fms       v24, v39, v23, v29
    vf.neg       v23, v24                        // a/y: one correction to the IEEE quotient
    vf.fms       v24, v28, v26, v18
    vf.cmp.o     p1, v23, v23
    @p1 v.sel        v27, v23, v29
    vf.fms       v23, v26, v24, v26
    v.lshr       v24, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s46, s48, #288
    v.and        v27, v24, v25
    vf.neg       v24, v23                        // Newton step: r0*(2 - x*r0)
    v.or         v23, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s53, v4, #10
    v.st.b       [s50, #0], v23
    vf.cmp.o     p1, v24, v24
    v.splat      v23, s53
    @p1 v.sel        v27, v24, v26
    v.ld.w       v24, [s55, #0]
    vf.max.ieee  v26, v23, v20
    v.rcp.approx v23, v26                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v24, v2                    // a/y: faithful quotient
    vf.fms       v39, v29, v19, v24
    vf.fms       v19, v39, v2, v29
    vf.neg       v2, v19                         // a/y: one correction to the IEEE quotient
    vf.fms       v19, v26, v23, v18
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v24, v2, v29
    vf.fms       v2, v23, v19, v23
    v.lshr       v19, v24, v22
    vf.cvt.f32.e4m3 v29, v24
    s.addi       s50, s48, #320
    v.and        v24, v19, v25
    vf.neg       v19, v2                         // Newton step: r0*(2 - x*r0)
    v.or         v2, v29, v24                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s53, v4, #11
    v.st.b       [s52, #0], v2
    vf.cmp.o     p1, v19, v19
    v.splat      v2, s53
    @p1 v.sel        v24, v19, v23
    vf.max.ieee  v19, v2, v20
    v.ld.w       v2, [s54, #0]
    v.rcp.approx v23, v19                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v2, v27                    // a/y: faithful quotient
    vf.fms       v39, v29, v28, v2
    vf.fms       v2, v39, v27, v29
    vf.fms       v27, v19, v23, v18
    vf.neg       v28, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v23, v27, v23
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v29
    vf.neg       v28, v2                         // Newton step: r0*(2 - x*r0)
    v.lshr       v2, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s52, s48, #352
    v.and        v27, v2, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v2, v28, v23
    v.or         v23, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s53, v4, #12
    s.addi       s55, s31, #896
    v.st.b       [s46, #0], v23
    v.splat      v23, s53
    v.ld.w       v27, [s54, #0]
    vf.max.ieee  v28, v23, v20
    v.rcp.approx v23, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v27, v24                   // a/y: faithful quotient
    vf.fms       v39, v29, v26, v27
    vf.fms       v26, v39, v24, v29
    vf.neg       v24, v26                        // a/y: one correction to the IEEE quotient
    vf.fms       v26, v28, v23, v18
    vf.cmp.o     p1, v24, v24
    @p1 v.sel        v27, v24, v29
    vf.fms       v24, v23, v26, v23
    v.lshr       v26, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s46, s48, #384
    v.and        v27, v26, v25
    vf.neg       v26, v24                        // Newton step: r0*(2 - x*r0)
    v.or         v24, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s53, v4, #13
    v.st.b       [s50, #0], v24
    vf.cmp.o     p1, v26, v26
    v.splat      v24, s53
    @p1 v.sel        v27, v26, v23
    v.ld.w       v23, [s54, #0]
    vf.max.ieee  v26, v24, v20
    v.rcp.approx v24, v26                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v23, v2                    // a/y: faithful quotient
    vf.fms       v39, v29, v19, v23
    vf.fms       v19, v39, v2, v29
    vf.neg       v2, v19                         // a/y: one correction to the IEEE quotient
    vf.fms       v19, v26, v24, v18
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v23, v2, v29
    vf.fms       v2, v24, v19, v24
    v.lshr       v19, v23, v22
    vf.cvt.f32.e4m3 v29, v23
    s.addi       s50, s48, #416
    v.and        v23, v19, v25
    vf.neg       v19, v2                         // Newton step: r0*(2 - x*r0)
    v.or         v2, v29, v23                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s53, v4, #14
    v.st.b       [s52, #0], v2
    vf.cmp.o     p1, v19, v19
    v.splat      v2, s53
    @p1 v.sel        v23, v19, v24
    vf.max.ieee  v19, v2, v20
    v.ld.w       v2, [s55, #0]
    v.rcp.approx v24, v19                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v2, v27                    // a/y: faithful quotient
    vf.fms       v39, v29, v28, v2
    vf.fms       v2, v39, v27, v29
    vf.fms       v27, v19, v24, v18
    vf.neg       v28, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v24, v27, v24
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v29
    vf.neg       v28, v2                         // Newton step: r0*(2 - x*r0)
    v.lshr       v2, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s52, s48, #448
    v.and        v27, v2, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v2, v28, v24
    v.or         v24, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s53, v4, #15
    s.addi       s54, s31, #896
    v.st.b       [s46, #0], v24
    v.splat      v24, s53
    v.ld.w       v27, [s55, #0]
    vf.max.ieee  v28, v24, v20
    v.rcp.approx v24, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v27, v23                   // a/y: faithful quotient
    vf.fms       v39, v29, v26, v27
    vf.fms       v26, v39, v23, v29
    vf.neg       v23, v26                        // a/y: one correction to the IEEE quotient
    vf.fms       v26, v28, v24, v18
    vf.cmp.o     p1, v23, v23
    @p1 v.sel        v27, v23, v29
    vf.fms       v23, v24, v26, v24
    v.lshr       v26, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s46, s48, #480
    v.and        v27, v26, v25
    vf.neg       v26, v23                        // Newton step: r0*(2 - x*r0)
    v.or         v23, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s53, s31, #960
    v.st.b       [s50, #0], v23
    v.extract    s50, v4, #0
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v24
    v.ld.w       v24, [s55, #0]
    v.splat      v26, s50
    vf.max.ieee  v27, v26, v20
    v.rcp.approx v26, v27                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v24, v2                    // a/y: faithful quotient
    vf.fms       v39, v29, v19, v24
    vf.fms       v19, v39, v2, v29
    vf.neg       v2, v19                         // a/y: one correction to the IEEE quotient
    vf.fms       v19, v27, v26, v18
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v24, v2, v29
    v.lshr       v2, v24, v22
    vf.cvt.f32.e4m3 v29, v24
    vf.fms       v24, v26, v19, v26
    v.and        v19, v2, v25
    s.addi       s50, s48, #16
    v.or         v2, v29, v19                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v19, v24                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s52, #0], v2
    v.extract    s52, v4, #1
    vf.cmp.o     p1, v19, v19
    v.splat      v2, s52
    @p1 v.sel        v24, v19, v26
    v.ld.w       v19, [s54, #0]
    vf.max.ieee  v26, v2, v20
    v.rcp.approx v2, v26                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v19, v23                   // a/y: faithful quotient
    vf.fms       v39, v29, v28, v19
    vf.fms       v19, v39, v23, v29
    vf.neg       v23, v19                        // a/y: one correction to the IEEE quotient
    vf.fms       v19, v26, v2, v18
    vf.cmp.o     p1, v23, v23
    @p1 v.sel        v28, v23, v29
    vf.fms       v23, v2, v19, v2
    v.lshr       v19, v28, v22
    vf.cvt.f32.e4m3 v29, v28
    s.addi       s52, s48, #48
    v.and        v28, v19, v25
    vf.neg       v19, v23                        // Newton step: r0*(2 - x*r0)
    v.or         v23, v29, v28                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s54, v4, #2
    v.st.b       [s46, #0], v23
    vf.cmp.o     p1, v19, v19
    v.splat      v23, s54
    @p1 v.sel        v28, v19, v2
    vf.max.ieee  v2, v23, v20
    v.ld.w       v19, [s53, #0]
    v.rcp.approx v23, v2                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v19, v24                   // a/y: faithful quotient
    vf.fms       v39, v29, v27, v19
    vf.fms       v19, v39, v24, v29
    vf.fms       v24, v2, v23, v18
    vf.neg       v27, v19                        // a/y: one correction to the IEEE quotient
    vf.fms       v19, v23, v24, v23
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v24, v27, v29
    vf.neg       v27, v19                        // Newton step: r0*(2 - x*r0)
    v.lshr       v19, v24, v22
    vf.cvt.f32.e4m3 v29, v24
    s.addi       s46, s48, #80
    v.and        v24, v19, v25
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v19, v27, v23
    v.or         v23, v29, v24                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s54, v4, #3
    s.addi       s55, s31, #960
    v.st.b       [s50, #0], v23
    v.splat      v23, s54
    v.ld.w       v24, [s53, #0]
    vf.max.ieee  v27, v23, v20
    v.rcp.approx v23, v27                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v24, v28                   // a/y: faithful quotient
    vf.fms       v39, v29, v26, v24
    vf.fms       v24, v39, v28, v29
    vf.neg       v26, v24                        // a/y: one correction to the IEEE quotient
    vf.fms       v24, v27, v23, v18
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v28, v26, v29
    vf.fms       v26, v23, v24, v23
    v.lshr       v24, v28, v22
    vf.cvt.f32.e4m3 v29, v28
    s.addi       s50, s48, #112
    v.and        v28, v24, v25
    vf.neg       v24, v26                        // Newton step: r0*(2 - x*r0)
    v.or         v26, v29, v28                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s54, v4, #4
    v.st.b       [s52, #0], v26
    vf.cmp.o     p1, v24, v24
    v.splat      v26, s54
    @p1 v.sel        v28, v24, v23
    v.ld.w       v23, [s53, #0]
    vf.max.ieee  v24, v26, v20
    v.rcp.approx v26, v24                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v23, v19                   // a/y: faithful quotient
    vf.fms       v39, v29, v2, v23
    vf.fms       v2, v39, v19, v29
    vf.neg       v19, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v24, v26, v18
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v23, v19, v29
    vf.fms       v19, v26, v2, v26
    v.lshr       v2, v23, v22
    vf.cvt.f32.e4m3 v29, v23
    s.addi       s52, s48, #144
    v.and        v23, v2, v25
    vf.neg       v2, v19                         // Newton step: r0*(2 - x*r0)
    v.or         v19, v29, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s53, v4, #5
    v.st.b       [s46, #0], v19
    vf.cmp.o     p1, v2, v2
    v.splat      v19, s53
    @p1 v.sel        v23, v2, v26
    vf.max.ieee  v2, v19, v20
    v.ld.w       v19, [s55, #0]
    v.rcp.approx v26, v2                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v19, v28                   // a/y: faithful quotient
    vf.fms       v39, v29, v27, v19
    vf.fms       v19, v39, v28, v29
    vf.fms       v27, v2, v26, v18
    vf.neg       v28, v19                        // a/y: one correction to the IEEE quotient
    vf.fms       v19, v26, v27, v26
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v29
    vf.neg       v28, v19                        // Newton step: r0*(2 - x*r0)
    v.lshr       v19, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s46, s48, #176
    v.and        v27, v19, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v26
    v.or         v26, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s53, v4, #6
    s.addi       s54, s31, #960
    v.st.b       [s50, #0], v26
    v.splat      v26, s53
    v.ld.w       v27, [s55, #0]
    vf.max.ieee  v28, v26, v20
    v.rcp.approx v26, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v27, v23                   // a/y: faithful quotient
    vf.fms       v39, v29, v24, v27
    vf.fms       v24, v39, v23, v29
    vf.neg       v23, v24                        // a/y: one correction to the IEEE quotient
    vf.fms       v24, v28, v26, v18
    vf.cmp.o     p1, v23, v23
    @p1 v.sel        v27, v23, v29
    vf.fms       v23, v26, v24, v26
    v.lshr       v24, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s50, s48, #208
    v.and        v27, v24, v25
    vf.neg       v24, v23                        // Newton step: r0*(2 - x*r0)
    v.or         v23, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s53, v4, #7
    v.st.b       [s52, #0], v23
    vf.cmp.o     p1, v24, v24
    v.splat      v23, s53
    @p1 v.sel        v27, v24, v26
    v.ld.w       v24, [s55, #0]
    vf.max.ieee  v26, v23, v20
    v.rcp.approx v23, v26                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v24, v19                   // a/y: faithful quotient
    vf.fms       v39, v29, v2, v24
    vf.fms       v2, v39, v19, v29
    vf.neg       v19, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v26, v23, v18
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v24, v19, v29
    vf.fms       v19, v23, v2, v23
    v.lshr       v2, v24, v22
    vf.cvt.f32.e4m3 v29, v24
    s.addi       s52, s48, #240
    v.and        v24, v2, v25
    vf.neg       v2, v19                         // Newton step: r0*(2 - x*r0)
    v.or         v19, v29, v24                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s53, v4, #8
    v.st.b       [s46, #0], v19
    vf.cmp.o     p1, v2, v2
    v.splat      v19, s53
    @p1 v.sel        v24, v2, v23
    vf.max.ieee  v2, v19, v20
    v.ld.w       v19, [s54, #0]
    v.rcp.approx v23, v2                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v19, v27                   // a/y: faithful quotient
    vf.fms       v39, v29, v28, v19
    vf.fms       v19, v39, v27, v29
    vf.fms       v27, v2, v23, v18
    vf.neg       v28, v19                        // a/y: one correction to the IEEE quotient
    vf.fms       v19, v23, v27, v23
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v29
    vf.neg       v28, v19                        // Newton step: r0*(2 - x*r0)
    v.lshr       v19, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s46, s48, #272
    v.and        v27, v19, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v23
    v.or         v23, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s53, v4, #9
    s.addi       s55, s31, #960
    v.st.b       [s50, #0], v23
    v.splat      v23, s53
    v.ld.w       v27, [s54, #0]
    vf.max.ieee  v28, v23, v20
    v.rcp.approx v23, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v27, v24                   // a/y: faithful quotient
    vf.fms       v39, v29, v26, v27
    vf.fms       v26, v39, v24, v29
    vf.neg       v24, v26                        // a/y: one correction to the IEEE quotient
    vf.fms       v26, v28, v23, v18
    vf.cmp.o     p1, v24, v24
    @p1 v.sel        v27, v24, v29
    vf.fms       v24, v23, v26, v23
    v.lshr       v26, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s50, s48, #304
    v.and        v27, v26, v25
    vf.neg       v26, v24                        // Newton step: r0*(2 - x*r0)
    v.or         v24, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s53, v4, #10
    v.st.b       [s52, #0], v24
    vf.cmp.o     p1, v26, v26
    v.splat      v24, s53
    @p1 v.sel        v27, v26, v23
    v.ld.w       v23, [s54, #0]
    vf.max.ieee  v26, v24, v20
    v.rcp.approx v24, v26                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v23, v19                   // a/y: faithful quotient
    vf.fms       v39, v29, v2, v23
    vf.fms       v2, v39, v19, v29
    vf.neg       v19, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v26, v24, v18
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v23, v19, v29
    vf.fms       v19, v24, v2, v24
    v.lshr       v2, v23, v22
    vf.cvt.f32.e4m3 v29, v23
    s.addi       s52, s48, #336
    v.and        v23, v2, v25
    vf.neg       v2, v19                         // Newton step: r0*(2 - x*r0)
    v.or         v19, v29, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s53, v4, #11
    v.st.b       [s46, #0], v19
    vf.cmp.o     p1, v2, v2
    v.splat      v19, s53
    @p1 v.sel        v23, v2, v24
    vf.max.ieee  v2, v19, v20
    v.ld.w       v19, [s55, #0]
    v.rcp.approx v24, v2                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v19, v27                   // a/y: faithful quotient
    vf.fms       v39, v29, v28, v19
    vf.fms       v19, v39, v27, v29
    vf.fms       v27, v2, v24, v18
    vf.neg       v28, v19                        // a/y: one correction to the IEEE quotient
    vf.fms       v19, v24, v27, v24
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v29
    vf.neg       v28, v19                        // Newton step: r0*(2 - x*r0)
    v.lshr       v19, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s46, s48, #368
    v.and        v27, v19, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v24
    v.or         v24, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s53, v4, #12
    s.addi       s54, s31, #960
    v.st.b       [s50, #0], v24
    v.splat      v24, s53
    v.ld.w       v27, [s55, #0]
    vf.max.ieee  v28, v24, v20
    v.rcp.approx v24, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v27, v23                   // a/y: faithful quotient
    vf.fms       v39, v29, v26, v27
    vf.fms       v26, v39, v23, v29
    vf.neg       v23, v26                        // a/y: one correction to the IEEE quotient
    vf.fms       v26, v28, v24, v18
    vf.cmp.o     p1, v23, v23
    @p1 v.sel        v27, v23, v29
    vf.fms       v23, v24, v26, v24
    v.lshr       v26, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s50, s48, #400
    v.and        v27, v26, v25
    vf.neg       v26, v23                        // Newton step: r0*(2 - x*r0)
    v.or         v23, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s53, v4, #13
    v.st.b       [s52, #0], v23
    vf.cmp.o     p1, v26, v26
    v.splat      v23, s53
    @p1 v.sel        v27, v26, v24
    v.ld.w       v24, [s55, #0]
    vf.max.ieee  v26, v23, v20
    v.rcp.approx v23, v26                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v24, v19                   // a/y: faithful quotient
    vf.fms       v39, v29, v2, v24
    vf.fms       v2, v39, v19, v29
    vf.neg       v19, v2                         // a/y: one correction to the IEEE quotient
    vf.fms       v2, v26, v23, v18
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v24, v19, v29
    vf.fms       v19, v23, v2, v23
    v.lshr       v2, v24, v22
    vf.cvt.f32.e4m3 v29, v24
    s.addi       s52, s48, #432
    v.and        v24, v2, v25
    vf.neg       v2, v19                         // Newton step: r0*(2 - x*r0)
    v.or         v19, v29, v24                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s53, v4, #14
    v.st.b       [s46, #0], v19
    vf.cmp.o     p1, v2, v2
    v.splat      v19, s53
    @p1 v.sel        v24, v2, v23
    vf.max.ieee  v2, v19, v20
    v.ld.w       v19, [s54, #0]
    v.rcp.approx v23, v2                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v19, v27                   // a/y: faithful quotient
    vf.fms       v39, v29, v28, v19
    vf.fms       v19, v39, v27, v29
    vf.fms       v27, v2, v23, v18
    vf.neg       v28, v19                        // a/y: one correction to the IEEE quotient
    vf.fms       v19, v23, v27, v23
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v29
    vf.neg       v28, v19                        // Newton step: r0*(2 - x*r0)
    v.lshr       v19, v27, v22
    vf.cvt.f32.e4m3 v29, v27
    s.addi       s46, s48, #464
    v.and        v27, v19, v25
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v23
    v.or         v23, v29, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s53, v4, #15
    s.addi       s55, s31, #960
    v.st.b       [s50, #0], v23
    v.splat      v23, s53
    v.ld.w       v27, [s54, #0]
    vf.max.ieee  v28, v23, v20
    v.rcp.approx v20, v28                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v23, v27, v24                   // a/y: faithful quotient
    vf.fms       v29, v23, v26, v27
    vf.fms       v26, v29, v24, v23
    vf.neg       v24, v26                        // a/y: one correction to the IEEE quotient
    vf.fms       v26, v28, v20, v18
    vf.cmp.o     p1, v24, v24
    @p1 v.sel        v18, v24, v23
    vf.fms       v23, v20, v26, v20
    v.lshr       v24, v18, v22
    vf.cvt.f32.e4m3 v26, v18
    s.addi       s50, s48, #496
    v.and        v18, v24, v25
    vf.neg       v24, v23                        // Newton step: r0*(2 - x*r0)
    v.or         v23, v26, v18                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v23
    vf.cmp.o     p1, v24, v24
    @p1 v.sel        v18, v24, v20
    v.ld.w       v20, [s54, #0]
    s.addi       s52, s48, #64
    s.addi       s53, s48, #128
    s.addi       s54, s48, #192
    vf.mul       v23, v20, v19                   // a/y: faithful quotient
    vf.fms       v24, v23, v2, v20
    vf.fms       v2, v24, v19, v23
    vf.neg       v19, v2                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v2, v19, v23
    v.lshr       v19, v2, v22
    vf.cvt.f32.e4m3 v20, v2
    v.and        v2, v19, v25
    v.or         v19, v20, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    s.addi       s46, s48, #256
    v.ld.w       v2, [s55, #0]
    s.addi       s55, s48, #320
    vf.mul       v19, v2, v18                    // a/y: faithful quotient
    vf.fms       v20, v19, v28, v2
    vf.fms       v2, v20, v18, v19
    vf.neg       v18, v2                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v18, v18
    @p1 v.sel        v2, v18, v19
    v.lshr       v18, v2, v22
    vf.cvt.f32.e4m3 v19, v2
    v.and        v2, v18, v25
    v.or         v18, v19, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s50, #0], v18
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    s.addi       s50, s48, #384
    v.ld.w       v2, [s48, #0]
    s.addi       s56, s48, #448
    v.mov        v56, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s52, #0]
    v.extract    s48, v30, #2
    v.mov        v57, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s53, #0]
    v.mov        v58, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s54, #0]
    v.mov        v59, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s46, #0]
    v.mov        v60, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s55, #0]
    v.mov        v61, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s50, #0]
    v.mov        v62, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s56, #0]
    v.mov        v63, v2                         // hand off through the shared window (sec 7.3)
    mb.wait      s42
    mb.arm       s46, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s46
    mb.wait      s46
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s48, x8dot_done_79
    s.movz       s50, #0
    s.addi       s52, s31, #1664
    s.add        s53, s13, s24
    s.addi       s54, s50, #0
    v.ld.w       v2, [s52, #0]
    s.addi       s50, s53, #96
    s.addi       s52, s31, #2304
x8dot_row_80:
    s.addi       s53, s26, #-96
    v.movi       v18, #0
    s.sub        s55, s53, s54
    s.add        s53, s50, s54
    v.splat      v19, s55
    s.shli       s55, s54, #4
    s.addi       s56, s54, #1
    v.cmp.gt     p1, v19, v18
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v18, [s53, v2]             // index is in elements (ISA sec 9.1)
    s.add        s53, s52, s55
    s.movz       s55, #32
    v.st.b       [s53, #0], v18
    fence.acq_rel.device
    s.mov        s54, s56
    s.cmp.lt     s53, s54, s55
    br.nz        s53, x8dot_row_80
x8dot_done_79:
    v.splat      v2, s48
    v.movi       v18, #0
    mb.arm       s48, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s50, #0
    v.extract    s52, v32, #2
    s.movz       s53, #96
    v.cmp.ne     p1, v2, v18
    v.cmp.eq     p2, v2, v18
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s54, s48            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s54, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s54, s48          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s49
    mb.arm       s52, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s54, v30, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s52
    mb.wait      s52
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s54, x8dot_done_81
    s.addi       s55, s31, #1728
    s.add        s56, s13, s24
    s.addi       s57, s50, #0
    v.ld.w       v2, [s55, #0]
    s.addi       s55, s56, #96
    s.addi       s56, s31, #2816
x8dot_row_82:
    s.addi       s58, s26, #-96
    v.movi       v18, #0
    s.sub        s59, s58, s57
    s.add        s58, s55, s57
    v.splat      v19, s59
    s.shli       s59, s57, #4
    s.addi       s60, s57, #1
    v.cmp.gt     p1, v19, v18
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v18, [s58, v2]             // index is in elements (ISA sec 9.1)
    s.add        s58, s56, s59
    s.movz       s59, #32
    v.st.b       [s58, #0], v18
    fence.acq_rel.device
    s.mov        s57, s60
    s.cmp.lt     s58, s57, s59
    br.nz        s58, x8dot_row_82
x8dot_done_81:
    v.splat      v2, s54
    v.movi       v18, #0
    mb.arm       s54, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s55, v32, #3
    v.cmp.ne     p1, v2, v18
    v.cmp.eq     p2, v2, v18
    s.mov        s56, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s56, s54            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s56, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s56, s54          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s48
    mb.arm       s53, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s55, v30, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s53
    mb.wait      s53
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s55, x8dot_done_83
    s.addi       s56, s31, #1792
    s.add        s57, s13, s24
    s.addi       s58, s50, #0
    v.ld.w       v2, [s56, #0]
    s.addi       s50, s57, #96
    s.addi       s56, s31, #2304
x8dot_row_84:
    s.addi       s57, s26, #-96
    v.movi       v18, #0
    s.sub        s59, s57, s58
    s.add        s57, s50, s58
    v.splat      v19, s59
    s.shli       s59, s58, #4
    s.addi       s60, s58, #1
    v.cmp.gt     p1, v19, v18
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v18, [s57, v2]             // index is in elements (ISA sec 9.1)
    s.add        s57, s56, s59
    s.movz       s59, #32
    v.st.b       [s57, #0], v18
    fence.acq_rel.device
    s.mov        s58, s60
    s.cmp.lt     s57, s58, s59
    br.nz        s57, x8dot_row_84
x8dot_done_83:
    v.splat      v2, s55
    v.movi       v18, #0
    mb.arm       s50, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s55, #0
    v.extract    s56, v32, #4
    s.movz       s57, #96
    v.cmp.ne     p1, v2, v18
    v.cmp.eq     p2, v2, v18
    s.mov        s58, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s59, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s58, s50            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s58, s56                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s59, s57                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s58, s50          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s54
    mb.arm       s56, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s58, v30, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s56
    mb.wait      s56
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s58, x8dot_done_85
    s.addi       s59, s31, #1856
    s.add        s60, s13, s24
    s.addi       s20, s55, #0
    v.ld.w       v2, [s59, #0]
    s.addi       s27, s60, #96
    s.addi       s28, s31, #2816
x8dot_row_86:
    s.addi       s29, s26, #-96
    v.movi       v18, #0
    s.sub        s30, s29, s20
    s.add        s29, s27, s20
    v.splat      v19, s30
    s.shli       s30, s20, #4
    s.addi       s32, s20, #1
    v.cmp.gt     p1, v19, v18
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v18, [s29, v2]             // index is in elements (ISA sec 9.1)
    s.add        s29, s28, s30
    s.movz       s30, #32
    v.st.b       [s29, #0], v18
    fence.acq_rel.device
    s.mov        s20, s32
    s.cmp.lt     s29, s20, s30
    br.nz        s29, x8dot_row_86
x8dot_done_85:
    v.splat      v2, s58
    v.movi       v18, #0
    mb.arm       s20, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s27, v32, #5
    v.cmp.ne     p1, v2, v18
    v.cmp.eq     p2, v2, v18
    s.mov        s28, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s29, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s28, s20            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s28, s27                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s29, s57                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s28, s20          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s50
    mb.arm       s27, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s28, v30, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s27
    mb.wait      s27
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s28, x8dot_done_87
    s.addi       s29, s31, #1920
    s.add        s30, s13, s24
    s.addi       s32, s55, #0
    v.ld.w       v2, [s29, #0]
    s.addi       s29, s30, #96
    s.addi       s30, s31, #2304
x8dot_row_88:
    s.addi       s33, s26, #-96
    v.movi       v18, #0
    s.sub        s34, s33, s32
    s.add        s33, s29, s32
    v.splat      v19, s34
    s.shli       s34, s32, #4
    s.addi       s35, s32, #1
    v.cmp.gt     p1, v19, v18
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v18, [s33, v2]             // index is in elements (ISA sec 9.1)
    s.add        s33, s30, s34
    s.movz       s34, #32
    v.st.b       [s33, #0], v18
    fence.acq_rel.device
    s.mov        s32, s35
    s.cmp.lt     s33, s32, s34
    br.nz        s33, x8dot_row_88
x8dot_done_87:
    v.splat      v2, s28
    v.movi       v18, #0
    mb.arm       s28, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s29, #0
    v.extract    s30, v32, #6
    s.movz       s32, #96
    v.cmp.ne     p1, v2, v18
    v.cmp.eq     p2, v2, v18
    s.mov        s33, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s29                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s33, s28            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s33, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s33, s28          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s20
    mb.arm       s30, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s33, v30, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s30
    mb.wait      s30
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s33, x8dot_done_89
    s.addi       s34, s31, #1984
    s.add        s35, s13, s24
    s.addi       s36, s29, #0
    v.ld.w       v2, [s34, #0]
    s.addi       s34, s35, #96
    s.addi       s35, s31, #2816
x8dot_row_90:
    s.addi       s37, s26, #-96
    v.movi       v18, #0
    s.sub        s38, s37, s36
    s.add        s37, s34, s36
    v.splat      v19, s38
    s.shli       s38, s36, #4
    s.addi       s39, s36, #1
    v.cmp.gt     p1, v19, v18
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v18, [s37, v2]             // index is in elements (ISA sec 9.1)
    s.add        s37, s35, s38
    s.movz       s38, #32
    v.st.b       [s37, #0], v18
    fence.acq_rel.device
    s.mov        s36, s39
    s.cmp.lt     s37, s36, s38
    br.nz        s37, x8dot_row_90
x8dot_done_89:
    v.splat      v2, s33
    v.movi       v18, #0
    mb.arm       s26, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s33, v32, #7
    v.cmp.ne     p1, v2, v18
    v.cmp.eq     p2, v2, v18
    s.mov        s34, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s29                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s34, s26            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s34, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s34, s26          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s28
    mb.arm       s32, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s33, s31, #5888
    s.movz       s34, #1
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s32
    mb.wait      s32
    mb.wait      s26
    mb.arm       s35, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s36, s33, #64
    s.movz       s37, #2
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s35
    mb.wait      s35
    a.vread      v2, a8, s29
    s.addi       s29, s33, #128
    s.movz       s38, #3
    v.st.w       [s33, #0], v2
    a.vread      v2, a8, s34
    s.addi       s34, s33, #192
    s.movz       s39, #4
    s.addi       s40, s33, #256
    s.movz       s41, #5
    s.addi       s42, s33, #320
    s.movz       s43, #6
    s.addi       s44, s33, #384
    s.movz       s45, #7
    s.addi       s46, s33, #448
    s.movz       s47, #8
    s.addi       s48, s33, #512
    s.movz       s49, #9
    s.addi       s51, s33, #576
    v.st.w       [s36, #0], v2
    a.vread      v2, a8, s37
    s.movz       s36, #10
    s.addi       s37, s33, #640
    v.st.w       [s29, #0], v2
    a.vread      v2, a8, s38
    s.movz       s29, #11
    s.addi       s38, s33, #704
    v.st.w       [s34, #0], v2
    a.vread      v2, a8, s39
    s.movz       s34, #12
    s.addi       s39, s33, #768
    v.st.w       [s40, #0], v2
    a.vread      v2, a8, s41
    s.movz       s40, #13
    s.addi       s41, s33, #832
    v.st.w       [s42, #0], v2
    a.vread      v2, a8, s43
    s.movz       s42, #14
    s.addi       s43, s33, #896
    s.addi       s52, s33, #960
    v.st.w       [s44, #0], v2
    a.vread      v2, a8, s45
    s.movz       s33, #15
    s.movz       s44, #0
    v.st.w       [s46, #0], v2
    a.vread      v2, a8, s47
    s.addi       s45, s31, #6912
    s.movz       s46, #1
    v.st.w       [s48, #0], v2
    a.vread      v2, a8, s49
    s.addi       s47, s45, #64
    s.movz       s48, #2
    v.st.w       [s51, #0], v2
    a.vread      v2, a8, s36
    s.addi       s36, s45, #128
    s.movz       s49, #3
    v.st.w       [s37, #0], v2
    a.vread      v2, a8, s29
    s.addi       s29, s45, #192
    s.movz       s37, #4
    v.st.w       [s38, #0], v2
    a.vread      v2, a8, s34
    s.addi       s34, s45, #256
    s.movz       s38, #5
    v.st.w       [s39, #0], v2
    a.vread      v2, a8, s40
    s.addi       s39, s45, #320
    s.movz       s40, #6
    v.st.w       [s41, #0], v2
    a.vread      v2, a8, s42
    s.addi       s41, s45, #384
    s.movz       s42, #7
    v.st.w       [s43, #0], v2
    a.vread      v2, a8, s33
    s.addi       s33, s45, #448
    s.movz       s43, #8
    v.st.w       [s52, #0], v2
    fence.acq_rel.device
    a.vread      v2, a9, s44
    s.addi       s44, s45, #512
    s.movz       s51, #9
    v.st.w       [s45, #0], v2
    a.vread      v2, a9, s46
    s.addi       s46, s45, #576
    v.st.w       [s47, #0], v2
    a.vread      v2, a9, s48
    s.movz       s47, #10
    s.addi       s48, s45, #640
    v.st.w       [s36, #0], v2
    a.vread      v2, a9, s49
    s.movz       s36, #11
    s.addi       s49, s45, #704
    v.st.w       [s29, #0], v2
    a.vread      v2, a9, s37
    s.movz       s29, #12
    s.addi       s37, s45, #768
    v.st.w       [s34, #0], v2
    a.vread      v2, a9, s38
    s.movz       s34, #13
    s.addi       s38, s45, #832
    v.st.w       [s39, #0], v2
    a.vread      v2, a9, s40
    s.movz       s39, #14
    s.addi       s40, s45, #896
    s.addi       s52, s45, #960
    v.st.w       [s41, #0], v2
    a.vread      v2, a9, s42
    s.movz       s41, #15
    s.movz       s42, #0
    v.st.w       [s33, #0], v2
    a.vread      v2, a9, s43
    s.addi       s33, s31, #7936
    s.movz       s43, #1
    v.st.w       [s44, #0], v2
    a.vread      v2, a9, s51
    s.addi       s44, s33, #64
    s.movz       s45, #2
    v.st.w       [s46, #0], v2
    a.vread      v2, a9, s47
    s.addi       s46, s33, #128
    s.movz       s47, #3
    v.st.w       [s48, #0], v2
    a.vread      v2, a9, s36
    s.addi       s36, s33, #192
    s.movz       s48, #4
    v.st.w       [s49, #0], v2
    a.vread      v2, a9, s29
    s.addi       s29, s33, #256
    s.movz       s49, #5
    v.st.w       [s37, #0], v2
    a.vread      v2, a9, s34
    s.addi       s34, s33, #320
    s.movz       s37, #6
    v.st.w       [s38, #0], v2
    a.vread      v2, a9, s39
    s.addi       s38, s33, #384
    s.movz       s39, #7
    v.st.w       [s40, #0], v2
    a.vread      v2, a9, s41
    s.addi       s40, s33, #448
    s.movz       s41, #8
    v.st.w       [s52, #0], v2
    fence.acq_rel.device
    a.vread      v2, a10, s42
    s.addi       s42, s33, #512
    s.movz       s51, #9
    v.st.w       [s33, #0], v2
    a.vread      v2, a10, s43
    s.addi       s43, s33, #576
    v.st.w       [s44, #0], v2
    a.vread      v2, a10, s45
    s.movz       s44, #10
    s.addi       s45, s33, #640
    v.st.w       [s46, #0], v2
    a.vread      v2, a10, s47
    s.movz       s46, #11
    s.addi       s47, s33, #704
    v.st.w       [s36, #0], v2
    a.vread      v2, a10, s48
    s.movz       s36, #12
    s.addi       s48, s33, #768
    v.st.w       [s29, #0], v2
    a.vread      v2, a10, s49
    s.movz       s29, #13
    s.addi       s49, s33, #832
    v.st.w       [s34, #0], v2
    a.vread      v2, a10, s37
    s.movz       s34, #14
    s.addi       s37, s33, #896
    s.addi       s52, s33, #960
    v.st.w       [s38, #0], v2
    a.vread      v2, a10, s39
    s.movz       s33, #15
    s.movz       s38, #0
    v.st.w       [s40, #0], v2
    a.vread      v2, a10, s41
    s.addi       s39, s31, #8960
    s.movz       s40, #1
    v.st.w       [s42, #0], v2
    a.vread      v2, a10, s51
    s.addi       s41, s39, #64
    s.movz       s42, #2
    v.st.w       [s43, #0], v2
    a.vread      v2, a10, s44
    s.addi       s43, s39, #128
    s.movz       s44, #3
    v.st.w       [s45, #0], v2
    a.vread      v2, a10, s46
    s.addi       s45, s39, #192
    s.movz       s46, #4
    v.st.w       [s47, #0], v2
    a.vread      v2, a10, s36
    s.addi       s36, s39, #256
    s.movz       s47, #5
    v.st.w       [s48, #0], v2
    a.vread      v2, a10, s29
    s.addi       s29, s39, #320
    s.movz       s48, #6
    v.st.w       [s49, #0], v2
    a.vread      v2, a10, s34
    s.addi       s34, s39, #384
    s.movz       s49, #7
    v.st.w       [s37, #0], v2
    a.vread      v2, a10, s33
    s.addi       s33, s39, #448
    s.movz       s37, #8
    v.st.w       [s52, #0], v2
    fence.acq_rel.device
    a.vread      v2, a11, s38
    s.addi       s38, s39, #512
    s.movz       s51, #9
    v.st.w       [s39, #0], v2
    a.vread      v2, a11, s40
    s.addi       s40, s39, #576
    v.st.w       [s41, #0], v2
    a.vread      v2, a11, s42
    s.movz       s41, #10
    s.addi       s42, s39, #640
    v.st.w       [s43, #0], v2
    a.vread      v2, a11, s44
    s.movz       s43, #11
    s.addi       s44, s39, #704
    v.st.w       [s45, #0], v2
    a.vread      v2, a11, s46
    s.movz       s45, #12
    s.addi       s46, s39, #768
    v.st.w       [s36, #0], v2
    a.vread      v2, a11, s47
    s.movz       s36, #13
    s.addi       s47, s39, #832
    v.st.w       [s29, #0], v2
    a.vread      v2, a11, s48
    s.movz       s29, #14
    s.addi       s48, s39, #896
    s.addi       s52, s39, #960
    v.st.w       [s34, #0], v2
    a.vread      v2, a11, s49
    s.movz       s34, #15
    s.movz       s39, #0
    v.st.w       [s33, #0], v2
    a.vread      v2, a11, s37
    s.addi       s33, s31, #9984
    s.movz       s37, #1
    v.st.w       [s38, #0], v2
    a.vread      v2, a11, s51
    s.addi       s38, s33, #64
    s.movz       s49, #2
    v.st.w       [s40, #0], v2
    a.vread      v2, a11, s41
    s.addi       s40, s33, #128
    s.movz       s41, #3
    v.st.w       [s42, #0], v2
    a.vread      v2, a11, s43
    s.addi       s42, s33, #192
    s.movz       s43, #4
    v.st.w       [s44, #0], v2
    a.vread      v2, a11, s45
    s.addi       s44, s33, #256
    s.movz       s45, #5
    v.st.w       [s46, #0], v2
    a.vread      v2, a11, s36
    s.addi       s36, s33, #320
    s.movz       s46, #6
    v.st.w       [s47, #0], v2
    a.vread      v2, a11, s29
    s.addi       s29, s33, #384
    s.movz       s47, #7
    v.st.w       [s48, #0], v2
    a.vread      v2, a11, s34
    s.addi       s34, s33, #448
    s.movz       s48, #8
    v.st.w       [s52, #0], v2
    fence.acq_rel.device
    a.vread      v2, a12, s39
    s.addi       s39, s33, #512
    s.movz       s51, #9
    v.st.w       [s33, #0], v2
    a.vread      v2, a12, s37
    s.addi       s37, s33, #576
    v.st.w       [s38, #0], v2
    a.vread      v2, a12, s49
    s.movz       s38, #10
    s.addi       s49, s33, #640
    v.st.w       [s40, #0], v2
    a.vread      v2, a12, s41
    s.movz       s40, #11
    s.addi       s41, s33, #704
    v.st.w       [s42, #0], v2
    a.vread      v2, a12, s43
    s.movz       s42, #12
    s.addi       s43, s33, #768
    v.st.w       [s44, #0], v2
    a.vread      v2, a12, s45
    s.movz       s44, #13
    s.addi       s45, s33, #832
    v.st.w       [s36, #0], v2
    a.vread      v2, a12, s46
    s.movz       s36, #14
    s.addi       s46, s33, #896
    s.addi       s52, s33, #960
    v.st.w       [s29, #0], v2
    a.vread      v2, a12, s47
    s.movz       s29, #15
    s.movz       s33, #0
    v.st.w       [s34, #0], v2
    a.vread      v2, a12, s48
    s.addi       s34, s31, #11008
    s.movz       s47, #1
    v.st.w       [s39, #0], v2
    a.vread      v2, a12, s51
    s.addi       s39, s34, #64
    s.movz       s48, #2
    v.st.w       [s37, #0], v2
    a.vread      v2, a12, s38
    s.addi       s37, s34, #128
    s.movz       s38, #3
    v.st.w       [s49, #0], v2
    a.vread      v2, a12, s40
    s.addi       s40, s34, #192
    s.movz       s49, #4
    v.st.w       [s41, #0], v2
    a.vread      v2, a12, s42
    s.addi       s41, s34, #256
    s.movz       s42, #5
    v.st.w       [s43, #0], v2
    a.vread      v2, a12, s44
    s.addi       s43, s34, #320
    s.movz       s44, #6
    v.st.w       [s45, #0], v2
    a.vread      v2, a12, s36
    s.addi       s36, s34, #384
    s.movz       s45, #7
    v.st.w       [s46, #0], v2
    a.vread      v2, a12, s29
    s.addi       s29, s34, #448
    s.movz       s46, #8
    v.st.w       [s52, #0], v2
    fence.acq_rel.device
    a.vread      v2, a13, s33
    s.addi       s33, s34, #512
    s.movz       s51, #9
    v.st.w       [s34, #0], v2
    a.vread      v2, a13, s47
    s.addi       s47, s34, #576
    v.st.w       [s39, #0], v2
    a.vread      v2, a13, s48
    s.movz       s39, #10
    s.addi       s48, s34, #640
    v.st.w       [s37, #0], v2
    a.vread      v2, a13, s38
    s.movz       s37, #11
    s.addi       s38, s34, #704
    v.st.w       [s40, #0], v2
    a.vread      v2, a13, s49
    s.movz       s40, #12
    s.addi       s49, s34, #768
    v.st.w       [s41, #0], v2
    a.vread      v2, a13, s42
    s.movz       s41, #13
    s.addi       s42, s34, #832
    v.st.w       [s43, #0], v2
    a.vread      v2, a13, s44
    s.movz       s43, #14
    s.addi       s44, s34, #896
    s.addi       s52, s34, #960
    v.st.w       [s36, #0], v2
    a.vread      v2, a13, s45
    s.movz       s34, #15
    s.movz       s36, #0
    v.st.w       [s29, #0], v2
    a.vread      v2, a13, s46
    s.addi       s29, s31, #12032
    s.movz       s45, #1
    v.st.w       [s33, #0], v2
    a.vread      v2, a13, s51
    s.addi       s33, s29, #64
    s.movz       s46, #2
    v.st.w       [s47, #0], v2
    a.vread      v2, a13, s39
    s.addi       s39, s29, #128
    s.movz       s47, #3
    v.st.w       [s48, #0], v2
    a.vread      v2, a13, s37
    s.addi       s37, s29, #192
    s.movz       s48, #4
    v.st.w       [s38, #0], v2
    a.vread      v2, a13, s40
    s.addi       s38, s29, #256
    s.movz       s40, #5
    v.st.w       [s49, #0], v2
    a.vread      v2, a13, s41
    s.addi       s41, s29, #320
    s.movz       s49, #6
    v.st.w       [s42, #0], v2
    a.vread      v2, a13, s43
    s.addi       s42, s29, #384
    s.movz       s43, #7
    v.st.w       [s44, #0], v2
    a.vread      v2, a13, s34
    s.addi       s34, s29, #448
    s.movz       s44, #8
    v.st.w       [s52, #0], v2
    fence.acq_rel.device
    a.vread      v2, a14, s36
    s.addi       s36, s29, #512
    s.movz       s51, #9
    v.st.w       [s29, #0], v2
    a.vread      v2, a14, s45
    s.addi       s45, s29, #576
    v.st.w       [s33, #0], v2
    a.vread      v2, a14, s46
    s.movz       s33, #10
    s.addi       s46, s29, #640
    v.st.w       [s39, #0], v2
    a.vread      v2, a14, s47
    s.movz       s39, #11
    s.addi       s47, s29, #704
    v.st.w       [s37, #0], v2
    a.vread      v2, a14, s48
    s.movz       s37, #12
    s.addi       s48, s29, #768
    v.st.w       [s38, #0], v2
    a.vread      v2, a14, s40
    s.movz       s38, #13
    s.addi       s40, s29, #832
    v.st.w       [s41, #0], v2
    a.vread      v2, a14, s49
    s.movz       s41, #14
    s.addi       s49, s29, #896
    s.addi       s52, s29, #960
    v.st.w       [s42, #0], v2
    a.vread      v2, a14, s43
    s.movz       s29, #15
    s.movz       s42, #0
    v.st.w       [s34, #0], v2
    a.vread      v2, a14, s44
    s.addi       s34, s31, #13056
    s.movz       s43, #1
    v.st.w       [s36, #0], v2
    a.vread      v2, a14, s51
    s.addi       s36, s34, #64
    s.movz       s44, #2
    v.st.w       [s45, #0], v2
    a.vread      v2, a14, s33
    s.addi       s33, s34, #128
    s.movz       s45, #3
    v.st.w       [s46, #0], v2
    a.vread      v2, a14, s39
    s.addi       s39, s34, #192
    s.movz       s46, #4
    v.st.w       [s47, #0], v2
    a.vread      v2, a14, s37
    s.addi       s37, s34, #256
    s.movz       s47, #5
    v.st.w       [s48, #0], v2
    a.vread      v2, a14, s38
    s.addi       s38, s34, #320
    s.movz       s48, #6
    v.st.w       [s40, #0], v2
    a.vread      v2, a14, s41
    s.addi       s40, s34, #384
    s.movz       s41, #7
    v.st.w       [s49, #0], v2
    a.vread      v2, a14, s29
    s.addi       s29, s34, #448
    s.movz       s49, #8
    v.st.w       [s52, #0], v2
    fence.acq_rel.device
    a.vread      v2, a15, s42
    s.addi       s42, s34, #512
    s.movz       s51, #9
    v.st.w       [s34, #0], v2
    a.vread      v2, a15, s43
    s.addi       s43, s34, #576
    v.st.w       [s36, #0], v2
    a.vread      v2, a15, s44
    s.movz       s36, #10
    s.addi       s44, s34, #640
    v.st.w       [s33, #0], v2
    a.vread      v2, a15, s45
    s.movz       s33, #11
    s.addi       s45, s34, #704
    v.st.w       [s39, #0], v2
    a.vread      v2, a15, s46
    s.movz       s39, #12
    s.addi       s46, s34, #768
    v.st.w       [s37, #0], v2
    a.vread      v2, a15, s47
    s.movz       s37, #13
    s.addi       s47, s34, #832
    v.st.w       [s38, #0], v2
    a.vread      v2, a15, s48
    s.movz       s38, #14
    s.addi       s48, s34, #896
    s.addi       s52, s34, #960
    v.st.w       [s40, #0], v2
    a.vread      v2, a15, s41
    s.movz       s34, #15
    s.movz       s40, #0
    v.st.w       [s29, #0], v2
    a.vread      v2, a15, s49
    s.addi       s29, s31, #5888
    v.extract    s41, v4, #0
    v.splat      v18, s41
    s.addi       s41, s31, #14080
    v.st.w       [s42, #0], v2
    a.vread      v2, a15, s51
    s.movz       s42, #1
    s.addi       s49, s31, #5952
    v.st.w       [s43, #0], v2
    a.vread      v2, a15, s36
    v.extract    s36, v4, #1
    s.addi       s43, s41, #64
    v.splat      v19, s36
    s.movz       s36, #2
    v.st.w       [s44, #0], v2
    a.vread      v2, a15, s33
    s.addi       s33, s31, #6016
    v.extract    s44, v4, #2
    v.splat      v20, s44
    s.addi       s44, s41, #128
    v.st.w       [s45, #0], v2
    a.vread      v2, a15, s39
    s.addi       s39, s41, #192
    v.st.w       [s46, #0], v2
    a.vread      v2, a15, s37
    s.movz       s37, #3
    s.addi       s45, s31, #6080
    v.st.w       [s47, #0], v2
    a.vread      v2, a15, s38
    v.extract    s38, v4, #3
    v.splat      v22, s38
    v.st.w       [s48, #0], v2
    a.vread      v2, a15, s34
    s.movz       s34, #4
    s.addi       s38, s41, #256
    v.st.w       [s52, #0], v2
    fence.acq_rel.device
    a.vread      v2, a0, s40
    s.addi       s40, s31, #6144
    v.extract    s46, v4, #4
    v.splat      v23, s46
    v.ld.w       v24, [s29, #0]
    vf.mul       v25, v24, v18
    s.addi       s29, s41, #320
    vf.mul       v18, v25, v31
    s.movz       s46, #5
    vf.add       v24, v2, v18
    v.st.w       [s41, #0], v24
    a.vread      v2, a0, s42
    s.addi       s42, s31, #6208
    v.extract    s47, v4, #5
    v.splat      v18, s47
    v.ld.w       v24, [s49, #0]
    vf.mul       v25, v24, v19
    s.addi       s47, s41, #384
    vf.mul       v19, v25, v31
    s.movz       s48, #6
    vf.add       v24, v2, v19
    v.st.w       [s43, #0], v24
    a.vread      v2, a0, s36
    s.addi       s36, s31, #6272
    v.extract    s43, v4, #6
    v.splat      v19, s43
    v.ld.w       v24, [s33, #0]
    vf.mul       v25, v24, v20
    s.addi       s33, s41, #448
    vf.mul       v20, v25, v31
    s.movz       s43, #7
    vf.add       v24, v2, v20
    v.st.w       [s44, #0], v24
    a.vread      v2, a0, s37
    s.addi       s37, s31, #6336
    v.extract    s44, v4, #7
    v.splat      v20, s44
    v.ld.w       v24, [s45, #0]
    vf.mul       v25, v24, v22
    s.addi       s44, s41, #512
    vf.mul       v22, v25, v31
    s.movz       s45, #8
    vf.add       v24, v2, v22
    v.st.w       [s39, #0], v24
    a.vread      v2, a0, s34
    s.addi       s34, s31, #6400
    v.extract    s39, v4, #8
    v.splat      v22, s39
    v.ld.w       v24, [s40, #0]
    vf.mul       v25, v24, v23
    s.addi       s39, s41, #576
    vf.mul       v23, v25, v31
    s.movz       s40, #9
    vf.add       v24, v2, v23
    v.st.w       [s38, #0], v24
    a.vread      v2, a0, s46
    s.addi       s38, s31, #6464
    v.extract    s46, v4, #9
    v.splat      v23, s46
    v.ld.w       v24, [s42, #0]
    vf.mul       v25, v24, v18
    s.addi       s42, s41, #640
    vf.mul       v18, v25, v31
    s.movz       s46, #10
    vf.add       v24, v2, v18
    v.st.w       [s29, #0], v24
    a.vread      v2, a0, s48
    s.addi       s29, s31, #6528
    v.extract    s48, v4, #10
    v.splat      v18, s48
    v.ld.w       v24, [s36, #0]
    vf.mul       v25, v24, v19
    s.addi       s36, s41, #704
    vf.mul       v19, v25, v31
    s.movz       s48, #11
    vf.add       v24, v2, v19
    v.st.w       [s47, #0], v24
    a.vread      v2, a0, s43
    s.addi       s43, s31, #6592
    v.extract    s47, v4, #11
    v.splat      v19, s47
    v.ld.w       v24, [s37, #0]
    vf.mul       v25, v24, v20
    s.addi       s37, s41, #768
    vf.mul       v20, v25, v31
    s.movz       s47, #12
    vf.add       v24, v2, v20
    v.st.w       [s33, #0], v24
    a.vread      v2, a0, s45
    s.addi       s33, s31, #6656
    v.extract    s45, v4, #12
    v.splat      v20, s45
    v.ld.w       v24, [s34, #0]
    vf.mul       v25, v24, v22
    s.addi       s34, s41, #832
    vf.mul       v22, v25, v31
    s.movz       s45, #13
    vf.add       v24, v2, v22
    v.st.w       [s44, #0], v24
    a.vread      v2, a0, s40
    s.addi       s40, s31, #6720
    v.extract    s44, v4, #13
    v.splat      v22, s44
    v.ld.w       v24, [s38, #0]
    vf.mul       v25, v24, v23
    s.addi       s38, s41, #896
    vf.mul       v23, v25, v31
    s.movz       s44, #14
    vf.add       v24, v2, v23
    v.st.w       [s39, #0], v24
    a.vread      v2, a0, s46
    s.addi       s39, s31, #6784
    v.extract    s46, v4, #14
    v.splat      v23, s46
    v.ld.w       v24, [s29, #0]
    vf.mul       v25, v24, v18
    s.addi       s29, s41, #960
    vf.mul       v18, v25, v31
    s.movz       s41, #15
    vf.add       v24, v2, v18
    v.st.w       [s42, #0], v24
    a.vread      v2, a0, s48
    s.addi       s42, s31, #6848
    v.extract    s46, v4, #15
    v.splat      v18, s46
    v.ld.w       v24, [s43, #0]
    vf.mul       v25, v24, v19
    vf.mul       v19, v25, v31
    s.addi       s43, s31, #15104
    vf.add       v24, v2, v19
    s.movz       s46, #0
    v.st.w       [s36, #0], v24
    a.vread      v2, a0, s47
    s.addi       s36, s31, #6912
    v.extract    s47, v4, #0
    v.splat      v19, s47
    v.ld.w       v24, [s33, #0]
    vf.mul       v25, v24, v20
    vf.mul       v20, v25, v31
    s.addi       s33, s43, #64
    vf.add       v24, v2, v20
    s.movz       s47, #1
    v.st.w       [s37, #0], v24
    a.vread      v2, a0, s45
    s.addi       s37, s31, #6976
    v.extract    s45, v4, #1
    v.splat      v20, s45
    v.ld.w       v24, [s40, #0]
    vf.mul       v25, v24, v22
    vf.mul       v22, v25, v31
    s.addi       s40, s43, #128
    vf.add       v24, v2, v22
    s.movz       s45, #2
    v.st.w       [s34, #0], v24
    a.vread      v2, a0, s44
    s.addi       s34, s31, #7040
    v.extract    s44, v4, #2
    v.splat      v22, s44
    v.ld.w       v24, [s39, #0]
    vf.mul       v25, v24, v23
    vf.mul       v23, v25, v31
    s.addi       s39, s43, #192
    vf.add       v24, v2, v23
    s.movz       s44, #3
    v.st.w       [s38, #0], v24
    a.vread      v2, a0, s41
    s.addi       s38, s31, #7104
    v.extract    s41, v4, #3
    v.splat      v23, s41
    v.ld.w       v24, [s42, #0]
    vf.mul       v25, v24, v18
    vf.mul       v18, v25, v31
    s.addi       s41, s43, #256
    vf.add       v24, v2, v18
    s.movz       s42, #4
    v.st.w       [s29, #0], v24
    fence.acq_rel.device
    a.vread      v2, a1, s46
    s.addi       s29, s31, #7168
    v.extract    s46, v4, #4
    v.splat      v18, s46
    v.ld.w       v24, [s36, #0]
    vf.mul       v25, v24, v19
    s.addi       s36, s43, #320
    vf.mul       v19, v25, v21
    s.movz       s46, #5
    vf.add       v24, v2, v19
    v.st.w       [s43, #0], v24
    a.vread      v2, a1, s47
    s.addi       s47, s31, #7232
    v.extract    s48, v4, #5
    v.splat      v19, s48
    v.ld.w       v24, [s37, #0]
    vf.mul       v25, v24, v20
    s.addi       s37, s43, #384
    vf.mul       v20, v25, v21
    s.movz       s48, #6
    vf.add       v24, v2, v20
    v.st.w       [s33, #0], v24
    a.vread      v2, a1, s45
    s.addi       s33, s31, #7296
    v.extract    s45, v4, #6
    v.splat      v20, s45
    v.ld.w       v24, [s34, #0]
    vf.mul       v25, v24, v22
    s.addi       s34, s43, #448
    vf.mul       v22, v25, v21
    s.movz       s45, #7
    vf.add       v24, v2, v22
    v.st.w       [s40, #0], v24
    a.vread      v2, a1, s44
    s.addi       s40, s31, #7360
    v.extract    s44, v4, #7
    v.splat      v22, s44
    v.ld.w       v24, [s38, #0]
    vf.mul       v25, v24, v23
    s.addi       s38, s43, #512
    vf.mul       v23, v25, v21
    s.movz       s44, #8
    vf.add       v24, v2, v23
    v.st.w       [s39, #0], v24
    a.vread      v2, a1, s42
    s.addi       s39, s31, #7424
    v.extract    s42, v4, #8
    v.splat      v23, s42
    v.ld.w       v24, [s29, #0]
    vf.mul       v25, v24, v18
    s.addi       s29, s43, #576
    vf.mul       v18, v25, v21
    s.movz       s42, #9
    vf.add       v24, v2, v18
    v.st.w       [s41, #0], v24
    a.vread      v2, a1, s46
    s.addi       s41, s31, #7488
    v.extract    s46, v4, #9
    v.splat      v18, s46
    v.ld.w       v24, [s47, #0]
    vf.mul       v25, v24, v19
    s.addi       s46, s43, #640
    vf.mul       v19, v25, v21
    s.movz       s47, #10
    vf.add       v24, v2, v19
    v.st.w       [s36, #0], v24
    a.vread      v2, a1, s48
    s.addi       s36, s31, #7552
    v.extract    s48, v4, #10
    v.splat      v19, s48
    v.ld.w       v24, [s33, #0]
    vf.mul       v25, v24, v20
    s.addi       s33, s43, #704
    vf.mul       v20, v25, v21
    s.movz       s48, #11
    vf.add       v24, v2, v20
    v.st.w       [s37, #0], v24
    a.vread      v2, a1, s45
    s.addi       s37, s31, #7616
    v.extract    s45, v4, #11
    v.splat      v20, s45
    v.ld.w       v24, [s40, #0]
    vf.mul       v25, v24, v22
    s.addi       s40, s43, #768
    vf.mul       v22, v25, v21
    s.movz       s45, #12
    vf.add       v24, v2, v22
    v.st.w       [s34, #0], v24
    a.vread      v2, a1, s44
    s.addi       s34, s31, #7680
    v.extract    s44, v4, #12
    v.splat      v22, s44
    v.ld.w       v24, [s39, #0]
    vf.mul       v25, v24, v23
    s.addi       s39, s43, #832
    vf.mul       v23, v25, v21
    s.movz       s44, #13
    vf.add       v24, v2, v23
    v.st.w       [s38, #0], v24
    a.vread      v2, a1, s42
    s.addi       s38, s31, #7744
    v.extract    s42, v4, #13
    v.splat      v23, s42
    v.ld.w       v24, [s41, #0]
    vf.mul       v25, v24, v18
    s.addi       s41, s43, #896
    vf.mul       v18, v25, v21
    s.movz       s42, #14
    vf.add       v24, v2, v18
    v.st.w       [s29, #0], v24
    a.vread      v2, a1, s47
    s.addi       s29, s31, #7808
    v.extract    s47, v4, #14
    v.splat      v18, s47
    v.ld.w       v24, [s36, #0]
    vf.mul       v25, v24, v19
    s.addi       s36, s43, #960
    vf.mul       v19, v25, v21
    s.movz       s43, #15
    vf.add       v24, v2, v19
    v.st.w       [s46, #0], v24
    a.vread      v2, a1, s48
    s.addi       s46, s31, #7872
    v.extract    s47, v4, #15
    v.splat      v19, s47
    v.ld.w       v24, [s37, #0]
    vf.mul       v25, v24, v20
    vf.mul       v20, v25, v21
    s.addi       s37, s31, #16128
    vf.add       v24, v2, v20
    s.movz       s47, #0
    v.st.w       [s33, #0], v24
    a.vread      v2, a1, s45
    s.addi       s33, s31, #7936
    v.extract    s45, v4, #0
    v.splat      v20, s45
    v.ld.w       v24, [s34, #0]
    vf.mul       v25, v24, v22
    vf.mul       v22, v25, v21
    s.addi       s34, s37, #64
    vf.add       v24, v2, v22
    s.movz       s45, #1
    v.st.w       [s40, #0], v24
    a.vread      v2, a1, s44
    s.addi       s40, s31, #8000
    v.extract    s44, v4, #1
    v.splat      v22, s44
    v.ld.w       v24, [s38, #0]
    vf.mul       v25, v24, v23
    vf.mul       v23, v25, v21
    s.addi       s38, s37, #128
    vf.add       v24, v2, v23
    s.movz       s44, #2
    v.st.w       [s39, #0], v24
    a.vread      v2, a1, s42
    s.addi       s39, s31, #8064
    v.extract    s42, v4, #2
    v.splat      v23, s42
    v.ld.w       v24, [s29, #0]
    vf.mul       v25, v24, v18
    vf.mul       v18, v25, v21
    s.addi       s29, s37, #192
    vf.add       v24, v2, v18
    s.movz       s42, #3
    v.st.w       [s41, #0], v24
    a.vread      v2, a1, s43
    s.addi       s41, s31, #8128
    v.extract    s43, v4, #3
    v.splat      v18, s43
    v.ld.w       v24, [s46, #0]
    vf.mul       v25, v24, v19
    vf.mul       v19, v25, v21
    s.addi       s43, s37, #256
    vf.add       v21, v2, v19
    s.movz       s46, #4
    v.st.w       [s36, #0], v21
    fence.acq_rel.device
    a.vread      v2, a2, s47
    s.addi       s36, s31, #8192
    v.extract    s47, v4, #4
    v.splat      v19, s47
    v.ld.w       v21, [s33, #0]
    vf.mul       v24, v21, v20
    s.addi       s33, s37, #320
    vf.mul       v20, v24, v33
    s.movz       s47, #5
    vf.add       v21, v2, v20
    v.st.w       [s37, #0], v21
    a.vread      v2, a2, s45
    s.addi       s45, s31, #8256
    v.extract    s48, v4, #5
    v.splat      v20, s48
    v.ld.w       v21, [s40, #0]
    vf.mul       v24, v21, v22
    s.addi       s40, s37, #384
    vf.mul       v21, v24, v33
    s.movz       s48, #6
    vf.add       v22, v2, v21
    v.st.w       [s34, #0], v22
    a.vread      v2, a2, s44
    s.addi       s34, s31, #8320
    v.extract    s44, v4, #6
    v.splat      v21, s44
    v.ld.w       v22, [s39, #0]
    vf.mul       v24, v22, v23
    s.addi       s39, s37, #448
    vf.mul       v22, v24, v33
    s.movz       s44, #7
    vf.add       v23, v2, v22
    v.st.w       [s38, #0], v23
    a.vread      v2, a2, s42
    s.addi       s38, s31, #8384
    v.extract    s42, v4, #7
    v.splat      v22, s42
    v.ld.w       v23, [s41, #0]
    vf.mul       v24, v23, v18
    s.addi       s41, s37, #512
    vf.mul       v18, v24, v33
    s.movz       s42, #8
    vf.add       v23, v2, v18
    v.st.w       [s29, #0], v23
    a.vread      v2, a2, s46
    s.addi       s29, s31, #8448
    v.extract    s46, v4, #8
    v.splat      v18, s46
    v.ld.w       v23, [s36, #0]
    vf.mul       v24, v23, v19
    s.addi       s36, s37, #576
    vf.mul       v19, v24, v33
    s.movz       s46, #9
    vf.add       v23, v2, v19
    v.st.w       [s43, #0], v23
    a.vread      v2, a2, s47
    s.addi       s43, s31, #8512
    v.extract    s47, v4, #9
    v.splat      v19, s47
    v.ld.w       v23, [s45, #0]
    vf.mul       v24, v23, v20
    s.addi       s45, s37, #640
    vf.mul       v20, v24, v33
    s.movz       s47, #10
    vf.add       v23, v2, v20
    v.st.w       [s33, #0], v23
    a.vread      v2, a2, s48
    s.addi       s33, s31, #8576
    v.extract    s48, v4, #10
    v.splat      v20, s48
    v.ld.w       v23, [s34, #0]
    vf.mul       v24, v23, v21
    s.addi       s34, s37, #704
    vf.mul       v21, v24, v33
    s.movz       s48, #11
    vf.add       v23, v2, v21
    v.st.w       [s40, #0], v23
    a.vread      v2, a2, s44
    s.addi       s40, s31, #8640
    v.extract    s44, v4, #11
    v.splat      v21, s44
    v.ld.w       v23, [s38, #0]
    vf.mul       v24, v23, v22
    s.addi       s38, s37, #768
    vf.mul       v22, v24, v33
    s.movz       s44, #12
    vf.add       v23, v2, v22
    v.st.w       [s39, #0], v23
    a.vread      v2, a2, s42
    s.addi       s39, s31, #8704
    v.extract    s42, v4, #12
    v.splat      v22, s42
    v.ld.w       v23, [s29, #0]
    vf.mul       v24, v23, v18
    s.addi       s29, s37, #832
    vf.mul       v18, v24, v33
    s.movz       s42, #13
    vf.add       v23, v2, v18
    v.st.w       [s41, #0], v23
    a.vread      v2, a2, s46
    s.addi       s41, s31, #8768
    v.extract    s46, v4, #13
    v.splat      v18, s46
    v.ld.w       v23, [s43, #0]
    vf.mul       v24, v23, v19
    s.addi       s43, s37, #896
    vf.mul       v19, v24, v33
    s.movz       s46, #14
    vf.add       v23, v2, v19
    v.st.w       [s36, #0], v23
    a.vread      v2, a2, s47
    s.addi       s36, s31, #8832
    v.extract    s47, v4, #14
    v.splat      v19, s47
    v.ld.w       v23, [s33, #0]
    vf.mul       v24, v23, v20
    s.addi       s33, s37, #960
    vf.mul       v20, v24, v33
    s.movz       s37, #15
    vf.add       v23, v2, v20
    v.st.w       [s45, #0], v23
    a.vread      v2, a2, s48
    s.addi       s45, s31, #8896
    v.extract    s47, v4, #15
    v.splat      v20, s47
    v.ld.w       v23, [s40, #0]
    vf.mul       v24, v23, v21
    vf.mul       v21, v24, v33
    s.addi       s40, s31, #17152
    vf.add       v23, v2, v21
    s.movz       s47, #0
    v.st.w       [s34, #0], v23
    a.vread      v2, a2, s44
    s.addi       s34, s31, #8960
    v.extract    s44, v4, #0
    v.splat      v21, s44
    v.ld.w       v23, [s39, #0]
    vf.mul       v24, v23, v22
    vf.mul       v22, v24, v33
    s.addi       s39, s40, #64
    vf.add       v23, v2, v22
    s.movz       s44, #1
    v.st.w       [s38, #0], v23
    a.vread      v2, a2, s42
    s.addi       s38, s31, #9024
    v.extract    s42, v4, #1
    v.splat      v22, s42
    v.ld.w       v23, [s41, #0]
    vf.mul       v24, v23, v18
    vf.mul       v18, v24, v33
    s.addi       s41, s40, #128
    vf.add       v23, v2, v18
    s.movz       s42, #2
    v.st.w       [s29, #0], v23
    a.vread      v2, a2, s46
    s.addi       s29, s31, #9088
    v.extract    s46, v4, #2
    v.splat      v18, s46
    v.ld.w       v23, [s36, #0]
    vf.mul       v24, v23, v19
    vf.mul       v19, v24, v33
    s.addi       s36, s40, #192
    vf.add       v23, v2, v19
    s.movz       s46, #3
    v.st.w       [s43, #0], v23
    a.vread      v2, a2, s37
    s.addi       s37, s31, #9152
    v.extract    s43, v4, #3
    v.splat      v19, s43
    v.ld.w       v23, [s45, #0]
    vf.mul       v24, v23, v20
    vf.mul       v20, v24, v33
    s.addi       s43, s40, #256
    vf.add       v23, v2, v20
    s.movz       s45, #4
    v.st.w       [s33, #0], v23
    fence.acq_rel.device
    a.vread      v2, a3, s47
    s.addi       s33, s31, #9216
    v.extract    s47, v4, #4
    v.splat      v20, s47
    v.ld.w       v23, [s34, #0]
    vf.mul       v24, v23, v21
    s.addi       s34, s40, #320
    vf.mul       v21, v24, v34
    s.movz       s47, #5
    vf.add       v23, v2, v21
    v.st.w       [s40, #0], v23
    a.vread      v2, a3, s44
    s.addi       s44, s31, #9280
    v.extract    s48, v4, #5
    v.splat      v21, s48
    v.ld.w       v23, [s38, #0]
    vf.mul       v24, v23, v22
    s.addi       s38, s40, #384
    vf.mul       v22, v24, v34
    s.movz       s48, #6
    vf.add       v23, v2, v22
    v.st.w       [s39, #0], v23
    a.vread      v2, a3, s42
    s.addi       s39, s31, #9344
    v.extract    s42, v4, #6
    v.splat      v22, s42
    v.ld.w       v23, [s29, #0]
    vf.mul       v24, v23, v18
    s.addi       s29, s40, #448
    vf.mul       v18, v24, v34
    s.movz       s42, #7
    vf.add       v23, v2, v18
    v.st.w       [s41, #0], v23
    a.vread      v2, a3, s46
    s.addi       s41, s31, #9408
    v.extract    s46, v4, #7
    v.splat      v18, s46
    v.ld.w       v23, [s37, #0]
    vf.mul       v24, v23, v19
    s.addi       s37, s40, #512
    vf.mul       v19, v24, v34
    s.movz       s46, #8
    vf.add       v23, v2, v19
    v.st.w       [s36, #0], v23
    a.vread      v2, a3, s45
    s.addi       s36, s31, #9472
    v.extract    s45, v4, #8
    v.splat      v19, s45
    v.ld.w       v23, [s33, #0]
    vf.mul       v24, v23, v20
    s.addi       s33, s40, #576
    vf.mul       v20, v24, v34
    s.movz       s45, #9
    vf.add       v23, v2, v20
    v.st.w       [s43, #0], v23
    a.vread      v2, a3, s47
    s.addi       s43, s31, #9536
    v.extract    s47, v4, #9
    v.splat      v20, s47
    v.ld.w       v23, [s44, #0]
    vf.mul       v24, v23, v21
    s.addi       s44, s40, #640
    vf.mul       v21, v24, v34
    s.movz       s47, #10
    vf.add       v23, v2, v21
    v.st.w       [s34, #0], v23
    a.vread      v2, a3, s48
    s.addi       s34, s31, #9600
    v.extract    s48, v4, #10
    v.splat      v21, s48
    v.ld.w       v23, [s39, #0]
    vf.mul       v24, v23, v22
    s.addi       s39, s40, #704
    vf.mul       v22, v24, v34
    s.movz       s48, #11
    vf.add       v23, v2, v22
    v.st.w       [s38, #0], v23
    a.vread      v2, a3, s42
    s.addi       s38, s31, #9664
    v.extract    s42, v4, #11
    v.splat      v22, s42
    v.ld.w       v23, [s41, #0]
    vf.mul       v24, v23, v18
    s.addi       s41, s40, #768
    vf.mul       v18, v24, v34
    s.movz       s42, #12
    vf.add       v23, v2, v18
    v.st.w       [s29, #0], v23
    a.vread      v2, a3, s46
    s.addi       s29, s31, #9728
    v.extract    s46, v4, #12
    v.splat      v18, s46
    v.ld.w       v23, [s36, #0]
    vf.mul       v24, v23, v19
    s.addi       s36, s40, #832
    vf.mul       v19, v24, v34
    s.movz       s46, #13
    vf.add       v23, v2, v19
    v.st.w       [s37, #0], v23
    a.vread      v2, a3, s45
    s.addi       s37, s31, #9792
    v.extract    s45, v4, #13
    v.splat      v19, s45
    v.ld.w       v23, [s43, #0]
    vf.mul       v24, v23, v20
    s.addi       s43, s40, #896
    vf.mul       v20, v24, v34
    s.movz       s45, #14
    vf.add       v23, v2, v20
    v.st.w       [s33, #0], v23
    a.vread      v2, a3, s47
    s.addi       s33, s31, #9856
    v.extract    s47, v4, #14
    v.splat      v20, s47
    v.ld.w       v23, [s34, #0]
    vf.mul       v24, v23, v21
    s.addi       s34, s40, #960
    vf.mul       v21, v24, v34
    s.movz       s40, #15
    vf.add       v23, v2, v21
    v.st.w       [s44, #0], v23
    a.vread      v2, a3, s48
    s.addi       s44, s31, #9920
    v.extract    s47, v4, #15
    v.splat      v21, s47
    v.ld.w       v23, [s38, #0]
    vf.mul       v24, v23, v22
    vf.mul       v22, v24, v34
    s.addi       s38, s31, #18176
    vf.add       v23, v2, v22
    s.movz       s47, #0
    v.st.w       [s39, #0], v23
    a.vread      v2, a3, s42
    s.addi       s39, s31, #9984
    v.extract    s42, v4, #0
    v.splat      v22, s42
    v.ld.w       v23, [s29, #0]
    vf.mul       v24, v23, v18
    vf.mul       v18, v24, v34
    s.addi       s29, s38, #64
    vf.add       v23, v2, v18
    s.movz       s42, #1
    v.st.w       [s41, #0], v23
    a.vread      v2, a3, s46
    s.addi       s41, s31, #10048
    v.extract    s46, v4, #1
    v.splat      v18, s46
    v.ld.w       v23, [s37, #0]
    vf.mul       v24, v23, v19
    vf.mul       v19, v24, v34
    s.addi       s37, s38, #128
    vf.add       v23, v2, v19
    s.movz       s46, #2
    v.st.w       [s36, #0], v23
    a.vread      v2, a3, s45
    s.addi       s36, s31, #10112
    v.extract    s45, v4, #2
    v.splat      v19, s45
    v.ld.w       v23, [s33, #0]
    vf.mul       v24, v23, v20
    vf.mul       v20, v24, v34
    s.addi       s33, s38, #192
    vf.add       v23, v2, v20
    s.movz       s45, #3
    v.st.w       [s43, #0], v23
    a.vread      v2, a3, s40
    s.addi       s40, s31, #10176
    v.extract    s43, v4, #3
    v.splat      v20, s43
    v.ld.w       v23, [s44, #0]
    vf.mul       v24, v23, v21
    vf.mul       v21, v24, v34
    s.addi       s43, s38, #256
    vf.add       v23, v2, v21
    s.movz       s44, #4
    v.st.w       [s34, #0], v23
    fence.acq_rel.device
    a.vread      v2, a4, s47
    s.addi       s34, s31, #10240
    v.extract    s47, v4, #4
    v.splat      v21, s47
    v.ld.w       v23, [s39, #0]
    vf.mul       v24, v23, v22
    s.addi       s39, s38, #320
    vf.mul       v22, v24, v35
    s.movz       s47, #5
    vf.add       v23, v2, v22
    v.st.w       [s38, #0], v23
    a.vread      v2, a4, s42
    s.addi       s42, s31, #10304
    v.extract    s48, v4, #5
    v.splat      v22, s48
    v.ld.w       v23, [s41, #0]
    vf.mul       v24, v23, v18
    s.addi       s41, s38, #384
    vf.mul       v18, v24, v35
    s.movz       s48, #6
    vf.add       v23, v2, v18
    v.st.w       [s29, #0], v23
    a.vread      v2, a4, s46
    s.addi       s29, s31, #10368
    v.extract    s46, v4, #6
    v.splat      v18, s46
    v.ld.w       v23, [s36, #0]
    vf.mul       v24, v23, v19
    s.addi       s36, s38, #448
    vf.mul       v19, v24, v35
    s.movz       s46, #7
    vf.add       v23, v2, v19
    v.st.w       [s37, #0], v23
    a.vread      v2, a4, s45
    s.addi       s37, s31, #10432
    v.extract    s45, v4, #7
    v.splat      v19, s45
    v.ld.w       v23, [s40, #0]
    vf.mul       v24, v23, v20
    s.addi       s40, s38, #512
    vf.mul       v20, v24, v35
    s.movz       s45, #8
    vf.add       v23, v2, v20
    v.st.w       [s33, #0], v23
    a.vread      v2, a4, s44
    s.addi       s33, s31, #10496
    v.extract    s44, v4, #8
    v.splat      v20, s44
    v.ld.w       v23, [s34, #0]
    vf.mul       v24, v23, v21
    s.addi       s34, s38, #576
    vf.mul       v21, v24, v35
    s.movz       s44, #9
    vf.add       v23, v2, v21
    v.st.w       [s43, #0], v23
    a.vread      v2, a4, s47
    s.addi       s43, s31, #10560
    v.extract    s47, v4, #9
    v.splat      v21, s47
    v.ld.w       v23, [s42, #0]
    vf.mul       v24, v23, v22
    s.addi       s42, s38, #640
    vf.mul       v22, v24, v35
    s.movz       s47, #10
    vf.add       v23, v2, v22
    v.st.w       [s39, #0], v23
    a.vread      v2, a4, s48
    s.addi       s39, s31, #10624
    v.extract    s48, v4, #10
    v.splat      v22, s48
    v.ld.w       v23, [s29, #0]
    vf.mul       v24, v23, v18
    s.addi       s29, s38, #704
    vf.mul       v18, v24, v35
    s.movz       s48, #11
    vf.add       v23, v2, v18
    v.st.w       [s41, #0], v23
    a.vread      v2, a4, s46
    s.addi       s41, s31, #10688
    v.extract    s46, v4, #11
    v.splat      v18, s46
    v.ld.w       v23, [s37, #0]
    vf.mul       v24, v23, v19
    s.addi       s37, s38, #768
    vf.mul       v19, v24, v35
    s.movz       s46, #12
    vf.add       v23, v2, v19
    v.st.w       [s36, #0], v23
    a.vread      v2, a4, s45
    s.addi       s36, s31, #10752
    v.extract    s45, v4, #12
    v.splat      v19, s45
    v.ld.w       v23, [s33, #0]
    vf.mul       v24, v23, v20
    s.addi       s33, s38, #832
    vf.mul       v20, v24, v35
    s.movz       s45, #13
    vf.add       v23, v2, v20
    v.st.w       [s40, #0], v23
    a.vread      v2, a4, s44
    s.addi       s40, s31, #10816
    v.extract    s44, v4, #13
    v.splat      v20, s44
    v.ld.w       v23, [s43, #0]
    vf.mul       v24, v23, v21
    s.addi       s43, s38, #896
    vf.mul       v21, v24, v35
    s.movz       s44, #14
    vf.add       v23, v2, v21
    v.st.w       [s34, #0], v23
    a.vread      v2, a4, s47
    s.addi       s34, s31, #10880
    v.extract    s47, v4, #14
    v.splat      v21, s47
    v.ld.w       v23, [s39, #0]
    vf.mul       v24, v23, v22
    s.addi       s39, s38, #960
    vf.mul       v22, v24, v35
    s.movz       s38, #15
    vf.add       v23, v2, v22
    v.st.w       [s42, #0], v23
    a.vread      v2, a4, s48
    s.addi       s42, s31, #10944
    v.extract    s47, v4, #15
    v.splat      v22, s47
    v.ld.w       v23, [s41, #0]
    vf.mul       v24, v23, v18
    vf.mul       v18, v24, v35
    s.addi       s41, s31, #19200
    vf.add       v23, v2, v18
    s.movz       s47, #0
    v.st.w       [s29, #0], v23
    a.vread      v2, a4, s46
    s.addi       s29, s31, #11008
    v.extract    s46, v4, #0
    v.splat      v18, s46
    v.ld.w       v23, [s36, #0]
    vf.mul       v24, v23, v19
    vf.mul       v19, v24, v35
    s.addi       s36, s41, #64
    vf.add       v23, v2, v19
    s.movz       s46, #1
    v.st.w       [s37, #0], v23
    a.vread      v2, a4, s45
    s.addi       s37, s31, #11072
    v.extract    s45, v4, #1
    v.splat      v19, s45
    v.ld.w       v23, [s40, #0]
    vf.mul       v24, v23, v20
    vf.mul       v20, v24, v35
    s.addi       s40, s41, #128
    vf.add       v23, v2, v20
    s.movz       s45, #2
    v.st.w       [s33, #0], v23
    a.vread      v2, a4, s44
    s.addi       s33, s31, #11136
    v.extract    s44, v4, #2
    v.splat      v20, s44
    v.ld.w       v23, [s34, #0]
    vf.mul       v24, v23, v21
    vf.mul       v21, v24, v35
    s.addi       s34, s41, #192
    vf.add       v23, v2, v21
    s.movz       s44, #3
    v.st.w       [s43, #0], v23
    a.vread      v2, a4, s38
    s.addi       s38, s31, #11200
    v.extract    s43, v4, #3
    v.splat      v21, s43
    v.ld.w       v23, [s42, #0]
    vf.mul       v24, v23, v22
    vf.mul       v22, v24, v35
    s.addi       s42, s41, #256
    vf.add       v23, v2, v22
    s.movz       s43, #4
    v.st.w       [s39, #0], v23
    fence.acq_rel.device
    a.vread      v2, a5, s47
    s.addi       s39, s31, #11264
    v.extract    s47, v4, #4
    v.splat      v22, s47
    v.ld.w       v23, [s29, #0]
    vf.mul       v24, v23, v18
    s.addi       s29, s41, #320
    vf.mul       v18, v24, v36
    s.movz       s47, #5
    vf.add       v23, v2, v18
    v.st.w       [s41, #0], v23
    a.vread      v2, a5, s46
    s.addi       s46, s31, #11328
    v.extract    s48, v4, #5
    v.splat      v18, s48
    v.ld.w       v23, [s37, #0]
    vf.mul       v24, v23, v19
    s.addi       s37, s41, #384
    vf.mul       v19, v24, v36
    s.movz       s48, #6
    vf.add       v23, v2, v19
    v.st.w       [s36, #0], v23
    a.vread      v2, a5, s45
    s.addi       s36, s31, #11392
    v.extract    s45, v4, #6
    v.splat      v19, s45
    v.ld.w       v23, [s33, #0]
    vf.mul       v24, v23, v20
    s.addi       s33, s41, #448
    vf.mul       v20, v24, v36
    s.movz       s45, #7
    vf.add       v23, v2, v20
    v.st.w       [s40, #0], v23
    a.vread      v2, a5, s44
    s.addi       s40, s31, #11456
    v.extract    s44, v4, #7
    v.splat      v20, s44
    v.ld.w       v23, [s38, #0]
    vf.mul       v24, v23, v21
    s.addi       s38, s41, #512
    vf.mul       v21, v24, v36
    s.movz       s44, #8
    vf.add       v23, v2, v21
    v.st.w       [s34, #0], v23
    a.vread      v2, a5, s43
    s.addi       s34, s31, #11520
    v.extract    s43, v4, #8
    v.splat      v21, s43
    v.ld.w       v23, [s39, #0]
    vf.mul       v24, v23, v22
    s.addi       s39, s41, #576
    vf.mul       v22, v24, v36
    s.movz       s43, #9
    vf.add       v23, v2, v22
    v.st.w       [s42, #0], v23
    a.vread      v2, a5, s47
    s.addi       s42, s31, #11584
    v.extract    s47, v4, #9
    v.splat      v22, s47
    v.ld.w       v23, [s46, #0]
    vf.mul       v24, v23, v18
    s.addi       s46, s41, #640
    vf.mul       v18, v24, v36
    s.movz       s47, #10
    vf.add       v23, v2, v18
    v.st.w       [s29, #0], v23
    a.vread      v2, a5, s48
    s.addi       s29, s31, #11648
    v.extract    s48, v4, #10
    v.splat      v18, s48
    v.ld.w       v23, [s36, #0]
    vf.mul       v24, v23, v19
    s.addi       s36, s41, #704
    vf.mul       v19, v24, v36
    s.movz       s48, #11
    vf.add       v23, v2, v19
    v.st.w       [s37, #0], v23
    a.vread      v2, a5, s45
    s.addi       s37, s31, #11712
    v.extract    s45, v4, #11
    v.splat      v19, s45
    v.ld.w       v23, [s40, #0]
    vf.mul       v24, v23, v20
    s.addi       s40, s41, #768
    vf.mul       v20, v24, v36
    s.movz       s45, #12
    vf.add       v23, v2, v20
    v.st.w       [s33, #0], v23
    a.vread      v2, a5, s44
    s.addi       s33, s31, #11776
    v.extract    s44, v4, #12
    v.splat      v20, s44
    v.ld.w       v23, [s34, #0]
    vf.mul       v24, v23, v21
    s.addi       s34, s41, #832
    vf.mul       v21, v24, v36
    s.movz       s44, #13
    vf.add       v23, v2, v21
    v.st.w       [s38, #0], v23
    a.vread      v2, a5, s43
    s.addi       s38, s31, #11840
    v.extract    s43, v4, #13
    v.splat      v21, s43
    v.ld.w       v23, [s42, #0]
    vf.mul       v24, v23, v22
    s.addi       s42, s41, #896
    vf.mul       v22, v24, v36
    s.movz       s43, #14
    vf.add       v23, v2, v22
    v.st.w       [s39, #0], v23
    a.vread      v2, a5, s47
    s.addi       s39, s31, #11904
    v.extract    s47, v4, #14
    v.splat      v22, s47
    v.ld.w       v23, [s29, #0]
    vf.mul       v24, v23, v18
    s.addi       s29, s41, #960
    vf.mul       v18, v24, v36
    s.movz       s41, #15
    vf.add       v23, v2, v18
    v.st.w       [s46, #0], v23
    a.vread      v2, a5, s48
    s.addi       s46, s31, #11968
    v.extract    s47, v4, #15
    v.splat      v18, s47
    v.ld.w       v23, [s37, #0]
    vf.mul       v24, v23, v19
    vf.mul       v19, v24, v36
    s.addi       s37, s31, #20224
    vf.add       v23, v2, v19
    s.movz       s47, #0
    v.st.w       [s36, #0], v23
    a.vread      v2, a5, s45
    s.addi       s36, s31, #12032
    v.extract    s45, v4, #0
    v.splat      v19, s45
    v.ld.w       v23, [s33, #0]
    vf.mul       v24, v23, v20
    vf.mul       v20, v24, v36
    s.addi       s33, s37, #64
    vf.add       v23, v2, v20
    s.movz       s45, #1
    v.st.w       [s40, #0], v23
    a.vread      v2, a5, s44
    s.addi       s40, s31, #12096
    v.extract    s44, v4, #1
    v.splat      v20, s44
    v.ld.w       v23, [s38, #0]
    vf.mul       v24, v23, v21
    vf.mul       v21, v24, v36
    s.addi       s38, s37, #128
    vf.add       v23, v2, v21
    s.movz       s44, #2
    v.st.w       [s34, #0], v23
    a.vread      v2, a5, s43
    s.addi       s34, s31, #12160
    v.extract    s43, v4, #2
    v.splat      v21, s43
    v.ld.w       v23, [s39, #0]
    vf.mul       v24, v23, v22
    vf.mul       v22, v24, v36
    s.addi       s39, s37, #192
    vf.add       v23, v2, v22
    s.movz       s43, #3
    v.st.w       [s42, #0], v23
    a.vread      v2, a5, s41
    s.addi       s41, s31, #12224
    v.extract    s42, v4, #3
    v.splat      v22, s42
    v.ld.w       v23, [s46, #0]
    vf.mul       v24, v23, v18
    vf.mul       v18, v24, v36
    s.addi       s42, s37, #256
    vf.add       v23, v2, v18
    s.movz       s46, #4
    v.st.w       [s29, #0], v23
    fence.acq_rel.device
    a.vread      v2, a6, s47
    s.addi       s29, s31, #12288
    v.extract    s47, v4, #4
    v.splat      v18, s47
    v.ld.w       v23, [s36, #0]
    vf.mul       v24, v23, v19
    s.addi       s36, s37, #320
    vf.mul       v19, v24, v37
    s.movz       s47, #5
    vf.add       v23, v2, v19
    v.st.w       [s37, #0], v23
    a.vread      v2, a6, s45
    s.addi       s45, s31, #12352
    v.extract    s48, v4, #5
    v.splat      v19, s48
    v.ld.w       v23, [s40, #0]
    vf.mul       v24, v23, v20
    s.addi       s40, s37, #384
    vf.mul       v20, v24, v37
    s.movz       s48, #6
    vf.add       v23, v2, v20
    v.st.w       [s33, #0], v23
    a.vread      v2, a6, s44
    s.addi       s33, s31, #12416
    v.extract    s44, v4, #6
    v.splat      v20, s44
    v.ld.w       v23, [s34, #0]
    vf.mul       v24, v23, v21
    s.addi       s34, s37, #448
    vf.mul       v21, v24, v37
    s.movz       s44, #7
    vf.add       v23, v2, v21
    v.st.w       [s38, #0], v23
    a.vread      v2, a6, s43
    s.addi       s38, s31, #12480
    v.extract    s43, v4, #7
    v.splat      v21, s43
    v.ld.w       v23, [s41, #0]
    vf.mul       v24, v23, v22
    s.addi       s41, s37, #512
    vf.mul       v22, v24, v37
    s.movz       s43, #8
    vf.add       v23, v2, v22
    v.st.w       [s39, #0], v23
    a.vread      v2, a6, s46
    s.addi       s39, s31, #12544
    v.extract    s46, v4, #8
    v.splat      v22, s46
    v.ld.w       v23, [s29, #0]
    vf.mul       v24, v23, v18
    s.addi       s29, s37, #576
    vf.mul       v18, v24, v37
    s.movz       s46, #9
    vf.add       v23, v2, v18
    v.st.w       [s42, #0], v23
    a.vread      v2, a6, s47
    s.addi       s42, s31, #12608
    v.extract    s47, v4, #9
    v.splat      v18, s47
    v.ld.w       v23, [s45, #0]
    vf.mul       v24, v23, v19
    s.addi       s45, s37, #640
    vf.mul       v19, v24, v37
    s.movz       s47, #10
    vf.add       v23, v2, v19
    v.st.w       [s36, #0], v23
    a.vread      v2, a6, s48
    s.addi       s36, s31, #12672
    v.extract    s48, v4, #10
    v.splat      v19, s48
    v.ld.w       v23, [s33, #0]
    vf.mul       v24, v23, v20
    s.addi       s33, s37, #704
    vf.mul       v20, v24, v37
    s.movz       s48, #11
    vf.add       v23, v2, v20
    v.st.w       [s40, #0], v23
    a.vread      v2, a6, s44
    s.addi       s40, s31, #12736
    v.extract    s44, v4, #11
    v.splat      v20, s44
    v.ld.w       v23, [s38, #0]
    vf.mul       v24, v23, v21
    s.addi       s38, s37, #768
    vf.mul       v21, v24, v37
    s.movz       s44, #12
    vf.add       v23, v2, v21
    v.st.w       [s34, #0], v23
    a.vread      v2, a6, s43
    s.addi       s34, s31, #12800
    v.extract    s43, v4, #12
    v.splat      v21, s43
    v.ld.w       v23, [s39, #0]
    vf.mul       v24, v23, v22
    s.addi       s39, s37, #832
    vf.mul       v22, v24, v37
    s.movz       s43, #13
    vf.add       v23, v2, v22
    v.st.w       [s41, #0], v23
    a.vread      v2, a6, s46
    s.addi       s41, s31, #12864
    v.extract    s46, v4, #13
    v.splat      v22, s46
    v.ld.w       v23, [s42, #0]
    vf.mul       v24, v23, v18
    s.addi       s42, s37, #896
    vf.mul       v18, v24, v37
    s.movz       s46, #14
    vf.add       v23, v2, v18
    v.st.w       [s29, #0], v23
    a.vread      v2, a6, s47
    s.addi       s29, s31, #12928
    v.extract    s47, v4, #14
    v.splat      v18, s47
    v.ld.w       v23, [s36, #0]
    vf.mul       v24, v23, v19
    s.addi       s36, s37, #960
    vf.mul       v19, v24, v37
    s.movz       s37, #15
    vf.add       v23, v2, v19
    v.st.w       [s45, #0], v23
    a.vread      v2, a6, s48
    s.addi       s45, s31, #12992
    v.extract    s47, v4, #15
    v.splat      v19, s47
    v.ld.w       v23, [s40, #0]
    vf.mul       v24, v23, v20
    vf.mul       v20, v24, v37
    s.addi       s40, s31, #21248
    vf.add       v23, v2, v20
    s.movz       s47, #0
    v.st.w       [s33, #0], v23
    a.vread      v2, a6, s44
    s.addi       s33, s31, #13056
    v.extract    s44, v4, #0
    v.splat      v20, s44
    v.ld.w       v23, [s34, #0]
    vf.mul       v24, v23, v21
    vf.mul       v21, v24, v37
    s.addi       s34, s40, #64
    vf.add       v23, v2, v21
    s.movz       s44, #1
    v.st.w       [s38, #0], v23
    a.vread      v2, a6, s43
    s.addi       s38, s31, #13120
    v.extract    s43, v4, #1
    v.splat      v21, s43
    v.ld.w       v23, [s41, #0]
    vf.mul       v24, v23, v22
    vf.mul       v22, v24, v37
    s.addi       s41, s40, #128
    vf.add       v23, v2, v22
    s.movz       s43, #2
    v.st.w       [s39, #0], v23
    a.vread      v2, a6, s46
    s.addi       s39, s31, #13184
    v.extract    s46, v4, #2
    v.splat      v22, s46
    v.ld.w       v23, [s29, #0]
    vf.mul       v24, v23, v18
    vf.mul       v18, v24, v37
    s.addi       s29, s40, #192
    vf.add       v23, v2, v18
    s.movz       s46, #3
    v.st.w       [s42, #0], v23
    a.vread      v2, a6, s37
    s.addi       s37, s31, #13248
    v.extract    s42, v4, #3
    v.splat      v18, s42
    v.ld.w       v23, [s45, #0]
    vf.mul       v24, v23, v19
    vf.mul       v19, v24, v37
    s.addi       s42, s40, #256
    vf.add       v23, v2, v19
    s.movz       s45, #4
    v.st.w       [s36, #0], v23
    fence.acq_rel.device
    a.vread      v2, a7, s47
    s.addi       s36, s31, #13312
    v.extract    s47, v4, #4
    v.splat      v19, s47
    v.ld.w       v23, [s33, #0]
    vf.mul       v24, v23, v20
    s.addi       s33, s40, #320
    vf.mul       v20, v24, v38
    s.movz       s47, #5
    vf.add       v23, v2, v20
    v.st.w       [s40, #0], v23
    a.vread      v2, a7, s44
    s.addi       s44, s31, #13376
    v.extract    s48, v4, #5
    v.splat      v20, s48
    v.ld.w       v23, [s38, #0]
    vf.mul       v24, v23, v21
    s.addi       s38, s40, #384
    vf.mul       v21, v24, v38
    s.movz       s48, #6
    vf.add       v23, v2, v21
    v.st.w       [s34, #0], v23
    a.vread      v2, a7, s43
    s.addi       s34, s31, #13440
    v.extract    s43, v4, #6
    v.splat      v21, s43
    v.ld.w       v23, [s39, #0]
    vf.mul       v24, v23, v22
    s.addi       s39, s40, #448
    vf.mul       v22, v24, v38
    s.movz       s43, #7
    vf.add       v23, v2, v22
    v.st.w       [s41, #0], v23
    a.vread      v2, a7, s46
    s.addi       s41, s31, #13504
    v.extract    s46, v4, #7
    v.splat      v22, s46
    v.ld.w       v23, [s37, #0]
    vf.mul       v24, v23, v18
    s.addi       s37, s40, #512
    vf.mul       v18, v24, v38
    s.movz       s46, #8
    vf.add       v23, v2, v18
    v.st.w       [s29, #0], v23
    a.vread      v2, a7, s45
    s.addi       s29, s31, #13568
    v.extract    s45, v4, #8
    v.splat      v18, s45
    v.ld.w       v23, [s36, #0]
    vf.mul       v24, v23, v19
    s.addi       s36, s40, #576
    vf.mul       v19, v24, v38
    s.movz       s45, #9
    vf.add       v23, v2, v19
    v.st.w       [s42, #0], v23
    a.vread      v2, a7, s47
    s.addi       s42, s31, #13632
    v.extract    s47, v4, #9
    v.splat      v19, s47
    v.ld.w       v23, [s44, #0]
    vf.mul       v24, v23, v20
    s.addi       s44, s40, #640
    vf.mul       v20, v24, v38
    s.movz       s47, #10
    vf.add       v23, v2, v20
    v.st.w       [s33, #0], v23
    a.vread      v2, a7, s48
    s.addi       s33, s31, #13696
    v.extract    s48, v4, #10
    v.splat      v20, s48
    v.ld.w       v23, [s34, #0]
    vf.mul       v24, v23, v21
    s.addi       s34, s40, #704
    vf.mul       v21, v24, v38
    s.movz       s48, #11
    vf.add       v23, v2, v21
    v.st.w       [s38, #0], v23
    a.vread      v2, a7, s43
    s.addi       s38, s31, #13760
    v.extract    s43, v4, #11
    v.splat      v21, s43
    v.ld.w       v23, [s41, #0]
    vf.mul       v24, v23, v22
    s.addi       s41, s40, #768
    vf.mul       v22, v24, v38
    s.movz       s43, #12
    vf.add       v23, v2, v22
    v.st.w       [s39, #0], v23
    a.vread      v2, a7, s46
    s.addi       s39, s31, #13824
    v.extract    s46, v4, #12
    v.splat      v22, s46
    v.ld.w       v23, [s29, #0]
    vf.mul       v24, v23, v18
    s.addi       s29, s40, #832
    vf.mul       v18, v24, v38
    s.movz       s46, #13
    vf.add       v23, v2, v18
    v.st.w       [s37, #0], v23
    a.vread      v2, a7, s45
    s.addi       s37, s31, #13888
    v.extract    s45, v4, #13
    v.splat      v18, s45
    v.ld.w       v23, [s42, #0]
    vf.mul       v24, v23, v19
    s.addi       s42, s40, #896
    vf.mul       v19, v24, v38
    s.movz       s45, #14
    vf.add       v23, v2, v19
    v.st.w       [s36, #0], v23
    a.vread      v2, a7, s47
    s.addi       s36, s31, #13952
    v.extract    s47, v4, #14
    v.splat      v19, s47
    v.ld.w       v23, [s33, #0]
    vf.mul       v24, v23, v20
    s.addi       s33, s40, #960
    vf.mul       v20, v24, v38
    s.movz       s40, #15
    vf.add       v23, v2, v20
    v.st.w       [s44, #0], v23
    a.vread      v2, a7, s48
    s.addi       s44, s31, #14016
    v.extract    s47, v4, #15
    v.splat      v4, s47
    v.ld.w       v20, [s38, #0]
    vf.mul       v23, v20, v21
    vf.mul       v20, v23, v38
    s.addi       s38, s18, #128
    vf.add       v21, v2, v20
    s.addi       s47, s38, #0
    v.st.w       [s34, #0], v21
    a.vread      v2, a7, s43
    s.addi       s34, s24, #128
    s.addi       s38, s25, #4                    // &ptr_carry_17[1] (a constant offset, x4)
    s.addi       s43, s34, #0
    s.addi       s34, s38, #0
    s.addi       s38, s25, #4                    // &ptr_carry_18[1] (a constant offset, x4)
    v.ld.w       v20, [s39, #0]
    s.addi       s38, s25, #4                    // &ptr_carry_19[1] (a constant offset, x4)
    s.addi       s38, s25, #4                    // &ptr_carry_20[1] (a constant offset, x4)
    s.addi       s38, s25, #4                    // &ptr_carry_21[1] (a constant offset, x4)
    vf.mul       v21, v20, v22
    s.addi       s38, s25, #4                    // &ptr_carry_22[1] (a constant offset, x4)
    vf.mul       v20, v21, v38
    s.addi       s38, s25, #4                    // &ptr_carry_23[1] (a constant offset, x4)
    vf.add       v21, v2, v20
    s.addi       s38, s25, #4                    // &ptr_carry_24[1] (a constant offset, x4)
    v.st.w       [s41, #0], v21
    a.vread      v2, a7, s46
    s.addi       s38, s31, #14080
    s.movz       s39, #0
    v.ld.w       v20, [s37, #0]
    s.movz       s37, #1
    vf.mul       v21, v20, v18
    s.addi       s41, s31, #14144
    vf.mul       v18, v21, v38
    vf.add       v20, v2, v18
    v.st.w       [s29, #0], v20
    a.vread      v2, a7, s45
    s.addi       s29, s31, #14208
    s.movz       s45, #2
    s.movz       s46, #3
    v.ld.w       v18, [s36, #0]
    s.addi       s36, s31, #14272
    vf.mul       v20, v18, v19
    s.movz       s48, #4
    vf.mul       v18, v20, v38
    s.addi       s49, s31, #14336
    vf.add       v19, v2, v18
    v.st.w       [s42, #0], v19
    a.vread      v2, a7, s40
    s.addi       s40, s31, #14400
    s.movz       s42, #5
    v.ld.w       v18, [s44, #0]
    s.addi       s44, s31, #14464
    s.movz       s51, #6
    vf.mul       v19, v18, v4
    vf.mul       v4, v19, v38
    vf.add       v18, v2, v4
    v.st.w       [s33, #0], v18
    fence.acq_rel.device
    s.mov        s18, s47
    s.mov        s24, s43
    s.mov        s25, s34
    s.addi       s33, s31, #14528
    s.movz       s34, #7
    s.addi       s43, s31, #14592
    s.movz       s47, #8
    s.addi       s52, s31, #14656
    s.movz       s53, #9
    s.addi       s54, s31, #14720
    v.ld.w       v2, [s38, #0]
    s.movz       s38, #10
    a.vwrite     a0, s39, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s31, #14784
    a.vwrite     a0, s37, v2
    v.ld.w       v2, [s29, #0]
    s.movz       s29, #11
    a.vwrite     a0, s45, v2
    v.ld.w       v2, [s36, #0]
    s.addi       s36, s31, #14848
    a.vwrite     a0, s46, v2
    v.ld.w       v2, [s49, #0]
    s.movz       s49, #12
    a.vwrite     a0, s48, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s31, #14912
    a.vwrite     a0, s42, v2
    v.ld.w       v2, [s44, #0]
    s.movz       s44, #13
    a.vwrite     a0, s51, v2
    v.ld.w       v2, [s33, #0]
    s.addi       s33, s31, #14976
    a.vwrite     a0, s34, v2
    v.ld.w       v2, [s43, #0]
    s.movz       s43, #14
    a.vwrite     a0, s47, v2
    v.ld.w       v2, [s52, #0]
    s.addi       s52, s31, #15040
    a.vwrite     a0, s53, v2
    v.ld.w       v2, [s54, #0]
    s.movz       s54, #15
    a.vwrite     a0, s38, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s31, #15104
    a.vwrite     a0, s29, v2
    v.ld.w       v2, [s36, #0]
    s.addi       s36, s31, #15168
    a.vwrite     a0, s49, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s31, #15232
    a.vwrite     a0, s44, v2
    v.ld.w       v2, [s33, #0]
    s.addi       s33, s31, #15296
    a.vwrite     a0, s43, v2
    v.ld.w       v2, [s52, #0]
    s.addi       s52, s31, #15360
    a.vwrite     a0, s54, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s31, #15424
    a.vwrite     a1, s39, v2
    v.ld.w       v2, [s36, #0]
    s.addi       s36, s31, #15488
    s.addi       s39, s31, #15552
    a.vwrite     a1, s37, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s37, s31, #15616
    s.addi       s40, s31, #15680
    a.vwrite     a1, s45, v2
    v.ld.w       v2, [s33, #0]
    s.addi       s33, s31, #15744
    s.addi       s45, s31, #15808
    a.vwrite     a1, s46, v2
    v.ld.w       v2, [s52, #0]
    s.addi       s46, s31, #15872
    s.addi       s52, s31, #15936
    a.vwrite     a1, s48, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s31, #16000
    s.addi       s48, s31, #16064
    a.vwrite     a1, s42, v2
    v.ld.w       v2, [s36, #0]
    s.addi       s36, s31, #16128
    s.movz       s42, #0
    a.vwrite     a1, s51, v2
    v.ld.w       v2, [s39, #0]
    s.addi       s39, s31, #16192
    s.movz       s51, #1
    a.vwrite     a1, s34, v2
    v.ld.w       v2, [s37, #0]
    s.addi       s34, s31, #16256
    s.movz       s37, #2
    a.vwrite     a1, s47, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s31, #16320
    s.movz       s47, #3
    a.vwrite     a1, s53, v2
    v.ld.w       v2, [s33, #0]
    s.addi       s33, s31, #16384
    s.movz       s53, #4
    a.vwrite     a1, s38, v2
    v.ld.w       v2, [s45, #0]
    s.addi       s38, s31, #16448
    s.movz       s45, #5
    a.vwrite     a1, s29, v2
    v.ld.w       v2, [s46, #0]
    s.addi       s29, s31, #16512
    s.movz       s46, #6
    a.vwrite     a1, s49, v2
    v.ld.w       v2, [s52, #0]
    s.addi       s49, s31, #16576
    s.movz       s52, #7
    a.vwrite     a1, s44, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s31, #16640
    s.movz       s44, #8
    a.vwrite     a1, s43, v2
    v.ld.w       v2, [s48, #0]
    s.addi       s43, s31, #16704
    s.movz       s48, #9
    a.vwrite     a1, s54, v2
    v.ld.w       v2, [s36, #0]
    s.addi       s36, s31, #16768
    s.movz       s54, #10
    a.vwrite     a2, s42, v2
    v.ld.w       v2, [s39, #0]
    s.addi       s39, s31, #16832
    a.vwrite     a2, s51, v2
    v.ld.w       v2, [s34, #0]
    s.movz       s34, #11
    a.vwrite     a2, s37, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s31, #16896
    a.vwrite     a2, s47, v2
    v.ld.w       v2, [s33, #0]
    s.movz       s33, #12
    a.vwrite     a2, s53, v2
    v.ld.w       v2, [s38, #0]
    s.addi       s38, s31, #16960
    a.vwrite     a2, s45, v2
    v.ld.w       v2, [s29, #0]
    s.movz       s29, #13
    a.vwrite     a2, s46, v2
    v.ld.w       v2, [s49, #0]
    s.addi       s49, s31, #17024
    a.vwrite     a2, s52, v2
    v.ld.w       v2, [s41, #0]
    s.movz       s41, #14
    a.vwrite     a2, s44, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s31, #17088
    a.vwrite     a2, s48, v2
    v.ld.w       v2, [s36, #0]
    s.movz       s36, #15
    a.vwrite     a2, s54, v2
    v.ld.w       v2, [s39, #0]
    s.addi       s39, s31, #17152
    a.vwrite     a2, s34, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s31, #17216
    a.vwrite     a2, s33, v2
    v.ld.w       v2, [s38, #0]
    s.addi       s38, s31, #17280
    a.vwrite     a2, s29, v2
    v.ld.w       v2, [s49, #0]
    s.addi       s49, s31, #17344
    a.vwrite     a2, s41, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s31, #17408
    a.vwrite     a2, s36, v2
    v.ld.w       v2, [s39, #0]
    s.addi       s39, s31, #17472
    a.vwrite     a3, s42, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s31, #17536
    s.addi       s42, s31, #17600
    a.vwrite     a3, s51, v2
    v.ld.w       v2, [s38, #0]
    s.addi       s38, s31, #17664
    s.addi       s51, s31, #17728
    a.vwrite     a3, s37, v2
    v.ld.w       v2, [s49, #0]
    s.addi       s37, s31, #17792
    s.addi       s49, s31, #17856
    a.vwrite     a3, s47, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s31, #17920
    s.addi       s47, s31, #17984
    a.vwrite     a3, s53, v2
    v.ld.w       v2, [s39, #0]
    s.addi       s39, s31, #18048
    s.addi       s53, s31, #18112
    a.vwrite     a3, s45, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s31, #18176
    s.movz       s45, #0
    a.vwrite     a3, s46, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s31, #18240
    s.movz       s46, #1
    a.vwrite     a3, s52, v2
    v.ld.w       v2, [s38, #0]
    s.addi       s38, s31, #18304
    s.movz       s52, #2
    a.vwrite     a3, s44, v2
    v.ld.w       v2, [s51, #0]
    s.addi       s44, s31, #18368
    s.movz       s51, #3
    a.vwrite     a3, s48, v2
    v.ld.w       v2, [s37, #0]
    s.addi       s37, s31, #18432
    s.movz       s48, #4
    a.vwrite     a3, s54, v2
    v.ld.w       v2, [s49, #0]
    s.addi       s49, s31, #18496
    s.movz       s54, #5
    a.vwrite     a3, s34, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s34, s31, #18560
    s.movz       s43, #6
    a.vwrite     a3, s33, v2
    v.ld.w       v2, [s47, #0]
    s.addi       s33, s31, #18624
    s.movz       s47, #7
    a.vwrite     a3, s29, v2
    v.ld.w       v2, [s39, #0]
    s.addi       s29, s31, #18688
    s.movz       s39, #8
    a.vwrite     a3, s41, v2
    v.ld.w       v2, [s53, #0]
    s.addi       s41, s31, #18752
    s.movz       s53, #9
    a.vwrite     a3, s36, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s36, s31, #18816
    s.movz       s40, #10
    a.vwrite     a4, s45, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s31, #18880
    a.vwrite     a4, s46, v2
    v.ld.w       v2, [s38, #0]
    s.movz       s38, #11
    a.vwrite     a4, s52, v2
    v.ld.w       v2, [s44, #0]
    s.addi       s44, s31, #18944
    a.vwrite     a4, s51, v2
    v.ld.w       v2, [s37, #0]
    s.movz       s37, #12
    a.vwrite     a4, s48, v2
    v.ld.w       v2, [s49, #0]
    s.addi       s49, s31, #19008
    a.vwrite     a4, s54, v2
    v.ld.w       v2, [s34, #0]
    s.movz       s34, #13
    a.vwrite     a4, s43, v2
    v.ld.w       v2, [s33, #0]
    s.addi       s33, s31, #19072
    a.vwrite     a4, s47, v2
    v.ld.w       v2, [s29, #0]
    s.movz       s29, #14
    a.vwrite     a4, s39, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s31, #19136
    a.vwrite     a4, s53, v2
    v.ld.w       v2, [s36, #0]
    s.movz       s36, #15
    a.vwrite     a4, s40, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s31, #19200
    a.vwrite     a4, s38, v2
    v.ld.w       v2, [s44, #0]
    s.addi       s44, s31, #19264
    a.vwrite     a4, s37, v2
    v.ld.w       v2, [s49, #0]
    s.addi       s49, s31, #19328
    a.vwrite     a4, s34, v2
    v.ld.w       v2, [s33, #0]
    s.addi       s33, s31, #19392
    a.vwrite     a4, s29, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s31, #19456
    a.vwrite     a4, s36, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s31, #19520
    a.vwrite     a5, s45, v2
    v.ld.w       v2, [s44, #0]
    s.addi       s44, s31, #19584
    s.addi       s45, s31, #19648
    a.vwrite     a5, s46, v2
    v.ld.w       v2, [s49, #0]
    s.addi       s46, s31, #19712
    s.addi       s49, s31, #19776
    a.vwrite     a5, s52, v2
    v.ld.w       v2, [s33, #0]
    s.addi       s33, s31, #19840
    s.addi       s52, s31, #19904
    a.vwrite     a5, s51, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s31, #19968
    s.addi       s51, s31, #20032
    a.vwrite     a5, s48, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s31, #20096
    s.addi       s48, s31, #20160
    a.vwrite     a5, s54, v2
    v.ld.w       v2, [s44, #0]
    s.addi       s44, s31, #20224
    s.movz       s54, #0
    a.vwrite     a5, s43, v2
    v.ld.w       v2, [s45, #0]
    s.addi       s43, s31, #20288
    s.movz       s45, #1
    a.vwrite     a5, s47, v2
    v.ld.w       v2, [s46, #0]
    s.addi       s46, s31, #20352
    s.movz       s47, #2
    a.vwrite     a5, s39, v2
    v.ld.w       v2, [s49, #0]
    s.addi       s39, s31, #20416
    s.movz       s49, #3
    a.vwrite     a5, s53, v2
    v.ld.w       v2, [s33, #0]
    s.addi       s33, s31, #20480
    s.movz       s53, #4
    a.vwrite     a5, s40, v2
    v.ld.w       v2, [s52, #0]
    s.addi       s40, s31, #20544
    s.movz       s52, #5
    a.vwrite     a5, s38, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s38, s31, #20608
    s.movz       s41, #6
    a.vwrite     a5, s37, v2
    v.ld.w       v2, [s51, #0]
    s.addi       s37, s31, #20672
    s.movz       s51, #7
    a.vwrite     a5, s34, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s34, s31, #20736
    s.movz       s42, #8
    a.vwrite     a5, s29, v2
    v.ld.w       v2, [s48, #0]
    s.addi       s29, s31, #20800
    s.movz       s48, #9
    a.vwrite     a5, s36, v2
    v.ld.w       v2, [s44, #0]
    s.addi       s36, s31, #20864
    s.movz       s44, #10
    a.vwrite     a6, s54, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s31, #20928
    a.vwrite     a6, s45, v2
    v.ld.w       v2, [s46, #0]
    s.movz       s46, #11
    a.vwrite     a6, s47, v2
    v.ld.w       v2, [s39, #0]
    s.addi       s39, s31, #20992
    a.vwrite     a6, s49, v2
    v.ld.w       v2, [s33, #0]
    s.movz       s33, #12
    a.vwrite     a6, s53, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s31, #21056
    a.vwrite     a6, s52, v2
    v.ld.w       v2, [s38, #0]
    s.movz       s38, #13
    a.vwrite     a6, s41, v2
    v.ld.w       v2, [s37, #0]
    s.addi       s37, s31, #21120
    a.vwrite     a6, s51, v2
    v.ld.w       v2, [s34, #0]
    s.movz       s34, #14
    a.vwrite     a6, s42, v2
    v.ld.w       v2, [s29, #0]
    s.addi       s29, s31, #21184
    a.vwrite     a6, s48, v2
    v.ld.w       v2, [s36, #0]
    s.movz       s36, #15
    a.vwrite     a6, s44, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s31, #21248
    a.vwrite     a6, s46, v2
    v.ld.w       v2, [s39, #0]
    s.addi       s39, s31, #21312
    a.vwrite     a6, s33, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s31, #21376
    a.vwrite     a6, s38, v2
    v.ld.w       v2, [s37, #0]
    s.addi       s37, s31, #21440
    a.vwrite     a6, s34, v2
    v.ld.w       v2, [s29, #0]
    s.addi       s29, s31, #21504
    a.vwrite     a6, s36, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s31, #21568
    a.vwrite     a7, s54, v2
    v.ld.w       v2, [s39, #0]
    s.addi       s39, s31, #21632
    s.addi       s54, s31, #21696
    a.vwrite     a7, s45, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s31, #21760
    s.addi       s45, s31, #21824
    a.vwrite     a7, s47, v2
    v.ld.w       v2, [s37, #0]
    s.addi       s37, s31, #21888
    s.addi       s47, s31, #21952
    a.vwrite     a7, s49, v2
    v.ld.w       v2, [s29, #0]
    s.addi       s29, s31, #22016
    s.addi       s49, s31, #22080
    a.vwrite     a7, s53, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s31, #22144
    s.addi       s53, s31, #22208
    s.add        s31, s17, s10
    a.vwrite     a7, s52, v2
    v.ld.w       v2, [s39, #0]
    s.movz       s39, #1
    a.vwrite     a7, s41, v2
    v.ld.w       v2, [s54, #0]
    a.vwrite     a7, s51, v2
    v.ld.w       v2, [s40, #0]
    a.vwrite     a7, s42, v2
    v.ld.w       v2, [s45, #0]
    a.vwrite     a7, s48, v2
    v.ld.w       v2, [s37, #0]
    a.vwrite     a7, s44, v2
    v.ld.w       v2, [s47, #0]
    a.vwrite     a7, s46, v2
    v.ld.w       v2, [s29, #0]
    a.vwrite     a7, s33, v2
    v.ld.w       v2, [s49, #0]
    a.vwrite     a7, s38, v2
    v.ld.w       v2, [s43, #0]
    a.vwrite     a7, s34, v2
    v.ld.w       v2, [s53, #0]
    a.vwrite     a7, s36, v2
    s.mov        s17, s31
    br.nz        s39, for_25
endfor_26:
    s.mul        s2, s8, s4
    s.movz       s4, #0
    s.muli       s5, s1, #2
    s.add        s6, s4, s1                      // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s7, s2, s23
    v.splat      v1, s6
    a.vread      v2, a0, s4
    s.muli       s6, s23, #2
    s.add        s8, s4, s2                      // the tile origin
    s.muli       s9, s7, #2
    s.add        s7, s4, s3                      // the tile origin
    v.splat      v3, s8
    v.splat      v4, s10
    v.add        v5, v0, v1
    v.splat      v1, s7
    vf.cvt.f32.bf16 v6, v2
    s.add        s4, s9, s5
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v1
    s.muli       s7, s6, #1
    s.add        s10, s19, s4
    p.and        p3, p1, p2
    s.movz       s4, #1
    @p3 v.st.h       [s10, #0], v6
    a.vread      v1, a0, s4
    s.addi       s4, s8, #1
    s.add        s10, s7, s9
    v.splat      v2, s4
    vf.cvt.f32.bf16 v3, v1
    s.add        s4, s10, s5
    v.cmp.lt     p1, v2, v4
    s.muli       s7, s6, #2
    s.add        s10, s19, s4
    p.and        p3, p1, p2
    s.movz       s4, #2
    s.addi       s11, s1, #16
    s.addi       s12, s1, #32
    @p3 v.st.h       [s10, #0], v3
    a.vread      v1, a0, s4
    s.addi       s4, s1, #48
    s.addi       s10, s1, #64
    vf.cvt.f32.bf16 v2, v1
    s.addi       s13, s1, #80
    s.addi       s14, s1, #96
    s.addi       s15, s1, #112
    v.iota       v1                              // arange(0, VLEN)
    s.add        s1, s7, s9
    v.splat      v3, s2
    s.add        s2, s1, s5
    v.add        v5, v3, v1
    s.addi       s1, s8, #2
    s.muli       s7, s6, #3
    v.splat      v1, s1
    s.add        s1, s19, s2
    s.movz       s2, #3
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.addi       s16, s8, #3
    @p3 v.st.h       [s1, #0], v2
    a.vread      v1, a0, s2
    s.add        s1, s7, s9
    v.splat      v2, s16
    vf.cvt.f32.bf16 v3, v1
    s.add        s2, s1, s5
    v.cmp.lt     p1, v2, v4
    s.muli       s1, s6, #4
    s.add        s7, s19, s2
    p.and        p3, p1, p2
    s.movz       s2, #4
    s.addi       s16, s8, #4
    s.add        s17, s1, s9
    v.splat      v1, s16
    @p3 v.st.h       [s7, #0], v3
    a.vread      v2, a0, s2
    s.add        s1, s17, s5
    v.cmp.lt     p1, v1, v4
    vf.cvt.f32.bf16 v1, v2
    s.muli       s2, s6, #5
    s.add        s7, s19, s1
    p.and        p3, p1, p2
    s.movz       s1, #5
    s.addi       s16, s8, #5
    s.add        s17, s2, s9
    v.splat      v2, s16
    s.add        s2, s17, s5
    s.muli       s16, s6, #6
    @p3 v.st.h       [s7, #0], v1
    a.vread      v1, a0, s1
    v.cmp.lt     p1, v2, v4
    s.add        s1, s19, s2
    vf.cvt.f32.bf16 v2, v1
    p.and        p3, p1, p2
    s.movz       s2, #6
    s.addi       s7, s8, #6
    s.add        s17, s16, s9
    v.splat      v1, s7
    s.add        s7, s17, s5
    s.muli       s16, s6, #7
    v.cmp.lt     p1, v1, v4
    s.add        s17, s19, s7
    @p3 v.st.h       [s1, #0], v2
    a.vread      v1, a0, s2
    p.and        p3, p1, p2
    s.movz       s1, #7
    vf.cvt.f32.bf16 v2, v1
    s.addi       s2, s8, #7
    s.add        s7, s16, s9
    v.splat      v1, s2
    s.add        s2, s7, s5
    s.muli       s7, s6, #8
    v.cmp.lt     p1, v1, v4
    s.add        s16, s19, s2
    p.and        p4, p1, p2
    s.movz       s2, #8
    @p3 v.st.h       [s17, #0], v2
    a.vread      v1, a0, s1
    s.addi       s1, s8, #8
    s.add        s17, s7, s9
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s1
    s.add        s1, s17, s5
    s.muli       s7, s6, #9
    v.cmp.lt     p1, v1, v4
    s.add        s17, s19, s1
    p.and        p3, p1, p2
    s.movz       s1, #9
    s.addi       s18, s8, #9
    s.add        s21, s7, s9
    @p4 v.st.h       [s16, #0], v2
    a.vread      v1, a0, s2
    v.splat      v2, s18
    s.add        s2, s21, s5
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.muli       s7, s6, #10
    s.add        s16, s19, s2
    p.and        p4, p1, p2
    s.movz       s2, #10
    s.addi       s18, s8, #10
    s.add        s21, s7, s9
    v.splat      v1, s18
    s.add        s7, s21, s5
    @p3 v.st.h       [s17, #0], v3
    a.vread      v2, a0, s1
    v.cmp.lt     p1, v1, v4
    s.muli       s1, s6, #11
    vf.cvt.f32.bf16 v1, v2
    s.add        s17, s19, s7
    p.and        p3, p1, p2
    s.movz       s7, #11
    s.addi       s18, s8, #11
    s.add        s21, s1, s9
    v.splat      v2, s18
    s.add        s1, s21, s5
    s.muli       s18, s6, #12
    s.add        s21, s19, s1
    @p4 v.st.h       [s16, #0], v1
    a.vread      v1, a0, s2
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.movz       s1, #12
    s.addi       s2, s8, #12
    s.add        s16, s18, s9
    v.splat      v1, s2
    s.add        s2, s16, s5
    s.muli       s16, s6, #13
    s.add        s18, s19, s2
    s.movz       s2, #13
    s.addi       s22, s8, #13
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a0, s7
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.add        s7, s16, s9
    v.splat      v2, s22
    s.add        s16, s7, s5
    s.muli       s7, s6, #14
    s.add        s17, s19, s16
    s.movz       s16, #14
    s.addi       s22, s8, #14
    s.add        s23, s7, s9
    @p4 v.st.h       [s21, #0], v1
    a.vread      v1, a0, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s22
    s.add        s1, s23, s5
    s.muli       s7, s6, #15
    s.add        s21, s19, s1
    s.movz       s1, #15
    s.addi       s22, s8, #15
    v.splat      v3, s8
    s.add        s23, s7, s9
    v.splat      v5, s22
    @p3 v.st.h       [s18, #0], v2
    a.vread      v2, a0, s2
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.movz       s2, #0
    s.add        s7, s23, s5
    s.add        s5, s2, s11                     // the tile origin
    s.add        s18, s19, s7
    s.muli       s7, s11, #2
    v.splat      v2, s5
    s.add        s5, s2, s3                      // the tile origin
    s.muli       s11, s6, #1
    v.add        v6, v0, v2
    @p4 v.st.h       [s17, #0], v1
    a.vread      v1, a0, s16
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s5
    s.add        s5, s9, s7
    v.cmp.lt     p1, v3, v4
    s.add        s16, s19, s5
    s.movz       s5, #1
    s.addi       s17, s8, #1
    s.add        s22, s11, s9
    v.splat      v3, s17
    s.add        s11, s22, s7
    @p3 v.st.h       [s21, #0], v2
    a.vread      v2, a0, s1
    v.cmp.lt     p2, v6, v1
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.muli       s1, s6, #2
    s.add        s17, s19, s11
    s.movz       s11, #2
    s.addi       s21, s8, #2
    s.muli       s22, s6, #3
    s.add        s23, s1, s9
    v.splat      v2, s21
    s.add        s1, s23, s7
    s.movz       s21, #3
    @p4 v.st.h       [s18, #0], v1
    a.vread      v1, a1, s2
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.add        s2, s19, s1
    s.addi       s1, s8, #3
    s.add        s18, s22, s9
    v.splat      v1, s1
    s.add        s1, s18, s7
    s.muli       s18, s6, #4
    s.add        s22, s19, s1
    s.movz       s1, #4
    @p3 v.st.h       [s16, #0], v3
    a.vread      v3, a1, s5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.addi       s5, s8, #4
    s.add        s16, s18, s9
    v.splat      v3, s5
    s.add        s5, s16, s7
    s.muli       s16, s6, #5
    s.add        s18, s19, s5
    s.movz       s5, #5
    @p4 v.st.h       [s17, #0], v2
    a.vread      v2, a1, s11
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.addi       s11, s8, #5
    s.add        s17, s16, s9
    v.splat      v2, s11
    s.add        s11, s17, s7
    s.muli       s16, s6, #6
    s.add        s17, s19, s11
    s.movz       s11, #6
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a1, s21
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.addi       s2, s8, #6
    s.add        s21, s16, s9
    v.splat      v1, s2
    s.add        s2, s21, s7
    s.muli       s16, s6, #7
    s.add        s21, s19, s2
    s.movz       s2, #7
    @p4 v.st.h       [s22, #0], v3
    a.vread      v3, a1, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.addi       s1, s8, #7
    s.add        s22, s16, s9
    v.splat      v3, s1
    s.add        s1, s22, s7
    s.muli       s16, s6, #8
    s.add        s22, s19, s1
    s.movz       s1, #8
    @p3 v.st.h       [s18, #0], v2
    a.vread      v2, a1, s5
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.addi       s5, s8, #8
    s.add        s18, s16, s9
    v.splat      v2, s5
    s.add        s5, s18, s7
    s.muli       s16, s6, #9
    s.add        s18, s19, s5
    s.movz       s5, #9
    @p4 v.st.h       [s17, #0], v1
    a.vread      v1, a1, s11
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.addi       s11, s8, #9
    s.add        s17, s16, s9
    v.splat      v1, s11
    s.add        s11, s17, s7
    s.muli       s16, s6, #10
    s.add        s17, s19, s11
    s.movz       s11, #10
    @p3 v.st.h       [s21, #0], v3
    a.vread      v3, a1, s2
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.addi       s2, s8, #10
    s.add        s21, s16, s9
    v.splat      v3, s2
    s.add        s2, s21, s7
    s.muli       s16, s6, #11
    s.add        s21, s19, s2
    s.movz       s2, #11
    @p4 v.st.h       [s22, #0], v2
    a.vread      v2, a1, s1
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.addi       s1, s8, #11
    s.add        s22, s16, s9
    v.splat      v2, s1
    s.add        s1, s22, s7
    s.muli       s16, s6, #12
    s.add        s22, s19, s1
    s.movz       s1, #12
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a1, s5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.addi       s5, s8, #12
    s.add        s18, s16, s9
    v.splat      v1, s5
    s.add        s5, s18, s7
    s.muli       s16, s6, #13
    s.add        s18, s19, s5
    s.movz       s5, #13
    @p4 v.st.h       [s17, #0], v3
    a.vread      v3, a1, s11
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.addi       s11, s8, #13
    s.add        s17, s16, s9
    v.splat      v3, s11
    s.add        s11, s17, s7
    s.muli       s16, s6, #14
    s.add        s17, s19, s11
    s.movz       s11, #14
    @p3 v.st.h       [s21, #0], v2
    a.vread      v2, a1, s2
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.addi       s2, s8, #14
    s.add        s21, s16, s9
    v.splat      v2, s2
    s.add        s2, s21, s7
    s.muli       s16, s6, #15
    s.add        s21, s19, s2
    s.movz       s2, #15
    @p4 v.st.h       [s22, #0], v1
    a.vread      v1, a1, s1
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s8, #15
    s.add        s22, s16, s9
    v.splat      v1, s1
    s.movz       s1, #0
    s.add        s16, s22, s7
    s.add        s7, s1, s12                     // the tile origin
    s.add        s22, s19, s16
    s.muli       s16, s12, #2
    v.splat      v5, s7
    @p3 v.st.h       [s18, #0], v3
    a.vread      v3, a1, s5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.add        s5, s1, s3                      // the tile origin
    v.splat      v3, s8
    v.add        v6, v0, v5
    v.splat      v5, s5
    s.add        s5, s9, s16
    s.muli       s7, s6, #1
    s.add        s12, s19, s5
    s.movz       s5, #1
    @p4 v.st.h       [s17, #0], v2
    a.vread      v2, a1, s11
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    v.cmp.lt     p1, v3, v4
    s.addi       s11, s8, #1
    s.add        s17, s7, s9
    v.splat      v2, s11
    s.add        s7, s17, s16
    s.muli       s11, s6, #2
    s.add        s17, s19, s7
    s.movz       s7, #2
    @p3 v.st.h       [s21, #0], v1
    a.vread      v1, a1, s2
    v.cmp.lt     p2, v6, v5
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.addi       s2, s8, #2
    s.add        s18, s11, s9
    v.splat      v1, s2
    s.add        s2, s18, s16
    s.muli       s11, s6, #3
    s.add        s18, s19, s2
    s.movz       s2, #3
    @p4 v.st.h       [s22, #0], v3
    a.vread      v3, a2, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.addi       s1, s8, #3
    s.add        s21, s11, s9
    v.splat      v3, s1
    s.add        s1, s21, s16
    s.muli       s11, s6, #4
    s.add        s21, s19, s1
    s.movz       s1, #4
    s.addi       s22, s8, #4
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a2, s5
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.add        s5, s11, s9
    v.splat      v2, s22
    s.add        s11, s5, s16
    s.muli       s5, s6, #5
    s.add        s12, s19, s11
    s.movz       s11, #5
    s.addi       s22, s8, #5
    s.add        s23, s5, s9
    @p4 v.st.h       [s17, #0], v1
    a.vread      v1, a2, s7
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s22
    s.add        s5, s23, s16
    s.muli       s7, s6, #6
    s.add        s17, s19, s5
    s.movz       s5, #6
    s.addi       s22, s8, #6
    s.add        s23, s7, s9
    v.splat      v5, s22
    @p3 v.st.h       [s18, #0], v3
    a.vread      v3, a2, s2
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.add        s2, s23, s16
    s.muli       s7, s6, #7
    s.add        s18, s19, s2
    s.movz       s2, #7
    s.addi       s22, s8, #7
    s.add        s23, s7, s9
    v.splat      v3, s22
    s.add        s7, s23, s16
    @p4 v.st.h       [s21, #0], v2
    a.vread      v2, a2, s1
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.muli       s1, s6, #8
    s.add        s21, s19, s7
    s.movz       s7, #8
    s.addi       s22, s8, #8
    s.add        s23, s1, s9
    v.splat      v2, s22
    s.add        s1, s23, s16
    @p3 v.st.h       [s12, #0], v1
    a.vread      v1, a2, s11
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s11, s6, #9
    s.add        s12, s19, s1
    s.movz       s1, #9
    s.addi       s22, s8, #9
    s.add        s23, s11, s9
    v.splat      v1, s22
    s.add        s11, s23, s16
    @p4 v.st.h       [s17, #0], v5
    a.vread      v5, a2, s5
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v5
    s.muli       s5, s6, #10
    s.add        s17, s19, s11
    s.movz       s11, #10
    s.addi       s22, s8, #10
    s.add        s23, s5, s9
    v.splat      v5, s22
    s.add        s5, s23, s16
    @p3 v.st.h       [s18, #0], v3
    a.vread      v3, a2, s2
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.muli       s2, s6, #11
    s.add        s18, s19, s5
    s.movz       s5, #11
    s.addi       s22, s8, #11
    s.add        s23, s2, s9
    v.splat      v3, s22
    s.add        s2, s23, s16
    @p4 v.st.h       [s21, #0], v2
    a.vread      v2, a2, s7
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.muli       s7, s6, #12
    s.add        s21, s19, s2
    s.movz       s2, #12
    s.addi       s22, s8, #12
    s.add        s23, s7, s9
    v.splat      v2, s22
    s.add        s7, s23, s16
    @p3 v.st.h       [s12, #0], v1
    a.vread      v1, a2, s1
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s1, s6, #13
    s.add        s12, s19, s7
    s.movz       s7, #13
    s.addi       s22, s8, #13
    s.add        s23, s1, s9
    v.splat      v1, s22
    s.add        s1, s23, s16
    @p4 v.st.h       [s17, #0], v5
    a.vread      v5, a2, s11
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v5
    s.muli       s11, s6, #14
    s.add        s17, s19, s1
    s.movz       s1, #14
    s.addi       s22, s8, #14
    s.add        s23, s11, s9
    v.splat      v5, s22
    s.add        s11, s23, s16
    @p3 v.st.h       [s18, #0], v3
    a.vread      v3, a2, s5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.muli       s5, s6, #15
    s.add        s18, s19, s11
    s.movz       s11, #15
    s.addi       s22, s8, #15
    s.add        s23, s5, s9
    v.splat      v3, s22
    s.add        s5, s23, s16
    @p4 v.st.h       [s21, #0], v2
    a.vread      v2, a2, s2
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.movz       s2, #0
    s.add        s16, s19, s5
    s.add        s5, s2, s4                      // the tile origin
    s.muli       s21, s4, #2
    v.splat      v2, s5
    v.splat      v6, s8
    v.add        v7, v0, v2
    s.add        s4, s9, s21
    @p3 v.st.h       [s12, #0], v1
    a.vread      v1, a2, s7
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.add        s5, s2, s3                      // the tile origin
    s.muli       s7, s6, #1
    v.splat      v1, s5
    s.add        s5, s19, s4
    s.movz       s4, #1
    s.add        s12, s7, s9
    s.add        s7, s12, s21
    @p4 v.st.h       [s17, #0], v2
    a.vread      v2, a2, s1
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    v.cmp.lt     p1, v6, v4
    s.addi       s1, s8, #1
    s.muli       s12, s6, #2
    v.splat      v2, s1
    s.add        s1, s19, s7
    s.movz       s7, #2
    s.add        s17, s12, s9
    @p3 v.st.h       [s18, #0], v3
    a.vread      v3, a2, s11
    v.cmp.lt     p2, v7, v1
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s11, s8, #2
    s.add        s12, s17, s21
    v.splat      v3, s11
    s.muli       s11, s6, #3
    s.add        s17, s19, s12
    s.movz       s12, #3
    s.add        s18, s11, s9
    @p4 v.st.h       [s16, #0], v1
    a.vread      v1, a3, s2
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s2, s8, #3
    s.add        s11, s18, s21
    v.splat      v1, s2
    s.muli       s2, s6, #4
    s.add        s16, s19, s11
    s.movz       s11, #4
    s.addi       s18, s8, #4
    s.add        s22, s2, s9
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a3, s4
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    v.splat      v2, s18
    s.add        s2, s22, s21
    s.muli       s4, s6, #5
    s.add        s5, s19, s2
    s.movz       s2, #5
    s.addi       s18, s8, #5
    s.add        s22, s4, s9
    v.splat      v5, s18
    @p4 v.st.h       [s1, #0], v3
    a.vread      v3, a3, s7
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.add        s1, s22, s21
    s.muli       s4, s6, #6
    s.add        s7, s19, s1
    s.movz       s1, #6
    s.addi       s18, s8, #6
    s.add        s22, s4, s9
    v.splat      v3, s18
    s.add        s4, s22, s21
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a3, s12
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s12, s6, #7
    s.add        s17, s19, s4
    s.movz       s4, #7
    s.addi       s18, s8, #7
    s.add        s22, s12, s9
    v.splat      v1, s18
    s.add        s12, s22, s21
    @p4 v.st.h       [s16, #0], v2
    a.vread      v2, a3, s11
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s11, s6, #8
    s.add        s16, s19, s12
    s.movz       s12, #8
    s.addi       s18, s8, #8
    s.add        s22, s11, s9
    v.splat      v2, s18
    s.add        s11, s22, s21
    @p3 v.st.h       [s5, #0], v5
    a.vread      v5, a3, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v5
    s.muli       s2, s6, #9
    s.add        s5, s19, s11
    s.movz       s11, #9
    s.addi       s18, s8, #9
    s.add        s22, s2, s9
    v.splat      v5, s18
    s.add        s2, s22, s21
    @p4 v.st.h       [s7, #0], v3
    a.vread      v3, a3, s1
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s1, s6, #10
    s.add        s7, s19, s2
    s.movz       s2, #10
    s.addi       s18, s8, #10
    s.add        s22, s1, s9
    v.splat      v3, s18
    s.add        s1, s22, s21
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a3, s4
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s4, s6, #11
    s.add        s17, s19, s1
    s.movz       s1, #11
    s.addi       s18, s8, #11
    s.add        s22, s4, s9
    v.splat      v1, s18
    s.add        s4, s22, s21
    @p4 v.st.h       [s16, #0], v2
    a.vread      v2, a3, s12
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s12, s6, #12
    s.add        s16, s19, s4
    s.movz       s4, #12
    s.addi       s18, s8, #12
    s.add        s22, s12, s9
    v.splat      v2, s18
    s.add        s12, s22, s21
    @p3 v.st.h       [s5, #0], v5
    a.vread      v5, a3, s11
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v5
    s.muli       s5, s6, #13
    s.add        s11, s19, s12
    s.movz       s12, #13
    s.addi       s18, s8, #13
    s.add        s22, s5, s9
    v.splat      v5, s18
    s.add        s5, s22, s21
    @p4 v.st.h       [s7, #0], v3
    a.vread      v3, a3, s2
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s2, s6, #14
    s.add        s7, s19, s5
    s.movz       s5, #14
    s.addi       s18, s8, #14
    s.add        s22, s2, s9
    v.splat      v3, s18
    s.add        s2, s22, s21
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a3, s1
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s1, s6, #15
    s.add        s17, s19, s2
    s.movz       s2, #15
    s.addi       s18, s8, #15
    s.add        s22, s1, s9
    v.splat      v1, s18
    s.add        s1, s22, s21
    @p4 v.st.h       [s16, #0], v2
    a.vread      v2, a3, s4
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.movz       s4, #0
    s.add        s16, s19, s1
    s.add        s1, s4, s10                     // the tile origin
    s.muli       s18, s10, #2
    v.splat      v2, s1
    v.splat      v6, s8
    v.add        v7, v0, v2
    s.add        s1, s9, s18
    @p3 v.st.h       [s11, #0], v5
    a.vread      v2, a3, s12
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.add        s10, s4, s3                     // the tile origin
    s.muli       s11, s6, #1
    v.splat      v2, s10
    s.add        s10, s19, s1
    s.movz       s1, #1
    s.add        s12, s11, s9
    s.add        s11, s12, s18
    @p4 v.st.h       [s7, #0], v3
    a.vread      v3, a3, s5
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    v.cmp.lt     p1, v6, v4
    s.addi       s5, s8, #1
    s.muli       s7, s6, #2
    v.splat      v3, s5
    s.add        s5, s19, s11
    s.movz       s11, #2
    s.add        s12, s7, s9
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a3, s2
    v.cmp.lt     p2, v7, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s2, s8, #2
    s.add        s7, s12, s18
    v.splat      v1, s2
    s.muli       s2, s6, #3
    s.add        s12, s19, s7
    s.movz       s7, #3
    s.add        s17, s2, s9
    @p4 v.st.h       [s16, #0], v2
    a.vread      v2, a4, s4
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s2, s8, #3
    s.add        s4, s17, s18
    v.splat      v2, s2
    s.muli       s2, s6, #4
    s.add        s16, s19, s4
    s.movz       s4, #4
    s.addi       s17, s8, #4
    s.add        s21, s2, s9
    @p3 v.st.h       [s10, #0], v3
    a.vread      v3, a4, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    v.splat      v3, s17
    s.add        s1, s21, s18
    s.muli       s2, s6, #5
    s.add        s10, s19, s1
    s.movz       s1, #5
    s.addi       s17, s8, #5
    s.add        s21, s2, s9
    v.splat      v5, s17
    @p4 v.st.h       [s5, #0], v1
    a.vread      v1, a4, s11
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.add        s2, s21, s18
    s.muli       s5, s6, #6
    s.add        s11, s19, s2
    s.movz       s2, #6
    s.addi       s17, s8, #6
    s.add        s21, s5, s9
    v.splat      v1, s17
    s.add        s5, s21, s18
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a4, s7
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s7, s6, #7
    s.add        s12, s19, s5
    s.movz       s5, #7
    s.addi       s17, s8, #7
    s.add        s21, s7, s9
    v.splat      v2, s17
    s.add        s7, s21, s18
    @p4 v.st.h       [s16, #0], v3
    a.vread      v3, a4, s4
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v3
    s.muli       s4, s6, #8
    s.add        s16, s19, s7
    s.movz       s7, #8
    s.addi       s17, s8, #8
    s.add        s21, s4, s9
    v.splat      v3, s17
    s.add        s4, s21, s18
    @p3 v.st.h       [s10, #0], v5
    a.vread      v5, a4, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.muli       s1, s6, #9
    s.add        s10, s19, s4
    s.movz       s4, #9
    s.addi       s17, s8, #9
    s.add        s21, s1, s9
    v.splat      v5, s17
    s.add        s1, s21, s18
    @p4 v.st.h       [s11, #0], v1
    a.vread      v1, a4, s2
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s2, s6, #10
    s.add        s11, s19, s1
    s.movz       s1, #10
    s.addi       s17, s8, #10
    s.add        s21, s2, s9
    v.splat      v1, s17
    s.add        s2, s21, s18
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a4, s5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s5, s6, #11
    s.add        s12, s19, s2
    s.movz       s2, #11
    s.addi       s17, s8, #11
    s.add        s21, s5, s9
    v.splat      v2, s17
    s.add        s5, s21, s18
    @p4 v.st.h       [s16, #0], v3
    a.vread      v3, a4, s7
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v3
    s.muli       s7, s6, #12
    s.add        s16, s19, s5
    s.movz       s5, #12
    s.addi       s17, s8, #12
    s.add        s21, s7, s9
    v.splat      v3, s17
    s.add        s7, s21, s18
    @p3 v.st.h       [s10, #0], v5
    a.vread      v5, a4, s4
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.muli       s4, s6, #13
    s.add        s10, s19, s7
    s.movz       s7, #13
    s.addi       s17, s8, #13
    s.add        s21, s4, s9
    v.splat      v5, s17
    s.add        s4, s21, s18
    @p4 v.st.h       [s11, #0], v1
    a.vread      v1, a4, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s1, s6, #14
    s.add        s11, s19, s4
    s.movz       s4, #14
    s.addi       s17, s8, #14
    s.add        s21, s1, s9
    v.splat      v1, s17
    s.add        s1, s21, s18
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a4, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s2, s6, #15
    s.add        s12, s19, s1
    s.movz       s1, #15
    s.addi       s17, s8, #15
    s.add        s21, s2, s9
    v.splat      v2, s17
    s.add        s2, s21, s18
    @p4 v.st.h       [s16, #0], v3
    a.vread      v3, a4, s5
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v3
    s.movz       s5, #0
    s.add        s16, s19, s2
    s.add        s2, s5, s13                     // the tile origin
    s.muli       s17, s13, #2
    v.splat      v3, s2
    v.splat      v6, s8
    v.add        v7, v0, v3
    s.add        s2, s9, s17
    @p3 v.st.h       [s10, #0], v5
    a.vread      v3, a4, s7
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.add        s7, s5, s3                      // the tile origin
    s.muli       s10, s6, #1
    v.splat      v3, s7
    s.add        s7, s19, s2
    s.movz       s2, #1
    s.add        s13, s10, s9
    s.add        s10, s13, s17
    @p4 v.st.h       [s11, #0], v1
    a.vread      v1, a4, s4
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    v.cmp.lt     p1, v6, v4
    s.addi       s4, s8, #1
    s.muli       s11, s6, #2
    v.splat      v1, s4
    s.add        s4, s19, s10
    s.movz       s10, #2
    s.add        s13, s11, s9
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a4, s1
    v.cmp.lt     p2, v7, v3
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s1, s8, #2
    s.add        s11, s13, s17
    v.splat      v2, s1
    s.muli       s1, s6, #3
    s.add        s12, s19, s11
    s.movz       s11, #3
    s.add        s13, s1, s9
    @p4 v.st.h       [s16, #0], v3
    a.vread      v3, a5, s5
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s1, s8, #3
    s.add        s5, s13, s17
    v.splat      v3, s1
    s.muli       s1, s6, #4
    s.add        s13, s19, s5
    s.movz       s5, #4
    s.addi       s16, s8, #4
    s.add        s18, s1, s9
    @p3 v.st.h       [s7, #0], v1
    a.vread      v1, a5, s2
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s16
    s.add        s1, s18, s17
    s.muli       s2, s6, #5
    s.add        s7, s19, s1
    s.movz       s1, #5
    s.addi       s16, s8, #5
    s.add        s18, s2, s9
    v.splat      v5, s16
    @p4 v.st.h       [s4, #0], v2
    a.vread      v2, a5, s10
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.add        s2, s18, s17
    s.muli       s4, s6, #6
    s.add        s10, s19, s2
    s.movz       s2, #6
    s.addi       s16, s8, #6
    s.add        s18, s4, s9
    v.splat      v2, s16
    s.add        s4, s18, s17
    @p3 v.st.h       [s12, #0], v3
    a.vread      v3, a5, s11
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s11, s6, #7
    s.add        s12, s19, s4
    s.movz       s4, #7
    s.addi       s16, s8, #7
    s.add        s18, s11, s9
    v.splat      v3, s16
    s.add        s11, s18, s17
    @p4 v.st.h       [s13, #0], v1
    a.vread      v1, a5, s5
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s5, s6, #8
    s.add        s13, s19, s11
    s.movz       s11, #8
    s.addi       s16, s8, #8
    s.add        s18, s5, s9
    v.splat      v1, s16
    s.add        s5, s18, s17
    @p3 v.st.h       [s7, #0], v5
    a.vread      v5, a5, s1
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v5
    s.muli       s1, s6, #9
    s.add        s7, s19, s5
    s.movz       s5, #9
    s.addi       s16, s8, #9
    s.add        s18, s1, s9
    v.splat      v5, s16
    s.add        s1, s18, s17
    @p4 v.st.h       [s10, #0], v2
    a.vread      v2, a5, s2
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s2, s6, #10
    s.add        s10, s19, s1
    s.movz       s1, #10
    s.addi       s16, s8, #10
    s.add        s18, s2, s9
    v.splat      v2, s16
    s.add        s2, s18, s17
    @p3 v.st.h       [s12, #0], v3
    a.vread      v3, a5, s4
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s4, s6, #11
    s.add        s12, s19, s2
    s.movz       s2, #11
    s.addi       s16, s8, #11
    s.add        s18, s4, s9
    v.splat      v3, s16
    s.add        s4, s18, s17
    @p4 v.st.h       [s13, #0], v1
    a.vread      v1, a5, s11
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s11, s6, #12
    s.add        s13, s19, s4
    s.movz       s4, #12
    s.addi       s16, s8, #12
    s.add        s18, s11, s9
    v.splat      v1, s16
    s.add        s11, s18, s17
    @p3 v.st.h       [s7, #0], v5
    a.vread      v5, a5, s5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v5
    s.muli       s5, s6, #13
    s.add        s7, s19, s11
    s.movz       s11, #13
    s.addi       s16, s8, #13
    s.add        s18, s5, s9
    v.splat      v5, s16
    s.add        s5, s18, s17
    @p4 v.st.h       [s10, #0], v2
    a.vread      v2, a5, s1
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s1, s6, #14
    s.add        s10, s19, s5
    s.movz       s5, #14
    s.addi       s16, s8, #14
    s.add        s18, s1, s9
    v.splat      v2, s16
    s.add        s1, s18, s17
    @p3 v.st.h       [s12, #0], v3
    a.vread      v3, a5, s2
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s2, s6, #15
    s.add        s12, s19, s1
    s.movz       s1, #15
    s.addi       s16, s8, #15
    s.add        s18, s2, s9
    v.splat      v3, s16
    s.add        s2, s18, s17
    @p4 v.st.h       [s13, #0], v1
    a.vread      v1, a5, s4
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.movz       s4, #0
    s.add        s13, s19, s2
    s.add        s2, s4, s14                     // the tile origin
    s.muli       s16, s14, #2
    v.splat      v1, s2
    v.splat      v6, s8
    v.add        v7, v0, v1
    s.add        s2, s9, s16
    @p3 v.st.h       [s7, #0], v5
    a.vread      v1, a5, s11
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.add        s7, s4, s3                      // the tile origin
    s.muli       s11, s6, #1
    v.splat      v1, s7
    s.add        s7, s19, s2
    s.movz       s2, #1
    s.add        s14, s11, s9
    s.add        s11, s14, s16
    @p4 v.st.h       [s10, #0], v2
    a.vread      v2, a5, s5
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    v.cmp.lt     p1, v6, v4
    s.addi       s5, s8, #1
    s.muli       s10, s6, #2
    v.splat      v2, s5
    s.add        s5, s19, s11
    s.movz       s11, #2
    s.add        s14, s10, s9
    @p3 v.st.h       [s12, #0], v3
    a.vread      v3, a5, s1
    v.cmp.lt     p2, v7, v1
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s1, s8, #2
    s.add        s10, s14, s16
    v.splat      v3, s1
    s.muli       s1, s6, #3
    s.add        s12, s19, s10
    s.movz       s10, #3
    s.add        s14, s1, s9
    @p4 v.st.h       [s13, #0], v1
    a.vread      v1, a6, s4
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s1, s8, #3
    s.add        s4, s14, s16
    v.splat      v1, s1
    s.muli       s1, s6, #4
    s.add        s13, s19, s4
    s.movz       s4, #4
    s.addi       s14, s8, #4
    s.add        s17, s1, s9
    @p3 v.st.h       [s7, #0], v2
    a.vread      v2, a6, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    v.splat      v2, s14
    s.add        s1, s17, s16
    s.muli       s2, s6, #5
    s.add        s7, s19, s1
    s.movz       s1, #5
    s.addi       s14, s8, #5
    s.add        s17, s2, s9
    v.splat      v5, s14
    @p4 v.st.h       [s5, #0], v3
    a.vread      v3, a6, s11
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.add        s2, s17, s16
    s.muli       s5, s6, #6
    s.add        s11, s19, s2
    s.movz       s2, #6
    s.addi       s14, s8, #6
    s.add        s17, s5, s9
    v.splat      v3, s14
    s.add        s5, s17, s16
    @p3 v.st.h       [s12, #0], v1
    a.vread      v1, a6, s10
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s10, s6, #7
    s.add        s12, s19, s5
    s.movz       s5, #7
    s.addi       s14, s8, #7
    s.add        s17, s10, s9
    v.splat      v1, s14
    s.add        s10, s17, s16
    @p4 v.st.h       [s13, #0], v2
    a.vread      v2, a6, s4
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s4, s6, #8
    s.add        s13, s19, s10
    s.movz       s10, #8
    s.addi       s14, s8, #8
    s.add        s17, s4, s9
    v.splat      v2, s14
    s.add        s4, s17, s16
    @p3 v.st.h       [s7, #0], v5
    a.vread      v5, a6, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v5
    s.muli       s1, s6, #9
    s.add        s7, s19, s4
    s.movz       s4, #9
    s.addi       s14, s8, #9
    s.add        s17, s1, s9
    v.splat      v5, s14
    s.add        s1, s17, s16
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a6, s2
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s2, s6, #10
    s.add        s11, s19, s1
    s.movz       s1, #10
    s.addi       s14, s8, #10
    s.add        s17, s2, s9
    v.splat      v3, s14
    s.add        s2, s17, s16
    @p3 v.st.h       [s12, #0], v1
    a.vread      v1, a6, s5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s5, s6, #11
    s.add        s12, s19, s2
    s.movz       s2, #11
    s.addi       s14, s8, #11
    s.add        s17, s5, s9
    v.splat      v1, s14
    s.add        s5, s17, s16
    @p4 v.st.h       [s13, #0], v2
    a.vread      v2, a6, s10
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s10, s6, #12
    s.add        s13, s19, s5
    s.movz       s5, #12
    s.addi       s14, s8, #12
    s.add        s17, s10, s9
    v.splat      v2, s14
    s.add        s10, s17, s16
    @p3 v.st.h       [s7, #0], v5
    a.vread      v5, a6, s4
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v5
    s.muli       s4, s6, #13
    s.add        s7, s19, s10
    s.movz       s10, #13
    s.addi       s14, s8, #13
    s.add        s17, s4, s9
    v.splat      v5, s14
    s.add        s4, s17, s16
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a6, s1
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s1, s6, #14
    s.add        s11, s19, s4
    s.movz       s4, #14
    s.addi       s14, s8, #14
    s.add        s17, s1, s9
    v.splat      v3, s14
    s.add        s1, s17, s16
    @p3 v.st.h       [s12, #0], v1
    a.vread      v1, a6, s2
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s2, s6, #15
    s.add        s12, s19, s1
    s.movz       s1, #15
    s.addi       s14, s8, #15
    s.add        s17, s2, s9
    v.splat      v1, s14
    s.add        s2, s17, s16
    @p4 v.st.h       [s13, #0], v2
    a.vread      v2, a6, s5
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.movz       s5, #0
    s.add        s13, s19, s2
    s.add        s2, s5, s15                     // the tile origin
    s.muli       s14, s15, #2
    v.splat      v2, s2
    v.splat      v6, s8
    v.add        v7, v0, v2
    s.add        s2, s9, s14
    @p3 v.st.h       [s7, #0], v5
    a.vread      v0, a6, s10
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.add        s7, s5, s3                      // the tile origin
    s.muli       s3, s6, #1
    v.splat      v0, s7
    s.add        s7, s19, s2
    s.movz       s2, #1
    s.add        s10, s3, s9
    s.add        s3, s10, s14
    @p4 v.st.h       [s11, #0], v2
    a.vread      v2, a6, s4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    v.cmp.lt     p1, v6, v4
    s.addi       s4, s8, #1
    s.muli       s10, s6, #2
    v.splat      v2, s4
    s.add        s4, s19, s3
    s.movz       s3, #2
    s.add        s11, s10, s9
    @p3 v.st.h       [s12, #0], v1
    a.vread      v1, a6, s1
    v.cmp.lt     p2, v7, v0
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.addi       s1, s8, #2
    s.add        s10, s11, s14
    v.splat      v1, s1
    s.muli       s1, s6, #3
    s.add        s11, s19, s10
    s.movz       s10, #3
    s.add        s12, s1, s9
    @p4 v.st.h       [s13, #0], v0
    a.vread      v0, a7, s5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.addi       s1, s8, #3
    s.add        s5, s12, s14
    v.splat      v0, s1
    s.muli       s1, s6, #4
    s.add        s12, s19, s5
    s.movz       s5, #4
    s.addi       s13, s8, #4
    s.add        s15, s1, s9
    @p3 v.st.h       [s7, #0], v2
    a.vread      v2, a7, s2
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    v.splat      v2, s13
    s.add        s1, s15, s14
    s.muli       s2, s6, #5
    s.add        s7, s19, s1
    s.movz       s1, #5
    s.addi       s13, s8, #5
    s.add        s15, s2, s9
    v.splat      v3, s13
    @p4 v.st.h       [s4, #0], v1
    a.vread      v1, a7, s3
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.add        s2, s15, s14
    s.muli       s3, s6, #6
    s.add        s4, s19, s2
    s.movz       s2, #6
    s.addi       s13, s8, #6
    s.add        s15, s3, s9
    v.splat      v1, s13
    s.add        s3, s15, s14
    @p3 v.st.h       [s11, #0], v0
    a.vread      v0, a7, s10
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.muli       s10, s6, #7
    s.add        s11, s19, s3
    s.movz       s3, #7
    s.addi       s13, s8, #7
    s.add        s15, s10, s9
    v.splat      v0, s13
    s.add        s10, s15, s14
    @p4 v.st.h       [s12, #0], v2
    a.vread      v2, a7, s5
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s5, s6, #8
    s.add        s12, s19, s10
    s.movz       s10, #8
    s.addi       s13, s8, #8
    s.add        s15, s5, s9
    v.splat      v2, s13
    s.add        s5, s15, s14
    @p3 v.st.h       [s7, #0], v3
    a.vread      v3, a7, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s1, s6, #9
    s.add        s7, s19, s5
    s.movz       s5, #9
    s.addi       s13, s8, #9
    s.add        s15, s1, s9
    v.splat      v3, s13
    s.add        s1, s15, s14
    @p4 v.st.h       [s4, #0], v1
    a.vread      v1, a7, s2
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.muli       s2, s6, #10
    s.add        s4, s19, s1
    s.movz       s1, #10
    s.addi       s13, s8, #10
    s.add        s15, s2, s9
    v.splat      v1, s13
    s.add        s2, s15, s14
    @p3 v.st.h       [s11, #0], v0
    a.vread      v0, a7, s3
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.muli       s3, s6, #11
    s.add        s11, s19, s2
    s.movz       s2, #11
    s.addi       s13, s8, #11
    s.add        s15, s3, s9
    v.splat      v0, s13
    s.add        s3, s15, s14
    @p4 v.st.h       [s12, #0], v2
    a.vread      v2, a7, s10
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s10, s6, #12
    s.add        s12, s19, s3
    s.movz       s3, #12
    s.addi       s13, s8, #12
    s.add        s15, s10, s9
    v.splat      v2, s13
    s.add        s10, s15, s14
    @p3 v.st.h       [s7, #0], v3
    a.vread      v3, a7, s5
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s5, s6, #13
    s.add        s7, s19, s10
    s.movz       s10, #13
    s.addi       s13, s8, #13
    s.add        s15, s5, s9
    v.splat      v3, s13
    s.add        s5, s15, s14
    @p4 v.st.h       [s4, #0], v1
    a.vread      v1, a7, s1
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.muli       s1, s6, #14
    s.add        s4, s19, s5
    s.movz       s5, #14
    s.addi       s13, s8, #14
    s.add        s15, s1, s9
    v.splat      v1, s13
    s.add        s1, s15, s14
    @p3 v.st.h       [s11, #0], v0
    a.vread      v0, a7, s2
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.muli       s2, s6, #15
    s.add        s6, s19, s1
    s.movz       s1, #15
    s.addi       s11, s8, #15
    s.add        s8, s2, s9
    v.splat      v0, s11
    s.add        s2, s8, s14
    @p4 v.st.h       [s12, #0], v2
    a.vread      v2, a7, s3
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.add        s3, s19, s2
    @p3 v.st.h       [s7, #0], v3
    a.vread      v2, a7, s10
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    @p4 v.st.h       [s4, #0], v1
    a.vread      v1, a7, s5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v1
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a7, s1
    vf.cvt.f32.bf16 v1, v0
    @p4 v.st.h       [s3, #0], v1
    exit
    exit
