    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.rdspecial  s2, arg_base
    v.add        v2, v1, v0
    v.movi       v0, #0
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v1, #0
    v.sub        v3, v0, v2
    s.shli       s4, s1, #2                      // element offset -> bytes (x4)
    v.cmp.lt     p1, v2, v0
    v.sub        v4, v1, v2
    @p1 v.sel        v5, v3, v2
    v.movi       v3, #11
    s.add        s1, s3, s4                      // &in_ptr0[...]
    v.cmp.lt     p2, v2, v1
    @p2 v.sel        v6, v4, v2
    v.movi       v2, #2047
    v.lshr       v4, v5, v3
    v.ld.w       v3, [s1, #0]
    v.and        v5, v6, v2
    v.sub        v2, v0, v4
    v.sub        v6, v1, v5
    @p1 v.sel        v7, v2, v4
    v.movi       v2, #8192
    v.movi       v4, #2048
    @p2 v.sel        v8, v6, v5
    v.mul        v5, v7, v2
    v.sub        v2, v1, v4
    s.ld.d       s1, [s2, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.sub        v6, v0, v4
    v.add        v7, v8, v5
    v.cmp.lt     p1, v4, v1
    v.cmp.lt     p2, v4, v0
    @p1 v.sel        v0, v2, v4
    @p2 v.sel        v0, v6, v4
    v.st.scatter.w [s1, v7], v3
__rctx_next:
    exit
