source /tools/Xilinx/Vivado/2023.2/settings64.sh
cd "$HOME/tnca_build/r40_hierarchy_screen"
for preserve in 0 1; do
 timeout -k 15 2400 vivado -mode batch -source source/flow/fpga/synth_r40_range_grid.tcl -tclargs "$PWD/source" "$PWD/case$preserve" "$preserve" > case$preserve.log 2>&1
 result=$?
 echo "$result" > case$preserve.exit
 if [ "$result" -ne 0 ]; then exit "$result"; fi
done
