source /tools/Xilinx/Vivado/2023.2/settings64.sh
cd "$HOME/tnca_build/r40_attempt01_boundary_audit_v2"
timeout -k 15 2700 vivado -mode batch -source diagnose.tcl -tclargs "$HOME/tnca_build/r40_attempt01_20261016/xo/tmp/link/vivado/vpl/prj/prj.runs/impl_1/level0_wrapper_routed_error.dcp" "$PWD/reports" > stdout.log 2>&1
echo $? > exit
