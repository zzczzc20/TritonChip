#!/usr/bin/env bash
set -eu
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 CUDA_VISIBLE_DEVICES=
export PYTHONPATH="$HOME/r41_q35_multiturn_diag_20261031:$HOME/r41_q35_multiturn_diag_20261031/python:$HOME/r41_q35_multiturn_diag_20261031/compiler/python:$HOME/r41_q35_multiturn_diag_20261031/tools/asm:$HOME/r41_q35_multiturn_diag_20261031/tools/performance_harness/systemc"
export TNCA_TLM_BINARY="$HOME/r41_vl_reason_dp/build/tnca-chip" TNCA_TLM_CONFIG="$HOME/r41_vl_reason_dp/src/tools/performance_harness/systemc/configs/r41-mma-dp.cfg" TNCA_TLM_MEMORY_BYTES=0x200000000 TNCA_DRAM_PATH=fast TNCA_TLM_UNTIMED_COLD=0 TNCA_TLM_OUT="$HOME/r41_q35_compensated_mean_20261101_tlm" R41_MEAN_OUT="$HOME/r41_q35_compensated_mean_20261101_diag"
exec "$HOME/flux-venv/bin/python" -u "$HOME/r41_q35_compensated_mean_20261101.py"
