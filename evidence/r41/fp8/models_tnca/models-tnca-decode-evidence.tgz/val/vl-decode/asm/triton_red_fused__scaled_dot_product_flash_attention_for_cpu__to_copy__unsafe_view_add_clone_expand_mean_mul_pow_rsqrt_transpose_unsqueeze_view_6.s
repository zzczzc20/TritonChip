    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s8, [s1, #40]                   // in_ptr5: device_ptr64 at arg_base+40
    s.ld.d       s9, [s1, #48]                   // in_ptr6: device_ptr64 at arg_base+48
    s.ld.d       s10, [s1, #56]                  // out_ptr0: device_ptr64 at arg_base+56
    s.rdspecial  s1, arg_base
    s.ld.d       s11, [s1, #80]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s12, #512
    s.mul        s13, s1, s12
    s.add        s1, s11, s13                    // this context's own scratch
    s.addi       s11, s1, #0                     // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s12, #0
    s.st.d       [s11, #0], s3
    s.movz       s12, #16
    s.st.d       [s11, #8], s12
    s.movz       s12, #128
    s.st.d       [s11, #16], s12
    s.movz       s12, #256
    s.st.d       [s11, #48], s12
    s.movz       s12, #2
    s.st.d       [s11, #56], s12
    .li       s12, #68719476737
    s.st.d       [s11, #88], s12
    .li       s12, #1108101562368
    s.st.d       [s11, #104], s12
    fence.release.device
    td.load      d0, [s11]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s11, #1
    s.addi       s12, s1, #256                   // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s12, #0], s7
    s.movz       s1, #16
    s.st.d       [s12, #8], s1
    s.movz       s1, #128
    s.st.d       [s12, #16], s1
    s.movz       s1, #256
    s.st.d       [s12, #48], s1
    s.movz       s1, #2
    s.st.d       [s12, #56], s1
    .li       s1, #68719476737
    s.st.d       [s12, #88], s1
    .li       s1, #1108101562368
    s.st.d       [s12, #104], s1
    fence.release.device
    td.load      d1, [s12]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s12, #128
    s.movz       s13, #16
    v.splat      v0, s4
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v2, #32
    v.movi       v3, #0
    v.movi       v4, #1
    v.cmp.lt     p1, v0, v3
    v.cmp.lt     p2, v2, v3
    v.sub        v4, v3, v0
    @p1 v.sel        v5, v4, v0
    v.sub        v4, v3, v2
    @p2 v.sel        v6, v4, v2
    v.movi       v4, #5
    v.lshr       v6, v5, v4
    v.sub        v4, v3, v6
    @p1 v.sel        v3, v4, v6
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s11
    v.cmp.lt     p1, v4, v5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s5, v3]               // index is in elements (ISA sec 9.1)
    v.movi       v5, #0
    v.movi       v6, #1
    v.cmp.lt     p1, v0, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v0
    @p1 v.sel        v7, v6, v0
    v.sub        v0, v5, v2
    @p2 v.sel        v6, v0, v2
    v.movi       v0, #31
    v.and        v2, v7, v0
    v.sub        v0, v5, v2
    @p1 v.sel        v5, v0, v2
    s.addi       s5, s1, #0
    v.movi       v0, #0
    v.movi       v2, #0
    v.mov        v2, v0
for_1:
    s.cmp.ge     s1, s5, s12
    br.nz        s1, endfor_2
    s.movz       s1, #0
    s.movz       s11, #0
    s.cmp.lt     s14, s4, s1
    s.movz       s1, #32
    s.sub        s15, s11, s14
    s.movz       s11, #0
    s.movz       s14, #0
    s.cmp.lt     s16, s1, s11
    s.xor        s11, s4, s15
    s.sub        s17, s14, s16
    s.sub        s14, s11, s15
    s.xor        s11, s15, s17
    s.lshri      s15, s14, #5
    v.splat      v0, s5
    s.xor        s16, s15, s11
    v.iota       v6                              // arange(0, VLEN)
    s.sub        s18, s16, s11
    s.movz       s11, #128
    s.muli       s16, s18, #256
    s.movz       s19, #16
    s.muli       s20, s5, #2
    v.add        v7, v0, v6
    v.movi       v0, #0
    v.splat      v6, s11
    v.splat      v8, s18
    v.movi       v9, #0
    v.splat      v10, s19
    v.cmp.ge     p1, v7, v0
    v.cmp.lt     p2, v7, v6
    v.cmp.ge     p3, v8, v9
    v.cmp.lt     p4, v8, v10
    s.add        s11, s3, s16
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s16, s11, s20
    p.and        p2, p5, p1
    v.splat      v0, s5
    s.shli       s11, s5, #1                     // element offset -> bytes (x2)
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v6, [s16, #0]
    v.add        v7, v0, v1
    v.movi       v0, #128
    s.add        s16, s2, s11                    // &in_ptr0[...]
    v.cmp.lt     p1, v7, v0
    s.muli       s19, s18, #256
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s16, #0]
    vf.cvt.bf16.f32 v8, v6
    s.add        s16, s6, s11                    // &in_ptr3[...]
    s.muli       s20, s15, #32
    s.add        s15, s7, s19
    s.xor        s19, s1, s17
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v6, [s16, #0]
    vf.cvt.bf16.f32 v9, v0
    v.splat      v0, s5
    v.iota       v10                             // arange(0, VLEN)
    s.movz       s1, #128
    s.muli       s16, s5, #2
    v.add        v11, v0, v10
    v.movi       v0, #0
    v.splat      v10, s1
    v.splat      v12, s18
    v.movi       v13, #0
    v.cmp.ge     p2, v11, v0
    v.cmp.lt     p3, v11, v10
    p.and        p4, p2, p3
    s.add        s1, s15, s16
    vf.cvt.bf16.f32 v0, v6
    s.sub        s15, s19, s17
    s.movz       s15, #16
    v.cmp.ge     p2, v12, v13
    v.splat      v6, s15
    s.sub        s15, s14, s20
    .li       s14, #1124073472
    v.splat      v10, s14                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s14, #1065353216
    v.splat      v11, s14                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v13, v10                        // ISA 8.8: <= 2**-22 relative
    v.movi       v14, #0
    v.movi       v15, #1
    v.sub        v16, v14, v3
    v.cmp.lt     p3, v3, v14
    @p3 v.sel        v17, v16, v3
    v.cmp.lt     p5, v12, v6
    .li       s14, #897988541
    v.splat      v6, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.lshr       v12, v17, v15
    p.and        p6, p2, p5
    v.movi       v15, #128
    v.sub        v16, v14, v12
    p.and        p2, p4, p6
    s.add        s14, s8, s11                    // &in_ptr5[...]
    v.mul        v17, v5, v15
    @p3 v.sel        v15, v16, v12
    v.movi       v12, #4096
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v16, [s1, #0]
    v.extract    s1, v17, #0
    v.mul        v17, v15, v12
    v.splat      v12, s1
    v.extract    s1, v17, #0
    v.add        v15, v7, v12
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v7, [s14, #0]
    v.splat      v12, s1
    vf.cvt.bf16.f32 v17, v16
    .li       s1, #1077936128
    v.splat      v16, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v18, v10, v13, v11
    .li       s1, #3204448256
    v.splat      v11, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cvt.bf16.f32 v19, v7
    v.add        v7, v15, v12
    vf.fms       v12, v13, v18, v13
    v.movi       v15, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v15, [s9, v7]              // index is in elements (ISA sec 9.1)
    v.movi       v7, #2
    v.movi       v18, #1
    vf.neg       v18, v12                        // Newton step: r0*(2 - x*r0)
    vf.mul       v12, v17, v19
    v.sub        v17, v14, v7
    vf.cvt.bf16.f32 v19, v15
    vf.cmp.o     p2, v18, v18
    @p2 v.sel        v15, v18, v13
    v.cmp.lt     p2, v7, v14
    vf.mul       v13, v4, v15                    // a/y: faithful quotient
    .li       s1, #1050163184
    v.splat      v14, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p2 v.sel        v18, v17, v7
    vf.mul       v7, v19, v14
    vf.fms       v17, v13, v10, v4
    v.movi       v10, #0
    s.movz       s1, #4096
    s.add        s1, s5, s13
    vf.fms       v18, v17, v15, v13
    s.movz       s11, #1
    vf.neg       v15, v18                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v17, v15, v13
    vf.add       v13, v17, v6
    v.rsqrt.approx v6, v13                       // ISA 8.8: <= 2**-22 relative
    vf.mul       v15, v6, v6
    vf.mul       v17, v6, v11
    vf.fms       v11, v13, v15, v16
    vf.mul       v13, v17, v11                   // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v13, v13
    @p2 v.sel        v11, v13, v6
    v.extract    s14, v11, #0
    v.splat      v6, s14
    vf.mul       v11, v8, v6
    vf.mul       v6, v9, v11
    vf.mul       v8, v6, v0
    vf.add       v0, v8, v12
    vf.mul       v6, v0, v14
    vf.mul       v0, v6, v7
    vf.add       v6, v2, v0
    @p1 v.sel        v0, v6, v2
    v.mov        v10, v0
    v.mov        v2, v10
    s.mov        s5, s1
    br.nz        s11, for_1
endfor_2:
    vf.reduce.add.b v0, v2
    v.movi       v1, #0
    s.movz       s1, #1
    vf.add       v2, v0, v1
    s.shli       s2, s4, #2                      // element offset -> bytes (x4)
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.add        s1, s10, s2                     // &out_ptr0[...]
    v.cmp.lt     p1, v0, v1
    @p1 v.st.w       [s1, #0], v2
__rctx_next:
    exit
