from pathlib import Path
import subprocess,json
root=Path.cwd();out=root/'pressure_mshr8_fulltag';out.mkdir(exist_ok=False);records=[]
def run(name,args):
 p=subprocess.run(args,capture_output=True,text=True,timeout=900);s=p.stdout+p.stderr;(out/(name+'.log')).write_text(s);assert p.returncode==0,(name,s[-3000:]);return s
for select,policy in [(0,0),(1,0),(1,74)]:
 name=f'select{select}_policy{policy}';binary=str(out/(name+'.vvp'))
 args=['iverilog','-g2012','-I','rtl/common','-s','tb_nuca_slice','-Ptb_nuca_slice.SETS=32','-Ptb_nuca_slice.SET_W=5','-Ptb_nuca_slice.WAYS=8','-Ptb_nuca_slice.WAY_W=3','-Ptb_nuca_slice.MAINTENANCE=1','-Ptb_nuca_slice.REGISTER_VICTIM_OWNER=1','-Ptb_nuca_slice.DCO_REGISTERED_RANGES=1',f'-Ptb_nuca_slice.REGISTER_VICTIM_SELECT={select}',f'-Ptb_nuca_slice.POLICY={policy}','-Ptb_nuca_slice.EPOCH_CHURN=3','-Ptb_nuca_slice.DRAM_LAT=400','-o',binary,'rtl/nuca/tnca_nuca_slice.v','tb/common/tnca_dram_model.v',str(root/'tb_pressure_mshr8.v')]
 run(name+'_build',args)
 for seed in [1,7]:
  case=name+'_seed'+str(seed);s=run(case,['vvp',binary,'+nreq=20000',f'+seed={seed}','+min_wb=1','+min_block=1']);assert '\nPASS\n' in s and '\nFAIL' not in s and 'FATAL' not in s,(case,s[-3000:]);records.append(dict(name=case,select=select,policy=policy,status='functional-pass',stdout=s.strip()));(out/'report.json').write_text(json.dumps(records,indent=2)+'\n');print('PASS',case,flush=True)
print('REGISTERED_VICTIM_PRESSURE_DONE',flush=True)
