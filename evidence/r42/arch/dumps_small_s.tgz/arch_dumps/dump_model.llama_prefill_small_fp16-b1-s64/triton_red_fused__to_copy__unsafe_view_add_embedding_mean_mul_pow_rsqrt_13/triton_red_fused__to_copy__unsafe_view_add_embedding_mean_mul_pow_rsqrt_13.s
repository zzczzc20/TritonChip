    s.rdspecial  s1, arg_base
    s.rdspecial  s2, role_id
    s.ld.d       s3, [s1, #56]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.movz       s1, #768
    s.rdspecial  s4, arg_base
    s.mul        s5, s2, s1
    s.movz       s1, #16
    s.movz       s2, #1
    s.movz       s6, #0
    s.movz       s7, #128
    s.movz       s8, #32
    s.rdspecial  s9, role_id
    s.rdspecial  s10, npid.x
    s.ld.d       s11, [s4, #0]                   // in_ptr0: device_ptr64 at arg_base+0
    s.add        s12, s3, s5                     // this context's own scratch
    s.ld.d       s3, [s4, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s4, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s12, [s4, #24]                  // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s13, [s4, #32]                  // out_ptr1: device_ptr64 at arg_base+32
__rctx_program:
    s.shli       s4, s9, #3                      // element offset -> bytes (x8)
    v.movi       v0, #0
    v.movi       v1, #1
    v.iota       v2                              // arange(0, VLEN)
    s.add        s14, s11, s4                    // &in_ptr0[...]
    v.splat      v3, s2
    v.movi       v4, #16
    v.shl        v5, v0, v1
    v.movi       v0, #0
    v.movi       v1, #0
    v.movi       v6, #0
    v.movi       v7, #0
    s.addi       s4, s14, #4
    v.cmp.lt     p1, v2, v3
    v.add        v3, v2, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s14, v5]              // index is in elements (ISA sec 9.1)
    s.addi       s14, s6, #0
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v8, [s4, v5]               // index is in elements (ISA sec 9.1)
    v.mov        v1, v0
    v.mov        v7, v6
for_1:
    s.cmp.ge     s4, s14, s7
    br.nz        s4, endfor_2
    s.addi       s4, s14, #16
    v.splat      v0, s14
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s4
    v.iota       v9                              // arange(0, VLEN)
    s.movz       s15, #64
    s.muli       s16, s9, #256
    v.add        v10, v0, v5
    v.movi       v0, #0
    v.splat      v5, s7
    v.splat      v11, s9
    v.splat      v12, s15
    v.add        v13, v6, v9
    v.movi       v6, #0
    v.splat      v9, s7
    v.splat      v14, s9
    v.splat      v15, s15
    s.muli       s15, s14, #2
    s.muli       s17, s4, #2
    v.extract    s4, v8, #0
    v.cmp.ge     p1, v10, v0
    v.cmp.lt     p2, v10, v5
    v.cmp.ge     p3, v11, v0
    v.cmp.lt     p4, v11, v12
    v.extract    s18, v4, #0
    s.shli       s19, s4, #32
    s.add        s4, s5, s16
    p.and        p5, p1, p2
    v.cmp.ge     p1, v13, v6
    p.and        p2, p3, p4
    v.cmp.lt     p3, v13, v9
    p.and        p4, p1, p3
    v.cmp.ge     p1, v14, v6
    s.add        s16, s4, s15
    p.and        p3, p5, p2
    v.cmp.lt     p2, v14, v15
    p.and        p5, p1, p2
    s.add        s15, s4, s17
    p.and        p1, p4, p5
    v.movi       v0, #0
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v5, [s16, #0]
    v.splat      v6, s14
    s.or         s4, s18, s19
    v.splat      v9, s14
    s.movz       s16, #0
    v.add        v10, v6, v2
    s.cmp.ge     s17, s4, s16
    v.add        v6, v9, v3
    s.movz       s18, #512
    v.movi       v9, #0
    s.cmp.lt     s19, s4, s18
    v.movi       v11, #0
    v.movi       v12, #0
    v.movi       v13, #1
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s15, #0]
    v.insert     v0, s17, #0
    v.insert     v9, s19, #0
    s.movz       s15, #1
    v.cmp.ne     p1, v0, v11
    v.cmp.ne     p2, v9, v12
    p.and        p3, p1, p2
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v9, s15
    @p3 v.sel        v11, v12, v13
    vf.cvt.f16.f32 v12, v5
    v.cmp.lt     p1, v0, v9
    @p1 v.reduce.or  s15, v11
    s.cmp.eq     s17, s15, s16
    vf.cvt.f16.f32 v0, v14
    br.nz        s17, assert_ok_3
    trap         #677351
assert_ok_3:
    s.movz       s15, #128
    v.extract    s16, v10, #0
    s.mul        s17, s4, s15
    s.shli       s4, s16, #32
    v.extract    s15, v10, #1
    s.ashri      s16, s4, #32
    v.movi       v5, #0
    v.movi       v9, #0
    v.movi       v11, #0
    v.movi       v13, #0
    s.shli       s4, s15, #32
    s.lshri      s15, s17, #32
    s.lshri      s18, s16, #32
    v.extract    s19, v10, #2
    s.ashri      s20, s4, #32
    v.insert     v5, s17, #0
    v.insert     v9, s15, #0
    v.insert     v11, s16, #0
    v.insert     v13, s18, #0
    s.shli       s4, s19, #32
    s.lshri      s15, s20, #32
    v.extract    s16, v10, #3
    s.ashri      s17, s4, #32
    v.insert     v11, s20, #1
    v.insert     v13, s15, #1
    s.shli       s4, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v10, #4
    s.ashri      s18, s4, #32
    v.insert     v11, s17, #2
    v.insert     v13, s15, #2
    s.shli       s4, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v10, #5
    s.ashri      s17, s4, #32
    v.insert     v11, s18, #3
    v.insert     v13, s15, #3
    s.shli       s4, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v10, #6
    s.ashri      s18, s4, #32
    v.insert     v11, s17, #4
    v.insert     v13, s15, #4
    s.shli       s4, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v10, #7
    s.ashri      s17, s4, #32
    v.insert     v11, s18, #5
    v.insert     v13, s15, #5
    s.shli       s4, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v10, #8
    s.ashri      s18, s4, #32
    v.insert     v11, s17, #6
    v.insert     v13, s15, #6
    s.shli       s4, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v10, #9
    s.ashri      s17, s4, #32
    v.insert     v11, s18, #7
    v.insert     v13, s15, #7
    s.shli       s4, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v10, #10
    s.ashri      s18, s4, #32
    v.insert     v11, s17, #8
    v.insert     v13, s15, #8
    s.shli       s4, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v10, #11
    s.ashri      s17, s4, #32
    v.insert     v11, s18, #9
    v.insert     v13, s15, #9
    s.shli       s4, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v10, #12
    s.ashri      s18, s4, #32
    v.insert     v11, s17, #10
    v.insert     v13, s15, #10
    s.shli       s4, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v10, #13
    s.ashri      s17, s4, #32
    v.insert     v11, s18, #11
    v.insert     v13, s15, #11
    s.shli       s4, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v10, #14
    s.ashri      s18, s4, #32
    v.insert     v11, s17, #12
    v.insert     v13, s15, #12
    s.shli       s4, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v10, #15
    v.extract    s17, v6, #0
    s.ashri      s19, s4, #32
    v.insert     v11, s18, #13
    v.insert     v13, s15, #13
    s.shli       s4, s16, #32
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v6, #1
    s.ashri      s18, s4, #32
    s.ashri      s4, s15, #32
    v.insert     v11, s19, #14
    v.insert     v13, s16, #14
    v.movi       v14, #0
    v.movi       v15, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    s.lshri      s17, s4, #32
    v.extract    s19, v6, #2
    s.ashri      s20, s15, #32
    v.insert     v11, s18, #15
    v.insert     v13, s16, #15
    v.insert     v14, s4, #0
    v.insert     v15, s17, #0
    s.shli       s4, s19, #32
    s.lshri      s15, s20, #32
    v.extract    s16, v6, #3
    s.ashri      s17, s4, #32
    v.insert     v14, s20, #1
    v.insert     v15, s15, #1
    s.shli       s4, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v6, #4
    s.ashri      s18, s4, #32
    v.insert     v14, s17, #2
    v.insert     v15, s15, #2
    s.shli       s4, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v6, #5
    s.ashri      s17, s4, #32
    v.insert     v14, s18, #3
    v.insert     v15, s15, #3
    s.shli       s4, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v6, #6
    s.ashri      s18, s4, #32
    v.insert     v14, s17, #4
    v.insert     v15, s15, #4
    s.shli       s4, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v6, #7
    s.ashri      s17, s4, #32
    v.insert     v14, s18, #5
    v.insert     v15, s15, #5
    s.shli       s4, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v6, #8
    s.ashri      s18, s4, #32
    v.insert     v14, s17, #6
    v.insert     v15, s15, #6
    s.shli       s4, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v6, #9
    s.ashri      s17, s4, #32
    v.insert     v14, s18, #7
    v.insert     v15, s15, #7
    s.shli       s4, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v6, #10
    s.ashri      s18, s4, #32
    v.insert     v14, s17, #8
    v.insert     v15, s15, #8
    s.shli       s4, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v6, #11
    s.ashri      s17, s4, #32
    v.insert     v14, s18, #9
    v.insert     v15, s15, #9
    s.shli       s4, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v6, #12
    s.ashri      s18, s4, #32
    v.insert     v14, s17, #10
    v.insert     v15, s15, #10
    s.shli       s4, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v6, #13
    s.ashri      s17, s4, #32
    v.insert     v14, s18, #11
    v.insert     v15, s15, #11
    s.shli       s4, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v6, #14
    s.ashri      s18, s4, #32
    v.insert     v14, s17, #12
    v.insert     v15, s15, #12
    s.shli       s4, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v6, #15
    v.extract    s17, v9, #0
    s.ashri      s19, s4, #32
    v.insert     v14, s18, #13
    v.insert     v15, s15, #13
    s.shli       s4, s16, #32
    v.extract    s15, v5, #0
    s.shli       s16, s17, #32
    s.lshri      s17, s19, #32
    v.extract    s18, v9, #0
    s.ashri      s20, s4, #32
    s.or         s4, s15, s16
    v.insert     v14, s19, #14
    v.insert     v15, s17, #14
    v.movi       v16, #0
    v.movi       v17, #0
    v.extract    s15, v5, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s20, #32
    s.lshri      s18, s4, #32
    v.extract    s19, v9, #0
    s.or         s21, s15, s16
    v.insert     v14, s20, #15
    v.insert     v15, s17, #15
    v.insert     v16, s4, #0
    v.insert     v17, s18, #0
    v.extract    s4, v5, #0
    s.shli       s15, s19, #32
    s.lshri      s16, s21, #32
    v.extract    s17, v9, #0
    s.or         s18, s4, s15
    v.insert     v16, s21, #1
    v.insert     v17, s16, #1
    v.extract    s4, v5, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v9, #0
    s.or         s19, s4, s15
    v.insert     v16, s18, #2
    v.insert     v17, s16, #2
    v.extract    s4, v5, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v9, #0
    s.or         s18, s4, s15
    v.insert     v16, s19, #3
    v.insert     v17, s16, #3
    v.extract    s4, v5, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v9, #0
    s.or         s19, s4, s15
    v.insert     v16, s18, #4
    v.insert     v17, s16, #4
    v.extract    s4, v5, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v9, #0
    s.or         s18, s4, s15
    v.insert     v16, s19, #5
    v.insert     v17, s16, #5
    v.extract    s4, v5, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v9, #0
    s.or         s19, s4, s15
    v.insert     v16, s18, #6
    v.insert     v17, s16, #6
    v.extract    s4, v5, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v9, #0
    s.or         s18, s4, s15
    v.insert     v16, s19, #7
    v.insert     v17, s16, #7
    v.extract    s4, v5, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v9, #0
    s.or         s19, s4, s15
    v.insert     v16, s18, #8
    v.insert     v17, s16, #8
    v.extract    s4, v5, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v9, #0
    s.or         s18, s4, s15
    v.insert     v16, s19, #9
    v.insert     v17, s16, #9
    v.extract    s4, v5, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v9, #0
    s.or         s19, s4, s15
    v.insert     v16, s18, #10
    v.insert     v17, s16, #10
    v.extract    s4, v5, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v9, #0
    s.or         s18, s4, s15
    v.insert     v16, s19, #11
    v.insert     v17, s16, #11
    v.extract    s4, v5, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v9, #0
    s.or         s19, s4, s15
    v.insert     v16, s18, #12
    v.insert     v17, s16, #12
    v.extract    s4, v5, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v9, #0
    v.extract    s18, v9, #0
    s.or         s20, s4, s15
    v.insert     v16, s19, #13
    v.insert     v17, s16, #13
    v.extract    s4, v5, #0
    s.shli       s15, s17, #32
    v.extract    s16, v5, #0
    s.shli       s17, s18, #32
    s.lshri      s18, s20, #32
    v.extract    s19, v9, #0
    s.or         s21, s4, s15
    s.or         s4, s16, s17
    v.insert     v16, s20, #14
    v.insert     v17, s18, #14
    v.movi       v18, #0
    v.movi       v19, #0
    v.extract    s15, v5, #0
    s.shli       s16, s19, #32
    s.lshri      s17, s21, #32
    s.lshri      s18, s4, #32
    v.extract    s19, v9, #0
    s.or         s20, s15, s16
    v.insert     v16, s21, #15
    v.insert     v17, s17, #15
    v.insert     v18, s4, #0
    v.insert     v19, s18, #0
    v.extract    s4, v5, #0
    s.shli       s15, s19, #32
    s.lshri      s16, s20, #32
    v.extract    s17, v9, #0
    s.or         s18, s4, s15
    v.insert     v18, s20, #1
    v.insert     v19, s16, #1
    v.extract    s4, v5, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v9, #0
    s.or         s19, s4, s15
    v.insert     v18, s18, #2
    v.insert     v19, s16, #2
    v.extract    s4, v5, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v9, #0
    s.or         s18, s4, s15
    v.insert     v18, s19, #3
    v.insert     v19, s16, #3
    v.extract    s4, v5, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v9, #0
    s.or         s19, s4, s15
    v.insert     v18, s18, #4
    v.insert     v19, s16, #4
    v.extract    s4, v5, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v9, #0
    s.or         s18, s4, s15
    v.insert     v18, s19, #5
    v.insert     v19, s16, #5
    v.extract    s4, v5, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v9, #0
    s.or         s19, s4, s15
    v.insert     v18, s18, #6
    v.insert     v19, s16, #6
    v.extract    s4, v5, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v9, #0
    s.or         s18, s4, s15
    v.insert     v18, s19, #7
    v.insert     v19, s16, #7
    v.extract    s4, v5, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v9, #0
    s.or         s19, s4, s15
    v.insert     v18, s18, #8
    v.insert     v19, s16, #8
    v.extract    s4, v5, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v9, #0
    s.or         s18, s4, s15
    v.insert     v18, s19, #9
    v.insert     v19, s16, #9
    v.extract    s4, v5, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v9, #0
    s.or         s19, s4, s15
    v.insert     v18, s18, #10
    v.insert     v19, s16, #10
    v.extract    s4, v5, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v9, #0
    s.or         s18, s4, s15
    v.insert     v18, s19, #11
    v.insert     v19, s16, #11
    v.extract    s4, v5, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v9, #0
    s.or         s19, s4, s15
    v.extract    s4, v13, #0
    v.extract    s15, v17, #0
    v.insert     v18, s18, #12
    v.insert     v19, s16, #12
    v.extract    s16, v5, #0
    s.shli       s18, s17, #32
    s.lshri      s17, s19, #32
    v.extract    s20, v9, #0
    s.shli       s21, s4, #32
    s.shli       s4, s15, #32
    s.or         s15, s16, s18
    v.extract    s16, v11, #0
    v.insert     v18, s19, #13
    v.extract    s18, v16, #0
    v.insert     v19, s17, #13
    v.extract    s17, v13, #1
    s.shli       s19, s20, #32
    s.or         s20, s16, s21
    v.extract    s16, v17, #1
    s.or         s21, s18, s4
    v.extract    s4, v5, #0
    s.shli       s18, s17, #32
    s.shli       s17, s16, #32
    s.or         s16, s4, s19
    s.lshri      s4, s15, #32
    s.add        s19, s20, s21
    v.extract    s20, v11, #1
    v.insert     v18, s15, #14
    v.extract    s15, v16, #1
    v.insert     v19, s4, #14
    v.extract    s4, v13, #2
    v.movi       v5, #0
    v.movi       v9, #0
    s.or         s21, s20, s18
    v.extract    s18, v17, #2
    s.or         s20, s15, s17
    s.lshri      s15, s16, #32
    s.shli       s17, s4, #32
    s.shli       s4, s18, #32
    s.add        s18, s21, s20
    s.lshri      s20, s19, #32
    v.insert     v18, s16, #15
    v.extract    s16, v11, #2
    v.insert     v19, s15, #15
    v.extract    s15, v16, #2
    v.insert     v5, s19, #0
    v.extract    s19, v13, #3
    v.insert     v9, s20, #0
    v.extract    s20, v17, #3
    s.or         s21, s16, s17
    s.or         s16, s15, s4
    s.lshri      s4, s18, #32
    v.extract    s15, v11, #3
    s.shli       s17, s19, #32
    s.shli       s19, s20, #32
    s.add        s20, s21, s16
    v.extract    s16, v16, #3
    v.insert     v5, s18, #1
    v.extract    s18, v13, #4
    v.insert     v9, s4, #1
    v.extract    s4, v17, #4
    s.or         s21, s15, s17
    s.or         s15, s16, s19
    s.lshri      s16, s20, #32
    v.extract    s17, v11, #4
    s.shli       s19, s18, #32
    s.shli       s18, s4, #32
    s.add        s4, s21, s15
    v.extract    s15, v16, #4
    v.insert     v5, s20, #2
    v.extract    s20, v13, #5
    v.insert     v9, s16, #2
    v.extract    s16, v17, #5
    s.or         s21, s17, s19
    s.or         s17, s15, s18
    s.lshri      s15, s4, #32
    v.extract    s18, v11, #5
    s.shli       s19, s20, #32
    s.shli       s20, s16, #32
    s.add        s16, s21, s17
    v.extract    s17, v16, #5
    v.insert     v5, s4, #3
    v.extract    s4, v13, #6
    v.insert     v9, s15, #3
    v.extract    s15, v17, #6
    s.or         s21, s18, s19
    s.or         s18, s17, s20
    s.lshri      s17, s16, #32
    v.extract    s19, v11, #6
    s.shli       s20, s4, #32
    s.shli       s4, s15, #32
    s.add        s15, s21, s18
    v.extract    s18, v16, #6
    v.insert     v5, s16, #4
    v.extract    s16, v13, #7
    v.insert     v9, s17, #4
    v.extract    s17, v17, #7
    s.or         s21, s19, s20
    s.or         s19, s18, s4
    s.lshri      s4, s15, #32
    v.extract    s18, v11, #7
    s.shli       s20, s16, #32
    s.shli       s16, s17, #32
    s.add        s17, s21, s19
    v.extract    s19, v16, #7
    v.insert     v5, s15, #5
    v.extract    s15, v13, #8
    v.insert     v9, s4, #5
    v.extract    s4, v17, #8
    s.or         s21, s18, s20
    s.or         s18, s19, s16
    s.lshri      s16, s17, #32
    v.extract    s19, v11, #8
    s.shli       s20, s15, #32
    s.shli       s15, s4, #32
    s.add        s4, s21, s18
    v.extract    s18, v16, #8
    v.insert     v5, s17, #6
    v.extract    s17, v13, #9
    v.insert     v9, s16, #6
    v.extract    s16, v17, #9
    s.or         s21, s19, s20
    s.or         s19, s18, s15
    s.lshri      s15, s4, #32
    v.extract    s18, v11, #9
    s.shli       s20, s17, #32
    s.shli       s17, s16, #32
    s.add        s16, s21, s19
    v.extract    s19, v16, #9
    v.insert     v5, s4, #7
    v.extract    s4, v13, #10
    v.insert     v9, s15, #7
    v.extract    s15, v17, #10
    s.or         s21, s18, s20
    s.or         s18, s19, s17
    s.lshri      s17, s16, #32
    v.extract    s19, v11, #10
    s.shli       s20, s4, #32
    s.shli       s4, s15, #32
    s.add        s15, s21, s18
    v.extract    s18, v16, #10
    v.insert     v5, s16, #8
    v.extract    s16, v13, #11
    v.insert     v9, s17, #8
    v.extract    s17, v17, #11
    s.or         s21, s19, s20
    s.or         s19, s18, s4
    s.lshri      s4, s15, #32
    v.extract    s18, v11, #11
    s.shli       s20, s16, #32
    s.shli       s16, s17, #32
    s.add        s17, s21, s19
    v.extract    s19, v16, #11
    v.insert     v5, s15, #9
    v.extract    s15, v13, #12
    v.insert     v9, s4, #9
    v.extract    s4, v17, #12
    s.or         s21, s18, s20
    s.or         s18, s19, s16
    s.lshri      s16, s17, #32
    v.extract    s19, v11, #12
    s.shli       s20, s15, #32
    s.shli       s15, s4, #32
    s.add        s4, s21, s18
    v.extract    s18, v16, #12
    v.insert     v5, s17, #10
    v.extract    s17, v13, #13
    v.insert     v9, s16, #10
    v.extract    s16, v17, #13
    s.or         s21, s19, s20
    s.or         s19, s18, s15
    s.lshri      s15, s4, #32
    v.extract    s18, v11, #13
    s.shli       s20, s17, #32
    s.shli       s17, s16, #32
    s.add        s16, s21, s19
    v.extract    s19, v16, #13
    v.insert     v5, s4, #11
    v.extract    s4, v13, #14
    v.insert     v9, s15, #11
    v.extract    s15, v17, #14
    s.or         s21, s18, s20
    s.or         s18, s19, s17
    s.lshri      s17, s16, #32
    v.extract    s19, v11, #14
    s.shli       s20, s4, #32
    s.shli       s4, s15, #32
    s.add        s15, s21, s18
    v.extract    s18, v16, #14
    v.insert     v5, s16, #12
    v.extract    s16, v13, #15
    v.insert     v9, s17, #12
    v.extract    s17, v17, #15
    s.or         s21, s19, s20
    v.extract    s19, v15, #0
    s.or         s20, s18, s4
    v.extract    s4, v19, #0
    s.shli       s18, s16, #32
    s.shli       s16, s17, #32
    s.shli       s17, s19, #32
    s.shli       s19, s4, #32
    s.add        s4, s21, s20
    s.lshri      s20, s15, #32
    v.insert     v5, s15, #13
    v.extract    s15, v11, #15
    v.insert     v9, s20, #13
    v.extract    s20, v16, #15
    s.or         s21, s15, s18
    v.extract    s15, v14, #0
    s.or         s18, s20, s16
    v.extract    s16, v18, #0
    s.or         s20, s15, s17
    v.extract    s15, v15, #1
    s.or         s17, s16, s19
    v.extract    s16, v19, #1
    s.shli       s19, s15, #32
    s.shli       s15, s16, #32
    s.add        s16, s21, s18
    s.lshri      s18, s4, #32
    s.add        s21, s20, s17
    v.extract    s17, v14, #1
    v.insert     v5, s4, #14
    v.extract    s4, v18, #1
    v.insert     v9, s18, #14
    v.extract    s18, v15, #2
    v.movi       v11, #0
    v.movi       v13, #0
    s.or         s20, s17, s19
    v.extract    s17, v19, #2
    s.or         s19, s4, s15
    s.lshri      s4, s16, #32
    s.shli       s15, s18, #32
    s.shli       s18, s17, #32
    s.add        s17, s20, s19
    s.lshri      s19, s21, #32
    v.insert     v5, s16, #15
    v.extract    s16, v14, #2
    v.insert     v9, s4, #15
    v.extract    s4, v18, #2
    v.insert     v11, s21, #0
    v.extract    s20, v15, #3
    v.insert     v13, s19, #0
    v.extract    s19, v19, #3
    s.or         s21, s16, s15
    s.or         s15, s4, s18
    s.lshri      s4, s17, #32
    v.extract    s16, v14, #3
    s.shli       s18, s20, #32
    s.shli       s20, s19, #32
    s.add        s19, s21, s15
    v.extract    s15, v18, #3
    v.insert     v11, s17, #1
    v.extract    s17, v15, #4
    v.insert     v13, s4, #1
    v.extract    s4, v19, #4
    s.or         s21, s16, s18
    s.or         s16, s15, s20
    s.lshri      s15, s19, #32
    v.extract    s18, v14, #4
    s.shli       s20, s17, #32
    s.shli       s17, s4, #32
    s.add        s4, s21, s16
    v.extract    s16, v18, #4
    v.insert     v11, s19, #2
    v.extract    s19, v15, #5
    v.insert     v13, s15, #2
    v.extract    s15, v19, #5
    s.or         s21, s18, s20
    s.or         s18, s16, s17
    s.lshri      s16, s4, #32
    v.extract    s17, v14, #5
    s.shli       s20, s19, #32
    s.shli       s19, s15, #32
    s.add        s15, s21, s18
    v.extract    s18, v18, #5
    v.insert     v11, s4, #3
    v.extract    s4, v15, #6
    v.insert     v13, s16, #3
    v.extract    s16, v19, #6
    s.or         s21, s17, s20
    s.or         s17, s18, s19
    s.lshri      s18, s15, #32
    v.extract    s19, v14, #6
    s.shli       s20, s4, #32
    s.shli       s4, s16, #32
    s.add        s16, s21, s17
    v.extract    s17, v18, #6
    v.insert     v11, s15, #4
    v.extract    s15, v15, #7
    v.insert     v13, s18, #4
    v.extract    s18, v19, #7
    s.or         s21, s19, s20
    s.or         s19, s17, s4
    s.lshri      s4, s16, #32
    v.extract    s17, v14, #7
    s.shli       s20, s15, #32
    s.shli       s15, s18, #32
    s.add        s18, s21, s19
    v.extract    s19, v18, #7
    v.insert     v11, s16, #5
    v.extract    s16, v15, #8
    v.insert     v13, s4, #5
    v.extract    s4, v19, #8
    s.or         s21, s17, s20
    s.or         s17, s19, s15
    s.lshri      s15, s18, #32
    v.extract    s19, v14, #8
    s.shli       s20, s16, #32
    s.shli       s16, s4, #32
    s.add        s4, s21, s17
    v.extract    s17, v18, #8
    v.insert     v11, s18, #6
    v.extract    s18, v15, #9
    v.insert     v13, s15, #6
    v.extract    s15, v19, #9
    s.or         s21, s19, s20
    s.or         s19, s17, s16
    s.lshri      s16, s4, #32
    v.extract    s17, v14, #9
    s.shli       s20, s18, #32
    s.shli       s18, s15, #32
    s.add        s15, s21, s19
    v.extract    s19, v18, #9
    v.insert     v11, s4, #7
    v.extract    s4, v15, #10
    v.insert     v13, s16, #7
    v.extract    s16, v19, #10
    s.or         s21, s17, s20
    s.or         s17, s19, s18
    s.lshri      s18, s15, #32
    v.extract    s19, v14, #10
    s.shli       s20, s4, #32
    s.shli       s4, s16, #32
    s.add        s16, s21, s17
    v.extract    s17, v18, #10
    v.insert     v11, s15, #8
    v.extract    s15, v15, #11
    v.insert     v13, s18, #8
    v.extract    s18, v19, #11
    s.or         s21, s19, s20
    s.or         s19, s17, s4
    s.lshri      s4, s16, #32
    v.extract    s17, v14, #11
    s.shli       s20, s15, #32
    s.shli       s15, s18, #32
    s.add        s18, s21, s19
    v.extract    s19, v18, #11
    v.insert     v11, s16, #9
    v.extract    s16, v15, #12
    v.insert     v13, s4, #9
    v.extract    s4, v19, #12
    s.or         s21, s17, s20
    s.or         s17, s19, s15
    s.lshri      s15, s18, #32
    v.extract    s19, v14, #12
    s.shli       s20, s16, #32
    s.shli       s16, s4, #32
    s.add        s4, s21, s17
    v.extract    s17, v18, #12
    v.insert     v11, s18, #10
    v.extract    s18, v15, #13
    v.insert     v13, s15, #10
    v.extract    s15, v19, #13
    s.or         s21, s19, s20
    s.or         s19, s17, s16
    s.lshri      s16, s4, #32
    v.extract    s17, v14, #13
    s.shli       s20, s18, #32
    s.shli       s18, s15, #32
    s.add        s15, s21, s19
    v.extract    s19, v18, #13
    v.insert     v11, s4, #11
    v.extract    s4, v15, #14
    v.insert     v13, s16, #11
    v.movi       v16, #31
    v.extract    s16, v19, #14
    s.or         s21, s17, s20
    s.or         s17, s19, s18
    s.lshri      s18, s15, #32
    v.extract    s19, v14, #14
    s.shli       s20, s4, #32
    s.shli       s4, s16, #32
    v.ashr       v17, v5, v16
    s.add        s16, s21, s17
    v.extract    s17, v18, #14
    v.movi       v16, #1
    v.movi       v20, #0
    v.insert     v11, s15, #12
    v.extract    s15, v15, #15
    v.insert     v13, s18, #12
    v.extract    s18, v19, #15
    s.or         s21, s19, s20
    s.or         s19, s17, s4
    s.lshri      s4, s16, #32
    v.extract    s17, v14, #15
    s.shli       s20, s15, #32
    s.shli       s15, s18, #32
    v.cmp.ne     p1, v9, v17
    s.add        s18, s21, s19
    v.extract    s19, v18, #15
    @p1 v.sel        v9, v16, v20
    v.insert     v11, s16, #13
    v.insert     v13, s4, #13
    s.or         s4, s17, s20
    s.or         s16, s19, s15
    s.lshri      s15, s18, #32
    s.add        s17, s4, s16
    v.reduce.or  s4, v9
    s.movz       s16, #0
    v.insert     v11, s18, #14
    v.insert     v13, s15, #14
    s.lshri      s15, s17, #32
    s.cmp.eq     s18, s4, s16
    v.insert     v11, s17, #15
    v.insert     v13, s15, #15
    br.nz        s18, narrow_ok_4
    trap         #677220
narrow_ok_4:
    v.movi       v9, #31
    v.movi       v14, #1
    v.movi       v15, #0
    v.ashr       v16, v11, v9
    v.cmp.ne     p1, v13, v16
    @p1 v.sel        v9, v14, v15
    v.reduce.or  s4, v9
    s.cmp.eq     s15, s4, s16
    br.nz        s15, narrow_ok_5
    trap         #677220
narrow_ok_5:
    v.movi       v9, #128
    v.movi       v13, #0
    v.movi       v14, #0
    v.cmp.lt     p1, v10, v9
    v.cmp.lt     p2, v6, v9
    v.movi       v15, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v15, [s3, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v10, v9
    s.movz       s4, #1
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v5, [s3, v11]              // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v10, v15
    v.cmp.lt     p2, v6, v9
    vf.add       v6, v10, v12
    vf.mul       v9, v6, v6
    vf.cvt.f16.f32 v6, v5
    vf.add       v5, v1, v9
    vf.add       v9, v6, v0
    @p1 v.sel        v13, v5, v1
    vf.mul       v0, v9, v9
    vf.add       v5, v7, v0
    @p2 v.sel        v14, v5, v7
    v.mov        v1, v13
    v.mov        v7, v14
    s.add        s14, s14, s8
    br.nz        s4, for_1
endfor_2:
    vf.reduce.add.b v0, v1
    vf.reduce.add.b v1, v7
    v.movi       v5, #0
    s.addi       s4, s6, #0
    vf.add       v6, v0, v1
    vf.add       v0, v6, v5
for_6:
    s.cmp.ge     s14, s4, s7
    br.nz        s14, endfor_7
    s.addi       s14, s4, #16
    v.splat      v1, s4
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s14
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s15, #128
    s.movz       s16, #64
    s.muli       s17, s9, #256
    v.add        v9, v1, v5
    v.movi       v1, #0
    v.splat      v5, s15
    v.splat      v10, s9
    v.splat      v11, s16
    v.add        v12, v6, v7
    v.movi       v6, #0
    v.splat      v7, s15
    v.splat      v13, s9
    v.splat      v14, s16
    v.splat      v15, s4
    v.splat      v16, s4
    s.muli       s15, s4, #2
    s.muli       s16, s14, #2
    s.add        s14, s1, s4
    v.cmp.ge     p1, v9, v1
    v.cmp.lt     p2, v9, v5
    v.cmp.ge     p3, v10, v1
    v.cmp.lt     p4, v10, v11
    v.add        v1, v15, v2
    v.add        v5, v16, v3
    s.add        s18, s5, s17
    p.and        p5, p1, p2
    v.cmp.ge     p1, v12, v6
    p.and        p2, p3, p4
    v.cmp.lt     p3, v12, v7
    p.and        p4, p1, p3
    v.cmp.ge     p1, v13, v6
    v.movi       v6, #128
    s.shli       s17, s4, #1                     // element offset -> bytes (x2)
    s.shli       s19, s14, #1                    // element offset -> bytes (x2)
    s.add        s20, s18, s15
    v.extract    s15, v8, #0
    v.extract    s21, v4, #0
    s.shli       s22, s15, #32
    s.movz       s15, #0
    s.or         s23, s21, s22
    s.movz       s21, #512
    p.and        p3, p5, p2
    v.cmp.lt     p2, v13, v14
    p.and        p5, p1, p2
    s.add        s22, s18, s16
    p.and        p1, p4, p5
    s.add        s16, s12, s17                   // &in_ptr3[...]
    s.add        s17, s12, s19                   // &in_ptr3[...]
    v.movi       v7, #0
    v.movi       v9, #0
    v.cmp.lt     p2, v1, v6
    v.cmp.lt     p4, v5, v6
    s.cmp.ge     s18, s23, s15
    s.cmp.lt     s19, s23, s21
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v10, [s20, #0]
    v.movi       v11, #0
    v.movi       v12, #0
    v.movi       v13, #1
    s.movz       s20, #1
    v.iota       v14                             // arange(0, VLEN)
    v.splat      v15, s20
    v.cmp.lt     p3, v14, v15
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s22, #0]
    vf.cvt.f16.f32 v15, v10
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v10, [s16, #0]
    vf.cvt.f16.f32 v16, v14
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v14, [s17, #0]
    v.insert     v7, s18, #0
    v.insert     v9, s19, #0
    vf.cvt.f16.f32 v17, v10
    v.cmp.ne     p1, v7, v11
    v.cmp.ne     p2, v9, v12
    p.and        p4, p1, p2
    @p4 v.sel        v7, v12, v13
    @p3 v.reduce.or  s16, v7
    s.cmp.eq     s17, s16, s15
    vf.cvt.f16.f32 v7, v14
    br.nz        s17, assert_ok_8
    trap         #677351
assert_ok_8:
    s.movz       s15, #128
    v.extract    s16, v1, #0
    s.mul        s17, s23, s15
    s.shli       s15, s16, #32
    v.extract    s16, v1, #1
    s.ashri      s18, s15, #32
    v.movi       v9, #0
    v.movi       v10, #0
    v.movi       v11, #0
    v.movi       v12, #0
    s.shli       s15, s16, #32
    s.lshri      s16, s17, #32
    s.lshri      s19, s18, #32
    v.extract    s20, v1, #2
    s.ashri      s21, s15, #32
    v.insert     v9, s17, #0
    v.insert     v10, s16, #0
    v.insert     v11, s18, #0
    v.insert     v12, s19, #0
    s.shli       s15, s20, #32
    s.lshri      s16, s21, #32
    v.extract    s17, v1, #3
    s.ashri      s18, s15, #32
    v.insert     v11, s21, #1
    v.insert     v12, s16, #1
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v1, #4
    s.ashri      s19, s15, #32
    v.insert     v11, s18, #2
    v.insert     v12, s16, #2
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v1, #5
    s.ashri      s18, s15, #32
    v.insert     v11, s19, #3
    v.insert     v12, s16, #3
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v1, #6
    s.ashri      s19, s15, #32
    v.insert     v11, s18, #4
    v.insert     v12, s16, #4
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v1, #7
    s.ashri      s18, s15, #32
    v.insert     v11, s19, #5
    v.insert     v12, s16, #5
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v1, #8
    s.ashri      s19, s15, #32
    v.insert     v11, s18, #6
    v.insert     v12, s16, #6
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v1, #9
    s.ashri      s18, s15, #32
    v.insert     v11, s19, #7
    v.insert     v12, s16, #7
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v1, #10
    s.ashri      s19, s15, #32
    v.insert     v11, s18, #8
    v.insert     v12, s16, #8
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v1, #11
    s.ashri      s18, s15, #32
    v.insert     v11, s19, #9
    v.insert     v12, s16, #9
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v1, #12
    s.ashri      s19, s15, #32
    v.insert     v11, s18, #10
    v.insert     v12, s16, #10
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v1, #13
    s.ashri      s18, s15, #32
    v.insert     v11, s19, #11
    v.insert     v12, s16, #11
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v1, #14
    s.ashri      s19, s15, #32
    v.insert     v11, s18, #12
    v.insert     v12, s16, #12
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v1, #15
    v.extract    s18, v5, #0
    s.ashri      s20, s15, #32
    v.insert     v11, s19, #13
    v.insert     v12, s16, #13
    s.shli       s15, s17, #32
    s.shli       s16, s18, #32
    s.lshri      s17, s20, #32
    v.extract    s18, v5, #1
    s.ashri      s19, s15, #32
    s.ashri      s15, s16, #32
    v.insert     v11, s20, #14
    v.insert     v12, s17, #14
    v.movi       v13, #0
    v.movi       v14, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s19, #32
    s.lshri      s18, s15, #32
    v.extract    s20, v5, #2
    s.ashri      s21, s16, #32
    v.insert     v11, s19, #15
    v.insert     v12, s17, #15
    v.insert     v13, s15, #0
    v.insert     v14, s18, #0
    s.shli       s15, s20, #32
    s.lshri      s16, s21, #32
    v.extract    s17, v5, #3
    s.ashri      s18, s15, #32
    v.insert     v13, s21, #1
    v.insert     v14, s16, #1
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v5, #4
    s.ashri      s19, s15, #32
    v.insert     v13, s18, #2
    v.insert     v14, s16, #2
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v5, #5
    s.ashri      s18, s15, #32
    v.insert     v13, s19, #3
    v.insert     v14, s16, #3
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v5, #6
    s.ashri      s19, s15, #32
    v.insert     v13, s18, #4
    v.insert     v14, s16, #4
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v5, #7
    s.ashri      s18, s15, #32
    v.insert     v13, s19, #5
    v.insert     v14, s16, #5
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v5, #8
    s.ashri      s19, s15, #32
    v.insert     v13, s18, #6
    v.insert     v14, s16, #6
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v5, #9
    s.ashri      s18, s15, #32
    v.insert     v13, s19, #7
    v.insert     v14, s16, #7
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v5, #10
    s.ashri      s19, s15, #32
    v.insert     v13, s18, #8
    v.insert     v14, s16, #8
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v5, #11
    s.ashri      s18, s15, #32
    v.insert     v13, s19, #9
    v.insert     v14, s16, #9
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v5, #12
    s.ashri      s19, s15, #32
    v.insert     v13, s18, #10
    v.insert     v14, s16, #10
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v5, #13
    s.ashri      s18, s15, #32
    v.insert     v13, s19, #11
    v.insert     v14, s16, #11
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v5, #14
    s.ashri      s19, s15, #32
    v.insert     v13, s18, #12
    v.insert     v14, s16, #12
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v5, #15
    v.extract    s18, v10, #0
    s.ashri      s20, s15, #32
    v.insert     v13, s19, #13
    v.insert     v14, s16, #13
    s.shli       s15, s17, #32
    v.extract    s16, v9, #0
    s.shli       s17, s18, #32
    s.lshri      s18, s20, #32
    v.extract    s19, v10, #0
    s.ashri      s21, s15, #32
    s.or         s15, s16, s17
    v.insert     v13, s20, #14
    v.insert     v14, s18, #14
    v.movi       v18, #0
    v.movi       v19, #0
    v.extract    s16, v9, #0
    s.shli       s17, s19, #32
    s.lshri      s18, s21, #32
    s.lshri      s19, s15, #32
    v.extract    s20, v10, #0
    s.or         s22, s16, s17
    v.insert     v13, s21, #15
    v.insert     v14, s18, #15
    v.insert     v18, s15, #0
    v.insert     v19, s19, #0
    v.extract    s15, v9, #0
    s.shli       s16, s20, #32
    s.lshri      s17, s22, #32
    v.extract    s18, v10, #0
    s.or         s19, s15, s16
    v.insert     v18, s22, #1
    v.insert     v19, s17, #1
    v.extract    s15, v9, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s19, #32
    v.extract    s18, v10, #0
    s.or         s20, s15, s16
    v.insert     v18, s19, #2
    v.insert     v19, s17, #2
    v.extract    s15, v9, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s20, #32
    v.extract    s18, v10, #0
    s.or         s19, s15, s16
    v.insert     v18, s20, #3
    v.insert     v19, s17, #3
    v.extract    s15, v9, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s19, #32
    v.extract    s18, v10, #0
    s.or         s20, s15, s16
    v.insert     v18, s19, #4
    v.insert     v19, s17, #4
    v.extract    s15, v9, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s20, #32
    v.extract    s18, v10, #0
    s.or         s19, s15, s16
    v.insert     v18, s20, #5
    v.insert     v19, s17, #5
    v.extract    s15, v9, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s19, #32
    v.extract    s18, v10, #0
    s.or         s20, s15, s16
    v.insert     v18, s19, #6
    v.insert     v19, s17, #6
    v.extract    s15, v9, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s20, #32
    v.extract    s18, v10, #0
    s.or         s19, s15, s16
    v.insert     v18, s20, #7
    v.insert     v19, s17, #7
    v.extract    s15, v9, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s19, #32
    v.extract    s18, v10, #0
    s.or         s20, s15, s16
    v.insert     v18, s19, #8
    v.insert     v19, s17, #8
    v.extract    s15, v9, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s20, #32
    v.extract    s18, v10, #0
    s.or         s19, s15, s16
    v.insert     v18, s20, #9
    v.insert     v19, s17, #9
    v.extract    s15, v9, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s19, #32
    v.extract    s18, v10, #0
    s.or         s20, s15, s16
    v.insert     v18, s19, #10
    v.insert     v19, s17, #10
    v.extract    s15, v9, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s20, #32
    v.extract    s18, v10, #0
    s.or         s19, s15, s16
    v.insert     v18, s20, #11
    v.insert     v19, s17, #11
    v.extract    s15, v9, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s19, #32
    v.extract    s18, v10, #0
    s.or         s20, s15, s16
    v.insert     v18, s19, #12
    v.insert     v19, s17, #12
    v.extract    s15, v9, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s20, #32
    v.extract    s18, v10, #0
    v.extract    s19, v10, #0
    s.or         s21, s15, s16
    v.insert     v18, s20, #13
    v.insert     v19, s17, #13
    v.extract    s15, v9, #0
    s.shli       s16, s18, #32
    v.extract    s17, v9, #0
    s.shli       s18, s19, #32
    s.lshri      s19, s21, #32
    v.extract    s20, v10, #0
    s.or         s22, s15, s16
    s.or         s15, s17, s18
    v.insert     v18, s21, #14
    v.insert     v19, s19, #14
    v.movi       v20, #0
    v.movi       v21, #0
    v.extract    s16, v9, #0
    s.shli       s17, s20, #32
    s.lshri      s18, s22, #32
    s.lshri      s19, s15, #32
    v.extract    s20, v10, #0
    s.or         s21, s16, s17
    v.insert     v18, s22, #15
    v.insert     v19, s18, #15
    v.insert     v20, s15, #0
    v.insert     v21, s19, #0
    v.extract    s15, v9, #0
    s.shli       s16, s20, #32
    s.lshri      s17, s21, #32
    v.extract    s18, v10, #0
    s.or         s19, s15, s16
    v.insert     v20, s21, #1
    v.insert     v21, s17, #1
    v.extract    s15, v9, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s19, #32
    v.extract    s18, v10, #0
    s.or         s20, s15, s16
    v.insert     v20, s19, #2
    v.insert     v21, s17, #2
    v.extract    s15, v9, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s20, #32
    v.extract    s18, v10, #0
    s.or         s19, s15, s16
    v.insert     v20, s20, #3
    v.insert     v21, s17, #3
    v.extract    s15, v9, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s19, #32
    v.extract    s18, v10, #0
    s.or         s20, s15, s16
    v.insert     v20, s19, #4
    v.insert     v21, s17, #4
    v.extract    s15, v9, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s20, #32
    v.extract    s18, v10, #0
    s.or         s19, s15, s16
    v.insert     v20, s20, #5
    v.insert     v21, s17, #5
    v.extract    s15, v9, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s19, #32
    v.extract    s18, v10, #0
    s.or         s20, s15, s16
    v.insert     v20, s19, #6
    v.insert     v21, s17, #6
    v.extract    s15, v9, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s20, #32
    v.extract    s18, v10, #0
    s.or         s19, s15, s16
    v.insert     v20, s20, #7
    v.insert     v21, s17, #7
    v.extract    s15, v9, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s19, #32
    v.extract    s18, v10, #0
    s.or         s20, s15, s16
    v.insert     v20, s19, #8
    v.insert     v21, s17, #8
    v.extract    s15, v9, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s20, #32
    v.extract    s18, v10, #0
    s.or         s19, s15, s16
    v.insert     v20, s20, #9
    v.insert     v21, s17, #9
    v.extract    s15, v9, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s19, #32
    v.extract    s18, v10, #0
    s.or         s20, s15, s16
    v.insert     v20, s19, #10
    v.insert     v21, s17, #10
    v.extract    s15, v9, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s20, #32
    v.extract    s18, v10, #0
    s.or         s19, s15, s16
    v.insert     v20, s20, #11
    v.insert     v21, s17, #11
    v.extract    s15, v9, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s19, #32
    v.extract    s18, v10, #0
    s.or         s20, s15, s16
    v.extract    s15, v12, #0
    v.extract    s16, v19, #0
    v.insert     v20, s19, #12
    v.insert     v21, s17, #12
    v.extract    s17, v9, #0
    s.shli       s19, s18, #32
    s.lshri      s18, s20, #32
    v.extract    s21, v10, #0
    s.shli       s22, s15, #32
    s.shli       s15, s16, #32
    s.or         s16, s17, s19
    v.extract    s17, v11, #0
    v.insert     v20, s20, #13
    v.extract    s19, v18, #0
    v.insert     v21, s18, #13
    v.extract    s18, v12, #1
    s.shli       s20, s21, #32
    s.or         s21, s17, s22
    v.extract    s17, v19, #1
    s.or         s22, s19, s15
    v.extract    s15, v9, #0
    s.shli       s19, s18, #32
    s.shli       s18, s17, #32
    s.or         s17, s15, s20
    s.lshri      s15, s16, #32
    s.add        s20, s21, s22
    v.extract    s21, v11, #1
    v.insert     v20, s16, #14
    v.extract    s16, v18, #1
    v.insert     v21, s15, #14
    v.extract    s15, v12, #2
    v.movi       v9, #0
    v.movi       v10, #0
    s.or         s22, s21, s19
    v.extract    s19, v19, #2
    s.or         s21, s16, s18
    s.lshri      s16, s17, #32
    s.shli       s18, s15, #32
    s.shli       s15, s19, #32
    s.add        s19, s22, s21
    s.lshri      s21, s20, #32
    v.insert     v20, s17, #15
    v.extract    s17, v11, #2
    v.insert     v21, s16, #15
    v.extract    s16, v18, #2
    v.insert     v9, s20, #0
    v.extract    s20, v12, #3
    v.insert     v10, s21, #0
    v.extract    s21, v19, #3
    s.or         s22, s17, s18
    s.or         s17, s16, s15
    s.lshri      s15, s19, #32
    v.extract    s16, v11, #3
    s.shli       s18, s20, #32
    s.shli       s20, s21, #32
    s.add        s21, s22, s17
    v.extract    s17, v18, #3
    v.insert     v9, s19, #1
    v.extract    s19, v12, #4
    v.insert     v10, s15, #1
    v.extract    s15, v19, #4
    s.or         s22, s16, s18
    s.or         s16, s17, s20
    s.lshri      s17, s21, #32
    v.extract    s18, v11, #4
    s.shli       s20, s19, #32
    s.shli       s19, s15, #32
    s.add        s15, s22, s16
    v.extract    s16, v18, #4
    v.insert     v9, s21, #2
    v.extract    s21, v12, #5
    v.insert     v10, s17, #2
    v.extract    s17, v19, #5
    s.or         s22, s18, s20
    s.or         s18, s16, s19
    s.lshri      s16, s15, #32
    v.extract    s19, v11, #5
    s.shli       s20, s21, #32
    s.shli       s21, s17, #32
    s.add        s17, s22, s18
    v.extract    s18, v18, #5
    v.insert     v9, s15, #3
    v.extract    s15, v12, #6
    v.insert     v10, s16, #3
    v.extract    s16, v19, #6
    s.or         s22, s19, s20
    s.or         s19, s18, s21
    s.lshri      s18, s17, #32
    v.extract    s20, v11, #6
    s.shli       s21, s15, #32
    s.shli       s15, s16, #32
    s.add        s16, s22, s19
    v.extract    s19, v18, #6
    v.insert     v9, s17, #4
    v.extract    s17, v12, #7
    v.insert     v10, s18, #4
    v.extract    s18, v19, #7
    s.or         s22, s20, s21
    s.or         s20, s19, s15
    s.lshri      s15, s16, #32
    v.extract    s19, v11, #7
    s.shli       s21, s17, #32
    s.shli       s17, s18, #32
    s.add        s18, s22, s20
    v.extract    s20, v18, #7
    v.insert     v9, s16, #5
    v.extract    s16, v12, #8
    v.insert     v10, s15, #5
    v.extract    s15, v19, #8
    s.or         s22, s19, s21
    s.or         s19, s20, s17
    s.lshri      s17, s18, #32
    v.extract    s20, v11, #8
    s.shli       s21, s16, #32
    s.shli       s16, s15, #32
    s.add        s15, s22, s19
    v.extract    s19, v18, #8
    v.insert     v9, s18, #6
    v.extract    s18, v12, #9
    v.insert     v10, s17, #6
    v.extract    s17, v19, #9
    s.or         s22, s20, s21
    s.or         s20, s19, s16
    s.lshri      s16, s15, #32
    v.extract    s19, v11, #9
    s.shli       s21, s18, #32
    s.shli       s18, s17, #32
    s.add        s17, s22, s20
    v.extract    s20, v18, #9
    v.insert     v9, s15, #7
    v.extract    s15, v12, #10
    v.insert     v10, s16, #7
    v.extract    s16, v19, #10
    s.or         s22, s19, s21
    s.or         s19, s20, s18
    s.lshri      s18, s17, #32
    v.extract    s20, v11, #10
    s.shli       s21, s15, #32
    s.shli       s15, s16, #32
    s.add        s16, s22, s19
    v.extract    s19, v18, #10
    v.insert     v9, s17, #8
    v.extract    s17, v12, #11
    v.insert     v10, s18, #8
    v.extract    s18, v19, #11
    s.or         s22, s20, s21
    s.or         s20, s19, s15
    s.lshri      s15, s16, #32
    v.extract    s19, v11, #11
    s.shli       s21, s17, #32
    s.shli       s17, s18, #32
    s.add        s18, s22, s20
    v.extract    s20, v18, #11
    v.insert     v9, s16, #9
    v.extract    s16, v12, #12
    v.insert     v10, s15, #9
    v.extract    s15, v19, #12
    s.or         s22, s19, s21
    s.or         s19, s20, s17
    s.lshri      s17, s18, #32
    v.extract    s20, v11, #12
    s.shli       s21, s16, #32
    s.shli       s16, s15, #32
    s.add        s15, s22, s19
    v.extract    s19, v18, #12
    v.insert     v9, s18, #10
    v.extract    s18, v12, #13
    v.insert     v10, s17, #10
    v.extract    s17, v19, #13
    s.or         s22, s20, s21
    s.or         s20, s19, s16
    s.lshri      s16, s15, #32
    v.extract    s19, v11, #13
    s.shli       s21, s18, #32
    s.shli       s18, s17, #32
    s.add        s17, s22, s20
    v.extract    s20, v18, #13
    v.insert     v9, s15, #11
    v.extract    s15, v12, #14
    v.insert     v10, s16, #11
    v.extract    s16, v19, #14
    s.or         s22, s19, s21
    s.or         s19, s20, s18
    s.lshri      s18, s17, #32
    v.extract    s20, v11, #14
    s.shli       s21, s15, #32
    s.shli       s15, s16, #32
    s.add        s16, s22, s19
    v.extract    s19, v18, #14
    v.insert     v9, s17, #12
    v.extract    s17, v12, #15
    v.insert     v10, s18, #12
    v.extract    s18, v19, #15
    s.or         s22, s20, s21
    v.extract    s20, v14, #0
    s.or         s21, s19, s15
    v.extract    s15, v21, #0
    s.shli       s19, s17, #32
    s.shli       s17, s18, #32
    s.shli       s18, s20, #32
    s.shli       s20, s15, #32
    s.add        s15, s22, s21
    s.lshri      s21, s16, #32
    v.insert     v9, s16, #13
    v.extract    s16, v11, #15
    v.insert     v10, s21, #13
    v.extract    s21, v18, #15
    s.or         s22, s16, s19
    v.extract    s16, v13, #0
    s.or         s19, s21, s17
    v.extract    s17, v20, #0
    s.or         s21, s16, s18
    v.extract    s16, v14, #1
    s.or         s18, s17, s20
    v.extract    s17, v21, #1
    s.shli       s20, s16, #32
    s.shli       s16, s17, #32
    s.add        s17, s22, s19
    s.lshri      s19, s15, #32
    s.add        s22, s21, s18
    v.extract    s18, v13, #1
    v.insert     v9, s15, #14
    v.extract    s15, v20, #1
    v.insert     v10, s19, #14
    v.extract    s19, v14, #2
    v.movi       v11, #0
    v.movi       v12, #0
    s.or         s21, s18, s20
    v.extract    s18, v21, #2
    s.or         s20, s15, s16
    s.lshri      s15, s17, #32
    s.shli       s16, s19, #32
    s.shli       s19, s18, #32
    s.add        s18, s21, s20
    s.lshri      s20, s22, #32
    v.insert     v9, s17, #15
    v.extract    s17, v13, #2
    v.insert     v10, s15, #15
    v.extract    s15, v20, #2
    v.insert     v11, s22, #0
    v.extract    s21, v14, #3
    v.insert     v12, s20, #0
    v.extract    s20, v21, #3
    s.or         s22, s17, s16
    s.or         s16, s15, s19
    s.lshri      s15, s18, #32
    v.extract    s17, v13, #3
    s.shli       s19, s21, #32
    s.shli       s21, s20, #32
    s.add        s20, s22, s16
    v.extract    s16, v20, #3
    v.insert     v11, s18, #1
    v.extract    s18, v14, #4
    v.insert     v12, s15, #1
    v.extract    s15, v21, #4
    s.or         s22, s17, s19
    s.or         s17, s16, s21
    s.lshri      s16, s20, #32
    v.extract    s19, v13, #4
    s.shli       s21, s18, #32
    s.shli       s18, s15, #32
    s.add        s15, s22, s17
    v.extract    s17, v20, #4
    v.insert     v11, s20, #2
    v.extract    s20, v14, #5
    v.insert     v12, s16, #2
    v.extract    s16, v21, #5
    s.or         s22, s19, s21
    s.or         s19, s17, s18
    s.lshri      s17, s15, #32
    v.extract    s18, v13, #5
    s.shli       s21, s20, #32
    s.shli       s20, s16, #32
    s.add        s16, s22, s19
    v.extract    s19, v20, #5
    v.insert     v11, s15, #3
    v.extract    s15, v14, #6
    v.insert     v12, s17, #3
    v.extract    s17, v21, #6
    s.or         s22, s18, s21
    s.or         s18, s19, s20
    s.lshri      s19, s16, #32
    v.extract    s20, v13, #6
    s.shli       s21, s15, #32
    s.shli       s15, s17, #32
    s.add        s17, s22, s18
    v.extract    s18, v20, #6
    v.insert     v11, s16, #4
    v.extract    s16, v14, #7
    v.insert     v12, s19, #4
    v.extract    s19, v21, #7
    s.or         s22, s20, s21
    s.or         s20, s18, s15
    s.lshri      s15, s17, #32
    v.extract    s18, v13, #7
    s.shli       s21, s16, #32
    s.shli       s16, s19, #32
    s.add        s19, s22, s20
    v.extract    s20, v20, #7
    v.insert     v11, s17, #5
    v.extract    s17, v14, #8
    v.insert     v12, s15, #5
    v.extract    s15, v21, #8
    s.or         s22, s18, s21
    s.or         s18, s20, s16
    s.lshri      s16, s19, #32
    v.extract    s20, v13, #8
    s.shli       s21, s17, #32
    s.shli       s17, s15, #32
    s.add        s15, s22, s18
    v.extract    s18, v20, #8
    v.insert     v11, s19, #6
    v.extract    s19, v14, #9
    v.insert     v12, s16, #6
    v.extract    s16, v21, #9
    s.or         s22, s20, s21
    s.or         s20, s18, s17
    s.lshri      s17, s15, #32
    v.extract    s18, v13, #9
    s.shli       s21, s19, #32
    s.shli       s19, s16, #32
    s.add        s16, s22, s20
    v.extract    s20, v20, #9
    v.insert     v11, s15, #7
    v.extract    s15, v14, #10
    v.insert     v12, s17, #7
    v.extract    s17, v21, #10
    s.or         s22, s18, s21
    s.or         s18, s20, s19
    s.lshri      s19, s16, #32
    v.extract    s20, v13, #10
    s.shli       s21, s15, #32
    s.shli       s15, s17, #32
    s.add        s17, s22, s18
    v.extract    s18, v20, #10
    v.insert     v11, s16, #8
    v.extract    s16, v14, #11
    v.insert     v12, s19, #8
    v.extract    s19, v21, #11
    s.or         s22, s20, s21
    s.or         s20, s18, s15
    s.lshri      s15, s17, #32
    v.extract    s18, v13, #11
    s.shli       s21, s16, #32
    s.shli       s16, s19, #32
    s.add        s19, s22, s20
    v.extract    s20, v20, #11
    v.insert     v11, s17, #9
    v.extract    s17, v14, #12
    v.insert     v12, s15, #9
    v.extract    s15, v21, #12
    s.or         s22, s18, s21
    s.or         s18, s20, s16
    s.lshri      s16, s19, #32
    v.extract    s20, v13, #12
    s.shli       s21, s17, #32
    s.shli       s17, s15, #32
    s.add        s15, s22, s18
    v.extract    s18, v20, #12
    v.insert     v11, s19, #10
    v.extract    s19, v14, #13
    v.insert     v12, s16, #10
    v.extract    s16, v21, #13
    s.or         s22, s20, s21
    s.or         s20, s18, s17
    s.lshri      s17, s15, #32
    v.extract    s18, v13, #13
    s.shli       s21, s19, #32
    s.shli       s19, s16, #32
    s.add        s16, s22, s20
    v.extract    s20, v20, #13
    v.insert     v11, s15, #11
    v.extract    s15, v14, #14
    v.insert     v12, s17, #11
    v.movi       v18, #31
    v.extract    s17, v21, #14
    s.or         s22, s18, s21
    s.or         s18, s20, s19
    s.lshri      s19, s16, #32
    v.extract    s20, v13, #14
    s.shli       s21, s15, #32
    s.shli       s15, s17, #32
    v.ashr       v19, v9, v18
    s.add        s17, s22, s18
    v.extract    s18, v20, #14
    v.movi       v18, #1
    v.movi       v22, #0
    v.insert     v11, s16, #12
    v.extract    s16, v14, #15
    v.insert     v12, s19, #12
    v.extract    s19, v21, #15
    s.or         s22, s20, s21
    s.or         s20, s18, s15
    s.lshri      s15, s17, #32
    v.extract    s18, v13, #15
    s.shli       s21, s16, #32
    s.shli       s16, s19, #32
    v.cmp.ne     p1, v10, v19
    s.add        s19, s22, s20
    v.extract    s20, v20, #15
    @p1 v.sel        v10, v18, v22
    v.insert     v11, s17, #13
    v.insert     v12, s15, #13
    s.or         s15, s18, s21
    s.or         s17, s20, s16
    s.lshri      s16, s19, #32
    s.add        s18, s15, s17
    v.reduce.or  s15, v10
    s.movz       s17, #0
    v.insert     v11, s19, #14
    v.insert     v12, s16, #14
    s.lshri      s16, s18, #32
    s.cmp.eq     s19, s15, s17
    v.insert     v11, s18, #15
    v.insert     v12, s16, #15
    br.nz        s19, narrow_ok_9
    trap         #677220
narrow_ok_9:
    v.movi       v10, #31
    v.movi       v13, #1
    v.movi       v14, #0
    v.ashr       v18, v11, v10
    v.cmp.ne     p1, v12, v18
    @p1 v.sel        v10, v13, v14
    v.reduce.or  s15, v10
    s.cmp.eq     s16, s15, s17
    br.nz        s16, narrow_ok_10
    trap         #677220
narrow_ok_10:
    v.cmp.lt     p1, v1, v6
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v10, [s3, v9]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v6
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v9, [s3, v11]              // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v11, v10
    vf.cvt.f16.f32 v10, v9
    vf.add       v9, v11, v15
    vf.add       v11, v10, v16
    .li       s15, #1124073472
    v.splat      v10, s15                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v12, v10                        // ISA 8.8: <= 2**-22 relative
    .li       s15, #1065353216
    v.splat      v13, s15                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v14, v10, v12, v13
    vf.fms       v10, v12, v14, v12
    vf.neg       v13, v10                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v13, v13
    @p1 v.sel        v10, v13, v12
    vf.mul       v12, v0, v10                    // a/y as a refined reciprocal (ISA has no divide)
    .li       s15, #925353388
    v.splat      v10, s15                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v13, v12, v10
    v.rsqrt.approx v10, v13                      // ISA 8.8: <= 2**-22 relative
    vf.mul       v12, v10, v10
    .li       s15, #1077936128
    v.splat      v14, s15                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v15, v13, v12, v14
    .li       s15, #3204448256
    v.splat      v12, s15                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v13, v10, v12
    vf.mul       v12, v13, v15                   // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v12, v12
    @p1 v.sel        v13, v12, v10
    v.extract    s15, v13, #0
    v.splat      v10, s15
    vf.mul       v12, v9, v10
    vf.mul       v9, v11, v10
    vf.mul       v10, v12, v17
    vf.mul       v11, v9, v7
    s.mul        s15, s9, s7
    s.add        s16, s4, s15
    s.add        s17, s14, s15
    vf.cvt.f32.f16 v7, v10
    vf.cvt.f32.f16 v9, v11
    v.cmp.lt     p1, v1, v6
    s.shli       s14, s16, #1                    // element offset -> bytes (x2)
    s.add        s15, s13, s14                   // &out_ptr1[...]
    @p1 v.st.h       [s15, #0], v7
    v.cmp.lt     p1, v5, v6
    s.shli       s14, s17, #1                    // element offset -> bytes (x2)
    s.add        s15, s13, s14                   // &out_ptr1[...]
    @p1 v.st.h       [s15, #0], v9
    s.add        s4, s4, s8
    s.movz       s14, #1
    br.nz        s14, for_6
endfor_7:
__rctx_next:
    s.addi       s4, s9, #2                      // the next program of this context: + 2
    s.cmp.lt     s14, s4, s10
    s.mov        s9, s4
    br.nz        s14, __rctx_program
    exit
