    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, pid.y
    s.movz       s2, #16
    s.movz       s3, #0
    s.mul        s5, s1, s2
    s.rdspecial  s1, arg_base
    v.movi       v0, #0
    v.movi       v1, #0
    s.ld.d       s6, [s1, #80]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.add        s1, s3, s5                      // the tile origin
    s.rdspecial  s3, role_id
    s.addi       s7, s1, #1
    v.splat      v2, s1
    v.splat      v3, s7
    s.movz       s7, #15360
    v.sub        v4, v0, v2
    v.sub        v5, v1, v3
    v.cmp.lt     p1, v2, v0
    v.cmp.lt     p2, v3, v1
    @p1 v.sel        v6, v4, v2
    v.movi       v2, #63
    @p2 v.sel        v4, v5, v3
    s.mul        s8, s3, s7
    v.and        v3, v6, v2
    s.rdspecial  s3, arg_base
    s.mul        s7, s4, s2
    v.sub        v2, v0, v3
    s.add        s2, s6, s8                      // this context's own scratch
    s.ld.d       s4, [s3, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.addi       s6, s2, #0
    @p1 v.sel        v5, v2, v3
    s.addi       s8, s6, #64
    s.movz       s9, #64
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v2, s9
    v.movi       v3, #1
    v.movi       v3, #1
    v.sub        v3, v0, v2
    v.sub        v6, v1, v2
    s.ld.d       s9, [s3, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.movi       v7, #63
    v.cmp.lt     p1, v2, v0
    v.cmp.lt     p3, v2, v1
    @p1 v.sel        v0, v3, v2
    @p3 v.sel        v0, v6, v2
    s.ld.d       s10, [s3, #16]                  // in_ptr2: device_ptr64 at arg_base+16
    v.and        v0, v4, v7
    s.ld.d       s11, [s3, #24]                  // in_ptr3: device_ptr64 at arg_base+24
    v.sub        v3, v1, v0
    s.ld.d       s12, [s3, #32]                  // in_ptr4: device_ptr64 at arg_base+32
    @p2 v.sel        v1, v3, v0
    s.ld.d       s13, [s3, #40]                  // in_ptr5: device_ptr64 at arg_base+40
    s.ld.d       s14, [s3, #48]                  // out_ptr0: device_ptr64 at arg_base+48
    s.addi       s15, s6, #128
    s.ld.d       s16, [s3, #56]                  // out_ptr1: device_ptr64 at arg_base+56
    s.addi       s3, s1, #2
    s.addi       s17, s1, #3
    v.splat      v0, s3
    v.movi       v3, #0
    v.splat      v4, s17
    v.movi       v6, #0
    v.sub        v7, v3, v0
    v.cmp.lt     p1, v0, v3
    v.sub        v8, v6, v4
    v.cmp.lt     p2, v4, v6
    @p1 v.sel        v9, v7, v0
    v.movi       v0, #63
    @p2 v.sel        v7, v8, v4
    v.movi       v4, #63
    v.and        v8, v9, v0
    s.addi       s3, s6, #192
    v.and        v0, v7, v4
    v.sub        v4, v3, v8
    v.st.w       [s6, #0], v5
    s.addi       s17, s1, #4
    v.movi       v5, #0
    v.splat      v7, s17
    v.movi       v9, #63
    v.sub        v10, v6, v0
    v.sub        v11, v5, v7
    v.cmp.lt     p3, v7, v5
    @p1 v.sel        v12, v4, v8
    @p3 v.sel        v4, v11, v7
    @p2 v.sel        v7, v10, v0
    s.addi       s17, s6, #256
    v.and        v0, v4, v9
    v.sub        v4, v3, v2
    v.sub        v8, v6, v2
    v.sub        v9, v5, v0
    v.sub        v10, v5, v2
    v.cmp.lt     p1, v2, v3
    @p3 v.sel        v3, v9, v0
    v.st.w       [s8, #0], v1
    s.addi       s8, s1, #5
    v.movi       v0, #0
    v.splat      v1, s8
    s.addi       s8, s6, #320
    v.cmp.lt     p2, v2, v6
    v.cmp.lt     p3, v2, v5
    v.movi       v5, #1
    v.sub        v5, v0, v1
    v.cmp.lt     p4, v1, v0
    v.sub        v6, v0, v2
    @p4 v.sel        v9, v5, v1
    @p1 v.sel        v1, v4, v2
    v.movi       v1, #63
    v.cmp.lt     p1, v2, v0
    v.movi       v4, #1
    v.and        v4, v9, v1
    @p2 v.sel        v1, v8, v2
    v.st.w       [s15, #0], v12
    s.addi       s15, s1, #6
    v.movi       v1, #0
    v.splat      v5, s15
    v.movi       v8, #63
    v.sub        v9, v0, v4
    v.sub        v0, v1, v5
    v.cmp.lt     p2, v5, v1
    @p4 v.sel        v11, v9, v4
    @p2 v.sel        v4, v0, v5
    s.addi       s15, s6, #384
    v.sub        v0, v1, v2
    v.and        v5, v4, v8
    v.cmp.lt     p4, v2, v1
    v.movi       v4, #1
    v.sub        v4, v1, v5
    @p3 v.sel        v1, v10, v2
    v.movi       v1, #1
    @p2 v.sel        v1, v4, v5
    v.st.w       [s3, #0], v7
    s.addi       s3, s1, #7
    v.movi       v4, #0
    v.splat      v5, s3
    v.movi       v7, #63
    s.addi       s3, s6, #448
    v.sub        v8, v4, v5
    v.cmp.lt     p2, v5, v4
    v.sub        v9, v4, v2
    @p2 v.sel        v10, v8, v5
    v.cmp.lt     p3, v2, v4
    @p1 v.sel        v5, v6, v2
    v.and        v5, v10, v7
    v.movi       v6, #1
    @p4 v.sel        v6, v0, v2
    v.sub        v0, v4, v5
    v.movi       v4, #1
    @p3 v.sel        v4, v9, v2
    @p2 v.sel        v4, v0, v5
    v.st.w       [s17, #0], v3
    s.addi       s17, s1, #8
    v.movi       v0, #0
    v.splat      v3, s17
    v.movi       v5, #63
    s.addi       s17, s6, #512
    v.sub        v6, v0, v3
    v.cmp.lt     p1, v3, v0
    v.sub        v7, v0, v2
    @p1 v.sel        v8, v6, v3
    v.cmp.lt     p2, v2, v0
    v.movi       v3, #1
    v.and        v3, v8, v5
    @p2 v.sel        v5, v7, v2
    v.sub        v5, v0, v3
    @p1 v.sel        v0, v5, v3
    v.st.w       [s8, #0], v11
    s.addi       s8, s1, #9
    v.movi       v3, #0
    v.splat      v5, s8
    v.movi       v6, #63
    s.addi       s8, s6, #576
    v.sub        v7, v3, v5
    v.cmp.lt     p1, v5, v3
    v.sub        v8, v3, v2
    @p1 v.sel        v9, v7, v5
    v.cmp.lt     p2, v2, v3
    v.movi       v5, #1
    v.and        v5, v9, v6
    @p2 v.sel        v6, v8, v2
    v.sub        v6, v3, v5
    @p1 v.sel        v3, v6, v5
    v.st.w       [s15, #0], v1
    s.addi       s15, s1, #10
    v.movi       v1, #0
    v.splat      v5, s15
    v.movi       v6, #63
    s.addi       s15, s6, #640
    v.sub        v7, v1, v5
    v.cmp.lt     p1, v5, v1
    v.sub        v8, v1, v2
    @p1 v.sel        v9, v7, v5
    v.cmp.lt     p2, v2, v1
    v.movi       v5, #1
    v.and        v5, v9, v6
    @p2 v.sel        v6, v8, v2
    v.sub        v6, v1, v5
    @p1 v.sel        v1, v6, v5
    v.st.w       [s3, #0], v4
    s.addi       s3, s1, #11
    v.movi       v4, #0
    v.splat      v5, s3
    v.movi       v6, #63
    s.addi       s3, s6, #704
    v.sub        v7, v4, v5
    v.cmp.lt     p1, v5, v4
    v.sub        v8, v4, v2
    @p1 v.sel        v9, v7, v5
    v.cmp.lt     p2, v2, v4
    v.movi       v5, #1
    v.and        v5, v9, v6
    @p2 v.sel        v6, v8, v2
    v.sub        v6, v4, v5
    @p1 v.sel        v4, v6, v5
    v.st.w       [s17, #0], v0
    s.addi       s17, s1, #12
    v.movi       v0, #0
    v.splat      v5, s17
    v.movi       v6, #63
    s.addi       s17, s6, #768
    v.sub        v7, v0, v5
    v.cmp.lt     p1, v5, v0
    v.sub        v8, v0, v2
    @p1 v.sel        v9, v7, v5
    v.cmp.lt     p2, v2, v0
    v.movi       v5, #1
    v.and        v5, v9, v6
    @p2 v.sel        v6, v8, v2
    v.sub        v6, v0, v5
    @p1 v.sel        v0, v6, v5
    v.st.w       [s8, #0], v3
    s.addi       s8, s1, #13
    v.movi       v3, #0
    v.splat      v5, s8
    v.movi       v6, #63
    s.addi       s8, s6, #832
    v.sub        v7, v3, v5
    v.cmp.lt     p1, v5, v3
    v.sub        v8, v3, v2
    @p1 v.sel        v9, v7, v5
    v.cmp.lt     p2, v2, v3
    v.movi       v5, #1
    v.and        v5, v9, v6
    @p2 v.sel        v6, v8, v2
    v.sub        v6, v3, v5
    @p1 v.sel        v3, v6, v5
    v.st.w       [s15, #0], v1
    s.addi       s15, s1, #14
    v.movi       v1, #0
    v.splat      v5, s15
    v.movi       v6, #63
    s.addi       s15, s6, #896
    v.sub        v7, v1, v5
    v.cmp.lt     p1, v5, v1
    v.sub        v8, v1, v2
    @p1 v.sel        v9, v7, v5
    v.cmp.lt     p2, v2, v1
    v.movi       v5, #1
    v.and        v5, v9, v6
    @p2 v.sel        v6, v8, v2
    v.sub        v6, v1, v5
    @p1 v.sel        v1, v6, v5
    v.st.w       [s3, #0], v4
    s.addi       s3, s1, #15
    v.movi       v4, #0
    v.splat      v5, s3
    v.movi       v6, #63
    s.addi       s3, s6, #960
    v.sub        v7, v4, v5
    v.cmp.lt     p1, v5, v4
    v.sub        v8, v4, v2
    @p1 v.sel        v9, v7, v5
    v.cmp.lt     p2, v2, v4
    v.movi       v5, #1
    v.and        v5, v9, v6
    @p2 v.sel        v6, v8, v2
    v.sub        v6, v4, v5
    @p1 v.sel        v4, v6, v5
    v.st.w       [s17, #0], v0
    v.splat      v0, s1
    v.movi       v5, #0
    v.movi       v6, #6
    s.addi       s6, s2, #1024
    v.sub        v7, v5, v0
    v.cmp.lt     p1, v0, v5
    v.sub        v8, v5, v2
    @p1 v.sel        v9, v7, v0
    v.cmp.lt     p2, v2, v5
    v.movi       v0, #1
    v.lshr       v0, v9, v6
    @p2 v.sel        v6, v8, v2
    v.sub        v6, v5, v0
    @p1 v.sel        v5, v6, v0
    v.st.w       [s8, #0], v3
    s.addi       s8, s1, #1
    v.movi       v0, #0
    v.splat      v3, s8
    v.movi       v6, #6
    s.addi       s8, s6, #64
    v.sub        v7, v0, v3
    v.cmp.lt     p1, v3, v0
    v.sub        v8, v0, v2
    @p1 v.sel        v9, v7, v3
    v.cmp.lt     p2, v2, v0
    v.movi       v3, #1
    v.lshr       v3, v9, v6
    @p2 v.sel        v6, v8, v2
    v.sub        v6, v0, v3
    @p1 v.sel        v0, v6, v3
    v.st.w       [s15, #0], v1
    s.addi       s15, s1, #2
    v.movi       v1, #0
    v.splat      v3, s15
    v.movi       v6, #6
    s.addi       s15, s6, #128
    v.sub        v7, v1, v3
    v.cmp.lt     p1, v3, v1
    v.sub        v8, v1, v2
    @p1 v.sel        v9, v7, v3
    v.cmp.lt     p2, v2, v1
    v.movi       v3, #1
    v.lshr       v3, v9, v6
    @p2 v.sel        v6, v8, v2
    v.sub        v6, v1, v3
    @p1 v.sel        v1, v6, v3
    v.st.w       [s3, #0], v4
    fence.acq_rel.device
    s.addi       s3, s1, #3
    v.movi       v3, #0
    v.splat      v4, s3
    v.movi       v6, #6
    s.addi       s3, s6, #192
    v.sub        v7, v3, v4
    v.cmp.lt     p1, v4, v3
    v.sub        v8, v3, v2
    @p1 v.sel        v9, v7, v4
    v.cmp.lt     p2, v2, v3
    v.movi       v4, #1
    v.lshr       v4, v9, v6
    @p2 v.sel        v6, v8, v2
    v.sub        v6, v3, v4
    v.st.w       [s6, #0], v5
    s.addi       s17, s1, #4
    v.movi       v3, #0
    v.splat      v5, s17
    v.movi       v7, #6
    @p1 v.sel        v8, v6, v4
    v.sub        v4, v3, v5
    v.cmp.lt     p1, v5, v3
    s.addi       s17, s6, #256
    @p1 v.sel        v6, v4, v5
    v.sub        v4, v3, v2
    v.cmp.lt     p2, v2, v3
    v.lshr       v5, v6, v7
    v.movi       v6, #1
    @p2 v.sel        v6, v4, v2
    v.sub        v4, v3, v5
    @p1 v.sel        v3, v4, v5
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #5
    v.movi       v0, #0
    v.splat      v4, s8
    v.movi       v5, #6
    s.addi       s8, s6, #320
    v.sub        v6, v0, v4
    v.cmp.lt     p1, v4, v0
    v.sub        v7, v0, v2
    @p1 v.sel        v9, v6, v4
    v.cmp.lt     p2, v2, v0
    v.movi       v4, #1
    v.lshr       v4, v9, v5
    @p2 v.sel        v5, v7, v2
    v.sub        v5, v0, v4
    @p1 v.sel        v0, v5, v4
    v.st.w       [s15, #0], v1
    s.addi       s15, s1, #6
    v.movi       v1, #0
    v.splat      v4, s15
    v.movi       v5, #6
    s.addi       s15, s6, #384
    v.sub        v6, v1, v4
    v.cmp.lt     p1, v4, v1
    v.sub        v7, v1, v2
    @p1 v.sel        v9, v6, v4
    v.cmp.lt     p2, v2, v1
    v.movi       v4, #1
    v.lshr       v4, v9, v5
    @p2 v.sel        v5, v7, v2
    v.sub        v5, v1, v4
    @p1 v.sel        v1, v5, v4
    v.st.w       [s3, #0], v8
    s.addi       s3, s1, #7
    v.movi       v4, #0
    v.splat      v5, s3
    v.movi       v6, #6
    s.addi       s3, s6, #448
    v.sub        v7, v4, v5
    v.cmp.lt     p1, v5, v4
    v.sub        v8, v4, v2
    @p1 v.sel        v9, v7, v5
    v.cmp.lt     p2, v2, v4
    v.movi       v5, #1
    v.lshr       v5, v9, v6
    @p2 v.sel        v6, v8, v2
    v.sub        v6, v4, v5
    @p1 v.sel        v4, v6, v5
    v.st.w       [s17, #0], v3
    s.addi       s17, s1, #8
    v.movi       v3, #0
    v.splat      v5, s17
    v.movi       v6, #6
    s.addi       s17, s6, #512
    v.sub        v7, v3, v5
    v.cmp.lt     p1, v5, v3
    v.sub        v8, v3, v2
    @p1 v.sel        v9, v7, v5
    v.cmp.lt     p2, v2, v3
    v.movi       v5, #1
    v.lshr       v5, v9, v6
    @p2 v.sel        v6, v8, v2
    v.sub        v6, v3, v5
    @p1 v.sel        v3, v6, v5
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #9
    v.movi       v0, #0
    v.splat      v5, s8
    v.movi       v6, #6
    s.addi       s8, s6, #576
    v.sub        v7, v0, v5
    v.cmp.lt     p1, v5, v0
    v.sub        v8, v0, v2
    @p1 v.sel        v9, v7, v5
    v.cmp.lt     p2, v2, v0
    v.movi       v5, #1
    v.lshr       v5, v9, v6
    @p2 v.sel        v6, v8, v2
    v.sub        v6, v0, v5
    @p1 v.sel        v0, v6, v5
    v.st.w       [s15, #0], v1
    s.addi       s15, s1, #10
    v.movi       v1, #0
    v.splat      v5, s15
    v.movi       v6, #6
    s.addi       s15, s6, #640
    v.sub        v7, v1, v5
    v.cmp.lt     p1, v5, v1
    v.sub        v8, v1, v2
    @p1 v.sel        v9, v7, v5
    v.cmp.lt     p2, v2, v1
    v.movi       v5, #1
    v.lshr       v5, v9, v6
    @p2 v.sel        v6, v8, v2
    v.sub        v6, v1, v5
    @p1 v.sel        v1, v6, v5
    v.st.w       [s3, #0], v4
    s.addi       s3, s1, #11
    v.movi       v4, #0
    v.splat      v5, s3
    v.movi       v6, #6
    s.addi       s3, s6, #704
    v.sub        v7, v4, v5
    v.cmp.lt     p1, v5, v4
    v.sub        v8, v4, v2
    @p1 v.sel        v9, v7, v5
    v.cmp.lt     p2, v2, v4
    v.movi       v5, #1
    v.lshr       v5, v9, v6
    @p2 v.sel        v6, v8, v2
    v.sub        v6, v4, v5
    @p1 v.sel        v4, v6, v5
    v.st.w       [s17, #0], v3
    s.addi       s17, s1, #12
    v.movi       v3, #0
    v.splat      v5, s17
    v.movi       v6, #6
    s.addi       s17, s6, #768
    v.sub        v7, v3, v5
    v.cmp.lt     p1, v5, v3
    v.sub        v8, v3, v2
    @p1 v.sel        v9, v7, v5
    v.cmp.lt     p2, v2, v3
    v.movi       v5, #1
    v.lshr       v5, v9, v6
    @p2 v.sel        v6, v8, v2
    v.sub        v6, v3, v5
    @p1 v.sel        v3, v6, v5
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #13
    v.movi       v0, #0
    v.splat      v5, s8
    v.movi       v6, #6
    s.addi       s8, s6, #832
    v.sub        v7, v0, v5
    v.cmp.lt     p1, v5, v0
    v.sub        v8, v0, v2
    @p1 v.sel        v9, v7, v5
    v.cmp.lt     p2, v2, v0
    v.movi       v5, #1
    v.lshr       v5, v9, v6
    @p2 v.sel        v6, v8, v2
    v.sub        v6, v0, v5
    @p1 v.sel        v0, v6, v5
    v.st.w       [s15, #0], v1
    s.addi       s15, s1, #14
    v.movi       v1, #0
    v.splat      v5, s15
    v.movi       v6, #6
    s.addi       s15, s6, #896
    v.sub        v7, v1, v5
    v.cmp.lt     p1, v5, v1
    v.sub        v8, v1, v2
    @p1 v.sel        v9, v7, v5
    v.cmp.lt     p2, v2, v1
    v.movi       v5, #1
    v.lshr       v5, v9, v6
    @p2 v.sel        v6, v8, v2
    v.sub        v6, v1, v5
    @p1 v.sel        v1, v6, v5
    v.st.w       [s3, #0], v4
    s.addi       s3, s1, #15
    v.movi       v4, #0
    v.splat      v5, s3
    v.movi       v6, #6
    s.addi       s3, s6, #960
    v.sub        v7, v4, v5
    v.cmp.lt     p1, v5, v4
    v.sub        v8, v4, v2
    @p1 v.sel        v9, v7, v5
    v.cmp.lt     p2, v2, v4
    v.movi       v5, #1
    v.lshr       v5, v9, v6
    @p2 v.sel        v6, v8, v2
    v.sub        v6, v4, v5
    @p1 v.sel        v4, v6, v5
    v.st.w       [s17, #0], v3
    s.addi       s6, s2, #1024
    s.movz       s17, #0
    s.movz       s18, #32
    s.add        s19, s17, s7                    // the tile origin
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v5, s19
    v.splat      v6, s18
    s.movz       s17, #0
    v.add        v7, v3, v5
    v.splat      v3, s17
    s.addi       s19, s2, #2048
    v.st.w       [s8, #0], v0
    s.addi       s8, s2, #0
    s.movz       s20, #192
    s.addi       s21, s2, #1088
    v.splat      v0, s20
    s.addi       s20, s2, #64
    v.st.w       [s15, #0], v1
    s.addi       s15, s19, #64
    v.st.w       [s3, #0], v4
    fence.acq_rel.device
    s.addi       s3, s2, #1152
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s2, #128
    v.ld.w       v4, [s8, #0]
    v.mul        v5, v1, v6
    s.addi       s8, s19, #128
    v.add        v1, v7, v5
    v.mul        v5, v4, v0
    v.add        v4, v1, v5
    v.add        v1, v3, v4
    v.st.w       [s19, #0], v1
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s2, #1216
    v.ld.w       v4, [s20, #0]
    v.mul        v5, v1, v6
    s.addi       s20, s2, #192
    v.add        v1, v7, v5
    v.mul        v5, v4, v0
    v.add        v4, v1, v5
    v.add        v1, v3, v4
    v.st.w       [s15, #0], v1
    s.addi       s15, s19, #192
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s2, #1280
    v.ld.w       v4, [s6, #0]
    v.mul        v5, v1, v6
    s.addi       s6, s2, #256
    v.add        v1, v7, v5
    v.mul        v5, v4, v0
    v.add        v4, v1, v5
    v.add        v1, v3, v4
    v.st.w       [s8, #0], v1
    s.addi       s8, s19, #256
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s2, #1344
    v.ld.w       v4, [s20, #0]
    v.mul        v5, v1, v6
    s.addi       s20, s2, #320
    v.add        v1, v7, v5
    v.mul        v5, v4, v0
    v.add        v4, v1, v5
    v.add        v1, v3, v4
    v.st.w       [s15, #0], v1
    s.addi       s15, s19, #320
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s2, #1408
    v.ld.w       v4, [s6, #0]
    v.mul        v5, v1, v6
    s.addi       s6, s2, #384
    v.add        v1, v7, v5
    v.mul        v5, v4, v0
    v.add        v4, v1, v5
    v.add        v1, v3, v4
    v.st.w       [s8, #0], v1
    s.addi       s8, s19, #384
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s2, #1472
    v.ld.w       v4, [s20, #0]
    v.mul        v5, v1, v6
    s.addi       s20, s2, #448
    v.add        v1, v7, v5
    v.mul        v5, v4, v0
    v.add        v4, v1, v5
    v.add        v1, v3, v4
    v.st.w       [s15, #0], v1
    s.addi       s15, s19, #448
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s2, #1536
    v.ld.w       v4, [s6, #0]
    v.mul        v5, v1, v6
    s.addi       s6, s2, #512
    v.add        v1, v7, v5
    v.mul        v5, v4, v0
    v.add        v4, v1, v5
    v.add        v1, v3, v4
    v.st.w       [s8, #0], v1
    s.addi       s8, s19, #512
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s2, #1600
    v.ld.w       v4, [s20, #0]
    v.mul        v5, v1, v6
    s.addi       s20, s2, #576
    v.add        v1, v7, v5
    v.mul        v5, v4, v0
    v.add        v4, v1, v5
    v.add        v1, v3, v4
    v.st.w       [s15, #0], v1
    s.addi       s15, s19, #576
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s2, #1664
    v.ld.w       v4, [s6, #0]
    v.mul        v5, v1, v6
    s.addi       s6, s2, #640
    v.add        v1, v7, v5
    v.mul        v5, v4, v0
    v.add        v4, v1, v5
    v.add        v1, v3, v4
    v.st.w       [s8, #0], v1
    s.addi       s8, s19, #640
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s2, #1728
    v.ld.w       v4, [s20, #0]
    v.mul        v5, v1, v6
    s.addi       s20, s2, #704
    v.add        v1, v7, v5
    v.mul        v5, v4, v0
    v.add        v4, v1, v5
    v.add        v1, v3, v4
    v.st.w       [s15, #0], v1
    s.addi       s15, s19, #704
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s2, #1792
    v.ld.w       v4, [s6, #0]
    v.mul        v5, v1, v6
    s.addi       s6, s2, #768
    v.add        v1, v7, v5
    v.mul        v5, v4, v0
    v.add        v4, v1, v5
    v.add        v1, v3, v4
    v.st.w       [s8, #0], v1
    s.addi       s8, s19, #768
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s2, #1856
    v.ld.w       v4, [s20, #0]
    v.mul        v5, v1, v6
    s.addi       s20, s2, #832
    v.add        v1, v7, v5
    v.mul        v5, v4, v0
    v.add        v4, v1, v5
    v.add        v1, v3, v4
    v.st.w       [s15, #0], v1
    s.addi       s15, s19, #832
    v.splat      v1, s18
    s.addi       s18, s2, #1920
    v.cmp.lt     p1, v7, v1
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s2, #896
    v.splat      v4, s1
    v.ld.w       v5, [s6, #0]
    v.mul        v8, v1, v6
    s.addi       s6, s19, #896
    s.addi       s22, s19, #960
    v.add        v1, v7, v8
    v.mul        v8, v5, v0
    v.add        v5, v1, v8
    v.add        v1, v3, v5
    v.st.w       [s8, #0], v1
    s.addi       s8, s2, #1984
    v.ld.w       v1, [s21, #0]
    s.addi       s19, s2, #960
    v.ld.w       v5, [s20, #0]
    v.mul        v8, v1, v6
    s.addi       s20, s2, #2048
    v.add        v1, v7, v8
    v.mul        v8, v5, v0
    v.add        v5, v1, v8
    v.add        v1, v3, v5
    v.st.w       [s15, #0], v1
    s.movz       s15, #384
    v.splat      v1, s15
    s.addi       s15, s2, #3072
    v.cmp.lt     p2, v4, v1
    p.and        p3, p1, p2
    v.ld.w       v4, [s18, #0]
    s.addi       s18, s2, #2112
    v.ld.w       v5, [s3, #0]
    v.mul        v8, v4, v6
    s.addi       s3, s1, #1
    v.add        v4, v7, v8
    v.splat      v8, s3
    s.addi       s3, s15, #64
    v.cmp.lt     p2, v8, v1
    p.and        p4, p1, p2
    v.mul        v8, v5, v0
    v.add        v5, v4, v8
    v.add        v4, v3, v5
    v.st.w       [s6, #0], v4
    s.addi       s6, s2, #2176
    v.ld.w       v4, [s8, #0]
    s.addi       s8, s1, #2
    v.splat      v5, s8
    s.addi       s8, s15, #128
    v.cmp.lt     p2, v5, v1
    p.and        p5, p1, p2
    v.ld.w       v5, [s19, #0]
    v.mul        v8, v4, v6
    s.addi       s19, s2, #2240
    v.add        v4, v7, v8
    v.mul        v8, v5, v0
    v.add        v0, v4, v8
    v.add        v4, v3, v0
    v.st.w       [s22, #0], v4
    fence.acq_rel.device
    s.addi       s21, s1, #3
    v.splat      v0, s21
    s.addi       s21, s15, #192
    v.ld.w       v3, [s20, #0]
    s.addi       s20, s2, #2304
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v4, [s4, v3]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    v.st.w       [s15, #0], v4
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s1, #4
    v.splat      v3, s18
    s.addi       s18, s15, #256
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v4, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    v.st.w       [s3, #0], v4
    s.addi       s3, s2, #2368
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s1, #5
    v.splat      v3, s6
    s.addi       s6, s15, #320
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v4, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p5, p1, p2
    v.st.w       [s8, #0], v4
    s.addi       s8, s2, #2432
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s1, #6
    v.splat      v3, s19
    s.addi       s19, s15, #384
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v4, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p3, p1, p2
    v.st.w       [s21, #0], v4
    s.addi       s21, s2, #2496
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s1, #7
    v.splat      v3, s20
    s.addi       s20, s15, #448
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v4, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    v.st.w       [s18, #0], v4
    s.addi       s18, s2, #2560
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s1, #8
    v.splat      v3, s3
    s.addi       s3, s15, #512
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v4, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p5, p1, p2
    v.st.w       [s6, #0], v4
    s.addi       s6, s2, #2624
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #9
    v.splat      v3, s8
    s.addi       s8, s15, #576
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v4, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p3, p1, p2
    v.st.w       [s19, #0], v4
    s.addi       s19, s2, #2688
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s1, #10
    v.splat      v3, s21
    s.addi       s21, s15, #640
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v4, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    v.st.w       [s20, #0], v4
    s.addi       s20, s2, #2752
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s1, #11
    v.splat      v3, s18
    s.addi       s18, s15, #704
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v4, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p5, p1, p2
    v.st.w       [s3, #0], v4
    s.addi       s3, s2, #2816
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s1, #12
    v.splat      v3, s6
    s.addi       s6, s15, #768
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v4, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p3, p1, p2
    v.st.w       [s8, #0], v4
    s.addi       s8, s2, #2880
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s1, #13
    v.splat      v3, s19
    s.addi       s19, s15, #832
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v4, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    v.st.w       [s21, #0], v4
    s.addi       s21, s2, #2944
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s1, #14
    v.splat      v3, s20
    s.addi       s20, s15, #896
    s.addi       s22, s15, #960
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v4, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p5, p1, p2
    v.st.w       [s18, #0], v4
    s.addi       s15, s2, #3008
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s1, #15
    v.splat      v3, s3
    s.addi       s3, s2, #0
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v4, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p3, p1, p2
    v.st.w       [s6, #0], v4
    s.addi       s6, s2, #4096
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s2, #64
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v3, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s19, #0], v3
    s.addi       s18, s6, #64
    v.ld.w       v0, [s21, #0]
    s.addi       s19, s2, #128
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v3, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s20, #0], v3
    s.addi       s20, s6, #128
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s2, #192
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v3, [s4, v0]               // index is in elements (ISA sec 9.1)
    s.addi       s4, s6, #192
    v.st.w       [s22, #0], v3
    fence.acq_rel.device
    s.addi       s21, s2, #256
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s6, #256
    v.mul        v3, v0, v6
    v.add        v0, v7, v3
    v.st.w       [s6, #0], v0
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s2, #320
    v.mul        v3, v0, v6
    v.add        v0, v7, v3
    v.st.w       [s18, #0], v0
    s.addi       s18, s6, #320
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s2, #384
    v.mul        v3, v0, v6
    v.add        v0, v7, v3
    v.st.w       [s20, #0], v0
    s.addi       s20, s6, #384
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s2, #448
    v.mul        v3, v0, v6
    v.add        v0, v7, v3
    v.st.w       [s4, #0], v0
    s.addi       s4, s6, #448
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s2, #512
    v.mul        v3, v0, v6
    v.add        v0, v7, v3
    v.st.w       [s3, #0], v0
    s.addi       s3, s6, #512
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s2, #576
    v.mul        v3, v0, v6
    v.add        v0, v7, v3
    v.st.w       [s18, #0], v0
    s.addi       s18, s6, #576
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s2, #640
    v.mul        v3, v0, v6
    v.add        v0, v7, v3
    v.st.w       [s20, #0], v0
    s.addi       s20, s6, #640
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s2, #704
    v.mul        v3, v0, v6
    v.add        v0, v7, v3
    v.st.w       [s4, #0], v0
    s.addi       s4, s6, #704
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s2, #768
    v.splat      v3, s17
    v.mul        v4, v0, v6
    v.add        v0, v7, v4
    v.st.w       [s3, #0], v0
    s.addi       s3, s6, #768
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s2, #832
    v.mul        v4, v0, v6
    v.add        v0, v7, v4
    v.st.w       [s18, #0], v0
    s.addi       s18, s6, #832
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s2, #896
    v.mul        v4, v0, v6
    v.add        v0, v7, v4
    v.st.w       [s20, #0], v0
    s.addi       s20, s6, #896
    s.addi       s22, s6, #960
    v.ld.w       v0, [s15, #0]
    s.addi       s6, s2, #960
    v.mul        v4, v0, v6
    v.add        v0, v7, v4
    v.st.w       [s4, #0], v0
    s.addi       s4, s2, #4096
    v.ld.w       v0, [s21, #0]
    s.addi       s15, s2, #5120
    v.mul        v4, v0, v6
    v.add        v0, v7, v4
    v.st.w       [s3, #0], v0
    s.addi       s3, s2, #4160
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s15, #64
    v.mul        v4, v0, v6
    v.add        v0, v7, v4
    v.st.w       [s18, #0], v0
    s.addi       s18, s2, #4224
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s15, #128
    v.mul        v4, v0, v6
    v.add        v0, v7, v4
    v.st.w       [s20, #0], v0
    s.addi       s20, s2, #4288
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s15, #192
    v.mul        v4, v0, v6
    v.add        v0, v7, v4
    v.st.w       [s22, #0], v0
    fence.acq_rel.device
    s.addi       s21, s2, #4352
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s15, #256
    v.add        v4, v3, v0
    v.st.w       [s15, #0], v4
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s2, #4416
    v.add        v4, v3, v0
    v.st.w       [s8, #0], v4
    s.addi       s8, s15, #320
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s2, #4480
    v.add        v4, v3, v0
    v.st.w       [s19, #0], v4
    s.addi       s19, s15, #384
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s2, #4544
    v.add        v4, v3, v0
    v.st.w       [s6, #0], v4
    s.addi       s6, s15, #448
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s2, #4608
    v.add        v4, v3, v0
    v.st.w       [s4, #0], v4
    s.addi       s4, s15, #512
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s2, #4672
    v.add        v4, v3, v0
    v.st.w       [s8, #0], v4
    s.addi       s8, s15, #576
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s2, #4736
    v.add        v4, v3, v0
    v.st.w       [s19, #0], v4
    s.addi       s19, s15, #640
    v.splat      v0, s1
    v.ld.w       v4, [s20, #0]
    s.addi       s20, s2, #4800
    v.cmp.lt     p2, v0, v1
    v.add        v0, v3, v4
    p.and        p3, p1, p2
    v.st.w       [s6, #0], v0
    s.addi       s6, s15, #704
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s2, #4864
    v.add        v4, v3, v0
    v.st.w       [s4, #0], v4
    s.addi       s4, s15, #768
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s2, #4928
    v.add        v4, v3, v0
    v.st.w       [s8, #0], v4
    s.addi       s8, s15, #832
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s2, #4992
    v.add        v4, v3, v0
    v.st.w       [s19, #0], v4
    s.addi       s19, s15, #896
    s.addi       s22, s15, #960
    v.ld.w       v0, [s20, #0]
    s.addi       s15, s2, #5056
    v.add        v4, v3, v0
    v.st.w       [s6, #0], v4
    s.addi       s6, s2, #5120
    v.ld.w       v0, [s21, #0]
    s.addi       s20, s2, #6144
    v.add        v4, v3, v0
    v.st.w       [s4, #0], v4
    s.addi       s4, s2, #5184
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s1, #1
    v.splat      v4, s3
    s.addi       s3, s20, #64
    v.cmp.lt     p2, v4, v1
    p.and        p4, p1, p2
    v.add        v4, v3, v0
    v.st.w       [s8, #0], v4
    s.addi       s8, s2, #5248
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s1, #2
    v.splat      v4, s18
    s.addi       s18, s20, #128
    v.cmp.lt     p2, v4, v1
    p.and        p5, p1, p2
    v.add        v4, v3, v0
    v.st.w       [s19, #0], v4
    s.addi       s19, s2, #5312
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s1, #3
    v.splat      v4, s15
    s.addi       s15, s20, #192
    v.add        v5, v3, v0
    v.st.w       [s22, #0], v5
    fence.acq_rel.device
    s.addi       s21, s2, #5376
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s1, #4
    v.splat      v3, s6
    s.addi       s6, s20, #256
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v1
    p.and        p3, p1, p2
    v.st.w       [s20, #0], v5
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s2, #5440
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v4, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    v.st.w       [s3, #0], v4
    s.addi       s3, s1, #5
    v.splat      v0, s3
    s.addi       s3, s20, #320
    v.ld.w       v3, [s8, #0]
    s.addi       s8, s2, #5504
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v4, [s9, v3]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p5, p1, p2
    v.st.w       [s18, #0], v4
    s.addi       s18, s1, #6
    v.splat      v0, s18
    s.addi       s18, s20, #384
    v.ld.w       v3, [s19, #0]
    s.addi       s19, s2, #5568
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v4, [s9, v3]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    v.st.w       [s15, #0], v4
    s.addi       s15, s1, #7
    v.splat      v0, s15
    s.addi       s15, s20, #448
    v.ld.w       v3, [s21, #0]
    s.addi       s21, s2, #5632
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v4, [s9, v3]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p4, p1, p2
    v.st.w       [s6, #0], v4
    s.addi       s6, s1, #8
    v.splat      v0, s6
    s.addi       s6, s20, #512
    v.ld.w       v3, [s4, #0]
    s.addi       s4, s2, #5696
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v4, [s9, v3]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p5, p1, p2
    v.st.w       [s3, #0], v4
    s.addi       s3, s1, #9
    v.splat      v0, s3
    s.addi       s3, s20, #576
    v.ld.w       v3, [s8, #0]
    s.addi       s8, s2, #5760
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v4, [s9, v3]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    v.st.w       [s18, #0], v4
    s.addi       s18, s1, #10
    v.splat      v0, s18
    s.addi       s18, s20, #640
    v.ld.w       v3, [s19, #0]
    s.addi       s19, s2, #5824
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v4, [s9, v3]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p4, p1, p2
    v.st.w       [s15, #0], v4
    s.addi       s15, s1, #11
    v.splat      v0, s15
    s.addi       s15, s20, #704
    v.ld.w       v3, [s21, #0]
    s.addi       s21, s2, #5888
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v4, [s9, v3]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p5, p1, p2
    v.st.w       [s6, #0], v4
    s.addi       s6, s1, #12
    v.splat      v0, s6
    s.addi       s6, s20, #768
    v.ld.w       v3, [s4, #0]
    s.addi       s4, s2, #5952
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v4, [s9, v3]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    v.st.w       [s3, #0], v4
    s.addi       s3, s1, #13
    v.splat      v0, s3
    s.addi       s3, s20, #832
    v.ld.w       v3, [s8, #0]
    s.addi       s8, s2, #6016
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v4, [s9, v3]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p4, p1, p2
    v.st.w       [s18, #0], v4
    s.addi       s18, s1, #14
    v.splat      v0, s18
    s.addi       s18, s20, #896
    s.addi       s22, s20, #960
    v.ld.w       v3, [s19, #0]
    s.addi       s19, s2, #6080
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v4, [s9, v3]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p5, p1, p2
    v.st.w       [s15, #0], v4
    s.addi       s15, s1, #15
    v.splat      v0, s15
    s.addi       s15, s2, #6144
    v.ld.w       v3, [s21, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s20, #0
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v4, [s9, v3]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    v.st.w       [s6, #0], v4
    s.addi       s6, s2, #6208
    v.ld.w       v0, [s4, #0]
    s.movz       s4, #1
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v3, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v3
    s.addi       s3, s2, #6272
    v.ld.w       v0, [s8, #0]
    s.movz       s8, #2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v3, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s18, #0], v3
    s.addi       s18, s2, #6336
    v.ld.w       v0, [s19, #0]
    s.movz       s19, #3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v3, [s9, v0]               // index is in elements (ISA sec 9.1)
    s.addi       s9, s2, #6400
    v.st.w       [s22, #0], v3
    fence.acq_rel.device
    s.movz       s21, #4
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s2, #6464
    vf.cvt.f16.f32 v3, v0
    a.vwrite     a0, s20, v3
    v.ld.w       v0, [s6, #0]
    s.movz       s6, #5
    s.addi       s20, s2, #6528
    vf.cvt.f16.f32 v3, v0
    a.vwrite     a0, s4, v3
    v.ld.w       v0, [s3, #0]
    s.movz       s3, #6
    s.addi       s4, s2, #6592
    vf.cvt.f16.f32 v3, v0
    a.vwrite     a0, s8, v3
    v.ld.w       v0, [s18, #0]
    s.movz       s8, #7
    s.addi       s18, s2, #6656
    vf.cvt.f16.f32 v3, v0
    a.vwrite     a0, s19, v3
    v.ld.w       v0, [s9, #0]
    s.movz       s9, #8
    s.addi       s19, s2, #6720
    vf.cvt.f16.f32 v3, v0
    a.vwrite     a0, s21, v3
    v.ld.w       v0, [s15, #0]
    s.movz       s15, #9
    s.addi       s21, s2, #6784
    vf.cvt.f16.f32 v3, v0
    a.vwrite     a0, s6, v3
    v.ld.w       v0, [s20, #0]
    s.movz       s6, #10
    s.addi       s20, s2, #6848
    vf.cvt.f16.f32 v3, v0
    a.vwrite     a0, s3, v3
    v.ld.w       v0, [s4, #0]
    s.movz       s3, #11
    s.addi       s4, s2, #6912
    v.splat      v3, s17
    vf.cvt.f16.f32 v4, v0
    a.vwrite     a0, s8, v4
    v.ld.w       v0, [s18, #0]
    s.movz       s8, #12
    s.addi       s18, s2, #6976
    vf.cvt.f16.f32 v4, v0
    a.vwrite     a0, s9, v4
    v.ld.w       v0, [s19, #0]
    s.movz       s9, #13
    s.addi       s19, s2, #7040
    vf.cvt.f16.f32 v4, v0
    a.vwrite     a0, s15, v4
    v.ld.w       v0, [s21, #0]
    s.movz       s15, #14
    s.addi       s21, s2, #7104
    vf.cvt.f16.f32 v4, v0
    a.vwrite     a0, s6, v4
    v.ld.w       v0, [s20, #0]
    s.movz       s6, #15
    s.addi       s20, s2, #4096
    vf.cvt.f16.f32 v4, v0
    a.vwrite     a0, s3, v4
    v.ld.w       v0, [s4, #0]
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.addi       s3, s2, #7168
    s.addi       s4, s2, #4160
    vf.cvt.f16.f32 v4, v0
    a.vwrite     a0, s8, v4
    v.ld.w       v0, [s18, #0]
    s.addi       s8, s3, #64
    s.addi       s18, s2, #4224
    vf.cvt.f16.f32 v4, v0
    a.vwrite     a0, s9, v4
    v.ld.w       v0, [s19, #0]
    s.addi       s9, s3, #128
    s.addi       s19, s2, #4288
    vf.cvt.f16.f32 v4, v0
    a.vwrite     a0, s15, v4
    v.ld.w       v0, [s21, #0]
    s.addi       s15, s3, #192
    s.addi       s21, s2, #4352
    vf.cvt.f16.f32 v4, v0
    a.vwrite     a0, s6, v4
    v.ld.w       v0, [s20, #0]
    s.addi       s6, s3, #256
    s.addi       s20, s2, #4416
    v.add        v4, v3, v0
    v.st.w       [s3, #0], v4
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s3, #320
    v.add        v4, v3, v0
    v.st.w       [s8, #0], v4
    s.addi       s8, s2, #4480
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s3, #384
    v.add        v4, v3, v0
    v.st.w       [s9, #0], v4
    s.addi       s9, s2, #4544
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s3, #448
    v.add        v4, v3, v0
    v.st.w       [s15, #0], v4
    s.addi       s15, s2, #4608
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s3, #512
    v.add        v4, v3, v0
    v.st.w       [s6, #0], v4
    s.muli       s6, s7, #2                      // a runtime tile origin, x2
    s.add        s22, s10, s6                    // the tile origin
    s.muli       s6, s5, #64                     // a runtime tile origin, x64
    s.add        s10, s22, s6                    // the tile origin
    s.addi       s6, s2, #4672
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s3, #576
    v.add        v4, v3, v0
    v.st.w       [s4, #0], v4
    s.addi       s4, s2, #4736
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s3, #640
    v.add        v4, v3, v0
    v.st.w       [s18, #0], v4
    s.addi       s18, s2, #4800
    v.splat      v0, s1
    v.ld.w       v4, [s9, #0]
    s.addi       s9, s3, #704
    v.cmp.lt     p2, v0, v1
    v.add        v0, v3, v4
    p.and        p3, p1, p2
    v.st.w       [s19, #0], v0
    s.addi       s19, s2, #4864
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s3, #768
    v.add        v4, v3, v0
    v.st.w       [s21, #0], v4
    s.addi       s21, s2, #4928
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s3, #832
    v.add        v4, v3, v0
    v.st.w       [s20, #0], v4
    s.addi       s20, s2, #4992
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s3, #896
    s.addi       s22, s3, #960
    v.add        v4, v3, v0
    v.st.w       [s8, #0], v4
    s.addi       s3, s2, #5056
    v.ld.w       v0, [s18, #0]
    s.addi       s8, s2, #7168
    v.add        v4, v3, v0
    v.st.w       [s9, #0], v4
    s.addi       s9, s2, #8192
    v.ld.w       v0, [s19, #0]
    s.addi       s18, s2, #7232
    v.add        v4, v3, v0
    v.st.w       [s15, #0], v4
    s.addi       s15, s1, #1
    v.splat      v0, s15
    s.addi       s15, s9, #64
    v.cmp.lt     p2, v0, v1
    p.and        p4, p1, p2
    v.ld.w       v0, [s21, #0]
    s.addi       s19, s2, #7296
    v.add        v4, v3, v0
    v.st.w       [s6, #0], v4
    s.addi       s6, s1, #2
    v.splat      v0, s6
    s.addi       s6, s9, #128
    v.cmp.lt     p2, v0, v1
    p.and        p5, p1, p2
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s2, #7360
    v.add        v4, v3, v0
    v.st.w       [s4, #0], v4
    s.addi       s4, s1, #3
    v.splat      v0, s4
    s.addi       s4, s9, #192
    v.ld.w       v4, [s3, #0]
    s.addi       s3, s2, #7424
    v.add        v5, v3, v4
    v.st.w       [s22, #0], v5
    fence.acq_rel.device
    s.addi       s21, s1, #4
    v.splat      v3, s21
    s.addi       s21, s9, #256
    v.ld.w       v4, [s8, #0]
    s.addi       s8, s2, #7488
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s11, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    v.st.w       [s9, #0], v5
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s1, #5
    v.splat      v4, s18
    s.addi       s18, s9, #320
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s11, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    v.st.w       [s15, #0], v5
    s.addi       s15, s2, #7552
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s1, #6
    v.splat      v3, s19
    s.addi       s19, s9, #384
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v5, [s11, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v1
    p.and        p5, p1, p2
    v.st.w       [s6, #0], v5
    s.addi       s6, s2, #7616
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s1, #7
    v.splat      v4, s20
    s.addi       s20, s9, #448
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s11, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p3, p1, p2
    v.st.w       [s4, #0], v5
    s.addi       s4, s2, #7680
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s1, #8
    v.splat      v3, s3
    s.addi       s3, s9, #512
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s11, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v1
    p.and        p4, p1, p2
    v.st.w       [s21, #0], v5
    s.addi       s21, s2, #7744
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #9
    v.splat      v4, s8
    s.addi       s8, s9, #576
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v5, [s11, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p5, p1, p2
    v.st.w       [s18, #0], v5
    s.addi       s18, s2, #7808
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s1, #10
    v.splat      v3, s15
    s.addi       s15, s9, #640
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s11, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v1
    p.and        p3, p1, p2
    v.st.w       [s19, #0], v5
    s.addi       s19, s2, #7872
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s1, #11
    v.splat      v4, s6
    s.addi       s6, s9, #704
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s11, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    v.st.w       [s20, #0], v5
    s.addi       s20, s2, #7936
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s1, #12
    v.splat      v3, s4
    s.addi       s4, s9, #768
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v5, [s11, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v1
    p.and        p5, p1, p2
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #8000
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s1, #13
    v.splat      v4, s21
    s.addi       s21, s9, #832
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s11, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p3, p1, p2
    v.st.w       [s8, #0], v5
    s.addi       s8, s2, #8064
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s1, #14
    v.splat      v3, s18
    s.addi       s18, s9, #896
    s.addi       s22, s9, #960
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s11, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v1
    p.and        p4, p1, p2
    v.st.w       [s15, #0], v5
    s.addi       s9, s2, #8128
    v.ld.w       v0, [s19, #0]
    s.addi       s15, s1, #15
    v.splat      v4, s15
    s.addi       s15, s2, #8192
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v5, [s11, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p5, p1, p2
    v.st.w       [s6, #0], v5
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s6, #0
    v.ld.w       v0, [s20, #0]
    s.addi       s19, s2, #8256
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v3, [s11, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v1
    p.and        p3, p1, p2
    v.st.w       [s4, #0], v3
    s.movz       s4, #1
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s2, #8320
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v3, [s11, v0]              // index is in elements (ISA sec 9.1)
    v.st.w       [s21, #0], v3
    s.movz       s20, #2
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s2, #8384
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v3, [s11, v0]              // index is in elements (ISA sec 9.1)
    v.st.w       [s18, #0], v3
    s.movz       s18, #3
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s2, #8448
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v3, [s11, v0]              // index is in elements (ISA sec 9.1)
    s.movz       s11, #4
    v.st.w       [s22, #0], v3
    fence.acq_rel.device
    s.addi       s21, s2, #8512
    v.ld.w       v0, [s15, #0]
    s.movz       s15, #5
    vf.cvt.f16.f32 v3, v0
    a.vwrite     a1, s6, v3
    v.ld.w       v0, [s19, #0]
    s.addi       s6, s2, #8576
    s.movz       s19, #6
    vf.cvt.f16.f32 v3, v0
    a.vwrite     a1, s4, v3
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s2, #8640
    s.movz       s4, #7
    vf.cvt.f16.f32 v3, v0
    a.vwrite     a1, s20, v3
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s2, #8704
    s.movz       s20, #8
    vf.cvt.f16.f32 v3, v0
    a.vwrite     a1, s18, v3
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s2, #8768
    s.movz       s18, #9
    vf.cvt.f16.f32 v3, v0
    a.vwrite     a1, s11, v3
    v.ld.w       v0, [s21, #0]
    s.addi       s11, s2, #8832
    s.movz       s21, #10
    vf.cvt.f16.f32 v3, v0
    a.vwrite     a1, s15, v3
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s2, #8896
    s.movz       s15, #11
    vf.cvt.f16.f32 v3, v0
    a.vwrite     a1, s19, v3
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s2, #8960
    s.movz       s19, #12
    v.movi       v3, #0
    vf.cvt.f16.f32 v4, v0
    v.movi       v0, #1
    a.vwrite     a1, s4, v4
    v.ld.w       v4, [s8, #0]
    s.addi       s4, s2, #9024
    s.movz       s8, #13
    vf.cvt.f16.f32 v5, v4
    a.vwrite     a1, s20, v5
    v.ld.w       v4, [s9, #0]
    s.addi       s9, s2, #9088
    s.movz       s20, #14
    v.movi       v5, #0
    v.movi       v8, #0
    vf.cvt.f16.f32 v9, v4
    a.vwrite     a1, s18, v9
    v.ld.w       v4, [s11, #0]
    s.addi       s11, s2, #9152
    s.movz       s18, #15
    vf.cvt.f16.f32 v9, v4
    a.vwrite     a1, s21, v9
    v.ld.w       v4, [s6, #0]
    s.addi       s6, s2, #1024
    s.movz       s21, #3
    v.splat      v9, s21
    s.addi       s21, s2, #9216
    v.sub        v10, v3, v9
    v.cmp.lt     p2, v9, v3
    @p2 v.sel        v11, v10, v9
    vf.cvt.f16.f32 v10, v4
    a.vwrite     a1, s15, v10
    v.ld.w       v4, [s3, #0]
    s.movz       s3, #31
    vf.cvt.f16.f32 v10, v4
    a.vwrite     a1, s19, v10
    v.ld.w       v4, [s4, #0]
    vf.cvt.f16.f32 v10, v4
    a.vwrite     a1, s8, v10
    v.ld.w       v4, [s9, #0]
    vf.cvt.f16.f32 v10, v4
    a.vwrite     a1, s20, v10
    v.ld.w       v4, [s11, #0]
    vf.cvt.f16.f32 v10, v4
    a.vwrite     a1, s18, v10
    v.ld.w       v4, [s6, #0]
    v.sub        v10, v3, v4
    v.cmp.lt     p3, v4, v3
    @p3 v.sel        v12, v10, v4
idiv_1:
    v.splat      v4, s3
    v.shl        v10, v8, v0
    v.cmp.lt     p4, v8, v3
    v.lshr       v13, v12, v4
    v.shl        v14, v0, v4
    s.subi       s4, s3, #1
    v.and        v4, v13, v0
    s.movz       s6, #0
    v.or         v13, v10, v4
    v.cmp.geu    p5, v13, v11
    p.or         p6, p4, p5
    v.sub        v4, v13, v11
    @p6 v.sel        v10, v14, v3
    @p6 v.sel        v14, v4, v13
    v.or         v4, v5, v10
    v.mov        v8, v14
    v.mov        v5, v4
    s.mov        s3, s4
    s.cmp.ge     s4, s3, s6
    br.nz        s4, idiv_1
    v.sub        v0, v3, v5
    p.xor        p4, p3, p2
    s.addi       s3, s2, #1088
    @p4 v.sel        v3, v0, v5
    v.movi       v0, #0
    s.addi       s4, s21, #64
    v.st.w       [s21, #0], v3
    v.sub        v3, v0, v9
    v.cmp.lt     p2, v9, v0
    v.movi       v4, #1
    @p2 v.sel        v5, v3, v9
    v.movi       v3, #0
    v.movi       v8, #0
    s.movz       s6, #31
    v.ld.w       v10, [s3, #0]
    v.sub        v11, v0, v10
    v.cmp.lt     p3, v10, v0
    @p3 v.sel        v12, v11, v10
idiv_2:
    v.splat      v10, s6
    v.shl        v11, v8, v4
    v.cmp.lt     p4, v8, v0
    v.lshr       v13, v12, v10
    v.shl        v14, v4, v10
    s.subi       s3, s6, #1
    v.and        v10, v13, v4
    s.movz       s8, #0
    v.or         v13, v11, v10
    v.cmp.geu    p5, v13, v5
    p.or         p6, p4, p5
    v.sub        v10, v13, v5
    @p6 v.sel        v11, v14, v0
    @p6 v.sel        v14, v10, v13
    v.or         v10, v3, v11
    v.mov        v8, v14
    v.mov        v3, v10
    s.mov        s6, s3
    s.cmp.ge     s3, s6, s8
    br.nz        s3, idiv_2
    v.sub        v4, v0, v3
    p.xor        p4, p3, p2
    s.addi       s3, s2, #1152
    @p4 v.sel        v0, v4, v3
    v.movi       v3, #0
    s.addi       s6, s21, #128
    v.st.w       [s4, #0], v0
    v.sub        v0, v3, v9
    v.cmp.lt     p2, v9, v3
    v.movi       v4, #1
    @p2 v.sel        v5, v0, v9
    v.movi       v0, #0
    v.movi       v8, #0
    s.movz       s4, #31
    v.ld.w       v10, [s3, #0]
    v.sub        v11, v3, v10
    v.cmp.lt     p3, v10, v3
    @p3 v.sel        v12, v11, v10
idiv_3:
    v.splat      v10, s4
    v.shl        v11, v8, v4
    v.cmp.lt     p4, v8, v3
    v.lshr       v13, v12, v10
    v.shl        v14, v4, v10
    s.subi       s3, s4, #1
    v.and        v10, v13, v4
    s.movz       s8, #0
    v.or         v13, v11, v10
    v.cmp.geu    p5, v13, v5
    p.or         p6, p4, p5
    v.sub        v10, v13, v5
    @p6 v.sel        v11, v14, v3
    @p6 v.sel        v14, v10, v13
    v.or         v10, v0, v11
    v.mov        v8, v14
    v.mov        v0, v10
    s.mov        s4, s3
    s.cmp.ge     s3, s4, s8
    br.nz        s3, idiv_3
    v.sub        v4, v3, v0
    p.xor        p4, p3, p2
    s.addi       s3, s2, #1216
    @p4 v.sel        v3, v4, v0
    v.movi       v0, #0
    s.addi       s4, s21, #192
    v.st.w       [s6, #0], v3
    v.sub        v3, v0, v9
    v.cmp.lt     p2, v9, v0
    v.movi       v4, #1
    @p2 v.sel        v5, v3, v9
    v.movi       v3, #0
    v.movi       v8, #0
    s.movz       s6, #31
    v.ld.w       v10, [s3, #0]
    v.sub        v11, v0, v10
    v.cmp.lt     p3, v10, v0
    @p3 v.sel        v12, v11, v10
idiv_4:
    v.splat      v10, s6
    v.shl        v11, v8, v4
    v.cmp.lt     p4, v8, v0
    v.lshr       v13, v12, v10
    v.shl        v14, v4, v10
    s.subi       s3, s6, #1
    v.and        v10, v13, v4
    s.movz       s8, #0
    v.or         v13, v11, v10
    v.cmp.geu    p5, v13, v5
    p.or         p6, p4, p5
    v.sub        v10, v13, v5
    @p6 v.sel        v11, v14, v0
    @p6 v.sel        v14, v10, v13
    v.or         v10, v3, v11
    v.mov        v8, v14
    v.mov        v3, v10
    s.mov        s6, s3
    s.cmp.ge     s3, s6, s8
    br.nz        s3, idiv_4
    v.sub        v4, v0, v3
    p.xor        p4, p3, p2
    s.addi       s3, s2, #1280
    @p4 v.sel        v0, v4, v3
    v.movi       v3, #0
    s.addi       s6, s21, #256
    v.st.w       [s4, #0], v0
    v.sub        v0, v3, v9
    v.cmp.lt     p2, v9, v3
    v.movi       v4, #1
    @p2 v.sel        v5, v0, v9
    v.movi       v0, #0
    v.movi       v8, #0
    s.movz       s4, #31
    v.ld.w       v10, [s3, #0]
    v.sub        v11, v3, v10
    v.cmp.lt     p3, v10, v3
    @p3 v.sel        v12, v11, v10
idiv_5:
    v.splat      v10, s4
    v.shl        v11, v8, v4
    v.cmp.lt     p4, v8, v3
    v.lshr       v13, v12, v10
    v.shl        v14, v4, v10
    s.subi       s3, s4, #1
    v.and        v10, v13, v4
    s.movz       s8, #0
    v.or         v13, v11, v10
    v.cmp.geu    p5, v13, v5
    p.or         p6, p4, p5
    v.sub        v10, v13, v5
    @p6 v.sel        v11, v14, v3
    @p6 v.sel        v14, v10, v13
    v.or         v10, v0, v11
    v.mov        v8, v14
    v.mov        v0, v10
    s.mov        s4, s3
    s.cmp.ge     s3, s4, s8
    br.nz        s3, idiv_5
    v.sub        v4, v3, v0
    p.xor        p4, p3, p2
    s.addi       s3, s2, #1344
    @p4 v.sel        v3, v4, v0
    v.movi       v0, #0
    s.addi       s4, s21, #320
    v.st.w       [s6, #0], v3
    v.sub        v3, v0, v9
    v.cmp.lt     p2, v9, v0
    v.movi       v4, #1
    @p2 v.sel        v5, v3, v9
    v.movi       v3, #0
    v.movi       v8, #0
    s.movz       s6, #31
    v.ld.w       v10, [s3, #0]
    v.sub        v11, v0, v10
    v.cmp.lt     p3, v10, v0
    @p3 v.sel        v12, v11, v10
idiv_6:
    v.splat      v10, s6
    v.shl        v11, v8, v4
    v.cmp.lt     p4, v8, v0
    v.lshr       v13, v12, v10
    v.shl        v14, v4, v10
    s.subi       s3, s6, #1
    v.and        v10, v13, v4
    s.movz       s8, #0
    v.or         v13, v11, v10
    v.cmp.geu    p5, v13, v5
    p.or         p6, p4, p5
    v.sub        v10, v13, v5
    @p6 v.sel        v11, v14, v0
    @p6 v.sel        v14, v10, v13
    v.or         v10, v3, v11
    v.mov        v8, v14
    v.mov        v3, v10
    s.mov        s6, s3
    s.cmp.ge     s3, s6, s8
    br.nz        s3, idiv_6
    v.sub        v4, v0, v3
    p.xor        p4, p3, p2
    s.addi       s3, s2, #1408
    @p4 v.sel        v0, v4, v3
    v.movi       v3, #0
    s.addi       s6, s21, #384
    v.st.w       [s4, #0], v0
    v.sub        v0, v3, v9
    v.cmp.lt     p2, v9, v3
    v.movi       v4, #1
    @p2 v.sel        v5, v0, v9
    v.movi       v0, #0
    v.movi       v8, #0
    s.movz       s4, #31
    v.ld.w       v10, [s3, #0]
    v.sub        v11, v3, v10
    v.cmp.lt     p3, v10, v3
    @p3 v.sel        v12, v11, v10
idiv_7:
    v.splat      v10, s4
    v.shl        v11, v8, v4
    v.cmp.lt     p4, v8, v3
    v.lshr       v13, v12, v10
    v.shl        v14, v4, v10
    s.subi       s3, s4, #1
    v.and        v10, v13, v4
    s.movz       s8, #0
    v.or         v13, v11, v10
    v.cmp.geu    p5, v13, v5
    p.or         p6, p4, p5
    v.sub        v10, v13, v5
    @p6 v.sel        v11, v14, v3
    @p6 v.sel        v14, v10, v13
    v.or         v10, v0, v11
    v.mov        v8, v14
    v.mov        v0, v10
    s.mov        s4, s3
    s.cmp.ge     s3, s4, s8
    br.nz        s3, idiv_7
    v.sub        v4, v3, v0
    p.xor        p4, p3, p2
    s.addi       s3, s2, #1472
    @p4 v.sel        v3, v4, v0
    v.movi       v0, #0
    s.addi       s4, s21, #448
    v.st.w       [s6, #0], v3
    v.sub        v3, v0, v9
    v.cmp.lt     p2, v9, v0
    v.movi       v4, #1
    @p2 v.sel        v5, v3, v9
    v.movi       v3, #0
    v.movi       v8, #0
    s.movz       s6, #31
    v.ld.w       v10, [s3, #0]
    v.sub        v11, v0, v10
    v.cmp.lt     p3, v10, v0
    @p3 v.sel        v12, v11, v10
idiv_8:
    v.splat      v10, s6
    v.shl        v11, v8, v4
    v.cmp.lt     p4, v8, v0
    v.lshr       v13, v12, v10
    v.shl        v14, v4, v10
    s.subi       s3, s6, #1
    v.and        v10, v13, v4
    s.movz       s8, #0
    v.or         v13, v11, v10
    v.cmp.geu    p5, v13, v5
    p.or         p6, p4, p5
    v.sub        v10, v13, v5
    @p6 v.sel        v11, v14, v0
    @p6 v.sel        v14, v10, v13
    v.or         v10, v3, v11
    v.mov        v8, v14
    v.mov        v3, v10
    s.mov        s6, s3
    s.cmp.ge     s3, s6, s8
    br.nz        s3, idiv_8
    v.sub        v4, v0, v3
    p.xor        p4, p3, p2
    s.addi       s3, s2, #1536
    @p4 v.sel        v0, v4, v3
    v.movi       v3, #0
    s.addi       s6, s21, #512
    v.st.w       [s4, #0], v0
    v.sub        v0, v3, v9
    v.cmp.lt     p2, v9, v3
    v.movi       v4, #1
    @p2 v.sel        v5, v0, v9
    v.movi       v0, #0
    v.movi       v8, #0
    s.movz       s4, #31
    v.ld.w       v10, [s3, #0]
    v.sub        v11, v3, v10
    v.cmp.lt     p3, v10, v3
    @p3 v.sel        v12, v11, v10
idiv_9:
    v.splat      v10, s4
    v.shl        v11, v8, v4
    v.cmp.lt     p4, v8, v3
    v.lshr       v13, v12, v10
    v.shl        v14, v4, v10
    s.subi       s3, s4, #1
    v.and        v10, v13, v4
    s.movz       s8, #0
    v.or         v13, v11, v10
    v.cmp.geu    p5, v13, v5
    p.or         p6, p4, p5
    v.sub        v10, v13, v5
    @p6 v.sel        v11, v14, v3
    @p6 v.sel        v14, v10, v13
    v.or         v10, v0, v11
    v.mov        v8, v14
    v.mov        v0, v10
    s.mov        s4, s3
    s.cmp.ge     s3, s4, s8
    br.nz        s3, idiv_9
    v.sub        v4, v3, v0
    p.xor        p4, p3, p2
    s.addi       s3, s2, #1600
    @p4 v.sel        v3, v4, v0
    v.movi       v0, #0
    s.addi       s4, s21, #576
    v.st.w       [s6, #0], v3
    v.sub        v3, v0, v9
    v.cmp.lt     p2, v9, v0
    v.movi       v4, #1
    @p2 v.sel        v5, v3, v9
    v.movi       v3, #0
    v.movi       v8, #0
    s.movz       s6, #31
    v.ld.w       v10, [s3, #0]
    v.sub        v11, v0, v10
    v.cmp.lt     p3, v10, v0
    @p3 v.sel        v12, v11, v10
idiv_10:
    v.splat      v10, s6
    v.shl        v11, v8, v4
    v.cmp.lt     p4, v8, v0
    v.lshr       v13, v12, v10
    v.shl        v14, v4, v10
    s.subi       s3, s6, #1
    v.and        v10, v13, v4
    s.movz       s8, #0
    v.or         v13, v11, v10
    v.cmp.geu    p5, v13, v5
    p.or         p6, p4, p5
    v.sub        v10, v13, v5
    @p6 v.sel        v11, v14, v0
    @p6 v.sel        v14, v10, v13
    v.or         v10, v3, v11
    v.mov        v8, v14
    v.mov        v3, v10
    s.mov        s6, s3
    s.cmp.ge     s3, s6, s8
    br.nz        s3, idiv_10
    v.sub        v4, v0, v3
    p.xor        p4, p3, p2
    s.addi       s3, s2, #1664
    @p4 v.sel        v0, v4, v3
    v.movi       v3, #0
    s.addi       s6, s21, #640
    v.st.w       [s4, #0], v0
    v.sub        v0, v3, v9
    v.cmp.lt     p2, v9, v3
    v.movi       v4, #1
    @p2 v.sel        v5, v0, v9
    v.movi       v0, #0
    v.movi       v8, #0
    s.movz       s4, #31
    v.ld.w       v10, [s3, #0]
    v.sub        v11, v3, v10
    v.cmp.lt     p3, v10, v3
    @p3 v.sel        v12, v11, v10
idiv_11:
    v.splat      v10, s4
    v.shl        v11, v8, v4
    v.cmp.lt     p4, v8, v3
    v.lshr       v13, v12, v10
    v.shl        v14, v4, v10
    s.subi       s3, s4, #1
    v.and        v10, v13, v4
    s.movz       s8, #0
    v.or         v13, v11, v10
    v.cmp.geu    p5, v13, v5
    p.or         p6, p4, p5
    v.sub        v10, v13, v5
    @p6 v.sel        v11, v14, v3
    @p6 v.sel        v14, v10, v13
    v.or         v10, v0, v11
    v.mov        v8, v14
    v.mov        v0, v10
    s.mov        s4, s3
    s.cmp.ge     s3, s4, s8
    br.nz        s3, idiv_11
    v.sub        v4, v3, v0
    p.xor        p4, p3, p2
    s.addi       s3, s2, #1728
    @p4 v.sel        v3, v4, v0
    v.movi       v0, #0
    s.addi       s4, s21, #704
    v.st.w       [s6, #0], v3
    v.sub        v3, v0, v9
    v.cmp.lt     p2, v9, v0
    v.movi       v4, #1
    @p2 v.sel        v5, v3, v9
    v.movi       v3, #0
    v.movi       v8, #0
    s.movz       s6, #31
    v.ld.w       v10, [s3, #0]
    v.sub        v11, v0, v10
    v.cmp.lt     p3, v10, v0
    @p3 v.sel        v12, v11, v10
idiv_12:
    v.splat      v10, s6
    v.shl        v11, v8, v4
    v.cmp.lt     p4, v8, v0
    v.lshr       v13, v12, v10
    v.shl        v14, v4, v10
    s.subi       s3, s6, #1
    v.and        v10, v13, v4
    s.movz       s8, #0
    v.or         v13, v11, v10
    v.cmp.geu    p5, v13, v5
    p.or         p6, p4, p5
    v.sub        v10, v13, v5
    @p6 v.sel        v11, v14, v0
    @p6 v.sel        v14, v10, v13
    v.or         v10, v3, v11
    v.mov        v8, v14
    v.mov        v3, v10
    s.mov        s6, s3
    s.cmp.ge     s3, s6, s8
    br.nz        s3, idiv_12
    v.sub        v4, v0, v3
    p.xor        p4, p3, p2
    s.addi       s3, s2, #1792
    @p4 v.sel        v0, v4, v3
    v.movi       v3, #0
    s.addi       s6, s21, #768
    v.st.w       [s4, #0], v0
    v.sub        v0, v3, v9
    v.cmp.lt     p2, v9, v3
    v.movi       v4, #1
    @p2 v.sel        v5, v0, v9
    v.movi       v0, #0
    v.movi       v8, #0
    s.movz       s4, #31
    v.ld.w       v10, [s3, #0]
    v.sub        v11, v3, v10
    v.cmp.lt     p3, v10, v3
    @p3 v.sel        v12, v11, v10
idiv_13:
    v.splat      v10, s4
    v.shl        v11, v8, v4
    v.cmp.lt     p4, v8, v3
    v.lshr       v13, v12, v10
    v.shl        v14, v4, v10
    s.subi       s3, s4, #1
    v.and        v10, v13, v4
    s.movz       s8, #0
    v.or         v13, v11, v10
    v.cmp.geu    p5, v13, v5
    p.or         p6, p4, p5
    v.sub        v10, v13, v5
    @p6 v.sel        v11, v14, v3
    @p6 v.sel        v14, v10, v13
    v.or         v10, v0, v11
    v.mov        v8, v14
    v.mov        v0, v10
    s.mov        s4, s3
    s.cmp.ge     s3, s4, s8
    br.nz        s3, idiv_13
    v.sub        v4, v3, v0
    p.xor        p4, p3, p2
    s.addi       s3, s2, #1856
    @p4 v.sel        v3, v4, v0
    v.movi       v0, #0
    s.addi       s4, s21, #832
    v.st.w       [s6, #0], v3
    v.sub        v3, v0, v9
    v.cmp.lt     p2, v9, v0
    v.movi       v4, #1
    @p2 v.sel        v5, v3, v9
    v.movi       v3, #0
    v.movi       v8, #0
    s.movz       s6, #31
    v.ld.w       v10, [s3, #0]
    v.sub        v11, v0, v10
    v.cmp.lt     p3, v10, v0
    @p3 v.sel        v12, v11, v10
idiv_14:
    v.splat      v10, s6
    v.shl        v11, v8, v4
    v.cmp.lt     p4, v8, v0
    v.lshr       v13, v12, v10
    v.shl        v14, v4, v10
    s.subi       s3, s6, #1
    v.and        v10, v13, v4
    s.movz       s8, #0
    v.or         v13, v11, v10
    v.cmp.geu    p5, v13, v5
    p.or         p6, p4, p5
    v.sub        v10, v13, v5
    @p6 v.sel        v11, v14, v0
    @p6 v.sel        v14, v10, v13
    v.or         v10, v3, v11
    v.mov        v8, v14
    v.mov        v3, v10
    s.mov        s6, s3
    s.cmp.ge     s3, s6, s8
    br.nz        s3, idiv_14
    v.sub        v4, v0, v3
    p.xor        p4, p3, p2
    s.addi       s3, s2, #1920
    @p4 v.sel        v0, v4, v3
    v.movi       v3, #0
    s.addi       s6, s21, #896
    v.st.w       [s4, #0], v0
    v.sub        v0, v3, v9
    v.cmp.lt     p2, v9, v3
    v.movi       v4, #1
    @p2 v.sel        v5, v0, v9
    v.movi       v0, #0
    v.movi       v8, #0
    s.movz       s4, #31
    v.ld.w       v10, [s3, #0]
    v.sub        v11, v3, v10
    v.cmp.lt     p3, v10, v3
    @p3 v.sel        v12, v11, v10
idiv_15:
    v.splat      v10, s4
    v.shl        v11, v8, v4
    v.cmp.lt     p4, v8, v3
    v.lshr       v13, v12, v10
    v.shl        v14, v4, v10
    s.subi       s3, s4, #1
    v.and        v10, v13, v4
    s.movz       s8, #0
    v.or         v13, v11, v10
    v.cmp.geu    p5, v13, v5
    p.or         p6, p4, p5
    v.sub        v10, v13, v5
    @p6 v.sel        v11, v14, v3
    @p6 v.sel        v14, v10, v13
    v.or         v10, v0, v11
    v.mov        v8, v14
    v.mov        v0, v10
    s.mov        s4, s3
    s.cmp.ge     s3, s4, s8
    br.nz        s3, idiv_15
    v.sub        v4, v3, v0
    p.xor        p4, p3, p2
    s.addi       s3, s2, #1984
    @p4 v.sel        v3, v4, v0
    v.movi       v0, #0
    s.addi       s4, s21, #960
    v.st.w       [s6, #0], v3
    v.sub        v3, v0, v9
    v.cmp.lt     p2, v9, v0
    v.movi       v4, #1
    @p2 v.sel        v5, v3, v9
    v.movi       v3, #0
    v.movi       v8, #0
    s.movz       s6, #31
    v.ld.w       v9, [s3, #0]
    v.sub        v10, v0, v9
    v.cmp.lt     p3, v9, v0
    @p3 v.sel        v11, v10, v9
idiv_16:
    v.splat      v9, s6
    v.shl        v10, v8, v4
    v.cmp.lt     p4, v8, v0
    v.lshr       v12, v11, v9
    v.shl        v13, v4, v9
    s.subi       s3, s6, #1
    v.and        v9, v12, v4
    s.movz       s8, #0
    v.or         v12, v10, v9
    v.cmp.geu    p5, v12, v5
    p.or         p6, p4, p5
    v.sub        v9, v12, v5
    @p6 v.sel        v10, v13, v0
    @p6 v.sel        v13, v9, v12
    v.or         v9, v3, v10
    v.mov        v8, v13
    v.mov        v3, v9
    s.mov        s6, s3
    s.cmp.ge     s3, s6, s8
    br.nz        s3, idiv_16
    v.sub        v4, v0, v3
    p.xor        p4, p3, p2
    s.addi       s3, s2, #9216
    @p4 v.sel        v0, v4, v3
    s.addi       s6, s2, #0
    v.splat      v3, s17
    v.st.w       [s4, #0], v0
    fence.acq_rel.device
    s.addi       s4, s2, #10240
    s.addi       s8, s2, #9280
    s.addi       s9, s2, #64
    s.addi       s11, s4, #64
    s.addi       s15, s2, #9344
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s2, #128
    v.ld.w       v4, [s6, #0]
    v.mul        v5, v0, v6
    s.addi       s6, s4, #128
    v.add        v0, v7, v5
    v.mul        v5, v4, v2
    v.add        v4, v0, v5
    v.add        v0, v3, v4
    v.st.w       [s4, #0], v0
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s2, #9408
    v.ld.w       v4, [s9, #0]
    v.mul        v5, v0, v6
    s.addi       s9, s2, #192
    v.add        v0, v7, v5
    v.mul        v5, v4, v2
    v.add        v4, v0, v5
    v.add        v0, v3, v4
    v.st.w       [s11, #0], v0
    s.addi       s11, s4, #192
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s2, #9472
    v.ld.w       v4, [s3, #0]
    v.mul        v5, v0, v6
    s.addi       s3, s2, #256
    v.add        v0, v7, v5
    v.mul        v5, v4, v2
    v.add        v4, v0, v5
    v.add        v0, v3, v4
    v.st.w       [s6, #0], v0
    s.addi       s6, s4, #256
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s2, #9536
    v.ld.w       v4, [s9, #0]
    v.mul        v5, v0, v6
    s.addi       s9, s2, #320
    v.add        v0, v7, v5
    v.mul        v5, v4, v2
    v.add        v4, v0, v5
    v.add        v0, v3, v4
    v.st.w       [s11, #0], v0
    s.addi       s11, s4, #320
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s2, #9600
    v.ld.w       v4, [s3, #0]
    v.mul        v5, v0, v6
    s.addi       s3, s2, #384
    v.add        v0, v7, v5
    v.mul        v5, v4, v2
    v.add        v4, v0, v5
    v.add        v0, v3, v4
    v.st.w       [s6, #0], v0
    s.addi       s6, s4, #384
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s2, #9664
    v.ld.w       v4, [s9, #0]
    v.mul        v5, v0, v6
    s.addi       s9, s2, #448
    v.add        v0, v7, v5
    v.mul        v5, v4, v2
    v.add        v4, v0, v5
    v.add        v0, v3, v4
    v.st.w       [s11, #0], v0
    s.addi       s11, s4, #448
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s2, #9728
    v.ld.w       v4, [s3, #0]
    v.mul        v5, v0, v6
    s.addi       s3, s2, #512
    v.add        v0, v7, v5
    v.mul        v5, v4, v2
    v.add        v4, v0, v5
    v.add        v0, v3, v4
    v.st.w       [s6, #0], v0
    s.addi       s6, s4, #512
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s2, #9792
    v.ld.w       v4, [s9, #0]
    v.mul        v5, v0, v6
    s.addi       s9, s2, #576
    v.add        v0, v7, v5
    v.mul        v5, v4, v2
    v.add        v4, v0, v5
    v.add        v0, v3, v4
    v.st.w       [s11, #0], v0
    s.addi       s11, s4, #576
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s2, #9856
    v.ld.w       v4, [s3, #0]
    v.mul        v5, v0, v6
    s.addi       s3, s2, #640
    v.add        v0, v7, v5
    v.mul        v5, v4, v2
    v.add        v4, v0, v5
    v.add        v0, v3, v4
    v.st.w       [s6, #0], v0
    s.addi       s6, s4, #640
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s2, #9920
    v.ld.w       v4, [s9, #0]
    v.mul        v5, v0, v6
    s.addi       s9, s2, #704
    v.add        v0, v7, v5
    v.mul        v5, v4, v2
    v.add        v4, v0, v5
    v.add        v0, v3, v4
    v.st.w       [s11, #0], v0
    s.addi       s11, s4, #704
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s2, #9984
    v.ld.w       v4, [s3, #0]
    v.mul        v5, v0, v6
    s.addi       s3, s2, #768
    v.add        v0, v7, v5
    v.mul        v5, v4, v2
    v.add        v4, v0, v5
    v.add        v0, v3, v4
    v.st.w       [s6, #0], v0
    s.addi       s6, s4, #768
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s2, #10048
    v.ld.w       v4, [s9, #0]
    v.mul        v5, v0, v6
    s.addi       s9, s2, #832
    v.add        v0, v7, v5
    v.mul        v5, v4, v2
    v.add        v4, v0, v5
    v.add        v0, v3, v4
    v.st.w       [s11, #0], v0
    s.addi       s11, s4, #832
    v.splat      v0, s1
    v.cmp.lt     p2, v0, v1
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s2, #10112
    p.and        p3, p1, p2
    v.ld.w       v4, [s3, #0]
    v.mul        v5, v0, v6
    s.addi       s3, s2, #896
    v.add        v0, v7, v5
    v.mul        v5, v4, v2
    v.add        v4, v0, v5
    v.add        v0, v3, v4
    v.st.w       [s6, #0], v0
    s.addi       s6, s4, #896
    s.addi       s18, s4, #960
    v.ld.w       v0, [s8, #0]
    s.addi       s4, s2, #10176
    v.ld.w       v4, [s9, #0]
    v.mul        v5, v0, v6
    s.addi       s8, s2, #960
    v.add        v0, v7, v5
    v.mul        v5, v4, v2
    v.add        v4, v0, v5
    v.add        v0, v3, v4
    v.st.w       [s11, #0], v0
    s.addi       s9, s2, #10240
    v.ld.w       v0, [s15, #0]
    s.addi       s11, s2, #11264
    v.ld.w       v4, [s3, #0]
    v.mul        v5, v0, v6
    s.addi       s3, s2, #10304
    v.add        v0, v7, v5
    v.mul        v5, v4, v2
    v.add        v4, v0, v5
    v.add        v0, v3, v4
    v.st.w       [s6, #0], v0
    s.addi       s6, s1, #1
    v.splat      v0, s6
    s.addi       s6, s11, #64
    v.cmp.lt     p2, v0, v1
    p.and        p4, p1, p2
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s2, #10368
    v.ld.w       v4, [s8, #0]
    v.mul        v5, v0, v6
    s.addi       s8, s1, #2
    v.add        v0, v7, v5
    v.splat      v5, s8
    s.addi       s8, s11, #128
    v.mul        v6, v4, v2
    v.add        v2, v0, v6
    v.add        v0, v3, v2
    v.st.w       [s18, #0], v0
    fence.acq_rel.device
    s.addi       s15, s2, #10432
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s1, #3
    v.splat      v2, s9
    s.addi       s9, s11, #192
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v3, [s12, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    v.st.w       [s11, #0], v3
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s2, #10496
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v3, [s12, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v1
    p.and        p4, p1, p2
    v.st.w       [s6, #0], v3
    s.addi       s6, s1, #4
    v.splat      v0, s6
    s.addi       s6, s11, #256
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s2, #10560
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v3, [s12, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    v.st.w       [s8, #0], v3
    s.addi       s8, s1, #5
    v.splat      v0, s8
    s.addi       s8, s11, #320
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s2, #10624
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v3, [s12, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p4, p1, p2
    v.st.w       [s9, #0], v3
    s.addi       s9, s1, #6
    v.splat      v0, s9
    s.addi       s9, s11, #384
    v.ld.w       v2, [s3, #0]
    s.addi       s3, s2, #10688
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v3, [s12, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    v.st.w       [s6, #0], v3
    s.addi       s6, s1, #7
    v.splat      v0, s6
    s.addi       s6, s11, #448
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s2, #10752
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v3, [s12, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p4, p1, p2
    v.st.w       [s8, #0], v3
    s.addi       s8, s1, #8
    v.splat      v0, s8
    s.addi       s8, s11, #512
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s2, #10816
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v3, [s12, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    v.st.w       [s9, #0], v3
    s.addi       s9, s1, #9
    v.splat      v0, s9
    s.addi       s9, s11, #576
    v.ld.w       v2, [s3, #0]
    s.addi       s3, s2, #10880
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v3, [s12, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p4, p1, p2
    v.st.w       [s6, #0], v3
    s.addi       s6, s1, #10
    v.splat      v0, s6
    s.addi       s6, s11, #640
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s2, #10944
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v3, [s12, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    v.st.w       [s8, #0], v3
    s.addi       s8, s1, #11
    v.splat      v0, s8
    s.addi       s8, s11, #704
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s2, #11008
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v3, [s12, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p4, p1, p2
    v.st.w       [s9, #0], v3
    s.addi       s9, s1, #12
    v.splat      v0, s9
    s.addi       s9, s11, #768
    v.ld.w       v2, [s3, #0]
    s.addi       s3, s2, #11072
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v3, [s12, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    v.st.w       [s6, #0], v3
    s.addi       s6, s1, #13
    v.splat      v0, s17
    v.splat      v2, s6
    s.addi       s6, s11, #832
    v.ld.w       v3, [s4, #0]
    s.addi       s4, s2, #11136
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v4, [s12, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v1
    p.and        p4, p1, p2
    v.st.w       [s8, #0], v4
    s.addi       s8, s1, #14
    v.splat      v2, s8
    s.addi       s8, s11, #896
    s.addi       s18, s11, #960
    v.ld.w       v3, [s15, #0]
    s.addi       s11, s2, #11200
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v4, [s12, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v1
    p.and        p3, p1, p2
    v.st.w       [s9, #0], v4
    s.addi       s9, s1, #15
    v.splat      v2, s9
    s.addi       s9, s2, #9216
    v.ld.w       v3, [s3, #0]
    s.addi       s3, s2, #4096
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v4, [s12, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v1
    p.and        p4, p1, p2
    v.st.w       [s6, #0], v4
    s.movz       s6, #2048
    v.splat      v2, s6
    s.addi       s6, s2, #12288
    v.ld.w       v3, [s4, #0]
    s.addi       s4, s2, #9280
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v4, [s12, v3]              // index is in elements (ISA sec 9.1)
    v.st.w       [s8, #0], v4
    s.addi       s8, s2, #4160
    v.ld.w       v3, [s11, #0]
    s.addi       s11, s6, #64
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v4, [s12, v3]              // index is in elements (ISA sec 9.1)
    s.addi       s12, s2, #9344
    v.st.w       [s18, #0], v4
    fence.acq_rel.device
    s.addi       s15, s2, #4224
    v.ld.w       v3, [s9, #0]
    s.addi       s9, s6, #128
    v.ld.w       v4, [s3, #0]
    v.mul        v5, v3, v2
    s.addi       s3, s2, #9408
    v.add        v3, v4, v5
    v.add        v4, v0, v3
    v.st.w       [s6, #0], v4
    v.ld.w       v3, [s4, #0]
    s.addi       s4, s2, #4288
    v.ld.w       v4, [s8, #0]
    v.mul        v5, v3, v2
    s.addi       s8, s6, #192
    v.add        v3, v4, v5
    v.add        v4, v0, v3
    v.st.w       [s11, #0], v4
    s.addi       s11, s2, #9472
    v.ld.w       v3, [s12, #0]
    s.addi       s12, s2, #4352
    v.ld.w       v4, [s15, #0]
    v.mul        v5, v3, v2
    s.addi       s15, s6, #256
    v.add        v3, v4, v5
    v.add        v4, v0, v3
    v.st.w       [s9, #0], v4
    s.addi       s9, s2, #9536
    v.ld.w       v3, [s3, #0]
    s.addi       s3, s2, #4416
    v.ld.w       v4, [s4, #0]
    v.mul        v5, v3, v2
    s.addi       s4, s6, #320
    v.add        v3, v4, v5
    v.add        v4, v0, v3
    v.st.w       [s8, #0], v4
    s.addi       s8, s2, #9600
    v.ld.w       v3, [s11, #0]
    s.addi       s11, s2, #4480
    v.ld.w       v4, [s12, #0]
    v.mul        v5, v3, v2
    s.addi       s12, s6, #384
    v.add        v3, v4, v5
    v.add        v4, v0, v3
    v.st.w       [s15, #0], v4
    s.addi       s15, s2, #9664
    v.ld.w       v3, [s9, #0]
    s.addi       s9, s2, #4544
    v.ld.w       v4, [s3, #0]
    v.mul        v5, v3, v2
    s.addi       s3, s6, #448
    v.add        v3, v4, v5
    v.add        v4, v0, v3
    v.st.w       [s4, #0], v4
    s.addi       s4, s2, #9728
    v.ld.w       v3, [s8, #0]
    s.addi       s8, s2, #4608
    v.ld.w       v4, [s11, #0]
    v.mul        v5, v3, v2
    s.addi       s11, s6, #512
    v.add        v3, v4, v5
    v.add        v4, v0, v3
    v.st.w       [s12, #0], v4
    s.addi       s12, s2, #9792
    v.ld.w       v3, [s15, #0]
    s.addi       s15, s2, #4672
    v.ld.w       v4, [s9, #0]
    v.mul        v5, v3, v2
    s.addi       s9, s6, #576
    v.add        v3, v4, v5
    v.add        v4, v0, v3
    v.st.w       [s3, #0], v4
    s.addi       s3, s2, #9856
    v.ld.w       v3, [s4, #0]
    s.addi       s4, s2, #4736
    v.ld.w       v4, [s8, #0]
    v.mul        v5, v3, v2
    s.addi       s8, s6, #640
    v.add        v3, v4, v5
    v.add        v4, v0, v3
    v.st.w       [s11, #0], v4
    s.addi       s11, s2, #9920
    v.ld.w       v3, [s12, #0]
    s.addi       s12, s2, #4800
    v.ld.w       v4, [s15, #0]
    v.mul        v5, v3, v2
    s.addi       s15, s6, #704
    v.add        v3, v4, v5
    v.add        v4, v0, v3
    v.st.w       [s9, #0], v4
    s.addi       s9, s2, #9984
    v.ld.w       v3, [s3, #0]
    s.addi       s3, s2, #4864
    v.ld.w       v4, [s4, #0]
    v.mul        v5, v3, v2
    s.addi       s4, s6, #768
    v.add        v3, v4, v5
    v.add        v4, v0, v3
    v.st.w       [s8, #0], v4
    s.addi       s8, s2, #10048
    v.splat      v3, s1
    v.ld.w       v4, [s11, #0]
    s.addi       s11, s2, #4928
    v.ld.w       v5, [s12, #0]
    v.mul        v6, v4, v2
    s.addi       s12, s6, #832
    v.cmp.lt     p2, v3, v1
    p.and        p3, p1, p2
    v.add        v3, v5, v6
    v.add        v4, v0, v3
    v.st.w       [s15, #0], v4
    s.addi       s15, s2, #10112
    v.ld.w       v3, [s9, #0]
    s.addi       s9, s2, #4992
    v.ld.w       v4, [s3, #0]
    v.mul        v5, v3, v2
    s.addi       s3, s6, #896
    s.addi       s18, s6, #960
    v.add        v3, v4, v5
    v.add        v4, v0, v3
    v.st.w       [s4, #0], v4
    s.addi       s4, s2, #10176
    v.ld.w       v3, [s8, #0]
    s.addi       s6, s2, #5056
    v.ld.w       v4, [s11, #0]
    v.mul        v5, v3, v2
    s.addi       s8, s2, #12288
    v.add        v3, v4, v5
    v.add        v4, v0, v3
    v.st.w       [s12, #0], v4
    s.addi       s11, s2, #13312
    v.ld.w       v3, [s15, #0]
    s.addi       s12, s2, #12352
    v.ld.w       v4, [s9, #0]
    v.mul        v5, v3, v2
    s.addi       s9, s1, #1
    v.splat      v3, s9
    s.addi       s9, s11, #64
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    v.add        v3, v4, v5
    v.add        v4, v0, v3
    v.st.w       [s3, #0], v4
    s.addi       s3, s2, #12416
    v.ld.w       v3, [s4, #0]
    s.addi       s4, s1, #2
    v.splat      v4, s4
    s.addi       s4, s11, #128
    v.ld.w       v5, [s6, #0]
    v.mul        v6, v3, v2
    s.addi       s6, s2, #12480
    v.add        v3, v5, v6
    v.add        v5, v0, v3
    v.st.w       [s18, #0], v5
    fence.acq_rel.device
    s.addi       s15, s1, #3
    v.splat      v0, s15
    s.addi       s15, s11, #192
    v.ld.w       v3, [s8, #0]
    s.addi       s8, s2, #12544
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s13, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v1
    p.and        p3, p1, p2
    v.st.w       [s11, #0], v5
    v.ld.w       v3, [s12, #0]
    s.addi       s12, s1, #4
    v.splat      v4, s12
    s.addi       s12, s11, #256
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s13, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p4, p1, p2
    v.st.w       [s9, #0], v5
    s.addi       s9, s2, #12608
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s1, #5
    v.splat      v3, s3
    s.addi       s3, s11, #320
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v1
    p.and        p3, p1, p2
    v.st.w       [s4, #0], v5
    s.addi       s4, s2, #12672
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s1, #6
    v.splat      v4, s6
    s.addi       s6, s11, #384
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    v.st.w       [s15, #0], v5
    s.addi       s15, s2, #12736
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #7
    v.splat      v3, s8
    s.addi       s8, s11, #448
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v1
    p.and        p3, p1, p2
    v.st.w       [s12, #0], v5
    s.addi       s12, s2, #12800
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s1, #8
    v.splat      v4, s9
    s.addi       s9, s11, #512
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #12864
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s1, #9
    v.splat      v3, s4
    s.addi       s4, s11, #576
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v1
    p.and        p3, p1, p2
    v.st.w       [s6, #0], v5
    s.addi       s6, s2, #12928
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s1, #10
    v.splat      v4, s15
    s.addi       s15, s11, #640
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    v.st.w       [s8, #0], v5
    s.addi       s8, s2, #12992
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s1, #11
    v.splat      v3, s12
    s.addi       s12, s11, #704
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v1
    p.and        p3, p1, p2
    v.st.w       [s9, #0], v5
    s.addi       s9, s2, #13056
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s1, #12
    v.splat      v4, s3
    s.addi       s3, s11, #768
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    v.st.w       [s4, #0], v5
    s.addi       s4, s2, #13120
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s1, #13
    v.splat      v3, s6
    s.addi       s6, s11, #832
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v1
    p.and        p3, p1, p2
    .li       s18, #1054295293
    v.splat      v0, s18                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.st.w       [s15, #0], v5
    s.addi       s15, s2, #13184
    .li       s18, #1054295293
    v.splat      v4, s18                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.ld.w       v5, [s8, #0]
    s.addi       s8, s1, #14
    v.splat      v6, s8
    s.addi       s8, s11, #896
    s.addi       s18, s11, #960
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v7, [s13, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    v.st.w       [s12, #0], v7
    s.addi       s11, s2, #13248
    v.ld.w       v3, [s9, #0]
    s.addi       s9, s1, #15
    v.splat      v5, s9
    s.addi       s9, s2, #11264
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v7, [s13, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v1
    p.and        p3, p1, p2
    v.st.w       [s3, #0], v7
    s.movz       s3, #0
    v.ld.w       v3, [s4, #0]
    s.addi       s4, s2, #13312
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v6, [s13, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v1
    p.and        p4, p1, p2
    v.st.w       [s6, #0], v6
    s.movz       s6, #0
    v.ld.w       v3, [s15, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s12, #0
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s13, v3]              // index is in elements (ISA sec 9.1)
    v.st.w       [s8, #0], v5
    s.addi       s8, s2, #11328
    v.ld.w       v3, [s11, #0]
    s.movz       s11, #1
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s13, v3]              // index is in elements (ISA sec 9.1)
    s.addi       s13, s2, #13376
    v.st.w       [s18, #0], v5
    fence.acq_rel.device
    s.movz       s15, #1
    v.ld.w       v3, [s9, #0]
    a.vread      v5, a0, s3
    s.movz       s3, #1
    s.addi       s9, s2, #11392
    v.ld.w       v6, [s4, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s6
    s.movz       s4, #2
    s.addi       s6, s2, #13440
    vf.mul       v8, v7, v5
    vf.cvt.f16.f32 v5, v6
    vf.mul       v6, v5, v3
    vf.add       v3, v8, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s12, v5
    v.ld.w       v3, [s8, #0]
    a.vread      v5, a0, s11
    s.movz       s8, #2
    s.movz       s11, #2
    s.addi       s12, s2, #11456
    v.ld.w       v6, [s13, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s15
    s.movz       s13, #3
    s.addi       s15, s2, #13504
    vf.mul       v8, v7, v5
    vf.cvt.f16.f32 v5, v6
    vf.mul       v6, v5, v3
    vf.add       v3, v8, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s3, v5
    v.ld.w       v3, [s9, #0]
    a.vread      v5, a0, s4
    s.movz       s3, #3
    s.movz       s4, #3
    s.addi       s9, s2, #11520
    v.ld.w       v6, [s6, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s8
    s.movz       s6, #4
    s.addi       s8, s2, #13568
    vf.mul       v8, v7, v5
    vf.cvt.f16.f32 v5, v6
    vf.mul       v6, v5, v3
    vf.add       v3, v8, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s11, v5
    v.ld.w       v3, [s12, #0]
    a.vread      v5, a0, s13
    s.movz       s11, #4
    s.movz       s12, #4
    s.addi       s13, s2, #11584
    v.ld.w       v6, [s15, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s3
    s.movz       s3, #5
    s.addi       s15, s2, #13632
    vf.mul       v8, v7, v5
    vf.cvt.f16.f32 v5, v6
    vf.mul       v6, v5, v3
    vf.add       v3, v8, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s4, v5
    v.ld.w       v3, [s9, #0]
    a.vread      v5, a0, s6
    s.movz       s4, #5
    s.movz       s6, #5
    s.addi       s9, s2, #11648
    v.ld.w       v6, [s8, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s11
    s.movz       s8, #6
    s.addi       s11, s2, #13696
    vf.mul       v8, v7, v5
    vf.cvt.f16.f32 v5, v6
    vf.mul       v6, v5, v3
    vf.add       v3, v8, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s12, v5
    v.ld.w       v3, [s13, #0]
    a.vread      v5, a0, s3
    s.movz       s3, #6
    s.movz       s12, #6
    s.addi       s13, s2, #11712
    v.ld.w       v6, [s15, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s4
    s.movz       s4, #7
    s.addi       s15, s2, #13760
    vf.mul       v8, v7, v5
    vf.cvt.f16.f32 v5, v6
    vf.mul       v6, v5, v3
    vf.add       v3, v8, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s6, v5
    v.ld.w       v3, [s9, #0]
    a.vread      v5, a0, s8
    s.movz       s6, #7
    s.movz       s8, #7
    s.addi       s9, s2, #11776
    v.ld.w       v6, [s11, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s3
    s.movz       s3, #8
    s.addi       s11, s2, #13824
    vf.mul       v8, v7, v5
    vf.cvt.f16.f32 v5, v6
    vf.mul       v6, v5, v3
    vf.add       v3, v8, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s12, v5
    v.ld.w       v3, [s13, #0]
    a.vread      v5, a0, s4
    s.movz       s4, #8
    s.movz       s12, #8
    s.addi       s13, s2, #11840
    v.ld.w       v6, [s15, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s6
    s.movz       s6, #9
    s.addi       s15, s2, #13888
    vf.mul       v8, v7, v5
    vf.cvt.f16.f32 v5, v6
    vf.mul       v6, v5, v3
    vf.add       v3, v8, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s8, v5
    v.ld.w       v3, [s9, #0]
    a.vread      v5, a0, s3
    s.movz       s3, #9
    s.movz       s8, #9
    s.addi       s9, s2, #11904
    v.ld.w       v6, [s11, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s4
    s.movz       s4, #10
    s.addi       s11, s2, #13952
    vf.mul       v8, v7, v5
    vf.cvt.f16.f32 v5, v6
    vf.mul       v6, v5, v3
    vf.add       v3, v8, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s12, v5
    v.ld.w       v3, [s13, #0]
    a.vread      v5, a0, s6
    s.movz       s6, #10
    s.movz       s12, #10
    s.addi       s13, s2, #11968
    v.ld.w       v6, [s15, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s3
    s.movz       s3, #11
    s.addi       s15, s2, #14016
    vf.mul       v8, v7, v5
    vf.cvt.f16.f32 v5, v6
    vf.mul       v6, v5, v3
    vf.add       v3, v8, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s8, v5
    v.ld.w       v3, [s9, #0]
    a.vread      v5, a0, s4
    s.movz       s4, #11
    s.movz       s8, #11
    s.addi       s9, s2, #12032
    v.ld.w       v6, [s11, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s6
    s.movz       s6, #12
    s.addi       s11, s2, #14080
    vf.mul       v8, v7, v5
    vf.cvt.f16.f32 v5, v6
    vf.mul       v6, v5, v3
    vf.add       v3, v8, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s12, v5
    v.ld.w       v3, [s13, #0]
    a.vread      v5, a0, s3
    s.movz       s3, #12
    s.movz       s12, #12
    s.addi       s13, s2, #12096
    v.ld.w       v6, [s15, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s4
    s.movz       s4, #13
    s.addi       s15, s2, #14144
    vf.mul       v8, v7, v5
    vf.cvt.f16.f32 v5, v6
    vf.mul       v6, v5, v3
    vf.add       v3, v8, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s8, v5
    v.ld.w       v3, [s9, #0]
    a.vread      v5, a0, s6
    s.movz       s6, #13
    s.movz       s8, #13
    s.addi       s9, s2, #12160
    v.ld.w       v6, [s11, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s3
    s.movz       s3, #14
    s.addi       s11, s2, #14208
    vf.mul       v8, v7, v5
    vf.cvt.f16.f32 v5, v6
    vf.mul       v6, v5, v3
    vf.add       v3, v8, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s12, v5
    v.ld.w       v3, [s13, #0]
    a.vread      v5, a0, s4
    s.movz       s4, #14
    s.movz       s12, #14
    s.addi       s13, s2, #12224
    s.muli       s18, s5, #128                   // a runtime tile origin, x128
    v.ld.w       v6, [s15, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s6
    s.movz       s5, #15
    s.addi       s6, s2, #14272
    vf.mul       v8, v7, v5
    vf.cvt.f16.f32 v5, v6
    v.splat      v6, s1
    v.cmp.lt     p2, v6, v1
    vf.mul       v6, v5, v3
    p.and        p3, p1, p2
    vf.add       v3, v8, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s8, v5
    v.ld.w       v3, [s9, #0]
    a.vread      v5, a0, s3
    s.movz       s3, #15
    s.movz       s8, #15
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.addi       s9, s2, #3072
    v.ld.w       v6, [s11, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s4
    s.movz       s4, #0
    s.movz       s11, #0
    v.splat      v8, s1
    vf.mul       v9, v7, v5
    v.cmp.lt     p2, v8, v1
    p.and        p4, p1, p2
    vf.cvt.f16.f32 v5, v6
    vf.mul       v6, v5, v3
    vf.add       v3, v9, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s12, v5
    v.ld.w       v3, [s13, #0]
    a.vread      v5, a0, s5
    s.muli       s5, s7, #4                      // a runtime tile origin, x4
    s.addi       s12, s1, #1
    s.addi       s13, s2, #3136
    v.splat      v6, s12
    s.movz       s12, #1
    s.add        s15, s14, s5                    // the tile origin
    s.addi       s5, s10, #64                    // row 1
    s.add        s14, s15, s18                   // the tile origin
    v.ld.w       v7, [s6, #0]
    vf.cvt.f16.f32 v8, v3
    a.vread      v3, a1, s3
    s.movz       s3, #1
    vf.mul       v9, v8, v5
    vf.cvt.f16.f32 v5, v7
    s.addi       s6, s1, #1
    s.addi       s15, s14, #128                  // row 1
    vf.mul       v7, v5, v3
    v.splat      v3, s6
    vf.add       v5, v9, v7
    vf.mul       v7, v5, v4
    a.vwrite     a2, s8, v7
    v.ld.w       v4, [s9, #0]
    a.vread      v5, a0, s4
    s.addi       s4, s2, #3200
    s.movz       s6, #2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s10, #0]
    vf.cvt.f16.f32 v8, v4
    a.vread      v4, a1, s11
    v.cmp.lt     p2, v6, v1
    p.and        p3, p1, p2
    s.addi       s8, s1, #2
    vf.mul       v6, v8, v5
    v.splat      v5, s8
    s.addi       s8, s10, #128                   // row 2
    s.movz       s9, #2
    vf.cvt.f16.f32 v8, v7
    vf.mul       v7, v8, v4
    vf.add       v4, v6, v7
    s.addi       s11, s14, #256                  // row 2
    vf.mul       v6, v4, v0
    @p4 v.st.w       [s14, #0], v6
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    v.ld.w       v3, [s13, #0]
    a.vread      v4, a0, s12
    s.addi       s12, s1, #2
    s.addi       s13, s2, #3264
    v.splat      v6, s12
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s5, #0]
    vf.cvt.f16.f32 v8, v3
    a.vread      v3, a1, s3
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    s.movz       s3, #3
    vf.mul       v5, v8, v4
    s.addi       s5, s1, #3
    s.addi       s12, s10, #192                  // row 3
    v.splat      v4, s5
    vf.cvt.f16.f32 v8, v7
    s.movz       s5, #3
    vf.mul       v7, v8, v3
    vf.add       v3, v5, v7
    vf.mul       v5, v3, v0
    @p4 v.st.w       [s15, #0], v5
    v.cmp.lt     p2, v6, v1
    p.and        p4, p1, p2
    s.addi       s15, s1, #3
    v.splat      v3, s15
    s.addi       s15, s14, #384                  // row 3
    v.ld.w       v5, [s4, #0]
    a.vread      v6, a0, s6
    s.addi       s4, s2, #3328
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s8, #0]
    vf.cvt.f16.f32 v8, v5
    a.vread      v5, a1, s9
    v.cmp.lt     p2, v4, v1
    p.and        p3, p1, p2
    s.movz       s6, #4
    vf.mul       v4, v8, v6
    s.addi       s8, s1, #4
    s.addi       s9, s10, #256                   // row 4
    v.splat      v6, s8
    vf.cvt.f16.f32 v8, v7
    s.movz       s8, #4
    vf.mul       v7, v8, v5
    vf.add       v5, v4, v7
    vf.mul       v4, v5, v0
    @p4 v.st.w       [s11, #0], v4
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    s.addi       s11, s1, #4
    v.splat      v3, s11
    s.addi       s11, s14, #512                  // row 4
    v.ld.w       v4, [s13, #0]
    a.vread      v5, a0, s3
    s.addi       s3, s2, #3392
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s12, #0]
    vf.cvt.f16.f32 v8, v4
    a.vread      v4, a1, s5
    v.cmp.lt     p2, v6, v1
    p.and        p3, p1, p2
    s.movz       s5, #5
    vf.mul       v6, v8, v5
    s.addi       s12, s1, #5
    s.addi       s13, s10, #320                  // row 5
    v.splat      v5, s12
    vf.cvt.f16.f32 v8, v7
    s.movz       s12, #5
    vf.mul       v7, v8, v4
    vf.add       v4, v6, v7
    vf.mul       v6, v4, v0
    @p4 v.st.w       [s15, #0], v6
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    s.addi       s15, s1, #5
    v.splat      v3, s15
    s.addi       s15, s14, #640                  // row 5
    v.ld.w       v4, [s4, #0]
    a.vread      v6, a0, s6
    s.addi       s4, s2, #3456
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s9, #0]
    vf.cvt.f16.f32 v8, v4
    a.vread      v4, a1, s8
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    s.movz       s6, #6
    vf.mul       v5, v8, v6
    s.addi       s8, s1, #6
    s.addi       s9, s10, #384                   // row 6
    v.splat      v6, s8
    vf.cvt.f16.f32 v8, v7
    s.movz       s8, #6
    vf.mul       v7, v8, v4
    vf.add       v4, v5, v7
    vf.mul       v5, v4, v0
    @p4 v.st.w       [s11, #0], v5
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    s.addi       s11, s1, #6
    v.splat      v3, s11
    s.addi       s11, s14, #768                  // row 6
    v.ld.w       v4, [s3, #0]
    a.vread      v5, a0, s5
    s.addi       s3, s2, #3520
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s13, #0]
    vf.cvt.f16.f32 v8, v4
    a.vread      v4, a1, s12
    v.cmp.lt     p2, v6, v1
    p.and        p3, p1, p2
    s.movz       s5, #7
    vf.mul       v6, v8, v5
    s.addi       s12, s1, #7
    s.addi       s13, s10, #448                  // row 7
    v.splat      v5, s12
    vf.cvt.f16.f32 v8, v7
    s.movz       s12, #7
    vf.mul       v7, v8, v4
    vf.add       v4, v6, v7
    vf.mul       v6, v4, v0
    @p4 v.st.w       [s15, #0], v6
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    s.addi       s15, s1, #7
    v.splat      v3, s15
    s.addi       s15, s14, #896                  // row 7
    v.ld.w       v4, [s4, #0]
    a.vread      v6, a0, s6
    s.addi       s4, s2, #3584
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s9, #0]
    vf.cvt.f16.f32 v8, v4
    a.vread      v4, a1, s8
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    s.movz       s6, #8
    vf.mul       v5, v8, v6
    s.addi       s8, s1, #8
    s.addi       s9, s10, #512                   // row 8
    v.splat      v6, s8
    vf.cvt.f16.f32 v8, v7
    s.movz       s8, #8
    vf.mul       v7, v8, v4
    vf.add       v4, v5, v7
    vf.mul       v5, v4, v0
    @p4 v.st.w       [s11, #0], v5
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    s.addi       s11, s1, #8
    v.splat      v3, s11
    s.addi       s11, s14, #1024                 // row 8
    v.ld.w       v4, [s3, #0]
    a.vread      v5, a0, s5
    s.addi       s3, s2, #3648
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s13, #0]
    vf.cvt.f16.f32 v8, v4
    a.vread      v4, a1, s12
    v.cmp.lt     p2, v6, v1
    p.and        p3, p1, p2
    s.movz       s5, #9
    vf.mul       v6, v8, v5
    s.addi       s12, s1, #9
    s.addi       s13, s10, #576                  // row 9
    v.splat      v5, s12
    vf.cvt.f16.f32 v8, v7
    s.movz       s12, #9
    vf.mul       v7, v8, v4
    vf.add       v4, v6, v7
    vf.mul       v6, v4, v0
    @p4 v.st.w       [s15, #0], v6
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    s.addi       s15, s1, #9
    v.splat      v3, s15
    s.addi       s15, s14, #1152                 // row 9
    v.ld.w       v4, [s4, #0]
    a.vread      v6, a0, s6
    s.addi       s4, s2, #3712
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s9, #0]
    vf.cvt.f16.f32 v8, v4
    a.vread      v4, a1, s8
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    s.movz       s6, #10
    vf.mul       v5, v8, v6
    s.addi       s8, s1, #10
    s.addi       s9, s10, #640                   // row 10
    v.splat      v6, s8
    vf.cvt.f16.f32 v8, v7
    s.movz       s8, #10
    vf.mul       v7, v8, v4
    vf.add       v4, v5, v7
    vf.mul       v5, v4, v0
    @p4 v.st.w       [s11, #0], v5
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    s.addi       s11, s1, #10
    v.splat      v3, s11
    s.addi       s11, s14, #1280                 // row 10
    v.ld.w       v4, [s3, #0]
    a.vread      v5, a0, s5
    s.addi       s3, s2, #3776
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s13, #0]
    vf.cvt.f16.f32 v8, v4
    a.vread      v4, a1, s12
    v.cmp.lt     p2, v6, v1
    p.and        p3, p1, p2
    s.movz       s5, #11
    vf.mul       v6, v8, v5
    s.addi       s12, s1, #11
    s.addi       s13, s10, #704                  // row 11
    v.splat      v5, s12
    vf.cvt.f16.f32 v8, v7
    s.movz       s12, #11
    vf.mul       v7, v8, v4
    vf.add       v4, v6, v7
    vf.mul       v6, v4, v0
    @p4 v.st.w       [s15, #0], v6
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    s.addi       s15, s1, #11
    v.splat      v3, s15
    s.addi       s15, s14, #1408                 // row 11
    v.ld.w       v4, [s4, #0]
    a.vread      v6, a0, s6
    s.addi       s4, s2, #3840
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s9, #0]
    vf.cvt.f16.f32 v8, v4
    a.vread      v4, a1, s8
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    s.movz       s6, #12
    vf.mul       v5, v8, v6
    s.addi       s8, s1, #12
    s.addi       s9, s10, #768                   // row 12
    v.splat      v6, s8
    vf.cvt.f16.f32 v8, v7
    s.movz       s8, #12
    vf.mul       v7, v8, v4
    vf.add       v4, v5, v7
    vf.mul       v5, v4, v0
    @p4 v.st.w       [s11, #0], v5
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    s.addi       s11, s1, #12
    v.splat      v3, s11
    s.addi       s11, s14, #1536                 // row 12
    v.ld.w       v4, [s3, #0]
    a.vread      v5, a0, s5
    s.addi       s3, s2, #3904
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s13, #0]
    vf.cvt.f16.f32 v8, v4
    a.vread      v4, a1, s12
    v.cmp.lt     p2, v6, v1
    p.and        p3, p1, p2
    s.movz       s5, #13
    vf.mul       v6, v8, v5
    s.addi       s12, s1, #13
    s.addi       s13, s10, #832                  // row 13
    v.splat      v5, s12
    vf.cvt.f16.f32 v8, v7
    s.movz       s12, #13
    vf.mul       v7, v8, v4
    vf.add       v4, v6, v7
    vf.mul       v6, v4, v0
    @p4 v.st.w       [s15, #0], v6
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    s.addi       s15, s1, #13
    v.splat      v3, s15
    s.addi       s15, s14, #1664                 // row 13
    v.ld.w       v4, [s4, #0]
    a.vread      v6, a0, s6
    s.addi       s4, s2, #3968
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s9, #0]
    vf.cvt.f16.f32 v8, v4
    a.vread      v4, a1, s8
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    s.movz       s6, #14
    vf.mul       v5, v8, v6
    s.addi       s8, s1, #14
    s.addi       s9, s10, #896                   // row 14
    v.splat      v6, s8
    vf.cvt.f16.f32 v8, v7
    s.movz       s8, #14
    vf.mul       v7, v8, v4
    vf.add       v4, v5, v7
    vf.mul       v5, v4, v0
    @p4 v.st.w       [s11, #0], v5
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    s.addi       s11, s1, #14
    v.splat      v3, s11
    s.addi       s11, s14, #1792                 // row 14
    v.ld.w       v4, [s3, #0]
    a.vread      v5, a0, s5
    s.addi       s3, s2, #4032
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s13, #0]
    vf.cvt.f16.f32 v8, v4
    a.vread      v4, a1, s12
    v.cmp.lt     p2, v6, v1
    p.and        p3, p1, p2
    s.movz       s5, #15
    vf.mul       v6, v8, v5
    s.addi       s12, s1, #15
    s.addi       s13, s10, #960                  // row 15
    v.splat      v5, s12
    vf.cvt.f16.f32 v8, v7
    s.movz       s10, #15
    vf.mul       v7, v8, v4
    vf.add       v4, v6, v7
    vf.mul       v6, v4, v0
    s.addi       s12, s1, #15
    s.addi       s18, s14, #1920                 // row 15
    v.splat      v4, s12
    @p4 v.st.w       [s15, #0], v6
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    s.addi       s12, s2, #14336
    v.ld.w       v3, [s4, #0]
    a.vread      v6, a0, s6
    v.splat      v7, s17
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v8, [s9, #0]
    vf.cvt.f16.f32 v9, v3
    a.vread      v3, a1, s8
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    s.addi       s4, s2, #0
    vf.mul       v5, v9, v6
    s.muli       s6, s7, #64                     // a runtime tile origin, x64
    s.movz       s7, #64
    s.movz       s8, #0
    v.iota       v6                              // arange(0, VLEN)
    v.splat      v9, s7
    s.add        s7, s8, s6                      // the tile origin
    vf.cvt.f16.f32 v10, v8
    s.addi       s6, s2, #1024
    v.mul        v8, v6, v9
    v.splat      v6, s7
    vf.mul       v9, v10, v3
    v.add        v3, v8, v6
    vf.add       v6, v5, v9
    vf.mul       v5, v6, v0
    s.addi       s7, s2, #64
    s.addi       s8, s12, #64
    @p4 v.st.w       [s11, #0], v5
    v.cmp.lt     p2, v4, v1
    p.and        p4, p1, p2
    s.addi       s9, s2, #1088
    v.ld.w       v4, [s3, #0]
    a.vread      v5, a0, s5
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v6, [s13, #0]
    vf.cvt.f16.f32 v8, v4
    a.vread      v4, a1, s10
    vf.mul       v9, v8, v5
    s.addi       s3, s2, #128
    s.addi       s5, s2, #1152
    s.addi       s10, s12, #128
    vf.cvt.f16.f32 v5, v6
    vf.mul       v6, v5, v4
    vf.add       v4, v9, v6
    s.addi       s11, s12, #192
    vf.mul       v5, v4, v0
    s.addi       s13, s2, #192
    s.addi       s14, s2, #1216
    @p4 v.st.w       [s18, #0], v5
    s.addi       s15, s12, #256
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s2, #256
    s.addi       s17, s2, #1280
    v.ld.w       v4, [s6, #0]
    v.add        v5, v0, v3
    s.addi       s6, s2, #320
    v.mul        v0, v4, v2
    v.add        v4, v5, v0
    v.add        v0, v7, v4
    v.st.w       [s12, #0], v0
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s2, #1344
    v.ld.w       v4, [s9, #0]
    v.add        v5, v0, v3
    s.addi       s9, s12, #320
    v.mul        v0, v4, v2
    v.add        v4, v5, v0
    v.add        v0, v7, v4
    v.st.w       [s8, #0], v0
    s.addi       s8, s2, #384
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s2, #1408
    v.ld.w       v4, [s5, #0]
    v.add        v5, v0, v3
    s.addi       s5, s12, #384
    v.mul        v0, v4, v2
    v.add        v4, v5, v0
    v.add        v0, v7, v4
    v.st.w       [s10, #0], v0
    s.addi       s10, s2, #448
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s2, #1472
    v.ld.w       v4, [s14, #0]
    v.add        v5, v0, v3
    s.addi       s14, s12, #448
    v.mul        v0, v4, v2
    v.add        v4, v5, v0
    v.add        v0, v7, v4
    v.st.w       [s11, #0], v0
    s.addi       s11, s2, #512
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s2, #1536
    v.ld.w       v4, [s17, #0]
    v.add        v5, v0, v3
    s.addi       s17, s12, #512
    v.mul        v0, v4, v2
    v.add        v4, v5, v0
    v.add        v0, v7, v4
    v.st.w       [s15, #0], v0
    s.addi       s15, s2, #576
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s2, #1600
    v.ld.w       v4, [s7, #0]
    v.add        v5, v0, v3
    s.addi       s7, s12, #576
    v.mul        v0, v4, v2
    v.add        v4, v5, v0
    v.add        v0, v7, v4
    v.st.w       [s9, #0], v0
    s.addi       s9, s2, #640
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s2, #1664
    v.ld.w       v4, [s3, #0]
    v.add        v5, v0, v3
    s.addi       s3, s12, #640
    v.mul        v0, v4, v2
    v.add        v4, v5, v0
    v.add        v0, v7, v4
    v.st.w       [s5, #0], v0
    s.addi       s5, s2, #704
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s2, #1728
    v.ld.w       v4, [s13, #0]
    v.add        v5, v0, v3
    s.addi       s13, s12, #704
    v.mul        v0, v4, v2
    v.add        v4, v5, v0
    v.add        v0, v7, v4
    v.st.w       [s14, #0], v0
    s.addi       s14, s2, #768
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s2, #1792
    v.ld.w       v4, [s4, #0]
    v.add        v5, v0, v3
    s.addi       s4, s12, #768
    v.mul        v0, v4, v2
    v.add        v4, v5, v0
    v.add        v0, v7, v4
    v.st.w       [s17, #0], v0
    s.addi       s17, s2, #832
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s2, #1856
    v.ld.w       v4, [s6, #0]
    v.add        v5, v0, v3
    s.addi       s6, s12, #832
    v.mul        v0, v4, v2
    v.add        v4, v5, v0
    v.add        v0, v7, v4
    v.st.w       [s7, #0], v0
    s.addi       s7, s2, #896
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s2, #1920
    v.ld.w       v4, [s8, #0]
    v.add        v5, v0, v3
    s.addi       s8, s12, #896
    s.addi       s18, s12, #960
    v.mul        v0, v4, v2
    v.add        v4, v5, v0
    v.add        v0, v7, v4
    v.st.w       [s3, #0], v0
    s.addi       s3, s2, #960
    v.ld.w       v0, [s5, #0]
    s.addi       s5, s2, #1984
    v.ld.w       v4, [s10, #0]
    v.add        v5, v0, v3
    s.movz       s10, #0
    v.mul        v0, v4, v2
    v.add        v4, v5, v0
    v.splat      v0, s1
    v.add        v5, v7, v4
    v.cmp.lt     p2, v0, v1
    v.st.w       [s13, #0], v5
    s.addi       s12, s2, #14336
    p.and        p3, p1, p2
    v.ld.w       v0, [s14, #0]
    s.movz       s13, #1
    v.ld.w       v4, [s11, #0]
    v.add        v5, v0, v3
    s.addi       s11, s2, #14400
    v.mul        v0, v4, v2
    v.add        v4, v5, v0
    v.add        v0, v7, v4
    v.st.w       [s4, #0], v0
    s.addi       s4, s1, #1
    v.splat      v0, s4
    s.movz       s4, #2
    v.cmp.lt     p2, v0, v1
    p.and        p4, p1, p2
    v.ld.w       v0, [s17, #0]
    s.addi       s14, s2, #14464
    v.ld.w       v4, [s15, #0]
    v.add        v5, v0, v3
    s.addi       s15, s1, #2
    v.splat      v0, s15
    v.mul        v6, v4, v2
    v.add        v4, v5, v6
    v.add        v5, v7, v4
    v.st.w       [s6, #0], v5
    s.movz       s6, #3
    s.addi       s15, s2, #14528
    v.ld.w       v4, [s7, #0]
    v.ld.w       v5, [s9, #0]
    v.add        v6, v4, v3
    s.addi       s7, s1, #3
    v.splat      v4, s7
    v.mul        v8, v5, v2
    v.add        v5, v6, v8
    v.add        v6, v7, v5
    s.movz       s7, #4
    v.st.w       [s8, #0], v6
    s.addi       s8, s2, #14592
    v.ld.w       v5, [s3, #0]
    s.addi       s3, s1, #4
    v.ld.w       v6, [s5, #0]
    v.add        v8, v5, v3
    v.splat      v3, s3
    v.mul        v5, v6, v2
    v.add        v2, v8, v5
    s.movz       s3, #5
    v.add        v5, v7, v2
    v.st.w       [s18, #0], v5
    fence.acq_rel.device
    a.vread      v2, a2, s10
    s.addi       s5, s2, #14656
    s.addi       s9, s1, #5
    v.splat      v5, s9
    v.ld.w       v6, [s12, #0]
    s.movz       s9, #6
    @p3 v.st.scatter.w [s16, v6], v2
    a.vread      v2, a2, s13
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    s.addi       s10, s2, #14720
    s.addi       s12, s1, #6
    v.splat      v0, s12
    v.ld.w       v6, [s11, #0]
    s.movz       s11, #7
    @p4 v.st.scatter.w [s16, v6], v2
    a.vread      v2, a2, s4
    v.cmp.lt     p2, v4, v1
    p.and        p4, p1, p2
    s.addi       s4, s2, #14784
    s.addi       s12, s1, #7
    v.splat      v4, s12
    v.ld.w       v6, [s14, #0]
    s.movz       s12, #8
    @p3 v.st.scatter.w [s16, v6], v2
    a.vread      v2, a2, s6
    v.cmp.lt     p2, v3, v1
    p.and        p3, p1, p2
    s.addi       s6, s2, #14848
    s.addi       s13, s1, #8
    v.splat      v3, s13
    v.ld.w       v6, [s15, #0]
    s.movz       s13, #9
    @p4 v.st.scatter.w [s16, v6], v2
    a.vread      v2, a2, s7
    v.cmp.lt     p2, v5, v1
    p.and        p4, p1, p2
    s.addi       s7, s2, #14912
    s.addi       s14, s1, #9
    v.splat      v5, s14
    v.ld.w       v6, [s8, #0]
    s.movz       s8, #10
    @p3 v.st.scatter.w [s16, v6], v2
    a.vread      v2, a2, s3
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    s.addi       s3, s2, #14976
    s.addi       s14, s1, #10
    v.splat      v0, s14
    v.ld.w       v6, [s5, #0]
    s.movz       s5, #11
    @p4 v.st.scatter.w [s16, v6], v2
    a.vread      v2, a2, s9
    v.cmp.lt     p2, v4, v1
    p.and        p4, p1, p2
    s.addi       s9, s2, #15040
    s.addi       s14, s1, #11
    v.splat      v4, s14
    v.ld.w       v6, [s10, #0]
    s.movz       s10, #12
    @p3 v.st.scatter.w [s16, v6], v2
    a.vread      v2, a2, s11
    v.cmp.lt     p2, v3, v1
    p.and        p3, p1, p2
    s.addi       s11, s2, #15104
    s.addi       s14, s1, #12
    v.splat      v3, s14
    v.ld.w       v6, [s4, #0]
    s.movz       s4, #13
    @p4 v.st.scatter.w [s16, v6], v2
    a.vread      v2, a2, s12
    v.cmp.lt     p2, v5, v1
    p.and        p4, p1, p2
    s.addi       s12, s2, #15168
    s.addi       s14, s1, #13
    v.splat      v5, s14
    v.ld.w       v6, [s6, #0]
    s.movz       s6, #14
    @p3 v.st.scatter.w [s16, v6], v2
    a.vread      v2, a2, s13
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    s.addi       s13, s2, #15232
    s.addi       s14, s1, #14
    v.splat      v0, s14
    v.ld.w       v6, [s7, #0]
    s.movz       s7, #15
    @p4 v.st.scatter.w [s16, v6], v2
    a.vread      v2, a2, s8
    v.cmp.lt     p2, v4, v1
    p.and        p4, p1, p2
    s.addi       s8, s2, #15296
    s.addi       s2, s1, #15
    v.splat      v4, s2
    v.ld.w       v6, [s3, #0]
    @p3 v.st.scatter.w [s16, v6], v2
    a.vread      v2, a2, s5
    v.cmp.lt     p2, v3, v1
    p.and        p3, p1, p2
    v.ld.w       v3, [s9, #0]
    @p4 v.st.scatter.w [s16, v3], v2
    a.vread      v2, a2, s10
    v.cmp.lt     p2, v5, v1
    p.and        p4, p1, p2
    v.ld.w       v3, [s11, #0]
    @p3 v.st.scatter.w [s16, v3], v2
    a.vread      v2, a2, s4
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    v.ld.w       v0, [s12, #0]
    @p4 v.st.scatter.w [s16, v0], v2
    a.vread      v0, a2, s6
    v.cmp.lt     p2, v4, v1
    p.and        p4, p1, p2
    v.ld.w       v1, [s13, #0]
    @p3 v.st.scatter.w [s16, v1], v0
    a.vread      v0, a2, s7
    v.ld.w       v1, [s8, #0]
    @p4 v.st.scatter.w [s16, v1], v0
__rctx_next:
    exit
