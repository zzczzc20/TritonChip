    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // out_ptr0: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // out_ptr1: device_ptr64 at arg_base+32
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.add        v2, v1, v0
    v.movi       v0, #1920
    v.cmp.lt     p1, v2, v0
    v.movi       v0, #32
    v.movi       v1, #0
    v.cmp.lt     p2, v2, v1
    v.cmp.lt     p3, v0, v1
    v.sub        v3, v1, v2
    @p2 v.sel        v4, v3, v2
    v.sub        v3, v1, v0
    @p3 v.sel        v5, v3, v0
    v.movi       v3, #31
    v.and        v5, v4, v3
    v.sub        v3, v1, v5
    @p2 v.sel        v1, v3, v5
    v.movi       v3, #0
    v.cmp.lt     p2, v2, v3
    v.cmp.lt     p3, v0, v3
    v.sub        v4, v3, v2
    @p2 v.sel        v5, v4, v2
    v.sub        v4, v3, v0
    @p3 v.sel        v6, v4, v0
    v.movi       v4, #5
    v.lshr       v6, v5, v4
    v.sub        v4, v3, v6
    @p2 v.sel        v3, v4, v6
    v.movi       v4, #4
    v.movi       v5, #0
    v.cmp.lt     p2, v3, v5
    v.cmp.lt     p3, v4, v5
    v.sub        v6, v5, v3
    @p2 v.sel        v7, v6, v3
    v.sub        v6, v5, v4
    @p3 v.sel        v8, v6, v4
    v.movi       v4, #3
    v.and        v6, v7, v4
    v.sub        v4, v5, v6
    @p2 v.sel        v5, v4, v6
    v.movi       v4, #128
    v.movi       v6, #0
    v.cmp.lt     p2, v2, v6
    v.cmp.lt     p3, v4, v6
    v.sub        v7, v6, v2
    @p2 v.sel        v8, v7, v2
    v.sub        v2, v6, v4
    @p3 v.sel        v7, v2, v4
    v.movi       v2, #7
    v.lshr       v4, v8, v2
    v.sub        v2, v6, v4
    @p2 v.sel        v6, v2, v4
    v.add        v2, v1, v0
    v.movi       v0, #256
    v.mul        v4, v3, v0
    v.add        v0, v2, v4
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v7, [s2, v0]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v0, v7
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v7, [s3, v3]               // index is in elements (ISA sec 9.1)
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v3, [s5, v2]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v2, v3
    v.add        v3, v1, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v4, [s2, v3]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v3, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v4, [s5, v1]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v8, v4
    .li       s1, #1132462080
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v9, v4                          // ISA 8.8: <= 2**-22 relative
    .li       s1, #1065353216
    v.splat      v10, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v11, v4, v9, v10
    vf.fms       v10, v9, v11, v9
    vf.neg       v11, v10                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v11, v11
    @p2 v.sel        v10, v11, v9
    vf.mul       v9, v7, v10                     // a/y: faithful quotient
    vf.fms       v11, v9, v4, v7
    vf.fms       v4, v11, v10, v9
    vf.neg       v7, v4                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v7, v7
    @p2 v.sel        v4, v7, v9
    .li       s1, #897988541
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v9, v4, v7
    v.rsqrt.approx v4, v9                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v7, v4, v4
    .li       s1, #1077936128
    v.splat      v10, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v11, v9, v7, v10
    .li       s1, #3204448256
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v9, v4, v7
    vf.mul       v7, v9, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v7, v7
    @p2 v.sel        v9, v7, v4
    vf.mul       v4, v0, v9
    .li       s1, #1065353216
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v7, v2, v0
    vf.mul       v2, v4, v7
    vf.neg       v4, v2
    vf.mul       v2, v3, v9
    vf.add       v3, v8, v0
    vf.mul       v0, v2, v3
    v.movi       v2, #64
    v.mul        v3, v6, v2
    v.add        v2, v1, v3
    v.movi       v1, #960
    v.mul        v3, v5, v1
    v.add        v1, v2, v3
    vf.cvt.f32.bf16 v2, v4
    @p1 v.st.scatter.h [s6, v1], v2
    vf.cvt.f32.bf16 v2, v0
    @p1 v.st.scatter.h [s7, v1], v2
__rctx_next:
    exit
