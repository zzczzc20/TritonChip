    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    v.movi       v1, #0
    v.movi       v2, #5
    v.movi       v3, #0
    v.movi       v4, #0
    v.splat      v5, s2
    v.movi       v6, #0
    v.add        v7, v5, v0
    v.movi       v0, #31
    v.sub        v5, v1, v7
    v.cmp.lt     p1, v7, v1
    @p1 v.sel        v8, v5, v7
    v.sub        v5, v4, v7
    v.lshr       v9, v8, v2
    v.cmp.lt     p2, v7, v4
    v.sub        v2, v1, v9
    @p2 v.sel        v8, v5, v7
    @p1 v.sel        v5, v2, v9
    v.movi       v2, #63
    v.sub        v9, v6, v5
    v.cmp.lt     p1, v5, v6
    @p1 v.sel        v10, v9, v5
    v.movi       v5, #32
    v.and        v9, v8, v0
    v.movi       v0, #64
    v.and        v8, v10, v2
    v.movi       v2, #2048
    s.rdspecial  s1, arg_base
    v.sub        v10, v4, v5
    v.sub        v11, v4, v9
    v.sub        v12, v1, v5
    v.sub        v13, v6, v0
    v.cmp.lt     p3, v5, v4
    v.sub        v4, v6, v8
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v14, #1
    @p3 v.sel        v14, v10, v5
    v.cmp.lt     p3, v7, v3
    s.ld.d       s4, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.sub        v10, v3, v7
    @p2 v.sel        v14, v11, v9
    @p3 v.sel        v9, v10, v7
    v.movi       v7, #11
    v.movi       v10, #3
    v.lshr       v11, v9, v7
    v.movi       v7, #0
    v.cmp.lt     p2, v5, v1
    v.sub        v1, v3, v11
    v.movi       v9, #1
    @p3 v.sel        v9, v1, v11
    v.sub        v1, v3, v2
    v.cmp.lt     p3, v0, v6
    v.sub        v6, v7, v9
    @p2 v.sel        v11, v12, v5
    v.sub        v11, v7, v10
    v.cmp.lt     p2, v2, v3
    v.movi       v3, #1
    @p3 v.sel        v3, v13, v0
    v.cmp.lt     p3, v9, v7
    @p1 v.sel        v3, v4, v8
    v.cmp.lt     p1, v10, v7
    v.movi       v4, #1
    @p2 v.sel        v4, v1, v2
    v.movi       v1, #1
    @p3 v.sel        v2, v6, v9
    @p1 v.sel        v4, v11, v10
    v.movi       v6, #0
    v.movi       v8, #0
    s.movz       s1, #31
idiv_1:
    v.splat      v9, s1
    v.shl        v10, v8, v1
    v.lshr       v11, v2, v9
    v.cmp.lt     p2, v8, v7
    v.and        v12, v11, v1
    v.shl        v11, v1, v9
    v.or         v9, v10, v12
    s.subi       s5, s1, #1
    v.cmp.geu    p4, v9, v4
    p.or         p5, p2, p4
    v.sub        v10, v9, v4
    @p5 v.sel        v12, v11, v7
    @p5 v.sel        v11, v10, v9
    v.or         v9, v6, v12
    v.mov        v8, v11
    v.mov        v6, v9
    s.mov        s1, s5
    s.movz       s5, #0
    s.cmp.ge     s6, s1, s5
    br.nz        s6, idiv_1
    p.xor        p2, p3, p1
    v.sub        v1, v7, v6
    v.mul        v2, v3, v0
    @p2 v.sel        v0, v1, v6
    s.shli       s1, s2, #2                      // element offset -> bytes (x4)
    v.mul        v1, v0, v5
    s.add        s2, s4, s1                      // &out_ptr0[...]
    v.add        v0, v14, v1
    s.movz       s1, #32
    v.add        v1, v0, v2
    s.movz       s1, #64
    v.ld.gather.h v0, [s3, v1]                   // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v1, v0
    v.st.w       [s2, #0], v1
__rctx_next:
    exit
