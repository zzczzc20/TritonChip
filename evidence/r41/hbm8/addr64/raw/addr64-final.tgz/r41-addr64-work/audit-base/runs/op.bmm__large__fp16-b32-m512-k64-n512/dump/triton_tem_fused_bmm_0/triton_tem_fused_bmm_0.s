    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s3, s4, s1
    s.movz       s1, #32
    s.movz       s5, #0
    s.sub        s6, s2, s3
    s.movz       s2, #0
    s.cmp.lt     s3, s1, s5
    s.xor        s5, s4, s6
    s.sub        s7, s2, s3
    s.sub        s2, s5, s6
    s.xor        s3, s6, s7
    s.lshri      s5, s2, #5
    s.movz       s6, #1
    s.xor        s8, s5, s3
    s.movz       s9, #0
    s.sub        s10, s8, s3
    s.movz       s3, #0
    s.sub        s8, s1, s10
    s.movz       s11, #0
    s.min.s      s12, s8, s6
    s.movz       s6, #0
    s.cmp.lt     s8, s12, s9
    s.cmp.lt     s9, s4, s3
    s.sub        s3, s11, s8
    s.sub        s8, s6, s9
    s.xor        s6, s12, s3
    s.muli       s9, s5, #32
    s.movz       s5, #0
    s.movz       s11, #1
    s.xor        s13, s4, s8
    s.sub        s14, s6, s3
    s.rdspecial  s3, arg_base
    s.xor        s6, s1, s7
    s.movz       s15, #0
    s.sub        s16, s13, s8
    s.addi       s13, s5, #0
    s.cmp.eq     s5, s14, s11
    s.ld.d       s11, [s3, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.sub        s17, s6, s7
    s.sub        s6, s2, s9
    s.addi       s2, s15, #0
    s.ld.d       s6, [s3, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s7, [s3, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.mov        s13, s16
    br.nz        s5, sdiv_done_1
    s.movz       s3, #0
    s.movz       s5, #31
    s.mov        s13, s3
    s.addi       s3, s5, #0
sdiv_2:
    s.lshr       s5, s16, s3
    s.shli       s9, s2, #1
    s.andi       s15, s5, #1
    s.movz       s5, #0
    s.or         s17, s9, s15
    s.movz       s9, #1
    s.cmp.geu    s15, s17, s14
    s.shl        s18, s9, s3
    s.sub        s9, s5, s15
    s.subi       s5, s3, #1
    s.and        s15, s14, s9
    s.and        s19, s18, s9
    s.sub        s9, s17, s15
    s.or         s15, s13, s19
    s.mov        s2, s9
    s.mov        s13, s15
    s.mov        s3, s5
    s.movz       s5, #0
    s.cmp.ge     s9, s3, s5
    br.nz        s9, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s5, #0
    s.cmp.lt     s9, s4, s3
    s.movz       s3, #0
    s.sub        s13, s5, s9
    s.movz       s5, #0
    s.xor        s9, s4, s13
    s.movz       s4, #0
    s.sub        s14, s9, s13
    s.cmp.lt     s9, s12, s3
    s.lshri      s3, s14, #5
    s.movz       s15, #0
    s.muli       s16, s3, #32
    s.movz       s3, #0
    s.sub        s17, s4, s9
    s.movz       s4, #0
    s.cmp.lt     s9, s1, s15
    s.sub        s15, s14, s16
    s.xor        s14, s12, s17
    s.xor        s12, s15, s13
    s.xor        s15, s2, s8
    s.sub        s2, s12, s13
    s.sub        s12, s4, s9
    s.cmp.lt     s4, s2, s5
    s.sub        s5, s14, s17
    s.sub        s9, s3, s4
    s.movz       s3, #0
    s.xor        s4, s2, s9
    s.movz       s2, #1
    s.sub        s13, s15, s8
    s.xor        s8, s1, s12
    s.sub        s14, s4, s9
    s.movz       s4, #0
    s.addi       s15, s3, #0
    s.cmp.eq     s3, s5, s2
    s.add        s2, s10, s13
    s.sub        s10, s8, s12
    s.addi       s8, s4, #0
    s.mov        s15, s14
    br.nz        s3, sdiv_done_3
    s.movz       s3, #0
    s.movz       s4, #31
    s.mov        s15, s3
    s.addi       s3, s4, #0
sdiv_4:
    s.lshr       s4, s14, s3
    s.shli       s10, s8, #1
    s.andi       s12, s4, #1
    s.movz       s4, #0
    s.or         s13, s10, s12
    s.movz       s10, #1
    s.cmp.geu    s12, s13, s5
    s.shl        s16, s10, s3
    s.sub        s10, s4, s12
    s.subi       s4, s3, #1
    s.and        s12, s5, s10
    s.and        s18, s16, s10
    s.sub        s10, s13, s12
    s.or         s12, s15, s18
    s.mov        s8, s10
    s.mov        s15, s12
    s.mov        s3, s4
    s.movz       s4, #0
    s.cmp.ge     s10, s3, s4
    br.nz        s10, sdiv_4
sdiv_done_3:
    s.movz       s3, #16
    s.rdspecial  s4, pid.z
    s.rdspecial  s5, npid.y
    s.xor        s8, s9, s17
    s.mul        s9, s2, s3
    s.mul        s10, s4, s5
    s.xor        s4, s15, s8
    s.rdspecial  s5, pid.y
    s.sub        s12, s4, s8
    s.andi       s4, s9, #511
    s.mul        s8, s12, s3
    s.add        s13, s5, s10
    s.movz       s5, #31
    s.rdspecial  s10, arg_base
    s.min.s      s14, s13, s5
    s.movz       s5, #32768
    s.ld.d       s15, [s10, #24]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.muli       s10, s4, #64                    // a runtime tile origin, x64
    s.mul        s16, s14, s5
    s.andi       s5, s8, #511
    s.movz       s14, #0
    s.rdspecial  s17, role_id
    s.movz       s18, #9728
    s.add        s19, s14, s10                   // the tile origin
    s.mul        s10, s17, s18
    s.add        s14, s19, s16                   // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s14
    s.movz       s17, #0
    s.add        s18, s15, s10                   // this context's own scratch
    v.splat      v2, s2
    s.addi       s2, s18, #0
    v.splat      v3, s17
    s.addi       s10, s14, #64
    v.splat      v4, s12
    v.splat      v5, s17
    v.add        v6, v0, v1
    s.addi       s12, s2, #64
    v.cmp.ge     p1, v2, v3
    v.splat      v1, s10
    v.iota       v2                              // arange(0, VLEN)
    v.cmp.ge     p1, v4, v5
    s.addi       s10, s14, #128
    v.splat      v3, s9
    v.splat      v4, s10
    v.add        v5, v0, v1
    s.addi       s10, s2, #128
    v.add        v1, v0, v4
    v.add        v4, v3, v2
    s.addi       s15, s14, #192
    v.splat      v3, s8
    s.addi       s19, s2, #192
    s.movz       s20, #64
    v.add        v4, v3, v2
    v.splat      v2, s15
    v.splat      v3, s4
    s.addi       s4, s2, #256
    v.add        v4, v0, v2
    s.addi       s15, s17, #0
    v.st.w       [s2, #0], v6
    v.iota       v2                              // arange(0, VLEN)
    s.addi       s17, s14, #256
    v.add        v6, v3, v2
    v.splat      v2, s17
    v.splat      v3, s5
    v.add        v6, v0, v2
    v.st.w       [s12, #0], v5
    v.iota       v2                              // arange(0, VLEN)
    s.addi       s12, s2, #320
    v.add        v5, v3, v2
    s.addi       s17, s14, #320
    s.addi       s21, s14, #384
    v.splat      v2, s17
    s.addi       s17, s14, #448
    v.splat      v3, s21
    s.addi       s21, s14, #512
    v.add        v5, v0, v2
    v.add        v2, v0, v3
    v.st.w       [s10, #0], v1
    s.addi       s10, s14, #576
    v.splat      v1, s17
    s.addi       s17, s14, #640
    v.add        v3, v0, v1
    v.st.w       [s19, #0], v4
    s.addi       s19, s14, #704
    v.splat      v1, s21
    s.addi       s21, s14, #768
    v.add        v4, v0, v1
    v.st.w       [s4, #0], v6
    s.addi       s4, s14, #832
    v.splat      v1, s10
    s.addi       s10, s14, #896
    s.addi       s22, s14, #960
    v.add        v6, v0, v1
    v.st.w       [s12, #0], v5
    v.splat      v1, s17
    s.addi       s12, s2, #384
    s.addi       s14, s18, #1024
    v.add        v5, v0, v1
    v.st.w       [s12, #0], v2
    s.movz       s12, #0
    v.splat      v1, s19
    s.addi       s17, s2, #448
    s.add        s19, s12, s5                    // the tile origin
    v.add        v2, v0, v1
    s.add        s5, s19, s16                    // the tile origin
    s.addi       s12, s2, #512
    s.addi       s16, s2, #576
    v.st.w       [s17, #0], v3
    s.addi       s17, s5, #512
    v.splat      v1, s21
    s.addi       s19, s2, #640
    v.add        v3, v0, v1
    v.st.w       [s12, #0], v4
    s.addi       s12, s5, #1024
    v.splat      v1, s4
    s.addi       s4, s2, #704
    v.add        v4, v0, v1
    v.st.w       [s16, #0], v6
    s.addi       s16, s5, #1536
    v.splat      v1, s10
    s.addi       s10, s2, #768
    v.add        v6, v0, v1
    v.st.w       [s19, #0], v5
    s.addi       s19, s5, #2048
    v.splat      v1, s22
    s.addi       s21, s2, #832
    v.add        v5, v0, v1
    v.st.w       [s4, #0], v2
    s.addi       s4, s5, #2560
    v.splat      v1, s5
    v.add        v2, v0, v1
    v.st.w       [s10, #0], v3
    s.addi       s10, s5, #3072
    v.splat      v1, s17
    s.addi       s17, s2, #896
    s.addi       s22, s2, #960
    v.add        v3, v0, v1
    v.st.w       [s21, #0], v4
    s.addi       s2, s5, #3584
    v.splat      v1, s12
    s.addi       s12, s14, #64
    v.add        v4, v0, v1
    v.st.w       [s17, #0], v6
    s.addi       s17, s5, #4096
    v.splat      v1, s16
    s.addi       s16, s14, #128
    v.add        v6, v0, v1
    v.st.w       [s22, #0], v5
    v.splat      v1, s19
    s.addi       s19, s14, #192
    s.addi       s21, s14, #256
    v.add        v5, v0, v1
    fence.acq_rel.device
    v.st.w       [s14, #0], v2
    v.splat      v1, s4
    s.addi       s4, s5, #4608
    v.add        v2, v0, v1
    v.st.w       [s12, #0], v3
    s.addi       s12, s5, #5120
    v.splat      v1, s10
    s.addi       s10, s5, #5632
    v.add        v3, v0, v1
    v.st.w       [s16, #0], v4
    s.addi       s16, s5, #6144
    v.splat      v1, s2
    s.addi       s2, s5, #6656
    v.add        v4, v0, v1
    v.st.w       [s19, #0], v6
    s.addi       s19, s5, #7168
    v.splat      v1, s17
    s.addi       s17, s14, #320
    v.add        v6, v0, v1
    v.st.w       [s21, #0], v5
    s.addi       s21, s5, #7680
    v.splat      v1, s4
    s.addi       s4, s14, #384
    s.addi       s5, s14, #448
    v.add        v5, v0, v1
    v.st.w       [s17, #0], v2
    v.splat      v1, s12
    s.addi       s12, s14, #512
    s.addi       s17, s14, #576
    v.add        v2, v0, v1
    v.st.w       [s4, #0], v3
    v.splat      v1, s10
    s.addi       s4, s14, #640
    s.addi       s10, s14, #704
    v.add        v3, v0, v1
    v.st.w       [s5, #0], v4
    v.splat      v1, s16
    s.addi       s5, s14, #768
    s.addi       s16, s14, #832
    v.add        v4, v0, v1
    v.st.w       [s12, #0], v6
    v.splat      v1, s2
    s.addi       s2, s14, #896
    s.addi       s12, s14, #960
    v.add        v6, v0, v1
    v.st.w       [s17, #0], v5
    v.splat      v1, s19
    v.add        v5, v0, v1
    v.st.w       [s4, #0], v2
    v.splat      v1, s21
    v.add        v2, v0, v1
    v.st.w       [s10, #0], v3
    v.st.w       [s5, #0], v4
    v.st.w       [s16, #0], v6
    v.st.w       [s2, #0], v5
    v.st.w       [s12, #0], v2
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s2, s15, s20
    br.nz        s2, endfor_6
    s.addi       s2, s18, #0
    s.addi       s4, s18, #2048
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #64
    s.addi       s5, s4, #64
    s.addi       s10, s18, #128
    s.addi       s12, s4, #128
    s.addi       s14, s18, #192
    s.addi       s16, s4, #192
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s4, #0], v2
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #256
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v2
    s.addi       s5, s4, #256
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s18, #320
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s12, s4, #320
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s18, #384
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v2
    s.addi       s16, s4, #384
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #448
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v2
    s.addi       s5, s4, #448
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s18, #512
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s12, s4, #512
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s18, #576
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v2
    s.addi       s16, s4, #576
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #640
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v2
    s.addi       s5, s4, #640
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s18, #704
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s12, s4, #704
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s18, #768
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v2
    s.addi       s16, s4, #768
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #832
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v2
    s.addi       s5, s4, #832
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s18, #896
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s12, s4, #896
    s.addi       s17, s4, #960
    v.ld.w       v1, [s14, #0]
    s.addi       s4, s18, #960
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v2
    s.addi       s14, s18, #1024
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #3072
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v2
    s.addi       s5, s18, #1088
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s2, #64
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s12, s18, #1152
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s2, #128
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    s.addi       s16, s18, #1216
    v.st.w       [s17, #0], v2
    fence.acq_rel.device
    s.addi       s17, s2, #192
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s18, #1280
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s2, #0], v2
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s2, #256
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s10, #0], v2
    s.addi       s10, s18, #1344
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s2, #320
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s4, #0], v2
    s.addi       s4, s18, #1408
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s2, #384
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s17, #0], v2
    s.addi       s17, s18, #1472
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s2, #448
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v2
    s.addi       s5, s18, #1536
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s2, #512
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s12, s18, #1600
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s2, #576
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v2
    s.addi       s16, s18, #1664
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s2, #640
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s18, #1728
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s2, #704
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s10, #0], v2
    s.addi       s10, s18, #1792
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s2, #768
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s4, #0], v2
    s.addi       s4, s18, #1856
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s2, #832
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s17, #0], v2
    s.addi       s17, s18, #1920
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s2, #896
    s.addi       s19, s2, #960
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v2
    s.addi       s2, s18, #1984
    v.ld.w       v1, [s10, #0]
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    s.addi       s5, s18, #2048
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s10, s18, #4096                 // 512 bytes of repack scratch
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #2112
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v2
    s.addi       s12, s10, #32                   // row 1
    v.ld.w       v1, [s17, #0]
    s.addi       s16, s18, #2176
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s10, #64                   // row 2
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #2240
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s17, s10, #96                   // row 3
    v.st.w       [s19, #0], v2
    fence.acq_rel.device
    s.addi       s19, s18, #2304
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s10, #128                   // row 4
    v.st.h       [s10, #0], v1
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #2368
    v.st.h       [s12, #0], v1
    s.addi       s12, s10, #160                  // row 5
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s18, #2432
    v.st.h       [s14, #0], v1
    s.addi       s14, s10, #192                  // row 6
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #2496
    v.st.h       [s17, #0], v1
    s.addi       s17, s10, #224                  // row 7
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s18, #2560
    s.movz       s21, #0
    v.st.h       [s5, #0], v1
    s.addi       s5, s10, #256                   // row 8
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #2624
    v.st.h       [s12, #0], v1
    s.addi       s12, s10, #288                  // row 9
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s18, #2688
    v.st.h       [s14, #0], v1
    s.addi       s14, s10, #320                  // row 10
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #2752
    v.st.h       [s17, #0], v1
    s.addi       s17, s10, #352                  // row 11
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s18, #2816
    v.st.h       [s5, #0], v1
    s.addi       s5, s10, #384                   // row 12
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #2880
    v.st.h       [s12, #0], v1
    s.addi       s12, s10, #416                  // row 13
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s18, #2944
    v.st.h       [s14, #0], v1
    s.addi       s14, s10, #448                  // row 14
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #3008
    v.st.h       [s17, #0], v1
    s.addi       s17, s10, #480                  // row 15
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s18, #4608                 // TensorMap 0: a repacked tile
    v.st.h       [s5, #0], v1
    s.movz       s5, #16
    v.ld.w       v1, [s4, #0]
    s.movz       s4, #16
    v.st.h       [s12, #0], v1
    s.movz       s12, #32
    v.ld.w       v1, [s16, #0]
    s.movz       s16, #2
    v.st.h       [s14, #0], v1
    .li       s14, #68719476752
    v.ld.w       v1, [s2, #0]
    .li       s2, #8589934592
    v.st.h       [s17, #0], v1
    s.movz       s17, #0
    s.st.d       [s19, #0], s10
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    s.addi       s10, s18, #3072
    s.st.d       [s19, #8], s5
    s.addi       s5, s18, #4864                  // 512 bytes of repack scratch
    s.st.d       [s19, #16], s4
    s.addi       s4, s18, #3136
    s.st.d       [s19, #48], s12
    s.addi       s12, s5, #32                    // row 1
    s.st.d       [s19, #56], s16
    s.addi       s16, s18, #3200
    s.st.d       [s19, #88], s14
    s.addi       s14, s5, #64                    // row 2
    s.st.d       [s19, #104], s2
    fence.release.device
    td.load      d0, [s19]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s2, b0, #0, #1                  // 0 arrival(s), 1 operation(s)
    s.addi       s19, s18, #3264
    s.addi       s21, s5, #96                    // row 3
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s22, s17                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s23, s17                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s22, s2
    mb.wait      s2
    s.addi       s17, s18, #3328
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s5, #128                   // row 4
    v.st.h       [s5, #0], v1
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #3392
    v.st.h       [s12, #0], v1
    s.addi       s12, s5, #160                   // row 5
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s18, #3456
    v.st.h       [s14, #0], v1
    s.addi       s14, s5, #192                   // row 6
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s18, #3520
    v.st.h       [s21, #0], v1
    s.addi       s21, s5, #224                   // row 7
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s18, #3584
    s.movz       s22, #0
    v.st.h       [s10, #0], v1
    s.addi       s10, s5, #256                   // row 8
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #3648
    v.st.h       [s12, #0], v1
    s.addi       s12, s5, #288                   // row 9
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s18, #3712
    v.st.h       [s14, #0], v1
    s.addi       s14, s5, #320                   // row 10
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s18, #3776
    v.st.h       [s21, #0], v1
    s.addi       s21, s5, #352                   // row 11
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s18, #3840
    v.st.h       [s10, #0], v1
    s.addi       s10, s5, #384                   // row 12
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #3904
    v.st.h       [s12, #0], v1
    s.addi       s12, s5, #416                   // row 13
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s18, #3968
    v.st.h       [s14, #0], v1
    s.addi       s14, s5, #448                   // row 14
    v.splat      v1, s3
    v.ld.w       v2, [s19, #0]
    s.addi       s19, s18, #4032
    v.st.h       [s21, #0], v2
    s.addi       s21, s5, #480                   // row 15
    v.ld.w       v2, [s17, #0]
    s.addi       s17, s18, #5376                 // TensorMap 1: a repacked tile
    v.st.h       [s10, #0], v2
    s.movz       s10, #16
    v.ld.w       v2, [s4, #0]
    s.movz       s4, #16
    v.st.h       [s12, #0], v2
    s.movz       s12, #32
    v.ld.w       v2, [s16, #0]
    s.movz       s16, #2
    v.st.h       [s14, #0], v2
    .li       s14, #68719476752
    v.ld.w       v2, [s19, #0]
    .li       s19, #8589934592
    v.st.h       [s21, #0], v2
    s.movz       s21, #0
    s.st.d       [s17, #0], s5
    s.addi       s5, s18, #0
    s.st.d       [s17, #8], s10
    s.addi       s10, s18, #5632
    s.st.d       [s17, #16], s4
    s.addi       s4, s18, #64
    s.st.d       [s17, #48], s12
    s.addi       s12, s10, #64
    s.st.d       [s17, #56], s16
    s.addi       s16, s18, #128
    s.st.d       [s17, #88], s14
    s.addi       s14, s10, #128
    s.st.d       [s17, #104], s19
    fence.release.device
    td.load      d1, [s17]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s17, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s19, s18, #192
    s.addi       s22, s10, #192
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s23, s21                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s24, s21                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s23, s17
    mb.wait      s17
    mb.arm       s21, b2, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s23, s18, #256
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.f16 a0, v56, v48, s21
    mb.wait      s21
    v.ld.w       v2, [s5, #0]
    s.addi       s5, s10, #256
    v.add        v3, v2, v1
    v.st.w       [s10, #0], v3
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s18, #320
    v.add        v3, v2, v1
    v.st.w       [s12, #0], v3
    s.addi       s12, s10, #320
    v.ld.w       v2, [s16, #0]
    s.addi       s16, s18, #384
    v.add        v3, v2, v1
    v.st.w       [s14, #0], v3
    s.addi       s14, s10, #384
    v.ld.w       v2, [s19, #0]
    s.addi       s19, s18, #448
    v.add        v3, v2, v1
    v.st.w       [s22, #0], v3
    s.addi       s22, s10, #448
    v.ld.w       v2, [s23, #0]
    s.addi       s23, s18, #512
    v.add        v3, v2, v1
    v.st.w       [s5, #0], v3
    s.addi       s5, s10, #512
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s18, #576
    v.add        v3, v2, v1
    v.st.w       [s12, #0], v3
    s.addi       s12, s10, #576
    v.ld.w       v2, [s16, #0]
    s.addi       s16, s18, #640
    v.add        v3, v2, v1
    v.st.w       [s14, #0], v3
    s.addi       s14, s10, #640
    v.ld.w       v2, [s19, #0]
    s.addi       s19, s18, #704
    v.add        v3, v2, v1
    v.st.w       [s22, #0], v3
    s.addi       s22, s10, #704
    v.ld.w       v2, [s23, #0]
    s.addi       s23, s18, #768
    v.add        v3, v2, v1
    v.st.w       [s5, #0], v3
    s.addi       s5, s10, #768
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s18, #832
    v.add        v3, v2, v1
    v.st.w       [s12, #0], v3
    s.addi       s12, s10, #832
    v.ld.w       v2, [s16, #0]
    s.addi       s16, s18, #896
    v.add        v3, v2, v1
    v.st.w       [s14, #0], v3
    s.addi       s14, s10, #896
    s.addi       s24, s10, #960
    v.ld.w       v2, [s19, #0]
    s.addi       s10, s18, #960
    v.add        v3, v2, v1
    v.st.w       [s22, #0], v3
    s.addi       s19, s18, #1024
    v.ld.w       v2, [s23, #0]
    s.movz       s22, #8192
    v.splat      v3, s22
    s.addi       s22, s18, #6656
    v.add        v4, v2, v1
    v.st.w       [s5, #0], v4
    s.addi       s5, s18, #1088
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s22, #64
    v.add        v4, v2, v1
    v.st.w       [s12, #0], v4
    s.addi       s12, s18, #1152
    v.ld.w       v2, [s16, #0]
    s.addi       s16, s22, #128
    v.add        v4, v2, v1
    v.st.w       [s14, #0], v4
    s.addi       s14, s18, #1216
    v.ld.w       v2, [s10, #0]
    s.addi       s10, s22, #192
    v.add        v4, v2, v1
    v.st.w       [s24, #0], v4
    fence.acq_rel.device
    s.addi       s23, s18, #1280
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s22, #256
    v.add        v2, v1, v3
    v.st.w       [s22, #0], v2
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s18, #1344
    v.add        v2, v1, v3
    v.st.w       [s4, #0], v2
    s.addi       s4, s22, #320
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s18, #1408
    v.add        v2, v1, v3
    v.st.w       [s16, #0], v2
    s.addi       s16, s22, #384
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s18, #1472
    v.add        v2, v1, v3
    v.st.w       [s10, #0], v2
    s.addi       s10, s22, #448
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s18, #1536
    v.add        v2, v1, v3
    v.st.w       [s19, #0], v2
    s.addi       s19, s22, #512
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s18, #1600
    v.add        v2, v1, v3
    v.st.w       [s4, #0], v2
    s.addi       s4, s22, #576
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s18, #1664
    v.add        v2, v1, v3
    v.st.w       [s16, #0], v2
    s.addi       s16, s22, #640
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s18, #1728
    v.add        v2, v1, v3
    v.st.w       [s10, #0], v2
    s.addi       s10, s22, #704
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s18, #1792
    v.add        v2, v1, v3
    v.st.w       [s19, #0], v2
    s.addi       s19, s22, #768
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s18, #1856
    v.add        v2, v1, v3
    v.st.w       [s4, #0], v2
    s.addi       s4, s22, #832
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s18, #1920
    v.add        v2, v1, v3
    v.st.w       [s16, #0], v2
    s.addi       s16, s22, #896
    s.addi       s24, s22, #960
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s18, #1984
    v.add        v2, v1, v3
    v.st.w       [s10, #0], v2
    s.addi       s10, s18, #5632
    v.ld.w       v1, [s23, #0]
    s.addi       s22, s18, #7680
    v.add        v2, v1, v3
    v.st.w       [s19, #0], v2
    s.addi       s19, s18, #5696
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s22, #64
    v.add        v2, v1, v3
    v.st.w       [s4, #0], v2
    s.addi       s4, s18, #5760
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s22, #128
    v.add        v2, v1, v3
    v.st.w       [s16, #0], v2
    s.addi       s16, s18, #5824
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s22, #192
    v.add        v2, v1, v3
    v.st.w       [s24, #0], v2
    fence.acq_rel.device
    s.addi       s23, s18, #5888
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s22, #256
    v.st.w       [s22, #0], v1
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s18, #5952
    v.st.w       [s5, #0], v1
    s.addi       s5, s22, #320
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #6016
    v.st.w       [s12, #0], v1
    s.addi       s12, s22, #384
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s18, #6080
    v.st.w       [s14, #0], v1
    s.addi       s14, s22, #448
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s18, #6144
    v.st.w       [s10, #0], v1
    s.addi       s10, s22, #512
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s18, #6208
    v.st.w       [s5, #0], v1
    s.addi       s5, s22, #576
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #6272
    v.st.w       [s12, #0], v1
    s.addi       s12, s22, #640
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s18, #6336
    v.st.w       [s14, #0], v1
    s.addi       s14, s22, #704
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s18, #6400
    v.st.w       [s10, #0], v1
    s.addi       s10, s22, #768
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s18, #6464
    v.st.w       [s5, #0], v1
    s.addi       s5, s22, #832
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #6528
    v.st.w       [s12, #0], v1
    s.addi       s12, s22, #896
    s.addi       s24, s22, #960
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s18, #6592
    v.st.w       [s14, #0], v1
    s.addi       s14, s18, #6656
    v.ld.w       v1, [s23, #0]
    s.addi       s22, s18, #8704
    v.st.w       [s10, #0], v1
    s.addi       s10, s18, #6720
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s22, #64
    v.st.w       [s5, #0], v1
    s.addi       s5, s18, #6784
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s22, #128
    v.st.w       [s12, #0], v1
    s.addi       s12, s18, #6848
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s22, #192
    v.st.w       [s24, #0], v1
    fence.acq_rel.device
    s.addi       s23, s18, #6912
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s22, #256
    v.st.w       [s22, #0], v1
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s18, #6976
    v.st.w       [s19, #0], v1
    s.addi       s19, s22, #320
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s18, #7040
    v.st.w       [s4, #0], v1
    s.addi       s4, s22, #384
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s18, #7104
    v.st.w       [s16, #0], v1
    s.addi       s16, s22, #448
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s18, #7168
    v.st.w       [s14, #0], v1
    s.addi       s14, s22, #512
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s18, #7232
    v.st.w       [s19, #0], v1
    s.addi       s19, s22, #576
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s18, #7296
    v.st.w       [s4, #0], v1
    s.addi       s4, s22, #640
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s18, #7360
    v.st.w       [s16, #0], v1
    s.addi       s16, s22, #704
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s18, #7424
    v.st.w       [s14, #0], v1
    s.addi       s14, s22, #768
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s18, #7488
    v.st.w       [s19, #0], v1
    s.addi       s19, s22, #832
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s18, #7552
    v.st.w       [s4, #0], v1
    s.addi       s4, s22, #896
    s.addi       s24, s22, #960
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s18, #7616
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #7680
    v.ld.w       v1, [s23, #0]
    s.addi       s22, s18, #0
    v.st.w       [s14, #0], v1
    s.addi       s14, s18, #7744
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s18, #64
    v.st.w       [s19, #0], v1
    s.addi       s19, s18, #7808
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s18, #128
    v.st.w       [s4, #0], v1
    s.addi       s4, s18, #7872
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s18, #192
    v.st.w       [s24, #0], v1
    fence.acq_rel.device
    s.addi       s23, s18, #7936
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s18, #256
    v.st.w       [s22, #0], v1
    s.addi       s22, s18, #8000
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s18, #320
    v.st.w       [s10, #0], v1
    s.addi       s10, s18, #8064
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s18, #384
    v.st.w       [s5, #0], v1
    s.addi       s5, s18, #8128
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #448
    v.st.w       [s12, #0], v1
    s.addi       s12, s18, #8192
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s18, #512
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #8256
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s18, #576
    v.st.w       [s14, #0], v1
    s.addi       s14, s18, #8320
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s18, #640
    v.st.w       [s19, #0], v1
    s.addi       s19, s18, #8384
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s18, #704
    v.st.w       [s4, #0], v1
    s.addi       s4, s18, #8448
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s18, #768
    v.st.w       [s23, #0], v1
    s.addi       s23, s18, #8512
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s18, #832
    v.st.w       [s22, #0], v1
    s.addi       s22, s18, #8576
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s18, #896
    v.st.w       [s10, #0], v1
    s.addi       s10, s18, #8640
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s18, #960
    v.st.w       [s5, #0], v1
    s.addi       s5, s18, #8704
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #1024
    v.st.w       [s12, #0], v1
    s.addi       s12, s18, #8768
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s18, #1088
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #8832
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s18, #1152
    v.st.w       [s14, #0], v1
    s.addi       s14, s18, #8896
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s18, #1216
    v.st.w       [s19, #0], v1
    fence.acq_rel.device
    s.addi       s19, s18, #8960
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s18, #1280
    v.st.w       [s4, #0], v1
    s.addi       s4, s18, #9024
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s18, #1344
    v.st.w       [s23, #0], v1
    s.addi       s23, s18, #9088
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s18, #1408
    v.st.w       [s22, #0], v1
    s.addi       s22, s18, #9152
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s18, #1472
    v.st.w       [s10, #0], v1
    s.addi       s10, s18, #9216
    s.add        s24, s15, s3
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s18, #1536
    v.st.w       [s5, #0], v1
    s.addi       s5, s18, #9280
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #1600
    v.st.w       [s12, #0], v1
    s.addi       s12, s18, #9344
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s18, #1664
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #9408
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s18, #1728
    v.st.w       [s14, #0], v1
    s.addi       s14, s18, #9472
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s18, #1792
    v.st.w       [s19, #0], v1
    s.addi       s19, s18, #9536
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s18, #1856
    v.st.w       [s4, #0], v1
    s.addi       s4, s18, #9600
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s18, #1920
    v.st.w       [s23, #0], v1
    s.addi       s23, s18, #9664
    s.addi       s25, s18, #1984
    v.ld.w       v1, [s16, #0]
    s.movz       s16, #1
    v.st.w       [s22, #0], v1
    v.ld.w       v1, [s14, #0]
    v.st.w       [s10, #0], v1
    v.ld.w       v1, [s19, #0]
    v.st.w       [s5, #0], v1
    v.ld.w       v1, [s4, #0]
    v.st.w       [s12, #0], v1
    v.ld.w       v1, [s23, #0]
    v.st.w       [s25, #0], v1
    fence.acq_rel.device
    s.mov        s15, s24
    br.nz        s16, for_5
endfor_6:
    s.movz       s3, #0
    .li       s4, #262144
    s.add        s5, s3, s8                      // the tile origin
    s.mul        s3, s13, s4
    s.movz       s4, #0
    s.muli       s6, s8, #2                      // a runtime tile origin, x2
    v.splat      v1, s5
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s5, #0
    s.add        s8, s4, s9                      // the tile origin
    s.movz       s4, #512
    s.muli       s10, s9, #1024                  // a runtime tile origin, x1024
    a.vread      v2, a0, s5
    v.splat      v3, s8
    v.splat      v4, s4
    v.add        v5, v0, v1
    v.splat      v0, s4
    s.muli       s4, s3, #2                      // a runtime tile origin, x2
    v.splat      v1, s13
    v.splat      v6, s1
    s.add        s1, s7, s6                      // the tile origin
    vf.cvt.f32.f16 v7, v2
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v0
    s.add        s3, s1, s10                     // the tile origin
    p.and        p3, p1, p2
    v.cmp.lt     p1, v1, v6
    s.add        s1, s3, s4                      // the tile origin
    p.and        p4, p3, p1
    s.movz       s3, #1
    s.addi       s4, s8, #1
    @p4 v.st.h       [s1, #0], v7
    a.vread      v0, a0, s3
    v.splat      v1, s4
    s.addi       s3, s1, #1024                   // row 1
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p3, v1, v4
    p.and        p4, p3, p2
    s.movz       s4, #2
    p.and        p3, p4, p1
    s.addi       s5, s8, #2
    s.addi       s6, s1, #2048                   // row 2
    v.splat      v0, s5
    s.movz       s5, #3
    s.addi       s7, s8, #3
    @p3 v.st.h       [s3, #0], v2
    a.vread      v1, a0, s4
    v.cmp.lt     p3, v0, v4
    p.and        p4, p3, p2
    vf.cvt.f32.f16 v0, v1
    p.and        p3, p4, p1
    v.splat      v1, s7
    s.addi       s3, s1, #3072                   // row 3
    s.movz       s4, #4
    v.cmp.lt     p4, v1, v4
    p.and        p5, p4, p2
    s.addi       s7, s8, #4
    p.and        p4, p5, p1
    v.splat      v1, s7
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p3, v1, v4
    p.and        p5, p3, p2
    vf.cvt.f32.f16 v1, v0
    s.addi       s5, s1, #4096                   // row 4
    p.and        p3, p5, p1
    s.movz       s6, #5
    s.addi       s7, s8, #5
    s.addi       s9, s1, #5120                   // row 5
    v.splat      v0, s7
    s.movz       s7, #6
    s.addi       s10, s8, #6
    @p4 v.st.h       [s3, #0], v1
    a.vread      v1, a0, s4
    v.cmp.lt     p4, v0, v4
    p.and        p5, p4, p2
    vf.cvt.f32.f16 v0, v1
    p.and        p4, p5, p1
    v.splat      v1, s10
    s.addi       s3, s1, #6144                   // row 6
    s.movz       s4, #7
    s.addi       s10, s8, #7
    v.splat      v2, s10
    s.addi       s10, s1, #7168                  // row 7
    @p3 v.st.h       [s5, #0], v0
    a.vread      v0, a0, s6
    v.cmp.lt     p3, v1, v4
    p.and        p5, p3, p2
    vf.cvt.f32.f16 v1, v0
    p.and        p3, p5, p1
    s.movz       s5, #8
    s.addi       s6, s8, #8
    v.splat      v0, s6
    s.addi       s6, s1, #8192                   // row 8
    @p4 v.st.h       [s9, #0], v1
    a.vread      v1, a0, s7
    v.cmp.lt     p4, v2, v4
    p.and        p5, p4, p2
    vf.cvt.f32.f16 v2, v1
    p.and        p4, p5, p1
    s.movz       s7, #9
    s.addi       s9, s8, #9
    v.splat      v1, s9
    s.addi       s9, s1, #9216                   // row 9
    @p3 v.st.h       [s3, #0], v2
    a.vread      v2, a0, s4
    v.cmp.lt     p3, v0, v4
    p.and        p5, p3, p2
    vf.cvt.f32.f16 v0, v2
    p.and        p3, p5, p1
    s.movz       s3, #10
    s.addi       s4, s8, #10
    v.splat      v2, s4
    s.addi       s4, s1, #10240                  // row 10
    @p4 v.st.h       [s10, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p4, v1, v4
    p.and        p5, p4, p2
    vf.cvt.f32.f16 v1, v0
    p.and        p4, p5, p1
    s.movz       s5, #11
    s.addi       s10, s8, #11
    v.splat      v0, s10
    s.addi       s10, s1, #11264                 // row 11
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a0, s7
    v.cmp.lt     p3, v2, v4
    p.and        p5, p3, p2
    vf.cvt.f32.f16 v2, v1
    p.and        p3, p5, p1
    s.movz       s6, #12
    s.addi       s7, s8, #12
    v.splat      v1, s7
    s.addi       s7, s1, #12288                  // row 12
    @p4 v.st.h       [s9, #0], v2
    a.vread      v2, a0, s3
    v.cmp.lt     p4, v0, v4
    p.and        p5, p4, p2
    vf.cvt.f32.f16 v0, v2
    p.and        p4, p5, p1
    s.movz       s3, #13
    s.addi       s9, s8, #13
    v.splat      v2, s9
    s.addi       s9, s1, #13312                  // row 13
    @p3 v.st.h       [s4, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p3, v1, v4
    p.and        p5, p3, p2
    vf.cvt.f32.f16 v1, v0
    p.and        p3, p5, p1
    s.movz       s4, #14
    s.addi       s5, s8, #14
    s.addi       s11, s8, #15
    v.splat      v0, s5
    s.addi       s5, s1, #14336                  // row 14
    v.splat      v3, s11
    s.movz       s8, #15
    s.addi       s11, s1, #15360                 // row 15
    @p4 v.st.h       [s10, #0], v1
    a.vread      v1, a0, s6
    v.cmp.lt     p4, v2, v4
    p.and        p5, p4, p2
    vf.cvt.f32.f16 v2, v1
    p.and        p4, p5, p1
    @p3 v.st.h       [s7, #0], v2
    a.vread      v1, a0, s3
    v.cmp.lt     p3, v0, v4
    p.and        p5, p3, p2
    vf.cvt.f32.f16 v0, v1
    p.and        p3, p5, p1
    @p4 v.st.h       [s9, #0], v0
    a.vread      v0, a0, s4
    v.cmp.lt     p4, v3, v4
    p.and        p5, p4, p2
    vf.cvt.f32.f16 v1, v0
    p.and        p2, p5, p1
    @p3 v.st.h       [s5, #0], v1
    a.vread      v0, a0, s8
    vf.cvt.f32.f16 v1, v0
    @p2 v.st.h       [s11, #0], v1
__rctx_next:
    exit
