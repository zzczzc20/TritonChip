#!/bin/bash
source /tools/Xilinx/Vivado/2023.2/settings64.sh >/dev/null 2>&1
cd /home/zzhouch/tnca_build/r40_attempt01_screen_20261016
vivado -mode batch -source flow/fpga/synth_r40_range_slice.tcl -tclargs /home/zzhouch/tnca_build/r40_attempt01_screen_20261016 /home/zzhouch/tnca_build/r40_attempt01_screen_20261016/screen32 1 32 5 > screen32.log 2>&1
printf '%s\n' "$?" > screen.exit
