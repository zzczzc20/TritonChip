    s.rdspecial  s1, pid.x
    s.movz       s2, #0
    s.movz       s3, #64
    s.cmp.lt     s4, s1, s2
    v.iota       v0                              // arange(0, VLEN)
    s.sub        s5, s2, s4
    v.movi       v1, #16
    s.xor        s4, s1, s5
    v.movi       v2, #32
    s.sub        s1, s4, s5
    v.movi       v3, #48
    s.lshri      s4, s1, #2
    v.add        v4, v0, v1
    s.muli       s6, s4, #4
    v.add        v1, v0, v2
    v.add        v2, v0, v3
    s.movz       s7, #4
    v.movi       v3, #0
    s.sub        s8, s1, s6
    s.cmp.lt     s1, s7, s2
    s.xor        s6, s8, s5
    s.sub        s8, s2, s1
    s.sub        s1, s6, s5
    s.xor        s2, s5, s8
    s.mul        s5, s1, s3
    s.xor        s1, s4, s2
    v.movi       v5, #64
    s.sub        s4, s1, s2
    s.rdspecial  s1, arg_base
    v.splat      v6, s5
    s.mul        s2, s4, s3
    s.xor        s4, s7, s8
    v.add        v7, v6, v0
    v.add        v8, v6, v4
    v.add        v9, v6, v1
    v.add        v10, v6, v2
    v.splat      v6, s2
    s.ld.d       s6, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    v.cmp.lt     p1, v5, v3
    v.add        v11, v6, v0
    v.add        v0, v6, v4
    v.add        v4, v6, v1
    v.add        v1, v6, v2
    v.cmp.lt     p2, v11, v3
    s.sub        s7, s4, s8
    v.movi       v2, #1
    s.ld.d       s4, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    v.sub        v2, v3, v11
    s.ld.d       s7, [s1, #16]                   // arg_SA: device_ptr64 at arg_base+16
    @p2 v.sel        v6, v2, v11
    s.ld.d       s8, [s1, #24]                   // arg_SB: device_ptr64 at arg_base+24
    v.sub        v2, v3, v5
    s.ld.d       s9, [s1, #32]                   // out_ptr1: device_ptr64 at arg_base+32
    v.movi       v11, #0
    v.movi       v12, #0
    v.movi       v13, #0
    v.cmp.lt     p3, v7, v11
    v.movi       v14, #0
    v.sub        v15, v12, v0
    v.sub        v16, v13, v4
    v.sub        v17, v14, v1
    v.movi       v18, #63
    @p1 v.sel        v19, v2, v5
    v.sub        v2, v11, v7
    v.cmp.lt     p1, v0, v12
    @p1 v.sel        v5, v15, v0
    v.movi       v0, #63
    v.movi       v15, #63
    v.and        v19, v6, v18
    @p3 v.sel        v6, v2, v7
    v.movi       v2, #63
    v.movi       v7, #64
    v.and        v18, v5, v0
    v.movi       v0, #64
    v.sub        v5, v3, v19
    v.movi       v3, #1
    v.movi       v3, #1
    @p2 v.sel        v3, v5, v19
    v.movi       v5, #255
    v.cmp.lt     p2, v4, v13
    @p2 v.sel        v19, v16, v4
    v.and        v4, v6, v5
    v.movi       v5, #64
    v.and        v6, v19, v15
    v.sub        v15, v11, v4
    v.movi       v16, #256
    v.movi       v19, #1
    @p3 v.sel        v19, v15, v4
    v.cmp.lt     p3, v1, v14
    @p3 v.sel        v4, v17, v1
    v.sub        v1, v12, v7
    v.sub        v15, v12, v18
    v.and        v17, v4, v2
    v.sub        v2, v13, v0
    @p1 v.sel        v4, v15, v18
    v.sub        v15, v13, v6
    v.cmp.lt     p1, v7, v12
    v.movi       v12, #0
    @p1 v.sel        v18, v1, v7
    v.movi       v1, #255
    v.sub        v7, v12, v8
    v.cmp.lt     p1, v8, v12
    @p2 v.sel        v18, v15, v6
    @p1 v.sel        v6, v7, v8
    v.movi       v7, #256
    v.sub        v8, v14, v5
    v.and        v15, v6, v1
    v.sub        v1, v14, v17
    v.cmp.lt     p2, v0, v13
    v.movi       v6, #0
    @p2 v.sel        v13, v2, v0
    v.movi       v0, #255
    v.sub        v2, v6, v9
    v.cmp.lt     p2, v9, v6
    @p3 v.sel        v13, v1, v17
    @p2 v.sel        v1, v2, v9
    v.sub        v2, v12, v15
    v.movi       v9, #256
    v.and        v17, v1, v0
    @p1 v.sel        v0, v2, v15
    v.sub        v1, v11, v16
    v.sub        v2, v6, v17
    v.cmp.lt     p1, v5, v14
    v.movi       v14, #0
    @p2 v.sel        v15, v2, v17
    v.movi       v2, #256
    v.cmp.lt     p2, v10, v14
    v.cmp.lt     p3, v16, v11
    v.sub        v11, v12, v7
    @p1 v.sel        v17, v8, v5
    v.sub        v5, v14, v10
    v.movi       v8, #255
    v.cmp.lt     p1, v7, v12
    @p2 v.sel        v12, v5, v10
    v.sub        v5, v6, v9
    v.sub        v10, v14, v2
    v.and        v17, v12, v8
    v.movi       v8, #1
    v.iota       v8                              // arange(0, VLEN)
    @p3 v.sel        v12, v1, v16
    v.sub        v1, v14, v17
    v.movi       v12, #16
    v.cmp.lt     p3, v9, v6
    @p2 v.sel        v6, v1, v17
    v.movi       v1, #32
    v.movi       v16, #48
    v.cmp.lt     p2, v2, v14
    v.iota       v14                             // arange(0, VLEN)
    v.movi       v17, #1
    @p1 v.sel        v17, v11, v7
    v.movi       v7, #128
    v.movi       v11, #64
    v.movi       v17, #1
    @p3 v.sel        v17, v5, v9
    v.movi       v5, #0
    v.movi       v9, #7
    v.movi       v17, #1
    v.cmp.lt     p1, v19, v5
    v.cmp.lt     p3, v7, v5
    @p2 v.sel        v17, v10, v2
    v.movi       v2, #0
    v.sub        v10, v5, v19
    v.add        v17, v8, v12
    v.movi       v12, #0
    v.cmp.lt     p2, v0, v2
    @p1 v.sel        v17, v10, v19
    v.add        v10, v8, v1
    v.sub        v1, v2, v0
    v.lshr       v10, v17, v9
    v.movi       v9, #7
    @p2 v.sel        v17, v1, v0
    v.add        v1, v8, v16
    v.sub        v1, v12, v15
    v.lshr       v8, v17, v9
    v.sub        v9, v5, v10
    v.movi       v16, #128
    v.sub        v17, v5, v7
    @p1 v.sel        v5, v9, v10
    v.cmp.lt     p1, v15, v12
    @p1 v.sel        v9, v1, v15
    v.sub        v1, v2, v8
    v.add        v10, v14, v11
    v.movi       v10, #128
    @p2 v.sel        v11, v1, v8
    v.movi       v1, #80
    v.cmp.lt     p2, v16, v2
    v.sub        v8, v2, v16
    v.add        v2, v14, v1
    v.movi       v1, #7
    s.movz       s1, #16
    s.movz       s10, #32
    v.lshr       v2, v9, v1
    v.movi       v1, #96
    s.movz       s11, #48
    s.movz       s12, #80
    v.add        v9, v14, v1
    v.sub        v1, v12, v2
    v.iota       v9                              // arange(0, VLEN)
    s.movz       s13, #96
    @p1 v.sel        v14, v1, v2
    v.movi       v1, #128
    v.cmp.lt     p1, v10, v12
    v.sub        v2, v12, v10
    s.movz       s14, #112
    v.movi       v12, #1
    @p3 v.sel        v12, v17, v7
    v.movi       v7, #112
    v.movi       v12, #0
    v.movi       v17, #1
    v.add        v17, v9, v7
    s.rdspecial  s15, arg_base
    v.sub        v7, v12, v6
    s.ld.d       s16, [s15, #40]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.cmp.lt     p3, v6, v12
    @p3 v.sel        v9, v7, v6
    v.movi       v7, #7
    s.movz       s15, #0
    @p2 v.sel        v17, v8, v16
    v.lshr       v8, v9, v7
    v.sub        v7, v12, v1
    v.movi       v9, #4
    v.sub        v16, v12, v8
    v.cmp.lt     p2, v1, v12
    s.addi       s17, s16, #0
    @p3 v.sel        v12, v16, v8
    v.movi       v8, #0
    s.addi       s18, s17, #64
    s.addi       s19, s17, #128
    s.addi       s20, s17, #192
    s.addi       s21, s17, #256
    v.movi       v16, #1
    s.addi       s22, s17, #320
    s.addi       s23, s17, #384
    s.addi       s24, s17, #448
    @p1 v.sel        v16, v2, v10
    s.addi       s25, s17, #512
    s.addi       s26, s17, #576
    s.addi       s27, s17, #640
    v.movi       v2, #1
    @p2 v.sel        v2, v7, v1
    v.movi       v1, #0
    v.mul        v2, v5, v9
    v.mul        v5, v11, v9
    v.mul        v7, v14, v9
    v.mul        v10, v12, v9
    v.st.w       [s17, #0], v8
    v.st.w       [s18, #0], v8
    s.addi       s18, s16, #1024
    v.st.w       [s19, #0], v8
    s.addi       s19, s17, #704
    v.st.w       [s20, #0], v8
    s.addi       s20, s17, #768
    v.st.w       [s21, #0], v8
    s.addi       s21, s17, #832
    v.st.w       [s22, #0], v8
    s.addi       s22, s17, #896
    s.addi       s28, s17, #960
    v.st.w       [s23, #0], v8
    s.addi       s17, s18, #64
    v.st.w       [s24, #0], v8
    s.addi       s23, s18, #128
    v.st.w       [s25, #0], v8
    s.movz       s24, #2
    v.st.w       [s26, #0], v8
    s.addi       s25, s18, #192
    v.st.w       [s27, #0], v8
    s.movz       s26, #1
    v.st.w       [s19, #0], v8
    s.addi       s19, s15, #0
    v.st.w       [s20, #0], v8
    s.addi       s20, s18, #256
    v.st.w       [s21, #0], v8
    s.addi       s21, s15, #0
    v.st.w       [s22, #0], v8
    s.addi       s22, s15, #0
    v.movi       v9, #0
    v.st.w       [s28, #0], v8
    s.addi       s27, s16, #2048
    fence.acq_rel.device
    v.st.w       [s18, #0], v1
    v.st.w       [s17, #0], v1
    s.addi       s17, s18, #320
    v.st.w       [s23, #0], v1
    s.addi       s23, s18, #384
    v.st.w       [s25, #0], v1
    s.addi       s25, s18, #448
    v.st.w       [s20, #0], v1
    s.addi       s20, s18, #512
    v.st.w       [s17, #0], v1
    s.addi       s17, s18, #576
    v.st.w       [s23, #0], v1
    s.addi       s23, s18, #640
    v.st.w       [s25, #0], v1
    s.addi       s25, s18, #704
    v.st.w       [s20, #0], v1
    s.addi       s20, s18, #768
    v.st.w       [s17, #0], v1
    s.addi       s17, s16, #3072
    v.movi       v8, #0
    v.st.w       [s23, #0], v1
    s.addi       s23, s18, #832
    v.st.w       [s25, #0], v1
    s.addi       s25, s18, #896
    s.addi       s28, s18, #960
    v.st.w       [s20, #0], v1
    s.addi       s18, s27, #64
    v.st.w       [s23, #0], v1
    s.addi       s20, s27, #128
    v.st.w       [s25, #0], v1
    s.addi       s23, s27, #192
    v.st.w       [s28, #0], v1
    s.addi       s25, s27, #256
    fence.acq_rel.device
    v.st.w       [s27, #0], v9
    v.st.w       [s18, #0], v9
    s.addi       s18, s27, #320
    v.st.w       [s20, #0], v9
    s.addi       s20, s27, #384
    v.st.w       [s23, #0], v9
    s.addi       s23, s27, #448
    v.st.w       [s25, #0], v9
    s.addi       s25, s27, #512
    v.st.w       [s18, #0], v9
    s.addi       s18, s27, #576
    v.st.w       [s20, #0], v9
    s.addi       s20, s27, #640
    v.st.w       [s23, #0], v9
    s.addi       s23, s27, #704
    v.st.w       [s25, #0], v9
    s.addi       s25, s27, #768
    v.st.w       [s18, #0], v9
    s.addi       s18, s16, #4096
    v.movi       v1, #0
    v.st.w       [s20, #0], v9
    s.addi       s20, s27, #832
    v.st.w       [s23, #0], v9
    s.addi       s23, s27, #896
    s.addi       s28, s27, #960
    v.st.w       [s25, #0], v9
    s.addi       s25, s17, #64
    v.st.w       [s20, #0], v9
    s.addi       s20, s17, #128
    v.st.w       [s23, #0], v9
    s.addi       s23, s17, #192
    v.st.w       [s28, #0], v9
    s.addi       s27, s17, #256
    fence.acq_rel.device
    v.st.w       [s17, #0], v8
    v.st.w       [s25, #0], v8
    s.addi       s25, s17, #320
    v.st.w       [s20, #0], v8
    s.addi       s20, s17, #384
    v.st.w       [s23, #0], v8
    s.addi       s23, s17, #448
    v.st.w       [s27, #0], v8
    s.addi       s27, s17, #512
    v.st.w       [s25, #0], v8
    s.addi       s25, s17, #576
    v.st.w       [s20, #0], v8
    s.addi       s20, s17, #640
    v.st.w       [s23, #0], v8
    s.addi       s23, s17, #704
    v.st.w       [s27, #0], v8
    s.addi       s27, s17, #768
    v.st.w       [s25, #0], v8
    s.addi       s25, s16, #5120
    v.movi       v9, #0
    v.st.w       [s20, #0], v8
    s.addi       s20, s17, #832
    v.st.w       [s23, #0], v8
    s.addi       s23, s17, #896
    s.addi       s28, s17, #960
    v.st.w       [s27, #0], v8
    s.addi       s17, s18, #64
    v.st.w       [s20, #0], v8
    s.addi       s20, s18, #128
    v.st.w       [s23, #0], v8
    s.addi       s23, s18, #192
    v.st.w       [s28, #0], v8
    s.addi       s27, s18, #256
    fence.acq_rel.device
    v.st.w       [s18, #0], v1
    v.st.w       [s17, #0], v1
    s.addi       s17, s18, #320
    v.st.w       [s20, #0], v1
    s.addi       s20, s18, #384
    v.st.w       [s23, #0], v1
    s.addi       s23, s18, #448
    v.st.w       [s27, #0], v1
    s.addi       s27, s18, #512
    v.st.w       [s17, #0], v1
    s.addi       s17, s18, #576
    v.st.w       [s20, #0], v1
    s.addi       s20, s18, #640
    v.st.w       [s23, #0], v1
    s.addi       s23, s18, #704
    v.st.w       [s27, #0], v1
    s.addi       s27, s18, #768
    v.st.w       [s17, #0], v1
    s.addi       s17, s16, #6144
    v.movi       v8, #0
    v.st.w       [s20, #0], v1
    s.addi       s20, s18, #832
    v.st.w       [s23, #0], v1
    s.addi       s23, s18, #896
    s.addi       s28, s18, #960
    v.st.w       [s27, #0], v1
    s.addi       s18, s25, #64
    v.st.w       [s20, #0], v1
    s.addi       s20, s25, #128
    v.st.w       [s23, #0], v1
    s.addi       s23, s25, #192
    v.st.w       [s28, #0], v1
    s.addi       s27, s25, #256
    fence.acq_rel.device
    v.st.w       [s25, #0], v9
    v.st.w       [s18, #0], v9
    s.addi       s18, s25, #320
    v.st.w       [s20, #0], v9
    s.addi       s20, s25, #384
    v.st.w       [s23, #0], v9
    s.addi       s23, s25, #448
    v.st.w       [s27, #0], v9
    s.addi       s27, s25, #512
    v.st.w       [s18, #0], v9
    s.addi       s18, s25, #576
    v.st.w       [s20, #0], v9
    s.addi       s20, s25, #640
    v.st.w       [s23, #0], v9
    s.addi       s23, s25, #704
    v.st.w       [s27, #0], v9
    s.addi       s27, s25, #768
    v.st.w       [s18, #0], v9
    s.addi       s18, s16, #7168
    v.movi       v1, #0
    v.st.w       [s20, #0], v9
    s.addi       s20, s25, #832
    v.st.w       [s23, #0], v9
    s.addi       s23, s25, #896
    s.addi       s28, s25, #960
    v.st.w       [s27, #0], v9
    s.addi       s25, s17, #64
    v.st.w       [s20, #0], v9
    s.addi       s20, s17, #128
    v.st.w       [s23, #0], v9
    s.addi       s23, s17, #192
    v.st.w       [s28, #0], v9
    s.addi       s27, s17, #256
    fence.acq_rel.device
    v.st.w       [s17, #0], v8
    v.st.w       [s25, #0], v8
    s.addi       s25, s17, #320
    v.st.w       [s20, #0], v8
    s.addi       s20, s17, #384
    v.st.w       [s23, #0], v8
    s.addi       s23, s17, #448
    v.st.w       [s27, #0], v8
    s.addi       s27, s17, #512
    v.st.w       [s25, #0], v8
    s.addi       s25, s17, #576
    v.st.w       [s20, #0], v8
    s.addi       s20, s17, #640
    v.st.w       [s23, #0], v8
    s.addi       s23, s17, #704
    v.st.w       [s27, #0], v8
    s.addi       s27, s17, #768
    v.st.w       [s25, #0], v8
    s.addi       s25, s16, #8192
    v.movi       v9, #0
    v.st.w       [s20, #0], v8
    s.addi       s20, s17, #832
    v.st.w       [s23, #0], v8
    s.addi       s23, s17, #896
    s.addi       s28, s17, #960
    v.st.w       [s27, #0], v8
    s.addi       s17, s18, #64
    v.st.w       [s20, #0], v8
    s.addi       s20, s18, #128
    v.st.w       [s23, #0], v8
    s.addi       s23, s18, #192
    v.st.w       [s28, #0], v8
    s.addi       s27, s18, #256
    fence.acq_rel.device
    v.st.w       [s18, #0], v1
    v.st.w       [s17, #0], v1
    s.addi       s17, s18, #320
    v.st.w       [s20, #0], v1
    s.addi       s20, s18, #384
    v.st.w       [s23, #0], v1
    s.addi       s23, s18, #448
    v.st.w       [s27, #0], v1
    s.addi       s27, s18, #512
    v.st.w       [s17, #0], v1
    s.addi       s17, s18, #576
    v.st.w       [s20, #0], v1
    s.addi       s20, s18, #640
    v.st.w       [s23, #0], v1
    s.addi       s23, s18, #704
    v.st.w       [s27, #0], v1
    s.addi       s27, s18, #768
    v.st.w       [s17, #0], v1
    s.addi       s17, s16, #9216
    v.movi       v8, #0
    v.st.w       [s20, #0], v1
    s.addi       s20, s18, #832
    v.st.w       [s23, #0], v1
    s.addi       s23, s18, #896
    s.addi       s28, s18, #960
    v.st.w       [s27, #0], v1
    s.addi       s18, s25, #64
    v.st.w       [s20, #0], v1
    s.addi       s20, s25, #128
    v.st.w       [s23, #0], v1
    s.addi       s23, s25, #192
    v.st.w       [s28, #0], v1
    s.addi       s27, s25, #256
    fence.acq_rel.device
    v.st.w       [s25, #0], v9
    v.st.w       [s18, #0], v9
    s.addi       s18, s25, #320
    v.st.w       [s20, #0], v9
    s.addi       s20, s25, #384
    v.st.w       [s23, #0], v9
    s.addi       s23, s25, #448
    v.st.w       [s27, #0], v9
    s.addi       s27, s25, #512
    v.st.w       [s18, #0], v9
    s.addi       s18, s25, #576
    v.st.w       [s20, #0], v9
    s.addi       s20, s25, #640
    v.st.w       [s23, #0], v9
    s.addi       s23, s25, #704
    v.st.w       [s27, #0], v9
    s.addi       s27, s25, #768
    v.st.w       [s18, #0], v9
    s.addi       s18, s16, #10240
    v.movi       v1, #0
    v.st.w       [s20, #0], v9
    s.addi       s20, s25, #832
    v.st.w       [s23, #0], v9
    s.addi       s23, s25, #896
    s.addi       s28, s25, #960
    v.st.w       [s27, #0], v9
    s.addi       s25, s17, #64
    v.st.w       [s20, #0], v9
    s.addi       s20, s17, #128
    v.st.w       [s23, #0], v9
    s.addi       s23, s17, #192
    v.st.w       [s28, #0], v9
    s.addi       s27, s17, #256
    fence.acq_rel.device
    v.st.w       [s17, #0], v8
    v.st.w       [s25, #0], v8
    s.addi       s25, s17, #320
    v.st.w       [s20, #0], v8
    s.addi       s20, s17, #384
    v.st.w       [s23, #0], v8
    s.addi       s23, s17, #448
    v.st.w       [s27, #0], v8
    s.addi       s27, s17, #512
    v.st.w       [s25, #0], v8
    s.addi       s25, s17, #576
    v.st.w       [s20, #0], v8
    s.addi       s20, s17, #640
    v.st.w       [s23, #0], v8
    s.addi       s23, s17, #704
    v.st.w       [s27, #0], v8
    s.addi       s27, s17, #768
    v.st.w       [s25, #0], v8
    s.addi       s25, s16, #11264
    v.movi       v9, #0
    v.st.w       [s20, #0], v8
    s.addi       s20, s17, #832
    v.st.w       [s23, #0], v8
    s.addi       s23, s17, #896
    s.addi       s28, s17, #960
    v.st.w       [s27, #0], v8
    s.addi       s17, s18, #64
    v.st.w       [s20, #0], v8
    s.addi       s20, s18, #128
    v.st.w       [s23, #0], v8
    s.addi       s23, s18, #192
    v.st.w       [s28, #0], v8
    s.addi       s27, s18, #256
    fence.acq_rel.device
    v.st.w       [s18, #0], v1
    v.st.w       [s17, #0], v1
    s.addi       s17, s18, #320
    v.st.w       [s20, #0], v1
    s.addi       s20, s18, #384
    v.st.w       [s23, #0], v1
    s.addi       s23, s18, #448
    v.st.w       [s27, #0], v1
    s.addi       s27, s18, #512
    v.st.w       [s17, #0], v1
    s.addi       s17, s18, #576
    v.st.w       [s20, #0], v1
    s.addi       s20, s18, #640
    v.st.w       [s23, #0], v1
    s.addi       s23, s18, #704
    v.st.w       [s27, #0], v1
    s.addi       s27, s18, #768
    v.st.w       [s17, #0], v1
    s.addi       s17, s16, #12288
    v.movi       v8, #0
    v.st.w       [s20, #0], v1
    s.addi       s20, s18, #832
    v.st.w       [s23, #0], v1
    s.addi       s23, s18, #896
    s.addi       s28, s18, #960
    v.st.w       [s27, #0], v1
    s.addi       s18, s25, #64
    v.st.w       [s20, #0], v1
    s.addi       s20, s25, #128
    v.st.w       [s23, #0], v1
    s.addi       s23, s25, #192
    v.st.w       [s28, #0], v1
    s.addi       s27, s25, #256
    fence.acq_rel.device
    v.st.w       [s25, #0], v9
    v.st.w       [s18, #0], v9
    s.addi       s18, s25, #320
    v.st.w       [s20, #0], v9
    s.addi       s20, s25, #384
    v.st.w       [s23, #0], v9
    s.addi       s23, s25, #448
    v.st.w       [s27, #0], v9
    s.addi       s27, s25, #512
    v.st.w       [s18, #0], v9
    s.addi       s18, s25, #576
    v.st.w       [s20, #0], v9
    s.addi       s20, s25, #640
    v.st.w       [s23, #0], v9
    s.addi       s23, s25, #704
    v.st.w       [s27, #0], v9
    s.addi       s27, s25, #768
    v.st.w       [s18, #0], v9
    s.addi       s18, s16, #13312
    v.movi       v1, #0
    v.st.w       [s20, #0], v9
    s.addi       s20, s25, #832
    v.st.w       [s23, #0], v9
    s.addi       s23, s25, #896
    s.addi       s28, s25, #960
    v.st.w       [s27, #0], v9
    s.addi       s25, s17, #64
    v.st.w       [s20, #0], v9
    s.addi       s20, s17, #128
    v.st.w       [s23, #0], v9
    s.addi       s23, s17, #192
    v.st.w       [s28, #0], v9
    s.addi       s27, s17, #256
    fence.acq_rel.device
    v.st.w       [s17, #0], v8
    v.st.w       [s25, #0], v8
    s.addi       s25, s17, #320
    v.st.w       [s20, #0], v8
    s.addi       s20, s17, #384
    v.st.w       [s23, #0], v8
    s.addi       s23, s17, #448
    v.st.w       [s27, #0], v8
    s.addi       s27, s17, #512
    v.st.w       [s25, #0], v8
    s.addi       s25, s17, #576
    v.st.w       [s20, #0], v8
    s.addi       s20, s17, #640
    v.st.w       [s23, #0], v8
    s.addi       s23, s17, #704
    v.st.w       [s27, #0], v8
    s.addi       s27, s17, #768
    v.st.w       [s25, #0], v8
    s.addi       s25, s16, #14336
    v.movi       v9, #0
    v.st.w       [s20, #0], v8
    s.addi       s20, s17, #832
    v.st.w       [s23, #0], v8
    s.addi       s23, s17, #896
    s.addi       s28, s17, #960
    v.st.w       [s27, #0], v8
    s.addi       s17, s18, #64
    v.st.w       [s20, #0], v8
    s.addi       s20, s18, #128
    v.st.w       [s23, #0], v8
    s.addi       s23, s18, #192
    v.st.w       [s28, #0], v8
    s.addi       s27, s18, #256
    fence.acq_rel.device
    v.st.w       [s18, #0], v1
    v.st.w       [s17, #0], v1
    s.addi       s17, s18, #320
    v.st.w       [s20, #0], v1
    s.addi       s20, s18, #384
    v.st.w       [s23, #0], v1
    s.addi       s23, s18, #448
    v.st.w       [s27, #0], v1
    s.addi       s27, s18, #512
    v.st.w       [s17, #0], v1
    s.addi       s17, s18, #576
    v.st.w       [s20, #0], v1
    s.addi       s20, s18, #640
    v.st.w       [s23, #0], v1
    s.addi       s23, s18, #704
    v.st.w       [s27, #0], v1
    s.addi       s27, s18, #768
    v.st.w       [s17, #0], v1
    s.addi       s17, s16, #15360
    v.movi       v8, #0
    v.st.w       [s20, #0], v1
    s.addi       s20, s18, #832
    v.st.w       [s23, #0], v1
    s.addi       s23, s18, #896
    s.addi       s28, s18, #960
    v.st.w       [s27, #0], v1
    s.addi       s18, s25, #64
    v.st.w       [s20, #0], v1
    s.addi       s20, s25, #128
    v.st.w       [s23, #0], v1
    s.addi       s23, s25, #192
    v.st.w       [s28, #0], v1
    s.addi       s27, s25, #256
    fence.acq_rel.device
    v.st.w       [s25, #0], v9
    v.st.w       [s18, #0], v9
    s.addi       s18, s25, #320
    v.st.w       [s20, #0], v9
    s.addi       s20, s25, #384
    v.st.w       [s23, #0], v9
    s.addi       s23, s25, #448
    v.st.w       [s27, #0], v9
    s.addi       s27, s25, #512
    v.st.w       [s18, #0], v9
    s.addi       s18, s25, #576
    v.st.w       [s20, #0], v9
    s.addi       s20, s25, #640
    v.st.w       [s23, #0], v9
    s.addi       s23, s25, #704
    v.st.w       [s27, #0], v9
    s.addi       s27, s25, #768
    v.st.w       [s18, #0], v9
    s.addi       s18, s25, #832
    v.st.w       [s20, #0], v9
    s.addi       s20, s25, #896
    s.addi       s28, s25, #960
    v.st.w       [s23, #0], v9
    s.addi       s23, s17, #64
    v.st.w       [s27, #0], v9
    s.addi       s25, s17, #128
    v.st.w       [s18, #0], v9
    s.addi       s18, s17, #192
    v.st.w       [s20, #0], v9
    s.addi       s20, s17, #256
    v.st.w       [s28, #0], v9
    s.addi       s27, s17, #320
    fence.acq_rel.device
    v.st.w       [s17, #0], v8
    v.st.w       [s23, #0], v8
    s.addi       s23, s17, #384
    v.st.w       [s25, #0], v8
    s.addi       s25, s17, #448
    v.st.w       [s18, #0], v8
    s.addi       s18, s17, #512
    v.st.w       [s20, #0], v8
    s.addi       s20, s17, #576
    v.st.w       [s27, #0], v8
    s.addi       s27, s17, #640
    v.st.w       [s23, #0], v8
    s.addi       s23, s17, #704
    v.st.w       [s25, #0], v8
    s.addi       s25, s17, #768
    v.st.w       [s18, #0], v8
    s.addi       s18, s17, #832
    v.st.w       [s20, #0], v8
    s.addi       s20, s17, #896
    s.addi       s28, s17, #960
    v.st.w       [s27, #0], v8
    v.st.w       [s23, #0], v8
    v.st.w       [s25, #0], v8
    v.st.w       [s18, #0], v8
    v.st.w       [s20, #0], v8
    v.st.w       [s28, #0], v8
    fence.acq_rel.device
for_1:
    s.cmp.ge     s17, s19, s24
    br.nz        s17, endfor_2
    v.extract    s17, v19, #0
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v8, s17
    v.extract    s18, v0, #0
    s.movz       s20, #128
    v.add        v9, v8, v1
    v.splat      v8, s18
    s.mul        s23, s19, s20
    v.sub        v11, v19, v9
    v.add        v9, v8, v1
    s.movz       s20, #256
    s.mul        s25, s19, s3
    s.sub        s27, s20, s23
    s.movz       s23, #0
    v.reduce.or  s28, v11
    v.sub        v8, v0, v9
    s.add        s29, s15, s27
    s.cmp.eq     s30, s28, s23
    s.cmp.ge     s28, s17, s23
    v.reduce.or  s31, v8
    s.shli       s32, s25, #2                    // element offset -> bytes (x4)
    s.shli       s33, s19, #2                    // element offset -> bytes (x4)
    s.and        s34, s30, s28
    s.cmp.ge     s28, s29, s23
    // tl.dot 64x128 by 128x64 FP8, B as W's rows written transposed by the engine (ISA sec 9E, tensor_transpose_8bit)
    v.movi       v8, #0
    v.movi       v9, #0
    s.cmp.eq     s30, s31, s23
    s.add        s31, s7, s32                    // &arg_SA[...]
    s.add        s32, s8, s33                    // &arg_SB[...]
    s.and        s33, s34, s28
    v.ld.gather.w v11, [s31, v3]                 // index is in elements (ISA sec 9.1)
    v.splat      v12, s20
    v.splat      v14, s20
    s.cmp.ge     s20, s18, s23
    v.splat      v16, s25
    v.extract    s25, v15, #0
    s.and        s34, s30, s20
    v.splat      v16, s19
    s.and        s20, s34, s28
    v.splat      v16, s19
    v.splat      v16, s19
    v.splat      v16, s19
    v.mul        v16, v19, v12
    v.mul        v17, v0, v12
    v.mul        v20, v15, v12
    v.mul        v12, v6, v14
    v.ld.gather.w v14, [s31, v4]                 // index is in elements (ISA sec 9.1)
    v.splat      v21, s25
    v.ld.gather.w v22, [s31, v18]                // index is in elements (ISA sec 9.1)
    v.add        v23, v21, v1
    v.ld.gather.w v21, [s31, v13]                // index is in elements (ISA sec 9.1)
    v.sub        v24, v15, v23
    s.cmp.ge     s30, s25, s23
    v.reduce.or  s31, v24
    s.cmp.eq     s34, s31, s23
    s.and        s31, s34, s30
    s.and        s30, s31, s28
    v.ld.gather.w v23, [s32, v2]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v24, [s32, v5]                 // index is in elements (ISA sec 9.1)
    v.extract    s31, v6, #0
    v.ld.gather.w v25, [s32, v7]                 // index is in elements (ISA sec 9.1)
    v.splat      v26, s31
    v.ld.gather.w v27, [s32, v10]                // index is in elements (ISA sec 9.1)
    v.add        v28, v26, v1
    s.movz       s32, #256
    v.insert     v8, s33, #0
    v.sub        v1, v6, v28
    v.insert     v9, s17, #0
    s.movz       s17, #0
    v.reduce.or  s33, v1
    v.insert     v8, s20, #1
    v.insert     v9, s18, #1
    s.cmp.eq     s18, s33, s23
    s.cmp.ge     s20, s31, s23
    v.insert     v8, s30, #2
    s.and        s23, s18, s20
    v.insert     v9, s25, #2
    s.and        s18, s23, s28
    s.add        s20, s4, s22
    s.addi       s23, s16, #16384                // TensorMap 0: W's rows for a transposed FP8 B
    .li       s25, #2147483647
    s.movz       s28, #1
    .li       s30, #137438953488
    .li       s33, #7705171329024
    v.insert     v8, s18, #3
    s.addi       s18, s16, #16640
    v.insert     v9, s31, #3
    v.splat      v1, s32
    s.addi       s31, s16, #17152                // TensorMap 1: the gathered fallback B tile
    s.st.d       [s23, #0], s20
    v.mul        v26, v3, v1
    s.movz       s20, #32
    s.st.d       [s23, #8], s25
    v.extract    s25, v26, #0
    s.add        s34, s25, s21
    s.add        s25, s6, s34
    s.st.d       [s23, #16], s29
    s.add        s34, s17, s27                   // the tile origin
    v.iota       v1                              // arange(0, VLEN)
    s.st.d       [s23, #48], s32
    v.splat      v28, s34
    s.movz       s17, #16
    .li       s32, #68719476768
    v.cmp.lt     p1, v1, v28
    s.st.d       [s23, #56], s28
    s.st.d       [s23, #88], s30
    v.extract    s30, v26, #1
    s.st.d       [s23, #104], s33
    fence.release.device
    td.load      d0, [s23]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s23, s16, #17408                // 512 bytes of repack scratch
    s.add        s34, s30, s21
    s.add        s30, s6, s34
    s.st.d       [s31, #0], s18
    s.addi       s18, s23, #0
    s.st.d       [s31, #8], s20
    v.extract    s20, v26, #2
    s.add        s34, s20, s21
    s.add        s20, s6, s34
    s.st.d       [s31, #16], s17
    s.st.d       [s31, #48], s17
    s.addi       s17, s23, #32
    s.st.d       [s31, #56], s28
    v.extract    s28, v26, #3
    s.add        s34, s28, s21
    s.add        s28, s6, s34
    s.st.d       [s31, #88], s32
    s.addi       s32, s23, #64
    s.st.d       [s31, #104], s33
    fence.release.device
    td.load      d1, [s31]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    m.zero       a0
    m.zero       a1
    m.zero       a2
    m.zero       a3
    m.zero       a4
    m.zero       a5
    m.zero       a6
    m.zero       a7
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s25, #0]
    v.extract    s25, v26, #4
    s.addi       s31, s23, #96
    s.add        s33, s25, s21
    v.extract    s25, v26, #5
    s.add        s34, s6, s33
    s.add        s33, s25, s21
    s.add        s25, s6, s33
    v.st.b       [s18, #0], v28
    s.addi       s18, s23, #128
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s30, #0]
    v.extract    s30, v26, #6
    s.add        s33, s30, s21
    s.add        s30, s6, s33
    v.st.b       [s17, #0], v28
    s.addi       s17, s23, #160
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s20, #0]
    v.extract    s20, v26, #7
    s.add        s33, s20, s21
    s.add        s20, s6, s33
    v.st.b       [s32, #0], v28
    s.addi       s32, s23, #192
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s28, #0]
    v.extract    s28, v26, #8
    s.add        s33, s28, s21
    s.add        s28, s6, s33
    v.st.b       [s31, #0], v28
    s.addi       s31, s23, #224
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s34, #0]
    v.extract    s33, v26, #9
    s.add        s34, s33, s21
    s.add        s33, s6, s34
    v.st.b       [s18, #0], v28
    s.addi       s18, s23, #256
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s25, #0]
    v.extract    s25, v26, #10
    s.add        s34, s25, s21
    s.add        s25, s6, s34
    v.st.b       [s17, #0], v28
    s.addi       s17, s23, #288
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s30, #0]
    v.extract    s30, v26, #11
    s.add        s34, s30, s21
    s.add        s30, s6, s34
    v.st.b       [s32, #0], v28
    s.addi       s32, s23, #320
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s20, #0]
    v.extract    s20, v26, #12
    s.add        s34, s20, s21
    s.add        s20, s6, s34
    v.st.b       [s31, #0], v28
    s.addi       s31, s23, #352
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s28, #0]
    v.extract    s28, v26, #13
    s.add        s34, s28, s21
    s.add        s28, s6, s34
    v.st.b       [s18, #0], v28
    s.addi       s18, s23, #384
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s33, #0]
    v.extract    s33, v26, #14
    s.add        s34, s33, s21
    s.add        s33, s6, s34
    v.st.b       [s17, #0], v28
    s.addi       s17, s23, #416
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s25, #0]
    v.extract    s25, v26, #15
    s.add        s34, s25, s21
    s.add        s25, s6, s34
    v.st.b       [s32, #0], v28
    s.addi       s32, s23, #448
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s30, #0]
    s.movz       s30, #0
    v.st.b       [s31, #0], v28
    s.add        s31, s30, s1                    // the tile origin
    s.add        s34, s30, s27                   // the tile origin
    v.splat      v28, s31
    v.extract    s30, v26, #0
    v.splat      v29, s34
    s.add        s31, s30, s21
    v.add        v30, v1, v28
    s.addi       s30, s31, #16
    s.addi       s31, s23, #480
    s.add        s34, s6, s30
    v.cmp.lt     p2, v30, v29
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s20, #0]
    v.extract    s20, v26, #1
    s.add        s30, s20, s21
    s.addi       s20, s30, #16
    s.add        s30, s6, s20
    v.st.b       [s18, #0], v28
    s.addi       s18, s23, #16
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s28, #0]
    v.extract    s20, v26, #2
    s.add        s28, s20, s21
    s.addi       s20, s28, #16
    s.add        s28, s6, s20
    v.st.b       [s17, #0], v28
    s.addi       s17, s23, #48
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s33, #0]
    v.extract    s20, v26, #3
    s.add        s33, s20, s21
    s.addi       s20, s33, #16
    s.add        s33, s6, s20
    v.st.b       [s32, #0], v28
    s.addi       s20, s23, #80
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s25, #0]
    v.extract    s25, v26, #4
    s.add        s32, s25, s21
    s.addi       s25, s32, #16
    s.add        s32, s6, s25
    v.st.b       [s31, #0], v28
    s.addi       s25, s23, #112
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s34, #0]
    v.extract    s31, v26, #5
    s.add        s34, s31, s21
    s.addi       s31, s34, #16
    s.add        s34, s6, s31
    v.st.b       [s18, #0], v28
    s.addi       s18, s23, #144
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s30, #0]
    v.extract    s30, v26, #6
    s.add        s31, s30, s21
    s.addi       s30, s31, #16
    s.add        s31, s6, s30
    v.st.b       [s17, #0], v28
    s.addi       s17, s23, #176
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s28, #0]
    v.extract    s28, v26, #7
    s.add        s30, s28, s21
    s.addi       s28, s30, #16
    s.add        s30, s6, s28
    v.st.b       [s20, #0], v28
    s.addi       s20, s23, #208
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s33, #0]
    v.extract    s28, v26, #8
    s.add        s33, s28, s21
    s.addi       s28, s33, #16
    s.add        s33, s6, s28
    v.st.b       [s25, #0], v28
    s.addi       s25, s23, #240
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s32, #0]
    v.extract    s28, v26, #9
    s.add        s32, s28, s21
    s.addi       s28, s32, #16
    s.add        s32, s6, s28
    v.st.b       [s18, #0], v28
    s.addi       s18, s23, #272
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s34, #0]
    v.extract    s28, v26, #10
    s.add        s34, s28, s21
    s.addi       s28, s34, #16
    s.add        s34, s6, s28
    v.st.b       [s17, #0], v28
    s.addi       s17, s23, #304
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s31, #0]
    v.extract    s28, v26, #11
    s.add        s31, s28, s21
    s.addi       s28, s31, #16
    s.add        s31, s6, s28
    v.st.b       [s20, #0], v28
    s.addi       s20, s23, #336
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s30, #0]
    v.extract    s28, v26, #12
    s.add        s30, s28, s21
    s.addi       s28, s30, #16
    s.add        s30, s6, s28
    v.st.b       [s25, #0], v28
    s.addi       s25, s23, #368
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s33, #0]
    v.extract    s28, v26, #13
    s.add        s33, s28, s21
    s.addi       s28, s33, #16
    s.add        s33, s6, s28
    v.st.b       [s18, #0], v28
    s.addi       s18, s23, #400
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s32, #0]
    v.extract    s28, v26, #14
    s.add        s32, s28, s21
    s.addi       s28, s32, #16
    s.add        s32, s6, s28
    v.st.b       [s17, #0], v28
    s.addi       s17, s23, #432
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s34, #0]
    v.extract    s28, v26, #15
    s.add        s34, s28, s21
    s.addi       s28, s34, #16
    s.add        s34, s6, s28
    v.st.b       [s20, #0], v28
    s.addi       s20, s23, #464
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s31, #0]
    s.movz       s28, #256
    v.splat      v29, s28
    s.addi       s28, s23, #496
    v.mul        v30, v4, v29
    v.st.b       [s25, #0], v28
    v.extract    s25, v30, #0
    s.add        s31, s25, s21
    s.add        s25, s6, s31
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s30, #0]
    v.extract    s30, v30, #1
    s.add        s31, s30, s21
    s.add        s30, s6, s31
    v.st.b       [s18, #0], v28
    s.addi       s18, s16, #17920                // 512 bytes of repack scratch
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s33, #0]
    s.addi       s31, s18, #0
    v.st.b       [s17, #0], v28
    v.extract    s17, v30, #2
    s.add        s33, s17, s21
    s.add        s17, s6, s33
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s32, #0]
    s.addi       s32, s18, #32
    v.st.b       [s20, #0], v28
    v.extract    s20, v30, #3
    s.add        s33, s20, s21
    s.add        s20, s6, s33
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s34, #0]
    s.addi       s33, s18, #64
    v.st.b       [s28, #0], v28
    v.extract    s28, v30, #4
    s.add        s34, s28, s21
    s.add        s28, s6, s34
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s25, #0]
    s.addi       s25, s18, #96
    v.st.b       [s31, #0], v28
    v.extract    s31, v30, #5
    s.add        s34, s31, s21
    s.add        s31, s6, s34
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s30, #0]
    s.addi       s30, s18, #128
    v.st.b       [s32, #0], v28
    v.extract    s32, v30, #6
    s.add        s34, s32, s21
    s.add        s32, s6, s34
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s17, #0]
    s.addi       s17, s18, #160
    v.st.b       [s33, #0], v28
    v.extract    s33, v30, #7
    s.add        s34, s33, s21
    s.add        s33, s6, s34
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s20, #0]
    s.addi       s20, s18, #192
    v.st.b       [s25, #0], v28
    v.extract    s25, v30, #8
    s.add        s34, s25, s21
    s.add        s25, s6, s34
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s28, #0]
    s.addi       s28, s18, #224
    v.st.b       [s30, #0], v28
    v.extract    s30, v30, #9
    s.add        s34, s30, s21
    s.add        s30, s6, s34
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s31, #0]
    s.addi       s31, s18, #256
    v.st.b       [s17, #0], v28
    v.extract    s17, v30, #10
    s.add        s34, s17, s21
    s.add        s17, s6, s34
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s32, #0]
    s.addi       s32, s18, #288
    v.st.b       [s20, #0], v28
    v.extract    s20, v30, #11
    s.add        s34, s20, s21
    s.add        s20, s6, s34
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s33, #0]
    s.addi       s33, s18, #320
    v.st.b       [s28, #0], v28
    v.extract    s28, v30, #12
    s.add        s34, s28, s21
    s.add        s28, s6, s34
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s25, #0]
    s.addi       s25, s18, #352
    v.st.b       [s31, #0], v28
    v.extract    s31, v30, #13
    s.add        s34, s31, s21
    s.add        s31, s6, s34
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s30, #0]
    s.addi       s30, s18, #384
    v.st.b       [s32, #0], v28
    v.extract    s32, v30, #14
    s.add        s34, s32, s21
    s.add        s32, s6, s34
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s17, #0]
    s.addi       s17, s18, #416
    v.st.b       [s33, #0], v28
    v.extract    s33, v30, #15
    s.add        s34, s33, s21
    s.add        s33, s6, s34
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s20, #0]
    s.addi       s20, s18, #448
    v.st.b       [s25, #0], v28
    v.extract    s25, v30, #0
    s.add        s34, s25, s21
    s.addi       s25, s34, #16
    s.add        s34, s6, s25
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s28, #0]
    s.addi       s25, s18, #480
    v.st.b       [s30, #0], v28
    v.extract    s28, v30, #1
    s.add        s30, s28, s21
    s.addi       s28, s30, #16
    s.add        s30, s6, s28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s31, #0]
    s.addi       s28, s18, #16
    v.st.b       [s17, #0], v28
    v.extract    s17, v30, #2
    s.add        s31, s17, s21
    s.addi       s17, s31, #16
    s.add        s31, s6, s17
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s32, #0]
    s.addi       s17, s18, #48
    v.st.b       [s20, #0], v28
    v.extract    s20, v30, #3
    s.add        s32, s20, s21
    s.addi       s20, s32, #16
    s.add        s32, s6, s20
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s33, #0]
    s.addi       s20, s18, #80
    v.st.b       [s25, #0], v28
    v.extract    s25, v30, #4
    s.add        s33, s25, s21
    s.addi       s25, s33, #16
    s.add        s33, s6, s25
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s34, #0]
    s.addi       s25, s18, #112
    v.st.b       [s28, #0], v28
    v.extract    s28, v30, #5
    s.add        s34, s28, s21
    s.addi       s28, s34, #16
    s.add        s34, s6, s28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s30, #0]
    s.addi       s28, s18, #144
    v.st.b       [s17, #0], v28
    v.extract    s17, v30, #6
    s.add        s30, s17, s21
    s.addi       s17, s30, #16
    s.add        s30, s6, s17
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s31, #0]
    s.addi       s17, s18, #176
    v.st.b       [s20, #0], v28
    v.extract    s20, v30, #7
    s.add        s31, s20, s21
    s.addi       s20, s31, #16
    s.add        s31, s6, s20
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s32, #0]
    s.addi       s20, s18, #208
    v.st.b       [s25, #0], v28
    v.extract    s25, v30, #8
    s.add        s32, s25, s21
    s.addi       s25, s32, #16
    s.add        s32, s6, s25
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s33, #0]
    s.addi       s25, s18, #240
    v.st.b       [s28, #0], v28
    v.extract    s28, v30, #9
    s.add        s33, s28, s21
    s.addi       s28, s33, #16
    s.add        s33, s6, s28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s34, #0]
    s.addi       s28, s18, #272
    v.st.b       [s17, #0], v28
    v.extract    s17, v30, #10
    s.add        s34, s17, s21
    s.addi       s17, s34, #16
    s.add        s34, s6, s17
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s30, #0]
    s.addi       s17, s18, #304
    v.st.b       [s20, #0], v28
    v.extract    s20, v30, #11
    s.add        s30, s20, s21
    s.addi       s20, s30, #16
    s.add        s30, s6, s20
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s31, #0]
    s.addi       s20, s18, #336
    v.st.b       [s25, #0], v28
    v.extract    s25, v30, #12
    s.add        s31, s25, s21
    s.addi       s25, s31, #16
    s.add        s31, s6, s25
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s32, #0]
    s.addi       s25, s18, #368
    v.st.b       [s28, #0], v28
    v.extract    s28, v30, #13
    s.add        s32, s28, s21
    s.addi       s28, s32, #16
    s.add        s32, s6, s28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s33, #0]
    s.addi       s28, s18, #400
    v.st.b       [s17, #0], v28
    v.extract    s17, v30, #14
    s.add        s33, s17, s21
    s.addi       s17, s33, #16
    s.add        s33, s6, s17
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s34, #0]
    s.addi       s17, s18, #432
    v.st.b       [s20, #0], v28
    v.extract    s20, v30, #15
    s.add        s34, s20, s21
    s.addi       s20, s34, #16
    s.add        s34, s6, s20
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s30, #0]
    s.addi       s20, s18, #464
    v.st.b       [s25, #0], v28
    s.movz       s25, #256
    v.splat      v28, s25
    s.addi       s25, s18, #496
    v.mul        v29, v18, v28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s31, #0]
    v.extract    s30, v29, #0
    s.add        s31, s30, s21
    s.add        s30, s6, s31
    v.st.b       [s28, #0], v28
    v.extract    s28, v29, #1
    s.add        s31, s28, s21
    s.add        s28, s6, s31
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s32, #0]
    s.addi       s31, s16, #18432                // 512 bytes of repack scratch
    v.st.b       [s17, #0], v28
    s.addi       s17, s31, #0
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s33, #0]
    v.extract    s32, v29, #2
    s.add        s33, s32, s21
    s.add        s32, s6, s33
    v.st.b       [s20, #0], v28
    s.addi       s20, s31, #32
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s34, #0]
    v.extract    s33, v29, #3
    s.add        s34, s33, s21
    s.add        s33, s6, s34
    v.st.b       [s25, #0], v28
    s.addi       s25, s31, #64
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s30, #0]
    v.extract    s30, v29, #4
    s.add        s34, s30, s21
    s.add        s30, s6, s34
    v.st.b       [s17, #0], v28
    s.addi       s17, s31, #96
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s28, #0]
    v.extract    s28, v29, #5
    s.add        s34, s28, s21
    s.add        s28, s6, s34
    v.st.b       [s20, #0], v28
    s.addi       s20, s31, #128
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s32, #0]
    v.extract    s32, v29, #6
    s.add        s34, s32, s21
    s.add        s32, s6, s34
    v.st.b       [s25, #0], v28
    s.addi       s25, s31, #160
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s33, #0]
    v.extract    s33, v29, #7
    s.add        s34, s33, s21
    s.add        s33, s6, s34
    v.st.b       [s17, #0], v28
    s.addi       s17, s31, #192
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s30, #0]
    v.extract    s30, v29, #8
    s.add        s34, s30, s21
    s.add        s30, s6, s34
    v.st.b       [s20, #0], v28
    s.addi       s20, s31, #224
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s28, #0]
    v.extract    s28, v29, #9
    s.add        s34, s28, s21
    s.add        s28, s6, s34
    v.st.b       [s25, #0], v28
    s.addi       s25, s31, #256
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s32, #0]
    v.extract    s32, v29, #10
    s.add        s34, s32, s21
    s.add        s32, s6, s34
    v.st.b       [s17, #0], v28
    s.addi       s17, s31, #288
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s33, #0]
    v.extract    s33, v29, #11
    s.add        s34, s33, s21
    s.add        s33, s6, s34
    v.st.b       [s20, #0], v28
    s.addi       s20, s31, #320
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s30, #0]
    v.extract    s30, v29, #12
    s.add        s34, s30, s21
    s.add        s30, s6, s34
    v.st.b       [s25, #0], v28
    s.addi       s25, s31, #352
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s28, #0]
    v.extract    s28, v29, #13
    s.add        s34, s28, s21
    s.add        s28, s6, s34
    v.st.b       [s17, #0], v28
    s.addi       s17, s31, #384
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s32, #0]
    v.extract    s32, v29, #14
    s.add        s34, s32, s21
    s.add        s32, s6, s34
    v.st.b       [s20, #0], v28
    s.addi       s20, s31, #416
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s33, #0]
    v.extract    s33, v29, #15
    s.add        s34, s33, s21
    s.add        s33, s6, s34
    v.st.b       [s25, #0], v28
    s.addi       s25, s31, #448
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s30, #0]
    v.extract    s30, v29, #0
    s.add        s34, s30, s21
    s.addi       s30, s34, #16
    s.add        s34, s6, s30
    v.st.b       [s17, #0], v28
    s.addi       s17, s31, #480
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s28, #0]
    v.extract    s28, v29, #1
    s.add        s30, s28, s21
    s.addi       s28, s30, #16
    s.add        s30, s6, s28
    v.st.b       [s20, #0], v28
    s.addi       s20, s31, #16
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s32, #0]
    v.extract    s28, v29, #2
    s.add        s32, s28, s21
    s.addi       s28, s32, #16
    s.add        s32, s6, s28
    v.st.b       [s25, #0], v28
    s.addi       s25, s31, #48
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s33, #0]
    v.extract    s28, v29, #3
    s.add        s33, s28, s21
    s.addi       s28, s33, #16
    s.add        s33, s6, s28
    v.st.b       [s17, #0], v28
    s.addi       s17, s31, #80
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s34, #0]
    v.extract    s28, v29, #4
    s.add        s34, s28, s21
    s.addi       s28, s34, #16
    s.add        s34, s6, s28
    v.st.b       [s20, #0], v28
    s.addi       s20, s31, #112
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s30, #0]
    v.extract    s28, v29, #5
    s.add        s30, s28, s21
    s.addi       s28, s30, #16
    s.add        s30, s6, s28
    v.st.b       [s25, #0], v28
    s.addi       s25, s31, #144
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s32, #0]
    v.extract    s28, v29, #6
    s.add        s32, s28, s21
    s.addi       s28, s32, #16
    s.add        s32, s6, s28
    v.st.b       [s17, #0], v28
    s.addi       s17, s31, #176
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s33, #0]
    v.extract    s28, v29, #7
    s.add        s33, s28, s21
    s.addi       s28, s33, #16
    s.add        s33, s6, s28
    v.st.b       [s20, #0], v28
    s.addi       s20, s31, #208
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s34, #0]
    v.extract    s28, v29, #8
    s.add        s34, s28, s21
    s.addi       s28, s34, #16
    s.add        s34, s6, s28
    v.st.b       [s25, #0], v28
    s.addi       s25, s31, #240
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s30, #0]
    v.extract    s28, v29, #9
    s.add        s30, s28, s21
    s.addi       s28, s30, #16
    s.add        s30, s6, s28
    v.st.b       [s17, #0], v28
    s.addi       s17, s31, #272
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s32, #0]
    v.extract    s28, v29, #10
    s.add        s32, s28, s21
    s.addi       s28, s32, #16
    s.add        s32, s6, s28
    v.st.b       [s20, #0], v28
    s.addi       s20, s31, #304
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s33, #0]
    v.extract    s28, v29, #11
    s.add        s33, s28, s21
    s.addi       s28, s33, #16
    s.add        s33, s6, s28
    v.st.b       [s25, #0], v28
    s.addi       s25, s31, #336
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s34, #0]
    v.extract    s28, v29, #12
    s.add        s34, s28, s21
    s.addi       s28, s34, #16
    s.add        s34, s6, s28
    v.st.b       [s17, #0], v28
    s.addi       s17, s31, #368
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s30, #0]
    v.extract    s28, v29, #13
    s.add        s30, s28, s21
    s.addi       s28, s30, #16
    s.add        s30, s6, s28
    v.st.b       [s20, #0], v28
    s.addi       s20, s31, #400
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s32, #0]
    v.extract    s28, v29, #14
    s.add        s32, s28, s21
    s.addi       s28, s32, #16
    s.add        s32, s6, s28
    v.st.b       [s25, #0], v28
    s.addi       s25, s31, #432
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s33, #0]
    v.extract    s28, v29, #15
    s.add        s33, s28, s21
    s.addi       s28, s33, #16
    s.add        s33, s6, s28
    v.st.b       [s17, #0], v28
    s.addi       s17, s31, #464
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s34, #0]
    s.movz       s28, #256
    v.splat      v31, s28
    s.addi       s28, s31, #496
    v.mul        v32, v13, v31
    v.st.b       [s20, #0], v28
    v.extract    s20, v32, #0
    s.add        s34, s20, s21
    s.add        s20, s6, s34
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s30, #0]
    v.extract    s30, v32, #1
    s.add        s34, s30, s21
    s.add        s30, s6, s34
    v.st.b       [s25, #0], v28
    s.addi       s25, s16, #18944                // 512 bytes of repack scratch
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s32, #0]
    s.addi       s32, s25, #0
    v.st.b       [s17, #0], v28
    v.extract    s17, v32, #2
    s.add        s34, s17, s21
    s.add        s17, s6, s34
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s33, #0]
    s.addi       s33, s25, #32
    v.st.b       [s28, #0], v28
    v.extract    s28, v32, #3
    s.add        s34, s28, s21
    s.add        s28, s6, s34
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s20, #0]
    s.addi       s20, s25, #64
    v.st.b       [s32, #0], v28
    v.extract    s32, v32, #4
    s.add        s34, s32, s21
    s.add        s32, s6, s34
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s30, #0]
    s.addi       s30, s25, #96
    v.st.b       [s33, #0], v28
    v.extract    s33, v32, #5
    s.add        s34, s33, s21
    s.add        s33, s6, s34
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s17, #0]
    s.addi       s17, s25, #128
    v.st.b       [s20, #0], v28
    v.extract    s20, v32, #6
    s.add        s34, s20, s21
    s.add        s20, s6, s34
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s28, #0]
    s.addi       s28, s25, #160
    v.st.b       [s30, #0], v28
    v.extract    s30, v32, #7
    s.add        s34, s30, s21
    s.add        s30, s6, s34
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s32, #0]
    s.addi       s32, s25, #192
    v.st.b       [s17, #0], v28
    v.extract    s17, v32, #8
    s.add        s34, s17, s21
    s.add        s17, s6, s34
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s33, #0]
    s.addi       s33, s25, #224
    v.st.b       [s28, #0], v28
    v.extract    s28, v32, #9
    s.add        s34, s28, s21
    s.add        s28, s6, s34
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s20, #0]
    s.addi       s20, s25, #256
    v.st.b       [s32, #0], v28
    v.extract    s32, v32, #10
    s.add        s34, s32, s21
    s.add        s32, s6, s34
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s30, #0]
    s.addi       s30, s25, #288
    v.st.b       [s33, #0], v28
    v.extract    s33, v32, #11
    s.add        s34, s33, s21
    s.add        s33, s6, s34
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s17, #0]
    s.addi       s17, s25, #320
    v.st.b       [s20, #0], v28
    v.extract    s20, v32, #12
    s.add        s34, s20, s21
    s.add        s20, s6, s34
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s28, #0]
    s.addi       s28, s25, #352
    v.st.b       [s30, #0], v28
    v.extract    s30, v32, #13
    s.add        s34, s30, s21
    s.add        s30, s6, s34
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s32, #0]
    s.addi       s32, s25, #384
    v.st.b       [s17, #0], v28
    v.extract    s17, v32, #14
    s.add        s34, s17, s21
    s.add        s17, s6, s34
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s33, #0]
    s.addi       s33, s25, #416
    v.st.b       [s28, #0], v28
    v.extract    s28, v32, #15
    s.add        s34, s28, s21
    s.add        s28, s6, s34
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s20, #0]
    s.addi       s20, s25, #448
    v.st.b       [s32, #0], v28
    v.extract    s32, v32, #0
    s.add        s34, s32, s21
    s.addi       s32, s34, #16
    s.add        s34, s6, s32
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s30, #0]
    s.addi       s30, s25, #480
    v.st.b       [s33, #0], v28
    v.extract    s32, v32, #1
    s.add        s33, s32, s21
    s.addi       s32, s33, #16
    s.add        s33, s6, s32
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s17, #0]
    s.addi       s17, s25, #16
    v.st.b       [s20, #0], v28
    v.extract    s20, v32, #2
    s.add        s32, s20, s21
    s.addi       s20, s32, #16
    s.add        s32, s6, s20
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s28, #0]
    s.addi       s20, s25, #48
    v.st.b       [s30, #0], v28
    v.extract    s28, v32, #3
    s.add        s30, s28, s21
    s.addi       s28, s30, #16
    s.add        s30, s6, s28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s34, #0]
    s.addi       s28, s25, #80
    v.st.b       [s17, #0], v28
    v.extract    s17, v32, #4
    s.add        s34, s17, s21
    s.addi       s17, s34, #16
    s.add        s34, s6, s17
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s33, #0]
    s.addi       s17, s25, #112
    v.st.b       [s20, #0], v28
    v.extract    s20, v32, #5
    s.add        s33, s20, s21
    s.addi       s20, s33, #16
    s.add        s33, s6, s20
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s32, #0]
    s.addi       s20, s25, #144
    v.st.b       [s28, #0], v28
    v.extract    s28, v32, #6
    s.add        s32, s28, s21
    s.addi       s28, s32, #16
    s.add        s32, s6, s28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s30, #0]
    s.addi       s28, s25, #176
    v.st.b       [s17, #0], v28
    v.extract    s17, v32, #7
    s.add        s30, s17, s21
    s.addi       s17, s30, #16
    s.add        s30, s6, s17
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s34, #0]
    s.addi       s17, s25, #208
    v.st.b       [s20, #0], v28
    v.extract    s20, v32, #8
    s.add        s34, s20, s21
    s.addi       s20, s34, #16
    s.add        s34, s6, s20
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s33, #0]
    s.addi       s20, s25, #240
    v.st.b       [s28, #0], v28
    v.extract    s28, v32, #9
    s.add        s33, s28, s21
    s.addi       s28, s33, #16
    s.add        s33, s6, s28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s32, #0]
    s.addi       s28, s25, #272
    v.st.b       [s17, #0], v28
    v.extract    s17, v32, #10
    s.add        s32, s17, s21
    s.addi       s17, s32, #16
    s.add        s32, s6, s17
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s30, #0]
    s.addi       s17, s25, #304
    v.st.b       [s20, #0], v28
    v.extract    s20, v32, #11
    s.add        s30, s20, s21
    s.addi       s20, s30, #16
    s.add        s30, s6, s20
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s34, #0]
    s.addi       s20, s25, #336
    v.st.b       [s28, #0], v28
    v.extract    s28, v32, #12
    s.add        s34, s28, s21
    s.addi       s28, s34, #16
    s.add        s34, s6, s28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s33, #0]
    s.addi       s28, s25, #368
    v.st.b       [s17, #0], v28
    v.extract    s17, v32, #13
    s.add        s33, s17, s21
    s.addi       s17, s33, #16
    s.add        s33, s6, s17
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s32, #0]
    s.addi       s17, s25, #400
    v.st.b       [s20, #0], v28
    v.extract    s20, v32, #14
    s.add        s32, s20, s21
    s.addi       s20, s32, #16
    s.add        s32, s6, s20
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s30, #0]
    s.addi       s20, s25, #432
    v.st.b       [s28, #0], v28
    v.extract    s28, v32, #15
    s.add        s30, s28, s21
    s.addi       s28, s30, #16
    s.add        s30, s6, s28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s34, #0]
    s.addi       s28, s25, #464
    v.st.b       [s17, #0], v28
    s.addi       s17, s25, #496
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s33, #0]
    v.extract    s33, v8, #0
    v.st.b       [s20, #0], v28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s32, #0]
    v.st.b       [s28, #0], v28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s30, #0]
    v.st.b       [s17, #0], v28
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s33, x8dot_done_3
    s.movz       s17, #0
    s.add        s20, s4, s22
    s.addi       s28, s17, #0
    s.addi       s17, s16, #16640
x8dot_row_4:
    s.addi       s30, s29, #0
    v.movi       v28, #0
    s.sub        s32, s30, s28
    s.add        s30, s20, s28
    v.splat      v31, s32
    s.shli       s32, s28, #4
    s.addi       s34, s28, #1
    v.cmp.gt     p1, v31, v28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v28, [s30, v16]            // index is in elements (ISA sec 9.1)
    s.add        s30, s17, s32
    s.movz       s32, #32
    v.st.b       [s30, #0], v28
    fence.acq_rel.device
    s.mov        s28, s34
    s.cmp.lt     s30, s28, s32
    br.nz        s30, x8dot_row_4
x8dot_done_3:
    v.splat      v28, s33
    v.movi       v31, #0
    mb.arm       s17, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s20, #0
    v.extract    s28, v9, #0
    v.cmp.ne     p1, v28, v31
    v.cmp.eq     p2, v28, v31
    s.mov        s32, s20                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s20                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s32, s17            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s32, s28                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s20                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s32, s17          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s17
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s23, #0]
    s.addi       s20, s23, #64
    s.addi       s28, s23, #128
    s.addi       s30, s23, #192
    s.addi       s32, s23, #256
    s.addi       s33, s23, #320
    s.addi       s34, s23, #384
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s20, #0]
    s.addi       s20, s23, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s28, #0]
    s.addi       s28, s18, #64
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s30, #0]
    s.addi       s30, s18, #128
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s32, #0]
    s.addi       s32, s18, #192
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s33, #0]
    s.addi       s33, s18, #256
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s34, #0]
    s.addi       s34, s18, #320
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s20, #0]
    s.addi       s20, s18, #384
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s35, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a0, v56, v48, s35
    mb.wait      s35
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s18, #0]
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s28, #0]
    s.addi       s28, s18, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s30, #0]
    s.addi       s30, s31, #64
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s32, #0]
    s.addi       s32, s31, #128
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s33, #0]
    s.addi       s33, s31, #192
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s34, #0]
    s.addi       s34, s31, #256
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s20, #0]
    s.addi       s20, s31, #320
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s28, #0]
    s.addi       s28, s31, #384
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s36, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a4, v56, v48, s36
    mb.wait      s36
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s31, #0]
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s30, #0]
    s.addi       s30, s31, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s32, #0]
    s.addi       s32, s25, #64
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s33, #0]
    s.addi       s33, s25, #128
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s34, #0]
    s.addi       s34, s25, #192
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s20, #0]
    s.addi       s20, s25, #256
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s28, #0]
    s.addi       s28, s25, #320
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s30, #0]
    s.addi       s30, s25, #384
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s37, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v48, s37
    mb.wait      s37
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s25, #0]
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s32, #0]
    s.addi       s32, s25, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s33, #0]
    v.extract    s33, v8, #1
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s34, #0]
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s20, #0]
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s28, #0]
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s30, #0]
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s32, #0]
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s20, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a12, v56, v48, s20
    mb.wait      s20
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s33, x8dot_done_5
    s.movz       s28, #0
    s.add        s30, s4, s22
    s.addi       s32, s28, #0
    s.addi       s28, s16, #16640
x8dot_row_6:
    s.addi       s34, s29, #0
    v.movi       v28, #0
    s.sub        s38, s34, s32
    s.add        s34, s30, s32
    v.splat      v31, s38
    s.shli       s38, s32, #4
    s.addi       s39, s32, #1
    v.cmp.gt     p1, v31, v28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v28, [s34, v17]            // index is in elements (ISA sec 9.1)
    s.add        s34, s28, s38
    s.movz       s38, #32
    v.st.b       [s34, #0], v28
    fence.acq_rel.device
    s.mov        s32, s39
    s.cmp.lt     s34, s32, s38
    br.nz        s34, x8dot_row_6
x8dot_done_5:
    v.splat      v28, s33
    v.movi       v31, #0
    mb.arm       s28, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s30, #0
    v.extract    s32, v9, #1
    v.cmp.ne     p1, v28, v31
    v.cmp.eq     p2, v28, v31
    s.mov        s33, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s33, s28            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s33, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s33, s28          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s28
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s23, #0]
    s.addi       s30, s23, #64
    s.addi       s32, s23, #128
    s.addi       s33, s23, #192
    s.addi       s34, s23, #256
    s.addi       s38, s23, #320
    s.addi       s39, s23, #384
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s30, #0]
    s.addi       s30, s23, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s32, #0]
    s.addi       s32, s18, #64
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s33, #0]
    s.addi       s33, s18, #128
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s34, #0]
    s.addi       s34, s18, #192
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s38, #0]
    s.addi       s38, s18, #256
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s39, #0]
    s.addi       s39, s18, #320
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s30, #0]
    s.addi       s30, s18, #384
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s40, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a1, v56, v48, s40
    mb.wait      s40
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s18, #0]
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s32, #0]
    s.addi       s32, s18, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s33, #0]
    s.addi       s33, s31, #64
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s34, #0]
    s.addi       s34, s31, #128
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s38, #0]
    s.addi       s38, s31, #192
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s39, #0]
    s.addi       s39, s31, #256
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s30, #0]
    s.addi       s30, s31, #320
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s32, #0]
    s.addi       s32, s31, #384
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s41, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a5, v56, v48, s41
    mb.wait      s41
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s31, #0]
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s33, #0]
    s.addi       s33, s31, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s34, #0]
    s.addi       s34, s25, #64
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s38, #0]
    s.addi       s38, s25, #128
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s39, #0]
    s.addi       s39, s25, #192
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s30, #0]
    s.addi       s30, s25, #256
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s32, #0]
    s.addi       s32, s25, #320
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s33, #0]
    s.addi       s33, s25, #384
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s42
    mb.wait      s42
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s25, #0]
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s34, #0]
    s.addi       s34, s25, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s38, #0]
    v.extract    s38, v8, #2
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s39, #0]
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s30, #0]
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s32, #0]
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s33, #0]
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s34, #0]
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s30, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s30
    mb.wait      s30
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s38, x8dot_done_7
    s.movz       s32, #0
    s.add        s33, s4, s22
    s.addi       s34, s32, #0
    s.addi       s32, s16, #16640
x8dot_row_8:
    s.addi       s39, s29, #0
    v.movi       v28, #0
    s.sub        s43, s39, s34
    s.add        s39, s33, s34
    v.splat      v31, s43
    s.shli       s43, s34, #4
    s.addi       s44, s34, #1
    v.cmp.gt     p1, v31, v28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v28, [s39, v20]            // index is in elements (ISA sec 9.1)
    s.add        s39, s32, s43
    s.movz       s43, #32
    v.st.b       [s39, #0], v28
    fence.acq_rel.device
    s.mov        s34, s44
    s.cmp.lt     s39, s34, s43
    br.nz        s39, x8dot_row_8
x8dot_done_7:
    v.splat      v28, s38
    v.movi       v31, #0
    mb.arm       s32, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s33, #0
    v.extract    s34, v9, #2
    v.cmp.ne     p1, v28, v31
    v.cmp.eq     p2, v28, v31
    s.mov        s38, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s38, s32            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s38, s32          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s32
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s23, #0]
    s.addi       s33, s23, #64
    s.addi       s34, s23, #128
    s.addi       s38, s23, #192
    s.addi       s39, s23, #256
    s.addi       s43, s23, #320
    s.addi       s44, s23, #384
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s33, #0]
    s.addi       s33, s23, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s34, #0]
    s.addi       s34, s18, #64
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s38, #0]
    s.addi       s38, s18, #128
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s39, #0]
    s.addi       s39, s18, #192
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s43, #0]
    s.addi       s43, s18, #256
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s44, #0]
    s.addi       s44, s18, #320
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s33, #0]
    s.addi       s33, s18, #384
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s45, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a2, v56, v48, s45
    mb.wait      s45
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s18, #0]
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s34, #0]
    s.addi       s34, s18, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s38, #0]
    s.addi       s38, s31, #64
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s39, #0]
    s.addi       s39, s31, #128
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s43, #0]
    s.addi       s43, s31, #192
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s44, #0]
    s.addi       s44, s31, #256
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s33, #0]
    s.addi       s33, s31, #320
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s34, #0]
    s.addi       s34, s31, #384
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s46, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a6, v56, v48, s46
    mb.wait      s46
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s31, #0]
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s38, #0]
    s.addi       s38, s31, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s39, #0]
    s.addi       s39, s25, #64
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s43, #0]
    s.addi       s43, s25, #128
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s44, #0]
    s.addi       s44, s25, #192
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s33, #0]
    s.addi       s33, s25, #256
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s34, #0]
    s.addi       s34, s25, #320
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s38, #0]
    s.addi       s38, s25, #384
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s47, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a10, v56, v48, s47
    mb.wait      s47
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s25, #0]
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s39, #0]
    s.addi       s39, s25, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s43, #0]
    v.extract    s43, v8, #3
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s44, #0]
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s33, #0]
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s34, #0]
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s38, #0]
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s39, #0]
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s33, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a14, v56, v48, s33
    mb.wait      s33
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s43, x8dot_done_9
    s.movz       s34, #0
    s.add        s38, s4, s22
    s.addi       s39, s34, #0
    s.addi       s34, s16, #16640
x8dot_row_10:
    s.addi       s44, s29, #0
    v.movi       v28, #0
    s.sub        s48, s44, s39
    s.add        s44, s38, s39
    v.splat      v31, s48
    s.shli       s48, s39, #4
    s.addi       s49, s39, #1
    v.cmp.gt     p1, v31, v28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v28, [s44, v12]            // index is in elements (ISA sec 9.1)
    s.add        s44, s34, s48
    s.movz       s48, #32
    v.st.b       [s44, #0], v28
    fence.acq_rel.device
    s.mov        s39, s49
    s.cmp.lt     s44, s39, s48
    br.nz        s44, x8dot_row_10
x8dot_done_9:
    v.splat      v28, s43
    v.movi       v31, #0
    mb.arm       s34, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s38, #0
    v.extract    s39, v9, #3
    v.cmp.ne     p1, v28, v31
    v.cmp.eq     p2, v28, v31
    s.mov        s43, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s43, s34            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s43, s34          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s34
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s23, #0]
    s.addi       s38, s23, #64
    s.addi       s39, s23, #128
    s.addi       s43, s23, #192
    s.addi       s44, s23, #256
    s.addi       s48, s23, #320
    s.addi       s49, s23, #384
    s.addi       s50, s23, #448
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s38, #0]
    s.addi       s23, s18, #64
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s39, #0]
    s.addi       s38, s18, #128
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s43, #0]
    s.addi       s39, s18, #192
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s44, #0]
    s.addi       s43, s18, #256
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s48, #0]
    s.addi       s44, s18, #320
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s49, #0]
    s.addi       s48, s18, #384
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s50, #0]
    s.addi       s49, s18, #448
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s50, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a3, v56, v48, s50
    mb.wait      s50
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s18, #0]
    s.addi       s18, s31, #64
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s23, #0]
    s.addi       s23, s31, #128
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s38, #0]
    s.addi       s38, s31, #192
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s39, #0]
    s.addi       s39, s31, #256
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s43, #0]
    s.addi       s43, s31, #320
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s44, #0]
    s.addi       s44, s31, #384
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s48, #0]
    s.addi       s48, s31, #448
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s49, #0]
    s.addi       s49, s25, #64
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s51, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a7, v56, v48, s51
    mb.wait      s51
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s31, #0]
    s.addi       s31, s25, #128
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s18, #0]
    s.addi       s18, s25, #192
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s23, #0]
    s.addi       s23, s25, #256
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s38, #0]
    s.addi       s38, s25, #320
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s39, #0]
    s.addi       s39, s25, #384
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s43, #0]
    s.addi       s43, s25, #448
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s44, #0]
    s.movz       s44, #0
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s48, #0]
    s.add        s48, s44, s10                   // the tile origin
    s.add        s52, s44, s27                   // the tile origin
    v.splat      v31, s48
    v.extract    s44, v26, #0
    v.splat      v33, s52
    s.add        s48, s44, s21
    v.add        v34, v1, v31
    s.addi       s44, s48, #32
    v.extract    s48, v26, #1
    s.add        s52, s6, s44
    v.cmp.lt     p1, v34, v33
    s.add        s44, s48, s21
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s48, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s53, s44, #32
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s48
    mb.wait      s48
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s25, #0]
    s.addi       s25, s16, #19456                // 512 bytes of repack scratch
    s.add        s44, s6, s53
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s49, #0]
    s.addi       s49, s25, #0
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s31, #0]
    v.extract    s31, v26, #2
    s.add        s53, s31, s21
    s.addi       s31, s53, #32
    s.add        s53, s6, s31
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s18, #0]
    s.addi       s18, s25, #32
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s23, #0]
    v.extract    s23, v26, #3
    s.add        s31, s23, s21
    s.addi       s23, s31, #32
    s.add        s31, s6, s23
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s38, #0]
    s.addi       s23, s25, #64
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s39, #0]
    v.extract    s38, v26, #4
    s.add        s39, s38, s21
    s.addi       s38, s39, #32
    s.add        s39, s6, s38
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s43, #0]
    s.addi       s38, s25, #96
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s43, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s43
    mb.wait      s43
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s52, #0]
    v.extract    s52, v26, #5
    s.add        s54, s52, s21
    s.addi       s52, s54, #32
    s.add        s54, s6, s52
    v.st.b       [s49, #0], v28
    s.addi       s49, s25, #128
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s44, #0]
    v.extract    s44, v26, #6
    s.add        s52, s44, s21
    s.addi       s44, s52, #32
    s.add        s52, s6, s44
    v.st.b       [s18, #0], v28
    s.addi       s18, s25, #160
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s53, #0]
    v.extract    s44, v26, #7
    s.add        s53, s44, s21
    s.addi       s44, s53, #32
    s.add        s53, s6, s44
    v.st.b       [s23, #0], v28
    s.addi       s23, s25, #192
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s31, #0]
    v.extract    s31, v26, #8
    s.add        s44, s31, s21
    s.addi       s31, s44, #32
    s.add        s44, s6, s31
    v.st.b       [s38, #0], v28
    s.addi       s31, s25, #224
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s39, #0]
    v.extract    s38, v26, #9
    s.add        s39, s38, s21
    s.addi       s38, s39, #32
    s.add        s39, s6, s38
    v.st.b       [s49, #0], v28
    s.addi       s38, s25, #256
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s54, #0]
    v.extract    s49, v26, #10
    s.add        s54, s49, s21
    s.addi       s49, s54, #32
    s.add        s54, s6, s49
    v.st.b       [s18, #0], v28
    s.addi       s18, s25, #288
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s52, #0]
    v.extract    s49, v26, #11
    s.add        s52, s49, s21
    s.addi       s49, s52, #32
    s.add        s52, s6, s49
    v.st.b       [s23, #0], v28
    s.addi       s23, s25, #320
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s53, #0]
    v.extract    s49, v26, #12
    s.add        s53, s49, s21
    s.addi       s49, s53, #32
    s.add        s53, s6, s49
    v.st.b       [s31, #0], v28
    s.addi       s31, s25, #352
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s44, #0]
    v.extract    s44, v26, #13
    s.add        s49, s44, s21
    s.addi       s44, s49, #32
    s.add        s49, s6, s44
    v.st.b       [s38, #0], v28
    s.addi       s38, s25, #384
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s39, #0]
    v.extract    s39, v26, #14
    s.add        s44, s39, s21
    s.addi       s39, s44, #32
    s.add        s44, s6, s39
    v.st.b       [s18, #0], v28
    s.addi       s18, s25, #416
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s54, #0]
    v.extract    s39, v26, #15
    s.add        s54, s39, s21
    s.addi       s39, s54, #32
    s.add        s54, s6, s39
    v.st.b       [s23, #0], v28
    s.addi       s23, s25, #448
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s52, #0]
    s.movz       s39, #0
    v.st.b       [s31, #0], v28
    s.add        s31, s39, s11                   // the tile origin
    s.add        s52, s39, s27                   // the tile origin
    v.splat      v28, s31
    v.extract    s31, v26, #0
    v.splat      v31, s52
    s.add        s39, s31, s21
    v.add        v33, v1, v28
    s.addi       s31, s39, #48
    s.addi       s39, s25, #480
    s.add        s52, s6, s31
    v.cmp.lt     p2, v33, v31
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s53, #0]
    v.extract    s31, v26, #1
    s.add        s53, s31, s21
    s.addi       s31, s53, #48
    s.add        s53, s6, s31
    v.st.b       [s38, #0], v28
    s.addi       s31, s25, #16
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s49, #0]
    v.extract    s38, v26, #2
    s.add        s49, s38, s21
    s.addi       s38, s49, #48
    s.add        s49, s6, s38
    v.st.b       [s18, #0], v28
    s.addi       s18, s25, #48
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s44, #0]
    v.extract    s38, v26, #3
    s.add        s44, s38, s21
    s.addi       s38, s44, #48
    s.add        s44, s6, s38
    v.st.b       [s23, #0], v28
    s.addi       s23, s25, #80
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s54, #0]
    v.extract    s38, v26, #4
    s.add        s54, s38, s21
    s.addi       s38, s54, #48
    s.add        s54, s6, s38
    v.st.b       [s39, #0], v28
    s.addi       s38, s25, #112
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s52, #0]
    v.extract    s39, v26, #5
    s.add        s52, s39, s21
    s.addi       s39, s52, #48
    s.add        s52, s6, s39
    v.st.b       [s31, #0], v28
    s.addi       s31, s25, #144
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s53, #0]
    v.extract    s39, v26, #6
    s.add        s53, s39, s21
    s.addi       s39, s53, #48
    s.add        s53, s6, s39
    v.st.b       [s18, #0], v28
    s.addi       s18, s25, #176
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s49, #0]
    v.extract    s39, v26, #7
    s.add        s49, s39, s21
    s.addi       s39, s49, #48
    s.add        s49, s6, s39
    v.st.b       [s23, #0], v28
    s.addi       s23, s25, #208
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s44, #0]
    v.extract    s39, v26, #8
    s.add        s44, s39, s21
    s.addi       s39, s44, #48
    s.add        s44, s6, s39
    v.st.b       [s38, #0], v28
    s.addi       s38, s25, #240
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s54, #0]
    v.extract    s39, v26, #9
    s.add        s54, s39, s21
    s.addi       s39, s54, #48
    s.add        s54, s6, s39
    v.st.b       [s31, #0], v28
    s.addi       s31, s25, #272
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s52, #0]
    v.extract    s39, v26, #10
    s.add        s52, s39, s21
    s.addi       s39, s52, #48
    s.add        s52, s6, s39
    v.st.b       [s18, #0], v28
    s.addi       s18, s25, #304
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s53, #0]
    v.extract    s39, v26, #11
    s.add        s53, s39, s21
    s.addi       s39, s53, #48
    s.add        s53, s6, s39
    v.st.b       [s23, #0], v28
    s.addi       s23, s25, #336
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s49, #0]
    v.extract    s39, v26, #12
    s.add        s49, s39, s21
    s.addi       s39, s49, #48
    s.add        s49, s6, s39
    v.st.b       [s38, #0], v28
    s.addi       s38, s25, #368
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s44, #0]
    v.extract    s39, v26, #13
    s.add        s44, s39, s21
    s.addi       s39, s44, #48
    s.add        s44, s6, s39
    v.st.b       [s31, #0], v28
    s.addi       s31, s25, #400
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s54, #0]
    v.extract    s39, v26, #14
    s.add        s54, s39, s21
    s.addi       s39, s54, #48
    s.add        s54, s6, s39
    v.st.b       [s18, #0], v28
    s.addi       s18, s25, #432
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s52, #0]
    v.extract    s39, v26, #15
    s.add        s52, s39, s21
    s.addi       s39, s52, #48
    s.add        s52, s6, s39
    v.st.b       [s23, #0], v28
    s.addi       s23, s25, #464
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s53, #0]
    v.extract    s39, v30, #0
    s.add        s53, s39, s21
    s.addi       s39, s53, #32
    s.add        s53, s6, s39
    v.st.b       [s38, #0], v28
    s.addi       s38, s25, #496
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s49, #0]
    v.extract    s39, v30, #1
    s.add        s49, s39, s21
    s.addi       s39, s49, #32
    s.add        s49, s6, s39
    v.st.b       [s31, #0], v28
    s.addi       s31, s16, #19968                // 512 bytes of repack scratch
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s44, #0]
    s.addi       s39, s31, #0
    v.st.b       [s18, #0], v28
    v.extract    s18, v30, #2
    s.add        s44, s18, s21
    s.addi       s18, s44, #32
    s.add        s44, s6, s18
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s54, #0]
    s.addi       s18, s31, #32
    v.st.b       [s23, #0], v28
    v.extract    s23, v30, #3
    s.add        s54, s23, s21
    s.addi       s23, s54, #32
    s.add        s54, s6, s23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s52, #0]
    s.addi       s23, s31, #64
    v.st.b       [s38, #0], v28
    v.extract    s38, v30, #4
    s.add        s52, s38, s21
    s.addi       s38, s52, #32
    s.add        s52, s6, s38
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s53, #0]
    s.addi       s38, s31, #96
    v.st.b       [s39, #0], v28
    v.extract    s39, v30, #5
    s.add        s53, s39, s21
    s.addi       s39, s53, #32
    s.add        s53, s6, s39
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s49, #0]
    s.addi       s39, s31, #128
    v.st.b       [s18, #0], v28
    v.extract    s18, v30, #6
    s.add        s49, s18, s21
    s.addi       s18, s49, #32
    s.add        s49, s6, s18
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s44, #0]
    s.addi       s18, s31, #160
    v.st.b       [s23, #0], v28
    v.extract    s23, v30, #7
    s.add        s44, s23, s21
    s.addi       s23, s44, #32
    s.add        s44, s6, s23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s54, #0]
    s.addi       s23, s31, #192
    v.st.b       [s38, #0], v28
    v.extract    s38, v30, #8
    s.add        s54, s38, s21
    s.addi       s38, s54, #32
    s.add        s54, s6, s38
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s52, #0]
    s.addi       s38, s31, #224
    v.st.b       [s39, #0], v28
    v.extract    s39, v30, #9
    s.add        s52, s39, s21
    s.addi       s39, s52, #32
    s.add        s52, s6, s39
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s53, #0]
    s.addi       s39, s31, #256
    v.st.b       [s18, #0], v28
    v.extract    s18, v30, #10
    s.add        s53, s18, s21
    s.addi       s18, s53, #32
    s.add        s53, s6, s18
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s49, #0]
    s.addi       s18, s31, #288
    v.st.b       [s23, #0], v28
    v.extract    s23, v30, #11
    s.add        s49, s23, s21
    s.addi       s23, s49, #32
    s.add        s49, s6, s23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s44, #0]
    s.addi       s23, s31, #320
    v.st.b       [s38, #0], v28
    v.extract    s38, v30, #12
    s.add        s44, s38, s21
    s.addi       s38, s44, #32
    s.add        s44, s6, s38
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s54, #0]
    s.addi       s38, s31, #352
    v.st.b       [s39, #0], v28
    v.extract    s39, v30, #13
    s.add        s54, s39, s21
    s.addi       s39, s54, #32
    s.add        s54, s6, s39
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s52, #0]
    s.addi       s39, s31, #384
    v.st.b       [s18, #0], v28
    v.extract    s18, v30, #14
    s.add        s52, s18, s21
    s.addi       s18, s52, #32
    s.add        s52, s6, s18
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s53, #0]
    s.addi       s18, s31, #416
    v.st.b       [s23, #0], v28
    v.extract    s23, v30, #15
    s.add        s53, s23, s21
    s.addi       s23, s53, #32
    s.add        s53, s6, s23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s49, #0]
    s.addi       s23, s31, #448
    v.st.b       [s38, #0], v28
    v.extract    s38, v30, #0
    s.add        s49, s38, s21
    s.addi       s38, s49, #48
    s.add        s49, s6, s38
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s44, #0]
    s.addi       s38, s31, #480
    v.st.b       [s39, #0], v28
    v.extract    s39, v30, #1
    s.add        s44, s39, s21
    s.addi       s39, s44, #48
    s.add        s44, s6, s39
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s54, #0]
    s.addi       s39, s31, #16
    v.st.b       [s18, #0], v28
    v.extract    s18, v30, #2
    s.add        s54, s18, s21
    s.addi       s18, s54, #48
    s.add        s54, s6, s18
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s52, #0]
    s.addi       s18, s31, #48
    v.st.b       [s23, #0], v28
    v.extract    s23, v30, #3
    s.add        s52, s23, s21
    s.addi       s23, s52, #48
    s.add        s52, s6, s23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s53, #0]
    s.addi       s23, s31, #80
    v.st.b       [s38, #0], v28
    v.extract    s38, v30, #4
    s.add        s53, s38, s21
    s.addi       s38, s53, #48
    s.add        s53, s6, s38
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s49, #0]
    s.addi       s38, s31, #112
    v.st.b       [s39, #0], v28
    v.extract    s39, v30, #5
    s.add        s49, s39, s21
    s.addi       s39, s49, #48
    s.add        s49, s6, s39
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s44, #0]
    s.addi       s39, s31, #144
    v.st.b       [s18, #0], v28
    v.extract    s18, v30, #6
    s.add        s44, s18, s21
    s.addi       s18, s44, #48
    s.add        s44, s6, s18
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s54, #0]
    s.addi       s18, s31, #176
    v.st.b       [s23, #0], v28
    v.extract    s23, v30, #7
    s.add        s54, s23, s21
    s.addi       s23, s54, #48
    s.add        s54, s6, s23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s52, #0]
    s.addi       s23, s31, #208
    v.st.b       [s38, #0], v28
    v.extract    s38, v30, #8
    s.add        s52, s38, s21
    s.addi       s38, s52, #48
    s.add        s52, s6, s38
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s53, #0]
    s.addi       s38, s31, #240
    v.st.b       [s39, #0], v28
    v.extract    s39, v30, #9
    s.add        s53, s39, s21
    s.addi       s39, s53, #48
    s.add        s53, s6, s39
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s49, #0]
    s.addi       s39, s31, #272
    v.st.b       [s18, #0], v28
    v.extract    s18, v30, #10
    s.add        s49, s18, s21
    s.addi       s18, s49, #48
    s.add        s49, s6, s18
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s44, #0]
    s.addi       s18, s31, #304
    v.st.b       [s23, #0], v28
    v.extract    s23, v30, #11
    s.add        s44, s23, s21
    s.addi       s23, s44, #48
    s.add        s44, s6, s23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s54, #0]
    s.addi       s23, s31, #336
    v.st.b       [s38, #0], v28
    v.extract    s38, v30, #12
    s.add        s54, s38, s21
    s.addi       s38, s54, #48
    s.add        s54, s6, s38
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s52, #0]
    s.addi       s38, s31, #368
    v.st.b       [s39, #0], v28
    v.extract    s39, v30, #13
    s.add        s52, s39, s21
    s.addi       s39, s52, #48
    s.add        s52, s6, s39
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s53, #0]
    s.addi       s39, s31, #400
    v.st.b       [s18, #0], v28
    v.extract    s18, v30, #14
    s.add        s53, s18, s21
    s.addi       s18, s53, #48
    s.add        s53, s6, s18
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s49, #0]
    s.addi       s18, s31, #432
    v.st.b       [s23, #0], v28
    v.extract    s23, v30, #15
    s.add        s49, s23, s21
    s.addi       s23, s49, #48
    s.add        s49, s6, s23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s44, #0]
    s.addi       s23, s31, #464
    v.st.b       [s38, #0], v28
    v.extract    s38, v29, #0
    s.add        s44, s38, s21
    s.addi       s38, s44, #32
    s.add        s44, s6, s38
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s54, #0]
    s.addi       s38, s31, #496
    v.st.b       [s39, #0], v28
    v.extract    s39, v29, #1
    s.add        s54, s39, s21
    s.addi       s39, s54, #32
    s.add        s54, s6, s39
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s52, #0]
    s.addi       s39, s16, #20480                // 512 bytes of repack scratch
    v.st.b       [s18, #0], v28
    s.addi       s18, s39, #0
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s53, #0]
    v.extract    s52, v29, #2
    s.add        s53, s52, s21
    s.addi       s52, s53, #32
    s.add        s53, s6, s52
    v.st.b       [s23, #0], v28
    s.addi       s23, s39, #32
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s49, #0]
    v.extract    s49, v29, #3
    s.add        s52, s49, s21
    s.addi       s49, s52, #32
    s.add        s52, s6, s49
    v.st.b       [s38, #0], v28
    s.addi       s38, s39, #64
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s44, #0]
    v.extract    s44, v29, #4
    s.add        s49, s44, s21
    s.addi       s44, s49, #32
    s.add        s49, s6, s44
    v.st.b       [s18, #0], v28
    s.addi       s18, s39, #96
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s54, #0]
    v.extract    s44, v29, #5
    s.add        s54, s44, s21
    s.addi       s44, s54, #32
    s.add        s54, s6, s44
    v.st.b       [s23, #0], v28
    s.addi       s23, s39, #128
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s53, #0]
    v.extract    s44, v29, #6
    s.add        s53, s44, s21
    s.addi       s44, s53, #32
    s.add        s53, s6, s44
    v.st.b       [s38, #0], v28
    s.addi       s38, s39, #160
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s52, #0]
    v.extract    s44, v29, #7
    s.add        s52, s44, s21
    s.addi       s44, s52, #32
    s.add        s52, s6, s44
    v.st.b       [s18, #0], v28
    s.addi       s18, s39, #192
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s49, #0]
    v.extract    s44, v29, #8
    s.add        s49, s44, s21
    s.addi       s44, s49, #32
    s.add        s49, s6, s44
    v.st.b       [s23, #0], v28
    s.addi       s23, s39, #224
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s54, #0]
    v.extract    s44, v29, #9
    s.add        s54, s44, s21
    s.addi       s44, s54, #32
    s.add        s54, s6, s44
    v.st.b       [s38, #0], v28
    s.addi       s38, s39, #256
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s53, #0]
    v.extract    s44, v29, #10
    s.add        s53, s44, s21
    s.addi       s44, s53, #32
    s.add        s53, s6, s44
    v.st.b       [s18, #0], v28
    s.addi       s18, s39, #288
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s52, #0]
    v.extract    s44, v29, #11
    s.add        s52, s44, s21
    s.addi       s44, s52, #32
    s.add        s52, s6, s44
    v.st.b       [s23, #0], v28
    s.addi       s23, s39, #320
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s49, #0]
    v.extract    s44, v29, #12
    s.add        s49, s44, s21
    s.addi       s44, s49, #32
    s.add        s49, s6, s44
    v.st.b       [s38, #0], v28
    s.addi       s38, s39, #352
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s54, #0]
    v.extract    s44, v29, #13
    s.add        s54, s44, s21
    s.addi       s44, s54, #32
    s.add        s54, s6, s44
    v.st.b       [s18, #0], v28
    s.addi       s18, s39, #384
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s53, #0]
    v.extract    s44, v29, #14
    s.add        s53, s44, s21
    s.addi       s44, s53, #32
    s.add        s53, s6, s44
    v.st.b       [s23, #0], v28
    s.addi       s23, s39, #416
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s52, #0]
    v.extract    s44, v29, #15
    s.add        s52, s44, s21
    s.addi       s44, s52, #32
    s.add        s52, s6, s44
    v.st.b       [s38, #0], v28
    s.addi       s38, s39, #448
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s49, #0]
    v.extract    s44, v29, #0
    s.add        s49, s44, s21
    s.addi       s44, s49, #48
    s.add        s49, s6, s44
    v.st.b       [s18, #0], v28
    s.addi       s18, s39, #480
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s54, #0]
    v.extract    s44, v29, #1
    s.add        s54, s44, s21
    s.addi       s44, s54, #48
    s.add        s54, s6, s44
    v.st.b       [s23, #0], v28
    s.addi       s23, s39, #16
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s53, #0]
    v.extract    s44, v29, #2
    s.add        s53, s44, s21
    s.addi       s44, s53, #48
    s.add        s53, s6, s44
    v.st.b       [s38, #0], v28
    s.addi       s38, s39, #48
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s52, #0]
    v.extract    s44, v29, #3
    s.add        s52, s44, s21
    s.addi       s44, s52, #48
    s.add        s52, s6, s44
    v.st.b       [s18, #0], v28
    s.addi       s18, s39, #80
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s49, #0]
    v.extract    s44, v29, #4
    s.add        s49, s44, s21
    s.addi       s44, s49, #48
    s.add        s49, s6, s44
    v.st.b       [s23, #0], v28
    s.addi       s23, s39, #112
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s54, #0]
    v.extract    s44, v29, #5
    s.add        s54, s44, s21
    s.addi       s44, s54, #48
    s.add        s54, s6, s44
    v.st.b       [s38, #0], v28
    s.addi       s38, s39, #144
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s53, #0]
    v.extract    s44, v29, #6
    s.add        s53, s44, s21
    s.addi       s44, s53, #48
    s.add        s53, s6, s44
    v.st.b       [s18, #0], v28
    s.addi       s18, s39, #176
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s52, #0]
    v.extract    s44, v29, #7
    s.add        s52, s44, s21
    s.addi       s44, s52, #48
    s.add        s52, s6, s44
    v.st.b       [s23, #0], v28
    s.addi       s23, s39, #208
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s49, #0]
    v.extract    s44, v29, #8
    s.add        s49, s44, s21
    s.addi       s44, s49, #48
    s.add        s49, s6, s44
    v.st.b       [s38, #0], v28
    s.addi       s38, s39, #240
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s54, #0]
    v.extract    s44, v29, #9
    s.add        s54, s44, s21
    s.addi       s44, s54, #48
    s.add        s54, s6, s44
    v.st.b       [s18, #0], v28
    s.addi       s18, s39, #272
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s53, #0]
    v.extract    s44, v29, #10
    s.add        s53, s44, s21
    s.addi       s44, s53, #48
    s.add        s53, s6, s44
    v.st.b       [s23, #0], v28
    s.addi       s23, s39, #304
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s52, #0]
    v.extract    s44, v29, #11
    s.add        s52, s44, s21
    s.addi       s44, s52, #48
    s.add        s52, s6, s44
    v.st.b       [s38, #0], v28
    s.addi       s38, s39, #336
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s49, #0]
    v.extract    s44, v29, #12
    s.add        s49, s44, s21
    s.addi       s44, s49, #48
    s.add        s49, s6, s44
    v.st.b       [s18, #0], v28
    s.addi       s18, s39, #368
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s54, #0]
    v.extract    s44, v29, #13
    s.add        s54, s44, s21
    s.addi       s44, s54, #48
    s.add        s54, s6, s44
    v.st.b       [s23, #0], v28
    s.addi       s23, s39, #400
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s53, #0]
    v.extract    s44, v29, #14
    s.add        s53, s44, s21
    s.addi       s44, s53, #48
    s.add        s53, s6, s44
    v.st.b       [s38, #0], v28
    s.addi       s38, s39, #432
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s52, #0]
    v.extract    s44, v29, #15
    s.add        s52, s44, s21
    s.addi       s44, s52, #48
    s.add        s52, s6, s44
    v.st.b       [s18, #0], v28
    s.addi       s18, s39, #464
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s49, #0]
    v.extract    s44, v32, #0
    s.add        s49, s44, s21
    s.addi       s44, s49, #32
    s.add        s49, s6, s44
    v.st.b       [s23, #0], v28
    s.addi       s23, s39, #496
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s54, #0]
    v.extract    s44, v32, #1
    s.add        s54, s44, s21
    s.addi       s44, s54, #32
    s.add        s54, s6, s44
    v.st.b       [s38, #0], v28
    s.addi       s38, s16, #20992                // 512 bytes of repack scratch
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s53, #0]
    s.addi       s44, s38, #0
    v.st.b       [s18, #0], v28
    v.extract    s18, v32, #2
    s.add        s53, s18, s21
    s.addi       s18, s53, #32
    s.add        s53, s6, s18
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s52, #0]
    s.addi       s18, s38, #32
    v.st.b       [s23, #0], v28
    v.extract    s23, v32, #3
    s.add        s52, s23, s21
    s.addi       s23, s52, #32
    s.add        s52, s6, s23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s49, #0]
    s.addi       s23, s38, #64
    v.st.b       [s44, #0], v28
    v.extract    s44, v32, #4
    s.add        s49, s44, s21
    s.addi       s44, s49, #32
    s.add        s49, s6, s44
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s54, #0]
    s.addi       s44, s38, #96
    v.st.b       [s18, #0], v28
    v.extract    s18, v32, #5
    s.add        s54, s18, s21
    s.addi       s18, s54, #32
    s.add        s54, s6, s18
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s53, #0]
    s.addi       s18, s38, #128
    v.st.b       [s23, #0], v28
    v.extract    s23, v32, #6
    s.add        s53, s23, s21
    s.addi       s23, s53, #32
    s.add        s53, s6, s23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s52, #0]
    s.addi       s23, s38, #160
    v.st.b       [s44, #0], v28
    v.extract    s44, v32, #7
    s.add        s52, s44, s21
    s.addi       s44, s52, #32
    s.add        s52, s6, s44
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s49, #0]
    s.addi       s44, s38, #192
    v.st.b       [s18, #0], v28
    v.extract    s18, v32, #8
    s.add        s49, s18, s21
    s.addi       s18, s49, #32
    s.add        s49, s6, s18
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s54, #0]
    s.addi       s18, s38, #224
    v.st.b       [s23, #0], v28
    v.extract    s23, v32, #9
    s.add        s54, s23, s21
    s.addi       s23, s54, #32
    s.add        s54, s6, s23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s53, #0]
    s.addi       s23, s38, #256
    v.st.b       [s44, #0], v28
    v.extract    s44, v32, #10
    s.add        s53, s44, s21
    s.addi       s44, s53, #32
    s.add        s53, s6, s44
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s52, #0]
    s.addi       s44, s38, #288
    v.st.b       [s18, #0], v28
    v.extract    s18, v32, #11
    s.add        s52, s18, s21
    s.addi       s18, s52, #32
    s.add        s52, s6, s18
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s49, #0]
    s.addi       s18, s38, #320
    v.st.b       [s23, #0], v28
    v.extract    s23, v32, #12
    s.add        s49, s23, s21
    s.addi       s23, s49, #32
    s.add        s49, s6, s23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s54, #0]
    s.addi       s23, s38, #352
    v.st.b       [s44, #0], v28
    v.extract    s44, v32, #13
    s.add        s54, s44, s21
    s.addi       s44, s54, #32
    s.add        s54, s6, s44
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s53, #0]
    s.addi       s44, s38, #384
    v.st.b       [s18, #0], v28
    v.extract    s18, v32, #14
    s.add        s53, s18, s21
    s.addi       s18, s53, #32
    s.add        s53, s6, s18
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s52, #0]
    s.addi       s18, s38, #416
    v.st.b       [s23, #0], v28
    v.extract    s23, v32, #15
    s.add        s52, s23, s21
    s.addi       s23, s52, #32
    s.add        s52, s6, s23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s49, #0]
    s.addi       s23, s38, #448
    v.st.b       [s44, #0], v28
    v.extract    s44, v32, #0
    s.add        s49, s44, s21
    s.addi       s44, s49, #48
    s.add        s49, s6, s44
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s54, #0]
    s.addi       s44, s38, #480
    v.st.b       [s18, #0], v28
    v.extract    s18, v32, #1
    s.add        s54, s18, s21
    s.addi       s18, s54, #48
    s.add        s54, s6, s18
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s53, #0]
    s.addi       s18, s38, #16
    v.st.b       [s23, #0], v28
    v.extract    s23, v32, #2
    s.add        s53, s23, s21
    s.addi       s23, s53, #48
    s.add        s53, s6, s23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s52, #0]
    s.addi       s23, s38, #48
    v.st.b       [s44, #0], v28
    v.extract    s44, v32, #3
    s.add        s52, s44, s21
    s.addi       s44, s52, #48
    s.add        s52, s6, s44
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s49, #0]
    s.addi       s44, s38, #80
    v.st.b       [s18, #0], v28
    v.extract    s18, v32, #4
    s.add        s49, s18, s21
    s.addi       s18, s49, #48
    s.add        s49, s6, s18
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s54, #0]
    s.addi       s18, s38, #112
    v.st.b       [s23, #0], v28
    v.extract    s23, v32, #5
    s.add        s54, s23, s21
    s.addi       s23, s54, #48
    s.add        s54, s6, s23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s53, #0]
    s.addi       s23, s38, #144
    v.st.b       [s44, #0], v28
    v.extract    s44, v32, #6
    s.add        s53, s44, s21
    s.addi       s44, s53, #48
    s.add        s53, s6, s44
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s52, #0]
    s.addi       s44, s38, #176
    v.st.b       [s18, #0], v28
    v.extract    s18, v32, #7
    s.add        s52, s18, s21
    s.addi       s18, s52, #48
    s.add        s52, s6, s18
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s49, #0]
    s.addi       s18, s38, #208
    v.st.b       [s23, #0], v28
    v.extract    s23, v32, #8
    s.add        s49, s23, s21
    s.addi       s23, s49, #48
    s.add        s49, s6, s23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s54, #0]
    s.addi       s23, s38, #240
    v.st.b       [s44, #0], v28
    v.extract    s44, v32, #9
    s.add        s54, s44, s21
    s.addi       s44, s54, #48
    s.add        s54, s6, s44
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s53, #0]
    s.addi       s44, s38, #272
    v.st.b       [s18, #0], v28
    v.extract    s18, v32, #10
    s.add        s53, s18, s21
    s.addi       s18, s53, #48
    s.add        s53, s6, s18
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s52, #0]
    s.addi       s18, s38, #304
    v.st.b       [s23, #0], v28
    v.extract    s23, v32, #11
    s.add        s52, s23, s21
    s.addi       s23, s52, #48
    s.add        s52, s6, s23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s49, #0]
    s.addi       s23, s38, #336
    v.st.b       [s44, #0], v28
    v.extract    s44, v32, #12
    s.add        s49, s44, s21
    s.addi       s44, s49, #48
    s.add        s49, s6, s44
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s54, #0]
    s.addi       s44, s38, #368
    v.st.b       [s18, #0], v28
    v.extract    s18, v32, #13
    s.add        s54, s18, s21
    s.addi       s18, s54, #48
    s.add        s54, s6, s18
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s53, #0]
    s.addi       s18, s38, #400
    v.st.b       [s23, #0], v28
    v.extract    s23, v32, #14
    s.add        s53, s23, s21
    s.addi       s23, s53, #48
    s.add        s53, s6, s23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s52, #0]
    s.addi       s23, s38, #432
    v.st.b       [s44, #0], v28
    v.extract    s44, v32, #15
    s.add        s52, s44, s21
    s.addi       s44, s52, #48
    s.add        s52, s6, s44
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s49, #0]
    s.addi       s44, s38, #464
    v.st.b       [s18, #0], v28
    s.addi       s18, s38, #496
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s54, #0]
    v.extract    s49, v8, #0
    v.st.b       [s23, #0], v28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s53, #0]
    v.st.b       [s44, #0], v28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s52, #0]
    v.st.b       [s18, #0], v28
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s49, x8dot_done_11
    s.movz       s18, #0
    s.add        s23, s4, s22
    s.addi       s44, s18, #0
    s.addi       s18, s23, #32
    s.addi       s23, s16, #16640
x8dot_row_12:
    s.addi       s52, s29, #-32
    v.movi       v28, #0
    s.sub        s53, s52, s44
    s.add        s52, s18, s44
    v.splat      v31, s53
    s.shli       s53, s44, #4
    s.addi       s54, s44, #1
    v.cmp.gt     p1, v31, v28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v28, [s52, v16]            // index is in elements (ISA sec 9.1)
    s.add        s52, s23, s53
    s.movz       s53, #32
    v.st.b       [s52, #0], v28
    fence.acq_rel.device
    s.mov        s44, s54
    s.cmp.lt     s52, s44, s53
    br.nz        s52, x8dot_row_12
x8dot_done_11:
    v.splat      v28, s49
    v.movi       v31, #0
    mb.arm       s18, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s23, #0
    v.extract    s44, v9, #0
    s.movz       s49, #32
    v.cmp.ne     p1, v28, v31
    v.cmp.eq     p2, v28, v31
    s.mov        s52, s23                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s23                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s52, s18            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s52, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s52, s18          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s18
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s25, #0]
    s.addi       s23, s25, #64
    s.addi       s44, s25, #128
    s.addi       s49, s25, #192
    s.addi       s52, s25, #256
    s.addi       s53, s25, #320
    s.addi       s54, s25, #384
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s23, #0]
    s.addi       s23, s25, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s44, #0]
    s.addi       s44, s31, #64
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s49, #0]
    s.addi       s49, s31, #128
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s52, #0]
    s.addi       s52, s31, #192
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s53, #0]
    s.addi       s53, s31, #256
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s54, #0]
    s.addi       s54, s31, #320
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s23, #0]
    s.addi       s23, s31, #384
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s55, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a0, v56, v48, s55
    mb.wait      s55
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s31, #0]
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s44, #0]
    s.addi       s44, s31, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s49, #0]
    s.addi       s49, s39, #64
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s52, #0]
    s.addi       s52, s39, #128
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s53, #0]
    s.addi       s53, s39, #192
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s54, #0]
    s.addi       s54, s39, #256
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s23, #0]
    s.addi       s23, s39, #320
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s44, #0]
    s.addi       s44, s39, #384
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s56, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a4, v56, v48, s56
    mb.wait      s56
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s39, #0]
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s49, #0]
    s.addi       s49, s39, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s52, #0]
    s.addi       s52, s38, #64
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s53, #0]
    s.addi       s53, s38, #128
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s54, #0]
    s.addi       s54, s38, #192
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s23, #0]
    s.addi       s23, s38, #256
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s44, #0]
    s.addi       s44, s38, #320
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s49, #0]
    s.addi       s49, s38, #384
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s57, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v48, s57
    mb.wait      s57
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s38, #0]
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s52, #0]
    s.addi       s52, s38, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s53, #0]
    v.extract    s53, v8, #1
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s54, #0]
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s23, #0]
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s44, #0]
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s49, #0]
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s52, #0]
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s23, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a12, v56, v48, s23
    mb.wait      s23
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s53, x8dot_done_13
    s.movz       s44, #0
    s.add        s49, s4, s22
    s.addi       s52, s44, #0
    s.addi       s44, s49, #32
    s.addi       s49, s16, #16640
x8dot_row_14:
    s.addi       s54, s29, #-32
    v.movi       v28, #0
    s.sub        s58, s54, s52
    s.add        s54, s44, s52
    v.splat      v31, s58
    s.shli       s58, s52, #4
    s.addi       s59, s52, #1
    v.cmp.gt     p1, v31, v28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v28, [s54, v17]            // index is in elements (ISA sec 9.1)
    s.add        s54, s49, s58
    s.movz       s58, #32
    v.st.b       [s54, #0], v28
    fence.acq_rel.device
    s.mov        s52, s59
    s.cmp.lt     s54, s52, s58
    br.nz        s54, x8dot_row_14
x8dot_done_13:
    v.splat      v28, s53
    v.movi       v31, #0
    mb.arm       s44, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s49, #0
    v.extract    s52, v9, #1
    s.movz       s53, #32
    v.cmp.ne     p1, v28, v31
    v.cmp.eq     p2, v28, v31
    s.mov        s58, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s59, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s58, s44            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s58, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s59, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s58, s44          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s44
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s25, #0]
    s.addi       s49, s25, #64
    s.addi       s52, s25, #128
    s.addi       s53, s25, #192
    s.addi       s54, s25, #256
    s.addi       s58, s25, #320
    s.addi       s59, s25, #384
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s49, #0]
    s.addi       s49, s25, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s52, #0]
    s.addi       s52, s31, #64
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s53, #0]
    s.addi       s53, s31, #128
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s54, #0]
    s.addi       s54, s31, #192
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s58, #0]
    s.addi       s58, s31, #256
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s59, #0]
    s.addi       s59, s31, #320
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s49, #0]
    s.addi       s49, s31, #384
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s60, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a1, v56, v48, s60
    mb.wait      s60
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s31, #0]
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s52, #0]
    s.addi       s52, s31, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s53, #0]
    s.addi       s53, s39, #64
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s54, #0]
    s.addi       s54, s39, #128
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s58, #0]
    s.addi       s58, s39, #192
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s59, #0]
    s.addi       s59, s39, #256
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s49, #0]
    s.addi       s49, s39, #320
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s52, #0]
    s.addi       s52, s39, #384
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s17, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a5, v56, v48, s17
    mb.wait      s17
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s39, #0]
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s53, #0]
    s.addi       s18, s39, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s54, #0]
    s.addi       s20, s38, #64
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s58, #0]
    s.addi       s23, s38, #128
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s59, #0]
    s.addi       s28, s38, #192
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s49, #0]
    s.addi       s30, s38, #256
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s52, #0]
    s.addi       s32, s38, #320
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s18, #0]
    s.addi       s18, s38, #384
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s33, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s33
    mb.wait      s33
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s38, #0]
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s20, #0]
    s.addi       s20, s38, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s23, #0]
    v.extract    s23, v8, #2
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s28, #0]
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s30, #0]
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s32, #0]
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s18, #0]
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s20, #0]
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s18, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s18
    mb.wait      s18
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s23, x8dot_done_15
    s.movz       s20, #0
    s.add        s28, s4, s22
    s.addi       s30, s20, #0
    s.addi       s20, s28, #32
    s.addi       s28, s16, #16640
x8dot_row_16:
    s.addi       s32, s29, #-32
    v.movi       v28, #0
    s.sub        s34, s32, s30
    s.add        s32, s20, s30
    v.splat      v31, s34
    s.shli       s34, s30, #4
    s.addi       s35, s30, #1
    v.cmp.gt     p1, v31, v28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v28, [s32, v20]            // index is in elements (ISA sec 9.1)
    s.add        s32, s28, s34
    s.movz       s34, #32
    v.st.b       [s32, #0], v28
    fence.acq_rel.device
    s.mov        s30, s35
    s.cmp.lt     s32, s30, s34
    br.nz        s32, x8dot_row_16
x8dot_done_15:
    v.splat      v28, s23
    v.movi       v31, #0
    mb.arm       s20, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s23, #0
    v.extract    s28, v9, #2
    s.movz       s30, #32
    v.cmp.ne     p1, v28, v31
    v.cmp.eq     p2, v28, v31
    s.mov        s34, s23                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s23                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s34, s20            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s34, s28                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s34, s20          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s20
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s25, #0]
    s.addi       s23, s25, #64
    s.addi       s28, s25, #128
    s.addi       s30, s25, #192
    s.addi       s32, s25, #256
    s.addi       s34, s25, #320
    s.addi       s35, s25, #384
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s23, #0]
    s.addi       s23, s25, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s28, #0]
    s.addi       s28, s31, #64
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s30, #0]
    s.addi       s30, s31, #128
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s32, #0]
    s.addi       s32, s31, #192
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s34, #0]
    s.addi       s34, s31, #256
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s35, #0]
    s.addi       s35, s31, #320
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s23, #0]
    s.addi       s23, s31, #384
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s36, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a2, v56, v48, s36
    mb.wait      s36
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s31, #0]
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s28, #0]
    s.addi       s28, s31, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s30, #0]
    s.addi       s30, s39, #64
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s32, #0]
    s.addi       s32, s39, #128
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s34, #0]
    s.addi       s34, s39, #192
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s35, #0]
    s.addi       s35, s39, #256
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s23, #0]
    s.addi       s23, s39, #320
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s28, #0]
    s.addi       s28, s39, #384
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s37, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a6, v56, v48, s37
    mb.wait      s37
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s39, #0]
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s30, #0]
    s.addi       s30, s39, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s32, #0]
    s.addi       s32, s38, #64
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s34, #0]
    s.addi       s34, s38, #128
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s35, #0]
    s.addi       s35, s38, #192
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s23, #0]
    s.addi       s23, s38, #256
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s28, #0]
    s.addi       s28, s38, #320
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s30, #0]
    s.addi       s30, s38, #384
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s40, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a10, v56, v48, s40
    mb.wait      s40
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s38, #0]
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s32, #0]
    s.addi       s32, s38, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s34, #0]
    v.extract    s34, v8, #3
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s35, #0]
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s23, #0]
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s28, #0]
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s30, #0]
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s32, #0]
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s23, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a14, v56, v48, s23
    mb.wait      s23
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s34, x8dot_done_17
    s.movz       s28, #0
    s.add        s30, s4, s22
    s.addi       s32, s28, #0
    s.addi       s28, s30, #32
    s.addi       s30, s16, #16640
x8dot_row_18:
    s.addi       s35, s29, #-32
    v.movi       v28, #0
    s.sub        s41, s35, s32
    s.add        s35, s28, s32
    v.splat      v31, s41
    s.shli       s41, s32, #4
    s.addi       s42, s32, #1
    v.cmp.gt     p1, v31, v28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v28, [s35, v12]            // index is in elements (ISA sec 9.1)
    s.add        s35, s30, s41
    s.movz       s41, #32
    v.st.b       [s35, #0], v28
    fence.acq_rel.device
    s.mov        s32, s42
    s.cmp.lt     s35, s32, s41
    br.nz        s35, x8dot_row_18
x8dot_done_17:
    v.splat      v28, s34
    v.movi       v31, #0
    mb.arm       s28, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s30, #0
    v.extract    s32, v9, #3
    s.movz       s34, #32
    v.cmp.ne     p1, v28, v31
    v.cmp.eq     p2, v28, v31
    s.mov        s41, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s41, s28            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s41, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s41, s28          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s28
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s25, #0]
    s.addi       s30, s25, #64
    s.addi       s32, s25, #128
    s.addi       s34, s25, #192
    s.addi       s35, s25, #256
    s.addi       s41, s25, #320
    s.addi       s42, s25, #384
    s.addi       s43, s25, #448
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s30, #0]
    s.addi       s25, s31, #64
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s32, #0]
    s.addi       s30, s31, #128
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s34, #0]
    s.addi       s32, s31, #192
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s35, #0]
    s.addi       s34, s31, #256
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s41, #0]
    s.addi       s35, s31, #320
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s42, #0]
    s.addi       s41, s31, #384
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s43, #0]
    s.addi       s42, s31, #448
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s43, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a3, v56, v48, s43
    mb.wait      s43
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s31, #0]
    s.addi       s31, s39, #64
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s25, #0]
    s.addi       s25, s39, #128
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s30, #0]
    s.addi       s30, s39, #192
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s32, #0]
    s.addi       s32, s39, #256
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s34, #0]
    s.addi       s34, s39, #320
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s35, #0]
    s.addi       s35, s39, #384
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s41, #0]
    s.addi       s41, s39, #448
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s42, #0]
    s.addi       s42, s38, #64
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s44, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a7, v56, v48, s44
    mb.wait      s44
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s39, #0]
    s.addi       s39, s38, #128
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s31, #0]
    s.addi       s31, s38, #192
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s25, #0]
    s.addi       s25, s38, #256
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s30, #0]
    s.addi       s30, s38, #320
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s32, #0]
    s.addi       s32, s38, #384
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s34, #0]
    s.addi       s34, s38, #448
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s35, #0]
    s.movz       s35, #0
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s41, #0]
    s.add        s41, s35, s3                    // the tile origin
    s.add        s45, s35, s27                   // the tile origin
    v.splat      v31, s41
    v.extract    s35, v26, #0
    v.splat      v33, s45
    s.add        s41, s35, s21
    v.add        v34, v1, v31
    s.addi       s35, s41, #64
    v.extract    s41, v26, #1
    s.add        s45, s6, s35
    v.cmp.lt     p1, v34, v33
    s.add        s35, s41, s21
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s41, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s46, s35, #64
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s41
    mb.wait      s41
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s38, #0]
    s.addi       s35, s16, #21504                // 512 bytes of repack scratch
    s.add        s38, s6, s46
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s42, #0]
    s.addi       s42, s35, #0
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s39, #0]
    v.extract    s39, v26, #2
    s.add        s46, s39, s21
    s.addi       s39, s46, #64
    s.add        s46, s6, s39
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s31, #0]
    s.addi       s31, s35, #32
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s25, #0]
    v.extract    s25, v26, #3
    s.add        s39, s25, s21
    s.addi       s25, s39, #64
    s.add        s39, s6, s25
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s30, #0]
    s.addi       s25, s35, #64
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s32, #0]
    v.extract    s30, v26, #4
    s.add        s32, s30, s21
    s.addi       s30, s32, #64
    s.add        s32, s6, s30
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s34, #0]
    s.addi       s30, s35, #96
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s34, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s34
    mb.wait      s34
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s45, #0]
    v.extract    s45, v26, #5
    s.add        s47, s45, s21
    s.addi       s45, s47, #64
    s.add        s47, s6, s45
    v.st.b       [s42, #0], v28
    s.addi       s42, s35, #128
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s38, #0]
    v.extract    s38, v26, #6
    s.add        s45, s38, s21
    s.addi       s38, s45, #64
    s.add        s45, s6, s38
    v.st.b       [s31, #0], v28
    s.addi       s31, s35, #160
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s46, #0]
    v.extract    s38, v26, #7
    s.add        s46, s38, s21
    s.addi       s38, s46, #64
    s.add        s46, s6, s38
    v.st.b       [s25, #0], v28
    s.addi       s25, s35, #192
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s39, #0]
    v.extract    s38, v26, #8
    s.add        s39, s38, s21
    s.addi       s38, s39, #64
    s.add        s39, s6, s38
    v.st.b       [s30, #0], v28
    s.addi       s30, s35, #224
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s32, #0]
    v.extract    s32, v26, #9
    s.add        s38, s32, s21
    s.addi       s32, s38, #64
    s.add        s38, s6, s32
    v.st.b       [s42, #0], v28
    s.addi       s32, s35, #256
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s47, #0]
    v.extract    s42, v26, #10
    s.add        s47, s42, s21
    s.addi       s42, s47, #64
    s.add        s47, s6, s42
    v.st.b       [s31, #0], v28
    s.addi       s31, s35, #288
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s45, #0]
    v.extract    s42, v26, #11
    s.add        s45, s42, s21
    s.addi       s42, s45, #64
    s.add        s45, s6, s42
    v.st.b       [s25, #0], v28
    s.addi       s25, s35, #320
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s46, #0]
    v.extract    s42, v26, #12
    s.add        s46, s42, s21
    s.addi       s42, s46, #64
    s.add        s46, s6, s42
    v.st.b       [s30, #0], v28
    s.addi       s30, s35, #352
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s39, #0]
    v.extract    s39, v26, #13
    s.add        s42, s39, s21
    s.addi       s39, s42, #64
    s.add        s42, s6, s39
    v.st.b       [s32, #0], v28
    s.addi       s32, s35, #384
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s38, #0]
    v.extract    s38, v26, #14
    s.add        s39, s38, s21
    s.addi       s38, s39, #64
    s.add        s39, s6, s38
    v.st.b       [s31, #0], v28
    s.addi       s31, s35, #416
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s47, #0]
    v.extract    s38, v26, #15
    s.add        s47, s38, s21
    s.addi       s38, s47, #64
    s.add        s47, s6, s38
    v.st.b       [s25, #0], v28
    s.addi       s25, s35, #448
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s45, #0]
    s.movz       s38, #0
    v.st.b       [s30, #0], v28
    s.add        s30, s38, s12                   // the tile origin
    s.add        s45, s38, s27                   // the tile origin
    v.splat      v28, s30
    v.extract    s30, v26, #0
    v.splat      v31, s45
    s.add        s38, s30, s21
    v.add        v33, v1, v28
    s.addi       s30, s38, #80
    s.addi       s38, s35, #480
    s.add        s45, s6, s30
    v.cmp.lt     p2, v33, v31
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s46, #0]
    v.extract    s30, v26, #1
    s.add        s46, s30, s21
    s.addi       s30, s46, #80
    s.add        s46, s6, s30
    v.st.b       [s32, #0], v28
    s.addi       s30, s35, #16
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s42, #0]
    v.extract    s32, v26, #2
    s.add        s42, s32, s21
    s.addi       s32, s42, #80
    s.add        s42, s6, s32
    v.st.b       [s31, #0], v28
    s.addi       s31, s35, #48
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s39, #0]
    v.extract    s32, v26, #3
    s.add        s39, s32, s21
    s.addi       s32, s39, #80
    s.add        s39, s6, s32
    v.st.b       [s25, #0], v28
    s.addi       s25, s35, #80
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s47, #0]
    v.extract    s32, v26, #4
    s.add        s47, s32, s21
    s.addi       s32, s47, #80
    s.add        s47, s6, s32
    v.st.b       [s38, #0], v28
    s.addi       s32, s35, #112
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s45, #0]
    v.extract    s38, v26, #5
    s.add        s45, s38, s21
    s.addi       s38, s45, #80
    s.add        s45, s6, s38
    v.st.b       [s30, #0], v28
    s.addi       s30, s35, #144
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s46, #0]
    v.extract    s38, v26, #6
    s.add        s46, s38, s21
    s.addi       s38, s46, #80
    s.add        s46, s6, s38
    v.st.b       [s31, #0], v28
    s.addi       s31, s35, #176
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s42, #0]
    v.extract    s38, v26, #7
    s.add        s42, s38, s21
    s.addi       s38, s42, #80
    s.add        s42, s6, s38
    v.st.b       [s25, #0], v28
    s.addi       s25, s35, #208
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s39, #0]
    v.extract    s38, v26, #8
    s.add        s39, s38, s21
    s.addi       s38, s39, #80
    s.add        s39, s6, s38
    v.st.b       [s32, #0], v28
    s.addi       s32, s35, #240
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s47, #0]
    v.extract    s38, v26, #9
    s.add        s47, s38, s21
    s.addi       s38, s47, #80
    s.add        s47, s6, s38
    v.st.b       [s30, #0], v28
    s.addi       s30, s35, #272
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s45, #0]
    v.extract    s38, v26, #10
    s.add        s45, s38, s21
    s.addi       s38, s45, #80
    s.add        s45, s6, s38
    v.st.b       [s31, #0], v28
    s.addi       s31, s35, #304
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s46, #0]
    v.extract    s38, v26, #11
    s.add        s46, s38, s21
    s.addi       s38, s46, #80
    s.add        s46, s6, s38
    v.st.b       [s25, #0], v28
    s.addi       s25, s35, #336
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s42, #0]
    v.extract    s38, v26, #12
    s.add        s42, s38, s21
    s.addi       s38, s42, #80
    s.add        s42, s6, s38
    v.st.b       [s32, #0], v28
    s.addi       s32, s35, #368
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s39, #0]
    v.extract    s38, v26, #13
    s.add        s39, s38, s21
    s.addi       s38, s39, #80
    s.add        s39, s6, s38
    v.st.b       [s30, #0], v28
    s.addi       s30, s35, #400
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s47, #0]
    v.extract    s38, v26, #14
    s.add        s47, s38, s21
    s.addi       s38, s47, #80
    s.add        s47, s6, s38
    v.st.b       [s31, #0], v28
    s.addi       s31, s35, #432
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s45, #0]
    v.extract    s38, v26, #15
    s.add        s45, s38, s21
    s.addi       s38, s45, #80
    s.add        s45, s6, s38
    v.st.b       [s25, #0], v28
    s.addi       s25, s35, #464
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s46, #0]
    v.extract    s38, v30, #0
    s.add        s46, s38, s21
    s.addi       s38, s46, #64
    s.add        s46, s6, s38
    v.st.b       [s32, #0], v28
    s.addi       s32, s35, #496
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s42, #0]
    v.extract    s38, v30, #1
    s.add        s42, s38, s21
    s.addi       s38, s42, #64
    s.add        s42, s6, s38
    v.st.b       [s30, #0], v28
    s.addi       s30, s16, #22016                // 512 bytes of repack scratch
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s39, #0]
    s.addi       s38, s30, #0
    v.st.b       [s31, #0], v28
    v.extract    s31, v30, #2
    s.add        s39, s31, s21
    s.addi       s31, s39, #64
    s.add        s39, s6, s31
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s47, #0]
    s.addi       s31, s30, #32
    v.st.b       [s25, #0], v28
    v.extract    s25, v30, #3
    s.add        s47, s25, s21
    s.addi       s25, s47, #64
    s.add        s47, s6, s25
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s45, #0]
    s.addi       s25, s30, #64
    v.st.b       [s32, #0], v28
    v.extract    s32, v30, #4
    s.add        s45, s32, s21
    s.addi       s32, s45, #64
    s.add        s45, s6, s32
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s46, #0]
    s.addi       s32, s30, #96
    v.st.b       [s38, #0], v28
    v.extract    s38, v30, #5
    s.add        s46, s38, s21
    s.addi       s38, s46, #64
    s.add        s46, s6, s38
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s42, #0]
    s.addi       s38, s30, #128
    v.st.b       [s31, #0], v28
    v.extract    s31, v30, #6
    s.add        s42, s31, s21
    s.addi       s31, s42, #64
    s.add        s42, s6, s31
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s39, #0]
    s.addi       s31, s30, #160
    v.st.b       [s25, #0], v28
    v.extract    s25, v30, #7
    s.add        s39, s25, s21
    s.addi       s25, s39, #64
    s.add        s39, s6, s25
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s47, #0]
    s.addi       s25, s30, #192
    v.st.b       [s32, #0], v28
    v.extract    s32, v30, #8
    s.add        s47, s32, s21
    s.addi       s32, s47, #64
    s.add        s47, s6, s32
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s45, #0]
    s.addi       s32, s30, #224
    v.st.b       [s38, #0], v28
    v.extract    s38, v30, #9
    s.add        s45, s38, s21
    s.addi       s38, s45, #64
    s.add        s45, s6, s38
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s46, #0]
    s.addi       s38, s30, #256
    v.st.b       [s31, #0], v28
    v.extract    s31, v30, #10
    s.add        s46, s31, s21
    s.addi       s31, s46, #64
    s.add        s46, s6, s31
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s42, #0]
    s.addi       s31, s30, #288
    v.st.b       [s25, #0], v28
    v.extract    s25, v30, #11
    s.add        s42, s25, s21
    s.addi       s25, s42, #64
    s.add        s42, s6, s25
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s39, #0]
    s.addi       s25, s30, #320
    v.st.b       [s32, #0], v28
    v.extract    s32, v30, #12
    s.add        s39, s32, s21
    s.addi       s32, s39, #64
    s.add        s39, s6, s32
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s47, #0]
    s.addi       s32, s30, #352
    v.st.b       [s38, #0], v28
    v.extract    s38, v30, #13
    s.add        s47, s38, s21
    s.addi       s38, s47, #64
    s.add        s47, s6, s38
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s45, #0]
    s.addi       s38, s30, #384
    v.st.b       [s31, #0], v28
    v.extract    s31, v30, #14
    s.add        s45, s31, s21
    s.addi       s31, s45, #64
    s.add        s45, s6, s31
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s46, #0]
    s.addi       s31, s30, #416
    v.st.b       [s25, #0], v28
    v.extract    s25, v30, #15
    s.add        s46, s25, s21
    s.addi       s25, s46, #64
    s.add        s46, s6, s25
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s42, #0]
    s.addi       s25, s30, #448
    v.st.b       [s32, #0], v28
    v.extract    s32, v30, #0
    s.add        s42, s32, s21
    s.addi       s32, s42, #80
    s.add        s42, s6, s32
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s39, #0]
    s.addi       s32, s30, #480
    v.st.b       [s38, #0], v28
    v.extract    s38, v30, #1
    s.add        s39, s38, s21
    s.addi       s38, s39, #80
    s.add        s39, s6, s38
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s47, #0]
    s.addi       s38, s30, #16
    v.st.b       [s31, #0], v28
    v.extract    s31, v30, #2
    s.add        s47, s31, s21
    s.addi       s31, s47, #80
    s.add        s47, s6, s31
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s45, #0]
    s.addi       s31, s30, #48
    v.st.b       [s25, #0], v28
    v.extract    s25, v30, #3
    s.add        s45, s25, s21
    s.addi       s25, s45, #80
    s.add        s45, s6, s25
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s46, #0]
    s.addi       s25, s30, #80
    v.st.b       [s32, #0], v28
    v.extract    s32, v30, #4
    s.add        s46, s32, s21
    s.addi       s32, s46, #80
    s.add        s46, s6, s32
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s42, #0]
    s.addi       s32, s30, #112
    v.st.b       [s38, #0], v28
    v.extract    s38, v30, #5
    s.add        s42, s38, s21
    s.addi       s38, s42, #80
    s.add        s42, s6, s38
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s39, #0]
    s.addi       s38, s30, #144
    v.st.b       [s31, #0], v28
    v.extract    s31, v30, #6
    s.add        s39, s31, s21
    s.addi       s31, s39, #80
    s.add        s39, s6, s31
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s47, #0]
    s.addi       s31, s30, #176
    v.st.b       [s25, #0], v28
    v.extract    s25, v30, #7
    s.add        s47, s25, s21
    s.addi       s25, s47, #80
    s.add        s47, s6, s25
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s45, #0]
    s.addi       s25, s30, #208
    v.st.b       [s32, #0], v28
    v.extract    s32, v30, #8
    s.add        s45, s32, s21
    s.addi       s32, s45, #80
    s.add        s45, s6, s32
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s46, #0]
    s.addi       s32, s30, #240
    v.st.b       [s38, #0], v28
    v.extract    s38, v30, #9
    s.add        s46, s38, s21
    s.addi       s38, s46, #80
    s.add        s46, s6, s38
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s42, #0]
    s.addi       s38, s30, #272
    v.st.b       [s31, #0], v28
    v.extract    s31, v30, #10
    s.add        s42, s31, s21
    s.addi       s31, s42, #80
    s.add        s42, s6, s31
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s39, #0]
    s.addi       s31, s30, #304
    v.st.b       [s25, #0], v28
    v.extract    s25, v30, #11
    s.add        s39, s25, s21
    s.addi       s25, s39, #80
    s.add        s39, s6, s25
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s47, #0]
    s.addi       s25, s30, #336
    v.st.b       [s32, #0], v28
    v.extract    s32, v30, #12
    s.add        s47, s32, s21
    s.addi       s32, s47, #80
    s.add        s47, s6, s32
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s45, #0]
    s.addi       s32, s30, #368
    v.st.b       [s38, #0], v28
    v.extract    s38, v30, #13
    s.add        s45, s38, s21
    s.addi       s38, s45, #80
    s.add        s45, s6, s38
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s46, #0]
    s.addi       s38, s30, #400
    v.st.b       [s31, #0], v28
    v.extract    s31, v30, #14
    s.add        s46, s31, s21
    s.addi       s31, s46, #80
    s.add        s46, s6, s31
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s42, #0]
    s.addi       s31, s30, #432
    v.st.b       [s25, #0], v28
    v.extract    s25, v30, #15
    s.add        s42, s25, s21
    s.addi       s25, s42, #80
    s.add        s42, s6, s25
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s39, #0]
    s.addi       s25, s30, #464
    v.st.b       [s32, #0], v28
    v.extract    s32, v29, #0
    s.add        s39, s32, s21
    s.addi       s32, s39, #64
    s.add        s39, s6, s32
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s47, #0]
    s.addi       s32, s30, #496
    v.st.b       [s38, #0], v28
    v.extract    s38, v29, #1
    s.add        s47, s38, s21
    s.addi       s38, s47, #64
    s.add        s47, s6, s38
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s45, #0]
    s.addi       s38, s16, #22528                // 512 bytes of repack scratch
    v.st.b       [s31, #0], v28
    s.addi       s31, s38, #0
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s46, #0]
    v.extract    s45, v29, #2
    s.add        s46, s45, s21
    s.addi       s45, s46, #64
    s.add        s46, s6, s45
    v.st.b       [s25, #0], v28
    s.addi       s25, s38, #32
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s42, #0]
    v.extract    s42, v29, #3
    s.add        s45, s42, s21
    s.addi       s42, s45, #64
    s.add        s45, s6, s42
    v.st.b       [s32, #0], v28
    s.addi       s32, s38, #64
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s39, #0]
    v.extract    s39, v29, #4
    s.add        s42, s39, s21
    s.addi       s39, s42, #64
    s.add        s42, s6, s39
    v.st.b       [s31, #0], v28
    s.addi       s31, s38, #96
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s47, #0]
    v.extract    s39, v29, #5
    s.add        s47, s39, s21
    s.addi       s39, s47, #64
    s.add        s47, s6, s39
    v.st.b       [s25, #0], v28
    s.addi       s25, s38, #128
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s46, #0]
    v.extract    s39, v29, #6
    s.add        s46, s39, s21
    s.addi       s39, s46, #64
    s.add        s46, s6, s39
    v.st.b       [s32, #0], v28
    s.addi       s32, s38, #160
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s45, #0]
    v.extract    s39, v29, #7
    s.add        s45, s39, s21
    s.addi       s39, s45, #64
    s.add        s45, s6, s39
    v.st.b       [s31, #0], v28
    s.addi       s31, s38, #192
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s42, #0]
    v.extract    s39, v29, #8
    s.add        s42, s39, s21
    s.addi       s39, s42, #64
    s.add        s42, s6, s39
    v.st.b       [s25, #0], v28
    s.addi       s25, s38, #224
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s47, #0]
    v.extract    s39, v29, #9
    s.add        s47, s39, s21
    s.addi       s39, s47, #64
    s.add        s47, s6, s39
    v.st.b       [s32, #0], v28
    s.addi       s32, s38, #256
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s46, #0]
    v.extract    s39, v29, #10
    s.add        s46, s39, s21
    s.addi       s39, s46, #64
    s.add        s46, s6, s39
    v.st.b       [s31, #0], v28
    s.addi       s31, s38, #288
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s45, #0]
    v.extract    s39, v29, #11
    s.add        s45, s39, s21
    s.addi       s39, s45, #64
    s.add        s45, s6, s39
    v.st.b       [s25, #0], v28
    s.addi       s25, s38, #320
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s42, #0]
    v.extract    s39, v29, #12
    s.add        s42, s39, s21
    s.addi       s39, s42, #64
    s.add        s42, s6, s39
    v.st.b       [s32, #0], v28
    s.addi       s32, s38, #352
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s47, #0]
    v.extract    s39, v29, #13
    s.add        s47, s39, s21
    s.addi       s39, s47, #64
    s.add        s47, s6, s39
    v.st.b       [s31, #0], v28
    s.addi       s31, s38, #384
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s46, #0]
    v.extract    s39, v29, #14
    s.add        s46, s39, s21
    s.addi       s39, s46, #64
    s.add        s46, s6, s39
    v.st.b       [s25, #0], v28
    s.addi       s25, s38, #416
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s45, #0]
    v.extract    s39, v29, #15
    s.add        s45, s39, s21
    s.addi       s39, s45, #64
    s.add        s45, s6, s39
    v.st.b       [s32, #0], v28
    s.addi       s32, s38, #448
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s42, #0]
    v.extract    s39, v29, #0
    s.add        s42, s39, s21
    s.addi       s39, s42, #80
    s.add        s42, s6, s39
    v.st.b       [s31, #0], v28
    s.addi       s31, s38, #480
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s47, #0]
    v.extract    s39, v29, #1
    s.add        s47, s39, s21
    s.addi       s39, s47, #80
    s.add        s47, s6, s39
    v.st.b       [s25, #0], v28
    s.addi       s25, s38, #16
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s46, #0]
    v.extract    s39, v29, #2
    s.add        s46, s39, s21
    s.addi       s39, s46, #80
    s.add        s46, s6, s39
    v.st.b       [s32, #0], v28
    s.addi       s32, s38, #48
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s45, #0]
    v.extract    s39, v29, #3
    s.add        s45, s39, s21
    s.addi       s39, s45, #80
    s.add        s45, s6, s39
    v.st.b       [s31, #0], v28
    s.addi       s31, s38, #80
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s42, #0]
    v.extract    s39, v29, #4
    s.add        s42, s39, s21
    s.addi       s39, s42, #80
    s.add        s42, s6, s39
    v.st.b       [s25, #0], v28
    s.addi       s25, s38, #112
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s47, #0]
    v.extract    s39, v29, #5
    s.add        s47, s39, s21
    s.addi       s39, s47, #80
    s.add        s47, s6, s39
    v.st.b       [s32, #0], v28
    s.addi       s32, s38, #144
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s46, #0]
    v.extract    s39, v29, #6
    s.add        s46, s39, s21
    s.addi       s39, s46, #80
    s.add        s46, s6, s39
    v.st.b       [s31, #0], v28
    s.addi       s31, s38, #176
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s45, #0]
    v.extract    s39, v29, #7
    s.add        s45, s39, s21
    s.addi       s39, s45, #80
    s.add        s45, s6, s39
    v.st.b       [s25, #0], v28
    s.addi       s25, s38, #208
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s42, #0]
    v.extract    s39, v29, #8
    s.add        s42, s39, s21
    s.addi       s39, s42, #80
    s.add        s42, s6, s39
    v.st.b       [s32, #0], v28
    s.addi       s32, s38, #240
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s47, #0]
    v.extract    s39, v29, #9
    s.add        s47, s39, s21
    s.addi       s39, s47, #80
    s.add        s47, s6, s39
    v.st.b       [s31, #0], v28
    s.addi       s31, s38, #272
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s46, #0]
    v.extract    s39, v29, #10
    s.add        s46, s39, s21
    s.addi       s39, s46, #80
    s.add        s46, s6, s39
    v.st.b       [s25, #0], v28
    s.addi       s25, s38, #304
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s45, #0]
    v.extract    s39, v29, #11
    s.add        s45, s39, s21
    s.addi       s39, s45, #80
    s.add        s45, s6, s39
    v.st.b       [s32, #0], v28
    s.addi       s32, s38, #336
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s42, #0]
    v.extract    s39, v29, #12
    s.add        s42, s39, s21
    s.addi       s39, s42, #80
    s.add        s42, s6, s39
    v.st.b       [s31, #0], v28
    s.addi       s31, s38, #368
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s47, #0]
    v.extract    s39, v29, #13
    s.add        s47, s39, s21
    s.addi       s39, s47, #80
    s.add        s47, s6, s39
    v.st.b       [s25, #0], v28
    s.addi       s25, s38, #400
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s46, #0]
    v.extract    s39, v29, #14
    s.add        s46, s39, s21
    s.addi       s39, s46, #80
    s.add        s46, s6, s39
    v.st.b       [s32, #0], v28
    s.addi       s32, s38, #432
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s45, #0]
    v.extract    s39, v29, #15
    s.add        s45, s39, s21
    s.addi       s39, s45, #80
    s.add        s45, s6, s39
    v.st.b       [s31, #0], v28
    s.addi       s31, s38, #464
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s42, #0]
    v.extract    s39, v32, #0
    s.add        s42, s39, s21
    s.addi       s39, s42, #64
    s.add        s42, s6, s39
    v.st.b       [s25, #0], v28
    s.addi       s25, s38, #496
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s47, #0]
    v.extract    s39, v32, #1
    s.add        s47, s39, s21
    s.addi       s39, s47, #64
    s.add        s47, s6, s39
    v.st.b       [s32, #0], v28
    s.addi       s32, s16, #23040                // 512 bytes of repack scratch
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s46, #0]
    s.addi       s39, s32, #0
    v.st.b       [s31, #0], v28
    v.extract    s31, v32, #2
    s.add        s46, s31, s21
    s.addi       s31, s46, #64
    s.add        s46, s6, s31
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s45, #0]
    s.addi       s31, s32, #32
    v.st.b       [s25, #0], v28
    v.extract    s25, v32, #3
    s.add        s45, s25, s21
    s.addi       s25, s45, #64
    s.add        s45, s6, s25
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s42, #0]
    s.addi       s25, s32, #64
    v.st.b       [s39, #0], v28
    v.extract    s39, v32, #4
    s.add        s42, s39, s21
    s.addi       s39, s42, #64
    s.add        s42, s6, s39
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s47, #0]
    s.addi       s39, s32, #96
    v.st.b       [s31, #0], v28
    v.extract    s31, v32, #5
    s.add        s47, s31, s21
    s.addi       s31, s47, #64
    s.add        s47, s6, s31
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s46, #0]
    s.addi       s31, s32, #128
    v.st.b       [s25, #0], v28
    v.extract    s25, v32, #6
    s.add        s46, s25, s21
    s.addi       s25, s46, #64
    s.add        s46, s6, s25
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s45, #0]
    s.addi       s25, s32, #160
    v.st.b       [s39, #0], v28
    v.extract    s39, v32, #7
    s.add        s45, s39, s21
    s.addi       s39, s45, #64
    s.add        s45, s6, s39
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s42, #0]
    s.addi       s39, s32, #192
    v.st.b       [s31, #0], v28
    v.extract    s31, v32, #8
    s.add        s42, s31, s21
    s.addi       s31, s42, #64
    s.add        s42, s6, s31
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s47, #0]
    s.addi       s31, s32, #224
    v.st.b       [s25, #0], v28
    v.extract    s25, v32, #9
    s.add        s47, s25, s21
    s.addi       s25, s47, #64
    s.add        s47, s6, s25
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s46, #0]
    s.addi       s25, s32, #256
    v.st.b       [s39, #0], v28
    v.extract    s39, v32, #10
    s.add        s46, s39, s21
    s.addi       s39, s46, #64
    s.add        s46, s6, s39
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s45, #0]
    s.addi       s39, s32, #288
    v.st.b       [s31, #0], v28
    v.extract    s31, v32, #11
    s.add        s45, s31, s21
    s.addi       s31, s45, #64
    s.add        s45, s6, s31
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s42, #0]
    s.addi       s31, s32, #320
    v.st.b       [s25, #0], v28
    v.extract    s25, v32, #12
    s.add        s42, s25, s21
    s.addi       s25, s42, #64
    s.add        s42, s6, s25
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s47, #0]
    s.addi       s25, s32, #352
    v.st.b       [s39, #0], v28
    v.extract    s39, v32, #13
    s.add        s47, s39, s21
    s.addi       s39, s47, #64
    s.add        s47, s6, s39
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s46, #0]
    s.addi       s39, s32, #384
    v.st.b       [s31, #0], v28
    v.extract    s31, v32, #14
    s.add        s46, s31, s21
    s.addi       s31, s46, #64
    s.add        s46, s6, s31
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s45, #0]
    s.addi       s31, s32, #416
    v.st.b       [s25, #0], v28
    v.extract    s25, v32, #15
    s.add        s45, s25, s21
    s.addi       s25, s45, #64
    s.add        s45, s6, s25
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s42, #0]
    s.addi       s25, s32, #448
    v.st.b       [s39, #0], v28
    v.extract    s39, v32, #0
    s.add        s42, s39, s21
    s.addi       s39, s42, #80
    s.add        s42, s6, s39
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s47, #0]
    s.addi       s39, s32, #480
    v.st.b       [s31, #0], v28
    v.extract    s31, v32, #1
    s.add        s47, s31, s21
    s.addi       s31, s47, #80
    s.add        s47, s6, s31
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s46, #0]
    s.addi       s31, s32, #16
    v.st.b       [s25, #0], v28
    v.extract    s25, v32, #2
    s.add        s46, s25, s21
    s.addi       s25, s46, #80
    s.add        s46, s6, s25
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s45, #0]
    s.addi       s25, s32, #48
    v.st.b       [s39, #0], v28
    v.extract    s39, v32, #3
    s.add        s45, s39, s21
    s.addi       s39, s45, #80
    s.add        s45, s6, s39
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s42, #0]
    s.addi       s39, s32, #80
    v.st.b       [s31, #0], v28
    v.extract    s31, v32, #4
    s.add        s42, s31, s21
    s.addi       s31, s42, #80
    s.add        s42, s6, s31
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s47, #0]
    s.addi       s31, s32, #112
    v.st.b       [s25, #0], v28
    v.extract    s25, v32, #5
    s.add        s47, s25, s21
    s.addi       s25, s47, #80
    s.add        s47, s6, s25
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s46, #0]
    s.addi       s25, s32, #144
    v.st.b       [s39, #0], v28
    v.extract    s39, v32, #6
    s.add        s46, s39, s21
    s.addi       s39, s46, #80
    s.add        s46, s6, s39
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s45, #0]
    s.addi       s39, s32, #176
    v.st.b       [s31, #0], v28
    v.extract    s31, v32, #7
    s.add        s45, s31, s21
    s.addi       s31, s45, #80
    s.add        s45, s6, s31
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s42, #0]
    s.addi       s31, s32, #208
    v.st.b       [s25, #0], v28
    v.extract    s25, v32, #8
    s.add        s42, s25, s21
    s.addi       s25, s42, #80
    s.add        s42, s6, s25
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s47, #0]
    s.addi       s25, s32, #240
    v.st.b       [s39, #0], v28
    v.extract    s39, v32, #9
    s.add        s47, s39, s21
    s.addi       s39, s47, #80
    s.add        s47, s6, s39
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s46, #0]
    s.addi       s39, s32, #272
    v.st.b       [s31, #0], v28
    v.extract    s31, v32, #10
    s.add        s46, s31, s21
    s.addi       s31, s46, #80
    s.add        s46, s6, s31
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s45, #0]
    s.addi       s31, s32, #304
    v.st.b       [s25, #0], v28
    v.extract    s25, v32, #11
    s.add        s45, s25, s21
    s.addi       s25, s45, #80
    s.add        s45, s6, s25
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s42, #0]
    s.addi       s25, s32, #336
    v.st.b       [s39, #0], v28
    v.extract    s39, v32, #12
    s.add        s42, s39, s21
    s.addi       s39, s42, #80
    s.add        s42, s6, s39
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s47, #0]
    s.addi       s39, s32, #368
    v.st.b       [s31, #0], v28
    v.extract    s31, v32, #13
    s.add        s47, s31, s21
    s.addi       s31, s47, #80
    s.add        s47, s6, s31
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s46, #0]
    s.addi       s31, s32, #400
    v.st.b       [s25, #0], v28
    v.extract    s25, v32, #14
    s.add        s46, s25, s21
    s.addi       s25, s46, #80
    s.add        s46, s6, s25
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s45, #0]
    s.addi       s25, s32, #432
    v.st.b       [s39, #0], v28
    v.extract    s39, v32, #15
    s.add        s45, s39, s21
    s.addi       s39, s45, #80
    s.add        s45, s6, s39
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s42, #0]
    s.addi       s39, s32, #464
    v.st.b       [s31, #0], v28
    s.addi       s31, s32, #496
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s47, #0]
    v.extract    s42, v8, #0
    v.st.b       [s25, #0], v28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s46, #0]
    v.st.b       [s39, #0], v28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v28, [s45, #0]
    v.st.b       [s31, #0], v28
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s42, x8dot_done_19
    s.movz       s25, #0
    s.add        s31, s4, s22
    s.addi       s39, s25, #0
    s.addi       s25, s31, #64
    s.addi       s31, s16, #16640
x8dot_row_20:
    s.addi       s45, s29, #-64
    v.movi       v28, #0
    s.sub        s46, s45, s39
    s.add        s45, s25, s39
    v.splat      v31, s46
    s.shli       s46, s39, #4
    s.addi       s47, s39, #1
    v.cmp.gt     p1, v31, v28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v28, [s45, v16]            // index is in elements (ISA sec 9.1)
    s.add        s45, s31, s46
    s.movz       s46, #32
    v.st.b       [s45, #0], v28
    fence.acq_rel.device
    s.mov        s39, s47
    s.cmp.lt     s45, s39, s46
    br.nz        s45, x8dot_row_20
x8dot_done_19:
    v.splat      v28, s42
    v.movi       v31, #0
    mb.arm       s25, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s31, #0
    v.extract    s39, v9, #0
    s.movz       s42, #64
    v.cmp.ne     p1, v28, v31
    v.cmp.eq     p2, v28, v31
    s.mov        s45, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s45, s25            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s45, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s45, s25          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s25
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s35, #0]
    s.addi       s31, s35, #64
    s.addi       s39, s35, #128
    s.addi       s42, s35, #192
    s.addi       s45, s35, #256
    s.addi       s46, s35, #320
    s.addi       s47, s35, #384
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s31, #0]
    s.addi       s31, s35, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s39, #0]
    s.addi       s39, s30, #64
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s42, #0]
    s.addi       s42, s30, #128
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s45, #0]
    s.addi       s45, s30, #192
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s46, #0]
    s.addi       s46, s30, #256
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s47, #0]
    s.addi       s47, s30, #320
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s31, #0]
    s.addi       s31, s30, #384
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s48, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a0, v56, v48, s48
    mb.wait      s48
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s30, #0]
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s39, #0]
    s.addi       s39, s30, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s42, #0]
    s.addi       s42, s38, #64
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s45, #0]
    s.addi       s45, s38, #128
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s46, #0]
    s.addi       s46, s38, #192
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s47, #0]
    s.addi       s47, s38, #256
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s31, #0]
    s.addi       s31, s38, #320
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s39, #0]
    s.addi       s39, s38, #384
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s49, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a4, v56, v48, s49
    mb.wait      s49
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s38, #0]
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s42, #0]
    s.addi       s42, s38, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s45, #0]
    s.addi       s45, s32, #64
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s46, #0]
    s.addi       s46, s32, #128
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s47, #0]
    s.addi       s47, s32, #192
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s31, #0]
    s.addi       s31, s32, #256
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s39, #0]
    s.addi       s39, s32, #320
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s42, #0]
    s.addi       s42, s32, #384
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s50, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v48, s50
    mb.wait      s50
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s32, #0]
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s45, #0]
    s.addi       s45, s32, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s46, #0]
    v.extract    s46, v8, #1
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s47, #0]
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s31, #0]
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s39, #0]
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s42, #0]
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s45, #0]
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s31, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a12, v56, v48, s31
    mb.wait      s31
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s46, x8dot_done_21
    s.movz       s39, #0
    s.add        s42, s4, s22
    s.addi       s45, s39, #0
    s.addi       s39, s42, #64
    s.addi       s42, s16, #16640
x8dot_row_22:
    s.addi       s47, s29, #-64
    v.movi       v28, #0
    s.sub        s51, s47, s45
    s.add        s47, s39, s45
    v.splat      v31, s51
    s.shli       s51, s45, #4
    s.addi       s52, s45, #1
    v.cmp.gt     p1, v31, v28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v28, [s47, v17]            // index is in elements (ISA sec 9.1)
    s.add        s47, s42, s51
    s.movz       s51, #32
    v.st.b       [s47, #0], v28
    fence.acq_rel.device
    s.mov        s45, s52
    s.cmp.lt     s47, s45, s51
    br.nz        s47, x8dot_row_22
x8dot_done_21:
    v.splat      v28, s46
    v.movi       v31, #0
    mb.arm       s39, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s42, #0
    v.extract    s45, v9, #1
    s.movz       s46, #64
    v.cmp.ne     p1, v28, v31
    v.cmp.eq     p2, v28, v31
    s.mov        s51, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s51, s39            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s51, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s51, s39          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s39
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s35, #0]
    s.addi       s42, s35, #64
    s.addi       s45, s35, #128
    s.addi       s46, s35, #192
    s.addi       s47, s35, #256
    s.addi       s51, s35, #320
    s.addi       s52, s35, #384
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s42, #0]
    s.addi       s42, s35, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s45, #0]
    s.addi       s45, s30, #64
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s46, #0]
    s.addi       s46, s30, #128
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s47, #0]
    s.addi       s47, s30, #192
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s51, #0]
    s.addi       s51, s30, #256
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s52, #0]
    s.addi       s52, s30, #320
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s42, #0]
    s.addi       s42, s30, #384
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s53, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a1, v56, v48, s53
    mb.wait      s53
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s30, #0]
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s45, #0]
    s.addi       s45, s30, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s46, #0]
    s.addi       s46, s38, #64
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s47, #0]
    s.addi       s47, s38, #128
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s51, #0]
    s.addi       s51, s38, #192
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s52, #0]
    s.addi       s52, s38, #256
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s42, #0]
    s.addi       s42, s38, #320
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s45, #0]
    s.addi       s45, s38, #384
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s54, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a5, v56, v48, s54
    mb.wait      s54
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s38, #0]
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s46, #0]
    s.addi       s46, s38, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s47, #0]
    s.addi       s47, s32, #64
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s51, #0]
    s.addi       s51, s32, #128
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s52, #0]
    s.addi       s52, s32, #192
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s42, #0]
    s.addi       s42, s32, #256
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s45, #0]
    s.addi       s45, s32, #320
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s46, #0]
    s.addi       s46, s32, #384
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s55, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s55
    mb.wait      s55
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s32, #0]
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s47, #0]
    s.addi       s47, s32, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s51, #0]
    v.extract    s51, v8, #2
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s52, #0]
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s42, #0]
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s45, #0]
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s46, #0]
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s47, #0]
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s42
    mb.wait      s42
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s51, x8dot_done_23
    s.movz       s45, #0
    s.add        s46, s4, s22
    s.addi       s47, s45, #0
    s.addi       s45, s46, #64
    s.addi       s46, s16, #16640
x8dot_row_24:
    s.addi       s52, s29, #-64
    v.movi       v28, #0
    s.sub        s56, s52, s47
    s.add        s52, s45, s47
    v.splat      v31, s56
    s.shli       s56, s47, #4
    s.addi       s57, s47, #1
    v.cmp.gt     p1, v31, v28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v28, [s52, v20]            // index is in elements (ISA sec 9.1)
    s.add        s52, s46, s56
    s.movz       s56, #32
    v.st.b       [s52, #0], v28
    fence.acq_rel.device
    s.mov        s47, s57
    s.cmp.lt     s52, s47, s56
    br.nz        s52, x8dot_row_24
x8dot_done_23:
    v.splat      v28, s51
    v.movi       v31, #0
    mb.arm       s45, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s46, #0
    v.extract    s47, v9, #2
    s.movz       s51, #64
    v.cmp.ne     p1, v28, v31
    v.cmp.eq     p2, v28, v31
    s.mov        s56, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s56, s45            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s56, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s56, s45          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s45
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s35, #0]
    s.addi       s46, s35, #64
    s.addi       s47, s35, #128
    s.addi       s51, s35, #192
    s.addi       s52, s35, #256
    s.addi       s56, s35, #320
    s.addi       s57, s35, #384
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s46, #0]
    s.addi       s46, s35, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s47, #0]
    s.addi       s47, s30, #64
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s51, #0]
    s.addi       s51, s30, #128
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s52, #0]
    s.addi       s52, s30, #192
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s56, #0]
    s.addi       s56, s30, #256
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s57, #0]
    s.addi       s57, s30, #320
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s46, #0]
    s.addi       s46, s30, #384
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s58, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a2, v56, v48, s58
    mb.wait      s58
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s30, #0]
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s47, #0]
    s.addi       s47, s30, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s51, #0]
    s.addi       s51, s38, #64
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s52, #0]
    s.addi       s52, s38, #128
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s56, #0]
    s.addi       s56, s38, #192
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s57, #0]
    s.addi       s57, s38, #256
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s46, #0]
    s.addi       s46, s38, #320
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s47, #0]
    s.addi       s47, s38, #384
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s59, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a6, v56, v48, s59
    mb.wait      s59
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s38, #0]
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s51, #0]
    s.addi       s51, s38, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s52, #0]
    s.addi       s52, s32, #64
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s56, #0]
    s.addi       s56, s32, #128
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s57, #0]
    s.addi       s57, s32, #192
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s46, #0]
    s.addi       s46, s32, #256
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s47, #0]
    s.addi       s47, s32, #320
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s51, #0]
    s.addi       s51, s32, #384
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s60, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a10, v56, v48, s60
    mb.wait      s60
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s32, #0]
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s52, #0]
    s.addi       s52, s32, #448
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s56, #0]
    v.extract    s56, v8, #3
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s57, #0]
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s46, #0]
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s47, #0]
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s51, #0]
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s52, #0]
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s46, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a14, v56, v48, s46
    mb.wait      s46
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s56, x8dot_done_25
    s.movz       s47, #0
    s.add        s51, s4, s22
    s.addi       s52, s47, #0
    s.addi       s47, s51, #64
    s.addi       s51, s16, #16640
x8dot_row_26:
    s.addi       s57, s29, #-64
    v.movi       v28, #0
    s.sub        s17, s57, s52
    s.add        s18, s47, s52
    v.splat      v31, s17
    s.shli       s17, s52, #4
    s.addi       s20, s52, #1
    v.cmp.gt     p1, v31, v28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v28, [s18, v12]            // index is in elements (ISA sec 9.1)
    s.add        s18, s51, s17
    s.movz       s17, #32
    v.st.b       [s18, #0], v28
    fence.acq_rel.device
    s.mov        s52, s20
    s.cmp.lt     s18, s52, s17
    br.nz        s18, x8dot_row_26
x8dot_done_25:
    v.splat      v28, s56
    v.movi       v31, #0
    mb.arm       s17, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s18, #0
    v.extract    s20, v9, #3
    s.movz       s23, #64
    v.cmp.ne     p1, v28, v31
    v.cmp.eq     p2, v28, v31
    s.mov        s33, s18                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s18                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s33, s17            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s33, s20                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s23                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s33, s17          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s17
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s35, #0]
    s.addi       s18, s35, #64
    s.addi       s20, s35, #128
    s.addi       s23, s35, #192
    s.addi       s25, s35, #256
    s.addi       s28, s35, #320
    s.addi       s31, s35, #384
    s.addi       s33, s35, #448
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s18, #0]
    s.addi       s18, s30, #64
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s20, #0]
    s.addi       s20, s30, #128
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s23, #0]
    s.addi       s23, s30, #192
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s25, #0]
    s.addi       s25, s30, #256
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s28, #0]
    s.addi       s28, s30, #320
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s31, #0]
    s.addi       s31, s30, #384
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s33, #0]
    s.addi       s33, s30, #448
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s34, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a3, v56, v48, s34
    mb.wait      s34
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s30, #0]
    s.addi       s30, s38, #64
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s18, #0]
    s.addi       s18, s38, #128
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s20, #0]
    s.addi       s20, s38, #192
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s23, #0]
    s.addi       s23, s38, #256
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s25, #0]
    s.addi       s25, s38, #320
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s28, #0]
    s.addi       s28, s38, #384
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s31, #0]
    s.addi       s31, s38, #448
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s33, #0]
    s.addi       s33, s32, #64
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s35, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a7, v56, v48, s35
    mb.wait      s35
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s38, #0]
    s.addi       s36, s32, #128
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s30, #0]
    s.addi       s30, s32, #192
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s18, #0]
    s.addi       s18, s32, #256
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s20, #0]
    s.addi       s20, s32, #320
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s23, #0]
    s.addi       s23, s32, #384
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s25, #0]
    s.addi       s25, s32, #448
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s28, #0]
    s.movz       s28, #0
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s31, #0]
    s.add        s31, s28, s13                   // the tile origin
    s.add        s37, s28, s27                   // the tile origin
    v.splat      v31, s31
    v.extract    s28, v26, #0
    v.splat      v33, s37
    s.add        s31, s28, s21
    v.add        v34, v1, v31
    s.addi       s28, s31, #96
    v.extract    s31, v26, #1
    s.add        s37, s6, s28
    v.cmp.lt     p1, v34, v33
    s.add        s28, s31, s21
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s31, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s38, s28, #96
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s31
    mb.wait      s31
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v28, [s32, #0]
    s.addi       s28, s16, #23552                // 512 bytes of repack scratch
    s.add        s32, s6, s38
    v.mov        v56, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s33, #0]
    s.addi       s33, s28, #0
    v.mov        v57, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s36, #0]
    v.extract    s36, v26, #2
    s.add        s38, s36, s21
    s.addi       s36, s38, #96
    s.add        s38, s6, s36
    v.mov        v58, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s30, #0]
    s.addi       s30, s28, #32
    v.mov        v59, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s18, #0]
    v.extract    s18, v26, #3
    s.add        s36, s18, s21
    s.addi       s18, s36, #96
    s.add        s36, s6, s18
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s20, #0]
    s.addi       s18, s28, #64
    v.mov        v61, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s23, #0]
    v.extract    s20, v26, #4
    s.add        s23, s20, s21
    s.addi       s20, s23, #96
    s.add        s23, s6, s20
    v.mov        v62, v28                        // hand off through the shared window (sec 7.3)
    v.ld.w       v28, [s25, #0]
    s.addi       s20, s28, #96
    v.mov        v63, v28                        // hand off through the shared window (sec 7.3)
    mb.arm       s25, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s25
    mb.wait      s25
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s37, #0]
    v.extract    s37, v26, #5
    s.add        s39, s37, s21
    s.addi       s37, s39, #96
    s.add        s39, s6, s37
    v.st.b       [s33, #0], v28
    s.addi       s33, s28, #128
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s32, #0]
    v.extract    s32, v26, #6
    s.add        s37, s32, s21
    s.addi       s32, s37, #96
    s.add        s37, s6, s32
    v.st.b       [s30, #0], v28
    s.addi       s30, s28, #160
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s38, #0]
    v.extract    s32, v26, #7
    s.add        s38, s32, s21
    s.addi       s32, s38, #96
    s.add        s38, s6, s32
    v.st.b       [s18, #0], v28
    s.addi       s18, s28, #192
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s36, #0]
    v.extract    s32, v26, #8
    s.add        s36, s32, s21
    s.addi       s32, s36, #96
    s.add        s36, s6, s32
    v.st.b       [s20, #0], v28
    s.addi       s20, s28, #224
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s23, #0]
    v.extract    s23, v26, #9
    s.add        s32, s23, s21
    s.addi       s23, s32, #96
    s.add        s32, s6, s23
    v.st.b       [s33, #0], v28
    s.addi       s23, s28, #256
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s39, #0]
    v.extract    s33, v26, #10
    s.add        s39, s33, s21
    s.addi       s33, s39, #96
    s.add        s39, s6, s33
    v.st.b       [s30, #0], v28
    s.addi       s30, s28, #288
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s37, #0]
    v.extract    s33, v26, #11
    s.add        s37, s33, s21
    s.addi       s33, s37, #96
    s.add        s37, s6, s33
    v.st.b       [s18, #0], v28
    s.addi       s18, s28, #320
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s38, #0]
    v.extract    s33, v26, #12
    s.add        s38, s33, s21
    s.addi       s33, s38, #96
    s.add        s38, s6, s33
    v.st.b       [s20, #0], v28
    s.addi       s20, s28, #352
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s36, #0]
    v.extract    s33, v26, #13
    s.add        s36, s33, s21
    s.addi       s33, s36, #96
    s.add        s36, s6, s33
    v.st.b       [s23, #0], v28
    s.addi       s23, s28, #384
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s32, #0]
    v.extract    s32, v26, #14
    s.add        s33, s32, s21
    s.addi       s32, s33, #96
    s.add        s33, s6, s32
    v.st.b       [s30, #0], v28
    s.addi       s30, s28, #416
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s39, #0]
    v.extract    s32, v26, #15
    s.add        s39, s32, s21
    s.addi       s32, s39, #96
    s.add        s39, s6, s32
    v.st.b       [s18, #0], v28
    s.addi       s18, s28, #448
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v28, [s37, #0]
    s.movz       s32, #0
    s.add        s37, s32, s27                   // the tile origin
    s.add        s27, s32, s14                   // the tile origin
    v.splat      v31, s37
    v.extract    s32, v26, #0
    v.splat      v33, s27
    s.add        s27, s32, s21
    s.addi       s32, s28, #480
    s.addi       s37, s27, #112
    v.add        v34, v1, v33
    v.st.b       [s20, #0], v28
    s.add        s20, s6, s37
    v.cmp.lt     p2, v34, v31
    v.extract    s27, v26, #1
    s.add        s37, s27, s21
    s.addi       s27, s37, #112
    s.add        s37, s6, s27
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s38, #0]
    s.addi       s27, s28, #16
    v.st.b       [s23, #0], v1
    v.extract    s23, v26, #2
    s.add        s38, s23, s21
    s.addi       s23, s38, #112
    s.add        s38, s6, s23
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s36, #0]
    s.addi       s23, s28, #48
    v.st.b       [s30, #0], v1
    v.extract    s30, v26, #3
    s.add        s36, s30, s21
    s.addi       s30, s36, #112
    s.add        s36, s6, s30
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s33, #0]
    s.addi       s30, s28, #80
    v.st.b       [s18, #0], v1
    v.extract    s18, v26, #4
    s.add        s33, s18, s21
    s.addi       s18, s33, #112
    s.add        s33, s6, s18
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s39, #0]
    s.addi       s18, s28, #112
    v.st.b       [s32, #0], v1
    v.extract    s32, v26, #5
    s.add        s39, s32, s21
    s.addi       s32, s39, #112
    s.add        s39, s6, s32
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s20, #0]
    s.addi       s20, s28, #144
    v.st.b       [s27, #0], v1
    v.extract    s27, v26, #6
    s.add        s32, s27, s21
    s.addi       s27, s32, #112
    s.add        s32, s6, s27
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s37, #0]
    s.addi       s27, s28, #176
    v.st.b       [s23, #0], v1
    v.extract    s23, v26, #7
    s.add        s37, s23, s21
    s.addi       s23, s37, #112
    s.add        s37, s6, s23
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s38, #0]
    s.addi       s23, s28, #208
    v.st.b       [s30, #0], v1
    v.extract    s30, v26, #8
    s.add        s38, s30, s21
    s.addi       s30, s38, #112
    s.add        s38, s6, s30
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s36, #0]
    s.addi       s30, s28, #240
    v.st.b       [s18, #0], v1
    v.extract    s18, v26, #9
    s.add        s36, s18, s21
    s.addi       s18, s36, #112
    s.add        s36, s6, s18
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s33, #0]
    s.addi       s18, s28, #272
    v.st.b       [s20, #0], v1
    v.extract    s20, v26, #10
    s.add        s33, s20, s21
    s.addi       s20, s33, #112
    s.add        s33, s6, s20
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s39, #0]
    s.addi       s20, s28, #304
    v.st.b       [s27, #0], v1
    v.extract    s27, v26, #11
    s.add        s39, s27, s21
    s.addi       s27, s39, #112
    s.add        s39, s6, s27
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s32, #0]
    s.addi       s27, s28, #336
    v.st.b       [s23, #0], v1
    v.extract    s23, v26, #12
    s.add        s32, s23, s21
    s.addi       s23, s32, #112
    s.add        s32, s6, s23
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s37, #0]
    s.addi       s23, s28, #368
    v.st.b       [s30, #0], v1
    v.extract    s30, v26, #13
    s.add        s37, s30, s21
    s.addi       s30, s37, #112
    s.add        s37, s6, s30
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s38, #0]
    s.addi       s30, s28, #400
    v.st.b       [s18, #0], v1
    v.extract    s18, v26, #14
    s.add        s38, s18, s21
    s.addi       s18, s38, #112
    s.add        s38, s6, s18
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s36, #0]
    s.addi       s18, s28, #432
    v.st.b       [s20, #0], v1
    v.extract    s20, v26, #15
    s.add        s36, s20, s21
    s.addi       s20, s36, #112
    s.add        s36, s6, s20
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s33, #0]
    s.addi       s20, s28, #464
    v.st.b       [s27, #0], v1
    v.extract    s27, v30, #0
    s.add        s33, s27, s21
    s.addi       s27, s33, #96
    s.add        s33, s6, s27
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s39, #0]
    s.addi       s27, s28, #496
    v.st.b       [s23, #0], v1
    v.extract    s23, v30, #1
    s.add        s39, s23, s21
    s.addi       s23, s39, #96
    s.add        s39, s6, s23
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s32, #0]
    s.addi       s23, s16, #24064                // 512 bytes of repack scratch
    v.st.b       [s30, #0], v1
    s.addi       s30, s23, #0
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s37, #0]
    v.extract    s32, v30, #2
    s.add        s37, s32, s21
    s.addi       s32, s37, #96
    s.add        s37, s6, s32
    v.st.b       [s18, #0], v1
    s.addi       s18, s23, #32
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s38, #0]
    v.extract    s32, v30, #3
    s.add        s38, s32, s21
    s.addi       s32, s38, #96
    s.add        s38, s6, s32
    v.st.b       [s20, #0], v1
    s.addi       s20, s23, #64
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s36, #0]
    v.extract    s32, v30, #4
    s.add        s36, s32, s21
    s.addi       s32, s36, #96
    s.add        s36, s6, s32
    v.st.b       [s27, #0], v1
    s.addi       s27, s23, #96
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s33, #0]
    v.extract    s32, v30, #5
    s.add        s33, s32, s21
    s.addi       s32, s33, #96
    s.add        s33, s6, s32
    v.st.b       [s30, #0], v1
    s.addi       s30, s23, #128
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s39, #0]
    v.extract    s32, v30, #6
    s.add        s39, s32, s21
    s.addi       s32, s39, #96
    s.add        s39, s6, s32
    v.st.b       [s18, #0], v1
    s.addi       s18, s23, #160
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s37, #0]
    v.extract    s32, v30, #7
    s.add        s37, s32, s21
    s.addi       s32, s37, #96
    s.add        s37, s6, s32
    v.st.b       [s20, #0], v1
    s.addi       s20, s23, #192
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s38, #0]
    v.extract    s32, v30, #8
    s.add        s38, s32, s21
    s.addi       s32, s38, #96
    s.add        s38, s6, s32
    v.st.b       [s27, #0], v1
    s.addi       s27, s23, #224
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s36, #0]
    v.extract    s32, v30, #9
    s.add        s36, s32, s21
    s.addi       s32, s36, #96
    s.add        s36, s6, s32
    v.st.b       [s30, #0], v1
    s.addi       s30, s23, #256
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s33, #0]
    v.extract    s32, v30, #10
    s.add        s33, s32, s21
    s.addi       s32, s33, #96
    s.add        s33, s6, s32
    v.st.b       [s18, #0], v1
    s.addi       s18, s23, #288
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s39, #0]
    v.extract    s32, v30, #11
    s.add        s39, s32, s21
    s.addi       s32, s39, #96
    s.add        s39, s6, s32
    v.st.b       [s20, #0], v1
    s.addi       s20, s23, #320
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s37, #0]
    v.extract    s32, v30, #12
    s.add        s37, s32, s21
    s.addi       s32, s37, #96
    s.add        s37, s6, s32
    v.st.b       [s27, #0], v1
    s.addi       s27, s23, #352
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s38, #0]
    v.extract    s32, v30, #13
    s.add        s38, s32, s21
    s.addi       s32, s38, #96
    s.add        s38, s6, s32
    v.st.b       [s30, #0], v1
    s.addi       s30, s23, #384
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s36, #0]
    v.extract    s32, v30, #14
    s.add        s36, s32, s21
    s.addi       s32, s36, #96
    s.add        s36, s6, s32
    v.st.b       [s18, #0], v1
    s.addi       s18, s23, #416
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s33, #0]
    v.extract    s32, v30, #15
    s.add        s33, s32, s21
    s.addi       s32, s33, #96
    s.add        s33, s6, s32
    v.st.b       [s20, #0], v1
    s.addi       s20, s23, #448
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s39, #0]
    v.extract    s32, v30, #0
    s.add        s39, s32, s21
    s.addi       s32, s39, #112
    s.add        s39, s6, s32
    v.st.b       [s27, #0], v1
    s.addi       s27, s23, #480
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s37, #0]
    v.extract    s32, v30, #1
    s.add        s37, s32, s21
    s.addi       s32, s37, #112
    s.add        s37, s6, s32
    v.st.b       [s30, #0], v1
    s.addi       s30, s23, #16
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s38, #0]
    v.extract    s32, v30, #2
    s.add        s38, s32, s21
    s.addi       s32, s38, #112
    s.add        s38, s6, s32
    v.st.b       [s18, #0], v1
    s.addi       s18, s23, #48
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s36, #0]
    v.extract    s32, v30, #3
    s.add        s36, s32, s21
    s.addi       s32, s36, #112
    s.add        s36, s6, s32
    v.st.b       [s20, #0], v1
    s.addi       s20, s23, #80
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s33, #0]
    v.extract    s32, v30, #4
    s.add        s33, s32, s21
    s.addi       s32, s33, #112
    s.add        s33, s6, s32
    v.st.b       [s27, #0], v1
    s.addi       s27, s23, #112
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s39, #0]
    v.extract    s32, v30, #5
    s.add        s39, s32, s21
    s.addi       s32, s39, #112
    s.add        s39, s6, s32
    v.st.b       [s30, #0], v1
    s.addi       s30, s23, #144
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s37, #0]
    v.extract    s32, v30, #6
    s.add        s37, s32, s21
    s.addi       s32, s37, #112
    s.add        s37, s6, s32
    v.st.b       [s18, #0], v1
    s.addi       s18, s23, #176
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s38, #0]
    v.extract    s32, v30, #7
    s.add        s38, s32, s21
    s.addi       s32, s38, #112
    s.add        s38, s6, s32
    v.st.b       [s20, #0], v1
    s.addi       s20, s23, #208
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s36, #0]
    v.extract    s32, v30, #8
    s.add        s36, s32, s21
    s.addi       s32, s36, #112
    s.add        s36, s6, s32
    v.st.b       [s27, #0], v1
    s.addi       s27, s23, #240
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s33, #0]
    v.extract    s32, v30, #9
    s.add        s33, s32, s21
    s.addi       s32, s33, #112
    s.add        s33, s6, s32
    v.st.b       [s30, #0], v1
    s.addi       s30, s23, #272
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s39, #0]
    v.extract    s32, v30, #10
    s.add        s39, s32, s21
    s.addi       s32, s39, #112
    s.add        s39, s6, s32
    v.st.b       [s18, #0], v1
    s.addi       s18, s23, #304
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s37, #0]
    v.extract    s32, v30, #11
    s.add        s37, s32, s21
    s.addi       s32, s37, #112
    s.add        s37, s6, s32
    v.st.b       [s20, #0], v1
    s.addi       s20, s23, #336
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s38, #0]
    v.extract    s32, v30, #12
    s.add        s38, s32, s21
    s.addi       s32, s38, #112
    s.add        s38, s6, s32
    v.st.b       [s27, #0], v1
    s.addi       s27, s23, #368
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s36, #0]
    v.extract    s32, v30, #13
    s.add        s36, s32, s21
    s.addi       s32, s36, #112
    s.add        s36, s6, s32
    v.st.b       [s30, #0], v1
    s.addi       s30, s23, #400
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s33, #0]
    v.extract    s32, v30, #14
    s.add        s33, s32, s21
    s.addi       s32, s33, #112
    s.add        s33, s6, s32
    v.st.b       [s18, #0], v1
    s.addi       s18, s23, #432
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s39, #0]
    v.extract    s32, v30, #15
    s.add        s39, s32, s21
    s.addi       s32, s39, #112
    s.add        s39, s6, s32
    v.st.b       [s20, #0], v1
    s.addi       s20, s23, #464
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s37, #0]
    v.extract    s32, v29, #0
    s.add        s37, s32, s21
    s.addi       s32, s37, #96
    s.add        s37, s6, s32
    v.st.b       [s27, #0], v1
    s.addi       s27, s23, #496
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s38, #0]
    v.extract    s32, v29, #1
    s.add        s38, s32, s21
    s.addi       s32, s38, #96
    s.add        s38, s6, s32
    v.st.b       [s30, #0], v1
    s.addi       s30, s16, #24576                // 512 bytes of repack scratch
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s36, #0]
    s.addi       s32, s30, #0
    v.st.b       [s18, #0], v1
    v.extract    s18, v29, #2
    s.add        s36, s18, s21
    s.addi       s18, s36, #96
    s.add        s36, s6, s18
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s33, #0]
    s.addi       s18, s30, #32
    v.st.b       [s20, #0], v1
    v.extract    s20, v29, #3
    s.add        s33, s20, s21
    s.addi       s20, s33, #96
    s.add        s33, s6, s20
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s39, #0]
    s.addi       s20, s30, #64
    v.st.b       [s27, #0], v1
    v.extract    s27, v29, #4
    s.add        s39, s27, s21
    s.addi       s27, s39, #96
    s.add        s39, s6, s27
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s37, #0]
    s.addi       s27, s30, #96
    v.st.b       [s32, #0], v1
    v.extract    s32, v29, #5
    s.add        s37, s32, s21
    s.addi       s32, s37, #96
    s.add        s37, s6, s32
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s38, #0]
    s.addi       s32, s30, #128
    v.st.b       [s18, #0], v1
    v.extract    s18, v29, #6
    s.add        s38, s18, s21
    s.addi       s18, s38, #96
    s.add        s38, s6, s18
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s36, #0]
    s.addi       s18, s30, #160
    v.st.b       [s20, #0], v1
    v.extract    s20, v29, #7
    s.add        s36, s20, s21
    s.addi       s20, s36, #96
    s.add        s36, s6, s20
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s33, #0]
    s.addi       s20, s30, #192
    v.st.b       [s27, #0], v1
    v.extract    s27, v29, #8
    s.add        s33, s27, s21
    s.addi       s27, s33, #96
    s.add        s33, s6, s27
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s39, #0]
    s.addi       s27, s30, #224
    v.st.b       [s32, #0], v1
    v.extract    s32, v29, #9
    s.add        s39, s32, s21
    s.addi       s32, s39, #96
    s.add        s39, s6, s32
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s37, #0]
    s.addi       s32, s30, #256
    v.st.b       [s18, #0], v1
    v.extract    s18, v29, #10
    s.add        s37, s18, s21
    s.addi       s18, s37, #96
    s.add        s37, s6, s18
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s38, #0]
    s.addi       s18, s30, #288
    v.st.b       [s20, #0], v1
    v.extract    s20, v29, #11
    s.add        s38, s20, s21
    s.addi       s20, s38, #96
    s.add        s38, s6, s20
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s36, #0]
    s.addi       s20, s30, #320
    v.st.b       [s27, #0], v1
    v.extract    s27, v29, #12
    s.add        s36, s27, s21
    s.addi       s27, s36, #96
    s.add        s36, s6, s27
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s33, #0]
    s.addi       s27, s30, #352
    v.st.b       [s32, #0], v1
    v.extract    s32, v29, #13
    s.add        s33, s32, s21
    s.addi       s32, s33, #96
    s.add        s33, s6, s32
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s39, #0]
    s.addi       s32, s30, #384
    v.st.b       [s18, #0], v1
    v.extract    s18, v29, #14
    s.add        s39, s18, s21
    s.addi       s18, s39, #96
    s.add        s39, s6, s18
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s37, #0]
    s.addi       s18, s30, #416
    v.st.b       [s20, #0], v1
    v.extract    s20, v29, #15
    s.add        s37, s20, s21
    s.addi       s20, s37, #96
    s.add        s37, s6, s20
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s38, #0]
    s.addi       s20, s30, #448
    v.st.b       [s27, #0], v1
    v.extract    s27, v29, #0
    s.add        s38, s27, s21
    s.addi       s27, s38, #112
    s.add        s38, s6, s27
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s36, #0]
    s.addi       s27, s30, #480
    v.st.b       [s32, #0], v1
    v.extract    s32, v29, #1
    s.add        s36, s32, s21
    s.addi       s32, s36, #112
    s.add        s36, s6, s32
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s33, #0]
    s.addi       s32, s30, #16
    v.st.b       [s18, #0], v1
    v.extract    s18, v29, #2
    s.add        s33, s18, s21
    s.addi       s18, s33, #112
    s.add        s33, s6, s18
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s39, #0]
    s.addi       s18, s30, #48
    v.st.b       [s20, #0], v1
    v.extract    s20, v29, #3
    s.add        s39, s20, s21
    s.addi       s20, s39, #112
    s.add        s39, s6, s20
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s37, #0]
    s.addi       s20, s30, #80
    v.st.b       [s27, #0], v1
    v.extract    s27, v29, #4
    s.add        s37, s27, s21
    s.addi       s27, s37, #112
    s.add        s37, s6, s27
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s38, #0]
    s.addi       s27, s30, #112
    v.st.b       [s32, #0], v1
    v.extract    s32, v29, #5
    s.add        s38, s32, s21
    s.addi       s32, s38, #112
    s.add        s38, s6, s32
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s36, #0]
    s.addi       s32, s30, #144
    v.st.b       [s18, #0], v1
    v.extract    s18, v29, #6
    s.add        s36, s18, s21
    s.addi       s18, s36, #112
    s.add        s36, s6, s18
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s33, #0]
    s.addi       s18, s30, #176
    v.st.b       [s20, #0], v1
    v.extract    s20, v29, #7
    s.add        s33, s20, s21
    s.addi       s20, s33, #112
    s.add        s33, s6, s20
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s39, #0]
    s.addi       s20, s30, #208
    v.st.b       [s27, #0], v1
    v.extract    s27, v29, #8
    s.add        s39, s27, s21
    s.addi       s27, s39, #112
    s.add        s39, s6, s27
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s37, #0]
    s.addi       s27, s30, #240
    v.st.b       [s32, #0], v1
    v.extract    s32, v29, #9
    s.add        s37, s32, s21
    s.addi       s32, s37, #112
    s.add        s37, s6, s32
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s38, #0]
    s.addi       s32, s30, #272
    v.st.b       [s18, #0], v1
    v.extract    s18, v29, #10
    s.add        s38, s18, s21
    s.addi       s18, s38, #112
    s.add        s38, s6, s18
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s36, #0]
    s.addi       s18, s30, #304
    v.st.b       [s20, #0], v1
    v.extract    s20, v29, #11
    s.add        s36, s20, s21
    s.addi       s20, s36, #112
    s.add        s36, s6, s20
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s33, #0]
    s.addi       s20, s30, #336
    v.st.b       [s27, #0], v1
    v.extract    s27, v29, #12
    s.add        s33, s27, s21
    s.addi       s27, s33, #112
    s.add        s33, s6, s27
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s39, #0]
    s.addi       s27, s30, #368
    v.st.b       [s32, #0], v1
    v.extract    s32, v29, #13
    s.add        s39, s32, s21
    s.addi       s32, s39, #112
    s.add        s39, s6, s32
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s37, #0]
    s.addi       s32, s30, #400
    v.st.b       [s18, #0], v1
    v.extract    s18, v29, #14
    s.add        s37, s18, s21
    s.addi       s18, s37, #112
    s.add        s37, s6, s18
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s38, #0]
    s.addi       s18, s30, #432
    v.st.b       [s20, #0], v1
    v.extract    s20, v29, #15
    s.add        s38, s20, s21
    s.addi       s20, s38, #112
    s.add        s38, s6, s20
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s36, #0]
    s.addi       s20, s30, #464
    v.st.b       [s27, #0], v1
    v.extract    s27, v32, #0
    s.add        s36, s27, s21
    s.addi       s27, s36, #96
    s.add        s36, s6, s27
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s33, #0]
    s.addi       s27, s30, #496
    v.st.b       [s32, #0], v1
    v.extract    s32, v32, #1
    s.add        s33, s32, s21
    s.addi       s32, s33, #96
    s.add        s33, s6, s32
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s39, #0]
    s.addi       s32, s16, #25088                // 512 bytes of repack scratch
    v.st.b       [s18, #0], v1
    s.addi       s18, s32, #0
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s37, #0]
    v.extract    s37, v32, #2
    s.add        s39, s37, s21
    s.addi       s37, s39, #96
    s.add        s39, s6, s37
    v.st.b       [s20, #0], v1
    s.addi       s20, s32, #32
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s38, #0]
    v.extract    s37, v32, #3
    s.add        s38, s37, s21
    s.addi       s37, s38, #96
    s.add        s38, s6, s37
    v.st.b       [s27, #0], v1
    s.addi       s27, s32, #64
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s36, #0]
    v.extract    s36, v32, #4
    s.add        s37, s36, s21
    s.addi       s36, s37, #96
    s.add        s37, s6, s36
    v.st.b       [s18, #0], v1
    s.addi       s18, s32, #96
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s33, #0]
    v.extract    s33, v32, #5
    s.add        s36, s33, s21
    s.addi       s33, s36, #96
    s.add        s36, s6, s33
    v.st.b       [s20, #0], v1
    s.addi       s20, s32, #128
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s39, #0]
    v.extract    s33, v32, #6
    s.add        s39, s33, s21
    s.addi       s33, s39, #96
    s.add        s39, s6, s33
    v.st.b       [s27, #0], v1
    s.addi       s27, s32, #160
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s38, #0]
    v.extract    s33, v32, #7
    s.add        s38, s33, s21
    s.addi       s33, s38, #96
    s.add        s38, s6, s33
    v.st.b       [s18, #0], v1
    s.addi       s18, s32, #192
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s37, #0]
    v.extract    s33, v32, #8
    s.add        s37, s33, s21
    s.addi       s33, s37, #96
    s.add        s37, s6, s33
    v.st.b       [s20, #0], v1
    s.addi       s20, s32, #224
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s36, #0]
    v.extract    s33, v32, #9
    s.add        s36, s33, s21
    s.addi       s33, s36, #96
    s.add        s36, s6, s33
    v.st.b       [s27, #0], v1
    s.addi       s27, s32, #256
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s39, #0]
    v.extract    s33, v32, #10
    s.add        s39, s33, s21
    s.addi       s33, s39, #96
    s.add        s39, s6, s33
    v.st.b       [s18, #0], v1
    s.addi       s18, s32, #288
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s38, #0]
    v.extract    s33, v32, #11
    s.add        s38, s33, s21
    s.addi       s33, s38, #96
    s.add        s38, s6, s33
    v.st.b       [s20, #0], v1
    s.addi       s20, s32, #320
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s37, #0]
    v.extract    s33, v32, #12
    s.add        s37, s33, s21
    s.addi       s33, s37, #96
    s.add        s37, s6, s33
    v.st.b       [s27, #0], v1
    s.addi       s27, s32, #352
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s36, #0]
    v.extract    s33, v32, #13
    s.add        s36, s33, s21
    s.addi       s33, s36, #96
    s.add        s36, s6, s33
    v.st.b       [s18, #0], v1
    s.addi       s18, s32, #384
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s39, #0]
    v.extract    s33, v32, #14
    s.add        s39, s33, s21
    s.addi       s33, s39, #96
    s.add        s39, s6, s33
    v.st.b       [s20, #0], v1
    s.addi       s20, s32, #416
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s38, #0]
    v.extract    s33, v32, #15
    s.add        s38, s33, s21
    s.addi       s33, s38, #96
    s.add        s38, s6, s33
    v.st.b       [s27, #0], v1
    s.addi       s27, s32, #448
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s37, #0]
    v.extract    s33, v32, #0
    s.add        s37, s33, s21
    s.addi       s33, s37, #112
    s.add        s37, s6, s33
    v.st.b       [s18, #0], v1
    s.addi       s18, s32, #480
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s36, #0]
    v.extract    s33, v32, #1
    s.add        s36, s33, s21
    s.addi       s33, s36, #112
    s.add        s36, s6, s33
    v.st.b       [s20, #0], v1
    s.addi       s20, s32, #16
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s39, #0]
    v.extract    s33, v32, #2
    s.add        s39, s33, s21
    s.addi       s33, s39, #112
    s.add        s39, s6, s33
    v.st.b       [s27, #0], v1
    s.addi       s27, s32, #48
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s38, #0]
    v.extract    s33, v32, #3
    s.add        s38, s33, s21
    s.addi       s33, s38, #112
    s.add        s38, s6, s33
    v.st.b       [s18, #0], v1
    s.addi       s18, s32, #80
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s37, #0]
    v.extract    s33, v32, #4
    s.add        s37, s33, s21
    s.addi       s33, s37, #112
    s.add        s37, s6, s33
    v.st.b       [s20, #0], v1
    s.addi       s20, s32, #112
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s36, #0]
    v.extract    s33, v32, #5
    s.add        s36, s33, s21
    s.addi       s33, s36, #112
    s.add        s36, s6, s33
    v.st.b       [s27, #0], v1
    s.addi       s27, s32, #144
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s39, #0]
    v.extract    s33, v32, #6
    s.add        s39, s33, s21
    s.addi       s33, s39, #112
    s.add        s39, s6, s33
    v.st.b       [s18, #0], v1
    s.addi       s18, s32, #176
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s38, #0]
    v.extract    s33, v32, #7
    s.add        s38, s33, s21
    s.addi       s33, s38, #112
    s.add        s38, s6, s33
    v.st.b       [s20, #0], v1
    s.addi       s20, s32, #208
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s37, #0]
    v.extract    s33, v32, #8
    s.add        s37, s33, s21
    s.addi       s33, s37, #112
    s.add        s37, s6, s33
    v.st.b       [s27, #0], v1
    s.addi       s27, s32, #240
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s36, #0]
    v.extract    s33, v32, #9
    s.add        s36, s33, s21
    s.addi       s33, s36, #112
    s.add        s36, s6, s33
    v.st.b       [s18, #0], v1
    s.addi       s18, s32, #272
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s39, #0]
    v.extract    s33, v32, #10
    s.add        s39, s33, s21
    s.addi       s33, s39, #112
    s.add        s39, s6, s33
    v.st.b       [s20, #0], v1
    s.addi       s20, s32, #304
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s38, #0]
    v.extract    s33, v32, #11
    s.add        s38, s33, s21
    s.addi       s33, s38, #112
    s.add        s38, s6, s33
    v.st.b       [s27, #0], v1
    s.addi       s27, s32, #336
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s37, #0]
    v.extract    s33, v32, #12
    s.add        s37, s33, s21
    s.addi       s33, s37, #112
    s.add        s37, s6, s33
    v.st.b       [s18, #0], v1
    s.addi       s18, s32, #368
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s36, #0]
    v.extract    s33, v32, #13
    s.add        s36, s33, s21
    s.addi       s33, s36, #112
    s.add        s36, s6, s33
    v.st.b       [s20, #0], v1
    s.addi       s20, s32, #400
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s39, #0]
    v.extract    s33, v32, #14
    s.add        s39, s33, s21
    s.addi       s33, s39, #112
    s.add        s39, s6, s33
    v.st.b       [s27, #0], v1
    s.addi       s27, s32, #432
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s38, #0]
    v.extract    s33, v32, #15
    s.add        s38, s33, s21
    s.addi       s33, s38, #112
    s.add        s38, s6, s33
    v.st.b       [s18, #0], v1
    s.addi       s18, s32, #464
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s37, #0]
    s.addi       s33, s32, #496
    v.st.b       [s20, #0], v1
    v.extract    s20, v8, #0
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s36, #0]
    v.st.b       [s27, #0], v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s39, #0]
    v.st.b       [s18, #0], v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v1, [s38, #0]
    v.st.b       [s33, #0], v1
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s20, x8dot_done_27
    s.movz       s18, #0
    s.add        s27, s4, s22
    s.addi       s33, s18, #0
    s.addi       s18, s27, #96
    s.addi       s27, s16, #16640
x8dot_row_28:
    s.addi       s36, s29, #-96
    v.movi       v1, #0
    s.sub        s37, s36, s33
    s.add        s36, s18, s33
    v.splat      v26, s37
    s.shli       s37, s33, #4
    s.addi       s38, s33, #1
    v.cmp.gt     p1, v26, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v1, [s36, v16]             // index is in elements (ISA sec 9.1)
    s.add        s36, s27, s37
    s.movz       s37, #32
    v.st.b       [s36, #0], v1
    fence.acq_rel.device
    s.mov        s33, s38
    s.cmp.lt     s36, s33, s37
    br.nz        s36, x8dot_row_28
x8dot_done_27:
    v.splat      v1, s20
    v.movi       v16, #0
    mb.arm       s18, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s20, #0
    v.extract    s27, v9, #0
    s.movz       s33, #96
    v.cmp.ne     p1, v1, v16
    v.cmp.eq     p2, v1, v16
    s.mov        s36, s20                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s20                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s36, s18            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s27                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s36, s18          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s18
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v1, [s28, #0]
    s.addi       s20, s28, #64
    s.addi       s27, s28, #128
    s.addi       s33, s28, #192
    s.addi       s36, s28, #256
    s.addi       s37, s28, #320
    s.addi       s38, s28, #384
    v.mov        v56, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s28, #448
    v.mov        v57, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s27, #0]
    s.addi       s27, s23, #64
    v.mov        v58, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s33, #0]
    s.addi       s33, s23, #128
    v.mov        v59, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s36, #0]
    s.addi       s36, s23, #192
    v.mov        v60, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s37, #0]
    s.addi       s37, s23, #256
    v.mov        v61, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s38, #0]
    s.addi       s38, s23, #320
    v.mov        v62, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s23, #384
    v.mov        v63, v1                         // hand off through the shared window (sec 7.3)
    mb.arm       s39, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a0, v56, v48, s39
    mb.wait      s39
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v1, [s23, #0]
    v.mov        v56, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s27, #0]
    s.addi       s27, s23, #448
    v.mov        v57, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s33, #0]
    s.addi       s33, s30, #64
    v.mov        v58, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s36, #0]
    s.addi       s36, s30, #128
    v.mov        v59, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s37, #0]
    s.addi       s37, s30, #192
    v.mov        v60, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s38, #0]
    s.addi       s38, s30, #256
    v.mov        v61, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s30, #320
    v.mov        v62, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s27, #0]
    s.addi       s27, s30, #384
    v.mov        v63, v1                         // hand off through the shared window (sec 7.3)
    mb.arm       s40, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a4, v56, v48, s40
    mb.wait      s40
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v1, [s30, #0]
    v.mov        v56, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s33, #0]
    s.addi       s33, s30, #448
    v.mov        v57, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s36, #0]
    s.addi       s36, s32, #64
    v.mov        v58, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s37, #0]
    s.addi       s37, s32, #128
    v.mov        v59, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s38, #0]
    s.addi       s38, s32, #192
    v.mov        v60, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s32, #256
    v.mov        v61, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s27, #0]
    s.addi       s27, s32, #320
    v.mov        v62, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s33, #0]
    s.addi       s33, s32, #384
    v.mov        v63, v1                         // hand off through the shared window (sec 7.3)
    mb.arm       s41, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v48, s41
    mb.wait      s41
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v1, [s32, #0]
    v.mov        v56, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s36, #0]
    s.addi       s36, s32, #448
    v.mov        v57, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s37, #0]
    v.extract    s37, v8, #1
    v.mov        v58, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s38, #0]
    v.mov        v59, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s20, #0]
    v.mov        v60, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s27, #0]
    v.mov        v61, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s33, #0]
    v.mov        v62, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s36, #0]
    v.mov        v63, v1                         // hand off through the shared window (sec 7.3)
    mb.arm       s20, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a12, v56, v48, s20
    mb.wait      s20
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s37, x8dot_done_29
    s.movz       s27, #0
    s.add        s33, s4, s22
    s.addi       s36, s27, #0
    s.addi       s27, s33, #96
    s.addi       s33, s16, #16640
x8dot_row_30:
    s.addi       s38, s29, #-96
    v.movi       v1, #0
    s.sub        s42, s38, s36
    s.add        s38, s27, s36
    v.splat      v16, s42
    s.shli       s42, s36, #4
    s.addi       s43, s36, #1
    v.cmp.gt     p1, v16, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v1, [s38, v17]             // index is in elements (ISA sec 9.1)
    s.add        s38, s33, s42
    s.movz       s42, #32
    v.st.b       [s38, #0], v1
    fence.acq_rel.device
    s.mov        s36, s43
    s.cmp.lt     s38, s36, s42
    br.nz        s38, x8dot_row_30
x8dot_done_29:
    v.splat      v1, s37
    v.movi       v16, #0
    mb.arm       s27, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s33, #0
    v.extract    s36, v9, #1
    s.movz       s37, #96
    v.cmp.ne     p1, v1, v16
    v.cmp.eq     p2, v1, v16
    s.mov        s42, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s42, s27            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s42, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s42, s27          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s27
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v1, [s28, #0]
    s.addi       s33, s28, #64
    s.addi       s36, s28, #128
    s.addi       s37, s28, #192
    s.addi       s38, s28, #256
    s.addi       s42, s28, #320
    s.addi       s43, s28, #384
    v.mov        v56, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s33, #0]
    s.addi       s33, s28, #448
    v.mov        v57, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s36, #0]
    s.addi       s36, s23, #64
    v.mov        v58, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s37, #0]
    s.addi       s37, s23, #128
    v.mov        v59, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s38, #0]
    s.addi       s38, s23, #192
    v.mov        v60, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s42, #0]
    s.addi       s42, s23, #256
    v.mov        v61, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s43, #0]
    s.addi       s43, s23, #320
    v.mov        v62, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s33, #0]
    s.addi       s33, s23, #384
    v.mov        v63, v1                         // hand off through the shared window (sec 7.3)
    mb.arm       s44, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a1, v56, v48, s44
    mb.wait      s44
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v1, [s23, #0]
    v.mov        v56, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s36, #0]
    s.addi       s36, s23, #448
    v.mov        v57, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s37, #0]
    s.addi       s37, s30, #64
    v.mov        v58, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s38, #0]
    s.addi       s38, s30, #128
    v.mov        v59, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s42, #0]
    s.addi       s42, s30, #192
    v.mov        v60, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s43, #0]
    s.addi       s43, s30, #256
    v.mov        v61, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s33, #0]
    s.addi       s33, s30, #320
    v.mov        v62, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s36, #0]
    s.addi       s36, s30, #384
    v.mov        v63, v1                         // hand off through the shared window (sec 7.3)
    mb.arm       s45, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a5, v56, v48, s45
    mb.wait      s45
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v1, [s30, #0]
    v.mov        v56, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s37, #0]
    s.addi       s37, s30, #448
    v.mov        v57, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s38, #0]
    s.addi       s38, s32, #64
    v.mov        v58, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s42, #0]
    s.addi       s42, s32, #128
    v.mov        v59, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s43, #0]
    s.addi       s43, s32, #192
    v.mov        v60, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s33, #0]
    s.addi       s33, s32, #256
    v.mov        v61, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s36, #0]
    s.addi       s36, s32, #320
    v.mov        v62, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s37, #0]
    s.addi       s37, s32, #384
    v.mov        v63, v1                         // hand off through the shared window (sec 7.3)
    mb.arm       s46, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s46
    mb.wait      s46
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v1, [s32, #0]
    v.mov        v56, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s38, #0]
    s.addi       s38, s32, #448
    v.mov        v57, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s42, #0]
    v.extract    s42, v8, #2
    v.mov        v58, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s43, #0]
    v.mov        v59, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s33, #0]
    v.mov        v60, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s36, #0]
    v.mov        v61, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s37, #0]
    v.mov        v62, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s38, #0]
    v.mov        v63, v1                         // hand off through the shared window (sec 7.3)
    mb.arm       s33, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s33
    mb.wait      s33
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s42, x8dot_done_31
    s.movz       s36, #0
    s.add        s37, s4, s22
    s.addi       s38, s36, #0
    s.addi       s36, s37, #96
    s.addi       s37, s16, #16640
x8dot_row_32:
    s.addi       s43, s29, #-96
    v.movi       v1, #0
    s.sub        s47, s43, s38
    s.add        s43, s36, s38
    v.splat      v16, s47
    s.shli       s47, s38, #4
    s.addi       s48, s38, #1
    v.cmp.gt     p1, v16, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v1, [s43, v20]             // index is in elements (ISA sec 9.1)
    s.add        s43, s37, s47
    s.movz       s47, #32
    v.st.b       [s43, #0], v1
    fence.acq_rel.device
    s.mov        s38, s48
    s.cmp.lt     s43, s38, s47
    br.nz        s43, x8dot_row_32
x8dot_done_31:
    v.splat      v1, s42
    v.movi       v16, #0
    mb.arm       s36, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s37, #0
    v.extract    s38, v9, #2
    s.movz       s42, #96
    v.cmp.ne     p1, v1, v16
    v.cmp.eq     p2, v1, v16
    s.mov        s47, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s47, s36            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s47, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s47, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v1, [s28, #0]
    s.addi       s37, s28, #64
    s.addi       s38, s28, #128
    s.addi       s42, s28, #192
    s.addi       s43, s28, #256
    s.addi       s47, s28, #320
    s.addi       s48, s28, #384
    v.mov        v56, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s37, #0]
    s.addi       s37, s28, #448
    v.mov        v57, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s38, #0]
    s.addi       s38, s23, #64
    v.mov        v58, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s42, #0]
    s.addi       s42, s23, #128
    v.mov        v59, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s43, #0]
    s.addi       s43, s23, #192
    v.mov        v60, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s47, #0]
    s.addi       s47, s23, #256
    v.mov        v61, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s48, #0]
    s.addi       s48, s23, #320
    v.mov        v62, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s37, #0]
    s.addi       s37, s23, #384
    v.mov        v63, v1                         // hand off through the shared window (sec 7.3)
    mb.arm       s49, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a2, v56, v48, s49
    mb.wait      s49
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v1, [s23, #0]
    v.mov        v56, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s38, #0]
    s.addi       s38, s23, #448
    v.mov        v57, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s42, #0]
    s.addi       s42, s30, #64
    v.mov        v58, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s43, #0]
    s.addi       s43, s30, #128
    v.mov        v59, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s47, #0]
    s.addi       s47, s30, #192
    v.mov        v60, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s48, #0]
    s.addi       s48, s30, #256
    v.mov        v61, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s37, #0]
    s.addi       s37, s30, #320
    v.mov        v62, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s38, #0]
    s.addi       s38, s30, #384
    v.mov        v63, v1                         // hand off through the shared window (sec 7.3)
    mb.arm       s50, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a6, v56, v48, s50
    mb.wait      s50
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v1, [s30, #0]
    v.mov        v56, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s42, #0]
    s.addi       s42, s30, #448
    v.mov        v57, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s43, #0]
    s.addi       s43, s32, #64
    v.mov        v58, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s47, #0]
    s.addi       s47, s32, #128
    v.mov        v59, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s48, #0]
    s.addi       s48, s32, #192
    v.mov        v60, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s37, #0]
    s.addi       s37, s32, #256
    v.mov        v61, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s38, #0]
    s.addi       s38, s32, #320
    v.mov        v62, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s42, #0]
    s.addi       s42, s32, #384
    v.mov        v63, v1                         // hand off through the shared window (sec 7.3)
    mb.arm       s51, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a10, v56, v48, s51
    mb.wait      s51
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v1, [s32, #0]
    v.mov        v56, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s43, #0]
    s.addi       s43, s32, #448
    v.mov        v57, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s47, #0]
    v.extract    s47, v8, #3
    v.mov        v58, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s48, #0]
    v.mov        v59, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s37, #0]
    v.mov        v60, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s38, #0]
    v.mov        v61, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s42, #0]
    v.mov        v62, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s43, #0]
    v.mov        v63, v1                         // hand off through the shared window (sec 7.3)
    mb.arm       s37, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a14, v56, v48, s37
    mb.wait      s37
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s47, x8dot_done_33
    s.movz       s38, #0
    s.add        s42, s4, s22
    s.addi       s43, s38, #0
    s.addi       s38, s42, #96
    s.addi       s42, s16, #16640
x8dot_row_34:
    s.addi       s48, s29, #-96
    v.movi       v1, #0
    s.sub        s52, s48, s43
    s.add        s48, s38, s43
    v.splat      v8, s52
    s.shli       s52, s43, #4
    s.addi       s53, s43, #1
    v.cmp.gt     p1, v8, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v1, [s48, v12]             // index is in elements (ISA sec 9.1)
    s.add        s48, s42, s52
    s.movz       s52, #32
    v.st.b       [s48, #0], v1
    fence.acq_rel.device
    s.mov        s43, s53
    s.cmp.lt     s48, s43, s52
    br.nz        s48, x8dot_row_34
x8dot_done_33:
    v.splat      v1, s47
    v.movi       v8, #0
    mb.arm       s29, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s38, #0
    v.extract    s42, v9, #3
    s.movz       s43, #96
    v.cmp.ne     p1, v1, v8
    v.cmp.eq     p2, v1, v8
    s.mov        s47, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s47, s29            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s47, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s47, s29          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s29
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v1, [s28, #0]
    s.addi       s38, s28, #64
    s.addi       s42, s28, #128
    s.addi       s43, s28, #192
    s.addi       s47, s28, #256
    s.addi       s48, s28, #320
    s.addi       s52, s28, #384
    s.addi       s53, s28, #448
    v.mov        v56, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s38, #0]
    s.addi       s28, s23, #64
    v.mov        v57, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s42, #0]
    s.addi       s38, s23, #128
    v.mov        v58, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s43, #0]
    s.addi       s42, s23, #192
    v.mov        v59, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s47, #0]
    s.addi       s43, s23, #256
    v.mov        v60, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s48, #0]
    s.addi       s47, s23, #320
    v.mov        v61, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s52, #0]
    s.addi       s48, s23, #384
    v.mov        v62, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s53, #0]
    s.addi       s52, s23, #448
    v.mov        v63, v1                         // hand off through the shared window (sec 7.3)
    mb.arm       s53, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a3, v56, v48, s53
    mb.wait      s53
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s30, #64
    v.mov        v56, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s28, #0]
    s.addi       s28, s30, #128
    v.mov        v57, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s38, #0]
    s.addi       s38, s30, #192
    v.mov        v58, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s42, #0]
    s.addi       s42, s30, #256
    v.mov        v59, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s43, #0]
    s.addi       s43, s30, #320
    v.mov        v60, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s47, #0]
    s.addi       s47, s30, #384
    v.mov        v61, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s48, #0]
    s.addi       s48, s30, #448
    v.mov        v62, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s52, #0]
    s.addi       s52, s32, #64
    v.mov        v63, v1                         // hand off through the shared window (sec 7.3)
    mb.arm       s54, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a7, v56, v48, s54
    mb.wait      s54
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v1, [s30, #0]
    s.addi       s30, s32, #128
    v.mov        v56, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s32, #192
    v.mov        v57, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s28, #0]
    s.addi       s28, s32, #256
    v.mov        v58, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s38, #0]
    s.addi       s38, s32, #320
    v.mov        v59, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s42, #0]
    s.addi       s42, s32, #384
    v.mov        v60, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s43, #0]
    s.addi       s43, s32, #448
    v.mov        v61, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s47, #0]
    s.movz       s47, #0
    v.mov        v62, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s48, #0]
    s.addi       s48, s16, #25600
    v.mov        v63, v1                         // hand off through the shared window (sec 7.3)
    mb.arm       s55, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s55
    mb.wait      s55
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v1, [s32, #0]
    s.movz       s32, #1
    v.mov        v56, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s52, #0]
    s.addi       s52, s48, #64
    v.mov        v57, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s30, #0]
    s.movz       s30, #2
    v.mov        v58, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s48, #128
    v.mov        v59, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s28, #0]
    s.movz       s28, #3
    v.mov        v60, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s38, #0]
    s.addi       s38, s48, #192
    v.mov        v61, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s42, #0]
    s.movz       s42, #4
    v.mov        v62, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s43, #0]
    s.addi       s43, s48, #256
    v.mov        v63, v1                         // hand off through the shared window (sec 7.3)
    mb.arm       s56, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s56
    mb.wait      s56
    a.vread      v1, a0, s47
    s.movz       s47, #5
    v.st.w       [s48, #0], v1
    a.vread      v1, a0, s32
    s.addi       s32, s48, #320
    v.st.w       [s52, #0], v1
    a.vread      v1, a0, s30
    s.movz       s30, #6
    s.addi       s52, s48, #384
    v.st.w       [s23, #0], v1
    a.vread      v1, a0, s28
    s.movz       s23, #7
    s.addi       s28, s48, #448
    v.st.w       [s38, #0], v1
    a.vread      v1, a0, s42
    s.movz       s38, #8
    s.addi       s42, s48, #512
    v.st.w       [s43, #0], v1
    a.vread      v1, a0, s47
    s.movz       s43, #9
    s.addi       s47, s48, #576
    v.st.w       [s32, #0], v1
    a.vread      v1, a0, s30
    s.movz       s30, #10
    s.addi       s32, s48, #640
    v.st.w       [s52, #0], v1
    a.vread      v1, a0, s23
    s.movz       s23, #11
    s.addi       s52, s48, #704
    v.st.w       [s28, #0], v1
    a.vread      v1, a0, s38
    s.movz       s28, #12
    s.addi       s38, s48, #768
    v.st.w       [s42, #0], v1
    a.vread      v1, a0, s43
    s.movz       s42, #13
    s.addi       s43, s48, #832
    v.st.w       [s47, #0], v1
    a.vread      v1, a0, s30
    s.movz       s30, #14
    s.addi       s47, s48, #896
    s.addi       s57, s48, #960
    v.st.w       [s32, #0], v1
    a.vread      v1, a0, s23
    s.movz       s23, #15
    s.movz       s32, #0
    v.st.w       [s52, #0], v1
    a.vread      v1, a0, s28
    s.addi       s28, s16, #26624
    s.movz       s48, #1
    v.st.w       [s38, #0], v1
    a.vread      v1, a0, s42
    s.addi       s38, s28, #64
    s.movz       s42, #2
    v.st.w       [s43, #0], v1
    a.vread      v1, a0, s30
    s.addi       s30, s28, #128
    s.movz       s43, #3
    v.st.w       [s47, #0], v1
    a.vread      v1, a0, s23
    s.addi       s23, s28, #192
    s.movz       s47, #4
    v.st.w       [s57, #0], v1
    fence.acq_rel.device
    a.vread      v1, a1, s32
    s.addi       s32, s28, #256
    s.movz       s52, #5
    v.st.w       [s28, #0], v1
    a.vread      v1, a1, s48
    s.addi       s48, s28, #320
    v.st.w       [s38, #0], v1
    a.vread      v1, a1, s42
    s.movz       s38, #6
    s.addi       s42, s28, #384
    v.st.w       [s30, #0], v1
    a.vread      v1, a1, s43
    s.movz       s30, #7
    s.addi       s43, s28, #448
    v.st.w       [s23, #0], v1
    a.vread      v1, a1, s47
    s.movz       s23, #8
    s.addi       s47, s28, #512
    v.st.w       [s32, #0], v1
    a.vread      v1, a1, s52
    s.movz       s32, #9
    s.addi       s52, s28, #576
    v.st.w       [s48, #0], v1
    a.vread      v1, a1, s38
    s.movz       s38, #10
    s.addi       s48, s28, #640
    v.st.w       [s42, #0], v1
    a.vread      v1, a1, s30
    s.movz       s30, #11
    s.addi       s42, s28, #704
    v.st.w       [s43, #0], v1
    a.vread      v1, a1, s23
    s.movz       s23, #12
    s.addi       s43, s28, #768
    v.st.w       [s47, #0], v1
    a.vread      v1, a1, s32
    s.movz       s32, #13
    s.addi       s47, s28, #832
    v.st.w       [s52, #0], v1
    a.vread      v1, a1, s38
    s.movz       s38, #14
    s.addi       s52, s28, #896
    s.addi       s57, s28, #960
    v.st.w       [s48, #0], v1
    a.vread      v1, a1, s30
    s.movz       s28, #15
    s.movz       s30, #0
    v.st.w       [s42, #0], v1
    a.vread      v1, a1, s23
    s.addi       s23, s16, #27648
    s.movz       s42, #1
    v.st.w       [s43, #0], v1
    a.vread      v1, a1, s32
    s.addi       s32, s23, #64
    s.movz       s43, #2
    v.st.w       [s47, #0], v1
    a.vread      v1, a1, s38
    s.addi       s38, s23, #128
    s.movz       s47, #3
    v.st.w       [s52, #0], v1
    a.vread      v1, a1, s28
    s.addi       s28, s23, #192
    s.movz       s48, #4
    v.st.w       [s57, #0], v1
    fence.acq_rel.device
    a.vread      v1, a2, s30
    s.addi       s30, s23, #256
    s.movz       s52, #5
    v.st.w       [s23, #0], v1
    a.vread      v1, a2, s42
    s.addi       s42, s23, #320
    v.st.w       [s32, #0], v1
    a.vread      v1, a2, s43
    s.movz       s32, #6
    s.addi       s43, s23, #384
    v.st.w       [s38, #0], v1
    a.vread      v1, a2, s47
    s.movz       s38, #7
    s.addi       s47, s23, #448
    v.st.w       [s28, #0], v1
    a.vread      v1, a2, s48
    s.movz       s28, #8
    s.addi       s48, s23, #512
    v.st.w       [s30, #0], v1
    a.vread      v1, a2, s52
    s.movz       s30, #9
    s.addi       s52, s23, #576
    v.st.w       [s42, #0], v1
    a.vread      v1, a2, s32
    s.movz       s32, #10
    s.addi       s42, s23, #640
    v.st.w       [s43, #0], v1
    a.vread      v1, a2, s38
    s.movz       s38, #11
    s.addi       s43, s23, #704
    v.st.w       [s47, #0], v1
    a.vread      v1, a2, s28
    s.movz       s28, #12
    s.addi       s47, s23, #768
    v.st.w       [s48, #0], v1
    a.vread      v1, a2, s30
    s.movz       s30, #13
    s.addi       s48, s23, #832
    v.st.w       [s52, #0], v1
    a.vread      v1, a2, s32
    s.movz       s32, #14
    s.addi       s52, s23, #896
    s.addi       s57, s23, #960
    v.st.w       [s42, #0], v1
    a.vread      v1, a2, s38
    s.movz       s23, #15
    s.movz       s38, #0
    v.st.w       [s43, #0], v1
    a.vread      v1, a2, s28
    s.addi       s28, s16, #28672
    s.movz       s42, #1
    v.st.w       [s47, #0], v1
    a.vread      v1, a2, s30
    s.addi       s30, s28, #64
    s.movz       s43, #2
    v.st.w       [s48, #0], v1
    a.vread      v1, a2, s32
    s.addi       s32, s28, #128
    s.movz       s47, #3
    v.st.w       [s52, #0], v1
    a.vread      v1, a2, s23
    s.addi       s23, s28, #192
    s.movz       s48, #4
    v.st.w       [s57, #0], v1
    fence.acq_rel.device
    a.vread      v1, a3, s38
    s.addi       s38, s28, #256
    s.movz       s52, #5
    v.st.w       [s28, #0], v1
    a.vread      v1, a3, s42
    s.addi       s42, s28, #320
    v.st.w       [s30, #0], v1
    a.vread      v1, a3, s43
    s.movz       s30, #6
    s.addi       s43, s28, #384
    v.st.w       [s32, #0], v1
    a.vread      v1, a3, s47
    s.movz       s32, #7
    s.addi       s47, s28, #448
    v.st.w       [s23, #0], v1
    a.vread      v1, a3, s48
    s.movz       s23, #8
    s.addi       s48, s28, #512
    v.st.w       [s38, #0], v1
    a.vread      v1, a3, s52
    s.movz       s38, #9
    s.addi       s52, s28, #576
    v.st.w       [s42, #0], v1
    a.vread      v1, a3, s30
    s.movz       s30, #10
    s.addi       s42, s28, #640
    v.st.w       [s43, #0], v1
    a.vread      v1, a3, s32
    s.movz       s32, #11
    s.addi       s43, s28, #704
    v.st.w       [s47, #0], v1
    a.vread      v1, a3, s23
    s.movz       s23, #12
    s.addi       s47, s28, #768
    v.st.w       [s48, #0], v1
    a.vread      v1, a3, s38
    s.movz       s38, #13
    s.addi       s48, s28, #832
    v.st.w       [s52, #0], v1
    a.vread      v1, a3, s30
    s.movz       s30, #14
    s.addi       s52, s28, #896
    s.addi       s57, s28, #960
    v.st.w       [s42, #0], v1
    a.vread      v1, a3, s32
    s.movz       s28, #15
    s.movz       s32, #0
    v.st.w       [s43, #0], v1
    a.vread      v1, a3, s23
    s.addi       s23, s16, #29696
    s.movz       s42, #1
    v.st.w       [s47, #0], v1
    a.vread      v1, a3, s38
    s.addi       s38, s23, #64
    s.movz       s43, #2
    v.st.w       [s48, #0], v1
    a.vread      v1, a3, s30
    s.addi       s30, s23, #128
    s.movz       s47, #3
    v.st.w       [s52, #0], v1
    a.vread      v1, a3, s28
    s.addi       s28, s23, #192
    s.movz       s48, #4
    v.st.w       [s57, #0], v1
    fence.acq_rel.device
    a.vread      v1, a4, s32
    s.addi       s32, s23, #256
    s.movz       s52, #5
    v.st.w       [s23, #0], v1
    a.vread      v1, a4, s42
    s.addi       s42, s23, #320
    v.st.w       [s38, #0], v1
    a.vread      v1, a4, s43
    s.movz       s38, #6
    s.addi       s43, s23, #384
    v.st.w       [s30, #0], v1
    a.vread      v1, a4, s47
    s.movz       s30, #7
    s.addi       s47, s23, #448
    v.st.w       [s28, #0], v1
    a.vread      v1, a4, s48
    s.movz       s28, #8
    s.addi       s48, s23, #512
    v.st.w       [s32, #0], v1
    a.vread      v1, a4, s52
    s.movz       s32, #9
    s.addi       s52, s23, #576
    v.st.w       [s42, #0], v1
    a.vread      v1, a4, s38
    s.movz       s38, #10
    s.addi       s42, s23, #640
    v.st.w       [s43, #0], v1
    a.vread      v1, a4, s30
    s.movz       s30, #11
    s.addi       s43, s23, #704
    v.st.w       [s47, #0], v1
    a.vread      v1, a4, s28
    s.movz       s28, #12
    s.addi       s47, s23, #768
    v.st.w       [s48, #0], v1
    a.vread      v1, a4, s32
    s.movz       s32, #13
    s.addi       s48, s23, #832
    v.st.w       [s52, #0], v1
    a.vread      v1, a4, s38
    s.movz       s38, #14
    s.addi       s52, s23, #896
    s.addi       s57, s23, #960
    v.st.w       [s42, #0], v1
    a.vread      v1, a4, s30
    s.movz       s23, #15
    s.movz       s30, #0
    v.st.w       [s43, #0], v1
    a.vread      v1, a4, s28
    s.addi       s28, s16, #30720
    s.movz       s42, #1
    v.st.w       [s47, #0], v1
    a.vread      v1, a4, s32
    s.addi       s32, s28, #64
    s.movz       s43, #2
    v.st.w       [s48, #0], v1
    a.vread      v1, a4, s38
    s.addi       s38, s28, #128
    s.movz       s47, #3
    v.st.w       [s52, #0], v1
    a.vread      v1, a4, s23
    s.addi       s23, s28, #192
    s.movz       s48, #4
    v.st.w       [s57, #0], v1
    fence.acq_rel.device
    a.vread      v1, a5, s30
    s.addi       s30, s28, #256
    s.movz       s52, #5
    v.st.w       [s28, #0], v1
    a.vread      v1, a5, s42
    s.addi       s42, s28, #320
    v.st.w       [s32, #0], v1
    a.vread      v1, a5, s43
    s.movz       s32, #6
    s.addi       s43, s28, #384
    v.st.w       [s38, #0], v1
    a.vread      v1, a5, s47
    s.movz       s38, #7
    s.addi       s47, s28, #448
    v.st.w       [s23, #0], v1
    a.vread      v1, a5, s48
    s.movz       s23, #8
    s.addi       s48, s28, #512
    v.st.w       [s30, #0], v1
    a.vread      v1, a5, s52
    s.movz       s30, #9
    s.addi       s52, s28, #576
    v.st.w       [s42, #0], v1
    a.vread      v1, a5, s32
    s.movz       s32, #10
    s.addi       s42, s28, #640
    v.st.w       [s43, #0], v1
    a.vread      v1, a5, s38
    s.movz       s38, #11
    s.addi       s43, s28, #704
    v.st.w       [s47, #0], v1
    a.vread      v1, a5, s23
    s.movz       s23, #12
    s.addi       s47, s28, #768
    v.st.w       [s48, #0], v1
    a.vread      v1, a5, s30
    s.movz       s30, #13
    s.addi       s48, s28, #832
    v.st.w       [s52, #0], v1
    a.vread      v1, a5, s32
    s.movz       s32, #14
    s.addi       s52, s28, #896
    s.addi       s57, s28, #960
    v.st.w       [s42, #0], v1
    a.vread      v1, a5, s38
    s.movz       s28, #15
    s.movz       s38, #0
    v.st.w       [s43, #0], v1
    a.vread      v1, a5, s23
    s.addi       s23, s16, #31744
    s.movz       s42, #1
    v.st.w       [s47, #0], v1
    a.vread      v1, a5, s30
    s.addi       s30, s23, #64
    s.movz       s43, #2
    v.st.w       [s48, #0], v1
    a.vread      v1, a5, s32
    s.addi       s32, s23, #128
    s.movz       s47, #3
    v.st.w       [s52, #0], v1
    a.vread      v1, a5, s28
    s.addi       s28, s23, #192
    s.movz       s48, #4
    v.st.w       [s57, #0], v1
    fence.acq_rel.device
    a.vread      v1, a6, s38
    s.addi       s38, s23, #256
    s.movz       s52, #5
    v.st.w       [s23, #0], v1
    a.vread      v1, a6, s42
    s.addi       s42, s23, #320
    v.st.w       [s30, #0], v1
    a.vread      v1, a6, s43
    s.movz       s30, #6
    s.addi       s43, s23, #384
    v.st.w       [s32, #0], v1
    a.vread      v1, a6, s47
    s.movz       s32, #7
    s.addi       s47, s23, #448
    v.st.w       [s28, #0], v1
    a.vread      v1, a6, s48
    s.movz       s28, #8
    s.addi       s48, s23, #512
    v.st.w       [s38, #0], v1
    a.vread      v1, a6, s52
    s.movz       s38, #9
    s.addi       s52, s23, #576
    v.st.w       [s42, #0], v1
    a.vread      v1, a6, s30
    s.movz       s30, #10
    s.addi       s42, s23, #640
    v.st.w       [s43, #0], v1
    a.vread      v1, a6, s32
    s.movz       s32, #11
    s.addi       s43, s23, #704
    v.st.w       [s47, #0], v1
    a.vread      v1, a6, s28
    s.movz       s28, #12
    s.addi       s47, s23, #768
    v.st.w       [s48, #0], v1
    a.vread      v1, a6, s38
    s.movz       s38, #13
    s.addi       s48, s23, #832
    v.st.w       [s52, #0], v1
    a.vread      v1, a6, s30
    s.movz       s30, #14
    s.addi       s52, s23, #896
    s.addi       s57, s23, #960
    v.st.w       [s42, #0], v1
    a.vread      v1, a6, s32
    s.movz       s23, #15
    s.movz       s32, #0
    v.st.w       [s43, #0], v1
    a.vread      v1, a6, s28
    s.movz       s28, #32768
    s.movz       s42, #1
    s.add        s43, s16, s28
    v.st.w       [s47, #0], v1
    a.vread      v1, a6, s38
    s.addi       s28, s43, #64
    s.movz       s38, #2
    v.st.w       [s48, #0], v1
    a.vread      v1, a6, s30
    s.addi       s30, s43, #128
    s.movz       s47, #3
    v.st.w       [s52, #0], v1
    a.vread      v1, a6, s23
    s.addi       s23, s43, #192
    s.movz       s48, #4
    v.st.w       [s57, #0], v1
    fence.acq_rel.device
    a.vread      v1, a7, s32
    s.addi       s32, s43, #256
    s.movz       s52, #5
    v.st.w       [s43, #0], v1
    a.vread      v1, a7, s42
    s.addi       s42, s43, #320
    v.st.w       [s28, #0], v1
    a.vread      v1, a7, s38
    s.movz       s28, #6
    s.addi       s38, s43, #384
    v.st.w       [s30, #0], v1
    a.vread      v1, a7, s47
    s.movz       s30, #7
    s.addi       s47, s43, #448
    v.st.w       [s23, #0], v1
    a.vread      v1, a7, s48
    s.movz       s23, #8
    s.addi       s48, s43, #512
    v.st.w       [s32, #0], v1
    a.vread      v1, a7, s52
    s.movz       s32, #9
    s.addi       s52, s43, #576
    v.st.w       [s42, #0], v1
    a.vread      v1, a7, s28
    s.movz       s28, #10
    s.addi       s42, s43, #640
    v.st.w       [s38, #0], v1
    a.vread      v1, a7, s30
    s.movz       s30, #11
    s.addi       s38, s43, #704
    v.st.w       [s47, #0], v1
    a.vread      v1, a7, s23
    s.movz       s23, #12
    s.addi       s47, s43, #768
    v.st.w       [s48, #0], v1
    a.vread      v1, a7, s32
    s.movz       s32, #13
    s.addi       s48, s43, #832
    v.st.w       [s52, #0], v1
    a.vread      v1, a7, s28
    s.movz       s28, #14
    s.addi       s52, s43, #896
    s.addi       s57, s43, #960
    v.st.w       [s42, #0], v1
    a.vread      v1, a7, s30
    s.movz       s30, #15
    s.movz       s42, #0
    v.st.w       [s38, #0], v1
    a.vread      v1, a7, s23
    s.movz       s23, #33792
    s.movz       s38, #1
    s.add        s43, s16, s23
    v.st.w       [s47, #0], v1
    a.vread      v1, a7, s32
    s.addi       s23, s43, #64
    s.movz       s32, #2
    v.st.w       [s48, #0], v1
    a.vread      v1, a7, s28
    s.addi       s28, s43, #128
    s.movz       s47, #3
    v.st.w       [s52, #0], v1
    a.vread      v1, a7, s30
    s.addi       s30, s43, #192
    s.movz       s48, #4
    v.st.w       [s57, #0], v1
    fence.acq_rel.device
    a.vread      v1, a8, s42
    s.addi       s42, s43, #256
    s.movz       s52, #5
    v.st.w       [s43, #0], v1
    a.vread      v1, a8, s38
    s.addi       s38, s43, #320
    v.st.w       [s23, #0], v1
    a.vread      v1, a8, s32
    s.movz       s23, #6
    s.addi       s32, s43, #384
    v.st.w       [s28, #0], v1
    a.vread      v1, a8, s47
    s.movz       s28, #7
    s.addi       s47, s43, #448
    v.st.w       [s30, #0], v1
    a.vread      v1, a8, s48
    s.movz       s30, #8
    s.addi       s48, s43, #512
    v.st.w       [s42, #0], v1
    a.vread      v1, a8, s52
    s.movz       s42, #9
    s.addi       s52, s43, #576
    v.st.w       [s38, #0], v1
    a.vread      v1, a8, s23
    s.movz       s23, #10
    s.addi       s38, s43, #640
    v.st.w       [s32, #0], v1
    a.vread      v1, a8, s28
    s.movz       s28, #11
    s.addi       s32, s43, #704
    v.st.w       [s47, #0], v1
    a.vread      v1, a8, s30
    s.movz       s30, #12
    s.addi       s47, s43, #768
    v.st.w       [s48, #0], v1
    a.vread      v1, a8, s42
    s.movz       s42, #13
    s.addi       s48, s43, #832
    v.st.w       [s52, #0], v1
    a.vread      v1, a8, s23
    s.movz       s23, #14
    s.addi       s52, s43, #896
    s.addi       s57, s43, #960
    v.st.w       [s38, #0], v1
    a.vread      v1, a8, s28
    s.movz       s28, #15
    s.movz       s38, #0
    v.st.w       [s32, #0], v1
    a.vread      v1, a8, s30
    s.movz       s30, #34816
    s.movz       s32, #1
    s.add        s43, s16, s30
    v.st.w       [s47, #0], v1
    a.vread      v1, a8, s42
    s.addi       s30, s43, #64
    s.movz       s42, #2
    v.st.w       [s48, #0], v1
    a.vread      v1, a8, s23
    s.addi       s23, s43, #128
    s.movz       s47, #3
    v.st.w       [s52, #0], v1
    a.vread      v1, a8, s28
    s.addi       s28, s43, #192
    s.movz       s48, #4
    v.st.w       [s57, #0], v1
    fence.acq_rel.device
    a.vread      v1, a9, s38
    s.addi       s38, s43, #256
    s.movz       s52, #5
    v.st.w       [s43, #0], v1
    a.vread      v1, a9, s32
    s.addi       s32, s43, #320
    v.st.w       [s30, #0], v1
    a.vread      v1, a9, s42
    s.movz       s30, #6
    s.addi       s42, s43, #384
    v.st.w       [s23, #0], v1
    a.vread      v1, a9, s47
    s.movz       s23, #7
    s.addi       s47, s43, #448
    v.st.w       [s28, #0], v1
    a.vread      v1, a9, s48
    s.movz       s28, #8
    s.addi       s48, s43, #512
    v.st.w       [s38, #0], v1
    a.vread      v1, a9, s52
    s.movz       s38, #9
    s.addi       s52, s43, #576
    v.st.w       [s32, #0], v1
    a.vread      v1, a9, s30
    s.movz       s30, #10
    s.addi       s32, s43, #640
    v.st.w       [s42, #0], v1
    a.vread      v1, a9, s23
    s.movz       s23, #11
    s.addi       s42, s43, #704
    v.st.w       [s47, #0], v1
    a.vread      v1, a9, s28
    s.movz       s28, #12
    s.addi       s47, s43, #768
    v.st.w       [s48, #0], v1
    a.vread      v1, a9, s38
    s.movz       s38, #13
    s.addi       s48, s43, #832
    v.st.w       [s52, #0], v1
    a.vread      v1, a9, s30
    s.movz       s30, #14
    s.addi       s52, s43, #896
    s.addi       s57, s43, #960
    v.st.w       [s32, #0], v1
    a.vread      v1, a9, s23
    s.movz       s23, #15
    s.movz       s32, #0
    v.st.w       [s42, #0], v1
    a.vread      v1, a9, s28
    s.movz       s28, #35840
    s.movz       s42, #1
    s.add        s43, s16, s28
    v.st.w       [s47, #0], v1
    a.vread      v1, a9, s38
    s.addi       s28, s43, #64
    s.movz       s38, #2
    v.st.w       [s48, #0], v1
    a.vread      v1, a9, s30
    s.addi       s30, s43, #128
    s.movz       s47, #3
    v.st.w       [s52, #0], v1
    a.vread      v1, a9, s23
    s.addi       s23, s43, #192
    s.movz       s48, #4
    v.st.w       [s57, #0], v1
    fence.acq_rel.device
    a.vread      v1, a10, s32
    s.addi       s32, s43, #256
    s.movz       s52, #5
    v.st.w       [s43, #0], v1
    a.vread      v1, a10, s42
    s.addi       s42, s43, #320
    v.st.w       [s28, #0], v1
    a.vread      v1, a10, s38
    s.movz       s28, #6
    s.addi       s38, s43, #384
    v.st.w       [s30, #0], v1
    a.vread      v1, a10, s47
    s.movz       s30, #7
    s.addi       s47, s43, #448
    v.st.w       [s23, #0], v1
    a.vread      v1, a10, s48
    s.movz       s23, #8
    s.addi       s48, s43, #512
    v.st.w       [s32, #0], v1
    a.vread      v1, a10, s52
    s.movz       s32, #9
    s.addi       s52, s43, #576
    v.st.w       [s42, #0], v1
    a.vread      v1, a10, s28
    s.movz       s28, #10
    s.addi       s42, s43, #640
    v.st.w       [s38, #0], v1
    a.vread      v1, a10, s30
    s.movz       s30, #11
    s.addi       s38, s43, #704
    v.st.w       [s47, #0], v1
    a.vread      v1, a10, s23
    s.movz       s23, #12
    s.addi       s47, s43, #768
    v.st.w       [s48, #0], v1
    a.vread      v1, a10, s32
    s.movz       s32, #13
    s.addi       s48, s43, #832
    v.st.w       [s52, #0], v1
    a.vread      v1, a10, s28
    s.movz       s28, #14
    s.addi       s52, s43, #896
    s.addi       s57, s43, #960
    v.st.w       [s42, #0], v1
    a.vread      v1, a10, s30
    s.movz       s30, #15
    s.movz       s42, #0
    v.st.w       [s38, #0], v1
    a.vread      v1, a10, s23
    s.movz       s23, #36864
    s.movz       s38, #1
    s.add        s43, s16, s23
    v.st.w       [s47, #0], v1
    a.vread      v1, a10, s32
    s.addi       s23, s43, #64
    s.movz       s32, #2
    v.st.w       [s48, #0], v1
    a.vread      v1, a10, s28
    s.addi       s28, s43, #128
    s.movz       s47, #3
    v.st.w       [s52, #0], v1
    a.vread      v1, a10, s30
    s.addi       s30, s43, #192
    s.movz       s48, #4
    v.st.w       [s57, #0], v1
    fence.acq_rel.device
    a.vread      v1, a11, s42
    s.addi       s42, s43, #256
    s.movz       s52, #5
    v.st.w       [s43, #0], v1
    a.vread      v1, a11, s38
    s.addi       s38, s43, #320
    v.st.w       [s23, #0], v1
    a.vread      v1, a11, s32
    s.movz       s23, #6
    s.addi       s32, s43, #384
    v.st.w       [s28, #0], v1
    a.vread      v1, a11, s47
    s.movz       s28, #7
    s.addi       s47, s43, #448
    v.st.w       [s30, #0], v1
    a.vread      v1, a11, s48
    s.movz       s30, #8
    s.addi       s48, s43, #512
    v.st.w       [s42, #0], v1
    a.vread      v1, a11, s52
    s.movz       s42, #9
    s.addi       s52, s43, #576
    v.st.w       [s38, #0], v1
    a.vread      v1, a11, s23
    s.movz       s23, #10
    s.addi       s38, s43, #640
    v.st.w       [s32, #0], v1
    a.vread      v1, a11, s28
    s.movz       s28, #11
    s.addi       s32, s43, #704
    v.st.w       [s47, #0], v1
    a.vread      v1, a11, s30
    s.movz       s30, #12
    s.addi       s47, s43, #768
    v.st.w       [s48, #0], v1
    a.vread      v1, a11, s42
    s.movz       s42, #13
    s.addi       s48, s43, #832
    v.st.w       [s52, #0], v1
    a.vread      v1, a11, s23
    s.movz       s23, #14
    s.addi       s52, s43, #896
    s.addi       s57, s43, #960
    v.st.w       [s38, #0], v1
    a.vread      v1, a11, s28
    s.movz       s28, #15
    s.movz       s38, #0
    v.st.w       [s32, #0], v1
    a.vread      v1, a11, s30
    s.movz       s30, #37888
    s.movz       s32, #1
    s.add        s43, s16, s30
    v.st.w       [s47, #0], v1
    a.vread      v1, a11, s42
    s.addi       s30, s43, #64
    s.movz       s42, #2
    v.st.w       [s48, #0], v1
    a.vread      v1, a11, s23
    s.addi       s23, s43, #128
    s.movz       s47, #3
    v.st.w       [s52, #0], v1
    a.vread      v1, a11, s28
    s.addi       s28, s43, #192
    s.movz       s48, #4
    v.st.w       [s57, #0], v1
    fence.acq_rel.device
    a.vread      v1, a12, s38
    s.addi       s38, s43, #256
    s.movz       s52, #5
    v.st.w       [s43, #0], v1
    a.vread      v1, a12, s32
    s.addi       s32, s43, #320
    v.st.w       [s30, #0], v1
    a.vread      v1, a12, s42
    s.movz       s30, #6
    s.addi       s42, s43, #384
    v.st.w       [s23, #0], v1
    a.vread      v1, a12, s47
    s.movz       s23, #7
    s.addi       s47, s43, #448
    v.st.w       [s28, #0], v1
    a.vread      v1, a12, s48
    s.movz       s28, #8
    s.addi       s48, s43, #512
    v.st.w       [s38, #0], v1
    a.vread      v1, a12, s52
    s.movz       s38, #9
    s.addi       s52, s43, #576
    v.st.w       [s32, #0], v1
    a.vread      v1, a12, s30
    s.movz       s30, #10
    s.addi       s32, s43, #640
    v.st.w       [s42, #0], v1
    a.vread      v1, a12, s23
    s.movz       s23, #11
    s.addi       s42, s43, #704
    v.st.w       [s47, #0], v1
    a.vread      v1, a12, s28
    s.movz       s28, #12
    s.addi       s47, s43, #768
    v.st.w       [s48, #0], v1
    a.vread      v1, a12, s38
    s.movz       s38, #13
    s.addi       s48, s43, #832
    v.st.w       [s52, #0], v1
    a.vread      v1, a12, s30
    s.movz       s30, #14
    s.addi       s52, s43, #896
    s.addi       s57, s43, #960
    v.st.w       [s32, #0], v1
    a.vread      v1, a12, s23
    s.movz       s23, #15
    s.movz       s32, #0
    v.st.w       [s42, #0], v1
    a.vread      v1, a12, s28
    s.movz       s28, #38912
    s.movz       s42, #1
    s.add        s43, s16, s28
    v.st.w       [s47, #0], v1
    a.vread      v1, a12, s38
    s.addi       s28, s43, #64
    s.movz       s38, #2
    v.st.w       [s48, #0], v1
    a.vread      v1, a12, s30
    s.addi       s30, s43, #128
    s.movz       s47, #3
    v.st.w       [s52, #0], v1
    a.vread      v1, a12, s23
    s.addi       s23, s43, #192
    s.movz       s48, #4
    v.st.w       [s57, #0], v1
    fence.acq_rel.device
    a.vread      v1, a13, s32
    s.addi       s32, s43, #256
    s.movz       s52, #5
    v.st.w       [s43, #0], v1
    a.vread      v1, a13, s42
    s.addi       s42, s43, #320
    v.st.w       [s28, #0], v1
    a.vread      v1, a13, s38
    s.movz       s28, #6
    s.addi       s38, s43, #384
    v.st.w       [s30, #0], v1
    a.vread      v1, a13, s47
    s.movz       s30, #7
    s.addi       s47, s43, #448
    v.st.w       [s23, #0], v1
    a.vread      v1, a13, s48
    s.movz       s23, #8
    s.addi       s48, s43, #512
    v.st.w       [s32, #0], v1
    a.vread      v1, a13, s52
    s.movz       s32, #9
    s.addi       s52, s43, #576
    v.st.w       [s42, #0], v1
    a.vread      v1, a13, s28
    s.movz       s28, #10
    s.addi       s42, s43, #640
    v.st.w       [s38, #0], v1
    a.vread      v1, a13, s30
    s.movz       s30, #11
    s.addi       s38, s43, #704
    v.st.w       [s47, #0], v1
    a.vread      v1, a13, s23
    s.movz       s23, #12
    s.addi       s47, s43, #768
    v.st.w       [s48, #0], v1
    a.vread      v1, a13, s32
    s.movz       s32, #13
    s.addi       s48, s43, #832
    v.st.w       [s52, #0], v1
    a.vread      v1, a13, s28
    s.movz       s28, #14
    s.addi       s52, s43, #896
    s.addi       s57, s43, #960
    v.st.w       [s42, #0], v1
    a.vread      v1, a13, s30
    s.movz       s30, #15
    s.movz       s42, #0
    v.st.w       [s38, #0], v1
    a.vread      v1, a13, s23
    s.movz       s23, #39936
    s.movz       s38, #1
    s.add        s43, s16, s23
    v.st.w       [s47, #0], v1
    a.vread      v1, a13, s32
    s.addi       s23, s43, #64
    s.movz       s32, #2
    v.st.w       [s48, #0], v1
    a.vread      v1, a13, s28
    s.addi       s28, s43, #128
    s.movz       s47, #3
    v.st.w       [s52, #0], v1
    a.vread      v1, a13, s30
    s.addi       s30, s43, #192
    s.movz       s48, #4
    v.st.w       [s57, #0], v1
    fence.acq_rel.device
    a.vread      v1, a14, s42
    s.addi       s42, s43, #256
    s.movz       s52, #5
    v.st.w       [s43, #0], v1
    a.vread      v1, a14, s38
    s.addi       s38, s43, #320
    v.st.w       [s23, #0], v1
    a.vread      v1, a14, s32
    s.movz       s23, #6
    s.addi       s32, s43, #384
    v.st.w       [s28, #0], v1
    a.vread      v1, a14, s47
    s.movz       s28, #7
    s.addi       s47, s43, #448
    v.st.w       [s30, #0], v1
    a.vread      v1, a14, s48
    s.movz       s30, #8
    s.addi       s48, s43, #512
    v.st.w       [s42, #0], v1
    a.vread      v1, a14, s52
    s.movz       s42, #9
    s.addi       s52, s43, #576
    v.st.w       [s38, #0], v1
    a.vread      v1, a14, s23
    s.movz       s23, #10
    s.addi       s38, s43, #640
    v.st.w       [s32, #0], v1
    a.vread      v1, a14, s28
    s.movz       s28, #11
    s.addi       s32, s43, #704
    v.st.w       [s47, #0], v1
    a.vread      v1, a14, s30
    s.movz       s30, #12
    s.addi       s47, s43, #768
    v.st.w       [s48, #0], v1
    a.vread      v1, a14, s42
    s.movz       s42, #13
    s.addi       s48, s43, #832
    v.st.w       [s52, #0], v1
    a.vread      v1, a14, s23
    s.movz       s23, #14
    s.addi       s52, s43, #896
    s.addi       s57, s43, #960
    v.st.w       [s38, #0], v1
    a.vread      v1, a14, s28
    s.movz       s28, #15
    s.movz       s38, #0
    v.st.w       [s32, #0], v1
    a.vread      v1, a14, s30
    s.movz       s30, #40960
    s.movz       s32, #1
    s.add        s43, s16, s30
    v.st.w       [s47, #0], v1
    a.vread      v1, a14, s42
    s.addi       s30, s43, #64
    s.movz       s42, #2
    v.st.w       [s48, #0], v1
    a.vread      v1, a14, s23
    s.addi       s23, s43, #128
    s.movz       s47, #3
    v.st.w       [s52, #0], v1
    a.vread      v1, a14, s28
    s.addi       s28, s43, #192
    s.movz       s48, #4
    v.st.w       [s57, #0], v1
    fence.acq_rel.device
    a.vread      v1, a15, s38
    s.addi       s38, s43, #256
    s.movz       s52, #5
    v.st.w       [s43, #0], v1
    a.vread      v1, a15, s32
    s.addi       s32, s43, #320
    v.st.w       [s30, #0], v1
    a.vread      v1, a15, s42
    s.movz       s30, #6
    s.addi       s42, s43, #384
    v.st.w       [s23, #0], v1
    a.vread      v1, a15, s47
    s.movz       s23, #7
    s.addi       s47, s43, #448
    v.st.w       [s28, #0], v1
    a.vread      v1, a15, s48
    s.movz       s28, #8
    s.addi       s48, s43, #512
    v.st.w       [s38, #0], v1
    a.vread      v1, a15, s52
    s.movz       s38, #9
    s.addi       s52, s43, #576
    v.st.w       [s32, #0], v1
    a.vread      v1, a15, s30
    s.movz       s30, #10
    s.addi       s32, s43, #640
    v.st.w       [s42, #0], v1
    a.vread      v1, a15, s23
    s.movz       s23, #11
    s.addi       s42, s43, #704
    v.st.w       [s47, #0], v1
    a.vread      v1, a15, s28
    s.movz       s28, #12
    s.addi       s47, s43, #768
    v.st.w       [s48, #0], v1
    a.vread      v1, a15, s38
    s.movz       s38, #13
    s.addi       s48, s43, #832
    v.st.w       [s52, #0], v1
    a.vread      v1, a15, s30
    s.movz       s30, #14
    s.addi       s52, s43, #896
    s.addi       s57, s43, #960
    v.st.w       [s32, #0], v1
    a.vread      v1, a15, s23
    s.movz       s23, #15
    s.addi       s32, s16, #25600
    v.st.w       [s42, #0], v1
    a.vread      v1, a15, s28
    s.addi       s28, s16, #0
    v.extract    s42, v11, #0
    v.splat      v8, s42
    s.movz       s42, #41984
    s.add        s43, s16, s42
    v.st.w       [s47, #0], v1
    a.vread      v1, a15, s38
    s.addi       s38, s16, #25664
    s.addi       s42, s16, #64
    v.st.w       [s48, #0], v1
    a.vread      v1, a15, s30
    v.extract    s30, v11, #1
    s.addi       s47, s43, #64
    v.splat      v9, s30
    s.addi       s30, s16, #25728
    v.st.w       [s52, #0], v1
    a.vread      v1, a15, s23
    s.addi       s23, s16, #128
    v.extract    s48, v11, #2
    v.splat      v12, s48
    s.addi       s48, s43, #128
    v.st.w       [s57, #0], v1
    fence.acq_rel.device
    s.addi       s52, s16, #25792
    v.ld.w       v1, [s32, #0]
    s.addi       s32, s16, #192
    v.ld.w       v16, [s28, #0]
    vf.mul       v17, v1, v8
    v.extract    s28, v11, #3
    v.splat      v1, s28
    s.addi       s28, s43, #192
    vf.mul       v8, v17, v23
    vf.add       v17, v16, v8
    v.st.w       [s43, #0], v17
    v.ld.w       v8, [s38, #0]
    s.addi       s38, s16, #25856
    v.ld.w       v16, [s42, #0]
    vf.mul       v17, v8, v9
    s.addi       s42, s16, #256
    vf.mul       v8, v17, v23
    vf.add       v9, v16, v8
    v.st.w       [s47, #0], v9
    v.extract    s47, v11, #4
    v.splat      v8, s47
    s.addi       s47, s43, #256
    v.ld.w       v9, [s30, #0]
    s.addi       s30, s16, #25920
    v.ld.w       v16, [s23, #0]
    vf.mul       v17, v9, v12
    s.addi       s23, s16, #320
    vf.mul       v9, v17, v23
    vf.add       v12, v16, v9
    v.st.w       [s48, #0], v12
    v.extract    s48, v11, #5
    v.splat      v9, s48
    s.addi       s48, s43, #320
    v.ld.w       v12, [s52, #0]
    s.addi       s52, s16, #25984
    v.ld.w       v16, [s32, #0]
    vf.mul       v17, v12, v1
    s.addi       s32, s16, #384
    vf.mul       v1, v17, v23
    vf.add       v12, v16, v1
    v.st.w       [s28, #0], v12
    v.extract    s28, v11, #6
    v.splat      v1, s28
    s.addi       s28, s43, #384
    v.ld.w       v12, [s38, #0]
    s.addi       s38, s16, #26048
    v.ld.w       v16, [s42, #0]
    vf.mul       v17, v12, v8
    s.addi       s42, s16, #448
    vf.mul       v8, v17, v23
    vf.add       v12, v16, v8
    v.st.w       [s47, #0], v12
    v.extract    s47, v11, #7
    v.splat      v8, s47
    s.addi       s47, s43, #448
    v.ld.w       v12, [s30, #0]
    s.addi       s30, s16, #26112
    v.ld.w       v16, [s23, #0]
    vf.mul       v17, v12, v9
    s.addi       s23, s16, #512
    vf.mul       v9, v17, v23
    vf.add       v12, v16, v9
    v.st.w       [s48, #0], v12
    v.extract    s48, v11, #8
    v.splat      v9, s48
    s.addi       s48, s43, #512
    v.ld.w       v12, [s52, #0]
    s.addi       s52, s16, #26176
    v.ld.w       v16, [s32, #0]
    vf.mul       v17, v12, v1
    s.addi       s32, s16, #576
    vf.mul       v1, v17, v23
    vf.add       v12, v16, v1
    v.st.w       [s28, #0], v12
    v.extract    s28, v11, #9
    v.splat      v1, s28
    s.addi       s28, s43, #576
    v.ld.w       v12, [s38, #0]
    s.addi       s38, s16, #26240
    v.ld.w       v16, [s42, #0]
    vf.mul       v17, v12, v8
    s.addi       s42, s16, #640
    vf.mul       v8, v17, v23
    vf.add       v12, v16, v8
    v.st.w       [s47, #0], v12
    v.extract    s47, v11, #10
    v.splat      v8, s47
    s.addi       s47, s43, #640
    v.ld.w       v12, [s30, #0]
    s.addi       s30, s16, #26304
    v.ld.w       v16, [s23, #0]
    vf.mul       v17, v12, v9
    s.addi       s23, s16, #704
    vf.mul       v9, v17, v23
    vf.add       v12, v16, v9
    v.st.w       [s48, #0], v12
    v.extract    s48, v11, #11
    v.splat      v9, s48
    s.addi       s48, s43, #704
    v.ld.w       v12, [s52, #0]
    s.addi       s52, s16, #26368
    v.ld.w       v16, [s32, #0]
    vf.mul       v17, v12, v1
    s.addi       s32, s16, #768
    vf.mul       v1, v17, v23
    vf.add       v12, v16, v1
    v.st.w       [s28, #0], v12
    v.extract    s28, v11, #12
    v.splat      v1, s28
    s.addi       s28, s43, #768
    v.ld.w       v12, [s38, #0]
    s.addi       s38, s16, #26432
    v.ld.w       v16, [s42, #0]
    vf.mul       v17, v12, v8
    s.addi       s42, s16, #832
    vf.mul       v8, v17, v23
    vf.add       v12, v16, v8
    v.st.w       [s47, #0], v12
    v.extract    s47, v11, #13
    v.splat      v8, s47
    s.addi       s47, s43, #832
    v.ld.w       v12, [s30, #0]
    s.addi       s30, s16, #26496
    v.ld.w       v16, [s23, #0]
    vf.mul       v17, v12, v9
    s.addi       s23, s16, #896
    vf.mul       v9, v17, v23
    vf.add       v12, v16, v9
    v.st.w       [s48, #0], v12
    v.extract    s48, v11, #14
    v.splat      v9, s48
    s.addi       s48, s43, #896
    s.addi       s57, s43, #960
    v.ld.w       v12, [s52, #0]
    s.addi       s43, s16, #26560
    v.ld.w       v16, [s32, #0]
    vf.mul       v17, v12, v1
    s.addi       s32, s16, #960
    vf.mul       v1, v17, v23
    vf.add       v12, v16, v1
    v.st.w       [s28, #0], v12
    v.extract    s28, v11, #15
    v.splat      v1, s28
    s.addi       s28, s16, #26624
    v.ld.w       v12, [s38, #0]
    s.addi       s38, s16, #1024
    v.ld.w       v16, [s42, #0]
    vf.mul       v17, v12, v8
    v.extract    s42, v11, #0
    v.splat      v8, s42
    s.movz       s42, #43008
    vf.mul       v12, v17, v23
    s.add        s52, s16, s42
    vf.add       v17, v16, v12
    v.st.w       [s47, #0], v17
    s.addi       s42, s16, #26688
    v.ld.w       v12, [s30, #0]
    s.addi       s30, s16, #1088
    v.ld.w       v16, [s23, #0]
    vf.mul       v17, v12, v9
    v.extract    s23, v11, #1
    v.splat      v9, s23
    s.addi       s23, s52, #64
    vf.mul       v12, v17, v23
    vf.add       v17, v16, v12
    v.st.w       [s48, #0], v17
    s.addi       s47, s16, #26752
    v.ld.w       v12, [s43, #0]
    s.addi       s43, s16, #1152
    v.ld.w       v16, [s32, #0]
    vf.mul       v17, v12, v1
    v.extract    s32, v11, #2
    v.splat      v1, s32
    s.addi       s32, s52, #128
    vf.mul       v12, v17, v23
    vf.add       v17, v16, v12
    v.st.w       [s57, #0], v17
    fence.acq_rel.device
    s.addi       s48, s16, #26816
    v.ld.w       v12, [s28, #0]
    s.addi       s28, s16, #1216
    v.ld.w       v16, [s38, #0]
    vf.mul       v17, v12, v8
    v.extract    s38, v11, #3
    v.splat      v8, s38
    s.addi       s38, s52, #192
    vf.mul       v12, v17, v24
    vf.add       v17, v16, v12
    v.st.w       [s52, #0], v17
    v.ld.w       v12, [s42, #0]
    s.addi       s42, s16, #26880
    v.ld.w       v16, [s30, #0]
    vf.mul       v17, v12, v9
    s.addi       s30, s16, #1280
    vf.mul       v9, v17, v24
    vf.add       v12, v16, v9
    v.st.w       [s23, #0], v12
    v.extract    s23, v11, #4
    v.splat      v9, s23
    s.addi       s23, s52, #256
    v.ld.w       v12, [s47, #0]
    s.addi       s47, s16, #26944
    v.ld.w       v16, [s43, #0]
    vf.mul       v17, v12, v1
    s.addi       s43, s16, #1344
    vf.mul       v1, v17, v24
    vf.add       v12, v16, v1
    v.st.w       [s32, #0], v12
    v.extract    s32, v11, #5
    v.splat      v1, s32
    s.addi       s32, s52, #320
    v.ld.w       v12, [s48, #0]
    s.addi       s48, s16, #27008
    v.ld.w       v16, [s28, #0]
    vf.mul       v17, v12, v8
    s.addi       s28, s16, #1408
    vf.mul       v8, v17, v24
    vf.add       v12, v16, v8
    v.st.w       [s38, #0], v12
    v.extract    s38, v11, #6
    v.splat      v8, s38
    s.addi       s38, s52, #384
    v.ld.w       v12, [s42, #0]
    s.addi       s42, s16, #27072
    v.ld.w       v16, [s30, #0]
    vf.mul       v17, v12, v9
    s.addi       s30, s16, #1472
    vf.mul       v9, v17, v24
    vf.add       v12, v16, v9
    v.st.w       [s23, #0], v12
    v.extract    s23, v11, #7
    v.splat      v9, s23
    s.addi       s23, s52, #448
    v.ld.w       v12, [s47, #0]
    s.addi       s47, s16, #27136
    v.ld.w       v16, [s43, #0]
    vf.mul       v17, v12, v1
    s.addi       s43, s16, #1536
    vf.mul       v1, v17, v24
    vf.add       v12, v16, v1
    v.st.w       [s32, #0], v12
    v.extract    s32, v11, #8
    v.splat      v1, s32
    s.addi       s32, s52, #512
    v.ld.w       v12, [s48, #0]
    s.addi       s48, s16, #27200
    v.ld.w       v16, [s28, #0]
    vf.mul       v17, v12, v8
    s.addi       s28, s16, #1600
    vf.mul       v8, v17, v24
    vf.add       v12, v16, v8
    v.st.w       [s38, #0], v12
    v.extract    s38, v11, #9
    v.splat      v8, s38
    s.addi       s38, s52, #576
    v.ld.w       v12, [s42, #0]
    s.addi       s42, s16, #27264
    v.ld.w       v16, [s30, #0]
    vf.mul       v17, v12, v9
    s.addi       s30, s16, #1664
    vf.mul       v9, v17, v24
    vf.add       v12, v16, v9
    v.st.w       [s23, #0], v12
    v.extract    s23, v11, #10
    v.splat      v9, s23
    s.addi       s23, s52, #640
    v.ld.w       v12, [s47, #0]
    s.addi       s47, s16, #27328
    v.ld.w       v16, [s43, #0]
    vf.mul       v17, v12, v1
    s.addi       s43, s16, #1728
    vf.mul       v1, v17, v24
    vf.add       v12, v16, v1
    v.st.w       [s32, #0], v12
    v.extract    s32, v11, #11
    v.splat      v1, s32
    s.addi       s32, s52, #704
    v.ld.w       v12, [s48, #0]
    s.addi       s48, s16, #27392
    v.ld.w       v16, [s28, #0]
    vf.mul       v17, v12, v8
    s.addi       s28, s16, #1792
    vf.mul       v8, v17, v24
    vf.add       v12, v16, v8
    v.st.w       [s38, #0], v12
    v.extract    s38, v11, #12
    v.splat      v8, s38
    s.addi       s38, s52, #768
    v.ld.w       v12, [s42, #0]
    s.addi       s42, s16, #27456
    v.ld.w       v16, [s30, #0]
    vf.mul       v17, v12, v9
    s.addi       s30, s16, #1856
    vf.mul       v9, v17, v24
    vf.add       v12, v16, v9
    v.st.w       [s23, #0], v12
    v.extract    s23, v11, #13
    v.splat      v9, s23
    s.addi       s23, s52, #832
    v.ld.w       v12, [s47, #0]
    s.addi       s47, s16, #27520
    v.ld.w       v16, [s43, #0]
    vf.mul       v17, v12, v1
    s.addi       s43, s16, #1920
    vf.mul       v1, v17, v24
    vf.add       v12, v16, v1
    v.st.w       [s32, #0], v12
    v.extract    s32, v11, #14
    v.splat      v1, s32
    s.addi       s32, s52, #896
    s.addi       s57, s52, #960
    v.ld.w       v12, [s48, #0]
    s.addi       s48, s16, #27584
    v.ld.w       v16, [s28, #0]
    vf.mul       v17, v12, v8
    s.addi       s28, s16, #1984
    vf.mul       v8, v17, v24
    vf.add       v12, v16, v8
    v.st.w       [s38, #0], v12
    v.extract    s38, v11, #15
    v.splat      v8, s38
    s.addi       s38, s16, #27648
    v.ld.w       v12, [s42, #0]
    s.addi       s42, s16, #2048
    v.ld.w       v16, [s30, #0]
    vf.mul       v17, v12, v9
    v.extract    s30, v11, #0
    v.splat      v9, s30
    s.movz       s30, #44032
    vf.mul       v12, v17, v24
    s.add        s52, s16, s30
    vf.add       v17, v16, v12
    v.st.w       [s23, #0], v17
    s.addi       s23, s16, #27712
    v.ld.w       v12, [s47, #0]
    s.addi       s30, s16, #2112
    v.ld.w       v16, [s43, #0]
    vf.mul       v17, v12, v1
    v.extract    s43, v11, #1
    v.splat      v1, s43
    s.addi       s43, s52, #64
    vf.mul       v12, v17, v24
    vf.add       v17, v16, v12
    v.st.w       [s32, #0], v17
    s.addi       s32, s16, #27776
    v.ld.w       v12, [s48, #0]
    s.addi       s47, s16, #2176
    v.ld.w       v16, [s28, #0]
    vf.mul       v17, v12, v8
    v.extract    s28, v11, #2
    v.splat      v8, s28
    s.addi       s28, s52, #128
    vf.mul       v12, v17, v24
    vf.add       v17, v16, v12
    v.st.w       [s57, #0], v17
    fence.acq_rel.device
    s.addi       s48, s16, #27840
    v.ld.w       v12, [s38, #0]
    s.addi       s38, s16, #2240
    v.ld.w       v16, [s42, #0]
    vf.mul       v17, v12, v9
    v.extract    s42, v11, #3
    v.splat      v9, s42
    s.addi       s42, s52, #192
    vf.mul       v12, v17, v25
    vf.add       v17, v16, v12
    v.st.w       [s52, #0], v17
    v.ld.w       v12, [s23, #0]
    s.addi       s23, s16, #27904
    v.ld.w       v16, [s30, #0]
    vf.mul       v17, v12, v1
    s.addi       s30, s16, #2304
    vf.mul       v1, v17, v25
    vf.add       v12, v16, v1
    v.st.w       [s43, #0], v12
    v.extract    s43, v11, #4
    v.splat      v1, s43
    s.addi       s43, s52, #256
    v.ld.w       v12, [s32, #0]
    s.addi       s32, s16, #27968
    v.ld.w       v16, [s47, #0]
    vf.mul       v17, v12, v8
    s.addi       s47, s16, #2368
    vf.mul       v8, v17, v25
    vf.add       v12, v16, v8
    v.st.w       [s28, #0], v12
    v.extract    s28, v11, #5
    v.splat      v8, s28
    s.addi       s28, s52, #320
    v.ld.w       v12, [s48, #0]
    s.addi       s48, s16, #28032
    v.ld.w       v16, [s38, #0]
    vf.mul       v17, v12, v9
    s.addi       s38, s16, #2432
    vf.mul       v9, v17, v25
    vf.add       v12, v16, v9
    v.st.w       [s42, #0], v12
    v.extract    s42, v11, #6
    v.splat      v9, s42
    s.addi       s42, s52, #384
    v.ld.w       v12, [s23, #0]
    s.addi       s23, s16, #28096
    v.ld.w       v16, [s30, #0]
    vf.mul       v17, v12, v1
    s.addi       s30, s16, #2496
    vf.mul       v1, v17, v25
    vf.add       v12, v16, v1
    v.st.w       [s43, #0], v12
    v.extract    s43, v11, #7
    v.splat      v1, s43
    s.addi       s43, s52, #448
    v.ld.w       v12, [s32, #0]
    s.addi       s32, s16, #28160
    v.ld.w       v16, [s47, #0]
    vf.mul       v17, v12, v8
    s.addi       s47, s16, #2560
    vf.mul       v8, v17, v25
    vf.add       v12, v16, v8
    v.st.w       [s28, #0], v12
    v.extract    s28, v11, #8
    v.splat      v8, s28
    s.addi       s28, s52, #512
    v.ld.w       v12, [s48, #0]
    s.addi       s48, s16, #28224
    v.ld.w       v16, [s38, #0]
    vf.mul       v17, v12, v9
    s.addi       s38, s16, #2624
    vf.mul       v9, v17, v25
    vf.add       v12, v16, v9
    v.st.w       [s42, #0], v12
    v.extract    s42, v11, #9
    v.splat      v9, s42
    s.addi       s42, s52, #576
    v.ld.w       v12, [s23, #0]
    s.addi       s23, s16, #28288
    v.ld.w       v16, [s30, #0]
    vf.mul       v17, v12, v1
    s.addi       s30, s16, #2688
    vf.mul       v1, v17, v25
    vf.add       v12, v16, v1
    v.st.w       [s43, #0], v12
    v.extract    s43, v11, #10
    v.splat      v1, s43
    s.addi       s43, s52, #640
    v.ld.w       v12, [s32, #0]
    s.addi       s32, s16, #28352
    v.ld.w       v16, [s47, #0]
    vf.mul       v17, v12, v8
    s.addi       s47, s16, #2752
    vf.mul       v8, v17, v25
    vf.add       v12, v16, v8
    v.st.w       [s28, #0], v12
    v.extract    s28, v11, #11
    v.splat      v8, s28
    s.addi       s28, s52, #704
    v.ld.w       v12, [s48, #0]
    s.addi       s48, s16, #28416
    v.ld.w       v16, [s38, #0]
    vf.mul       v17, v12, v9
    s.addi       s38, s16, #2816
    vf.mul       v9, v17, v25
    vf.add       v12, v16, v9
    v.st.w       [s42, #0], v12
    v.extract    s42, v11, #12
    v.splat      v9, s42
    s.addi       s42, s52, #768
    v.ld.w       v12, [s23, #0]
    s.addi       s23, s16, #28480
    v.ld.w       v16, [s30, #0]
    vf.mul       v17, v12, v1
    s.addi       s30, s16, #2880
    vf.mul       v1, v17, v25
    vf.add       v12, v16, v1
    v.st.w       [s43, #0], v12
    v.extract    s43, v11, #13
    v.splat      v1, s43
    s.addi       s43, s52, #832
    v.ld.w       v12, [s32, #0]
    s.addi       s32, s16, #28544
    v.ld.w       v16, [s47, #0]
    vf.mul       v17, v12, v8
    s.addi       s47, s16, #2944
    vf.mul       v8, v17, v25
    vf.add       v12, v16, v8
    v.st.w       [s28, #0], v12
    v.extract    s28, v11, #14
    v.splat      v8, s28
    s.addi       s28, s52, #896
    s.addi       s57, s52, #960
    v.ld.w       v12, [s48, #0]
    s.addi       s48, s16, #28608
    v.ld.w       v16, [s38, #0]
    vf.mul       v17, v12, v9
    s.addi       s38, s16, #3008
    vf.mul       v9, v17, v25
    vf.add       v12, v16, v9
    v.st.w       [s42, #0], v12
    v.extract    s42, v11, #15
    v.splat      v9, s42
    s.addi       s42, s16, #28672
    v.ld.w       v12, [s23, #0]
    s.addi       s23, s16, #3072
    v.ld.w       v16, [s30, #0]
    vf.mul       v17, v12, v1
    v.extract    s30, v11, #0
    v.splat      v1, s30
    s.movz       s30, #45056
    vf.mul       v12, v17, v25
    s.add        s52, s16, s30
    vf.add       v17, v16, v12
    v.st.w       [s43, #0], v17
    s.addi       s30, s16, #28736
    v.ld.w       v12, [s32, #0]
    s.addi       s32, s16, #3136
    v.ld.w       v16, [s47, #0]
    vf.mul       v17, v12, v8
    v.extract    s43, v11, #1
    v.splat      v8, s43
    s.addi       s43, s52, #64
    vf.mul       v12, v17, v25
    vf.add       v17, v16, v12
    v.st.w       [s28, #0], v17
    s.addi       s28, s16, #28800
    v.ld.w       v12, [s48, #0]
    s.addi       s47, s16, #3200
    v.ld.w       v16, [s38, #0]
    vf.mul       v17, v12, v9
    v.extract    s38, v11, #2
    v.splat      v9, s38
    s.addi       s38, s52, #128
    vf.mul       v12, v17, v25
    vf.add       v17, v16, v12
    v.st.w       [s57, #0], v17
    fence.acq_rel.device
    s.addi       s48, s16, #28864
    v.ld.w       v12, [s42, #0]
    s.addi       s42, s16, #3264
    v.ld.w       v16, [s23, #0]
    vf.mul       v17, v12, v1
    v.extract    s23, v11, #3
    v.splat      v1, s23
    s.addi       s23, s52, #192
    vf.mul       v12, v17, v27
    vf.add       v17, v16, v12
    v.st.w       [s52, #0], v17
    v.ld.w       v12, [s30, #0]
    s.addi       s30, s16, #28928
    v.ld.w       v16, [s32, #0]
    vf.mul       v17, v12, v8
    s.addi       s32, s16, #3328
    vf.mul       v8, v17, v27
    vf.add       v12, v16, v8
    v.st.w       [s43, #0], v12
    v.extract    s43, v11, #4
    v.splat      v8, s43
    s.addi       s43, s52, #256
    v.ld.w       v12, [s28, #0]
    s.addi       s28, s16, #28992
    v.ld.w       v16, [s47, #0]
    vf.mul       v17, v12, v9
    s.addi       s47, s16, #3392
    vf.mul       v9, v17, v27
    vf.add       v12, v16, v9
    v.st.w       [s38, #0], v12
    v.extract    s38, v11, #5
    v.splat      v9, s38
    s.addi       s38, s52, #320
    v.ld.w       v12, [s48, #0]
    s.addi       s48, s16, #29056
    v.ld.w       v16, [s42, #0]
    vf.mul       v17, v12, v1
    s.addi       s42, s16, #3456
    vf.mul       v1, v17, v27
    vf.add       v12, v16, v1
    v.st.w       [s23, #0], v12
    v.extract    s23, v11, #6
    v.splat      v1, s23
    s.addi       s23, s52, #384
    v.ld.w       v12, [s30, #0]
    s.addi       s30, s16, #29120
    v.ld.w       v16, [s32, #0]
    vf.mul       v17, v12, v8
    s.addi       s32, s16, #3520
    vf.mul       v8, v17, v27
    vf.add       v12, v16, v8
    v.st.w       [s43, #0], v12
    v.extract    s43, v11, #7
    v.splat      v8, s43
    s.addi       s43, s52, #448
    v.ld.w       v12, [s28, #0]
    s.addi       s28, s16, #29184
    v.ld.w       v16, [s47, #0]
    vf.mul       v17, v12, v9
    s.addi       s47, s16, #3584
    vf.mul       v9, v17, v27
    vf.add       v12, v16, v9
    v.st.w       [s38, #0], v12
    v.extract    s38, v11, #8
    v.splat      v9, s38
    s.addi       s38, s52, #512
    v.ld.w       v12, [s48, #0]
    s.addi       s48, s16, #29248
    v.ld.w       v16, [s42, #0]
    vf.mul       v17, v12, v1
    s.addi       s42, s16, #3648
    vf.mul       v1, v17, v27
    vf.add       v12, v16, v1
    v.st.w       [s23, #0], v12
    v.extract    s23, v11, #9
    v.splat      v1, s23
    s.addi       s23, s52, #576
    v.ld.w       v12, [s30, #0]
    s.addi       s30, s16, #29312
    v.ld.w       v16, [s32, #0]
    vf.mul       v17, v12, v8
    s.addi       s32, s16, #3712
    vf.mul       v8, v17, v27
    vf.add       v12, v16, v8
    v.st.w       [s43, #0], v12
    v.extract    s43, v11, #10
    v.splat      v8, s43
    s.addi       s43, s52, #640
    v.ld.w       v12, [s28, #0]
    s.addi       s28, s16, #29376
    v.ld.w       v16, [s47, #0]
    vf.mul       v17, v12, v9
    s.addi       s47, s16, #3776
    vf.mul       v9, v17, v27
    vf.add       v12, v16, v9
    v.st.w       [s38, #0], v12
    v.extract    s38, v11, #11
    v.splat      v9, s38
    s.addi       s38, s52, #704
    v.ld.w       v12, [s48, #0]
    s.addi       s48, s16, #29440
    v.ld.w       v16, [s42, #0]
    vf.mul       v17, v12, v1
    s.addi       s42, s16, #3840
    vf.mul       v1, v17, v27
    vf.add       v12, v16, v1
    v.st.w       [s23, #0], v12
    v.extract    s23, v11, #12
    v.splat      v1, s23
    s.addi       s23, s52, #768
    v.ld.w       v12, [s30, #0]
    s.addi       s30, s16, #29504
    v.ld.w       v16, [s32, #0]
    vf.mul       v17, v12, v8
    s.addi       s32, s16, #3904
    vf.mul       v8, v17, v27
    vf.add       v12, v16, v8
    v.st.w       [s43, #0], v12
    v.extract    s43, v11, #13
    v.splat      v8, s43
    s.addi       s43, s52, #832
    v.ld.w       v12, [s28, #0]
    s.addi       s28, s16, #29568
    v.ld.w       v16, [s47, #0]
    vf.mul       v17, v12, v9
    s.addi       s47, s16, #3968
    vf.mul       v9, v17, v27
    vf.add       v12, v16, v9
    v.st.w       [s38, #0], v12
    v.extract    s38, v11, #14
    v.splat      v9, s38
    s.addi       s38, s52, #896
    s.addi       s57, s52, #960
    v.ld.w       v12, [s48, #0]
    s.addi       s48, s16, #29632
    v.ld.w       v16, [s42, #0]
    vf.mul       v17, v12, v1
    s.addi       s42, s16, #4032
    vf.mul       v1, v17, v27
    vf.add       v12, v16, v1
    v.st.w       [s23, #0], v12
    v.extract    s23, v11, #15
    v.splat      v1, s23
    s.addi       s23, s16, #29696
    v.ld.w       v11, [s30, #0]
    s.addi       s30, s16, #4096
    v.ld.w       v12, [s32, #0]
    vf.mul       v16, v11, v8
    v.extract    s32, v14, #0
    v.splat      v8, s32
    s.movz       s32, #46080
    vf.mul       v11, v16, v27
    s.add        s52, s16, s32
    vf.add       v16, v12, v11
    v.st.w       [s43, #0], v16
    s.addi       s32, s16, #29760
    v.ld.w       v11, [s28, #0]
    s.addi       s28, s16, #4160
    v.ld.w       v12, [s47, #0]
    vf.mul       v16, v11, v9
    v.extract    s43, v14, #1
    v.splat      v9, s43
    s.addi       s43, s52, #64
    vf.mul       v11, v16, v27
    vf.add       v16, v12, v11
    v.st.w       [s38, #0], v16
    s.addi       s38, s16, #29824
    v.ld.w       v11, [s48, #0]
    s.addi       s47, s16, #4224
    v.ld.w       v12, [s42, #0]
    vf.mul       v16, v11, v1
    v.extract    s42, v14, #2
    v.splat      v1, s42
    s.addi       s42, s52, #128
    vf.mul       v11, v16, v27
    vf.add       v16, v12, v11
    v.st.w       [s57, #0], v16
    fence.acq_rel.device
    s.addi       s48, s16, #29888
    v.ld.w       v11, [s23, #0]
    s.addi       s23, s16, #4288
    v.ld.w       v12, [s30, #0]
    vf.mul       v16, v11, v8
    v.extract    s30, v14, #3
    v.splat      v8, s30
    s.addi       s30, s52, #192
    vf.mul       v11, v16, v23
    vf.add       v16, v12, v11
    v.st.w       [s52, #0], v16
    v.ld.w       v11, [s32, #0]
    s.addi       s32, s16, #29952
    v.ld.w       v12, [s28, #0]
    vf.mul       v16, v11, v9
    s.addi       s28, s16, #4352
    vf.mul       v9, v16, v23
    vf.add       v11, v12, v9
    v.st.w       [s43, #0], v11
    v.extract    s43, v14, #4
    v.splat      v9, s43
    s.addi       s43, s52, #256
    v.ld.w       v11, [s38, #0]
    s.addi       s38, s16, #30016
    v.ld.w       v12, [s47, #0]
    vf.mul       v16, v11, v1
    s.addi       s47, s16, #4416
    vf.mul       v1, v16, v23
    vf.add       v11, v12, v1
    v.st.w       [s42, #0], v11
    v.extract    s42, v14, #5
    v.splat      v1, s42
    s.addi       s42, s52, #320
    v.ld.w       v11, [s48, #0]
    s.addi       s48, s16, #30080
    v.ld.w       v12, [s23, #0]
    vf.mul       v16, v11, v8
    s.addi       s23, s16, #4480
    vf.mul       v8, v16, v23
    vf.add       v11, v12, v8
    v.st.w       [s30, #0], v11
    v.extract    s30, v14, #6
    v.splat      v8, s30
    s.addi       s30, s52, #384
    v.ld.w       v11, [s32, #0]
    s.addi       s32, s16, #30144
    v.ld.w       v12, [s28, #0]
    vf.mul       v16, v11, v9
    s.addi       s28, s16, #4544
    vf.mul       v9, v16, v23
    vf.add       v11, v12, v9
    v.st.w       [s43, #0], v11
    v.extract    s43, v14, #7
    v.splat      v9, s43
    s.addi       s43, s52, #448
    v.ld.w       v11, [s38, #0]
    s.addi       s38, s16, #30208
    v.ld.w       v12, [s47, #0]
    vf.mul       v16, v11, v1
    s.addi       s47, s16, #4608
    vf.mul       v1, v16, v23
    vf.add       v11, v12, v1
    v.st.w       [s42, #0], v11
    v.extract    s42, v14, #8
    v.splat      v1, s42
    s.addi       s42, s52, #512
    v.ld.w       v11, [s48, #0]
    s.addi       s48, s16, #30272
    v.ld.w       v12, [s23, #0]
    vf.mul       v16, v11, v8
    s.addi       s23, s16, #4672
    vf.mul       v8, v16, v23
    vf.add       v11, v12, v8
    v.st.w       [s30, #0], v11
    v.extract    s30, v14, #9
    v.splat      v8, s30
    s.addi       s30, s52, #576
    v.ld.w       v11, [s32, #0]
    s.addi       s32, s16, #30336
    v.ld.w       v12, [s28, #0]
    vf.mul       v16, v11, v9
    s.addi       s28, s16, #4736
    vf.mul       v9, v16, v23
    vf.add       v11, v12, v9
    v.st.w       [s43, #0], v11
    v.extract    s43, v14, #10
    v.splat      v9, s43
    s.addi       s43, s52, #640
    v.ld.w       v11, [s38, #0]
    s.addi       s38, s16, #30400
    v.ld.w       v12, [s47, #0]
    vf.mul       v16, v11, v1
    s.addi       s47, s16, #4800
    vf.mul       v1, v16, v23
    vf.add       v11, v12, v1
    v.st.w       [s42, #0], v11
    v.extract    s42, v14, #11
    v.splat      v1, s42
    s.addi       s42, s52, #704
    v.ld.w       v11, [s48, #0]
    s.addi       s48, s16, #30464
    v.ld.w       v12, [s23, #0]
    vf.mul       v16, v11, v8
    s.addi       s23, s16, #4864
    vf.mul       v8, v16, v23
    vf.add       v11, v12, v8
    v.st.w       [s30, #0], v11
    v.extract    s30, v14, #12
    v.splat      v8, s30
    s.addi       s30, s52, #768
    v.ld.w       v11, [s32, #0]
    s.addi       s32, s16, #30528
    v.ld.w       v12, [s28, #0]
    vf.mul       v16, v11, v9
    s.addi       s28, s16, #4928
    vf.mul       v9, v16, v23
    vf.add       v11, v12, v9
    v.st.w       [s43, #0], v11
    v.extract    s43, v14, #13
    v.splat      v9, s43
    s.addi       s43, s52, #832
    v.ld.w       v11, [s38, #0]
    s.addi       s38, s16, #30592
    v.ld.w       v12, [s47, #0]
    vf.mul       v16, v11, v1
    s.addi       s47, s16, #4992
    vf.mul       v1, v16, v23
    vf.add       v11, v12, v1
    v.st.w       [s42, #0], v11
    v.extract    s42, v14, #14
    v.splat      v1, s42
    s.addi       s42, s52, #896
    s.addi       s57, s52, #960
    v.ld.w       v11, [s48, #0]
    s.addi       s48, s16, #30656
    v.ld.w       v12, [s23, #0]
    vf.mul       v16, v11, v8
    s.addi       s23, s16, #5056
    vf.mul       v8, v16, v23
    vf.add       v11, v12, v8
    v.st.w       [s30, #0], v11
    v.extract    s30, v14, #15
    v.splat      v8, s30
    s.addi       s30, s16, #30720
    v.ld.w       v11, [s32, #0]
    s.addi       s32, s16, #5120
    v.ld.w       v12, [s28, #0]
    vf.mul       v16, v11, v9
    v.extract    s28, v14, #0
    v.splat      v9, s28
    s.movz       s28, #47104
    vf.mul       v11, v16, v23
    s.add        s52, s16, s28
    vf.add       v16, v12, v11
    v.st.w       [s43, #0], v16
    s.addi       s28, s16, #30784
    v.ld.w       v11, [s38, #0]
    s.addi       s38, s16, #5184
    v.ld.w       v12, [s47, #0]
    vf.mul       v16, v11, v1
    v.extract    s43, v14, #1
    v.splat      v1, s43
    s.addi       s43, s52, #64
    vf.mul       v11, v16, v23
    vf.add       v16, v12, v11
    v.st.w       [s42, #0], v16
    s.addi       s42, s16, #30848
    v.ld.w       v11, [s48, #0]
    s.addi       s47, s16, #5248
    v.ld.w       v12, [s23, #0]
    vf.mul       v16, v11, v8
    v.extract    s23, v14, #2
    v.splat      v8, s23
    s.addi       s23, s52, #128
    vf.mul       v11, v16, v23
    vf.add       v16, v12, v11
    v.st.w       [s57, #0], v16
    fence.acq_rel.device
    s.addi       s48, s16, #30912
    v.ld.w       v11, [s30, #0]
    s.addi       s30, s16, #5312
    v.ld.w       v12, [s32, #0]
    vf.mul       v16, v11, v9
    v.extract    s32, v14, #3
    v.splat      v9, s32
    s.addi       s32, s52, #192
    vf.mul       v11, v16, v24
    vf.add       v16, v12, v11
    v.st.w       [s52, #0], v16
    v.ld.w       v11, [s28, #0]
    s.addi       s28, s16, #30976
    v.ld.w       v12, [s38, #0]
    vf.mul       v16, v11, v1
    s.addi       s38, s16, #5376
    vf.mul       v1, v16, v24
    vf.add       v11, v12, v1
    v.st.w       [s43, #0], v11
    v.extract    s43, v14, #4
    v.splat      v1, s43
    s.addi       s43, s52, #256
    v.ld.w       v11, [s42, #0]
    s.addi       s42, s16, #31040
    v.ld.w       v12, [s47, #0]
    vf.mul       v16, v11, v8
    s.addi       s47, s16, #5440
    vf.mul       v8, v16, v24
    vf.add       v11, v12, v8
    v.st.w       [s23, #0], v11
    v.extract    s23, v14, #5
    v.splat      v8, s23
    s.addi       s23, s52, #320
    v.ld.w       v11, [s48, #0]
    s.addi       s48, s16, #31104
    v.ld.w       v12, [s30, #0]
    vf.mul       v16, v11, v9
    s.addi       s30, s16, #5504
    vf.mul       v9, v16, v24
    vf.add       v11, v12, v9
    v.st.w       [s32, #0], v11
    v.extract    s32, v14, #6
    v.splat      v9, s32
    s.addi       s32, s52, #384
    v.ld.w       v11, [s28, #0]
    s.addi       s28, s16, #31168
    v.ld.w       v12, [s38, #0]
    vf.mul       v16, v11, v1
    s.addi       s38, s16, #5568
    vf.mul       v1, v16, v24
    vf.add       v11, v12, v1
    v.st.w       [s43, #0], v11
    v.extract    s43, v14, #7
    v.splat      v1, s43
    s.addi       s43, s52, #448
    v.ld.w       v11, [s42, #0]
    s.addi       s42, s16, #31232
    v.ld.w       v12, [s47, #0]
    vf.mul       v16, v11, v8
    s.addi       s47, s16, #5632
    vf.mul       v8, v16, v24
    vf.add       v11, v12, v8
    v.st.w       [s23, #0], v11
    v.extract    s23, v14, #8
    v.splat      v8, s23
    s.addi       s23, s52, #512
    v.ld.w       v11, [s48, #0]
    s.addi       s48, s16, #31296
    v.ld.w       v12, [s30, #0]
    vf.mul       v16, v11, v9
    s.addi       s30, s16, #5696
    vf.mul       v9, v16, v24
    vf.add       v11, v12, v9
    v.st.w       [s32, #0], v11
    v.extract    s32, v14, #9
    v.splat      v9, s32
    s.addi       s32, s52, #576
    v.ld.w       v11, [s28, #0]
    s.addi       s28, s16, #31360
    v.ld.w       v12, [s38, #0]
    vf.mul       v16, v11, v1
    s.addi       s38, s16, #5760
    vf.mul       v1, v16, v24
    vf.add       v11, v12, v1
    v.st.w       [s43, #0], v11
    v.extract    s43, v14, #10
    v.splat      v1, s43
    s.addi       s43, s52, #640
    v.ld.w       v11, [s42, #0]
    s.addi       s42, s16, #31424
    v.ld.w       v12, [s47, #0]
    vf.mul       v16, v11, v8
    s.addi       s47, s16, #5824
    vf.mul       v8, v16, v24
    vf.add       v11, v12, v8
    v.st.w       [s23, #0], v11
    v.extract    s23, v14, #11
    v.splat      v8, s23
    s.addi       s23, s52, #704
    v.ld.w       v11, [s48, #0]
    s.addi       s48, s16, #31488
    v.ld.w       v12, [s30, #0]
    vf.mul       v16, v11, v9
    s.addi       s30, s16, #5888
    vf.mul       v9, v16, v24
    vf.add       v11, v12, v9
    v.st.w       [s32, #0], v11
    v.extract    s32, v14, #12
    v.splat      v9, s32
    s.addi       s32, s52, #768
    v.ld.w       v11, [s28, #0]
    s.addi       s28, s16, #31552
    v.ld.w       v12, [s38, #0]
    vf.mul       v16, v11, v1
    s.addi       s38, s16, #5952
    vf.mul       v1, v16, v24
    vf.add       v11, v12, v1
    v.st.w       [s43, #0], v11
    v.extract    s43, v14, #13
    v.splat      v1, s43
    s.addi       s43, s52, #832
    v.ld.w       v11, [s42, #0]
    s.addi       s42, s16, #31616
    v.ld.w       v12, [s47, #0]
    vf.mul       v16, v11, v8
    s.addi       s47, s16, #6016
    vf.mul       v8, v16, v24
    vf.add       v11, v12, v8
    v.st.w       [s23, #0], v11
    v.extract    s23, v14, #14
    v.splat      v8, s23
    s.addi       s23, s52, #896
    s.addi       s57, s52, #960
    v.ld.w       v11, [s48, #0]
    s.addi       s48, s16, #31680
    v.ld.w       v12, [s30, #0]
    vf.mul       v16, v11, v9
    s.addi       s30, s16, #6080
    vf.mul       v9, v16, v24
    vf.add       v11, v12, v9
    v.st.w       [s32, #0], v11
    v.extract    s32, v14, #15
    v.splat      v9, s32
    s.addi       s32, s16, #31744
    v.ld.w       v11, [s28, #0]
    s.addi       s28, s16, #6144
    v.ld.w       v12, [s38, #0]
    vf.mul       v16, v11, v1
    v.extract    s38, v14, #0
    v.splat      v1, s38
    s.movz       s38, #48128
    vf.mul       v11, v16, v24
    s.add        s52, s16, s38
    vf.add       v16, v12, v11
    v.st.w       [s43, #0], v16
    s.addi       s38, s16, #31808
    v.ld.w       v11, [s42, #0]
    s.addi       s42, s16, #6208
    v.ld.w       v12, [s47, #0]
    vf.mul       v16, v11, v8
    v.extract    s43, v14, #1
    v.splat      v8, s43
    s.addi       s43, s52, #64
    vf.mul       v11, v16, v24
    vf.add       v16, v12, v11
    v.st.w       [s23, #0], v16
    s.addi       s23, s16, #31872
    v.ld.w       v11, [s48, #0]
    s.addi       s47, s16, #6272
    v.ld.w       v12, [s30, #0]
    vf.mul       v16, v11, v9
    v.extract    s30, v14, #2
    v.splat      v9, s30
    s.addi       s30, s52, #128
    vf.mul       v11, v16, v24
    vf.add       v16, v12, v11
    v.st.w       [s57, #0], v16
    fence.acq_rel.device
    s.addi       s48, s16, #31936
    v.ld.w       v11, [s32, #0]
    s.addi       s32, s16, #6336
    v.ld.w       v12, [s28, #0]
    vf.mul       v16, v11, v1
    v.extract    s28, v14, #3
    v.splat      v1, s28
    s.addi       s28, s52, #192
    vf.mul       v11, v16, v25
    vf.add       v16, v12, v11
    v.st.w       [s52, #0], v16
    v.ld.w       v11, [s38, #0]
    s.addi       s38, s16, #32000
    v.ld.w       v12, [s42, #0]
    vf.mul       v16, v11, v8
    s.addi       s42, s16, #6400
    vf.mul       v8, v16, v25
    vf.add       v11, v12, v8
    v.st.w       [s43, #0], v11
    v.extract    s43, v14, #4
    v.splat      v8, s43
    s.addi       s43, s52, #256
    v.ld.w       v11, [s23, #0]
    s.addi       s23, s16, #32064
    v.ld.w       v12, [s47, #0]
    vf.mul       v16, v11, v9
    s.addi       s47, s16, #6464
    vf.mul       v9, v16, v25
    vf.add       v11, v12, v9
    v.st.w       [s30, #0], v11
    v.extract    s30, v14, #5
    v.splat      v9, s30
    s.addi       s30, s52, #320
    v.ld.w       v11, [s48, #0]
    s.addi       s48, s16, #32128
    v.ld.w       v12, [s32, #0]
    vf.mul       v16, v11, v1
    s.addi       s32, s16, #6528
    vf.mul       v1, v16, v25
    vf.add       v11, v12, v1
    v.st.w       [s28, #0], v11
    v.extract    s28, v14, #6
    v.splat      v1, s28
    s.addi       s28, s52, #384
    v.ld.w       v11, [s38, #0]
    s.addi       s38, s16, #32192
    v.ld.w       v12, [s42, #0]
    vf.mul       v16, v11, v8
    s.addi       s42, s16, #6592
    vf.mul       v8, v16, v25
    vf.add       v11, v12, v8
    v.st.w       [s43, #0], v11
    v.extract    s43, v14, #7
    v.splat      v8, s43
    s.addi       s43, s52, #448
    v.ld.w       v11, [s23, #0]
    s.addi       s23, s16, #32256
    v.ld.w       v12, [s47, #0]
    vf.mul       v16, v11, v9
    s.addi       s47, s16, #6656
    vf.mul       v9, v16, v25
    vf.add       v11, v12, v9
    v.st.w       [s30, #0], v11
    v.extract    s30, v14, #8
    v.splat      v9, s30
    s.addi       s30, s52, #512
    v.ld.w       v11, [s48, #0]
    s.addi       s48, s16, #32320
    v.ld.w       v12, [s32, #0]
    vf.mul       v16, v11, v1
    s.addi       s32, s16, #6720
    vf.mul       v1, v16, v25
    vf.add       v11, v12, v1
    v.st.w       [s28, #0], v11
    v.extract    s28, v14, #9
    v.splat      v1, s28
    s.addi       s28, s52, #576
    v.ld.w       v11, [s38, #0]
    s.addi       s38, s16, #32384
    v.ld.w       v12, [s42, #0]
    vf.mul       v16, v11, v8
    s.addi       s42, s16, #6784
    vf.mul       v8, v16, v25
    vf.add       v11, v12, v8
    v.st.w       [s43, #0], v11
    v.extract    s43, v14, #10
    v.splat      v8, s43
    s.addi       s43, s52, #640
    v.ld.w       v11, [s23, #0]
    s.addi       s23, s16, #32448
    v.ld.w       v12, [s47, #0]
    vf.mul       v16, v11, v9
    s.addi       s47, s16, #6848
    vf.mul       v9, v16, v25
    vf.add       v11, v12, v9
    v.st.w       [s30, #0], v11
    v.extract    s30, v14, #11
    v.splat      v9, s30
    s.addi       s30, s52, #704
    v.ld.w       v11, [s48, #0]
    s.addi       s48, s16, #32512
    v.ld.w       v12, [s32, #0]
    vf.mul       v16, v11, v1
    s.addi       s32, s16, #6912
    vf.mul       v1, v16, v25
    vf.add       v11, v12, v1
    v.st.w       [s28, #0], v11
    v.extract    s28, v14, #12
    v.splat      v1, s28
    s.addi       s28, s52, #768
    v.ld.w       v11, [s38, #0]
    s.addi       s38, s16, #32576
    v.ld.w       v12, [s42, #0]
    vf.mul       v16, v11, v8
    s.addi       s42, s16, #6976
    vf.mul       v8, v16, v25
    vf.add       v11, v12, v8
    v.st.w       [s43, #0], v11
    v.extract    s43, v14, #13
    v.splat      v8, s43
    s.addi       s43, s52, #832
    v.ld.w       v11, [s23, #0]
    s.addi       s23, s16, #32640
    v.ld.w       v12, [s47, #0]
    vf.mul       v16, v11, v9
    s.addi       s47, s16, #7040
    vf.mul       v9, v16, v25
    vf.add       v11, v12, v9
    v.st.w       [s30, #0], v11
    v.extract    s30, v14, #14
    v.splat      v9, s30
    s.addi       s30, s52, #896
    s.addi       s57, s52, #960
    v.ld.w       v11, [s48, #0]
    s.addi       s48, s16, #32704
    v.ld.w       v12, [s32, #0]
    vf.mul       v16, v11, v1
    s.addi       s32, s16, #7104
    vf.mul       v1, v16, v25
    vf.add       v11, v12, v1
    v.st.w       [s28, #0], v11
    v.extract    s28, v14, #15
    v.splat      v1, s28
    s.movz       s28, #32768
    s.add        s52, s16, s28
    v.ld.w       v11, [s38, #0]
    s.addi       s28, s16, #7168
    v.ld.w       v12, [s42, #0]
    vf.mul       v16, v11, v8
    v.extract    s38, v14, #0
    v.splat      v8, s38
    s.movz       s38, #49152
    vf.mul       v11, v16, v25
    s.add        s42, s16, s38
    vf.add       v16, v12, v11
    v.st.w       [s43, #0], v16
    s.movz       s38, #32832
    s.add        s43, s16, s38
    v.ld.w       v11, [s23, #0]
    s.addi       s23, s16, #7232
    v.ld.w       v12, [s47, #0]
    vf.mul       v16, v11, v9
    v.extract    s38, v14, #1
    v.splat      v9, s38
    s.movz       s38, #32896
    vf.mul       v11, v16, v25
    s.add        s47, s16, s38
    vf.add       v16, v12, v11
    v.st.w       [s30, #0], v16
    s.addi       s30, s42, #64
    v.ld.w       v11, [s48, #0]
    s.addi       s38, s16, #7296
    v.ld.w       v12, [s32, #0]
    vf.mul       v16, v11, v1
    v.extract    s32, v14, #2
    v.splat      v1, s32
    s.movz       s32, #32960
    vf.mul       v11, v16, v25
    s.add        s48, s16, s32
    vf.add       v16, v12, v11
    v.st.w       [s57, #0], v16
    fence.acq_rel.device
    s.addi       s32, s42, #128
    v.ld.w       v11, [s52, #0]
    s.addi       s52, s16, #7360
    v.ld.w       v12, [s28, #0]
    vf.mul       v16, v11, v8
    v.extract    s28, v14, #3
    v.splat      v8, s28
    s.movz       s28, #33024
    vf.mul       v11, v16, v27
    s.add        s57, s16, s28
    vf.add       v16, v12, v11
    v.st.w       [s42, #0], v16
    v.ld.w       v11, [s43, #0]
    s.addi       s28, s42, #192
    v.ld.w       v12, [s23, #0]
    vf.mul       v16, v11, v9
    s.addi       s23, s16, #7424
    vf.mul       v9, v16, v27
    vf.add       v11, v12, v9
    v.st.w       [s30, #0], v11
    v.extract    s30, v14, #4
    v.splat      v9, s30
    s.movz       s30, #33088
    s.add        s43, s16, s30
    v.ld.w       v11, [s47, #0]
    s.addi       s30, s42, #256
    v.ld.w       v12, [s38, #0]
    vf.mul       v16, v11, v1
    s.addi       s38, s16, #7488
    vf.mul       v1, v16, v27
    vf.add       v11, v12, v1
    v.st.w       [s32, #0], v11
    v.extract    s32, v14, #5
    v.splat      v1, s32
    s.movz       s32, #33152
    s.add        s47, s16, s32
    v.ld.w       v11, [s48, #0]
    s.addi       s32, s42, #320
    v.ld.w       v12, [s52, #0]
    vf.mul       v16, v11, v8
    s.addi       s48, s16, #7552
    vf.mul       v8, v16, v27
    vf.add       v11, v12, v8
    v.st.w       [s28, #0], v11
    v.extract    s28, v14, #6
    v.splat      v8, s28
    s.movz       s28, #33216
    s.add        s52, s16, s28
    v.ld.w       v11, [s57, #0]
    s.addi       s28, s42, #384
    v.ld.w       v12, [s23, #0]
    vf.mul       v16, v11, v9
    s.addi       s23, s16, #7616
    vf.mul       v9, v16, v27
    vf.add       v11, v12, v9
    v.st.w       [s30, #0], v11
    v.extract    s30, v14, #7
    v.splat      v9, s30
    s.movz       s30, #33280
    s.add        s57, s16, s30
    v.ld.w       v11, [s43, #0]
    s.addi       s30, s42, #448
    v.ld.w       v12, [s38, #0]
    vf.mul       v16, v11, v1
    s.addi       s38, s16, #7680
    vf.mul       v1, v16, v27
    vf.add       v11, v12, v1
    v.st.w       [s32, #0], v11
    v.extract    s32, v14, #8
    v.splat      v1, s32
    s.movz       s32, #33344
    s.add        s43, s16, s32
    v.ld.w       v11, [s47, #0]
    s.addi       s32, s42, #512
    v.ld.w       v12, [s48, #0]
    vf.mul       v16, v11, v8
    s.addi       s47, s16, #7744
    vf.mul       v8, v16, v27
    vf.add       v11, v12, v8
    v.st.w       [s28, #0], v11
    v.extract    s28, v14, #9
    v.splat      v8, s28
    s.movz       s28, #33408
    s.add        s48, s16, s28
    v.ld.w       v11, [s52, #0]
    s.addi       s28, s42, #576
    v.ld.w       v12, [s23, #0]
    vf.mul       v16, v11, v9
    s.addi       s23, s16, #7808
    vf.mul       v9, v16, v27
    vf.add       v11, v12, v9
    v.st.w       [s30, #0], v11
    v.extract    s30, v14, #10
    v.splat      v9, s30
    s.movz       s30, #33472
    s.add        s52, s16, s30
    v.ld.w       v11, [s57, #0]
    s.addi       s30, s42, #640
    v.ld.w       v12, [s38, #0]
    vf.mul       v16, v11, v1
    s.addi       s38, s16, #7872
    vf.mul       v1, v16, v27
    vf.add       v11, v12, v1
    v.st.w       [s32, #0], v11
    v.extract    s32, v14, #11
    v.splat      v1, s32
    s.movz       s32, #33536
    s.add        s57, s16, s32
    v.ld.w       v11, [s43, #0]
    s.addi       s32, s42, #704
    v.ld.w       v12, [s47, #0]
    vf.mul       v16, v11, v8
    s.addi       s43, s16, #7936
    vf.mul       v8, v16, v27
    vf.add       v11, v12, v8
    v.st.w       [s28, #0], v11
    v.extract    s28, v14, #12
    v.splat      v8, s28
    s.movz       s28, #33600
    s.add        s47, s16, s28
    v.ld.w       v11, [s48, #0]
    s.addi       s28, s42, #768
    v.ld.w       v12, [s23, #0]
    vf.mul       v16, v11, v9
    s.addi       s23, s16, #8000
    vf.mul       v9, v16, v27
    vf.add       v11, v12, v9
    v.st.w       [s30, #0], v11
    v.extract    s30, v14, #13
    v.splat      v9, s30
    s.movz       s30, #33664
    s.add        s48, s16, s30
    v.ld.w       v11, [s52, #0]
    s.addi       s30, s42, #832
    v.ld.w       v12, [s38, #0]
    vf.mul       v16, v11, v1
    s.addi       s38, s16, #8064
    vf.mul       v1, v16, v27
    vf.add       v11, v12, v1
    v.st.w       [s32, #0], v11
    v.extract    s32, v14, #14
    v.splat      v1, s32
    s.movz       s32, #33728
    s.add        s52, s16, s32
    v.ld.w       v11, [s57, #0]
    s.addi       s32, s42, #896
    s.addi       s57, s42, #960
    v.ld.w       v12, [s43, #0]
    vf.mul       v16, v11, v8
    s.addi       s42, s16, #8128
    vf.mul       v8, v16, v27
    vf.add       v11, v12, v8
    v.st.w       [s28, #0], v11
    v.extract    s28, v14, #15
    v.splat      v8, s28
    s.movz       s28, #33792
    s.add        s43, s16, s28
    v.ld.w       v11, [s47, #0]
    s.addi       s28, s16, #8192
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v9
    v.extract    s23, v22, #0
    v.splat      v9, s23
    s.movz       s23, #50176
    vf.mul       v11, v14, v27
    s.add        s47, s16, s23
    vf.add       v14, v12, v11
    v.st.w       [s30, #0], v14
    s.movz       s23, #33856
    s.add        s30, s16, s23
    v.ld.w       v11, [s48, #0]
    s.addi       s23, s16, #8256
    v.ld.w       v12, [s38, #0]
    vf.mul       v14, v11, v1
    v.extract    s38, v22, #1
    v.splat      v1, s38
    s.movz       s38, #33920
    vf.mul       v11, v14, v27
    s.add        s48, s16, s38
    vf.add       v14, v12, v11
    v.st.w       [s32, #0], v14
    s.addi       s32, s47, #64
    v.ld.w       v11, [s52, #0]
    s.addi       s38, s16, #8320
    v.ld.w       v12, [s42, #0]
    vf.mul       v14, v11, v8
    v.extract    s42, v22, #2
    v.splat      v8, s42
    s.movz       s42, #33984
    vf.mul       v11, v14, v27
    s.add        s52, s16, s42
    vf.add       v14, v12, v11
    v.st.w       [s57, #0], v14
    fence.acq_rel.device
    s.addi       s42, s47, #128
    v.ld.w       v11, [s43, #0]
    s.addi       s43, s16, #8384
    v.ld.w       v12, [s28, #0]
    vf.mul       v14, v11, v9
    v.extract    s28, v22, #3
    v.splat      v9, s28
    s.movz       s28, #34048
    vf.mul       v11, v14, v23
    s.add        s57, s16, s28
    vf.add       v14, v12, v11
    v.st.w       [s47, #0], v14
    v.ld.w       v11, [s30, #0]
    s.addi       s28, s47, #192
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v1
    s.addi       s23, s16, #8448
    vf.mul       v1, v14, v23
    vf.add       v11, v12, v1
    v.st.w       [s32, #0], v11
    v.extract    s30, v22, #4
    v.splat      v1, s30
    s.movz       s30, #34112
    s.add        s32, s16, s30
    v.ld.w       v11, [s48, #0]
    s.addi       s30, s47, #256
    v.ld.w       v12, [s38, #0]
    vf.mul       v14, v11, v8
    s.addi       s38, s16, #8512
    vf.mul       v8, v14, v23
    vf.add       v11, v12, v8
    v.st.w       [s42, #0], v11
    v.extract    s42, v22, #5
    v.splat      v8, s42
    s.movz       s42, #34176
    s.add        s48, s16, s42
    v.ld.w       v11, [s52, #0]
    s.addi       s42, s47, #320
    v.ld.w       v12, [s43, #0]
    vf.mul       v14, v11, v9
    s.addi       s43, s16, #8576
    vf.mul       v9, v14, v23
    vf.add       v11, v12, v9
    v.st.w       [s28, #0], v11
    v.extract    s28, v22, #6
    v.splat      v9, s28
    s.movz       s28, #34240
    s.add        s52, s16, s28
    v.ld.w       v11, [s57, #0]
    s.addi       s28, s47, #384
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v1
    s.addi       s23, s16, #8640
    vf.mul       v1, v14, v23
    vf.add       v11, v12, v1
    v.st.w       [s30, #0], v11
    v.extract    s30, v22, #7
    v.splat      v1, s30
    s.movz       s30, #34304
    s.add        s57, s16, s30
    v.ld.w       v11, [s32, #0]
    s.addi       s30, s47, #448
    v.ld.w       v12, [s38, #0]
    vf.mul       v14, v11, v8
    s.addi       s32, s16, #8704
    vf.mul       v8, v14, v23
    vf.add       v11, v12, v8
    v.st.w       [s42, #0], v11
    v.extract    s38, v22, #8
    v.splat      v8, s38
    s.movz       s38, #34368
    s.add        s42, s16, s38
    v.ld.w       v11, [s48, #0]
    s.addi       s38, s47, #512
    v.ld.w       v12, [s43, #0]
    vf.mul       v14, v11, v9
    s.addi       s43, s16, #8768
    vf.mul       v9, v14, v23
    vf.add       v11, v12, v9
    v.st.w       [s28, #0], v11
    v.extract    s28, v22, #9
    v.splat      v9, s28
    s.movz       s28, #34432
    s.add        s48, s16, s28
    v.ld.w       v11, [s52, #0]
    s.addi       s28, s47, #576
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v1
    s.addi       s23, s16, #8832
    vf.mul       v1, v14, v23
    vf.add       v11, v12, v1
    v.st.w       [s30, #0], v11
    v.extract    s30, v22, #10
    v.splat      v1, s30
    s.movz       s30, #34496
    s.add        s52, s16, s30
    v.ld.w       v11, [s57, #0]
    s.addi       s30, s47, #640
    v.ld.w       v12, [s32, #0]
    vf.mul       v14, v11, v8
    s.addi       s32, s16, #8896
    vf.mul       v8, v14, v23
    vf.add       v11, v12, v8
    v.st.w       [s38, #0], v11
    v.extract    s38, v22, #11
    v.splat      v8, s38
    s.movz       s38, #34560
    s.add        s57, s16, s38
    v.ld.w       v11, [s42, #0]
    s.addi       s38, s47, #704
    v.ld.w       v12, [s43, #0]
    vf.mul       v14, v11, v9
    s.addi       s42, s16, #8960
    vf.mul       v9, v14, v23
    vf.add       v11, v12, v9
    v.st.w       [s28, #0], v11
    v.extract    s28, v22, #12
    v.splat      v9, s28
    s.movz       s28, #34624
    s.add        s43, s16, s28
    v.ld.w       v11, [s48, #0]
    s.addi       s28, s47, #768
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v1
    s.addi       s23, s16, #9024
    vf.mul       v1, v14, v23
    vf.add       v11, v12, v1
    v.st.w       [s30, #0], v11
    v.extract    s30, v22, #13
    v.splat      v1, s30
    s.movz       s30, #34688
    s.add        s48, s16, s30
    v.ld.w       v11, [s52, #0]
    s.addi       s30, s47, #832
    v.ld.w       v12, [s32, #0]
    vf.mul       v14, v11, v8
    s.addi       s32, s16, #9088
    vf.mul       v8, v14, v23
    vf.add       v11, v12, v8
    v.st.w       [s38, #0], v11
    v.extract    s38, v22, #14
    v.splat      v8, s38
    s.movz       s38, #34752
    s.add        s52, s16, s38
    v.ld.w       v11, [s57, #0]
    s.addi       s38, s47, #896
    s.addi       s57, s47, #960
    v.ld.w       v12, [s42, #0]
    vf.mul       v14, v11, v9
    s.addi       s42, s16, #9152
    vf.mul       v9, v14, v23
    vf.add       v11, v12, v9
    v.st.w       [s28, #0], v11
    v.extract    s28, v22, #15
    v.splat      v9, s28
    s.movz       s28, #34816
    s.add        s47, s16, s28
    v.ld.w       v11, [s43, #0]
    s.addi       s28, s16, #9216
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v1
    v.extract    s23, v22, #0
    v.splat      v1, s23
    s.movz       s23, #51200
    vf.mul       v11, v14, v23
    s.add        s43, s16, s23
    vf.add       v14, v12, v11
    v.st.w       [s30, #0], v14
    s.movz       s23, #34880
    s.add        s30, s16, s23
    v.ld.w       v11, [s48, #0]
    s.addi       s23, s16, #9280
    v.ld.w       v12, [s32, #0]
    vf.mul       v14, v11, v8
    v.extract    s32, v22, #1
    v.splat      v8, s32
    s.movz       s32, #34944
    vf.mul       v11, v14, v23
    s.add        s48, s16, s32
    vf.add       v14, v12, v11
    v.st.w       [s38, #0], v14
    s.addi       s32, s43, #64
    v.ld.w       v11, [s52, #0]
    s.addi       s38, s16, #9344
    v.ld.w       v12, [s42, #0]
    vf.mul       v14, v11, v9
    v.extract    s42, v22, #2
    v.splat      v9, s42
    s.movz       s42, #35008
    vf.mul       v11, v14, v23
    s.add        s52, s16, s42
    vf.add       v14, v12, v11
    v.st.w       [s57, #0], v14
    fence.acq_rel.device
    s.addi       s42, s43, #128
    v.ld.w       v11, [s47, #0]
    s.addi       s47, s16, #9408
    v.ld.w       v12, [s28, #0]
    vf.mul       v14, v11, v1
    v.extract    s28, v22, #3
    v.splat      v1, s28
    s.movz       s28, #35072
    vf.mul       v11, v14, v24
    s.add        s57, s16, s28
    vf.add       v14, v12, v11
    v.st.w       [s43, #0], v14
    v.ld.w       v11, [s30, #0]
    s.addi       s28, s43, #192
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v8
    s.addi       s23, s16, #9472
    vf.mul       v8, v14, v24
    vf.add       v11, v12, v8
    v.st.w       [s32, #0], v11
    v.extract    s30, v22, #4
    v.splat      v8, s30
    s.movz       s30, #35136
    s.add        s32, s16, s30
    v.ld.w       v11, [s48, #0]
    s.addi       s30, s43, #256
    v.ld.w       v12, [s38, #0]
    vf.mul       v14, v11, v9
    s.addi       s38, s16, #9536
    vf.mul       v9, v14, v24
    vf.add       v11, v12, v9
    v.st.w       [s42, #0], v11
    v.extract    s42, v22, #5
    v.splat      v9, s42
    s.movz       s42, #35200
    s.add        s48, s16, s42
    v.ld.w       v11, [s52, #0]
    s.addi       s42, s43, #320
    v.ld.w       v12, [s47, #0]
    vf.mul       v14, v11, v1
    s.addi       s47, s16, #9600
    vf.mul       v1, v14, v24
    vf.add       v11, v12, v1
    v.st.w       [s28, #0], v11
    v.extract    s28, v22, #6
    v.splat      v1, s28
    s.movz       s28, #35264
    s.add        s52, s16, s28
    v.ld.w       v11, [s57, #0]
    s.addi       s28, s43, #384
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v8
    s.addi       s23, s16, #9664
    vf.mul       v8, v14, v24
    vf.add       v11, v12, v8
    v.st.w       [s30, #0], v11
    v.extract    s30, v22, #7
    v.splat      v8, s30
    s.movz       s30, #35328
    s.add        s57, s16, s30
    v.ld.w       v11, [s32, #0]
    s.addi       s30, s43, #448
    v.ld.w       v12, [s38, #0]
    vf.mul       v14, v11, v9
    s.addi       s32, s16, #9728
    vf.mul       v9, v14, v24
    vf.add       v11, v12, v9
    v.st.w       [s42, #0], v11
    v.extract    s38, v22, #8
    v.splat      v9, s38
    s.movz       s38, #35392
    s.add        s42, s16, s38
    v.ld.w       v11, [s48, #0]
    s.addi       s38, s43, #512
    v.ld.w       v12, [s47, #0]
    vf.mul       v14, v11, v1
    s.addi       s47, s16, #9792
    vf.mul       v1, v14, v24
    vf.add       v11, v12, v1
    v.st.w       [s28, #0], v11
    v.extract    s28, v22, #9
    v.splat      v1, s28
    s.movz       s28, #35456
    s.add        s48, s16, s28
    v.ld.w       v11, [s52, #0]
    s.addi       s28, s43, #576
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v8
    s.addi       s23, s16, #9856
    vf.mul       v8, v14, v24
    vf.add       v11, v12, v8
    v.st.w       [s30, #0], v11
    v.extract    s30, v22, #10
    v.splat      v8, s30
    s.movz       s30, #35520
    s.add        s52, s16, s30
    v.ld.w       v11, [s57, #0]
    s.addi       s30, s43, #640
    v.ld.w       v12, [s32, #0]
    vf.mul       v14, v11, v9
    s.addi       s32, s16, #9920
    vf.mul       v9, v14, v24
    vf.add       v11, v12, v9
    v.st.w       [s38, #0], v11
    v.extract    s38, v22, #11
    v.splat      v9, s38
    s.movz       s38, #35584
    s.add        s57, s16, s38
    v.ld.w       v11, [s42, #0]
    s.addi       s38, s43, #704
    v.ld.w       v12, [s47, #0]
    vf.mul       v14, v11, v1
    s.addi       s42, s16, #9984
    vf.mul       v1, v14, v24
    vf.add       v11, v12, v1
    v.st.w       [s28, #0], v11
    v.extract    s28, v22, #12
    v.splat      v1, s28
    s.movz       s28, #35648
    s.add        s47, s16, s28
    v.ld.w       v11, [s48, #0]
    s.addi       s28, s43, #768
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v8
    s.addi       s23, s16, #10048
    vf.mul       v8, v14, v24
    vf.add       v11, v12, v8
    v.st.w       [s30, #0], v11
    v.extract    s30, v22, #13
    v.splat      v8, s30
    s.movz       s30, #35712
    s.add        s48, s16, s30
    v.ld.w       v11, [s52, #0]
    s.addi       s30, s43, #832
    v.ld.w       v12, [s32, #0]
    vf.mul       v14, v11, v9
    s.addi       s32, s16, #10112
    vf.mul       v9, v14, v24
    vf.add       v11, v12, v9
    v.st.w       [s38, #0], v11
    v.extract    s38, v22, #14
    v.splat      v9, s38
    s.movz       s38, #35776
    s.add        s52, s16, s38
    v.ld.w       v11, [s57, #0]
    s.addi       s38, s43, #896
    s.addi       s57, s43, #960
    v.ld.w       v12, [s42, #0]
    vf.mul       v14, v11, v1
    s.addi       s42, s16, #10176
    vf.mul       v1, v14, v24
    vf.add       v11, v12, v1
    v.st.w       [s28, #0], v11
    v.extract    s28, v22, #15
    v.splat      v1, s28
    s.movz       s28, #35840
    s.add        s43, s16, s28
    v.ld.w       v11, [s47, #0]
    s.addi       s28, s16, #10240
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v8
    v.extract    s23, v22, #0
    v.splat      v8, s23
    s.movz       s23, #52224
    vf.mul       v11, v14, v24
    s.add        s47, s16, s23
    vf.add       v14, v12, v11
    v.st.w       [s30, #0], v14
    s.movz       s23, #35904
    s.add        s30, s16, s23
    v.ld.w       v11, [s48, #0]
    s.addi       s23, s16, #10304
    v.ld.w       v12, [s32, #0]
    vf.mul       v14, v11, v9
    v.extract    s32, v22, #1
    v.splat      v9, s32
    s.movz       s32, #35968
    vf.mul       v11, v14, v24
    s.add        s48, s16, s32
    vf.add       v14, v12, v11
    v.st.w       [s38, #0], v14
    s.addi       s32, s47, #64
    v.ld.w       v11, [s52, #0]
    s.addi       s38, s16, #10368
    v.ld.w       v12, [s42, #0]
    vf.mul       v14, v11, v1
    v.extract    s42, v22, #2
    v.splat      v1, s42
    s.movz       s42, #36032
    vf.mul       v11, v14, v24
    s.add        s52, s16, s42
    vf.add       v14, v12, v11
    v.st.w       [s57, #0], v14
    fence.acq_rel.device
    s.addi       s42, s47, #128
    v.ld.w       v11, [s43, #0]
    s.addi       s43, s16, #10432
    v.ld.w       v12, [s28, #0]
    vf.mul       v14, v11, v8
    v.extract    s28, v22, #3
    v.splat      v8, s28
    s.movz       s28, #36096
    vf.mul       v11, v14, v25
    s.add        s57, s16, s28
    vf.add       v14, v12, v11
    v.st.w       [s47, #0], v14
    v.ld.w       v11, [s30, #0]
    s.addi       s28, s47, #192
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v9
    s.addi       s23, s16, #10496
    vf.mul       v9, v14, v25
    vf.add       v11, v12, v9
    v.st.w       [s32, #0], v11
    v.extract    s30, v22, #4
    v.splat      v9, s30
    s.movz       s30, #36160
    s.add        s32, s16, s30
    v.ld.w       v11, [s48, #0]
    s.addi       s30, s47, #256
    v.ld.w       v12, [s38, #0]
    vf.mul       v14, v11, v1
    s.addi       s38, s16, #10560
    vf.mul       v1, v14, v25
    vf.add       v11, v12, v1
    v.st.w       [s42, #0], v11
    v.extract    s42, v22, #5
    v.splat      v1, s42
    s.movz       s42, #36224
    s.add        s48, s16, s42
    v.ld.w       v11, [s52, #0]
    s.addi       s42, s47, #320
    v.ld.w       v12, [s43, #0]
    vf.mul       v14, v11, v8
    s.addi       s43, s16, #10624
    vf.mul       v8, v14, v25
    vf.add       v11, v12, v8
    v.st.w       [s28, #0], v11
    v.extract    s28, v22, #6
    v.splat      v8, s28
    s.movz       s28, #36288
    s.add        s52, s16, s28
    v.ld.w       v11, [s57, #0]
    s.addi       s28, s47, #384
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v9
    s.addi       s23, s16, #10688
    vf.mul       v9, v14, v25
    vf.add       v11, v12, v9
    v.st.w       [s30, #0], v11
    v.extract    s30, v22, #7
    v.splat      v9, s30
    s.movz       s30, #36352
    s.add        s57, s16, s30
    v.ld.w       v11, [s32, #0]
    s.addi       s30, s47, #448
    v.ld.w       v12, [s38, #0]
    vf.mul       v14, v11, v1
    s.addi       s32, s16, #10752
    vf.mul       v1, v14, v25
    vf.add       v11, v12, v1
    v.st.w       [s42, #0], v11
    v.extract    s38, v22, #8
    v.splat      v1, s38
    s.movz       s38, #36416
    s.add        s42, s16, s38
    v.ld.w       v11, [s48, #0]
    s.addi       s38, s47, #512
    v.ld.w       v12, [s43, #0]
    vf.mul       v14, v11, v8
    s.addi       s43, s16, #10816
    vf.mul       v8, v14, v25
    vf.add       v11, v12, v8
    v.st.w       [s28, #0], v11
    v.extract    s28, v22, #9
    v.splat      v8, s28
    s.movz       s28, #36480
    s.add        s48, s16, s28
    v.ld.w       v11, [s52, #0]
    s.addi       s28, s47, #576
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v9
    s.addi       s23, s16, #10880
    vf.mul       v9, v14, v25
    vf.add       v11, v12, v9
    v.st.w       [s30, #0], v11
    v.extract    s30, v22, #10
    v.splat      v9, s30
    s.movz       s30, #36544
    s.add        s52, s16, s30
    v.ld.w       v11, [s57, #0]
    s.addi       s30, s47, #640
    v.ld.w       v12, [s32, #0]
    vf.mul       v14, v11, v1
    s.addi       s32, s16, #10944
    vf.mul       v1, v14, v25
    vf.add       v11, v12, v1
    v.st.w       [s38, #0], v11
    v.extract    s38, v22, #11
    v.splat      v1, s38
    s.movz       s38, #36608
    s.add        s57, s16, s38
    v.ld.w       v11, [s42, #0]
    s.addi       s38, s47, #704
    v.ld.w       v12, [s43, #0]
    vf.mul       v14, v11, v8
    s.addi       s42, s16, #11008
    vf.mul       v8, v14, v25
    vf.add       v11, v12, v8
    v.st.w       [s28, #0], v11
    v.extract    s28, v22, #12
    v.splat      v8, s28
    s.movz       s28, #36672
    s.add        s43, s16, s28
    v.ld.w       v11, [s48, #0]
    s.addi       s28, s47, #768
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v9
    s.addi       s23, s16, #11072
    vf.mul       v9, v14, v25
    vf.add       v11, v12, v9
    v.st.w       [s30, #0], v11
    v.extract    s30, v22, #13
    v.splat      v9, s30
    s.movz       s30, #36736
    s.add        s48, s16, s30
    v.ld.w       v11, [s52, #0]
    s.addi       s30, s47, #832
    v.ld.w       v12, [s32, #0]
    vf.mul       v14, v11, v1
    s.addi       s32, s16, #11136
    vf.mul       v1, v14, v25
    vf.add       v11, v12, v1
    v.st.w       [s38, #0], v11
    v.extract    s38, v22, #14
    v.splat      v1, s38
    s.movz       s38, #36800
    s.add        s52, s16, s38
    v.ld.w       v11, [s57, #0]
    s.addi       s38, s47, #896
    s.addi       s57, s47, #960
    v.ld.w       v12, [s42, #0]
    vf.mul       v14, v11, v8
    s.addi       s42, s16, #11200
    vf.mul       v8, v14, v25
    vf.add       v11, v12, v8
    v.st.w       [s28, #0], v11
    v.extract    s28, v22, #15
    v.splat      v8, s28
    s.movz       s28, #36864
    s.add        s47, s16, s28
    v.ld.w       v11, [s43, #0]
    s.addi       s28, s16, #11264
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v9
    v.extract    s23, v22, #0
    v.splat      v9, s23
    s.movz       s23, #53248
    vf.mul       v11, v14, v25
    s.add        s43, s16, s23
    vf.add       v14, v12, v11
    v.st.w       [s30, #0], v14
    s.movz       s23, #36928
    s.add        s30, s16, s23
    v.ld.w       v11, [s48, #0]
    s.addi       s23, s16, #11328
    v.ld.w       v12, [s32, #0]
    vf.mul       v14, v11, v1
    v.extract    s32, v22, #1
    v.splat      v1, s32
    s.movz       s32, #36992
    vf.mul       v11, v14, v25
    s.add        s48, s16, s32
    vf.add       v14, v12, v11
    v.st.w       [s38, #0], v14
    s.addi       s32, s43, #64
    v.ld.w       v11, [s52, #0]
    s.addi       s38, s16, #11392
    v.ld.w       v12, [s42, #0]
    vf.mul       v14, v11, v8
    v.extract    s42, v22, #2
    v.splat      v8, s42
    s.movz       s42, #37056
    vf.mul       v11, v14, v25
    s.add        s52, s16, s42
    vf.add       v14, v12, v11
    v.st.w       [s57, #0], v14
    fence.acq_rel.device
    s.addi       s42, s43, #128
    v.ld.w       v11, [s47, #0]
    s.addi       s47, s16, #11456
    v.ld.w       v12, [s28, #0]
    vf.mul       v14, v11, v9
    v.extract    s28, v22, #3
    v.splat      v9, s28
    s.movz       s28, #37120
    vf.mul       v11, v14, v27
    s.add        s57, s16, s28
    vf.add       v14, v12, v11
    v.st.w       [s43, #0], v14
    v.ld.w       v11, [s30, #0]
    s.addi       s28, s43, #192
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v1
    s.addi       s23, s16, #11520
    vf.mul       v1, v14, v27
    vf.add       v11, v12, v1
    v.st.w       [s32, #0], v11
    v.extract    s30, v22, #4
    v.splat      v1, s30
    s.movz       s30, #37184
    s.add        s32, s16, s30
    v.ld.w       v11, [s48, #0]
    s.addi       s30, s43, #256
    v.ld.w       v12, [s38, #0]
    vf.mul       v14, v11, v8
    s.addi       s38, s16, #11584
    vf.mul       v8, v14, v27
    vf.add       v11, v12, v8
    v.st.w       [s42, #0], v11
    v.extract    s42, v22, #5
    v.splat      v8, s42
    s.movz       s42, #37248
    s.add        s48, s16, s42
    v.ld.w       v11, [s52, #0]
    s.addi       s42, s43, #320
    v.ld.w       v12, [s47, #0]
    vf.mul       v14, v11, v9
    s.addi       s47, s16, #11648
    vf.mul       v9, v14, v27
    vf.add       v11, v12, v9
    v.st.w       [s28, #0], v11
    v.extract    s28, v22, #6
    v.splat      v9, s28
    s.movz       s28, #37312
    s.add        s52, s16, s28
    v.ld.w       v11, [s57, #0]
    s.addi       s28, s43, #384
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v1
    s.addi       s23, s16, #11712
    vf.mul       v1, v14, v27
    vf.add       v11, v12, v1
    v.st.w       [s30, #0], v11
    v.extract    s30, v22, #7
    v.splat      v1, s30
    s.movz       s30, #37376
    s.add        s57, s16, s30
    v.ld.w       v11, [s32, #0]
    s.addi       s30, s43, #448
    v.ld.w       v12, [s38, #0]
    vf.mul       v14, v11, v8
    s.addi       s32, s16, #11776
    vf.mul       v8, v14, v27
    vf.add       v11, v12, v8
    v.st.w       [s42, #0], v11
    v.extract    s38, v22, #8
    v.splat      v8, s38
    s.movz       s38, #37440
    s.add        s42, s16, s38
    v.ld.w       v11, [s48, #0]
    s.addi       s38, s43, #512
    v.ld.w       v12, [s47, #0]
    vf.mul       v14, v11, v9
    s.addi       s47, s16, #11840
    vf.mul       v9, v14, v27
    vf.add       v11, v12, v9
    v.st.w       [s28, #0], v11
    v.extract    s28, v22, #9
    v.splat      v9, s28
    s.movz       s28, #37504
    s.add        s48, s16, s28
    v.ld.w       v11, [s52, #0]
    s.addi       s28, s43, #576
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v1
    s.addi       s23, s16, #11904
    vf.mul       v1, v14, v27
    vf.add       v11, v12, v1
    v.st.w       [s30, #0], v11
    v.extract    s30, v22, #10
    v.splat      v1, s30
    s.movz       s30, #37568
    s.add        s52, s16, s30
    v.ld.w       v11, [s57, #0]
    s.addi       s30, s43, #640
    v.ld.w       v12, [s32, #0]
    vf.mul       v14, v11, v8
    s.addi       s32, s16, #11968
    vf.mul       v8, v14, v27
    vf.add       v11, v12, v8
    v.st.w       [s38, #0], v11
    v.extract    s38, v22, #11
    v.splat      v8, s38
    s.movz       s38, #37632
    s.add        s57, s16, s38
    v.ld.w       v11, [s42, #0]
    s.addi       s38, s43, #704
    v.ld.w       v12, [s47, #0]
    vf.mul       v14, v11, v9
    s.addi       s42, s16, #12032
    vf.mul       v9, v14, v27
    vf.add       v11, v12, v9
    v.st.w       [s28, #0], v11
    v.extract    s28, v22, #12
    v.splat      v9, s28
    s.movz       s28, #37696
    s.add        s47, s16, s28
    v.ld.w       v11, [s48, #0]
    s.addi       s28, s43, #768
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v1
    s.addi       s23, s16, #12096
    vf.mul       v1, v14, v27
    vf.add       v11, v12, v1
    v.st.w       [s30, #0], v11
    v.extract    s30, v22, #13
    v.splat      v1, s30
    s.movz       s30, #37760
    s.add        s48, s16, s30
    v.ld.w       v11, [s52, #0]
    s.addi       s30, s43, #832
    v.ld.w       v12, [s32, #0]
    vf.mul       v14, v11, v8
    s.addi       s32, s16, #12160
    vf.mul       v8, v14, v27
    vf.add       v11, v12, v8
    v.st.w       [s38, #0], v11
    v.extract    s38, v22, #14
    v.splat      v8, s38
    s.movz       s38, #37824
    s.add        s52, s16, s38
    v.ld.w       v11, [s57, #0]
    s.addi       s38, s43, #896
    s.addi       s57, s43, #960
    v.ld.w       v12, [s42, #0]
    vf.mul       v14, v11, v9
    s.addi       s42, s16, #12224
    vf.mul       v9, v14, v27
    vf.add       v11, v12, v9
    v.st.w       [s28, #0], v11
    v.extract    s28, v22, #15
    v.splat      v9, s28
    s.movz       s28, #37888
    s.add        s43, s16, s28
    v.ld.w       v11, [s47, #0]
    s.addi       s28, s16, #12288
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v1
    v.extract    s23, v21, #0
    v.splat      v1, s23
    s.movz       s23, #54272
    vf.mul       v11, v14, v27
    s.add        s47, s16, s23
    vf.add       v14, v12, v11
    v.st.w       [s30, #0], v14
    s.movz       s23, #37952
    s.add        s30, s16, s23
    v.ld.w       v11, [s48, #0]
    s.addi       s23, s16, #12352
    v.ld.w       v12, [s32, #0]
    vf.mul       v14, v11, v8
    v.extract    s32, v21, #1
    v.splat      v8, s32
    s.movz       s32, #38016
    vf.mul       v11, v14, v27
    s.add        s48, s16, s32
    vf.add       v14, v12, v11
    v.st.w       [s38, #0], v14
    s.addi       s32, s47, #64
    v.ld.w       v11, [s52, #0]
    s.addi       s38, s16, #12416
    v.ld.w       v12, [s42, #0]
    vf.mul       v14, v11, v9
    v.extract    s42, v21, #2
    v.splat      v9, s42
    s.movz       s42, #38080
    vf.mul       v11, v14, v27
    s.add        s52, s16, s42
    vf.add       v14, v12, v11
    v.st.w       [s57, #0], v14
    fence.acq_rel.device
    s.addi       s42, s47, #128
    v.ld.w       v11, [s43, #0]
    s.addi       s43, s16, #12480
    v.ld.w       v12, [s28, #0]
    vf.mul       v14, v11, v1
    v.extract    s28, v21, #3
    v.splat      v1, s28
    s.movz       s28, #38144
    vf.mul       v11, v14, v23
    s.add        s57, s16, s28
    vf.add       v14, v12, v11
    v.st.w       [s47, #0], v14
    v.ld.w       v11, [s30, #0]
    s.addi       s28, s47, #192
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v8
    s.addi       s23, s16, #12544
    vf.mul       v8, v14, v23
    vf.add       v11, v12, v8
    v.st.w       [s32, #0], v11
    v.extract    s30, v21, #4
    v.splat      v8, s30
    s.movz       s30, #38208
    s.add        s32, s16, s30
    v.ld.w       v11, [s48, #0]
    s.addi       s30, s47, #256
    v.ld.w       v12, [s38, #0]
    vf.mul       v14, v11, v9
    s.addi       s38, s16, #12608
    vf.mul       v9, v14, v23
    vf.add       v11, v12, v9
    v.st.w       [s42, #0], v11
    v.extract    s42, v21, #5
    v.splat      v9, s42
    s.movz       s42, #38272
    s.add        s48, s16, s42
    v.ld.w       v11, [s52, #0]
    s.addi       s42, s47, #320
    v.ld.w       v12, [s43, #0]
    vf.mul       v14, v11, v1
    s.addi       s43, s16, #12672
    vf.mul       v1, v14, v23
    vf.add       v11, v12, v1
    v.st.w       [s28, #0], v11
    v.extract    s28, v21, #6
    v.splat      v1, s28
    s.movz       s28, #38336
    s.add        s52, s16, s28
    v.ld.w       v11, [s57, #0]
    s.addi       s28, s47, #384
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v8
    s.addi       s23, s16, #12736
    vf.mul       v8, v14, v23
    vf.add       v11, v12, v8
    v.st.w       [s30, #0], v11
    v.extract    s30, v21, #7
    v.splat      v8, s30
    s.movz       s30, #38400
    s.add        s57, s16, s30
    v.ld.w       v11, [s32, #0]
    s.addi       s30, s47, #448
    v.ld.w       v12, [s38, #0]
    vf.mul       v14, v11, v9
    s.addi       s32, s16, #12800
    vf.mul       v9, v14, v23
    vf.add       v11, v12, v9
    v.st.w       [s42, #0], v11
    v.extract    s38, v21, #8
    v.splat      v9, s38
    s.movz       s38, #38464
    s.add        s42, s16, s38
    v.ld.w       v11, [s48, #0]
    s.addi       s38, s47, #512
    v.ld.w       v12, [s43, #0]
    vf.mul       v14, v11, v1
    s.addi       s43, s16, #12864
    vf.mul       v1, v14, v23
    vf.add       v11, v12, v1
    v.st.w       [s28, #0], v11
    v.extract    s28, v21, #9
    v.splat      v1, s28
    s.movz       s28, #38528
    s.add        s48, s16, s28
    v.ld.w       v11, [s52, #0]
    s.addi       s28, s47, #576
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v8
    s.addi       s23, s16, #12928
    vf.mul       v8, v14, v23
    vf.add       v11, v12, v8
    v.st.w       [s30, #0], v11
    v.extract    s30, v21, #10
    v.splat      v8, s30
    s.movz       s30, #38592
    s.add        s52, s16, s30
    v.ld.w       v11, [s57, #0]
    s.addi       s30, s47, #640
    v.ld.w       v12, [s32, #0]
    vf.mul       v14, v11, v9
    s.addi       s32, s16, #12992
    vf.mul       v9, v14, v23
    vf.add       v11, v12, v9
    v.st.w       [s38, #0], v11
    v.extract    s38, v21, #11
    v.splat      v9, s38
    s.movz       s38, #38656
    s.add        s57, s16, s38
    v.ld.w       v11, [s42, #0]
    s.addi       s38, s47, #704
    v.ld.w       v12, [s43, #0]
    vf.mul       v14, v11, v1
    s.addi       s42, s16, #13056
    vf.mul       v1, v14, v23
    vf.add       v11, v12, v1
    v.st.w       [s28, #0], v11
    v.extract    s28, v21, #12
    v.splat      v1, s28
    s.movz       s28, #38720
    s.add        s43, s16, s28
    v.ld.w       v11, [s48, #0]
    s.addi       s28, s47, #768
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v8
    s.addi       s23, s16, #13120
    vf.mul       v8, v14, v23
    vf.add       v11, v12, v8
    v.st.w       [s30, #0], v11
    v.extract    s30, v21, #13
    v.splat      v8, s30
    s.movz       s30, #38784
    s.add        s48, s16, s30
    v.ld.w       v11, [s52, #0]
    s.addi       s30, s47, #832
    v.ld.w       v12, [s32, #0]
    vf.mul       v14, v11, v9
    s.addi       s32, s16, #13184
    vf.mul       v9, v14, v23
    vf.add       v11, v12, v9
    v.st.w       [s38, #0], v11
    v.extract    s38, v21, #14
    v.splat      v9, s38
    s.movz       s38, #38848
    s.add        s52, s16, s38
    v.ld.w       v11, [s57, #0]
    s.addi       s38, s47, #896
    s.addi       s57, s47, #960
    v.ld.w       v12, [s42, #0]
    vf.mul       v14, v11, v1
    s.addi       s42, s16, #13248
    vf.mul       v1, v14, v23
    vf.add       v11, v12, v1
    v.st.w       [s28, #0], v11
    v.extract    s28, v21, #15
    v.splat      v1, s28
    s.movz       s28, #38912
    s.add        s47, s16, s28
    v.ld.w       v11, [s43, #0]
    s.addi       s28, s16, #13312
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v8
    v.extract    s23, v21, #0
    v.splat      v8, s23
    s.movz       s23, #55296
    vf.mul       v11, v14, v23
    s.add        s43, s16, s23
    vf.add       v14, v12, v11
    v.st.w       [s30, #0], v14
    s.movz       s23, #38976
    s.add        s30, s16, s23
    v.ld.w       v11, [s48, #0]
    s.addi       s23, s16, #13376
    v.ld.w       v12, [s32, #0]
    vf.mul       v14, v11, v9
    v.extract    s32, v21, #1
    v.splat      v9, s32
    s.movz       s32, #39040
    vf.mul       v11, v14, v23
    s.add        s48, s16, s32
    vf.add       v14, v12, v11
    v.st.w       [s38, #0], v14
    s.addi       s32, s43, #64
    v.ld.w       v11, [s52, #0]
    s.addi       s38, s16, #13440
    v.ld.w       v12, [s42, #0]
    vf.mul       v14, v11, v1
    v.extract    s42, v21, #2
    v.splat      v1, s42
    s.movz       s42, #39104
    vf.mul       v11, v14, v23
    s.add        s52, s16, s42
    vf.add       v14, v12, v11
    v.st.w       [s57, #0], v14
    fence.acq_rel.device
    s.addi       s42, s43, #128
    v.ld.w       v11, [s47, #0]
    s.addi       s47, s16, #13504
    v.ld.w       v12, [s28, #0]
    vf.mul       v14, v11, v8
    v.extract    s28, v21, #3
    v.splat      v8, s28
    s.movz       s28, #39168
    vf.mul       v11, v14, v24
    s.add        s57, s16, s28
    vf.add       v14, v12, v11
    v.st.w       [s43, #0], v14
    v.ld.w       v11, [s30, #0]
    s.addi       s28, s43, #192
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v9
    s.addi       s23, s16, #13568
    vf.mul       v9, v14, v24
    vf.add       v11, v12, v9
    v.st.w       [s32, #0], v11
    v.extract    s30, v21, #4
    v.splat      v9, s30
    s.movz       s30, #39232
    s.add        s32, s16, s30
    v.ld.w       v11, [s48, #0]
    s.addi       s30, s43, #256
    v.ld.w       v12, [s38, #0]
    vf.mul       v14, v11, v1
    s.addi       s38, s16, #13632
    vf.mul       v1, v14, v24
    vf.add       v11, v12, v1
    v.st.w       [s42, #0], v11
    v.extract    s42, v21, #5
    v.splat      v1, s42
    s.movz       s42, #39296
    s.add        s48, s16, s42
    v.ld.w       v11, [s52, #0]
    s.addi       s42, s43, #320
    v.ld.w       v12, [s47, #0]
    vf.mul       v14, v11, v8
    s.addi       s47, s16, #13696
    vf.mul       v8, v14, v24
    vf.add       v11, v12, v8
    v.st.w       [s28, #0], v11
    v.extract    s28, v21, #6
    v.splat      v8, s28
    s.movz       s28, #39360
    s.add        s52, s16, s28
    v.ld.w       v11, [s57, #0]
    s.addi       s28, s43, #384
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v9
    s.addi       s23, s16, #13760
    vf.mul       v9, v14, v24
    vf.add       v11, v12, v9
    v.st.w       [s30, #0], v11
    v.extract    s30, v21, #7
    v.splat      v9, s30
    s.movz       s30, #39424
    s.add        s57, s16, s30
    v.ld.w       v11, [s32, #0]
    s.addi       s30, s43, #448
    v.ld.w       v12, [s38, #0]
    vf.mul       v14, v11, v1
    s.addi       s32, s16, #13824
    vf.mul       v1, v14, v24
    vf.add       v11, v12, v1
    v.st.w       [s42, #0], v11
    v.extract    s38, v21, #8
    v.splat      v1, s38
    s.movz       s38, #39488
    s.add        s42, s16, s38
    v.ld.w       v11, [s48, #0]
    s.addi       s38, s43, #512
    v.ld.w       v12, [s47, #0]
    vf.mul       v14, v11, v8
    s.addi       s47, s16, #13888
    vf.mul       v8, v14, v24
    vf.add       v11, v12, v8
    v.st.w       [s28, #0], v11
    v.extract    s28, v21, #9
    v.splat      v8, s28
    s.movz       s28, #39552
    s.add        s48, s16, s28
    v.ld.w       v11, [s52, #0]
    s.addi       s28, s43, #576
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v9
    s.addi       s23, s16, #13952
    vf.mul       v9, v14, v24
    vf.add       v11, v12, v9
    v.st.w       [s30, #0], v11
    v.extract    s30, v21, #10
    v.splat      v9, s30
    s.movz       s30, #39616
    s.add        s52, s16, s30
    v.ld.w       v11, [s57, #0]
    s.addi       s30, s43, #640
    v.ld.w       v12, [s32, #0]
    vf.mul       v14, v11, v1
    s.addi       s32, s16, #14016
    vf.mul       v1, v14, v24
    vf.add       v11, v12, v1
    v.st.w       [s38, #0], v11
    v.extract    s38, v21, #11
    v.splat      v1, s38
    s.movz       s38, #39680
    s.add        s57, s16, s38
    v.ld.w       v11, [s42, #0]
    s.addi       s38, s43, #704
    v.ld.w       v12, [s47, #0]
    vf.mul       v14, v11, v8
    s.addi       s42, s16, #14080
    vf.mul       v8, v14, v24
    vf.add       v11, v12, v8
    v.st.w       [s28, #0], v11
    v.extract    s28, v21, #12
    v.splat      v8, s28
    s.movz       s28, #39744
    s.add        s47, s16, s28
    v.ld.w       v11, [s48, #0]
    s.addi       s28, s43, #768
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v9
    s.addi       s23, s16, #14144
    vf.mul       v9, v14, v24
    vf.add       v11, v12, v9
    v.st.w       [s30, #0], v11
    v.extract    s30, v21, #13
    v.splat      v9, s30
    s.movz       s30, #39808
    s.add        s48, s16, s30
    v.ld.w       v11, [s52, #0]
    s.addi       s30, s43, #832
    v.ld.w       v12, [s32, #0]
    vf.mul       v14, v11, v1
    s.addi       s32, s16, #14208
    vf.mul       v1, v14, v24
    vf.add       v11, v12, v1
    v.st.w       [s38, #0], v11
    v.extract    s38, v21, #14
    v.splat      v1, s38
    s.movz       s38, #39872
    s.add        s52, s16, s38
    v.ld.w       v11, [s57, #0]
    s.addi       s38, s43, #896
    s.addi       s57, s43, #960
    v.ld.w       v12, [s42, #0]
    vf.mul       v14, v11, v8
    s.addi       s42, s16, #14272
    vf.mul       v8, v14, v24
    vf.add       v11, v12, v8
    v.st.w       [s28, #0], v11
    v.extract    s28, v21, #15
    v.splat      v8, s28
    s.movz       s28, #39936
    s.add        s43, s16, s28
    v.ld.w       v11, [s47, #0]
    s.addi       s28, s16, #14336
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v9
    v.extract    s23, v21, #0
    v.splat      v9, s23
    s.movz       s23, #56320
    vf.mul       v11, v14, v24
    s.add        s47, s16, s23
    vf.add       v14, v12, v11
    v.st.w       [s30, #0], v14
    s.movz       s23, #40000
    s.add        s30, s16, s23
    v.ld.w       v11, [s48, #0]
    s.addi       s23, s16, #14400
    v.ld.w       v12, [s32, #0]
    vf.mul       v14, v11, v1
    v.extract    s32, v21, #1
    v.splat      v1, s32
    s.movz       s32, #40064
    vf.mul       v11, v14, v24
    s.add        s48, s16, s32
    vf.add       v14, v12, v11
    v.st.w       [s38, #0], v14
    s.addi       s32, s47, #64
    v.ld.w       v11, [s52, #0]
    s.addi       s38, s16, #14464
    v.ld.w       v12, [s42, #0]
    vf.mul       v14, v11, v8
    v.extract    s42, v21, #2
    v.splat      v8, s42
    s.movz       s42, #40128
    vf.mul       v11, v14, v24
    s.add        s52, s16, s42
    vf.add       v14, v12, v11
    v.st.w       [s57, #0], v14
    fence.acq_rel.device
    s.addi       s42, s47, #128
    v.ld.w       v11, [s43, #0]
    s.addi       s43, s16, #14528
    v.ld.w       v12, [s28, #0]
    vf.mul       v14, v11, v9
    v.extract    s28, v21, #3
    v.splat      v9, s28
    s.movz       s28, #40192
    vf.mul       v11, v14, v25
    s.add        s57, s16, s28
    vf.add       v14, v12, v11
    v.st.w       [s47, #0], v14
    v.ld.w       v11, [s30, #0]
    s.addi       s28, s47, #192
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v1
    s.addi       s23, s16, #14592
    vf.mul       v1, v14, v25
    vf.add       v11, v12, v1
    v.st.w       [s32, #0], v11
    v.extract    s30, v21, #4
    v.splat      v1, s30
    s.movz       s30, #40256
    s.add        s32, s16, s30
    v.ld.w       v11, [s48, #0]
    s.addi       s30, s47, #256
    v.ld.w       v12, [s38, #0]
    vf.mul       v14, v11, v8
    s.addi       s38, s16, #14656
    vf.mul       v8, v14, v25
    vf.add       v11, v12, v8
    v.st.w       [s42, #0], v11
    v.extract    s42, v21, #5
    v.splat      v8, s42
    s.movz       s42, #40320
    s.add        s48, s16, s42
    v.ld.w       v11, [s52, #0]
    s.addi       s42, s47, #320
    v.ld.w       v12, [s43, #0]
    vf.mul       v14, v11, v9
    s.addi       s43, s16, #14720
    vf.mul       v9, v14, v25
    vf.add       v11, v12, v9
    v.st.w       [s28, #0], v11
    v.extract    s28, v21, #6
    v.splat      v9, s28
    s.movz       s28, #40384
    s.add        s52, s16, s28
    v.ld.w       v11, [s57, #0]
    s.addi       s28, s47, #384
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v1
    s.addi       s23, s16, #14784
    vf.mul       v1, v14, v25
    vf.add       v11, v12, v1
    v.st.w       [s30, #0], v11
    v.extract    s30, v21, #7
    v.splat      v1, s30
    s.movz       s30, #40448
    s.add        s57, s16, s30
    v.ld.w       v11, [s32, #0]
    s.addi       s30, s47, #448
    v.ld.w       v12, [s38, #0]
    vf.mul       v14, v11, v8
    s.addi       s32, s16, #14848
    vf.mul       v8, v14, v25
    vf.add       v11, v12, v8
    v.st.w       [s42, #0], v11
    v.extract    s38, v21, #8
    v.splat      v8, s38
    s.movz       s38, #40512
    s.add        s42, s16, s38
    v.ld.w       v11, [s48, #0]
    s.addi       s38, s47, #512
    v.ld.w       v12, [s43, #0]
    vf.mul       v14, v11, v9
    s.addi       s43, s16, #14912
    vf.mul       v9, v14, v25
    vf.add       v11, v12, v9
    v.st.w       [s28, #0], v11
    v.extract    s28, v21, #9
    v.splat      v9, s28
    s.movz       s28, #40576
    s.add        s48, s16, s28
    v.ld.w       v11, [s52, #0]
    s.addi       s28, s47, #576
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v1
    s.addi       s23, s16, #14976
    vf.mul       v1, v14, v25
    vf.add       v11, v12, v1
    v.st.w       [s30, #0], v11
    v.extract    s30, v21, #10
    v.splat      v1, s30
    s.movz       s30, #40640
    s.add        s52, s16, s30
    v.ld.w       v11, [s57, #0]
    s.addi       s30, s47, #640
    v.ld.w       v12, [s32, #0]
    vf.mul       v14, v11, v8
    s.addi       s32, s16, #15040
    vf.mul       v8, v14, v25
    vf.add       v11, v12, v8
    v.st.w       [s38, #0], v11
    v.extract    s38, v21, #11
    v.splat      v8, s38
    s.movz       s38, #40704
    s.add        s57, s16, s38
    v.ld.w       v11, [s42, #0]
    s.addi       s38, s47, #704
    v.ld.w       v12, [s43, #0]
    vf.mul       v14, v11, v9
    s.addi       s42, s16, #15104
    vf.mul       v9, v14, v25
    vf.add       v11, v12, v9
    v.st.w       [s28, #0], v11
    v.extract    s28, v21, #12
    v.splat      v9, s28
    s.movz       s28, #40768
    s.add        s43, s16, s28
    v.ld.w       v11, [s48, #0]
    s.addi       s28, s47, #768
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v1
    s.addi       s23, s16, #15168
    vf.mul       v1, v14, v25
    vf.add       v11, v12, v1
    v.st.w       [s30, #0], v11
    v.extract    s30, v21, #13
    v.splat      v1, s30
    s.movz       s30, #40832
    s.add        s48, s16, s30
    v.ld.w       v11, [s52, #0]
    s.addi       s30, s47, #832
    v.ld.w       v12, [s32, #0]
    vf.mul       v14, v11, v8
    s.addi       s32, s16, #15232
    vf.mul       v8, v14, v25
    vf.add       v11, v12, v8
    v.st.w       [s38, #0], v11
    v.extract    s38, v21, #14
    v.splat      v8, s38
    s.movz       s38, #40896
    s.add        s52, s16, s38
    v.ld.w       v11, [s57, #0]
    s.addi       s38, s47, #896
    s.addi       s57, s47, #960
    v.ld.w       v12, [s42, #0]
    vf.mul       v14, v11, v9
    s.addi       s42, s16, #15296
    vf.mul       v9, v14, v25
    vf.add       v11, v12, v9
    v.st.w       [s28, #0], v11
    v.extract    s28, v21, #15
    v.splat      v9, s28
    s.movz       s28, #40960
    s.add        s47, s16, s28
    v.ld.w       v11, [s43, #0]
    s.addi       s28, s16, #15360
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v1
    v.extract    s23, v21, #0
    v.splat      v1, s23
    s.movz       s23, #57344
    vf.mul       v11, v14, v25
    s.add        s43, s16, s23
    vf.add       v14, v12, v11
    v.st.w       [s30, #0], v14
    s.movz       s23, #41024
    s.add        s30, s16, s23
    v.ld.w       v11, [s48, #0]
    s.addi       s23, s16, #15424
    v.ld.w       v12, [s32, #0]
    vf.mul       v14, v11, v8
    v.extract    s32, v21, #1
    v.splat      v8, s32
    s.movz       s32, #41088
    vf.mul       v11, v14, v25
    s.add        s48, s16, s32
    vf.add       v14, v12, v11
    v.st.w       [s38, #0], v14
    s.addi       s32, s43, #64
    v.ld.w       v11, [s52, #0]
    s.addi       s38, s16, #15488
    v.ld.w       v12, [s42, #0]
    vf.mul       v14, v11, v9
    v.extract    s42, v21, #2
    v.splat      v9, s42
    s.movz       s42, #41152
    vf.mul       v11, v14, v25
    s.add        s52, s16, s42
    vf.add       v14, v12, v11
    v.st.w       [s57, #0], v14
    fence.acq_rel.device
    s.addi       s42, s43, #128
    v.ld.w       v11, [s47, #0]
    s.addi       s47, s16, #15552
    v.ld.w       v12, [s28, #0]
    vf.mul       v14, v11, v1
    v.extract    s28, v21, #3
    v.splat      v1, s28
    s.movz       s28, #41216
    vf.mul       v11, v14, v27
    s.add        s57, s16, s28
    vf.add       v14, v12, v11
    v.st.w       [s43, #0], v14
    v.ld.w       v11, [s30, #0]
    s.addi       s28, s43, #192
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v8
    s.addi       s23, s16, #15616
    vf.mul       v8, v14, v27
    vf.add       v11, v12, v8
    v.st.w       [s32, #0], v11
    v.extract    s30, v21, #4
    v.splat      v8, s30
    s.movz       s30, #41280
    s.add        s32, s16, s30
    v.ld.w       v11, [s48, #0]
    s.addi       s30, s43, #256
    v.ld.w       v12, [s38, #0]
    vf.mul       v14, v11, v9
    s.addi       s38, s16, #15680
    vf.mul       v9, v14, v27
    vf.add       v11, v12, v9
    v.st.w       [s42, #0], v11
    v.extract    s42, v21, #5
    v.splat      v9, s42
    s.movz       s42, #41344
    s.add        s48, s16, s42
    v.ld.w       v11, [s52, #0]
    s.addi       s42, s43, #320
    v.ld.w       v12, [s47, #0]
    vf.mul       v14, v11, v1
    s.addi       s47, s16, #15744
    vf.mul       v1, v14, v27
    vf.add       v11, v12, v1
    v.st.w       [s28, #0], v11
    v.extract    s28, v21, #6
    v.splat      v1, s28
    s.movz       s28, #41408
    s.add        s52, s16, s28
    v.ld.w       v11, [s57, #0]
    s.addi       s28, s43, #384
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v8
    s.addi       s23, s16, #15808
    vf.mul       v8, v14, v27
    vf.add       v11, v12, v8
    v.st.w       [s30, #0], v11
    v.extract    s30, v21, #7
    v.splat      v8, s30
    s.movz       s30, #41472
    s.add        s57, s16, s30
    v.ld.w       v11, [s32, #0]
    s.addi       s30, s43, #448
    v.ld.w       v12, [s38, #0]
    vf.mul       v14, v11, v9
    s.addi       s32, s16, #15872
    vf.mul       v9, v14, v27
    vf.add       v11, v12, v9
    v.st.w       [s42, #0], v11
    v.extract    s38, v21, #8
    v.splat      v9, s38
    s.movz       s38, #41536
    s.add        s42, s16, s38
    v.ld.w       v11, [s48, #0]
    s.addi       s38, s43, #512
    v.ld.w       v12, [s47, #0]
    vf.mul       v14, v11, v1
    s.addi       s47, s16, #15936
    vf.mul       v1, v14, v27
    vf.add       v11, v12, v1
    v.st.w       [s28, #0], v11
    v.extract    s28, v21, #9
    v.splat      v1, s28
    s.movz       s28, #41600
    s.add        s48, s16, s28
    v.ld.w       v11, [s52, #0]
    s.addi       s28, s43, #576
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v8
    s.addi       s23, s16, #16000
    vf.mul       v8, v14, v27
    vf.add       v11, v12, v8
    v.st.w       [s30, #0], v11
    v.extract    s30, v21, #10
    v.splat      v8, s30
    s.movz       s30, #41664
    s.add        s52, s16, s30
    v.ld.w       v11, [s57, #0]
    s.addi       s30, s43, #640
    v.ld.w       v12, [s32, #0]
    vf.mul       v14, v11, v9
    s.addi       s32, s16, #16064
    vf.mul       v9, v14, v27
    vf.add       v11, v12, v9
    v.st.w       [s38, #0], v11
    v.extract    s38, v21, #11
    v.splat      v9, s38
    s.movz       s38, #41728
    s.add        s57, s16, s38
    v.ld.w       v11, [s42, #0]
    s.addi       s38, s43, #704
    v.ld.w       v12, [s47, #0]
    vf.mul       v14, v11, v1
    s.addi       s42, s16, #16128
    vf.mul       v1, v14, v27
    vf.add       v11, v12, v1
    v.st.w       [s28, #0], v11
    v.extract    s28, v21, #12
    v.splat      v1, s28
    s.movz       s28, #41792
    s.add        s47, s16, s28
    v.ld.w       v11, [s48, #0]
    s.addi       s28, s43, #768
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v8
    s.addi       s23, s16, #16192
    vf.mul       v8, v14, v27
    vf.add       v11, v12, v8
    v.st.w       [s30, #0], v11
    v.extract    s30, v21, #13
    v.splat      v8, s30
    s.movz       s30, #41856
    s.add        s48, s16, s30
    v.ld.w       v11, [s52, #0]
    s.addi       s30, s43, #832
    v.ld.w       v12, [s32, #0]
    vf.mul       v14, v11, v9
    s.addi       s32, s16, #16256
    vf.mul       v9, v14, v27
    vf.add       v11, v12, v9
    v.st.w       [s38, #0], v11
    v.extract    s38, v21, #14
    v.splat      v9, s38
    s.movz       s38, #41920
    s.add        s52, s16, s38
    v.ld.w       v11, [s57, #0]
    s.addi       s38, s43, #896
    s.addi       s57, s43, #960
    v.ld.w       v12, [s42, #0]
    vf.mul       v14, v11, v1
    s.addi       s42, s16, #16320
    vf.mul       v1, v14, v27
    vf.add       v11, v12, v1
    v.st.w       [s28, #0], v11
    v.extract    s28, v21, #15
    v.splat      v1, s28
    s.addi       s28, s21, #128
    s.addi       s43, s28, #0
    v.ld.w       v11, [s47, #0]
    s.addi       s28, s22, #128
    s.addi       s47, s28, #0
    v.ld.w       v12, [s23, #0]
    vf.mul       v14, v11, v8
    s.movz       s23, #41984
    s.add        s28, s16, s23
    vf.mul       v8, v14, v27
    vf.add       v11, v12, v8
    v.st.w       [s30, #0], v11
    s.movz       s23, #42048
    s.add        s30, s16, s23
    v.ld.w       v8, [s48, #0]
    s.addi       s23, s16, #0
    v.ld.w       v11, [s32, #0]
    vf.mul       v12, v8, v9
    s.movz       s32, #42112
    s.add        s48, s16, s32
    vf.mul       v8, v12, v27
    vf.add       v9, v11, v8
    v.st.w       [s38, #0], v9
    s.addi       s32, s16, #64
    v.ld.w       v8, [s52, #0]
    s.movz       s38, #42176
    s.add        s52, s16, s38
    v.ld.w       v9, [s42, #0]
    vf.mul       v11, v8, v1
    s.addi       s38, s16, #128
    vf.mul       v1, v11, v27
    vf.add       v8, v9, v1
    v.st.w       [s57, #0], v8
    fence.acq_rel.device
    s.mov        s21, s43
    s.mov        s22, s47
    s.movz       s42, #42240
    s.addi       s43, s16, #192
    s.add        s47, s16, s42
    s.movz       s42, #42304
    s.addi       s57, s16, #256
    s.add        s58, s16, s42
    s.movz       s42, #42368
    s.add        s59, s16, s42
    v.ld.w       v1, [s28, #0]
    s.addi       s28, s16, #320
    v.st.w       [s23, #0], v1
    s.movz       s23, #42432
    s.add        s42, s16, s23
    v.ld.w       v1, [s30, #0]
    s.addi       s23, s16, #384
    v.st.w       [s32, #0], v1
    s.movz       s30, #42496
    s.add        s32, s16, s30
    v.ld.w       v1, [s48, #0]
    s.addi       s30, s16, #448
    v.st.w       [s38, #0], v1
    s.movz       s38, #42560
    s.add        s48, s16, s38
    v.ld.w       v1, [s52, #0]
    s.addi       s38, s16, #512
    v.st.w       [s43, #0], v1
    s.movz       s43, #42624
    s.add        s52, s16, s43
    v.ld.w       v1, [s47, #0]
    s.addi       s43, s16, #576
    v.st.w       [s57, #0], v1
    s.movz       s47, #42688
    s.add        s57, s16, s47
    v.ld.w       v1, [s58, #0]
    s.addi       s47, s16, #640
    v.st.w       [s28, #0], v1
    s.movz       s28, #42752
    s.add        s58, s16, s28
    v.ld.w       v1, [s59, #0]
    s.addi       s28, s16, #704
    v.st.w       [s23, #0], v1
    s.movz       s23, #42816
    s.add        s59, s16, s23
    v.ld.w       v1, [s42, #0]
    s.addi       s23, s16, #768
    v.st.w       [s30, #0], v1
    s.movz       s30, #42880
    s.add        s42, s16, s30
    v.ld.w       v1, [s32, #0]
    s.addi       s30, s16, #832
    v.st.w       [s38, #0], v1
    s.movz       s32, #42944
    s.add        s38, s16, s32
    v.ld.w       v1, [s48, #0]
    s.addi       s32, s16, #896
    v.st.w       [s43, #0], v1
    s.movz       s43, #43008
    s.add        s48, s16, s43
    v.ld.w       v1, [s52, #0]
    s.addi       s43, s16, #960
    v.st.w       [s47, #0], v1
    s.movz       s47, #43072
    s.add        s52, s16, s47
    v.ld.w       v1, [s57, #0]
    s.addi       s47, s16, #1024
    v.st.w       [s28, #0], v1
    s.movz       s28, #43136
    s.add        s57, s16, s28
    v.ld.w       v1, [s58, #0]
    s.addi       s28, s16, #1088
    v.st.w       [s23, #0], v1
    s.movz       s23, #43200
    s.add        s58, s16, s23
    v.ld.w       v1, [s59, #0]
    s.addi       s23, s16, #1152
    v.st.w       [s30, #0], v1
    s.movz       s30, #43264
    s.add        s59, s16, s30
    v.ld.w       v1, [s42, #0]
    s.addi       s30, s16, #1216
    v.st.w       [s32, #0], v1
    s.movz       s32, #43328
    s.add        s42, s16, s32
    v.ld.w       v1, [s38, #0]
    s.addi       s32, s16, #1280
    v.st.w       [s43, #0], v1
    fence.acq_rel.device
    s.movz       s38, #43392
    s.add        s43, s16, s38
    v.ld.w       v1, [s48, #0]
    s.addi       s38, s16, #1344
    v.st.w       [s47, #0], v1
    s.movz       s47, #43456
    s.add        s48, s16, s47
    v.ld.w       v1, [s52, #0]
    s.addi       s47, s16, #1408
    v.st.w       [s28, #0], v1
    s.movz       s28, #43520
    s.add        s52, s16, s28
    v.ld.w       v1, [s57, #0]
    s.addi       s28, s16, #1472
    v.st.w       [s23, #0], v1
    s.movz       s23, #43584
    s.add        s57, s16, s23
    v.ld.w       v1, [s58, #0]
    s.addi       s23, s16, #1536
    v.st.w       [s30, #0], v1
    s.movz       s30, #43648
    s.add        s58, s16, s30
    v.ld.w       v1, [s59, #0]
    s.addi       s30, s16, #1600
    v.st.w       [s32, #0], v1
    s.movz       s32, #43712
    s.add        s59, s16, s32
    v.ld.w       v1, [s42, #0]
    s.addi       s32, s16, #1664
    v.st.w       [s38, #0], v1
    s.movz       s38, #43776
    s.add        s42, s16, s38
    v.ld.w       v1, [s43, #0]
    s.addi       s38, s16, #1728
    v.st.w       [s47, #0], v1
    s.movz       s43, #43840
    s.add        s47, s16, s43
    v.ld.w       v1, [s48, #0]
    s.addi       s43, s16, #1792
    v.st.w       [s28, #0], v1
    s.movz       s28, #43904
    s.add        s48, s16, s28
    v.ld.w       v1, [s52, #0]
    s.addi       s28, s16, #1856
    v.st.w       [s23, #0], v1
    s.movz       s23, #43968
    s.add        s52, s16, s23
    v.ld.w       v1, [s57, #0]
    s.addi       s23, s16, #1920
    v.st.w       [s30, #0], v1
    s.movz       s30, #44032
    s.add        s57, s16, s30
    v.ld.w       v1, [s58, #0]
    s.addi       s30, s16, #1984
    v.st.w       [s32, #0], v1
    s.movz       s32, #44096
    s.add        s58, s16, s32
    v.ld.w       v1, [s59, #0]
    s.addi       s32, s16, #2048
    v.st.w       [s38, #0], v1
    s.movz       s38, #44160
    s.add        s59, s16, s38
    v.ld.w       v1, [s42, #0]
    s.addi       s38, s16, #2112
    v.st.w       [s43, #0], v1
    s.movz       s42, #44224
    s.add        s43, s16, s42
    v.ld.w       v1, [s47, #0]
    s.addi       s42, s16, #2176
    v.st.w       [s28, #0], v1
    s.movz       s28, #44288
    s.add        s47, s16, s28
    v.ld.w       v1, [s48, #0]
    s.addi       s28, s16, #2240
    v.st.w       [s23, #0], v1
    s.movz       s23, #44352
    s.add        s48, s16, s23
    v.ld.w       v1, [s52, #0]
    s.addi       s23, s16, #2304
    v.st.w       [s30, #0], v1
    fence.acq_rel.device
    s.movz       s30, #44416
    s.add        s52, s16, s30
    v.ld.w       v1, [s57, #0]
    s.addi       s30, s16, #2368
    v.st.w       [s32, #0], v1
    s.movz       s32, #44480
    s.add        s57, s16, s32
    v.ld.w       v1, [s58, #0]
    s.addi       s32, s16, #2432
    v.st.w       [s38, #0], v1
    s.movz       s38, #44544
    s.add        s58, s16, s38
    v.ld.w       v1, [s59, #0]
    s.addi       s38, s16, #2496
    v.st.w       [s42, #0], v1
    s.movz       s42, #44608
    s.add        s59, s16, s42
    v.ld.w       v1, [s43, #0]
    s.addi       s42, s16, #2560
    v.st.w       [s28, #0], v1
    s.movz       s28, #44672
    s.add        s43, s16, s28
    v.ld.w       v1, [s47, #0]
    s.addi       s28, s16, #2624
    v.st.w       [s23, #0], v1
    s.movz       s23, #44736
    s.add        s47, s16, s23
    v.ld.w       v1, [s48, #0]
    s.addi       s23, s16, #2688
    v.st.w       [s30, #0], v1
    s.movz       s30, #44800
    s.add        s48, s16, s30
    v.ld.w       v1, [s52, #0]
    s.addi       s30, s16, #2752
    v.st.w       [s32, #0], v1
    s.movz       s32, #44864
    s.add        s52, s16, s32
    v.ld.w       v1, [s57, #0]
    s.addi       s32, s16, #2816
    v.st.w       [s38, #0], v1
    s.movz       s38, #44928
    s.add        s57, s16, s38
    v.ld.w       v1, [s58, #0]
    s.addi       s38, s16, #2880
    v.st.w       [s42, #0], v1
    s.movz       s42, #44992
    s.add        s58, s16, s42
    v.ld.w       v1, [s59, #0]
    s.addi       s42, s16, #2944
    v.st.w       [s28, #0], v1
    s.movz       s28, #45056
    s.add        s59, s16, s28
    v.ld.w       v1, [s43, #0]
    s.addi       s28, s16, #3008
    v.st.w       [s23, #0], v1
    s.movz       s23, #45120
    s.add        s43, s16, s23
    v.ld.w       v1, [s47, #0]
    s.addi       s23, s16, #3072
    v.st.w       [s30, #0], v1
    s.movz       s30, #45184
    s.add        s47, s16, s30
    v.ld.w       v1, [s48, #0]
    s.addi       s30, s16, #3136
    v.st.w       [s32, #0], v1
    s.movz       s32, #45248
    s.add        s48, s16, s32
    v.ld.w       v1, [s52, #0]
    s.addi       s32, s16, #3200
    v.st.w       [s38, #0], v1
    s.movz       s38, #45312
    s.add        s52, s16, s38
    v.ld.w       v1, [s57, #0]
    s.addi       s38, s16, #3264
    v.st.w       [s42, #0], v1
    s.movz       s42, #45376
    s.add        s57, s16, s42
    v.ld.w       v1, [s58, #0]
    s.addi       s42, s16, #3328
    v.st.w       [s28, #0], v1
    fence.acq_rel.device
    s.movz       s28, #45440
    s.add        s58, s16, s28
    v.ld.w       v1, [s59, #0]
    s.addi       s28, s16, #3392
    v.st.w       [s23, #0], v1
    s.movz       s23, #45504
    s.add        s59, s16, s23
    v.ld.w       v1, [s43, #0]
    s.addi       s23, s16, #3456
    v.st.w       [s30, #0], v1
    s.movz       s30, #45568
    s.add        s43, s16, s30
    v.ld.w       v1, [s47, #0]
    s.addi       s30, s16, #3520
    v.st.w       [s32, #0], v1
    s.movz       s32, #45632
    s.add        s47, s16, s32
    v.ld.w       v1, [s48, #0]
    s.addi       s32, s16, #3584
    v.st.w       [s38, #0], v1
    s.movz       s38, #45696
    s.add        s48, s16, s38
    v.ld.w       v1, [s52, #0]
    s.addi       s38, s16, #3648
    v.st.w       [s42, #0], v1
    s.movz       s42, #45760
    s.add        s52, s16, s42
    v.ld.w       v1, [s57, #0]
    s.addi       s42, s16, #3712
    v.st.w       [s28, #0], v1
    s.movz       s28, #45824
    s.add        s57, s16, s28
    v.ld.w       v1, [s58, #0]
    s.addi       s28, s16, #3776
    v.st.w       [s23, #0], v1
    s.movz       s23, #45888
    s.add        s58, s16, s23
    v.ld.w       v1, [s59, #0]
    s.addi       s23, s16, #3840
    v.st.w       [s30, #0], v1
    s.movz       s30, #45952
    s.add        s59, s16, s30
    v.ld.w       v1, [s43, #0]
    s.addi       s30, s16, #3904
    v.st.w       [s32, #0], v1
    s.movz       s32, #46016
    s.add        s43, s16, s32
    v.ld.w       v1, [s47, #0]
    s.addi       s32, s16, #3968
    v.st.w       [s38, #0], v1
    s.movz       s38, #46080
    s.add        s47, s16, s38
    v.ld.w       v1, [s48, #0]
    s.addi       s38, s16, #4032
    v.st.w       [s42, #0], v1
    s.movz       s42, #46144
    s.add        s48, s16, s42
    v.ld.w       v1, [s52, #0]
    s.addi       s42, s16, #4096
    v.st.w       [s28, #0], v1
    s.movz       s28, #46208
    s.add        s52, s16, s28
    v.ld.w       v1, [s57, #0]
    s.addi       s28, s16, #4160
    v.st.w       [s23, #0], v1
    s.movz       s23, #46272
    s.add        s57, s16, s23
    v.ld.w       v1, [s58, #0]
    s.addi       s23, s16, #4224
    v.st.w       [s30, #0], v1
    s.movz       s30, #46336
    s.add        s58, s16, s30
    v.ld.w       v1, [s59, #0]
    s.addi       s30, s16, #4288
    v.st.w       [s32, #0], v1
    s.movz       s32, #46400
    s.add        s59, s16, s32
    v.ld.w       v1, [s43, #0]
    s.addi       s32, s16, #4352
    v.st.w       [s38, #0], v1
    fence.acq_rel.device
    s.movz       s38, #46464
    s.add        s43, s16, s38
    v.ld.w       v1, [s47, #0]
    s.addi       s38, s16, #4416
    v.st.w       [s42, #0], v1
    s.movz       s42, #46528
    s.add        s47, s16, s42
    v.ld.w       v1, [s48, #0]
    s.addi       s42, s16, #4480
    v.st.w       [s28, #0], v1
    s.movz       s28, #46592
    s.add        s48, s16, s28
    v.ld.w       v1, [s52, #0]
    s.addi       s28, s16, #4544
    v.st.w       [s23, #0], v1
    s.movz       s23, #46656
    s.add        s52, s16, s23
    v.ld.w       v1, [s57, #0]
    s.addi       s23, s16, #4608
    v.st.w       [s30, #0], v1
    s.movz       s30, #46720
    s.add        s57, s16, s30
    v.ld.w       v1, [s58, #0]
    s.addi       s30, s16, #4672
    v.st.w       [s32, #0], v1
    s.movz       s32, #46784
    s.add        s58, s16, s32
    v.ld.w       v1, [s59, #0]
    s.addi       s32, s16, #4736
    v.st.w       [s38, #0], v1
    s.movz       s38, #46848
    s.add        s59, s16, s38
    v.ld.w       v1, [s43, #0]
    s.addi       s38, s16, #4800
    v.st.w       [s42, #0], v1
    s.movz       s42, #46912
    s.add        s43, s16, s42
    v.ld.w       v1, [s47, #0]
    s.addi       s42, s16, #4864
    v.st.w       [s28, #0], v1
    s.movz       s28, #46976
    s.add        s47, s16, s28
    v.ld.w       v1, [s48, #0]
    s.addi       s28, s16, #4928
    v.st.w       [s23, #0], v1
    s.movz       s23, #47040
    s.add        s48, s16, s23
    v.ld.w       v1, [s52, #0]
    s.addi       s23, s16, #4992
    v.st.w       [s30, #0], v1
    s.movz       s30, #47104
    s.add        s52, s16, s30
    v.ld.w       v1, [s57, #0]
    s.addi       s30, s16, #5056
    v.st.w       [s32, #0], v1
    s.movz       s32, #47168
    s.add        s57, s16, s32
    v.ld.w       v1, [s58, #0]
    s.addi       s32, s16, #5120
    v.st.w       [s38, #0], v1
    s.movz       s38, #47232
    s.add        s58, s16, s38
    v.ld.w       v1, [s59, #0]
    s.addi       s38, s16, #5184
    v.st.w       [s42, #0], v1
    s.movz       s42, #47296
    s.add        s59, s16, s42
    v.ld.w       v1, [s43, #0]
    s.addi       s42, s16, #5248
    v.st.w       [s28, #0], v1
    s.movz       s28, #47360
    s.add        s43, s16, s28
    v.ld.w       v1, [s47, #0]
    s.addi       s28, s16, #5312
    v.st.w       [s23, #0], v1
    s.movz       s23, #47424
    s.add        s47, s16, s23
    v.ld.w       v1, [s48, #0]
    s.addi       s23, s16, #5376
    v.st.w       [s30, #0], v1
    fence.acq_rel.device
    s.movz       s30, #47488
    s.add        s48, s16, s30
    v.ld.w       v1, [s52, #0]
    s.addi       s30, s16, #5440
    v.st.w       [s32, #0], v1
    s.movz       s32, #47552
    s.add        s52, s16, s32
    v.ld.w       v1, [s57, #0]
    s.addi       s32, s16, #5504
    v.st.w       [s38, #0], v1
    s.movz       s38, #47616
    s.add        s57, s16, s38
    v.ld.w       v1, [s58, #0]
    s.addi       s38, s16, #5568
    v.st.w       [s42, #0], v1
    s.movz       s42, #47680
    s.add        s58, s16, s42
    v.ld.w       v1, [s59, #0]
    s.addi       s42, s16, #5632
    v.st.w       [s28, #0], v1
    s.movz       s28, #47744
    s.add        s59, s16, s28
    v.ld.w       v1, [s43, #0]
    s.addi       s28, s16, #5696
    v.st.w       [s23, #0], v1
    s.movz       s23, #47808
    s.add        s43, s16, s23
    v.ld.w       v1, [s47, #0]
    s.addi       s23, s16, #5760
    v.st.w       [s30, #0], v1
    s.movz       s30, #47872
    s.add        s47, s16, s30
    v.ld.w       v1, [s48, #0]
    s.addi       s30, s16, #5824
    v.st.w       [s32, #0], v1
    s.movz       s32, #47936
    s.add        s48, s16, s32
    v.ld.w       v1, [s52, #0]
    s.addi       s32, s16, #5888
    v.st.w       [s38, #0], v1
    s.movz       s38, #48000
    s.add        s52, s16, s38
    v.ld.w       v1, [s57, #0]
    s.addi       s38, s16, #5952
    v.st.w       [s42, #0], v1
    s.movz       s42, #48064
    s.add        s57, s16, s42
    v.ld.w       v1, [s58, #0]
    s.addi       s42, s16, #6016
    v.st.w       [s28, #0], v1
    s.movz       s28, #48128
    s.add        s58, s16, s28
    v.ld.w       v1, [s59, #0]
    s.addi       s28, s16, #6080
    v.st.w       [s23, #0], v1
    s.movz       s23, #48192
    s.add        s59, s16, s23
    v.ld.w       v1, [s43, #0]
    s.addi       s23, s16, #6144
    v.st.w       [s30, #0], v1
    s.movz       s30, #48256
    s.add        s43, s16, s30
    v.ld.w       v1, [s47, #0]
    s.addi       s30, s16, #6208
    v.st.w       [s32, #0], v1
    s.movz       s32, #48320
    s.add        s47, s16, s32
    v.ld.w       v1, [s48, #0]
    s.addi       s32, s16, #6272
    v.st.w       [s38, #0], v1
    s.movz       s38, #48384
    s.add        s48, s16, s38
    v.ld.w       v1, [s52, #0]
    s.addi       s38, s16, #6336
    v.st.w       [s42, #0], v1
    s.movz       s42, #48448
    s.add        s52, s16, s42
    v.ld.w       v1, [s57, #0]
    s.addi       s42, s16, #6400
    v.st.w       [s28, #0], v1
    fence.acq_rel.device
    s.movz       s28, #48512
    s.add        s57, s16, s28
    v.ld.w       v1, [s58, #0]
    s.addi       s28, s16, #6464
    v.st.w       [s23, #0], v1
    s.movz       s23, #48576
    s.add        s58, s16, s23
    v.ld.w       v1, [s59, #0]
    s.addi       s23, s16, #6528
    v.st.w       [s30, #0], v1
    s.movz       s30, #48640
    s.add        s59, s16, s30
    v.ld.w       v1, [s43, #0]
    s.addi       s30, s16, #6592
    v.st.w       [s32, #0], v1
    s.movz       s32, #48704
    s.add        s43, s16, s32
    v.ld.w       v1, [s47, #0]
    s.addi       s32, s16, #6656
    v.st.w       [s38, #0], v1
    s.movz       s38, #48768
    s.add        s47, s16, s38
    v.ld.w       v1, [s48, #0]
    s.addi       s38, s16, #6720
    v.st.w       [s42, #0], v1
    s.movz       s42, #48832
    s.add        s48, s16, s42
    v.ld.w       v1, [s52, #0]
    s.addi       s42, s16, #6784
    v.st.w       [s28, #0], v1
    s.movz       s28, #48896
    s.add        s52, s16, s28
    v.ld.w       v1, [s57, #0]
    s.addi       s28, s16, #6848
    v.st.w       [s23, #0], v1
    s.movz       s23, #48960
    s.add        s57, s16, s23
    v.ld.w       v1, [s58, #0]
    s.addi       s23, s16, #6912
    v.st.w       [s30, #0], v1
    s.movz       s30, #49024
    s.add        s58, s16, s30
    v.ld.w       v1, [s59, #0]
    s.addi       s30, s16, #6976
    v.st.w       [s32, #0], v1
    s.movz       s32, #49088
    s.add        s59, s16, s32
    v.ld.w       v1, [s43, #0]
    s.addi       s32, s16, #7040
    v.st.w       [s38, #0], v1
    s.movz       s38, #49152
    s.add        s43, s16, s38
    v.ld.w       v1, [s47, #0]
    s.addi       s38, s16, #7104
    v.st.w       [s42, #0], v1
    s.movz       s42, #49216
    s.add        s47, s16, s42
    v.ld.w       v1, [s48, #0]
    s.addi       s42, s16, #7168
    v.st.w       [s28, #0], v1
    s.movz       s28, #49280
    s.add        s48, s16, s28
    v.ld.w       v1, [s52, #0]
    s.addi       s28, s16, #7232
    v.st.w       [s23, #0], v1
    s.movz       s23, #49344
    s.add        s52, s16, s23
    v.ld.w       v1, [s57, #0]
    s.addi       s23, s16, #7296
    v.st.w       [s30, #0], v1
    s.movz       s30, #49408
    s.add        s57, s16, s30
    v.ld.w       v1, [s58, #0]
    s.addi       s30, s16, #7360
    v.st.w       [s32, #0], v1
    s.movz       s32, #49472
    s.add        s58, s16, s32
    v.ld.w       v1, [s59, #0]
    s.addi       s32, s16, #7424
    v.st.w       [s38, #0], v1
    fence.acq_rel.device
    s.movz       s38, #49536
    s.add        s59, s16, s38
    v.ld.w       v1, [s43, #0]
    s.addi       s38, s16, #7488
    v.st.w       [s42, #0], v1
    s.movz       s42, #49600
    s.add        s43, s16, s42
    v.ld.w       v1, [s47, #0]
    s.addi       s42, s16, #7552
    v.st.w       [s28, #0], v1
    s.movz       s28, #49664
    s.add        s47, s16, s28
    v.ld.w       v1, [s48, #0]
    s.addi       s28, s16, #7616
    v.st.w       [s23, #0], v1
    s.movz       s23, #49728
    s.add        s48, s16, s23
    v.ld.w       v1, [s52, #0]
    s.addi       s23, s16, #7680
    v.st.w       [s30, #0], v1
    s.movz       s30, #49792
    s.add        s52, s16, s30
    v.ld.w       v1, [s57, #0]
    s.addi       s30, s16, #7744
    v.st.w       [s32, #0], v1
    s.movz       s32, #49856
    s.add        s57, s16, s32
    v.ld.w       v1, [s58, #0]
    s.addi       s32, s16, #7808
    v.st.w       [s38, #0], v1
    s.movz       s38, #49920
    s.add        s58, s16, s38
    v.ld.w       v1, [s59, #0]
    s.addi       s38, s16, #7872
    v.st.w       [s42, #0], v1
    s.movz       s42, #49984
    s.add        s59, s16, s42
    v.ld.w       v1, [s43, #0]
    s.addi       s42, s16, #7936
    v.st.w       [s28, #0], v1
    s.movz       s28, #50048
    s.add        s43, s16, s28
    v.ld.w       v1, [s47, #0]
    s.addi       s28, s16, #8000
    v.st.w       [s23, #0], v1
    s.movz       s23, #50112
    s.add        s47, s16, s23
    v.ld.w       v1, [s48, #0]
    s.addi       s23, s16, #8064
    v.st.w       [s30, #0], v1
    s.movz       s30, #50176
    s.add        s48, s16, s30
    v.ld.w       v1, [s52, #0]
    s.addi       s30, s16, #8128
    v.st.w       [s32, #0], v1
    s.movz       s32, #50240
    s.add        s52, s16, s32
    v.ld.w       v1, [s57, #0]
    s.addi       s32, s16, #8192
    v.st.w       [s38, #0], v1
    s.movz       s38, #50304
    s.add        s57, s16, s38
    v.ld.w       v1, [s58, #0]
    s.addi       s38, s16, #8256
    v.st.w       [s42, #0], v1
    s.movz       s42, #50368
    s.add        s58, s16, s42
    v.ld.w       v1, [s59, #0]
    s.addi       s42, s16, #8320
    v.st.w       [s28, #0], v1
    s.movz       s28, #50432
    s.add        s59, s16, s28
    v.ld.w       v1, [s43, #0]
    s.addi       s28, s16, #8384
    v.st.w       [s23, #0], v1
    s.movz       s23, #50496
    s.add        s43, s16, s23
    v.ld.w       v1, [s47, #0]
    s.addi       s23, s16, #8448
    v.st.w       [s30, #0], v1
    fence.acq_rel.device
    s.movz       s30, #50560
    s.add        s47, s16, s30
    v.ld.w       v1, [s48, #0]
    s.addi       s30, s16, #8512
    v.st.w       [s32, #0], v1
    s.movz       s32, #50624
    s.add        s48, s16, s32
    v.ld.w       v1, [s52, #0]
    s.addi       s32, s16, #8576
    v.st.w       [s38, #0], v1
    s.movz       s38, #50688
    s.add        s52, s16, s38
    v.ld.w       v1, [s57, #0]
    s.addi       s38, s16, #8640
    v.st.w       [s42, #0], v1
    s.movz       s42, #50752
    s.add        s57, s16, s42
    v.ld.w       v1, [s58, #0]
    s.addi       s42, s16, #8704
    v.st.w       [s28, #0], v1
    s.movz       s28, #50816
    s.add        s58, s16, s28
    v.ld.w       v1, [s59, #0]
    s.addi       s28, s16, #8768
    v.st.w       [s23, #0], v1
    s.movz       s23, #50880
    s.add        s59, s16, s23
    v.ld.w       v1, [s43, #0]
    s.addi       s23, s16, #8832
    v.st.w       [s30, #0], v1
    s.movz       s30, #50944
    s.add        s43, s16, s30
    v.ld.w       v1, [s47, #0]
    s.addi       s30, s16, #8896
    v.st.w       [s32, #0], v1
    s.movz       s32, #51008
    s.add        s47, s16, s32
    v.ld.w       v1, [s48, #0]
    s.addi       s32, s16, #8960
    v.st.w       [s38, #0], v1
    s.movz       s38, #51072
    s.add        s48, s16, s38
    v.ld.w       v1, [s52, #0]
    s.addi       s38, s16, #9024
    v.st.w       [s42, #0], v1
    s.movz       s42, #51136
    s.add        s52, s16, s42
    v.ld.w       v1, [s57, #0]
    s.addi       s42, s16, #9088
    v.st.w       [s28, #0], v1
    s.movz       s28, #51200
    s.add        s57, s16, s28
    v.ld.w       v1, [s58, #0]
    s.addi       s28, s16, #9152
    v.st.w       [s23, #0], v1
    s.movz       s23, #51264
    s.add        s58, s16, s23
    v.ld.w       v1, [s59, #0]
    s.addi       s23, s16, #9216
    v.st.w       [s30, #0], v1
    s.movz       s30, #51328
    s.add        s59, s16, s30
    v.ld.w       v1, [s43, #0]
    s.addi       s30, s16, #9280
    v.st.w       [s32, #0], v1
    s.movz       s32, #51392
    s.add        s43, s16, s32
    v.ld.w       v1, [s47, #0]
    s.addi       s32, s16, #9344
    v.st.w       [s38, #0], v1
    s.movz       s38, #51456
    s.add        s47, s16, s38
    v.ld.w       v1, [s48, #0]
    s.addi       s38, s16, #9408
    v.st.w       [s42, #0], v1
    s.movz       s42, #51520
    s.add        s48, s16, s42
    v.ld.w       v1, [s52, #0]
    s.addi       s42, s16, #9472
    v.st.w       [s28, #0], v1
    fence.acq_rel.device
    s.movz       s28, #51584
    s.add        s52, s16, s28
    v.ld.w       v1, [s57, #0]
    s.addi       s28, s16, #9536
    v.st.w       [s23, #0], v1
    s.movz       s23, #51648
    s.add        s57, s16, s23
    v.ld.w       v1, [s58, #0]
    s.addi       s23, s16, #9600
    v.st.w       [s30, #0], v1
    s.movz       s30, #51712
    s.add        s58, s16, s30
    v.ld.w       v1, [s59, #0]
    s.addi       s30, s16, #9664
    v.st.w       [s32, #0], v1
    s.movz       s32, #51776
    s.add        s59, s16, s32
    v.ld.w       v1, [s43, #0]
    s.addi       s32, s16, #9728
    v.st.w       [s38, #0], v1
    s.movz       s38, #51840
    s.add        s43, s16, s38
    v.ld.w       v1, [s47, #0]
    s.addi       s38, s16, #9792
    v.st.w       [s42, #0], v1
    s.movz       s42, #51904
    s.add        s47, s16, s42
    v.ld.w       v1, [s48, #0]
    s.addi       s42, s16, #9856
    v.st.w       [s28, #0], v1
    s.movz       s28, #51968
    s.add        s48, s16, s28
    v.ld.w       v1, [s52, #0]
    s.addi       s28, s16, #9920
    v.st.w       [s23, #0], v1
    s.movz       s23, #52032
    s.add        s52, s16, s23
    v.ld.w       v1, [s57, #0]
    s.addi       s23, s16, #9984
    v.st.w       [s30, #0], v1
    s.movz       s30, #52096
    s.add        s57, s16, s30
    v.ld.w       v1, [s58, #0]
    s.addi       s30, s16, #10048
    v.st.w       [s32, #0], v1
    s.movz       s32, #52160
    s.add        s58, s16, s32
    v.ld.w       v1, [s59, #0]
    s.addi       s32, s16, #10112
    v.st.w       [s38, #0], v1
    s.movz       s38, #52224
    s.add        s59, s16, s38
    v.ld.w       v1, [s43, #0]
    s.addi       s38, s16, #10176
    v.st.w       [s42, #0], v1
    s.movz       s42, #52288
    s.add        s43, s16, s42
    v.ld.w       v1, [s47, #0]
    s.addi       s42, s16, #10240
    v.st.w       [s28, #0], v1
    s.movz       s28, #52352
    s.add        s47, s16, s28
    v.ld.w       v1, [s48, #0]
    s.addi       s28, s16, #10304
    v.st.w       [s23, #0], v1
    s.movz       s23, #52416
    s.add        s48, s16, s23
    v.ld.w       v1, [s52, #0]
    s.addi       s23, s16, #10368
    v.st.w       [s30, #0], v1
    s.movz       s30, #52480
    s.add        s52, s16, s30
    v.ld.w       v1, [s57, #0]
    s.addi       s30, s16, #10432
    v.st.w       [s32, #0], v1
    s.movz       s32, #52544
    s.add        s57, s16, s32
    v.ld.w       v1, [s58, #0]
    s.addi       s32, s16, #10496
    v.st.w       [s38, #0], v1
    fence.acq_rel.device
    s.movz       s38, #52608
    s.add        s58, s16, s38
    v.ld.w       v1, [s59, #0]
    s.addi       s38, s16, #10560
    v.st.w       [s42, #0], v1
    s.movz       s42, #52672
    s.add        s59, s16, s42
    v.ld.w       v1, [s43, #0]
    s.addi       s42, s16, #10624
    v.st.w       [s28, #0], v1
    s.movz       s28, #52736
    s.add        s43, s16, s28
    v.ld.w       v1, [s47, #0]
    s.addi       s28, s16, #10688
    v.st.w       [s23, #0], v1
    s.movz       s23, #52800
    s.add        s47, s16, s23
    v.ld.w       v1, [s48, #0]
    s.addi       s23, s16, #10752
    v.st.w       [s30, #0], v1
    s.movz       s30, #52864
    s.add        s48, s16, s30
    v.ld.w       v1, [s52, #0]
    s.addi       s30, s16, #10816
    v.st.w       [s32, #0], v1
    s.movz       s32, #52928
    s.add        s52, s16, s32
    v.ld.w       v1, [s57, #0]
    s.addi       s32, s16, #10880
    v.st.w       [s38, #0], v1
    s.movz       s38, #52992
    s.add        s57, s16, s38
    v.ld.w       v1, [s58, #0]
    s.addi       s38, s16, #10944
    v.st.w       [s42, #0], v1
    s.movz       s42, #53056
    s.add        s58, s16, s42
    v.ld.w       v1, [s59, #0]
    s.addi       s42, s16, #11008
    v.st.w       [s28, #0], v1
    s.movz       s28, #53120
    s.add        s59, s16, s28
    v.ld.w       v1, [s43, #0]
    s.addi       s28, s16, #11072
    v.st.w       [s23, #0], v1
    s.movz       s23, #53184
    s.add        s43, s16, s23
    v.ld.w       v1, [s47, #0]
    s.addi       s23, s16, #11136
    v.st.w       [s30, #0], v1
    s.movz       s30, #53248
    s.add        s47, s16, s30
    v.ld.w       v1, [s48, #0]
    s.addi       s30, s16, #11200
    v.st.w       [s32, #0], v1
    s.movz       s32, #53312
    s.add        s48, s16, s32
    v.ld.w       v1, [s52, #0]
    s.addi       s32, s16, #11264
    v.st.w       [s38, #0], v1
    s.movz       s38, #53376
    s.add        s52, s16, s38
    v.ld.w       v1, [s57, #0]
    s.addi       s38, s16, #11328
    v.st.w       [s42, #0], v1
    s.movz       s42, #53440
    s.add        s57, s16, s42
    v.ld.w       v1, [s58, #0]
    s.addi       s42, s16, #11392
    v.st.w       [s28, #0], v1
    s.movz       s28, #53504
    s.add        s58, s16, s28
    v.ld.w       v1, [s59, #0]
    s.addi       s28, s16, #11456
    v.st.w       [s23, #0], v1
    s.movz       s23, #53568
    s.add        s59, s16, s23
    v.ld.w       v1, [s43, #0]
    s.addi       s23, s16, #11520
    v.st.w       [s30, #0], v1
    fence.acq_rel.device
    s.movz       s30, #53632
    s.add        s43, s16, s30
    v.ld.w       v1, [s47, #0]
    s.addi       s30, s16, #11584
    v.st.w       [s32, #0], v1
    s.movz       s32, #53696
    s.add        s47, s16, s32
    v.ld.w       v1, [s48, #0]
    s.addi       s32, s16, #11648
    v.st.w       [s38, #0], v1
    s.movz       s38, #53760
    s.add        s48, s16, s38
    v.ld.w       v1, [s52, #0]
    s.addi       s38, s16, #11712
    v.st.w       [s42, #0], v1
    s.movz       s42, #53824
    s.add        s52, s16, s42
    v.ld.w       v1, [s57, #0]
    s.addi       s42, s16, #11776
    v.st.w       [s28, #0], v1
    s.movz       s28, #53888
    s.add        s57, s16, s28
    v.ld.w       v1, [s58, #0]
    s.addi       s28, s16, #11840
    v.st.w       [s23, #0], v1
    s.movz       s23, #53952
    s.add        s58, s16, s23
    v.ld.w       v1, [s59, #0]
    s.addi       s23, s16, #11904
    v.st.w       [s30, #0], v1
    s.movz       s30, #54016
    s.add        s59, s16, s30
    v.ld.w       v1, [s43, #0]
    s.addi       s30, s16, #11968
    v.st.w       [s32, #0], v1
    s.movz       s32, #54080
    s.add        s43, s16, s32
    v.ld.w       v1, [s47, #0]
    s.addi       s32, s16, #12032
    v.st.w       [s38, #0], v1
    s.movz       s38, #54144
    s.add        s47, s16, s38
    v.ld.w       v1, [s48, #0]
    s.addi       s38, s16, #12096
    v.st.w       [s42, #0], v1
    s.movz       s42, #54208
    s.add        s48, s16, s42
    v.ld.w       v1, [s52, #0]
    s.addi       s42, s16, #12160
    v.st.w       [s28, #0], v1
    s.movz       s28, #54272
    s.add        s52, s16, s28
    v.ld.w       v1, [s57, #0]
    s.addi       s28, s16, #12224
    v.st.w       [s23, #0], v1
    s.movz       s23, #54336
    s.add        s57, s16, s23
    v.ld.w       v1, [s58, #0]
    s.addi       s23, s16, #12288
    v.st.w       [s30, #0], v1
    s.movz       s30, #54400
    s.add        s58, s16, s30
    v.ld.w       v1, [s59, #0]
    s.addi       s30, s16, #12352
    v.st.w       [s32, #0], v1
    s.movz       s32, #54464
    s.add        s59, s16, s32
    v.ld.w       v1, [s43, #0]
    s.addi       s32, s16, #12416
    v.st.w       [s38, #0], v1
    s.movz       s38, #54528
    s.add        s43, s16, s38
    v.ld.w       v1, [s47, #0]
    s.addi       s38, s16, #12480
    v.st.w       [s42, #0], v1
    s.movz       s42, #54592
    s.add        s47, s16, s42
    v.ld.w       v1, [s48, #0]
    s.addi       s42, s16, #12544
    v.st.w       [s28, #0], v1
    fence.acq_rel.device
    s.movz       s28, #54656
    s.add        s48, s16, s28
    v.ld.w       v1, [s52, #0]
    s.addi       s28, s16, #12608
    v.st.w       [s23, #0], v1
    s.movz       s23, #54720
    s.add        s52, s16, s23
    v.ld.w       v1, [s57, #0]
    s.addi       s23, s16, #12672
    v.st.w       [s30, #0], v1
    s.movz       s30, #54784
    s.add        s57, s16, s30
    v.ld.w       v1, [s58, #0]
    s.addi       s30, s16, #12736
    v.st.w       [s32, #0], v1
    s.movz       s32, #54848
    s.add        s58, s16, s32
    v.ld.w       v1, [s59, #0]
    s.addi       s32, s16, #12800
    v.st.w       [s38, #0], v1
    s.movz       s38, #54912
    s.add        s59, s16, s38
    v.ld.w       v1, [s43, #0]
    s.addi       s38, s16, #12864
    v.st.w       [s42, #0], v1
    s.movz       s42, #54976
    s.add        s43, s16, s42
    v.ld.w       v1, [s47, #0]
    s.addi       s42, s16, #12928
    v.st.w       [s28, #0], v1
    s.movz       s28, #55040
    s.add        s47, s16, s28
    v.ld.w       v1, [s48, #0]
    s.addi       s28, s16, #12992
    v.st.w       [s23, #0], v1
    s.movz       s23, #55104
    s.add        s48, s16, s23
    v.ld.w       v1, [s52, #0]
    s.addi       s23, s16, #13056
    v.st.w       [s30, #0], v1
    s.movz       s30, #55168
    s.add        s52, s16, s30
    v.ld.w       v1, [s57, #0]
    s.addi       s30, s16, #13120
    v.st.w       [s32, #0], v1
    s.movz       s32, #55232
    s.add        s57, s16, s32
    v.ld.w       v1, [s58, #0]
    s.addi       s32, s16, #13184
    v.st.w       [s38, #0], v1
    s.movz       s38, #55296
    s.add        s58, s16, s38
    v.ld.w       v1, [s59, #0]
    s.addi       s38, s16, #13248
    v.st.w       [s42, #0], v1
    s.movz       s42, #55360
    s.add        s59, s16, s42
    v.ld.w       v1, [s43, #0]
    s.addi       s42, s16, #13312
    v.st.w       [s28, #0], v1
    s.movz       s28, #55424
    s.add        s43, s16, s28
    v.ld.w       v1, [s47, #0]
    s.addi       s28, s16, #13376
    v.st.w       [s23, #0], v1
    s.movz       s23, #55488
    s.add        s47, s16, s23
    v.ld.w       v1, [s48, #0]
    s.addi       s23, s16, #13440
    v.st.w       [s30, #0], v1
    s.movz       s30, #55552
    s.add        s48, s16, s30
    v.ld.w       v1, [s52, #0]
    s.addi       s30, s16, #13504
    v.st.w       [s32, #0], v1
    s.movz       s32, #55616
    s.add        s52, s16, s32
    v.ld.w       v1, [s57, #0]
    s.addi       s32, s16, #13568
    v.st.w       [s38, #0], v1
    fence.acq_rel.device
    s.movz       s38, #55680
    s.add        s57, s16, s38
    v.ld.w       v1, [s58, #0]
    s.addi       s38, s16, #13632
    v.st.w       [s42, #0], v1
    s.movz       s42, #55744
    s.add        s58, s16, s42
    v.ld.w       v1, [s59, #0]
    s.addi       s42, s16, #13696
    v.st.w       [s28, #0], v1
    s.movz       s28, #55808
    s.add        s59, s16, s28
    v.ld.w       v1, [s43, #0]
    s.addi       s28, s16, #13760
    v.st.w       [s23, #0], v1
    s.movz       s23, #55872
    s.add        s43, s16, s23
    v.ld.w       v1, [s47, #0]
    s.addi       s23, s16, #13824
    v.st.w       [s30, #0], v1
    s.movz       s30, #55936
    s.add        s47, s16, s30
    v.ld.w       v1, [s48, #0]
    s.addi       s30, s16, #13888
    v.st.w       [s32, #0], v1
    s.movz       s32, #56000
    s.add        s48, s16, s32
    v.ld.w       v1, [s52, #0]
    s.addi       s32, s16, #13952
    v.st.w       [s38, #0], v1
    s.movz       s38, #56064
    s.add        s52, s16, s38
    v.ld.w       v1, [s57, #0]
    s.addi       s38, s16, #14016
    v.st.w       [s42, #0], v1
    s.movz       s42, #56128
    s.add        s57, s16, s42
    v.ld.w       v1, [s58, #0]
    s.addi       s42, s16, #14080
    v.st.w       [s28, #0], v1
    s.movz       s28, #56192
    s.add        s58, s16, s28
    v.ld.w       v1, [s59, #0]
    s.addi       s28, s16, #14144
    v.st.w       [s23, #0], v1
    s.movz       s23, #56256
    s.add        s59, s16, s23
    v.ld.w       v1, [s43, #0]
    s.addi       s23, s16, #14208
    v.st.w       [s30, #0], v1
    s.movz       s30, #56320
    s.add        s43, s16, s30
    v.ld.w       v1, [s47, #0]
    s.addi       s30, s16, #14272
    v.st.w       [s32, #0], v1
    s.movz       s32, #56384
    s.add        s47, s16, s32
    v.ld.w       v1, [s48, #0]
    s.addi       s32, s16, #14336
    v.st.w       [s38, #0], v1
    s.movz       s38, #56448
    s.add        s48, s16, s38
    v.ld.w       v1, [s52, #0]
    s.addi       s38, s16, #14400
    v.st.w       [s42, #0], v1
    s.movz       s42, #56512
    s.add        s52, s16, s42
    v.ld.w       v1, [s57, #0]
    s.addi       s42, s16, #14464
    v.st.w       [s28, #0], v1
    s.movz       s28, #56576
    s.add        s57, s16, s28
    v.ld.w       v1, [s58, #0]
    s.addi       s28, s16, #14528
    v.st.w       [s23, #0], v1
    s.movz       s23, #56640
    s.add        s58, s16, s23
    v.ld.w       v1, [s59, #0]
    s.addi       s23, s16, #14592
    v.st.w       [s30, #0], v1
    fence.acq_rel.device
    s.movz       s30, #56704
    s.add        s59, s16, s30
    v.ld.w       v1, [s43, #0]
    s.addi       s30, s16, #14656
    v.st.w       [s32, #0], v1
    s.movz       s32, #56768
    s.add        s43, s16, s32
    v.ld.w       v1, [s47, #0]
    s.addi       s32, s16, #14720
    v.st.w       [s38, #0], v1
    s.movz       s38, #56832
    s.add        s47, s16, s38
    v.ld.w       v1, [s48, #0]
    s.addi       s38, s16, #14784
    v.st.w       [s42, #0], v1
    s.movz       s42, #56896
    s.add        s48, s16, s42
    v.ld.w       v1, [s52, #0]
    s.addi       s42, s16, #14848
    v.st.w       [s28, #0], v1
    s.movz       s28, #56960
    s.add        s52, s16, s28
    v.ld.w       v1, [s57, #0]
    s.addi       s28, s16, #14912
    v.st.w       [s23, #0], v1
    s.movz       s23, #57024
    s.add        s57, s16, s23
    v.ld.w       v1, [s58, #0]
    s.addi       s23, s16, #14976
    v.st.w       [s30, #0], v1
    s.movz       s30, #57088
    s.add        s58, s16, s30
    v.ld.w       v1, [s59, #0]
    s.addi       s30, s16, #15040
    v.st.w       [s32, #0], v1
    s.movz       s32, #57152
    s.add        s59, s16, s32
    v.ld.w       v1, [s43, #0]
    s.addi       s32, s16, #15104
    v.st.w       [s38, #0], v1
    s.movz       s38, #57216
    s.add        s43, s16, s38
    v.ld.w       v1, [s47, #0]
    s.addi       s38, s16, #15168
    v.st.w       [s42, #0], v1
    s.movz       s42, #57280
    s.add        s47, s16, s42
    v.ld.w       v1, [s48, #0]
    s.addi       s42, s16, #15232
    v.st.w       [s28, #0], v1
    s.movz       s28, #57344
    s.add        s48, s16, s28
    v.ld.w       v1, [s52, #0]
    s.addi       s28, s16, #15296
    v.st.w       [s23, #0], v1
    s.movz       s23, #57408
    s.add        s52, s16, s23
    v.ld.w       v1, [s57, #0]
    s.addi       s23, s16, #15360
    v.st.w       [s30, #0], v1
    s.movz       s30, #57472
    s.add        s57, s16, s30
    v.ld.w       v1, [s58, #0]
    s.addi       s30, s16, #15424
    v.st.w       [s32, #0], v1
    s.movz       s32, #57536
    s.add        s58, s16, s32
    v.ld.w       v1, [s59, #0]
    s.addi       s32, s16, #15488
    v.st.w       [s38, #0], v1
    s.movz       s38, #57600
    s.add        s59, s16, s38
    v.ld.w       v1, [s43, #0]
    s.addi       s38, s16, #15552
    v.st.w       [s42, #0], v1
    s.movz       s42, #57664
    s.add        s43, s16, s42
    v.ld.w       v1, [s47, #0]
    s.addi       s42, s16, #15616
    v.st.w       [s28, #0], v1
    fence.acq_rel.device
    s.movz       s28, #57728
    s.add        s47, s16, s28
    v.ld.w       v1, [s48, #0]
    s.addi       s28, s16, #15680
    v.st.w       [s23, #0], v1
    s.movz       s23, #57792
    s.add        s48, s16, s23
    v.ld.w       v1, [s52, #0]
    s.addi       s23, s16, #15744
    v.st.w       [s30, #0], v1
    s.movz       s30, #57856
    s.add        s52, s16, s30
    v.ld.w       v1, [s57, #0]
    s.addi       s30, s16, #15808
    v.st.w       [s32, #0], v1
    s.movz       s32, #57920
    s.add        s57, s16, s32
    v.ld.w       v1, [s58, #0]
    s.addi       s32, s16, #15872
    v.st.w       [s38, #0], v1
    s.movz       s38, #57984
    s.add        s58, s16, s38
    v.ld.w       v1, [s59, #0]
    s.addi       s38, s16, #15936
    v.st.w       [s42, #0], v1
    s.movz       s42, #58048
    s.add        s59, s16, s42
    v.ld.w       v1, [s43, #0]
    s.addi       s42, s16, #16000
    v.st.w       [s28, #0], v1
    s.movz       s28, #58112
    s.add        s43, s16, s28
    v.ld.w       v1, [s47, #0]
    s.addi       s28, s16, #16064
    s.add        s47, s19, s26
    v.st.w       [s23, #0], v1
    s.movz       s23, #58176
    s.add        s60, s16, s23
    v.ld.w       v1, [s48, #0]
    s.addi       s23, s16, #16128
    v.st.w       [s30, #0], v1
    s.movz       s30, #58240
    s.add        s48, s16, s30
    v.ld.w       v1, [s52, #0]
    s.addi       s30, s16, #16192
    v.st.w       [s32, #0], v1
    s.movz       s32, #58304
    s.add        s52, s16, s32
    v.ld.w       v1, [s57, #0]
    s.addi       s32, s16, #16256
    v.st.w       [s38, #0], v1
    s.addi       s38, s16, #16320
    v.ld.w       v1, [s58, #0]
    s.movz       s57, #1
    v.st.w       [s42, #0], v1
    v.ld.w       v1, [s59, #0]
    v.st.w       [s28, #0], v1
    v.ld.w       v1, [s43, #0]
    v.st.w       [s23, #0], v1
    v.ld.w       v1, [s60, #0]
    v.st.w       [s30, #0], v1
    v.ld.w       v1, [s48, #0]
    v.st.w       [s32, #0], v1
    v.ld.w       v1, [s52, #0]
    v.st.w       [s38, #0], v1
    fence.acq_rel.device
    s.mov        s19, s47
    br.nz        s57, for_1
endfor_2:
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.addi       s1, s16, #0
    s.movz       s4, #0
    v.ld.w       v0, [s1, #0]
    s.add        s1, s4, s5                      // the tile origin
    s.muli       s6, s5, #2                      // a runtime tile origin, x2
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v2, s1
    s.add        s1, s4, s2                      // the tile origin
    s.movz       s4, #256
    s.muli       s7, s2, #512                    // a runtime tile origin, x512
    v.splat      v3, s1
    v.splat      v4, s3
    v.add        v5, v1, v2
    v.splat      v2, s4
    s.add        s8, s9, s6                      // the tile origin
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v2
    s.add        s6, s8, s7                      // the tile origin
    p.and        p3, p1, p2
    s.addi       s7, s16, #64
    vf.cvt.f32.bf16 v2, v0
    s.addi       s8, s1, #1
    s.addi       s10, s6, #512                   // row 1
    v.splat      v0, s8
    s.addi       s8, s16, #128
    @p3 v.st.h       [s6, #0], v2
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    s.addi       s11, s1, #2
    s.addi       s12, s6, #1024                  // row 2
    v.splat      v0, s11
    s.addi       s11, s16, #192
    s.addi       s13, s5, #16
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.addi       s14, s5, #32
    s.addi       s15, s5, #48
    s.addi       s19, s2, #16
    s.addi       s21, s6, #1536                  // row 3
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s2, #32
    s.addi       s22, s1, #3
    s.addi       s23, s2, #48
    v.splat      v2, s22
    s.addi       s22, s16, #256
    v.cmp.lt     p1, v2, v4
    p.and        p5, p1, p2
    vf.cvt.f32.bf16 v2, v0
    @p3 v.st.h       [s10, #0], v2
    s.addi       s10, s1, #4
    v.splat      v0, s10
    s.addi       s10, s6, #2048                  // row 4
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s16, #320
    vf.cvt.f32.bf16 v2, v0
    @p4 v.st.h       [s12, #0], v2
    s.addi       s12, s1, #5
    v.splat      v0, s12
    s.addi       s12, s6, #2560                  // row 5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s16, #384
    vf.cvt.f32.bf16 v2, v0
    @p5 v.st.h       [s21, #0], v2
    s.addi       s21, s1, #6
    v.splat      v0, s21
    s.addi       s21, s6, #3072                  // row 6
    v.cmp.lt     p1, v0, v4
    p.and        p5, p1, p2
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s16, #448
    vf.cvt.f32.bf16 v2, v0
    @p3 v.st.h       [s10, #0], v2
    s.addi       s10, s1, #7
    v.splat      v0, s10
    s.addi       s10, s6, #3584                  // row 7
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s16, #512
    vf.cvt.f32.bf16 v2, v0
    @p4 v.st.h       [s12, #0], v2
    s.addi       s12, s1, #8
    v.splat      v0, s12
    s.addi       s12, s6, #4096                  // row 8
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s16, #576
    vf.cvt.f32.bf16 v2, v0
    @p5 v.st.h       [s21, #0], v2
    s.addi       s21, s1, #9
    v.splat      v0, s21
    s.addi       s21, s6, #4608                  // row 9
    v.cmp.lt     p1, v0, v4
    p.and        p5, p1, p2
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s16, #640
    vf.cvt.f32.bf16 v2, v0
    @p3 v.st.h       [s10, #0], v2
    s.addi       s10, s1, #10
    v.splat      v0, s10
    s.addi       s10, s6, #5120                  // row 10
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s16, #704
    vf.cvt.f32.bf16 v2, v0
    @p4 v.st.h       [s12, #0], v2
    s.addi       s12, s1, #11
    v.splat      v0, s12
    s.addi       s12, s6, #5632                  // row 11
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s16, #768
    vf.cvt.f32.bf16 v2, v0
    @p5 v.st.h       [s21, #0], v2
    s.addi       s21, s1, #12
    v.splat      v0, s21
    s.addi       s21, s6, #6144                  // row 12
    v.cmp.lt     p1, v0, v4
    p.and        p5, p1, p2
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s16, #832
    vf.cvt.f32.bf16 v2, v0
    @p3 v.st.h       [s10, #0], v2
    s.addi       s10, s1, #13
    v.splat      v0, s10
    s.addi       s10, s6, #6656                  // row 13
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s16, #896
    vf.cvt.f32.bf16 v2, v0
    v.splat      v0, s1
    v.cmp.lt     p1, v0, v4
    @p4 v.st.h       [s12, #0], v2
    s.addi       s12, s1, #14
    v.splat      v0, s12
    s.addi       s12, s6, #7168                  // row 14
    s.addi       s24, s6, #7680                  // row 15
    v.cmp.lt     p4, v0, v4
    p.and        p6, p4, p2
    v.ld.w       v0, [s11, #0]
    s.addi       s6, s16, #960
    v.splat      v2, s4
    vf.cvt.f32.bf16 v3, v0
    @p5 v.st.h       [s21, #0], v3
    s.addi       s11, s1, #15
    v.splat      v0, s11
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.addi       s11, s16, #1024
    v.cmp.lt     p4, v0, v4
    p.and        p5, p4, p2
    v.ld.w       v0, [s22, #0]
    s.movz       s21, #0
    s.add        s22, s21, s13                   // the tile origin
    v.splat      v3, s22
    s.muli       s21, s13, #2                    // a runtime tile origin, x2
    v.add        v5, v1, v3
    s.add        s22, s9, s21                    // the tile origin
    v.cmp.lt     p4, v5, v2
    p.and        p7, p1, p4
    vf.cvt.f32.bf16 v2, v0
    @p3 v.st.h       [s10, #0], v2
    s.muli       s10, s2, #512                   // a runtime tile origin, x512
    s.add        s21, s22, s10                   // the tile origin
    s.addi       s10, s16, #1088
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #1
    v.splat      v2, s8
    s.addi       s8, s21, #512                   // row 1
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p4
    vf.cvt.f32.bf16 v2, v0
    @p6 v.st.h       [s12, #0], v2
    s.addi       s12, s16, #1152
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s1, #2
    v.splat      v2, s6
    s.addi       s6, s21, #1024                  // row 2
    v.cmp.lt     p1, v2, v4
    p.and        p6, p1, p4
    vf.cvt.f32.bf16 v2, v0
    @p5 v.st.h       [s24, #0], v2
    s.addi       s22, s16, #1216
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s1, #3
    v.splat      v2, s11
    s.addi       s11, s21, #1536                 // row 3
    v.cmp.lt     p1, v2, v4
    p.and        p5, p1, p4
    vf.cvt.f32.bf16 v2, v0
    @p7 v.st.h       [s21, #0], v2
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s16, #1280
    vf.cvt.f32.bf16 v2, v0
    @p3 v.st.h       [s8, #0], v2
    s.addi       s8, s1, #4
    v.splat      v0, s8
    s.addi       s8, s21, #2048                  // row 4
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p4
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s16, #1344
    vf.cvt.f32.bf16 v2, v0
    @p6 v.st.h       [s6, #0], v2
    s.addi       s6, s1, #5
    v.splat      v0, s6
    s.addi       s6, s21, #2560                  // row 5
    v.cmp.lt     p1, v0, v4
    p.and        p6, p1, p4
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s16, #1408
    vf.cvt.f32.bf16 v2, v0
    @p5 v.st.h       [s11, #0], v2
    s.addi       s11, s1, #6
    v.splat      v0, s11
    s.addi       s11, s21, #3072                 // row 6
    v.cmp.lt     p1, v0, v4
    p.and        p5, p1, p4
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s16, #1472
    vf.cvt.f32.bf16 v2, v0
    @p3 v.st.h       [s8, #0], v2
    s.addi       s8, s1, #7
    v.splat      v0, s8
    s.addi       s8, s21, #3584                  // row 7
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p4
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s16, #1536
    vf.cvt.f32.bf16 v2, v0
    @p6 v.st.h       [s6, #0], v2
    s.addi       s6, s1, #8
    v.splat      v0, s6
    s.addi       s6, s21, #4096                  // row 8
    v.cmp.lt     p1, v0, v4
    p.and        p6, p1, p4
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s16, #1600
    vf.cvt.f32.bf16 v2, v0
    @p5 v.st.h       [s11, #0], v2
    s.addi       s11, s1, #9
    v.splat      v0, s11
    s.addi       s11, s21, #4608                 // row 9
    v.cmp.lt     p1, v0, v4
    p.and        p5, p1, p4
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s16, #1664
    vf.cvt.f32.bf16 v2, v0
    @p3 v.st.h       [s8, #0], v2
    s.addi       s8, s1, #10
    v.splat      v0, s8
    s.addi       s8, s21, #5120                  // row 10
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p4
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s16, #1728
    vf.cvt.f32.bf16 v2, v0
    @p6 v.st.h       [s6, #0], v2
    s.addi       s6, s1, #11
    v.splat      v0, s6
    s.addi       s6, s21, #5632                  // row 11
    v.cmp.lt     p1, v0, v4
    p.and        p6, p1, p4
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s16, #1792
    vf.cvt.f32.bf16 v2, v0
    @p5 v.st.h       [s11, #0], v2
    s.addi       s11, s1, #12
    v.splat      v0, s11
    s.addi       s11, s21, #6144                 // row 12
    v.cmp.lt     p1, v0, v4
    p.and        p5, p1, p4
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s16, #1856
    vf.cvt.f32.bf16 v2, v0
    @p3 v.st.h       [s8, #0], v2
    s.addi       s8, s1, #13
    v.splat      v0, s8
    s.addi       s8, s21, #6656                  // row 13
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p4
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s16, #1920
    vf.cvt.f32.bf16 v2, v0
    v.splat      v0, s1
    v.cmp.lt     p1, v0, v4
    @p6 v.st.h       [s6, #0], v2
    s.addi       s6, s1, #14
    v.splat      v0, s6
    s.addi       s6, s21, #7168                  // row 14
    s.addi       s24, s21, #7680                 // row 15
    v.cmp.lt     p6, v0, v4
    p.and        p7, p6, p4
    v.ld.w       v0, [s22, #0]
    s.addi       s21, s16, #1984
    v.splat      v2, s4
    vf.cvt.f32.bf16 v3, v0
    @p5 v.st.h       [s11, #0], v3
    s.addi       s11, s1, #15
    v.splat      v0, s11
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.addi       s11, s16, #2048
    v.cmp.lt     p5, v0, v4
    p.and        p6, p5, p4
    v.ld.w       v0, [s10, #0]
    s.movz       s10, #0
    s.add        s22, s10, s14                   // the tile origin
    v.splat      v3, s22
    s.muli       s10, s14, #2                    // a runtime tile origin, x2
    v.add        v5, v1, v3
    s.add        s22, s9, s10                    // the tile origin
    vf.cvt.f32.bf16 v3, v0
    @p3 v.st.h       [s8, #0], v3
    s.muli       s8, s2, #512                    // a runtime tile origin, x512
    v.cmp.lt     p3, v5, v2
    p.and        p5, p1, p3
    s.add        s10, s22, s8                    // the tile origin
    s.addi       s8, s16, #2112
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s1, #1
    v.splat      v2, s12
    s.addi       s12, s10, #512                  // row 1
    vf.cvt.f32.bf16 v3, v0
    @p7 v.st.h       [s6, #0], v3
    v.cmp.lt     p1, v2, v4
    p.and        p7, p1, p3
    s.addi       s6, s16, #2176
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s1, #2
    v.splat      v2, s21
    s.addi       s21, s10, #1024                 // row 2
    vf.cvt.f32.bf16 v3, v0
    @p6 v.st.h       [s24, #0], v3
    v.cmp.lt     p1, v2, v4
    p.and        p6, p1, p3
    s.addi       s22, s16, #2240
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s1, #3
    v.splat      v2, s11
    s.addi       s11, s10, #1536                 // row 3
    vf.cvt.f32.bf16 v3, v0
    @p5 v.st.h       [s10, #0], v3
    v.cmp.lt     p1, v2, v4
    p.and        p5, p1, p3
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s16, #2304
    vf.cvt.f32.bf16 v2, v0
    @p7 v.st.h       [s12, #0], v2
    s.addi       s12, s1, #4
    v.splat      v0, s12
    s.addi       s12, s10, #2048                 // row 4
    v.cmp.lt     p1, v0, v4
    p.and        p7, p1, p3
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s16, #2368
    vf.cvt.f32.bf16 v2, v0
    @p6 v.st.h       [s21, #0], v2
    s.addi       s21, s1, #5
    v.splat      v0, s21
    s.addi       s21, s10, #2560                 // row 5
    v.cmp.lt     p1, v0, v4
    p.and        p6, p1, p3
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s16, #2432
    vf.cvt.f32.bf16 v2, v0
    @p5 v.st.h       [s11, #0], v2
    s.addi       s11, s1, #6
    v.splat      v0, s11
    s.addi       s11, s10, #3072                 // row 6
    v.cmp.lt     p1, v0, v4
    p.and        p5, p1, p3
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s16, #2496
    vf.cvt.f32.bf16 v2, v0
    @p7 v.st.h       [s12, #0], v2
    s.addi       s12, s1, #7
    v.splat      v0, s12
    s.addi       s12, s10, #3584                 // row 7
    v.cmp.lt     p1, v0, v4
    p.and        p7, p1, p3
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s16, #2560
    vf.cvt.f32.bf16 v2, v0
    @p6 v.st.h       [s21, #0], v2
    s.addi       s21, s1, #8
    v.splat      v0, s21
    s.addi       s21, s10, #4096                 // row 8
    v.cmp.lt     p1, v0, v4
    p.and        p6, p1, p3
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s16, #2624
    vf.cvt.f32.bf16 v2, v0
    @p5 v.st.h       [s11, #0], v2
    s.addi       s11, s1, #9
    v.splat      v0, s11
    s.addi       s11, s10, #4608                 // row 9
    v.cmp.lt     p1, v0, v4
    p.and        p5, p1, p3
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s16, #2688
    vf.cvt.f32.bf16 v2, v0
    @p7 v.st.h       [s12, #0], v2
    s.addi       s12, s1, #10
    v.splat      v0, s12
    s.addi       s12, s10, #5120                 // row 10
    v.cmp.lt     p1, v0, v4
    p.and        p7, p1, p3
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s16, #2752
    vf.cvt.f32.bf16 v2, v0
    @p6 v.st.h       [s21, #0], v2
    s.addi       s21, s1, #11
    v.splat      v0, s21
    s.addi       s21, s10, #5632                 // row 11
    v.cmp.lt     p1, v0, v4
    p.and        p6, p1, p3
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s16, #2816
    vf.cvt.f32.bf16 v2, v0
    @p5 v.st.h       [s11, #0], v2
    s.addi       s11, s1, #12
    v.splat      v0, s11
    s.addi       s11, s10, #6144                 // row 12
    v.cmp.lt     p1, v0, v4
    p.and        p5, p1, p3
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s16, #2880
    vf.cvt.f32.bf16 v2, v0
    @p7 v.st.h       [s12, #0], v2
    s.addi       s12, s1, #13
    s.muli       s24, s2, #512                   // a runtime tile origin, x512
    v.splat      v0, s12
    s.addi       s2, s10, #6656                  // row 13
    v.cmp.lt     p1, v0, v4
    p.and        p7, p1, p3
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s16, #2944
    vf.cvt.f32.bf16 v2, v0
    v.splat      v0, s1
    @p6 v.st.h       [s21, #0], v2
    s.addi       s12, s1, #14
    v.cmp.lt     p1, v0, v4
    v.splat      v0, s12
    s.addi       s12, s10, #7168                 // row 14
    s.addi       s21, s10, #7680                 // row 15
    v.ld.w       v2, [s22, #0]
    s.addi       s10, s16, #3008
    v.splat      v3, s4
    s.addi       s4, s1, #15
    v.splat      v5, s4
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.addi       s4, s16, #3072
    vf.cvt.f32.bf16 v6, v2
    @p5 v.st.h       [s11, #0], v6
    v.cmp.lt     p5, v0, v4
    p.and        p6, p5, p3
    s.movz       s11, #0
    s.add        s22, s11, s15                   // the tile origin
    v.splat      v0, s22
    s.muli       s11, s15, #2                    // a runtime tile origin, x2
    v.add        v2, v1, v0
    s.add        s22, s9, s11                    // the tile origin
    v.ld.w       v0, [s8, #0]
    s.add        s8, s22, s24                    // the tile origin
    s.addi       s11, s16, #3136
    s.addi       s22, s1, #1
    v.splat      v1, s22
    s.addi       s22, s8, #512                   // row 1
    vf.cvt.f32.bf16 v6, v0
    @p7 v.st.h       [s2, #0], v6
    v.cmp.lt     p5, v5, v4
    p.and        p7, p5, p3
    s.addi       s2, s16, #3200
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s1, #2
    v.splat      v5, s6
    s.addi       s6, s8, #1024                   // row 2
    vf.cvt.f32.bf16 v6, v0
    @p6 v.st.h       [s12, #0], v6
    v.cmp.lt     p5, v2, v3
    p.and        p6, p1, p5
    s.addi       s12, s16, #3264
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s1, #3
    v.splat      v2, s10
    s.addi       s10, s8, #1536                  // row 3
    vf.cvt.f32.bf16 v3, v0
    @p7 v.st.h       [s21, #0], v3
    v.cmp.lt     p1, v1, v4
    p.and        p7, p1, p5
    s.addi       s21, s16, #3328
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s1, #4
    v.splat      v1, s4
    s.addi       s4, s8, #2048                   // row 4
    vf.cvt.f32.bf16 v3, v0
    @p6 v.st.h       [s8, #0], v3
    v.cmp.lt     p1, v5, v4
    p.and        p6, p1, p5
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s16, #3392
    vf.cvt.f32.bf16 v3, v0
    @p7 v.st.h       [s22, #0], v3
    v.cmp.lt     p1, v2, v4
    p.and        p7, p1, p5
    s.addi       s22, s1, #5
    v.splat      v0, s22
    s.addi       s22, s8, #2560                  // row 5
    v.ld.w       v2, [s2, #0]
    s.addi       s2, s16, #3456
    vf.cvt.f32.bf16 v3, v2
    @p6 v.st.h       [s6, #0], v3
    v.cmp.lt     p1, v1, v4
    p.and        p6, p1, p5
    s.addi       s6, s1, #6
    v.splat      v1, s6
    s.addi       s6, s8, #3072                   // row 6
    v.ld.w       v2, [s12, #0]
    s.addi       s12, s16, #3520
    vf.cvt.f32.bf16 v3, v2
    @p7 v.st.h       [s10, #0], v3
    v.cmp.lt     p1, v0, v4
    p.and        p7, p1, p5
    s.addi       s10, s1, #7
    v.splat      v0, s10
    s.addi       s10, s8, #3584                  // row 7
    v.ld.w       v2, [s21, #0]
    s.addi       s21, s16, #3584
    vf.cvt.f32.bf16 v3, v2
    @p6 v.st.h       [s4, #0], v3
    v.cmp.lt     p1, v1, v4
    p.and        p6, p1, p5
    s.addi       s4, s1, #8
    v.splat      v1, s4
    s.addi       s4, s8, #4096                   // row 8
    v.ld.w       v2, [s11, #0]
    s.addi       s11, s16, #3648
    vf.cvt.f32.bf16 v3, v2
    @p7 v.st.h       [s22, #0], v3
    v.cmp.lt     p1, v0, v4
    p.and        p7, p1, p5
    s.addi       s22, s1, #9
    v.splat      v0, s22
    s.addi       s22, s8, #4608                  // row 9
    v.ld.w       v2, [s2, #0]
    s.addi       s2, s16, #3712
    vf.cvt.f32.bf16 v3, v2
    @p6 v.st.h       [s6, #0], v3
    v.cmp.lt     p1, v1, v4
    p.and        p6, p1, p5
    s.addi       s6, s1, #10
    v.splat      v1, s6
    s.addi       s6, s8, #5120                   // row 10
    v.ld.w       v2, [s12, #0]
    s.addi       s12, s16, #3776
    vf.cvt.f32.bf16 v3, v2
    @p7 v.st.h       [s10, #0], v3
    v.cmp.lt     p1, v0, v4
    p.and        p7, p1, p5
    s.addi       s10, s1, #11
    v.splat      v0, s10
    s.addi       s10, s8, #5632                  // row 11
    v.ld.w       v2, [s21, #0]
    s.addi       s21, s16, #3840
    vf.cvt.f32.bf16 v3, v2
    @p6 v.st.h       [s4, #0], v3
    v.cmp.lt     p1, v1, v4
    p.and        p6, p1, p5
    s.addi       s4, s1, #12
    v.splat      v1, s4
    s.addi       s4, s8, #6144                   // row 12
    v.ld.w       v2, [s11, #0]
    s.addi       s11, s16, #3904
    vf.cvt.f32.bf16 v3, v2
    @p7 v.st.h       [s22, #0], v3
    v.cmp.lt     p1, v0, v4
    p.and        p7, p1, p5
    s.addi       s22, s1, #13
    v.splat      v0, s22
    s.addi       s22, s8, #6656                  // row 13
    v.ld.w       v2, [s2, #0]
    s.addi       s2, s16, #3968
    vf.cvt.f32.bf16 v3, v2
    @p6 v.st.h       [s6, #0], v3
    v.cmp.lt     p1, v1, v4
    p.and        p6, p1, p5
    s.addi       s6, s1, #14
    s.addi       s24, s1, #15
    v.splat      v1, s6
    s.addi       s1, s8, #7168                   // row 14
    v.splat      v2, s24
    s.addi       s6, s16, #4032
    s.addi       s24, s8, #7680                  // row 15
    v.ld.w       v3, [s12, #0]
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.addi       s8, s16, #4096
    vf.cvt.f32.bf16 v5, v3
    v.splat      v3, s3
    @p7 v.st.h       [s10, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p7, p1, p5
    s.movz       s10, #0
    s.add        s12, s10, s19                   // the tile origin
    v.splat      v0, s12
    v.ld.w       v5, [s21, #0]
    s.muli       s10, s5, #2                     // a runtime tile origin, x2
    s.add        s21, s9, s10                    // the tile origin
    vf.cvt.f32.bf16 v6, v5
    @p6 v.st.h       [s4, #0], v6
    v.cmp.lt     p1, v1, v4
    p.and        p6, p1, p5
    s.muli       s4, s19, #512                   // a runtime tile origin, x512
    s.add        s10, s21, s4                    // the tile origin
    s.addi       s4, s16, #4160
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s12, #1
    v.splat      v5, s11
    s.addi       s11, s10, #512                  // row 1
    vf.cvt.f32.bf16 v6, v1
    @p7 v.st.h       [s22, #0], v6
    v.cmp.lt     p1, v2, v4
    p.and        p7, p1, p5
    s.addi       s21, s16, #4224
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s12, #2
    v.splat      v2, s2
    s.addi       s2, s10, #1024                  // row 2
    vf.cvt.f32.bf16 v4, v1
    @p6 v.st.h       [s1, #0], v4
    v.cmp.lt     p1, v0, v3
    p.and        p6, p1, p2
    s.addi       s1, s16, #4288
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s12, #3
    v.splat      v1, s6
    s.addi       s6, s10, #1536                  // row 3
    vf.cvt.f32.bf16 v4, v0
    @p7 v.st.h       [s24, #0], v4
    v.cmp.lt     p1, v5, v3
    p.and        p7, p1, p2
    s.addi       s22, s16, #4352
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s12, #4
    v.splat      v4, s8
    s.addi       s8, s10, #2048                  // row 4
    vf.cvt.f32.bf16 v5, v0
    @p6 v.st.h       [s10, #0], v5
    v.cmp.lt     p1, v2, v3
    p.and        p6, p1, p2
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s16, #4416
    vf.cvt.f32.bf16 v2, v0
    @p7 v.st.h       [s11, #0], v2
    v.cmp.lt     p1, v1, v3
    p.and        p7, p1, p2
    s.addi       s11, s12, #5
    v.splat      v0, s11
    s.addi       s11, s10, #2560                 // row 5
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s16, #4480
    vf.cvt.f32.bf16 v2, v1
    @p6 v.st.h       [s2, #0], v2
    v.cmp.lt     p1, v4, v3
    p.and        p6, p1, p2
    s.addi       s2, s12, #6
    v.splat      v1, s2
    s.addi       s2, s10, #3072                  // row 6
    v.ld.w       v2, [s1, #0]
    s.addi       s1, s16, #4544
    vf.cvt.f32.bf16 v4, v2
    @p7 v.st.h       [s6, #0], v4
    v.cmp.lt     p1, v0, v3
    p.and        p7, p1, p2
    s.addi       s6, s12, #7
    v.splat      v0, s6
    s.addi       s6, s10, #3584                  // row 7
    v.ld.w       v2, [s22, #0]
    s.addi       s22, s16, #4608
    vf.cvt.f32.bf16 v4, v2
    @p6 v.st.h       [s8, #0], v4
    v.cmp.lt     p1, v1, v3
    p.and        p6, p1, p2
    s.addi       s8, s12, #8
    v.splat      v1, s8
    s.addi       s8, s10, #4096                  // row 8
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s16, #4672
    vf.cvt.f32.bf16 v4, v2
    @p7 v.st.h       [s11, #0], v4
    v.cmp.lt     p1, v0, v3
    p.and        p7, p1, p2
    s.addi       s11, s12, #9
    v.splat      v0, s11
    s.addi       s11, s10, #4608                 // row 9
    v.ld.w       v2, [s21, #0]
    s.addi       s21, s16, #4736
    vf.cvt.f32.bf16 v4, v2
    @p6 v.st.h       [s2, #0], v4
    v.cmp.lt     p1, v1, v3
    p.and        p6, p1, p2
    s.addi       s2, s12, #10
    v.splat      v1, s2
    s.addi       s2, s10, #5120                  // row 10
    v.ld.w       v2, [s1, #0]
    s.addi       s1, s16, #4800
    vf.cvt.f32.bf16 v4, v2
    @p7 v.st.h       [s6, #0], v4
    v.cmp.lt     p1, v0, v3
    p.and        p7, p1, p2
    s.addi       s6, s12, #11
    v.splat      v0, s6
    s.addi       s6, s10, #5632                  // row 11
    v.ld.w       v2, [s22, #0]
    s.addi       s22, s16, #4864
    vf.cvt.f32.bf16 v4, v2
    @p6 v.st.h       [s8, #0], v4
    v.cmp.lt     p1, v1, v3
    p.and        p6, p1, p2
    s.addi       s8, s12, #12
    v.splat      v1, s8
    s.addi       s8, s10, #6144                  // row 12
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s16, #4928
    vf.cvt.f32.bf16 v4, v2
    @p7 v.st.h       [s11, #0], v4
    v.cmp.lt     p1, v0, v3
    p.and        p7, p1, p2
    s.addi       s11, s12, #13
    v.splat      v0, s11
    s.addi       s11, s10, #6656                 // row 13
    v.ld.w       v2, [s21, #0]
    s.addi       s21, s16, #4992
    vf.cvt.f32.bf16 v4, v2
    @p6 v.st.h       [s2, #0], v4
    v.cmp.lt     p1, v1, v3
    p.and        p6, p1, p2
    s.addi       s2, s12, #14
    v.splat      v1, s2
    s.addi       s2, s10, #7168                  // row 14
    s.addi       s24, s10, #7680                 // row 15
    v.ld.w       v2, [s1, #0]
    s.addi       s1, s16, #5056
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s12
    @p7 v.st.h       [s6, #0], v4
    v.cmp.lt     p1, v0, v3
    p.and        p7, p1, p2
    s.addi       s6, s12, #15
    v.splat      v0, s6
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.addi       s6, s16, #5120
    v.ld.w       v4, [s22, #0]
    s.muli       s10, s13, #2                    // a runtime tile origin, x2
    s.add        s22, s9, s10                    // the tile origin
    vf.cvt.f32.bf16 v5, v4
    @p6 v.st.h       [s8, #0], v5
    v.cmp.lt     p1, v1, v3
    p.and        p6, p1, p2
    s.muli       s8, s19, #512                   // a runtime tile origin, x512
    s.add        s10, s22, s8                    // the tile origin
    s.addi       s8, s16, #5184
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s12, #1
    v.splat      v4, s4
    s.addi       s4, s10, #512                   // row 1
    vf.cvt.f32.bf16 v5, v1
    @p7 v.st.h       [s11, #0], v5
    v.cmp.lt     p1, v0, v3
    p.and        p7, p1, p2
    s.addi       s11, s16, #5248
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s12, #2
    v.splat      v1, s21
    s.addi       s21, s10, #1024                 // row 2
    vf.cvt.f32.bf16 v5, v0
    @p6 v.st.h       [s2, #0], v5
    v.cmp.lt     p1, v2, v3
    p.and        p6, p1, p4
    s.addi       s2, s16, #5312
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s12, #3
    v.splat      v2, s1
    s.addi       s1, s10, #1536                  // row 3
    vf.cvt.f32.bf16 v5, v0
    @p7 v.st.h       [s24, #0], v5
    v.cmp.lt     p1, v4, v3
    p.and        p7, p1, p4
    s.addi       s22, s16, #5376
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s12, #4
    v.splat      v4, s6
    s.addi       s6, s10, #2048                  // row 4
    vf.cvt.f32.bf16 v5, v0
    @p6 v.st.h       [s10, #0], v5
    v.cmp.lt     p1, v1, v3
    p.and        p6, p1, p4
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s16, #5440
    vf.cvt.f32.bf16 v1, v0
    @p7 v.st.h       [s4, #0], v1
    v.cmp.lt     p1, v2, v3
    p.and        p7, p1, p4
    s.addi       s4, s12, #5
    v.splat      v0, s4
    s.addi       s4, s10, #2560                  // row 5
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s16, #5504
    vf.cvt.f32.bf16 v2, v1
    @p6 v.st.h       [s21, #0], v2
    v.cmp.lt     p1, v4, v3
    p.and        p6, p1, p4
    s.addi       s21, s12, #6
    v.splat      v1, s21
    s.addi       s21, s10, #3072                 // row 6
    v.ld.w       v2, [s2, #0]
    s.addi       s2, s16, #5568
    vf.cvt.f32.bf16 v4, v2
    @p7 v.st.h       [s1, #0], v4
    v.cmp.lt     p1, v0, v3
    p.and        p7, p1, p4
    s.addi       s1, s12, #7
    v.splat      v0, s1
    s.addi       s1, s10, #3584                  // row 7
    v.ld.w       v2, [s22, #0]
    s.addi       s22, s16, #5632
    vf.cvt.f32.bf16 v4, v2
    @p6 v.st.h       [s6, #0], v4
    v.cmp.lt     p1, v1, v3
    p.and        p6, p1, p4
    s.addi       s6, s12, #8
    v.splat      v1, s6
    s.addi       s6, s10, #4096                  // row 8
    v.ld.w       v2, [s8, #0]
    s.addi       s8, s16, #5696
    vf.cvt.f32.bf16 v4, v2
    @p7 v.st.h       [s4, #0], v4
    v.cmp.lt     p1, v0, v3
    p.and        p7, p1, p4
    s.addi       s4, s12, #9
    v.splat      v0, s4
    s.addi       s4, s10, #4608                  // row 9
    v.ld.w       v2, [s11, #0]
    s.addi       s11, s16, #5760
    vf.cvt.f32.bf16 v4, v2
    @p6 v.st.h       [s21, #0], v4
    v.cmp.lt     p1, v1, v3
    p.and        p6, p1, p4
    s.addi       s21, s12, #10
    v.splat      v1, s21
    s.addi       s21, s10, #5120                 // row 10
    v.ld.w       v2, [s2, #0]
    s.addi       s2, s16, #5824
    vf.cvt.f32.bf16 v4, v2
    @p7 v.st.h       [s1, #0], v4
    v.cmp.lt     p1, v0, v3
    p.and        p7, p1, p4
    s.addi       s1, s12, #11
    v.splat      v0, s1
    s.addi       s1, s10, #5632                  // row 11
    v.ld.w       v2, [s22, #0]
    s.addi       s22, s16, #5888
    vf.cvt.f32.bf16 v4, v2
    @p6 v.st.h       [s6, #0], v4
    v.cmp.lt     p1, v1, v3
    p.and        p6, p1, p4
    s.addi       s6, s12, #12
    v.splat      v1, s6
    s.addi       s6, s10, #6144                  // row 12
    v.ld.w       v2, [s8, #0]
    s.addi       s8, s16, #5952
    vf.cvt.f32.bf16 v4, v2
    @p7 v.st.h       [s4, #0], v4
    v.cmp.lt     p1, v0, v3
    p.and        p7, p1, p4
    s.addi       s4, s12, #13
    v.splat      v0, s4
    s.addi       s4, s10, #6656                  // row 13
    v.ld.w       v2, [s11, #0]
    s.addi       s11, s16, #6016
    vf.cvt.f32.bf16 v4, v2
    @p6 v.st.h       [s21, #0], v4
    v.cmp.lt     p1, v1, v3
    p.and        p6, p1, p4
    s.addi       s21, s12, #14
    v.splat      v1, s21
    s.addi       s21, s10, #7168                 // row 14
    s.addi       s24, s10, #7680                 // row 15
    v.ld.w       v2, [s2, #0]
    s.addi       s2, s16, #6080
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s12
    @p7 v.st.h       [s1, #0], v4
    v.cmp.lt     p1, v0, v3
    p.and        p7, p1, p4
    s.addi       s1, s12, #15
    v.splat      v0, s1
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.addi       s1, s16, #6144
    v.ld.w       v4, [s22, #0]
    s.muli       s10, s14, #2                    // a runtime tile origin, x2
    s.add        s22, s9, s10                    // the tile origin
    vf.cvt.f32.bf16 v5, v4
    @p6 v.st.h       [s6, #0], v5
    v.cmp.lt     p1, v1, v3
    p.and        p6, p1, p4
    s.muli       s6, s19, #512                   // a runtime tile origin, x512
    s.add        s10, s22, s6                    // the tile origin
    s.addi       s6, s16, #6208
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s12, #1
    v.splat      v4, s8
    s.addi       s8, s10, #512                   // row 1
    vf.cvt.f32.bf16 v5, v1
    @p7 v.st.h       [s4, #0], v5
    v.cmp.lt     p1, v0, v3
    p.and        p7, p1, p4
    s.addi       s4, s16, #6272
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s12, #2
    v.splat      v1, s11
    s.addi       s11, s10, #1024                 // row 2
    vf.cvt.f32.bf16 v5, v0
    @p6 v.st.h       [s21, #0], v5
    v.cmp.lt     p1, v2, v3
    p.and        p6, p1, p3
    s.addi       s21, s16, #6336
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s12, #3
    v.splat      v2, s2
    s.addi       s2, s10, #1536                  // row 3
    vf.cvt.f32.bf16 v5, v0
    @p7 v.st.h       [s24, #0], v5
    v.cmp.lt     p1, v4, v3
    p.and        p7, p1, p3
    s.addi       s22, s16, #6400
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s12, #4
    v.splat      v4, s1
    s.addi       s1, s10, #2048                  // row 4
    vf.cvt.f32.bf16 v5, v0
    @p6 v.st.h       [s10, #0], v5
    v.cmp.lt     p1, v1, v3
    p.and        p6, p1, p3
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s16, #6464
    vf.cvt.f32.bf16 v1, v0
    @p7 v.st.h       [s8, #0], v1
    v.cmp.lt     p1, v2, v3
    p.and        p7, p1, p3
    s.addi       s8, s12, #5
    v.splat      v0, s8
    s.addi       s8, s10, #2560                  // row 5
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s16, #6528
    vf.cvt.f32.bf16 v2, v1
    @p6 v.st.h       [s11, #0], v2
    v.cmp.lt     p1, v4, v3
    p.and        p6, p1, p3
    s.addi       s11, s12, #6
    v.splat      v1, s11
    s.addi       s11, s10, #3072                 // row 6
    v.ld.w       v2, [s21, #0]
    s.addi       s21, s16, #6592
    vf.cvt.f32.bf16 v4, v2
    @p7 v.st.h       [s2, #0], v4
    v.cmp.lt     p1, v0, v3
    p.and        p7, p1, p3
    s.addi       s2, s12, #7
    v.splat      v0, s2
    s.addi       s2, s10, #3584                  // row 7
    v.ld.w       v2, [s22, #0]
    s.addi       s22, s16, #6656
    vf.cvt.f32.bf16 v4, v2
    @p6 v.st.h       [s1, #0], v4
    v.cmp.lt     p1, v1, v3
    p.and        p6, p1, p3
    s.addi       s1, s12, #8
    v.splat      v1, s1
    s.addi       s1, s10, #4096                  // row 8
    v.ld.w       v2, [s6, #0]
    s.addi       s6, s16, #6720
    vf.cvt.f32.bf16 v4, v2
    @p7 v.st.h       [s8, #0], v4
    v.cmp.lt     p1, v0, v3
    p.and        p7, p1, p3
    s.addi       s8, s12, #9
    v.splat      v0, s8
    s.addi       s8, s10, #4608                  // row 9
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s16, #6784
    vf.cvt.f32.bf16 v4, v2
    @p6 v.st.h       [s11, #0], v4
    v.cmp.lt     p1, v1, v3
    p.and        p6, p1, p3
    s.addi       s11, s12, #10
    v.splat      v1, s11
    s.addi       s11, s10, #5120                 // row 10
    v.ld.w       v2, [s21, #0]
    s.addi       s21, s16, #6848
    vf.cvt.f32.bf16 v4, v2
    @p7 v.st.h       [s2, #0], v4
    v.cmp.lt     p1, v0, v3
    p.and        p7, p1, p3
    s.addi       s2, s12, #11
    v.splat      v0, s2
    s.addi       s2, s10, #5632                  // row 11
    v.ld.w       v2, [s22, #0]
    s.addi       s22, s16, #6912
    vf.cvt.f32.bf16 v4, v2
    @p6 v.st.h       [s1, #0], v4
    v.cmp.lt     p1, v1, v3
    p.and        p6, p1, p3
    s.addi       s1, s12, #12
    v.splat      v1, s1
    s.addi       s1, s10, #6144                  // row 12
    v.ld.w       v2, [s6, #0]
    s.addi       s6, s16, #6976
    vf.cvt.f32.bf16 v4, v2
    @p7 v.st.h       [s8, #0], v4
    v.cmp.lt     p1, v0, v3
    p.and        p7, p1, p3
    s.addi       s8, s12, #13
    v.splat      v0, s8
    s.addi       s8, s10, #6656                  // row 13
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s16, #7040
    vf.cvt.f32.bf16 v4, v2
    @p6 v.st.h       [s11, #0], v4
    v.cmp.lt     p1, v1, v3
    p.and        p6, p1, p3
    s.addi       s11, s12, #14
    s.muli       s24, s19, #512                  // a runtime tile origin, x512
    v.splat      v1, s11
    s.addi       s11, s10, #7168                 // row 14
    s.addi       s19, s10, #7680                 // row 15
    v.ld.w       v2, [s21, #0]
    s.addi       s10, s16, #7104
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s12
    @p7 v.st.h       [s2, #0], v4
    v.cmp.lt     p1, v0, v3
    p.and        p7, p1, p3
    s.addi       s2, s12, #15
    v.splat      v0, s2
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.addi       s2, s16, #7168
    v.ld.w       v4, [s22, #0]
    s.muli       s21, s15, #2                    // a runtime tile origin, x2
    s.add        s22, s9, s21                    // the tile origin
    s.add        s21, s22, s24                   // the tile origin
    s.addi       s22, s16, #7232
    vf.cvt.f32.bf16 v5, v4
    @p6 v.st.h       [s1, #0], v5
    v.cmp.lt     p1, v1, v3
    p.and        p6, p1, p3
    s.addi       s1, s12, #1
    v.splat      v1, s1
    s.addi       s1, s21, #512                   // row 1
    v.ld.w       v4, [s6, #0]
    s.addi       s6, s16, #7296
    vf.cvt.f32.bf16 v5, v4
    @p7 v.st.h       [s8, #0], v5
    v.cmp.lt     p1, v0, v3
    p.and        p7, p1, p3
    s.addi       s8, s12, #2
    v.splat      v0, s8
    s.addi       s8, s21, #1024                  // row 2
    v.ld.w       v4, [s4, #0]
    s.addi       s4, s16, #7360
    vf.cvt.f32.bf16 v5, v4
    @p6 v.st.h       [s11, #0], v5
    v.cmp.lt     p1, v2, v3
    p.and        p6, p1, p5
    s.addi       s11, s12, #3
    v.splat      v2, s11
    s.addi       s11, s21, #1536                 // row 3
    v.ld.w       v4, [s10, #0]
    s.addi       s10, s16, #7424
    vf.cvt.f32.bf16 v5, v4
    @p7 v.st.h       [s19, #0], v5
    v.cmp.lt     p1, v1, v3
    p.and        p7, p1, p5
    s.addi       s19, s12, #4
    v.splat      v1, s19
    s.addi       s19, s21, #2048                 // row 4
    v.ld.w       v4, [s2, #0]
    s.addi       s2, s16, #7488
    vf.cvt.f32.bf16 v5, v4
    @p6 v.st.h       [s21, #0], v5
    v.cmp.lt     p1, v0, v3
    p.and        p6, p1, p5
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s12, #5
    v.splat      v4, s22
    s.addi       s22, s21, #2560                 // row 5
    vf.cvt.f32.bf16 v5, v0
    @p7 v.st.h       [s1, #0], v5
    v.cmp.lt     p1, v2, v3
    p.and        p7, p1, p5
    s.addi       s1, s16, #7552
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s12, #6
    v.splat      v2, s6
    s.addi       s6, s21, #3072                  // row 6
    vf.cvt.f32.bf16 v5, v0
    @p6 v.st.h       [s8, #0], v5
    v.cmp.lt     p1, v1, v3
    p.and        p6, p1, p5
    s.addi       s8, s16, #7616
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s12, #7
    v.splat      v1, s4
    s.addi       s4, s21, #3584                  // row 7
    vf.cvt.f32.bf16 v5, v0
    @p7 v.st.h       [s11, #0], v5
    v.cmp.lt     p1, v4, v3
    p.and        p7, p1, p5
    s.addi       s11, s16, #7680
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s12, #8
    v.splat      v4, s10
    s.addi       s10, s21, #4096                 // row 8
    vf.cvt.f32.bf16 v5, v0
    @p6 v.st.h       [s19, #0], v5
    v.cmp.lt     p1, v2, v3
    p.and        p6, p1, p5
    s.addi       s19, s16, #7744
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s12, #9
    v.splat      v2, s2
    s.addi       s2, s21, #4608                  // row 9
    vf.cvt.f32.bf16 v5, v0
    @p7 v.st.h       [s22, #0], v5
    v.cmp.lt     p1, v1, v3
    p.and        p7, p1, p5
    s.addi       s22, s16, #7808
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s12, #10
    v.splat      v1, s1
    s.addi       s1, s21, #5120                  // row 10
    vf.cvt.f32.bf16 v5, v0
    @p6 v.st.h       [s6, #0], v5
    v.cmp.lt     p1, v4, v3
    p.and        p6, p1, p5
    s.addi       s6, s16, #7872
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s12, #11
    v.splat      v4, s8
    s.addi       s8, s21, #5632                  // row 11
    vf.cvt.f32.bf16 v5, v0
    @p7 v.st.h       [s4, #0], v5
    v.cmp.lt     p1, v2, v3
    p.and        p7, p1, p5
    s.addi       s4, s16, #7936
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s12, #12
    v.splat      v2, s11
    s.addi       s11, s21, #6144                 // row 12
    vf.cvt.f32.bf16 v5, v0
    @p6 v.st.h       [s10, #0], v5
    v.cmp.lt     p1, v1, v3
    p.and        p6, p1, p5
    s.addi       s10, s16, #8000
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #13
    v.splat      v1, s19
    s.addi       s19, s21, #6656                 // row 13
    vf.cvt.f32.bf16 v5, v0
    @p7 v.st.h       [s2, #0], v5
    v.cmp.lt     p1, v4, v3
    p.and        p7, p1, p5
    s.addi       s2, s16, #8064
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s12, #14
    s.addi       s24, s12, #15
    v.splat      v4, s22
    s.addi       s12, s21, #7168                 // row 14
    s.addi       s22, s21, #7680                 // row 15
    vf.cvt.f32.bf16 v5, v0
    v.splat      v0, s24
    s.addi       s21, s16, #8128
    @p6 v.st.h       [s1, #0], v5
    v.cmp.lt     p1, v2, v3
    p.and        p6, p1, p5
    s.muli       s1, s5, #2                      // a runtime tile origin, x2
    s.add        s24, s9, s1                     // the tile origin
    v.ld.w       v2, [s6, #0]
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.addi       s1, s16, #8192
    vf.cvt.f32.bf16 v5, v2
    v.splat      v2, s3
    @p7 v.st.h       [s8, #0], v5
    v.cmp.lt     p1, v1, v3
    p.and        p7, p1, p5
    s.movz       s6, #0
    s.add        s8, s6, s7                      // the tile origin
    v.splat      v1, s8
    v.ld.w       v5, [s4, #0]
    s.muli       s4, s7, #512                    // a runtime tile origin, x512
    s.add        s6, s24, s4                     // the tile origin
    vf.cvt.f32.bf16 v6, v5
    s.addi       s4, s16, #8256
    @p6 v.st.h       [s11, #0], v6
    v.cmp.lt     p1, v4, v3
    p.and        p6, p1, p5
    s.addi       s11, s8, #1
    v.splat      v4, s11
    s.addi       s11, s6, #512                   // row 1
    v.ld.w       v5, [s10, #0]
    vf.cvt.f32.bf16 v6, v5
    s.addi       s10, s16, #8320
    @p7 v.st.h       [s19, #0], v6
    v.cmp.lt     p1, v0, v3
    p.and        p7, p1, p5
    s.addi       s19, s8, #2
    v.splat      v0, s19
    s.addi       s19, s6, #1024                  // row 2
    v.ld.w       v3, [s2, #0]
    vf.cvt.f32.bf16 v5, v3
    s.addi       s2, s16, #8384
    @p6 v.st.h       [s12, #0], v5
    v.cmp.lt     p1, v1, v2
    p.and        p6, p1, p2
    s.addi       s12, s8, #3
    v.splat      v1, s12
    s.addi       s12, s6, #1536                  // row 3
    v.ld.w       v3, [s21, #0]
    vf.cvt.f32.bf16 v5, v3
    s.addi       s21, s16, #8448
    @p7 v.st.h       [s22, #0], v5
    v.cmp.lt     p1, v4, v2
    p.and        p7, p1, p2
    s.addi       s22, s8, #4
    v.splat      v3, s22
    s.addi       s22, s6, #2048                  // row 4
    v.ld.w       v4, [s1, #0]
    s.addi       s1, s16, #8512
    vf.cvt.f32.bf16 v5, v4
    @p6 v.st.h       [s6, #0], v5
    v.cmp.lt     p1, v0, v2
    p.and        p6, p1, p2
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s8, #5
    v.splat      v4, s4
    s.addi       s4, s6, #2560                   // row 5
    vf.cvt.f32.bf16 v5, v0
    @p7 v.st.h       [s11, #0], v5
    v.cmp.lt     p1, v1, v2
    p.and        p7, p1, p2
    s.addi       s11, s16, #8576
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s8, #6
    v.splat      v1, s10
    s.addi       s10, s6, #3072                  // row 6
    vf.cvt.f32.bf16 v5, v0
    @p6 v.st.h       [s19, #0], v5
    v.cmp.lt     p1, v3, v2
    p.and        p6, p1, p2
    s.addi       s19, s16, #8640
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s8, #7
    v.splat      v3, s2
    s.addi       s2, s6, #3584                   // row 7
    vf.cvt.f32.bf16 v5, v0
    @p7 v.st.h       [s12, #0], v5
    v.cmp.lt     p1, v4, v2
    p.and        p7, p1, p2
    s.addi       s12, s16, #8704
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s8, #8
    v.splat      v4, s21
    s.addi       s21, s6, #4096                  // row 8
    vf.cvt.f32.bf16 v5, v0
    @p6 v.st.h       [s22, #0], v5
    v.cmp.lt     p1, v1, v2
    p.and        p6, p1, p2
    s.addi       s22, s16, #8768
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s8, #9
    v.splat      v1, s1
    s.addi       s1, s6, #4608                   // row 9
    vf.cvt.f32.bf16 v5, v0
    @p7 v.st.h       [s4, #0], v5
    v.cmp.lt     p1, v3, v2
    p.and        p7, p1, p2
    s.addi       s4, s16, #8832
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s8, #10
    v.splat      v3, s11
    s.addi       s11, s6, #5120                  // row 10
    vf.cvt.f32.bf16 v5, v0
    @p6 v.st.h       [s10, #0], v5
    v.cmp.lt     p1, v4, v2
    p.and        p6, p1, p2
    s.addi       s10, s16, #8896
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s8, #11
    v.splat      v4, s19
    s.addi       s19, s6, #5632                  // row 11
    vf.cvt.f32.bf16 v5, v0
    @p7 v.st.h       [s2, #0], v5
    v.cmp.lt     p1, v1, v2
    p.and        p7, p1, p2
    s.addi       s2, s16, #8960
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s8, #12
    v.splat      v1, s12
    s.addi       s12, s6, #6144                  // row 12
    vf.cvt.f32.bf16 v5, v0
    @p6 v.st.h       [s21, #0], v5
    v.cmp.lt     p1, v3, v2
    p.and        p6, p1, p2
    s.addi       s21, s16, #9024
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s8, #13
    v.splat      v3, s22
    s.addi       s22, s6, #6656                  // row 13
    vf.cvt.f32.bf16 v5, v0
    @p7 v.st.h       [s1, #0], v5
    v.cmp.lt     p1, v4, v2
    p.and        p7, p1, p2
    s.addi       s1, s16, #9088
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s8, #14
    v.splat      v4, s4
    s.addi       s4, s6, #7168                   // row 14
    s.addi       s24, s6, #7680                  // row 15
    vf.cvt.f32.bf16 v5, v0
    @p6 v.st.h       [s11, #0], v5
    v.cmp.lt     p1, v1, v2
    p.and        p6, p1, p2
    s.addi       s6, s16, #9152
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s8, #15
    v.splat      v1, s10
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.addi       s10, s16, #9216
    vf.cvt.f32.bf16 v5, v0
    v.splat      v0, s8
    @p7 v.st.h       [s19, #0], v5
    v.cmp.lt     p1, v3, v2
    p.and        p7, p1, p2
    s.muli       s11, s13, #2                    // a runtime tile origin, x2
    s.add        s19, s9, s11                    // the tile origin
    v.ld.w       v3, [s2, #0]
    s.muli       s2, s7, #512                    // a runtime tile origin, x512
    s.add        s11, s19, s2                    // the tile origin
    s.addi       s2, s16, #9280
    vf.cvt.f32.bf16 v5, v3
    @p6 v.st.h       [s12, #0], v5
    v.cmp.lt     p1, v4, v2
    p.and        p6, p1, p2
    s.addi       s12, s8, #1
    v.splat      v3, s12
    s.addi       s12, s11, #512                  // row 1
    v.ld.w       v4, [s21, #0]
    s.addi       s19, s16, #9344
    vf.cvt.f32.bf16 v5, v4
    @p7 v.st.h       [s22, #0], v5
    v.cmp.lt     p1, v1, v2
    p.and        p7, p1, p2
    s.addi       s21, s8, #2
    v.splat      v1, s21
    s.addi       s21, s11, #1024                 // row 2
    v.ld.w       v4, [s1, #0]
    s.addi       s1, s16, #9408
    vf.cvt.f32.bf16 v5, v4
    @p6 v.st.h       [s4, #0], v5
    v.cmp.lt     p1, v0, v2
    p.and        p6, p1, p4
    s.addi       s4, s8, #3
    v.splat      v0, s4
    s.addi       s4, s11, #1536                  // row 3
    v.ld.w       v4, [s6, #0]
    s.addi       s6, s16, #9472
    vf.cvt.f32.bf16 v5, v4
    @p7 v.st.h       [s24, #0], v5
    v.cmp.lt     p1, v3, v2
    p.and        p7, p1, p4
    s.addi       s22, s8, #4
    v.splat      v3, s22
    s.addi       s22, s11, #2048                 // row 4
    v.ld.w       v4, [s10, #0]
    s.addi       s10, s16, #9536
    vf.cvt.f32.bf16 v5, v4
    @p6 v.st.h       [s11, #0], v5
    v.cmp.lt     p1, v1, v2
    p.and        p6, p1, p4
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s8, #5
    v.splat      v4, s2
    s.addi       s2, s11, #2560                  // row 5
    vf.cvt.f32.bf16 v5, v1
    @p7 v.st.h       [s12, #0], v5
    v.cmp.lt     p1, v0, v2
    p.and        p7, p1, p4
    s.addi       s12, s16, #9600
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s8, #6
    v.splat      v1, s19
    s.addi       s19, s11, #3072                 // row 6
    vf.cvt.f32.bf16 v5, v0
    @p6 v.st.h       [s21, #0], v5
    v.cmp.lt     p1, v3, v2
    p.and        p6, p1, p4
    s.addi       s21, s16, #9664
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s8, #7
    v.splat      v3, s1
    s.addi       s1, s11, #3584                  // row 7
    vf.cvt.f32.bf16 v5, v0
    @p7 v.st.h       [s4, #0], v5
    v.cmp.lt     p1, v4, v2
    p.and        p7, p1, p4
    s.addi       s4, s16, #9728
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s8, #8
    v.splat      v4, s6
    s.addi       s6, s11, #4096                  // row 8
    vf.cvt.f32.bf16 v5, v0
    @p6 v.st.h       [s22, #0], v5
    v.cmp.lt     p1, v1, v2
    p.and        p6, p1, p4
    s.addi       s22, s16, #9792
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s8, #9
    v.splat      v1, s10
    s.addi       s10, s11, #4608                 // row 9
    vf.cvt.f32.bf16 v5, v0
    @p7 v.st.h       [s2, #0], v5
    v.cmp.lt     p1, v3, v2
    p.and        p7, p1, p4
    s.addi       s2, s16, #9856
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s8, #10
    v.splat      v3, s12
    s.addi       s12, s11, #5120                 // row 10
    vf.cvt.f32.bf16 v5, v0
    @p6 v.st.h       [s19, #0], v5
    v.cmp.lt     p1, v4, v2
    p.and        p6, p1, p4
    s.addi       s19, s16, #9920
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s8, #11
    v.splat      v4, s21
    s.addi       s21, s11, #5632                 // row 11
    vf.cvt.f32.bf16 v5, v0
    @p7 v.st.h       [s1, #0], v5
    v.cmp.lt     p1, v1, v2
    p.and        p7, p1, p4
    s.addi       s1, s16, #9984
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s8, #12
    v.splat      v1, s4
    s.addi       s4, s11, #6144                  // row 12
    vf.cvt.f32.bf16 v5, v0
    @p6 v.st.h       [s6, #0], v5
    v.cmp.lt     p1, v3, v2
    p.and        p6, p1, p4
    s.addi       s6, s16, #10048
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s8, #13
    v.splat      v3, s22
    s.addi       s22, s11, #6656                 // row 13
    vf.cvt.f32.bf16 v5, v0
    @p7 v.st.h       [s10, #0], v5
    v.cmp.lt     p1, v4, v2
    p.and        p7, p1, p4
    s.addi       s10, s16, #10112
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s8, #14
    v.splat      v4, s2
    s.addi       s2, s11, #7168                  // row 14
    s.addi       s24, s11, #7680                 // row 15
    vf.cvt.f32.bf16 v5, v0
    @p6 v.st.h       [s12, #0], v5
    v.cmp.lt     p1, v1, v2
    p.and        p6, p1, p4
    s.addi       s11, s16, #10176
    v.ld.w       v0, [s19, #0]
    s.addi       s12, s8, #15
    v.splat      v1, s12
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.addi       s12, s16, #10240
    vf.cvt.f32.bf16 v5, v0
    v.splat      v0, s8
    @p7 v.st.h       [s21, #0], v5
    v.cmp.lt     p1, v3, v2
    p.and        p7, p1, p4
    s.muli       s19, s14, #2                    // a runtime tile origin, x2
    s.add        s21, s9, s19                    // the tile origin
    v.ld.w       v3, [s1, #0]
    s.muli       s1, s7, #512                    // a runtime tile origin, x512
    s.add        s19, s21, s1                    // the tile origin
    s.addi       s1, s16, #10304
    vf.cvt.f32.bf16 v5, v3
    @p6 v.st.h       [s4, #0], v5
    v.cmp.lt     p1, v4, v2
    p.and        p6, p1, p4
    s.addi       s4, s8, #1
    v.splat      v3, s4
    s.addi       s4, s19, #512                   // row 1
    v.ld.w       v4, [s6, #0]
    s.addi       s6, s16, #10368
    vf.cvt.f32.bf16 v5, v4
    @p7 v.st.h       [s22, #0], v5
    v.cmp.lt     p1, v1, v2
    p.and        p7, p1, p4
    s.addi       s21, s8, #2
    v.splat      v1, s21
    s.addi       s21, s19, #1024                 // row 2
    v.ld.w       v4, [s10, #0]
    s.addi       s10, s16, #10432
    vf.cvt.f32.bf16 v5, v4
    @p6 v.st.h       [s2, #0], v5
    v.cmp.lt     p1, v0, v2
    p.and        p6, p1, p3
    s.addi       s2, s8, #3
    v.splat      v0, s2
    s.addi       s2, s19, #1536                  // row 3
    v.ld.w       v4, [s11, #0]
    s.addi       s11, s16, #10496
    vf.cvt.f32.bf16 v5, v4
    @p7 v.st.h       [s24, #0], v5
    v.cmp.lt     p1, v3, v2
    p.and        p7, p1, p3
    s.addi       s22, s8, #4
    v.splat      v3, s22
    s.addi       s22, s19, #2048                 // row 4
    v.ld.w       v4, [s12, #0]
    s.addi       s12, s16, #10560
    vf.cvt.f32.bf16 v5, v4
    @p6 v.st.h       [s19, #0], v5
    v.cmp.lt     p1, v1, v2
    p.and        p6, p1, p3
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s8, #5
    v.splat      v4, s1
    s.addi       s1, s19, #2560                  // row 5
    vf.cvt.f32.bf16 v5, v1
    @p7 v.st.h       [s4, #0], v5
    v.cmp.lt     p1, v0, v2
    p.and        p7, p1, p3
    s.addi       s4, s16, #10624
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s8, #6
    v.splat      v1, s6
    s.addi       s6, s19, #3072                  // row 6
    vf.cvt.f32.bf16 v5, v0
    @p6 v.st.h       [s21, #0], v5
    v.cmp.lt     p1, v3, v2
    p.and        p6, p1, p3
    s.addi       s21, s16, #10688
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s8, #7
    v.splat      v3, s10
    s.addi       s10, s19, #3584                 // row 7
    vf.cvt.f32.bf16 v5, v0
    @p7 v.st.h       [s2, #0], v5
    v.cmp.lt     p1, v4, v2
    p.and        p7, p1, p3
    s.addi       s2, s16, #10752
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s8, #8
    v.splat      v4, s11
    s.addi       s11, s19, #4096                 // row 8
    vf.cvt.f32.bf16 v5, v0
    @p6 v.st.h       [s22, #0], v5
    v.cmp.lt     p1, v1, v2
    p.and        p6, p1, p3
    s.addi       s22, s16, #10816
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s8, #9
    v.splat      v1, s12
    s.addi       s12, s19, #4608                 // row 9
    vf.cvt.f32.bf16 v5, v0
    @p7 v.st.h       [s1, #0], v5
    v.cmp.lt     p1, v3, v2
    p.and        p7, p1, p3
    s.addi       s1, s16, #10880
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s8, #10
    v.splat      v3, s4
    s.addi       s4, s19, #5120                  // row 10
    vf.cvt.f32.bf16 v5, v0
    @p6 v.st.h       [s6, #0], v5
    v.cmp.lt     p1, v4, v2
    p.and        p6, p1, p3
    s.addi       s6, s16, #10944
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s8, #11
    v.splat      v4, s21
    s.addi       s21, s19, #5632                 // row 11
    vf.cvt.f32.bf16 v5, v0
    @p7 v.st.h       [s10, #0], v5
    v.cmp.lt     p1, v1, v2
    p.and        p7, p1, p3
    s.addi       s10, s16, #11008
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s8, #12
    v.splat      v1, s2
    s.addi       s2, s19, #6144                  // row 12
    vf.cvt.f32.bf16 v5, v0
    @p6 v.st.h       [s11, #0], v5
    v.cmp.lt     p1, v3, v2
    p.and        p6, p1, p3
    s.addi       s11, s16, #11072
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s8, #13
    v.splat      v3, s22
    s.addi       s22, s19, #6656                 // row 13
    vf.cvt.f32.bf16 v5, v0
    @p7 v.st.h       [s12, #0], v5
    v.cmp.lt     p1, v4, v2
    p.and        p7, p1, p3
    s.addi       s12, s16, #11136
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s8, #14
    v.splat      v4, s1
    s.addi       s1, s19, #7168                  // row 14
    s.addi       s24, s19, #7680                 // row 15
    vf.cvt.f32.bf16 v5, v0
    @p6 v.st.h       [s4, #0], v5
    v.cmp.lt     p1, v1, v2
    p.and        p6, p1, p3
    s.addi       s4, s16, #11200
    s.muli       s19, s7, #512                   // a runtime tile origin, x512
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s8, #15
    v.splat      v1, s6
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.addi       s6, s16, #11264
    vf.cvt.f32.bf16 v5, v0
    v.splat      v0, s8
    @p7 v.st.h       [s21, #0], v5
    v.cmp.lt     p1, v3, v2
    p.and        p7, p1, p3
    s.muli       s7, s15, #2                     // a runtime tile origin, x2
    s.add        s21, s9, s7                     // the tile origin
    s.add        s7, s21, s19                    // the tile origin
    s.addi       s19, s16, #11328
    v.ld.w       v3, [s10, #0]
    vf.cvt.f32.bf16 v5, v3
    s.addi       s10, s8, #1
    v.splat      v3, s10
    s.addi       s10, s7, #512                   // row 1
    @p6 v.st.h       [s2, #0], v5
    v.cmp.lt     p1, v4, v2
    p.and        p6, p1, p3
    s.addi       s2, s16, #11392
    v.ld.w       v4, [s11, #0]
    vf.cvt.f32.bf16 v5, v4
    s.addi       s11, s8, #2
    v.splat      v4, s11
    s.addi       s11, s7, #1024                  // row 2
    @p7 v.st.h       [s22, #0], v5
    v.cmp.lt     p1, v1, v2
    p.and        p7, p1, p3
    s.addi       s21, s16, #11456
    v.ld.w       v1, [s12, #0]
    vf.cvt.f32.bf16 v5, v1
    s.addi       s12, s8, #3
    v.splat      v1, s12
    s.addi       s12, s7, #1536                  // row 3
    @p6 v.st.h       [s1, #0], v5
    v.cmp.lt     p1, v0, v2
    p.and        p6, p1, p5
    s.addi       s1, s16, #11520
    v.ld.w       v0, [s4, #0]
    vf.cvt.f32.bf16 v5, v0
    s.addi       s4, s8, #4
    v.splat      v0, s4
    s.addi       s4, s7, #2048                   // row 4
    @p7 v.st.h       [s24, #0], v5
    v.cmp.lt     p1, v3, v2
    p.and        p7, p1, p5
    s.addi       s22, s16, #11584
    v.ld.w       v3, [s6, #0]
    s.addi       s6, s8, #5
    v.splat      v5, s6
    s.addi       s6, s7, #2560                   // row 5
    vf.cvt.f32.bf16 v6, v3
    @p6 v.st.h       [s7, #0], v6
    v.cmp.lt     p1, v4, v2
    p.and        p6, p1, p5
    v.ld.w       v3, [s19, #0]
    s.addi       s19, s16, #11648
    vf.cvt.f32.bf16 v4, v3
    @p7 v.st.h       [s10, #0], v4
    v.cmp.lt     p1, v1, v2
    p.and        p7, p1, p5
    s.addi       s10, s8, #6
    v.splat      v1, s10
    s.addi       s10, s7, #3072                  // row 6
    v.ld.w       v3, [s2, #0]
    s.addi       s2, s16, #11712
    vf.cvt.f32.bf16 v4, v3
    @p6 v.st.h       [s11, #0], v4
    v.cmp.lt     p1, v0, v2
    p.and        p6, p1, p5
    s.addi       s11, s8, #7
    v.splat      v0, s11
    s.addi       s11, s7, #3584                  // row 7
    v.ld.w       v3, [s21, #0]
    s.addi       s21, s16, #11776
    vf.cvt.f32.bf16 v4, v3
    @p7 v.st.h       [s12, #0], v4
    v.cmp.lt     p1, v5, v2
    p.and        p7, p1, p5
    s.addi       s12, s8, #8
    v.splat      v3, s12
    s.addi       s12, s7, #4096                  // row 8
    v.ld.w       v4, [s1, #0]
    s.addi       s1, s16, #11840
    vf.cvt.f32.bf16 v5, v4
    @p6 v.st.h       [s4, #0], v5
    v.cmp.lt     p1, v1, v2
    p.and        p6, p1, p5
    s.addi       s4, s8, #9
    v.splat      v1, s4
    s.addi       s4, s7, #4608                   // row 9
    v.ld.w       v4, [s22, #0]
    s.addi       s22, s16, #11904
    vf.cvt.f32.bf16 v5, v4
    @p7 v.st.h       [s6, #0], v5
    v.cmp.lt     p1, v0, v2
    p.and        p7, p1, p5
    s.addi       s6, s8, #10
    v.splat      v0, s6
    s.addi       s6, s7, #5120                   // row 10
    v.ld.w       v4, [s19, #0]
    s.addi       s19, s16, #11968
    vf.cvt.f32.bf16 v5, v4
    @p6 v.st.h       [s10, #0], v5
    v.cmp.lt     p1, v3, v2
    p.and        p6, p1, p5
    s.addi       s10, s8, #11
    v.splat      v3, s10
    s.addi       s10, s7, #5632                  // row 11
    v.ld.w       v4, [s2, #0]
    s.addi       s2, s16, #12032
    vf.cvt.f32.bf16 v5, v4
    @p7 v.st.h       [s11, #0], v5
    v.cmp.lt     p1, v1, v2
    p.and        p7, p1, p5
    s.addi       s11, s8, #12
    v.splat      v1, s11
    s.addi       s11, s7, #6144                  // row 12
    v.ld.w       v4, [s21, #0]
    s.addi       s21, s16, #12096
    vf.cvt.f32.bf16 v5, v4
    @p6 v.st.h       [s12, #0], v5
    v.cmp.lt     p1, v0, v2
    p.and        p6, p1, p5
    s.addi       s12, s8, #13
    v.splat      v0, s12
    s.addi       s12, s7, #6656                  // row 13
    v.ld.w       v4, [s1, #0]
    s.addi       s1, s16, #12160
    vf.cvt.f32.bf16 v5, v4
    @p7 v.st.h       [s4, #0], v5
    v.cmp.lt     p1, v3, v2
    p.and        p7, p1, p5
    s.addi       s4, s8, #14
    v.splat      v3, s4
    s.addi       s4, s7, #7168                   // row 14
    s.addi       s24, s7, #7680                  // row 15
    v.ld.w       v4, [s22, #0]
    s.addi       s7, s16, #12224
    s.addi       s22, s8, #15
    vf.cvt.f32.bf16 v5, v4
    v.splat      v4, s22
    s.muli       s8, s5, #2                      // a runtime tile origin, x2
    @p6 v.st.h       [s6, #0], v5
    v.cmp.lt     p1, v1, v2
    p.and        p6, p1, p5
    s.muli       s5, s23, #512                   // a runtime tile origin, x512
    s.add        s6, s9, s8                      // the tile origin
    s.add        s8, s6, s5                      // the tile origin
    v.ld.w       v1, [s19, #0]
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.addi       s5, s16, #12288
    vf.cvt.f32.bf16 v5, v1
    s.movz       s6, #0
    v.splat      v1, s3
    s.add        s3, s6, s23                     // the tile origin
    @p7 v.st.h       [s10, #0], v5
    v.cmp.lt     p1, v0, v2
    p.and        p7, p1, p5
    v.splat      v0, s3
    v.ld.w       v5, [s2, #0]
    vf.cvt.f32.bf16 v6, v5
    s.addi       s2, s16, #12352
    s.addi       s6, s3, #1
    s.addi       s10, s8, #512                   // row 1
    v.splat      v5, s6
    @p6 v.st.h       [s11, #0], v6
    v.cmp.lt     p1, v3, v2
    p.and        p6, p1, p5
    v.ld.w       v3, [s21, #0]
    vf.cvt.f32.bf16 v6, v3
    s.addi       s6, s16, #12416
    s.addi       s11, s3, #2
    s.addi       s19, s8, #1024                  // row 2
    v.splat      v3, s11
    @p7 v.st.h       [s12, #0], v6
    v.cmp.lt     p1, v4, v2
    p.and        p7, p1, p5
    v.ld.w       v2, [s1, #0]
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s16, #12480
    s.addi       s11, s3, #3
    s.addi       s12, s8, #1536                  // row 3
    v.splat      v2, s11
    @p6 v.st.h       [s4, #0], v4
    v.cmp.lt     p1, v0, v1
    p.and        p6, p1, p2
    v.ld.w       v0, [s7, #0]
    vf.cvt.f32.bf16 v4, v0
    s.addi       s4, s16, #12544
    s.addi       s7, s3, #4
    s.addi       s11, s8, #2048                  // row 4
    v.splat      v0, s7
    @p7 v.st.h       [s24, #0], v4
    v.cmp.lt     p1, v5, v1
    p.and        p7, p1, p2
    s.addi       s7, s16, #12608
    v.ld.w       v4, [s5, #0]
    s.addi       s5, s8, #2560                   // row 5
    vf.cvt.f32.bf16 v5, v4
    s.addi       s21, s3, #5
    s.addi       s22, s16, #12672
    v.splat      v4, s21
    @p6 v.st.h       [s8, #0], v5
    v.cmp.lt     p1, v3, v1
    p.and        p6, p1, p2
    s.addi       s21, s8, #3072                  // row 6
    v.ld.w       v3, [s2, #0]
    s.addi       s2, s3, #6
    vf.cvt.f32.bf16 v5, v3
    v.splat      v3, s2
    s.addi       s2, s16, #12736
    @p7 v.st.h       [s10, #0], v5
    v.cmp.lt     p1, v2, v1
    p.and        p7, p1, p2
    s.addi       s10, s8, #3584                  // row 7
    v.ld.w       v2, [s6, #0]
    s.addi       s6, s3, #7
    vf.cvt.f32.bf16 v5, v2
    v.splat      v2, s6
    s.addi       s6, s16, #12800
    @p6 v.st.h       [s19, #0], v5
    v.cmp.lt     p1, v0, v1
    p.and        p6, p1, p2
    s.addi       s19, s8, #4096                  // row 8
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s3, #8
    vf.cvt.f32.bf16 v5, v0
    v.splat      v0, s1
    s.addi       s1, s16, #12864
    @p7 v.st.h       [s12, #0], v5
    v.cmp.lt     p1, v4, v1
    p.and        p7, p1, p2
    s.addi       s12, s8, #4608                  // row 9
    v.ld.w       v4, [s4, #0]
    s.addi       s4, s3, #9
    vf.cvt.f32.bf16 v5, v4
    v.splat      v4, s4
    s.addi       s4, s16, #12928
    @p6 v.st.h       [s11, #0], v5
    v.cmp.lt     p1, v3, v1
    p.and        p6, p1, p2
    s.addi       s11, s8, #5120                  // row 10
    v.ld.w       v3, [s7, #0]
    s.addi       s7, s3, #10
    vf.cvt.f32.bf16 v5, v3
    v.splat      v3, s7
    s.addi       s7, s16, #12992
    @p7 v.st.h       [s5, #0], v5
    v.cmp.lt     p1, v2, v1
    p.and        p7, p1, p2
    s.addi       s5, s8, #5632                   // row 11
    v.ld.w       v2, [s22, #0]
    s.addi       s22, s3, #11
    vf.cvt.f32.bf16 v5, v2
    v.splat      v2, s22
    s.addi       s22, s16, #13056
    @p6 v.st.h       [s21, #0], v5
    v.cmp.lt     p1, v0, v1
    p.and        p6, p1, p2
    s.addi       s21, s8, #6144                  // row 12
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s3, #12
    vf.cvt.f32.bf16 v5, v0
    v.splat      v0, s2
    s.addi       s2, s16, #13120
    @p7 v.st.h       [s10, #0], v5
    v.cmp.lt     p1, v4, v1
    p.and        p7, p1, p2
    s.addi       s10, s8, #6656                  // row 13
    v.ld.w       v4, [s6, #0]
    s.addi       s6, s3, #13
    vf.cvt.f32.bf16 v5, v4
    v.splat      v4, s6
    s.addi       s6, s16, #13184
    @p6 v.st.h       [s19, #0], v5
    v.cmp.lt     p1, v3, v1
    p.and        p6, p1, p2
    s.addi       s19, s8, #7168                  // row 14
    v.ld.w       v3, [s1, #0]
    s.addi       s1, s3, #14
    vf.cvt.f32.bf16 v5, v3
    v.splat      v3, s1
    s.addi       s1, s16, #13248
    @p7 v.st.h       [s12, #0], v5
    v.cmp.lt     p1, v2, v1
    p.and        p7, p1, p2
    s.addi       s12, s8, #7680                  // row 15
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s3, #15
    vf.cvt.f32.bf16 v5, v2
    v.splat      v2, s4
    s.muli       s4, s13, #2                     // a runtime tile origin, x2
    @p6 v.st.h       [s11, #0], v5
    v.cmp.lt     p1, v0, v1
    p.and        p6, p1, p2
    s.muli       s8, s23, #512                   // a runtime tile origin, x512
    s.add        s11, s9, s4                     // the tile origin
    s.add        s4, s11, s8                     // the tile origin
    v.ld.w       v0, [s7, #0]
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.addi       s7, s16, #13312
    vf.cvt.f32.bf16 v5, v0
    v.splat      v0, s3
    @p7 v.st.h       [s5, #0], v5
    v.cmp.lt     p1, v4, v1
    p.and        p7, p1, p2
    s.addi       s5, s16, #13376
    v.ld.w       v4, [s22, #0]
    vf.cvt.f32.bf16 v5, v4
    s.addi       s8, s3, #1
    s.addi       s11, s4, #512                   // row 1
    v.splat      v4, s8
    @p6 v.st.h       [s21, #0], v5
    v.cmp.lt     p1, v3, v1
    p.and        p6, p1, p2
    s.addi       s8, s16, #13440
    v.ld.w       v3, [s2, #0]
    vf.cvt.f32.bf16 v5, v3
    s.addi       s2, s3, #2
    s.addi       s13, s4, #1024                  // row 2
    v.splat      v3, s2
    @p7 v.st.h       [s10, #0], v5
    v.cmp.lt     p1, v2, v1
    p.and        p7, p1, p2
    v.cmp.lt     p1, v0, v1
    p.and        p2, p1, p4
    s.addi       s2, s16, #13504
    v.ld.w       v0, [s6, #0]
    vf.cvt.f32.bf16 v2, v0
    s.addi       s6, s3, #3
    s.addi       s10, s4, #1536                  // row 3
    v.splat      v0, s6
    @p6 v.st.h       [s19, #0], v2
    v.cmp.lt     p1, v4, v1
    p.and        p6, p1, p4
    s.addi       s6, s16, #13568
    v.ld.w       v2, [s1, #0]
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s3, #4
    s.addi       s19, s4, #2048                  // row 4
    v.splat      v2, s1
    @p7 v.st.h       [s12, #0], v4
    v.cmp.lt     p1, v3, v1
    p.and        p7, p1, p4
    s.addi       s1, s16, #13632
    s.addi       s12, s3, #5
    s.addi       s21, s4, #2560                  // row 5
    v.splat      v3, s12
    v.ld.w       v4, [s7, #0]
    vf.cvt.f32.bf16 v5, v4
    s.addi       s7, s16, #13696
    @p2 v.st.h       [s4, #0], v5
    v.cmp.lt     p1, v0, v1
    p.and        p2, p1, p4
    s.addi       s12, s4, #3072                  // row 6
    v.ld.w       v0, [s5, #0]
    s.addi       s5, s3, #6
    vf.cvt.f32.bf16 v4, v0
    v.splat      v0, s5
    s.addi       s5, s16, #13760
    @p6 v.st.h       [s11, #0], v4
    v.cmp.lt     p1, v2, v1
    p.and        p6, p1, p4
    s.addi       s11, s4, #3584                  // row 7
    v.ld.w       v2, [s8, #0]
    s.addi       s8, s3, #7
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s8
    s.addi       s8, s16, #13824
    @p7 v.st.h       [s13, #0], v4
    v.cmp.lt     p1, v3, v1
    p.and        p7, p1, p4
    s.addi       s13, s4, #4096                  // row 8
    v.ld.w       v3, [s2, #0]
    s.addi       s2, s3, #8
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s2
    s.addi       s2, s16, #13888
    @p2 v.st.h       [s10, #0], v4
    v.cmp.lt     p1, v0, v1
    p.and        p2, p1, p4
    s.addi       s10, s4, #4608                  // row 9
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s3, #9
    vf.cvt.f32.bf16 v4, v0
    v.splat      v0, s6
    s.addi       s6, s16, #13952
    @p6 v.st.h       [s19, #0], v4
    v.cmp.lt     p1, v2, v1
    p.and        p6, p1, p4
    s.addi       s19, s4, #5120                  // row 10
    v.ld.w       v2, [s1, #0]
    s.addi       s1, s3, #10
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s1
    s.addi       s1, s16, #14016
    @p7 v.st.h       [s21, #0], v4
    v.cmp.lt     p1, v3, v1
    p.and        p7, p1, p4
    s.addi       s21, s4, #5632                  // row 11
    v.ld.w       v3, [s7, #0]
    s.addi       s7, s3, #11
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s7
    s.addi       s7, s16, #14080
    @p2 v.st.h       [s12, #0], v4
    v.cmp.lt     p1, v0, v1
    p.and        p2, p1, p4
    s.addi       s12, s4, #6144                  // row 12
    v.ld.w       v0, [s5, #0]
    s.addi       s5, s3, #12
    vf.cvt.f32.bf16 v4, v0
    v.splat      v0, s5
    s.addi       s5, s16, #14144
    @p6 v.st.h       [s11, #0], v4
    v.cmp.lt     p1, v2, v1
    p.and        p6, p1, p4
    s.addi       s11, s4, #6656                  // row 13
    v.ld.w       v2, [s8, #0]
    s.addi       s8, s3, #13
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s8
    s.addi       s8, s16, #14208
    @p7 v.st.h       [s13, #0], v4
    v.cmp.lt     p1, v3, v1
    p.and        p7, p1, p4
    s.addi       s13, s4, #7168                  // row 14
    v.ld.w       v3, [s2, #0]
    s.addi       s2, s3, #14
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s2
    s.addi       s2, s16, #14272
    @p2 v.st.h       [s10, #0], v4
    v.cmp.lt     p1, v0, v1
    p.and        p2, p1, p4
    s.addi       s10, s4, #7680                  // row 15
    v.ld.w       v0, [s6, #0]
    s.addi       s4, s3, #15
    vf.cvt.f32.bf16 v4, v0
    v.splat      v0, s4
    s.muli       s4, s14, #2                     // a runtime tile origin, x2
    @p6 v.st.h       [s19, #0], v4
    v.cmp.lt     p1, v2, v1
    p.and        p6, p1, p4
    s.muli       s6, s23, #512                   // a runtime tile origin, x512
    s.add        s14, s9, s4                     // the tile origin
    s.add        s4, s14, s6                     // the tile origin
    v.ld.w       v2, [s1, #0]
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.addi       s1, s16, #14336
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s3
    @p7 v.st.h       [s21, #0], v4
    v.cmp.lt     p1, v3, v1
    p.and        p7, p1, p4
    s.addi       s6, s16, #14400
    v.ld.w       v3, [s7, #0]
    vf.cvt.f32.bf16 v4, v3
    s.addi       s7, s3, #1
    s.addi       s14, s4, #512                   // row 1
    v.splat      v3, s7
    @p2 v.st.h       [s12, #0], v4
    v.cmp.lt     p1, v0, v1
    p.and        p2, p1, p4
    v.cmp.lt     p1, v2, v1
    p.and        p4, p1, p3
    s.addi       s7, s16, #14464
    v.ld.w       v0, [s5, #0]
    vf.cvt.f32.bf16 v2, v0
    s.addi       s5, s3, #2
    s.addi       s12, s4, #1024                  // row 2
    v.splat      v0, s5
    @p6 v.st.h       [s11, #0], v2
    v.cmp.lt     p1, v3, v1
    p.and        p6, p1, p3
    s.addi       s5, s16, #14528
    v.ld.w       v2, [s8, #0]
    vf.cvt.f32.bf16 v3, v2
    s.addi       s8, s3, #3
    s.addi       s11, s4, #1536                  // row 3
    v.splat      v2, s8
    @p7 v.st.h       [s13, #0], v3
    v.cmp.lt     p1, v0, v1
    p.and        p7, p1, p3
    s.addi       s8, s16, #14592
    v.ld.w       v0, [s2, #0]
    vf.cvt.f32.bf16 v3, v0
    s.addi       s2, s3, #4
    s.addi       s13, s4, #2048                  // row 4
    v.splat      v0, s2
    @p2 v.st.h       [s10, #0], v3
    v.cmp.lt     p1, v2, v1
    p.and        p2, p1, p3
    s.addi       s2, s16, #14656
    s.addi       s10, s3, #5
    s.addi       s19, s4, #2560                  // row 5
    v.splat      v2, s10
    v.ld.w       v3, [s1, #0]
    vf.cvt.f32.bf16 v4, v3
    s.addi       s1, s16, #14720
    @p4 v.st.h       [s4, #0], v4
    v.cmp.lt     p1, v0, v1
    p.and        p4, p1, p3
    s.addi       s10, s4, #3072                  // row 6
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s3, #6
    vf.cvt.f32.bf16 v3, v0
    v.splat      v0, s6
    s.addi       s6, s16, #14784
    @p6 v.st.h       [s14, #0], v3
    v.cmp.lt     p1, v2, v1
    p.and        p6, p1, p3
    s.addi       s14, s4, #3584                  // row 7
    v.ld.w       v2, [s7, #0]
    s.addi       s7, s3, #7
    vf.cvt.f32.bf16 v3, v2
    v.splat      v2, s7
    s.addi       s7, s16, #14848
    @p7 v.st.h       [s12, #0], v3
    v.cmp.lt     p1, v0, v1
    p.and        p7, p1, p3
    s.addi       s12, s4, #4096                  // row 8
    v.ld.w       v0, [s5, #0]
    s.addi       s5, s3, #8
    vf.cvt.f32.bf16 v3, v0
    v.splat      v0, s5
    s.addi       s5, s16, #14912
    @p2 v.st.h       [s11, #0], v3
    v.cmp.lt     p1, v2, v1
    p.and        p2, p1, p3
    s.addi       s11, s4, #4608                  // row 9
    v.ld.w       v2, [s8, #0]
    s.addi       s8, s3, #9
    vf.cvt.f32.bf16 v3, v2
    v.splat      v2, s8
    s.addi       s8, s16, #14976
    @p4 v.st.h       [s13, #0], v3
    v.cmp.lt     p1, v0, v1
    p.and        p4, p1, p3
    s.addi       s13, s4, #5120                  // row 10
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s3, #10
    vf.cvt.f32.bf16 v3, v0
    v.splat      v0, s2
    s.addi       s2, s16, #15040
    @p6 v.st.h       [s19, #0], v3
    v.cmp.lt     p1, v2, v1
    p.and        p6, p1, p3
    s.addi       s19, s4, #5632                  // row 11
    v.ld.w       v2, [s1, #0]
    s.addi       s1, s3, #11
    vf.cvt.f32.bf16 v3, v2
    v.splat      v2, s1
    s.addi       s1, s16, #15104
    @p7 v.st.h       [s10, #0], v3
    v.cmp.lt     p1, v0, v1
    p.and        p7, p1, p3
    s.addi       s10, s4, #6144                  // row 12
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s3, #12
    vf.cvt.f32.bf16 v3, v0
    v.splat      v0, s6
    s.addi       s6, s16, #15168
    @p2 v.st.h       [s14, #0], v3
    v.cmp.lt     p1, v2, v1
    p.and        p2, p1, p3
    s.addi       s14, s4, #6656                  // row 13
    v.ld.w       v2, [s7, #0]
    s.addi       s7, s3, #13
    vf.cvt.f32.bf16 v3, v2
    v.splat      v2, s7
    s.addi       s7, s16, #15232
    @p4 v.st.h       [s12, #0], v3
    v.cmp.lt     p1, v0, v1
    p.and        p4, p1, p3
    s.addi       s12, s4, #7168                  // row 14
    v.ld.w       v0, [s5, #0]
    s.addi       s5, s3, #14
    vf.cvt.f32.bf16 v3, v0
    v.splat      v0, s5
    s.addi       s5, s16, #15296
    @p6 v.st.h       [s11, #0], v3
    v.cmp.lt     p1, v2, v1
    p.and        p6, p1, p3
    s.addi       s11, s4, #7680                  // row 15
    v.ld.w       v2, [s8, #0]
    s.addi       s4, s3, #15
    vf.cvt.f32.bf16 v3, v2
    v.splat      v2, s4
    s.muli       s4, s15, #2                     // a runtime tile origin, x2
    @p7 v.st.h       [s13, #0], v3
    v.cmp.lt     p1, v0, v1
    p.and        p7, p1, p3
    s.muli       s8, s23, #512                   // a runtime tile origin, x512
    s.add        s13, s9, s4                     // the tile origin
    s.add        s4, s13, s8                     // the tile origin
    v.ld.w       v0, [s2, #0]
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.addi       s2, s16, #15360
    vf.cvt.f32.bf16 v3, v0
    v.splat      v0, s3
    @p2 v.st.h       [s19, #0], v3
    v.cmp.lt     p1, v2, v1
    p.and        p2, p1, p3
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p5
    s.addi       s8, s16, #15424
    v.ld.w       v0, [s1, #0]
    vf.cvt.f32.bf16 v2, v0
    s.addi       s1, s3, #1
    s.addi       s9, s4, #512                    // row 1
    v.splat      v0, s1
    @p4 v.st.h       [s10, #0], v2
    v.cmp.lt     p1, v0, v1
    p.and        p4, p1, p5
    s.addi       s1, s16, #15488
    v.ld.w       v0, [s6, #0]
    vf.cvt.f32.bf16 v2, v0
    s.addi       s6, s3, #2
    s.addi       s10, s4, #1024                  // row 2
    v.splat      v0, s6
    @p6 v.st.h       [s14, #0], v2
    v.cmp.lt     p1, v0, v1
    p.and        p6, p1, p5
    s.addi       s6, s16, #15552
    v.ld.w       v0, [s7, #0]
    vf.cvt.f32.bf16 v2, v0
    s.addi       s7, s3, #3
    s.addi       s13, s4, #1536                  // row 3
    v.splat      v0, s7
    @p7 v.st.h       [s12, #0], v2
    v.cmp.lt     p1, v0, v1
    p.and        p7, p1, p5
    s.addi       s7, s16, #15616
    v.ld.w       v0, [s5, #0]
    vf.cvt.f32.bf16 v2, v0
    s.addi       s5, s3, #4
    s.addi       s12, s4, #2048                  // row 4
    v.splat      v0, s5
    @p2 v.st.h       [s11, #0], v2
    v.cmp.lt     p1, v0, v1
    p.and        p2, p1, p5
    s.addi       s5, s16, #15680
    s.addi       s11, s3, #5
    s.addi       s14, s4, #2560                  // row 5
    v.splat      v0, s11
    v.ld.w       v2, [s2, #0]
    vf.cvt.f32.bf16 v3, v2
    s.addi       s2, s16, #15744
    @p3 v.st.h       [s4, #0], v3
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p5
    s.addi       s11, s4, #3072                  // row 6
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s3, #6
    vf.cvt.f32.bf16 v2, v0
    v.splat      v0, s8
    s.addi       s8, s16, #15808
    @p4 v.st.h       [s9, #0], v2
    v.cmp.lt     p1, v0, v1
    p.and        p4, p1, p5
    s.addi       s9, s4, #3584                   // row 7
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s3, #7
    vf.cvt.f32.bf16 v2, v0
    v.splat      v0, s1
    s.addi       s1, s16, #15872
    @p6 v.st.h       [s10, #0], v2
    v.cmp.lt     p1, v0, v1
    p.and        p6, p1, p5
    s.addi       s10, s4, #4096                  // row 8
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s3, #8
    vf.cvt.f32.bf16 v2, v0
    v.splat      v0, s6
    s.addi       s6, s16, #15936
    @p7 v.st.h       [s13, #0], v2
    v.cmp.lt     p1, v0, v1
    p.and        p7, p1, p5
    s.addi       s13, s4, #4608                  // row 9
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s3, #9
    vf.cvt.f32.bf16 v2, v0
    v.splat      v0, s7
    s.addi       s7, s16, #16000
    @p2 v.st.h       [s12, #0], v2
    v.cmp.lt     p1, v0, v1
    p.and        p2, p1, p5
    s.addi       s12, s4, #5120                  // row 10
    v.ld.w       v0, [s5, #0]
    s.addi       s5, s3, #10
    vf.cvt.f32.bf16 v2, v0
    v.splat      v0, s5
    s.addi       s5, s16, #16064
    @p3 v.st.h       [s14, #0], v2
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p5
    s.addi       s14, s4, #5632                  // row 11
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s3, #11
    vf.cvt.f32.bf16 v2, v0
    v.splat      v0, s2
    s.addi       s2, s16, #16128
    @p4 v.st.h       [s11, #0], v2
    v.cmp.lt     p1, v0, v1
    p.and        p4, p1, p5
    s.addi       s11, s4, #6144                  // row 12
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s3, #12
    vf.cvt.f32.bf16 v2, v0
    v.splat      v0, s8
    s.addi       s8, s16, #16192
    @p6 v.st.h       [s9, #0], v2
    v.cmp.lt     p1, v0, v1
    p.and        p6, p1, p5
    s.addi       s9, s4, #6656                   // row 13
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s3, #13
    vf.cvt.f32.bf16 v2, v0
    v.splat      v0, s1
    s.addi       s1, s16, #16256
    @p7 v.st.h       [s10, #0], v2
    v.cmp.lt     p1, v0, v1
    p.and        p7, p1, p5
    s.addi       s10, s4, #7168                  // row 14
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s3, #14
    vf.cvt.f32.bf16 v2, v0
    v.splat      v0, s6
    s.addi       s6, s16, #16320
    @p2 v.st.h       [s13, #0], v2
    v.cmp.lt     p1, v0, v1
    p.and        p2, p1, p5
    s.addi       s13, s4, #7680                  // row 15
    v.ld.w       v0, [s7, #0]
    s.addi       s4, s3, #15
    vf.cvt.f32.bf16 v2, v0
    v.splat      v0, s4
    @p3 v.st.h       [s12, #0], v2
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p5
    v.ld.w       v0, [s5, #0]
    vf.cvt.f32.bf16 v1, v0
    @p4 v.st.h       [s14, #0], v1
    v.ld.w       v0, [s2, #0]
    vf.cvt.f32.bf16 v1, v0
    @p6 v.st.h       [s11, #0], v1
    v.ld.w       v0, [s8, #0]
    vf.cvt.f32.bf16 v1, v0
    @p7 v.st.h       [s9, #0], v1
    v.ld.w       v0, [s1, #0]
    vf.cvt.f32.bf16 v1, v0
    @p2 v.st.h       [s10, #0], v1
    v.ld.w       v0, [s6, #0]
    vf.cvt.f32.bf16 v1, v0
    @p3 v.st.h       [s13, #0], v1
    exit
    exit
