    s.rdspecial  s1, arg_base
    s.rdspecial  s2, role_id
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.rdspecial  s4, npid.x
    s.ld.d       s5, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
__rctx_program:
    s.shli       s1, s2, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #5
    v.add        v4, v1, v0
    v.movi       v0, #0
    v.movi       v1, #0
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    v.sub        v6, v0, v4
    @p1 v.sel        v7, v5, v4
    v.movi       v5, #0
    v.sub        v8, v1, v4
    v.lshr       v9, v7, v3
    v.cmp.lt     p2, v4, v0
    v.cmp.lt     p3, v4, v1
    v.sub        v3, v2, v9
    @p2 v.sel        v7, v6, v4
    v.movi       v6, #31
    @p1 v.sel        v10, v3, v9
    @p3 v.sel        v3, v8, v4
    v.movi       v4, #14
    v.sub        v8, v5, v10
    v.cmp.lt     p1, v10, v5
    v.and        v9, v7, v6
    @p1 v.sel        v6, v8, v10
    v.movi       v7, #511
    v.lshr       v8, v3, v4
    v.sub        v3, v0, v9
    v.and        v4, v6, v7
    v.sub        v6, v1, v8
    v.movi       v7, #32
    @p2 v.sel        v11, v3, v9
    v.sub        v3, v5, v4
    @p3 v.sel        v9, v6, v8
    v.movi       v6, #64
    @p1 v.sel        v8, v3, v4
    v.add        v3, v11, v7
    v.mul        v4, v9, v6
    v.movi       v9, #512
    v.cmp.lt     p1, v7, v0
    v.add        v12, v3, v4
    v.movi       v3, #256
    v.sub        v4, v0, v7
    v.cmp.lt     p2, v7, v2
    v.mul        v0, v8, v3
    v.movi       v3, #16384
    v.sub        v8, v2, v7
    v.add        v2, v12, v0
    v.sub        v0, v5, v9
    v.cmp.lt     p3, v9, v5
    v.ld.gather.h v5, [s3, v2]                   // index is in elements (ISA sec 9.1)
    v.sub        v2, v1, v3
    @p1 v.sel        v12, v4, v7
    v.mul        v4, v10, v6
    v.cmp.lt     p1, v3, v1
    @p2 v.sel        v1, v8, v7
    v.add        v1, v11, v4
    @p3 v.sel        v4, v0, v9
    @p1 v.sel        v0, v2, v3
    vf.cvt.f16.f32 v0, v5
    vf.neg       v2, v0
    vf.cvt.f32.f16 v0, v2
    v.st.scatter.h [s5, v1], v0
__rctx_next:
    s.addi       s1, s2, #4                      // the next program of this context: + 4
    s.cmp.lt     s6, s1, s4
    s.mov        s2, s1
    br.nz        s6, __rctx_program
    exit
