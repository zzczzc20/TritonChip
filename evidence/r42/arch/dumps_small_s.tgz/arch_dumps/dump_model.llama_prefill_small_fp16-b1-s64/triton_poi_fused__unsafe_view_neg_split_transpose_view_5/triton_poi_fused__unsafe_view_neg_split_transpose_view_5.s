    s.rdspecial  s1, arg_base
    s.movz       s2, #256
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #0
    s.rdspecial  s5, role_id
    s.rdspecial  s6, npid.x
    s.ld.d       s7, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
__rctx_program:
    // tiled element-wise program: 256 lanes as 2 tiles of 128 (0 tensor-engine transfers, one load buffer(s))
    s.mul        s1, s5, s2
    s.addi       s8, s4, #0
tiles_1:
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #16
    v.movi       v2, #32
    v.movi       v3, #48
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v5, #64
    v.movi       v6, #80
    v.movi       v7, #96
    v.iota       v8                              // arange(0, VLEN)
    v.movi       v9, #112
    // tile 0 of the iteration: lanes t0 + 0
    s.add        s9, s1, s8
    v.add        v10, v0, v1
    v.splat      v1, s9
    v.add        v11, v0, v2
    v.add        v2, v0, v3
    v.add        v3, v4, v5
    v.add        v5, v4, v6
    v.add        v6, v4, v7
    v.add        v4, v8, v9
    v.add        v7, v1, v0
    v.add        v0, v1, v10
    v.add        v8, v1, v11
    v.add        v9, v1, v2
    v.add        v2, v1, v3
    v.add        v3, v1, v5
    v.add        v5, v1, v6
    v.add        v6, v1, v4
    v.movi       v1, #0
    v.movi       v4, #0
    v.movi       v10, #0
    v.movi       v11, #0
    v.sub        v12, v1, v7
    v.sub        v13, v4, v0
    v.sub        v14, v10, v8
    v.sub        v15, v11, v9
    v.cmp.lt     p1, v7, v1
    v.cmp.lt     p2, v0, v4
    v.cmp.lt     p3, v8, v10
    @p1 v.sel        v16, v12, v7
    v.movi       v12, #15
    @p2 v.sel        v17, v13, v0
    v.movi       v13, #15
    @p3 v.sel        v18, v14, v8
    v.movi       v14, #15
    v.movi       v19, #15
    v.and        v20, v16, v12
    v.and        v12, v17, v13
    v.and        v13, v18, v14
    v.sub        v14, v1, v20
    v.sub        v16, v4, v12
    v.sub        v17, v10, v13
    v.movi       v18, #16
    v.movi       v21, #0
    @p1 v.sel        v22, v14, v20
    v.cmp.lt     p1, v9, v11
    @p1 v.sel        v14, v15, v9
    v.movi       v15, #16
    @p2 v.sel        v20, v16, v12
    v.cmp.lt     p2, v2, v21
    v.and        v12, v14, v19
    v.movi       v14, #16
    @p3 v.sel        v16, v17, v13
    v.sub        v13, v11, v12
    v.movi       v17, #16
    v.movi       v19, #16
    @p1 v.sel        v23, v13, v12
    v.sub        v12, v1, v18
    v.sub        v13, v4, v15
    v.sub        v24, v10, v14
    v.sub        v25, v11, v17
    v.cmp.lt     p1, v18, v1
    v.sub        v1, v21, v2
    v.sub        v26, v21, v19
    v.cmp.lt     p3, v15, v4
    @p2 v.sel        v4, v1, v2
    @p1 v.sel        v1, v12, v18
    v.movi       v1, #0
    v.movi       v12, #15
    v.movi       v27, #16
    v.sub        v28, v1, v3
    v.cmp.lt     p1, v3, v1
    v.and        v29, v4, v12
    @p1 v.sel        v4, v28, v3
    v.sub        v12, v1, v27
    v.sub        v28, v21, v29
    @p3 v.sel        v30, v13, v15
    v.movi       v13, #0
    v.movi       v30, #15
    @p2 v.sel        v31, v28, v29
    v.cmp.lt     p2, v5, v13
    v.and        v28, v4, v30
    v.movi       v4, #16
    v.cmp.lt     p3, v14, v10
    v.sub        v10, v13, v5
    v.sub        v29, v1, v28
    v.sub        v30, v13, v4
    @p2 v.sel        v32, v10, v5
    @p1 v.sel        v10, v29, v28
    v.cmp.lt     p1, v17, v11
    @p3 v.sel        v11, v24, v14
    v.movi       v11, #0
    v.movi       v24, #15
    v.movi       v28, #16
    v.sub        v29, v11, v6
    v.cmp.lt     p3, v6, v11
    v.and        v33, v32, v24
    @p3 v.sel        v24, v29, v6
    v.sub        v29, v11, v28
    v.sub        v32, v13, v33
    @p1 v.sel        v34, v25, v17
    v.movi       v25, #0
    v.movi       v34, #15
    @p2 v.sel        v35, v32, v33
    v.cmp.lt     p1, v7, v25
    v.and        v32, v24, v34
    v.cmp.lt     p2, v19, v21
    v.sub        v21, v25, v7
    v.sub        v24, v11, v32
    v.sub        v33, v25, v18
    @p1 v.sel        v34, v21, v7
    @p3 v.sel        v21, v24, v32
    v.cmp.lt     p3, v27, v1
    @p2 v.sel        v1, v26, v19
    v.movi       v1, #0
    v.movi       v24, #4
    v.movi       v26, #4
    v.sub        v32, v1, v0
    v.cmp.lt     p2, v0, v1
    v.lshr       v36, v34, v24
    @p2 v.sel        v24, v32, v0
    v.sub        v32, v1, v15
    v.sub        v34, v25, v36
    @p3 v.sel        v37, v12, v27
    v.movi       v12, #0
    v.lshr       v37, v24, v26
    @p1 v.sel        v24, v34, v36
    v.sub        v26, v12, v8
    v.cmp.lt     p1, v8, v12
    v.sub        v34, v1, v37
    @p1 v.sel        v36, v26, v8
    v.cmp.lt     p3, v4, v13
    v.movi       v13, #4
    @p2 v.sel        v26, v34, v37
    v.sub        v34, v12, v14
    v.lshr       v37, v36, v13
    v.cmp.lt     p2, v28, v11
    @p3 v.sel        v11, v30, v4
    v.movi       v11, #0
    v.movi       v13, #4
    v.sub        v30, v12, v37
    v.sub        v36, v11, v9
    v.cmp.lt     p3, v9, v11
    @p1 v.sel        v38, v30, v37
    @p3 v.sel        v30, v36, v9
    v.sub        v36, v11, v17
    v.cmp.lt     p1, v18, v25
    v.lshr       v25, v30, v13
    @p2 v.sel        v13, v29, v28
    v.movi       v13, #0
    v.movi       v29, #4
    v.sub        v30, v11, v25
    v.sub        v37, v13, v2
    v.cmp.lt     p2, v2, v13
    @p3 v.sel        v39, v30, v25
    @p2 v.sel        v25, v37, v2
    v.sub        v30, v13, v19
    v.cmp.lt     p3, v15, v1
    v.lshr       v1, v25, v29
    @p1 v.sel        v25, v33, v18
    v.movi       v25, #0
    v.movi       v29, #4
    v.sub        v33, v13, v1
    v.sub        v37, v25, v3
    v.cmp.lt     p1, v3, v25
    @p2 v.sel        v40, v33, v1
    @p1 v.sel        v1, v37, v3
    v.sub        v33, v25, v27
    v.cmp.lt     p2, v14, v12
    v.lshr       v12, v1, v29
    @p3 v.sel        v1, v32, v15
    v.movi       v1, #0
    v.movi       v29, #4
    v.sub        v32, v25, v12
    v.sub        v37, v1, v5
    v.cmp.lt     p3, v5, v1
    @p1 v.sel        v41, v32, v12
    @p3 v.sel        v12, v37, v5
    v.sub        v32, v1, v4
    v.cmp.lt     p1, v17, v11
    v.lshr       v11, v12, v29
    @p2 v.sel        v12, v34, v14
    v.movi       v12, #0
    v.movi       v29, #4
    v.sub        v34, v1, v11
    v.sub        v37, v12, v6
    v.cmp.lt     p2, v6, v12
    @p3 v.sel        v42, v34, v11
    @p2 v.sel        v11, v37, v6
    v.sub        v34, v12, v28
    v.cmp.lt     p3, v19, v13
    v.lshr       v13, v11, v29
    @p1 v.sel        v11, v36, v17
    v.movi       v11, #0
    v.sub        v29, v12, v13
    v.movi       v36, #63
    v.sub        v37, v11, v24
    @p2 v.sel        v43, v29, v13
    v.cmp.lt     p1, v24, v11
    @p1 v.sel        v13, v37, v24
    v.movi       v29, #64
    v.cmp.lt     p2, v27, v25
    v.and        v25, v13, v36
    v.sub        v13, v11, v29
    @p3 v.sel        v36, v30, v19
    v.movi       v30, #0
    v.movi       v36, #63
    v.sub        v37, v11, v25
    v.sub        v44, v30, v26
    v.cmp.lt     p3, v26, v30
    @p1 v.sel        v45, v37, v25
    @p3 v.sel        v25, v44, v26
    v.movi       v37, #64
    v.cmp.lt     p1, v4, v1
    @p2 v.sel        v1, v33, v27
    v.movi       v1, #0
    v.and        v33, v25, v36
    v.movi       v25, #64
    v.sub        v36, v1, v38
    v.cmp.lt     p2, v38, v1
    v.sub        v44, v30, v33
    @p2 v.sel        v46, v36, v38
    v.sub        v36, v30, v37
    @p3 v.sel        v47, v44, v33
    v.sub        v33, v1, v25
    v.cmp.lt     p3, v28, v12
    @p1 v.sel        v12, v32, v4
    v.movi       v12, #0
    v.movi       v32, #63
    v.movi       v44, #64
    v.sub        v48, v12, v39
    v.cmp.lt     p1, v39, v12
    v.and        v49, v46, v32
    @p1 v.sel        v32, v48, v39
    v.sub        v46, v12, v44
    v.sub        v48, v1, v49
    @p3 v.sel        v50, v34, v28
    v.movi       v34, #0
    v.movi       v50, #63
    @p2 v.sel        v51, v48, v49
    v.cmp.lt     p2, v40, v34
    v.and        v48, v32, v50
    v.movi       v32, #64
    v.cmp.lt     p3, v29, v11
    v.sub        v11, v34, v40
    v.sub        v49, v12, v48
    v.sub        v50, v34, v32
    @p2 v.sel        v52, v11, v40
    @p1 v.sel        v11, v49, v48
    v.cmp.lt     p1, v37, v30
    @p3 v.sel        v30, v13, v29
    v.movi       v13, #0
    v.movi       v30, #63
    v.movi       v48, #64
    v.sub        v49, v13, v41
    v.cmp.lt     p3, v41, v13
    v.and        v53, v52, v30
    @p3 v.sel        v30, v49, v41
    v.sub        v49, v13, v48
    v.sub        v52, v34, v53
    @p1 v.sel        v54, v36, v37
    v.movi       v36, #0
    v.movi       v54, #63
    @p2 v.sel        v55, v52, v53
    v.cmp.lt     p1, v42, v36
    v.and        v52, v30, v54
    v.movi       v30, #64
    v.cmp.lt     p2, v25, v1
    v.sub        v1, v36, v42
    v.sub        v53, v13, v52
    v.sub        v54, v36, v30
    @p1 v.sel        v56, v1, v42
    @p3 v.sel        v1, v53, v52
    v.cmp.lt     p3, v44, v12
    @p2 v.sel        v12, v33, v25
    v.movi       v12, #0
    v.movi       v33, #63
    v.movi       v52, #64
    v.sub        v53, v12, v43
    v.cmp.lt     p2, v43, v12
    v.and        v57, v56, v33
    @p2 v.sel        v33, v53, v43
    v.sub        v53, v12, v52
    v.sub        v56, v36, v57
    @p3 v.sel        v58, v46, v44
    v.movi       v46, #0
    v.movi       v58, #63
    @p1 v.sel        v59, v56, v57
    v.cmp.lt     p1, v7, v46
    v.and        v56, v33, v58
    v.movi       v33, #1024
    v.cmp.lt     p3, v32, v34
    v.sub        v34, v46, v7
    v.sub        v57, v12, v56
    v.sub        v58, v46, v33
    @p1 v.sel        v60, v34, v7
    @p2 v.sel        v34, v57, v56
    v.cmp.lt     p2, v48, v13
    @p3 v.sel        v13, v50, v32
    v.movi       v13, #0
    v.movi       v50, #10
    v.movi       v56, #1024
    v.sub        v57, v13, v0
    v.cmp.lt     p3, v0, v13
    v.lshr       v61, v60, v50
    @p3 v.sel        v50, v57, v0
    v.sub        v57, v13, v56
    v.sub        v60, v46, v61
    @p2 v.sel        v62, v49, v48
    v.movi       v49, #0
    v.movi       v62, #10
    @p1 v.sel        v63, v60, v61
    v.cmp.lt     p1, v8, v49
    v.lshr       v60, v50, v62
    v.movi       v50, #1024
    v.cmp.lt     p2, v30, v36
    v.sub        v36, v49, v8
    v.sub        v61, v13, v60
    @p2 v.sel        v62, v54, v30
    v.movi       v54, #0
    @p1 v.sel        v62, v36, v8
    @p3 v.sel        v36, v61, v60
    v.cmp.lt     p2, v9, v54
    v.movi       v60, #10
    v.cmp.lt     p3, v52, v12
    v.sub        v12, v54, v9
    v.lshr       v61, v62, v60
    v.movi       v60, #1024
    @p2 v.sel        v62, v12, v9
    @p3 v.sel        v12, v53, v52
    v.movi       v12, #0
    v.cmp.lt     p3, v33, v46
    v.movi       v46, #10
    @p3 v.sel        v53, v58, v33
    v.movi       v33, #0
    v.sub        v53, v12, v2
    v.cmp.lt     p3, v2, v12
    v.lshr       v58, v62, v46
    @p3 v.sel        v46, v53, v2
    v.movi       v53, #10
    v.lshr       v62, v46, v53
    v.sub        v46, v49, v61
    @p1 v.sel        v53, v46, v61
    v.cmp.lt     p1, v3, v33
    v.sub        v46, v54, v58
    @p2 v.sel        v61, v46, v58
    v.sub        v46, v12, v62
    v.cmp.lt     p2, v56, v13
    v.sub        v13, v33, v3
    @p3 v.sel        v58, v46, v62
    v.movi       v46, #1024
    @p1 v.sel        v62, v13, v3
    v.cmp.lt     p3, v50, v49
    v.sub        v13, v49, v50
    @p2 v.sel        v49, v57, v56
    v.movi       v49, #0
    v.movi       v56, #10
    v.cmp.lt     p2, v60, v54
    v.sub        v57, v54, v60
    v.lshr       v54, v62, v56
    v.sub        v56, v49, v5
    @p3 v.sel        v62, v13, v50
    v.movi       v13, #0
    v.cmp.lt     p3, v5, v49
    @p3 v.sel        v50, v56, v5
    v.sub        v56, v13, v6
    @p2 v.sel        v62, v57, v60
    v.cmp.lt     p2, v6, v13
    v.movi       v57, #10
    @p2 v.sel        v60, v56, v6
    v.movi       v56, #10
    v.lshr       v62, v50, v57
    v.sub        v50, v33, v54
    v.lshr       v57, v60, v56
    v.sub        v56, v49, v62
    @p1 v.sel        v60, v50, v54
    v.sub        v50, v13, v57
    @p3 v.sel        v54, v56, v62
    v.add        v56, v22, v18
    @p2 v.sel        v18, v50, v57
    v.add        v50, v20, v15
    v.add        v15, v16, v14
    v.movi       v14, #1024
    v.movi       v57, #1024
    v.cmp.lt     p1, v46, v12
    v.add        v62, v23, v17
    v.add        v17, v31, v19
    v.add        v19, v10, v27
    v.sub        v27, v12, v46
    v.add        v12, v35, v4
    v.cmp.lt     p2, v14, v33
    v.sub        v4, v33, v14
    v.cmp.lt     p3, v57, v49
    v.sub        v33, v49, v57
    @p1 v.sel        v49, v27, v46
    v.movi       v27, #32
    v.movi       v46, #32
    v.add        v49, v21, v28
    v.mul        v28, v63, v27
    v.mul        v63, v36, v27
    v.mul        v36, v53, v27
    v.mul        v53, v61, v27
    v.mul        v61, v58, v27
    v.mul        v58, v60, v46
    v.mul        v60, v54, v46
    v.mul        v54, v18, v46
    v.add        v18, v56, v28
    v.movi       v28, #1024
    @p2 v.sel        v56, v4, v14
    v.add        v4, v50, v63
    v.add        v14, v15, v36
    v.add        v15, v62, v53
    v.add        v36, v17, v61
    v.add        v17, v19, v58
    v.add        v19, v12, v60
    v.add        v12, v49, v54
    v.mul        v49, v45, v29
    v.mul        v29, v47, v37
    v.mul        v37, v51, v25
    v.mul        v25, v11, v44
    v.mul        v11, v55, v32
    v.sub        v32, v13, v28
    v.cmp.lt     p1, v28, v13
    @p3 v.sel        v13, v33, v57
    v.mul        v13, v1, v48
    v.mul        v1, v59, v30
    v.mul        v30, v34, v52
    v.movi       v33, #2048
    v.add        v34, v18, v49
    v.add        v18, v4, v29
    v.add        v4, v14, v37
    v.add        v14, v15, v25
    v.add        v15, v36, v11
    v.add        v11, v17, v13
    v.add        v13, v19, v1
    v.add        v1, v12, v30
    @p1 v.sel        v12, v32, v28
    v.movi       v12, #2048
    v.movi       v17, #2048
    v.cmp.lt     p1, v7, v33
    v.cmp.lt     p2, v0, v33
    v.cmp.lt     p3, v8, v33
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v19, [s3, v34]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v9, v12
    v.mul        v25, v24, v27
    v.mul        v24, v26, v27
    v.mul        v26, v38, v27
    v.mul        v28, v39, v27
    v.mul        v29, v40, v27
    v.mul        v27, v41, v46
    v.mul        v30, v42, v46
    v.mul        v32, v43, v46
    v.add        v34, v22, v25
    v.add        v22, v20, v24
    v.add        v20, v16, v26
    v.add        v16, v23, v28
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.h v23, [s3, v18]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v12
    vf.cvt.f16.f32 v18, v19
    v.add        v19, v31, v29
    v.add        v24, v10, v27
    v.add        v10, v35, v30
    v.add        v25, v21, v32
    vf.neg       v21, v18
    vf.cvt.f32.f16 v18, v21
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.h v21, [s3, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v3, v12
    vf.cvt.f16.f32 v4, v23
    vf.neg       v23, v4
    vf.cvt.f32.f16 v4, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v23, [s3, v14]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v17
    vf.cvt.f16.f32 v14, v21
    vf.neg       v21, v14
    vf.cvt.f32.f16 v14, v21
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.h v21, [s3, v15]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v17
    vf.cvt.f16.f32 v15, v23
    vf.neg       v23, v15
    vf.cvt.f32.f16 v15, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.h v23, [s3, v11]             // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v11, v21
    v.cmp.lt     p3, v7, v33
    vf.neg       v7, v11
    vf.cvt.f32.f16 v11, v7
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v7, [s3, v13]              // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v13, v23
    v.cmp.lt     p1, v0, v33
    vf.neg       v0, v13
    vf.cvt.f32.f16 v13, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v0, [s3, v1]               // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v1, v7
    v.cmp.lt     p2, v8, v33
    vf.neg       v7, v1
    vf.cvt.f32.f16 v1, v7
    vf.cvt.f16.f32 v7, v0
    s.addi       s9, s8, #128
    @p3 v.st.scatter.h [s7, v34], v18
    v.cmp.lt     p3, v9, v12
    s.movz       s10, #256
    vf.neg       v0, v7
    vf.cvt.f32.f16 v7, v0
    @p1 v.st.scatter.h [s7, v22], v4
    v.cmp.lt     p1, v2, v12
    @p2 v.st.scatter.h [s7, v20], v14
    v.cmp.lt     p2, v3, v12
    @p3 v.st.scatter.h [s7, v16], v15
    v.cmp.lt     p3, v5, v17
    @p1 v.st.scatter.h [s7, v19], v11
    v.cmp.lt     p1, v6, v17
    @p2 v.st.scatter.h [s7, v24], v13
    @p3 v.st.scatter.h [s7, v10], v1
    @p1 v.st.scatter.h [s7, v25], v7
    s.mov        s8, s9
    s.cmp.lt     s9, s8, s10
    br.nz        s9, tiles_1
endtiles_2:
__rctx_next:
    s.addi       s1, s5, #4                      // the next program of this context: + 4
    s.cmp.lt     s8, s1, s6
    s.mov        s5, s1
    br.nz        s8, __rctx_program
    exit
