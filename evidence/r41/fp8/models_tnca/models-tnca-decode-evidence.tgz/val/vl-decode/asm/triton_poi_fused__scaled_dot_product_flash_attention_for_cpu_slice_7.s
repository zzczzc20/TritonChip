    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    v.movi       v1, #13
    v.movi       v2, #0
    s.rdspecial  s1, arg_base
    v.movi       v3, #26624
    v.splat      v4, s2
    v.sub        v5, v2, v1
    v.add        v6, v4, v0
    v.cmp.lt     p1, v1, v2
    v.sub        v0, v2, v6
    v.cmp.lt     p2, v6, v2
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.cmp.lt     p3, v6, v3
    v.movi       v3, #1
    s.ld.d       s4, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    @p2 v.sel        v4, v0, v6
    @p1 v.sel        v0, v5, v1
    v.movi       v5, #0
    v.movi       v7, #0
    s.movz       s1, #31
idiv_1:
    v.splat      v8, s1
    v.shl        v9, v7, v3
    v.lshr       v10, v4, v8
    v.cmp.lt     p1, v7, v2
    v.and        v11, v10, v3
    v.shl        v10, v3, v8
    v.or         v8, v9, v11
    s.subi       s5, s1, #1
    v.cmp.geu    p4, v8, v0
    p.or         p5, p1, p4
    v.sub        v9, v8, v0
    @p5 v.sel        v11, v10, v2
    @p5 v.sel        v10, v9, v8
    v.or         v8, v5, v11
    v.mov        v7, v10
    v.mov        v5, v8
    s.mov        s1, s5
    s.movz       s5, #0
    s.cmp.ge     s6, s1, s5
    br.nz        s6, idiv_1
    v.movi       v0, #0
    v.sub        v3, v2, v7
    v.sub        v2, v0, v6
    v.sub        v4, v0, v1
    v.cmp.lt     p1, v6, v0
    v.cmp.lt     p4, v1, v0
    @p2 v.sel        v5, v3, v7
    v.movi       v3, #1
    @p1 v.sel        v7, v2, v6
    @p4 v.sel        v2, v4, v1
    v.movi       v1, #0
    v.movi       v4, #0
    s.movz       s1, #31
idiv_2:
    v.splat      v8, s1
    v.shl        v9, v4, v3
    v.lshr       v10, v7, v8
    v.cmp.lt     p2, v4, v0
    v.and        v11, v10, v3
    v.shl        v10, v3, v8
    v.or         v8, v9, v11
    s.subi       s5, s1, #1
    v.cmp.geu    p5, v8, v2
    p.or         p6, p2, p5
    v.sub        v9, v8, v2
    @p6 v.sel        v11, v10, v0
    @p6 v.sel        v10, v9, v8
    v.or         v8, v1, v11
    v.mov        v4, v10
    v.mov        v1, v8
    s.mov        s1, s5
    s.movz       s5, #0
    s.cmp.ge     s6, s1, s5
    br.nz        s6, idiv_2
    p.xor        p2, p1, p4
    v.sub        v2, v0, v1
    v.movi       v0, #0
    @p2 v.sel        v3, v2, v1
    v.movi       v1, #127
    v.sub        v2, v0, v3
    v.cmp.lt     p1, v3, v0
    @p1 v.sel        v4, v2, v3
    v.movi       v2, #128
    v.and        v3, v4, v1
    v.movi       v1, #1664
    v.movi       v4, #0
    v.sub        v7, v0, v2
    v.sub        v8, v0, v3
    v.sub        v9, v4, v6
    v.sub        v10, v4, v1
    v.cmp.lt     p2, v2, v0
    v.cmp.lt     p4, v6, v4
    v.movi       v0, #1
    @p2 v.sel        v0, v7, v2
    v.cmp.lt     p2, v1, v4
    @p1 v.sel        v0, v8, v3
    v.movi       v3, #1
    @p4 v.sel        v7, v9, v6
    @p2 v.sel        v6, v10, v1
    v.movi       v1, #0
    v.movi       v8, #0
    s.movz       s1, #31
idiv_3:
    v.splat      v9, s1
    v.shl        v10, v8, v3
    v.lshr       v11, v7, v9
    v.cmp.lt     p1, v8, v4
    v.and        v12, v11, v3
    v.shl        v11, v3, v9
    v.or         v9, v10, v12
    s.subi       s5, s1, #1
    v.cmp.geu    p5, v9, v6
    p.or         p6, p1, p5
    v.sub        v10, v9, v6
    @p6 v.sel        v12, v11, v4
    @p6 v.sel        v11, v10, v9
    v.or         v9, v1, v12
    v.mov        v8, v11
    v.mov        v1, v9
    s.mov        s1, s5
    s.movz       s5, #0
    s.cmp.ge     s6, s1, s5
    br.nz        s6, idiv_3
    p.xor        p1, p4, p2
    v.sub        v3, v4, v1
    v.movi       v4, #0
    @p1 v.sel        v6, v3, v1
    v.movi       v1, #1
    v.sub        v3, v4, v6
    v.cmp.lt     p1, v6, v4
    @p1 v.sel        v7, v3, v6
    v.mul        v3, v5, v2
    v.lshr       v2, v7, v1
    v.movi       v1, #4096
    v.sub        v5, v4, v2
    v.add        v6, v0, v3
    @p1 v.sel        v0, v5, v2
    .li       s1, #1050163184
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.mul        v3, v0, v1
    v.movi       v0, #2
    v.add        v1, v6, v3
    s.shli       s1, s2, #2                      // element offset -> bytes (x4)
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v3, [s3, v1]               // index is in elements (ISA sec 9.1)
    v.sub        v1, v4, v0
    s.add        s2, s4, s1                      // &out_ptr0[...]
    v.cmp.lt     p1, v0, v4
    s.movz       s1, #128
    v.movi       v4, #1
    vf.cvt.bf16.f32 v4, v3
    @p1 v.sel        v3, v1, v0
    s.movz       s1, #4096
    vf.mul       v0, v4, v2
    @p3 v.st.w       [s2, #0], v0
__rctx_next:
    exit
