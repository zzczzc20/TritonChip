    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    v.movi       v1, #6016
    v.movi       v2, #0
    s.rdspecial  s1, arg_base
    v.sub        v3, v2, v1
    v.splat      v4, s2
    v.cmp.lt     p1, v1, v2
    v.add        v5, v4, v0
    s.ld.d       s2, [s1, #0]                    // out_ptr0: device_ptr64 at arg_base+0
    v.sub        v0, v2, v5
    v.cmp.lt     p2, v5, v2
    v.movi       v4, #1
    @p2 v.sel        v6, v0, v5
    @p1 v.sel        v0, v3, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s1, #31
idiv_1:
    v.splat      v8, s1
    v.shl        v9, v7, v4
    v.lshr       v10, v6, v8
    v.cmp.lt     p1, v7, v2
    v.and        v11, v10, v4
    v.shl        v10, v4, v8
    v.or         v8, v9, v11
    s.subi       s3, s1, #1
    v.cmp.geu    p3, v8, v0
    p.or         p4, p1, p3
    v.sub        v9, v8, v0
    @p4 v.sel        v11, v10, v2
    @p4 v.sel        v10, v9, v8
    v.or         v8, v3, v11
    v.mov        v7, v10
    v.mov        v3, v8
    s.mov        s1, s3
    s.movz       s3, #0
    s.cmp.ge     s4, s1, s3
    br.nz        s4, idiv_1
    v.movi       v0, #0
    v.sub        v3, v2, v7
    v.sub        v2, v0, v5
    v.sub        v4, v0, v1
    v.cmp.lt     p1, v5, v0
    v.cmp.lt     p3, v1, v0
    @p2 v.sel        v6, v3, v7
    v.movi       v3, #1
    @p1 v.sel        v7, v2, v5
    @p3 v.sel        v2, v4, v1
    v.movi       v1, #0
    v.movi       v4, #0
    s.movz       s1, #31
idiv_2:
    v.splat      v5, s1
    v.shl        v8, v4, v3
    v.lshr       v9, v7, v5
    v.cmp.lt     p2, v4, v0
    v.and        v10, v9, v3
    v.shl        v9, v3, v5
    v.or         v5, v8, v10
    s.subi       s3, s1, #1
    v.cmp.geu    p4, v5, v2
    p.or         p5, p2, p4
    v.sub        v8, v5, v2
    @p5 v.sel        v10, v9, v0
    @p5 v.sel        v9, v8, v5
    v.or         v5, v1, v10
    v.mov        v4, v9
    v.mov        v1, v5
    s.mov        s1, s3
    s.movz       s3, #0
    s.cmp.ge     s4, s1, s3
    br.nz        s4, idiv_2
    p.xor        p2, p1, p3
    v.sub        v2, v0, v1
    v.movi       v0, #8192
    @p2 v.sel        v3, v2, v1
    v.movi       v1, #0
    v.mul        v2, v3, v0
    s.movz       s1, #8192
    v.add        v0, v6, v2
    v.st.scatter.w [s2, v0], v1
__rctx_next:
    exit
