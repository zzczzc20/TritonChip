    s.rdspecial  s1, role_id
    s.rdspecial  s2, npid.x
__rctx_program:
    s.rdspecial  s3, arg_base
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.rdspecial  s4, arg_base
    s.ld.d       s5, [s3, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.shli       s6, s1, #4                      // x16 as a shift
    s.movz       s7, #0
    s.rdspecial  s8, pid.y
    s.rdspecial  s9, role_id
    s.movz       s10, #1280
    // tile epilogue: 16 rows through the vector unit, as f32 (ISA sec 9B)
    s.add        s11, s7, s6                     // the tile origin
    s.shli       s12, s8, #4                     // x16 as a shift
    s.muli       s8, s6, #4                      // a runtime tile origin, x4
    s.mul        s13, s9, s10
    v.iota       v0                              // arange(0, VLEN)
    s.ld.d       s9, [s4, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.splat      v1, s11
    s.add        s4, s7, s12                     // the tile origin
    s.muli       s7, s12, #1024                  // a runtime tile origin, x1024
    v.add        v2, v0, v1
    v.splat      v0, s4
    s.add        s10, s5, s8                     // the tile origin
    v.cmpi.lt    p1, v2, #256
    v.cmpi.lt    p2, v0, #16
    s.movz       s5, #16
    s.add        s8, s10, s7                     // the tile origin
    s.ld.d       s7, [s3, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.add        s3, s9, s13                     // this context's own scratch
    s.movz       s9, #256
    s.addi       s10, s3, #0                     // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s11, #64
    s.movz       s13, #4
    .li       s14, #68719476752
    .li       s15, #2207613190144
    p.and        p3, p1, p2
    s.addi       s16, s3, #256                   // 1024 bytes of repack scratch
    s.st.d       [s10, #0], s7
    s.st.d       [s10, #8], s9
    s.addi       s3, s4, #1
    v.splat      v0, s3
    s.addi       s3, s8, #1024                   // row 1
    v.cmpi.lt    p2, v0, #16
    p.and        p4, p1, p2
    s.st.d       [s10, #16], s5
    s.movz       s5, #1
    s.muli       s9, s5, #64
    s.add        s5, s16, s9
    s.st.d       [s10, #48], s11
    s.addi       s9, s4, #2
    v.splat      v0, s9
    s.addi       s9, s8, #2048                   // row 2
    v.cmpi.lt    p2, v0, #16
    p.and        p5, p1, p2
    s.st.d       [s10, #56], s13
    s.st.d       [s10, #88], s14
    s.movz       s11, #2
    s.muli       s14, s11, #64
    s.add        s11, s16, s14
    s.st.d       [s10, #104], s15
    fence.release.device
    td.load      d0, [s10]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s10, s4, #3
    s.addi       s14, s8, #3072                  // row 3
    v.splat      v0, s10
    s.movz       s10, #3
    s.muli       s15, s13, #64
    s.muli       s13, s10, #64
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s8, #0]
    v.cmpi.lt    p2, v0, #16
    p.and        p3, p1, p2
    s.add        s10, s16, s13
    s.add        s13, s16, s15
    v.st.w       [s16, #0], v1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s3, #0]
    s.addi       s3, s4, #4
    v.splat      v1, s3
    s.addi       s3, s8, #4096                   // row 4
    v.cmpi.lt    p2, v1, #16
    p.and        p4, p1, p2
    v.st.w       [s5, #0], v0
    s.addi       s5, s4, #5
    v.splat      v0, s5
    s.addi       s5, s8, #5120                   // row 5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p5 v.ld.w       v1, [s9, #0]
    v.cmpi.lt    p2, v0, #16
    p.and        p5, p1, p2
    s.movz       s9, #5
    s.muli       s15, s9, #64
    s.add        s9, s16, s15
    v.st.w       [s11, #0], v1
    s.addi       s11, s4, #6
    v.splat      v0, s11
    s.addi       s11, s8, #6144                  // row 6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s14, #0]
    v.cmpi.lt    p2, v0, #16
    p.and        p3, p1, p2
    s.movz       s14, #6
    s.muli       s15, s14, #64
    s.add        s14, s16, s15
    v.st.w       [s10, #0], v1
    s.addi       s10, s4, #7
    v.splat      v0, s10
    s.addi       s10, s8, #7168                  // row 7
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s3, #0]
    v.cmpi.lt    p2, v0, #16
    p.and        p4, p1, p2
    s.movz       s3, #7
    s.muli       s15, s3, #64
    s.add        s3, s16, s15
    v.st.w       [s13, #0], v1
    s.addi       s13, s4, #8
    v.splat      v0, s13
    s.addi       s13, s8, #8192                  // row 8
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p5 v.ld.w       v1, [s5, #0]
    v.cmpi.lt    p2, v0, #16
    p.and        p5, p1, p2
    s.movz       s5, #8
    s.muli       s15, s5, #64
    s.add        s5, s16, s15
    v.st.w       [s9, #0], v1
    s.addi       s9, s4, #9
    v.splat      v0, s9
    s.addi       s9, s8, #9216                   // row 9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s11, #0]
    v.cmpi.lt    p2, v0, #16
    p.and        p3, p1, p2
    s.movz       s11, #9
    s.muli       s15, s11, #64
    s.add        s11, s16, s15
    v.st.w       [s14, #0], v1
    s.addi       s14, s4, #10
    v.splat      v0, s14
    s.addi       s14, s8, #10240                 // row 10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s10, #0]
    v.cmpi.lt    p2, v0, #16
    p.and        p4, p1, p2
    s.movz       s10, #10
    s.muli       s15, s10, #64
    s.add        s10, s16, s15
    v.st.w       [s3, #0], v1
    s.addi       s3, s4, #11
    v.splat      v0, s3
    s.addi       s3, s8, #11264                  // row 11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p5 v.ld.w       v1, [s13, #0]
    v.cmpi.lt    p2, v0, #16
    p.and        p5, p1, p2
    s.movz       s13, #11
    s.muli       s15, s13, #64
    s.add        s13, s16, s15
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #12
    v.splat      v0, s5
    s.addi       s5, s8, #12288                  // row 12
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s9, #0]
    v.cmpi.lt    p2, v0, #16
    p.and        p3, p1, p2
    s.movz       s9, #12
    s.muli       s15, s9, #64
    s.add        s9, s16, s15
    v.st.w       [s11, #0], v1
    s.addi       s11, s4, #13
    v.splat      v0, s11
    s.addi       s11, s8, #13312                 // row 13
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s14, #0]
    v.cmpi.lt    p2, v0, #16
    p.and        p4, p1, p2
    s.movz       s14, #13
    s.muli       s15, s14, #64
    s.add        s14, s16, s15
    v.st.w       [s10, #0], v1
    s.addi       s10, s4, #14
    s.addi       s15, s4, #15
    v.splat      v0, s10
    s.addi       s4, s8, #14336                  // row 14
    v.splat      v1, s15
    s.movz       s10, #14
    s.addi       s15, s8, #15360                 // row 15
    s.muli       s8, s10, #64
    s.add        s10, s16, s8
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p5 v.ld.w       v2, [s3, #0]
    v.cmpi.lt    p2, v0, #16
    p.and        p5, p1, p2
    s.movz       s3, #0
    v.st.w       [s13, #0], v2
    s.muli       s8, s3, #64
    s.muli       s13, s3, #4
    // tl.trans: 16 columns, gathered %c179:scalar elements apart (ISA sec 9.1)
    v.iota       v0                              // arange(0, VLEN)
    s.add        s3, s16, s8
    s.add        s8, s3, s13
    s.movz       s3, #15
    s.muli       s13, s3, #64
    s.add        s3, s16, s13
    s.movz       s13, #16
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v2, [s5, #0]
    v.cmpi.lt    p2, v1, #16
    p.and        p3, p1, p2
    v.splat      v1, s13
    s.addi       s5, s8, #4                      // column 1
    s.addi       s13, s8, #8                     // column 2
    v.mul        v3, v0, v1                      // one element per source row
    v.st.w       [s9, #0], v2
    s.addi       s9, s8, #12                     // column 3
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s11, #0]
    s.addi       s11, s8, #16                    // column 4
    v.st.w       [s14, #0], v0
    s.addi       s14, s8, #20                    // column 5
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p5 v.ld.w       v0, [s4, #0]
    s.addi       s4, s8, #24                     // column 6
    v.st.w       [s10, #0], v0
    s.addi       s10, s8, #28                    // column 7
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s15, #0]
    s.addi       s15, s8, #32                    // column 8
    v.splat      v1, s12
    v.iota       v2                              // arange(0, VLEN)
    s.muli       s16, s12, #4
    v.st.w       [s3, #0], v0
    s.addi       s3, s8, #36                     // column 9
    fence.acq_rel.device
    v.add        v0, v1, v2
    v.movi       v1, #0
    v.splat      v2, s6
    v.cmpi.lt    p1, v0, #16
    v.cmp.ge     p2, v0, v1
    v.cmp.ge     p3, v2, v1
    v.cmpi.lt    p4, v2, #256
    p.and        p5, p2, p1
    p.and        p1, p3, p4
    p.and        p2, p5, p1
    v.ld.gather.w v0, [s8, v3]                   // index is in elements (ISA sec 9.1)
    v.ld.gather.w v1, [s5, v3]                   // index is in elements (ISA sec 9.1)
    s.addi       s5, s8, #40                     // column 10
    v.ld.gather.w v2, [s13, v3]                  // index is in elements (ISA sec 9.1)
    s.addi       s12, s8, #44                    // column 11
    v.movi       v4, #0
    v.ld.gather.w v5, [s9, v3]                   // index is in elements (ISA sec 9.1)
    s.addi       s9, s8, #48                     // column 12
    v.ld.gather.w v6, [s11, v3]                  // index is in elements (ISA sec 9.1)
    s.addi       s11, s8, #52                    // column 13
    v.ld.gather.w v7, [s14, v3]                  // index is in elements (ISA sec 9.1)
    s.addi       s13, s8, #56                    // column 14
    s.addi       s14, s8, #60                    // column 15
    v.ld.gather.w v8, [s4, v3]                   // index is in elements (ISA sec 9.1)
    s.muli       s4, s6, #64
    s.add        s8, s7, s4
    s.addi       s4, s6, #1
    s.add        s7, s8, s16
    s.movz       s8, #1
    v.splat      v9, s4
    s.movz       s4, #2
    s.muli       s16, s8, #64
    s.muli       s8, s4, #64
    v.cmp.ge     p1, v9, v4
    v.cmpi.lt    p3, v9, #256
    p.and        p4, p1, p3
    s.add        s4, s7, s16
    v.ld.gather.w v4, [s10, v3]                  // index is in elements (ISA sec 9.1)
    s.addi       s10, s6, #2
    p.and        p1, p5, p4
    v.splat      v9, s10
    s.add        s10, s7, s8
    v.ld.gather.w v10, [s15, v3]                 // index is in elements (ISA sec 9.1)
    v.movi       v11, #0
    v.cmp.ge     p3, v9, v11
    v.ld.gather.w v11, [s3, v3]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.w v12, [s5, v3]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.w v13, [s12, v3]                 // index is in elements (ISA sec 9.1)
    s.movz       s3, #3
    s.muli       s5, s3, #64
    v.ld.gather.w v14, [s9, v3]                  // index is in elements (ISA sec 9.1)
    s.addi       s3, s6, #3
    s.add        s8, s7, s5
    v.ld.gather.w v15, [s11, v3]                 // index is in elements (ISA sec 9.1)
    v.splat      v16, s3
    v.movi       v17, #0
    v.ld.gather.w v18, [s13, v3]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v19, [s14, v3]                 // index is in elements (ISA sec 9.1)
    s.addi       s3, s6, #4
    s.movz       s5, #4
    s.movz       s9, #5
    v.splat      v3, s3
    v.movi       v20, #0
    s.muli       s3, s5, #64
    s.muli       s5, s9, #64
    s.add        s9, s7, s3
    s.add        s3, s7, s5
    @p2 v.st.w       [s7, #0], v0
    s.addi       s5, s6, #5
    s.movz       s11, #6
    v.splat      v0, s5
    v.movi       v21, #0
    s.muli       s5, s11, #64
    v.cmpi.lt    p2, v9, #256
    p.and        p4, p3, p2
    v.cmp.ge     p2, v16, v17
    p.and        p3, p5, p4
    s.add        s11, s7, s5
    @p1 v.st.w       [s4, #0], v1
    s.addi       s4, s6, #6
    s.movz       s5, #7
    v.splat      v1, s4
    v.movi       v9, #0
    s.muli       s4, s5, #64
    v.cmpi.lt    p1, v16, #256
    p.and        p4, p2, p1
    v.cmp.ge     p1, v3, v20
    p.and        p2, p5, p4
    s.add        s5, s7, s4
    @p3 v.st.w       [s10, #0], v2
    s.addi       s4, s6, #7
    s.movz       s10, #8
    v.splat      v2, s4
    v.movi       v16, #0
    s.muli       s4, s10, #64
    v.cmpi.lt    p3, v3, #256
    p.and        p4, p1, p3
    v.cmp.ge     p1, v0, v21
    p.and        p3, p5, p4
    s.add        s10, s7, s4
    @p2 v.st.w       [s8, #0], v5
    s.addi       s4, s6, #8
    s.movz       s8, #9
    v.splat      v3, s4
    v.movi       v5, #0
    s.muli       s4, s8, #64
    v.cmpi.lt    p2, v0, #256
    p.and        p4, p1, p2
    v.cmp.ge     p1, v1, v9
    p.and        p2, p5, p4
    s.add        s8, s7, s4
    @p3 v.st.w       [s9, #0], v6
    s.addi       s4, s6, #9
    s.movz       s9, #10
    v.splat      v0, s4
    v.movi       v6, #0
    s.muli       s4, s9, #64
    v.cmpi.lt    p3, v1, #256
    p.and        p4, p1, p3
    v.cmp.ge     p1, v2, v16
    p.and        p3, p5, p4
    s.add        s9, s7, s4
    @p2 v.st.w       [s3, #0], v7
    s.addi       s3, s6, #10
    s.movz       s4, #11
    v.splat      v1, s3
    v.movi       v7, #0
    s.muli       s3, s4, #64
    v.cmpi.lt    p2, v2, #256
    p.and        p4, p1, p2
    v.cmp.ge     p1, v3, v5
    p.and        p2, p5, p4
    s.add        s4, s7, s3
    @p3 v.st.w       [s11, #0], v8
    s.addi       s3, s6, #11
    s.movz       s11, #12
    v.splat      v2, s3
    v.movi       v5, #0
    s.muli       s3, s11, #64
    v.cmpi.lt    p3, v3, #256
    p.and        p4, p1, p3
    v.cmp.ge     p1, v0, v6
    p.and        p3, p5, p4
    s.add        s11, s7, s3
    @p2 v.st.w       [s5, #0], v4
    s.addi       s3, s6, #12
    s.movz       s5, #13
    v.splat      v3, s3
    v.movi       v4, #0
    s.muli       s3, s5, #64
    v.cmpi.lt    p2, v0, #256
    p.and        p4, p1, p2
    v.cmp.ge     p1, v1, v7
    p.and        p2, p5, p4
    s.add        s5, s7, s3
    @p3 v.st.w       [s10, #0], v10
    s.addi       s3, s6, #13
    s.movz       s10, #14
    v.splat      v0, s3
    v.movi       v6, #0
    s.muli       s3, s10, #64
    v.cmpi.lt    p3, v1, #256
    p.and        p4, p1, p3
    v.cmp.ge     p1, v2, v5
    p.and        p3, p5, p4
    s.add        s10, s7, s3
    @p2 v.st.w       [s8, #0], v11
    s.addi       s3, s6, #14
    s.movz       s8, #15
    v.splat      v1, s3
    v.movi       v5, #0
    s.muli       s3, s8, #64
    v.cmpi.lt    p2, v2, #256
    p.and        p4, p1, p2
    v.cmp.ge     p1, v3, v4
    p.and        p2, p5, p4
    s.add        s8, s7, s3
    @p3 v.st.w       [s9, #0], v12
    s.addi       s3, s6, #15
    v.movi       v2, #0
    v.splat      v4, s3
    v.cmpi.lt    p3, v3, #256
    p.and        p4, p1, p3
    v.cmp.ge     p1, v0, v6
    p.and        p3, p5, p4
    @p2 v.st.w       [s4, #0], v13
    v.cmpi.lt    p2, v0, #256
    p.and        p4, p1, p2
    v.cmp.ge     p1, v1, v5
    p.and        p2, p5, p4
    @p3 v.st.w       [s11, #0], v14
    v.cmpi.lt    p3, v1, #256
    p.and        p4, p1, p3
    v.cmp.ge     p1, v4, v2
    p.and        p3, p5, p4
    @p2 v.st.w       [s5, #0], v15
    v.cmpi.lt    p2, v4, #256
    p.and        p4, p1, p2
    p.and        p1, p5, p4
    @p3 v.st.w       [s10, #0], v18
    @p1 v.st.w       [s8, #0], v19
__rctx_next:
    s.addi       s3, s1, #2                      // the next program of this context: + 2
    s.cmp.lt     s4, s3, s2
    s.mov        s1, s3
    br.nz        s4, __rctx_program
    exit
