# AOT ID: ['0_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/lq/clqqb5ca5vsurepmtigxuxvujjzsirkinmhk7nnx6bzwjhtm5lzw.py
# Topologically Sorted Source Nodes: [x, rms_norm], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   rms_norm => add, convert_element_type, convert_element_type_1, mean, mul, mul_1, pow_1, rsqrt
#   x => embedding
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 1][1, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "f16[512, 128][128, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %buf0 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf0]
#   %arg6_1 : Tensor "f16[128][1]tnca:0" = PlaceHolder[target=arg6_1]
#   %embedding : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %convert_element_type : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%embedding, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type, 2), kwargs = {})
#   %mean : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [2], True), kwargs = {})
#   %add : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean, 9.999999747378752e-06), kwargs = {})
#   %rsqrt : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %mul : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, %rsqrt), kwargs = {})
#   %mul_1 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul, %arg6_1), kwargs = {})
#   %convert_element_type_1 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_1, torch.float16), kwargs = {})
#   return %buf0,%convert_element_type_1
triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0 = async_compile.triton('triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 768}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0(in_ptr0, in_ptr1, in_ptr2, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
    _tmp7 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tl.device_assert((0 <= tmp1) & (tmp1 < 512), "index out of bounds: 0 <= tmp1 < 512")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 128*tmp1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp4 = tmp3.to(tl.float32)
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask, tmp8, _tmp7)
    tmp7 = triton_helpers.promote_to_tensor(tl.sum(_tmp7, 0))
    tmp9 = tl.load(in_ptr0 + (0))
    tmp10 = tl.broadcast_to(tmp9, [R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp20 = tl.load(in_ptr2 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp10) & (tmp10 < 512), "index out of bounds: 0 <= tmp10 < 512")
        tmp12 = tl.load(in_ptr1 + (r0_0 + 128*tmp10), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp13 = tmp12.to(tl.float32)
        tmp14 = tl.full([1], 128.0, tl.float32)
        tmp15 = (tmp7 / tmp14)
        tmp16 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp17 = tmp15 + tmp16
        tmp18 = libdevice.rsqrt(tmp17)
        tmp19 = tmp13 * tmp18
        tmp21 = tmp20.to(tl.float32)
        tmp22 = tmp19 * tmp21
        tmp23 = tmp22.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp23, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/a4/ca4cn3jqqievf6eonspradpkh26lndx7styde6xsfjqwgdnvfn6e.py
# Topologically Sorted Source Nodes: [x, rms_norm, linear], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear => mm, permute, view
#   rms_norm => add, convert_element_type, convert_element_type_1, mean, mul, mul_1, pow_1, rsqrt
#   x => embedding
# Graph fragment:
#   %convert_element_type_1 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0" = PlaceHolder[target=convert_element_type_1]
#   %arg7_1 : Tensor "f16[128, 128][128, 1]tnca:0" = PlaceHolder[target=arg7_1]
#   %embedding : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %convert_element_type : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%embedding, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type, 2), kwargs = {})
#   %mean : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [2], True), kwargs = {})
#   %add : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean, 9.999999747378752e-06), kwargs = {})
#   %rsqrt : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %mul : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, %rsqrt), kwargs = {})
#   %mul_1 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul, %arg6_1), kwargs = {})
#   %convert_element_type_1 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_1, torch.float16), kwargs = {})
#   %view : Tensor "f16[1, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_1, [1, 128]), kwargs = {})
#   %permute : Tensor "f16[128, 128][1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg7_1, [1, 0]), kwargs = {})
#   %mm : Tensor "f16[1, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view, %permute), kwargs = {})
#   return %mm
triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1 = async_compile.triton('triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1', 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 128
    K = 128
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 0
    stride_ak = 1
    stride_bk = 1
    stride_bn = 128

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 128*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 128*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 128*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 128*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/xb/cxbi2r2hn2raehpervsapbptrd4zfjpxaqpj3sz636amiftqzifq.py
# Topologically Sorted Source Nodes: [linear_1], Original ATen: [aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_1 => mm_1, permute_2, view_3
# Graph fragment:
#   %convert_element_type_1 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0" = PlaceHolder[target=convert_element_type_1]
#   %arg8_1 : Tensor "f16[64, 128][128, 1]tnca:0" = PlaceHolder[target=arg8_1]
#   %view_3 : Tensor "f16[1, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_1, [1, 128]), kwargs = {})
#   %permute_2 : Tensor "f16[128, 64][1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg8_1, [1, 0]), kwargs = {})
#   %mm_1 : Tensor "f16[1, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_3, %permute_2), kwargs = {})
#   return %mm_1
triton_tem_fused_mm_t_view_2 = async_compile.triton('triton_tem_fused_mm_t_view_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_mm_t_view_2', 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_mm_t_view_2(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 64
    K = 128
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 128
    stride_ak = 1
    stride_bk = 1
    stride_bn = 128

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 128*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 64*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 128*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 64*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/me/cmeb4yam2foes2xjz5p6zgztagm4srhlyhvvzebucjmcnoqseved.py
# Topologically Sorted Source Nodes: [linear, view, q, chunk, neg], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
# Source node to ATen node mapping:
#   chunk => split
#   linear => view_1
#   neg => neg
#   q => permute_1
#   view => view_2
# Graph fragment:
#   %mm : Tensor "f16[1, 128][128, 1]tnca:0" = PlaceHolder[target=mm]
#   %view_1 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [1, 1, 128]), kwargs = {})
#   %view_2 : Tensor "f16[1, 1, 4, 32][128, 128, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_1, [1, 1, 4, 32]), kwargs = {})
#   %permute_1 : Tensor "f16[1, 4, 1, 32][128, 32, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_2, [0, 2, 1, 3]), kwargs = {})
#   %split : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%permute_1, 16, -1), kwargs = {})
#   %neg : Tensor "f16[1, 4, 1, 16][64, 16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%getitem_1,), kwargs = {})
#   return %neg
triton_poi_fused__unsafe_view_neg_split_transpose_view_3 = async_compile.triton('triton_poi_fused__unsafe_view_neg_split_transpose_view_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 64}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_neg_split_transpose_view_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 384}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_neg_split_transpose_view_3(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 64
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 16)
    x1 = xindex // 16
    tmp0 = tl.load(in_ptr0 + (16 + x0 + 32*x1), xmask).to(tl.float32)
    tmp1 = -tmp0
    tl.store(out_ptr0 + (x0 + 32*x1), tmp1, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/bn/cbntkek6bjswiul3s3lr2rwctvxqa2cvzfbon7pmbxcyyswd6bjv.py
# Topologically Sorted Source Nodes: [linear, view, q, chunk, neg, cat], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
# Source node to ATen node mapping:
#   cat => cat
#   chunk => split
#   linear => view_1
#   neg => neg
#   q => permute_1
#   view => view_2
# Graph fragment:
#   %mm : Tensor "f16[1, 128][128, 1]tnca:0" = PlaceHolder[target=mm]
#   %view_1 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [1, 1, 128]), kwargs = {})
#   %view_2 : Tensor "f16[1, 1, 4, 32][128, 128, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_1, [1, 1, 4, 32]), kwargs = {})
#   %permute_1 : Tensor "f16[1, 4, 1, 32][128, 32, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_2, [0, 2, 1, 3]), kwargs = {})
#   %split : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%permute_1, 16, -1), kwargs = {})
#   %neg : Tensor "f16[1, 4, 1, 16][64, 16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%getitem_1,), kwargs = {})
#   %cat : Tensor "f16[1, 4, 1, 32][128, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg, %getitem], -1), kwargs = {})
#   return %buf5
triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4 = async_compile.triton('triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 64}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 384}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 64
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 16)
    x1 = xindex // 16
    tmp0 = tl.load(in_ptr0 + (x0 + 32*x1), xmask).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 32*x1), tmp0, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/ht/chtccedxjz6u5o7rue4cp5kg74rxacobrwo4sn7cswjqbyyxuop6.py
# Topologically Sorted Source Nodes: [linear_1, view_1, k, chunk_1, neg_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
# Source node to ATen node mapping:
#   chunk_1 => split_1
#   k => permute_3
#   linear_1 => view_4
#   neg_1 => neg_1
#   view_1 => view_5
# Graph fragment:
#   %mm_1 : Tensor "f16[1, 64][64, 1]tnca:0" = PlaceHolder[target=mm_1]
#   %view_4 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 1, 64]), kwargs = {})
#   %view_5 : Tensor "f16[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_4, [1, 1, 2, 32]), kwargs = {})
#   %permute_3 : Tensor "f16[1, 2, 1, 32][64, 32, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_5, [0, 2, 1, 3]), kwargs = {})
#   %split_1 : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%permute_3, 16, -1), kwargs = {})
#   %neg_1 : Tensor "f16[1, 2, 1, 16][32, 16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%getitem_3,), kwargs = {})
#   return %neg_1
triton_poi_fused__unsafe_view_neg_split_transpose_view_5 = async_compile.triton('triton_poi_fused__unsafe_view_neg_split_transpose_view_5', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 32}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_neg_split_transpose_view_5', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 192}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_neg_split_transpose_view_5(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 32
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 16)
    x1 = xindex // 16
    tmp0 = tl.load(in_ptr0 + (16 + x0 + 32*x1), xmask).to(tl.float32)
    tmp1 = -tmp0
    tl.store(out_ptr0 + (x0 + 32*x1), tmp1, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/yu/cyu57gcqcjqqr6oafjnyqetj2e53gblwkkfqq5bz455kirskx5ui.py
# Topologically Sorted Source Nodes: [linear_1, view_1, k, chunk_1, neg_1, cat_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
# Source node to ATen node mapping:
#   cat_1 => cat_1
#   chunk_1 => split_1
#   k => permute_3
#   linear_1 => view_4
#   neg_1 => neg_1
#   view_1 => view_5
# Graph fragment:
#   %mm_1 : Tensor "f16[1, 64][64, 1]tnca:0" = PlaceHolder[target=mm_1]
#   %view_4 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 1, 64]), kwargs = {})
#   %view_5 : Tensor "f16[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_4, [1, 1, 2, 32]), kwargs = {})
#   %permute_3 : Tensor "f16[1, 2, 1, 32][64, 32, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_5, [0, 2, 1, 3]), kwargs = {})
#   %split_1 : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%permute_3, 16, -1), kwargs = {})
#   %neg_1 : Tensor "f16[1, 2, 1, 16][32, 16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%getitem_3,), kwargs = {})
#   %cat_1 : Tensor "f16[1, 2, 1, 32][64, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg_1, %getitem_2], -1), kwargs = {})
#   return %buf8
triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6 = async_compile.triton('triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 32}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 192}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 32
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 16)
    x1 = xindex // 16
    tmp0 = tl.load(in_ptr0 + (x0 + 32*x1), xmask).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 32*x1), tmp0, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/rd/crd5nibaw5pou2sxdtcjaa7tsprv6o5ois6aqr27lyucd4obbcka.py
# Topologically Sorted Source Nodes: [linear_1, view_1, k, getitem, mul_2, mul_3, k_1, k_2], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
# Source node to ATen node mapping:
#   getitem => select
#   k => permute_3
#   k_1 => add_2
#   k_2 => cat_2
#   linear_1 => view_4
#   mul_2 => mul_4
#   mul_3 => mul_5
#   view_1 => view_5
# Graph fragment:
#   %arg4_1 : Tensor "f16[4, 1, 2, 128, 32][8192, 8192, 4096, 32, 1]tnca:0" = PlaceHolder[target=arg4_1]
#   %view_4 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 1, 64]), kwargs = {})
#   %view_5 : Tensor "f16[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_4, [1, 1, 2, 32]), kwargs = {})
#   %permute_3 : Tensor "f16[1, 2, 1, 32][64, 32, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_5, [0, 2, 1, 3]), kwargs = {})
#   %select : Tensor "f16[1, 2, 128, 32][8192, 4096, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg4_1, 0, 0), kwargs = {})
#   %mul_4 : Tensor "f16[1, 2, 1, 32][64, 32, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_3, %arg2_1), kwargs = {})
#   %mul_5 : Tensor "f16[1, 2, 1, 32][64, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_1, %arg3_1), kwargs = {})
#   %add_2 : Tensor "f16[1, 2, 1, 32][64, 32, 32, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_4, %mul_5), kwargs = {})
#   %cat_2 : Tensor "f16[1, 2, 129, 32][8256, 4128, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%select, %add_2], 2), kwargs = {})
#   return %buf10
triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_7 = async_compile.triton('triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_7', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 8192}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_7', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 49152}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_7(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 8192
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x2 = xindex
    x0 = (xindex % 4096)
    x1 = xindex // 4096
    tmp0 = tl.load(in_ptr0 + (x2), None).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 4128*x1), tmp0, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/np/cnp2owpacry33drgtvhjm533ybkndfnkrx7kpxwyaqe3dpdky26h.py
# Topologically Sorted Source Nodes: [linear_1, view_1, k, mul_2, mul_3, k_1, stack], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten.stack]
# Source node to ATen node mapping:
#   k => permute_3
#   k_1 => add_2
#   linear_1 => view_4
#   mul_2 => mul_4
#   mul_3 => mul_5
#   stack => cat_16
#   view_1 => view_5
# Graph fragment:
#   %mm_1 : Tensor "f16[1, 64][64, 1]tnca:0" = PlaceHolder[target=mm_1]
#   %arg2_1 : Tensor "f16[1, 32][32, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %cat_1 : Tensor "f16[1, 2, 1, 32][64, 32, 32, 1]tnca:0" = PlaceHolder[target=cat_1]
#   %arg3_1 : Tensor "f16[1, 32][32, 1]tnca:0" = PlaceHolder[target=arg3_1]
#   %add_2 : Tensor "f16[1, 2, 1, 32][8256, 4128, 32, 1]tnca:0" = PlaceHolder[target=add_2]
#   %view_4 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 1, 64]), kwargs = {})
#   %view_5 : Tensor "f16[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_4, [1, 1, 2, 32]), kwargs = {})
#   %permute_3 : Tensor "f16[1, 2, 1, 32][64, 32, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_5, [0, 2, 1, 3]), kwargs = {})
#   %mul_4 : Tensor "f16[1, 2, 1, 32][64, 32, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_3, %arg2_1), kwargs = {})
#   %mul_5 : Tensor "f16[1, 2, 1, 32][64, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_1, %arg3_1), kwargs = {})
#   %add_2 : Tensor "f16[1, 2, 1, 32][64, 32, 32, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_4, %mul_5), kwargs = {})
#   %cat_16 : Tensor "f16[4, 2, 1, 32][64, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%add_2, %add_9, %add_16, %add_23],), kwargs = {})
#   return %add_2,%buf129
triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8 = async_compile.triton('triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 64}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'out_ptr0': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 4, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 896}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 64
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x2 = xindex
    x0 = (xindex % 32)
    x1 = xindex // 32
    tmp0 = tl.load(in_ptr0 + (x2), xmask).to(tl.float32)
    tmp1 = tl.load(in_ptr1 + (x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp3 = tl.load(in_ptr2 + (x2), xmask).to(tl.float32)
    tmp4 = tl.load(in_ptr3 + (x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp2 = tmp0 * tmp1
    tmp5 = tmp3 * tmp4
    tmp6 = tmp2 + tmp5
    tl.store(out_ptr0 + (x0 + 4128*x1), tmp6, xmask)
    tl.store(out_ptr1 + (x2), tmp6, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/5e/c5ehk33hajx6v3qhujdedyvdv74yqirhnlzmmomg726vppu3gs2y.py
# Topologically Sorted Source Nodes: [linear, view, q, mul, mul_1, q_1, o, getitem_6, expand, k_3], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
# Source node to ATen node mapping:
#   expand => expand
#   getitem_6 => unsqueeze
#   k_3 => clone, view_9
#   linear => view_1
#   mul => mul_2
#   mul_1 => mul_3
#   o => bmm, convert_element_type_8, convert_element_type_9, mul_6, mul_7, permute_6, view_11, view_12
#   q => permute_1
#   q_1 => add_1
#   view => view_2
# Graph fragment:
#   %mm : Tensor "f16[1, 128][128, 1]tnca:0" = PlaceHolder[target=mm]
#   %arg2_1 : Tensor "f16[1, 32][32, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %cat : Tensor "f16[1, 4, 1, 32][128, 32, 32, 1]tnca:0" = PlaceHolder[target=cat]
#   %arg3_1 : Tensor "f16[1, 32][32, 1]tnca:0" = PlaceHolder[target=arg3_1]
#   %cat_2 : Tensor "f16[1, 2, 129, 32][8256, 4128, 32, 1]tnca:0" = PlaceHolder[target=cat_2]
#   %view_1 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [1, 1, 128]), kwargs = {})
#   %view_2 : Tensor "f16[1, 1, 4, 32][128, 128, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_1, [1, 1, 4, 32]), kwargs = {})
#   %permute_1 : Tensor "f16[1, 4, 1, 32][128, 32, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_2, [0, 2, 1, 3]), kwargs = {})
#   %mul_2 : Tensor "f16[1, 4, 1, 32][128, 32, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_1, %arg2_1), kwargs = {})
#   %mul_3 : Tensor "f16[1, 4, 1, 32][128, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat, %arg3_1), kwargs = {})
#   %add_1 : Tensor "f16[1, 4, 1, 32][128, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_2, %mul_3), kwargs = {})
#   %convert_element_type_8 : Tensor "f32[1, 4, 1, 32][128, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_1, torch.float32), kwargs = {})
#   %mul_6 : Tensor "f32[1, 4, 1, 32][128, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%convert_element_type_8, 0.42044820762685725), kwargs = {})
#   %view_11 : Tensor "f32[4, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_2, [4, 1, 32]), kwargs = {})
#   %unsqueeze : Tensor "f16[1, 2, 1, 129, 32][8256, 4128, 4128, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%cat_2, 2), kwargs = {})
#   %expand : Tensor "f16[1, 2, 2, 129, 32][8256, 4128, 0, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze, [1, 2, 2, 129, 32]), kwargs = {})
#   %clone : Tensor "f16[1, 2, 2, 129, 32][16512, 8256, 4128, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand,), kwargs = {memory_format: torch.contiguous_format})
#   %view_9 : Tensor "f16[1, 4, 129, 32][16512, 4128, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 4, 129, 32]), kwargs = {})
#   %convert_element_type_9 : Tensor "f32[1, 4, 129, 32][16512, 4128, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_9, torch.float32), kwargs = {})
#   %permute_6 : Tensor "f32[1, 4, 32, 129][16512, 4128, 1, 32]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_9, [0, 1, 3, 2]), kwargs = {})
#   %mul_7 : Tensor "f32[1, 4, 32, 129][16512, 4128, 1, 32]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%permute_6, 0.42044820762685725), kwargs = {})
#   %view_12 : Tensor "f32[4, 32, 129][4128, 1, 32]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_3, [4, 32, 129]), kwargs = {})
#   %bmm : Tensor "f32[4, 1, 129][129, 129, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_11, %view_12), kwargs = {})
#   return %bmm
triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1024, 'r0_': 32},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 4128, 'r0_': 17152}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 516
    XBLOCK: tl.constexpr = 1
    r0_numel = 32
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x1 = xindex // 129
    x0 = (xindex % 129)
    _tmp15 = tl.full([R0_BLOCK], 0, tl.float32)
    x3 = xindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_2 + 32*x1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tl.load(in_ptr1 + (r0_2), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp3 = tl.load(in_ptr2 + (r0_2 + 32*x1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp4 = tl.load(in_ptr3 + (r0_2), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp10 = tl.load(in_ptr4 + (r0_2 + 32*x0 + 4128*(x1 // 2)), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp2 = tmp0 * tmp1
        tmp5 = tmp3 * tmp4
        tmp6 = tmp2 + tmp5
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tl.full([1], 0.42044820762685725, tl.float32)
        tmp9 = tmp7 * tmp8
        tmp11 = tmp10.to(tl.float32)
        tmp12 = tmp11 * tmp8
        tmp13 = tmp9 * tmp12
        tmp14 = tl.broadcast_to(tmp13, [R0_BLOCK])
        tmp16 = _tmp15 + tmp14
        _tmp15 = tl.where(r0_mask, tmp16, _tmp15)
    tmp15 = triton_helpers.promote_to_tensor(tl.sum(_tmp15, 0))
    tl.store(out_ptr0 + (x3), tmp15, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/z4/cz4m24ir625o4vokvztvbnuq4wnjbzlowchiybadorj6zas3giud.py
# Topologically Sorted Source Nodes: [o], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   o => amax, any_1, eq, exp, logical_not, sub, sum_1, view_13
# Graph fragment:
#   %bmm : Tensor "f32[4, 1, 129][129, 129, 1]tnca:0" = PlaceHolder[target=bmm]
#   %amax : Tensor "f32[1, 4, 1, 1][4, 1, 4, 4]tnca:0" = PlaceHolder[target=amax]
#   %exp : Tensor "f32[1, 4, 1, 129][516, 129, 516, 1]tnca:0" = PlaceHolder[target=exp]
#   %view_13 : Tensor "f32[1, 4, 1, 129][516, 129, 129, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm, [1, 4, 1, 129]), kwargs = {})
#   %eq : Tensor "b8[1, 4, 1, 129][516, 129, 129, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.eq.Scalar](args = (%view_13, -inf), kwargs = {})
#   %logical_not : Tensor "b8[1, 4, 1, 129][516, 129, 129, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%eq,), kwargs = {})
#   %any_1 : Tensor "b8[1, 4, 1, 1][4, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.any.dim](args = (%logical_not, -1, True), kwargs = {})
#   %amax : Tensor "f32[1, 4, 1, 1][4, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.amax.default](args = (%view_13, [-1], True), kwargs = {})
#   %sub : Tensor "f32[1, 4, 1, 129][516, 129, 129, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%view_13, %amax), kwargs = {})
#   %exp : Tensor "f32[1, 4, 1, 129][516, 129, 129, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.exp.default](args = (%sub,), kwargs = {})
#   %sum_1 : Tensor "f32[1, 4, 1, 1][4, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%exp, [-1], True), kwargs = {})
#   return %any_1,%amax,%exp,%sum_1
triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 4, 'r0_': 256},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*i1', 'out_ptr2': '*fp32', 'out_ptr3': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 2, 'num_store': 3, 'num_reduction': 3, 'autotune_hints': set(), 'tiling_scores': {'x': 20, 'r0_': 6192}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10(in_ptr0, out_ptr0, out_ptr2, out_ptr3, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 4
    XBLOCK: tl.constexpr = 1
    r0_numel = 129
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    _tmp7 = tl.full([R0_BLOCK], False, tl.int1)
    _tmp11 = tl.full([R0_BLOCK], float("-inf"), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 129*x0), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.full([1], float("-inf"), tl.float32)
        tmp2 = tmp0 == tmp1
        tmp3 = tmp2 == 0
        tmp4 = tmp3.to(tl.int64)
        tmp5 = (tmp4 != 0)
        tmp6 = tl.broadcast_to(tmp5, [R0_BLOCK])
        tmp8 = _tmp7 | tmp6
        _tmp7 = tl.where(r0_mask, tmp8, _tmp7)
        tmp10 = tl.broadcast_to(tmp0, [R0_BLOCK])
        tmp12 = tl.maximum(_tmp11, tmp10, tl.PropagateNan.ALL)
        _tmp11 = tl.where(r0_mask, tmp12, _tmp11)
    tmp9 = _tmp7.to(tl.int8)
    tmp7 = triton_helpers.promote_to_tensor(triton_helpers.any(tmp9, 0))
    tmp11 = triton_helpers.promote_to_tensor(triton_helpers.max2(_tmp11, 0))
    tl.store(out_ptr0 + (x0), tmp7, None)
    _tmp17 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp13 = tl.load(in_ptr0 + (r0_1 + 129*x0), r0_mask, eviction_policy='evict_first', other=0.0)
        tmp14 = tmp13 - tmp11
        tmp15 = libdevice.exp(tmp14)
        tmp16 = tl.broadcast_to(tmp15, [R0_BLOCK])
        tmp18 = _tmp17 + tmp16
        _tmp17 = tl.where(r0_mask, tmp18, _tmp17)
        tl.store(out_ptr2 + (r0_1 + 129*x0), tmp15, r0_mask)
    tmp17 = triton_helpers.promote_to_tensor(tl.sum(_tmp17, 0))
    tl.store(out_ptr3 + (x0), tmp17, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/dc/cdcsftjqsplc622zhu23wgmpkm2gyxhdfa6uukvrqpnwbweif3ew.py
# Topologically Sorted Source Nodes: [getitem_1, linear_2, view_2, v, v_1], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
# Source node to ATen node mapping:
#   getitem_1 => select_1
#   linear_2 => view_7
#   v => permute_5
#   v_1 => cat_3
#   view_2 => view_8
# Graph fragment:
#   %mm_2 : Tensor "f16[1, 64][64, 1]tnca:0" = PlaceHolder[target=mm_2]
#   %select_1 : Tensor "f16[1, 2, 128, 32][8192, 4096, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg5_1, 0, 0), kwargs = {})
#   %view_7 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_2, [1, 1, 64]), kwargs = {})
#   %view_8 : Tensor "f16[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_7, [1, 1, 2, 32]), kwargs = {})
#   %permute_5 : Tensor "f16[1, 2, 1, 32][64, 32, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_8, [0, 2, 1, 3]), kwargs = {})
#   %cat_3 : Tensor "f16[1, 2, 129, 32][8256, 4128, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%select_1, %permute_5], 2), kwargs = {})
#   return %buf20
triton_poi_fused__unsafe_view_cat_select_transpose_view_11 = async_compile.triton('triton_poi_fused__unsafe_view_cat_select_transpose_view_11', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 64}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_cat_select_transpose_view_11', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 384}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_cat_select_transpose_view_11(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 64
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x2 = xindex
    x0 = (xindex % 32)
    x1 = xindex // 32
    tmp0 = tl.load(in_ptr0 + (x2), xmask).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 4128*x1), tmp0, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/3v/c3vfojknfi5eomry3o5bm67hlsn3gc6qft65qcnnogn4x7prmegs.py
# Topologically Sorted Source Nodes: [o, getitem_7, expand_1, v_2], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
# Source node to ATen node mapping:
#   expand_1 => expand_1
#   getitem_7 => unsqueeze_1
#   o => bmm_1, convert_element_type_10, convert_element_type_11, div, full_default, logical_not_1, view_14, view_15, view_16, where
#   v_2 => clone_1, view_10
# Graph fragment:
#   %any_1 : Tensor "b8[1, 4, 1, 1][4, 1, 4, 4]tnca:0" = PlaceHolder[target=any_1]
#   %exp : Tensor "f32[1, 4, 1, 129][516, 129, 516, 1]tnca:0" = PlaceHolder[target=exp]
#   %sum_1 : Tensor "f32[1, 4, 1, 1][4, 1, 4, 4]tnca:0" = PlaceHolder[target=sum_1]
#   %cat_3 : Tensor "f16[1, 2, 129, 32][8256, 4128, 32, 1]tnca:0" = PlaceHolder[target=cat_3]
#   %bmm_1 : Tensor "f32[4, 1, 32][32, 32, 1]tnca:0" = PlaceHolder[target=bmm_1]
#   %logical_not_1 : Tensor "b8[1, 4, 1, 1][4, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%any_1,), kwargs = {})
#   %full_default : Tensor "f32[1, 4, 1, 129][516, 129, 129, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([1, 4, 1, 129], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %div : Tensor "f32[1, 4, 1, 129][516, 129, 129, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp, %sum_1), kwargs = {})
#   %where : Tensor "f32[1, 4, 1, 129][516, 129, 129, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_not_1, %full_default, %div), kwargs = {})
#   %view_14 : Tensor "f32[4, 1, 129][129, 129, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_4, [4, 1, 129]), kwargs = {})
#   %unsqueeze_1 : Tensor "f16[1, 2, 1, 129, 32][8256, 4128, 4128, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%cat_3, 2), kwargs = {})
#   %expand_1 : Tensor "f16[1, 2, 2, 129, 32][8256, 4128, 0, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [1, 2, 2, 129, 32]), kwargs = {})
#   %clone_1 : Tensor "f16[1, 2, 2, 129, 32][16512, 8256, 4128, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_1,), kwargs = {memory_format: torch.contiguous_format})
#   %view_10 : Tensor "f16[1, 4, 129, 32][16512, 4128, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_1, [1, 4, 129, 32]), kwargs = {})
#   %convert_element_type_10 : Tensor "f32[1, 4, 129, 32][16512, 4128, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_10, torch.float32), kwargs = {})
#   %view_15 : Tensor "f32[4, 129, 32][4128, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_5, [4, 129, 32]), kwargs = {})
#   %bmm_1 : Tensor "f32[4, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_14, %view_15), kwargs = {})
#   %view_16 : Tensor "f32[1, 4, 1, 32][128, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_1, [1, 4, 1, 32]), kwargs = {})
#   %convert_element_type_11 : Tensor "f16[1, 4, 1, 32][128, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_16, torch.float16), kwargs = {})
#   return %bmm_1,%convert_element_type_11
triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 128, 'r0_': 256},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i1', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 4, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 17024, 'r0_': 2064}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 128
    XBLOCK: tl.constexpr = 1
    r0_numel = 129
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x1 = xindex // 32
    tmp0 = tl.load(in_ptr0 + (x1), None, eviction_policy='evict_last').to(tl.int1)
    tmp3 = tl.load(in_ptr2 + (x1), None, eviction_policy='evict_last')
    x0 = (xindex % 32)
    _tmp11 = tl.full([R0_BLOCK], 0, tl.float32)
    x3 = xindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp2 = tl.load(in_ptr1 + (r0_2 + 129*x1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp7 = tl.load(in_ptr3 + (x0 + 32*r0_2 + 4128*(x1 // 2)), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp1 = tmp0 == 0
        tmp4 = (tmp2 / tmp3)
        tmp5 = tl.full([1], 0.0, tl.float32)
        tmp6 = tl.where(tmp1, tmp5, tmp4)
        tmp8 = tmp7.to(tl.float32)
        tmp9 = tmp6 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask, tmp12, _tmp11)
    tmp11 = triton_helpers.promote_to_tensor(tl.sum(_tmp11, 0))
    tmp13 = tmp11.to(tl.float32)
    tl.store(out_ptr1 + (x3), tmp13, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/2q/c2qzvsxjl2kvidupllggirfdtpibxtqadnk4c6oud5z6l6x4v4mx.py
# Topologically Sorted Source Nodes: [x, h, x_1, y], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   h => view_19
#   x => embedding
#   x_1 => add_3
#   y => add_4, convert_element_type_15, convert_element_type_16, mean_1, mul_8, mul_9, pow_2, rsqrt_1
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 1][1, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "f16[512, 128][128, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %mm_3 : Tensor "f16[1, 128][128, 1]tnca:0" = PlaceHolder[target=mm_3]
#   %buf25 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf25]
#   %arg11_1 : Tensor "f16[128][1]tnca:0" = PlaceHolder[target=arg11_1]
#   %embedding : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %view_19 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [1, 1, 128]), kwargs = {})
#   %add_3 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_19), kwargs = {})
#   %convert_element_type_15 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_3, torch.float32), kwargs = {})
#   %pow_2 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_15, 2), kwargs = {})
#   %mean_1 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_2, [2], True), kwargs = {})
#   %add_4 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_1, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_1 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_4,), kwargs = {})
#   %mul_8 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_15, %rsqrt_1), kwargs = {})
#   %mul_9 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_8, %arg11_1), kwargs = {})
#   %convert_element_type_16 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_9, torch.float16), kwargs = {})
#   return %buf25,%convert_element_type_16
triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_13 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_13', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_13', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 1024}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_13(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr2, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    _tmp9 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp4 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp1) & (tmp1 < 512), "index out of bounds: 0 <= tmp1 < 512")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 128*tmp1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp5 = tmp3 + tmp4
        tmp6 = tmp5.to(tl.float32)
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask, tmp10, _tmp9)
    tmp9 = triton_helpers.promote_to_tensor(tl.sum(_tmp9, 0))
    tmp11 = tl.load(in_ptr0 + (0))
    tmp12 = tl.broadcast_to(tmp11, [R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr2, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp15 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp24 = tl.load(in_ptr3 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp12) & (tmp12 < 512), "index out of bounds: 0 <= tmp12 < 512")
        tmp14 = tl.load(in_ptr1 + (r0_0 + 128*tmp12), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp16 = tmp14 + tmp15
        tmp17 = tmp16.to(tl.float32)
        tmp18 = tl.full([1], 128.0, tl.float32)
        tmp19 = (tmp9 / tmp18)
        tmp20 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp21 = tmp19 + tmp20
        tmp22 = libdevice.rsqrt(tmp21)
        tmp23 = tmp17 * tmp22
        tmp25 = tmp24.to(tl.float32)
        tmp26 = tmp23 * tmp25
        tmp27 = tmp26.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp27, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/f5/cf5nlpsnkcda6caekqnvu35yesf7h7mg2tpksvit4xzr5s7hb4zz.py
# Topologically Sorted Source Nodes: [linear_4], Original ATen: [aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_4 => mm_4, permute_11, view_20
# Graph fragment:
#   %convert_element_type_16 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0" = PlaceHolder[target=convert_element_type_16]
#   %arg12_1 : Tensor "f16[352, 128][128, 1]tnca:0" = PlaceHolder[target=arg12_1]
#   %view_20 : Tensor "f16[1, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_16, [1, 128]), kwargs = {})
#   %permute_11 : Tensor "f16[128, 352][1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg12_1, [1, 0]), kwargs = {})
#   %mm_4 : Tensor "f16[1, 352][352, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_20, %permute_11), kwargs = {})
#   return %mm_4
triton_tem_fused_mm_t_view_14 = async_compile.triton('triton_tem_fused_mm_t_view_14', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_mm_t_view_14', 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_mm_t_view_14(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 352
    K = 128
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 128
    stride_ak = 1
    stride_bk = 1
    stride_bn = 128

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 128*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 352*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 128*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 352*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/fq/cfqjhs6zzf7qwxef3pvcgwo2gh2qne3hf5a5wunmv6fvcri6k7yj.py
# Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_4], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
# Source node to ATen node mapping:
#   linear_4 => view_21
#   linear_5 => mm_5, permute_12, view_22, view_23
#   mul_4 => mul_10
#   silu => add_5, convert_element_type_19, convert_element_type_20, div_1, exp_1, neg_2
# Graph fragment:
#   %convert_element_type_16 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0" = PlaceHolder[target=convert_element_type_16]
#   %arg13_1 : Tensor "f16[352, 128][128, 1]tnca:0" = PlaceHolder[target=arg13_1]
#   %mm_4 : Tensor "f16[1, 352][352, 1]tnca:0" = PlaceHolder[target=mm_4]
#   %mm_5 : Tensor "f16[1, 352][352, 1]tnca:0" = PlaceHolder[target=mm_5]
#   %view_21 : Tensor "f16[1, 1, 352][352, 352, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_4, [1, 1, 352]), kwargs = {})
#   %convert_element_type_19 : Tensor "f32[1, 1, 352][352, 352, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_21, torch.float32), kwargs = {})
#   %neg_2 : Tensor "f32[1, 1, 352][352, 352, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_19,), kwargs = {})
#   %exp_1 : Tensor "f32[1, 1, 352][352, 352, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_2,), kwargs = {})
#   %add_5 : Tensor "f32[1, 1, 352][352, 352, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp_1, 1), kwargs = {})
#   %div_1 : Tensor "f32[1, 1, 352][352, 352, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_19, %add_5), kwargs = {})
#   %convert_element_type_20 : Tensor "f16[1, 1, 352][352, 352, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_1, torch.float16), kwargs = {})
#   %view_22 : Tensor "f16[1, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_16, [1, 128]), kwargs = {})
#   %permute_12 : Tensor "f16[128, 352][1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg13_1, [1, 0]), kwargs = {})
#   %mm_5 : Tensor "f16[1, 352][352, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_22, %permute_12), kwargs = {})
#   %view_23 : Tensor "f16[1, 1, 352][352, 352, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_5, [1, 1, 352]), kwargs = {})
#   %mul_10 : Tensor "f16[1, 1, 352][352, 352, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_20, %view_23), kwargs = {})
#   return %mm_5,%mul_10
triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15 = async_compile.triton('triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'in_ptr2': '*fp16', 'out_ptr1': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15', 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15(arg_A, arg_B, in_ptr2, out_ptr1):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 352
    K = 128
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 128
    stride_ak = 1
    stride_bk = 1
    stride_bn = 128

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 128*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 352*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 128*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 352*idx_m
    tmp0 = acc.to(tl.float16)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tl.load(in_ptr2 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), mask).to(tl.float32)
    tmp3 = tmp2.to(tl.float32)
    tmp4 = -tmp3
    tmp5 = libdevice.exp(tmp4)
    tmp6 = tl.full([1], 1.0, tl.float32)
    tmp7 = tmp5 + tmp6
    tmp8 = (tmp3 / tmp7)
    tmp9 = tmp8.to(tl.float32)
    tmp10 = tmp9 * tmp1
    tl.store(out_ptr1 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), tmp10, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/zj/czjqqq4tenzo7o4s7e7rbw5m6bpkixt7gkro4zf5xueope4hy5hw.py
# Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_4, linear_6], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_4 => view_21
#   linear_5 => view_23
#   linear_6 => mm_6, permute_13, view_24
#   mul_4 => mul_10
#   silu => add_5, convert_element_type_19, convert_element_type_20, div_1, exp_1, neg_2
# Graph fragment:
#   %mul_10 : Tensor "f16[1, 1, 352][352, 352, 1]tnca:0" = PlaceHolder[target=mul_10]
#   %arg14_1 : Tensor "f16[128, 352][352, 1]tnca:0" = PlaceHolder[target=arg14_1]
#   %view_21 : Tensor "f16[1, 1, 352][352, 352, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_4, [1, 1, 352]), kwargs = {})
#   %convert_element_type_19 : Tensor "f32[1, 1, 352][352, 352, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_21, torch.float32), kwargs = {})
#   %neg_2 : Tensor "f32[1, 1, 352][352, 352, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_19,), kwargs = {})
#   %exp_1 : Tensor "f32[1, 1, 352][352, 352, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_2,), kwargs = {})
#   %add_5 : Tensor "f32[1, 1, 352][352, 352, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp_1, 1), kwargs = {})
#   %div_1 : Tensor "f32[1, 1, 352][352, 352, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_19, %add_5), kwargs = {})
#   %convert_element_type_20 : Tensor "f16[1, 1, 352][352, 352, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_1, torch.float16), kwargs = {})
#   %view_23 : Tensor "f16[1, 1, 352][352, 352, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_5, [1, 1, 352]), kwargs = {})
#   %mul_10 : Tensor "f16[1, 1, 352][352, 352, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_20, %view_23), kwargs = {})
#   %view_24 : Tensor "f16[1, 352][352, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mul_10, [1, 352]), kwargs = {})
#   %permute_13 : Tensor "f16[352, 128][1, 352]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg14_1, [1, 0]), kwargs = {})
#   %mm_6 : Tensor "f16[1, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_24, %permute_13), kwargs = {})
#   return %mm_6
triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16 = async_compile.triton('triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16', 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 128
    K = 352
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 0
    stride_ak = 1
    stride_bk = 1
    stride_bn = 352

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 352*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 128*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 352*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 128*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/5j/c5jd72csbhxgy3xjxnz2ajeh6iytqqbi6fa5xuowdvwcudehtur7.py
# Topologically Sorted Source Nodes: [x, h, x_1, linear_6, x_2, rms_norm_2], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   h => view_19
#   linear_6 => view_25
#   rms_norm_2 => add_7, convert_element_type_25, convert_element_type_26, mean_2, mul_11, mul_12, pow_3, rsqrt_2
#   x => embedding
#   x_1 => add_3
#   x_2 => add_6
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 1][1, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "f16[512, 128][128, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %mm_3 : Tensor "f16[1, 128][128, 1]tnca:0" = PlaceHolder[target=mm_3]
#   %mm_6 : Tensor "f16[1, 128][128, 1]tnca:0" = PlaceHolder[target=mm_6]
#   %buf31 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf31]
#   %arg15_1 : Tensor "f16[128][1]tnca:0" = PlaceHolder[target=arg15_1]
#   %embedding : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %view_19 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [1, 1, 128]), kwargs = {})
#   %add_3 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_19), kwargs = {})
#   %view_25 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_6, [1, 1, 128]), kwargs = {})
#   %add_6 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_3, %view_25), kwargs = {})
#   %convert_element_type_25 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_6, torch.float32), kwargs = {})
#   %pow_3 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_25, 2), kwargs = {})
#   %mean_2 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_3, [2], True), kwargs = {})
#   %add_7 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_2, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_2 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_7,), kwargs = {})
#   %mul_11 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_25, %rsqrt_2), kwargs = {})
#   %mul_12 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_11, %arg15_1), kwargs = {})
#   %convert_element_type_26 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_12, torch.float16), kwargs = {})
#   return %buf31,%convert_element_type_26
triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 1280}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr2, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr3, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    _tmp11 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp4 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp6 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp1) & (tmp1 < 512), "index out of bounds: 0 <= tmp1 < 512")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 128*tmp1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp5 = tmp3 + tmp4
        tmp7 = tmp5 + tmp6
        tmp8 = tmp7.to(tl.float32)
        tmp9 = tmp8 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask, tmp12, _tmp11)
    tmp11 = triton_helpers.promote_to_tensor(tl.sum(_tmp11, 0))
    tmp13 = tl.load(in_ptr0 + (0))
    tmp14 = tl.broadcast_to(tmp13, [R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr2, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr3, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp17 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp19 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp28 = tl.load(in_ptr4 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp14) & (tmp14 < 512), "index out of bounds: 0 <= tmp14 < 512")
        tmp16 = tl.load(in_ptr1 + (r0_0 + 128*tmp14), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp18 = tmp16 + tmp17
        tmp20 = tmp18 + tmp19
        tmp21 = tmp20.to(tl.float32)
        tmp22 = tl.full([1], 128.0, tl.float32)
        tmp23 = (tmp11 / tmp22)
        tmp24 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp25 = tmp23 + tmp24
        tmp26 = libdevice.rsqrt(tmp25)
        tmp27 = tmp21 * tmp26
        tmp29 = tmp28.to(tl.float32)
        tmp30 = tmp27 * tmp29
        tmp31 = tmp30.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp31, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/c4/cc4hvyq2opsbb5sxwzpyhvyt3vy6rxyc2wps7dzbbyghow2ld23l.py
# Topologically Sorted Source Nodes: [linear_7], Original ATen: [aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_7 => mm_7, permute_14, view_26
# Graph fragment:
#   %convert_element_type_26 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0" = PlaceHolder[target=convert_element_type_26]
#   %arg16_1 : Tensor "f16[128, 128][128, 1]tnca:0" = PlaceHolder[target=arg16_1]
#   %view_26 : Tensor "f16[1, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_26, [1, 128]), kwargs = {})
#   %permute_14 : Tensor "f16[128, 128][1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg16_1, [1, 0]), kwargs = {})
#   %mm_7 : Tensor "f16[1, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_26, %permute_14), kwargs = {})
#   return %mm_7
triton_tem_fused_mm_t_view_18 = async_compile.triton('triton_tem_fused_mm_t_view_18', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_mm_t_view_18', 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_mm_t_view_18(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 128
    K = 128
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 128
    stride_ak = 1
    stride_bk = 1
    stride_bn = 128

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 128*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 128*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 128*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 128*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/2b/c2bndefbvqyqh6elzwuclp37nhbmtktemez6t4zpbisz5onkf5ev.py
# Topologically Sorted Source Nodes: [linear_8, view_4, k_4, getitem_8, mul_7, mul_8, k_5, k_6], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
# Source node to ATen node mapping:
#   getitem_8 => select_2
#   k_4 => permute_17
#   k_5 => add_9
#   k_6 => cat_6
#   linear_8 => view_30
#   mul_7 => mul_15
#   mul_8 => mul_16
#   view_4 => view_31
# Graph fragment:
#   %arg4_1 : Tensor "f16[4, 1, 2, 128, 32][8192, 8192, 4096, 32, 1]tnca:0" = PlaceHolder[target=arg4_1]
#   %view_30 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_8, [1, 1, 64]), kwargs = {})
#   %view_31 : Tensor "f16[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_30, [1, 1, 2, 32]), kwargs = {})
#   %permute_17 : Tensor "f16[1, 2, 1, 32][64, 32, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_31, [0, 2, 1, 3]), kwargs = {})
#   %select_2 : Tensor "f16[1, 2, 128, 32][8192, 4096, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg4_1, 0, 1), kwargs = {})
#   %mul_15 : Tensor "f16[1, 2, 1, 32][64, 32, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_17, %arg2_1), kwargs = {})
#   %mul_16 : Tensor "f16[1, 2, 1, 32][64, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_5, %arg3_1), kwargs = {})
#   %add_9 : Tensor "f16[1, 2, 1, 32][64, 32, 32, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_15, %mul_16), kwargs = {})
#   %cat_6 : Tensor "f16[1, 2, 129, 32][8256, 4128, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%select_2, %add_9], 2), kwargs = {})
#   return %buf41
triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_19 = async_compile.triton('triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_19', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 8192}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_19', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 49152}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_19(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 8192
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x2 = xindex
    x0 = (xindex % 4096)
    x1 = xindex // 4096
    tmp0 = tl.load(in_ptr0 + (8192 + x2), None).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 4128*x1), tmp0, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/g3/cg3cr2gelmclggbokooxipe4agxze7od2smh5jto7jvmnfycawzw.py
# Topologically Sorted Source Nodes: [x, h, x_1, linear_6, x_2, h_1, x_3, y_1], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   h => view_19
#   h_1 => view_45
#   linear_6 => view_25
#   x => embedding
#   x_1 => add_3
#   x_2 => add_6
#   x_3 => add_10
#   y_1 => add_11, convert_element_type_40, convert_element_type_41, mean_3, mul_19, mul_20, pow_4, rsqrt_3
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 1][1, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "f16[512, 128][128, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %mm_3 : Tensor "f16[1, 128][128, 1]tnca:0" = PlaceHolder[target=mm_3]
#   %mm_6 : Tensor "f16[1, 128][128, 1]tnca:0" = PlaceHolder[target=mm_6]
#   %mm_10 : Tensor "f16[1, 128][128, 1]tnca:0" = PlaceHolder[target=mm_10]
#   %add_10 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0" = PlaceHolder[target=add_10]
#   %buf57 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf57]
#   %arg20_1 : Tensor "f16[128][1]tnca:0" = PlaceHolder[target=arg20_1]
#   %embedding : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %view_19 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [1, 1, 128]), kwargs = {})
#   %add_3 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_19), kwargs = {})
#   %view_25 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_6, [1, 1, 128]), kwargs = {})
#   %add_6 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_3, %view_25), kwargs = {})
#   %view_45 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_10, [1, 1, 128]), kwargs = {})
#   %add_10 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_6, %view_45), kwargs = {})
#   %convert_element_type_40 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_10, torch.float32), kwargs = {})
#   %pow_4 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_40, 2), kwargs = {})
#   %mean_3 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_4, [2], True), kwargs = {})
#   %add_11 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_3, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_3 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_11,), kwargs = {})
#   %mul_19 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_40, %rsqrt_3), kwargs = {})
#   %mul_20 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_19, %arg20_1), kwargs = {})
#   %convert_element_type_41 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_20, torch.float16), kwargs = {})
#   return %add_10,%buf57,%convert_element_type_41
triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_20 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_20', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp16', 'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_20', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 6, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 2048}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_20(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
    tma_descriptor0 = tl.make_tensor_descriptor(in_out_ptr0, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr2, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr3, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    _tmp13 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp4 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp6 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp8 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp1) & (tmp1 < 512), "index out of bounds: 0 <= tmp1 < 512")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 128*tmp1), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp5 = tmp3 + tmp4
        tmp7 = tmp5 + tmp6
        tmp9 = tmp7 + tmp8
        tmp10 = tmp9.to(tl.float32)
        tmp11 = tmp10 * tmp10
        tmp12 = tl.broadcast_to(tmp11, [R0_BLOCK])
        tmp14 = _tmp13 + tmp12
        _tmp13 = tl.where(r0_mask, tmp14, _tmp13)
        tl.store(in_out_ptr0 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp9, r0_mask)
    tmp13 = triton_helpers.promote_to_tensor(tl.sum(_tmp13, 0))
    tma_descriptor3 = tl.make_tensor_descriptor(in_out_ptr0, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tl.debug_barrier()
        tmp15 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp23 = tl.load(in_ptr4 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp16 = tmp15.to(tl.float32)
        tmp17 = tl.full([1], 128.0, tl.float32)
        tmp18 = (tmp13 / tmp17)
        tmp19 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp20 = tmp18 + tmp19
        tmp21 = libdevice.rsqrt(tmp20)
        tmp22 = tmp16 * tmp21
        tmp24 = tmp23.to(tl.float32)
        tmp25 = tmp22 * tmp24
        tmp26 = tmp25.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp26, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/qf/cqffubmfz3wijyyq6ro4amzlznyv3y4fazvnokmuajcbpvy6qauz.py
# Topologically Sorted Source Nodes: [y_1, linear_11], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_11 => mm_11, permute_25, view_46
#   y_1 => add_11, convert_element_type_40, convert_element_type_41, mean_3, mul_19, mul_20, pow_4, rsqrt_3
# Graph fragment:
#   %convert_element_type_41 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0" = PlaceHolder[target=convert_element_type_41]
#   %arg21_1 : Tensor "f16[352, 128][128, 1]tnca:0" = PlaceHolder[target=arg21_1]
#   %convert_element_type_40 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_10, torch.float32), kwargs = {})
#   %pow_4 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_40, 2), kwargs = {})
#   %mean_3 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_4, [2], True), kwargs = {})
#   %add_11 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_3, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_3 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_11,), kwargs = {})
#   %mul_19 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_40, %rsqrt_3), kwargs = {})
#   %mul_20 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_19, %arg20_1), kwargs = {})
#   %convert_element_type_41 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_20, torch.float16), kwargs = {})
#   %view_46 : Tensor "f16[1, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_41, [1, 128]), kwargs = {})
#   %permute_25 : Tensor "f16[128, 352][1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg21_1, [1, 0]), kwargs = {})
#   %mm_11 : Tensor "f16[1, 352][352, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_46, %permute_25), kwargs = {})
#   return %mm_11
triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_21 = async_compile.triton('triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_21', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_21', 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_21(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 352
    K = 128
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 0
    stride_ak = 1
    stride_bk = 1
    stride_bn = 128

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 128*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 352*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 128*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 352*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/lb/clboefqnokfcejes7q6dh3yth3wa5eyu42aehy4vtk46zzj6gzuq.py
# Topologically Sorted Source Nodes: [linear_13, x_4, rms_norm_4], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   linear_13 => view_51
#   rms_norm_4 => add_14, convert_element_type_50, convert_element_type_51, mean_4, mul_22, mul_23, pow_5, rsqrt_4
#   x_4 => add_13
# Graph fragment:
#   %add_10 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0" = PlaceHolder[target=add_10]
#   %mm_13 : Tensor "f16[1, 128][128, 1]tnca:0" = PlaceHolder[target=mm_13]
#   %buf63 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf63]
#   %arg24_1 : Tensor "f16[128][1]tnca:0" = PlaceHolder[target=arg24_1]
#   %view_51 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_13, [1, 1, 128]), kwargs = {})
#   %add_13 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_10, %view_51), kwargs = {})
#   %convert_element_type_50 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_13, torch.float32), kwargs = {})
#   %pow_5 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_50, 2), kwargs = {})
#   %mean_4 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_5, [2], True), kwargs = {})
#   %add_14 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_4, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_4 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_14,), kwargs = {})
#   %mul_22 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_50, %rsqrt_4), kwargs = {})
#   %mul_23 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_22, %arg24_1), kwargs = {})
#   %convert_element_type_51 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_23, torch.float16), kwargs = {})
#   return %buf63,%convert_element_type_51
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_22 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_22', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_22', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 1280}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_22(in_ptr0, in_ptr1, in_ptr2, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    _tmp6 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp3 * tmp3
        tmp5 = tl.broadcast_to(tmp4, [R0_BLOCK])
        tmp7 = _tmp6 + tmp5
        _tmp6 = tl.where(r0_mask, tmp7, _tmp6)
    tmp6 = triton_helpers.promote_to_tensor(tl.sum(_tmp6, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr0, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr1, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp8 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp9 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp18 = tl.load(in_ptr2 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp10 = tmp8 + tmp9
        tmp11 = tmp10.to(tl.float32)
        tmp12 = tl.full([1], 128.0, tl.float32)
        tmp13 = (tmp6 / tmp12)
        tmp14 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp15 = tmp13 + tmp14
        tmp16 = libdevice.rsqrt(tmp15)
        tmp17 = tmp11 * tmp16
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tmp17 * tmp19
        tmp21 = tmp20.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp21, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/c6/cc6bmkxrhonns4lhh4cignzxgdr2pitphzatxvwsxe2xxiqp6kgb.py
# Topologically Sorted Source Nodes: [linear_15, view_7, k_8, getitem_16, mul_12, mul_13, k_9, k_10], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
# Source node to ATen node mapping:
#   getitem_16 => select_4
#   k_10 => cat_10
#   k_8 => permute_31
#   k_9 => add_16
#   linear_15 => view_56
#   mul_12 => mul_26
#   mul_13 => mul_27
#   view_7 => view_57
# Graph fragment:
#   %arg4_1 : Tensor "f16[4, 1, 2, 128, 32][8192, 8192, 4096, 32, 1]tnca:0" = PlaceHolder[target=arg4_1]
#   %view_56 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_15, [1, 1, 64]), kwargs = {})
#   %view_57 : Tensor "f16[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_56, [1, 1, 2, 32]), kwargs = {})
#   %permute_31 : Tensor "f16[1, 2, 1, 32][64, 32, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_57, [0, 2, 1, 3]), kwargs = {})
#   %select_4 : Tensor "f16[1, 2, 128, 32][8192, 4096, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg4_1, 0, 2), kwargs = {})
#   %mul_26 : Tensor "f16[1, 2, 1, 32][64, 32, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_31, %arg2_1), kwargs = {})
#   %mul_27 : Tensor "f16[1, 2, 1, 32][64, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_9, %arg3_1), kwargs = {})
#   %add_16 : Tensor "f16[1, 2, 1, 32][64, 32, 32, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_26, %mul_27), kwargs = {})
#   %cat_10 : Tensor "f16[1, 2, 129, 32][8256, 4128, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%select_4, %add_16], 2), kwargs = {})
#   return %buf73
triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_23 = async_compile.triton('triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_23', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 8192}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_23', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 49152}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_23(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 8192
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x2 = xindex
    x0 = (xindex % 4096)
    x1 = xindex // 4096
    tmp0 = tl.load(in_ptr0 + (16384 + x2), None).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 4128*x1), tmp0, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/dl/cdl726mhelpbakd7icojhxkmwqtwekxeewy3eexmnjercozhgol2.py
# Topologically Sorted Source Nodes: [linear_2, view_2, v, linear_9, view_5, v_3, getitem_17, linear_16, view_8, v_6, v_7, linear_23, view_11, v_9, stack_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.cat, aten.stack]
# Source node to ATen node mapping:
#   getitem_17 => select_5
#   linear_16 => view_59
#   linear_2 => view_7
#   linear_23 => view_85
#   linear_9 => view_33
#   stack_1 => cat_17
#   v => permute_5
#   v_3 => permute_19
#   v_6 => permute_33
#   v_7 => cat_11
#   v_9 => permute_47
#   view_11 => view_86
#   view_2 => view_8
#   view_5 => view_34
#   view_8 => view_60
# Graph fragment:
#   %mm_16 : Tensor "f16[1, 64][64, 1]tnca:0" = PlaceHolder[target=mm_16]
#   %view_7 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_2, [1, 1, 64]), kwargs = {})
#   %view_8 : Tensor "f16[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_7, [1, 1, 2, 32]), kwargs = {})
#   %permute_5 : Tensor "f16[1, 2, 1, 32][64, 32, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_8, [0, 2, 1, 3]), kwargs = {})
#   %view_33 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_9, [1, 1, 64]), kwargs = {})
#   %view_34 : Tensor "f16[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_33, [1, 1, 2, 32]), kwargs = {})
#   %permute_19 : Tensor "f16[1, 2, 1, 32][64, 32, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_34, [0, 2, 1, 3]), kwargs = {})
#   %select_5 : Tensor "f16[1, 2, 128, 32][8192, 4096, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg5_1, 0, 2), kwargs = {})
#   %view_59 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_16, [1, 1, 64]), kwargs = {})
#   %view_60 : Tensor "f16[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_59, [1, 1, 2, 32]), kwargs = {})
#   %permute_33 : Tensor "f16[1, 2, 1, 32][64, 32, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_60, [0, 2, 1, 3]), kwargs = {})
#   %cat_11 : Tensor "f16[1, 2, 129, 32][8256, 4128, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%select_5, %permute_33], 2), kwargs = {})
#   %view_85 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_23, [1, 1, 64]), kwargs = {})
#   %view_86 : Tensor "f16[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_85, [1, 1, 2, 32]), kwargs = {})
#   %permute_47 : Tensor "f16[1, 2, 1, 32][64, 32, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_86, [0, 2, 1, 3]), kwargs = {})
#   %cat_17 : Tensor "f16[4, 2, 1, 32][64, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%permute_5, %permute_19, %permute_33, %permute_47],), kwargs = {})
#   return %buf83,%buf136
triton_poi_fused__unsafe_view_cat_select_stack_transpose_view_24 = async_compile.triton('triton_poi_fused__unsafe_view_cat_select_stack_transpose_view_24', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 64}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_cat_select_stack_transpose_view_24', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 640}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_cat_select_stack_transpose_view_24(in_ptr0, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 64
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x2 = xindex
    x0 = (xindex % 32)
    x1 = xindex // 32
    tmp0 = tl.load(in_ptr0 + (x2), xmask).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 4128*x1), tmp0, xmask)
    tl.store(out_ptr1 + (x2), tmp0, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/6g/c6gzfognbqgt3icx7naqkzzxyotoj5wkncq7zknay6fccxy7k7fu.py
# Topologically Sorted Source Nodes: [linear_13, x_4, h_2, x_5, y_2], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   h_2 => view_71
#   linear_13 => view_51
#   x_4 => add_13
#   x_5 => add_17
#   y_2 => add_18, convert_element_type_65, convert_element_type_66, mean_5, mul_30, mul_31, pow_6, rsqrt_5
# Graph fragment:
#   %add_10 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0" = PlaceHolder[target=add_10]
#   %mm_13 : Tensor "f16[1, 128][128, 1]tnca:0" = PlaceHolder[target=mm_13]
#   %mm_17 : Tensor "f16[1, 128][128, 1]tnca:0" = PlaceHolder[target=mm_17]
#   %buf88 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf88]
#   %arg29_1 : Tensor "f16[128][1]tnca:0" = PlaceHolder[target=arg29_1]
#   %view_51 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_13, [1, 1, 128]), kwargs = {})
#   %add_13 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_10, %view_51), kwargs = {})
#   %view_71 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_17, [1, 1, 128]), kwargs = {})
#   %add_17 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_13, %view_71), kwargs = {})
#   %convert_element_type_65 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_17, torch.float32), kwargs = {})
#   %pow_6 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_65, 2), kwargs = {})
#   %mean_5 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_6, [2], True), kwargs = {})
#   %add_18 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_5, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_5 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_18,), kwargs = {})
#   %mul_30 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_65, %rsqrt_5), kwargs = {})
#   %mul_31 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_30, %arg29_1), kwargs = {})
#   %convert_element_type_66 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_31, torch.float16), kwargs = {})
#   return %buf88,%convert_element_type_66
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 1536}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr2, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    _tmp8 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp3 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tmp5 * tmp5
        tmp7 = tl.broadcast_to(tmp6, [R0_BLOCK])
        tmp9 = _tmp8 + tmp7
        _tmp8 = tl.where(r0_mask, tmp9, _tmp8)
    tmp8 = triton_helpers.promote_to_tensor(tl.sum(_tmp8, 0))
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr0, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor4 = tl.make_tensor_descriptor(in_ptr1, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor5 = tl.make_tensor_descriptor(in_ptr2, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp10 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp11 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor4.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp13 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor5.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp22 = tl.load(in_ptr3 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp12 = tmp10 + tmp11
        tmp14 = tmp12 + tmp13
        tmp15 = tmp14.to(tl.float32)
        tmp16 = tl.full([1], 128.0, tl.float32)
        tmp17 = (tmp8 / tmp16)
        tmp18 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp19 = tmp17 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp15 * tmp20
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tmp21 * tmp23
        tmp25 = tmp24.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp25, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/y7/cy7vtnbbt25kadca22xtttniwvb3q4t4sdtnafyaw5iuws4iau4e.py
# Topologically Sorted Source Nodes: [linear_13, x_4, h_2, x_5, linear_20, x_6, rms_norm_6], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   h_2 => view_71
#   linear_13 => view_51
#   linear_20 => view_77
#   rms_norm_6 => add_21, convert_element_type_75, convert_element_type_76, mean_6, mul_33, mul_34, pow_7, rsqrt_6
#   x_4 => add_13
#   x_5 => add_17
#   x_6 => add_20
# Graph fragment:
#   %add_10 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0" = PlaceHolder[target=add_10]
#   %mm_13 : Tensor "f16[1, 128][128, 1]tnca:0" = PlaceHolder[target=mm_13]
#   %mm_17 : Tensor "f16[1, 128][128, 1]tnca:0" = PlaceHolder[target=mm_17]
#   %mm_20 : Tensor "f16[1, 128][128, 1]tnca:0" = PlaceHolder[target=mm_20]
#   %buf94 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf94]
#   %arg33_1 : Tensor "f16[128][1]tnca:0" = PlaceHolder[target=arg33_1]
#   %view_51 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_13, [1, 1, 128]), kwargs = {})
#   %add_13 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_10, %view_51), kwargs = {})
#   %view_71 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_17, [1, 1, 128]), kwargs = {})
#   %add_17 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_13, %view_71), kwargs = {})
#   %view_77 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_20, [1, 1, 128]), kwargs = {})
#   %add_20 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_17, %view_77), kwargs = {})
#   %convert_element_type_75 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_20, torch.float32), kwargs = {})
#   %pow_7 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_75, 2), kwargs = {})
#   %mean_6 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_7, [2], True), kwargs = {})
#   %add_21 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_6, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_6 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_21,), kwargs = {})
#   %mul_33 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_75, %rsqrt_6), kwargs = {})
#   %mul_34 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_33, %arg33_1), kwargs = {})
#   %convert_element_type_76 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_34, torch.float16), kwargs = {})
#   return %buf94,%convert_element_type_76
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_26 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_26', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_26', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 9, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 1792}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_26(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr2, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr3, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    _tmp10 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp3 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp5 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tmp7 * tmp7
        tmp9 = tl.broadcast_to(tmp8, [R0_BLOCK])
        tmp11 = _tmp10 + tmp9
        _tmp10 = tl.where(r0_mask, tmp11, _tmp10)
    tmp10 = triton_helpers.promote_to_tensor(tl.sum(_tmp10, 0))
    tma_descriptor4 = tl.make_tensor_descriptor(in_ptr0, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor5 = tl.make_tensor_descriptor(in_ptr1, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor6 = tl.make_tensor_descriptor(in_ptr2, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor7 = tl.make_tensor_descriptor(in_ptr3, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp12 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor4.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp13 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor5.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp15 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor6.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp17 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor7.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp26 = tl.load(in_ptr4 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp14 = tmp12 + tmp13
        tmp16 = tmp14 + tmp15
        tmp18 = tmp16 + tmp17
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tl.full([1], 128.0, tl.float32)
        tmp21 = (tmp10 / tmp20)
        tmp22 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp23 = tmp21 + tmp22
        tmp24 = libdevice.rsqrt(tmp23)
        tmp25 = tmp19 * tmp24
        tmp27 = tmp26.to(tl.float32)
        tmp28 = tmp25 * tmp27
        tmp29 = tmp28.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp29, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/ak/cakcmmarvntqnbdzfcepfe33soev3btvn6yii4qfurshhbsxdapn.py
# Topologically Sorted Source Nodes: [linear_22, view_10, k_12, getitem_24, mul_17, mul_18, k_13, k_14], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
# Source node to ATen node mapping:
#   getitem_24 => select_6
#   k_12 => permute_45
#   k_13 => add_23
#   k_14 => cat_14
#   linear_22 => view_82
#   mul_17 => mul_37
#   mul_18 => mul_38
#   view_10 => view_83
# Graph fragment:
#   %arg4_1 : Tensor "f16[4, 1, 2, 128, 32][8192, 8192, 4096, 32, 1]tnca:0" = PlaceHolder[target=arg4_1]
#   %view_82 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_22, [1, 1, 64]), kwargs = {})
#   %view_83 : Tensor "f16[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_82, [1, 1, 2, 32]), kwargs = {})
#   %permute_45 : Tensor "f16[1, 2, 1, 32][64, 32, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_83, [0, 2, 1, 3]), kwargs = {})
#   %select_6 : Tensor "f16[1, 2, 128, 32][8192, 4096, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg4_1, 0, 3), kwargs = {})
#   %mul_37 : Tensor "f16[1, 2, 1, 32][64, 32, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_45, %arg2_1), kwargs = {})
#   %mul_38 : Tensor "f16[1, 2, 1, 32][64, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_13, %arg3_1), kwargs = {})
#   %add_23 : Tensor "f16[1, 2, 1, 32][64, 32, 32, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_37, %mul_38), kwargs = {})
#   %cat_14 : Tensor "f16[1, 2, 129, 32][8256, 4128, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%select_6, %add_23], 2), kwargs = {})
#   return %buf104
triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_27 = async_compile.triton('triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_27', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 8192}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_27', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 49152}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_27(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 8192
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x2 = xindex
    x0 = (xindex % 4096)
    x1 = xindex // 4096
    tmp0 = tl.load(in_ptr0 + (24576 + x2), None).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 4128*x1), tmp0, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/l3/cl35ub6esarkmkjb2eogv4uyvaghck5alidvj475thet4jzypwdk.py
# Topologically Sorted Source Nodes: [linear_13, x_4, h_2, x_5, linear_20, x_6, h_3, x_7, y_3], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   h_2 => view_71
#   h_3 => view_97
#   linear_13 => view_51
#   linear_20 => view_77
#   x_4 => add_13
#   x_5 => add_17
#   x_6 => add_20
#   x_7 => add_24
#   y_3 => add_25, convert_element_type_90, convert_element_type_91, mean_7, mul_41, mul_42, pow_8, rsqrt_7
# Graph fragment:
#   %add_10 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0" = PlaceHolder[target=add_10]
#   %mm_13 : Tensor "f16[1, 128][128, 1]tnca:0" = PlaceHolder[target=mm_13]
#   %mm_17 : Tensor "f16[1, 128][128, 1]tnca:0" = PlaceHolder[target=mm_17]
#   %mm_20 : Tensor "f16[1, 128][128, 1]tnca:0" = PlaceHolder[target=mm_20]
#   %mm_24 : Tensor "f16[1, 128][128, 1]tnca:0" = PlaceHolder[target=mm_24]
#   %add_24 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0" = PlaceHolder[target=add_24]
#   %buf120 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf120]
#   %arg38_1 : Tensor "f16[128][1]tnca:0" = PlaceHolder[target=arg38_1]
#   %view_51 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_13, [1, 1, 128]), kwargs = {})
#   %add_13 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_10, %view_51), kwargs = {})
#   %view_71 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_17, [1, 1, 128]), kwargs = {})
#   %add_17 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_13, %view_71), kwargs = {})
#   %view_77 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_20, [1, 1, 128]), kwargs = {})
#   %add_20 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_17, %view_77), kwargs = {})
#   %view_97 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_24, [1, 1, 128]), kwargs = {})
#   %add_24 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_20, %view_97), kwargs = {})
#   %convert_element_type_90 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_24, torch.float32), kwargs = {})
#   %pow_8 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_90, 2), kwargs = {})
#   %mean_7 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_8, [2], True), kwargs = {})
#   %add_25 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_7, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_7 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_25,), kwargs = {})
#   %mul_41 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_90, %rsqrt_7), kwargs = {})
#   %mul_42 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_41, %arg38_1), kwargs = {})
#   %convert_element_type_91 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_42, torch.float16), kwargs = {})
#   return %add_24,%buf120,%convert_element_type_91
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_28 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_28', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp16', 'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_28', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 7, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 2560}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_28(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_out_ptr0, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr1, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr2, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor4 = tl.make_tensor_descriptor(in_ptr3, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    _tmp12 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp3 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp5 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp7 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor4.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp8 = tmp6 + tmp7
        tmp9 = tmp8.to(tl.float32)
        tmp10 = tmp9 * tmp9
        tmp11 = tl.broadcast_to(tmp10, [R0_BLOCK])
        tmp13 = _tmp12 + tmp11
        _tmp12 = tl.where(r0_mask, tmp13, _tmp12)
        tl.store(in_out_ptr0 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp8, r0_mask)
    tmp12 = triton_helpers.promote_to_tensor(tl.sum(_tmp12, 0))
    tma_descriptor5 = tl.make_tensor_descriptor(in_out_ptr0, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tl.debug_barrier()
        tmp14 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor5.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp22 = tl.load(in_ptr4 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp15 = tmp14.to(tl.float32)
        tmp16 = tl.full([1], 128.0, tl.float32)
        tmp17 = (tmp12 / tmp16)
        tmp18 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp19 = tmp17 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp15 * tmp20
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tmp21 * tmp23
        tmp25 = tmp24.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp25, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/ea/ceayh3yap4gi5uthkumumkfjyvqrbonpe4zvf4lu6fzf4p7imrye.py
# Topologically Sorted Source Nodes: [linear_27, x_8, rms_norm_8], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   linear_27 => view_103
#   rms_norm_8 => add_28, convert_element_type_100, convert_element_type_101, mean_8, mul_44, mul_45, pow_9, rsqrt_8
#   x_8 => add_27
# Graph fragment:
#   %add_24 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0" = PlaceHolder[target=add_24]
#   %mm_27 : Tensor "f16[1, 128][128, 1]tnca:0" = PlaceHolder[target=mm_27]
#   %buf126 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf126]
#   %arg42_1 : Tensor "f16[128][1]tnca:0" = PlaceHolder[target=arg42_1]
#   %view_103 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_27, [1, 1, 128]), kwargs = {})
#   %add_27 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_24, %view_103), kwargs = {})
#   %convert_element_type_100 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_27, torch.float32), kwargs = {})
#   %pow_9 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_100, 2), kwargs = {})
#   %mean_8 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_9, [2], True), kwargs = {})
#   %add_28 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_8, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_8 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_28,), kwargs = {})
#   %mul_44 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_100, %rsqrt_8), kwargs = {})
#   %mul_45 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_44, %arg42_1), kwargs = {})
#   %convert_element_type_101 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_45, torch.float16), kwargs = {})
#   return %buf126,%convert_element_type_101
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_29 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_29', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp16', 'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_29', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 1280}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_29(in_out_ptr0, in_ptr0, in_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_out_ptr0, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    _tmp6 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp3 * tmp3
        tmp5 = tl.broadcast_to(tmp4, [R0_BLOCK])
        tmp7 = _tmp6 + tmp5
        _tmp6 = tl.where(r0_mask, tmp7, _tmp6)
    tmp6 = triton_helpers.promote_to_tensor(tl.sum(_tmp6, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_out_ptr0, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr0, shape=[128], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp8 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp9 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp18 = tl.load(in_ptr1 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp10 = tmp8 + tmp9
        tmp11 = tmp10.to(tl.float32)
        tmp12 = tl.full([1], 128.0, tl.float32)
        tmp13 = (tmp6 / tmp12)
        tmp14 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp15 = tmp13 + tmp14
        tmp16 = libdevice.rsqrt(tmp15)
        tmp17 = tmp11 * tmp16
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tmp17 * tmp19
        tmp21 = tmp20.to(tl.float32)
        tl.store(in_out_ptr0 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp21, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/ij/cijwzzc3csye3wg4atmutdedfrcwr6xqz3tjsmp2cyhfuxsn2emu.py
# Topologically Sorted Source Nodes: [linear_27, x_8, rms_norm_8, linear_28], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_27 => view_103
#   linear_28 => mm_28, permute_56, view_104
#   rms_norm_8 => add_28, convert_element_type_100, convert_element_type_101, mean_8, mul_44, mul_45, pow_9, rsqrt_8
#   x_8 => add_27
# Graph fragment:
#   %convert_element_type_101 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0" = PlaceHolder[target=convert_element_type_101]
#   %arg43_1 : Tensor "f16[512, 128][128, 1]tnca:0" = PlaceHolder[target=arg43_1]
#   %view_103 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_27, [1, 1, 128]), kwargs = {})
#   %add_27 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_24, %view_103), kwargs = {})
#   %convert_element_type_100 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_27, torch.float32), kwargs = {})
#   %pow_9 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_100, 2), kwargs = {})
#   %mean_8 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_9, [2], True), kwargs = {})
#   %add_28 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_8, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_8 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_28,), kwargs = {})
#   %mul_44 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_100, %rsqrt_8), kwargs = {})
#   %mul_45 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_44, %arg42_1), kwargs = {})
#   %convert_element_type_101 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_45, torch.float16), kwargs = {})
#   %view_104 : Tensor "f16[1, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_101, [1, 128]), kwargs = {})
#   %permute_56 : Tensor "f16[128, 512][1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg43_1, [1, 0]), kwargs = {})
#   %mm_28 : Tensor "f16[1, 512][512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_104, %permute_56), kwargs = {})
#   return %mm_28
triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_t_view_30 = async_compile.triton('triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_t_view_30', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_t_view_30', 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_t_view_30(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 512
    K = 128
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 0
    stride_ak = 1
    stride_bk = 1
    stride_bn = 128

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 128*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 512*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 128*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 512*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__small__fp16-b1-p128/inductor_cache/wa/cwabmjjr7qij6zqdtbq2fpcseesfn6l7fwrl22ix4ok2dyq2kges.py
# Topologically Sorted Source Nodes: [linear_2, view_2, v, linear_9, view_5, v_3, linear_16, view_8, v_6, linear_23, view_11, v_9, stack_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.stack]
# Source node to ATen node mapping:
#   linear_16 => view_59
#   linear_2 => view_7
#   linear_23 => view_85
#   linear_9 => view_33
#   stack_1 => cat_17
#   v => permute_5
#   v_3 => permute_19
#   v_6 => permute_33
#   v_9 => permute_47
#   view_11 => view_86
#   view_2 => view_8
#   view_5 => view_34
#   view_8 => view_60
# Graph fragment:
#   %mm_2 : Tensor "f16[1, 64][64, 1]tnca:0" = PlaceHolder[target=mm_2]
#   %view_7 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_2, [1, 1, 64]), kwargs = {})
#   %view_8 : Tensor "f16[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_7, [1, 1, 2, 32]), kwargs = {})
#   %permute_5 : Tensor "f16[1, 2, 1, 32][64, 32, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_8, [0, 2, 1, 3]), kwargs = {})
#   %view_33 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_9, [1, 1, 64]), kwargs = {})
#   %view_34 : Tensor "f16[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_33, [1, 1, 2, 32]), kwargs = {})
#   %permute_19 : Tensor "f16[1, 2, 1, 32][64, 32, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_34, [0, 2, 1, 3]), kwargs = {})
#   %view_59 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_16, [1, 1, 64]), kwargs = {})
#   %view_60 : Tensor "f16[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_59, [1, 1, 2, 32]), kwargs = {})
#   %permute_33 : Tensor "f16[1, 2, 1, 32][64, 32, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_60, [0, 2, 1, 3]), kwargs = {})
#   %view_85 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_23, [1, 1, 64]), kwargs = {})
#   %view_86 : Tensor "f16[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_85, [1, 1, 2, 32]), kwargs = {})
#   %permute_47 : Tensor "f16[1, 2, 1, 32][64, 32, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_86, [0, 2, 1, 3]), kwargs = {})
#   %cat_17 : Tensor "f16[4, 2, 1, 32][64, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%permute_5, %permute_19, %permute_33, %permute_47],), kwargs = {})
#   return %buf134
triton_poi_fused__unsafe_view_stack_transpose_view_31 = async_compile.triton('triton_poi_fused__unsafe_view_stack_transpose_view_31', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 64}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_stack_transpose_view_31', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 384}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_stack_transpose_view_31(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 64
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask).to(tl.float32)
    tl.store(out_ptr0 + (x0), tmp0, xmask)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1 = args
        args.clear()
        assert_size_stride_grouped((arg1_1, arg0_1, arg6_1), ((1, 1), (512, 128), (128, )), ((1, 1), (128, 1), (1, )), 'input')
        buf1 = empty_strided((1, 1, 128), (128, 128, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [x, rms_norm], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0.run(arg1_1, arg0_1, arg6_1, buf1, 1, 128, stream=raw_stream0)
        del arg6_1
        assert_size_stride(arg7_1, (128, 128), (128, 1), 'input')
        buf2 = empty_strided((1, 128), (128, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [x, rms_norm, linear], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf1, arg7_1, buf2, 8, 1, 1, stream=raw_stream0)
        del arg7_1
        assert_size_stride(arg8_1, (64, 128), (128, 1), 'input')
        buf3 = empty_strided((1, 64), (64, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_1], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf1, arg8_1, buf3, 4, 1, 1, stream=raw_stream0)
        del arg8_1
        buf6 = empty_strided((1, 4, 1, 32), (128, 32, 32, 1), device='tnca', dtype=torch.float16)
        buf4 = reinterpret_tensor(buf6, (1, 4, 1, 16), (128, 32, 32, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear, view, q, chunk, neg], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf2, buf4, 64, stream=raw_stream0)
        buf5 = reinterpret_tensor(buf6, (1, 4, 1, 16), (128, 32, 32, 1), 16)  # alias
        # Topologically Sorted Source Nodes: [linear, view, q, chunk, neg, cat], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf2, buf5, 64, stream=raw_stream0)
        buf9 = empty_strided((1, 2, 1, 32), (64, 32, 32, 1), device='tnca', dtype=torch.float16)
        buf7 = reinterpret_tensor(buf9, (1, 2, 1, 16), (64, 32, 32, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_1, view_1, k, chunk_1, neg_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_5.run(buf3, buf7, 32, stream=raw_stream0)
        del buf4
        del buf5
        buf8 = reinterpret_tensor(buf9, (1, 2, 1, 16), (64, 32, 32, 1), 16)  # alias
        # Topologically Sorted Source Nodes: [linear_1, view_1, k, chunk_1, neg_1, cat_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6.run(buf3, buf8, 32, stream=raw_stream0)
        assert_size_stride(arg4_1, (4, 1, 2, 128, 32), (8192, 8192, 4096, 32, 1), 'input')
        buf12 = empty_strided((1, 2, 129, 32), (8256, 4128, 32, 1), device='tnca', dtype=torch.float16)
        buf10 = reinterpret_tensor(buf12, (1, 2, 128, 32), (8256, 4128, 32, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_1, view_1, k, getitem, mul_2, mul_3, k_1, k_2], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_7.run(arg4_1, buf10, 8192, stream=raw_stream0)
        del buf7
        del buf8
        assert_size_stride_grouped((arg2_1, arg3_1), ((1, 32), (1, 32)), ((32, 1), (32, 1)), 'input')
        buf11 = reinterpret_tensor(buf12, (1, 2, 1, 32), (8256, 4128, 32, 1), 4096)  # alias
        buf133 = empty_strided((4, 2, 1, 32), (64, 32, 32, 1), device='tnca', dtype=torch.float16)
        buf129 = reinterpret_tensor(buf133, (1, 2, 1, 32), (64, 32, 32, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_1, view_1, k, mul_2, mul_3, k_1, stack], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8.run(buf3, arg2_1, buf9, arg3_1, buf11, buf129, 64, stream=raw_stream0)
        buf13 = empty_strided((4, 1, 129), (129, 129, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [linear, view, q, mul, mul_1, q_1, o, getitem_6, expand, k_3], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9.run(buf2, arg2_1, buf6, arg3_1, buf12, buf13, 516, 32, stream=raw_stream0)
        del buf10
        del buf11
        buf14 = empty_strided((1, 4, 1, 1), (4, 1, 4, 4), device='tnca', dtype=torch.bool)
        buf16 = empty_strided((1, 4, 1, 129), (516, 129, 516, 1), device='tnca', dtype=torch.float32)
        buf17 = empty_strided((1, 4, 1, 1), (4, 1, 4, 4), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [o], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10.run(buf13, buf14, buf16, buf17, 4, 129, stream=raw_stream0)
        del buf13
        assert_size_stride(arg9_1, (64, 128), (128, 1), 'input')
        buf18 = reinterpret_tensor(buf9, (1, 64), (64, 1), 0); del buf9  # reuse
        # Topologically Sorted Source Nodes: [linear_2], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf1, arg9_1, buf18, 4, 1, 1, stream=raw_stream0)
        del arg9_1
        assert_size_stride(arg5_1, (4, 1, 2, 128, 32), (8192, 8192, 4096, 32, 1), 'input')
        buf21 = buf12; del buf12  # reuse
        buf19 = reinterpret_tensor(buf21, (1, 2, 128, 32), (8256, 4128, 32, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [getitem_1, linear_2, view_2, v, v_1], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_7.run(arg5_1, buf19, 8192, stream=raw_stream0)
        buf20 = reinterpret_tensor(buf21, (1, 2, 1, 32), (8256, 4128, 32, 1), 4096)  # alias
        # Topologically Sorted Source Nodes: [getitem_1, linear_2, view_2, v, v_1], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_select_transpose_view_11.run(buf18, buf20, 64, stream=raw_stream0)
        buf23 = reinterpret_tensor(buf1, (1, 4, 1, 32), (128, 32, 32, 1), 0); del buf1  # reuse
        # Topologically Sorted Source Nodes: [o, getitem_7, expand_1, v_2], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(buf14, buf16, buf17, buf21, buf23, 128, 129, stream=raw_stream0)
        del buf19
        del buf20
        assert_size_stride(arg10_1, (128, 128), (128, 1), 'input')
        buf24 = reinterpret_tensor(buf6, (1, 128), (128, 1), 0); del buf6  # reuse
        # Topologically Sorted Source Nodes: [o, transpose_3, o_1, h], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf23, arg10_1, buf24, 8, 1, 1, stream=raw_stream0)
        del arg10_1
        assert_size_stride(arg11_1, (128, ), (1, ), 'input')
        buf26 = reinterpret_tensor(buf23, (1, 1, 128), (128, 128, 1), 0); del buf23  # reuse
        # Topologically Sorted Source Nodes: [x, h, x_1, y], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_13.run(arg1_1, arg0_1, buf24, arg11_1, buf26, 1, 128, stream=raw_stream0)
        del arg11_1
        assert_size_stride(arg12_1, (352, 128), (128, 1), 'input')
        buf27 = empty_strided((1, 352), (352, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_4], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_14.run(buf26, arg12_1, buf27, 22, 1, 1, stream=raw_stream0)
        del arg12_1
        assert_size_stride(arg13_1, (352, 128), (128, 1), 'input')
        buf29 = empty_strided((1, 1, 352), (352, 352, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_4], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf26, arg13_1, buf27, buf29, 22, 1, 1, stream=raw_stream0)
        del arg13_1
        del buf27
        assert_size_stride(arg14_1, (128, 352), (352, 1), 'input')
        buf30 = reinterpret_tensor(buf26, (1, 128), (128, 1), 0); del buf26  # reuse
        # Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_4, linear_6], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf29, arg14_1, buf30, 8, 1, 1, stream=raw_stream0)
        del arg14_1
        del buf29
        assert_size_stride(arg15_1, (128, ), (1, ), 'input')
        buf32 = reinterpret_tensor(buf2, (1, 1, 128), (128, 128, 1), 0); del buf2  # reuse
        # Topologically Sorted Source Nodes: [x, h, x_1, linear_6, x_2, rms_norm_2], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17.run(arg1_1, arg0_1, buf24, buf30, arg15_1, buf32, 1, 128, stream=raw_stream0)
        del arg15_1
        assert_size_stride(arg16_1, (128, 128), (128, 1), 'input')
        buf33 = empty_strided((1, 128), (128, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_7], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_18.run(buf32, arg16_1, buf33, 8, 1, 1, stream=raw_stream0)
        del arg16_1
        assert_size_stride(arg17_1, (64, 128), (128, 1), 'input')
        buf34 = buf3; del buf3  # reuse
        # Topologically Sorted Source Nodes: [linear_8], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf32, arg17_1, buf34, 4, 1, 1, stream=raw_stream0)
        del arg17_1
        buf37 = empty_strided((1, 4, 1, 32), (128, 32, 32, 1), device='tnca', dtype=torch.float16)
        buf35 = reinterpret_tensor(buf37, (1, 4, 1, 16), (128, 32, 32, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_7, view_3, q_2, chunk_2, neg_2], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf33, buf35, 64, stream=raw_stream0)
        buf36 = reinterpret_tensor(buf37, (1, 4, 1, 16), (128, 32, 32, 1), 16)  # alias
        # Topologically Sorted Source Nodes: [linear_7, view_3, q_2, chunk_2, neg_2, cat_4], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf33, buf36, 64, stream=raw_stream0)
        buf40 = empty_strided((1, 2, 1, 32), (64, 32, 32, 1), device='tnca', dtype=torch.float16)
        buf38 = reinterpret_tensor(buf40, (1, 2, 1, 16), (64, 32, 32, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_8, view_4, k_4, chunk_3, neg_3], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_5.run(buf34, buf38, 32, stream=raw_stream0)
        del buf35
        del buf36
        buf39 = reinterpret_tensor(buf40, (1, 2, 1, 16), (64, 32, 32, 1), 16)  # alias
        # Topologically Sorted Source Nodes: [linear_8, view_4, k_4, chunk_3, neg_3, cat_5], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6.run(buf34, buf39, 32, stream=raw_stream0)
        buf43 = buf21; del buf21  # reuse
        buf41 = reinterpret_tensor(buf43, (1, 2, 128, 32), (8256, 4128, 32, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_8, view_4, k_4, getitem_8, mul_7, mul_8, k_5, k_6], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_19.run(arg4_1, buf41, 8192, stream=raw_stream0)
        del buf38
        del buf39
        buf42 = reinterpret_tensor(buf43, (1, 2, 1, 32), (8256, 4128, 32, 1), 4096)  # alias
        buf130 = reinterpret_tensor(buf133, (1, 2, 1, 32), (64, 32, 32, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [linear_8, view_4, k_4, mul_7, mul_8, k_5, stack], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8.run(buf34, arg2_1, buf40, arg3_1, buf42, buf130, 64, stream=raw_stream0)
        buf44 = reinterpret_tensor(buf16, (4, 1, 129), (129, 129, 1), 0); del buf16  # reuse
        # Topologically Sorted Source Nodes: [linear_7, view_3, q_2, mul_5, mul_6, q_3, o_2, getitem_14, expand_2, k_7], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9.run(buf33, arg2_1, buf37, arg3_1, buf43, buf44, 516, 32, stream=raw_stream0)
        del buf41
        del buf42
        buf45 = buf14; del buf14  # reuse
        buf47 = empty_strided((1, 4, 1, 129), (516, 129, 516, 1), device='tnca', dtype=torch.float32)
        buf48 = buf17; del buf17  # reuse
        # Topologically Sorted Source Nodes: [o_2], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10.run(buf44, buf45, buf47, buf48, 4, 129, stream=raw_stream0)
        del buf44
        assert_size_stride(arg18_1, (64, 128), (128, 1), 'input')
        buf49 = reinterpret_tensor(buf40, (1, 64), (64, 1), 0); del buf40  # reuse
        # Topologically Sorted Source Nodes: [linear_9], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf32, arg18_1, buf49, 4, 1, 1, stream=raw_stream0)
        del arg18_1
        buf52 = buf43; del buf43  # reuse
        buf50 = reinterpret_tensor(buf52, (1, 2, 128, 32), (8256, 4128, 32, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [getitem_9, linear_9, view_5, v_3, v_4], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_19.run(arg5_1, buf50, 8192, stream=raw_stream0)
        buf51 = reinterpret_tensor(buf52, (1, 2, 1, 32), (8256, 4128, 32, 1), 4096)  # alias
        # Topologically Sorted Source Nodes: [getitem_9, linear_9, view_5, v_3, v_4], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_select_transpose_view_11.run(buf49, buf51, 64, stream=raw_stream0)
        buf54 = reinterpret_tensor(buf32, (1, 4, 1, 32), (128, 32, 32, 1), 0); del buf32  # reuse
        # Topologically Sorted Source Nodes: [o_2, getitem_15, expand_3, v_5], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(buf45, buf47, buf48, buf52, buf54, 128, 129, stream=raw_stream0)
        del buf50
        del buf51
        assert_size_stride(arg19_1, (128, 128), (128, 1), 'input')
        buf55 = reinterpret_tensor(buf37, (1, 128), (128, 1), 0); del buf37  # reuse
        # Topologically Sorted Source Nodes: [o_2, transpose_7, o_3, h_1], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf54, arg19_1, buf55, 8, 1, 1, stream=raw_stream0)
        del arg19_1
        assert_size_stride(arg20_1, (128, ), (1, ), 'input')
        buf56 = reinterpret_tensor(buf24, (1, 1, 128), (128, 128, 1), 0); del buf24  # reuse
        buf58 = reinterpret_tensor(buf54, (1, 1, 128), (128, 128, 1), 0); del buf54  # reuse
        # Topologically Sorted Source Nodes: [x, h, x_1, linear_6, x_2, h_1, x_3, y_1], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_20.run(buf56, arg1_1, arg0_1, buf30, buf55, arg20_1, buf58, 1, 128, stream=raw_stream0)
        del arg0_1
        del arg1_1
        del arg20_1
        assert_size_stride(arg21_1, (352, 128), (128, 1), 'input')
        buf59 = empty_strided((1, 352), (352, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [y_1, linear_11], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_21.run(buf58, arg21_1, buf59, 22, 1, 1, stream=raw_stream0)
        del arg21_1
        assert_size_stride(arg22_1, (352, 128), (128, 1), 'input')
        buf61 = empty_strided((1, 1, 352), (352, 352, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_11, silu_1, linear_12, mul_9], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf58, arg22_1, buf59, buf61, 22, 1, 1, stream=raw_stream0)
        del arg22_1
        del buf59
        assert_size_stride(arg23_1, (128, 352), (352, 1), 'input')
        buf62 = reinterpret_tensor(buf58, (1, 128), (128, 1), 0); del buf58  # reuse
        # Topologically Sorted Source Nodes: [linear_11, silu_1, linear_12, mul_9, linear_13], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf61, arg23_1, buf62, 8, 1, 1, stream=raw_stream0)
        del arg23_1
        del buf61
        assert_size_stride(arg24_1, (128, ), (1, ), 'input')
        buf64 = reinterpret_tensor(buf55, (1, 1, 128), (128, 128, 1), 0); del buf55  # reuse
        # Topologically Sorted Source Nodes: [linear_13, x_4, rms_norm_4], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_22.run(buf56, buf62, arg24_1, buf64, 1, 128, stream=raw_stream0)
        del arg24_1
        assert_size_stride(arg25_1, (128, 128), (128, 1), 'input')
        buf65 = buf30; del buf30  # reuse
        # Topologically Sorted Source Nodes: [linear_13, x_4, rms_norm_4, linear_14], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf64, arg25_1, buf65, 8, 1, 1, stream=raw_stream0)
        del arg25_1
        assert_size_stride(arg26_1, (64, 128), (128, 1), 'input')
        buf66 = buf34; del buf34  # reuse
        # Topologically Sorted Source Nodes: [linear_15], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf64, arg26_1, buf66, 4, 1, 1, stream=raw_stream0)
        del arg26_1
        buf69 = reinterpret_tensor(buf33, (1, 4, 1, 32), (128, 32, 32, 1), 0); del buf33  # reuse
        buf67 = reinterpret_tensor(buf69, (1, 4, 1, 16), (128, 32, 32, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_14, view_6, q_4, chunk_4, neg_4], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf65, buf67, 64, stream=raw_stream0)
        buf68 = reinterpret_tensor(buf69, (1, 4, 1, 16), (128, 32, 32, 1), 16)  # alias
        # Topologically Sorted Source Nodes: [linear_14, view_6, q_4, chunk_4, neg_4, cat_8], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf65, buf68, 64, stream=raw_stream0)
        buf72 = empty_strided((1, 2, 1, 32), (64, 32, 32, 1), device='tnca', dtype=torch.float16)
        buf70 = reinterpret_tensor(buf72, (1, 2, 1, 16), (64, 32, 32, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_15, view_7, k_8, chunk_5, neg_5], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_5.run(buf66, buf70, 32, stream=raw_stream0)
        del buf67
        del buf68
        buf71 = reinterpret_tensor(buf72, (1, 2, 1, 16), (64, 32, 32, 1), 16)  # alias
        # Topologically Sorted Source Nodes: [linear_15, view_7, k_8, chunk_5, neg_5, cat_9], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6.run(buf66, buf71, 32, stream=raw_stream0)
        buf75 = buf52; del buf52  # reuse
        buf73 = reinterpret_tensor(buf75, (1, 2, 128, 32), (8256, 4128, 32, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_15, view_7, k_8, getitem_16, mul_12, mul_13, k_9, k_10], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_23.run(arg4_1, buf73, 8192, stream=raw_stream0)
        del buf70
        del buf71
        buf74 = reinterpret_tensor(buf75, (1, 2, 1, 32), (8256, 4128, 32, 1), 4096)  # alias
        buf131 = reinterpret_tensor(buf133, (1, 2, 1, 32), (64, 32, 32, 1), 128)  # alias
        # Topologically Sorted Source Nodes: [linear_15, view_7, k_8, mul_12, mul_13, k_9, stack], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8.run(buf66, arg2_1, buf72, arg3_1, buf74, buf131, 64, stream=raw_stream0)
        del buf66
        buf76 = reinterpret_tensor(buf47, (4, 1, 129), (129, 129, 1), 0); del buf47  # reuse
        # Topologically Sorted Source Nodes: [linear_14, view_6, q_4, mul_10, mul_11, q_5, o_4, getitem_22, expand_4, k_11], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9.run(buf65, arg2_1, buf69, arg3_1, buf75, buf76, 516, 32, stream=raw_stream0)
        del buf73
        del buf74
        buf77 = buf45; del buf45  # reuse
        buf79 = empty_strided((1, 4, 1, 129), (516, 129, 516, 1), device='tnca', dtype=torch.float32)
        buf80 = buf48; del buf48  # reuse
        # Topologically Sorted Source Nodes: [o_4], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10.run(buf76, buf77, buf79, buf80, 4, 129, stream=raw_stream0)
        del buf76
        assert_size_stride(arg27_1, (64, 128), (128, 1), 'input')
        buf81 = reinterpret_tensor(buf72, (1, 64), (64, 1), 0); del buf72  # reuse
        # Topologically Sorted Source Nodes: [linear_16], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf64, arg27_1, buf81, 4, 1, 1, stream=raw_stream0)
        del arg27_1
        buf84 = buf75; del buf75  # reuse
        buf82 = reinterpret_tensor(buf84, (1, 2, 128, 32), (8256, 4128, 32, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [getitem_17, linear_16, view_8, v_6, v_7], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_23.run(arg5_1, buf82, 8192, stream=raw_stream0)
        buf83 = reinterpret_tensor(buf84, (1, 2, 1, 32), (8256, 4128, 32, 1), 4096)  # alias
        buf138 = empty_strided((4, 2, 1, 32), (64, 32, 32, 1), device='tnca', dtype=torch.float16)
        buf136 = reinterpret_tensor(buf138, (1, 2, 1, 32), (64, 32, 32, 1), 128)  # alias
        # Topologically Sorted Source Nodes: [linear_2, view_2, v, linear_9, view_5, v_3, getitem_17, linear_16, view_8, v_6, v_7, linear_23, view_11, v_9, stack_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.cat, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_select_stack_transpose_view_24.run(buf81, buf83, buf136, 64, stream=raw_stream0)
        del buf81
        buf86 = reinterpret_tensor(buf64, (1, 4, 1, 32), (128, 32, 32, 1), 0); del buf64  # reuse
        # Topologically Sorted Source Nodes: [o_4, getitem_23, expand_5, v_8], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(buf77, buf79, buf80, buf84, buf86, 128, 129, stream=raw_stream0)
        del buf79
        del buf82
        del buf83
        assert_size_stride(arg28_1, (128, 128), (128, 1), 'input')
        buf87 = reinterpret_tensor(buf69, (1, 128), (128, 1), 0); del buf69  # reuse
        # Topologically Sorted Source Nodes: [o_4, transpose_11, o_5, h_2], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf86, arg28_1, buf87, 8, 1, 1, stream=raw_stream0)
        del arg28_1
        assert_size_stride(arg29_1, (128, ), (1, ), 'input')
        buf89 = reinterpret_tensor(buf86, (1, 1, 128), (128, 128, 1), 0); del buf86  # reuse
        # Topologically Sorted Source Nodes: [linear_13, x_4, h_2, x_5, y_2], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25.run(buf56, buf62, buf87, arg29_1, buf89, 1, 128, stream=raw_stream0)
        del arg29_1
        assert_size_stride(arg30_1, (352, 128), (128, 1), 'input')
        buf90 = empty_strided((1, 352), (352, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_18], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_14.run(buf89, arg30_1, buf90, 22, 1, 1, stream=raw_stream0)
        del arg30_1
        assert_size_stride(arg31_1, (352, 128), (128, 1), 'input')
        buf92 = empty_strided((1, 1, 352), (352, 352, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_18, silu_2, linear_19, mul_14], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf89, arg31_1, buf90, buf92, 22, 1, 1, stream=raw_stream0)
        del arg31_1
        del buf90
        assert_size_stride(arg32_1, (128, 352), (352, 1), 'input')
        buf93 = reinterpret_tensor(buf89, (1, 128), (128, 1), 0); del buf89  # reuse
        # Topologically Sorted Source Nodes: [linear_18, silu_2, linear_19, mul_14, linear_20], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf92, arg32_1, buf93, 8, 1, 1, stream=raw_stream0)
        del arg32_1
        del buf92
        assert_size_stride(arg33_1, (128, ), (1, ), 'input')
        buf95 = reinterpret_tensor(buf65, (1, 1, 128), (128, 128, 1), 0); del buf65  # reuse
        # Topologically Sorted Source Nodes: [linear_13, x_4, h_2, x_5, linear_20, x_6, rms_norm_6], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_26.run(buf56, buf62, buf87, buf93, arg33_1, buf95, 1, 128, stream=raw_stream0)
        del arg33_1
        assert_size_stride(arg34_1, (128, 128), (128, 1), 'input')
        buf96 = empty_strided((1, 128), (128, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_21], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_18.run(buf95, arg34_1, buf96, 8, 1, 1, stream=raw_stream0)
        del arg34_1
        assert_size_stride(arg35_1, (64, 128), (128, 1), 'input')
        buf97 = empty_strided((1, 64), (64, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_22], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf95, arg35_1, buf97, 4, 1, 1, stream=raw_stream0)
        del arg35_1
        buf100 = empty_strided((1, 4, 1, 32), (128, 32, 32, 1), device='tnca', dtype=torch.float16)
        buf98 = reinterpret_tensor(buf100, (1, 4, 1, 16), (128, 32, 32, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_21, view_9, q_6, chunk_6, neg_6], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf96, buf98, 64, stream=raw_stream0)
        buf99 = reinterpret_tensor(buf100, (1, 4, 1, 16), (128, 32, 32, 1), 16)  # alias
        # Topologically Sorted Source Nodes: [linear_21, view_9, q_6, chunk_6, neg_6, cat_12], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf96, buf99, 64, stream=raw_stream0)
        buf103 = empty_strided((1, 2, 1, 32), (64, 32, 32, 1), device='tnca', dtype=torch.float16)
        buf101 = reinterpret_tensor(buf103, (1, 2, 1, 16), (64, 32, 32, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_22, view_10, k_12, chunk_7, neg_7], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_5.run(buf97, buf101, 32, stream=raw_stream0)
        del buf98
        del buf99
        buf102 = reinterpret_tensor(buf103, (1, 2, 1, 16), (64, 32, 32, 1), 16)  # alias
        # Topologically Sorted Source Nodes: [linear_22, view_10, k_12, chunk_7, neg_7, cat_13], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6.run(buf97, buf102, 32, stream=raw_stream0)
        buf106 = buf84; del buf84  # reuse
        buf104 = reinterpret_tensor(buf106, (1, 2, 128, 32), (8256, 4128, 32, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_22, view_10, k_12, getitem_24, mul_17, mul_18, k_13, k_14], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_27.run(arg4_1, buf104, 8192, stream=raw_stream0)
        del arg4_1
        del buf101
        del buf102
        buf105 = reinterpret_tensor(buf106, (1, 2, 1, 32), (8256, 4128, 32, 1), 4096)  # alias
        buf132 = reinterpret_tensor(buf133, (1, 2, 1, 32), (64, 32, 32, 1), 192)  # alias
        # Topologically Sorted Source Nodes: [linear_22, view_10, k_12, mul_17, mul_18, k_13, stack], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8.run(buf97, arg2_1, buf103, arg3_1, buf105, buf132, 64, stream=raw_stream0)
        del buf103
        buf107 = empty_strided((4, 1, 129), (129, 129, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [linear_21, view_9, q_6, mul_15, mul_16, q_7, o_6, getitem_30, expand_6, k_15], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9.run(buf96, arg2_1, buf100, arg3_1, buf106, buf107, 516, 32, stream=raw_stream0)
        del arg2_1
        del arg3_1
        del buf100
        del buf104
        del buf105
        del buf96
        buf108 = buf77; del buf77  # reuse
        buf110 = empty_strided((1, 4, 1, 129), (516, 129, 516, 1), device='tnca', dtype=torch.float32)
        buf111 = buf80; del buf80  # reuse
        # Topologically Sorted Source Nodes: [o_6], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10.run(buf107, buf108, buf110, buf111, 4, 129, stream=raw_stream0)
        del buf107
        assert_size_stride(arg36_1, (64, 128), (128, 1), 'input')
        buf112 = buf97; del buf97  # reuse
        # Topologically Sorted Source Nodes: [linear_23], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf95, arg36_1, buf112, 4, 1, 1, stream=raw_stream0)
        del arg36_1
        del buf95
        buf115 = buf106; del buf106  # reuse
        buf113 = reinterpret_tensor(buf115, (1, 2, 128, 32), (8256, 4128, 32, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [getitem_25, linear_23, view_11, v_9, v_10], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_27.run(arg5_1, buf113, 8192, stream=raw_stream0)
        del arg5_1
        buf114 = reinterpret_tensor(buf115, (1, 2, 1, 32), (8256, 4128, 32, 1), 4096)  # alias
        buf137 = reinterpret_tensor(buf138, (1, 2, 1, 32), (64, 32, 32, 1), 192)  # alias
        # Topologically Sorted Source Nodes: [linear_2, view_2, v, linear_9, view_5, v_3, linear_16, view_8, v_6, getitem_25, linear_23, view_11, v_9, v_10, stack_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.cat, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_select_stack_transpose_view_24.run(buf112, buf114, buf137, 64, stream=raw_stream0)
        del buf112
        buf117 = empty_strided((1, 4, 1, 32), (128, 32, 32, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [o_6, getitem_31, expand_7, v_11], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(buf108, buf110, buf111, buf115, buf117, 128, 129, stream=raw_stream0)
        del buf108
        del buf110
        del buf111
        del buf113
        del buf114
        del buf115
        assert_size_stride(arg37_1, (128, 128), (128, 1), 'input')
        buf118 = empty_strided((1, 128), (128, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [o_6, transpose_15, o_7, h_3], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf117, arg37_1, buf118, 8, 1, 1, stream=raw_stream0)
        del arg37_1
        assert_size_stride(arg38_1, (128, ), (1, ), 'input')
        buf119 = buf56; del buf56  # reuse
        buf121 = reinterpret_tensor(buf117, (1, 1, 128), (128, 128, 1), 0); del buf117  # reuse
        # Topologically Sorted Source Nodes: [linear_13, x_4, h_2, x_5, linear_20, x_6, h_3, x_7, y_3], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_28.run(buf119, buf62, buf87, buf93, buf118, arg38_1, buf121, 1, 128, stream=raw_stream0)
        del arg38_1
        del buf118
        del buf62
        del buf87
        del buf93
        assert_size_stride(arg39_1, (352, 128), (128, 1), 'input')
        buf122 = empty_strided((1, 352), (352, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [y_3, linear_25], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_21.run(buf121, arg39_1, buf122, 22, 1, 1, stream=raw_stream0)
        del arg39_1
        assert_size_stride(arg40_1, (352, 128), (128, 1), 'input')
        buf124 = empty_strided((1, 1, 352), (352, 352, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_25, silu_3, linear_26, mul_19], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf121, arg40_1, buf122, buf124, 22, 1, 1, stream=raw_stream0)
        del arg40_1
        del buf122
        assert_size_stride(arg41_1, (128, 352), (352, 1), 'input')
        buf125 = reinterpret_tensor(buf121, (1, 128), (128, 1), 0); del buf121  # reuse
        # Topologically Sorted Source Nodes: [linear_25, silu_3, linear_26, mul_19, linear_27], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf124, arg41_1, buf125, 8, 1, 1, stream=raw_stream0)
        del arg41_1
        del buf124
        assert_size_stride(arg42_1, (128, ), (1, ), 'input')
        buf127 = buf119; del buf119  # reuse
        # Topologically Sorted Source Nodes: [linear_27, x_8, rms_norm_8], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_29.run(buf127, buf125, arg42_1, 1, 128, stream=raw_stream0)
        del arg42_1
        del buf125
        assert_size_stride(arg43_1, (512, 128), (128, 1), 'input')
        buf128 = empty_strided((1, 512), (512, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_27, x_8, rms_norm_8, linear_28], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_t_view_30.run(buf127, arg43_1, buf128, 32, 1, 1, stream=raw_stream0)
        del arg43_1
        del buf127
        buf134 = reinterpret_tensor(buf138, (1, 2, 1, 32), (64, 32, 32, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_2, view_2, v, linear_9, view_5, v_3, linear_16, view_8, v_6, linear_23, view_11, v_9, stack_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_stack_transpose_view_31.run(buf18, buf134, 64, stream=raw_stream0)
        del buf18
        buf135 = reinterpret_tensor(buf138, (1, 2, 1, 32), (64, 32, 32, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [linear_2, view_2, v, linear_9, view_5, v_3, linear_16, view_8, v_6, linear_23, view_11, v_9, stack_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_stack_transpose_view_31.run(buf49, buf135, 64, stream=raw_stream0)
        del buf49
        return (reinterpret_tensor(buf128, (1, 1, 512), (512, 512, 1), 0), reinterpret_tensor(buf133, (4, 1, 2, 1, 32), (64, 64, 32, 32, 1), 0), reinterpret_tensor(buf138, (4, 1, 2, 1, 32), (64, 64, 32, 32, 1), 0), )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((512, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    arg1_1 = rand_strided((1, 1), (1, 1), device='tnca:0', dtype=torch.int64)
    arg2_1 = rand_strided((1, 32), (32, 1), device='tnca:0', dtype=torch.float16)
    arg3_1 = rand_strided((1, 32), (32, 1), device='tnca:0', dtype=torch.float16)
    arg4_1 = rand_strided((4, 1, 2, 128, 32), (8192, 8192, 4096, 32, 1), device='tnca:0', dtype=torch.float16)
    arg5_1 = rand_strided((4, 1, 2, 128, 32), (8192, 8192, 4096, 32, 1), device='tnca:0', dtype=torch.float16)
    arg6_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg7_1 = rand_strided((128, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    arg8_1 = rand_strided((64, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    arg9_1 = rand_strided((64, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    arg10_1 = rand_strided((128, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    arg11_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg12_1 = rand_strided((352, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    arg13_1 = rand_strided((352, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    arg14_1 = rand_strided((128, 352), (352, 1), device='tnca:0', dtype=torch.float16)
    arg15_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg16_1 = rand_strided((128, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    arg17_1 = rand_strided((64, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    arg18_1 = rand_strided((64, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    arg19_1 = rand_strided((128, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    arg20_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg21_1 = rand_strided((352, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    arg22_1 = rand_strided((352, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    arg23_1 = rand_strided((128, 352), (352, 1), device='tnca:0', dtype=torch.float16)
    arg24_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg25_1 = rand_strided((128, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    arg26_1 = rand_strided((64, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    arg27_1 = rand_strided((64, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    arg28_1 = rand_strided((128, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    arg29_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg30_1 = rand_strided((352, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    arg31_1 = rand_strided((352, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    arg32_1 = rand_strided((128, 352), (352, 1), device='tnca:0', dtype=torch.float16)
    arg33_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg34_1 = rand_strided((128, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    arg35_1 = rand_strided((64, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    arg36_1 = rand_strided((64, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    arg37_1 = rand_strided((128, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    arg38_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg39_1 = rand_strided((352, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    arg40_1 = rand_strided((352, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    arg41_1 = rand_strided((128, 352), (352, 1), device='tnca:0', dtype=torch.float16)
    arg42_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg43_1 = rand_strided((512, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
