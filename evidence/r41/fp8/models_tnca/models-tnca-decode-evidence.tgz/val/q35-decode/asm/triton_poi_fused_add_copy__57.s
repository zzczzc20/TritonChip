    s.rdspecial  s1, arg_base
    v.movi       v0, #0
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v1, #0
    s.movz       s3, #17
    s.ld.d       s4, [s2, #0]                    // one element, not a vector
    v.movi       v2, #0
    v.movi       v3, #0
    s.lshri      s2, s4, #32
    s.ld.d       s5, [s1, #8]                    // out_ptr1: device_ptr64 at arg_base+8
    v.insert     v0, s4, #0
    v.insert     v1, s2, #0
    v.extract    s1, v0, #0
    v.extract    s2, v1, #0
    s.shli       s4, s2, #32
    v.movi       v0, #0
    s.or         s2, s1, s4
    v.movi       v1, #1
    s.add        s1, s2, s3
    v.iota       v4                              // arange(0, VLEN)
    s.lshri      s2, s1, #32
    v.insert     v2, s1, #0
    v.insert     v3, s2, #0
    v.shl        v5, v0, v1
    s.addi       s1, s5, #4
    v.cmpi.lt    p1, v4, #1
    @p1 v.st.scatter.w [s5, v5], v2
    @p1 v.st.scatter.w [s1, v5], v3
    exit
    exit
