#!/usr/bin/env python3
"""Compare completed profiled TLM runs with identical prompts and depths."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import sys

import torch
from safetensors.torch import load_file

p = argparse.ArgumentParser()
p.add_argument('--model', choices=('q35', 'model'), required=True)
p.add_argument('--tree', type=Path, required=True)
p.add_argument('--out', type=Path, required=True)
a = p.parse_args()
sys.path[:0] = [str(a.tree), str(a.tree / 'python'), str(a.tree / 'compiler/python'), str(a.tree / 'tools/asm')]
from tnca import artifact

root = Path.home()
runs = [root / f'r41_x8_equal_output_vl_l1_{mode}_20261101' for mode in (0, 1)]
result = {'schema': 'r41-x8-equal-output-tlm-ab/1',
          'scope': 'reduced-depth DP SystemC/TLM; not a board or independent full-model quality result',
          'routes': [], 'code_mismatches': [], 'metadata_mismatches': []}
profiles = []
for run in runs:
    report = json.loads((run / 'report.json').read_text())
    profile = json.loads((run / 'profile/launches.json').read_text())['launches']
    profiles.append(profile)
    row = {'route': run.name, 'status': report['status'],
           'cpu_numerical_fallback': report.get('cpu_numerical_fallback'),
           'generated_tokens': report.get('generated_tokens'), 'steps': []}
    for index, kind in ((1, 'prefill'), (2, 'decode')):
        launches = [x for x in profile if x['step'] == index and not x.get('skipped', False)]
        fp8 = [x for x in launches if x['kernel'] == 'w8a8_block_dynamic_fp8_matmul_kernel']
        macs = instructions = 0
        for x in fp8:
            activation = next(z for z in x['args'] if z.get('role') == 'act' and z.get('dtype') == 'bfloat16')
            weight = next(z for z in x['args'] if z.get('role') == 'weight' and z.get('dtype') == 'float8_e4m3fn')
            macs += math.prod(activation['shape'][:-1]) * math.prod(weight['shape'])
            instructions += sum(v for k, v in x['counters'].items() if k.startswith('core_') and k.endswith('_instructions'))
        metered = next(x for x in report['steps'] if x['kind'] == kind)['transfers_inside_step']
        row['steps'].append(dict(kind=kind, launches=len(launches), device_cycles=sum(x['device_cycles'] for x in launches),
            code_loads=sum(x['code_load_count'] for x in launches), code_bytes=sum(x['code_upload_bytes'] for x in launches),
            evictions=sum(x['evicted'] for x in launches), host_read_calls=metered['host_read_calls'],
            fp8_macs=macs, fp8_instructions=instructions, fp8_instructions_per_mac=instructions / macs if macs else None))
    result['routes'].append(row)
left, right = profiles
result['same_launch_count'] = len(left) == len(right)
for index, (x, y) in enumerate(zip(left, right)):
    if (x['step'], x['kernel'], x['grid']) != (y['step'], y['kernel'], y['grid']):
        result['metadata_mismatches'].append(index)
    text_a = artifact.load(x['artifact'])[1]['text']
    text_b = artifact.load(y['artifact'])[1]['text']
    if hashlib.sha256(text_a).digest() != hashlib.sha256(text_b).digest():
        result['code_mismatches'].append(index)
left = load_file(str(runs[0] / 'logits.safetensors'))
right = load_file(str(runs[1] / 'logits.safetensors'))
if set(left) != set(right):
    raise ValueError('different logits keys')
result['logits'] = {k: {'elements': left[k].numel(),
    'bit_mismatches': int((left[k].contiguous().view(torch.int16) != right[k].contiguous().view(torch.int16)).sum())}
    for k in left}
a.out.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
