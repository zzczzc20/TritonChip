    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    s.rdspecial  s2, arg_base
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v2, #5
    v.add        v3, v1, v0
    v.movi       v0, #4
    v.movi       v1, #1
    v.mul        v4, v3, v2
    v.mul        v2, v3, v0
    v.movi       v3, #2
    v.add        v5, v4, v1
    v.add        v6, v2, v1
    v.add        v1, v4, v3
    s.ld.d       s4, [s2, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.movi       v7, #3
    v.add        v8, v2, v3
    v.add        v3, v4, v0
    v.add        v0, v4, v7
    v.add        v4, v2, v7
    .li       s5, #1069066811
    v.splat      v7, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s5, #1060205080
    v.splat      v9, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.ld.gather.h v10, [s3, v5]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.h v5, [s4, v2]                   // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v2, v10
    v.ld.gather.h v10, [s3, v1]                  // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v1, v5
    vf.mul       v5, v2, v1
    v.ld.gather.h v1, [s4, v6]                   // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v2, v10
    v.ld.gather.h v6, [s3, v0]                   // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v0, v1
    vf.mul       v1, v2, v0
    vf.add       v0, v5, v1
    v.ld.gather.h v1, [s4, v8]                   // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v2, v6
    v.ld.gather.h v5, [s3, v3]                   // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v3, v1
    vf.mul       v1, v2, v3
    vf.add       v2, v0, v1
    v.ld.gather.h v0, [s4, v4]                   // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v1, v5
    vf.cvt.bf16.f32 v3, v0
    s.ld.d       s3, [s2, #16]                   // out_ptr1: device_ptr64 at arg_base+16
    .li       s2, #1065353216
    v.splat      v0, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1065353216
    v.splat      v4, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s2, s1, #1                      // element offset -> bytes (x2)
    vf.mul       v5, v1, v3
    vf.add       v1, v2, v5
    s.add        s1, s3, s2                      // &out_ptr1[...]
    vf.neg       v2, v1
    vf.mul       v3, v2, v7
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v2, v7, v3                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v6, v9
    vf.fma       v3, v5, v2, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v2, v3, v5
    vf.add       v3, v2, v0
    v.rcp.approx v0, v3                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v2, v3, v0, v4
    vf.fms       v4, v0, v2, v0
    vf.neg       v2, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v4, v2, v0
    vf.mul       v0, v1, v4                      // a/y: faithful quotient
    vf.fms       v2, v0, v3, v1
    vf.fms       v1, v2, v4, v0
    vf.neg       v2, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v1, v2, v0
    vf.cvt.f32.bf16 v0, v1
    v.st.h       [s1, #0], v0
__rctx_next:
    exit
