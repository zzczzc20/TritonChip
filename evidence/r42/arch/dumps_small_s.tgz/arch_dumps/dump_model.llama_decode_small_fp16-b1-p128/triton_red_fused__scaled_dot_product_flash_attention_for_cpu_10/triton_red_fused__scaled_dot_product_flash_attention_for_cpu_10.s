    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #129
    s.movz       s5, #64
    s.movz       s6, #1
    s.rdspecial  s6, role_id
    s.rdspecial  s7, npid.x
    s.ld.d       s8, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.ld.d       s9, [s1, #16]                   // out_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s10, [s1, #24]                  // out_ptr3: device_ptr64 at arg_base+24
__rctx_program:
    s.mul        s1, s6, s4
    s.addi       s11, s2, #0
    v.movi       v0, #0
    v.movi       v1, #0
    v.iota       v2                              // arange(0, VLEN)
    s.add        s12, s11, s1
    v.movi       v3, #16
    v.movi       v4, #32
    v.movi       v5, #48
    .li       s1, #4286578688
    v.splat      v6, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v7, #0
    v.movi       v8, #0
    v.movi       v9, #0
    v.movi       v10, #0
    s.shli       s1, s12, #2                     // element offset -> bytes (x4)
    v.cmp.ne     p1, v0, v1
    v.add        v0, v2, v3
    v.add        v3, v2, v4
    v.add        v4, v2, v5
    p.mov        p2, p1
    p.mov        p3, p1
    p.mov        p4, p1
    p.mov        p5, p1
    v.mov        v7, v6
    v.mov        v8, v6
    v.mov        v9, v6
    v.mov        v10, v6
    v.movi       v5, #129
    v.movi       v11, #1
    s.add        s12, s3, s1                     // &in_ptr0[...]
for_1:
    v.splat      v12, s11
    v.splat      v13, s11
    v.splat      v14, s11
    v.add        v15, v12, v2
    v.splat      v12, s11
    v.add        v16, v13, v0
    v.cmp.lt     p1, v15, v5
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v13, [s12, #0]
    v.add        v15, v14, v3
    v.add        v14, v12, v4
    v.movi       v12, #0
    v.movi       v17, #0
    v.cmp.lt     p6, v16, v5
    v.cmp.lt     p7, v15, v5
    v.cmp.lt     p8, v14, v5
    vf.cmp.eq    p9, v13, v6
    @p9 v.sel        v14, v11, v1
    v.movi       v15, #0                         // other=, materialised (sec 12)
    @p6 v.ld.w       v15, [s12, #64]
    v.cmp.eq     p9, v14, v1
    @p9 v.sel        v14, v11, v1
    v.extract    s1, v14, #0
    v.extract    s13, v14, #1
    s.lshri      s14, s1, #32
    s.lshri      s15, s13, #32
    v.extract    s16, v14, #2
    v.extract    s17, v14, #3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p7 v.ld.w       v16, [s12, #128]
    vf.cmp.eq    p9, v15, v6
    @p9 v.sel        v18, v11, v1
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p8 v.ld.w       v19, [s12, #192]
    v.insert     v12, s1, #0
    v.insert     v17, s14, #0
    s.lshri      s1, s16, #32
    v.insert     v12, s13, #1
    v.insert     v17, s15, #1
    s.lshri      s13, s17, #32
    v.insert     v12, s16, #2
    v.insert     v17, s1, #2
    v.extract    s1, v14, #4
    v.insert     v12, s17, #3
    v.insert     v17, s13, #3
    s.lshri      s13, s1, #32
    v.extract    s14, v14, #5
    v.insert     v12, s1, #4
    v.insert     v17, s13, #4
    s.lshri      s1, s14, #32
    v.extract    s13, v14, #6
    v.insert     v12, s14, #5
    v.insert     v17, s1, #5
    s.lshri      s1, s13, #32
    v.extract    s14, v14, #7
    v.insert     v12, s13, #6
    v.insert     v17, s1, #6
    s.lshri      s1, s14, #32
    v.extract    s13, v14, #8
    v.insert     v12, s14, #7
    v.insert     v17, s1, #7
    s.lshri      s1, s13, #32
    v.extract    s14, v14, #9
    v.insert     v12, s13, #8
    v.insert     v17, s1, #8
    s.lshri      s1, s14, #32
    v.insert     v12, s14, #9
    v.insert     v17, s1, #9
    vf.cmp.eq    p9, v16, v6
    v.extract    s1, v14, #10
    @p9 v.sel        v20, v11, v1
    v.insert     v12, s1, #10
    vf.cmp.eq    p9, v19, v6
    s.lshri      s13, s1, #32
    @p9 v.sel        v21, v11, v1
    v.extract    s1, v14, #11
    v.insert     v17, s13, #10
    s.lshri      s13, s1, #32
    v.extract    s14, v14, #12
    v.insert     v12, s1, #11
    v.insert     v17, s13, #11
    s.lshri      s1, s14, #32
    v.extract    s13, v14, #13
    v.insert     v12, s14, #12
    v.insert     v17, s1, #12
    s.lshri      s1, s13, #32
    v.cmp.eq     p9, v18, v1
    v.extract    s14, v14, #14
    @p9 v.sel        v18, v11, v1
    v.insert     v12, s13, #13
    v.insert     v17, s1, #13
    s.lshri      s1, s14, #32
    v.extract    s13, v14, #15
    v.extract    s15, v18, #0
    v.insert     v12, s14, #14
    v.insert     v17, s1, #14
    v.movi       v14, #0
    v.movi       v22, #0
    s.lshri      s1, s13, #32
    s.lshri      s14, s15, #32
    v.extract    s16, v18, #1
    v.insert     v12, s13, #15
    v.insert     v17, s1, #15
    v.insert     v14, s15, #0
    v.insert     v22, s14, #0
    s.lshri      s1, s16, #32
    v.extract    s13, v18, #2
    v.insert     v14, s16, #1
    v.insert     v22, s1, #1
    s.lshri      s1, s13, #32
    v.extract    s14, v18, #3
    v.insert     v14, s13, #2
    v.insert     v22, s1, #2
    s.lshri      s1, s14, #32
    v.extract    s13, v18, #4
    v.insert     v14, s14, #3
    v.insert     v22, s1, #3
    s.lshri      s1, s13, #32
    v.extract    s14, v18, #5
    v.insert     v14, s13, #4
    v.insert     v22, s1, #4
    s.lshri      s1, s14, #32
    v.extract    s13, v18, #6
    v.insert     v14, s14, #5
    v.insert     v22, s1, #5
    s.lshri      s1, s13, #32
    v.extract    s14, v18, #7
    v.insert     v14, s13, #6
    v.insert     v22, s1, #6
    s.lshri      s1, s14, #32
    v.extract    s13, v18, #8
    v.insert     v14, s14, #7
    v.insert     v22, s1, #7
    s.lshri      s1, s13, #32
    v.extract    s14, v18, #9
    v.insert     v14, s13, #8
    v.insert     v22, s1, #8
    s.lshri      s1, s14, #32
    v.extract    s13, v18, #10
    v.insert     v14, s14, #9
    v.insert     v22, s1, #9
    s.lshri      s1, s13, #32
    v.extract    s14, v18, #11
    v.insert     v14, s13, #10
    v.insert     v22, s1, #10
    s.lshri      s1, s14, #32
    v.extract    s13, v18, #12
    v.insert     v14, s14, #11
    v.insert     v22, s1, #11
    s.lshri      s1, s13, #32
    v.extract    s14, v18, #13
    v.insert     v14, s13, #12
    v.insert     v22, s1, #12
    s.lshri      s1, s14, #32
    v.cmp.eq     p9, v20, v1
    v.extract    s13, v18, #14
    @p9 v.sel        v20, v11, v1
    v.insert     v14, s14, #13
    v.insert     v22, s1, #13
    s.lshri      s1, s13, #32
    v.extract    s14, v18, #15
    v.extract    s15, v20, #0
    v.insert     v14, s13, #14
    v.insert     v22, s1, #14
    v.movi       v18, #0
    v.movi       v23, #0
    s.lshri      s1, s14, #32
    s.lshri      s13, s15, #32
    v.extract    s16, v20, #1
    v.insert     v14, s14, #15
    v.insert     v22, s1, #15
    v.insert     v18, s15, #0
    v.insert     v23, s13, #0
    s.lshri      s1, s16, #32
    v.extract    s13, v20, #2
    v.insert     v18, s16, #1
    v.insert     v23, s1, #1
    s.lshri      s1, s13, #32
    v.extract    s14, v20, #3
    v.insert     v18, s13, #2
    v.insert     v23, s1, #2
    s.lshri      s1, s14, #32
    v.extract    s13, v20, #4
    v.insert     v18, s14, #3
    v.insert     v23, s1, #3
    s.lshri      s1, s13, #32
    v.extract    s14, v20, #5
    v.insert     v18, s13, #4
    v.insert     v23, s1, #4
    s.lshri      s1, s14, #32
    v.extract    s13, v20, #6
    v.insert     v18, s14, #5
    v.insert     v23, s1, #5
    s.lshri      s1, s13, #32
    v.extract    s14, v20, #7
    v.insert     v18, s13, #6
    v.insert     v23, s1, #6
    s.lshri      s1, s14, #32
    v.extract    s13, v20, #8
    v.insert     v18, s14, #7
    v.insert     v23, s1, #7
    s.lshri      s1, s13, #32
    v.extract    s14, v20, #9
    v.insert     v18, s13, #8
    v.insert     v23, s1, #8
    s.lshri      s1, s14, #32
    v.extract    s13, v20, #10
    v.insert     v18, s14, #9
    v.insert     v23, s1, #9
    s.lshri      s1, s13, #32
    v.extract    s14, v20, #11
    v.insert     v18, s13, #10
    v.insert     v23, s1, #10
    s.lshri      s1, s14, #32
    v.extract    s13, v20, #12
    v.insert     v18, s14, #11
    v.insert     v23, s1, #11
    s.lshri      s1, s13, #32
    v.extract    s14, v20, #13
    v.insert     v18, s13, #12
    v.insert     v23, s1, #12
    s.lshri      s1, s14, #32
    v.cmp.eq     p9, v21, v1
    v.extract    s13, v20, #14
    @p9 v.sel        v21, v11, v1
    v.insert     v18, s14, #13
    v.insert     v23, s1, #13
    s.lshri      s1, s13, #32
    v.extract    s14, v20, #15
    v.extract    s15, v21, #0
    v.insert     v18, s13, #14
    v.insert     v23, s1, #14
    v.movi       v20, #0
    v.movi       v24, #0
    s.lshri      s1, s14, #32
    s.lshri      s13, s15, #32
    v.extract    s16, v21, #1
    v.insert     v18, s14, #15
    v.insert     v23, s1, #15
    v.insert     v20, s15, #0
    v.insert     v24, s13, #0
    s.lshri      s1, s16, #32
    v.extract    s13, v21, #2
    v.insert     v20, s16, #1
    v.insert     v24, s1, #1
    s.lshri      s1, s13, #32
    v.extract    s14, v21, #3
    v.insert     v20, s13, #2
    v.insert     v24, s1, #2
    s.lshri      s1, s14, #32
    v.extract    s13, v21, #4
    v.insert     v20, s14, #3
    v.insert     v24, s1, #3
    s.lshri      s1, s13, #32
    v.extract    s14, v21, #5
    v.insert     v20, s13, #4
    v.insert     v24, s1, #4
    s.lshri      s1, s14, #32
    v.extract    s13, v21, #6
    v.insert     v20, s14, #5
    v.insert     v24, s1, #5
    s.lshri      s1, s13, #32
    v.extract    s14, v21, #7
    v.insert     v20, s13, #6
    v.insert     v24, s1, #6
    s.lshri      s1, s14, #32
    v.extract    s13, v21, #8
    v.insert     v20, s14, #7
    v.insert     v24, s1, #7
    s.lshri      s1, s13, #32
    v.extract    s14, v21, #9
    v.insert     v20, s13, #8
    v.insert     v24, s1, #8
    s.lshri      s1, s14, #32
    v.extract    s13, v21, #10
    v.insert     v20, s14, #9
    v.insert     v24, s1, #9
    s.lshri      s1, s13, #32
    v.extract    s14, v21, #11
    v.insert     v20, s13, #10
    v.insert     v24, s1, #10
    s.lshri      s1, s14, #32
    v.extract    s13, v21, #12
    v.insert     v20, s14, #11
    v.insert     v24, s1, #11
    s.lshri      s1, s13, #32
    v.extract    s14, v21, #13
    v.insert     v20, s13, #12
    v.insert     v24, s1, #12
    s.lshri      s1, s14, #32
    v.extract    s13, v17, #0
    v.extract    s15, v21, #14
    v.insert     v20, s14, #13
    v.insert     v24, s1, #13
    v.extract    s1, v12, #0
    s.shli       s14, s13, #32
    s.lshri      s13, s15, #32
    v.extract    s16, v17, #1
    v.extract    s17, v21, #15
    s.or         s18, s1, s14
    v.insert     v20, s15, #14
    v.insert     v24, s13, #14
    v.movi       v21, #0
    v.extract    s1, v12, #1
    s.shli       s13, s16, #32
    s.lshri      s14, s17, #32
    s.cmp.ne     s15, s18, s2
    v.extract    s16, v17, #2
    s.or         s18, s1, s13
    v.insert     v20, s17, #15
    v.insert     v24, s14, #15
    v.insert     v21, s15, #0
    v.extract    s1, v12, #2
    s.shli       s13, s16, #32
    s.cmp.ne     s14, s18, s2
    v.extract    s15, v17, #3
    s.or         s16, s1, s13
    v.insert     v21, s14, #1
    v.extract    s1, v12, #3
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v17, #4
    s.or         s16, s1, s13
    v.insert     v21, s14, #2
    v.extract    s1, v12, #4
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v17, #5
    s.or         s16, s1, s13
    v.insert     v21, s14, #3
    v.extract    s1, v12, #5
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v17, #6
    s.or         s16, s1, s13
    v.insert     v21, s14, #4
    v.extract    s1, v12, #6
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    vf.max.prop  v25, v7, v13
    s.or         s15, s1, s13
    v.insert     v21, s14, #5
    vf.max.prop  v13, v8, v15
    s.cmp.ne     s1, s15, s2
    vf.max.prop  v15, v9, v16
    v.insert     v21, s1, #6
    vf.max.prop  v16, v10, v19
    v.extract    s1, v12, #7
    @p1 v.sel        v7, v25, v7
    v.extract    s13, v17, #7
    @p6 v.sel        v8, v13, v8
    s.shli       s14, s13, #32
    @p7 v.sel        v9, v15, v9
    s.or         s13, s1, s14
    @p8 v.sel        v10, v16, v10
    v.extract    s1, v17, #8
    v.extract    s14, v12, #8
    s.shli       s15, s1, #32
    s.cmp.ne     s1, s13, s2
    v.extract    s13, v17, #9
    s.or         s16, s14, s15
    v.insert     v21, s1, #7
    v.extract    s1, v12, #9
    s.shli       s14, s13, #32
    s.cmp.ne     s13, s16, s2
    v.extract    s15, v17, #10
    s.or         s16, s1, s14
    v.insert     v21, s13, #8
    v.extract    s1, v12, #10
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v17, #11
    s.or         s16, s1, s13
    v.insert     v21, s14, #9
    v.extract    s1, v12, #11
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v17, #12
    s.or         s16, s1, s13
    v.insert     v21, s14, #10
    v.extract    s1, v12, #12
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v17, #13
    s.or         s16, s1, s13
    v.insert     v21, s14, #11
    v.extract    s1, v12, #13
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v17, #14
    s.or         s16, s1, s13
    v.insert     v21, s14, #12
    v.extract    s1, v12, #14
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v17, #15
    v.extract    s16, v22, #0
    s.or         s17, s1, s13
    v.insert     v21, s14, #13
    v.extract    s1, v12, #15
    s.shli       s13, s15, #32
    v.extract    s14, v14, #0
    s.shli       s15, s16, #32
    s.cmp.ne     s16, s17, s2
    v.extract    s17, v22, #1
    s.or         s18, s1, s13
    s.or         s1, s14, s15
    v.insert     v21, s16, #14
    v.movi       v12, #0
    v.extract    s13, v14, #1
    s.shli       s14, s17, #32
    s.cmp.ne     s15, s18, s2
    s.cmp.ne     s16, s1, s2
    v.extract    s1, v22, #2
    s.or         s17, s13, s14
    v.insert     v21, s15, #15
    v.insert     v12, s16, #0
    v.extract    s13, v14, #2
    s.shli       s14, s1, #32
    s.cmp.ne     s1, s17, s2
    v.extract    s15, v22, #3
    s.or         s16, s13, s14
    v.insert     v12, s1, #1
    v.extract    s1, v14, #3
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v22, #4
    s.or         s16, s1, s13
    v.insert     v12, s14, #2
    v.extract    s1, v14, #4
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v22, #5
    s.or         s16, s1, s13
    v.insert     v12, s14, #3
    v.extract    s1, v14, #5
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v22, #6
    s.or         s16, s1, s13
    v.insert     v12, s14, #4
    v.extract    s1, v14, #6
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    s.or         s15, s1, s13
    v.insert     v12, s14, #5
    v.cmp.ne     p9, v21, v1
    s.cmp.ne     s1, s15, s2
    p.or         p10, p2, p9
    v.insert     v12, s1, #6
    p.not        p9, p1
    p.and        p11, p1, p10
    v.extract    s1, v22, #7
    v.extract    s13, v14, #7
    p.and        p1, p9, p2
    s.shli       s14, s1, #32
    p.or         p9, p11, p1
    s.or         s1, s13, s14
    p.mov        p1, p9
    v.extract    s13, v22, #8
    v.extract    s14, v14, #8
    s.shli       s15, s13, #32
    s.cmp.ne     s13, s1, s2
    v.extract    s1, v22, #9
    s.or         s16, s14, s15
    v.insert     v12, s13, #7
    v.extract    s13, v14, #9
    s.shli       s14, s1, #32
    s.cmp.ne     s1, s16, s2
    v.extract    s15, v22, #10
    s.or         s16, s13, s14
    v.insert     v12, s1, #8
    v.extract    s1, v14, #10
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v22, #11
    s.or         s16, s1, s13
    v.insert     v12, s14, #9
    v.extract    s1, v14, #11
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v22, #12
    s.or         s16, s1, s13
    v.insert     v12, s14, #10
    v.extract    s1, v14, #12
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v22, #13
    s.or         s16, s1, s13
    v.insert     v12, s14, #11
    v.extract    s1, v14, #13
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v22, #14
    s.or         s16, s1, s13
    v.insert     v12, s14, #12
    v.extract    s1, v14, #14
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v22, #15
    v.extract    s16, v23, #0
    s.or         s17, s1, s13
    v.insert     v12, s14, #13
    v.extract    s1, v14, #15
    s.shli       s13, s15, #32
    v.extract    s14, v18, #0
    s.shli       s15, s16, #32
    s.cmp.ne     s16, s17, s2
    v.extract    s17, v23, #1
    s.or         s18, s1, s13
    s.or         s1, s14, s15
    v.insert     v12, s16, #14
    v.movi       v13, #0
    v.extract    s13, v18, #1
    s.shli       s14, s17, #32
    s.cmp.ne     s15, s18, s2
    s.cmp.ne     s16, s1, s2
    v.extract    s1, v23, #2
    s.or         s17, s13, s14
    v.insert     v12, s15, #15
    v.insert     v13, s16, #0
    v.extract    s13, v18, #2
    s.shli       s14, s1, #32
    s.cmp.ne     s1, s17, s2
    v.extract    s15, v23, #3
    s.or         s16, s13, s14
    v.insert     v13, s1, #1
    v.extract    s1, v18, #3
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v23, #4
    s.or         s16, s1, s13
    v.insert     v13, s14, #2
    v.extract    s1, v18, #4
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v23, #5
    s.or         s16, s1, s13
    v.insert     v13, s14, #3
    v.extract    s1, v18, #5
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v23, #6
    s.or         s16, s1, s13
    v.insert     v13, s14, #4
    v.extract    s1, v18, #6
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    s.or         s15, s1, s13
    v.insert     v13, s14, #5
    v.cmp.ne     p9, v12, v1
    s.cmp.ne     s1, s15, s2
    p.or         p10, p3, p9
    v.insert     v13, s1, #6
    p.not        p9, p6
    p.and        p11, p6, p10
    v.extract    s1, v23, #7
    v.extract    s13, v18, #7
    p.and        p6, p9, p3
    s.shli       s14, s1, #32
    p.or         p9, p11, p6
    s.or         s1, s13, s14
    p.mov        p6, p9
    v.extract    s13, v23, #8
    v.extract    s14, v18, #8
    s.shli       s15, s13, #32
    s.cmp.ne     s13, s1, s2
    v.extract    s1, v23, #9
    s.or         s16, s14, s15
    v.insert     v13, s13, #7
    v.extract    s13, v18, #9
    s.shli       s14, s1, #32
    s.cmp.ne     s1, s16, s2
    v.extract    s15, v23, #10
    s.or         s16, s13, s14
    v.insert     v13, s1, #8
    v.extract    s1, v18, #10
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v23, #11
    s.or         s16, s1, s13
    v.insert     v13, s14, #9
    v.extract    s1, v18, #11
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v23, #12
    s.or         s16, s1, s13
    v.insert     v13, s14, #10
    v.extract    s1, v18, #12
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v23, #13
    s.or         s16, s1, s13
    v.insert     v13, s14, #11
    v.extract    s1, v18, #13
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v23, #14
    s.or         s16, s1, s13
    v.insert     v13, s14, #12
    v.extract    s1, v18, #14
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v23, #15
    v.extract    s16, v24, #0
    s.or         s17, s1, s13
    v.insert     v13, s14, #13
    v.extract    s1, v18, #15
    s.shli       s13, s15, #32
    v.extract    s14, v20, #0
    s.shli       s15, s16, #32
    s.cmp.ne     s16, s17, s2
    v.extract    s17, v24, #1
    s.or         s18, s1, s13
    s.or         s1, s14, s15
    v.insert     v13, s16, #14
    v.movi       v12, #0
    v.extract    s13, v20, #1
    s.shli       s14, s17, #32
    s.cmp.ne     s15, s18, s2
    s.cmp.ne     s16, s1, s2
    v.extract    s1, v24, #2
    s.or         s17, s13, s14
    v.insert     v13, s15, #15
    v.insert     v12, s16, #0
    v.extract    s13, v20, #2
    s.shli       s14, s1, #32
    s.cmp.ne     s1, s17, s2
    v.extract    s15, v24, #3
    s.or         s16, s13, s14
    v.insert     v12, s1, #1
    v.extract    s1, v20, #3
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v24, #4
    s.or         s16, s1, s13
    v.insert     v12, s14, #2
    v.extract    s1, v20, #4
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v24, #5
    s.or         s16, s1, s13
    v.insert     v12, s14, #3
    v.extract    s1, v20, #5
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v24, #6
    s.or         s16, s1, s13
    v.insert     v12, s14, #4
    v.extract    s1, v20, #6
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    s.or         s15, s1, s13
    v.insert     v12, s14, #5
    v.cmp.ne     p9, v13, v1
    s.cmp.ne     s1, s15, s2
    p.or         p10, p4, p9
    v.insert     v12, s1, #6
    p.not        p9, p7
    p.and        p11, p7, p10
    v.extract    s1, v24, #7
    v.extract    s13, v20, #7
    p.and        p7, p9, p4
    s.shli       s14, s1, #32
    p.or         p9, p11, p7
    s.or         s1, s13, s14
    p.mov        p7, p9
    v.extract    s13, v24, #8
    v.extract    s14, v20, #8
    s.shli       s15, s13, #32
    s.cmp.ne     s13, s1, s2
    v.extract    s1, v24, #9
    s.or         s16, s14, s15
    v.insert     v12, s13, #7
    v.extract    s13, v20, #9
    s.shli       s14, s1, #32
    s.cmp.ne     s1, s16, s2
    v.extract    s15, v24, #10
    s.or         s16, s13, s14
    v.insert     v12, s1, #8
    v.extract    s1, v20, #10
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v24, #11
    s.or         s16, s1, s13
    v.insert     v12, s14, #9
    v.extract    s1, v20, #11
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v24, #12
    s.or         s16, s1, s13
    v.insert     v12, s14, #10
    v.extract    s1, v20, #12
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v24, #13
    s.or         s16, s1, s13
    v.insert     v12, s14, #11
    v.extract    s1, v20, #13
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v24, #14
    s.or         s16, s1, s13
    v.insert     v12, s14, #12
    v.extract    s1, v20, #14
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    v.extract    s15, v24, #15
    s.or         s16, s1, s13
    v.insert     v12, s14, #13
    v.extract    s1, v20, #15
    s.shli       s13, s15, #32
    s.cmp.ne     s14, s16, s2
    s.or         s15, s1, s13
    v.insert     v12, s14, #14
    s.cmp.ne     s1, s15, s2
    p.not        p9, p8
    v.insert     v12, s1, #15
    p.and        p10, p9, p5
    v.cmp.ne     p9, v12, v1
    p.or         p11, p5, p9
    p.and        p9, p8, p11
    p.mov        p2, p1
    p.or         p1, p9, p10
    p.mov        p3, p6
    p.mov        p6, p1
    p.mov        p4, p7
    p.mov        p5, p6
    s.addi       s12, s12, #256                  // the next iteration's address
    s.add        s11, s11, s5
    s.cmp.lt     s1, s11, s4
    br.nz        s1, for_1
endfor_2:
    v.movi       v1, #1
    v.movi       v5, #0
    vf.cmp.uo    p1, v7, v7
    vf.reduce.max.b v6, v7
    @p1 v.sel        v7, v1, v5
    vf.cmp.uo    p1, v8, v8
    @p1 v.sel        v11, v1, v5
    vf.cmp.uo    p1, v9, v9
    @p1 v.sel        v12, v1, v5
    vf.cmp.uo    p1, v10, v10
    @p1 v.sel        v13, v1, v5
    v.reduce.or.b v14, v7
    v.reduce.or.b v7, v11
    v.reduce.or.b v11, v12
    v.reduce.or.b v12, v13
    .li       s1, #2143289344
    v.splat      v13, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.reduce.max.b v15, v8
    vf.reduce.max.b v8, v9
    vf.reduce.max.b v9, v10
    v.cmp.ne     p1, v14, v5
    @p1 v.sel        v10, v13, v6
    v.cmp.ne     p1, v7, v5
    @p1 v.sel        v6, v13, v15
    v.cmp.ne     p1, v11, v5
    @p1 v.sel        v7, v13, v8
    v.cmp.ne     p1, v12, v5
    @p1 v.sel        v8, v13, v9
    @p2 v.sel        v9, v1, v5
    @p3 v.sel        v11, v1, v5
    @p4 v.sel        v12, v1, v5
    @p5 v.sel        v13, v1, v5
    vf.max.prop  v1, v10, v6
    vf.max.prop  v5, v7, v8
    v.reduce.or  s1, v9
    v.reduce.or  s11, v11
    v.reduce.or  s12, v12
    v.reduce.or  s13, v13
    v.splat      v6, s1
    v.splat      v7, s11
    v.splat      v8, s12
    v.splat      v9, s13
    vf.max.prop  v10, v1, v5
    v.or         v1, v6, v7
    v.or         v5, v8, v9
    v.movi       v6, #0
    s.movz       s1, #1
    v.or         v7, v1, v5
    vf.add       v1, v10, v6
    s.addi       s11, s2, #0
    v.extract    s12, v7, #0
    s.mul        s13, s6, s4
    s.shli       s14, s6, #0                     // element offset -> bytes (x1)
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v7, s1
    v.splat      v8, s12
    s.add        s1, s11, s13
    s.add        s12, s11, s13
    v.movi       v9, #0
    v.movi       v10, #0
    v.movi       v11, #0
    v.movi       v12, #0
    s.add        s13, s8, s14                    // &out_ptr0[...]
    v.extract    s14, v1, #0
    s.shli       s15, s1, #2                     // element offset -> bytes (x4)
    s.shli       s1, s12, #2                     // element offset -> bytes (x4)
    v.cmp.lt     p1, v5, v7
    @p1 v.st.b       [s13, #0], v8
    v.mov        v9, v6
    v.mov        v10, v6
    v.mov        v11, v6
    v.mov        v12, v6
    v.movi       v1, #129
    v.splat      v5, s14
    .li       s12, #1069066811
    v.splat      v7, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s12, #1060205080
    v.splat      v8, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s12, s3, s15                    // &in_ptr0[...]
    s.add        s13, s9, s1                     // &out_ptr2[...]
for_3:
    v.splat      v13, s11
    v.splat      v14, s11
    v.splat      v15, s11
    v.splat      v16, s11
    v.add        v17, v13, v2
    v.add        v13, v14, v0
    v.add        v14, v15, v3
    v.add        v15, v16, v4
    v.cmp.lt     p1, v17, v1
    v.cmp.lt     p2, v13, v1
    v.cmp.lt     p3, v14, v1
    v.cmp.lt     p4, v15, v1
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v13, [s12, #0]
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v14, [s12, #64]
    vf.sub       v15, v13, v5
    vf.mul       v13, v15, v7
    v.exp2.approx v16, v13                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v17, v15, v7, v13               // the exact rounding error of x*log2(e)
    vf.mul       v13, v17, v8
    v.movi       v15, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v15, [s12, #128]
    vf.sub       v17, v14, v5
    vf.mul       v14, v17, v7
    v.exp2.approx v18, v14                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v19, v17, v7, v14               // the exact rounding error of x*log2(e)
    vf.mul       v14, v19, v8
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v17, [s12, #192]
    vf.sub       v19, v15, v5
    vf.fma       v15, v16, v13, v16              // 2**t * 2**d
    vf.mul       v13, v19, v7
    vf.cmp.o     p5, v15, v15
    @p5 v.sel        v20, v15, v16
    v.exp2.approx v15, v13                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v16, v19, v7, v13               // the exact rounding error of x*log2(e)
    vf.add       v13, v9, v20
    vf.mul       v19, v16, v8
    vf.sub       v16, v17, v5
    @p1 v.sel        v9, v13, v9
    vf.fma       v13, v18, v14, v18              // 2**t * 2**d
    @p1 v.st.w       [s13, #0], v20
    vf.mul       v14, v16, v7
    vf.cmp.o     p1, v13, v13
    @p1 v.sel        v17, v13, v18
    v.exp2.approx v13, v14                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v18, v16, v7, v14               // the exact rounding error of x*log2(e)
    vf.add       v14, v10, v17
    vf.mul       v16, v18, v8
    @p2 v.sel        v10, v14, v10
    vf.fma       v14, v15, v19, v15              // 2**t * 2**d
    @p2 v.st.w       [s13, #64], v17
    vf.cmp.o     p1, v14, v14
    @p1 v.sel        v17, v14, v15
    vf.add       v14, v11, v17
    @p3 v.sel        v11, v14, v11
    vf.fma       v14, v13, v16, v13              // 2**t * 2**d
    @p3 v.st.w       [s13, #128], v17
    vf.cmp.o     p1, v14, v14
    @p1 v.sel        v15, v14, v13
    vf.add       v13, v12, v15
    @p4 v.sel        v12, v13, v12
    @p4 v.st.w       [s13, #192], v15
    s.addi       s12, s12, #256                  // the next iteration's address
    s.addi       s13, s13, #256                  // the next iteration's address
    s.add        s11, s11, s5
    s.cmp.lt     s1, s11, s4
    br.nz        s1, for_3
endfor_4:
    vf.reduce.add.b v0, v9
    vf.reduce.add.b v1, v10
    vf.reduce.add.b v2, v11
    vf.reduce.add.b v3, v12
    vf.add       v4, v0, v1
    s.movz       s1, #1
    vf.add       v0, v2, v3
    s.shli       s11, s6, #2                     // element offset -> bytes (x4)
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v2, s1
    s.add        s1, s10, s11                    // &out_ptr3[...]
    vf.add       v3, v4, v0
    v.cmp.lt     p1, v1, v2
    vf.add       v0, v3, v6
    @p1 v.st.w       [s1, #0], v0
__rctx_next:
    s.addi       s1, s6, #4                      // the next program of this context: + 4
    s.cmp.lt     s11, s1, s7
    s.mov        s6, s1
    br.nz        s11, __rctx_program
    exit
