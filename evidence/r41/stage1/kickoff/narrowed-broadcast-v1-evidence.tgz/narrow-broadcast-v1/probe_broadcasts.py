"""Compile-only: which [R,1] broadcast path each kernel of the regression graphs takes."""
import json, os, sys
from pathlib import Path
ROOT = Path(sys.argv[1]).resolve()
sys.path[:0] = [str(ROOT), str(ROOT/'python'), str(ROOT/'compiler/python'), str(ROOT/'tools/asm'), str(ROOT/'tools/r40')]
os.environ.update(TNCA_LAUNCH='skip', TNCA_TORCH_DEVICE='native', TNCA_PROFILE='core-vrf-sync-v5', TNCA_TRITON='1')
import torch, triton, torch.nn.functional as F
import tnca.inductor
from tnca.triton_backend import driver
from tnca.artifact import load
from v3_compile_preflight import HostSession
captured = []
orig = driver.TNCALauncher.__call__
def call(self, *a, **k):
    captured.append(Path(a[4] if len(a) > 4 else k['function']))
    return orig(self, *a, **k)
driver.TNCALauncher.__call__ = call
tnca.inductor.configure()
import tnca.torch_device as tdev
stub = HostSession('core-vrf-sync-v5')
tdev.MEMORY.session = lambda index=0: stub
tdev.register()
out = {}
def run(name, fn, *args):
    captured.clear()
    torch._dynamo.reset()
    compiled = torch.compile(fn, backend='inductor', fullgraph=True, dynamic=False)
    compiled(*[a.to('tnca') if isinstance(a, torch.Tensor) else a for a in args])
    rows = {}
    for p in set(captured):
        man, _ = load(p)
        prov = man['optional_metadata']['provenance']
        rows[man['identity']['kernel_name']] = prov.get('column_broadcasts')
    out[name] = rows
torch.manual_seed(1)
for dtype in (torch.float16, torch.bfloat16, torch.float32):
    x = (torch.arange(27).reshape(9, 3).to(dtype).transpose(0, 1) * .01)
    bias = torch.tensor([.1, .2, .3], dtype=dtype).reshape(3, 1)
    run(f'loaded-column-{dtype}', lambda a, b: a + b, x, bias)
for batch, channels, length, kernel, stride, pad, dilation, dtype, has_bias in [
        (2, 5, 11, 3, 2, 2, 1, torch.bfloat16, True), (1, 3, 9, 5, 1, 4, 2, torch.float16, True),
        (2, 3, 12, 2, 3, 1, 1, torch.float32, False)]:
    base = torch.randn(batch, length, channels).to(dtype) * .1
    w = torch.randn(channels, 1, kernel).to(dtype) * .1
    b = torch.randn(channels).to(dtype) * .1 if has_bias else None
    fn = lambda a, ww, bb: F.conv1d(a, ww, bb, stride=stride, padding=pad, dilation=dilation, groups=channels)
    run(f'depthwise-{dtype}-s{stride}-d{dilation}', fn, base.transpose(1, 2), w, b)
x = torch.randn(1, 8, 7).to(torch.bfloat16); w = torch.randn(8, 1, 4).to(torch.bfloat16)
run('primitive-depthwise', lambda a, ww: F.conv1d(a, ww, padding=3, groups=a.shape[1])[..., :a.shape[-1]], x, w)
print(json.dumps(out, indent=1))
