    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #4095
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    @p1 v.sel        v4, v1, v3
    v.movi       v1, #0
    v.and        v5, v4, v0
    v.movi       v0, #0
    v.sub        v4, v2, v5
    v.sub        v6, v0, v3
    @p1 v.sel        v7, v4, v5
    v.movi       v4, #8
    v.sub        v5, v1, v7
    v.cmp.lt     p1, v7, v1
    @p1 v.sel        v8, v5, v7
    v.cmp.lt     p2, v3, v0
    @p2 v.sel        v5, v6, v3
    v.movi       v3, #12
    v.lshr       v6, v8, v4
    v.movi       v4, #0
    v.lshr       v8, v5, v3
    v.sub        v3, v1, v6
    v.sub        v5, v0, v8
    @p1 v.sel        v9, v3, v6
    @p2 v.sel        v3, v5, v8
    v.movi       v5, #256
    s.rdspecial  s2, arg_base
    v.cmp.lt     p1, v7, v4
    s.ld.d       s3, [s2, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.movi       v6, #4352
    v.mul        v8, v3, v5
    v.mul        v10, v9, v6
    s.ld.d       s4, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.sub        v6, v4, v7
    v.add        v11, v8, v10
    s.ld.d       s5, [s2, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    @p1 v.sel        v8, v6, v7
    v.movi       v6, #255
    v.movi       v7, #4096
    v.and        v10, v8, v6
    v.sub        v6, v2, v7
    v.cmp.lt     p2, v7, v2
    v.movi       v2, #512
    v.cmp.lt     p3, v7, v0
    v.mul        v8, v9, v2
    v.sub        v2, v4, v10
    v.add        v9, v8, v5
    @p1 v.sel        v8, v2, v10
    v.sub        v2, v0, v7
    v.add        v0, v11, v8
    v.sub        v10, v1, v5
    v.ld.gather.w v11, [s4, v0]                  // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v1
    v.sub        v0, v4, v5
    @p2 v.sel        v1, v6, v7
    v.movi       v1, #8192
    v.cmp.lt     p2, v5, v4
    v.mul        v4, v3, v1
    .li       s2, #1069066811
    v.splat      v1, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v3, v9, v4
    @p3 v.sel        v4, v2, v7
    v.add        v2, v3, v8
    .li       s2, #1060205080
    v.splat      v3, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.ld.gather.h v4, [s3, v2]                   // index is in elements (ISA sec 9.1)
    .li       s2, #1065353216
    v.splat      v2, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1065353216
    v.splat      v6, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v7, v10, v5
    s.shli       s2, s1, #1                      // element offset -> bytes (x2)
    @p2 v.sel        v7, v0, v5
    vf.cvt.bf16.f32 v0, v4
    s.add        s1, s5, s2                      // &out_ptr0[...]
    vf.neg       v4, v0
    vf.mul       v0, v4, v1
    v.exp2.approx v5, v0                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v4, v1, v0                  // the exact rounding error of x*log2(e)
    vf.mul       v0, v7, v3
    vf.fma       v1, v5, v0, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v0, v1, v5
    vf.add       v1, v0, v2
    v.rcp.approx v0, v1                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v3, v1, v0, v6
    vf.fms       v4, v0, v3, v0
    vf.neg       v3, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v4, v3, v0
    vf.mul       v0, v2, v4                      // a/y: faithful quotient
    vf.fms       v3, v0, v1, v2
    vf.fms       v1, v3, v4, v0
    vf.neg       v2, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v1, v2, v0
    vf.mul       v0, v11, v1
    vf.cvt.f32.bf16 v1, v0
    v.st.h       [s1, #0], v1
__rctx_next:
    exit
