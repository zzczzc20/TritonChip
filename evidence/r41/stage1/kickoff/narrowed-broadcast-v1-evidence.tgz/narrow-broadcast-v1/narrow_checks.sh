#!/bin/bash
# Correctness checks of the narrowed [R,1] broadcast on the frozen tree.
set -u
SRC=$HOME/r41s1-narrow
OUT=${1:-$HOME/r41s1-work/narrow-checks}
rm -rf $OUT; mkdir -p $OUT
source $HOME/tc_env/env.sh
export PYTHONPATH=$SRC:$SRC/python:$SRC/compiler/python:$SRC/compiler/test:$SRC/tools/asm:$SRC/tools/performance_harness/systemc
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 TORCH_EXTENSIONS_DIR=$HOME/r41s1-audit/ext TNCA_CACHE=$HOME/r41s1-work/tnca-cache
export TNCA_TENSOR_DESCRIPTORS=1 TNCA_TORCH_DEVICE=native TNCA_PROFILE=core-vrf-sync-v5
export TNCA_TLM_BINARY=$HOME/r41s1-build/systemc-final/tnca-chip
export TNCA_TLM_CONFIG=$SRC/tools/performance_harness/systemc/configs/r40-board-m2.cfg
export TNCA_TLM_MEMORY_BYTES=33554432 TNCA_HOST_TIMEOUT=3600 TNCA_DEADLINE=200000000
export TRITON_CACHE_DIR=$OUT/triton-cache TORCHINDUCTOR_CACHE_DIR=$OUT/inductor-cache
P=$HOME/tc_env/torchenv/bin/python
cd $SRC
step() { name=$1; shift; timeout 5400 "$@" > $OUT/$name.log 2>&1; echo "$name exit $?" >> $OUT/status.txt; }
TNCA_BACKEND=systemc-tlm-grid TNCA_TLM_OUT=$OUT/depthwise-systemc-model step depthwise-systemc $P tools/performance_harness/test_depthwise.py -v
TNCA_BACKEND=systemc-tlm-grid TNCA_TLM_OUT=$OUT/primitives-systemc-model step primitives-systemc $P tools/performance_harness/primitive_cases.py --out $OUT/primitives-systemc
TNCA_BACKEND=sim-file step depthwise-rtl $P tools/performance_harness/test_depthwise.py -v
echo done >> $OUT/status.txt
