import os, sys
ROOT = os.path.expanduser(os.environ.get('ROOT', '~/r41-fp8-core'))
sys.path[:0] = [ROOT, ROOT+'/python', ROOT+'/compiler/python', ROOT+'/tools/asm', ROOT+'/tools/performance_harness/systemc']
os.environ.update(TNCA_PROFILE='core-vrf-sync-v5', TNCA_TORCH_DEVICE='native', TNCA_INDEX_OPT='1')
os.environ.setdefault('TNCA_BACKEND', 'systemc-tlm-grid')
os.environ.setdefault('TNCA_TLM_BINARY', os.path.expanduser('~/r41-fp8-build/tnca-chip'))
import torch, triton, tnca, tlm_backend
M = tlm_backend.register()
import tnca.torch_device as D; D.register()
from tnca.triton_backend.driver import launch_log
import torch._inductor.config as ic
torch._dynamo.config.recompile_limit = 1000
def measure(name, fn, args):
    torch._dynamo.reset()
    f = torch.compile(fn, backend='inductor', fullgraph=True)
    d = [a.to('tnca') for a in args]
    y = f(*d)
    with launch_log(isolated=True) as L:
        y = f(*d)
    print(f'{name:44s}', sum(e["device_cycles"] for e in L), [(e["kernel"][:36], e["device_cycles"]) for e in L], flush=True)
    return y.cpu()
torch.manual_seed(0)
x = torch.randn(64, 256).to(torch.bfloat16); w = torch.randn(192, 256).to(torch.float8_e4m3fn); s = torch.tensor(0.02); b = torch.randn(192).to(torch.bfloat16)
fn = lambda x, w, s, b: torch.nn.functional.linear(x, w.to(x.dtype) * s, b)
y1 = measure(f'weight-only (prologue_fusion={ic.prologue_fusion})', fn, (x, w, s, b))
ic.prologue_fusion = False
y2 = measure('weight-only (prologue_fusion=False)', fn, (x, w, s, b))
print('same bits', torch.equal(y1.view(torch.int16), y2.view(torch.int16)))
wb = (w.to(torch.bfloat16) * s)
measure('bf16 linear (dequantised weight given)', lambda x, w, b: torch.nn.functional.linear(x, w, b), (x, wb, b))
