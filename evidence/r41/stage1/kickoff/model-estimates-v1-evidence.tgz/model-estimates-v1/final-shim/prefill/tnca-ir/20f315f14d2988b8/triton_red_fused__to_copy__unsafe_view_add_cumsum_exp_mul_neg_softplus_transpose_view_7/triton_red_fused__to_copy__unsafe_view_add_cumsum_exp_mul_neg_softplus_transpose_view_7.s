    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.splat      v0, s4
    v.movi       v1, #0
    s.rdspecial  s1, arg_base
    v.movi       v2, #15
    v.sub        v3, v1, v0
    v.cmp.lt     p1, v0, v1
    s.ld.d       s2, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    @p1 v.sel        v4, v3, v0
    s.movz       s3, #1
    v.iota       v3                              // arange(0, VLEN)
    v.and        v5, v4, v2
    v.splat      v2, s3
    v.movi       v4, #0
    v.sub        v6, v1, v5
    v.cmp.lt     p2, v3, v2
    v.sub        v2, v4, v0
    @p1 v.sel        v3, v6, v5
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.cmp.lt     p1, v0, v4
    @p1 v.sel        v5, v2, v0
    v.movi       v0, #4
    s.movz       s5, #1
    v.movi       v2, #16
    v.lshr       v6, v5, v0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v5, s5
    v.sub        v7, v1, v2
    v.sub        v8, v4, v2
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v9, [s2, v3]               // index is in elements (ISA sec 9.1)
    v.sub        v10, v4, v6
    s.movz       s2, #0
    v.cmp.lt     p2, v2, v1
    .li       s5, #2143289344
    v.splat      v1, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.lt     p3, v0, v5
    v.movi       v0, #0
    s.movz       s5, #64
    s.movz       s6, #16
    v.iota       v5                              // arange(0, VLEN)
    v.movi       v11, #1
    @p2 v.sel        v11, v7, v2
    v.cmp.lt     p2, v2, v4
    v.movi       v4, #1
    s.ld.d       s7, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    @p2 v.sel        v4, v8, v2
    @p1 v.sel        v2, v10, v6
    vf.cvt.bf16.f32 v4, v9
    s.addi       s8, s2, #0
    s.ld.d       s9, [s1, #24]                   // out_ptr0: device_ptr64 at arg_base+24
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v6, [s3, v3]               // index is in elements (ISA sec 9.1)
    v.mov        v0, v1
for_1:
    s.cmp.ge     s1, s8, s5
    br.nz        s1, endfor_2
    v.splat      v1, s8
    v.movi       v7, #1024
    v.movi       v8, #16
    v.add        v9, v1, v5
    v.extract    s1, v3, #0
    v.mul        v1, v2, v7
    v.mul        v7, v9, v8
    v.splat      v8, s1
    v.extract    s1, v1, #0
    v.movi       v1, #64
    v.add        v10, v8, v7
    v.splat      v7, s1
    v.cmp.lt     p1, v9, v1
    v.extract    s1, v4, #0
    v.add        v1, v10, v7
    v.splat      v7, s1
    .li       s1, #1069066811
    v.splat      v8, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v10, [s7, v1]              // index is in elements (ISA sec 9.1)
    .li       s1, #1060205080
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v11, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v12, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1101004800
    v.splat      v13, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.extract    s1, v6, #0
    s.movz       s3, #1024
    v.splat      v14, s1
    vf.cvt.bf16.f32 v15, v10
    vf.add       v10, v15, v7
    vf.mul       v7, v10, v8
    vf.cmp.gt    p2, v10, v13
    v.exp2.approx v13, v7                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v10, v8, v7                // the exact rounding error of x*log2(e)
    vf.mul       v7, v15, v1
    vf.fma       v8, v13, v7, v13                // 2**t * 2**d
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v7, v8, v13
    vf.add       v8, v7, v11
    vf.sub       v13, v8, v11
    v.log2.approx v15, v8                        // ISA 8.8: <= 2**-22, absolute on [0.5, 2]
    vf.cmp.eq    p3, v8, v11
    v.rcp.approx v8, v13                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v11, v15, v1                    // ln(x) = log2(x) * ln(2)
    vf.fms       v1, v13, v8, v12
    vf.fms       v12, v8, v1, v8
    vf.neg       v1, v12                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v1, v1
    @p4 v.sel        v12, v1, v8
    vf.mul       v1, v7, v12                     // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v8, v11, v1
    @p3 v.sel        v1, v7, v8
    @p2 v.sel        v7, v10, v1
    vf.mul       v1, v14, v7
    v.movi       v7, #0
    v.extract    s1, v1, #0
    v.extract    s3, v1, #1
    v.splat      v8, s1
    v.splat      v10, s3
    v.extract    s1, v1, #2
    v.extract    s3, v1, #3
    vf.add       v11, v8, v10
    v.splat      v10, s1
    v.splat      v12, s3
    v.extract    s1, v1, #4
    v.extract    s3, v1, #5
    vf.add       v13, v11, v10
    v.splat      v10, s1
    v.splat      v14, s3
    v.extract    s1, v1, #6
    v.extract    s3, v1, #7
    vf.add       v15, v13, v12
    v.splat      v12, s1
    v.splat      v16, s3
    v.extract    s1, v1, #8
    // one value per row into one vector (ISA 0x09)
    v.extract    s3, v8, #0
    vf.add       v8, v15, v10
    v.splat      v10, s1
    v.insert     v7, s3, #0
    v.extract    s1, v11, #0
    v.extract    s3, v1, #9
    vf.add       v11, v8, v14
    v.insert     v7, s1, #1
    v.extract    s1, v13, #0
    v.splat      v13, s3
    v.insert     v7, s1, #2
    vf.add       v14, v11, v12
    v.extract    s1, v15, #0
    v.extract    s3, v1, #10
    v.insert     v7, s1, #3
    v.splat      v12, s3
    vf.add       v15, v14, v16
    v.extract    s1, v8, #0
    v.extract    s3, v1, #11
    v.insert     v7, s1, #4
    v.extract    s1, v11, #0
    vf.add       v8, v15, v10
    v.splat      v10, s3
    v.insert     v7, s1, #5
    v.extract    s1, v14, #0
    v.extract    s3, v1, #12
    vf.add       v11, v8, v13
    v.insert     v7, s1, #6
    v.extract    s1, v15, #0
    v.splat      v13, s3
    v.insert     v7, s1, #7
    vf.add       v14, v11, v12
    v.extract    s1, v8, #0
    v.extract    s3, v1, #13
    v.insert     v7, s1, #8
    v.splat      v8, s3
    vf.add       v12, v14, v10
    v.extract    s1, v11, #0
    v.extract    s3, v1, #14
    v.insert     v7, s1, #9
    v.extract    s1, v14, #0
    vf.add       v10, v12, v13
    v.splat      v11, s3
    v.insert     v7, s1, #10
    v.extract    s1, v12, #0
    v.extract    s3, v1, #15
    vf.add       v1, v10, v8
    v.insert     v7, s1, #11
    v.extract    s1, v10, #0
    v.splat      v8, s3
    v.insert     v7, s1, #12
    vf.add       v10, v1, v11
    v.extract    s1, v1, #0
    v.movi       v1, #15
    v.insert     v7, s1, #13
    v.movi       v11, #1
    vf.add       v12, v10, v8
    v.extract    s1, v10, #0
    v.movi       v8, #0
    v.insert     v7, s1, #14
    v.cmp.eq     p2, v5, v1
    v.extract    s1, v12, #0
    @p2 v.sel        v1, v11, v8
    v.insert     v7, s1, #15
    v.extract    s1, v0, #0
    s.mul        s3, s4, s5
    v.mul        v8, v7, v1
    v.splat      v1, s1
    v.splat      v10, s8
    v.reduce.add s1, v8
    vf.add       v8, v1, v7
    v.splat      v1, s1
    v.splat      v11, s2
    s.add        s1, s8, s3
    vf.add       v12, v0, v1
    v.cmp.gt     p2, v10, v11
    s.shli       s10, s1, #2                     // element offset -> bytes (x4)
    @p2 v.sel        v10, v8, v7
    v.movi       v7, #0
    @p2 v.sel        v8, v12, v1
    s.add        s1, s9, s10                     // &out_ptr0[...]
    v.splat      v1, s3
    @p1 v.st.w       [s1, #0], v10
    v.mov        v7, v8
    s.add        s1, s8, s6
    s.movz       s3, #1
    v.add        v8, v9, v1
    v.mov        v0, v7
    s.mov        s8, s1
    br.nz        s3, for_1
endfor_2:
__rctx_next:
    exit
