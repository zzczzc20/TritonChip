# Read an existing module-screen DCP, apply the normal opt_design stage, then
# audit physical ownership before any complete implementation is considered.
set root [file normalize [lindex $argv 0]]
set preserve [lindex $argv 1]
set out [file normalize [lindex $argv 2]]
if {$preserve ni {0 1} || [file exists $out]} {error "invalid variant or reused output"}
file mkdir $out
set_param general.maxThreads 4
open_checkpoint $root/case$preserve/synth.dcp
opt_design
report_utilization -hierarchical -file $out/utilization.rpt
report_utilization -file $out/total_utilization.rpt
report_timing -max_paths 30 -nworst 1 -file $out/critical_paths.rpt
set f [open $out/tag_mapping.tsv {WRONLY CREAT EXCL}]
puts $f "cell\tprimitive"
foreach cell [get_cells -hierarchical -quiet -filter {IS_PRIMITIVE && NAME =~ "*g_sync_tags*"}] {
    puts $f "[get_property NAME $cell]\t[get_property REF_NAME $cell]"
}
close $f
set f [open $root/source/flow/fpga/synth_r40_range_grid.tcl r]
set original [read $f]
close $f
set begin [string first {# A tag/age/owner} $original]
set end [string first {write_checkpoint $out/synth.dcp} $original]
if {$begin<0 || $end<=$begin} {error "source-bound metric block absent"}
eval [string range $original $begin [expr {$end-1}]]
# Audit all foreign combinational consumers of explicit cache-private data,
# not just the TMU namespace. Stop at sequential endpoints.
set f [open $out/private_cone_escapes.tsv {WRONLY CREAT EXCL}]
puts $f "cache\tcell\tprimitive"
for {set tile 0} {$tile<3} {incr tile} {
    set prefix [format {g_tile[%d].u_slice/} $tile]
    set roots [list]
    foreach cell [get_cells -hierarchical -quiet -filter {IS_PRIMITIVE && REF_NAME =~ "FD*"}] {
        set name [get_property NAME $cell]
        if {[string first $prefix $name]==0 && [regexp {(read_tag_reg|victim_owner_q_reg|age_reg|v_bits_reg)} $name]} {
            lappend roots $cell
        }
    }
    if {![llength $roots]} {error "private source registers missing for tile $tile"}
    set pins [get_pins -quiet -of_objects $roots -filter {REF_PIN_NAME == Q}]
    foreach cell [all_fanout -flat -only_cells -from $pins] {
        set name [get_property NAME $cell]
        set ref [get_property REF_NAME $cell]
        if {[regexp {^(LUT|MUXF|CARRY)} $ref] && [string first $prefix $name]!=0} {
            puts $f "$tile\t$name\t$ref"
        }
    }
    flush $f
}
close $f
write_checkpoint $out/post_opt.dcp
puts "R40_POST_OPT_CACHE_OWNERSHIP_DONE"
exit
