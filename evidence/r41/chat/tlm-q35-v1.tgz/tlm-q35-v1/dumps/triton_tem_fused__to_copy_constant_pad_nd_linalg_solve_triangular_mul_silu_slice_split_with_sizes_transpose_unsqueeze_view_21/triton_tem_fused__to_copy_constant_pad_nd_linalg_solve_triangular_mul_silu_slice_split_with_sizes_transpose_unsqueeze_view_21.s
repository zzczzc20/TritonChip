    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.rdspecial  s2, arg_base
    s.ld.d       s3, [s1, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s5, #1536
    .li       s6, #2147483647
    s.mul        s7, s1, s5
    .li       s1, #2147483647
    s.movz       s5, #256
    s.movz       s8, #4
    .li       s9, #68719476752
    .li       s10, #2207613190144
    s.rdspecial  s11, arg_base
    s.ld.d       s12, [s2, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.add        s13, s3, s7                     // this context's own scratch
    s.rdspecial  s3, role_id
    s.addi       s7, s13, #0                     // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.movz       s13, #1536
    .li       s14, #2147483647
    s.mul        s15, s3, s13
    .li       s3, #2147483647
    s.movz       s13, #512
    s.movz       s16, #4
    .li       s17, #68719476752
    s.addi       s18, s12, #12416                // the pointer's constant offset (12416 bytes)
    s.ld.d       s19, [s2, #8]                   // arg_B: device_ptr64 at arg_base+8
    .li       s20, #2207613190144
    s.movz       s21, #0
    s.movz       s21, #0
    s.ld.d       s21, [s2, #16]                  // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s22, [s2, #24]                  // out_ptr1: device_ptr64 at arg_base+24
    s.movz       s2, #0
    s.st.d       [s7, #0], s18
    s.movz       s18, #0
    s.st.d       [s7, #8], s6
    s.movz       s6, #8
    s.st.d       [s7, #16], s1
    s.movz       s1, #0
    s.cmp.lt     s23, s6, s1
    s.st.d       [s7, #48], s5
    s.cmp.lt     s1, s4, s2
    s.movz       s2, #0
    s.sub        s5, s2, s23
    s.movz       s2, #1
    s.st.d       [s7, #56], s8
    s.sub        s8, s18, s1
    s.movz       s1, #0
    s.xor        s18, s4, s8
    s.st.d       [s7, #88], s9
    s.sub        s9, s18, s8
    s.movz       s18, #0
    s.st.d       [s7, #104], s10
    s.lshri      s10, s9, #3
    fence.release.device
    td.load      d0, [s7]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.xor        s7, s8, s5
    s.movz       s8, #0
    s.ld.d       s23, [s11, #32]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.cmp.lt     s11, s4, s18
    s.add        s18, s23, s15                   // this context's own scratch
    s.xor        s15, s10, s7
    s.muli       s23, s10, #8
    s.sub        s10, s15, s7
    s.movz       s7, #0
    s.addi       s15, s18, #256                  // TensorMap 1: a 2-D tt.load (built once, at entry)
    s.sub        s18, s7, s11
    s.sub        s7, s2, s10
    s.st.d       [s15, #0], s19
    s.min.s      s11, s7, s2
    s.movz       s2, #0
    s.cmp.lt     s7, s11, s1
    s.movz       s1, #1
    s.sub        s19, s8, s7
    s.xor        s7, s4, s18
    s.sub        s8, s9, s23
    s.xor        s8, s6, s5
    s.movz       s9, #0
    s.sub        s23, s7, s18
    s.st.d       [s15, #8], s14
    s.xor        s7, s11, s19
    s.sub        s14, s8, s5
    s.sub        s5, s7, s19
    s.st.d       [s15, #16], s3
    s.addi       s3, s2, #0
    s.addi       s2, s9, #0
    s.st.d       [s15, #48], s13
    s.cmp.eq     s7, s5, s1
    s.st.d       [s15, #56], s16
    s.st.d       [s15, #88], s17
    s.st.d       [s15, #104], s20
    fence.release.device
    td.load      d1, [s15]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.mov        s3, s23
    br.nz        s7, sdiv_done_1
    s.movz       s1, #0
    s.movz       s7, #31
    s.mov        s3, s1
    s.addi       s1, s7, #0
sdiv_2:
    s.lshr       s7, s23, s1
    s.shli       s8, s2, #1
    s.andi       s9, s7, #1
    s.movz       s7, #0
    s.or         s13, s8, s9
    s.movz       s8, #1
    s.cmp.geu    s9, s13, s5
    s.shl        s14, s8, s1
    s.sub        s8, s7, s9
    s.subi       s7, s1, #1
    s.and        s9, s5, s8
    s.and        s15, s14, s8
    s.sub        s8, s13, s9
    s.or         s9, s3, s15
    s.mov        s2, s8
    s.mov        s3, s9
    s.mov        s1, s7
    s.movz       s7, #0
    s.cmp.ge     s8, s1, s7
    br.nz        s8, sdiv_2
sdiv_done_1:
    s.movz       s1, #0
    s.movz       s3, #0
    s.cmp.lt     s5, s4, s1
    s.movz       s1, #0
    s.sub        s7, s3, s5
    s.movz       s3, #0
    s.xor        s5, s4, s7
    s.movz       s4, #0
    s.sub        s8, s5, s7
    s.cmp.lt     s5, s11, s1
    s.lshri      s1, s8, #3
    s.movz       s9, #0
    s.muli       s13, s1, #8
    s.sub        s1, s4, s5
    s.movz       s4, #0
    s.cmp.lt     s5, s6, s9
    s.xor        s9, s11, s1
    s.sub        s11, s8, s13
    s.movz       s8, #0
    s.xor        s13, s11, s7
    s.xor        s11, s2, s18
    s.sub        s2, s13, s7
    s.sub        s7, s8, s5
    s.cmp.lt     s5, s2, s3
    s.sub        s3, s9, s1
    s.sub        s8, s4, s5
    s.movz       s4, #0
    s.xor        s5, s2, s8
    s.movz       s2, #1
    s.sub        s9, s11, s18
    s.xor        s11, s6, s7
    s.sub        s6, s5, s8
    s.movz       s5, #0
    s.addi       s13, s4, #0
    s.cmp.eq     s4, s3, s2
    s.add        s2, s10, s9
    s.sub        s9, s11, s7
    s.addi       s7, s5, #0
    s.mov        s13, s6
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.movz       s5, #31
    s.mov        s13, s4
    s.addi       s4, s5, #0
sdiv_4:
    s.lshr       s5, s6, s4
    s.shli       s9, s7, #1
    s.andi       s10, s5, #1
    s.movz       s5, #0
    s.or         s11, s9, s10
    s.movz       s9, #1
    s.cmp.geu    s10, s11, s3
    s.shl        s14, s9, s4
    s.sub        s9, s5, s10
    s.subi       s5, s4, #1
    s.and        s10, s3, s9
    s.and        s15, s14, s9
    s.sub        s9, s11, s10
    s.or         s10, s13, s15
    s.mov        s7, s9
    s.mov        s13, s10
    s.mov        s4, s5
    s.movz       s5, #0
    s.cmp.ge     s9, s4, s5
    br.nz        s9, sdiv_4
sdiv_done_3:
    s.xor        s3, s8, s1
    s.xor        s1, s13, s3
    s.sub        s4, s1, s3
    v.splat      v0, s2
    s.movz       s1, #0
    v.splat      v1, s1
    v.cmp.ge     p1, v0, v1
    v.splat      v0, s4
    v.splat      v1, s1
    v.cmp.ge     p1, v0, v1
    s.movz       s3, #16
    s.mul        s5, s2, s3
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s5
    v.add        v2, v1, v0
    s.mul        s2, s4, s3
    v.splat      v1, s2
    v.add        v2, v1, v0
    s.andi       s4, s5, #15
    v.splat      v0, s4
    v.iota       v1                              // arange(0, VLEN)
    v.add        v2, v0, v1
    s.andi       s6, s2, #127
    v.splat      v0, s6
    v.iota       v1                              // arange(0, VLEN)
    v.add        v2, v0, v1
    s.rdspecial  s7, pid.y
    s.rdspecial  s8, pid.z
    s.rdspecial  s9, npid.y
    s.mul        s10, s8, s9
    s.add        s8, s7, s10
    s.movz       s7, #31
    s.min.s      s9, s8, s7
    s.movz       s7, #4096
    s.mul        s10, s9, s7
    s.addi       s11, s12, #12416                // &arg_A[3104] (a constant offset, x4)
    s.movz       s11, #2048
    s.mul        s12, s9, s11
    w.def        w0, #48, #16                    // v48..v63
    mb.arm       s9, b0, #0, #1                  // 0 arrival(s), 1 operation(s)
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s13, s4                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s14, s10                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.w w0, d0, s13, s9
    mb.wait      s9
    s.movz       s4, #0
    s.add        s10, s6, s12
    w.def        w1, #32, #16                    // v32..v47
    mb.arm       s6, b1, #0, #1                  // 0 arrival(s), 1 operation(s)
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s12, s4                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s13, s10                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.w w1, d1, s12, s6
    mb.wait      s6
    v.movi       v0, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s4, #0
    v.extract    s10, v48, #0
    v.splat      v1, s10
    vf.fma       v2, v1, v32, v0
    v.extract    s10, v48, #1
    v.splat      v1, s10
    vf.fma       v3, v1, v33, v2
    v.extract    s10, v48, #2
    v.splat      v1, s10
    vf.fma       v2, v1, v34, v3
    v.extract    s10, v48, #3
    v.splat      v1, s10
    vf.fma       v3, v1, v35, v2
    v.extract    s10, v48, #4
    v.splat      v1, s10
    vf.fma       v2, v1, v36, v3
    v.extract    s10, v48, #5
    v.splat      v1, s10
    vf.fma       v3, v1, v37, v2
    v.extract    s10, v48, #6
    v.splat      v1, s10
    vf.fma       v2, v1, v38, v3
    v.extract    s10, v48, #7
    v.splat      v1, s10
    vf.fma       v3, v1, v39, v2
    v.extract    s10, v48, #8
    v.splat      v1, s10
    vf.fma       v2, v1, v40, v3
    v.extract    s10, v48, #9
    v.splat      v1, s10
    vf.fma       v3, v1, v41, v2
    v.extract    s10, v48, #10
    v.splat      v1, s10
    vf.fma       v2, v1, v42, v3
    v.extract    s10, v48, #11
    v.splat      v1, s10
    vf.fma       v3, v1, v43, v2
    v.extract    s10, v48, #12
    v.splat      v1, s10
    vf.fma       v2, v1, v44, v3
    v.extract    s10, v48, #13
    v.splat      v1, s10
    vf.fma       v3, v1, v45, v2
    v.extract    s10, v48, #14
    v.splat      v1, s10
    vf.fma       v2, v1, v46, v3
    v.extract    s10, v48, #15
    v.splat      v1, s10
    vf.fma       v3, v1, v47, v2
    a.vwrite     a0, s4, v3
    s.movz       s4, #1
    v.extract    s10, v49, #0
    v.splat      v1, s10
    vf.fma       v2, v1, v32, v0
    v.extract    s10, v49, #1
    v.splat      v1, s10
    vf.fma       v3, v1, v33, v2
    v.extract    s10, v49, #2
    v.splat      v1, s10
    vf.fma       v2, v1, v34, v3
    v.extract    s10, v49, #3
    v.splat      v1, s10
    vf.fma       v3, v1, v35, v2
    v.extract    s10, v49, #4
    v.splat      v1, s10
    vf.fma       v2, v1, v36, v3
    v.extract    s10, v49, #5
    v.splat      v1, s10
    vf.fma       v3, v1, v37, v2
    v.extract    s10, v49, #6
    v.splat      v1, s10
    vf.fma       v2, v1, v38, v3
    v.extract    s10, v49, #7
    v.splat      v1, s10
    vf.fma       v3, v1, v39, v2
    v.extract    s10, v49, #8
    v.splat      v1, s10
    vf.fma       v2, v1, v40, v3
    v.extract    s10, v49, #9
    v.splat      v1, s10
    vf.fma       v3, v1, v41, v2
    v.extract    s10, v49, #10
    v.splat      v1, s10
    vf.fma       v2, v1, v42, v3
    v.extract    s10, v49, #11
    v.splat      v1, s10
    vf.fma       v3, v1, v43, v2
    v.extract    s10, v49, #12
    v.splat      v1, s10
    vf.fma       v2, v1, v44, v3
    v.extract    s10, v49, #13
    v.splat      v1, s10
    vf.fma       v3, v1, v45, v2
    v.extract    s10, v49, #14
    v.splat      v1, s10
    vf.fma       v2, v1, v46, v3
    v.extract    s10, v49, #15
    v.splat      v1, s10
    vf.fma       v3, v1, v47, v2
    a.vwrite     a0, s4, v3
    s.movz       s4, #2
    v.extract    s10, v50, #0
    v.splat      v1, s10
    vf.fma       v2, v1, v32, v0
    v.extract    s10, v50, #1
    v.splat      v1, s10
    vf.fma       v3, v1, v33, v2
    v.extract    s10, v50, #2
    v.splat      v1, s10
    vf.fma       v2, v1, v34, v3
    v.extract    s10, v50, #3
    v.splat      v1, s10
    vf.fma       v3, v1, v35, v2
    v.extract    s10, v50, #4
    v.splat      v1, s10
    vf.fma       v2, v1, v36, v3
    v.extract    s10, v50, #5
    v.splat      v1, s10
    vf.fma       v3, v1, v37, v2
    v.extract    s10, v50, #6
    v.splat      v1, s10
    vf.fma       v2, v1, v38, v3
    v.extract    s10, v50, #7
    v.splat      v1, s10
    vf.fma       v3, v1, v39, v2
    v.extract    s10, v50, #8
    v.splat      v1, s10
    vf.fma       v2, v1, v40, v3
    v.extract    s10, v50, #9
    v.splat      v1, s10
    vf.fma       v3, v1, v41, v2
    v.extract    s10, v50, #10
    v.splat      v1, s10
    vf.fma       v2, v1, v42, v3
    v.extract    s10, v50, #11
    v.splat      v1, s10
    vf.fma       v3, v1, v43, v2
    v.extract    s10, v50, #12
    v.splat      v1, s10
    vf.fma       v2, v1, v44, v3
    v.extract    s10, v50, #13
    v.splat      v1, s10
    vf.fma       v3, v1, v45, v2
    v.extract    s10, v50, #14
    v.splat      v1, s10
    vf.fma       v2, v1, v46, v3
    v.extract    s10, v50, #15
    v.splat      v1, s10
    vf.fma       v3, v1, v47, v2
    a.vwrite     a0, s4, v3
    s.movz       s4, #3
    v.extract    s10, v51, #0
    v.splat      v1, s10
    vf.fma       v2, v1, v32, v0
    v.extract    s10, v51, #1
    v.splat      v1, s10
    vf.fma       v3, v1, v33, v2
    v.extract    s10, v51, #2
    v.splat      v1, s10
    vf.fma       v2, v1, v34, v3
    v.extract    s10, v51, #3
    v.splat      v1, s10
    vf.fma       v3, v1, v35, v2
    v.extract    s10, v51, #4
    v.splat      v1, s10
    vf.fma       v2, v1, v36, v3
    v.extract    s10, v51, #5
    v.splat      v1, s10
    vf.fma       v3, v1, v37, v2
    v.extract    s10, v51, #6
    v.splat      v1, s10
    vf.fma       v2, v1, v38, v3
    v.extract    s10, v51, #7
    v.splat      v1, s10
    vf.fma       v3, v1, v39, v2
    v.extract    s10, v51, #8
    v.splat      v1, s10
    vf.fma       v2, v1, v40, v3
    v.extract    s10, v51, #9
    v.splat      v1, s10
    vf.fma       v3, v1, v41, v2
    v.extract    s10, v51, #10
    v.splat      v1, s10
    vf.fma       v2, v1, v42, v3
    v.extract    s10, v51, #11
    v.splat      v1, s10
    vf.fma       v3, v1, v43, v2
    v.extract    s10, v51, #12
    v.splat      v1, s10
    vf.fma       v2, v1, v44, v3
    v.extract    s10, v51, #13
    v.splat      v1, s10
    vf.fma       v3, v1, v45, v2
    v.extract    s10, v51, #14
    v.splat      v1, s10
    vf.fma       v2, v1, v46, v3
    v.extract    s10, v51, #15
    v.splat      v1, s10
    vf.fma       v3, v1, v47, v2
    a.vwrite     a0, s4, v3
    s.movz       s4, #4
    v.extract    s10, v52, #0
    v.splat      v1, s10
    vf.fma       v2, v1, v32, v0
    v.extract    s10, v52, #1
    v.splat      v1, s10
    vf.fma       v3, v1, v33, v2
    v.extract    s10, v52, #2
    v.splat      v1, s10
    vf.fma       v2, v1, v34, v3
    v.extract    s10, v52, #3
    v.splat      v1, s10
    vf.fma       v3, v1, v35, v2
    v.extract    s10, v52, #4
    v.splat      v1, s10
    vf.fma       v2, v1, v36, v3
    v.extract    s10, v52, #5
    v.splat      v1, s10
    vf.fma       v3, v1, v37, v2
    v.extract    s10, v52, #6
    v.splat      v1, s10
    vf.fma       v2, v1, v38, v3
    v.extract    s10, v52, #7
    v.splat      v1, s10
    vf.fma       v3, v1, v39, v2
    v.extract    s10, v52, #8
    v.splat      v1, s10
    vf.fma       v2, v1, v40, v3
    v.extract    s10, v52, #9
    v.splat      v1, s10
    vf.fma       v3, v1, v41, v2
    v.extract    s10, v52, #10
    v.splat      v1, s10
    vf.fma       v2, v1, v42, v3
    v.extract    s10, v52, #11
    v.splat      v1, s10
    vf.fma       v3, v1, v43, v2
    v.extract    s10, v52, #12
    v.splat      v1, s10
    vf.fma       v2, v1, v44, v3
    v.extract    s10, v52, #13
    v.splat      v1, s10
    vf.fma       v3, v1, v45, v2
    v.extract    s10, v52, #14
    v.splat      v1, s10
    vf.fma       v2, v1, v46, v3
    v.extract    s10, v52, #15
    v.splat      v1, s10
    vf.fma       v3, v1, v47, v2
    a.vwrite     a0, s4, v3
    s.movz       s4, #5
    v.extract    s10, v53, #0
    v.splat      v1, s10
    vf.fma       v2, v1, v32, v0
    v.extract    s10, v53, #1
    v.splat      v1, s10
    vf.fma       v3, v1, v33, v2
    v.extract    s10, v53, #2
    v.splat      v1, s10
    vf.fma       v2, v1, v34, v3
    v.extract    s10, v53, #3
    v.splat      v1, s10
    vf.fma       v3, v1, v35, v2
    v.extract    s10, v53, #4
    v.splat      v1, s10
    vf.fma       v2, v1, v36, v3
    v.extract    s10, v53, #5
    v.splat      v1, s10
    vf.fma       v3, v1, v37, v2
    v.extract    s10, v53, #6
    v.splat      v1, s10
    vf.fma       v2, v1, v38, v3
    v.extract    s10, v53, #7
    v.splat      v1, s10
    vf.fma       v3, v1, v39, v2
    v.extract    s10, v53, #8
    v.splat      v1, s10
    vf.fma       v2, v1, v40, v3
    v.extract    s10, v53, #9
    v.splat      v1, s10
    vf.fma       v3, v1, v41, v2
    v.extract    s10, v53, #10
    v.splat      v1, s10
    vf.fma       v2, v1, v42, v3
    v.extract    s10, v53, #11
    v.splat      v1, s10
    vf.fma       v3, v1, v43, v2
    v.extract    s10, v53, #12
    v.splat      v1, s10
    vf.fma       v2, v1, v44, v3
    v.extract    s10, v53, #13
    v.splat      v1, s10
    vf.fma       v3, v1, v45, v2
    v.extract    s10, v53, #14
    v.splat      v1, s10
    vf.fma       v2, v1, v46, v3
    v.extract    s10, v53, #15
    v.splat      v1, s10
    vf.fma       v3, v1, v47, v2
    a.vwrite     a0, s4, v3
    s.movz       s4, #6
    v.extract    s10, v54, #0
    v.splat      v1, s10
    vf.fma       v2, v1, v32, v0
    v.extract    s10, v54, #1
    v.splat      v1, s10
    vf.fma       v3, v1, v33, v2
    v.extract    s10, v54, #2
    v.splat      v1, s10
    vf.fma       v2, v1, v34, v3
    v.extract    s10, v54, #3
    v.splat      v1, s10
    vf.fma       v3, v1, v35, v2
    v.extract    s10, v54, #4
    v.splat      v1, s10
    vf.fma       v2, v1, v36, v3
    v.extract    s10, v54, #5
    v.splat      v1, s10
    vf.fma       v3, v1, v37, v2
    v.extract    s10, v54, #6
    v.splat      v1, s10
    vf.fma       v2, v1, v38, v3
    v.extract    s10, v54, #7
    v.splat      v1, s10
    vf.fma       v3, v1, v39, v2
    v.extract    s10, v54, #8
    v.splat      v1, s10
    vf.fma       v2, v1, v40, v3
    v.extract    s10, v54, #9
    v.splat      v1, s10
    vf.fma       v3, v1, v41, v2
    v.extract    s10, v54, #10
    v.splat      v1, s10
    vf.fma       v2, v1, v42, v3
    v.extract    s10, v54, #11
    v.splat      v1, s10
    vf.fma       v3, v1, v43, v2
    v.extract    s10, v54, #12
    v.splat      v1, s10
    vf.fma       v2, v1, v44, v3
    v.extract    s10, v54, #13
    v.splat      v1, s10
    vf.fma       v3, v1, v45, v2
    v.extract    s10, v54, #14
    v.splat      v1, s10
    vf.fma       v2, v1, v46, v3
    v.extract    s10, v54, #15
    v.splat      v1, s10
    vf.fma       v3, v1, v47, v2
    a.vwrite     a0, s4, v3
    s.movz       s4, #7
    v.extract    s10, v55, #0
    v.splat      v1, s10
    vf.fma       v2, v1, v32, v0
    v.extract    s10, v55, #1
    v.splat      v1, s10
    vf.fma       v3, v1, v33, v2
    v.extract    s10, v55, #2
    v.splat      v1, s10
    vf.fma       v2, v1, v34, v3
    v.extract    s10, v55, #3
    v.splat      v1, s10
    vf.fma       v3, v1, v35, v2
    v.extract    s10, v55, #4
    v.splat      v1, s10
    vf.fma       v2, v1, v36, v3
    v.extract    s10, v55, #5
    v.splat      v1, s10
    vf.fma       v3, v1, v37, v2
    v.extract    s10, v55, #6
    v.splat      v1, s10
    vf.fma       v2, v1, v38, v3
    v.extract    s10, v55, #7
    v.splat      v1, s10
    vf.fma       v3, v1, v39, v2
    v.extract    s10, v55, #8
    v.splat      v1, s10
    vf.fma       v2, v1, v40, v3
    v.extract    s10, v55, #9
    v.splat      v1, s10
    vf.fma       v3, v1, v41, v2
    v.extract    s10, v55, #10
    v.splat      v1, s10
    vf.fma       v2, v1, v42, v3
    v.extract    s10, v55, #11
    v.splat      v1, s10
    vf.fma       v3, v1, v43, v2
    v.extract    s10, v55, #12
    v.splat      v1, s10
    vf.fma       v2, v1, v44, v3
    v.extract    s10, v55, #13
    v.splat      v1, s10
    vf.fma       v3, v1, v45, v2
    v.extract    s10, v55, #14
    v.splat      v1, s10
    vf.fma       v2, v1, v46, v3
    v.extract    s10, v55, #15
    v.splat      v1, s10
    vf.fma       v3, v1, v47, v2
    a.vwrite     a0, s4, v3
    s.movz       s4, #8
    v.extract    s10, v56, #0
    v.splat      v1, s10
    vf.fma       v2, v1, v32, v0
    v.extract    s10, v56, #1
    v.splat      v1, s10
    vf.fma       v3, v1, v33, v2
    v.extract    s10, v56, #2
    v.splat      v1, s10
    vf.fma       v2, v1, v34, v3
    v.extract    s10, v56, #3
    v.splat      v1, s10
    vf.fma       v3, v1, v35, v2
    v.extract    s10, v56, #4
    v.splat      v1, s10
    vf.fma       v2, v1, v36, v3
    v.extract    s10, v56, #5
    v.splat      v1, s10
    vf.fma       v3, v1, v37, v2
    v.extract    s10, v56, #6
    v.splat      v1, s10
    vf.fma       v2, v1, v38, v3
    v.extract    s10, v56, #7
    v.splat      v1, s10
    vf.fma       v3, v1, v39, v2
    v.extract    s10, v56, #8
    v.splat      v1, s10
    vf.fma       v2, v1, v40, v3
    v.extract    s10, v56, #9
    v.splat      v1, s10
    vf.fma       v3, v1, v41, v2
    v.extract    s10, v56, #10
    v.splat      v1, s10
    vf.fma       v2, v1, v42, v3
    v.extract    s10, v56, #11
    v.splat      v1, s10
    vf.fma       v3, v1, v43, v2
    v.extract    s10, v56, #12
    v.splat      v1, s10
    vf.fma       v2, v1, v44, v3
    v.extract    s10, v56, #13
    v.splat      v1, s10
    vf.fma       v3, v1, v45, v2
    v.extract    s10, v56, #14
    v.splat      v1, s10
    vf.fma       v2, v1, v46, v3
    v.extract    s10, v56, #15
    v.splat      v1, s10
    vf.fma       v3, v1, v47, v2
    a.vwrite     a0, s4, v3
    s.movz       s4, #9
    v.extract    s10, v57, #0
    v.splat      v1, s10
    vf.fma       v2, v1, v32, v0
    v.extract    s10, v57, #1
    v.splat      v1, s10
    vf.fma       v3, v1, v33, v2
    v.extract    s10, v57, #2
    v.splat      v1, s10
    vf.fma       v2, v1, v34, v3
    v.extract    s10, v57, #3
    v.splat      v1, s10
    vf.fma       v3, v1, v35, v2
    v.extract    s10, v57, #4
    v.splat      v1, s10
    vf.fma       v2, v1, v36, v3
    v.extract    s10, v57, #5
    v.splat      v1, s10
    vf.fma       v3, v1, v37, v2
    v.extract    s10, v57, #6
    v.splat      v1, s10
    vf.fma       v2, v1, v38, v3
    v.extract    s10, v57, #7
    v.splat      v1, s10
    vf.fma       v3, v1, v39, v2
    v.extract    s10, v57, #8
    v.splat      v1, s10
    vf.fma       v2, v1, v40, v3
    v.extract    s10, v57, #9
    v.splat      v1, s10
    vf.fma       v3, v1, v41, v2
    v.extract    s10, v57, #10
    v.splat      v1, s10
    vf.fma       v2, v1, v42, v3
    v.extract    s10, v57, #11
    v.splat      v1, s10
    vf.fma       v3, v1, v43, v2
    v.extract    s10, v57, #12
    v.splat      v1, s10
    vf.fma       v2, v1, v44, v3
    v.extract    s10, v57, #13
    v.splat      v1, s10
    vf.fma       v3, v1, v45, v2
    v.extract    s10, v57, #14
    v.splat      v1, s10
    vf.fma       v2, v1, v46, v3
    v.extract    s10, v57, #15
    v.splat      v1, s10
    vf.fma       v3, v1, v47, v2
    a.vwrite     a0, s4, v3
    s.movz       s4, #10
    v.extract    s10, v58, #0
    v.splat      v1, s10
    vf.fma       v2, v1, v32, v0
    v.extract    s10, v58, #1
    v.splat      v1, s10
    vf.fma       v3, v1, v33, v2
    v.extract    s10, v58, #2
    v.splat      v1, s10
    vf.fma       v2, v1, v34, v3
    v.extract    s10, v58, #3
    v.splat      v1, s10
    vf.fma       v3, v1, v35, v2
    v.extract    s10, v58, #4
    v.splat      v1, s10
    vf.fma       v2, v1, v36, v3
    v.extract    s10, v58, #5
    v.splat      v1, s10
    vf.fma       v3, v1, v37, v2
    v.extract    s10, v58, #6
    v.splat      v1, s10
    vf.fma       v2, v1, v38, v3
    v.extract    s10, v58, #7
    v.splat      v1, s10
    vf.fma       v3, v1, v39, v2
    v.extract    s10, v58, #8
    v.splat      v1, s10
    vf.fma       v2, v1, v40, v3
    v.extract    s10, v58, #9
    v.splat      v1, s10
    vf.fma       v3, v1, v41, v2
    v.extract    s10, v58, #10
    v.splat      v1, s10
    vf.fma       v2, v1, v42, v3
    v.extract    s10, v58, #11
    v.splat      v1, s10
    vf.fma       v3, v1, v43, v2
    v.extract    s10, v58, #12
    v.splat      v1, s10
    vf.fma       v2, v1, v44, v3
    v.extract    s10, v58, #13
    v.splat      v1, s10
    vf.fma       v3, v1, v45, v2
    v.extract    s10, v58, #14
    v.splat      v1, s10
    vf.fma       v2, v1, v46, v3
    v.extract    s10, v58, #15
    v.splat      v1, s10
    vf.fma       v3, v1, v47, v2
    a.vwrite     a0, s4, v3
    s.movz       s4, #11
    v.extract    s10, v59, #0
    v.splat      v1, s10
    vf.fma       v2, v1, v32, v0
    v.extract    s10, v59, #1
    v.splat      v1, s10
    vf.fma       v3, v1, v33, v2
    v.extract    s10, v59, #2
    v.splat      v1, s10
    vf.fma       v2, v1, v34, v3
    v.extract    s10, v59, #3
    v.splat      v1, s10
    vf.fma       v3, v1, v35, v2
    v.extract    s10, v59, #4
    v.splat      v1, s10
    vf.fma       v2, v1, v36, v3
    v.extract    s10, v59, #5
    v.splat      v1, s10
    vf.fma       v3, v1, v37, v2
    v.extract    s10, v59, #6
    v.splat      v1, s10
    vf.fma       v2, v1, v38, v3
    v.extract    s10, v59, #7
    v.splat      v1, s10
    vf.fma       v3, v1, v39, v2
    v.extract    s10, v59, #8
    v.splat      v1, s10
    vf.fma       v2, v1, v40, v3
    v.extract    s10, v59, #9
    v.splat      v1, s10
    vf.fma       v3, v1, v41, v2
    v.extract    s10, v59, #10
    v.splat      v1, s10
    vf.fma       v2, v1, v42, v3
    v.extract    s10, v59, #11
    v.splat      v1, s10
    vf.fma       v3, v1, v43, v2
    v.extract    s10, v59, #12
    v.splat      v1, s10
    vf.fma       v2, v1, v44, v3
    v.extract    s10, v59, #13
    v.splat      v1, s10
    vf.fma       v3, v1, v45, v2
    v.extract    s10, v59, #14
    v.splat      v1, s10
    vf.fma       v2, v1, v46, v3
    v.extract    s10, v59, #15
    v.splat      v1, s10
    vf.fma       v3, v1, v47, v2
    a.vwrite     a0, s4, v3
    s.movz       s4, #12
    v.extract    s10, v60, #0
    v.splat      v1, s10
    vf.fma       v2, v1, v32, v0
    v.extract    s10, v60, #1
    v.splat      v1, s10
    vf.fma       v3, v1, v33, v2
    v.extract    s10, v60, #2
    v.splat      v1, s10
    vf.fma       v2, v1, v34, v3
    v.extract    s10, v60, #3
    v.splat      v1, s10
    vf.fma       v3, v1, v35, v2
    v.extract    s10, v60, #4
    v.splat      v1, s10
    vf.fma       v2, v1, v36, v3
    v.extract    s10, v60, #5
    v.splat      v1, s10
    vf.fma       v3, v1, v37, v2
    v.extract    s10, v60, #6
    v.splat      v1, s10
    vf.fma       v2, v1, v38, v3
    v.extract    s10, v60, #7
    v.splat      v1, s10
    vf.fma       v3, v1, v39, v2
    v.extract    s10, v60, #8
    v.splat      v1, s10
    vf.fma       v2, v1, v40, v3
    v.extract    s10, v60, #9
    v.splat      v1, s10
    vf.fma       v3, v1, v41, v2
    v.extract    s10, v60, #10
    v.splat      v1, s10
    vf.fma       v2, v1, v42, v3
    v.extract    s10, v60, #11
    v.splat      v1, s10
    vf.fma       v3, v1, v43, v2
    v.extract    s10, v60, #12
    v.splat      v1, s10
    vf.fma       v2, v1, v44, v3
    v.extract    s10, v60, #13
    v.splat      v1, s10
    vf.fma       v3, v1, v45, v2
    v.extract    s10, v60, #14
    v.splat      v1, s10
    vf.fma       v2, v1, v46, v3
    v.extract    s10, v60, #15
    v.splat      v1, s10
    vf.fma       v3, v1, v47, v2
    a.vwrite     a0, s4, v3
    s.movz       s4, #13
    v.extract    s10, v61, #0
    v.splat      v1, s10
    vf.fma       v2, v1, v32, v0
    v.extract    s10, v61, #1
    v.splat      v1, s10
    vf.fma       v3, v1, v33, v2
    v.extract    s10, v61, #2
    v.splat      v1, s10
    vf.fma       v2, v1, v34, v3
    v.extract    s10, v61, #3
    v.splat      v1, s10
    vf.fma       v3, v1, v35, v2
    v.extract    s10, v61, #4
    v.splat      v1, s10
    vf.fma       v2, v1, v36, v3
    v.extract    s10, v61, #5
    v.splat      v1, s10
    vf.fma       v3, v1, v37, v2
    v.extract    s10, v61, #6
    v.splat      v1, s10
    vf.fma       v2, v1, v38, v3
    v.extract    s10, v61, #7
    v.splat      v1, s10
    vf.fma       v3, v1, v39, v2
    v.extract    s10, v61, #8
    v.splat      v1, s10
    vf.fma       v2, v1, v40, v3
    v.extract    s10, v61, #9
    v.splat      v1, s10
    vf.fma       v3, v1, v41, v2
    v.extract    s10, v61, #10
    v.splat      v1, s10
    vf.fma       v2, v1, v42, v3
    v.extract    s10, v61, #11
    v.splat      v1, s10
    vf.fma       v3, v1, v43, v2
    v.extract    s10, v61, #12
    v.splat      v1, s10
    vf.fma       v2, v1, v44, v3
    v.extract    s10, v61, #13
    v.splat      v1, s10
    vf.fma       v3, v1, v45, v2
    v.extract    s10, v61, #14
    v.splat      v1, s10
    vf.fma       v2, v1, v46, v3
    v.extract    s10, v61, #15
    v.splat      v1, s10
    vf.fma       v3, v1, v47, v2
    a.vwrite     a0, s4, v3
    s.movz       s4, #14
    v.extract    s10, v62, #0
    v.splat      v1, s10
    vf.fma       v2, v1, v32, v0
    v.extract    s10, v62, #1
    v.splat      v1, s10
    vf.fma       v3, v1, v33, v2
    v.extract    s10, v62, #2
    v.splat      v1, s10
    vf.fma       v2, v1, v34, v3
    v.extract    s10, v62, #3
    v.splat      v1, s10
    vf.fma       v3, v1, v35, v2
    v.extract    s10, v62, #4
    v.splat      v1, s10
    vf.fma       v2, v1, v36, v3
    v.extract    s10, v62, #5
    v.splat      v1, s10
    vf.fma       v3, v1, v37, v2
    v.extract    s10, v62, #6
    v.splat      v1, s10
    vf.fma       v2, v1, v38, v3
    v.extract    s10, v62, #7
    v.splat      v1, s10
    vf.fma       v3, v1, v39, v2
    v.extract    s10, v62, #8
    v.splat      v1, s10
    vf.fma       v2, v1, v40, v3
    v.extract    s10, v62, #9
    v.splat      v1, s10
    vf.fma       v3, v1, v41, v2
    v.extract    s10, v62, #10
    v.splat      v1, s10
    vf.fma       v2, v1, v42, v3
    v.extract    s10, v62, #11
    v.splat      v1, s10
    vf.fma       v3, v1, v43, v2
    v.extract    s10, v62, #12
    v.splat      v1, s10
    vf.fma       v2, v1, v44, v3
    v.extract    s10, v62, #13
    v.splat      v1, s10
    vf.fma       v3, v1, v45, v2
    v.extract    s10, v62, #14
    v.splat      v1, s10
    vf.fma       v2, v1, v46, v3
    v.extract    s10, v62, #15
    v.splat      v1, s10
    vf.fma       v3, v1, v47, v2
    a.vwrite     a0, s4, v3
    s.movz       s4, #15
    v.extract    s10, v63, #0
    v.splat      v1, s10
    vf.fma       v2, v1, v32, v0
    v.extract    s10, v63, #1
    v.splat      v0, s10
    vf.fma       v1, v0, v33, v2
    v.extract    s10, v63, #2
    v.splat      v0, s10
    vf.fma       v2, v0, v34, v1
    v.extract    s10, v63, #3
    v.splat      v0, s10
    vf.fma       v1, v0, v35, v2
    v.extract    s10, v63, #4
    v.splat      v0, s10
    vf.fma       v2, v0, v36, v1
    v.extract    s10, v63, #5
    v.splat      v0, s10
    vf.fma       v1, v0, v37, v2
    v.extract    s10, v63, #6
    v.splat      v0, s10
    vf.fma       v2, v0, v38, v1
    v.extract    s10, v63, #7
    v.splat      v0, s10
    vf.fma       v1, v0, v39, v2
    v.extract    s10, v63, #8
    v.splat      v0, s10
    vf.fma       v2, v0, v40, v1
    v.extract    s10, v63, #9
    v.splat      v0, s10
    vf.fma       v1, v0, v41, v2
    v.extract    s10, v63, #10
    v.splat      v0, s10
    vf.fma       v2, v0, v42, v1
    v.extract    s10, v63, #11
    v.splat      v0, s10
    vf.fma       v1, v0, v43, v2
    v.extract    s10, v63, #12
    v.splat      v0, s10
    vf.fma       v2, v0, v44, v1
    v.extract    s10, v63, #13
    v.splat      v0, s10
    vf.fma       v1, v0, v45, v2
    v.extract    s10, v63, #14
    v.splat      v0, s10
    vf.fma       v2, v0, v46, v1
    v.extract    s10, v63, #15
    v.splat      v0, s10
    vf.fma       v1, v0, v47, v2
    a.vwrite     a0, s4, v1
    v.movi       v0, #0
    v.splat      v1, s8
    s.movz       s4, #32
    v.splat      v2, s4
    v.cmp.lt     p1, v1, v2
    s.mul        s4, s8, s11
    s.mul        s10, s8, s7
    s.rdspecial  s7, arg_base
    s.ld.d       s8, [s7, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s7, role_id
    s.movz       s12, #1536
    s.mul        s13, s7, s12
    s.add        s7, s8, s13                     // this context's own scratch
    s.addi       s8, s7, #512
    v.splat      v1, s1
    s.movz       s1, #0
    s.add        s12, s1, s2                     // the tile origin
    s.muli       s1, s5, #128                    // a runtime tile origin, x128
    s.add        s13, s12, s1                    // the tile origin
    s.add        s1, s13, s4                     // the tile origin
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s1
    v.add        v4, v2, v3
    v.splat      v3, s11
    v.movi       v5, #0
    v.movi       v6, #1
    v.cmp.lt     p2, v4, v5
    v.cmp.lt     p3, v3, v5
    v.sub        v6, v5, v4
    @p2 v.sel        v7, v6, v4
    v.sub        v4, v5, v3
    @p3 v.sel        v6, v4, v3
    v.movi       v4, #2047
    v.and        v6, v7, v4
    v.sub        v4, v5, v6
    @p2 v.sel        v5, v4, v6
    v.add        v4, v5, v3
    s.movz       s11, #0
    s.add        s12, s11, s10                   // the tile origin
    v.splat      v5, s12
    v.add        v6, v4, v5
    v.add        v4, v1, v6
    v.st.w       [s8, #0], v4
    s.addi       s10, s8, #64
    s.addi       s11, s1, #128
    v.splat      v4, s11
    v.add        v6, v2, v4
    v.movi       v4, #0
    v.movi       v7, #1
    v.cmp.lt     p2, v6, v4
    v.cmp.lt     p3, v3, v4
    v.sub        v7, v4, v6
    @p2 v.sel        v8, v7, v6
    v.sub        v6, v4, v3
    @p3 v.sel        v7, v6, v3
    v.movi       v6, #2047
    v.and        v7, v8, v6
    v.sub        v6, v4, v7
    @p2 v.sel        v4, v6, v7
    v.add        v6, v4, v3
    v.add        v4, v6, v5
    v.add        v6, v1, v4
    v.st.w       [s10, #0], v6
    s.addi       s10, s8, #128
    s.addi       s11, s1, #256
    v.splat      v4, s11
    v.add        v6, v2, v4
    v.movi       v4, #0
    v.movi       v7, #1
    v.cmp.lt     p2, v6, v4
    v.cmp.lt     p3, v3, v4
    v.sub        v7, v4, v6
    @p2 v.sel        v8, v7, v6
    v.sub        v6, v4, v3
    @p3 v.sel        v7, v6, v3
    v.movi       v6, #2047
    v.and        v7, v8, v6
    v.sub        v6, v4, v7
    @p2 v.sel        v4, v6, v7
    v.add        v6, v4, v3
    v.add        v4, v6, v5
    v.add        v6, v1, v4
    v.st.w       [s10, #0], v6
    s.addi       s10, s8, #192
    s.addi       s11, s1, #384
    v.splat      v4, s11
    v.add        v6, v2, v4
    v.movi       v4, #0
    v.movi       v7, #1
    v.cmp.lt     p2, v6, v4
    v.cmp.lt     p3, v3, v4
    v.sub        v7, v4, v6
    @p2 v.sel        v8, v7, v6
    v.sub        v6, v4, v3
    @p3 v.sel        v7, v6, v3
    v.movi       v6, #2047
    v.and        v7, v8, v6
    v.sub        v6, v4, v7
    @p2 v.sel        v4, v6, v7
    v.add        v6, v4, v3
    v.add        v4, v6, v5
    v.add        v6, v1, v4
    v.st.w       [s10, #0], v6
    s.addi       s10, s8, #256
    s.addi       s11, s1, #512
    v.splat      v4, s11
    v.add        v6, v2, v4
    v.movi       v4, #0
    v.movi       v7, #1
    v.cmp.lt     p2, v6, v4
    v.cmp.lt     p3, v3, v4
    v.sub        v7, v4, v6
    @p2 v.sel        v8, v7, v6
    v.sub        v6, v4, v3
    @p3 v.sel        v7, v6, v3
    v.movi       v6, #2047
    v.and        v7, v8, v6
    v.sub        v6, v4, v7
    @p2 v.sel        v4, v6, v7
    v.add        v6, v4, v3
    v.add        v4, v6, v5
    v.add        v6, v1, v4
    v.st.w       [s10, #0], v6
    s.addi       s10, s8, #320
    s.addi       s11, s1, #640
    v.splat      v4, s11
    v.add        v6, v2, v4
    v.movi       v4, #0
    v.movi       v7, #1
    v.cmp.lt     p2, v6, v4
    v.cmp.lt     p3, v3, v4
    v.sub        v7, v4, v6
    @p2 v.sel        v8, v7, v6
    v.sub        v6, v4, v3
    @p3 v.sel        v7, v6, v3
    v.movi       v6, #2047
    v.and        v7, v8, v6
    v.sub        v6, v4, v7
    @p2 v.sel        v4, v6, v7
    v.add        v6, v4, v3
    v.add        v4, v6, v5
    v.add        v6, v1, v4
    v.st.w       [s10, #0], v6
    s.addi       s10, s8, #384
    s.addi       s11, s1, #768
    v.splat      v4, s11
    v.add        v6, v2, v4
    v.movi       v4, #0
    v.movi       v7, #1
    v.cmp.lt     p2, v6, v4
    v.cmp.lt     p3, v3, v4
    v.sub        v7, v4, v6
    @p2 v.sel        v8, v7, v6
    v.sub        v6, v4, v3
    @p3 v.sel        v7, v6, v3
    v.movi       v6, #2047
    v.and        v7, v8, v6
    v.sub        v6, v4, v7
    @p2 v.sel        v4, v6, v7
    v.add        v6, v4, v3
    v.add        v4, v6, v5
    v.add        v6, v1, v4
    v.st.w       [s10, #0], v6
    s.addi       s10, s8, #448
    s.addi       s11, s1, #896
    v.splat      v4, s11
    v.add        v6, v2, v4
    v.movi       v4, #0
    v.movi       v7, #1
    v.cmp.lt     p2, v6, v4
    v.cmp.lt     p3, v3, v4
    v.sub        v7, v4, v6
    @p2 v.sel        v8, v7, v6
    v.sub        v6, v4, v3
    @p3 v.sel        v7, v6, v3
    v.movi       v6, #2047
    v.and        v7, v8, v6
    v.sub        v6, v4, v7
    @p2 v.sel        v4, v6, v7
    v.add        v6, v4, v3
    v.add        v4, v6, v5
    v.add        v6, v1, v4
    v.st.w       [s10, #0], v6
    s.addi       s10, s8, #512
    s.addi       s11, s1, #1024
    v.splat      v4, s11
    v.add        v6, v2, v4
    v.movi       v4, #0
    v.movi       v7, #1
    v.cmp.lt     p2, v6, v4
    v.cmp.lt     p3, v3, v4
    v.sub        v7, v4, v6
    @p2 v.sel        v8, v7, v6
    v.sub        v6, v4, v3
    @p3 v.sel        v7, v6, v3
    v.movi       v6, #2047
    v.and        v7, v8, v6
    v.sub        v6, v4, v7
    @p2 v.sel        v4, v6, v7
    v.add        v6, v4, v3
    v.add        v4, v6, v5
    v.add        v6, v1, v4
    v.st.w       [s10, #0], v6
    s.addi       s10, s8, #576
    s.addi       s11, s1, #1152
    v.splat      v4, s11
    v.add        v6, v2, v4
    v.movi       v4, #0
    v.movi       v7, #1
    v.cmp.lt     p2, v6, v4
    v.cmp.lt     p3, v3, v4
    v.sub        v7, v4, v6
    @p2 v.sel        v8, v7, v6
    v.sub        v6, v4, v3
    @p3 v.sel        v7, v6, v3
    v.movi       v6, #2047
    v.and        v7, v8, v6
    v.sub        v6, v4, v7
    @p2 v.sel        v4, v6, v7
    v.add        v6, v4, v3
    v.add        v4, v6, v5
    v.add        v6, v1, v4
    v.st.w       [s10, #0], v6
    s.addi       s10, s8, #640
    s.addi       s11, s1, #1280
    v.splat      v4, s11
    v.add        v6, v2, v4
    v.movi       v4, #0
    v.movi       v7, #1
    v.cmp.lt     p2, v6, v4
    v.cmp.lt     p3, v3, v4
    v.sub        v7, v4, v6
    @p2 v.sel        v8, v7, v6
    v.sub        v6, v4, v3
    @p3 v.sel        v7, v6, v3
    v.movi       v6, #2047
    v.and        v7, v8, v6
    v.sub        v6, v4, v7
    @p2 v.sel        v4, v6, v7
    v.add        v6, v4, v3
    v.add        v4, v6, v5
    v.add        v6, v1, v4
    v.st.w       [s10, #0], v6
    s.addi       s10, s8, #704
    s.addi       s11, s1, #1408
    v.splat      v4, s11
    v.add        v6, v2, v4
    v.movi       v4, #0
    v.movi       v7, #1
    v.cmp.lt     p2, v6, v4
    v.cmp.lt     p3, v3, v4
    v.sub        v7, v4, v6
    @p2 v.sel        v8, v7, v6
    v.sub        v6, v4, v3
    @p3 v.sel        v7, v6, v3
    v.movi       v6, #2047
    v.and        v7, v8, v6
    v.sub        v6, v4, v7
    @p2 v.sel        v4, v6, v7
    v.add        v6, v4, v3
    v.add        v4, v6, v5
    v.add        v6, v1, v4
    v.st.w       [s10, #0], v6
    s.addi       s10, s8, #768
    s.addi       s11, s1, #1536
    v.splat      v4, s11
    v.add        v6, v2, v4
    v.movi       v4, #0
    v.movi       v7, #1
    v.cmp.lt     p2, v6, v4
    v.cmp.lt     p3, v3, v4
    v.sub        v7, v4, v6
    @p2 v.sel        v8, v7, v6
    v.sub        v6, v4, v3
    @p3 v.sel        v7, v6, v3
    v.movi       v6, #2047
    v.and        v7, v8, v6
    v.sub        v6, v4, v7
    @p2 v.sel        v4, v6, v7
    v.add        v6, v4, v3
    v.add        v4, v6, v5
    v.add        v6, v1, v4
    v.st.w       [s10, #0], v6
    s.addi       s10, s8, #832
    s.addi       s11, s1, #1664
    v.splat      v4, s11
    v.add        v6, v2, v4
    v.movi       v4, #0
    v.movi       v7, #1
    v.cmp.lt     p2, v6, v4
    v.cmp.lt     p3, v3, v4
    v.sub        v7, v4, v6
    @p2 v.sel        v8, v7, v6
    v.sub        v6, v4, v3
    @p3 v.sel        v7, v6, v3
    v.movi       v6, #2047
    v.and        v7, v8, v6
    v.sub        v6, v4, v7
    @p2 v.sel        v4, v6, v7
    v.add        v6, v4, v3
    v.add        v4, v6, v5
    v.add        v6, v1, v4
    v.st.w       [s10, #0], v6
    s.addi       s10, s8, #896
    s.addi       s11, s1, #1792
    v.splat      v4, s11
    v.add        v6, v2, v4
    v.movi       v4, #0
    v.movi       v7, #1
    v.cmp.lt     p2, v6, v4
    v.cmp.lt     p3, v3, v4
    v.sub        v7, v4, v6
    @p2 v.sel        v8, v7, v6
    v.sub        v6, v4, v3
    @p3 v.sel        v7, v6, v3
    v.movi       v6, #2047
    v.and        v7, v8, v6
    v.sub        v6, v4, v7
    @p2 v.sel        v4, v6, v7
    v.add        v6, v4, v3
    v.add        v4, v6, v5
    v.add        v6, v1, v4
    v.st.w       [s10, #0], v6
    s.addi       s10, s8, #960
    s.addi       s8, s1, #1920
    v.splat      v4, s8
    v.add        v6, v2, v4
    v.movi       v4, #0
    v.movi       v7, #1
    v.cmp.lt     p2, v6, v4
    v.cmp.lt     p3, v3, v4
    v.sub        v7, v4, v6
    @p2 v.sel        v8, v7, v6
    v.sub        v6, v4, v3
    @p3 v.sel        v7, v6, v3
    v.movi       v6, #2047
    v.and        v7, v8, v6
    v.sub        v6, v4, v7
    @p2 v.sel        v4, v6, v7
    v.add        v6, v4, v3
    v.add        v3, v6, v5
    v.add        v4, v1, v3
    v.st.w       [s10, #0], v4
    fence.acq_rel.device
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s1, #0
    s.addi       s8, s7, #512
    v.ld.w       v1, [s8, #0]
    s.movz       s8, #0
    s.add        s10, s8, s5                     // the tile origin
    v.splat      v3, s10
    v.splat      v4, s3
    v.cmp.lt     p2, v3, v4
    s.movz       s3, #0
    s.add        s8, s3, s2                      // the tile origin
    v.splat      v3, s8
    v.add        v5, v2, v3
    s.movz       s3, #128
    v.splat      v2, s3
    v.cmp.lt     p3, v5, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s21, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v2
    s.movz       s1, #1
    s.addi       s3, s7, #576
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #1
    v.splat      v2, s3
    v.cmp.lt     p2, v2, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s21, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v2
    s.movz       s1, #2
    s.addi       s3, s7, #640
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #2
    v.splat      v2, s3
    v.cmp.lt     p2, v2, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s21, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v2
    s.movz       s1, #3
    s.addi       s3, s7, #704
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #3
    v.splat      v2, s3
    v.cmp.lt     p2, v2, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s21, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v2
    s.movz       s1, #4
    s.addi       s3, s7, #768
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #4
    v.splat      v2, s3
    v.cmp.lt     p2, v2, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s21, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v2
    s.movz       s1, #5
    s.addi       s3, s7, #832
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #5
    v.splat      v2, s3
    v.cmp.lt     p2, v2, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s21, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v2
    s.movz       s1, #6
    s.addi       s3, s7, #896
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #6
    v.splat      v2, s3
    v.cmp.lt     p2, v2, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s21, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v2
    s.movz       s1, #7
    s.addi       s3, s7, #960
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #7
    v.splat      v2, s3
    v.cmp.lt     p2, v2, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s21, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v2
    s.movz       s1, #8
    s.addi       s3, s7, #1024
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #8
    v.splat      v2, s3
    v.cmp.lt     p2, v2, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s21, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v2
    s.movz       s1, #9
    s.addi       s3, s7, #1088
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #9
    v.splat      v2, s3
    v.cmp.lt     p2, v2, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s21, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v2
    s.movz       s1, #10
    s.addi       s3, s7, #1152
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #10
    v.splat      v2, s3
    v.cmp.lt     p2, v2, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s21, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v2
    s.movz       s1, #11
    s.addi       s3, s7, #1216
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #11
    v.splat      v2, s3
    v.cmp.lt     p2, v2, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s21, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v2
    s.movz       s1, #12
    s.addi       s3, s7, #1280
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #12
    v.splat      v2, s3
    v.cmp.lt     p2, v2, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s21, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v2
    s.movz       s1, #13
    s.addi       s3, s7, #1344
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #13
    v.splat      v2, s3
    v.cmp.lt     p2, v2, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s21, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v2
    s.movz       s1, #14
    s.addi       s3, s7, #1408
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #14
    v.splat      v2, s3
    v.cmp.lt     p2, v2, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s21, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v2
    s.movz       s1, #15
    s.addi       s3, s7, #1472
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #15
    v.splat      v2, s3
    v.cmp.lt     p2, v2, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s21, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v2
    s.muli       s1, s2, #4                      // a runtime tile origin, x4
    s.add        s2, s22, s1                     // the tile origin
    s.muli       s1, s5, #512                    // a runtime tile origin, x512
    s.add        s3, s2, s1                      // the tile origin
    s.muli       s1, s4, #4                      // a runtime tile origin, x4
    s.add        s2, s3, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    a.vread      v1, a1, s1
    s.movz       s1, #0
    a.vread      v2, a0, s1
    vf.add       v3, v2, v0
    vf.sub       v2, v1, v3
    v.splat      v1, s10
    v.cmp.lt     p2, v1, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s2, #0], v2
    s.movz       s1, #1
    a.vread      v1, a1, s1
    s.movz       s1, #1
    a.vread      v2, a0, s1
    vf.add       v3, v2, v0
    vf.sub       v2, v1, v3
    s.addi       s1, s2, #512                    // row 1
    s.addi       s3, s10, #1
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v2
    s.movz       s1, #2
    a.vread      v1, a1, s1
    s.movz       s1, #2
    a.vread      v2, a0, s1
    vf.add       v3, v2, v0
    vf.sub       v2, v1, v3
    s.addi       s1, s2, #1024                   // row 2
    s.addi       s3, s10, #2
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v2
    s.movz       s1, #3
    a.vread      v1, a1, s1
    s.movz       s1, #3
    a.vread      v2, a0, s1
    vf.add       v3, v2, v0
    vf.sub       v2, v1, v3
    s.addi       s1, s2, #1536                   // row 3
    s.addi       s3, s10, #3
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v2
    s.movz       s1, #4
    a.vread      v1, a1, s1
    s.movz       s1, #4
    a.vread      v2, a0, s1
    vf.add       v3, v2, v0
    vf.sub       v2, v1, v3
    s.addi       s1, s2, #2048                   // row 4
    s.addi       s3, s10, #4
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v2
    s.movz       s1, #5
    a.vread      v1, a1, s1
    s.movz       s1, #5
    a.vread      v2, a0, s1
    vf.add       v3, v2, v0
    vf.sub       v2, v1, v3
    s.addi       s1, s2, #2560                   // row 5
    s.addi       s3, s10, #5
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v2
    s.movz       s1, #6
    a.vread      v1, a1, s1
    s.movz       s1, #6
    a.vread      v2, a0, s1
    vf.add       v3, v2, v0
    vf.sub       v2, v1, v3
    s.addi       s1, s2, #3072                   // row 6
    s.addi       s3, s10, #6
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v2
    s.movz       s1, #7
    a.vread      v1, a1, s1
    s.movz       s1, #7
    a.vread      v2, a0, s1
    vf.add       v3, v2, v0
    vf.sub       v2, v1, v3
    s.addi       s1, s2, #3584                   // row 7
    s.addi       s3, s10, #7
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v2
    s.movz       s1, #8
    a.vread      v1, a1, s1
    s.movz       s1, #8
    a.vread      v2, a0, s1
    vf.add       v3, v2, v0
    vf.sub       v2, v1, v3
    s.addi       s1, s2, #4096                   // row 8
    s.addi       s3, s10, #8
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v2
    s.movz       s1, #9
    a.vread      v1, a1, s1
    s.movz       s1, #9
    a.vread      v2, a0, s1
    vf.add       v3, v2, v0
    vf.sub       v2, v1, v3
    s.addi       s1, s2, #4608                   // row 9
    s.addi       s3, s10, #9
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v2
    s.movz       s1, #10
    a.vread      v1, a1, s1
    s.movz       s1, #10
    a.vread      v2, a0, s1
    vf.add       v3, v2, v0
    vf.sub       v2, v1, v3
    s.addi       s1, s2, #5120                   // row 10
    s.addi       s3, s10, #10
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v2
    s.movz       s1, #11
    a.vread      v1, a1, s1
    s.movz       s1, #11
    a.vread      v2, a0, s1
    vf.add       v3, v2, v0
    vf.sub       v2, v1, v3
    s.addi       s1, s2, #5632                   // row 11
    s.addi       s3, s10, #11
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v2
    s.movz       s1, #12
    a.vread      v1, a1, s1
    s.movz       s1, #12
    a.vread      v2, a0, s1
    vf.add       v3, v2, v0
    vf.sub       v2, v1, v3
    s.addi       s1, s2, #6144                   // row 12
    s.addi       s3, s10, #12
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v2
    s.movz       s1, #13
    a.vread      v1, a1, s1
    s.movz       s1, #13
    a.vread      v2, a0, s1
    vf.add       v3, v2, v0
    vf.sub       v2, v1, v3
    s.addi       s1, s2, #6656                   // row 13
    s.addi       s3, s10, #13
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v2
    s.movz       s1, #14
    a.vread      v1, a1, s1
    s.movz       s1, #14
    a.vread      v2, a0, s1
    vf.add       v3, v2, v0
    vf.sub       v2, v1, v3
    s.addi       s1, s2, #7168                   // row 14
    s.addi       s3, s10, #14
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v2
    s.movz       s1, #15
    a.vread      v1, a1, s1
    s.movz       s1, #15
    a.vread      v2, a0, s1
    vf.add       v3, v2, v0
    vf.sub       v0, v1, v3
    s.addi       s1, s2, #7680                   // row 15
    s.addi       s2, s10, #15
    v.splat      v1, s2
    v.cmp.lt     p2, v1, v4
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v0
__rctx_next:
    exit
