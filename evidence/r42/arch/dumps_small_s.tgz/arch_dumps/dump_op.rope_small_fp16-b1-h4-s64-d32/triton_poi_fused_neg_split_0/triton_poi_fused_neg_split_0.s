    s.rdspecial  s1, arg_base
    s.movz       s2, #256
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #0
    s.rdspecial  s5, role_id
    s.rdspecial  s6, npid.x
    s.ld.d       s7, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
__rctx_program:
    v.movi       v0, #16
    v.movi       v1, #0
    v.iota       v2                              // arange(0, VLEN)
    v.movi       v3, #32
    v.movi       v4, #48
    v.movi       v5, #64
    v.movi       v6, #80
    v.movi       v7, #96
    v.movi       v8, #112
    v.sub        v9, v1, v0
    v.cmp.lt     p1, v0, v1
    // tiled element-wise program: 256 lanes as 2 tiles of 128 (0 tensor-engine transfers, one load buffer(s))
    s.mul        s1, s5, s2
    s.addi       s8, s4, #0
    v.add        v10, v2, v0
    v.add        v11, v2, v3
    v.add        v12, v2, v4
    v.add        v4, v2, v5
    v.add        v5, v2, v6
    v.add        v6, v2, v7
    v.add        v7, v2, v8
    @p1 v.sel        v8, v9, v0
    v.movi       v8, #15
    v.movi       v9, #4
tiles_1:
    // tile 0 of the iteration: lanes t0 + 0
    s.add        s9, s1, s8
    v.splat      v13, s9
    v.add        v14, v13, v2
    v.add        v15, v13, v10
    v.add        v16, v13, v11
    v.add        v17, v13, v12
    v.add        v18, v13, v4
    v.add        v19, v13, v5
    v.add        v20, v13, v6
    v.add        v21, v13, v7
    v.sub        v13, v1, v14
    v.sub        v22, v1, v15
    v.sub        v23, v1, v16
    v.sub        v24, v1, v17
    v.sub        v25, v1, v18
    v.sub        v26, v1, v19
    v.sub        v27, v1, v20
    v.sub        v28, v1, v21
    v.cmp.lt     p1, v14, v1
    v.cmp.lt     p2, v15, v1
    v.cmp.lt     p3, v16, v1
    v.cmp.lt     p4, v17, v1
    v.cmp.lt     p5, v18, v1
    v.cmp.lt     p6, v19, v1
    v.cmp.lt     p7, v20, v1
    v.cmp.lt     p8, v21, v1
    @p1 v.sel        v29, v13, v14
    @p2 v.sel        v13, v22, v15
    @p3 v.sel        v14, v23, v16
    @p4 v.sel        v15, v24, v17
    @p5 v.sel        v16, v25, v18
    @p6 v.sel        v17, v26, v19
    @p7 v.sel        v18, v27, v20
    @p8 v.sel        v19, v28, v21
    v.and        v20, v29, v8
    v.and        v21, v13, v8
    v.and        v22, v14, v8
    v.and        v23, v15, v8
    v.and        v24, v16, v8
    v.and        v25, v17, v8
    v.and        v26, v18, v8
    v.and        v27, v19, v8
    v.lshr       v28, v29, v9
    v.lshr       v29, v13, v9
    v.sub        v13, v1, v20
    v.sub        v30, v1, v21
    v.sub        v31, v1, v22
    v.sub        v32, v1, v23
    v.sub        v33, v1, v24
    v.sub        v34, v1, v25
    v.sub        v35, v1, v26
    v.sub        v36, v1, v27
    v.sub        v37, v1, v28
    @p1 v.sel        v38, v13, v20
    v.lshr       v13, v14, v9
    v.lshr       v14, v15, v9
    v.sub        v15, v1, v29
    @p2 v.sel        v20, v30, v21
    v.lshr       v21, v16, v9
    v.lshr       v16, v17, v9
    v.sub        v17, v1, v13
    @p3 v.sel        v30, v31, v22
    v.lshr       v22, v18, v9
    v.lshr       v18, v19, v9
    v.sub        v19, v1, v14
    v.sub        v31, v1, v21
    @p4 v.sel        v39, v32, v23
    v.sub        v23, v1, v16
    @p5 v.sel        v32, v33, v24
    v.sub        v24, v1, v22
    v.sub        v33, v1, v18
    @p6 v.sel        v40, v34, v25
    @p7 v.sel        v25, v35, v26
    @p8 v.sel        v26, v36, v27
    @p1 v.sel        v27, v37, v28
    @p2 v.sel        v28, v15, v29
    @p3 v.sel        v15, v17, v13
    @p4 v.sel        v13, v19, v14
    @p5 v.sel        v14, v31, v21
    @p6 v.sel        v17, v23, v16
    @p7 v.sel        v16, v24, v22
    @p8 v.sel        v19, v33, v18
    v.add        v18, v38, v0
    v.add        v21, v20, v0
    v.add        v22, v30, v0
    v.add        v23, v39, v0
    v.add        v24, v32, v0
    v.add        v29, v40, v0
    v.add        v31, v25, v0
    v.add        v33, v26, v0
    v.mul        v34, v27, v3
    v.mul        v27, v28, v3
    v.mul        v28, v15, v3
    v.mul        v15, v13, v3
    v.mul        v13, v14, v3
    v.mul        v14, v17, v3
    v.mul        v17, v16, v3
    v.mul        v16, v19, v3
    v.add        v19, v18, v34
    v.add        v18, v21, v27
    v.add        v21, v22, v28
    v.add        v22, v23, v15
    v.add        v23, v24, v13
    v.add        v24, v29, v14
    v.add        v29, v31, v17
    v.add        v31, v33, v16
    v.ld.gather.h v33, [s3, v19]                 // index is in elements (ISA sec 9.1)
    v.add        v19, v38, v34
    v.add        v34, v20, v27
    v.add        v20, v30, v28
    v.add        v27, v39, v15
    v.add        v15, v32, v13
    v.add        v13, v40, v14
    v.add        v14, v25, v17
    v.add        v17, v26, v16
    v.ld.gather.h v16, [s3, v18]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v18, v33
    vf.neg       v25, v18
    vf.cvt.f32.f16 v18, v25
    v.ld.gather.h v25, [s3, v21]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v21, v16
    vf.neg       v16, v21
    vf.cvt.f32.f16 v21, v16
    v.ld.gather.h v16, [s3, v22]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v22, v25
    vf.neg       v25, v22
    vf.cvt.f32.f16 v22, v25
    v.ld.gather.h v25, [s3, v23]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v23, v16
    vf.neg       v16, v23
    vf.cvt.f32.f16 v23, v16
    v.ld.gather.h v16, [s3, v24]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v24, v25
    vf.neg       v25, v24
    vf.cvt.f32.f16 v24, v25
    v.ld.gather.h v25, [s3, v29]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v26, v16
    vf.neg       v16, v26
    vf.cvt.f32.f16 v26, v16
    v.ld.gather.h v16, [s3, v31]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v28, v25
    vf.neg       v25, v28
    vf.cvt.f32.f16 v28, v25
    vf.cvt.f16.f32 v25, v16
    v.st.scatter.h [s7, v19], v18
    vf.neg       v16, v25
    vf.cvt.f32.f16 v18, v16
    v.st.scatter.h [s7, v34], v21
    v.st.scatter.h [s7, v20], v22
    v.st.scatter.h [s7, v27], v23
    v.st.scatter.h [s7, v15], v24
    v.st.scatter.h [s7, v13], v26
    v.st.scatter.h [s7, v14], v28
    v.st.scatter.h [s7, v17], v18
    s.addi       s8, s8, #128
    s.cmp.lt     s9, s8, s2
    br.nz        s9, tiles_1
endtiles_2:
__rctx_next:
    s.addi       s1, s5, #4                      // the next program of this context: + 4
    s.cmp.lt     s8, s1, s6
    s.mov        s5, s1
    br.nz        s8, __rctx_program
    exit
