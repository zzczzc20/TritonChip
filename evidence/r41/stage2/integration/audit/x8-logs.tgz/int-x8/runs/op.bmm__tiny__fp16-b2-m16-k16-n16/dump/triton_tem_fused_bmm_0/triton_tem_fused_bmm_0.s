    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, role_id
    s.movz       s2, #512
    s.rdspecial  s3, arg_base
    s.mul        s5, s1, s2
    s.ld.d       s1, [s3, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s2, arg_base
    s.rdspecial  s3, role_id
    s.movz       s6, #512
    s.add        s7, s1, s5                      // this context's own scratch
    s.ld.d       s1, [s2, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.addi       s5, s7, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    .li       s7, #2147483647
    .li       s8, #2147483647
    s.movz       s9, #32
    s.movz       s10, #2
    .li       s11, #68719476752
    .li       s12, #8589934592
    s.rdspecial  s13, arg_base
    s.mul        s14, s3, s6
    s.ld.d       s3, [s2, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.movz       s6, #1
    .li       s15, #2147483647
    s.ld.d       s16, [s2, #16]                  // out_ptr0: device_ptr64 at arg_base+16
    s.movz       s2, #0
    s.movz       s2, #0
    s.st.d       [s5, #0], s1
    s.sub        s1, s6, s4
    s.min.s      s2, s1, s6
    s.st.d       [s5, #8], s7
    s.movz       s1, #0
    s.cmp.lt     s7, s2, s1
    s.st.d       [s5, #16], s8
    s.movz       s1, #0
    s.cmp.lt     s8, s4, s1
    s.st.d       [s5, #48], s9
    s.movz       s1, #0
    s.sub        s9, s1, s7
    s.movz       s1, #0
    s.st.d       [s5, #56], s10
    s.sub        s7, s1, s8
    s.xor        s1, s2, s9
    s.st.d       [s5, #88], s11
    s.movz       s8, #0
    s.movz       s10, #1
    s.st.d       [s5, #104], s12
    fence.release.device
    td.load      d0, [s5]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.ld.d       s5, [s13, #24]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.xor        s11, s4, s7
    s.sub        s12, s1, s9
    s.add        s1, s5, s14                     // this context's own scratch
    .li       s5, #2147483647
    s.addi       s9, s1, #256                    // TensorMap 1: a 2-D tt.load (built once, at entry)
    s.movz       s1, #32
    s.movz       s13, #2
    s.sub        s14, s11, s7
    s.addi       s11, s8, #0
    s.cmp.eq     s8, s12, s10
    s.st.d       [s9, #0], s3
    .li       s3, #68719476752
    s.st.d       [s9, #8], s15
    .li       s10, #8589934592
    s.st.d       [s9, #16], s5
    s.movz       s5, #0
    s.st.d       [s9, #48], s1
    s.addi       s1, s5, #0
    s.st.d       [s9, #56], s13
    s.st.d       [s9, #88], s3
    s.st.d       [s9, #104], s10
    fence.release.device
    td.load      d1, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.mov        s11, s14
    br.nz        s8, sdiv_done_1
    s.movz       s3, #0
    s.movz       s5, #31
    s.mov        s11, s3
    s.addi       s3, s5, #0
sdiv_2:
    s.lshr       s5, s14, s3
    s.shli       s8, s1, #1
    s.andi       s9, s5, #1
    s.movz       s5, #0
    s.or         s10, s8, s9
    s.movz       s8, #1
    s.cmp.geu    s9, s10, s12
    s.shl        s13, s8, s3
    s.sub        s8, s5, s9
    s.subi       s5, s3, #1
    s.and        s9, s12, s8
    s.and        s15, s13, s8
    s.sub        s8, s10, s9
    s.or         s9, s11, s15
    s.mov        s1, s8
    s.mov        s11, s9
    s.mov        s3, s5
    s.movz       s5, #0
    s.cmp.ge     s8, s3, s5
    br.nz        s8, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s5, #0
    s.movz       s8, #0
    s.movz       s9, #0
    s.cmp.lt     s10, s2, s3
    s.movz       s3, #0
    s.cmp.lt     s11, s5, s8
    s.sub        s8, s9, s10
    s.sub        s9, s3, s11
    s.xor        s3, s2, s8
    s.xor        s2, s1, s7
    s.xor        s1, s5, s9
    s.sub        s10, s3, s8
    s.movz       s3, #0
    s.movz       s11, #1
    s.sub        s12, s2, s7
    s.sub        s2, s1, s9
    s.movz       s1, #0
    s.addi       s7, s3, #0
    s.cmp.eq     s3, s10, s11
    s.add        s11, s4, s12
    s.addi       s4, s1, #0
    s.mov        s7, s2
    br.nz        s3, sdiv_done_3
    s.movz       s1, #0
    s.movz       s3, #31
    s.mov        s7, s1
    s.addi       s1, s3, #0
sdiv_4:
    s.lshr       s3, s2, s1
    s.shli       s12, s4, #1
    s.andi       s13, s3, #1
    s.movz       s3, #0
    s.or         s14, s12, s13
    s.movz       s12, #1
    s.cmp.geu    s13, s14, s10
    s.shl        s15, s12, s1
    s.sub        s12, s3, s13
    s.subi       s3, s1, #1
    s.and        s13, s10, s12
    s.and        s17, s15, s12
    s.sub        s12, s14, s13
    s.or         s13, s7, s17
    s.mov        s4, s12
    s.mov        s7, s13
    s.mov        s1, s3
    s.movz       s3, #0
    s.cmp.ge     s12, s1, s3
    br.nz        s12, sdiv_4
sdiv_done_3:
    s.rdspecial  s1, pid.z
    s.rdspecial  s2, npid.y
    s.xor        s3, s9, s8
    s.mul        s4, s1, s2
    s.xor        s1, s7, s3
    s.rdspecial  s2, pid.y
    s.sub        s7, s1, s3
    s.movz       s1, #16
    s.add        s3, s2, s4
    s.mul        s2, s11, s1
    s.mul        s4, s7, s1
    s.min.s      s8, s3, s6
    s.movz       s6, #256
    w.def        w0, #56, #8                     // v56..v63
    s.mul        s9, s8, s6
    s.andi       s8, s2, #15
    s.andi       s10, s4, #15
    mb.arm       s12, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s13, #0
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s14, s8                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s9                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s14, s12
    mb.wait      s12
    s.add        s14, s10, s9
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s9, b1, #0, #1                  // 0 arrival(s), 1 operation(s)
    v.movi       v0, #0
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s17, s13                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s18, s14                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s17, s9
    mb.wait      s9
    m.zero       a0
    mb.arm       s13, b2, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s14, #2
    m.mma.async.k16.f16 a0, v56, v48, s13
    mb.wait      s13
    v.splat      v1, s3
    v.splat      v2, s14
    v.splat      v3, s11
    v.cmp.lt     p1, v1, v2
    v.splat      v1, s5
    s.mul        s11, s3, s6
    v.splat      v2, s7
    v.splat      v4, s5
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s2
    v.splat      v7, s4
    v.splat      v8, s8
    v.cmp.ge     p2, v3, v1
    s.muli       s3, s4, #2                      // a runtime tile origin, x2
    s.muli       s5, s2, #32                     // a runtime tile origin, x32
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v3, s10
    v.cmp.ge     p2, v2, v4
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s6, #0
    s.muli       s7, s11, #2                     // a runtime tile origin, x2
    a.vread      v2, a0, s6
    s.add        s6, s16, s3                     // the tile origin
    v.iota       v4                              // arange(0, VLEN)
    s.add        s3, s6, s5                      // the tile origin
    v.add        v9, v6, v5
    s.movz       s5, #0
    vf.add       v6, v2, v0
    s.add        s6, s3, s7                      // the tile origin
    v.add        v2, v7, v5
    s.add        s3, s5, s2                      // the tile origin
    v.splat      v2, s1
    v.splat      v5, s3
    vf.cvt.f32.f16 v7, v6
    v.cmp.lt     p2, v5, v2
    v.add        v5, v8, v1
    s.movz       s2, #0
    v.iota       v1                              // arange(0, VLEN)
    s.add        s5, s2, s4                      // the tile origin
    v.add        v5, v3, v4
    v.splat      v3, s5
    v.splat      v4, s1
    v.add        v5, v1, v3
    s.movz       s1, #1
    v.cmp.lt     p3, v5, v4
    p.and        p4, p2, p3
    s.addi       s2, s3, #1
    p.and        p2, p4, p1
    v.splat      v1, s2
    @p2 v.st.h       [s6, #0], v7
    a.vread      v3, a0, s1
    v.cmp.lt     p2, v1, v2
    vf.add       v1, v3, v0
    p.and        p4, p2, p3
    s.addi       s1, s6, #32                     // row 1
    p.and        p2, p4, p1
    vf.cvt.f32.f16 v3, v1
    s.movz       s2, #2
    s.addi       s4, s3, #2
    s.addi       s5, s6, #64                     // row 2
    @p2 v.st.h       [s1, #0], v3
    a.vread      v1, a0, s2
    v.splat      v3, s4
    vf.add       v4, v1, v0
    v.cmp.lt     p2, v3, v2
    p.and        p4, p2, p3
    s.movz       s1, #3
    vf.cvt.f32.f16 v1, v4
    p.and        p2, p4, p1
    s.addi       s2, s3, #3
    s.addi       s4, s6, #96                     // row 3
    @p2 v.st.h       [s5, #0], v1
    a.vread      v1, a0, s1
    v.splat      v3, s2
    vf.add       v4, v1, v0
    v.cmp.lt     p2, v3, v2
    p.and        p4, p2, p3
    s.movz       s1, #4
    vf.cvt.f32.f16 v1, v4
    p.and        p2, p4, p1
    s.addi       s2, s3, #4
    s.addi       s5, s6, #128                    // row 4
    @p2 v.st.h       [s4, #0], v1
    a.vread      v1, a0, s1
    v.splat      v3, s2
    vf.add       v4, v1, v0
    v.cmp.lt     p2, v3, v2
    p.and        p4, p2, p3
    s.movz       s1, #5
    vf.cvt.f32.f16 v1, v4
    p.and        p2, p4, p1
    s.addi       s2, s3, #5
    s.addi       s4, s6, #160                    // row 5
    @p2 v.st.h       [s5, #0], v1
    a.vread      v1, a0, s1
    v.splat      v3, s2
    vf.add       v4, v1, v0
    v.cmp.lt     p2, v3, v2
    p.and        p4, p2, p3
    s.movz       s1, #6
    vf.cvt.f32.f16 v1, v4
    p.and        p2, p4, p1
    s.addi       s2, s3, #6
    s.addi       s5, s6, #192                    // row 6
    @p2 v.st.h       [s4, #0], v1
    a.vread      v1, a0, s1
    v.splat      v3, s2
    vf.add       v4, v1, v0
    v.cmp.lt     p2, v3, v2
    p.and        p4, p2, p3
    s.movz       s1, #7
    vf.cvt.f32.f16 v1, v4
    p.and        p2, p4, p1
    s.addi       s2, s3, #7
    s.addi       s4, s6, #224                    // row 7
    @p2 v.st.h       [s5, #0], v1
    a.vread      v1, a0, s1
    v.splat      v3, s2
    vf.add       v4, v1, v0
    v.cmp.lt     p2, v3, v2
    p.and        p4, p2, p3
    s.movz       s1, #8
    vf.cvt.f32.f16 v1, v4
    p.and        p2, p4, p1
    s.addi       s2, s3, #8
    s.addi       s5, s6, #256                    // row 8
    @p2 v.st.h       [s4, #0], v1
    a.vread      v1, a0, s1
    v.splat      v3, s2
    vf.add       v4, v1, v0
    v.cmp.lt     p2, v3, v2
    p.and        p4, p2, p3
    s.movz       s1, #9
    vf.cvt.f32.f16 v1, v4
    p.and        p2, p4, p1
    s.addi       s2, s3, #9
    s.addi       s4, s6, #288                    // row 9
    @p2 v.st.h       [s5, #0], v1
    a.vread      v1, a0, s1
    v.splat      v3, s2
    vf.add       v4, v1, v0
    v.cmp.lt     p2, v3, v2
    p.and        p4, p2, p3
    s.movz       s1, #10
    vf.cvt.f32.f16 v1, v4
    p.and        p2, p4, p1
    s.addi       s2, s3, #10
    s.addi       s5, s6, #320                    // row 10
    @p2 v.st.h       [s4, #0], v1
    a.vread      v1, a0, s1
    v.splat      v3, s2
    vf.add       v4, v1, v0
    v.cmp.lt     p2, v3, v2
    p.and        p4, p2, p3
    s.movz       s1, #11
    vf.cvt.f32.f16 v1, v4
    p.and        p2, p4, p1
    s.addi       s2, s3, #11
    s.addi       s4, s6, #352                    // row 11
    @p2 v.st.h       [s5, #0], v1
    a.vread      v1, a0, s1
    v.splat      v3, s2
    vf.add       v4, v1, v0
    v.cmp.lt     p2, v3, v2
    p.and        p4, p2, p3
    s.movz       s1, #12
    vf.cvt.f32.f16 v1, v4
    p.and        p2, p4, p1
    s.addi       s2, s3, #12
    s.addi       s5, s6, #384                    // row 12
    @p2 v.st.h       [s4, #0], v1
    a.vread      v1, a0, s1
    v.splat      v3, s2
    vf.add       v4, v1, v0
    v.cmp.lt     p2, v3, v2
    p.and        p4, p2, p3
    s.movz       s1, #13
    vf.cvt.f32.f16 v1, v4
    p.and        p2, p4, p1
    s.addi       s2, s3, #13
    s.addi       s4, s6, #416                    // row 13
    @p2 v.st.h       [s5, #0], v1
    a.vread      v1, a0, s1
    v.splat      v3, s2
    vf.add       v4, v1, v0
    v.cmp.lt     p2, v3, v2
    p.and        p4, p2, p3
    s.movz       s1, #14
    vf.cvt.f32.f16 v1, v4
    p.and        p2, p4, p1
    s.addi       s2, s3, #14
    s.addi       s5, s6, #448                    // row 14
    @p2 v.st.h       [s4, #0], v1
    a.vread      v1, a0, s1
    v.splat      v3, s2
    vf.add       v4, v1, v0
    v.cmp.lt     p2, v3, v2
    p.and        p4, p2, p3
    s.movz       s1, #15
    vf.cvt.f32.f16 v1, v4
    p.and        p2, p4, p1
    s.addi       s2, s3, #15
    s.addi       s3, s6, #480                    // row 15
    @p2 v.st.h       [s5, #0], v1
    a.vread      v1, a0, s1
    v.splat      v3, s2
    vf.add       v4, v1, v0
    v.cmp.lt     p2, v3, v2
    p.and        p4, p2, p3
    vf.cvt.f32.f16 v0, v4
    p.and        p2, p4, p1
    @p2 v.st.h       [s3, #0], v0
__rctx_next:
    exit
