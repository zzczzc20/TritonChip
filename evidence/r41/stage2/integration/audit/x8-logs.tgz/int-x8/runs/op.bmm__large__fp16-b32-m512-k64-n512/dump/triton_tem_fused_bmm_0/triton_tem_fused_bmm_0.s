    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s3, s4, s1
    s.movz       s1, #32
    s.movz       s5, #0
    s.sub        s6, s2, s3
    s.movz       s2, #0
    s.cmp.lt     s3, s1, s5
    s.xor        s5, s4, s6
    s.sub        s7, s2, s3
    s.sub        s2, s5, s6
    s.xor        s3, s6, s7
    s.lshri      s5, s2, #5
    s.movz       s6, #1
    s.xor        s8, s5, s3
    s.movz       s9, #0
    s.sub        s10, s8, s3
    s.movz       s3, #0
    s.sub        s8, s1, s10
    s.movz       s11, #0
    s.min.s      s12, s8, s6
    s.movz       s6, #0
    s.cmp.lt     s8, s12, s9
    s.cmp.lt     s9, s4, s3
    s.sub        s3, s11, s8
    s.sub        s8, s6, s9
    s.xor        s6, s12, s3
    s.muli       s9, s5, #32
    s.movz       s5, #0
    s.movz       s11, #1
    s.xor        s13, s4, s8
    s.sub        s14, s6, s3
    s.rdspecial  s3, arg_base
    s.xor        s6, s1, s7
    s.movz       s15, #0
    s.sub        s16, s13, s8
    s.addi       s13, s5, #0
    s.cmp.eq     s5, s14, s11
    s.ld.d       s11, [s3, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.sub        s17, s6, s7
    s.sub        s6, s2, s9
    s.ld.d       s2, [s3, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.addi       s6, s15, #0
    s.ld.d       s7, [s3, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.mov        s13, s16
    br.nz        s5, sdiv_done_1
    s.movz       s3, #0
    s.movz       s5, #31
    s.mov        s13, s3
    s.addi       s3, s5, #0
sdiv_2:
    s.lshr       s5, s16, s3
    s.shli       s9, s6, #1
    s.andi       s15, s5, #1
    s.movz       s5, #0
    s.or         s17, s9, s15
    s.movz       s9, #1
    s.cmp.geu    s15, s17, s14
    s.shl        s18, s9, s3
    s.sub        s9, s5, s15
    s.subi       s5, s3, #1
    s.and        s15, s14, s9
    s.and        s19, s18, s9
    s.sub        s9, s17, s15
    s.or         s15, s13, s19
    s.mov        s6, s9
    s.mov        s13, s15
    s.mov        s3, s5
    s.movz       s5, #0
    s.cmp.ge     s9, s3, s5
    br.nz        s9, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s5, #0
    s.cmp.lt     s9, s4, s3
    s.movz       s3, #0
    s.sub        s13, s5, s9
    s.movz       s5, #0
    s.xor        s9, s4, s13
    s.movz       s4, #0
    s.sub        s14, s9, s13
    s.cmp.lt     s9, s12, s3
    s.lshri      s3, s14, #5
    s.movz       s15, #0
    s.muli       s16, s3, #32
    s.movz       s3, #0
    s.sub        s17, s4, s9
    s.movz       s4, #0
    s.cmp.lt     s9, s1, s15
    s.sub        s15, s14, s16
    s.xor        s14, s12, s17
    s.xor        s12, s15, s13
    s.xor        s15, s6, s8
    s.sub        s6, s12, s13
    s.sub        s12, s4, s9
    s.cmp.lt     s4, s6, s5
    s.sub        s5, s14, s17
    s.sub        s9, s3, s4
    s.movz       s3, #0
    s.xor        s4, s6, s9
    s.movz       s6, #1
    s.sub        s13, s15, s8
    s.xor        s8, s1, s12
    s.sub        s14, s4, s9
    s.movz       s4, #0
    s.addi       s15, s3, #0
    s.cmp.eq     s3, s5, s6
    s.add        s6, s10, s13
    s.sub        s10, s8, s12
    s.addi       s8, s4, #0
    s.mov        s15, s14
    br.nz        s3, sdiv_done_3
    s.movz       s3, #0
    s.movz       s4, #31
    s.mov        s15, s3
    s.addi       s3, s4, #0
sdiv_4:
    s.lshr       s4, s14, s3
    s.shli       s10, s8, #1
    s.andi       s12, s4, #1
    s.movz       s4, #0
    s.or         s13, s10, s12
    s.movz       s10, #1
    s.cmp.geu    s12, s13, s5
    s.shl        s16, s10, s3
    s.sub        s10, s4, s12
    s.subi       s4, s3, #1
    s.and        s12, s5, s10
    s.and        s18, s16, s10
    s.sub        s10, s13, s12
    s.or         s12, s15, s18
    s.mov        s8, s10
    s.mov        s15, s12
    s.mov        s3, s4
    s.movz       s4, #0
    s.cmp.ge     s10, s3, s4
    br.nz        s10, sdiv_4
sdiv_done_3:
    s.movz       s3, #16
    s.rdspecial  s4, pid.z
    s.rdspecial  s5, npid.y
    s.xor        s8, s9, s17
    s.mul        s9, s6, s3
    s.mul        s10, s4, s5
    s.xor        s4, s15, s8
    s.rdspecial  s5, pid.y
    s.sub        s12, s4, s8
    s.andi       s4, s9, #511
    s.mul        s8, s12, s3
    s.add        s13, s5, s10
    s.movz       s5, #31
    s.movz       s10, #32768
    s.min.s      s14, s13, s5
    s.muli       s5, s4, #64                     // a runtime tile origin, x64
    s.mul        s15, s14, s10
    s.rdspecial  s10, role_id
    s.movz       s14, #9728
    s.andi       s16, s8, #511
    s.movz       s17, #0
    s.rdspecial  s18, arg_base
    s.mul        s19, s10, s14
    s.add        s10, s17, s5                    // the tile origin
    s.ld.d       s5, [s18, #24]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.add        s14, s10, s15                   // the tile origin
    s.movz       s10, #0
    s.add        s17, s5, s19                    // this context's own scratch
    v.iota       v0                              // arange(0, VLEN)
    s.addi       s5, s17, #0
    v.splat      v1, s14
    v.splat      v2, s6
    v.splat      v3, s10
    s.addi       s6, s14, #64
    v.splat      v4, s12
    v.splat      v5, s10
    v.add        v6, v0, v1
    s.addi       s12, s5, #64
    v.cmp.ge     p1, v2, v3
    v.splat      v1, s6
    v.iota       v2                              // arange(0, VLEN)
    v.add        v3, v0, v1
    v.cmp.ge     p1, v4, v5
    s.addi       s6, s14, #128
    v.splat      v1, s9
    v.splat      v4, s6
    s.addi       s6, s5, #128
    v.add        v5, v0, v4
    v.add        v4, v1, v2
    s.addi       s18, s14, #192
    v.splat      v1, s8
    s.addi       s19, s5, #192
    v.add        v4, v1, v2
    v.splat      v1, s18
    v.splat      v2, s4
    v.add        v4, v0, v1
    s.addi       s4, s5, #256
    s.movz       s18, #64
    s.addi       s20, s10, #0
    v.st.w       [s5, #0], v6
    v.iota       v1                              // arange(0, VLEN)
    s.addi       s10, s14, #256
    v.add        v6, v2, v1
    v.splat      v1, s10
    v.splat      v2, s16
    v.add        v6, v0, v1
    v.st.w       [s12, #0], v3
    v.iota       v1                              // arange(0, VLEN)
    s.addi       s10, s5, #320
    v.add        v3, v2, v1
    s.addi       s12, s14, #320
    s.addi       s21, s14, #384
    v.splat      v1, s12
    s.addi       s12, s14, #448
    v.splat      v2, s21
    s.addi       s21, s14, #512
    v.add        v3, v0, v1
    v.add        v1, v0, v2
    v.st.w       [s6, #0], v5
    s.addi       s6, s14, #576
    v.splat      v2, s12
    s.addi       s12, s14, #640
    v.add        v5, v0, v2
    v.st.w       [s19, #0], v4
    s.addi       s19, s14, #704
    v.splat      v2, s21
    s.addi       s21, s14, #768
    v.add        v4, v0, v2
    v.st.w       [s4, #0], v6
    s.addi       s4, s14, #832
    v.splat      v2, s6
    s.addi       s6, s14, #896
    s.addi       s22, s14, #960
    v.add        v6, v0, v2
    v.st.w       [s10, #0], v3
    v.splat      v2, s12
    s.addi       s10, s5, #384
    s.addi       s12, s17, #1024
    v.add        v3, v0, v2
    v.st.w       [s10, #0], v1
    s.movz       s10, #0
    v.splat      v1, s19
    s.addi       s14, s5, #448
    s.add        s19, s10, s16                   // the tile origin
    s.addi       s10, s5, #512
    s.add        s16, s19, s15                   // the tile origin
    s.addi       s15, s5, #576
    v.add        v2, v0, v1
    v.st.w       [s14, #0], v5
    s.addi       s14, s16, #512
    v.splat      v1, s21
    s.addi       s19, s5, #640
    v.add        v5, v0, v1
    v.st.w       [s10, #0], v4
    s.addi       s10, s16, #1024
    v.splat      v1, s4
    s.addi       s4, s5, #704
    v.add        v4, v0, v1
    v.st.w       [s15, #0], v6
    s.addi       s15, s16, #1536
    v.splat      v1, s6
    s.addi       s6, s5, #768
    v.add        v6, v0, v1
    v.st.w       [s19, #0], v3
    s.addi       s19, s16, #2048
    v.splat      v1, s22
    s.addi       s21, s5, #832
    v.add        v3, v0, v1
    v.st.w       [s4, #0], v2
    s.addi       s4, s16, #2560
    v.splat      v1, s16
    v.add        v2, v0, v1
    v.st.w       [s6, #0], v5
    s.addi       s6, s16, #3072
    v.splat      v1, s14
    s.addi       s14, s5, #896
    s.addi       s22, s5, #960
    v.add        v5, v0, v1
    v.st.w       [s21, #0], v4
    s.addi       s5, s16, #3584
    v.splat      v1, s10
    s.addi       s10, s12, #64
    v.add        v4, v0, v1
    v.st.w       [s14, #0], v6
    s.addi       s14, s16, #4096
    v.splat      v1, s15
    s.addi       s15, s12, #128
    v.add        v6, v0, v1
    v.st.w       [s22, #0], v3
    v.splat      v1, s19
    s.addi       s19, s12, #192
    s.addi       s21, s12, #256
    v.add        v3, v0, v1
    fence.acq_rel.device
    v.st.w       [s12, #0], v2
    v.splat      v1, s4
    s.addi       s4, s16, #4608
    v.add        v2, v0, v1
    v.st.w       [s10, #0], v5
    s.addi       s10, s16, #5120
    v.splat      v1, s6
    s.addi       s6, s16, #5632
    v.add        v5, v0, v1
    v.st.w       [s15, #0], v4
    s.addi       s15, s16, #6144
    v.splat      v1, s5
    s.addi       s5, s16, #6656
    v.add        v4, v0, v1
    v.st.w       [s19, #0], v6
    s.addi       s19, s16, #7168
    v.splat      v1, s14
    s.addi       s14, s12, #320
    v.add        v6, v0, v1
    v.st.w       [s21, #0], v3
    s.addi       s21, s16, #7680
    v.splat      v1, s4
    s.addi       s4, s12, #384
    s.addi       s16, s12, #448
    v.add        v3, v0, v1
    v.st.w       [s14, #0], v2
    v.splat      v1, s10
    s.addi       s10, s12, #512
    s.addi       s14, s12, #576
    v.add        v2, v0, v1
    v.st.w       [s4, #0], v5
    v.splat      v1, s6
    s.addi       s4, s12, #640
    s.addi       s6, s12, #704
    v.add        v5, v0, v1
    v.st.w       [s16, #0], v4
    v.splat      v1, s15
    s.addi       s15, s12, #768
    v.add        v4, v0, v1
    s.addi       s16, s12, #832
    v.st.w       [s10, #0], v6
    v.splat      v1, s5
    s.addi       s5, s12, #896
    v.add        v6, v0, v1
    s.addi       s10, s12, #960
    v.st.w       [s14, #0], v3
    v.splat      v1, s19
    v.add        v3, v0, v1
    v.st.w       [s4, #0], v2
    v.splat      v1, s21
    v.add        v2, v0, v1
    v.st.w       [s6, #0], v5
    v.st.w       [s15, #0], v4
    v.st.w       [s16, #0], v6
    v.st.w       [s5, #0], v3
    v.st.w       [s10, #0], v2
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s4, s20, s18
    br.nz        s4, endfor_6
    s.addi       s4, s17, #0
    s.addi       s5, s17, #2048
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #64
    s.addi       s6, s5, #64
    s.addi       s10, s17, #128
    s.addi       s12, s5, #128
    s.addi       s14, s17, #192
    s.addi       s15, s5, #192
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v2
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #256
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s6, #0], v2
    s.addi       s6, s5, #256
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s17, #320
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s12, s5, #320
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s17, #384
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s5, #384
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #448
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s6, #0], v2
    s.addi       s6, s5, #448
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s17, #512
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s12, s5, #512
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s17, #576
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s5, #576
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #640
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s6, #0], v2
    s.addi       s6, s5, #640
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s17, #704
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s12, s5, #704
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s17, #768
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s5, #768
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #832
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s6, #0], v2
    s.addi       s6, s5, #832
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s17, #896
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s12, s5, #896
    s.addi       s16, s5, #960
    v.ld.w       v1, [s14, #0]
    s.addi       s5, s17, #960
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s14, s17, #1024
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #3072
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s6, #0], v2
    s.addi       s6, s17, #1088
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s4, #64
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s12, s17, #1152
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s4, #128
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    s.addi       s15, s17, #1216
    v.st.w       [s16, #0], v2
    fence.acq_rel.device
    s.addi       s16, s4, #192
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s17, #1280
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s4, #0], v2
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s4, #256
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s10, #0], v2
    s.addi       s10, s17, #1344
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s4, #320
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v2
    s.addi       s5, s17, #1408
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s4, #384
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v2
    s.addi       s16, s17, #1472
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s4, #448
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s6, #0], v2
    s.addi       s6, s17, #1536
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s4, #512
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s12, s17, #1600
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s4, #576
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s17, #1664
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s4, #640
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s17, #1728
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s4, #704
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s10, #0], v2
    s.addi       s10, s17, #1792
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s4, #768
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v2
    s.addi       s5, s17, #1856
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s4, #832
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v2
    s.addi       s16, s17, #1920
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s4, #896
    s.addi       s19, s4, #960
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s6, #0], v2
    s.addi       s4, s17, #1984
    v.ld.w       v1, [s10, #0]
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    s.addi       s6, s17, #2048
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s10, s17, #4096                 // 512 bytes of repack scratch
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #2112
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s12, s10, #32                   // row 1
    v.ld.w       v1, [s16, #0]
    s.addi       s15, s17, #2176
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s10, #64                   // row 2
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #2240
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s16, s10, #96                   // row 3
    v.st.w       [s19, #0], v2
    fence.acq_rel.device
    s.addi       s19, s17, #2304
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s10, #128                   // row 4
    v.st.h       [s10, #0], v1
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #2368
    v.st.h       [s12, #0], v1
    s.addi       s12, s10, #160                  // row 5
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #2432
    v.st.h       [s14, #0], v1
    s.addi       s14, s10, #192                  // row 6
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #2496
    v.st.h       [s16, #0], v1
    s.addi       s16, s10, #224                  // row 7
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s17, #2560
    s.movz       s21, #0
    v.st.h       [s6, #0], v1
    s.addi       s6, s10, #256                   // row 8
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #2624
    v.st.h       [s12, #0], v1
    s.addi       s12, s10, #288                  // row 9
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #2688
    v.st.h       [s14, #0], v1
    s.addi       s14, s10, #320                  // row 10
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #2752
    v.st.h       [s16, #0], v1
    s.addi       s16, s10, #352                  // row 11
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s17, #2816
    v.st.h       [s6, #0], v1
    s.addi       s6, s10, #384                   // row 12
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #2880
    v.st.h       [s12, #0], v1
    s.addi       s12, s10, #416                  // row 13
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #2944
    v.st.h       [s14, #0], v1
    s.addi       s14, s10, #448                  // row 14
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #3008
    v.st.h       [s16, #0], v1
    s.addi       s16, s10, #480                  // row 15
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s17, #4608                 // TensorMap 0: a repacked tile
    v.st.h       [s6, #0], v1
    s.movz       s6, #16
    v.ld.w       v1, [s5, #0]
    s.movz       s5, #16
    v.st.h       [s12, #0], v1
    s.movz       s12, #32
    v.ld.w       v1, [s15, #0]
    s.movz       s15, #2
    v.st.h       [s14, #0], v1
    .li       s14, #68719476752
    v.ld.w       v1, [s4, #0]
    .li       s4, #8589934592
    v.st.h       [s16, #0], v1
    s.movz       s16, #0
    s.st.d       [s19, #0], s10
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    s.addi       s10, s17, #3072
    s.st.d       [s19, #8], s6
    s.addi       s6, s17, #4864                  // 512 bytes of repack scratch
    s.st.d       [s19, #16], s5
    s.addi       s5, s17, #3136
    s.st.d       [s19, #48], s12
    s.addi       s12, s6, #32                    // row 1
    s.st.d       [s19, #56], s15
    s.addi       s15, s17, #3200
    s.st.d       [s19, #88], s14
    s.addi       s14, s6, #64                    // row 2
    s.st.d       [s19, #104], s4
    fence.release.device
    td.load      d0, [s19]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s4, b0, #0, #1                  // 0 arrival(s), 1 operation(s)
    s.addi       s19, s17, #3264
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s21, s16                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s22, s16                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s21, s4
    mb.wait      s4
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s6, #96                    // row 3
    s.addi       s16, s17, #3328
    s.addi       s21, s6, #128                   // row 4
    v.st.h       [s6, #0], v1
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #3392
    v.st.h       [s12, #0], v1
    s.addi       s12, s6, #160                   // row 5
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #3456
    v.st.h       [s14, #0], v1
    s.addi       s14, s6, #192                   // row 6
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s17, #3520
    v.st.h       [s10, #0], v1
    s.addi       s10, s6, #224                   // row 7
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s17, #3584
    s.movz       s22, #0
    v.st.h       [s21, #0], v1
    s.addi       s21, s6, #256                   // row 8
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #3648
    v.st.h       [s12, #0], v1
    s.addi       s12, s6, #288                   // row 9
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #3712
    v.st.h       [s14, #0], v1
    s.addi       s14, s6, #320                   // row 10
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s17, #3776
    v.st.h       [s10, #0], v1
    s.addi       s10, s6, #352                   // row 11
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s17, #3840
    v.st.h       [s21, #0], v1
    s.addi       s21, s6, #384                   // row 12
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #3904
    v.st.h       [s12, #0], v1
    s.addi       s12, s6, #416                   // row 13
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #3968
    v.st.h       [s14, #0], v1
    s.addi       s14, s6, #448                   // row 14
    v.splat      v1, s3
    v.ld.w       v2, [s19, #0]
    s.addi       s19, s17, #4032
    v.st.h       [s10, #0], v2
    s.addi       s10, s6, #480                   // row 15
    v.ld.w       v2, [s16, #0]
    s.addi       s16, s17, #5376                 // TensorMap 1: a repacked tile
    v.st.h       [s21, #0], v2
    s.movz       s21, #16
    v.ld.w       v2, [s5, #0]
    s.movz       s5, #16
    v.st.h       [s12, #0], v2
    s.movz       s12, #32
    v.ld.w       v2, [s15, #0]
    s.movz       s15, #2
    v.st.h       [s14, #0], v2
    .li       s14, #68719476752
    v.ld.w       v2, [s19, #0]
    .li       s19, #8589934592
    v.st.h       [s10, #0], v2
    s.movz       s10, #0
    s.st.d       [s16, #0], s6
    s.addi       s6, s17, #0
    s.st.d       [s16, #8], s21
    s.addi       s21, s17, #5632
    s.st.d       [s16, #16], s5
    s.addi       s5, s17, #64
    s.st.d       [s16, #48], s12
    s.addi       s12, s21, #64
    s.st.d       [s16, #56], s15
    s.addi       s15, s17, #128
    s.st.d       [s16, #88], s14
    s.addi       s14, s21, #128
    s.st.d       [s16, #104], s19
    fence.release.device
    td.load      d1, [s16]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s16, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s19, s17, #192
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s22, s10                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s23, s10                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s22, s16
    mb.wait      s16
    mb.arm       s10, b2, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s22, s21, #192
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.f16 a0, v56, v48, s10
    mb.wait      s10
    v.ld.w       v2, [s6, #0]
    s.addi       s6, s17, #256
    s.addi       s23, s21, #256
    v.add        v3, v2, v1
    v.st.w       [s21, #0], v3
    v.ld.w       v2, [s5, #0]
    s.addi       s5, s17, #320
    v.add        v3, v2, v1
    v.st.w       [s12, #0], v3
    s.addi       s12, s21, #320
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s17, #384
    v.add        v3, v2, v1
    v.st.w       [s14, #0], v3
    s.addi       s14, s21, #384
    v.ld.w       v2, [s19, #0]
    s.addi       s19, s17, #448
    v.add        v3, v2, v1
    v.st.w       [s22, #0], v3
    s.addi       s22, s21, #448
    v.ld.w       v2, [s6, #0]
    s.addi       s6, s17, #512
    v.add        v3, v2, v1
    v.st.w       [s23, #0], v3
    s.addi       s23, s21, #512
    v.ld.w       v2, [s5, #0]
    s.addi       s5, s17, #576
    v.add        v3, v2, v1
    v.st.w       [s12, #0], v3
    s.addi       s12, s21, #576
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s17, #640
    v.add        v3, v2, v1
    v.st.w       [s14, #0], v3
    s.addi       s14, s21, #640
    v.ld.w       v2, [s19, #0]
    s.addi       s19, s17, #704
    v.add        v3, v2, v1
    v.st.w       [s22, #0], v3
    s.addi       s22, s21, #704
    v.ld.w       v2, [s6, #0]
    s.addi       s6, s17, #768
    v.add        v3, v2, v1
    v.st.w       [s23, #0], v3
    s.addi       s23, s21, #768
    v.ld.w       v2, [s5, #0]
    s.addi       s5, s17, #832
    v.add        v3, v2, v1
    v.st.w       [s12, #0], v3
    s.addi       s12, s21, #832
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s17, #896
    v.add        v3, v2, v1
    v.st.w       [s14, #0], v3
    s.addi       s14, s21, #896
    s.addi       s24, s21, #960
    v.ld.w       v2, [s19, #0]
    s.addi       s19, s17, #960
    v.add        v3, v2, v1
    v.st.w       [s22, #0], v3
    s.addi       s21, s17, #1024
    v.ld.w       v2, [s6, #0]
    s.movz       s6, #8192
    v.splat      v3, s6
    s.addi       s6, s17, #6656
    v.add        v4, v2, v1
    v.st.w       [s23, #0], v4
    s.addi       s22, s17, #1088
    v.ld.w       v2, [s5, #0]
    s.addi       s5, s6, #64
    v.add        v4, v2, v1
    v.st.w       [s12, #0], v4
    s.addi       s12, s17, #1152
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s6, #128
    v.add        v4, v2, v1
    v.st.w       [s14, #0], v4
    s.addi       s14, s17, #1216
    v.ld.w       v2, [s19, #0]
    s.addi       s19, s6, #192
    v.add        v4, v2, v1
    v.st.w       [s24, #0], v4
    fence.acq_rel.device
    s.addi       s23, s17, #1280
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s6, #256
    v.add        v2, v1, v3
    v.st.w       [s6, #0], v2
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s17, #1344
    v.add        v2, v1, v3
    v.st.w       [s5, #0], v2
    s.addi       s5, s6, #320
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s17, #1408
    v.add        v2, v1, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s6, #384
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s17, #1472
    v.add        v2, v1, v3
    v.st.w       [s19, #0], v2
    s.addi       s19, s6, #448
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s17, #1536
    v.add        v2, v1, v3
    v.st.w       [s21, #0], v2
    s.addi       s21, s6, #512
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s17, #1600
    v.add        v2, v1, v3
    v.st.w       [s5, #0], v2
    s.addi       s5, s6, #576
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s17, #1664
    v.add        v2, v1, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s6, #640
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s17, #1728
    v.add        v2, v1, v3
    v.st.w       [s19, #0], v2
    s.addi       s19, s6, #704
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s17, #1792
    v.add        v2, v1, v3
    v.st.w       [s21, #0], v2
    s.addi       s21, s6, #768
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s17, #1856
    v.add        v2, v1, v3
    v.st.w       [s5, #0], v2
    s.addi       s5, s6, #832
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s17, #1920
    v.add        v2, v1, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s6, #896
    s.addi       s24, s6, #960
    v.ld.w       v1, [s14, #0]
    s.addi       s6, s17, #1984
    v.add        v2, v1, v3
    v.st.w       [s19, #0], v2
    s.addi       s14, s17, #5632
    v.ld.w       v1, [s23, #0]
    s.addi       s19, s17, #7680
    v.add        v2, v1, v3
    v.st.w       [s21, #0], v2
    s.addi       s21, s17, #5696
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s19, #64
    v.add        v2, v1, v3
    v.st.w       [s5, #0], v2
    s.addi       s5, s17, #5760
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s19, #128
    v.add        v2, v1, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s17, #5824
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s19, #192
    v.add        v2, v1, v3
    v.st.w       [s24, #0], v2
    fence.acq_rel.device
    s.addi       s23, s17, #5888
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s19, #256
    v.st.w       [s19, #0], v1
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s17, #5952
    v.st.w       [s22, #0], v1
    s.addi       s22, s19, #320
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #6016
    v.st.w       [s12, #0], v1
    s.addi       s12, s19, #384
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #6080
    v.st.w       [s6, #0], v1
    s.addi       s6, s19, #448
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s17, #6144
    v.st.w       [s14, #0], v1
    s.addi       s14, s19, #512
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s17, #6208
    v.st.w       [s22, #0], v1
    s.addi       s22, s19, #576
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #6272
    v.st.w       [s12, #0], v1
    s.addi       s12, s19, #640
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #6336
    v.st.w       [s6, #0], v1
    s.addi       s6, s19, #704
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s17, #6400
    v.st.w       [s14, #0], v1
    s.addi       s14, s19, #768
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s17, #6464
    v.st.w       [s22, #0], v1
    s.addi       s22, s19, #832
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #6528
    v.st.w       [s12, #0], v1
    s.addi       s12, s19, #896
    s.addi       s24, s19, #960
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #6592
    v.st.w       [s6, #0], v1
    s.addi       s6, s17, #6656
    v.ld.w       v1, [s23, #0]
    s.addi       s19, s17, #8704
    v.st.w       [s14, #0], v1
    s.addi       s14, s17, #6720
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s19, #64
    v.st.w       [s22, #0], v1
    s.addi       s22, s17, #6784
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s19, #128
    v.st.w       [s12, #0], v1
    s.addi       s12, s17, #6848
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s19, #192
    v.st.w       [s24, #0], v1
    fence.acq_rel.device
    s.addi       s23, s17, #6912
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s19, #256
    v.st.w       [s19, #0], v1
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s17, #6976
    v.st.w       [s21, #0], v1
    s.addi       s21, s19, #320
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s17, #7040
    v.st.w       [s5, #0], v1
    s.addi       s5, s19, #384
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s17, #7104
    v.st.w       [s15, #0], v1
    s.addi       s15, s19, #448
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s17, #7168
    v.st.w       [s6, #0], v1
    s.addi       s6, s19, #512
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s17, #7232
    v.st.w       [s21, #0], v1
    s.addi       s21, s19, #576
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s17, #7296
    v.st.w       [s5, #0], v1
    s.addi       s5, s19, #640
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s17, #7360
    v.st.w       [s15, #0], v1
    s.addi       s15, s19, #704
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s17, #7424
    v.st.w       [s6, #0], v1
    s.addi       s6, s19, #768
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s17, #7488
    v.st.w       [s21, #0], v1
    s.addi       s21, s19, #832
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s17, #7552
    v.st.w       [s5, #0], v1
    s.addi       s5, s19, #896
    s.addi       s24, s19, #960
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s17, #7616
    v.st.w       [s15, #0], v1
    s.addi       s15, s17, #7680
    v.ld.w       v1, [s23, #0]
    s.addi       s19, s17, #0
    v.st.w       [s6, #0], v1
    s.addi       s6, s17, #7744
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s17, #64
    v.st.w       [s21, #0], v1
    s.addi       s21, s17, #7808
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s17, #128
    v.st.w       [s5, #0], v1
    s.addi       s5, s17, #7872
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s17, #192
    v.st.w       [s24, #0], v1
    fence.acq_rel.device
    s.addi       s23, s17, #7936
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #256
    v.st.w       [s19, #0], v1
    s.addi       s19, s17, #8000
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s17, #320
    v.st.w       [s14, #0], v1
    s.addi       s14, s17, #8064
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s17, #384
    v.st.w       [s22, #0], v1
    s.addi       s22, s17, #8128
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #448
    v.st.w       [s12, #0], v1
    s.addi       s12, s17, #8192
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s17, #512
    v.st.w       [s15, #0], v1
    s.addi       s15, s17, #8256
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s17, #576
    v.st.w       [s6, #0], v1
    s.addi       s6, s17, #8320
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s17, #640
    v.st.w       [s21, #0], v1
    s.addi       s21, s17, #8384
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s17, #704
    v.st.w       [s5, #0], v1
    s.addi       s5, s17, #8448
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s17, #768
    v.st.w       [s23, #0], v1
    s.addi       s23, s17, #8512
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #832
    v.st.w       [s19, #0], v1
    s.addi       s19, s17, #8576
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s17, #896
    v.st.w       [s14, #0], v1
    s.addi       s14, s17, #8640
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s17, #960
    v.st.w       [s22, #0], v1
    s.addi       s22, s17, #8704
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #1024
    v.st.w       [s12, #0], v1
    s.addi       s12, s17, #8768
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s17, #1088
    v.st.w       [s15, #0], v1
    s.addi       s15, s17, #8832
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s17, #1152
    v.st.w       [s6, #0], v1
    s.addi       s6, s17, #8896
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s17, #1216
    v.st.w       [s21, #0], v1
    fence.acq_rel.device
    s.addi       s21, s17, #8960
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s17, #1280
    v.st.w       [s5, #0], v1
    s.addi       s5, s17, #9024
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s17, #1344
    v.st.w       [s23, #0], v1
    s.addi       s23, s17, #9088
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #1408
    v.st.w       [s19, #0], v1
    s.addi       s19, s17, #9152
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s17, #1472
    v.st.w       [s14, #0], v1
    s.addi       s14, s17, #9216
    s.add        s24, s20, s3
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s17, #1536
    v.st.w       [s22, #0], v1
    s.addi       s22, s17, #9280
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #1600
    v.st.w       [s12, #0], v1
    s.addi       s12, s17, #9344
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s17, #1664
    v.st.w       [s15, #0], v1
    s.addi       s15, s17, #9408
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s17, #1728
    v.st.w       [s6, #0], v1
    s.addi       s6, s17, #9472
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s17, #1792
    v.st.w       [s21, #0], v1
    s.addi       s21, s17, #9536
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s17, #1856
    v.st.w       [s5, #0], v1
    s.addi       s5, s17, #9600
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s17, #1920
    v.st.w       [s23, #0], v1
    s.addi       s23, s17, #9664
    s.addi       s25, s17, #1984
    v.ld.w       v1, [s15, #0]
    s.movz       s15, #1
    v.st.w       [s19, #0], v1
    v.ld.w       v1, [s6, #0]
    v.st.w       [s14, #0], v1
    v.ld.w       v1, [s21, #0]
    v.st.w       [s22, #0], v1
    v.ld.w       v1, [s5, #0]
    v.st.w       [s12, #0], v1
    v.ld.w       v1, [s23, #0]
    v.st.w       [s25, #0], v1
    fence.acq_rel.device
    s.mov        s20, s24
    br.nz        s15, for_5
endfor_6:
    .li       s2, #262144
    s.movz       s3, #0
    s.mul        s5, s13, s2
    s.muli       s2, s8, #2                      // a runtime tile origin, x2
    s.movz       s6, #0
    s.add        s11, s3, s8                     // the tile origin
    s.muli       s3, s9, #1024                   // a runtime tile origin, x1024
    s.add        s8, s6, s9                      // the tile origin
    s.movz       s6, #512
    v.splat      v1, s11
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s9, #0
    s.muli       s11, s5, #2                     // a runtime tile origin, x2
    v.splat      v2, s8
    v.splat      v3, s6
    v.add        v4, v0, v1
    v.splat      v0, s6
    s.add        s5, s7, s2                      // the tile origin
    a.vread      v1, a0, s9
    v.splat      v5, s13
    v.splat      v6, s1
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v4, v0
    s.add        s1, s5, s3                      // the tile origin
    vf.cvt.f32.f16 v0, v1
    p.and        p3, p1, p2
    v.cmp.lt     p1, v5, v6
    s.addi       s2, s8, #1
    s.add        s3, s1, s11                     // the tile origin
    p.and        p4, p3, p1
    s.movz       s1, #1
    v.splat      v1, s2
    @p4 v.st.h       [s3, #0], v0
    a.vread      v0, a0, s1
    v.cmp.lt     p3, v1, v3
    vf.cvt.f32.f16 v1, v0
    p.and        p4, p3, p2
    s.addi       s1, s8, #2
    s.addi       s2, s3, #1024                   // row 1
    p.and        p3, p4, p1
    s.movz       s5, #2
    v.splat      v0, s1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p3, v0, v3
    vf.cvt.f32.f16 v0, v1
    p.and        p4, p3, p2
    s.addi       s1, s8, #3
    s.addi       s2, s3, #2048                   // row 2
    p.and        p3, p4, p1
    s.movz       s5, #3
    v.splat      v1, s1
    @p3 v.st.h       [s2, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p3, v1, v3
    vf.cvt.f32.f16 v1, v0
    p.and        p4, p3, p2
    s.addi       s1, s8, #4
    s.addi       s2, s3, #3072                   // row 3
    p.and        p3, p4, p1
    s.movz       s5, #4
    v.splat      v0, s1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p3, v0, v3
    vf.cvt.f32.f16 v0, v1
    p.and        p4, p3, p2
    s.addi       s1, s8, #5
    s.addi       s2, s3, #4096                   // row 4
    p.and        p3, p4, p1
    s.movz       s5, #5
    v.splat      v1, s1
    @p3 v.st.h       [s2, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p3, v1, v3
    vf.cvt.f32.f16 v1, v0
    p.and        p4, p3, p2
    s.addi       s1, s8, #6
    s.addi       s2, s3, #5120                   // row 5
    p.and        p3, p4, p1
    s.movz       s5, #6
    v.splat      v0, s1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p3, v0, v3
    vf.cvt.f32.f16 v0, v1
    p.and        p4, p3, p2
    s.addi       s1, s8, #7
    s.addi       s2, s3, #6144                   // row 6
    p.and        p3, p4, p1
    s.movz       s5, #7
    v.splat      v1, s1
    @p3 v.st.h       [s2, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p3, v1, v3
    vf.cvt.f32.f16 v1, v0
    p.and        p4, p3, p2
    s.addi       s1, s8, #8
    s.addi       s2, s3, #7168                   // row 7
    p.and        p3, p4, p1
    s.movz       s5, #8
    v.splat      v0, s1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p3, v0, v3
    vf.cvt.f32.f16 v0, v1
    p.and        p4, p3, p2
    s.addi       s1, s8, #9
    s.addi       s2, s3, #8192                   // row 8
    p.and        p3, p4, p1
    s.movz       s5, #9
    v.splat      v1, s1
    @p3 v.st.h       [s2, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p3, v1, v3
    vf.cvt.f32.f16 v1, v0
    p.and        p4, p3, p2
    s.addi       s1, s8, #10
    s.addi       s2, s3, #9216                   // row 9
    p.and        p3, p4, p1
    s.movz       s5, #10
    v.splat      v0, s1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p3, v0, v3
    vf.cvt.f32.f16 v0, v1
    p.and        p4, p3, p2
    s.addi       s1, s8, #11
    s.addi       s2, s3, #10240                  // row 10
    p.and        p3, p4, p1
    s.movz       s5, #11
    v.splat      v1, s1
    @p3 v.st.h       [s2, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p3, v1, v3
    vf.cvt.f32.f16 v1, v0
    p.and        p4, p3, p2
    s.addi       s1, s8, #12
    s.addi       s2, s3, #11264                  // row 11
    p.and        p3, p4, p1
    s.movz       s5, #12
    v.splat      v0, s1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p3, v0, v3
    vf.cvt.f32.f16 v0, v1
    p.and        p4, p3, p2
    s.addi       s1, s8, #13
    s.addi       s2, s3, #12288                  // row 12
    p.and        p3, p4, p1
    s.movz       s5, #13
    v.splat      v1, s1
    @p3 v.st.h       [s2, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p3, v1, v3
    vf.cvt.f32.f16 v1, v0
    p.and        p4, p3, p2
    s.addi       s1, s8, #14
    s.addi       s2, s3, #13312                  // row 13
    p.and        p3, p4, p1
    s.movz       s5, #14
    v.splat      v0, s1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p3, v0, v3
    vf.cvt.f32.f16 v0, v1
    p.and        p4, p3, p2
    s.addi       s1, s8, #15
    s.addi       s2, s3, #14336                  // row 14
    p.and        p3, p4, p1
    s.movz       s5, #15
    v.splat      v1, s1
    @p3 v.st.h       [s2, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p3, v1, v3
    vf.cvt.f32.f16 v1, v0
    p.and        p4, p3, p2
    s.addi       s1, s3, #15360                  // row 15
    p.and        p2, p4, p1
    @p2 v.st.h       [s1, #0], v1
__rctx_next:
    exit
