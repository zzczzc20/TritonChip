#!/bin/bash
# val.sh NAME CORES SUBCMD args... : qwen_tnca_layers.py on tnca (SystemC/TLM, 8 GiB window, x8 profile, IEEE div, fast DRAM)
N=$1; CORES=$2; shift 2
W=$HOME/r41-sw-work/val; O=$W/$N; T=$HOME/r41-sw-work/tree-val
rm -rf $O; mkdir -p $O
source ~/tc_env/env.sh >/dev/null 2>&1
export CUDA_VISIBLE_DEVICES= HF_HOME=$HOME/flux-hf HF_HUB_OFFLINE=0 QWEN_FP8_VIEW_DIR=$HOME/qwen-work/snapview
export OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 TORCHINDUCTOR_COMPILE_THREADS=1 PYTHONDONTWRITEBYTECODE=1
export TNCA_BACKEND=systemc-tlm-grid TNCA_TLM_BINARY=$W/tnca-chip TNCA_TLM_MEMORY_BYTES=0x200000000
export TNCA_PROFILE=core-vrf-sync-v5-x8 TNCA_IEEE_DIV=1 TNCA_DRAM_PATH=fast TNCA_TLM_UNTIMED_COLD=${UNTIMED:-0}
export TNCA_TORCH_DEVICE=native TNCA_INDEX_OPT=1 TNCA_TRITON=1 TNCA_KERNEL_DUMP=1 TNCA_DUMP_DIR=$O/dump
export TRITON_CACHE_DIR=$O/triton TORCHINDUCTOR_CACHE_DIR=$O/inductor TORCH_EXTENSIONS_DIR=$W/ext TNCA_TLM_OUT=$O/tlm
export TNCA_DEADLINE=40000000000 TNCA_HOST_TIMEOUT=40000
cd $O && /usr/bin/time -v taskset -c $CORES nice ~/flux-venv/bin/python -I -u $T/tools/models/qwen_tnca_layers.py "$@" --tnca-tree $T --out $O/result.json > $O/log 2>&1
echo EXIT=$? >> $O/log
