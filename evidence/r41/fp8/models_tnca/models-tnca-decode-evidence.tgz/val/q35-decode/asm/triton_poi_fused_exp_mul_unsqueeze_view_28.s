    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #7
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    @p1 v.sel        v4, v1, v3
    s.rdspecial  s2, arg_base
    v.lshr       v1, v4, v0
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.sub        v0, v2, v1
    s.shli       s4, s1, #2                      // element offset -> bytes (x4)
    s.ld.d       s1, [s2, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    @p1 v.sel        v3, v0, v1
    s.add        s5, s3, s4                      // &in_ptr0[...]
    v.ld.gather.w v0, [s1, v3]                   // index is in elements (ISA sec 9.1)
    v.movi       v1, #128
    v.sub        v3, v2, v1
    v.cmp.lt     p1, v1, v2
    @p1 v.sel        v2, v3, v1
    v.ld.w       v1, [s5, #0]
    s.ld.d       s1, [s2, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    vf.mul       v2, v1, v0
    s.add        s2, s1, s4                      // &out_ptr0[...]
    v.st.w       [s2, #0], v2
__rctx_next:
    exit
