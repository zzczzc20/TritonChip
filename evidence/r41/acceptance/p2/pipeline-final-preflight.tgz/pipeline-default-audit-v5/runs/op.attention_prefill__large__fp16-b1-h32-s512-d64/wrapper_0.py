# AOT ID: ['0_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/op.attention_prefill__large__fp16-b1-h32-s512-d64/inductor_cache/ve/cve5dfprgrrucsrprbuvpgj5iyziskdgd7zg5xzm42syibf3runw.py
# Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   scaled_dot_product_attention => convert_element_type, mul
# Graph fragment:
#   %arg0_1 : Tensor "f16[1, 32, 512, 64][1048576, 32768, 64, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %convert_element_type : Tensor "f32[1, 32, 512, 64][1048576, 32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg0_1, torch.float32), kwargs = {})
#   %mul : Tensor "f32[1, 32, 512, 64][1048576, 32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%convert_element_type, 0.3535533905932738), kwargs = {})
#   return %expand
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_0 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1048576}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 10485760}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_0(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1048576
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), None).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tl.full([1], 0.3535533905932738, tl.float32)
    tmp3 = tmp1 * tmp2
    tl.store(out_ptr0 + (x0), tmp3, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/op.attention_prefill__large__fp16-b1-h32-s512-d64/inductor_cache/m2/cm25xt7uvxffkevzf46y6ju5urfffav4xzoqhin2rvkwgrkx63xk.py
# Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   scaled_dot_product_attention => convert_element_type_1, mul_1, permute
# Graph fragment:
#   %arg1_1 : Tensor "f16[1, 32, 512, 64][1048576, 32768, 64, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %convert_element_type_1 : Tensor "f32[1, 32, 512, 64][1048576, 32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg1_1, torch.float32), kwargs = {})
#   %permute : Tensor "f32[1, 32, 64, 512][1048576, 32768, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_1, [0, 1, 3, 2]), kwargs = {})
#   %mul_1 : Tensor "f32[1, 32, 64, 512][1048576, 32768, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%permute, 0.3535533905932738), kwargs = {})
#   return %expand_1
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_1 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'y': 2048, 'x': 512}, tile_hint=TileHint.SQUARE,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp32', 'ynumel': 'i32', 'xnumel': 'i32', 'YBLOCK': 'constexpr', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid2D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'y': 2097152, 'x': 8388608}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_1(in_ptr0, out_ptr0, ynumel, xnumel, YBLOCK : tl.constexpr, XBLOCK : tl.constexpr):
    ynumel = 2048
    xnumel = 512
    yoffset = tl.program_id(1) * YBLOCK
    yindex = yoffset + tl.arange(0, YBLOCK)[:, None]
    ymask = tl.full([YBLOCK], True, tl.int1)[:, None]
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[None, :]
    xmask = xindex < xnumel
    x2 = xindex
    y0 = (yindex % 64)
    y1 = yindex // 64
    y3 = yindex
    tmp0 = tl.load(in_ptr0 + (y0 + 64*x2 + 32768*y1), xmask).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tl.full([1, 1], 0.3535533905932738, tl.float32)
    tmp3 = tmp1 * tmp2
    tl.store(out_ptr0 + (x2 + 512*y3), tmp3, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/op.attention_prefill__large__fp16-b1-h32-s512-d64/inductor_cache/nj/cnjoial6kggmy6d2ob6b2hcucktkuhwkkzs24edqpfhb3p7jh6ll.py
# Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   scaled_dot_product_attention => bmm, convert_element_type, convert_element_type_1, mul, mul_1, permute, view, view_1
# Graph fragment:
#   %expand : Tensor "f32[1, 32, 512, 64][1048576, 32768, 64, 1]tnca:0" = PlaceHolder[target=expand]
#   %expand_1 : Tensor "f32[1, 32, 64, 512][1048576, 32768, 512, 1]tnca:0" = PlaceHolder[target=expand_1]
#   %convert_element_type : Tensor "f32[1, 32, 512, 64][1048576, 32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg0_1, torch.float32), kwargs = {})
#   %mul : Tensor "f32[1, 32, 512, 64][1048576, 32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%convert_element_type, 0.3535533905932738), kwargs = {})
#   %view : Tensor "f32[32, 512, 64][32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand, [32, 512, 64]), kwargs = {})
#   %convert_element_type_1 : Tensor "f32[1, 32, 512, 64][1048576, 32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg1_1, torch.float32), kwargs = {})
#   %permute : Tensor "f32[1, 32, 64, 512][1048576, 32768, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_1, [0, 1, 3, 2]), kwargs = {})
#   %mul_1 : Tensor "f32[1, 32, 64, 512][1048576, 32768, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%permute, 0.3535533905932738), kwargs = {})
#   %view_1 : Tensor "f32[32, 64, 512][32768, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_1, [32, 64, 512]), kwargs = {})
#   %bmm : Tensor "f32[32, 512, 512][262144, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view, %view_1), kwargs = {})
#   return %bmm
triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_2 = async_compile.triton('triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp32', 'arg_B': '*fp32', 'out_ptr0': '*fp32'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_2', 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_2(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 512
    N = 512
    K = 64
    BATCH = 32

    stride_aq = 32768
    stride_am = 64
    stride_ak = 1

    stride_bq = 32768
    stride_bk = 512
    stride_bn = 1

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        ram = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        ram = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        rbn = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        rbn = rn % N

    rk = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)

    # Reconstruct batch index from grid_y/grid_z split (handles batch > 65535)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    # Clamp to valid range for safe pointer arithmetic; out-of-bounds CTAs are
    # masked off at the store below.
    idx_q_clamped = tl.minimum(idx_q, BATCH - 1)
    A = A + (ram[:, None] * stride_am + rk[None, :] * stride_ak + idx_q_clamped*stride_aq)
    B = B + (rk[:, None] * stride_bk + rbn[None, :] * stride_bn + idx_q_clamped*stride_bq)

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)
    for k in range(K, 0, -BLOCK_K):
        if EVEN_K:
            a = tl.load(A)
            b = tl.load(B)
        else:
            a = tl.load(A, mask=rk[None, :] < k, other=0.)
            b = tl.load(B, mask=rk[:, None] < k, other=0.)
        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32)
        A += BLOCK_K * stride_ak
        B += BLOCK_K * stride_bk

    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N) & (idx_q < BATCH)

    # inductor generates a suffix
    xindex = idx_n + 512*idx_m + 262144*idx_q
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/op.attention_prefill__large__fp16-b1-h32-s512-d64/inductor_cache/zk/czkaq45n4ztce2drz5556e5v5g5ofdv4dhhm2uw2w2rcxgcxbstr.py
# Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   scaled_dot_product_attention => add, amax, any_1, div, eq, exp, full_default, full_default_1, full_default_2, full_default_3, iota, iota_1, le, logical_and, logical_not, logical_not_1, sub, sub_1, sum_1, unsqueeze, unsqueeze_1, view_2, where, where_1
# Graph fragment:
#   %bmm : Tensor "f32[32, 512, 512][262144, 512, 1]tnca:0" = PlaceHolder[target=bmm]
#   %amax : Tensor "f32[1, 32, 512, 1][16384, 512, 1, 16384]tnca:0" = PlaceHolder[target=amax]
#   %exp : Tensor "f32[1, 32, 512, 512][8388608, 262144, 512, 1]tnca:0" = PlaceHolder[target=exp]
#   %any_1 : Tensor "b8[1, 32, 512, 1][16384, 512, 1, 16384]tnca:0" = PlaceHolder[target=any_1]
#   %sum_1 : Tensor "f32[1, 32, 512, 1][16384, 512, 1, 16384]tnca:0" = PlaceHolder[target=sum_1]
#   %view_2 : Tensor "f32[1, 32, 512, 512][8388608, 262144, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm, [1, 32, 512, 512]), kwargs = {})
#   %iota : Tensor "i64[512][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (512,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %unsqueeze : Tensor "i64[1, 512][512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%iota, -2), kwargs = {})
#   %iota_1 : Tensor "i64[512][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (512,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %unsqueeze_1 : Tensor "i64[512, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%iota_1, -1), kwargs = {})
#   %sub : Tensor "i64[512, 512][512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%unsqueeze, %unsqueeze_1), kwargs = {})
#   %le : Tensor "b8[512, 512][512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.le.Scalar](args = (%sub, 0), kwargs = {})
#   %full_default : Tensor "b8[512, 512][512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([512, 512], True), kwargs = {dtype: torch.bool, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %logical_and : Tensor "b8[512, 512][512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_and.default](args = (%le, %full_default), kwargs = {})
#   %full_default_2 : Tensor "f32[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([], 0.0), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %full_default_1 : Tensor "f32[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([], -inf), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %where : Tensor "f32[512, 512][512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_and, %full_default_2, %full_default_1), kwargs = {})
#   %add : Tensor "f32[1, 32, 512, 512][8388608, 262144, 512, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%view_2, %where), kwargs = {})
#   %eq : Tensor "b8[1, 32, 512, 512][8388608, 262144, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.eq.Scalar](args = (%add, -inf), kwargs = {})
#   %logical_not : Tensor "b8[1, 32, 512, 512][8388608, 262144, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%eq,), kwargs = {})
#   %any_1 : Tensor "b8[1, 32, 512, 1][16384, 512, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.any.dim](args = (%logical_not, -1, True), kwargs = {})
#   %logical_not_1 : Tensor "b8[1, 32, 512, 1][16384, 512, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%any_1,), kwargs = {})
#   %full_default_3 : Tensor "f32[1, 32, 512, 512][8388608, 262144, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([1, 32, 512, 512], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %amax : Tensor "f32[1, 32, 512, 1][16384, 512, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.amax.default](args = (%add, [-1], True), kwargs = {})
#   %sub_1 : Tensor "f32[1, 32, 512, 512][8388608, 262144, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%add, %amax), kwargs = {})
#   %exp : Tensor "f32[1, 32, 512, 512][8388608, 262144, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.exp.default](args = (%sub_1,), kwargs = {})
#   %sum_1 : Tensor "f32[1, 32, 512, 1][16384, 512, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%exp, [-1], True), kwargs = {})
#   %div : Tensor "f32[1, 32, 512, 512][8388608, 262144, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp, %sum_1), kwargs = {})
#   %where_1 : Tensor "f32[1, 32, 512, 512][8388608, 262144, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_not_1, %full_default_3, %div), kwargs = {})
#   return %any_1,%amax,%exp,%sum_1,%expand_2
triton_red_fused__scaled_dot_product_flash_attention_for_cpu_3 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16384, 'r0_': 512},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu_3', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 3, 'num_store': 2, 'num_reduction': 3, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 100663296}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 4}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu_3(in_out_ptr0, in_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 16384
    XBLOCK: tl.constexpr = 1
    r0_numel = 512
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x3 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[16384, 512], strides=[512, 1], block_shape=[XBLOCK, R0_BLOCK])
    x0 = (xindex % 512)
    _tmp16 = tl.full([R0_BLOCK], False, tl.int1)
    _tmp20 = tl.full([R0_BLOCK], float("-inf"), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp1 = (r0_2 + ((-1)*x0)).to(tl.int64)
        tmp2 = (tmp1).to(tl.int64)
        tmp3 = tl.full([1], 0, tl.int64)
        tmp4 = tmp2 <= tmp3
        tmp5 = tl.full([1], True, tl.int1)
        tmp6 = tmp4 & tmp5
        tmp7 = tl.full([1], 0.0, tl.float32)
        tmp8 = tl.full([1], float("-inf"), tl.float32)
        tmp9 = tl.where(tmp6, tmp7, tmp8)
        tmp10 = tmp0 + tmp9
        tmp11 = tmp10 == tmp8
        tmp12 = tmp11 == 0
        tmp13 = tmp12.to(tl.int64)
        tmp14 = (tmp13 != 0)
        tmp15 = tl.broadcast_to(tmp14, [R0_BLOCK])
        tmp17 = _tmp16 | tmp15
        _tmp16 = tl.where(r0_mask, tmp17, _tmp16)
        tmp19 = tl.broadcast_to(tmp10, [R0_BLOCK])
        tmp21 = tl.maximum(_tmp20, tmp19, tl.PropagateNan.ALL)
        _tmp20 = tl.where(r0_mask, tmp21, _tmp20)
    tmp18 = _tmp16.to(tl.int8)
    tmp16 = triton_helpers.promote_to_tensor(triton_helpers.any(tmp18, 0))
    tmp20 = triton_helpers.promote_to_tensor(triton_helpers.max2(_tmp20, 0))
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[16384, 512], strides=[512, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp36 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp22 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp23 = (r0_2 + ((-1)*x0)).to(tl.int64)
        tmp24 = (tmp23).to(tl.int64)
        tmp25 = tl.full([1], 0, tl.int64)
        tmp26 = tmp24 <= tmp25
        tmp27 = tl.full([1], True, tl.int1)
        tmp28 = tmp26 & tmp27
        tmp29 = tl.full([1], 0.0, tl.float32)
        tmp30 = tl.full([1], float("-inf"), tl.float32)
        tmp31 = tl.where(tmp28, tmp29, tmp30)
        tmp32 = tmp22 + tmp31
        tmp33 = tmp32 - tmp20
        tmp34 = libdevice.exp(tmp33)
        tmp35 = tl.broadcast_to(tmp34, [R0_BLOCK])
        tmp37 = _tmp36 + tmp35
        _tmp36 = tl.where(r0_mask, tmp37, _tmp36)
        tl.store(in_out_ptr0 + (r0_2 + 512*x3), tmp34, r0_mask)
    tmp36 = triton_helpers.promote_to_tensor(tl.sum(_tmp36, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_out_ptr0, shape=[16384, 512], strides=[512, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tl.debug_barrier()
        tmp39 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp38 = tmp16 == 0
        tmp40 = (tmp39 / tmp36)
        tmp41 = tl.full([1], 0.0, tl.float32)
        tmp42 = tl.where(tmp38, tmp41, tmp40)
        tl.store(in_out_ptr0 + (r0_2 + 512*x3), tmp42, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/op.attention_prefill__large__fp16-b1-h32-s512-d64/inductor_cache/uv/cuvjdm63eny3cpjvs76vqqcso3fq7urrmbj3f5w27r6o336mw3ho.py
# Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   scaled_dot_product_attention => convert_element_type_2
# Graph fragment:
#   %arg2_1 : Tensor "f16[1, 32, 512, 64][1048576, 32768, 64, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %convert_element_type_2 : Tensor "f32[1, 32, 512, 64][1048576, 32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg2_1, torch.float32), kwargs = {})
#   return %expand_3
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_4 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_4', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1048576}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_4', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 10485760}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_4(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1048576
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), None).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tl.store(out_ptr0 + (x0), tmp1, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/op.attention_prefill__large__fp16-b1-h32-s512-d64/inductor_cache/ke/ckebytb6cz7fufyh62ffh4ribzmykcbkrnu44x4lkbo43b54yu6o.py
# Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   scaled_dot_product_attention => bmm_1, convert_element_type_2, div, full_default_3, logical_not_1, view_3, view_4, where_1
# Graph fragment:
#   %expand_2 : Tensor "f32[1, 32, 512, 512][8388608, 262144, 512, 1]tnca:0" = PlaceHolder[target=expand_2]
#   %expand_3 : Tensor "f32[1, 32, 512, 64][1048576, 32768, 64, 1]tnca:0" = PlaceHolder[target=expand_3]
#   %logical_not_1 : Tensor "b8[1, 32, 512, 1][16384, 512, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%any_1,), kwargs = {})
#   %full_default_3 : Tensor "f32[1, 32, 512, 512][8388608, 262144, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([1, 32, 512, 512], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %div : Tensor "f32[1, 32, 512, 512][8388608, 262144, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp, %sum_1), kwargs = {})
#   %where_1 : Tensor "f32[1, 32, 512, 512][8388608, 262144, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_not_1, %full_default_3, %div), kwargs = {})
#   %view_3 : Tensor "f32[32, 512, 512][262144, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_2, [32, 512, 512]), kwargs = {})
#   %convert_element_type_2 : Tensor "f32[1, 32, 512, 64][1048576, 32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg2_1, torch.float32), kwargs = {})
#   %view_4 : Tensor "f32[32, 512, 64][32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_3, [32, 512, 64]), kwargs = {})
#   %bmm_1 : Tensor "f32[32, 512, 64][32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_3, %view_4), kwargs = {})
#   return %bmm_1
triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_5 = async_compile.triton('triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_5', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp32', 'arg_B': '*fp32', 'out_ptr0': '*fp32'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_5', 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_5(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 512
    N = 64
    K = 512
    BATCH = 32

    stride_aq = 262144
    stride_am = 512
    stride_ak = 1

    stride_bq = 32768
    stride_bk = 64
    stride_bn = 1

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        ram = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        ram = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        rbn = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        rbn = rn % N

    rk = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)

    # Reconstruct batch index from grid_y/grid_z split (handles batch > 65535)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    # Clamp to valid range for safe pointer arithmetic; out-of-bounds CTAs are
    # masked off at the store below.
    idx_q_clamped = tl.minimum(idx_q, BATCH - 1)
    A = A + (ram[:, None] * stride_am + rk[None, :] * stride_ak + idx_q_clamped*stride_aq)
    B = B + (rk[:, None] * stride_bk + rbn[None, :] * stride_bn + idx_q_clamped*stride_bq)

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)
    for k in range(K, 0, -BLOCK_K):
        if EVEN_K:
            a = tl.load(A)
            b = tl.load(B)
        else:
            a = tl.load(A, mask=rk[None, :] < k, other=0.)
            b = tl.load(B, mask=rk[:, None] < k, other=0.)
        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32)
        A += BLOCK_K * stride_ak
        B += BLOCK_K * stride_bk

    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N) & (idx_q < BATCH)

    # inductor generates a suffix
    xindex = idx_n + 64*idx_m + 32768*idx_q
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/op.attention_prefill__large__fp16-b1-h32-s512-d64/inductor_cache/xn/cxndvvfje7ajygtb62rphxt6rgeizbhwni5fidyzwfwybsvtok4d.py
# Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   scaled_dot_product_attention => clone, convert_element_type_3, permute_1, view_5
# Graph fragment:
#   %bmm_1 : Tensor "f32[32, 512, 64][32768, 64, 1]tnca:0" = PlaceHolder[target=bmm_1]
#   %view_5 : Tensor "f32[1, 32, 512, 64][1048576, 32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_1, [1, 32, 512, 64]), kwargs = {})
#   %convert_element_type_3 : Tensor "f16[1, 32, 512, 64][1048576, 32768, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_5, torch.float16), kwargs = {})
#   %permute_1 : Tensor "f16[512, 1, 32, 64][64, 1048576, 32768, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_3, [2, 0, 1, 3]), kwargs = {})
#   %clone : Tensor "f16[512, 1, 32, 64][2048, 2048, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%permute_1,), kwargs = {memory_format: torch.contiguous_format})
#   return %clone
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_6 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_6', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1048576}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_6', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 8388608}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_6(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1048576
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 64)
    x1 = ((xindex // 64) % 32)
    x2 = xindex // 2048
    x3 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 64*x2 + 32768*x1), None)
    tmp1 = tmp0.to(tl.float32)
    tl.store(out_ptr0 + (x3), tmp1, None)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1 = args
        args.clear()
        assert_size_stride(arg0_1, (1, 32, 512, 64), (1048576, 32768, 64, 1), 'input')
        buf0 = empty_strided((1, 32, 512, 64), (1048576, 32768, 64, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_0.run(arg0_1, buf0, 1048576, stream=raw_stream0)
        del arg0_1
        assert_size_stride(arg1_1, (1, 32, 512, 64), (1048576, 32768, 64, 1), 'input')
        buf1 = empty_strided((1, 32, 64, 512), (1048576, 32768, 512, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_1.run(arg1_1, buf1, 2048, 512, stream=raw_stream0)
        del arg1_1
        buf2 = empty_strided((32, 512, 512), (262144, 512, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_2.run(buf0, buf1, buf2, 1024, 32, 1, stream=raw_stream0)
        del buf0
        del buf1
        buf5 = empty_strided((1, 32, 512, 512), (8388608, 262144, 512, 1), device='tnca', dtype=torch.float32)
        buf7 = buf5; del buf5  # reuse
        # Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_3.run(buf7, buf2, 16384, 512, stream=raw_stream0)
        del buf2
        assert_size_stride(arg2_1, (1, 32, 512, 64), (1048576, 32768, 64, 1), 'input')
        buf8 = empty_strided((1, 32, 512, 64), (1048576, 32768, 64, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_4.run(arg2_1, buf8, 1048576, stream=raw_stream0)
        del arg2_1
        buf9 = empty_strided((32, 512, 64), (32768, 64, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_5.run(buf7, buf8, buf9, 128, 32, 1, stream=raw_stream0)
        del buf7
        del buf8
        buf10 = empty_strided((512, 1, 32, 64), (2048, 1, 64, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_6.run(buf9, buf10, 1048576, stream=raw_stream0)
        return (reinterpret_tensor(buf10, (1, 32, 512, 64), (2048, 64, 2048, 1), 0), )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((1, 32, 512, 64), (1048576, 32768, 64, 1), device='tnca:0', dtype=torch.float16)
    arg1_1 = rand_strided((1, 32, 512, 64), (1048576, 32768, 64, 1), device='tnca:0', dtype=torch.float16)
    arg2_1 = rand_strided((1, 32, 512, 64), (1048576, 32768, 64, 1), device='tnca:0', dtype=torch.float16)
    return [arg0_1, arg1_1, arg2_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
