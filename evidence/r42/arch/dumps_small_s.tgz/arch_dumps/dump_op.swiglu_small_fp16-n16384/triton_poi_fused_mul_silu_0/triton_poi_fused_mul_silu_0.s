    s.rdspecial  s1, arg_base
    s.movz       s2, #256
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #0
    s.rdspecial  s5, role_id
    s.rdspecial  s6, npid.x
    s.ld.d       s7, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s8, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
__rctx_program:
    // tiled element-wise program: 256 lanes as 2 tiles of 128 (3 tensor-engine transfers, one load buffer(s))
    s.mul        s1, s5, s2
    s.addi       s9, s4, #0
    .li       s10, #1069066811
    v.splat      v0, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s10, #1060205080
    v.splat      v1, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s10, #1065353216
    v.splat      v2, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
tiles_1:
    // tile 1 of the iteration: lanes t0 + 128
    s.addi       s10, s9, #128
    // tile 0 of the iteration: lanes t0 + 0
    s.add        s11, s1, s9
    s.add        s12, s1, s10
    s.shli       s10, s11, #1
    s.shli       s11, s12, #1
    s.add        s12, s3, s10
    s.add        s13, s3, s11
    v.ld.h       v3, [s12, #0]
    s.add        s14, s7, s10
    s.add        s15, s7, s11
    v.ld.h       v4, [s12, #32]
    vf.cvt.f16.f32 v5, v3
    v.ld.h       v3, [s12, #64]
    vf.cvt.f16.f32 v6, v4
    v.ld.h       v4, [s12, #96]
    vf.cvt.f16.f32 v7, v3
    v.ld.h       v3, [s12, #128]
    vf.cvt.f16.f32 v8, v4
    v.ld.h       v4, [s12, #160]
    vf.cvt.f16.f32 v9, v3
    v.ld.h       v3, [s12, #192]
    vf.cvt.f16.f32 v10, v4
    v.ld.h       v4, [s12, #224]
    vf.cvt.f16.f32 v11, v3
    vf.neg       v3, v5
    vf.neg       v12, v6
    vf.neg       v13, v7
    v.ld.h       v14, [s13, #0]
    vf.cvt.f16.f32 v15, v4
    vf.neg       v4, v8
    vf.neg       v16, v9
    v.ld.h       v17, [s13, #32]
    vf.cvt.f16.f32 v18, v14
    v.ld.h       v14, [s13, #64]
    vf.cvt.f16.f32 v19, v17
    v.ld.h       v17, [s13, #96]
    vf.cvt.f16.f32 v20, v14
    v.ld.h       v14, [s13, #128]
    vf.cvt.f16.f32 v21, v17
    v.ld.h       v17, [s13, #160]
    vf.cvt.f16.f32 v22, v14
    v.ld.h       v14, [s13, #192]
    vf.cvt.f16.f32 v23, v17
    v.ld.h       v17, [s13, #224]
    vf.cvt.f16.f32 v24, v14
    vf.cvt.f16.f32 v14, v17
    v.ld.h       v17, [s14, #0]
    vf.neg       v25, v10
    v.ld.h       v26, [s14, #32]
    vf.neg       v27, v11
    vf.cvt.f16.f32 v28, v17
    v.ld.h       v17, [s14, #64]
    vf.neg       v29, v15
    vf.cvt.f16.f32 v30, v26
    v.ld.h       v26, [s14, #96]
    vf.mul       v31, v3, v0
    vf.cvt.f16.f32 v32, v17
    v.ld.h       v17, [s14, #128]
    vf.fms       v33, v3, v0, v31                // the exact rounding error of x*log2(e)
    vf.cvt.f16.f32 v3, v26
    v.ld.h       v26, [s14, #160]
    v.exp2.approx v34, v31                       // ISA 8.8: <= 2**-22 relative
    vf.cvt.f16.f32 v31, v17
    v.ld.h       v17, [s14, #192]
    vf.mul       v35, v33, v1
    vf.cvt.f16.f32 v33, v26
    v.ld.h       v26, [s14, #224]
    vf.mul       v36, v12, v0
    vf.mul       v37, v13, v0
    vf.mul       v38, v4, v0
    vf.fma       v39, v34, v35, v34              // 2**t * 2**d
    vf.cvt.f16.f32 v35, v17
    v.exp2.approx v17, v36                       // ISA 8.8: <= 2**-22 relative
    v.exp2.approx v40, v37                       // ISA 8.8: <= 2**-22 relative
    v.exp2.approx v41, v38                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v42, v12, v0, v36               // the exact rounding error of x*log2(e)
    vf.fms       v12, v13, v0, v37               // the exact rounding error of x*log2(e)
    vf.fms       v13, v4, v0, v38                // the exact rounding error of x*log2(e)
    vf.cmp.o     p1, v39, v39
    @p1 v.sel        v4, v39, v34
    vf.mul       v34, v42, v1
    vf.mul       v36, v12, v1
    v.ld.h       v12, [s15, #0]
    vf.mul       v37, v13, v1
    vf.cvt.f16.f32 v13, v26
    v.ld.h       v26, [s15, #32]
    vf.fma       v38, v17, v34, v17              // 2**t * 2**d
    vf.fma       v34, v40, v36, v40              // 2**t * 2**d
    vf.fma       v36, v41, v37, v41              // 2**t * 2**d
    vf.cmp.o     p1, v38, v38
    vf.cmp.o     p2, v34, v34
    @p1 v.sel        v37, v38, v17
    @p2 v.sel        v17, v34, v40
    v.ld.h       v34, [s15, #64]
    vf.cmp.o     p1, v36, v36
    v.ld.h       v38, [s15, #96]
    @p1 v.sel        v39, v36, v41
    v.ld.h       v36, [s15, #128]
    vf.mul       v40, v16, v0
    v.ld.h       v41, [s15, #160]
    vf.fms       v42, v16, v0, v40               // the exact rounding error of x*log2(e)
    v.ld.h       v16, [s15, #192]
    v.exp2.approx v43, v40                       // ISA 8.8: <= 2**-22 relative
    v.ld.h       v40, [s15, #224]
    vf.mul       v44, v25, v0
    vf.mul       v45, v27, v0
    vf.mul       v46, v29, v0
    vf.mul       v47, v42, v1
    vf.add       v42, v4, v2
    v.exp2.approx v4, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v48, v25, v0, v44               // the exact rounding error of x*log2(e)
    v.exp2.approx v25, v45                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v27, v0, v45               // the exact rounding error of x*log2(e)
    v.exp2.approx v27, v46                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v29, v0, v46               // the exact rounding error of x*log2(e)
    vf.mul       v29, v48, v1
    vf.add       v46, v37, v2
    vf.mul       v37, v44, v1
    vf.fma       v44, v43, v47, v43              // 2**t * 2**d
    vf.mul       v47, v45, v1
    vf.add       v45, v17, v2
    vf.add       v17, v39, v2
    v.rcp.approx v39, v42                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v48, v44, v43
    v.rcp.approx v43, v46                        // ISA 8.8: <= 2**-22 relative
    vf.add       v44, v48, v2
    vf.fma       v48, v4, v29, v4                // 2**t * 2**d
    vf.fma       v29, v25, v37, v25              // 2**t * 2**d
    vf.fma       v37, v27, v47, v27              // 2**t * 2**d
    vf.cmp.o     p1, v48, v48
    @p1 v.sel        v47, v48, v4
    vf.cmp.o     p1, v29, v29
    @p1 v.sel        v4, v29, v25
    vf.cmp.o     p1, v37, v37
    @p1 v.sel        v25, v37, v27
    vf.add       v27, v47, v2
    vf.add       v29, v4, v2
    vf.add       v4, v25, v2
    v.rcp.approx v25, v45                        // ISA 8.8: <= 2**-22 relative
    v.rcp.approx v37, v17                        // ISA 8.8: <= 2**-22 relative
    v.rcp.approx v47, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v48, v42, v39, v2
    vf.fms       v42, v46, v43, v2
    vf.fms       v46, v39, v48, v39
    vf.fms       v48, v43, v42, v43
    vf.neg       v42, v46                        // Newton step: r0*(2 - x*r0)
    vf.neg       v46, v48                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v42, v42
    vf.cmp.o     p2, v46, v46
    @p1 v.sel        v48, v42, v39
    v.rcp.approx v39, v27                        // ISA 8.8: <= 2**-22 relative
    @p2 v.sel        v42, v46, v43
    v.rcp.approx v43, v29                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v5, v48                    // a/y as a refined reciprocal (ISA has no divide)
    v.rcp.approx v5, v4                          // ISA 8.8: <= 2**-22 relative
    vf.mul       v48, v6, v42                    // a/y as a refined reciprocal (ISA has no divide)
    vf.fms       v6, v45, v25, v2
    vf.fms       v42, v17, v37, v2
    vf.fms       v17, v44, v47, v2
    vf.mul       v44, v46, v28
    vf.mul       v28, v48, v30
    vf.fms       v30, v25, v6, v25
    vf.fms       v6, v37, v42, v37
    vf.fms       v42, v47, v17, v47
    vf.cvt.f32.f16 v17, v44
    vf.neg       v44, v30                        // Newton step: r0*(2 - x*r0)
    vf.neg       v30, v6                         // Newton step: r0*(2 - x*r0)
    vf.neg       v6, v42                         // Newton step: r0*(2 - x*r0)
    vf.cvt.f32.f16 v42, v28
    vf.cmp.o     p1, v44, v44
    vf.cmp.o     p2, v30, v30
    @p1 v.sel        v28, v44, v25
    vf.cmp.o     p1, v6, v6
    @p2 v.sel        v25, v30, v37
    @p1 v.sel        v30, v6, v47
    vf.fms       v6, v27, v39, v2
    vf.mul       v27, v7, v28                    // a/y as a refined reciprocal (ISA has no divide)
    vf.fms       v7, v29, v43, v2
    vf.mul       v28, v8, v25                    // a/y as a refined reciprocal (ISA has no divide)
    vf.fms       v8, v4, v5, v2
    vf.fms       v4, v39, v6, v39
    vf.mul       v6, v9, v30                     // a/y as a refined reciprocal (ISA has no divide)
    vf.fms       v9, v43, v7, v43
    vf.cvt.f16.f32 v7, v12
    vf.fms       v12, v5, v8, v5
    vf.neg       v8, v4                          // Newton step: r0*(2 - x*r0)
    vf.cvt.f16.f32 v4, v26
    vf.neg       v25, v9                         // Newton step: r0*(2 - x*r0)
    vf.cvt.f16.f32 v9, v34
    vf.neg       v26, v12                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v12, v8, v39
    vf.cmp.o     p1, v25, v25
    @p1 v.sel        v8, v25, v43
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v25, v26, v5
    vf.mul       v5, v10, v12                    // a/y as a refined reciprocal (ISA has no divide)
    vf.neg       v10, v18
    vf.neg       v12, v19
    vf.neg       v26, v20
    vf.neg       v29, v21
    vf.neg       v30, v22
    vf.neg       v34, v23
    vf.neg       v37, v24
    vf.mul       v39, v11, v8                    // a/y as a refined reciprocal (ISA has no divide)
    vf.neg       v8, v14
    vf.mul       v11, v10, v0
    vf.mul       v43, v15, v25                   // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v15, v12, v0
    vf.cvt.f16.f32 v25, v38
    vf.cvt.f16.f32 v38, v36
    v.exp2.approx v36, v11                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v10, v0, v11               // the exact rounding error of x*log2(e)
    vf.fms       v10, v12, v0, v15               // the exact rounding error of x*log2(e)
    vf.cvt.f16.f32 v11, v41
    vf.cvt.f16.f32 v12, v16
    vf.cvt.f16.f32 v16, v40
    vf.mul       v40, v44, v1
    vf.mul       v41, v27, v32
    v.exp2.approx v27, v15                       // ISA 8.8: <= 2**-22 relative
    vf.mul       v15, v28, v3
    vf.mul       v3, v10, v1
    vf.mul       v10, v6, v31
    vf.mul       v6, v5, v33
    vf.mul       v5, v39, v35
    vf.mul       v28, v43, v13
    vf.mul       v13, v26, v0
    vf.cvt.f32.f16 v31, v41
    vf.cvt.f32.f16 v32, v15
    vf.cvt.f32.f16 v15, v10
    vf.cvt.f32.f16 v10, v6
    v.exp2.approx v6, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v33, v26, v0, v13               // the exact rounding error of x*log2(e)
    vf.cvt.f32.f16 v13, v5
    vf.mul       v5, v29, v0
    vf.cvt.f32.f16 v26, v28
    s.add        s12, s8, s10
    vf.mul       v28, v33, v1
    v.st.h       [s12, #0], v17
    v.exp2.approx v17, v5                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v33, v29, v0, v5                // the exact rounding error of x*log2(e)
    vf.fma       v5, v36, v40, v36               // 2**t * 2**d
    vf.mul       v29, v33, v1
    vf.cmp.o     p1, v5, v5
    vf.fma       v33, v27, v3, v27               // 2**t * 2**d
    @p1 v.sel        v3, v5, v36
    vf.cmp.o     p1, v33, v33
    @p1 v.sel        v5, v33, v27
    v.st.h       [s12, #32], v42
    vf.fma       v27, v6, v28, v6                // 2**t * 2**d
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v28, v27, v6
    vf.fma       v6, v17, v29, v17               // 2**t * 2**d
    v.st.h       [s12, #64], v31
    vf.cmp.o     p1, v6, v6
    v.st.h       [s12, #96], v32
    @p1 v.sel        v27, v6, v17
    v.st.h       [s12, #128], v15
    vf.mul       v6, v30, v0
    v.st.h       [s12, #160], v10
    vf.fms       v10, v30, v0, v6                // the exact rounding error of x*log2(e)
    v.st.h       [s12, #192], v13
    v.exp2.approx v13, v6                        // ISA 8.8: <= 2**-22 relative
    v.st.h       [s12, #224], v26
    vf.mul       v6, v34, v0
    vf.mul       v15, v37, v0
    vf.mul       v17, v8, v0
    vf.mul       v26, v10, v1
    vf.add       v10, v3, v2
    v.exp2.approx v3, v6                         // ISA 8.8: <= 2**-22 relative
    v.exp2.approx v29, v15                       // ISA 8.8: <= 2**-22 relative
    v.exp2.approx v30, v17                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v31, v34, v0, v6                // the exact rounding error of x*log2(e)
    vf.fms       v6, v37, v0, v15                // the exact rounding error of x*log2(e)
    vf.fms       v15, v8, v0, v17                // the exact rounding error of x*log2(e)
    vf.add       v8, v5, v2
    vf.add       v5, v28, v2
    vf.mul       v17, v31, v1
    vf.mul       v28, v6, v1
    vf.mul       v6, v15, v1
    vf.fma       v15, v13, v26, v13              // 2**t * 2**d
    vf.add       v26, v27, v2
    v.rcp.approx v27, v10                        // ISA 8.8: <= 2**-22 relative
    v.rcp.approx v31, v8                         // ISA 8.8: <= 2**-22 relative
    v.rcp.approx v32, v5                         // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v15, v15
    @p1 v.sel        v33, v15, v13
    v.rcp.approx v13, v26                        // ISA 8.8: <= 2**-22 relative
    vf.add       v15, v33, v2
    vf.fma       v33, v3, v17, v3                // 2**t * 2**d
    vf.fma       v17, v29, v28, v29              // 2**t * 2**d
    vf.fma       v28, v30, v6, v30               // 2**t * 2**d
    vf.cmp.o     p1, v33, v33
    vf.cmp.o     p2, v17, v17
    @p1 v.sel        v6, v33, v3
    vf.cmp.o     p1, v28, v28
    @p2 v.sel        v3, v17, v29
    @p1 v.sel        v17, v28, v30
    vf.add       v28, v6, v2
    vf.add       v6, v3, v2
    vf.add       v3, v17, v2
    v.rcp.approx v17, v15                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v29, v10, v27, v2
    v.rcp.approx v10, v28                        // ISA 8.8: <= 2**-22 relative
    v.rcp.approx v30, v6                         // ISA 8.8: <= 2**-22 relative
    v.rcp.approx v33, v3                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v8, v31, v2
    vf.fms       v8, v5, v32, v2
    vf.fms       v5, v26, v13, v2
    vf.fms       v26, v27, v29, v27
    vf.fms       v29, v31, v34, v31
    vf.fms       v34, v32, v8, v32
    vf.fms       v8, v13, v5, v13
    vf.neg       v5, v26                         // Newton step: r0*(2 - x*r0)
    vf.neg       v26, v29                        // Newton step: r0*(2 - x*r0)
    vf.neg       v29, v34                        // Newton step: r0*(2 - x*r0)
    vf.neg       v34, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v8, v5, v27
    vf.cmp.o     p1, v26, v26
    vf.cmp.o     p2, v29, v29
    @p1 v.sel        v5, v26, v31
    vf.cmp.o     p1, v34, v34
    @p2 v.sel        v26, v29, v32
    @p1 v.sel        v27, v34, v13
    vf.mul       v13, v18, v8                    // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v8, v19, v5                     // a/y as a refined reciprocal (ISA has no divide)
    vf.fms       v5, v15, v17, v2
    vf.mul       v15, v20, v26                   // a/y as a refined reciprocal (ISA has no divide)
    vf.fms       v18, v28, v10, v2
    vf.fms       v19, v6, v30, v2
    vf.fms       v6, v3, v33, v2
    vf.fms       v3, v17, v5, v17
    vf.mul       v5, v21, v27                    // a/y as a refined reciprocal (ISA has no divide)
    vf.fms       v20, v10, v18, v10
    vf.fms       v18, v30, v19, v30
    vf.fms       v19, v33, v6, v33
    vf.neg       v6, v3                          // Newton step: r0*(2 - x*r0)
    vf.mul       v3, v13, v7
    vf.neg       v7, v20                         // Newton step: r0*(2 - x*r0)
    vf.neg       v13, v18                        // Newton step: r0*(2 - x*r0)
    vf.neg       v18, v19                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v19, v6, v17
    vf.cmp.o     p1, v7, v7
    vf.cmp.o     p2, v13, v13
    @p1 v.sel        v6, v7, v10
    vf.cmp.o     p1, v18, v18
    @p2 v.sel        v7, v13, v30
    @p1 v.sel        v10, v18, v33
    vf.mul       v13, v22, v19                   // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v17, v23, v6                    // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v6, v24, v7                     // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v7, v14, v10                    // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v10, v8, v4
    vf.mul       v4, v15, v9
    vf.mul       v8, v5, v25
    vf.mul       v5, v13, v38
    vf.mul       v9, v17, v11
    vf.mul       v11, v6, v12
    vf.mul       v6, v7, v16
    vf.cvt.f32.f16 v7, v3
    vf.cvt.f32.f16 v3, v10
    vf.cvt.f32.f16 v10, v4
    vf.cvt.f32.f16 v4, v8
    vf.cvt.f32.f16 v8, v5
    vf.cvt.f32.f16 v5, v9
    vf.cvt.f32.f16 v9, v11
    vf.cvt.f32.f16 v11, v6
    s.add        s10, s8, s11
    v.st.h       [s10, #0], v7
    v.st.h       [s10, #32], v3
    v.st.h       [s10, #64], v10
    v.st.h       [s10, #96], v4
    v.st.h       [s10, #128], v8
    v.st.h       [s10, #160], v5
    v.st.h       [s10, #192], v9
    v.st.h       [s10, #224], v11
    s.addi       s9, s9, #256
    s.cmp.lt     s10, s9, s2
    br.nz        s10, tiles_1
endtiles_2:
__rctx_next:
    s.addi       s1, s5, #4                      // the next program of this context: + 4
    s.cmp.lt     s9, s1, s6
    s.mov        s5, s1
    br.nz        s9, __rctx_program
    exit
