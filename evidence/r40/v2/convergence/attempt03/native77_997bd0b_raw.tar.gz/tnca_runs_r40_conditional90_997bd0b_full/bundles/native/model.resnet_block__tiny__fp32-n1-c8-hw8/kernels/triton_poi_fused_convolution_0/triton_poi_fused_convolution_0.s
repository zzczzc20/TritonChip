    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.rdspecial  s1, pid.y
    s.movz       s5, #8
    s.shli       s6, s1, #3                      // x8 as a shift
    s.muli       s1, s6, #256                    // a runtime tile origin, x256
    s.rdspecial  s7, arg_base
    s.ld.d       s8, [s7, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s7, role_id
    s.movz       s9, #768
    s.mul        s10, s7, s9
    s.add        s7, s8, s10                     // this context's own scratch
    s.addi       s8, s7, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s9, #0
    s.st.d       [s8, #0], s3
    s.movz       s10, #64
    s.st.d       [s8, #8], s10
    s.st.d       [s8, #16], s5
    s.movz       s5, #32
    s.st.d       [s8, #48], s5
    s.movz       s5, #4
    s.st.d       [s8, #56], s5
    .li       s5, #34359738384
    s.st.d       [s8, #88], s5
    .li       s5, #2207613190144
    s.st.d       [s8, #104], s5
    fence.release.device
    td.load      d0, [s8]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s5, s7, #256                    // 512 bytes of repack scratch
    s.add        s7, s9, s6                      // the tile origin
    s.addi       s8, s7, #1
    s.movz       s10, #1
    s.muli       s11, s10, #64
    s.add        s10, s5, s11
    s.addi       s11, s7, #2
    s.movz       s12, #2
    s.muli       s13, s12, #64
    s.add        s12, s5, s13
    s.addi       s13, s7, #3
    s.movz       s14, #3
    s.muli       s15, s14, #64
    s.add        s14, s5, s15
    s.addi       s15, s7, #4
    s.movz       s16, #4
    s.muli       s17, s16, #64
    s.add        s16, s5, s17
    s.addi       s17, s7, #5
    s.movz       s18, #5
    s.muli       s19, s18, #64
    s.add        s18, s5, s19
    s.addi       s19, s7, #6
    s.movz       s20, #6
    s.muli       s21, s20, #64
    s.add        s20, s5, s21
    s.addi       s21, s7, #7
    s.movz       s22, #7
    s.muli       s23, s22, #64
    s.add        s22, s5, s23
    s.movz       s23, #0
    s.movz       s24, #0
    s.movz       s25, #16
    s.muli       s26, s23, #64
    s.add        s23, s5, s26
    s.muli       s26, s24, #4
    s.add        s24, s23, s26
    s.addi       s23, s24, #4                    // column 1
    s.addi       s26, s24, #8                    // column 2
    s.addi       s27, s24, #12                   // column 3
    s.addi       s28, s24, #16                   // column 4
    s.addi       s29, s24, #20                   // column 5
    s.addi       s30, s24, #24                   // column 6
    s.addi       s31, s24, #28                   // column 7
    s.addi       s32, s24, #32                   // column 8
    s.addi       s33, s24, #36                   // column 9
    s.addi       s34, s24, #40                   // column 10
    s.addi       s35, s24, #44                   // column 11
    s.addi       s36, s24, #48                   // column 12
    s.addi       s37, s24, #52                   // column 13
    s.addi       s38, s24, #56                   // column 14
    s.addi       s39, s24, #60                   // column 15
    s.muli       s40, s6, #4
    s.movz       s41, #1
    s.muli       s42, s41, #32
    s.movz       s41, #2
    s.muli       s43, s41, #32
    s.movz       s41, #3
    s.muli       s44, s41, #32
    s.movz       s41, #4
    s.muli       s45, s41, #32
    s.movz       s41, #5
    s.muli       s46, s41, #32
    s.movz       s41, #6
    s.muli       s47, s41, #32
    s.movz       s41, #7
    s.muli       s48, s41, #32
    s.movz       s41, #8
    s.muli       s49, s41, #32
    s.movz       s41, #9
    s.muli       s50, s41, #32
    s.movz       s41, #10
    s.muli       s51, s41, #32
    s.movz       s41, #11
    s.muli       s52, s41, #32
    s.movz       s41, #12
    s.muli       s53, s41, #32
    s.movz       s41, #13
    s.muli       s54, s41, #32
    s.movz       s41, #14
    s.muli       s55, s41, #32
    s.movz       s41, #15
    s.muli       s56, s41, #32
    s.shli       s41, s4, #4                     // x16 as a shift
    s.muli       s4, s41, #4                     // a runtime tile origin, x4
    s.add        s57, s2, s4                     // the tile origin
    s.add        s2, s57, s1                     // the tile origin
    // a masked 8x16 tile with contiguous rows: one predicated load a row
    // tile epilogue: 8 rows through the vector unit, as f32 (ISA sec 9B)
    s.add        s1, s9, s41                     // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.add        v2, v0, v1
    v.cmpi.lt    p1, v2, #64
    v.splat      v0, s7
    v.cmpi.lt    p2, v0, #8
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s2, #0]
    v.st.w       [s5, #0], v0
    s.addi       s1, s2, #256                    // row 1
    v.splat      v0, s8
    v.cmpi.lt    p2, v0, #8
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s1, #0]
    v.st.w       [s10, #0], v0
    s.addi       s1, s2, #512                    // row 2
    v.splat      v0, s11
    v.cmpi.lt    p2, v0, #8
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s1, #0]
    v.st.w       [s12, #0], v0
    s.addi       s1, s2, #768                    // row 3
    v.splat      v0, s13
    v.cmpi.lt    p2, v0, #8
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s1, #0]
    v.st.w       [s14, #0], v0
    s.addi       s1, s2, #1024                   // row 4
    v.splat      v0, s15
    v.cmpi.lt    p2, v0, #8
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s1, #0]
    v.st.w       [s16, #0], v0
    s.addi       s1, s2, #1280                   // row 5
    v.splat      v0, s17
    v.cmpi.lt    p2, v0, #8
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s1, #0]
    v.st.w       [s18, #0], v0
    s.addi       s1, s2, #1536                   // row 6
    v.splat      v0, s19
    v.cmpi.lt    p2, v0, #8
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s1, #0]
    v.st.w       [s20, #0], v0
    s.addi       s1, s2, #1792                   // row 7
    v.splat      v0, s21
    v.cmpi.lt    p2, v0, #8
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s1, #0]
    v.st.w       [s22, #0], v0
    fence.acq_rel.device
    // tl.trans: 16 columns, gathered %c109:scalar elements apart (ISA sec 9.1)
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s25
    v.mul        v2, v0, v1                      // one element per source row
    v.ld.gather.w v0, [s24, v2]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.w v1, [s23, v2]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.w v3, [s26, v2]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.w v4, [s27, v2]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.w v5, [s28, v2]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.w v6, [s29, v2]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.w v7, [s30, v2]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.w v8, [s31, v2]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.w v9, [s32, v2]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.w v10, [s33, v2]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v11, [s34, v2]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v12, [s35, v2]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v13, [s36, v2]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v14, [s37, v2]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v15, [s38, v2]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v16, [s39, v2]                 // index is in elements (ISA sec 9.1)
    s.muli       s1, s41, #32
    s.add        s2, s3, s1
    s.add        s1, s2, s40
    v.splat      v2, s6
    v.iota       v17                             // arange(0, VLEN)
    v.add        v18, v2, v17
    v.movi       v2, #0
    v.cmp.ge     p1, v18, v2
    v.cmpi.lt    p2, v18, #8
    p.and        p3, p1, p2
    v.splat      v2, s41
    v.movi       v17, #0
    v.cmp.ge     p1, v2, v17
    v.cmpi.lt    p2, v2, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v2                              // arange(0, VLEN)
    v.cmpi.lt    p2, v2, #8
    p.and        p4, p2, p1
    @p4 v.st.w       [s1, #0], v0
    s.add        s2, s1, s42
    s.addi       s3, s41, #1
    v.splat      v0, s3
    v.movi       v2, #0
    v.cmp.ge     p1, v0, v2
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #8
    p.and        p4, p2, p1
    @p4 v.st.w       [s2, #0], v1
    s.add        s2, s1, s43
    s.addi       s3, s41, #2
    v.splat      v0, s3
    v.movi       v1, #0
    v.cmp.ge     p1, v0, v1
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #8
    p.and        p4, p2, p1
    @p4 v.st.w       [s2, #0], v3
    s.add        s2, s1, s44
    s.addi       s3, s41, #3
    v.splat      v0, s3
    v.movi       v1, #0
    v.cmp.ge     p1, v0, v1
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #8
    p.and        p4, p2, p1
    @p4 v.st.w       [s2, #0], v4
    s.add        s2, s1, s45
    s.addi       s3, s41, #4
    v.splat      v0, s3
    v.movi       v1, #0
    v.cmp.ge     p1, v0, v1
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #8
    p.and        p4, p2, p1
    @p4 v.st.w       [s2, #0], v5
    s.add        s2, s1, s46
    s.addi       s3, s41, #5
    v.splat      v0, s3
    v.movi       v1, #0
    v.cmp.ge     p1, v0, v1
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #8
    p.and        p4, p2, p1
    @p4 v.st.w       [s2, #0], v6
    s.add        s2, s1, s47
    s.addi       s3, s41, #6
    v.splat      v0, s3
    v.movi       v1, #0
    v.cmp.ge     p1, v0, v1
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #8
    p.and        p4, p2, p1
    @p4 v.st.w       [s2, #0], v7
    s.add        s2, s1, s48
    s.addi       s3, s41, #7
    v.splat      v0, s3
    v.movi       v1, #0
    v.cmp.ge     p1, v0, v1
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #8
    p.and        p4, p2, p1
    @p4 v.st.w       [s2, #0], v8
    s.add        s2, s1, s49
    s.addi       s3, s41, #8
    v.splat      v0, s3
    v.movi       v1, #0
    v.cmp.ge     p1, v0, v1
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #8
    p.and        p4, p2, p1
    @p4 v.st.w       [s2, #0], v9
    s.add        s2, s1, s50
    s.addi       s3, s41, #9
    v.splat      v0, s3
    v.movi       v1, #0
    v.cmp.ge     p1, v0, v1
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #8
    p.and        p4, p2, p1
    @p4 v.st.w       [s2, #0], v10
    s.add        s2, s1, s51
    s.addi       s3, s41, #10
    v.splat      v0, s3
    v.movi       v1, #0
    v.cmp.ge     p1, v0, v1
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #8
    p.and        p4, p2, p1
    @p4 v.st.w       [s2, #0], v11
    s.add        s2, s1, s52
    s.addi       s3, s41, #11
    v.splat      v0, s3
    v.movi       v1, #0
    v.cmp.ge     p1, v0, v1
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #8
    p.and        p4, p2, p1
    @p4 v.st.w       [s2, #0], v12
    s.add        s2, s1, s53
    s.addi       s3, s41, #12
    v.splat      v0, s3
    v.movi       v1, #0
    v.cmp.ge     p1, v0, v1
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #8
    p.and        p4, p2, p1
    @p4 v.st.w       [s2, #0], v13
    s.add        s2, s1, s54
    s.addi       s3, s41, #13
    v.splat      v0, s3
    v.movi       v1, #0
    v.cmp.ge     p1, v0, v1
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #8
    p.and        p4, p2, p1
    @p4 v.st.w       [s2, #0], v14
    s.add        s2, s1, s55
    s.addi       s3, s41, #14
    v.splat      v0, s3
    v.movi       v1, #0
    v.cmp.ge     p1, v0, v1
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #8
    p.and        p4, p2, p1
    @p4 v.st.w       [s2, #0], v15
    s.add        s2, s1, s56
    s.addi       s1, s41, #15
    v.splat      v0, s1
    v.movi       v1, #0
    v.cmp.ge     p1, v0, v1
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #8
    p.and        p3, p2, p1
    @p3 v.st.w       [s2, #0], v16
__rctx_next:
    exit
