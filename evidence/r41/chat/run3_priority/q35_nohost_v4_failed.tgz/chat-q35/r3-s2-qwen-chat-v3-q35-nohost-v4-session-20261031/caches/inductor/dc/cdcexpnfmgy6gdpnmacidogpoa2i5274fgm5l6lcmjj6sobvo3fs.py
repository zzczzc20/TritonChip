
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16, 'r0_': 64},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*i64', 'out_ptr0': '*i1', 'out_ptr2': '*fp32', 'out_ptr3': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_32', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 4, 'num_store': 3, 'num_reduction': 3, 'autotune_hints': set(), 'tiling_scores': {'x': 160, 'r0_': 12288}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 4}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_32(in_ptr0, in_ptr1, out_ptr0, out_ptr2, out_ptr3, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 16
    XBLOCK: tl.constexpr = 1
    r0_numel = 64
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[16, 64], strides=[64, 1], block_shape=[XBLOCK, R0_BLOCK])
    tmp1 = tl.load(in_ptr1 + (0))
    tmp2 = tl.broadcast_to(tmp1, [R0_BLOCK])
    _tmp18 = tl.full([R0_BLOCK], False, tl.int1)
    _tmp22 = tl.full([R0_BLOCK], float("-inf"), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp3 = tl.full([1], 0, tl.int64)
        tmp4 = tmp3 + tmp2
        tmp5 = (r0_1).to(tl.int64)
        tmp6 = (tmp5).to(tl.int64)
        tmp7 = tmp6 <= tmp4
        tmp8 = tl.full([1], 0.0, tl.float32)
        tmp9 = tl.full([1], float("-inf"), tl.float32)
        tmp10 = tl.where(tmp7, tmp8, tmp9)
        tmp11 = tmp10.to(tl.float32)
        tmp12 = tmp0 + tmp11
        tmp13 = tmp12 == tmp9
        tmp14 = tmp13 == 0
        tmp15 = tmp14.to(tl.int64)
        tmp16 = (tmp15 != 0)
        tmp17 = tl.broadcast_to(tmp16, [R0_BLOCK])
        tmp19 = _tmp18 | tmp17
        _tmp18 = tl.where(r0_mask, tmp19, _tmp18)
        tmp21 = tl.broadcast_to(tmp12, [R0_BLOCK])
        tmp23 = tl.maximum(_tmp22, tmp21, tl.PropagateNan.ALL)
        _tmp22 = tl.where(r0_mask, tmp23, _tmp22)
    tmp20 = _tmp18.to(tl.int8)
    tmp18 = triton_helpers.promote_to_tensor(triton_helpers.any(tmp20, 0))
    tmp22 = triton_helpers.promote_to_tensor(triton_helpers.max2(_tmp22, 0))
    tl.store(out_ptr0 + (x0), tmp18, None)
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[16, 64], strides=[64, 1], block_shape=[XBLOCK, R0_BLOCK])
    tmp25 = tl.load(in_ptr1 + (0))
    tmp26 = tl.broadcast_to(tmp25, [R0_BLOCK])
    _tmp40 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp24 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp27 = tl.full([1], 0, tl.int64)
        tmp28 = tmp27 + tmp26
        tmp29 = (r0_1).to(tl.int64)
        tmp30 = (tmp29).to(tl.int64)
        tmp31 = tmp30 <= tmp28
        tmp32 = tl.full([1], 0.0, tl.float32)
        tmp33 = tl.full([1], float("-inf"), tl.float32)
        tmp34 = tl.where(tmp31, tmp32, tmp33)
        tmp35 = tmp34.to(tl.float32)
        tmp36 = tmp24 + tmp35
        tmp37 = tmp36 - tmp22
        tmp38 = libdevice.exp(tmp37)
        tmp39 = tl.broadcast_to(tmp38, [R0_BLOCK])
        tmp41 = _tmp40 + tmp39
        _tmp40 = tl.where(r0_mask, tmp41, _tmp40)
        tl.store(out_ptr2 + (r0_1 + 64*x0), tmp38, r0_mask)
    tmp40 = triton_helpers.promote_to_tensor(tl.sum(_tmp40, 0))
    tl.store(out_ptr3 + (x0), tmp40, None)
