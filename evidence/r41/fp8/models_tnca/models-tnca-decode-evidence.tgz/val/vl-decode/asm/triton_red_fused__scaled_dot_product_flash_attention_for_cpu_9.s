    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.splat      v0, s4
    v.movi       v1, #13
    v.movi       v2, #0
    s.rdspecial  s1, arg_base
    v.sub        v3, v2, v0
    v.sub        v4, v2, v1
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    s.ld.d       s2, [s1, #0]                    // in_out_ptr0: device_ptr64 at arg_base+0
    v.iota       v5                              // arange(0, VLEN)
    v.movi       v6, #1
    s.ld.d       s3, [s1, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    @p1 v.sel        v7, v3, v0
    @p2 v.sel        v0, v4, v1
    v.movi       v1, #0
    v.movi       v3, #0
    s.movz       s1, #31
idiv_1:
    v.splat      v4, s1
    v.shl        v8, v3, v6
    v.lshr       v9, v7, v4
    v.cmp.lt     p2, v3, v2
    v.and        v10, v9, v6
    v.shl        v9, v6, v4
    v.or         v4, v8, v10
    s.subi       s5, s1, #1
    v.cmp.geu    p3, v4, v0
    p.or         p4, p2, p3
    v.sub        v8, v4, v0
    @p4 v.sel        v10, v9, v2
    @p4 v.sel        v9, v8, v4
    v.or         v4, v1, v10
    v.mov        v3, v9
    v.mov        v1, v4
    s.mov        s1, s5
    s.movz       s5, #0
    s.cmp.ge     s6, s1, s5
    br.nz        s6, idiv_1
    v.sub        v0, v2, v3
    v.movi       v1, #-1
    @p1 v.sel        v2, v0, v3
    s.movz       s1, #13
    v.mul        v0, v2, v1
    s.mul        s5, s4, s1
    v.extract    s1, v0, #0
    v.splat      v0, s1
    v.movi       v1, #13
    v.add        v2, v5, v0
    s.shli       s1, s5, #2                      // element offset -> bytes (x4)
    v.extract    s4, v2, #0
    s.shli       s6, s4, #32
    v.extract    s4, v2, #1
    s.ashri      s7, s6, #32
    s.shli       s6, s4, #32
    v.extract    s4, v2, #2
    s.add        s8, s3, s1                      // &in_ptr0[...]
    v.movi       v0, #0
    v.movi       v3, #0
    s.lshri      s9, s7, #32
    s.ashri      s10, s6, #32
    s.shli       s6, s4, #32
    v.cmp.lt     p1, v5, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s8, #0]
    v.extract    s4, v2, #3
    v.insert     v0, s7, #0
    v.insert     v3, s9, #0
    s.lshri      s7, s10, #32
    s.ashri      s8, s6, #32
    s.shli       s6, s4, #32
    v.extract    s4, v2, #4
    v.insert     v0, s10, #1
    v.insert     v3, s7, #1
    s.lshri      s7, s8, #32
    s.ashri      s9, s6, #32
    s.shli       s6, s4, #32
    v.extract    s4, v2, #5
    v.insert     v0, s8, #2
    v.insert     v3, s7, #2
    s.lshri      s7, s9, #32
    s.ashri      s8, s6, #32
    s.shli       s6, s4, #32
    v.insert     v0, s9, #3
    v.insert     v3, s7, #3
    s.lshri      s4, s8, #32
    s.ashri      s7, s6, #32
    v.insert     v0, s8, #4
    v.insert     v3, s4, #4
    s.lshri      s4, s7, #32
    v.insert     v0, s7, #5
    v.splat      v4, s5
    v.insert     v3, s4, #5
    v.add        v6, v5, v4
    v.extract    s4, v2, #6
    s.shli       s5, s4, #32
    .li       s4, #-1
    v.extract    s4, v2, #7
    s.ashri      s6, s5, #32
    s.shli       s5, s4, #32
    v.extract    s4, v2, #8
    s.lshri      s7, s6, #32
    s.ashri      s8, s5, #32
    s.shli       s5, s4, #32
    v.extract    s4, v2, #9
    v.insert     v0, s6, #6
    v.insert     v3, s7, #6
    s.lshri      s6, s8, #32
    s.ashri      s7, s5, #32
    s.shli       s5, s4, #32
    v.extract    s4, v2, #10
    v.insert     v0, s8, #7
    v.insert     v3, s6, #7
    s.lshri      s6, s7, #32
    s.ashri      s8, s5, #32
    s.shli       s5, s4, #32
    v.extract    s4, v2, #11
    v.insert     v0, s7, #8
    v.insert     v3, s6, #8
    s.lshri      s6, s8, #32
    s.ashri      s7, s5, #32
    s.shli       s5, s4, #32
    v.extract    s4, v2, #12
    v.insert     v0, s8, #9
    v.insert     v3, s6, #9
    s.lshri      s6, s7, #32
    s.ashri      s8, s5, #32
    s.shli       s5, s4, #32
    v.extract    s4, v2, #13
    v.insert     v0, s7, #10
    v.insert     v3, s6, #10
    s.lshri      s6, s8, #32
    s.ashri      s7, s5, #32
    s.shli       s5, s4, #32
    v.extract    s4, v2, #14
    v.insert     v0, s8, #11
    v.insert     v3, s6, #11
    s.lshri      s6, s7, #32
    s.ashri      s8, s5, #32
    s.shli       s5, s4, #32
    v.extract    s4, v2, #15
    v.insert     v0, s7, #12
    v.insert     v3, s6, #12
    s.lshri      s6, s8, #32
    s.ashri      s7, s5, #32
    s.shli       s5, s4, #32
    v.insert     v0, s8, #13
    v.insert     v3, s6, #13
    s.lshri      s4, s7, #32
    s.ashri      s6, s5, #32
    v.insert     v0, s7, #14
    v.insert     v3, s4, #14
    s.lshri      s4, s6, #32
    v.insert     v0, s6, #15
    v.insert     v3, s4, #15
    v.extract    s4, v0, #0
    v.extract    s5, v3, #0
    s.shli       s6, s5, #32
    v.extract    s5, v3, #1
    s.or         s7, s4, s6
    s.movz       s4, #0
    s.shli       s6, s5, #32
    v.extract    s5, v0, #1
    v.extract    s8, v3, #2
    v.movi       v2, #0
    s.cmp.le     s9, s7, s4
    s.or         s4, s5, s6
    s.movz       s5, #0
    s.shli       s6, s8, #32
    v.extract    s7, v0, #2
    v.extract    s8, v3, #3
    v.insert     v2, s9, #0
    s.cmp.le     s9, s4, s5
    s.or         s4, s7, s6
    s.movz       s5, #0
    s.shli       s6, s8, #32
    v.extract    s7, v0, #3
    v.extract    s8, v3, #4
    v.insert     v2, s9, #1
    s.cmp.le     s9, s4, s5
    s.or         s4, s7, s6
    s.movz       s5, #0
    s.shli       s6, s8, #32
    v.extract    s7, v0, #4
    v.extract    s8, v3, #5
    v.insert     v2, s9, #2
    s.cmp.le     s9, s4, s5
    s.or         s4, s7, s6
    s.movz       s5, #0
    s.shli       s6, s8, #32
    v.extract    s7, v0, #5
    v.extract    s8, v3, #6
    v.insert     v2, s9, #3
    s.cmp.le     s9, s4, s5
    s.or         s4, s7, s6
    s.movz       s5, #0
    s.shli       s6, s8, #32
    v.extract    s7, v0, #6
    v.extract    s8, v3, #7
    v.insert     v2, s9, #4
    s.cmp.le     s9, s4, s5
    s.or         s4, s7, s6
    s.movz       s5, #0
    s.shli       s6, s8, #32
    v.extract    s7, v0, #7
    v.extract    s8, v3, #8
    v.insert     v2, s9, #5
    s.cmp.le     s9, s4, s5
    s.or         s4, s7, s6
    s.movz       s5, #0
    s.shli       s6, s8, #32
    v.extract    s7, v0, #8
    v.extract    s8, v3, #9
    v.insert     v2, s9, #6
    s.cmp.le     s9, s4, s5
    s.or         s4, s7, s6
    s.movz       s5, #0
    s.shli       s6, s8, #32
    v.extract    s7, v0, #9
    v.extract    s8, v3, #10
    v.insert     v2, s9, #7
    s.cmp.le     s9, s4, s5
    s.or         s4, s7, s6
    s.movz       s5, #0
    s.shli       s6, s8, #32
    v.extract    s7, v0, #10
    v.extract    s8, v3, #11
    v.insert     v2, s9, #8
    s.cmp.le     s9, s4, s5
    s.or         s4, s7, s6
    s.movz       s5, #0
    s.shli       s6, s8, #32
    v.extract    s7, v0, #11
    v.extract    s8, v3, #12
    v.insert     v2, s9, #9
    s.cmp.le     s9, s4, s5
    s.or         s4, s7, s6
    s.movz       s5, #0
    s.shli       s6, s8, #32
    v.extract    s7, v0, #12
    v.extract    s8, v3, #13
    v.insert     v2, s9, #10
    s.cmp.le     s9, s4, s5
    s.or         s4, s7, s6
    s.movz       s5, #0
    s.shli       s6, s8, #32
    v.extract    s7, v0, #13
    v.extract    s8, v3, #14
    v.insert     v2, s9, #11
    s.cmp.le     s9, s4, s5
    s.or         s4, s7, s6
    s.movz       s5, #0
    s.shli       s6, s8, #32
    v.extract    s7, v0, #14
    v.extract    s8, v3, #15
    v.insert     v2, s9, #12
    s.cmp.le     s9, s4, s5
    s.or         s4, s7, s6
    s.movz       s5, #0
    s.shli       s6, s8, #32
    v.extract    s7, v0, #15
    v.insert     v2, s9, #13
    s.cmp.le     s8, s4, s5
    s.or         s4, s7, s6
    s.movz       s5, #0
    v.insert     v2, s8, #14
    s.cmp.le     s6, s4, s5
    v.movi       v0, #0
    v.insert     v2, s6, #15
    v.movi       v3, #0
    .li       s4, #4286578688
    v.splat      v4, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.ne     p2, v2, v0
    @p2 v.sel        v0, v3, v4
    v.movi       v2, #1
    vf.add       v5, v1, v0
    v.movi       v1, #0
    v.movi       v6, #0
    v.movi       v7, #1
    vf.cmp.eq    p2, v5, v4
    @p2 v.sel        v8, v2, v1
    v.movi       v1, #0
    v.cmp.eq     p2, v8, v6
    @p2 v.sel        v2, v7, v1
    v.movi       v1, #1
    v.movi       v6, #0
    v.extract    s4, v2, #0
    @p2 v.sel        v2, v1, v6
    v.movi       v1, #1
    v.movi       v6, #0
    v.movi       v7, #0
    v.movi       v8, #0
    s.lshri      s5, s4, #32
    v.extract    s6, v2, #1
    @p2 v.sel        v2, v1, v6
    v.movi       v1, #1
    v.movi       v6, #0
    v.insert     v7, s4, #0
    v.insert     v8, s5, #0
    s.lshri      s4, s6, #32
    v.extract    s5, v2, #2
    @p2 v.sel        v2, v1, v6
    v.movi       v1, #1
    v.movi       v6, #0
    v.insert     v7, s6, #1
    v.insert     v8, s4, #1
    s.lshri      s4, s5, #32
    v.extract    s6, v2, #3
    @p2 v.sel        v2, v1, v6
    v.movi       v1, #1
    v.movi       v6, #0
    v.insert     v7, s5, #2
    v.insert     v8, s4, #2
    s.lshri      s4, s6, #32
    v.extract    s5, v2, #4
    @p2 v.sel        v2, v1, v6
    v.movi       v1, #1
    v.movi       v6, #0
    v.insert     v7, s6, #3
    v.insert     v8, s4, #3
    s.lshri      s4, s5, #32
    v.extract    s6, v2, #5
    @p2 v.sel        v2, v1, v6
    v.movi       v1, #1
    v.movi       v6, #0
    v.insert     v7, s5, #4
    v.insert     v8, s4, #4
    s.lshri      s4, s6, #32
    v.extract    s5, v2, #6
    @p2 v.sel        v2, v1, v6
    v.movi       v1, #1
    v.movi       v6, #0
    v.insert     v7, s6, #5
    v.insert     v8, s4, #5
    s.lshri      s4, s5, #32
    v.extract    s6, v2, #7
    @p2 v.sel        v2, v1, v6
    v.movi       v1, #1
    v.movi       v6, #0
    v.insert     v7, s5, #6
    v.insert     v8, s4, #6
    s.lshri      s4, s6, #32
    v.extract    s5, v2, #8
    @p2 v.sel        v2, v1, v6
    v.movi       v1, #1
    v.movi       v6, #0
    v.insert     v7, s6, #7
    v.insert     v8, s4, #7
    s.lshri      s4, s5, #32
    v.extract    s6, v2, #9
    @p2 v.sel        v2, v1, v6
    v.movi       v1, #1
    v.movi       v6, #0
    v.insert     v7, s5, #8
    v.insert     v8, s4, #8
    s.lshri      s4, s6, #32
    v.extract    s5, v2, #10
    @p2 v.sel        v2, v1, v6
    v.movi       v1, #1
    v.movi       v6, #0
    v.insert     v7, s6, #9
    v.insert     v8, s4, #9
    s.lshri      s4, s5, #32
    v.extract    s6, v2, #11
    @p2 v.sel        v2, v1, v6
    v.movi       v1, #1
    v.movi       v6, #0
    v.insert     v7, s5, #10
    v.insert     v8, s4, #10
    s.lshri      s4, s6, #32
    v.extract    s5, v2, #12
    @p2 v.sel        v2, v1, v6
    v.movi       v1, #1
    v.movi       v6, #0
    v.insert     v7, s6, #11
    v.insert     v8, s4, #11
    s.lshri      s4, s5, #32
    v.extract    s6, v2, #13
    @p2 v.sel        v2, v1, v6
    v.movi       v1, #1
    v.movi       v6, #0
    v.insert     v7, s5, #12
    v.insert     v8, s4, #12
    s.lshri      s4, s6, #32
    v.extract    s5, v2, #14
    @p2 v.sel        v2, v1, v6
    v.insert     v7, s6, #13
    v.insert     v8, s4, #13
    s.lshri      s4, s5, #32
    v.extract    s6, v2, #15
    v.insert     v7, s5, #14
    v.insert     v8, s4, #14
    s.lshri      s4, s6, #32
    v.insert     v7, s6, #15
    v.insert     v8, s4, #15
    v.extract    s4, v7, #0
    v.extract    s5, v8, #0
    s.shli       s6, s5, #32
    v.extract    s5, v8, #1
    s.or         s7, s4, s6
    s.movz       s4, #0
    s.shli       s6, s5, #32
    v.extract    s5, v7, #1
    v.extract    s8, v8, #2
    v.movi       v1, #0
    s.cmp.ne     s9, s7, s4
    s.or         s4, s5, s6
    s.movz       s5, #0
    s.shli       s6, s8, #32
    v.extract    s7, v7, #2
    v.extract    s8, v8, #3
    v.insert     v1, s9, #0
    s.cmp.ne     s9, s4, s5
    s.or         s4, s7, s6
    s.movz       s5, #0
    s.shli       s6, s8, #32
    v.extract    s7, v7, #3
    v.extract    s8, v8, #4
    v.insert     v1, s9, #1
    s.cmp.ne     s9, s4, s5
    s.or         s4, s7, s6
    s.movz       s5, #0
    s.shli       s6, s8, #32
    v.extract    s7, v7, #4
    v.extract    s8, v8, #5
    v.insert     v1, s9, #2
    s.cmp.ne     s9, s4, s5
    s.or         s4, s7, s6
    s.movz       s5, #0
    s.shli       s6, s8, #32
    v.extract    s7, v7, #5
    v.extract    s8, v8, #6
    v.insert     v1, s9, #3
    s.cmp.ne     s9, s4, s5
    s.or         s4, s7, s6
    s.movz       s5, #0
    s.shli       s6, s8, #32
    v.extract    s7, v7, #6
    v.extract    s8, v8, #7
    v.insert     v1, s9, #4
    s.cmp.ne     s9, s4, s5
    s.or         s4, s7, s6
    s.movz       s5, #0
    s.shli       s6, s8, #32
    v.extract    s7, v7, #7
    v.extract    s8, v8, #8
    v.insert     v1, s9, #5
    s.cmp.ne     s9, s4, s5
    s.or         s4, s7, s6
    s.movz       s5, #0
    s.shli       s6, s8, #32
    v.extract    s7, v7, #8
    v.extract    s8, v8, #9
    v.insert     v1, s9, #6
    s.cmp.ne     s9, s4, s5
    s.or         s4, s7, s6
    s.movz       s5, #0
    s.shli       s6, s8, #32
    v.extract    s7, v7, #9
    v.extract    s8, v8, #10
    v.insert     v1, s9, #7
    s.cmp.ne     s9, s4, s5
    s.or         s4, s7, s6
    s.movz       s5, #0
    s.shli       s6, s8, #32
    v.extract    s7, v7, #10
    v.extract    s8, v8, #11
    v.insert     v1, s9, #8
    s.cmp.ne     s9, s4, s5
    s.or         s4, s7, s6
    s.movz       s5, #0
    s.shli       s6, s8, #32
    v.extract    s7, v7, #11
    v.extract    s8, v8, #12
    v.insert     v1, s9, #9
    s.cmp.ne     s9, s4, s5
    s.or         s4, s7, s6
    s.movz       s5, #0
    s.shli       s6, s8, #32
    v.extract    s7, v7, #12
    v.extract    s8, v8, #13
    v.insert     v1, s9, #10
    s.cmp.ne     s9, s4, s5
    s.or         s4, s7, s6
    s.movz       s5, #0
    s.shli       s6, s8, #32
    v.extract    s7, v7, #13
    v.extract    s8, v8, #14
    v.insert     v1, s9, #11
    s.cmp.ne     s9, s4, s5
    s.or         s4, s7, s6
    s.movz       s5, #0
    s.shli       s6, s8, #32
    v.extract    s7, v7, #14
    v.extract    s8, v8, #15
    v.insert     v1, s9, #12
    s.cmp.ne     s9, s4, s5
    s.or         s4, s7, s6
    s.movz       s5, #0
    s.shli       s6, s8, #32
    v.extract    s7, v7, #15
    v.insert     v1, s9, #13
    s.cmp.ne     s8, s4, s5
    s.or         s4, s7, s6
    s.movz       s5, #0
    @p1 v.sel        v2, v5, v4
    v.insert     v1, s8, #14
    s.cmp.ne     s6, s4, s5
    v.movi       v4, #1
    v.movi       v5, #0
    s.add        s4, s3, s1                      // &in_ptr0[...]
    vf.cmp.uo    p2, v2, v2
    v.insert     v1, s6, #15
    @p2 v.sel        v6, v4, v5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s4, #0]
    v.reduce.or.b v5, v6
    v.movi       v6, #0
    vf.reduce.max.b v7, v2
    .li       s3, #2143289344
    v.splat      v2, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.ne     p2, v5, v6
    @p2 v.sel        v5, v2, v7
    v.movi       v2, #0
    .li       s3, #1069066811
    v.splat      v6, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v7, v5, v2
    vf.add       v5, v4, v0
    .li       s3, #1060205080
    v.splat      v0, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s3, s2, s1                      // &in_out_ptr0[...]
    v.extract    s4, v7, #0
    v.splat      v4, s4
    v.movi       v7, #0
    vf.sub       v8, v5, v4
    v.movi       v4, #0
    v.movi       v5, #0
    p.not        p2, p1
    vf.mul       v9, v8, v6
    v.cmp.ne     p3, v1, v7
    s.add        s4, s2, s1                      // &in_out_ptr0[...]
    v.cmp.ne     p4, v4, v5
    v.exp2.approx v1, v9                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v4, v8, v6, v9                  // the exact rounding error of x*log2(e)
    p.and        p5, p1, p3
    p.and        p3, p2, p4
    v.movi       v5, #1
    vf.mul       v6, v4, v0
    p.or         p2, p5, p3
    .li       s5, #1065353216
    v.splat      v0, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v4, #0
    v.movi       v7, #0
    @p2 v.sel        v8, v5, v4
    v.reduce.or  s5, v8
    v.splat      v4, s5
    v.movi       v5, #1
    v.movi       v8, #0
    v.cmp.eq     p2, v4, v7
    @p2 v.sel        v4, v5, v8
    v.movi       v5, #0
    v.extract    s5, v4, #0
    v.splat      v4, s5
    s.add        s5, s2, s1                      // &in_out_ptr0[...]
    v.cmp.ne     p2, v4, v5
    vf.fma       v4, v1, v6, v1                  // 2**t * 2**d
    vf.cmp.o     p3, v4, v4
    @p3 v.sel        v5, v4, v1
    vf.add       v1, v5, v3
    @p1 v.st.w       [s3, #0], v5
    fence.acq_rel.device
    @p1 v.sel        v4, v1, v3
    vf.reduce.add.b v1, v4
    vf.add       v4, v1, v2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s4, #0]
    v.extract    s1, v4, #0
    v.splat      v2, s1
    v.rcp.approx v4, v2                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v2, v4, v0
    vf.fms       v0, v4, v5, v4
    vf.neg       v5, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v0, v5, v4
    vf.mul       v4, v1, v0                      // a/y: faithful quotient
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v0, v4
    vf.neg       v0, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v0, v0
    @p3 v.sel        v1, v0, v4
    @p2 v.sel        v0, v3, v1
    @p1 v.st.w       [s5, #0], v0
__rctx_next:
    exit
