from pathlib import Path
import re,subprocess,json,hashlib
root=Path.cwd();out=Path('/tmp/r40_argmin_proof');out.mkdir(exist_ok=False)
s=(root/'rtl/nuca/tnca_nuca_slice.v').read_text()
node=re.search(r'assign victim_tree\[rank_node\]\s*=.*?;',s,re.S)[0]
assert 'victim_tree[0][WAY_W:1]' in s and 'victim_tree[0][0]' in s
leaf=re.search(r'assign victim_tree\[VICTIM_LEAVES-1\+rank_way\]\s*=.*?;',s,re.S)[0]
results=[]
for ways in (1,2,3,4,5,8):
 width=max(1,(ways-1).bit_length());leaves=1<<(ways-1).bit_length()
 body=f"""module miter(input [{ways-1}:0] way_claimed,input [{ways*8-1}:0] keys,input [{ways-1}:0] dead);
localparam WAYS={ways},WAY_W={width},VICTIM_LEAVES={leaves},VICTIM_RECORD_W=10+WAY_W;
wire [VICTIM_RECORD_W-1:0] victim_tree [0:2*VICTIM_LEAVES-2];
genvar rank_way,rank_node;
generate for(rank_way=0;rank_way<VICTIM_LEAVES;rank_way=rank_way+1)begin
 if(rank_way<WAYS)begin
  wire [7:0] rank_key=keys[rank_way*8+:8];wire is_dead=dead[rank_way];
  {leaf}
 end else assign victim_tree[VICTIM_LEAVES-1+rank_way]={{VICTIM_RECORD_W{{1'b1}}}};
end
for(rank_node=0;rank_node<VICTIM_LEAVES-1;rank_node=rank_node+1)begin
 {node}
end endgenerate
reg ok,chosen_dead;reg [WAY_W-1:0] chosen;reg [7:0] best;integer i;
always @*begin
 ok=0;chosen_dead=0;chosen=0;best=8'hff;
 for(i=0;i<WAYS;i=i+1)if(!way_claimed[i] && (!ok || keys[i*8+:8]<best))begin
  ok=1;chosen=i;chosen_dead=dead[i];best=keys[i*8+:8];
 end
 assert(ok==!victim_tree[0][VICTIM_RECORD_W-1]);
 if(ok)begin assert(chosen==victim_tree[0][WAY_W:1]);assert(chosen_dead==victim_tree[0][0]);end
end
endmodule
"""
 for mutant in ((False,True) if ways==8 else (False,)):
  tag=f'w{ways}'+('_tie_mutation' if mutant else '')
  v=out/(tag+'.v');v.write_text(body.replace('rank_way[WAY_W-1:0]','~rank_way[WAY_W-1:0]') if mutant else body)
  ys=out/(tag+'.ys');ys.write_text(f'read_verilog -sv {v}; prep -top miter -flatten; memory_map; opt; sat -verify -prove-asserts -set-def-inputs\n')
  p=subprocess.run(['yosys','-Q','-T','-s',str(ys)],capture_output=True,text=True,timeout=120);(out/(tag+'.log')).write_text(p.stdout+p.stderr)
  if mutant:assert p.returncode!=0 and 'proof did fail' in p.stdout+p.stderr,(tag,p.returncode,p.stdout[-1000:])
  else:assert p.returncode==0 and 'SUCCESS' in p.stdout,(tag,p.returncode,p.stdout[-1000:])
  results.append(dict(ways=ways,tie_mutation=mutant,accepted=True));print('PROVEN' if not mutant else 'MUTATION CAUGHT',tag,flush=True)
(out/'report.json').write_text(json.dumps(dict(source_sha256=hashlib.sha256(s.encode()).hexdigest(),scope='actual RTL leaf records and comparator tree vs strict serial argmin for arbitrary rank keys, payload dead bits and claimed masks; rank-key classification covered separately',results=results),indent=2)+'\n')
