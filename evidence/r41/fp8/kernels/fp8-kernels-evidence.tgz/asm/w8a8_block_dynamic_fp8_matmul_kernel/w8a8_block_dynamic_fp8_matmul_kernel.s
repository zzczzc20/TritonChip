    s.rdspecial  s1, arg_base
    s.movz       s2, #15
    s.ld.sw      s3, [s1, #40]                   // N: i32 at arg_base+40
    s.rdspecial  s4, pid.x
    s.rdspecial  s5, pid.y
    s.movz       s6, #16
    s.ld.sw      s7, [s1, #32]                   // M: i32 at arg_base+32
    s.add        s8, s7, s2
    s.ld.d       s2, [s1, #0]                    // A: device_ptr64 at arg_base+0
    s.movz       s9, #0
    s.ld.d       s10, [s1, #8]                   // B: device_ptr64 at arg_base+8
    s.movz       s11, #0
    s.ld.d       s12, [s1, #16]                  // C: device_ptr64 at arg_base+16
    s.cmp.lt     s13, s8, s11
    s.ld.d       s11, [s1, #24]                  // Bs: device_ptr64 at arg_base+24
    s.sub        s14, s9, s13
    s.movz       s9, #0
    s.movz       s13, #0
    s.ld.sw      s15, [s1, #48]                  // K: i32 at arg_base+48
    s.cmp.lt     s16, s6, s9
    s.ld.sw      s9, [s1, #56]                   // stride_am: i32 at arg_base+56
    s.sub        s17, s13, s16
    s.ld.sw      s13, [s1, #64]                  // stride_bn: i32 at arg_base+64
    s.xor        s16, s8, s14
    s.ld.sw      s8, [s1, #72]                   // stride_cm: i32 at arg_base+72
    s.sub        s18, s16, s14
    s.ld.sw      s16, [s1, #80]                  // stride_bs_n: i32 at arg_base+80
    s.movz       s1, #127
    s.movz       s19, #0
    s.add        s20, s3, s1
    s.movz       s21, #0
    s.cmp.lt     s22, s20, s19
    s.movz       s19, #128
    s.sub        s23, s21, s22
    s.movz       s21, #0
    s.lshri      s22, s18, #4
    s.xor        s24, s14, s17
    s.muli       s14, s22, #16
    s.xor        s25, s6, s17
    s.xor        s26, s22, s24
    s.sub        s22, s25, s17
    s.movz       s17, #0
    s.xor        s22, s20, s23
    s.cmp.lt     s20, s19, s17
    s.sub        s17, s18, s14
    s.sub        s14, s21, s20
    s.sub        s17, s22, s23
    s.xor        s18, s19, s14
    s.sub        s20, s26, s24
    s.lshri      s21, s17, #7
    s.xor        s22, s23, s14
    s.movz       s23, #8
    s.xor        s24, s21, s22
    s.movz       s25, #0
    s.sub        s26, s24, s22
    s.movz       s22, #0
    s.mul        s24, s4, s26
    s.mul        s4, s26, s23
    s.muli       s26, s21, #128
    s.sub        s21, s18, s14
    s.movz       s14, #0
    s.add        s18, s24, s5
    s.cmp.lt     s5, s4, s14
    s.movz       s14, #0
    s.cmp.lt     s21, s18, s25
    s.sub        s24, s22, s5
    s.sub        s5, s14, s21
    s.sub        s14, s17, s26
    s.xor        s14, s4, s24
    s.xor        s17, s18, s5
    s.sub        s21, s14, s24
    s.movz       s14, #0
    s.movz       s22, #1
    s.sub        s25, s17, s5
    s.movz       s17, #0
    s.addi       s26, s14, #0
    s.cmp.eq     s14, s21, s22
    s.addi       s22, s17, #0
    s.mov        s26, s25
    br.nz        s14, sdiv_done_1
    s.movz       s14, #0
    s.mov        s26, s14
    s.movz       s14, #31
    s.addi       s17, s14, #0
sdiv_2:
    s.lshr       s14, s25, s17
    s.andi       s27, s14, #1
    s.shli       s14, s22, #1
    s.or         s28, s14, s27
    s.movz       s14, #0
    s.cmp.geu    s27, s28, s21
    s.sub        s29, s14, s27
    s.and        s14, s21, s29
    s.sub        s27, s28, s14
    s.mov        s22, s27
    s.movz       s14, #1
    s.shl        s27, s14, s17
    s.and        s14, s27, s29
    s.or         s27, s26, s14
    s.mov        s26, s27
    s.subi       s14, s17, #1
    s.mov        s17, s14
    s.movz       s14, #0
    s.cmp.ge     s27, s17, s14
    br.nz        s27, sdiv_2
sdiv_done_1:
    s.xor        s14, s5, s24
    s.movz       s5, #0
    s.xor        s17, s26, s14
    s.movz       s21, #0
    s.cmp.lt     s22, s4, s5
    s.sub        s5, s17, s14
    s.movz       s14, #0
    s.cmp.lt     s17, s18, s21
    s.sub        s21, s14, s22
    s.movz       s14, #0
    s.mul        s22, s5, s23
    s.sub        s5, s14, s17
    s.xor        s14, s4, s21
    s.xor        s4, s18, s5
    s.sub        s17, s14, s21
    s.movz       s14, #0
    s.sub        s18, s20, s22
    s.sub        s20, s4, s5
    s.movz       s4, #0
    s.addi       s21, s14, #0
    s.min.s      s14, s18, s23
    s.movz       s18, #1
    s.addi       s23, s4, #0
    s.cmp.eq     s4, s17, s18
    s.mov        s21, s20
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.mov        s21, s4
    s.movz       s4, #31
    s.addi       s18, s4, #0
sdiv_4:
    s.lshr       s4, s20, s18
    s.andi       s24, s4, #1
    s.shli       s4, s23, #1
    s.or         s25, s4, s24
    s.movz       s4, #0
    s.cmp.geu    s24, s25, s17
    s.sub        s26, s4, s24
    s.and        s4, s17, s26
    s.sub        s24, s25, s4
    s.mov        s23, s24
    s.movz       s4, #1
    s.shl        s24, s4, s18
    s.and        s4, s24, s26
    s.or         s24, s21, s4
    s.mov        s21, s24
    s.subi       s4, s18, #1
    s.mov        s18, s4
    s.movz       s4, #0
    s.cmp.ge     s24, s18, s4
    br.nz        s24, sdiv_4
sdiv_done_3:
    s.xor        s4, s23, s5
    s.movz       s17, #0
    s.sub        s18, s4, s5
    s.movz       s4, #0
    s.movz       s5, #0
    s.cmp.lt     s20, s14, s17
    s.movz       s17, #0
    s.cmp.lt     s21, s18, s4
    s.sub        s4, s5, s20
    s.sub        s5, s17, s21
    s.xor        s17, s14, s4
    s.xor        s20, s18, s5
    s.sub        s21, s17, s4
    s.movz       s4, #0
    s.movz       s17, #1
    s.sub        s23, s20, s5
    s.movz       s20, #0
    s.addi       s24, s4, #0
    s.cmp.eq     s4, s21, s17
    s.addi       s17, s20, #0
    s.mov        s24, s23
    br.nz        s4, sdiv_done_5
    s.movz       s4, #0
    s.mov        s24, s4
    s.movz       s4, #31
    s.addi       s20, s4, #0
sdiv_6:
    s.lshr       s4, s23, s20
    s.andi       s25, s4, #1
    s.shli       s4, s17, #1
    s.or         s26, s4, s25
    s.movz       s4, #0
    s.cmp.geu    s25, s26, s21
    s.sub        s27, s4, s25
    s.and        s4, s21, s27
    s.sub        s25, s26, s4
    s.mov        s17, s25
    s.movz       s4, #1
    s.shl        s25, s4, s20
    s.and        s4, s25, s27
    s.or         s25, s24, s4
    s.mov        s24, s25
    s.subi       s4, s20, #1
    s.mov        s20, s4
    s.movz       s4, #0
    s.cmp.ge     s25, s20, s4
    br.nz        s25, sdiv_6
sdiv_done_5:
    s.movz       s4, #0
    s.movz       s20, #0
    s.movz       s21, #0
    s.cmp.lt     s23, s14, s4
    s.cmp.lt     s4, s18, s20
    s.sub        s20, s21, s23
    s.movz       s21, #0
    s.xor        s23, s14, s20
    s.sub        s14, s21, s4
    s.xor        s4, s17, s5
    s.xor        s17, s18, s14
    s.sub        s18, s23, s20
    s.movz       s21, #0
    s.sub        s23, s4, s5
    s.sub        s4, s17, s14
    s.movz       s5, #0
    s.addi       s17, s21, #0
    s.add        s21, s22, s23
    s.movz       s22, #1
    s.addi       s23, s5, #0
    s.cmp.eq     s5, s18, s22
    s.mov        s17, s4
    br.nz        s5, sdiv_done_7
    s.movz       s5, #0
    s.mov        s17, s5
    s.movz       s5, #31
    s.addi       s22, s5, #0
sdiv_8:
    s.lshr       s5, s4, s22
    s.andi       s24, s5, #1
    s.shli       s5, s23, #1
    s.or         s25, s5, s24
    s.movz       s5, #0
    s.cmp.geu    s24, s25, s18
    s.sub        s26, s5, s24
    s.and        s5, s18, s26
    s.sub        s24, s25, s5
    s.mov        s23, s24
    s.movz       s5, #1
    s.shl        s24, s5, s22
    s.and        s5, s24, s26
    s.or         s24, s17, s5
    s.mov        s17, s24
    s.subi       s5, s22, #1
    s.mov        s22, s5
    s.movz       s5, #0
    s.cmp.ge     s24, s22, s5
    br.nz        s24, sdiv_8
sdiv_done_7:
    s.mul        s4, s21, s6
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s7
    v.movi       v2, #0
    s.xor        s5, s14, s20
    v.splat      v3, s4
    v.sub        v4, v2, v1
    s.xor        s14, s17, s5
    v.add        v5, v3, v0
    v.cmp.lt     p1, v1, v2
    s.sub        s17, s14, s5
    v.sub        v0, v2, v5
    v.cmp.lt     p2, v5, v2
    v.movi       v3, #1
    @p2 v.sel        v6, v0, v5
    @p1 v.sel        v0, v4, v1
    v.movi       v1, #0
    v.movi       v4, #0
    s.movz       s5, #31
idiv_9:
    v.splat      v5, s5
    v.shl        v7, v4, v3
    v.cmp.lt     p1, v4, v2
    v.lshr       v8, v6, v5
    v.shl        v9, v3, v5
    s.subi       s14, s5, #1
    v.and        v5, v8, v3
    v.or         v8, v7, v5
    v.cmp.geu    p3, v8, v0
    p.or         p4, p1, p3
    v.sub        v5, v8, v0
    @p4 v.sel        v7, v9, v2
    @p4 v.sel        v9, v5, v8
    v.or         v5, v1, v7
    v.mov        v4, v9
    v.mov        v1, v5
    s.mov        s5, s14
    s.movz       s14, #0
    s.cmp.ge     s18, s5, s14
    br.nz        s18, idiv_9
    s.mul        s5, s17, s19
    v.iota       v0                              // arange(0, VLEN)
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v3, #16
    v.iota       v5                              // arange(0, VLEN)
    v.movi       v6, #32
    v.iota       v7                              // arange(0, VLEN)
    v.movi       v8, #48
    v.iota       v9                              // arange(0, VLEN)
    v.movi       v10, #64
    v.sub        v11, v2, v4
    v.iota       v2                              // arange(0, VLEN)
    v.add        v12, v1, v3
    v.add        v1, v5, v6
    v.add        v3, v7, v8
    v.add        v5, v9, v10
    @p2 v.sel        v6, v11, v4
    v.splat      v4, s5
    v.movi       v7, #80
    v.iota       v8                              // arange(0, VLEN)
    v.movi       v9, #96
    v.iota       v10                             // arange(0, VLEN)
    v.movi       v11, #112
    v.add        v13, v4, v0
    v.add        v0, v2, v7
    v.add        v2, v8, v9
    v.add        v4, v10, v11
    v.splat      v7, s3
    v.splat      v8, s5
    v.splat      v9, s5
    v.splat      v10, s5
    v.splat      v11, s5
    v.splat      v14, s5
    v.splat      v15, s5
    v.splat      v16, s5
    v.movi       v17, #0
    v.add        v18, v8, v12
    v.add        v8, v9, v1
    v.cmp.lt     p1, v13, v17
    v.add        v1, v10, v3
    v.cmp.lt     p2, v7, v17
    v.add        v3, v11, v5
    v.sub        v5, v17, v13
    v.add        v9, v14, v0
    v.add        v0, v15, v2
    v.sub        v2, v17, v7
    v.add        v10, v16, v4
    v.splat      v4, s3
    v.splat      v11, s3
    v.splat      v12, s3
    v.splat      v14, s3
    v.splat      v15, s3
    v.splat      v16, s3
    v.splat      v19, s3
    v.movi       v20, #1
    @p1 v.sel        v21, v5, v13
    @p2 v.sel        v5, v2, v7
    v.movi       v2, #0
    v.movi       v7, #0
    s.movz       s14, #31
idiv_10:
    v.splat      v13, s14
    v.shl        v22, v7, v20
    v.cmp.lt     p2, v7, v17
    v.lshr       v23, v21, v13
    v.shl        v24, v20, v13
    s.subi       s17, s14, #1
    v.and        v13, v23, v20
    v.or         v23, v22, v13
    v.cmp.geu    p3, v23, v5
    p.or         p4, p2, p3
    v.sub        v13, v23, v5
    @p4 v.sel        v22, v24, v17
    @p4 v.sel        v24, v13, v23
    v.or         v13, v2, v22
    v.mov        v7, v24
    v.mov        v2, v13
    s.mov        s14, s17
    s.movz       s17, #0
    s.cmp.ge     s18, s14, s17
    br.nz        s18, idiv_10
    v.movi       v2, #0
    v.sub        v5, v17, v7
    v.movi       v13, #1
    v.sub        v17, v2, v18
    v.cmp.lt     p2, v18, v2
    @p1 v.sel        v20, v5, v7
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    @p2 v.sel        v7, v17, v18
    @p1 v.sel        v17, v5, v4
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s14, #31
idiv_11:
    v.splat      v18, s14
    v.shl        v21, v5, v13
    v.cmp.lt     p1, v5, v2
    v.lshr       v22, v7, v18
    v.shl        v23, v13, v18
    s.subi       s17, s14, #1
    v.and        v18, v22, v13
    v.or         v22, v21, v18
    v.cmp.geu    p3, v22, v17
    p.or         p4, p1, p3
    v.sub        v18, v22, v17
    @p4 v.sel        v21, v23, v2
    @p4 v.sel        v23, v18, v22
    v.or         v18, v4, v21
    v.mov        v5, v23
    v.mov        v4, v18
    s.mov        s14, s17
    s.movz       s17, #0
    s.cmp.ge     s18, s14, s17
    br.nz        s18, idiv_11
    v.movi       v4, #0
    v.sub        v7, v2, v5
    v.movi       v2, #1
    v.sub        v13, v4, v8
    v.cmp.lt     p1, v8, v4
    @p2 v.sel        v17, v7, v5
    v.sub        v5, v4, v11
    v.cmp.lt     p2, v11, v4
    @p1 v.sel        v7, v13, v8
    @p2 v.sel        v8, v5, v11
    v.movi       v5, #0
    v.movi       v11, #0
    s.movz       s14, #31
idiv_12:
    v.splat      v13, s14
    v.shl        v18, v11, v2
    v.cmp.lt     p2, v11, v4
    v.lshr       v21, v7, v13
    v.shl        v22, v2, v13
    s.subi       s17, s14, #1
    v.and        v13, v21, v2
    v.or         v21, v18, v13
    v.cmp.geu    p3, v21, v8
    p.or         p4, p2, p3
    v.sub        v13, v21, v8
    @p4 v.sel        v18, v22, v4
    @p4 v.sel        v22, v13, v21
    v.or         v13, v5, v18
    v.mov        v11, v22
    v.mov        v5, v13
    s.mov        s14, s17
    s.movz       s17, #0
    s.cmp.ge     s18, s14, s17
    br.nz        s18, idiv_12
    v.movi       v2, #0
    v.sub        v5, v4, v11
    v.movi       v4, #1
    v.sub        v7, v2, v1
    v.cmp.lt     p2, v1, v2
    @p1 v.sel        v8, v5, v11
    v.sub        v5, v2, v12
    v.cmp.lt     p1, v12, v2
    @p2 v.sel        v11, v7, v1
    @p1 v.sel        v1, v5, v12
    v.movi       v5, #0
    v.movi       v7, #0
    s.movz       s14, #31
idiv_13:
    v.splat      v12, s14
    v.shl        v13, v7, v4
    v.cmp.lt     p1, v7, v2
    v.lshr       v18, v11, v12
    v.shl        v21, v4, v12
    s.subi       s17, s14, #1
    v.and        v12, v18, v4
    v.or         v18, v13, v12
    v.cmp.geu    p3, v18, v1
    p.or         p4, p1, p3
    v.sub        v12, v18, v1
    @p4 v.sel        v13, v21, v2
    @p4 v.sel        v21, v12, v18
    v.or         v12, v5, v13
    v.mov        v7, v21
    v.mov        v5, v12
    s.mov        s14, s17
    s.movz       s17, #0
    s.cmp.ge     s18, s14, s17
    br.nz        s18, idiv_13
    v.movi       v1, #0
    v.sub        v4, v2, v7
    v.movi       v2, #1
    v.sub        v5, v1, v3
    v.cmp.lt     p1, v3, v1
    @p2 v.sel        v11, v4, v7
    v.sub        v4, v1, v14
    v.cmp.lt     p2, v14, v1
    @p1 v.sel        v7, v5, v3
    @p2 v.sel        v3, v4, v14
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s14, #31
idiv_14:
    v.splat      v12, s14
    v.shl        v13, v5, v2
    v.cmp.lt     p2, v5, v1
    v.lshr       v14, v7, v12
    v.shl        v18, v2, v12
    s.subi       s17, s14, #1
    v.and        v12, v14, v2
    v.or         v14, v13, v12
    v.cmp.geu    p3, v14, v3
    p.or         p4, p2, p3
    v.sub        v12, v14, v3
    @p4 v.sel        v13, v18, v1
    @p4 v.sel        v18, v12, v14
    v.or         v12, v4, v13
    v.mov        v5, v18
    v.mov        v4, v12
    s.mov        s14, s17
    s.movz       s17, #0
    s.cmp.ge     s18, s14, s17
    br.nz        s18, idiv_14
    v.movi       v2, #0
    v.sub        v3, v1, v5
    v.movi       v1, #1
    v.sub        v4, v2, v9
    v.cmp.lt     p2, v9, v2
    @p1 v.sel        v7, v3, v5
    v.sub        v3, v2, v15
    v.cmp.lt     p1, v15, v2
    @p2 v.sel        v5, v4, v9
    @p1 v.sel        v4, v3, v15
    v.movi       v3, #0
    v.movi       v9, #0
    s.movz       s14, #31
idiv_15:
    v.splat      v12, s14
    v.shl        v13, v9, v1
    v.cmp.lt     p1, v9, v2
    v.lshr       v14, v5, v12
    v.shl        v15, v1, v12
    s.subi       s17, s14, #1
    v.and        v12, v14, v1
    v.or         v14, v13, v12
    v.cmp.geu    p3, v14, v4
    p.or         p4, p1, p3
    v.sub        v12, v14, v4
    @p4 v.sel        v13, v15, v2
    @p4 v.sel        v15, v12, v14
    v.or         v12, v3, v13
    v.mov        v9, v15
    v.mov        v3, v12
    s.mov        s14, s17
    s.movz       s17, #0
    s.cmp.ge     s18, s14, s17
    br.nz        s18, idiv_15
    v.movi       v1, #0
    v.sub        v3, v2, v9
    v.movi       v2, #1
    v.sub        v4, v1, v0
    v.cmp.lt     p1, v0, v1
    @p2 v.sel        v5, v3, v9
    v.sub        v3, v1, v16
    v.cmp.lt     p2, v16, v1
    @p1 v.sel        v9, v4, v0
    @p2 v.sel        v0, v3, v16
    v.movi       v3, #0
    v.movi       v4, #0
    s.movz       s14, #31
idiv_16:
    v.splat      v12, s14
    v.shl        v13, v4, v2
    v.cmp.lt     p2, v4, v1
    v.lshr       v14, v9, v12
    v.shl        v15, v2, v12
    s.subi       s17, s14, #1
    v.and        v12, v14, v2
    v.or         v14, v13, v12
    v.cmp.geu    p3, v14, v0
    p.or         p4, p2, p3
    v.sub        v12, v14, v0
    @p4 v.sel        v13, v15, v1
    @p4 v.sel        v15, v12, v14
    v.or         v12, v3, v13
    v.mov        v4, v15
    v.mov        v3, v12
    s.mov        s14, s17
    s.movz       s17, #0
    s.cmp.ge     s18, s14, s17
    br.nz        s18, idiv_16
    v.movi       v0, #0
    v.sub        v2, v1, v4
    v.movi       v1, #1
    v.sub        v3, v0, v10
    v.cmp.lt     p2, v10, v0
    @p1 v.sel        v9, v2, v4
    v.sub        v2, v0, v19
    v.cmp.lt     p1, v19, v0
    @p2 v.sel        v4, v3, v10
    @p1 v.sel        v3, v2, v19
    v.movi       v2, #0
    v.movi       v10, #0
    s.movz       s14, #31
idiv_17:
    v.splat      v12, s14
    v.shl        v13, v10, v1
    v.cmp.lt     p1, v10, v0
    v.lshr       v14, v4, v12
    v.shl        v15, v1, v12
    s.subi       s17, s14, #1
    v.and        v12, v14, v1
    v.or         v14, v13, v12
    v.cmp.geu    p3, v14, v3
    p.or         p4, p1, p3
    v.sub        v12, v14, v3
    @p4 v.sel        v13, v15, v0
    @p4 v.sel        v15, v12, v14
    v.or         v12, v2, v13
    v.mov        v10, v15
    v.mov        v2, v12
    s.mov        s14, s17
    s.movz       s17, #0
    s.cmp.ge     s18, s14, s17
    br.nz        s18, idiv_17
    v.sub        v1, v0, v10
    v.movi       v0, #0
    v.movi       v2, #128
    @p2 v.sel        v3, v1, v10
    v.sub        v1, v0, v20
    v.cmp.lt     p1, v20, v0
    v.movi       v4, #7
    @p1 v.sel        v10, v1, v20
    v.sub        v1, v0, v2
    v.cmp.lt     p2, v2, v0
    s.movz       s14, #32
    v.lshr       v12, v10, v4
    s.movz       s17, #48
    s.movz       s18, #64
    v.sub        v4, v0, v12
    s.movz       s20, #80
    v.movi       v0, #128
    @p1 v.sel        v10, v4, v12
    s.movz       s21, #96
    v.movi       v4, #0
    s.movz       s22, #112
    v.movi       v12, #1
    v.sub        v12, v4, v17
    v.cmp.lt     p1, v17, v4
    v.movi       v13, #7
    @p1 v.sel        v14, v12, v17
    v.sub        v12, v4, v0
    @p2 v.sel        v15, v1, v2
    v.movi       v1, #0
    v.lshr       v2, v14, v13
    v.movi       v13, #128
    v.cmp.lt     p2, v8, v1
    v.sub        v14, v4, v2
    v.movi       v15, #1
    v.sub        v15, v1, v8
    @p1 v.sel        v16, v14, v2
    v.cmp.lt     p1, v0, v4
    @p2 v.sel        v2, v15, v8
    v.movi       v4, #7
    v.sub        v14, v1, v13
    @p1 v.sel        v15, v12, v0
    v.movi       v0, #0
    v.lshr       v12, v2, v4
    v.movi       v2, #128
    v.cmp.lt     p1, v11, v0
    v.sub        v4, v1, v12
    v.movi       v15, #1
    v.sub        v15, v0, v11
    @p2 v.sel        v18, v4, v12
    v.cmp.lt     p2, v13, v1
    @p1 v.sel        v1, v15, v11
    v.movi       v4, #7
    v.sub        v12, v0, v2
    @p2 v.sel        v15, v14, v13
    v.movi       v13, #0
    v.lshr       v14, v1, v4
    v.movi       v1, #128
    v.cmp.lt     p2, v7, v13
    v.sub        v4, v0, v14
    v.movi       v15, #1
    v.sub        v15, v13, v7
    @p1 v.sel        v19, v4, v14
    v.cmp.lt     p1, v2, v0
    @p2 v.sel        v0, v15, v7
    v.movi       v4, #7
    v.sub        v14, v13, v1
    @p1 v.sel        v15, v12, v2
    v.movi       v2, #0
    v.lshr       v12, v0, v4
    v.movi       v0, #128
    v.cmp.lt     p1, v5, v2
    v.sub        v4, v13, v12
    v.movi       v15, #1
    v.sub        v15, v2, v5
    @p2 v.sel        v21, v4, v12
    v.cmp.lt     p2, v1, v13
    @p1 v.sel        v4, v15, v5
    v.movi       v12, #7
    v.sub        v13, v2, v0
    @p2 v.sel        v15, v14, v1
    v.movi       v1, #0
    v.lshr       v14, v4, v12
    v.movi       v4, #128
    v.cmp.lt     p2, v9, v1
    v.sub        v12, v2, v14
    v.movi       v15, #1
    v.sub        v15, v1, v9
    @p1 v.sel        v22, v12, v14
    v.cmp.lt     p1, v0, v2
    @p2 v.sel        v2, v15, v9
    v.movi       v12, #7
    v.sub        v14, v1, v4
    @p1 v.sel        v15, v13, v0
    v.movi       v0, #0
    v.lshr       v13, v2, v12
    v.movi       v2, #128
    v.cmp.lt     p1, v3, v0
    v.sub        v12, v1, v13
    v.movi       v15, #1
    v.sub        v15, v0, v3
    @p2 v.sel        v23, v12, v13
    v.cmp.lt     p2, v4, v1
    @p1 v.sel        v1, v15, v3
    v.movi       v12, #7
    v.sub        v13, v0, v2
    @p2 v.sel        v15, v14, v4
    v.lshr       v4, v1, v12
    v.splat      v1, s16
    v.splat      v12, s16
    v.sub        v14, v0, v4
    v.splat      v15, s16
    v.splat      v24, s16
    @p1 v.sel        v25, v14, v4
    v.splat      v4, s16
    v.cmp.lt     p1, v2, v0
    v.movi       v0, #1
    v.splat      v0, s16
    @p1 v.sel        v14, v13, v2
    s.add        s23, s15, s1
    s.movz       s1, #0
    s.movz       s24, #0
    s.cmp.lt     s25, s23, s1
    s.movz       s1, #0
    s.sub        s26, s24, s25
    v.splat      v2, s16
    s.movz       s24, #0
    v.splat      v13, s16
    s.cmp.lt     s16, s19, s24
    v.mul        v14, v10, v1
    s.sub        s24, s1, s16
    v.mul        v1, v16, v12
    s.xor        s1, s23, s26
    v.mul        v10, v18, v15
    s.sub        s16, s1, s26
    v.mul        v12, v19, v24
    s.xor        s1, s19, s24
    v.mul        v15, v21, v4
    v.mul        v4, v22, v0
    s.lshri      s23, s16, #7
    v.mul        v0, v23, v2
    s.muli       s25, s23, #128
    v.mul        v2, v25, v13
    s.xor        s27, s26, s24
    s.sub        s26, s1, s24
    s.xor        s1, s23, s27
    s.movz       s23, #0
    s.movz       s24, #0
    s.sub        s26, s16, s25
    s.movz       s16, #0
    s.sub        s25, s1, s27
    s.movz       s1, #1
    s.addi       s26, s23, #0
    s.addi       s27, s24, #0
    s.addi       s24, s16, #0
    s.addi       s16, s11, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_26:
    s.cmp.ge     s11, s26, s25
    br.nz        s11, endfor_27
    s.muli       s11, s9, #2
    s.mul        s28, s26, s19
    s.muli       s29, s27, #2
    s.movz       s30, #0
    v.iota       v13                             // arange(0, VLEN)
    v.splat      v16, s11
    s.sub        s11, s15, s28
    s.rdspecial  s28, arg_base
    v.mul        v18, v6, v16
    s.add        s31, s30, s11                   // the tile origin
    s.ld.d       s30, [s28, #88]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.extract    s28, v18, #0
    v.splat      v16, s31
    s.add        s31, s28, s29
    s.add        s28, s2, s31
    v.cmp.lt     p1, v13, v16
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s28, #0]
    s.addi       s28, s30, #0
    v.extract    s31, v18, #1
    v.extract    s32, v18, #2
    s.add        s33, s31, s29
    s.add        s31, s32, s29
    s.add        s32, s2, s33
    s.add        s33, s2, s31
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s28, #0], v19
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s32, #0]
    s.addi       s31, s28, #64
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s31, #0], v19
    v.extract    s31, v18, #3
    s.add        s32, s31, s29
    s.add        s31, s2, s32
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    s.addi       s32, s28, #128
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s32, #0], v19
    v.extract    s32, v18, #4
    s.add        s33, s32, s29
    s.add        s32, s2, s33
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s31, #0]
    s.addi       s31, s28, #192
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s31, #0], v19
    v.extract    s31, v18, #5
    s.add        s33, s31, s29
    s.add        s31, s2, s33
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s32, #0]
    s.addi       s32, s28, #256
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s32, #0], v19
    v.extract    s32, v18, #6
    s.add        s33, s32, s29
    s.add        s32, s2, s33
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s31, #0]
    s.addi       s31, s28, #320
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s31, #0], v19
    v.extract    s31, v18, #7
    s.add        s33, s31, s29
    s.add        s31, s2, s33
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s32, #0]
    s.addi       s32, s28, #384
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s32, #0], v19
    v.extract    s32, v18, #8
    s.add        s33, s32, s29
    s.add        s32, s2, s33
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s31, #0]
    s.addi       s31, s28, #448
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s31, #0], v19
    v.extract    s31, v18, #9
    s.add        s33, s31, s29
    s.add        s31, s2, s33
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s32, #0]
    s.addi       s32, s28, #512
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s32, #0], v19
    v.extract    s32, v18, #10
    s.add        s33, s32, s29
    s.add        s32, s2, s33
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s31, #0]
    s.addi       s31, s28, #576
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s31, #0], v19
    v.extract    s31, v18, #11
    s.add        s33, s31, s29
    s.add        s31, s2, s33
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s32, #0]
    s.addi       s32, s28, #640
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s32, #0], v19
    v.extract    s32, v18, #12
    s.add        s33, s32, s29
    s.add        s32, s2, s33
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s31, #0]
    s.addi       s31, s28, #704
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s31, #0], v19
    v.extract    s31, v18, #13
    s.add        s33, s31, s29
    s.add        s31, s2, s33
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s32, #0]
    s.addi       s32, s28, #768
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s32, #0], v19
    v.extract    s32, v18, #14
    s.add        s33, s32, s29
    s.add        s32, s2, s33
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s31, #0]
    s.addi       s31, s28, #832
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s31, #0], v19
    v.extract    s31, v18, #15
    s.add        s33, s31, s29
    s.add        s31, s2, s33
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s32, #0]
    s.addi       s32, s28, #896
    s.addi       s33, s28, #960
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s32, #0], v19
    s.movz       s28, #0
    s.add        s32, s28, s6                    // the tile origin
    v.extract    s28, v18, #0
    v.splat      v16, s32
    s.movz       s32, #0
    s.add        s34, s28, s29
    s.add        s28, s32, s11                   // the tile origin
    s.addi       s32, s34, #32
    v.add        v19, v13, v16
    v.splat      v16, s28
    s.add        s28, s2, s32
    s.addi       s32, s30, #1024
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v21, [s31, #0]
    v.cmp.lt     p1, v19, v16
    vf.cvt.bf16.f32 v16, v21
    v.st.w       [s33, #0], v16
    fence.acq_rel.device
    v.extract    s31, v18, #1
    v.extract    s33, v18, #2
    s.add        s34, s31, s29
    s.add        s31, s33, s29
    s.addi       s33, s34, #32
    s.addi       s34, s31, #32
    s.add        s31, s2, s33
    s.add        s33, s2, s34
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s28, #0]
    s.addi       s28, s32, #64
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s32, #0], v19
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s31, #0]
    v.extract    s31, v18, #3
    s.add        s34, s31, s29
    s.addi       s31, s34, #32
    s.add        s34, s2, s31
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s28, #0], v19
    s.addi       s28, s32, #128
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    v.extract    s31, v18, #4
    s.add        s33, s31, s29
    s.addi       s31, s33, #32
    s.add        s33, s2, s31
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s28, #0], v19
    s.addi       s28, s32, #192
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s34, #0]
    v.extract    s31, v18, #5
    s.add        s34, s31, s29
    s.addi       s31, s34, #32
    s.add        s34, s2, s31
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s28, #0], v19
    s.addi       s28, s32, #256
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    v.extract    s31, v18, #6
    s.add        s33, s31, s29
    s.addi       s31, s33, #32
    s.add        s33, s2, s31
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s28, #0], v19
    s.addi       s28, s32, #320
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s34, #0]
    v.extract    s31, v18, #7
    s.add        s34, s31, s29
    s.addi       s31, s34, #32
    s.add        s34, s2, s31
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s28, #0], v19
    s.addi       s28, s32, #384
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    v.extract    s31, v18, #8
    s.add        s33, s31, s29
    s.addi       s31, s33, #32
    s.add        s33, s2, s31
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s28, #0], v19
    s.addi       s28, s32, #448
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s34, #0]
    v.extract    s31, v18, #9
    s.add        s34, s31, s29
    s.addi       s31, s34, #32
    s.add        s34, s2, s31
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s28, #0], v19
    s.addi       s28, s32, #512
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    v.extract    s31, v18, #10
    s.add        s33, s31, s29
    s.addi       s31, s33, #32
    s.add        s33, s2, s31
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s28, #0], v19
    s.addi       s28, s32, #576
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s34, #0]
    v.extract    s31, v18, #11
    s.add        s34, s31, s29
    s.addi       s31, s34, #32
    s.add        s34, s2, s31
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s28, #0], v19
    s.addi       s28, s32, #640
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    v.extract    s31, v18, #12
    s.add        s33, s31, s29
    s.addi       s31, s33, #32
    s.add        s33, s2, s31
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s28, #0], v19
    s.addi       s28, s32, #704
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s34, #0]
    v.extract    s31, v18, #13
    s.add        s34, s31, s29
    s.addi       s31, s34, #32
    s.add        s34, s2, s31
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s28, #0], v19
    s.addi       s28, s32, #768
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    v.extract    s31, v18, #14
    s.add        s33, s31, s29
    s.addi       s31, s33, #32
    s.add        s33, s2, s31
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s28, #0], v19
    s.addi       s28, s32, #832
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s34, #0]
    v.extract    s31, v18, #15
    s.add        s34, s31, s29
    s.addi       s31, s34, #32
    s.add        s34, s2, s31
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s28, #0], v19
    s.addi       s28, s32, #896
    s.addi       s31, s32, #960
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    v.extract    s32, v18, #0
    s.add        s33, s32, s29
    s.addi       s32, s33, #64
    s.add        s33, s2, s32
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s28, #0], v19
    s.movz       s28, #0
    s.add        s32, s28, s14                   // the tile origin
    s.movz       s28, #0
    v.splat      v16, s32
    s.add        s32, s28, s11                   // the tile origin
    s.addi       s28, s30, #2048
    v.add        v19, v13, v16
    v.splat      v16, s32
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v21, [s34, #0]
    v.cmp.lt     p1, v19, v16
    vf.cvt.bf16.f32 v16, v21
    v.st.w       [s31, #0], v16
    fence.acq_rel.device
    v.extract    s31, v18, #1
    v.extract    s32, v18, #2
    s.add        s34, s31, s29
    s.add        s31, s32, s29
    s.addi       s32, s34, #64
    s.addi       s34, s31, #64
    s.add        s31, s2, s32
    s.addi       s32, s28, #64
    s.add        s35, s2, s34
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    s.addi       s33, s28, #128
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s28, #0], v19
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s31, #0]
    v.extract    s31, v18, #3
    s.add        s34, s31, s29
    s.addi       s31, s34, #64
    s.add        s34, s2, s31
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s32, #0], v19
    v.extract    s31, v18, #4
    s.add        s32, s31, s29
    s.addi       s31, s32, #64
    s.add        s32, s2, s31
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s35, #0]
    s.addi       s31, s28, #192
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s33, #0], v19
    v.extract    s33, v18, #5
    s.add        s35, s33, s29
    s.addi       s33, s35, #64
    s.add        s35, s2, s33
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s34, #0]
    s.addi       s33, s28, #256
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s31, #0], v19
    v.extract    s31, v18, #6
    s.add        s34, s31, s29
    s.addi       s31, s34, #64
    s.add        s34, s2, s31
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s32, #0]
    s.addi       s31, s28, #320
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s33, #0], v19
    v.extract    s32, v18, #7
    s.add        s33, s32, s29
    s.addi       s32, s33, #64
    s.add        s33, s2, s32
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s35, #0]
    s.addi       s32, s28, #384
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s31, #0], v19
    v.extract    s31, v18, #8
    s.add        s35, s31, s29
    s.addi       s31, s35, #64
    s.add        s35, s2, s31
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s34, #0]
    s.addi       s31, s28, #448
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s32, #0], v19
    v.extract    s32, v18, #9
    s.add        s34, s32, s29
    s.addi       s32, s34, #64
    s.add        s34, s2, s32
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    s.addi       s32, s28, #512
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s31, #0], v19
    v.extract    s31, v18, #10
    s.add        s33, s31, s29
    s.addi       s31, s33, #64
    s.add        s33, s2, s31
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s35, #0]
    s.addi       s31, s28, #576
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s32, #0], v19
    v.extract    s32, v18, #11
    s.add        s35, s32, s29
    s.addi       s32, s35, #64
    s.add        s35, s2, s32
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s34, #0]
    s.addi       s32, s28, #640
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s31, #0], v19
    v.extract    s31, v18, #12
    s.add        s34, s31, s29
    s.addi       s31, s34, #64
    s.add        s34, s2, s31
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    s.addi       s31, s28, #704
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s32, #0], v19
    v.extract    s32, v18, #13
    s.add        s33, s32, s29
    s.addi       s32, s33, #64
    s.add        s33, s2, s32
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s35, #0]
    s.addi       s32, s28, #768
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s31, #0], v19
    v.extract    s31, v18, #14
    s.add        s35, s31, s29
    s.addi       s31, s35, #64
    s.add        s35, s2, s31
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s34, #0]
    s.addi       s31, s28, #832
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s32, #0], v19
    v.extract    s32, v18, #15
    s.add        s34, s32, s29
    s.addi       s32, s34, #64
    s.add        s34, s2, s32
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    s.addi       s32, s28, #896
    s.addi       s33, s28, #960
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s31, #0], v19
    v.extract    s28, v18, #0
    s.add        s31, s28, s29
    s.addi       s28, s31, #96
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s35, #0]
    s.add        s31, s2, s28
    s.addi       s28, s30, #3072
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s32, #0], v19
    s.movz       s32, #0
    s.add        s35, s32, s17                   // the tile origin
    s.movz       s32, #0
    v.splat      v16, s35
    s.add        s35, s32, s11                   // the tile origin
    v.add        v19, v13, v16
    v.splat      v16, s35
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v21, [s34, #0]
    v.cmp.lt     p1, v19, v16
    vf.cvt.bf16.f32 v16, v21
    v.st.w       [s33, #0], v16
    fence.acq_rel.device
    v.extract    s32, v18, #1
    v.extract    s33, v18, #2
    s.add        s34, s32, s29
    s.add        s32, s33, s29
    s.addi       s33, s34, #96
    s.addi       s34, s32, #96
    s.add        s32, s2, s33
    s.addi       s33, s28, #64
    s.add        s35, s2, s34
    s.addi       s34, s28, #128
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s31, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s28, #0], v19
    v.extract    s31, v18, #3
    s.add        s36, s31, s29
    s.addi       s31, s36, #96
    s.add        s36, s2, s31
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s32, #0]
    s.addi       s31, s28, #192
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s33, #0], v19
    v.extract    s32, v18, #4
    s.add        s33, s32, s29
    s.addi       s32, s33, #96
    s.add        s33, s2, s32
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s35, #0]
    s.addi       s32, s28, #256
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s34, #0], v19
    v.extract    s34, v18, #5
    s.add        s35, s34, s29
    s.addi       s34, s35, #96
    s.add        s35, s2, s34
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s36, #0]
    s.addi       s34, s28, #320
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s31, #0], v19
    v.extract    s31, v18, #6
    s.add        s36, s31, s29
    s.addi       s31, s36, #96
    s.add        s36, s2, s31
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    s.addi       s31, s28, #384
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s32, #0], v19
    v.extract    s32, v18, #7
    s.add        s33, s32, s29
    s.addi       s32, s33, #96
    s.add        s33, s2, s32
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s35, #0]
    s.addi       s32, s28, #448
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s34, #0], v19
    v.extract    s34, v18, #8
    s.add        s35, s34, s29
    s.addi       s34, s35, #96
    s.add        s35, s2, s34
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s36, #0]
    s.addi       s34, s28, #512
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s31, #0], v19
    v.extract    s31, v18, #9
    s.add        s36, s31, s29
    s.addi       s31, s36, #96
    s.add        s36, s2, s31
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    s.addi       s31, s28, #576
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s32, #0], v19
    v.extract    s32, v18, #10
    s.add        s33, s32, s29
    s.addi       s32, s33, #96
    s.add        s33, s2, s32
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s35, #0]
    s.addi       s32, s28, #640
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s34, #0], v19
    v.extract    s34, v18, #11
    s.add        s35, s34, s29
    s.addi       s34, s35, #96
    s.add        s35, s2, s34
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s36, #0]
    s.addi       s34, s28, #704
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s31, #0], v19
    v.extract    s31, v18, #12
    s.add        s36, s31, s29
    s.addi       s31, s36, #96
    s.add        s36, s2, s31
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    s.addi       s31, s28, #768
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s32, #0], v19
    v.extract    s32, v18, #13
    s.add        s33, s32, s29
    s.addi       s32, s33, #96
    s.add        s33, s2, s32
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s35, #0]
    s.addi       s32, s28, #832
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s34, #0], v19
    v.extract    s34, v18, #14
    s.add        s35, s34, s29
    s.addi       s34, s35, #96
    s.add        s35, s2, s34
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s36, #0]
    s.addi       s34, s28, #896
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s31, #0], v19
    v.extract    s31, v18, #15
    s.addi       s36, s28, #960
    s.add        s28, s31, s29
    s.addi       s31, s28, #96
    s.add        s28, s2, s31
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s32, #0], v19
    v.extract    s31, v18, #0
    s.addi       s32, s30, #4096
    s.add        s33, s31, s29
    s.addi       s31, s33, #128
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s35, #0]
    s.add        s33, s2, s31
    vf.cvt.bf16.f32 v19, v16
    s.movz       s31, #0
    v.st.w       [s34, #0], v19
    s.add        s34, s31, s18                   // the tile origin
    s.movz       s31, #0
    v.splat      v16, s34
    s.add        s34, s31, s11                   // the tile origin
    v.add        v19, v13, v16
    v.splat      v16, s34
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v21, [s28, #0]
    v.cmp.lt     p1, v19, v16
    vf.cvt.bf16.f32 v16, v21
    v.st.w       [s36, #0], v16
    fence.acq_rel.device
    v.extract    s28, v18, #1
    v.extract    s31, v18, #2
    s.add        s34, s28, s29
    s.add        s28, s31, s29
    s.addi       s31, s34, #128
    s.addi       s34, s28, #128
    s.add        s28, s2, s31
    s.addi       s31, s32, #64
    s.add        s35, s2, s34
    s.addi       s34, s32, #128
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s32, #0], v19
    v.extract    s33, v18, #3
    s.addi       s36, s32, #192
    s.add        s37, s33, s29
    s.addi       s33, s37, #128
    s.add        s37, s2, s33
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s28, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s31, #0], v19
    v.extract    s28, v18, #4
    s.addi       s31, s32, #256
    s.add        s33, s28, s29
    s.addi       s28, s33, #128
    s.add        s33, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s35, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s34, #0], v19
    v.extract    s28, v18, #5
    s.addi       s34, s32, #320
    s.add        s35, s28, s29
    s.addi       s28, s35, #128
    s.add        s35, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s37, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s36, #0], v19
    v.extract    s28, v18, #6
    s.addi       s36, s32, #384
    s.add        s37, s28, s29
    s.addi       s28, s37, #128
    s.add        s37, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s31, #0], v19
    v.extract    s28, v18, #7
    s.addi       s31, s32, #448
    s.add        s33, s28, s29
    s.addi       s28, s33, #128
    s.add        s33, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s35, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s34, #0], v19
    v.extract    s28, v18, #8
    s.addi       s34, s32, #512
    s.add        s35, s28, s29
    s.addi       s28, s35, #128
    s.add        s35, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s37, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s36, #0], v19
    v.extract    s28, v18, #9
    s.addi       s36, s32, #576
    s.add        s37, s28, s29
    s.addi       s28, s37, #128
    s.add        s37, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s31, #0], v19
    v.extract    s28, v18, #10
    s.addi       s31, s32, #640
    s.add        s33, s28, s29
    s.addi       s28, s33, #128
    s.add        s33, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s35, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s34, #0], v19
    v.extract    s28, v18, #11
    s.addi       s34, s32, #704
    s.add        s35, s28, s29
    s.addi       s28, s35, #128
    s.add        s35, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s37, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s36, #0], v19
    v.extract    s28, v18, #12
    s.addi       s36, s32, #768
    s.add        s37, s28, s29
    s.addi       s28, s37, #128
    s.add        s37, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s31, #0], v19
    v.extract    s28, v18, #13
    s.addi       s31, s32, #832
    s.add        s33, s28, s29
    s.addi       s28, s33, #128
    s.add        s33, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s35, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s34, #0], v19
    v.extract    s28, v18, #14
    s.addi       s34, s32, #896
    s.add        s35, s28, s29
    s.addi       s28, s35, #128
    s.add        s35, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s37, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s36, #0], v19
    v.extract    s28, v18, #15
    s.addi       s36, s32, #960
    s.add        s32, s28, s29
    s.addi       s28, s32, #128
    s.add        s32, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s31, #0], v19
    v.extract    s28, v18, #0
    s.addi       s31, s30, #5120
    s.add        s33, s28, s29
    s.addi       s28, s33, #160
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s35, #0]
    s.add        s33, s2, s28
    vf.cvt.bf16.f32 v19, v16
    s.movz       s28, #0
    v.st.w       [s34, #0], v19
    s.add        s34, s28, s20                   // the tile origin
    s.movz       s28, #0
    v.splat      v16, s34
    s.add        s34, s28, s11                   // the tile origin
    v.add        v19, v13, v16
    v.splat      v16, s34
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v21, [s32, #0]
    v.cmp.lt     p1, v19, v16
    vf.cvt.bf16.f32 v16, v21
    v.st.w       [s36, #0], v16
    fence.acq_rel.device
    v.extract    s28, v18, #1
    v.extract    s32, v18, #2
    s.add        s34, s28, s29
    s.add        s28, s32, s29
    s.addi       s32, s34, #160
    s.addi       s34, s28, #160
    s.add        s28, s2, s32
    s.addi       s32, s31, #64
    s.add        s35, s2, s34
    s.addi       s34, s31, #128
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s31, #0], v19
    v.extract    s33, v18, #3
    s.addi       s36, s31, #192
    s.add        s37, s33, s29
    s.addi       s33, s37, #160
    s.add        s37, s2, s33
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s28, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s32, #0], v19
    v.extract    s28, v18, #4
    s.addi       s32, s31, #256
    s.add        s33, s28, s29
    s.addi       s28, s33, #160
    s.add        s33, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s35, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s34, #0], v19
    v.extract    s28, v18, #5
    s.addi       s34, s31, #320
    s.add        s35, s28, s29
    s.addi       s28, s35, #160
    s.add        s35, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s37, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s36, #0], v19
    v.extract    s28, v18, #6
    s.addi       s36, s31, #384
    s.add        s37, s28, s29
    s.addi       s28, s37, #160
    s.add        s37, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s32, #0], v19
    v.extract    s28, v18, #7
    s.addi       s32, s31, #448
    s.add        s33, s28, s29
    s.addi       s28, s33, #160
    s.add        s33, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s35, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s34, #0], v19
    v.extract    s28, v18, #8
    s.addi       s34, s31, #512
    s.add        s35, s28, s29
    s.addi       s28, s35, #160
    s.add        s35, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s37, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s36, #0], v19
    v.extract    s28, v18, #9
    s.addi       s36, s31, #576
    s.add        s37, s28, s29
    s.addi       s28, s37, #160
    s.add        s37, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s32, #0], v19
    v.extract    s28, v18, #10
    s.addi       s32, s31, #640
    s.add        s33, s28, s29
    s.addi       s28, s33, #160
    s.add        s33, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s35, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s34, #0], v19
    v.extract    s28, v18, #11
    s.addi       s34, s31, #704
    s.add        s35, s28, s29
    s.addi       s28, s35, #160
    s.add        s35, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s37, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s36, #0], v19
    v.extract    s28, v18, #12
    s.addi       s36, s31, #768
    s.add        s37, s28, s29
    s.addi       s28, s37, #160
    s.add        s37, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s32, #0], v19
    v.extract    s28, v18, #13
    s.addi       s32, s31, #832
    s.add        s33, s28, s29
    s.addi       s28, s33, #160
    s.add        s33, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s35, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s34, #0], v19
    v.extract    s28, v18, #14
    s.addi       s34, s31, #896
    s.add        s35, s28, s29
    s.addi       s28, s35, #160
    s.add        s35, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s37, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s36, #0], v19
    v.extract    s28, v18, #15
    s.addi       s36, s31, #960
    s.add        s31, s28, s29
    s.addi       s28, s31, #160
    s.add        s31, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s32, #0], v19
    v.extract    s28, v18, #0
    s.addi       s32, s30, #6144
    s.add        s33, s28, s29
    s.addi       s28, s33, #192
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s35, #0]
    s.add        s33, s2, s28
    vf.cvt.bf16.f32 v19, v16
    s.movz       s28, #0
    v.st.w       [s34, #0], v19
    s.add        s34, s28, s21                   // the tile origin
    s.movz       s28, #0
    v.splat      v16, s34
    s.add        s34, s28, s11                   // the tile origin
    v.add        v19, v13, v16
    v.splat      v16, s34
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v21, [s31, #0]
    v.cmp.lt     p1, v19, v16
    vf.cvt.bf16.f32 v16, v21
    v.st.w       [s36, #0], v16
    fence.acq_rel.device
    v.extract    s28, v18, #1
    v.extract    s31, v18, #2
    s.add        s34, s28, s29
    s.add        s28, s31, s29
    s.addi       s31, s34, #192
    s.addi       s34, s28, #192
    s.add        s28, s2, s31
    s.addi       s31, s32, #64
    s.add        s35, s2, s34
    s.addi       s34, s32, #128
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s32, #0], v19
    v.extract    s33, v18, #3
    s.addi       s36, s32, #192
    s.add        s37, s33, s29
    s.addi       s33, s37, #192
    s.add        s37, s2, s33
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s28, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s31, #0], v19
    v.extract    s28, v18, #4
    s.addi       s31, s32, #256
    s.add        s33, s28, s29
    s.addi       s28, s33, #192
    s.add        s33, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s35, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s34, #0], v19
    v.extract    s28, v18, #5
    s.addi       s34, s32, #320
    s.add        s35, s28, s29
    s.addi       s28, s35, #192
    s.add        s35, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s37, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s36, #0], v19
    v.extract    s28, v18, #6
    s.addi       s36, s32, #384
    s.add        s37, s28, s29
    s.addi       s28, s37, #192
    s.add        s37, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s31, #0], v19
    v.extract    s28, v18, #7
    s.addi       s31, s32, #448
    s.add        s33, s28, s29
    s.addi       s28, s33, #192
    s.add        s33, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s35, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s34, #0], v19
    v.extract    s28, v18, #8
    s.addi       s34, s32, #512
    s.add        s35, s28, s29
    s.addi       s28, s35, #192
    s.add        s35, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s37, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s36, #0], v19
    v.extract    s28, v18, #9
    s.addi       s36, s32, #576
    s.add        s37, s28, s29
    s.addi       s28, s37, #192
    s.add        s37, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s31, #0], v19
    v.extract    s28, v18, #10
    s.addi       s31, s32, #640
    s.add        s33, s28, s29
    s.addi       s28, s33, #192
    s.add        s33, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s35, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s34, #0], v19
    v.extract    s28, v18, #11
    s.addi       s34, s32, #704
    s.add        s35, s28, s29
    s.addi       s28, s35, #192
    s.add        s35, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s37, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s36, #0], v19
    v.extract    s28, v18, #12
    s.addi       s36, s32, #768
    s.add        s37, s28, s29
    s.addi       s28, s37, #192
    s.add        s37, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s31, #0], v19
    v.extract    s28, v18, #13
    s.addi       s31, s32, #832
    s.add        s33, s28, s29
    s.addi       s28, s33, #192
    s.add        s33, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s35, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s34, #0], v19
    v.extract    s28, v18, #14
    s.addi       s34, s32, #896
    s.add        s35, s28, s29
    s.addi       s28, s35, #192
    s.add        s35, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s37, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s36, #0], v19
    v.extract    s28, v18, #15
    s.addi       s36, s32, #960
    s.add        s32, s28, s29
    s.addi       s28, s32, #192
    s.add        s32, s2, s28
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s33, #0]
    vf.cvt.bf16.f32 v19, v16
    v.st.w       [s31, #0], v19
    v.extract    s28, v18, #0
    s.addi       s31, s30, #7168
    s.add        s33, s28, s29
    s.addi       s28, s33, #224
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s35, #0]
    s.add        s33, s2, s28
    vf.cvt.bf16.f32 v19, v16
    s.movz       s28, #0
    v.st.w       [s34, #0], v19
    s.add        s34, s28, s22                   // the tile origin
    s.movz       s28, #0
    v.splat      v16, s34
    s.add        s34, s28, s11                   // the tile origin
    v.add        v19, v13, v16
    v.splat      v13, s34
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s32, #0]
    v.cmp.lt     p1, v19, v13
    vf.cvt.bf16.f32 v13, v16
    v.st.w       [s36, #0], v13
    fence.acq_rel.device
    v.extract    s28, v18, #1
    v.extract    s32, v18, #2
    s.add        s34, s28, s29
    s.add        s28, s32, s29
    s.addi       s32, s34, #224
    s.addi       s34, s28, #224
    s.add        s28, s2, s32
    s.addi       s32, s31, #64
    s.add        s35, s2, s34
    s.addi       s34, s31, #128
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s33, #0]
    vf.cvt.bf16.f32 v16, v13
    v.st.w       [s31, #0], v16
    v.extract    s33, v18, #3
    s.addi       s36, s31, #192
    s.add        s37, s33, s29
    s.addi       s33, s37, #224
    s.add        s37, s2, s33
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s28, #0]
    vf.cvt.bf16.f32 v16, v13
    v.st.w       [s32, #0], v16
    v.extract    s28, v18, #4
    s.addi       s32, s31, #256
    s.add        s33, s28, s29
    s.addi       s28, s33, #224
    s.add        s33, s2, s28
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s35, #0]
    vf.cvt.bf16.f32 v16, v13
    v.st.w       [s34, #0], v16
    v.extract    s28, v18, #5
    s.addi       s34, s31, #320
    s.add        s35, s28, s29
    s.addi       s28, s35, #224
    s.add        s35, s2, s28
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s37, #0]
    vf.cvt.bf16.f32 v16, v13
    v.st.w       [s36, #0], v16
    v.extract    s28, v18, #6
    s.addi       s36, s31, #384
    s.add        s37, s28, s29
    s.addi       s28, s37, #224
    s.add        s37, s2, s28
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s33, #0]
    vf.cvt.bf16.f32 v16, v13
    v.st.w       [s32, #0], v16
    v.extract    s28, v18, #7
    s.addi       s32, s31, #448
    s.add        s33, s28, s29
    s.addi       s28, s33, #224
    s.add        s33, s2, s28
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s35, #0]
    vf.cvt.bf16.f32 v16, v13
    v.st.w       [s34, #0], v16
    v.extract    s28, v18, #8
    s.addi       s34, s31, #512
    s.add        s35, s28, s29
    s.addi       s28, s35, #224
    s.add        s35, s2, s28
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s37, #0]
    vf.cvt.bf16.f32 v16, v13
    v.st.w       [s36, #0], v16
    v.extract    s28, v18, #9
    s.addi       s36, s31, #576
    s.add        s37, s28, s29
    s.addi       s28, s37, #224
    s.add        s37, s2, s28
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s33, #0]
    vf.cvt.bf16.f32 v16, v13
    v.st.w       [s32, #0], v16
    v.extract    s28, v18, #10
    s.addi       s32, s31, #640
    s.add        s33, s28, s29
    s.addi       s28, s33, #224
    s.add        s33, s2, s28
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s35, #0]
    vf.cvt.bf16.f32 v16, v13
    v.st.w       [s34, #0], v16
    v.extract    s28, v18, #11
    s.addi       s34, s31, #704
    s.add        s35, s28, s29
    s.addi       s28, s35, #224
    s.add        s35, s2, s28
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s37, #0]
    vf.cvt.bf16.f32 v16, v13
    v.st.w       [s36, #0], v16
    v.extract    s28, v18, #12
    s.addi       s36, s31, #768
    s.add        s37, s28, s29
    s.addi       s28, s37, #224
    s.add        s37, s2, s28
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s33, #0]
    vf.cvt.bf16.f32 v16, v13
    v.st.w       [s32, #0], v16
    v.extract    s28, v18, #13
    s.addi       s32, s31, #832
    s.add        s33, s28, s29
    s.addi       s28, s33, #224
    s.add        s33, s2, s28
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s35, #0]
    vf.cvt.bf16.f32 v16, v13
    v.st.w       [s34, #0], v16
    v.extract    s28, v18, #14
    s.addi       s34, s31, #896
    s.add        s35, s28, s29
    s.addi       s28, s35, #224
    s.add        s35, s2, s28
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s37, #0]
    vf.cvt.bf16.f32 v16, v13
    v.st.w       [s36, #0], v16
    v.extract    s28, v18, #15
    s.addi       s36, s31, #960
    s.add        s31, s28, s29
    s.addi       s28, s31, #224
    s.add        s29, s2, s28
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s33, #0]
    vf.cvt.bf16.f32 v16, v13
    v.st.w       [s32, #0], v16
    s.addi       s28, s30, #0
    s.addi       s31, s30, #1024
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s35, #0]
    vf.cvt.bf16.f32 v16, v13
    v.st.w       [s34, #0], v16
    s.addi       s32, s30, #2048
    s.addi       s33, s30, #3072
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s29, #0]
    vf.cvt.bf16.f32 v16, v13
    v.st.w       [s36, #0], v16
    fence.acq_rel.device
    s.addi       s29, s30, #4096
    v.ld.w       v13, [s28, #0]
    v.ld.w       v16, [s31, #0]
    vf.abs       v18, v13
    s.addi       s28, s30, #5120
    v.ld.w       v13, [s32, #0]
    vf.abs       v19, v16
    vf.max.ieee  v16, v18, v19
    s.addi       s31, s30, #6144
    v.ld.w       v18, [s33, #0]
    vf.abs       v19, v13
    vf.max.ieee  v13, v16, v19
    s.addi       s32, s30, #7168
    v.ld.w       v16, [s29, #0]
    vf.abs       v19, v18
    vf.max.ieee  v18, v13, v19
    s.addi       s29, s30, #64
    v.ld.w       v13, [s28, #0]
    vf.abs       v19, v16
    vf.max.ieee  v16, v18, v19
    s.addi       s28, s30, #1088
    v.ld.w       v18, [s29, #0]
    vf.abs       v19, v13
    vf.max.ieee  v13, v16, v19
    s.addi       s29, s30, #2112
    v.ld.w       v16, [s28, #0]
    vf.abs       v19, v18
    vf.abs       v18, v16
    v.ld.w       v16, [s31, #0]
    vf.max.ieee  v21, v19, v18
    v.ld.w       v18, [s29, #0]
    vf.abs       v19, v16
    vf.max.ieee  v16, v13, v19
    s.addi       s28, s30, #3136
    vf.abs       v13, v18
    v.ld.w       v18, [s32, #0]
    vf.max.ieee  v19, v21, v13
    v.ld.w       v13, [s28, #0]
    vf.abs       v21, v18
    vf.max.ieee  v18, v16, v21
    vf.reduce.max.b v16, v18
    s.addi       s28, s30, #4160
    s.addi       s29, s30, #5184
    s.addi       s31, s30, #6208
    s.addi       s32, s30, #7232
    v.ld.w       v18, [s28, #0]
    vf.abs       v21, v13
    vf.max.ieee  v13, v19, v21
    s.addi       s28, s30, #128
    v.ld.w       v19, [s29, #0]
    vf.abs       v21, v18
    vf.max.ieee  v18, v13, v21
    s.addi       s29, s30, #1152
    v.ld.w       v13, [s28, #0]
    vf.abs       v21, v19
    vf.max.ieee  v19, v18, v21
    s.addi       s28, s30, #2176
    v.ld.w       v18, [s29, #0]
    vf.abs       v21, v13
    vf.abs       v13, v18
    v.ld.w       v18, [s31, #0]
    vf.max.ieee  v22, v21, v13
    v.ld.w       v13, [s28, #0]
    vf.abs       v21, v18
    vf.max.ieee  v18, v19, v21
    s.addi       s28, s30, #3200
    vf.abs       v19, v13
    v.ld.w       v13, [s32, #0]
    vf.max.ieee  v21, v22, v19
    v.ld.w       v19, [s28, #0]
    vf.abs       v22, v13
    vf.max.ieee  v13, v18, v22
    vf.reduce.max.b v18, v13
    s.addi       s28, s30, #4224
    s.addi       s29, s30, #5248
    s.addi       s31, s30, #6272
    s.addi       s32, s30, #7296
    v.ld.w       v13, [s28, #0]
    vf.abs       v22, v19
    vf.max.ieee  v19, v21, v22
    s.addi       s28, s30, #192
    v.ld.w       v21, [s29, #0]
    vf.abs       v22, v13
    vf.max.ieee  v13, v19, v22
    s.addi       s29, s30, #1216
    v.ld.w       v19, [s28, #0]
    vf.abs       v22, v21
    vf.max.ieee  v21, v13, v22
    s.addi       s28, s30, #2240
    v.ld.w       v13, [s29, #0]
    vf.abs       v22, v19
    vf.abs       v19, v13
    v.ld.w       v13, [s31, #0]
    vf.max.ieee  v23, v22, v19
    v.ld.w       v19, [s28, #0]
    vf.abs       v22, v13
    vf.max.ieee  v13, v21, v22
    s.addi       s28, s30, #3264
    vf.abs       v21, v19
    v.ld.w       v19, [s32, #0]
    vf.max.ieee  v22, v23, v21
    v.ld.w       v21, [s28, #0]
    vf.abs       v23, v19
    vf.max.ieee  v19, v13, v23
    vf.reduce.max.b v13, v19
    s.addi       s28, s30, #4288
    s.addi       s29, s30, #5312
    s.addi       s31, s30, #6336
    s.addi       s32, s30, #7360
    v.ld.w       v19, [s28, #0]
    vf.abs       v23, v21
    vf.max.ieee  v21, v22, v23
    s.addi       s28, s30, #256
    v.ld.w       v22, [s29, #0]
    vf.abs       v23, v19
    vf.max.ieee  v19, v21, v23
    s.addi       s29, s30, #1280
    v.ld.w       v21, [s28, #0]
    vf.abs       v23, v22
    vf.max.ieee  v22, v19, v23
    s.addi       s28, s30, #2304
    v.ld.w       v19, [s29, #0]
    vf.abs       v23, v21
    vf.abs       v21, v19
    v.ld.w       v19, [s31, #0]
    vf.max.ieee  v24, v23, v21
    v.ld.w       v21, [s28, #0]
    vf.abs       v23, v19
    vf.max.ieee  v19, v22, v23
    s.addi       s28, s30, #3328
    vf.abs       v22, v21
    v.ld.w       v21, [s32, #0]
    vf.max.ieee  v23, v24, v22
    v.ld.w       v22, [s28, #0]
    vf.abs       v24, v21
    vf.max.ieee  v21, v19, v24
    vf.reduce.max.b v19, v21
    s.addi       s28, s30, #4352
    s.addi       s29, s30, #5376
    s.addi       s31, s30, #6400
    s.addi       s32, s30, #7424
    v.ld.w       v21, [s28, #0]
    vf.abs       v24, v22
    vf.max.ieee  v22, v23, v24
    s.addi       s28, s30, #320
    v.ld.w       v23, [s29, #0]
    vf.abs       v24, v21
    vf.max.ieee  v21, v22, v24
    s.addi       s29, s30, #1344
    v.ld.w       v22, [s28, #0]
    vf.abs       v24, v23
    vf.max.ieee  v23, v21, v24
    s.addi       s28, s30, #2368
    v.ld.w       v21, [s29, #0]
    vf.abs       v24, v22
    vf.abs       v22, v21
    v.ld.w       v21, [s31, #0]
    vf.max.ieee  v25, v24, v22
    v.ld.w       v22, [s28, #0]
    vf.abs       v24, v21
    vf.max.ieee  v21, v23, v24
    s.addi       s28, s30, #3392
    vf.abs       v23, v22
    v.ld.w       v22, [s32, #0]
    vf.max.ieee  v24, v25, v23
    v.ld.w       v23, [s28, #0]
    vf.abs       v25, v22
    vf.max.ieee  v22, v21, v25
    vf.reduce.max.b v21, v22
    s.addi       s28, s30, #4416
    s.addi       s29, s30, #5440
    s.addi       s31, s30, #6464
    s.addi       s32, s30, #7488
    v.ld.w       v22, [s28, #0]
    vf.abs       v25, v23
    vf.max.ieee  v23, v24, v25
    s.addi       s28, s30, #384
    v.ld.w       v24, [s29, #0]
    vf.abs       v25, v22
    vf.max.ieee  v22, v23, v25
    s.addi       s29, s30, #1408
    v.ld.w       v23, [s28, #0]
    vf.abs       v25, v24
    vf.max.ieee  v24, v22, v25
    s.addi       s28, s30, #2432
    v.ld.w       v22, [s29, #0]
    vf.abs       v25, v23
    vf.abs       v23, v22
    v.ld.w       v22, [s31, #0]
    vf.max.ieee  v26, v25, v23
    v.ld.w       v23, [s28, #0]
    vf.abs       v25, v22
    vf.max.ieee  v22, v24, v25
    s.addi       s28, s30, #3456
    vf.abs       v24, v23
    v.ld.w       v23, [s32, #0]
    vf.max.ieee  v25, v26, v24
    v.ld.w       v24, [s28, #0]
    vf.abs       v26, v23
    vf.max.ieee  v23, v22, v26
    vf.reduce.max.b v22, v23
    s.addi       s28, s30, #4480
    s.addi       s29, s30, #5504
    s.addi       s31, s30, #6528
    s.addi       s32, s30, #7552
    v.ld.w       v23, [s28, #0]
    vf.abs       v26, v24
    vf.max.ieee  v24, v25, v26
    s.addi       s28, s30, #448
    v.ld.w       v25, [s29, #0]
    vf.abs       v26, v23
    vf.max.ieee  v23, v24, v26
    s.addi       s29, s30, #1472
    v.ld.w       v24, [s28, #0]
    vf.abs       v26, v25
    vf.max.ieee  v25, v23, v26
    s.addi       s28, s30, #2496
    v.ld.w       v23, [s29, #0]
    vf.abs       v26, v24
    vf.abs       v24, v23
    v.ld.w       v23, [s31, #0]
    vf.max.ieee  v27, v26, v24
    v.ld.w       v24, [s28, #0]
    vf.abs       v26, v23
    vf.max.ieee  v23, v25, v26
    s.addi       s28, s30, #3520
    vf.abs       v25, v24
    v.ld.w       v24, [s32, #0]
    vf.max.ieee  v26, v27, v25
    v.ld.w       v25, [s28, #0]
    vf.abs       v27, v24
    vf.max.ieee  v24, v23, v27
    vf.reduce.max.b v23, v24
    s.addi       s28, s30, #4544
    s.addi       s29, s30, #5568
    s.addi       s31, s30, #6592
    s.addi       s32, s30, #7616
    v.ld.w       v24, [s28, #0]
    vf.abs       v27, v25
    vf.max.ieee  v25, v26, v27
    s.addi       s28, s30, #512
    v.ld.w       v26, [s29, #0]
    vf.abs       v27, v24
    vf.max.ieee  v24, v25, v27
    s.addi       s29, s30, #1536
    v.ld.w       v25, [s28, #0]
    vf.abs       v27, v26
    vf.max.ieee  v26, v24, v27
    s.addi       s28, s30, #2560
    v.ld.w       v24, [s29, #0]
    vf.abs       v27, v25
    vf.abs       v25, v24
    v.ld.w       v24, [s31, #0]
    vf.max.ieee  v28, v27, v25
    v.ld.w       v25, [s28, #0]
    vf.abs       v27, v24
    vf.max.ieee  v24, v26, v27
    s.addi       s28, s30, #3584
    vf.abs       v26, v25
    v.ld.w       v25, [s32, #0]
    vf.max.ieee  v27, v28, v26
    v.ld.w       v26, [s28, #0]
    vf.abs       v28, v25
    vf.max.ieee  v25, v24, v28
    vf.reduce.max.b v24, v25
    s.addi       s28, s30, #4608
    s.addi       s29, s30, #5632
    s.addi       s31, s30, #6656
    s.addi       s32, s30, #7680
    v.ld.w       v25, [s28, #0]
    vf.abs       v28, v26
    vf.max.ieee  v26, v27, v28
    s.addi       s28, s30, #576
    v.ld.w       v27, [s29, #0]
    vf.abs       v28, v25
    vf.max.ieee  v25, v26, v28
    s.addi       s29, s30, #1600
    v.ld.w       v26, [s28, #0]
    vf.abs       v28, v27
    vf.max.ieee  v27, v25, v28
    s.addi       s28, s30, #2624
    v.ld.w       v25, [s29, #0]
    vf.abs       v28, v26
    vf.abs       v26, v25
    v.ld.w       v25, [s31, #0]
    vf.max.ieee  v29, v28, v26
    v.ld.w       v26, [s28, #0]
    vf.abs       v28, v25
    vf.max.ieee  v25, v27, v28
    s.addi       s28, s30, #3648
    vf.abs       v27, v26
    v.ld.w       v26, [s32, #0]
    vf.max.ieee  v28, v29, v27
    v.ld.w       v27, [s28, #0]
    vf.abs       v29, v26
    vf.max.ieee  v26, v25, v29
    vf.reduce.max.b v25, v26
    s.addi       s28, s30, #4672
    s.addi       s29, s30, #5696
    s.addi       s31, s30, #6720
    s.addi       s32, s30, #7744
    v.ld.w       v26, [s28, #0]
    vf.abs       v29, v27
    vf.max.ieee  v27, v28, v29
    s.addi       s28, s30, #640
    v.ld.w       v28, [s29, #0]
    vf.abs       v29, v26
    vf.max.ieee  v26, v27, v29
    s.addi       s29, s30, #1664
    v.ld.w       v27, [s28, #0]
    vf.abs       v29, v28
    vf.max.ieee  v28, v26, v29
    s.addi       s28, s30, #2688
    v.ld.w       v26, [s29, #0]
    vf.abs       v29, v27
    vf.abs       v27, v26
    v.ld.w       v26, [s31, #0]
    vf.max.ieee  v30, v29, v27
    v.ld.w       v27, [s28, #0]
    vf.abs       v29, v26
    vf.max.ieee  v26, v28, v29
    s.addi       s28, s30, #3712
    vf.abs       v28, v27
    v.ld.w       v27, [s32, #0]
    vf.max.ieee  v29, v30, v28
    v.ld.w       v28, [s28, #0]
    vf.abs       v30, v27
    vf.max.ieee  v27, v26, v30
    vf.reduce.max.b v26, v27
    s.addi       s28, s30, #4736
    s.addi       s29, s30, #5760
    s.addi       s31, s30, #6784
    s.addi       s32, s30, #7808
    v.ld.w       v27, [s28, #0]
    vf.abs       v30, v28
    vf.max.ieee  v28, v29, v30
    s.addi       s28, s30, #704
    v.ld.w       v29, [s29, #0]
    vf.abs       v30, v27
    vf.max.ieee  v27, v28, v30
    s.addi       s29, s30, #1728
    v.ld.w       v28, [s28, #0]
    vf.abs       v30, v29
    vf.max.ieee  v29, v27, v30
    s.addi       s28, s30, #2752
    v.ld.w       v27, [s29, #0]
    vf.abs       v30, v28
    vf.abs       v28, v27
    v.ld.w       v27, [s31, #0]
    vf.max.ieee  v31, v30, v28
    v.ld.w       v28, [s28, #0]
    vf.abs       v30, v27
    vf.max.ieee  v27, v29, v30
    s.addi       s28, s30, #3776
    vf.abs       v29, v28
    v.ld.w       v28, [s32, #0]
    vf.max.ieee  v30, v31, v29
    v.ld.w       v29, [s28, #0]
    vf.abs       v31, v28
    vf.max.ieee  v28, v27, v31
    vf.reduce.max.b v27, v28
    s.addi       s28, s30, #4800
    s.addi       s29, s30, #5824
    s.addi       s31, s30, #6848
    s.addi       s32, s30, #7872
    v.ld.w       v28, [s28, #0]
    vf.abs       v31, v29
    vf.max.ieee  v29, v30, v31
    s.addi       s28, s30, #768
    v.ld.w       v30, [s29, #0]
    vf.abs       v31, v28
    vf.max.ieee  v28, v29, v31
    s.addi       s29, s30, #1792
    v.ld.w       v29, [s28, #0]
    vf.abs       v31, v30
    vf.max.ieee  v30, v28, v31
    s.addi       s28, s30, #2816
    v.ld.w       v28, [s29, #0]
    vf.abs       v31, v29
    vf.abs       v29, v28
    v.ld.w       v28, [s31, #0]
    vf.max.ieee  v32, v31, v29
    v.ld.w       v29, [s28, #0]
    vf.abs       v31, v28
    vf.max.ieee  v28, v30, v31
    s.addi       s28, s30, #3840
    vf.abs       v30, v29
    v.ld.w       v29, [s32, #0]
    vf.max.ieee  v31, v32, v30
    v.ld.w       v30, [s28, #0]
    vf.abs       v32, v29
    vf.max.ieee  v29, v28, v32
    vf.reduce.max.b v28, v29
    s.addi       s28, s30, #4864
    s.addi       s29, s30, #5888
    s.addi       s31, s30, #6912
    s.addi       s32, s30, #7936
    v.ld.w       v29, [s28, #0]
    vf.abs       v32, v30
    vf.max.ieee  v30, v31, v32
    s.addi       s28, s30, #832
    v.ld.w       v31, [s29, #0]
    vf.abs       v32, v29
    vf.max.ieee  v29, v30, v32
    s.addi       s29, s30, #1856
    v.ld.w       v30, [s28, #0]
    vf.abs       v32, v31
    vf.max.ieee  v31, v29, v32
    s.addi       s28, s30, #2880
    v.ld.w       v29, [s29, #0]
    vf.abs       v32, v30
    vf.abs       v30, v29
    v.ld.w       v29, [s31, #0]
    vf.max.ieee  v33, v32, v30
    v.ld.w       v30, [s28, #0]
    vf.abs       v32, v29
    vf.max.ieee  v29, v31, v32
    s.addi       s28, s30, #3904
    vf.abs       v31, v30
    v.ld.w       v30, [s32, #0]
    vf.max.ieee  v32, v33, v31
    v.ld.w       v31, [s28, #0]
    vf.abs       v33, v30
    vf.max.ieee  v30, v29, v33
    vf.reduce.max.b v29, v30
    s.addi       s28, s30, #4928
    s.addi       s29, s30, #5952
    s.addi       s31, s30, #6976
    s.addi       s32, s30, #8000
    v.ld.w       v30, [s28, #0]
    vf.abs       v33, v31
    vf.max.ieee  v31, v32, v33
    s.addi       s28, s30, #896
    v.ld.w       v32, [s29, #0]
    vf.abs       v33, v30
    vf.max.ieee  v30, v31, v33
    s.addi       s29, s30, #1920
    v.ld.w       v31, [s28, #0]
    vf.abs       v33, v32
    vf.max.ieee  v32, v30, v33
    s.addi       s28, s30, #2944
    v.ld.w       v30, [s29, #0]
    vf.abs       v33, v31
    vf.abs       v31, v30
    v.ld.w       v30, [s31, #0]
    vf.max.ieee  v34, v33, v31
    v.ld.w       v31, [s28, #0]
    vf.abs       v33, v30
    vf.max.ieee  v30, v32, v33
    s.addi       s28, s30, #3968
    v.ld.w       v32, [s32, #0]
    vf.abs       v33, v31
    vf.max.ieee  v31, v34, v33
    v.ld.w       v33, [s28, #0]
    vf.abs       v34, v32
    vf.max.ieee  v32, v30, v34
    vf.reduce.max.b v30, v32
    s.addi       s28, s30, #4992
    s.addi       s29, s30, #6016
    s.addi       s31, s30, #7040
    s.addi       s32, s30, #8064
    v.ld.w       v32, [s28, #0]
    vf.abs       v34, v33
    vf.max.ieee  v33, v31, v34
    s.addi       s28, s30, #960
    v.ld.w       v31, [s29, #0]
    vf.abs       v34, v32
    vf.max.ieee  v32, v33, v34
    s.addi       s29, s30, #1984
    v.ld.w       v33, [s28, #0]
    vf.abs       v34, v31
    vf.max.ieee  v31, v32, v34
    s.addi       s28, s30, #3008
    v.ld.w       v32, [s29, #0]
    vf.abs       v34, v33
    vf.abs       v33, v32
    vf.max.ieee  v32, v34, v33
    v.ld.w       v33, [s31, #0]
    vf.abs       v34, v33
    vf.max.ieee  v33, v31, v34
    v.ld.w       v31, [s28, #0]
    s.addi       s28, s30, #4032
    vf.abs       v34, v31
    vf.max.ieee  v31, v32, v34
    v.ld.w       v32, [s32, #0]
    vf.abs       v34, v32
    vf.max.ieee  v32, v33, v34
    v.ld.w       v33, [s28, #0]
    vf.reduce.max.b v34, v32
    s.addi       s28, s30, #5056
    s.addi       s29, s30, #6080
    s.addi       s31, s30, #7104
    s.addi       s32, s30, #8128
    vf.abs       v32, v33
    vf.max.ieee  v33, v31, v32
    v.ld.w       v31, [s28, #0]
    vf.abs       v32, v31
    // one value per row into one vector (ISA 0x09)
    v.extract    s28, v16, #0
    v.movi       v16, #0
    vf.max.ieee  v31, v33, v32
    v.ld.w       v32, [s29, #0]
    v.extract    s29, v18, #0
    v.ld.w       v18, [s31, #0]
    vf.abs       v33, v32
    v.extract    s31, v13, #0
    vf.max.ieee  v13, v31, v33
    v.extract    s33, v19, #0
    v.ld.w       v19, [s32, #0]
    v.insert     v16, s28, #0
    vf.abs       v31, v18
    v.extract    s28, v21, #0
    v.insert     v16, s29, #1
    v.insert     v16, s31, #2
    vf.max.ieee  v18, v13, v31
    v.extract    s29, v22, #0
    v.insert     v16, s33, #3
    v.insert     v16, s28, #4
    v.insert     v16, s29, #5
    vf.abs       v13, v19
    v.extract    s28, v23, #0
    vf.max.ieee  v19, v18, v13
    v.insert     v16, s28, #6
    vf.reduce.max.b v13, v19
    v.extract    s28, v24, #0
    v.extract    s29, v25, #0
    v.insert     v16, s28, #7
    .li       s28, #1138753536
    v.splat      v18, s28                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.extract    s28, v26, #0
    v.insert     v16, s29, #8
    v.rcp.approx v19, v18                        // ISA 8.8: <= 2**-22 relative
    .li       s29, #1065353216
    v.splat      v21, s29                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.insert     v16, s28, #9
    v.extract    s28, v27, #0
    v.extract    s29, v28, #0
    v.insert     v16, s28, #10
    v.extract    s28, v29, #0
    v.extract    s31, v30, #0
    v.insert     v16, s29, #11
    v.extract    s29, v34, #0
    v.extract    s32, v13, #0
    v.insert     v16, s28, #12
    v.insert     v16, s31, #13
    v.insert     v16, s29, #14
    .li       s28, #730643660
    v.splat      v13, s28                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.insert     v16, s32, #15
    v.splat      v22, s13
    v.splat      v23, s13
    v.mul        v24, v20, v22
    v.mul        v22, v17, v23
    vf.fms       v23, v18, v19, v21
    v.splat      v25, s13
    vf.fms       v26, v19, v23, v19
    v.mul        v23, v8, v25
    vf.neg       v25, v26                        // Newton step: r0*(2 - x*r0)
    v.splat      v26, s13
    vf.cmp.o     p1, v25, v25
    @p1 v.sel        v27, v25, v19
    v.mul        v19, v11, v26
    v.splat      v25, s13
    vf.mul       v26, v16, v27                   // a/y: faithful quotient
    v.mul        v28, v7, v25
    vf.fms       v25, v26, v18, v16
    v.splat      v16, s13
    vf.fms       v18, v25, v27, v26
    v.mul        v25, v5, v16
    vf.neg       v16, v18                        // a/y: one correction to the IEEE quotient
    v.splat      v18, s13
    vf.cmp.o     p1, v16, v16
    @p1 v.sel        v27, v16, v26
    v.ld.gather.w v16, [s16, v14]                // index is in elements (ISA sec 9.1)
    s.movz       s28, #16
    // tl.dot 16x128 by 128x128 FP8 as (B^T A^T)^T: B^T rows are contiguous loads, A is scattered into the MMA B operand
    v.iota       v26                             // arange(0, VLEN)
    v.splat      v29, s28
    s.add        s28, s23, s11
    v.mul        v30, v9, v18
    v.mul        v18, v26, v29
    v.iota       v26                             // arange(0, VLEN)
    v.splat      v29, s13
    v.movi       v31, #7
    v.mul        v32, v3, v29
    v.and        v29, v26, v31
    v.movi       v26, #2
    v.ld.gather.w v31, [s16, v1]                 // index is in elements (ISA sec 9.1)
    v.shl        v33, v29, v26
    v.ld.gather.w v26, [s16, v10]                // index is in elements (ISA sec 9.1)
    v.iota       v29                             // arange(0, VLEN)
    v.ld.gather.w v34, [s16, v12]                // index is in elements (ISA sec 9.1)
    v.movi       v35, #3
    v.ld.gather.w v36, [s16, v15]                // index is in elements (ISA sec 9.1)
    v.lshr       v37, v29, v35
    v.ld.gather.w v29, [s16, v4]                 // index is in elements (ISA sec 9.1)
    v.movi       v35, #0
    v.ld.gather.w v38, [s16, v0]                 // index is in elements (ISA sec 9.1)
    v.cmp.eq     p1, v37, v35
    v.ld.gather.w v35, [s16, v2]                 // index is in elements (ISA sec 9.1)
    s.addi       s11, s30, #0
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    s.addi       s29, s30, #8192                 // 512 bytes of repack scratch
    v.iota       v37                             // arange(0, VLEN)
    v.extract    s31, v27, #0
    v.movi       v39, #3
    v.splat      v40, s31
    v.movi       v41, #1
    v.lshr       v42, v37, v39
    vf.max.ieee  v37, v40, v13
    v.ld.w       v39, [s11, #0]
    v.cmp.eq     p2, v42, v41
    v.movi       v40, #24
    v.movi       v41, #128
    v.rcp.approx v42, v37                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v37, v42, v21
    vf.fms       v44, v42, v43, v42
    s.addi       s11, s29, #0
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v43, v43
    @p3 v.sel        v44, v43, v42
    s.addi       s31, s30, #64
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    v.extract    s32, v27, #1
    vf.fms       v43, v42, v37, v39
    v.splat      v37, s32
    vf.fms       v39, v43, v44, v42
    vf.max.ieee  v43, v37, v13
    vf.neg       v37, v39                        // a/y: one correction to the IEEE quotient
    v.rcp.approx v39, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v44, v37, v42
    v.lshr       v37, v44, v40
    vf.cvt.f32.e4m3 v42, v44
    v.and        v44, v37, v41
    v.or         v37, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v43, v39, v21
    v.ld.w       v42, [s31, #0]
    s.addi       s11, s29, #1
    vf.fms       v44, v39, v37, v39
    s.addi       s31, s30, #128
    vf.neg       v37, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #2
    @p3 v.sel        v44, v37, v39
    v.splat      v37, s32
    vf.mul       v39, v42, v44                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v39, v43, v42
    v.rcp.approx v42, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v37, v44, v39
    vf.neg       v37, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v45, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s31, #0]
    s.addi       s11, s29, #2
    s.addi       s31, s30, #192
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #3
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s32
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v42, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v42
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v44, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s31, #0]
    s.addi       s11, s29, #3
    s.addi       s31, s30, #256
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #4
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s32
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v39, v44, v42
    v.rcp.approx v42, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v39
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v45, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s31, #0]
    s.addi       s11, s29, #4
    s.addi       s31, s30, #320
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #5
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s32
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v42, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v42
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v44, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s31, #0]
    s.addi       s11, s29, #5
    s.addi       s31, s30, #384
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #6
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s32
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v39, v44, v42
    v.rcp.approx v42, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v39
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v45, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s31, #0]
    s.addi       s11, s29, #6
    s.addi       s31, s30, #448
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #7
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s32
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v42, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v42
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v44, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s31, #0]
    s.addi       s11, s29, #7
    s.addi       s31, s30, #512
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #8
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s32
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v39, v44, v42
    v.rcp.approx v42, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v39
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v45, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s31, #0]
    s.addi       s11, s29, #8
    s.addi       s31, s30, #576
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #9
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s32
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v42, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v42
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v44, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s31, #0]
    s.addi       s11, s29, #9
    s.addi       s31, s30, #640
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #10
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s32
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v39, v44, v42
    v.rcp.approx v42, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v39
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v45, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s31, #0]
    s.addi       s11, s29, #10
    s.addi       s31, s30, #704
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #11
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s32
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v42, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v42
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v44, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s31, #0]
    s.addi       s11, s29, #11
    s.addi       s31, s30, #768
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #12
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s32
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v39, v44, v42
    v.rcp.approx v42, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v39
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v45, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s31, #0]
    s.addi       s11, s29, #12
    s.addi       s31, s30, #832
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #13
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s32
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v42, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v42
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v44, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s31, #0]
    s.addi       s11, s29, #13
    s.addi       s31, s30, #896
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #14
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s32
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v39, v44, v42
    v.rcp.approx v42, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v39
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v45, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s31, #0]
    s.addi       s11, s29, #14
    s.addi       s31, s30, #960
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #15
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s32
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v42, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v42
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v44, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s31, #0]
    s.addi       s11, s29, #15
    s.addi       s31, s30, #1024
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #0
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s32
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v39, v44, v42
    v.rcp.approx v42, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v39
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v45, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s31, #0]
    s.addi       s11, s29, #256
    s.addi       s31, s30, #1088
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #1
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s32
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v42, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v42
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v44, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s31, #0]
    s.addi       s11, s29, #257
    s.addi       s31, s30, #1152
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #2
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s32
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v39, v44, v42
    v.rcp.approx v42, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v39
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v45, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s31, #0]
    s.addi       s11, s29, #258
    s.addi       s31, s30, #1216
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #3
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s32
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v42, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v42
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v44, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s31, #0]
    s.addi       s11, s29, #259
    s.addi       s31, s30, #1280
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #4
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s32
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v39, v44, v42
    v.rcp.approx v42, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v39
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v45, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s31, #0]
    s.addi       s11, s29, #260
    s.addi       s31, s30, #1344
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #5
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s32
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v42, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v42
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v44, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s31, #0]
    s.addi       s11, s29, #261
    s.addi       s31, s30, #1408
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #6
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s32
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v39, v44, v42
    v.rcp.approx v42, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v39
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v45, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s31, #0]
    s.addi       s11, s29, #262
    s.addi       s31, s30, #1472
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #7
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s32
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v42, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v42
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v44, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s31, #0]
    s.addi       s11, s29, #263
    s.addi       s31, s30, #1536
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #8
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s32
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v39, v44, v42
    v.rcp.approx v42, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v39
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v45, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s31, #0]
    s.addi       s11, s29, #264
    s.addi       s31, s30, #1600
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #9
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s32
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v42, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v42
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v44, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s31, #0]
    s.addi       s11, s29, #265
    s.addi       s31, s30, #1664
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #10
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s32
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v39, v44, v42
    v.rcp.approx v42, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v39
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v45, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s31, #0]
    s.addi       s11, s29, #266
    s.addi       s31, s30, #1728
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #11
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s32
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v42, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v42
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v44, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s31, #0]
    s.addi       s11, s29, #267
    s.addi       s31, s30, #1792
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #12
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s32
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v39, v44, v42
    v.rcp.approx v42, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v39
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v45, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s31, #0]
    s.addi       s11, s29, #268
    s.addi       s31, s30, #1856
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #13
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s32
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v42, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v42
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v44, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s31, #0]
    s.addi       s11, s29, #269
    s.addi       s31, s30, #1920
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #14
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s32
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v39, v44, v42
    v.rcp.approx v42, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v39
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v45, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s31, #0]
    s.addi       s11, s29, #270
    s.addi       s31, s30, #1984
    vf.cmp.o     p3, v37, v37
    v.extract    s32, v27, #15
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s32
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v42, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v42
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s11, v18], v37
    vf.fms       v37, v44, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s31, #0]
    s.addi       s11, s29, #271
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    vf.mul       v37, v42, v43                   // a/y: faithful quotient
    s.addi       s31, s29, #64
    vf.fms       v39, v37, v44, v42
    vf.fms       v42, v39, v43, v37
    vf.neg       v39, v42                        // a/y: one correction to the IEEE quotient
    s.addi       s32, s29, #128
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v42, v39, v37
    v.lshr       v37, v42, v40
    vf.cvt.f32.e4m3 v39, v42
    s.addi       s33, s29, #192
    v.and        v42, v37, v41
    v.or         v37, v39, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s34, s29, #256
    v.st.scatter.b [s11, v18], v37
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s11, s29, #320
    v.ld.w       v37, [s29, #0]
    v.mov        v48, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s31, #0]
    s.addi       s31, s29, #384
    v.mov        v49, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s32, #0]
    s.addi       s32, s29, #448
    v.mov        v50, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s33, #0]
    s.addi       s29, s28, #0
    v.splat      v39, s29
    v.sub        v42, v39, v33
    v.mov        v51, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s34, #0]
    v.movi       v39, #0
    v.movi       v43, #0
    v.cmp.gt     p3, v42, v39
    v.mov        v52, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s11, #0]
    v.max.s      v39, v42, v43
    v.movi       v42, #4
    v.min.s      v43, v39, v42
    v.mov        v53, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s31, #0]
    v.movi       v39, #3
    v.movi       v42, #1
    v.shl        v44, v43, v39
    v.mov        v54, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s32, #0]
    v.shl        v39, v42, v44
    v.movi       v42, #1
    v.sub        v44, v39, v42
    v.mov        v55, v37                        // hand off through the shared window (sec 7.3)
    s.add        s11, s10, s24
    v.extract    s29, v24, #1
    v.extract    s31, v24, #0
    s.add        s32, s11, s29
    s.add        s29, s11, s31
    p.and        p4, p1, p3
    s.addi       s31, s32, #-32
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s29, #0]
    p.and        p4, p2, p3
    v.movi       v39, #4
    v.movi       v42, #-1
    v.movi       v45, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v45, [s31, #0]
    v.cmp.ge     p4, v43, v39
    @p4 v.sel        v39, v42, v44
    v.extract    s29, v24, #3
    v.extract    s31, v24, #2
    s.add        s32, s11, s29
    s.add        s29, s11, s31
    p.and        p4, p1, p3
    s.addi       s31, s32, #-32
    v.extract    s32, v24, #4
    v.or         v42, v37, v45
    s.add        s33, s11, s32
    v.and        v37, v42, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s29, #0]
    p.and        p4, p2, p3
    v.extract    s29, v24, #5
    s.add        s32, s11, s29
    s.addi       s29, s32, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s31, #0]
    p.and        p4, p1, p3
    v.extract    s31, v24, #6
    v.or         v43, v37, v42
    s.add        s32, s11, s31
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s33, #0]
    p.and        p4, p2, p3
    v.extract    s31, v24, #7
    s.add        s33, s11, s31
    s.addi       s31, s33, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s29, #0]
    p.and        p4, p1, p3
    v.extract    s29, v24, #8
    v.or         v43, v37, v42
    s.add        s33, s11, s29
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s32, #0]
    p.and        p4, p2, p3
    v.extract    s29, v24, #9
    s.add        s32, s11, s29
    s.addi       s29, s32, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s31, #0]
    p.and        p4, p1, p3
    v.extract    s31, v24, #10
    v.or         v43, v37, v42
    s.add        s32, s11, s31
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s33, #0]
    p.and        p4, p2, p3
    v.extract    s31, v24, #11
    s.add        s33, s11, s31
    s.addi       s31, s33, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s29, #0]
    p.and        p4, p1, p3
    v.extract    s29, v24, #12
    v.or         v43, v37, v42
    s.add        s33, s11, s29
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s32, #0]
    p.and        p4, p2, p3
    v.extract    s29, v24, #13
    s.add        s32, s11, s29
    s.addi       s29, s32, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s31, #0]
    p.and        p4, p1, p3
    v.extract    s31, v24, #14
    v.or         v43, v37, v42
    s.add        s32, s11, s31
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s33, #0]
    p.and        p4, p2, p3
    v.extract    s31, v24, #15
    s.add        s33, s11, s31
    s.addi       s11, s33, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s29, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s32, #0]
    p.and        p4, p2, p3
    s.add        s29, s10, s24
    v.extract    s31, v22, #1
    v.extract    s32, v22, #0
    s.add        s33, s29, s31
    s.add        s31, s29, s32
    s.addi       s32, s33, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s11, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s11, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a8, v56, v48, s11
    mb.wait      s11
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s31, #0]
    p.and        p4, p2, p3
    v.extract    s31, v22, #3
    v.extract    s33, v22, #2
    s.add        s34, s29, s31
    s.add        s31, s29, s33
    s.addi       s33, s34, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s32, #0]
    p.and        p4, p1, p3
    v.extract    s32, v22, #4
    v.or         v43, v37, v42
    s.add        s34, s29, s32
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s31, #0]
    p.and        p4, p2, p3
    v.extract    s31, v22, #5
    s.add        s32, s29, s31
    s.addi       s31, s32, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s33, #0]
    p.and        p4, p1, p3
    v.extract    s32, v22, #6
    v.or         v43, v37, v42
    s.add        s33, s29, s32
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s34, #0]
    p.and        p4, p2, p3
    v.extract    s32, v22, #7
    s.add        s34, s29, s32
    s.addi       s32, s34, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s31, #0]
    p.and        p4, p1, p3
    v.extract    s31, v22, #8
    v.or         v43, v37, v42
    s.add        s34, s29, s31
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s33, #0]
    p.and        p4, p2, p3
    v.extract    s31, v22, #9
    s.add        s33, s29, s31
    s.addi       s31, s33, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s32, #0]
    p.and        p4, p1, p3
    v.extract    s32, v22, #10
    v.or         v43, v37, v42
    s.add        s33, s29, s32
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s34, #0]
    p.and        p4, p2, p3
    v.extract    s32, v22, #11
    s.add        s34, s29, s32
    s.addi       s32, s34, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s31, #0]
    p.and        p4, p1, p3
    v.extract    s31, v22, #12
    v.or         v43, v37, v42
    s.add        s34, s29, s31
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s33, #0]
    p.and        p4, p2, p3
    v.extract    s31, v22, #13
    s.add        s33, s29, s31
    s.addi       s31, s33, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s32, #0]
    p.and        p4, p1, p3
    v.extract    s32, v22, #14
    v.or         v43, v37, v42
    s.add        s33, s29, s32
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s34, #0]
    p.and        p4, p2, p3
    v.extract    s32, v22, #15
    s.add        s34, s29, s32
    s.addi       s29, s34, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s31, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s33, #0]
    p.and        p4, p2, p3
    s.add        s31, s10, s24
    v.extract    s32, v23, #1
    v.extract    s33, v23, #0
    s.add        s34, s31, s32
    s.add        s32, s31, s33
    s.addi       s33, s34, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s29, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s29, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a9, v56, v48, s29
    mb.wait      s29
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s32, #0]
    p.and        p4, p2, p3
    v.extract    s32, v23, #3
    v.extract    s34, v23, #2
    s.add        s35, s31, s32
    s.add        s32, s31, s34
    s.addi       s34, s35, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s33, #0]
    p.and        p4, p1, p3
    v.extract    s33, v23, #4
    v.or         v43, v37, v42
    s.add        s35, s31, s33
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s32, #0]
    p.and        p4, p2, p3
    v.extract    s32, v23, #5
    s.add        s33, s31, s32
    s.addi       s32, s33, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s34, #0]
    p.and        p4, p1, p3
    v.extract    s33, v23, #6
    v.or         v43, v37, v42
    s.add        s34, s31, s33
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s35, #0]
    p.and        p4, p2, p3
    v.extract    s33, v23, #7
    s.add        s35, s31, s33
    s.addi       s33, s35, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s32, #0]
    p.and        p4, p1, p3
    v.extract    s32, v23, #8
    v.or         v43, v37, v42
    s.add        s35, s31, s32
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s34, #0]
    p.and        p4, p2, p3
    v.extract    s32, v23, #9
    s.add        s34, s31, s32
    s.addi       s32, s34, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s33, #0]
    p.and        p4, p1, p3
    v.extract    s33, v23, #10
    v.or         v43, v37, v42
    s.add        s34, s31, s33
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s35, #0]
    p.and        p4, p2, p3
    v.extract    s33, v23, #11
    s.add        s35, s31, s33
    s.addi       s33, s35, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s32, #0]
    p.and        p4, p1, p3
    v.extract    s32, v23, #12
    v.or         v43, v37, v42
    s.add        s35, s31, s32
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s34, #0]
    p.and        p4, p2, p3
    v.extract    s32, v23, #13
    s.add        s34, s31, s32
    s.addi       s32, s34, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s33, #0]
    p.and        p4, p1, p3
    v.extract    s33, v23, #14
    v.or         v43, v37, v42
    s.add        s34, s31, s33
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s35, #0]
    p.and        p4, p2, p3
    v.extract    s33, v23, #15
    s.add        s35, s31, s33
    s.addi       s31, s35, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s32, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s34, #0]
    p.and        p4, p2, p3
    s.add        s32, s10, s24
    v.extract    s33, v19, #1
    v.extract    s34, v19, #0
    s.add        s35, s32, s33
    s.add        s33, s32, s34
    s.addi       s34, s35, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s31, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s31, b2, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a10, v56, v48, s31
    mb.wait      s31
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s33, #0]
    p.and        p4, p2, p3
    v.extract    s33, v19, #3
    v.extract    s35, v19, #2
    s.add        s36, s32, s33
    s.add        s33, s32, s35
    s.addi       s35, s36, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s34, #0]
    p.and        p4, p1, p3
    v.extract    s34, v19, #4
    v.or         v43, v37, v42
    s.add        s36, s32, s34
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s33, #0]
    p.and        p4, p2, p3
    v.extract    s33, v19, #5
    s.add        s34, s32, s33
    s.addi       s33, s34, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s35, #0]
    p.and        p4, p1, p3
    v.extract    s34, v19, #6
    v.or         v43, v37, v42
    s.add        s35, s32, s34
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s36, #0]
    p.and        p4, p2, p3
    v.extract    s34, v19, #7
    s.add        s36, s32, s34
    s.addi       s34, s36, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s33, #0]
    p.and        p4, p1, p3
    v.extract    s33, v19, #8
    v.or         v43, v37, v42
    s.add        s36, s32, s33
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s35, #0]
    p.and        p4, p2, p3
    v.extract    s33, v19, #9
    s.add        s35, s32, s33
    s.addi       s33, s35, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s34, #0]
    p.and        p4, p1, p3
    v.extract    s34, v19, #10
    v.or         v43, v37, v42
    s.add        s35, s32, s34
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s36, #0]
    p.and        p4, p2, p3
    v.extract    s34, v19, #11
    s.add        s36, s32, s34
    s.addi       s34, s36, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s33, #0]
    p.and        p4, p1, p3
    v.extract    s33, v19, #12
    v.or         v43, v37, v42
    s.add        s36, s32, s33
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s35, #0]
    p.and        p4, p2, p3
    v.extract    s33, v19, #13
    s.add        s35, s32, s33
    s.addi       s33, s35, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s34, #0]
    p.and        p4, p1, p3
    v.extract    s34, v19, #14
    v.or         v43, v37, v42
    s.add        s35, s32, s34
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s36, #0]
    p.and        p4, p2, p3
    v.extract    s34, v19, #15
    s.add        s36, s32, s34
    s.addi       s32, s36, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s33, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s35, #0]
    p.and        p4, p2, p3
    s.add        s33, s10, s24
    v.extract    s34, v28, #1
    v.extract    s35, v28, #0
    s.add        s36, s33, s34
    s.add        s34, s33, s35
    s.addi       s35, s36, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s32, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s32, b3, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a11, v56, v48, s32
    mb.wait      s32
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s34, #0]
    p.and        p4, p2, p3
    v.extract    s34, v28, #3
    v.extract    s36, v28, #2
    s.add        s37, s33, s34
    s.add        s34, s33, s36
    s.addi       s36, s37, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s35, #0]
    p.and        p4, p1, p3
    v.extract    s35, v28, #4
    v.or         v43, v37, v42
    s.add        s37, s33, s35
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s34, #0]
    p.and        p4, p2, p3
    v.extract    s34, v28, #5
    s.add        s35, s33, s34
    s.addi       s34, s35, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s36, #0]
    p.and        p4, p1, p3
    v.extract    s35, v28, #6
    v.or         v43, v37, v42
    s.add        s36, s33, s35
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s37, #0]
    p.and        p4, p2, p3
    v.extract    s35, v28, #7
    s.add        s37, s33, s35
    s.addi       s35, s37, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s34, #0]
    p.and        p4, p1, p3
    v.extract    s34, v28, #8
    v.or         v43, v37, v42
    s.add        s37, s33, s34
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s36, #0]
    p.and        p4, p2, p3
    v.extract    s34, v28, #9
    s.add        s36, s33, s34
    s.addi       s34, s36, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s35, #0]
    p.and        p4, p1, p3
    v.extract    s35, v28, #10
    v.or         v43, v37, v42
    s.add        s36, s33, s35
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s37, #0]
    p.and        p4, p2, p3
    v.extract    s35, v28, #11
    s.add        s37, s33, s35
    s.addi       s35, s37, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s34, #0]
    p.and        p4, p1, p3
    v.extract    s34, v28, #12
    v.or         v43, v37, v42
    s.add        s37, s33, s34
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s36, #0]
    p.and        p4, p2, p3
    v.extract    s34, v28, #13
    s.add        s36, s33, s34
    s.addi       s34, s36, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s35, #0]
    p.and        p4, p1, p3
    v.extract    s35, v28, #14
    v.or         v43, v37, v42
    s.add        s36, s33, s35
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s37, #0]
    p.and        p4, p2, p3
    v.extract    s35, v28, #15
    s.add        s37, s33, s35
    s.addi       s33, s37, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s34, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s36, #0]
    p.and        p4, p2, p3
    s.add        s34, s10, s24
    v.extract    s35, v25, #1
    v.extract    s36, v25, #0
    s.add        s37, s34, s35
    s.add        s35, s34, s36
    s.addi       s36, s37, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s33, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s33, b4, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a12, v56, v48, s33
    mb.wait      s33
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s35, #0]
    p.and        p4, p2, p3
    v.extract    s35, v25, #3
    v.extract    s37, v25, #2
    s.add        s38, s34, s35
    s.add        s35, s34, s37
    s.addi       s37, s38, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s36, #0]
    p.and        p4, p1, p3
    v.extract    s36, v25, #4
    v.or         v43, v37, v42
    s.add        s38, s34, s36
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s35, #0]
    p.and        p4, p2, p3
    v.extract    s35, v25, #5
    s.add        s36, s34, s35
    s.addi       s35, s36, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s36, v25, #6
    v.or         v43, v37, v42
    s.add        s37, s34, s36
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s38, #0]
    p.and        p4, p2, p3
    v.extract    s36, v25, #7
    s.add        s38, s34, s36
    s.addi       s36, s38, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s35, #0]
    p.and        p4, p1, p3
    v.extract    s35, v25, #8
    v.or         v43, v37, v42
    s.add        s38, s34, s35
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s37, #0]
    p.and        p4, p2, p3
    v.extract    s35, v25, #9
    s.add        s37, s34, s35
    s.addi       s35, s37, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s36, #0]
    p.and        p4, p1, p3
    v.extract    s36, v25, #10
    v.or         v43, v37, v42
    s.add        s37, s34, s36
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s38, #0]
    p.and        p4, p2, p3
    v.extract    s36, v25, #11
    s.add        s38, s34, s36
    s.addi       s36, s38, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s35, #0]
    p.and        p4, p1, p3
    v.extract    s35, v25, #12
    v.or         v43, v37, v42
    s.add        s38, s34, s35
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s37, #0]
    p.and        p4, p2, p3
    v.extract    s35, v25, #13
    s.add        s37, s34, s35
    s.addi       s35, s37, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s36, #0]
    p.and        p4, p1, p3
    v.extract    s36, v25, #14
    v.or         v43, v37, v42
    s.add        s37, s34, s36
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s38, #0]
    p.and        p4, p2, p3
    v.extract    s36, v25, #15
    s.add        s38, s34, s36
    s.addi       s34, s38, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s35, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s37, #0]
    p.and        p4, p2, p3
    s.add        s35, s10, s24
    v.extract    s36, v30, #1
    v.extract    s37, v30, #0
    s.add        s38, s35, s36
    s.add        s36, s35, s37
    s.addi       s37, s38, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s34, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s34, b5, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a13, v56, v48, s34
    mb.wait      s34
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s36, #0]
    p.and        p4, p2, p3
    v.extract    s36, v30, #3
    v.extract    s38, v30, #2
    s.add        s39, s35, s36
    s.add        s36, s35, s38
    s.addi       s38, s39, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v30, #4
    v.or         v43, v37, v42
    s.add        s39, s35, s37
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s36, #0]
    p.and        p4, p2, p3
    v.extract    s36, v30, #5
    s.add        s37, s35, s36
    s.addi       s36, s37, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s38, #0]
    p.and        p4, p1, p3
    v.extract    s37, v30, #6
    v.or         v43, v37, v42
    s.add        s38, s35, s37
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s39, #0]
    p.and        p4, p2, p3
    v.extract    s37, v30, #7
    s.add        s39, s35, s37
    s.addi       s37, s39, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s36, #0]
    p.and        p4, p1, p3
    v.extract    s36, v30, #8
    v.or         v43, v37, v42
    s.add        s39, s35, s36
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s38, #0]
    p.and        p4, p2, p3
    v.extract    s36, v30, #9
    s.add        s38, s35, s36
    s.addi       s36, s38, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v30, #10
    v.or         v43, v37, v42
    s.add        s38, s35, s37
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s39, #0]
    p.and        p4, p2, p3
    v.extract    s37, v30, #11
    s.add        s39, s35, s37
    s.addi       s37, s39, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s36, #0]
    p.and        p4, p1, p3
    v.extract    s36, v30, #12
    v.or         v43, v37, v42
    s.add        s39, s35, s36
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s38, #0]
    p.and        p4, p2, p3
    v.extract    s36, v30, #13
    s.add        s38, s35, s36
    s.addi       s36, s38, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v30, #14
    v.or         v43, v37, v42
    s.add        s38, s35, s37
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s39, #0]
    p.and        p4, p2, p3
    v.extract    s37, v30, #15
    s.add        s39, s35, s37
    s.addi       s35, s39, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s36, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s38, #0]
    p.and        p4, p2, p3
    s.add        s36, s10, s24
    v.extract    s37, v32, #1
    v.extract    s38, v32, #0
    s.add        s39, s36, s37
    s.add        s37, s36, s38
    s.addi       s38, s39, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s35, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s35, b6, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a14, v56, v48, s35
    mb.wait      s35
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s37, #0]
    p.and        p4, p2, p3
    v.extract    s37, v32, #3
    v.extract    s39, v32, #2
    s.add        s40, s36, s37
    s.add        s37, s36, s39
    s.addi       s39, s40, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s38, #0]
    p.and        p4, p1, p3
    v.extract    s38, v32, #4
    v.or         v43, v37, v42
    s.add        s40, s36, s38
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s37, #0]
    p.and        p4, p2, p3
    v.extract    s37, v32, #5
    s.add        s38, s36, s37
    s.addi       s37, s38, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s39, #0]
    p.and        p4, p1, p3
    v.extract    s38, v32, #6
    v.or         v43, v37, v42
    s.add        s39, s36, s38
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s40, #0]
    p.and        p4, p2, p3
    v.extract    s38, v32, #7
    s.add        s40, s36, s38
    s.addi       s38, s40, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v32, #8
    v.or         v43, v37, v42
    s.add        s40, s36, s37
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s39, #0]
    p.and        p4, p2, p3
    v.extract    s37, v32, #9
    s.add        s39, s36, s37
    s.addi       s37, s39, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s38, #0]
    p.and        p4, p1, p3
    v.extract    s38, v32, #10
    v.or         v43, v37, v42
    s.add        s39, s36, s38
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s40, #0]
    p.and        p4, p2, p3
    v.extract    s38, v32, #11
    s.add        s40, s36, s38
    s.addi       s38, s40, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v32, #12
    v.or         v43, v37, v42
    s.add        s40, s36, s37
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s39, #0]
    p.and        p4, p2, p3
    v.extract    s37, v32, #13
    s.add        s39, s36, s37
    s.addi       s37, s39, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s38, #0]
    p.and        p4, p1, p3
    v.extract    s38, v32, #14
    v.or         v43, v37, v42
    s.add        s39, s36, s38
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s40, #0]
    p.and        p4, p2, p3
    v.extract    s38, v32, #15
    s.add        s40, s36, s38
    s.addi       s36, s40, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    p.and        p5, p2, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v27, #0
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s39, #0]
    v.splat      v42, s37
    s.addi       s37, s30, #2048
    s.addi       s38, s30, #8704                 // 512 bytes of repack scratch
    vf.max.ieee  v43, v42, v13
    v.rcp.approx v42, v43                        // ISA 8.8: <= 2**-22 relative
    v.movi       v44, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v44, [s36, #0]
    v.or         v45, v37, v44
    vf.fms       v37, v43, v42, v21
    v.and        v44, v45, v39
    v.mov        v63, v44                        // hand off through the shared window (sec 7.3)
    mb.arm       s36, b7, #0, #1                 // 0 arrival(s), 1 operation(s)
    vf.fms       v39, v42, v37, v42
    m.mma.async.k32.e4m3 a15, v56, v48, s36
    mb.wait      s36
    v.ld.w       v37, [s37, #0]
    vf.neg       v44, v39                        // Newton step: r0*(2 - x*r0)
    s.addi       s37, s38, #0
    s.addi       s39, s30, #2112
    vf.cmp.o     p3, v44, v44
    v.extract    s40, v27, #1
    @p3 v.sel        v39, v44, v42
    v.splat      v42, s40
    vf.mul       v44, v37, v39                   // a/y: faithful quotient
    vf.max.ieee  v45, v42, v13
    vf.fms       v42, v44, v43, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v39, v44
    vf.neg       v39, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v42, v39, v44
    v.lshr       v39, v42, v40
    vf.cvt.f32.e4m3 v43, v42
    v.and        v42, v39, v41
    v.or         v39, v43, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v39
    vf.fms       v39, v45, v37, v21
    vf.fms       v42, v37, v39, v37
    vf.neg       v39, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s39, #0]
    s.addi       s37, s38, #1
    s.addi       s39, s30, #2176
    vf.cmp.o     p3, v39, v39
    v.extract    s40, v27, #2
    @p3 v.sel        v43, v39, v37
    v.splat      v37, s40
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s39, #0]
    s.addi       s37, s38, #2
    s.addi       s39, s30, #2240
    vf.cmp.o     p3, v37, v37
    v.extract    s40, v27, #3
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s40
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s39, #0]
    s.addi       s37, s38, #3
    s.addi       s39, s30, #2304
    vf.cmp.o     p3, v37, v37
    v.extract    s40, v27, #4
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s40
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s39, #0]
    s.addi       s37, s38, #4
    s.addi       s39, s30, #2368
    vf.cmp.o     p3, v37, v37
    v.extract    s40, v27, #5
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s40
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s39, #0]
    s.addi       s37, s38, #5
    s.addi       s39, s30, #2432
    vf.cmp.o     p3, v37, v37
    v.extract    s40, v27, #6
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s40
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s39, #0]
    s.addi       s37, s38, #6
    s.addi       s39, s30, #2496
    vf.cmp.o     p3, v37, v37
    v.extract    s40, v27, #7
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s40
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s39, #0]
    s.addi       s37, s38, #7
    s.addi       s39, s30, #2560
    vf.cmp.o     p3, v37, v37
    v.extract    s40, v27, #8
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s40
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s39, #0]
    s.addi       s37, s38, #8
    s.addi       s39, s30, #2624
    vf.cmp.o     p3, v37, v37
    v.extract    s40, v27, #9
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s40
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s39, #0]
    s.addi       s37, s38, #9
    s.addi       s39, s30, #2688
    vf.cmp.o     p3, v37, v37
    v.extract    s40, v27, #10
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s40
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s39, #0]
    s.addi       s37, s38, #10
    s.addi       s39, s30, #2752
    vf.cmp.o     p3, v37, v37
    v.extract    s40, v27, #11
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s40
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s39, #0]
    s.addi       s37, s38, #11
    s.addi       s39, s30, #2816
    vf.cmp.o     p3, v37, v37
    v.extract    s40, v27, #12
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s40
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s39, #0]
    s.addi       s37, s38, #12
    s.addi       s39, s30, #2880
    vf.cmp.o     p3, v37, v37
    v.extract    s40, v27, #13
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s40
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s39, #0]
    s.addi       s37, s38, #13
    s.addi       s39, s30, #2944
    vf.cmp.o     p3, v37, v37
    v.extract    s40, v27, #14
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s40
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s39, #0]
    s.addi       s37, s38, #14
    s.addi       s39, s30, #3008
    vf.cmp.o     p3, v37, v37
    v.extract    s40, v27, #15
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s40
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s39, #0]
    s.addi       s37, s38, #15
    s.addi       s39, s30, #3072
    vf.cmp.o     p3, v37, v37
    v.extract    s40, v27, #0
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s40
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s39, #0]
    s.addi       s37, s38, #256
    s.addi       s39, s30, #3136
    vf.cmp.o     p3, v37, v37
    v.extract    s40, v27, #1
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s40
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s39, #0]
    s.addi       s37, s38, #257
    s.addi       s39, s30, #3200
    vf.cmp.o     p3, v37, v37
    v.extract    s40, v27, #2
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s40
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s39, #0]
    s.addi       s37, s38, #258
    s.addi       s39, s30, #3264
    vf.cmp.o     p3, v37, v37
    v.extract    s40, v27, #3
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s40
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s39, #0]
    s.addi       s37, s38, #259
    s.addi       s39, s30, #3328
    vf.cmp.o     p3, v37, v37
    v.extract    s40, v27, #4
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s40
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s39, #0]
    s.addi       s37, s38, #260
    s.addi       s39, s30, #3392
    vf.cmp.o     p3, v37, v37
    v.extract    s40, v27, #5
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s40
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s39, #0]
    s.addi       s37, s38, #261
    s.addi       s39, s30, #3456
    vf.cmp.o     p3, v37, v37
    v.extract    s40, v27, #6
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s40
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s39, #0]
    s.addi       s37, s38, #262
    s.addi       s39, s30, #3520
    vf.cmp.o     p3, v37, v37
    v.extract    s40, v27, #7
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s40
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s39, #0]
    s.addi       s37, s38, #263
    s.addi       s39, s30, #3584
    vf.cmp.o     p3, v37, v37
    v.extract    s40, v27, #8
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s40
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s39, #0]
    s.addi       s37, s38, #264
    s.addi       s39, s30, #3648
    vf.cmp.o     p3, v37, v37
    v.extract    s40, v27, #9
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s40
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s39, #0]
    s.addi       s37, s38, #265
    s.addi       s39, s30, #3712
    vf.cmp.o     p3, v37, v37
    v.extract    s40, v27, #10
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s40
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s39, #0]
    s.addi       s37, s38, #266
    s.addi       s39, s30, #3776
    vf.cmp.o     p3, v37, v37
    v.extract    s40, v27, #11
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s40
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s39, #0]
    s.addi       s37, s38, #267
    s.addi       s39, s30, #3840
    vf.cmp.o     p3, v37, v37
    v.extract    s40, v27, #12
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s40
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s39, #0]
    s.addi       s37, s38, #268
    s.addi       s39, s30, #3904
    vf.cmp.o     p3, v37, v37
    v.extract    s40, v27, #13
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s40
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s39, #0]
    s.addi       s37, s38, #269
    s.addi       s39, s30, #3968
    vf.cmp.o     p3, v37, v37
    v.extract    s40, v27, #14
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s40
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s39, #0]
    s.addi       s37, s38, #270
    s.addi       s39, s30, #4032
    vf.cmp.o     p3, v37, v37
    v.extract    s40, v27, #15
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s40
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s39, #0]
    s.addi       s37, s38, #271
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    vf.mul       v37, v42, v43                   // a/y: faithful quotient
    s.addi       s39, s38, #64
    vf.fms       v39, v37, v45, v42
    vf.fms       v42, v39, v43, v37
    vf.neg       v39, v42                        // a/y: one correction to the IEEE quotient
    s.addi       s40, s38, #128
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v42, v39, v37
    v.lshr       v37, v42, v40
    vf.cvt.f32.e4m3 v39, v42
    s.addi       s41, s38, #192
    v.and        v42, v37, v41
    v.or         v37, v39, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s42, s38, #256
    v.st.scatter.b [s37, v18], v37
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s37, s38, #320
    v.ld.w       v37, [s38, #0]
    v.mov        v48, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s39, #0]
    s.addi       s39, s38, #384
    v.mov        v49, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s40, #0]
    s.addi       s40, s38, #448
    v.mov        v50, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s41, #0]
    s.addi       s38, s28, #-32
    v.splat      v39, s38
    v.sub        v42, v39, v33
    v.mov        v51, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s42, #0]
    v.movi       v39, #0
    v.movi       v43, #0
    v.cmp.gt     p3, v42, v39
    v.mov        v52, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s37, #0]
    v.max.s      v39, v42, v43
    v.movi       v42, #4
    v.min.s      v43, v39, v42
    v.mov        v53, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s39, #0]
    v.movi       v39, #3
    v.movi       v42, #1
    v.shl        v44, v43, v39
    v.mov        v54, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s40, #0]
    v.shl        v39, v42, v44
    v.movi       v42, #1
    v.sub        v44, v39, v42
    v.mov        v55, v37                        // hand off through the shared window (sec 7.3)
    s.addi       s37, s24, #32
    v.extract    s38, v24, #1
    s.add        s39, s10, s37
    v.extract    s37, v24, #0
    s.add        s40, s39, s38
    s.add        s38, s39, s37
    p.and        p4, p1, p3
    s.addi       s37, s40, #-32
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s38, #0]
    p.and        p4, p2, p3
    v.movi       v39, #4
    v.movi       v42, #-1
    v.movi       v45, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v45, [s37, #0]
    v.cmp.ge     p4, v43, v39
    @p4 v.sel        v39, v42, v44
    v.extract    s37, v24, #3
    v.extract    s38, v24, #2
    s.add        s40, s39, s37
    s.add        s37, s39, s38
    p.and        p4, p1, p3
    s.addi       s38, s40, #-32
    v.extract    s40, v24, #4
    v.or         v42, v37, v45
    s.add        s41, s39, s40
    v.and        v37, v42, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s37, #0]
    p.and        p4, p2, p3
    v.extract    s37, v24, #5
    s.add        s40, s39, s37
    s.addi       s37, s40, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s38, #0]
    p.and        p4, p1, p3
    v.extract    s38, v24, #6
    v.or         v43, v37, v42
    s.add        s40, s39, s38
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s41, #0]
    p.and        p4, p2, p3
    v.extract    s38, v24, #7
    s.add        s41, s39, s38
    s.addi       s38, s41, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v24, #8
    v.or         v43, v37, v42
    s.add        s41, s39, s37
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s40, #0]
    p.and        p4, p2, p3
    v.extract    s37, v24, #9
    s.add        s40, s39, s37
    s.addi       s37, s40, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s38, #0]
    p.and        p4, p1, p3
    v.extract    s38, v24, #10
    v.or         v43, v37, v42
    s.add        s40, s39, s38
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s41, #0]
    p.and        p4, p2, p3
    v.extract    s38, v24, #11
    s.add        s41, s39, s38
    s.addi       s38, s41, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v24, #12
    v.or         v43, v37, v42
    s.add        s41, s39, s37
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s40, #0]
    p.and        p4, p2, p3
    v.extract    s37, v24, #13
    s.add        s40, s39, s37
    s.addi       s37, s40, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s38, #0]
    p.and        p4, p1, p3
    v.extract    s38, v24, #14
    v.or         v43, v37, v42
    s.add        s40, s39, s38
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s41, #0]
    p.and        p4, p2, p3
    v.extract    s38, v24, #15
    s.add        s41, s39, s38
    s.addi       s38, s41, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s40, #0]
    p.and        p4, p2, p3
    s.addi       s37, s24, #32
    v.extract    s39, v22, #1
    s.add        s40, s10, s37
    v.extract    s37, v22, #0
    s.add        s41, s40, s39
    s.add        s39, s40, s37
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s38, #0]
    p.and        p4, p1, p3
    s.addi       s37, s41, #-32
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s38, b8, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a8, v56, v48, s38
    mb.wait      s38
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s39, #0]
    p.and        p4, p2, p3
    v.extract    s39, v22, #3
    v.extract    s41, v22, #2
    s.add        s42, s40, s39
    s.add        s39, s40, s41
    s.addi       s41, s42, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v22, #4
    v.or         v43, v37, v42
    s.add        s42, s40, s37
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s39, #0]
    p.and        p4, p2, p3
    v.extract    s37, v22, #5
    s.add        s39, s40, s37
    s.addi       s37, s39, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s41, #0]
    p.and        p4, p1, p3
    v.extract    s39, v22, #6
    v.or         v43, v37, v42
    s.add        s41, s40, s39
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s42, #0]
    p.and        p4, p2, p3
    v.extract    s39, v22, #7
    s.add        s42, s40, s39
    s.addi       s39, s42, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v22, #8
    v.or         v43, v37, v42
    s.add        s42, s40, s37
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s41, #0]
    p.and        p4, p2, p3
    v.extract    s37, v22, #9
    s.add        s41, s40, s37
    s.addi       s37, s41, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s39, #0]
    p.and        p4, p1, p3
    v.extract    s39, v22, #10
    v.or         v43, v37, v42
    s.add        s41, s40, s39
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s42, #0]
    p.and        p4, p2, p3
    v.extract    s39, v22, #11
    s.add        s42, s40, s39
    s.addi       s39, s42, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v22, #12
    v.or         v43, v37, v42
    s.add        s42, s40, s37
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s41, #0]
    p.and        p4, p2, p3
    v.extract    s37, v22, #13
    s.add        s41, s40, s37
    s.addi       s37, s41, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s39, #0]
    p.and        p4, p1, p3
    v.extract    s39, v22, #14
    v.or         v43, v37, v42
    s.add        s41, s40, s39
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s42, #0]
    p.and        p4, p2, p3
    v.extract    s39, v22, #15
    s.add        s42, s40, s39
    s.addi       s39, s42, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s41, #0]
    p.and        p4, p2, p3
    s.addi       s37, s24, #32
    v.extract    s40, v23, #1
    s.add        s41, s10, s37
    v.extract    s37, v23, #0
    s.add        s42, s41, s40
    s.add        s40, s41, s37
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s39, #0]
    p.and        p4, p1, p3
    s.addi       s37, s42, #-32
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s39, b9, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a9, v56, v48, s39
    mb.wait      s39
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s40, #0]
    p.and        p4, p2, p3
    v.extract    s40, v23, #3
    v.extract    s42, v23, #2
    s.add        s43, s41, s40
    s.add        s40, s41, s42
    s.addi       s42, s43, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v23, #4
    v.or         v43, v37, v42
    s.add        s43, s41, s37
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s40, #0]
    p.and        p4, p2, p3
    v.extract    s37, v23, #5
    s.add        s40, s41, s37
    s.addi       s37, s40, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s42, #0]
    p.and        p4, p1, p3
    v.extract    s40, v23, #6
    v.or         v43, v37, v42
    s.add        s42, s41, s40
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s43, #0]
    p.and        p4, p2, p3
    v.extract    s40, v23, #7
    s.add        s43, s41, s40
    s.addi       s40, s43, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v23, #8
    v.or         v43, v37, v42
    s.add        s43, s41, s37
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s42, #0]
    p.and        p4, p2, p3
    v.extract    s37, v23, #9
    s.add        s42, s41, s37
    s.addi       s37, s42, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v23, #10
    v.or         v43, v37, v42
    s.add        s42, s41, s40
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s43, #0]
    p.and        p4, p2, p3
    v.extract    s40, v23, #11
    s.add        s43, s41, s40
    s.addi       s40, s43, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v23, #12
    v.or         v43, v37, v42
    s.add        s43, s41, s37
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s42, #0]
    p.and        p4, p2, p3
    v.extract    s37, v23, #13
    s.add        s42, s41, s37
    s.addi       s37, s42, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v23, #14
    v.or         v43, v37, v42
    s.add        s42, s41, s40
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s43, #0]
    p.and        p4, p2, p3
    v.extract    s40, v23, #15
    s.add        s43, s41, s40
    s.addi       s40, s43, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s42, #0]
    p.and        p4, p2, p3
    s.addi       s37, s24, #32
    v.extract    s41, v19, #1
    s.add        s42, s10, s37
    v.extract    s37, v19, #0
    s.add        s43, s42, s41
    s.add        s41, s42, s37
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s40, #0]
    p.and        p4, p1, p3
    s.addi       s37, s43, #-32
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s40, b10, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a10, v56, v48, s40
    mb.wait      s40
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s41, #0]
    p.and        p4, p2, p3
    v.extract    s41, v19, #3
    v.extract    s43, v19, #2
    s.add        s44, s42, s41
    s.add        s41, s42, s43
    s.addi       s43, s44, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v19, #4
    v.or         v43, v37, v42
    s.add        s44, s42, s37
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s41, #0]
    p.and        p4, p2, p3
    v.extract    s37, v19, #5
    s.add        s41, s42, s37
    s.addi       s37, s41, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s43, #0]
    p.and        p4, p1, p3
    v.extract    s41, v19, #6
    v.or         v43, v37, v42
    s.add        s43, s42, s41
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s44, #0]
    p.and        p4, p2, p3
    v.extract    s41, v19, #7
    s.add        s44, s42, s41
    s.addi       s41, s44, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v19, #8
    v.or         v43, v37, v42
    s.add        s44, s42, s37
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s43, #0]
    p.and        p4, p2, p3
    v.extract    s37, v19, #9
    s.add        s43, s42, s37
    s.addi       s37, s43, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s41, #0]
    p.and        p4, p1, p3
    v.extract    s41, v19, #10
    v.or         v43, v37, v42
    s.add        s43, s42, s41
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s44, #0]
    p.and        p4, p2, p3
    v.extract    s41, v19, #11
    s.add        s44, s42, s41
    s.addi       s41, s44, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v19, #12
    v.or         v43, v37, v42
    s.add        s44, s42, s37
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s43, #0]
    p.and        p4, p2, p3
    v.extract    s37, v19, #13
    s.add        s43, s42, s37
    s.addi       s37, s43, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s41, #0]
    p.and        p4, p1, p3
    v.extract    s41, v19, #14
    v.or         v43, v37, v42
    s.add        s43, s42, s41
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s44, #0]
    p.and        p4, p2, p3
    v.extract    s41, v19, #15
    s.add        s44, s42, s41
    s.addi       s41, s44, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s43, #0]
    p.and        p4, p2, p3
    s.addi       s37, s24, #32
    v.extract    s42, v28, #1
    s.add        s43, s10, s37
    v.extract    s37, v28, #0
    s.add        s44, s43, s42
    s.add        s42, s43, s37
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s41, #0]
    p.and        p4, p1, p3
    s.addi       s37, s44, #-32
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s41, b11, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a11, v56, v48, s41
    mb.wait      s41
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s42, #0]
    p.and        p4, p2, p3
    v.extract    s42, v28, #3
    v.extract    s44, v28, #2
    s.add        s45, s43, s42
    s.add        s42, s43, s44
    s.addi       s44, s45, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v28, #4
    v.or         v43, v37, v42
    s.add        s45, s43, s37
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s42, #0]
    p.and        p4, p2, p3
    v.extract    s37, v28, #5
    s.add        s42, s43, s37
    s.addi       s37, s42, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s44, #0]
    p.and        p4, p1, p3
    v.extract    s42, v28, #6
    v.or         v43, v37, v42
    s.add        s44, s43, s42
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s45, #0]
    p.and        p4, p2, p3
    v.extract    s42, v28, #7
    s.add        s45, s43, s42
    s.addi       s42, s45, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v28, #8
    v.or         v43, v37, v42
    s.add        s45, s43, s37
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s44, #0]
    p.and        p4, p2, p3
    v.extract    s37, v28, #9
    s.add        s44, s43, s37
    s.addi       s37, s44, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s42, #0]
    p.and        p4, p1, p3
    v.extract    s42, v28, #10
    v.or         v43, v37, v42
    s.add        s44, s43, s42
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s45, #0]
    p.and        p4, p2, p3
    v.extract    s42, v28, #11
    s.add        s45, s43, s42
    s.addi       s42, s45, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v28, #12
    v.or         v43, v37, v42
    s.add        s45, s43, s37
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s44, #0]
    p.and        p4, p2, p3
    v.extract    s37, v28, #13
    s.add        s44, s43, s37
    s.addi       s37, s44, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s42, #0]
    p.and        p4, p1, p3
    v.extract    s42, v28, #14
    v.or         v43, v37, v42
    s.add        s44, s43, s42
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s45, #0]
    p.and        p4, p2, p3
    v.extract    s42, v28, #15
    s.add        s45, s43, s42
    s.addi       s42, s45, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s44, #0]
    p.and        p4, p2, p3
    s.addi       s37, s24, #32
    v.extract    s43, v25, #1
    s.add        s44, s10, s37
    v.extract    s37, v25, #0
    s.add        s45, s44, s43
    s.add        s43, s44, s37
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s42, #0]
    p.and        p4, p1, p3
    s.addi       s37, s45, #-32
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s42, b12, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a12, v56, v48, s42
    mb.wait      s42
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s43, #0]
    p.and        p4, p2, p3
    v.extract    s43, v25, #3
    v.extract    s45, v25, #2
    s.add        s46, s44, s43
    s.add        s43, s44, s45
    s.addi       s45, s46, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v25, #4
    v.or         v43, v37, v42
    s.add        s46, s44, s37
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s43, #0]
    p.and        p4, p2, p3
    v.extract    s37, v25, #5
    s.add        s43, s44, s37
    s.addi       s37, s43, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s45, #0]
    p.and        p4, p1, p3
    v.extract    s43, v25, #6
    v.or         v43, v37, v42
    s.add        s45, s44, s43
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s46, #0]
    p.and        p4, p2, p3
    v.extract    s43, v25, #7
    s.add        s46, s44, s43
    s.addi       s43, s46, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v25, #8
    v.or         v43, v37, v42
    s.add        s46, s44, s37
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s45, #0]
    p.and        p4, p2, p3
    v.extract    s37, v25, #9
    s.add        s45, s44, s37
    s.addi       s37, s45, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s43, #0]
    p.and        p4, p1, p3
    v.extract    s43, v25, #10
    v.or         v43, v37, v42
    s.add        s45, s44, s43
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s46, #0]
    p.and        p4, p2, p3
    v.extract    s43, v25, #11
    s.add        s46, s44, s43
    s.addi       s43, s46, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v25, #12
    v.or         v43, v37, v42
    s.add        s46, s44, s37
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s45, #0]
    p.and        p4, p2, p3
    v.extract    s37, v25, #13
    s.add        s45, s44, s37
    s.addi       s37, s45, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s43, #0]
    p.and        p4, p1, p3
    v.extract    s43, v25, #14
    v.or         v43, v37, v42
    s.add        s45, s44, s43
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s46, #0]
    p.and        p4, p2, p3
    v.extract    s43, v25, #15
    s.add        s46, s44, s43
    s.addi       s43, s46, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s45, #0]
    p.and        p4, p2, p3
    s.addi       s37, s24, #32
    v.extract    s44, v30, #1
    s.add        s45, s10, s37
    v.extract    s37, v30, #0
    s.add        s46, s45, s44
    s.add        s44, s45, s37
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s43, #0]
    p.and        p4, p1, p3
    s.addi       s37, s46, #-32
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s43, b13, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a13, v56, v48, s43
    mb.wait      s43
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s44, #0]
    p.and        p4, p2, p3
    v.extract    s44, v30, #3
    v.extract    s46, v30, #2
    s.add        s47, s45, s44
    s.add        s44, s45, s46
    s.addi       s46, s47, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v30, #4
    v.or         v43, v37, v42
    s.add        s47, s45, s37
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s44, #0]
    p.and        p4, p2, p3
    v.extract    s37, v30, #5
    s.add        s44, s45, s37
    s.addi       s37, s44, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s46, #0]
    p.and        p4, p1, p3
    v.extract    s44, v30, #6
    v.or         v43, v37, v42
    s.add        s46, s45, s44
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s47, #0]
    p.and        p4, p2, p3
    v.extract    s44, v30, #7
    s.add        s47, s45, s44
    s.addi       s44, s47, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v30, #8
    v.or         v43, v37, v42
    s.add        s47, s45, s37
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s46, #0]
    p.and        p4, p2, p3
    v.extract    s37, v30, #9
    s.add        s46, s45, s37
    s.addi       s37, s46, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s44, #0]
    p.and        p4, p1, p3
    v.extract    s44, v30, #10
    v.or         v43, v37, v42
    s.add        s46, s45, s44
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s47, #0]
    p.and        p4, p2, p3
    v.extract    s44, v30, #11
    s.add        s47, s45, s44
    s.addi       s44, s47, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v30, #12
    v.or         v43, v37, v42
    s.add        s47, s45, s37
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s46, #0]
    p.and        p4, p2, p3
    v.extract    s37, v30, #13
    s.add        s46, s45, s37
    s.addi       s37, s46, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s44, #0]
    p.and        p4, p1, p3
    v.extract    s44, v30, #14
    v.or         v43, v37, v42
    s.add        s46, s45, s44
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s47, #0]
    p.and        p4, p2, p3
    v.extract    s44, v30, #15
    s.add        s47, s45, s44
    s.addi       s44, s47, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s46, #0]
    p.and        p4, p2, p3
    s.addi       s37, s24, #32
    v.extract    s45, v32, #1
    s.add        s46, s10, s37
    v.extract    s37, v32, #0
    s.add        s47, s46, s45
    s.add        s45, s46, s37
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s44, #0]
    p.and        p4, p1, p3
    s.addi       s37, s47, #-32
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s44, b14, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a14, v56, v48, s44
    mb.wait      s44
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s45, #0]
    p.and        p4, p2, p3
    v.extract    s45, v32, #3
    v.extract    s47, v32, #2
    s.add        s48, s46, s45
    s.add        s45, s46, s47
    s.addi       s47, s48, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v32, #4
    v.or         v43, v37, v42
    s.add        s48, s46, s37
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s45, #0]
    p.and        p4, p2, p3
    v.extract    s37, v32, #5
    s.add        s45, s46, s37
    s.addi       s37, s45, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s47, #0]
    p.and        p4, p1, p3
    v.extract    s45, v32, #6
    v.or         v43, v37, v42
    s.add        s47, s46, s45
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s48, #0]
    p.and        p4, p2, p3
    v.extract    s45, v32, #7
    s.add        s48, s46, s45
    s.addi       s45, s48, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v32, #8
    v.or         v43, v37, v42
    s.add        s48, s46, s37
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s47, #0]
    p.and        p4, p2, p3
    v.extract    s37, v32, #9
    s.add        s47, s46, s37
    s.addi       s37, s47, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s45, #0]
    p.and        p4, p1, p3
    v.extract    s45, v32, #10
    v.or         v43, v37, v42
    s.add        s47, s46, s45
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s48, #0]
    p.and        p4, p2, p3
    v.extract    s45, v32, #11
    s.add        s48, s46, s45
    s.addi       s45, s48, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v32, #12
    v.or         v43, v37, v42
    s.add        s48, s46, s37
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s47, #0]
    p.and        p4, p2, p3
    v.extract    s37, v32, #13
    s.add        s47, s46, s37
    s.addi       s37, s47, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s45, #0]
    p.and        p4, p1, p3
    v.extract    s45, v32, #14
    v.or         v43, v37, v42
    s.add        s47, s46, s45
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s48, #0]
    p.and        p4, p2, p3
    v.extract    s45, v32, #15
    s.add        s48, s46, s45
    s.addi       s45, s48, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    p.and        p5, p2, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v27, #0
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s47, #0]
    v.splat      v42, s37
    s.addi       s37, s30, #4096
    s.addi       s46, s30, #9216                 // 512 bytes of repack scratch
    vf.max.ieee  v43, v42, v13
    v.rcp.approx v42, v43                        // ISA 8.8: <= 2**-22 relative
    v.movi       v44, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v44, [s45, #0]
    v.or         v45, v37, v44
    vf.fms       v37, v43, v42, v21
    v.and        v44, v45, v39
    v.mov        v63, v44                        // hand off through the shared window (sec 7.3)
    mb.arm       s45, b15, #0, #1                // 0 arrival(s), 1 operation(s)
    vf.fms       v39, v42, v37, v42
    m.mma.async.k32.e4m3 a15, v56, v48, s45
    mb.wait      s45
    v.ld.w       v37, [s37, #0]
    vf.neg       v44, v39                        // Newton step: r0*(2 - x*r0)
    s.addi       s37, s46, #0
    s.addi       s47, s30, #4160
    vf.cmp.o     p3, v44, v44
    v.extract    s48, v27, #1
    @p3 v.sel        v39, v44, v42
    v.splat      v42, s48
    vf.mul       v44, v37, v39                   // a/y: faithful quotient
    vf.max.ieee  v45, v42, v13
    vf.fms       v42, v44, v43, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v39, v44
    vf.neg       v39, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v42, v39, v44
    v.lshr       v39, v42, v40
    vf.cvt.f32.e4m3 v43, v42
    v.and        v42, v39, v41
    v.or         v39, v43, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v39
    vf.fms       v39, v45, v37, v21
    vf.fms       v42, v37, v39, v37
    vf.neg       v39, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s47, #0]
    s.addi       s37, s46, #1
    s.addi       s47, s30, #4224
    vf.cmp.o     p3, v39, v39
    v.extract    s48, v27, #2
    @p3 v.sel        v43, v39, v37
    v.splat      v37, s48
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s47, #0]
    s.addi       s37, s46, #2
    s.addi       s47, s30, #4288
    vf.cmp.o     p3, v37, v37
    v.extract    s48, v27, #3
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s48
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s47, #0]
    s.addi       s37, s46, #3
    s.addi       s47, s30, #4352
    vf.cmp.o     p3, v37, v37
    v.extract    s48, v27, #4
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s48
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s47, #0]
    s.addi       s37, s46, #4
    s.addi       s47, s30, #4416
    vf.cmp.o     p3, v37, v37
    v.extract    s48, v27, #5
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s48
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s47, #0]
    s.addi       s37, s46, #5
    s.addi       s47, s30, #4480
    vf.cmp.o     p3, v37, v37
    v.extract    s48, v27, #6
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s48
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s47, #0]
    s.addi       s37, s46, #6
    s.addi       s47, s30, #4544
    vf.cmp.o     p3, v37, v37
    v.extract    s48, v27, #7
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s48
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s47, #0]
    s.addi       s37, s46, #7
    s.addi       s47, s30, #4608
    vf.cmp.o     p3, v37, v37
    v.extract    s48, v27, #8
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s48
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s47, #0]
    s.addi       s37, s46, #8
    s.addi       s47, s30, #4672
    vf.cmp.o     p3, v37, v37
    v.extract    s48, v27, #9
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s48
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s47, #0]
    s.addi       s37, s46, #9
    s.addi       s47, s30, #4736
    vf.cmp.o     p3, v37, v37
    v.extract    s48, v27, #10
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s48
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s47, #0]
    s.addi       s37, s46, #10
    s.addi       s47, s30, #4800
    vf.cmp.o     p3, v37, v37
    v.extract    s48, v27, #11
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s48
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s47, #0]
    s.addi       s37, s46, #11
    s.addi       s47, s30, #4864
    vf.cmp.o     p3, v37, v37
    v.extract    s48, v27, #12
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s48
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s47, #0]
    s.addi       s37, s46, #12
    s.addi       s47, s30, #4928
    vf.cmp.o     p3, v37, v37
    v.extract    s48, v27, #13
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s48
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s47, #0]
    s.addi       s37, s46, #13
    s.addi       s47, s30, #4992
    vf.cmp.o     p3, v37, v37
    v.extract    s48, v27, #14
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s48
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s47, #0]
    s.addi       s37, s46, #14
    s.addi       s47, s30, #5056
    vf.cmp.o     p3, v37, v37
    v.extract    s48, v27, #15
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s48
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s47, #0]
    s.addi       s37, s46, #15
    s.addi       s47, s30, #5120
    vf.cmp.o     p3, v37, v37
    v.extract    s48, v27, #0
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s48
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s47, #0]
    s.addi       s37, s46, #256
    s.addi       s47, s30, #5184
    vf.cmp.o     p3, v37, v37
    v.extract    s48, v27, #1
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s48
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s47, #0]
    s.addi       s37, s46, #257
    s.addi       s47, s30, #5248
    vf.cmp.o     p3, v37, v37
    v.extract    s48, v27, #2
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s48
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s47, #0]
    s.addi       s37, s46, #258
    s.addi       s47, s30, #5312
    vf.cmp.o     p3, v37, v37
    v.extract    s48, v27, #3
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s48
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s47, #0]
    s.addi       s37, s46, #259
    s.addi       s47, s30, #5376
    vf.cmp.o     p3, v37, v37
    v.extract    s48, v27, #4
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s48
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s47, #0]
    s.addi       s37, s46, #260
    s.addi       s47, s30, #5440
    vf.cmp.o     p3, v37, v37
    v.extract    s48, v27, #5
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s48
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s47, #0]
    s.addi       s37, s46, #261
    s.addi       s47, s30, #5504
    vf.cmp.o     p3, v37, v37
    v.extract    s48, v27, #6
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s48
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s47, #0]
    s.addi       s37, s46, #262
    s.addi       s47, s30, #5568
    vf.cmp.o     p3, v37, v37
    v.extract    s48, v27, #7
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s48
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s47, #0]
    s.addi       s37, s46, #263
    s.addi       s47, s30, #5632
    vf.cmp.o     p3, v37, v37
    v.extract    s48, v27, #8
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s48
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s47, #0]
    s.addi       s37, s46, #264
    s.addi       s47, s30, #5696
    vf.cmp.o     p3, v37, v37
    v.extract    s48, v27, #9
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s48
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s47, #0]
    s.addi       s37, s46, #265
    s.addi       s47, s30, #5760
    vf.cmp.o     p3, v37, v37
    v.extract    s48, v27, #10
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s48
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s47, #0]
    s.addi       s37, s46, #266
    s.addi       s47, s30, #5824
    vf.cmp.o     p3, v37, v37
    v.extract    s48, v27, #11
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s48
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s47, #0]
    s.addi       s37, s46, #267
    s.addi       s47, s30, #5888
    vf.cmp.o     p3, v37, v37
    v.extract    s48, v27, #12
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s48
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s47, #0]
    s.addi       s37, s46, #268
    s.addi       s47, s30, #5952
    vf.cmp.o     p3, v37, v37
    v.extract    s48, v27, #13
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s48
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s47, #0]
    s.addi       s37, s46, #269
    s.addi       s47, s30, #6016
    vf.cmp.o     p3, v37, v37
    v.extract    s48, v27, #14
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s48
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s47, #0]
    s.addi       s37, s46, #270
    s.addi       s47, s30, #6080
    vf.cmp.o     p3, v37, v37
    v.extract    s48, v27, #15
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s48
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s47, #0]
    s.addi       s37, s46, #271
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    vf.mul       v37, v42, v43                   // a/y: faithful quotient
    s.addi       s47, s46, #64
    vf.fms       v39, v37, v45, v42
    vf.fms       v42, v39, v43, v37
    vf.neg       v39, v42                        // a/y: one correction to the IEEE quotient
    s.addi       s48, s46, #128
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v42, v39, v37
    v.lshr       v37, v42, v40
    vf.cvt.f32.e4m3 v39, v42
    s.addi       s49, s46, #192
    v.and        v42, v37, v41
    v.or         v37, v39, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s50, s46, #256
    v.st.scatter.b [s37, v18], v37
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s37, s46, #320
    v.ld.w       v37, [s46, #0]
    v.mov        v48, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s47, #0]
    s.addi       s47, s46, #384
    v.mov        v49, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s48, #0]
    s.addi       s48, s46, #448
    v.mov        v50, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s49, #0]
    s.addi       s46, s28, #-64
    v.splat      v39, s46
    v.sub        v42, v39, v33
    v.mov        v51, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s50, #0]
    v.movi       v39, #0
    v.movi       v43, #0
    v.cmp.gt     p3, v42, v39
    v.mov        v52, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s37, #0]
    v.max.s      v39, v42, v43
    v.movi       v42, #4
    v.min.s      v43, v39, v42
    v.mov        v53, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s47, #0]
    v.movi       v39, #3
    v.movi       v42, #1
    v.shl        v44, v43, v39
    v.mov        v54, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s48, #0]
    v.shl        v39, v42, v44
    v.movi       v42, #1
    v.sub        v44, v39, v42
    v.mov        v55, v37                        // hand off through the shared window (sec 7.3)
    s.addi       s37, s24, #64
    v.extract    s46, v24, #1
    s.add        s47, s10, s37
    v.extract    s37, v24, #0
    s.add        s48, s47, s46
    s.add        s46, s47, s37
    p.and        p4, p1, p3
    s.addi       s37, s48, #-32
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s46, #0]
    p.and        p4, p2, p3
    v.movi       v39, #4
    v.movi       v42, #-1
    v.movi       v45, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v45, [s37, #0]
    v.cmp.ge     p4, v43, v39
    @p4 v.sel        v39, v42, v44
    v.extract    s37, v24, #3
    v.extract    s46, v24, #2
    s.add        s48, s47, s37
    s.add        s37, s47, s46
    p.and        p4, p1, p3
    s.addi       s46, s48, #-32
    v.extract    s48, v24, #4
    v.or         v42, v37, v45
    s.add        s49, s47, s48
    v.and        v37, v42, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s37, #0]
    p.and        p4, p2, p3
    v.extract    s37, v24, #5
    s.add        s48, s47, s37
    s.addi       s37, s48, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s46, #0]
    p.and        p4, p1, p3
    v.extract    s46, v24, #6
    v.or         v43, v37, v42
    s.add        s48, s47, s46
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s49, #0]
    p.and        p4, p2, p3
    v.extract    s46, v24, #7
    s.add        s49, s47, s46
    s.addi       s46, s49, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v24, #8
    v.or         v43, v37, v42
    s.add        s49, s47, s37
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s48, #0]
    p.and        p4, p2, p3
    v.extract    s37, v24, #9
    s.add        s48, s47, s37
    s.addi       s37, s48, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s46, #0]
    p.and        p4, p1, p3
    v.extract    s46, v24, #10
    v.or         v43, v37, v42
    s.add        s48, s47, s46
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s49, #0]
    p.and        p4, p2, p3
    v.extract    s46, v24, #11
    s.add        s49, s47, s46
    s.addi       s46, s49, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v24, #12
    v.or         v43, v37, v42
    s.add        s49, s47, s37
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s48, #0]
    p.and        p4, p2, p3
    v.extract    s37, v24, #13
    s.add        s48, s47, s37
    s.addi       s37, s48, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s46, #0]
    p.and        p4, p1, p3
    v.extract    s46, v24, #14
    v.or         v43, v37, v42
    s.add        s48, s47, s46
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s49, #0]
    p.and        p4, p2, p3
    v.extract    s46, v24, #15
    s.add        s49, s47, s46
    s.addi       s46, s49, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s48, #0]
    p.and        p4, p2, p3
    s.addi       s37, s24, #64
    v.extract    s47, v22, #1
    s.add        s48, s10, s37
    v.extract    s37, v22, #0
    s.add        s49, s48, s47
    s.add        s47, s48, s37
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s46, #0]
    p.and        p4, p1, p3
    s.addi       s37, s49, #-32
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s46, b16, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a8, v56, v48, s46
    mb.wait      s46
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s47, #0]
    p.and        p4, p2, p3
    v.extract    s47, v22, #3
    v.extract    s49, v22, #2
    s.add        s50, s48, s47
    s.add        s47, s48, s49
    s.addi       s49, s50, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v22, #4
    v.or         v43, v37, v42
    s.add        s50, s48, s37
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s47, #0]
    p.and        p4, p2, p3
    v.extract    s37, v22, #5
    s.add        s47, s48, s37
    s.addi       s37, s47, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s49, #0]
    p.and        p4, p1, p3
    v.extract    s47, v22, #6
    v.or         v43, v37, v42
    s.add        s49, s48, s47
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s50, #0]
    p.and        p4, p2, p3
    v.extract    s47, v22, #7
    s.add        s50, s48, s47
    s.addi       s47, s50, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v22, #8
    v.or         v43, v37, v42
    s.add        s50, s48, s37
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s49, #0]
    p.and        p4, p2, p3
    v.extract    s37, v22, #9
    s.add        s49, s48, s37
    s.addi       s37, s49, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s47, #0]
    p.and        p4, p1, p3
    v.extract    s47, v22, #10
    v.or         v43, v37, v42
    s.add        s49, s48, s47
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s50, #0]
    p.and        p4, p2, p3
    v.extract    s47, v22, #11
    s.add        s50, s48, s47
    s.addi       s47, s50, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v22, #12
    v.or         v43, v37, v42
    s.add        s50, s48, s37
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s49, #0]
    p.and        p4, p2, p3
    v.extract    s37, v22, #13
    s.add        s49, s48, s37
    s.addi       s37, s49, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s47, #0]
    p.and        p4, p1, p3
    v.extract    s47, v22, #14
    v.or         v43, v37, v42
    s.add        s49, s48, s47
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s50, #0]
    p.and        p4, p2, p3
    v.extract    s47, v22, #15
    s.add        s50, s48, s47
    s.addi       s47, s50, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s49, #0]
    p.and        p4, p2, p3
    s.addi       s37, s24, #64
    v.extract    s48, v23, #1
    s.add        s49, s10, s37
    v.extract    s37, v23, #0
    s.add        s50, s49, s48
    s.add        s48, s49, s37
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s47, #0]
    p.and        p4, p1, p3
    s.addi       s37, s50, #-32
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s47, b17, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a9, v56, v48, s47
    mb.wait      s47
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s48, #0]
    p.and        p4, p2, p3
    v.extract    s48, v23, #3
    v.extract    s50, v23, #2
    s.add        s51, s49, s48
    s.add        s48, s49, s50
    s.addi       s50, s51, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v23, #4
    v.or         v43, v37, v42
    s.add        s51, s49, s37
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s48, #0]
    p.and        p4, p2, p3
    v.extract    s37, v23, #5
    s.add        s48, s49, s37
    s.addi       s37, s48, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s50, #0]
    p.and        p4, p1, p3
    v.extract    s48, v23, #6
    v.or         v43, v37, v42
    s.add        s50, s49, s48
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s51, #0]
    p.and        p4, p2, p3
    v.extract    s48, v23, #7
    s.add        s51, s49, s48
    s.addi       s48, s51, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v23, #8
    v.or         v43, v37, v42
    s.add        s51, s49, s37
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s50, #0]
    p.and        p4, p2, p3
    v.extract    s37, v23, #9
    s.add        s50, s49, s37
    s.addi       s37, s50, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s48, #0]
    p.and        p4, p1, p3
    v.extract    s48, v23, #10
    v.or         v43, v37, v42
    s.add        s50, s49, s48
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s51, #0]
    p.and        p4, p2, p3
    v.extract    s48, v23, #11
    s.add        s51, s49, s48
    s.addi       s48, s51, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v23, #12
    v.or         v43, v37, v42
    s.add        s51, s49, s37
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s50, #0]
    p.and        p4, p2, p3
    v.extract    s37, v23, #13
    s.add        s50, s49, s37
    s.addi       s37, s50, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s48, #0]
    p.and        p4, p1, p3
    v.extract    s48, v23, #14
    v.or         v43, v37, v42
    s.add        s50, s49, s48
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s51, #0]
    p.and        p4, p2, p3
    v.extract    s48, v23, #15
    s.add        s51, s49, s48
    s.addi       s48, s51, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s50, #0]
    p.and        p4, p2, p3
    s.addi       s37, s24, #64
    v.extract    s49, v19, #1
    s.add        s50, s10, s37
    v.extract    s37, v19, #0
    s.add        s51, s50, s49
    s.add        s49, s50, s37
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s48, #0]
    p.and        p4, p1, p3
    s.addi       s37, s51, #-32
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s48, b18, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a10, v56, v48, s48
    mb.wait      s48
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s49, #0]
    p.and        p4, p2, p3
    v.extract    s49, v19, #3
    v.extract    s51, v19, #2
    s.add        s52, s50, s49
    s.add        s49, s50, s51
    s.addi       s51, s52, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v19, #4
    v.or         v43, v37, v42
    s.add        s52, s50, s37
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s49, #0]
    p.and        p4, p2, p3
    v.extract    s37, v19, #5
    s.add        s49, s50, s37
    s.addi       s37, s49, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s51, #0]
    p.and        p4, p1, p3
    v.extract    s49, v19, #6
    v.or         v43, v37, v42
    s.add        s51, s50, s49
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s52, #0]
    p.and        p4, p2, p3
    v.extract    s49, v19, #7
    s.add        s52, s50, s49
    s.addi       s49, s52, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v19, #8
    v.or         v43, v37, v42
    s.add        s52, s50, s37
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s51, #0]
    p.and        p4, p2, p3
    v.extract    s37, v19, #9
    s.add        s51, s50, s37
    s.addi       s37, s51, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s49, #0]
    p.and        p4, p1, p3
    v.extract    s49, v19, #10
    v.or         v43, v37, v42
    s.add        s51, s50, s49
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s52, #0]
    p.and        p4, p2, p3
    v.extract    s49, v19, #11
    s.add        s52, s50, s49
    s.addi       s49, s52, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v19, #12
    v.or         v43, v37, v42
    s.add        s52, s50, s37
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s51, #0]
    p.and        p4, p2, p3
    v.extract    s37, v19, #13
    s.add        s51, s50, s37
    s.addi       s37, s51, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s49, #0]
    p.and        p4, p1, p3
    v.extract    s49, v19, #14
    v.or         v43, v37, v42
    s.add        s51, s50, s49
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s52, #0]
    p.and        p4, p2, p3
    v.extract    s49, v19, #15
    s.add        s52, s50, s49
    s.addi       s49, s52, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s51, #0]
    p.and        p4, p2, p3
    s.addi       s37, s24, #64
    v.extract    s50, v28, #1
    s.add        s51, s10, s37
    v.extract    s37, v28, #0
    s.add        s52, s51, s50
    s.add        s50, s51, s37
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s49, #0]
    p.and        p4, p1, p3
    s.addi       s37, s52, #-32
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s49, b19, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a11, v56, v48, s49
    mb.wait      s49
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s50, #0]
    p.and        p4, p2, p3
    v.extract    s50, v28, #3
    v.extract    s52, v28, #2
    s.add        s53, s51, s50
    s.add        s50, s51, s52
    s.addi       s52, s53, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v28, #4
    v.or         v43, v37, v42
    s.add        s53, s51, s37
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s50, #0]
    p.and        p4, p2, p3
    v.extract    s37, v28, #5
    s.add        s50, s51, s37
    s.addi       s37, s50, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s52, #0]
    p.and        p4, p1, p3
    v.extract    s50, v28, #6
    v.or         v43, v37, v42
    s.add        s52, s51, s50
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s53, #0]
    p.and        p4, p2, p3
    v.extract    s50, v28, #7
    s.add        s53, s51, s50
    s.addi       s50, s53, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v28, #8
    v.or         v43, v37, v42
    s.add        s53, s51, s37
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s52, #0]
    p.and        p4, p2, p3
    v.extract    s37, v28, #9
    s.add        s52, s51, s37
    s.addi       s37, s52, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s50, #0]
    p.and        p4, p1, p3
    v.extract    s50, v28, #10
    v.or         v43, v37, v42
    s.add        s52, s51, s50
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s53, #0]
    p.and        p4, p2, p3
    v.extract    s50, v28, #11
    s.add        s53, s51, s50
    s.addi       s50, s53, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v28, #12
    v.or         v43, v37, v42
    s.add        s53, s51, s37
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s52, #0]
    p.and        p4, p2, p3
    v.extract    s37, v28, #13
    s.add        s52, s51, s37
    s.addi       s37, s52, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s50, #0]
    p.and        p4, p1, p3
    v.extract    s50, v28, #14
    v.or         v43, v37, v42
    s.add        s52, s51, s50
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s53, #0]
    p.and        p4, p2, p3
    v.extract    s50, v28, #15
    s.add        s53, s51, s50
    s.addi       s50, s53, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s52, #0]
    p.and        p4, p2, p3
    s.addi       s37, s24, #64
    v.extract    s51, v25, #1
    s.add        s52, s10, s37
    v.extract    s37, v25, #0
    s.add        s53, s52, s51
    s.add        s51, s52, s37
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s50, #0]
    p.and        p4, p1, p3
    s.addi       s37, s53, #-32
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s50, b20, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a12, v56, v48, s50
    mb.wait      s50
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s51, #0]
    p.and        p4, p2, p3
    v.extract    s51, v25, #3
    v.extract    s53, v25, #2
    s.add        s54, s52, s51
    s.add        s51, s52, s53
    s.addi       s53, s54, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v25, #4
    v.or         v43, v37, v42
    s.add        s54, s52, s37
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s51, #0]
    p.and        p4, p2, p3
    v.extract    s37, v25, #5
    s.add        s51, s52, s37
    s.addi       s37, s51, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s53, #0]
    p.and        p4, p1, p3
    v.extract    s51, v25, #6
    v.or         v43, v37, v42
    s.add        s53, s52, s51
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s54, #0]
    p.and        p4, p2, p3
    v.extract    s51, v25, #7
    s.add        s54, s52, s51
    s.addi       s51, s54, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v25, #8
    v.or         v43, v37, v42
    s.add        s54, s52, s37
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s53, #0]
    p.and        p4, p2, p3
    v.extract    s37, v25, #9
    s.add        s53, s52, s37
    s.addi       s37, s53, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s51, #0]
    p.and        p4, p1, p3
    v.extract    s51, v25, #10
    v.or         v43, v37, v42
    s.add        s53, s52, s51
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s54, #0]
    p.and        p4, p2, p3
    v.extract    s51, v25, #11
    s.add        s54, s52, s51
    s.addi       s51, s54, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v25, #12
    v.or         v43, v37, v42
    s.add        s54, s52, s37
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s53, #0]
    p.and        p4, p2, p3
    v.extract    s37, v25, #13
    s.add        s53, s52, s37
    s.addi       s37, s53, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s51, #0]
    p.and        p4, p1, p3
    v.extract    s51, v25, #14
    v.or         v43, v37, v42
    s.add        s53, s52, s51
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s54, #0]
    p.and        p4, p2, p3
    v.extract    s51, v25, #15
    s.add        s54, s52, s51
    s.addi       s51, s54, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s53, #0]
    p.and        p4, p2, p3
    s.addi       s37, s24, #64
    v.extract    s52, v30, #1
    s.add        s53, s10, s37
    v.extract    s37, v30, #0
    s.add        s54, s53, s52
    s.add        s52, s53, s37
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s51, #0]
    p.and        p4, p1, p3
    s.addi       s37, s54, #-32
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s51, b21, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a13, v56, v48, s51
    mb.wait      s51
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s52, #0]
    p.and        p4, p2, p3
    v.extract    s52, v30, #3
    v.extract    s54, v30, #2
    s.add        s55, s53, s52
    s.add        s52, s53, s54
    s.addi       s54, s55, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v30, #4
    v.or         v43, v37, v42
    s.add        s55, s53, s37
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s52, #0]
    p.and        p4, p2, p3
    v.extract    s37, v30, #5
    s.add        s52, s53, s37
    s.addi       s37, s52, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s54, #0]
    p.and        p4, p1, p3
    v.extract    s52, v30, #6
    v.or         v43, v37, v42
    s.add        s54, s53, s52
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s55, #0]
    p.and        p4, p2, p3
    v.extract    s52, v30, #7
    s.add        s55, s53, s52
    s.addi       s52, s55, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v30, #8
    v.or         v43, v37, v42
    s.add        s55, s53, s37
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s54, #0]
    p.and        p4, p2, p3
    v.extract    s37, v30, #9
    s.add        s54, s53, s37
    s.addi       s37, s54, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s52, #0]
    p.and        p4, p1, p3
    v.extract    s52, v30, #10
    v.or         v43, v37, v42
    s.add        s54, s53, s52
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s55, #0]
    p.and        p4, p2, p3
    v.extract    s52, v30, #11
    s.add        s55, s53, s52
    s.addi       s52, s55, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v30, #12
    v.or         v43, v37, v42
    s.add        s55, s53, s37
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s54, #0]
    p.and        p4, p2, p3
    v.extract    s37, v30, #13
    s.add        s54, s53, s37
    s.addi       s37, s54, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s52, #0]
    p.and        p4, p1, p3
    v.extract    s52, v30, #14
    v.or         v43, v37, v42
    s.add        s54, s53, s52
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s55, #0]
    p.and        p4, p2, p3
    v.extract    s52, v30, #15
    s.add        s55, s53, s52
    s.addi       s52, s55, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s54, #0]
    p.and        p4, p2, p3
    s.addi       s37, s24, #64
    v.extract    s53, v32, #1
    s.add        s54, s10, s37
    v.extract    s37, v32, #0
    s.add        s55, s54, s53
    s.add        s53, s54, s37
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s52, #0]
    p.and        p4, p1, p3
    s.addi       s37, s55, #-32
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s52, b22, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a14, v56, v48, s52
    mb.wait      s52
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s53, #0]
    p.and        p4, p2, p3
    v.extract    s53, v32, #3
    v.extract    s55, v32, #2
    s.add        s56, s54, s53
    s.add        s53, s54, s55
    s.addi       s55, s56, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v32, #4
    v.or         v43, v37, v42
    s.add        s56, s54, s37
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s53, #0]
    p.and        p4, p2, p3
    v.extract    s37, v32, #5
    s.add        s53, s54, s37
    s.addi       s37, s53, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s55, #0]
    p.and        p4, p1, p3
    v.extract    s53, v32, #6
    v.or         v43, v37, v42
    s.add        s55, s54, s53
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s56, #0]
    p.and        p4, p2, p3
    v.extract    s53, v32, #7
    s.add        s56, s54, s53
    s.addi       s53, s56, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v32, #8
    v.or         v43, v37, v42
    s.add        s56, s54, s37
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s55, #0]
    p.and        p4, p2, p3
    v.extract    s37, v32, #9
    s.add        s55, s54, s37
    s.addi       s37, s55, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s53, #0]
    p.and        p4, p1, p3
    v.extract    s53, v32, #10
    v.or         v43, v37, v42
    s.add        s55, s54, s53
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s56, #0]
    p.and        p4, p2, p3
    v.extract    s53, v32, #11
    s.add        s56, s54, s53
    s.addi       s53, s56, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v32, #12
    v.or         v43, v37, v42
    s.add        s56, s54, s37
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s55, #0]
    p.and        p4, p2, p3
    v.extract    s37, v32, #13
    s.add        s55, s54, s37
    s.addi       s37, s55, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s53, #0]
    p.and        p4, p1, p3
    v.extract    s53, v32, #14
    v.or         v43, v37, v42
    s.add        s55, s54, s53
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s56, #0]
    p.and        p4, p2, p3
    v.extract    s53, v32, #15
    s.add        s56, s54, s53
    s.addi       s53, s56, #-32
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v42, [s37, #0]
    p.and        p4, p1, p3
    p.and        p5, p2, p3
    v.or         v43, v37, v42
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v27, #0
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s55, #0]
    v.splat      v42, s37
    s.addi       s37, s30, #6144
    s.addi       s54, s30, #9728                 // 512 bytes of repack scratch
    vf.max.ieee  v43, v42, v13
    v.rcp.approx v42, v43                        // ISA 8.8: <= 2**-22 relative
    v.movi       v44, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v44, [s53, #0]
    v.or         v45, v37, v44
    vf.fms       v37, v43, v42, v21
    v.and        v44, v45, v39
    v.mov        v63, v44                        // hand off through the shared window (sec 7.3)
    mb.arm       s53, b23, #0, #1                // 0 arrival(s), 1 operation(s)
    vf.fms       v39, v42, v37, v42
    m.mma.async.k32.e4m3 a15, v56, v48, s53
    mb.wait      s53
    v.ld.w       v37, [s37, #0]
    vf.neg       v44, v39                        // Newton step: r0*(2 - x*r0)
    s.addi       s37, s54, #0
    s.addi       s55, s30, #6208
    vf.cmp.o     p3, v44, v44
    v.extract    s56, v27, #1
    @p3 v.sel        v39, v44, v42
    v.splat      v42, s56
    vf.mul       v44, v37, v39                   // a/y: faithful quotient
    vf.max.ieee  v45, v42, v13
    vf.fms       v42, v44, v43, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v39, v44
    vf.neg       v39, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v42, v39, v44
    v.lshr       v39, v42, v40
    vf.cvt.f32.e4m3 v43, v42
    v.and        v42, v39, v41
    v.or         v39, v43, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v39
    vf.fms       v39, v45, v37, v21
    vf.fms       v42, v37, v39, v37
    vf.neg       v39, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s55, #0]
    s.addi       s37, s54, #1
    s.addi       s55, s30, #6272
    vf.cmp.o     p3, v39, v39
    v.extract    s56, v27, #2
    @p3 v.sel        v43, v39, v37
    v.splat      v37, s56
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s55, #0]
    s.addi       s37, s54, #2
    s.addi       s55, s30, #6336
    vf.cmp.o     p3, v37, v37
    v.extract    s56, v27, #3
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s56
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s55, #0]
    s.addi       s37, s54, #3
    s.addi       s55, s30, #6400
    vf.cmp.o     p3, v37, v37
    v.extract    s56, v27, #4
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s56
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s55, #0]
    s.addi       s37, s54, #4
    s.addi       s55, s30, #6464
    vf.cmp.o     p3, v37, v37
    v.extract    s56, v27, #5
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s56
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s55, #0]
    s.addi       s37, s54, #5
    s.addi       s55, s30, #6528
    vf.cmp.o     p3, v37, v37
    v.extract    s56, v27, #6
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s56
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s55, #0]
    s.addi       s37, s54, #6
    s.addi       s55, s30, #6592
    vf.cmp.o     p3, v37, v37
    v.extract    s56, v27, #7
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s56
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s55, #0]
    s.addi       s37, s54, #7
    s.addi       s55, s30, #6656
    vf.cmp.o     p3, v37, v37
    v.extract    s56, v27, #8
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s56
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s55, #0]
    s.addi       s37, s54, #8
    s.addi       s55, s30, #6720
    vf.cmp.o     p3, v37, v37
    v.extract    s56, v27, #9
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s56
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s55, #0]
    s.addi       s37, s54, #9
    s.addi       s55, s30, #6784
    vf.cmp.o     p3, v37, v37
    v.extract    s56, v27, #10
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s56
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s55, #0]
    s.addi       s37, s54, #10
    s.addi       s55, s30, #6848
    vf.cmp.o     p3, v37, v37
    v.extract    s56, v27, #11
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s56
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s55, #0]
    s.addi       s37, s54, #11
    s.addi       s55, s30, #6912
    vf.cmp.o     p3, v37, v37
    v.extract    s56, v27, #12
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s56
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s55, #0]
    s.addi       s37, s54, #12
    s.addi       s55, s30, #6976
    vf.cmp.o     p3, v37, v37
    v.extract    s56, v27, #13
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s56
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s55, #0]
    s.addi       s37, s54, #13
    s.addi       s55, s30, #7040
    vf.cmp.o     p3, v37, v37
    v.extract    s56, v27, #14
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s56
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s55, #0]
    s.addi       s37, s54, #14
    s.addi       s55, s30, #7104
    vf.cmp.o     p3, v37, v37
    v.extract    s56, v27, #15
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s56
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s55, #0]
    s.addi       s37, s54, #15
    s.addi       s55, s30, #7168
    vf.cmp.o     p3, v37, v37
    v.extract    s56, v27, #0
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s56
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s55, #0]
    s.addi       s37, s54, #256
    s.addi       s55, s30, #7232
    vf.cmp.o     p3, v37, v37
    v.extract    s56, v27, #1
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s56
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s55, #0]
    s.addi       s37, s54, #257
    s.addi       s55, s30, #7296
    vf.cmp.o     p3, v37, v37
    v.extract    s56, v27, #2
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s56
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s55, #0]
    s.addi       s37, s54, #258
    s.addi       s55, s30, #7360
    vf.cmp.o     p3, v37, v37
    v.extract    s56, v27, #3
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s56
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s55, #0]
    s.addi       s37, s54, #259
    s.addi       s55, s30, #7424
    vf.cmp.o     p3, v37, v37
    v.extract    s56, v27, #4
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s56
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s55, #0]
    s.addi       s37, s54, #260
    s.addi       s55, s30, #7488
    vf.cmp.o     p3, v37, v37
    v.extract    s56, v27, #5
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s56
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s55, #0]
    s.addi       s37, s54, #261
    s.addi       s55, s30, #7552
    vf.cmp.o     p3, v37, v37
    v.extract    s56, v27, #6
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s56
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s55, #0]
    s.addi       s37, s54, #262
    s.addi       s55, s30, #7616
    vf.cmp.o     p3, v37, v37
    v.extract    s56, v27, #7
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s56
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s55, #0]
    s.addi       s37, s54, #263
    s.addi       s55, s30, #7680
    vf.cmp.o     p3, v37, v37
    v.extract    s56, v27, #8
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s56
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s55, #0]
    s.addi       s37, s54, #264
    s.addi       s55, s30, #7744
    vf.cmp.o     p3, v37, v37
    v.extract    s56, v27, #9
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s56
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s55, #0]
    s.addi       s37, s54, #265
    s.addi       s55, s30, #7808
    vf.cmp.o     p3, v37, v37
    v.extract    s56, v27, #10
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s56
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s55, #0]
    s.addi       s37, s54, #266
    s.addi       s55, s30, #7872
    vf.cmp.o     p3, v37, v37
    v.extract    s56, v27, #11
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s56
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s55, #0]
    s.addi       s37, s54, #267
    s.addi       s55, s30, #7936
    vf.cmp.o     p3, v37, v37
    v.extract    s56, v27, #12
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s56
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s55, #0]
    s.addi       s37, s54, #268
    s.addi       s55, s30, #8000
    vf.cmp.o     p3, v37, v37
    v.extract    s56, v27, #13
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s56
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v37, v42, v44, v39
    v.rcp.approx v39, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v37, v43, v42
    vf.neg       v37, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v42
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v42, v43
    v.and        v43, v37, v41
    v.or         v37, v42, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v45, v39, v21
    vf.fms       v42, v39, v37, v39
    vf.neg       v37, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v42, [s55, #0]
    s.addi       s37, s54, #269
    s.addi       s55, s30, #8064
    vf.cmp.o     p3, v37, v37
    v.extract    s56, v27, #14
    @p3 v.sel        v43, v37, v39
    v.splat      v37, s56
    vf.mul       v39, v42, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v39, v45, v42
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v39
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v39
    v.lshr       v37, v43, v40
    vf.cvt.f32.e4m3 v39, v43
    v.and        v43, v37, v41
    v.or         v37, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v37
    vf.fms       v37, v44, v42, v21
    vf.fms       v39, v42, v37, v42
    vf.neg       v37, v39                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v39, [s55, #0]
    s.addi       s37, s54, #270
    s.addi       s55, s30, #8128
    vf.cmp.o     p3, v37, v37
    v.extract    s56, v27, #15
    @p3 v.sel        v43, v37, v42
    v.splat      v37, s56
    vf.mul       v42, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v37, v13
    vf.fms       v13, v42, v44, v39
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v39, v13, v43, v42
    vf.neg       v13, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v13, v13
    @p3 v.sel        v39, v13, v42
    v.lshr       v13, v39, v40
    vf.cvt.f32.e4m3 v42, v39
    v.and        v39, v13, v41
    v.or         v13, v42, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s37, v18], v13
    vf.fms       v13, v45, v37, v21
    vf.fms       v21, v37, v13, v37
    vf.neg       v13, v21                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v21, [s55, #0]
    s.addi       s37, s54, #271
    vf.cmp.o     p3, v13, v13
    @p3 v.sel        v39, v13, v37
    vf.mul       v13, v21, v39                   // a/y: faithful quotient
    s.addi       s55, s54, #64
    vf.fms       v37, v13, v45, v21
    vf.fms       v21, v37, v39, v13
    vf.neg       v37, v21                        // a/y: one correction to the IEEE quotient
    s.addi       s56, s54, #128
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v21, v37, v13
    v.lshr       v13, v21, v40
    vf.cvt.f32.e4m3 v37, v21
    s.addi       s57, s54, #192
    v.and        v21, v13, v41
    v.or         v13, v37, v21                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s58, s54, #256
    v.st.scatter.b [s37, v18], v13
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s37, s54, #320
    v.ld.w       v13, [s54, #0]
    v.mov        v48, v13                        // hand off through the shared window (sec 7.3)
    v.ld.w       v13, [s55, #0]
    s.addi       s55, s54, #384
    v.mov        v49, v13                        // hand off through the shared window (sec 7.3)
    v.ld.w       v13, [s56, #0]
    s.addi       s56, s54, #448
    v.mov        v50, v13                        // hand off through the shared window (sec 7.3)
    v.ld.w       v13, [s57, #0]
    s.addi       s54, s28, #-96
    v.splat      v21, s54
    v.sub        v37, v21, v33
    v.mov        v51, v13                        // hand off through the shared window (sec 7.3)
    v.ld.w       v13, [s58, #0]
    v.movi       v21, #0
    v.movi       v33, #0
    v.cmp.gt     p3, v37, v21
    v.mov        v52, v13                        // hand off through the shared window (sec 7.3)
    v.ld.w       v13, [s37, #0]
    v.max.s      v21, v37, v33
    v.movi       v33, #4
    v.min.s      v37, v21, v33
    v.mov        v53, v13                        // hand off through the shared window (sec 7.3)
    v.ld.w       v13, [s55, #0]
    v.movi       v21, #3
    v.movi       v33, #1
    v.shl        v39, v37, v21
    v.mov        v54, v13                        // hand off through the shared window (sec 7.3)
    v.ld.w       v13, [s56, #0]
    v.shl        v21, v33, v39
    v.movi       v33, #1
    v.sub        v39, v21, v33
    v.mov        v55, v13                        // hand off through the shared window (sec 7.3)
    s.addi       s28, s24, #96
    v.extract    s37, v24, #1
    s.add        s54, s10, s28
    v.extract    s28, v24, #0
    s.add        s55, s54, s37
    s.add        s37, s54, s28
    p.and        p4, p1, p3
    s.addi       s28, s55, #-32
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s37, #0]
    p.and        p4, p2, p3
    v.movi       v21, #4
    v.movi       v33, #-1
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s28, #0]
    v.cmp.ge     p4, v37, v21
    @p4 v.sel        v21, v33, v39
    v.extract    s28, v24, #3
    v.extract    s37, v24, #2
    s.add        s55, s54, s28
    s.add        s28, s54, s37
    p.and        p4, p1, p3
    s.addi       s37, s55, #-32
    v.extract    s55, v24, #4
    v.or         v33, v13, v40
    s.add        s56, s54, s55
    v.and        v13, v33, v21
    v.mov        v56, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s28, #0]
    p.and        p4, p2, p3
    v.extract    s28, v24, #5
    s.add        s55, s54, s28
    s.addi       s28, s55, #-32
    v.movi       v33, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v33, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v24, #6
    v.or         v37, v13, v33
    s.add        s55, s54, s37
    v.and        v13, v37, v21
    v.mov        v57, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s56, #0]
    p.and        p4, p2, p3
    v.extract    s37, v24, #7
    s.add        s56, s54, s37
    s.addi       s37, s56, #-32
    v.movi       v33, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v33, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v24, #8
    v.or         v37, v13, v33
    s.add        s56, s54, s28
    v.and        v13, v37, v21
    v.mov        v58, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s55, #0]
    p.and        p4, p2, p3
    v.extract    s28, v24, #9
    s.add        s55, s54, s28
    s.addi       s28, s55, #-32
    v.movi       v33, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v33, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v24, #10
    v.or         v37, v13, v33
    s.add        s55, s54, s37
    v.and        v13, v37, v21
    v.mov        v59, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s56, #0]
    p.and        p4, p2, p3
    v.extract    s37, v24, #11
    s.add        s56, s54, s37
    s.addi       s37, s56, #-32
    v.movi       v33, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v33, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v24, #12
    v.or         v37, v13, v33
    s.add        s56, s54, s28
    v.and        v13, v37, v21
    v.mov        v60, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s55, #0]
    p.and        p4, p2, p3
    v.extract    s28, v24, #13
    s.add        s55, s54, s28
    s.addi       s28, s55, #-32
    v.movi       v33, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v33, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v24, #14
    v.or         v37, v13, v33
    s.add        s55, s54, s37
    v.and        v13, v37, v21
    v.mov        v61, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s56, #0]
    p.and        p4, p2, p3
    v.extract    s37, v24, #15
    s.add        s56, s54, s37
    s.addi       s37, s56, #-32
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s28, #0]
    p.and        p4, p1, p3
    v.or         v33, v13, v24
    v.and        v13, v33, v21
    v.mov        v62, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s55, #0]
    p.and        p4, p2, p3
    s.addi       s28, s24, #96
    v.extract    s54, v22, #1
    s.add        s55, s10, s28
    v.extract    s28, v22, #0
    s.add        s56, s55, s54
    s.add        s54, s55, s28
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s37, #0]
    p.and        p4, p1, p3
    s.addi       s28, s56, #-32
    v.or         v33, v13, v24
    v.and        v13, v33, v21
    v.mov        v63, v13                        // hand off through the shared window (sec 7.3)
    mb.arm       s37, b24, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a8, v56, v48, s37
    mb.wait      s37
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s54, #0]
    p.and        p4, p2, p3
    v.extract    s54, v22, #3
    v.extract    s56, v22, #2
    s.add        s57, s55, s54
    s.add        s54, s55, s56
    s.addi       s56, s57, #-32
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v22, #4
    v.or         v33, v13, v24
    s.add        s57, s55, s28
    v.and        v13, v33, v21
    v.mov        v56, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s54, #0]
    p.and        p4, p2, p3
    v.extract    s28, v22, #5
    s.add        s54, s55, s28
    s.addi       s28, s54, #-32
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s56, #0]
    p.and        p4, p1, p3
    v.extract    s54, v22, #6
    v.or         v33, v13, v24
    s.add        s56, s55, s54
    v.and        v13, v33, v21
    v.mov        v57, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s57, #0]
    p.and        p4, p2, p3
    v.extract    s54, v22, #7
    s.add        s57, s55, s54
    s.addi       s54, s57, #-32
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v22, #8
    v.or         v33, v13, v24
    s.add        s57, s55, s28
    v.and        v13, v33, v21
    v.mov        v58, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s56, #0]
    p.and        p4, p2, p3
    v.extract    s28, v22, #9
    s.add        s56, s55, s28
    s.addi       s28, s56, #-32
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s54, #0]
    p.and        p4, p1, p3
    v.extract    s54, v22, #10
    v.or         v33, v13, v24
    s.add        s56, s55, s54
    v.and        v13, v33, v21
    v.mov        v59, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s57, #0]
    p.and        p4, p2, p3
    v.extract    s54, v22, #11
    s.add        s57, s55, s54
    s.addi       s54, s57, #-32
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v22, #12
    v.or         v33, v13, v24
    s.add        s57, s55, s28
    v.and        v13, v33, v21
    v.mov        v60, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s56, #0]
    p.and        p4, p2, p3
    v.extract    s28, v22, #13
    s.add        s56, s55, s28
    s.addi       s28, s56, #-32
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s54, #0]
    p.and        p4, p1, p3
    v.extract    s54, v22, #14
    v.or         v33, v13, v24
    s.add        s56, s55, s54
    v.and        v13, v33, v21
    v.mov        v61, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s57, #0]
    p.and        p4, p2, p3
    v.extract    s54, v22, #15
    s.add        s57, s55, s54
    s.addi       s54, s57, #-32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s28, #0]
    p.and        p4, p1, p3
    v.or         v24, v13, v22
    v.and        v13, v24, v21
    v.mov        v62, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s56, #0]
    p.and        p4, p2, p3
    s.addi       s28, s24, #96
    v.extract    s55, v23, #1
    s.add        s56, s10, s28
    v.extract    s28, v23, #0
    s.add        s57, s56, s55
    s.add        s55, s56, s28
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s54, #0]
    p.and        p4, p1, p3
    s.addi       s28, s57, #-32
    v.or         v24, v13, v22
    v.and        v13, v24, v21
    v.mov        v63, v13                        // hand off through the shared window (sec 7.3)
    mb.arm       s54, b25, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a9, v56, v48, s54
    mb.wait      s54
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s55, #0]
    p.and        p4, p2, p3
    v.extract    s55, v23, #3
    v.extract    s57, v23, #2
    s.add        s58, s56, s55
    s.add        s55, s56, s57
    s.addi       s57, s58, #-32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v23, #4
    v.or         v24, v13, v22
    s.add        s58, s56, s28
    v.and        v13, v24, v21
    v.mov        v56, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s55, #0]
    p.and        p4, p2, p3
    v.extract    s28, v23, #5
    s.add        s55, s56, s28
    s.addi       s28, s55, #-32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s57, #0]
    p.and        p4, p1, p3
    v.extract    s55, v23, #6
    v.or         v24, v13, v22
    s.add        s57, s56, s55
    v.and        v13, v24, v21
    v.mov        v57, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s58, #0]
    p.and        p4, p2, p3
    v.extract    s55, v23, #7
    s.add        s58, s56, s55
    s.addi       s55, s58, #-32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v23, #8
    v.or         v24, v13, v22
    s.add        s58, s56, s28
    v.and        v13, v24, v21
    v.mov        v58, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s57, #0]
    p.and        p4, p2, p3
    v.extract    s28, v23, #9
    s.add        s57, s56, s28
    s.addi       s28, s57, #-32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s55, #0]
    p.and        p4, p1, p3
    v.extract    s55, v23, #10
    v.or         v24, v13, v22
    s.add        s57, s56, s55
    v.and        v13, v24, v21
    v.mov        v59, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s58, #0]
    p.and        p4, p2, p3
    v.extract    s55, v23, #11
    s.add        s58, s56, s55
    s.addi       s55, s58, #-32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v23, #12
    v.or         v24, v13, v22
    s.add        s58, s56, s28
    v.and        v13, v24, v21
    v.mov        v60, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s57, #0]
    p.and        p4, p2, p3
    v.extract    s28, v23, #13
    s.add        s57, s56, s28
    s.addi       s28, s57, #-32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s55, #0]
    p.and        p4, p1, p3
    v.extract    s55, v23, #14
    v.or         v24, v13, v22
    s.add        s57, s56, s55
    v.and        v13, v24, v21
    v.mov        v61, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s58, #0]
    p.and        p4, p2, p3
    v.extract    s55, v23, #15
    s.add        s58, s56, s55
    s.addi       s55, s58, #-32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s28, #0]
    p.and        p4, p1, p3
    v.or         v23, v13, v22
    v.and        v13, v23, v21
    v.mov        v62, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s57, #0]
    p.and        p4, p2, p3
    s.addi       s28, s24, #96
    v.extract    s56, v19, #1
    s.add        s57, s10, s28
    v.extract    s28, v19, #0
    s.add        s58, s57, s56
    s.add        s56, s57, s28
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s55, #0]
    p.and        p4, p1, p3
    s.addi       s28, s58, #-32
    v.or         v23, v13, v22
    v.and        v13, v23, v21
    v.mov        v63, v13                        // hand off through the shared window (sec 7.3)
    mb.arm       s55, b26, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a10, v56, v48, s55
    mb.wait      s55
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s56, #0]
    p.and        p4, p2, p3
    v.extract    s56, v19, #3
    v.extract    s58, v19, #2
    s.add        s59, s57, s56
    s.add        s56, s57, s58
    s.addi       s58, s59, #-32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v19, #4
    v.or         v23, v13, v22
    s.add        s59, s57, s28
    v.and        v13, v23, v21
    v.mov        v56, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s56, #0]
    p.and        p4, p2, p3
    v.extract    s28, v19, #5
    s.add        s56, s57, s28
    s.addi       s28, s56, #-32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s58, #0]
    p.and        p4, p1, p3
    v.extract    s56, v19, #6
    v.or         v23, v13, v22
    s.add        s58, s57, s56
    v.and        v13, v23, v21
    v.mov        v57, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s59, #0]
    p.and        p4, p2, p3
    v.extract    s56, v19, #7
    s.add        s59, s57, s56
    s.addi       s56, s59, #-32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v19, #8
    v.or         v23, v13, v22
    s.add        s59, s57, s28
    v.and        v13, v23, v21
    v.mov        v58, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s58, #0]
    p.and        p4, p2, p3
    v.extract    s28, v19, #9
    s.add        s58, s57, s28
    s.addi       s28, s58, #-32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s56, #0]
    p.and        p4, p1, p3
    v.extract    s56, v19, #10
    v.or         v23, v13, v22
    s.add        s58, s57, s56
    v.and        v13, v23, v21
    v.mov        v59, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s59, #0]
    p.and        p4, p2, p3
    v.extract    s56, v19, #11
    s.add        s59, s57, s56
    s.addi       s56, s59, #-32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v19, #12
    v.or         v23, v13, v22
    s.add        s59, s57, s28
    v.and        v13, v23, v21
    v.mov        v60, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s58, #0]
    p.and        p4, p2, p3
    v.extract    s28, v19, #13
    s.add        s58, s57, s28
    s.addi       s28, s58, #-32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s56, #0]
    p.and        p4, p1, p3
    v.extract    s56, v19, #14
    v.or         v23, v13, v22
    s.add        s58, s57, s56
    v.and        v13, v23, v21
    v.mov        v61, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s59, #0]
    p.and        p4, p2, p3
    v.extract    s56, v19, #15
    s.add        s59, s57, s56
    s.addi       s56, s59, #-32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s28, #0]
    p.and        p4, p1, p3
    v.or         v22, v13, v19
    v.and        v13, v22, v21
    v.mov        v62, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s58, #0]
    p.and        p4, p2, p3
    s.addi       s28, s24, #96
    v.extract    s57, v28, #1
    s.add        s58, s10, s28
    v.extract    s28, v28, #0
    s.add        s59, s58, s57
    s.add        s57, s58, s28
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s56, #0]
    p.and        p4, p1, p3
    s.addi       s28, s59, #-32
    v.or         v22, v13, v19
    v.and        v13, v22, v21
    v.mov        v63, v13                        // hand off through the shared window (sec 7.3)
    mb.arm       s56, b27, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a11, v56, v48, s56
    mb.wait      s56
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s57, #0]
    p.and        p4, p2, p3
    v.extract    s57, v28, #3
    v.extract    s59, v28, #2
    s.add        s60, s58, s57
    s.add        s57, s58, s59
    s.addi       s59, s60, #-32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v28, #4
    v.or         v22, v13, v19
    s.add        s60, s58, s28
    v.and        v13, v22, v21
    v.mov        v56, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s57, #0]
    p.and        p4, p2, p3
    v.extract    s28, v28, #5
    s.add        s57, s58, s28
    s.addi       s28, s57, #-32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s59, #0]
    p.and        p4, p1, p3
    v.extract    s57, v28, #6
    v.or         v22, v13, v19
    s.add        s59, s58, s57
    v.and        v13, v22, v21
    v.mov        v57, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s60, #0]
    p.and        p4, p2, p3
    v.extract    s57, v28, #7
    s.add        s60, s58, s57
    s.addi       s57, s60, #-32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v28, #8
    v.or         v22, v13, v19
    s.add        s60, s58, s28
    v.and        v13, v22, v21
    v.mov        v58, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s59, #0]
    p.and        p4, p2, p3
    v.extract    s28, v28, #9
    s.add        s59, s58, s28
    s.addi       s28, s59, #-32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s57, #0]
    p.and        p4, p1, p3
    v.extract    s57, v28, #10
    v.or         v22, v13, v19
    s.add        s59, s58, s57
    v.and        v13, v22, v21
    v.mov        v59, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s60, #0]
    p.and        p4, p2, p3
    v.extract    s57, v28, #11
    s.add        s60, s58, s57
    s.addi       s57, s60, #-32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v28, #12
    v.or         v22, v13, v19
    s.add        s60, s58, s28
    v.and        v13, v22, v21
    v.mov        v60, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s59, #0]
    p.and        p4, p2, p3
    v.extract    s28, v28, #13
    s.add        s59, s58, s28
    s.addi       s28, s59, #-32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s57, #0]
    p.and        p4, p1, p3
    v.extract    s57, v28, #14
    v.or         v22, v13, v19
    s.add        s59, s58, s57
    v.and        v13, v22, v21
    v.mov        v61, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s60, #0]
    p.and        p4, p2, p3
    v.extract    s57, v28, #15
    s.add        s60, s58, s57
    s.addi       s57, s60, #-32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s28, #0]
    p.and        p4, p1, p3
    v.or         v22, v13, v19
    v.and        v13, v22, v21
    v.mov        v62, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s59, #0]
    p.and        p4, p2, p3
    s.addi       s28, s24, #96
    v.extract    s58, v25, #1
    s.add        s59, s10, s28
    v.extract    s28, v25, #0
    s.add        s60, s59, s58
    s.add        s58, s59, s28
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s57, #0]
    p.and        p4, p1, p3
    s.addi       s28, s60, #-32
    v.or         v22, v13, v19
    v.and        v13, v22, v21
    v.mov        v63, v13                        // hand off through the shared window (sec 7.3)
    mb.arm       s57, b28, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a12, v56, v48, s57
    mb.wait      s57
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s58, #0]
    p.and        p4, p2, p3
    v.extract    s58, v25, #3
    v.extract    s60, v25, #2
    s.add        s11, s59, s58
    s.add        s29, s59, s60
    s.addi       s31, s11, #-32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s11, v25, #4
    v.or         v22, v13, v19
    s.add        s28, s59, s11
    v.and        v13, v22, v21
    v.mov        v56, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s29, #0]
    p.and        p4, p2, p3
    v.extract    s11, v25, #5
    s.add        s29, s59, s11
    s.addi       s11, s29, #-32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s31, #0]
    p.and        p4, p1, p3
    v.extract    s29, v25, #6
    v.or         v22, v13, v19
    s.add        s31, s59, s29
    v.and        v13, v22, v21
    v.mov        v57, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s28, #0]
    p.and        p4, p2, p3
    v.extract    s28, v25, #7
    s.add        s29, s59, s28
    s.addi       s28, s29, #-32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s11, #0]
    p.and        p4, p1, p3
    v.extract    s11, v25, #8
    v.or         v22, v13, v19
    s.add        s29, s59, s11
    v.and        v13, v22, v21
    v.mov        v58, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s31, #0]
    p.and        p4, p2, p3
    v.extract    s11, v25, #9
    s.add        s31, s59, s11
    s.addi       s11, s31, #-32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v25, #10
    v.or         v22, v13, v19
    s.add        s31, s59, s28
    v.and        v13, v22, v21
    v.mov        v59, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s29, #0]
    p.and        p4, p2, p3
    v.extract    s28, v25, #11
    s.add        s29, s59, s28
    s.addi       s28, s29, #-32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s11, #0]
    p.and        p4, p1, p3
    v.extract    s11, v25, #12
    v.or         v22, v13, v19
    s.add        s29, s59, s11
    v.and        v13, v22, v21
    v.mov        v60, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s31, #0]
    p.and        p4, p2, p3
    v.extract    s11, v25, #13
    s.add        s31, s59, s11
    s.addi       s11, s31, #-32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v25, #14
    v.or         v22, v13, v19
    s.add        s31, s59, s28
    v.and        v13, v22, v21
    v.mov        v61, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s29, #0]
    p.and        p4, p2, p3
    v.extract    s28, v25, #15
    s.add        s29, s59, s28
    s.addi       s28, s29, #-32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s11, #0]
    p.and        p4, p1, p3
    v.or         v22, v13, v19
    v.and        v13, v22, v21
    v.mov        v62, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s31, #0]
    p.and        p4, p2, p3
    s.addi       s11, s24, #96
    v.extract    s29, v30, #1
    s.add        s31, s10, s11
    v.extract    s11, v30, #0
    s.add        s32, s31, s29
    s.add        s29, s31, s11
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s28, #0]
    p.and        p4, p1, p3
    s.addi       s11, s32, #-32
    v.or         v22, v13, v19
    v.and        v13, v22, v21
    v.mov        v63, v13                        // hand off through the shared window (sec 7.3)
    mb.arm       s28, b29, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a13, v56, v48, s28
    mb.wait      s28
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s29, #0]
    p.and        p4, p2, p3
    v.extract    s29, v30, #3
    v.extract    s32, v30, #2
    s.add        s33, s31, s29
    s.add        s29, s31, s32
    s.addi       s32, s33, #-32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s11, #0]
    p.and        p4, p1, p3
    v.extract    s11, v30, #4
    v.or         v22, v13, v19
    s.add        s33, s31, s11
    v.and        v13, v22, v21
    v.mov        v56, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s29, #0]
    p.and        p4, p2, p3
    v.extract    s11, v30, #5
    s.add        s29, s31, s11
    s.addi       s11, s29, #-32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s32, #0]
    p.and        p4, p1, p3
    v.extract    s29, v30, #6
    v.or         v22, v13, v19
    s.add        s32, s31, s29
    v.and        v13, v22, v21
    v.mov        v57, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s33, #0]
    p.and        p4, p2, p3
    v.extract    s29, v30, #7
    s.add        s33, s31, s29
    s.addi       s29, s33, #-32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s11, #0]
    p.and        p4, p1, p3
    v.extract    s11, v30, #8
    v.or         v22, v13, v19
    s.add        s33, s31, s11
    v.and        v13, v22, v21
    v.mov        v58, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s32, #0]
    p.and        p4, p2, p3
    v.extract    s11, v30, #9
    s.add        s32, s31, s11
    s.addi       s11, s32, #-32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s29, #0]
    p.and        p4, p1, p3
    v.extract    s29, v30, #10
    v.or         v22, v13, v19
    s.add        s32, s31, s29
    v.and        v13, v22, v21
    v.mov        v59, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s33, #0]
    p.and        p4, p2, p3
    v.extract    s29, v30, #11
    s.add        s33, s31, s29
    s.addi       s29, s33, #-32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s11, #0]
    p.and        p4, p1, p3
    v.extract    s11, v30, #12
    v.or         v22, v13, v19
    s.add        s33, s31, s11
    v.and        v13, v22, v21
    v.mov        v60, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s32, #0]
    p.and        p4, p2, p3
    v.extract    s11, v30, #13
    s.add        s32, s31, s11
    s.addi       s11, s32, #-32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s29, #0]
    p.and        p4, p1, p3
    v.extract    s29, v30, #14
    v.or         v22, v13, v19
    s.add        s32, s31, s29
    v.and        v13, v22, v21
    v.mov        v61, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s33, #0]
    p.and        p4, p2, p3
    v.extract    s29, v30, #15
    s.add        s33, s31, s29
    s.addi       s29, s33, #-32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s11, #0]
    p.and        p4, p1, p3
    v.or         v22, v13, v19
    v.and        v13, v22, v21
    v.mov        v62, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s32, #0]
    p.and        p4, p2, p3
    s.addi       s11, s24, #96
    v.extract    s31, v32, #1
    s.add        s32, s10, s11
    v.extract    s11, v32, #0
    s.add        s33, s32, s31
    s.add        s31, s32, s11
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s29, #0]
    p.and        p4, p1, p3
    s.addi       s11, s33, #-32
    v.or         v22, v13, v19
    v.and        v13, v22, v21
    v.mov        v63, v13                        // hand off through the shared window (sec 7.3)
    mb.arm       s29, b30, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a14, v56, v48, s29
    mb.wait      s29
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s31, #0]
    p.and        p4, p2, p3
    v.extract    s31, v32, #3
    v.extract    s33, v32, #2
    s.add        s34, s32, s31
    s.add        s31, s32, s33
    s.addi       s33, s34, #-32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s11, #0]
    p.and        p4, p1, p3
    v.extract    s11, v32, #4
    v.or         v22, v13, v19
    s.add        s34, s32, s11
    v.and        v13, v22, v21
    v.mov        v56, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s31, #0]
    p.and        p4, p2, p3
    v.extract    s11, v32, #5
    s.add        s31, s32, s11
    s.addi       s11, s31, #-32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s33, #0]
    p.and        p4, p1, p3
    v.extract    s31, v32, #6
    v.or         v22, v13, v19
    s.add        s33, s32, s31
    v.and        v13, v22, v21
    v.mov        v57, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s34, #0]
    p.and        p4, p2, p3
    v.extract    s31, v32, #7
    s.add        s34, s32, s31
    s.addi       s31, s34, #-32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s11, #0]
    p.and        p4, p1, p3
    v.extract    s11, v32, #8
    v.or         v22, v13, v19
    s.add        s34, s32, s11
    v.and        v13, v22, v21
    v.mov        v58, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s33, #0]
    p.and        p4, p2, p3
    v.extract    s11, v32, #9
    s.add        s33, s32, s11
    s.addi       s11, s33, #-32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s31, #0]
    p.and        p4, p1, p3
    v.extract    s31, v32, #10
    v.or         v22, v13, v19
    s.add        s33, s32, s31
    v.and        v13, v22, v21
    v.mov        v59, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s34, #0]
    p.and        p4, p2, p3
    v.extract    s31, v32, #11
    s.add        s34, s32, s31
    s.addi       s31, s34, #-32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s11, #0]
    p.and        p4, p1, p3
    v.extract    s11, v32, #12
    v.or         v22, v13, v19
    s.add        s34, s32, s11
    v.and        v13, v22, v21
    v.mov        v60, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s33, #0]
    p.and        p4, p2, p3
    v.extract    s11, v32, #13
    s.add        s33, s32, s11
    s.addi       s11, s33, #-32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s31, #0]
    p.and        p4, p1, p3
    v.extract    s31, v32, #14
    v.or         v22, v13, v19
    s.add        s33, s32, s31
    v.and        v13, v22, v21
    p.and        p5, p1, p3
    v.mov        v61, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s34, #0]
    p.and        p1, p2, p3
    v.extract    s31, v32, #15
    p.and        p4, p2, p3
    s.add        s34, s32, s31
    s.addi       s31, s34, #-32
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v19, [s11, #0]
    v.or         v22, v13, v19
    v.and        v13, v22, v21
    v.mov        v62, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v13, [s33, #0]
    s.movz       s11, #0
    s.addi       s32, s30, #10240
    s.movz       s33, #1
    s.addi       s34, s32, #4
    s.addi       s35, s32, #8
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s31, #0]
    s.movz       s31, #2
    v.or         v22, v13, v19
    v.and        v13, v22, v21
    v.mov        v63, v13                        // hand off through the shared window (sec 7.3)
    mb.arm       s36, b31, #0, #1                // 0 arrival(s), 1 operation(s)
    s.movz       s37, #3
    s.addi       s38, s32, #12
    m.mma.async.k32.e4m3 a15, v56, v48, s36
    mb.wait      s36
    a.vread      v13, a8, s11
    s.movz       s11, #4
    s.addi       s39, s32, #16
    v.st.scatter.w [s32, v18], v13
    a.vread      v13, a8, s33
    s.movz       s33, #5
    s.addi       s40, s32, #20
    v.st.scatter.w [s34, v18], v13
    a.vread      v13, a8, s31
    s.movz       s31, #6
    s.addi       s34, s32, #24
    v.st.scatter.w [s35, v18], v13
    a.vread      v13, a8, s37
    s.movz       s35, #7
    s.addi       s37, s32, #28
    v.st.scatter.w [s38, v18], v13
    a.vread      v13, a8, s11
    s.movz       s11, #8
    s.addi       s38, s32, #32
    v.st.scatter.w [s39, v18], v13
    a.vread      v13, a8, s33
    s.movz       s33, #9
    s.addi       s39, s32, #36
    v.st.scatter.w [s40, v18], v13
    a.vread      v13, a8, s31
    s.movz       s31, #10
    s.addi       s40, s32, #40
    v.st.scatter.w [s34, v18], v13
    a.vread      v13, a8, s35
    s.movz       s34, #11
    s.addi       s35, s32, #44
    v.st.scatter.w [s37, v18], v13
    a.vread      v13, a8, s11
    s.movz       s11, #12
    s.addi       s37, s32, #48
    v.st.scatter.w [s38, v18], v13
    a.vread      v13, a8, s33
    s.movz       s33, #13
    s.addi       s38, s32, #52
    v.st.scatter.w [s39, v18], v13
    a.vread      v13, a8, s31
    s.movz       s31, #14
    s.addi       s39, s32, #56
    v.st.scatter.w [s40, v18], v13
    a.vread      v13, a8, s34
    s.movz       s34, #15
    s.addi       s40, s32, #60
    v.st.scatter.w [s35, v18], v13
    a.vread      v13, a8, s11
    s.movz       s11, #0
    s.addi       s32, s30, #11264
    v.st.scatter.w [s37, v18], v13
    a.vread      v13, a8, s33
    s.movz       s33, #1
    s.addi       s35, s32, #4
    v.st.scatter.w [s38, v18], v13
    a.vread      v13, a8, s31
    s.movz       s31, #2
    s.addi       s37, s32, #8
    v.st.scatter.w [s39, v18], v13
    a.vread      v13, a8, s34
    s.movz       s34, #3
    s.addi       s38, s32, #12
    v.st.scatter.w [s40, v18], v13
    fence.acq_rel.device
    a.vread      v13, a9, s11
    s.movz       s11, #4
    s.addi       s39, s32, #16
    v.st.scatter.w [s32, v18], v13
    a.vread      v13, a9, s33
    s.movz       s33, #5
    s.addi       s40, s32, #20
    v.st.scatter.w [s35, v18], v13
    a.vread      v13, a9, s31
    s.movz       s31, #6
    s.addi       s35, s32, #24
    v.st.scatter.w [s37, v18], v13
    a.vread      v13, a9, s34
    s.movz       s34, #7
    s.addi       s37, s32, #28
    v.st.scatter.w [s38, v18], v13
    a.vread      v13, a9, s11
    s.movz       s11, #8
    s.addi       s38, s32, #32
    v.st.scatter.w [s39, v18], v13
    a.vread      v13, a9, s33
    s.movz       s33, #9
    s.addi       s39, s32, #36
    v.st.scatter.w [s40, v18], v13
    a.vread      v13, a9, s31
    s.movz       s31, #10
    s.addi       s40, s32, #40
    v.st.scatter.w [s35, v18], v13
    a.vread      v13, a9, s34
    s.movz       s34, #11
    s.addi       s35, s32, #44
    v.st.scatter.w [s37, v18], v13
    a.vread      v13, a9, s11
    s.movz       s11, #12
    s.addi       s37, s32, #48
    v.st.scatter.w [s38, v18], v13
    a.vread      v13, a9, s33
    s.movz       s33, #13
    s.addi       s38, s32, #52
    v.st.scatter.w [s39, v18], v13
    a.vread      v13, a9, s31
    s.movz       s31, #14
    s.addi       s39, s32, #56
    v.st.scatter.w [s40, v18], v13
    a.vread      v13, a9, s34
    s.movz       s34, #15
    s.addi       s40, s32, #60
    v.st.scatter.w [s35, v18], v13
    a.vread      v13, a9, s11
    s.movz       s11, #0
    s.addi       s32, s30, #12288
    v.st.scatter.w [s37, v18], v13
    a.vread      v13, a9, s33
    s.movz       s33, #1
    s.addi       s35, s32, #4
    v.st.scatter.w [s38, v18], v13
    a.vread      v13, a9, s31
    s.movz       s31, #2
    s.addi       s37, s32, #8
    v.st.scatter.w [s39, v18], v13
    a.vread      v13, a9, s34
    s.movz       s34, #3
    s.addi       s38, s32, #12
    v.st.scatter.w [s40, v18], v13
    fence.acq_rel.device
    a.vread      v13, a10, s11
    s.movz       s11, #4
    s.addi       s39, s32, #16
    v.st.scatter.w [s32, v18], v13
    a.vread      v13, a10, s33
    s.movz       s33, #5
    s.addi       s40, s32, #20
    v.st.scatter.w [s35, v18], v13
    a.vread      v13, a10, s31
    s.movz       s31, #6
    s.addi       s35, s32, #24
    v.st.scatter.w [s37, v18], v13
    a.vread      v13, a10, s34
    s.movz       s34, #7
    s.addi       s37, s32, #28
    v.st.scatter.w [s38, v18], v13
    a.vread      v13, a10, s11
    s.movz       s11, #8
    s.addi       s38, s32, #32
    v.st.scatter.w [s39, v18], v13
    a.vread      v13, a10, s33
    s.movz       s33, #9
    s.addi       s39, s32, #36
    v.st.scatter.w [s40, v18], v13
    a.vread      v13, a10, s31
    s.movz       s31, #10
    s.addi       s40, s32, #40
    v.st.scatter.w [s35, v18], v13
    a.vread      v13, a10, s34
    s.movz       s34, #11
    s.addi       s35, s32, #44
    v.st.scatter.w [s37, v18], v13
    a.vread      v13, a10, s11
    s.movz       s11, #12
    s.addi       s37, s32, #48
    v.st.scatter.w [s38, v18], v13
    a.vread      v13, a10, s33
    s.movz       s33, #13
    s.addi       s38, s32, #52
    v.st.scatter.w [s39, v18], v13
    a.vread      v13, a10, s31
    s.movz       s31, #14
    s.addi       s39, s32, #56
    v.st.scatter.w [s40, v18], v13
    a.vread      v13, a10, s34
    s.movz       s34, #15
    s.addi       s40, s32, #60
    v.st.scatter.w [s35, v18], v13
    a.vread      v13, a10, s11
    s.movz       s11, #0
    s.addi       s32, s30, #13312
    v.st.scatter.w [s37, v18], v13
    a.vread      v13, a10, s33
    s.movz       s33, #1
    s.addi       s35, s32, #4
    v.st.scatter.w [s38, v18], v13
    a.vread      v13, a10, s31
    s.movz       s31, #2
    s.addi       s37, s32, #8
    v.st.scatter.w [s39, v18], v13
    a.vread      v13, a10, s34
    s.movz       s34, #3
    s.addi       s38, s32, #12
    v.st.scatter.w [s40, v18], v13
    fence.acq_rel.device
    a.vread      v13, a11, s11
    s.movz       s11, #4
    s.addi       s39, s32, #16
    v.st.scatter.w [s32, v18], v13
    a.vread      v13, a11, s33
    s.movz       s33, #5
    s.addi       s40, s32, #20
    v.st.scatter.w [s35, v18], v13
    a.vread      v13, a11, s31
    s.movz       s31, #6
    s.addi       s35, s32, #24
    v.st.scatter.w [s37, v18], v13
    a.vread      v13, a11, s34
    s.movz       s34, #7
    s.addi       s37, s32, #28
    v.st.scatter.w [s38, v18], v13
    a.vread      v13, a11, s11
    s.movz       s11, #8
    s.addi       s38, s32, #32
    v.st.scatter.w [s39, v18], v13
    a.vread      v13, a11, s33
    s.movz       s33, #9
    s.addi       s39, s32, #36
    v.st.scatter.w [s40, v18], v13
    a.vread      v13, a11, s31
    s.movz       s31, #10
    s.addi       s40, s32, #40
    v.st.scatter.w [s35, v18], v13
    a.vread      v13, a11, s34
    s.movz       s34, #11
    s.addi       s35, s32, #44
    v.st.scatter.w [s37, v18], v13
    a.vread      v13, a11, s11
    s.movz       s11, #12
    s.addi       s37, s32, #48
    v.st.scatter.w [s38, v18], v13
    a.vread      v13, a11, s33
    s.movz       s33, #13
    s.addi       s38, s32, #52
    v.st.scatter.w [s39, v18], v13
    a.vread      v13, a11, s31
    s.movz       s31, #14
    s.addi       s39, s32, #56
    v.st.scatter.w [s40, v18], v13
    a.vread      v13, a11, s34
    s.movz       s34, #15
    s.addi       s40, s32, #60
    v.st.scatter.w [s35, v18], v13
    a.vread      v13, a11, s11
    s.movz       s11, #0
    s.addi       s32, s30, #14336
    v.st.scatter.w [s37, v18], v13
    a.vread      v13, a11, s33
    s.movz       s33, #1
    s.addi       s35, s32, #4
    v.st.scatter.w [s38, v18], v13
    a.vread      v13, a11, s31
    s.movz       s31, #2
    s.addi       s37, s32, #8
    v.st.scatter.w [s39, v18], v13
    a.vread      v13, a11, s34
    s.movz       s34, #3
    s.addi       s38, s32, #12
    v.st.scatter.w [s40, v18], v13
    fence.acq_rel.device
    a.vread      v13, a12, s11
    s.movz       s11, #4
    s.addi       s39, s32, #16
    v.st.scatter.w [s32, v18], v13
    a.vread      v13, a12, s33
    s.movz       s33, #5
    s.addi       s40, s32, #20
    v.st.scatter.w [s35, v18], v13
    a.vread      v13, a12, s31
    s.movz       s31, #6
    s.addi       s35, s32, #24
    v.st.scatter.w [s37, v18], v13
    a.vread      v13, a12, s34
    s.movz       s34, #7
    s.addi       s37, s32, #28
    v.st.scatter.w [s38, v18], v13
    a.vread      v13, a12, s11
    s.movz       s11, #8
    s.addi       s38, s32, #32
    v.st.scatter.w [s39, v18], v13
    a.vread      v13, a12, s33
    s.movz       s33, #9
    s.addi       s39, s32, #36
    v.st.scatter.w [s40, v18], v13
    a.vread      v13, a12, s31
    s.movz       s31, #10
    s.addi       s40, s32, #40
    v.st.scatter.w [s35, v18], v13
    a.vread      v13, a12, s34
    s.movz       s34, #11
    s.addi       s35, s32, #44
    v.st.scatter.w [s37, v18], v13
    a.vread      v13, a12, s11
    s.movz       s11, #12
    s.addi       s37, s32, #48
    v.st.scatter.w [s38, v18], v13
    a.vread      v13, a12, s33
    s.movz       s33, #13
    s.addi       s38, s32, #52
    v.st.scatter.w [s39, v18], v13
    a.vread      v13, a12, s31
    s.movz       s31, #14
    s.addi       s39, s32, #56
    v.st.scatter.w [s40, v18], v13
    a.vread      v13, a12, s34
    s.movz       s34, #15
    s.addi       s40, s32, #60
    v.st.scatter.w [s35, v18], v13
    a.vread      v13, a12, s11
    s.movz       s11, #0
    s.addi       s32, s30, #15360
    v.st.scatter.w [s37, v18], v13
    a.vread      v13, a12, s33
    s.movz       s33, #1
    s.addi       s35, s32, #4
    v.st.scatter.w [s38, v18], v13
    a.vread      v13, a12, s31
    s.movz       s31, #2
    s.addi       s37, s32, #8
    v.st.scatter.w [s39, v18], v13
    a.vread      v13, a12, s34
    s.movz       s34, #3
    s.addi       s38, s32, #12
    v.st.scatter.w [s40, v18], v13
    fence.acq_rel.device
    a.vread      v13, a13, s11
    s.movz       s11, #4
    s.addi       s39, s32, #16
    v.st.scatter.w [s32, v18], v13
    a.vread      v13, a13, s33
    s.movz       s33, #5
    s.addi       s40, s32, #20
    v.st.scatter.w [s35, v18], v13
    a.vread      v13, a13, s31
    s.movz       s31, #6
    s.addi       s35, s32, #24
    v.st.scatter.w [s37, v18], v13
    a.vread      v13, a13, s34
    s.movz       s34, #7
    s.addi       s37, s32, #28
    v.st.scatter.w [s38, v18], v13
    a.vread      v13, a13, s11
    s.movz       s11, #8
    s.addi       s38, s32, #32
    v.st.scatter.w [s39, v18], v13
    a.vread      v13, a13, s33
    s.movz       s33, #9
    s.addi       s39, s32, #36
    v.st.scatter.w [s40, v18], v13
    a.vread      v13, a13, s31
    s.movz       s31, #10
    s.addi       s40, s32, #40
    v.st.scatter.w [s35, v18], v13
    a.vread      v13, a13, s34
    s.movz       s34, #11
    s.addi       s35, s32, #44
    v.st.scatter.w [s37, v18], v13
    a.vread      v13, a13, s11
    s.movz       s11, #12
    s.addi       s37, s32, #48
    v.st.scatter.w [s38, v18], v13
    a.vread      v13, a13, s33
    s.movz       s33, #13
    s.addi       s38, s32, #52
    v.st.scatter.w [s39, v18], v13
    a.vread      v13, a13, s31
    s.movz       s31, #14
    s.addi       s39, s32, #56
    v.st.scatter.w [s40, v18], v13
    a.vread      v13, a13, s34
    s.movz       s34, #15
    s.addi       s40, s32, #60
    v.st.scatter.w [s35, v18], v13
    a.vread      v13, a13, s11
    s.movz       s11, #0
    s.addi       s32, s30, #16384
    v.st.scatter.w [s37, v18], v13
    a.vread      v13, a13, s33
    s.movz       s33, #1
    s.addi       s35, s32, #4
    v.st.scatter.w [s38, v18], v13
    a.vread      v13, a13, s31
    s.movz       s31, #2
    s.addi       s37, s32, #8
    v.st.scatter.w [s39, v18], v13
    a.vread      v13, a13, s34
    s.movz       s34, #3
    s.addi       s38, s32, #12
    v.st.scatter.w [s40, v18], v13
    fence.acq_rel.device
    a.vread      v13, a14, s11
    s.movz       s11, #4
    s.addi       s39, s32, #16
    v.st.scatter.w [s32, v18], v13
    a.vread      v13, a14, s33
    s.movz       s33, #5
    s.addi       s40, s32, #20
    v.st.scatter.w [s35, v18], v13
    a.vread      v13, a14, s31
    s.movz       s31, #6
    s.addi       s35, s32, #24
    v.st.scatter.w [s37, v18], v13
    a.vread      v13, a14, s34
    s.movz       s34, #7
    s.addi       s37, s32, #28
    v.st.scatter.w [s38, v18], v13
    a.vread      v13, a14, s11
    s.movz       s11, #8
    s.addi       s38, s32, #32
    v.st.scatter.w [s39, v18], v13
    a.vread      v13, a14, s33
    s.movz       s33, #9
    s.addi       s39, s32, #36
    v.st.scatter.w [s40, v18], v13
    a.vread      v13, a14, s31
    s.movz       s31, #10
    s.addi       s40, s32, #40
    v.st.scatter.w [s35, v18], v13
    a.vread      v13, a14, s34
    s.movz       s34, #11
    s.addi       s35, s32, #44
    v.st.scatter.w [s37, v18], v13
    a.vread      v13, a14, s11
    s.movz       s11, #12
    s.addi       s37, s32, #48
    v.st.scatter.w [s38, v18], v13
    a.vread      v13, a14, s33
    s.movz       s33, #13
    s.addi       s38, s32, #52
    v.st.scatter.w [s39, v18], v13
    a.vread      v13, a14, s31
    s.movz       s31, #14
    s.addi       s39, s32, #56
    v.st.scatter.w [s40, v18], v13
    a.vread      v13, a14, s34
    s.movz       s34, #15
    s.addi       s40, s32, #60
    v.st.scatter.w [s35, v18], v13
    a.vread      v13, a14, s11
    s.movz       s11, #0
    s.addi       s32, s30, #17408
    v.st.scatter.w [s37, v18], v13
    a.vread      v13, a14, s33
    s.movz       s33, #1
    s.addi       s35, s32, #4
    v.st.scatter.w [s38, v18], v13
    a.vread      v13, a14, s31
    s.movz       s31, #2
    s.addi       s37, s32, #8
    v.st.scatter.w [s39, v18], v13
    a.vread      v13, a14, s34
    s.movz       s34, #3
    s.addi       s38, s32, #12
    v.st.scatter.w [s40, v18], v13
    fence.acq_rel.device
    a.vread      v13, a15, s11
    s.movz       s11, #4
    s.addi       s39, s32, #16
    v.st.scatter.w [s32, v18], v13
    a.vread      v13, a15, s33
    s.movz       s33, #5
    s.addi       s40, s32, #20
    v.st.scatter.w [s35, v18], v13
    a.vread      v13, a15, s31
    s.movz       s31, #6
    s.addi       s35, s32, #24
    v.st.scatter.w [s37, v18], v13
    a.vread      v13, a15, s34
    s.movz       s34, #7
    s.addi       s37, s32, #28
    v.st.scatter.w [s38, v18], v13
    a.vread      v13, a15, s11
    s.movz       s11, #8
    s.addi       s38, s32, #32
    v.st.scatter.w [s39, v18], v13
    a.vread      v13, a15, s33
    s.movz       s33, #9
    s.addi       s39, s32, #36
    v.st.scatter.w [s40, v18], v13
    a.vread      v13, a15, s31
    s.movz       s31, #10
    s.addi       s40, s32, #40
    v.st.scatter.w [s35, v18], v13
    a.vread      v13, a15, s34
    s.movz       s34, #11
    s.addi       s35, s32, #44
    v.st.scatter.w [s37, v18], v13
    a.vread      v13, a15, s11
    s.movz       s11, #12
    s.addi       s37, s32, #48
    v.st.scatter.w [s38, v18], v13
    a.vread      v13, a15, s33
    s.movz       s33, #13
    s.addi       s38, s32, #52
    v.st.scatter.w [s39, v18], v13
    a.vread      v13, a15, s31
    s.movz       s31, #14
    s.addi       s39, s32, #56
    v.st.scatter.w [s40, v18], v13
    a.vread      v13, a15, s34
    s.movz       s34, #15
    s.addi       s40, s32, #60
    v.st.scatter.w [s35, v18], v13
    a.vread      v13, a15, s11
    s.movz       s11, #0
    s.addi       s32, s30, #18432
    v.st.scatter.w [s37, v18], v13
    a.vread      v13, a15, s33
    s.addi       s33, s30, #10240
    v.extract    s35, v27, #0
    v.st.scatter.w [s38, v18], v13
    a.vread      v13, a15, s31
    v.splat      v19, s35
    v.st.scatter.w [s39, v18], v13
    a.vread      v13, a15, s34
    s.movz       s31, #1
    s.addi       s34, s32, #64
    v.st.scatter.w [s40, v18], v13
    fence.acq_rel.device
    a.vread      v13, a0, s11
    s.addi       s11, s30, #10304
    v.extract    s35, v27, #1
    v.splat      v18, s35
    v.ld.w       v21, [s33, #0]
    s.addi       s33, s32, #128
    vf.mul       v22, v21, v19
    s.movz       s35, #2
    vf.mul       v19, v22, v16
    vf.add       v21, v13, v19
    s.addi       s37, s30, #10368
    v.st.w       [s32, #0], v21
    a.vread      v13, a0, s31
    v.extract    s31, v27, #2
    v.splat      v19, s31
    v.ld.w       v21, [s11, #0]
    s.addi       s11, s32, #192
    vf.mul       v22, v21, v18
    s.movz       s31, #3
    vf.mul       v18, v22, v16
    vf.add       v21, v13, v18
    s.addi       s38, s30, #10432
    v.st.w       [s34, #0], v21
    a.vread      v13, a0, s35
    v.extract    s34, v27, #3
    v.splat      v18, s34
    v.ld.w       v21, [s37, #0]
    s.addi       s34, s32, #256
    vf.mul       v22, v21, v19
    s.movz       s35, #4
    vf.mul       v19, v22, v16
    vf.add       v21, v13, v19
    s.addi       s37, s30, #10496
    v.st.w       [s33, #0], v21
    a.vread      v13, a0, s31
    v.extract    s31, v27, #4
    v.splat      v19, s31
    v.ld.w       v21, [s38, #0]
    s.addi       s31, s32, #320
    vf.mul       v22, v21, v18
    s.movz       s33, #5
    vf.mul       v18, v22, v16
    vf.add       v21, v13, v18
    s.addi       s38, s30, #10560
    v.st.w       [s11, #0], v21
    a.vread      v13, a0, s35
    v.extract    s11, v27, #5
    v.splat      v18, s11
    v.ld.w       v21, [s37, #0]
    s.addi       s11, s32, #384
    vf.mul       v22, v21, v19
    s.movz       s35, #6
    vf.mul       v19, v22, v16
    vf.add       v21, v13, v19
    s.addi       s37, s30, #10624
    v.st.w       [s34, #0], v21
    a.vread      v13, a0, s33
    v.extract    s33, v27, #6
    v.splat      v19, s33
    v.ld.w       v21, [s38, #0]
    s.addi       s33, s32, #448
    vf.mul       v22, v21, v18
    s.movz       s34, #7
    vf.mul       v18, v22, v16
    vf.add       v21, v13, v18
    s.addi       s38, s30, #10688
    v.st.w       [s31, #0], v21
    a.vread      v13, a0, s35
    v.extract    s31, v27, #7
    v.splat      v18, s31
    v.ld.w       v21, [s37, #0]
    s.addi       s31, s32, #512
    vf.mul       v22, v21, v19
    s.movz       s35, #8
    vf.mul       v19, v22, v16
    vf.add       v21, v13, v19
    s.addi       s37, s30, #10752
    v.st.w       [s11, #0], v21
    a.vread      v13, a0, s34
    v.extract    s11, v27, #8
    v.splat      v19, s11
    v.ld.w       v21, [s38, #0]
    s.addi       s11, s32, #576
    vf.mul       v22, v21, v18
    s.movz       s34, #9
    vf.mul       v18, v22, v16
    vf.add       v21, v13, v18
    s.addi       s38, s30, #10816
    v.st.w       [s33, #0], v21
    a.vread      v13, a0, s35
    v.extract    s33, v27, #9
    v.splat      v18, s33
    v.ld.w       v21, [s37, #0]
    s.addi       s33, s32, #640
    vf.mul       v22, v21, v19
    s.movz       s35, #10
    vf.mul       v19, v22, v16
    vf.add       v21, v13, v19
    s.addi       s37, s30, #10880
    v.st.w       [s31, #0], v21
    a.vread      v13, a0, s34
    v.extract    s31, v27, #10
    v.splat      v19, s31
    v.ld.w       v21, [s38, #0]
    s.addi       s31, s32, #704
    vf.mul       v22, v21, v18
    s.movz       s34, #11
    vf.mul       v18, v22, v16
    vf.add       v21, v13, v18
    s.addi       s38, s30, #10944
    v.st.w       [s11, #0], v21
    a.vread      v13, a0, s35
    v.extract    s11, v27, #11
    v.splat      v18, s11
    v.ld.w       v21, [s37, #0]
    s.addi       s11, s32, #768
    vf.mul       v22, v21, v19
    s.movz       s35, #12
    vf.mul       v19, v22, v16
    vf.add       v21, v13, v19
    s.addi       s37, s30, #11008
    v.st.w       [s33, #0], v21
    a.vread      v13, a0, s34
    v.extract    s33, v27, #12
    v.splat      v19, s33
    v.ld.w       v21, [s38, #0]
    s.addi       s33, s32, #832
    vf.mul       v22, v21, v18
    s.movz       s34, #13
    vf.mul       v18, v22, v16
    vf.add       v21, v13, v18
    s.addi       s38, s30, #11072
    v.st.w       [s31, #0], v21
    a.vread      v13, a0, s35
    v.extract    s31, v27, #13
    v.splat      v18, s31
    v.ld.w       v21, [s37, #0]
    s.addi       s31, s32, #896
    vf.mul       v22, v21, v19
    s.movz       s35, #14
    vf.mul       v19, v22, v16
    vf.add       v21, v13, v19
    s.addi       s37, s30, #11136
    v.st.w       [s11, #0], v21
    a.vread      v13, a0, s34
    v.extract    s11, v27, #14
    v.splat      v19, s11
    v.ld.w       v21, [s38, #0]
    s.addi       s11, s32, #960
    vf.mul       v22, v21, v18
    s.movz       s32, #15
    vf.mul       v18, v22, v16
    vf.add       v21, v13, v18
    s.addi       s34, s30, #11200
    v.st.w       [s33, #0], v21
    a.vread      v13, a0, s35
    v.extract    s33, v27, #15
    v.splat      v18, s33
    v.ld.w       v21, [s37, #0]
    vf.mul       v22, v21, v19
    s.addi       s33, s30, #19456
    vf.mul       v19, v22, v16
    s.movz       s35, #0
    vf.add       v21, v13, v19
    v.st.w       [s31, #0], v21
    a.vread      v13, a0, s32
    s.addi       s31, s30, #11264
    v.extract    s32, v27, #0
    v.splat      v19, s32
    v.ld.w       v21, [s34, #0]
    vf.mul       v22, v21, v18
    s.addi       s32, s33, #64
    vf.mul       v18, v22, v16
    s.movz       s34, #1
    vf.add       v16, v13, v18
    v.st.w       [s11, #0], v16
    fence.acq_rel.device
    a.vread      v13, a1, s35
    s.addi       s11, s30, #11328
    v.extract    s35, v27, #1
    v.splat      v16, s35
    v.ld.w       v18, [s31, #0]
    s.addi       s31, s33, #128
    vf.mul       v21, v18, v19
    s.movz       s35, #2
    vf.mul       v18, v21, v31
    vf.add       v19, v13, v18
    s.addi       s37, s30, #11392
    v.st.w       [s33, #0], v19
    a.vread      v13, a1, s34
    v.extract    s34, v27, #2
    v.splat      v18, s34
    v.ld.w       v19, [s11, #0]
    s.addi       s11, s33, #192
    vf.mul       v21, v19, v16
    s.movz       s34, #3
    vf.mul       v16, v21, v31
    vf.add       v19, v13, v16
    s.addi       s38, s30, #11456
    v.st.w       [s32, #0], v19
    a.vread      v13, a1, s35
    v.extract    s32, v27, #3
    v.splat      v16, s32
    v.ld.w       v19, [s37, #0]
    s.addi       s32, s33, #256
    vf.mul       v21, v19, v18
    s.movz       s35, #4
    vf.mul       v18, v21, v31
    vf.add       v19, v13, v18
    s.addi       s37, s30, #11520
    v.st.w       [s31, #0], v19
    a.vread      v13, a1, s34
    v.extract    s31, v27, #4
    v.splat      v18, s31
    v.ld.w       v19, [s38, #0]
    s.addi       s31, s33, #320
    vf.mul       v21, v19, v16
    s.movz       s34, #5
    vf.mul       v16, v21, v31
    vf.add       v19, v13, v16
    s.addi       s38, s30, #11584
    v.st.w       [s11, #0], v19
    a.vread      v13, a1, s35
    v.extract    s11, v27, #5
    v.splat      v16, s11
    v.ld.w       v19, [s37, #0]
    s.addi       s11, s33, #384
    vf.mul       v21, v19, v18
    s.movz       s35, #6
    vf.mul       v18, v21, v31
    vf.add       v19, v13, v18
    s.addi       s37, s30, #11648
    v.st.w       [s32, #0], v19
    a.vread      v13, a1, s34
    v.extract    s32, v27, #6
    v.splat      v18, s32
    v.ld.w       v19, [s38, #0]
    s.addi       s32, s33, #448
    vf.mul       v21, v19, v16
    s.movz       s34, #7
    vf.mul       v16, v21, v31
    vf.add       v19, v13, v16
    s.addi       s38, s30, #11712
    v.st.w       [s31, #0], v19
    a.vread      v13, a1, s35
    v.extract    s31, v27, #7
    v.splat      v16, s31
    v.ld.w       v19, [s37, #0]
    s.addi       s31, s33, #512
    vf.mul       v21, v19, v18
    s.movz       s35, #8
    vf.mul       v18, v21, v31
    vf.add       v19, v13, v18
    s.addi       s37, s30, #11776
    v.st.w       [s11, #0], v19
    a.vread      v13, a1, s34
    v.extract    s11, v27, #8
    v.splat      v18, s11
    v.ld.w       v19, [s38, #0]
    s.addi       s11, s33, #576
    vf.mul       v21, v19, v16
    s.movz       s34, #9
    vf.mul       v16, v21, v31
    vf.add       v19, v13, v16
    s.addi       s38, s30, #11840
    v.st.w       [s32, #0], v19
    a.vread      v13, a1, s35
    v.extract    s32, v27, #9
    v.splat      v16, s32
    v.ld.w       v19, [s37, #0]
    s.addi       s32, s33, #640
    vf.mul       v21, v19, v18
    s.movz       s35, #10
    vf.mul       v18, v21, v31
    vf.add       v19, v13, v18
    s.addi       s37, s30, #11904
    v.st.w       [s31, #0], v19
    a.vread      v13, a1, s34
    v.extract    s31, v27, #10
    v.splat      v18, s31
    v.ld.w       v19, [s38, #0]
    s.addi       s31, s33, #704
    vf.mul       v21, v19, v16
    s.movz       s34, #11
    vf.mul       v16, v21, v31
    vf.add       v19, v13, v16
    s.addi       s38, s30, #11968
    v.st.w       [s11, #0], v19
    a.vread      v13, a1, s35
    v.extract    s11, v27, #11
    v.splat      v16, s11
    v.ld.w       v19, [s37, #0]
    s.addi       s11, s33, #768
    vf.mul       v21, v19, v18
    s.movz       s35, #12
    vf.mul       v18, v21, v31
    vf.add       v19, v13, v18
    s.addi       s37, s30, #12032
    v.st.w       [s32, #0], v19
    a.vread      v13, a1, s34
    v.extract    s32, v27, #12
    v.splat      v18, s32
    v.ld.w       v19, [s38, #0]
    s.addi       s32, s33, #832
    vf.mul       v21, v19, v16
    s.movz       s34, #13
    vf.mul       v16, v21, v31
    vf.add       v19, v13, v16
    s.addi       s38, s30, #12096
    v.st.w       [s31, #0], v19
    a.vread      v13, a1, s35
    v.extract    s31, v27, #13
    v.splat      v16, s31
    v.ld.w       v19, [s37, #0]
    s.addi       s31, s33, #896
    vf.mul       v21, v19, v18
    s.movz       s35, #14
    vf.mul       v18, v21, v31
    vf.add       v19, v13, v18
    s.addi       s37, s30, #12160
    v.st.w       [s11, #0], v19
    a.vread      v13, a1, s34
    v.extract    s11, v27, #14
    v.splat      v18, s11
    v.ld.w       v19, [s38, #0]
    s.addi       s11, s33, #960
    vf.mul       v21, v19, v16
    s.movz       s33, #15
    vf.mul       v16, v21, v31
    vf.add       v19, v13, v16
    s.addi       s34, s30, #12224
    v.st.w       [s32, #0], v19
    a.vread      v13, a1, s35
    v.extract    s32, v27, #15
    v.splat      v16, s32
    v.ld.w       v19, [s37, #0]
    vf.mul       v21, v19, v18
    s.addi       s32, s30, #20480
    vf.mul       v18, v21, v31
    s.movz       s35, #0
    vf.add       v19, v13, v18
    v.st.w       [s31, #0], v19
    a.vread      v13, a1, s33
    s.addi       s31, s30, #12288
    v.extract    s33, v27, #0
    v.splat      v18, s33
    v.ld.w       v19, [s34, #0]
    vf.mul       v21, v19, v16
    s.addi       s33, s32, #64
    vf.mul       v16, v21, v31
    s.movz       s34, #1
    vf.add       v19, v13, v16
    v.st.w       [s11, #0], v19
    fence.acq_rel.device
    a.vread      v13, a2, s35
    s.addi       s11, s30, #12352
    v.extract    s35, v27, #1
    v.splat      v16, s35
    v.ld.w       v19, [s31, #0]
    s.addi       s31, s32, #128
    vf.mul       v21, v19, v18
    s.movz       s35, #2
    vf.mul       v18, v21, v26
    vf.add       v19, v13, v18
    s.addi       s37, s30, #12416
    v.st.w       [s32, #0], v19
    a.vread      v13, a2, s34
    v.extract    s34, v27, #2
    v.splat      v18, s34
    v.ld.w       v19, [s11, #0]
    s.addi       s11, s32, #192
    vf.mul       v21, v19, v16
    s.movz       s34, #3
    vf.mul       v16, v21, v26
    vf.add       v19, v13, v16
    s.addi       s38, s30, #12480
    v.st.w       [s33, #0], v19
    a.vread      v13, a2, s35
    v.extract    s33, v27, #3
    v.splat      v16, s33
    v.ld.w       v19, [s37, #0]
    s.addi       s33, s32, #256
    vf.mul       v21, v19, v18
    s.movz       s35, #4
    vf.mul       v18, v21, v26
    vf.add       v19, v13, v18
    s.addi       s37, s30, #12544
    v.st.w       [s31, #0], v19
    a.vread      v13, a2, s34
    v.extract    s31, v27, #4
    v.splat      v18, s31
    v.ld.w       v19, [s38, #0]
    s.addi       s31, s32, #320
    vf.mul       v21, v19, v16
    s.movz       s34, #5
    vf.mul       v16, v21, v26
    vf.add       v19, v13, v16
    s.addi       s38, s30, #12608
    v.st.w       [s11, #0], v19
    a.vread      v13, a2, s35
    v.extract    s11, v27, #5
    v.splat      v16, s11
    v.ld.w       v19, [s37, #0]
    s.addi       s11, s32, #384
    vf.mul       v21, v19, v18
    s.movz       s35, #6
    vf.mul       v18, v21, v26
    vf.add       v19, v13, v18
    s.addi       s37, s30, #12672
    v.st.w       [s33, #0], v19
    a.vread      v13, a2, s34
    v.extract    s33, v27, #6
    v.splat      v18, s33
    v.ld.w       v19, [s38, #0]
    s.addi       s33, s32, #448
    vf.mul       v21, v19, v16
    s.movz       s34, #7
    vf.mul       v16, v21, v26
    vf.add       v19, v13, v16
    s.addi       s38, s30, #12736
    v.st.w       [s31, #0], v19
    a.vread      v13, a2, s35
    v.extract    s31, v27, #7
    v.splat      v16, s31
    v.ld.w       v19, [s37, #0]
    s.addi       s31, s32, #512
    vf.mul       v21, v19, v18
    s.movz       s35, #8
    vf.mul       v18, v21, v26
    vf.add       v19, v13, v18
    s.addi       s37, s30, #12800
    v.st.w       [s11, #0], v19
    a.vread      v13, a2, s34
    v.extract    s11, v27, #8
    v.splat      v18, s11
    v.ld.w       v19, [s38, #0]
    s.addi       s11, s32, #576
    vf.mul       v21, v19, v16
    s.movz       s34, #9
    vf.mul       v16, v21, v26
    vf.add       v19, v13, v16
    s.addi       s38, s30, #12864
    v.st.w       [s33, #0], v19
    a.vread      v13, a2, s35
    v.extract    s33, v27, #9
    v.splat      v16, s33
    v.ld.w       v19, [s37, #0]
    s.addi       s33, s32, #640
    vf.mul       v21, v19, v18
    s.movz       s35, #10
    vf.mul       v18, v21, v26
    vf.add       v19, v13, v18
    s.addi       s37, s30, #12928
    v.st.w       [s31, #0], v19
    a.vread      v13, a2, s34
    v.extract    s31, v27, #10
    v.splat      v18, s31
    v.ld.w       v19, [s38, #0]
    s.addi       s31, s32, #704
    vf.mul       v21, v19, v16
    s.movz       s34, #11
    vf.mul       v16, v21, v26
    vf.add       v19, v13, v16
    s.addi       s38, s30, #12992
    v.st.w       [s11, #0], v19
    a.vread      v13, a2, s35
    v.extract    s11, v27, #11
    v.splat      v16, s11
    v.ld.w       v19, [s37, #0]
    s.addi       s11, s32, #768
    vf.mul       v21, v19, v18
    s.movz       s35, #12
    vf.mul       v18, v21, v26
    vf.add       v19, v13, v18
    s.addi       s37, s30, #13056
    v.st.w       [s33, #0], v19
    a.vread      v13, a2, s34
    v.extract    s33, v27, #12
    v.splat      v18, s33
    v.ld.w       v19, [s38, #0]
    s.addi       s33, s32, #832
    vf.mul       v21, v19, v16
    s.movz       s34, #13
    vf.mul       v16, v21, v26
    vf.add       v19, v13, v16
    s.addi       s38, s30, #13120
    v.st.w       [s31, #0], v19
    a.vread      v13, a2, s35
    v.extract    s31, v27, #13
    v.splat      v16, s31
    v.ld.w       v19, [s37, #0]
    s.addi       s31, s32, #896
    vf.mul       v21, v19, v18
    s.movz       s35, #14
    vf.mul       v18, v21, v26
    vf.add       v19, v13, v18
    s.addi       s37, s30, #13184
    v.st.w       [s11, #0], v19
    a.vread      v13, a2, s34
    v.extract    s11, v27, #14
    v.splat      v18, s11
    v.ld.w       v19, [s38, #0]
    s.addi       s11, s32, #960
    vf.mul       v21, v19, v16
    s.movz       s32, #15
    vf.mul       v16, v21, v26
    vf.add       v19, v13, v16
    s.addi       s34, s30, #13248
    v.st.w       [s33, #0], v19
    a.vread      v13, a2, s35
    v.extract    s33, v27, #15
    v.splat      v16, s33
    v.ld.w       v19, [s37, #0]
    vf.mul       v21, v19, v18
    s.addi       s33, s30, #21504
    vf.mul       v18, v21, v26
    s.movz       s35, #0
    vf.add       v19, v13, v18
    v.st.w       [s31, #0], v19
    a.vread      v13, a2, s32
    s.addi       s31, s30, #13312
    v.extract    s32, v27, #0
    v.splat      v18, s32
    v.ld.w       v19, [s34, #0]
    vf.mul       v21, v19, v16
    s.addi       s32, s33, #64
    vf.mul       v16, v21, v26
    s.movz       s34, #1
    vf.add       v19, v13, v16
    v.st.w       [s11, #0], v19
    fence.acq_rel.device
    a.vread      v13, a3, s35
    s.addi       s11, s30, #13376
    v.extract    s35, v27, #1
    v.splat      v16, s35
    v.ld.w       v19, [s31, #0]
    s.addi       s31, s33, #128
    vf.mul       v21, v19, v18
    s.movz       s35, #2
    vf.mul       v18, v21, v34
    vf.add       v19, v13, v18
    s.addi       s37, s30, #13440
    v.st.w       [s33, #0], v19
    a.vread      v13, a3, s34
    v.extract    s34, v27, #2
    v.splat      v18, s34
    v.ld.w       v19, [s11, #0]
    s.addi       s11, s33, #192
    vf.mul       v21, v19, v16
    s.movz       s34, #3
    vf.mul       v16, v21, v34
    vf.add       v19, v13, v16
    s.addi       s38, s30, #13504
    v.st.w       [s32, #0], v19
    a.vread      v13, a3, s35
    v.extract    s32, v27, #3
    v.splat      v16, s32
    v.ld.w       v19, [s37, #0]
    s.addi       s32, s33, #256
    vf.mul       v21, v19, v18
    s.movz       s35, #4
    vf.mul       v18, v21, v34
    vf.add       v19, v13, v18
    s.addi       s37, s30, #13568
    v.st.w       [s31, #0], v19
    a.vread      v13, a3, s34
    v.extract    s31, v27, #4
    v.splat      v18, s31
    v.ld.w       v19, [s38, #0]
    s.addi       s31, s33, #320
    vf.mul       v21, v19, v16
    s.movz       s34, #5
    vf.mul       v16, v21, v34
    vf.add       v19, v13, v16
    s.addi       s38, s30, #13632
    v.st.w       [s11, #0], v19
    a.vread      v13, a3, s35
    v.extract    s11, v27, #5
    v.splat      v16, s11
    v.ld.w       v19, [s37, #0]
    s.addi       s11, s33, #384
    vf.mul       v21, v19, v18
    s.movz       s35, #6
    vf.mul       v18, v21, v34
    vf.add       v19, v13, v18
    s.addi       s37, s30, #13696
    v.st.w       [s32, #0], v19
    a.vread      v13, a3, s34
    v.extract    s32, v27, #6
    v.splat      v18, s32
    v.ld.w       v19, [s38, #0]
    s.addi       s32, s33, #448
    vf.mul       v21, v19, v16
    s.movz       s34, #7
    vf.mul       v16, v21, v34
    vf.add       v19, v13, v16
    s.addi       s38, s30, #13760
    v.st.w       [s31, #0], v19
    a.vread      v13, a3, s35
    v.extract    s31, v27, #7
    v.splat      v16, s31
    v.ld.w       v19, [s37, #0]
    s.addi       s31, s33, #512
    vf.mul       v21, v19, v18
    s.movz       s35, #8
    vf.mul       v18, v21, v34
    vf.add       v19, v13, v18
    s.addi       s37, s30, #13824
    v.st.w       [s11, #0], v19
    a.vread      v13, a3, s34
    v.extract    s11, v27, #8
    v.splat      v18, s11
    v.ld.w       v19, [s38, #0]
    s.addi       s11, s33, #576
    vf.mul       v21, v19, v16
    s.movz       s34, #9
    vf.mul       v16, v21, v34
    vf.add       v19, v13, v16
    s.addi       s38, s30, #13888
    v.st.w       [s32, #0], v19
    a.vread      v13, a3, s35
    v.extract    s32, v27, #9
    v.splat      v16, s32
    v.ld.w       v19, [s37, #0]
    s.addi       s32, s33, #640
    vf.mul       v21, v19, v18
    s.movz       s35, #10
    vf.mul       v18, v21, v34
    vf.add       v19, v13, v18
    s.addi       s37, s30, #13952
    v.st.w       [s31, #0], v19
    a.vread      v13, a3, s34
    v.extract    s31, v27, #10
    v.splat      v18, s31
    v.ld.w       v19, [s38, #0]
    s.addi       s31, s33, #704
    vf.mul       v21, v19, v16
    s.movz       s34, #11
    vf.mul       v16, v21, v34
    vf.add       v19, v13, v16
    s.addi       s38, s30, #14016
    v.st.w       [s11, #0], v19
    a.vread      v13, a3, s35
    v.extract    s11, v27, #11
    v.splat      v16, s11
    v.ld.w       v19, [s37, #0]
    s.addi       s11, s33, #768
    vf.mul       v21, v19, v18
    s.movz       s35, #12
    vf.mul       v18, v21, v34
    vf.add       v19, v13, v18
    s.addi       s37, s30, #14080
    v.st.w       [s32, #0], v19
    a.vread      v13, a3, s34
    v.extract    s32, v27, #12
    v.splat      v18, s32
    v.ld.w       v19, [s38, #0]
    s.addi       s32, s33, #832
    vf.mul       v21, v19, v16
    s.movz       s34, #13
    vf.mul       v16, v21, v34
    vf.add       v19, v13, v16
    s.addi       s38, s30, #14144
    v.st.w       [s31, #0], v19
    a.vread      v13, a3, s35
    v.extract    s31, v27, #13
    v.splat      v16, s31
    v.ld.w       v19, [s37, #0]
    s.addi       s31, s33, #896
    vf.mul       v21, v19, v18
    s.movz       s35, #14
    vf.mul       v18, v21, v34
    vf.add       v19, v13, v18
    s.addi       s37, s30, #14208
    v.st.w       [s11, #0], v19
    a.vread      v13, a3, s34
    v.extract    s11, v27, #14
    v.splat      v18, s11
    v.ld.w       v19, [s38, #0]
    s.addi       s11, s33, #960
    vf.mul       v21, v19, v16
    s.movz       s33, #15
    vf.mul       v16, v21, v34
    vf.add       v19, v13, v16
    s.addi       s34, s30, #14272
    v.st.w       [s32, #0], v19
    a.vread      v13, a3, s35
    v.extract    s32, v27, #15
    v.splat      v16, s32
    v.ld.w       v19, [s37, #0]
    vf.mul       v21, v19, v18
    s.addi       s32, s30, #22528
    vf.mul       v18, v21, v34
    s.movz       s35, #0
    vf.add       v19, v13, v18
    v.st.w       [s31, #0], v19
    a.vread      v13, a3, s33
    s.addi       s31, s30, #14336
    v.extract    s33, v27, #0
    v.splat      v18, s33
    v.ld.w       v19, [s34, #0]
    vf.mul       v21, v19, v16
    s.addi       s33, s32, #64
    vf.mul       v16, v21, v34
    s.movz       s34, #1
    vf.add       v19, v13, v16
    v.st.w       [s11, #0], v19
    fence.acq_rel.device
    a.vread      v13, a4, s35
    s.addi       s11, s30, #14400
    v.extract    s35, v27, #1
    v.splat      v16, s35
    v.ld.w       v19, [s31, #0]
    s.addi       s31, s32, #128
    vf.mul       v21, v19, v18
    s.movz       s35, #2
    vf.mul       v18, v21, v36
    vf.add       v19, v13, v18
    s.addi       s37, s30, #14464
    v.st.w       [s32, #0], v19
    a.vread      v13, a4, s34
    v.extract    s34, v27, #2
    v.splat      v18, s34
    v.ld.w       v19, [s11, #0]
    s.addi       s11, s32, #192
    vf.mul       v21, v19, v16
    s.movz       s34, #3
    vf.mul       v16, v21, v36
    vf.add       v19, v13, v16
    s.addi       s38, s30, #14528
    v.st.w       [s33, #0], v19
    a.vread      v13, a4, s35
    v.extract    s33, v27, #3
    v.splat      v16, s33
    v.ld.w       v19, [s37, #0]
    s.addi       s33, s32, #256
    vf.mul       v21, v19, v18
    s.movz       s35, #4
    vf.mul       v18, v21, v36
    vf.add       v19, v13, v18
    s.addi       s37, s30, #14592
    v.st.w       [s31, #0], v19
    a.vread      v13, a4, s34
    v.extract    s31, v27, #4
    v.splat      v18, s31
    v.ld.w       v19, [s38, #0]
    s.addi       s31, s32, #320
    vf.mul       v21, v19, v16
    s.movz       s34, #5
    vf.mul       v16, v21, v36
    vf.add       v19, v13, v16
    s.addi       s38, s30, #14656
    v.st.w       [s11, #0], v19
    a.vread      v13, a4, s35
    v.extract    s11, v27, #5
    v.splat      v16, s11
    v.ld.w       v19, [s37, #0]
    s.addi       s11, s32, #384
    vf.mul       v21, v19, v18
    s.movz       s35, #6
    vf.mul       v18, v21, v36
    vf.add       v19, v13, v18
    s.addi       s37, s30, #14720
    v.st.w       [s33, #0], v19
    a.vread      v13, a4, s34
    v.extract    s33, v27, #6
    v.splat      v18, s33
    v.ld.w       v19, [s38, #0]
    s.addi       s33, s32, #448
    vf.mul       v21, v19, v16
    s.movz       s34, #7
    vf.mul       v16, v21, v36
    vf.add       v19, v13, v16
    s.addi       s38, s30, #14784
    v.st.w       [s31, #0], v19
    a.vread      v13, a4, s35
    v.extract    s31, v27, #7
    v.splat      v16, s31
    v.ld.w       v19, [s37, #0]
    s.addi       s31, s32, #512
    vf.mul       v21, v19, v18
    s.movz       s35, #8
    vf.mul       v18, v21, v36
    vf.add       v19, v13, v18
    s.addi       s37, s30, #14848
    v.st.w       [s11, #0], v19
    a.vread      v13, a4, s34
    v.extract    s11, v27, #8
    v.splat      v18, s11
    v.ld.w       v19, [s38, #0]
    s.addi       s11, s32, #576
    vf.mul       v21, v19, v16
    s.movz       s34, #9
    vf.mul       v16, v21, v36
    vf.add       v19, v13, v16
    s.addi       s38, s30, #14912
    v.st.w       [s33, #0], v19
    a.vread      v13, a4, s35
    v.extract    s33, v27, #9
    v.splat      v16, s33
    v.ld.w       v19, [s37, #0]
    s.addi       s33, s32, #640
    vf.mul       v21, v19, v18
    s.movz       s35, #10
    vf.mul       v18, v21, v36
    vf.add       v19, v13, v18
    s.addi       s37, s30, #14976
    v.st.w       [s31, #0], v19
    a.vread      v13, a4, s34
    v.extract    s31, v27, #10
    v.splat      v18, s31
    v.ld.w       v19, [s38, #0]
    s.addi       s31, s32, #704
    vf.mul       v21, v19, v16
    s.movz       s34, #11
    vf.mul       v16, v21, v36
    vf.add       v19, v13, v16
    s.addi       s38, s30, #15040
    v.st.w       [s11, #0], v19
    a.vread      v13, a4, s35
    v.extract    s11, v27, #11
    v.splat      v16, s11
    v.ld.w       v19, [s37, #0]
    s.addi       s11, s32, #768
    vf.mul       v21, v19, v18
    s.movz       s35, #12
    vf.mul       v18, v21, v36
    vf.add       v19, v13, v18
    s.addi       s37, s30, #15104
    v.st.w       [s33, #0], v19
    a.vread      v13, a4, s34
    v.extract    s33, v27, #12
    v.splat      v18, s33
    v.ld.w       v19, [s38, #0]
    s.addi       s33, s32, #832
    vf.mul       v21, v19, v16
    s.movz       s34, #13
    vf.mul       v16, v21, v36
    vf.add       v19, v13, v16
    s.addi       s38, s30, #15168
    v.st.w       [s31, #0], v19
    a.vread      v13, a4, s35
    v.extract    s31, v27, #13
    v.splat      v16, s31
    v.ld.w       v19, [s37, #0]
    s.addi       s31, s32, #896
    vf.mul       v21, v19, v18
    s.movz       s35, #14
    vf.mul       v18, v21, v36
    vf.add       v19, v13, v18
    s.addi       s37, s30, #15232
    v.st.w       [s11, #0], v19
    a.vread      v13, a4, s34
    v.extract    s11, v27, #14
    v.splat      v18, s11
    v.ld.w       v19, [s38, #0]
    s.addi       s11, s32, #960
    vf.mul       v21, v19, v16
    s.movz       s32, #15
    vf.mul       v16, v21, v36
    vf.add       v19, v13, v16
    s.addi       s34, s30, #15296
    v.st.w       [s33, #0], v19
    a.vread      v13, a4, s35
    v.extract    s33, v27, #15
    v.splat      v16, s33
    v.ld.w       v19, [s37, #0]
    vf.mul       v21, v19, v18
    s.addi       s33, s30, #23552
    vf.mul       v18, v21, v36
    s.movz       s35, #0
    vf.add       v19, v13, v18
    v.st.w       [s31, #0], v19
    a.vread      v13, a4, s32
    s.addi       s31, s30, #15360
    v.extract    s32, v27, #0
    v.splat      v18, s32
    v.ld.w       v19, [s34, #0]
    vf.mul       v21, v19, v16
    s.addi       s32, s33, #64
    vf.mul       v16, v21, v36
    s.movz       s34, #1
    vf.add       v19, v13, v16
    v.st.w       [s11, #0], v19
    fence.acq_rel.device
    a.vread      v13, a5, s35
    s.addi       s11, s30, #15424
    v.extract    s35, v27, #1
    v.splat      v16, s35
    v.ld.w       v19, [s31, #0]
    s.addi       s31, s33, #128
    vf.mul       v21, v19, v18
    s.movz       s35, #2
    vf.mul       v18, v21, v29
    vf.add       v19, v13, v18
    s.addi       s37, s30, #15488
    v.st.w       [s33, #0], v19
    a.vread      v13, a5, s34
    v.extract    s34, v27, #2
    v.splat      v18, s34
    v.ld.w       v19, [s11, #0]
    s.addi       s11, s33, #192
    vf.mul       v21, v19, v16
    s.movz       s34, #3
    vf.mul       v16, v21, v29
    vf.add       v19, v13, v16
    s.addi       s38, s30, #15552
    v.st.w       [s32, #0], v19
    a.vread      v13, a5, s35
    v.extract    s32, v27, #3
    v.splat      v16, s32
    v.ld.w       v19, [s37, #0]
    s.addi       s32, s33, #256
    vf.mul       v21, v19, v18
    s.movz       s35, #4
    vf.mul       v18, v21, v29
    vf.add       v19, v13, v18
    s.addi       s37, s30, #15616
    v.st.w       [s31, #0], v19
    a.vread      v13, a5, s34
    v.extract    s31, v27, #4
    v.splat      v18, s31
    v.ld.w       v19, [s38, #0]
    s.addi       s31, s33, #320
    vf.mul       v21, v19, v16
    s.movz       s34, #5
    vf.mul       v16, v21, v29
    vf.add       v19, v13, v16
    s.addi       s38, s30, #15680
    v.st.w       [s11, #0], v19
    a.vread      v13, a5, s35
    v.extract    s11, v27, #5
    v.splat      v16, s11
    v.ld.w       v19, [s37, #0]
    s.addi       s11, s33, #384
    vf.mul       v21, v19, v18
    s.movz       s35, #6
    vf.mul       v18, v21, v29
    vf.add       v19, v13, v18
    s.addi       s37, s30, #15744
    v.st.w       [s32, #0], v19
    a.vread      v13, a5, s34
    v.extract    s32, v27, #6
    v.splat      v18, s32
    v.ld.w       v19, [s38, #0]
    s.addi       s32, s33, #448
    vf.mul       v21, v19, v16
    s.movz       s34, #7
    vf.mul       v16, v21, v29
    vf.add       v19, v13, v16
    s.addi       s38, s30, #15808
    v.st.w       [s31, #0], v19
    a.vread      v13, a5, s35
    v.extract    s31, v27, #7
    v.splat      v16, s31
    v.ld.w       v19, [s37, #0]
    s.addi       s31, s33, #512
    vf.mul       v21, v19, v18
    s.movz       s35, #8
    vf.mul       v18, v21, v29
    vf.add       v19, v13, v18
    s.addi       s37, s30, #15872
    v.st.w       [s11, #0], v19
    a.vread      v13, a5, s34
    v.extract    s11, v27, #8
    v.splat      v18, s11
    v.ld.w       v19, [s38, #0]
    s.addi       s11, s33, #576
    vf.mul       v21, v19, v16
    s.movz       s34, #9
    vf.mul       v16, v21, v29
    vf.add       v19, v13, v16
    s.addi       s38, s30, #15936
    v.st.w       [s32, #0], v19
    a.vread      v13, a5, s35
    v.extract    s32, v27, #9
    v.splat      v16, s32
    v.ld.w       v19, [s37, #0]
    s.addi       s32, s33, #640
    vf.mul       v21, v19, v18
    s.movz       s35, #10
    vf.mul       v18, v21, v29
    vf.add       v19, v13, v18
    s.addi       s37, s30, #16000
    v.st.w       [s31, #0], v19
    a.vread      v13, a5, s34
    v.extract    s31, v27, #10
    v.splat      v18, s31
    v.ld.w       v19, [s38, #0]
    s.addi       s31, s33, #704
    vf.mul       v21, v19, v16
    s.movz       s34, #11
    vf.mul       v16, v21, v29
    vf.add       v19, v13, v16
    s.addi       s38, s30, #16064
    v.st.w       [s11, #0], v19
    a.vread      v13, a5, s35
    v.extract    s11, v27, #11
    v.splat      v16, s11
    v.ld.w       v19, [s37, #0]
    s.addi       s11, s33, #768
    vf.mul       v21, v19, v18
    s.movz       s35, #12
    vf.mul       v18, v21, v29
    vf.add       v19, v13, v18
    s.addi       s37, s30, #16128
    v.st.w       [s32, #0], v19
    a.vread      v13, a5, s34
    v.extract    s32, v27, #12
    v.splat      v18, s32
    v.ld.w       v19, [s38, #0]
    s.addi       s32, s33, #832
    vf.mul       v21, v19, v16
    s.movz       s34, #13
    vf.mul       v16, v21, v29
    vf.add       v19, v13, v16
    s.addi       s38, s30, #16192
    v.st.w       [s31, #0], v19
    a.vread      v13, a5, s35
    v.extract    s31, v27, #13
    v.splat      v16, s31
    v.ld.w       v19, [s37, #0]
    s.addi       s31, s33, #896
    vf.mul       v21, v19, v18
    s.movz       s35, #14
    vf.mul       v18, v21, v29
    vf.add       v19, v13, v18
    s.addi       s37, s30, #16256
    v.st.w       [s11, #0], v19
    a.vread      v13, a5, s34
    v.extract    s11, v27, #14
    v.splat      v18, s11
    v.ld.w       v19, [s38, #0]
    s.addi       s11, s33, #960
    vf.mul       v21, v19, v16
    s.movz       s33, #15
    vf.mul       v16, v21, v29
    vf.add       v19, v13, v16
    s.addi       s34, s30, #16320
    v.st.w       [s32, #0], v19
    a.vread      v13, a5, s35
    v.extract    s32, v27, #15
    v.splat      v16, s32
    v.ld.w       v19, [s37, #0]
    vf.mul       v21, v19, v18
    s.addi       s32, s30, #24576
    vf.mul       v18, v21, v29
    s.movz       s35, #0
    vf.add       v19, v13, v18
    v.st.w       [s31, #0], v19
    a.vread      v13, a5, s33
    s.addi       s31, s30, #16384
    v.extract    s33, v27, #0
    v.splat      v18, s33
    v.ld.w       v19, [s34, #0]
    vf.mul       v21, v19, v16
    s.addi       s33, s32, #64
    vf.mul       v16, v21, v29
    s.movz       s34, #1
    vf.add       v19, v13, v16
    v.st.w       [s11, #0], v19
    fence.acq_rel.device
    a.vread      v13, a6, s35
    s.addi       s11, s30, #16448
    v.extract    s35, v27, #1
    v.splat      v16, s35
    v.ld.w       v19, [s31, #0]
    s.addi       s31, s32, #128
    vf.mul       v21, v19, v18
    s.movz       s35, #2
    vf.mul       v18, v21, v38
    vf.add       v19, v13, v18
    s.addi       s37, s30, #16512
    v.st.w       [s32, #0], v19
    a.vread      v13, a6, s34
    v.extract    s34, v27, #2
    v.splat      v18, s34
    v.ld.w       v19, [s11, #0]
    s.addi       s11, s32, #192
    vf.mul       v21, v19, v16
    s.movz       s34, #3
    vf.mul       v16, v21, v38
    vf.add       v19, v13, v16
    s.addi       s38, s30, #16576
    v.st.w       [s33, #0], v19
    a.vread      v13, a6, s35
    v.extract    s33, v27, #3
    v.splat      v16, s33
    v.ld.w       v19, [s37, #0]
    s.addi       s33, s32, #256
    vf.mul       v21, v19, v18
    s.movz       s35, #4
    vf.mul       v18, v21, v38
    vf.add       v19, v13, v18
    s.addi       s37, s30, #16640
    v.st.w       [s31, #0], v19
    a.vread      v13, a6, s34
    v.extract    s31, v27, #4
    v.splat      v18, s31
    v.ld.w       v19, [s38, #0]
    s.addi       s31, s32, #320
    vf.mul       v21, v19, v16
    s.movz       s34, #5
    vf.mul       v16, v21, v38
    vf.add       v19, v13, v16
    s.addi       s38, s30, #16704
    v.st.w       [s11, #0], v19
    a.vread      v13, a6, s35
    v.extract    s11, v27, #5
    v.splat      v16, s11
    v.ld.w       v19, [s37, #0]
    s.addi       s11, s32, #384
    vf.mul       v21, v19, v18
    s.movz       s35, #6
    vf.mul       v18, v21, v38
    vf.add       v19, v13, v18
    s.addi       s37, s30, #16768
    v.st.w       [s33, #0], v19
    a.vread      v13, a6, s34
    v.extract    s33, v27, #6
    v.splat      v18, s33
    v.ld.w       v19, [s38, #0]
    s.addi       s33, s32, #448
    vf.mul       v21, v19, v16
    s.movz       s34, #7
    vf.mul       v16, v21, v38
    vf.add       v19, v13, v16
    s.addi       s38, s30, #16832
    v.st.w       [s31, #0], v19
    a.vread      v13, a6, s35
    v.extract    s31, v27, #7
    v.splat      v16, s31
    v.ld.w       v19, [s37, #0]
    s.addi       s31, s32, #512
    vf.mul       v21, v19, v18
    s.movz       s35, #8
    vf.mul       v18, v21, v38
    vf.add       v19, v13, v18
    s.addi       s37, s30, #16896
    v.st.w       [s11, #0], v19
    a.vread      v13, a6, s34
    v.extract    s11, v27, #8
    v.splat      v18, s11
    v.ld.w       v19, [s38, #0]
    s.addi       s11, s32, #576
    vf.mul       v21, v19, v16
    s.movz       s34, #9
    vf.mul       v16, v21, v38
    vf.add       v19, v13, v16
    s.addi       s38, s30, #16960
    v.st.w       [s33, #0], v19
    a.vread      v13, a6, s35
    v.extract    s33, v27, #9
    v.splat      v16, s33
    v.ld.w       v19, [s37, #0]
    s.addi       s33, s32, #640
    vf.mul       v21, v19, v18
    s.movz       s35, #10
    vf.mul       v18, v21, v38
    vf.add       v19, v13, v18
    s.addi       s37, s30, #17024
    v.st.w       [s31, #0], v19
    a.vread      v13, a6, s34
    v.extract    s31, v27, #10
    v.splat      v18, s31
    v.ld.w       v19, [s38, #0]
    s.addi       s31, s32, #704
    vf.mul       v21, v19, v16
    s.movz       s34, #11
    vf.mul       v16, v21, v38
    vf.add       v19, v13, v16
    s.addi       s38, s30, #17088
    v.st.w       [s11, #0], v19
    a.vread      v13, a6, s35
    v.extract    s11, v27, #11
    v.splat      v16, s11
    v.ld.w       v19, [s37, #0]
    s.addi       s11, s32, #768
    vf.mul       v21, v19, v18
    s.movz       s35, #12
    vf.mul       v18, v21, v38
    vf.add       v19, v13, v18
    s.addi       s37, s30, #17152
    v.st.w       [s33, #0], v19
    a.vread      v13, a6, s34
    v.extract    s33, v27, #12
    v.splat      v18, s33
    v.ld.w       v19, [s38, #0]
    s.addi       s33, s32, #832
    vf.mul       v21, v19, v16
    s.movz       s34, #13
    vf.mul       v16, v21, v38
    vf.add       v19, v13, v16
    s.addi       s38, s30, #17216
    v.st.w       [s31, #0], v19
    a.vread      v13, a6, s35
    v.extract    s31, v27, #13
    v.splat      v16, s31
    v.ld.w       v19, [s37, #0]
    s.addi       s31, s32, #896
    vf.mul       v21, v19, v18
    s.movz       s35, #14
    vf.mul       v18, v21, v38
    vf.add       v19, v13, v18
    s.addi       s37, s30, #17280
    v.st.w       [s11, #0], v19
    a.vread      v13, a6, s34
    v.extract    s11, v27, #14
    v.splat      v18, s11
    v.ld.w       v19, [s38, #0]
    s.addi       s11, s32, #960
    vf.mul       v21, v19, v16
    s.movz       s32, #15
    vf.mul       v16, v21, v38
    vf.add       v19, v13, v16
    s.addi       s34, s30, #17344
    v.st.w       [s33, #0], v19
    a.vread      v13, a6, s35
    v.extract    s33, v27, #15
    v.splat      v16, s33
    v.ld.w       v19, [s37, #0]
    vf.mul       v21, v19, v18
    s.addi       s33, s30, #25600
    vf.mul       v18, v21, v38
    s.movz       s35, #0
    vf.add       v19, v13, v18
    v.st.w       [s31, #0], v19
    a.vread      v13, a6, s32
    s.addi       s31, s30, #17408
    v.extract    s32, v27, #0
    v.splat      v18, s32
    v.ld.w       v19, [s34, #0]
    vf.mul       v21, v19, v16
    s.addi       s32, s33, #64
    vf.mul       v16, v21, v38
    s.movz       s34, #1
    vf.add       v19, v13, v16
    v.st.w       [s11, #0], v19
    fence.acq_rel.device
    a.vread      v13, a7, s35
    s.addi       s11, s30, #17472
    v.extract    s35, v27, #1
    v.splat      v16, s35
    v.ld.w       v19, [s31, #0]
    s.addi       s31, s33, #128
    vf.mul       v21, v19, v18
    s.movz       s35, #2
    vf.mul       v18, v21, v35
    vf.add       v19, v13, v18
    s.addi       s37, s30, #17536
    v.st.w       [s33, #0], v19
    a.vread      v13, a7, s34
    v.extract    s34, v27, #2
    v.splat      v18, s34
    v.ld.w       v19, [s11, #0]
    s.addi       s11, s33, #192
    vf.mul       v21, v19, v16
    s.movz       s34, #3
    vf.mul       v16, v21, v35
    vf.add       v19, v13, v16
    s.addi       s38, s30, #17600
    v.st.w       [s32, #0], v19
    a.vread      v13, a7, s35
    v.extract    s32, v27, #3
    v.splat      v16, s32
    v.ld.w       v19, [s37, #0]
    s.addi       s32, s33, #256
    vf.mul       v21, v19, v18
    s.movz       s35, #4
    vf.mul       v18, v21, v35
    vf.add       v19, v13, v18
    s.addi       s37, s30, #17664
    v.st.w       [s31, #0], v19
    a.vread      v13, a7, s34
    v.extract    s31, v27, #4
    v.splat      v18, s31
    v.ld.w       v19, [s38, #0]
    s.addi       s31, s33, #320
    vf.mul       v21, v19, v16
    s.movz       s34, #5
    vf.mul       v16, v21, v35
    vf.add       v19, v13, v16
    s.addi       s38, s30, #17728
    v.st.w       [s11, #0], v19
    a.vread      v13, a7, s35
    v.extract    s11, v27, #5
    v.splat      v16, s11
    v.ld.w       v19, [s37, #0]
    s.addi       s11, s33, #384
    vf.mul       v21, v19, v18
    s.movz       s35, #6
    vf.mul       v18, v21, v35
    vf.add       v19, v13, v18
    s.addi       s37, s30, #17792
    v.st.w       [s32, #0], v19
    a.vread      v13, a7, s34
    v.extract    s32, v27, #6
    v.splat      v18, s32
    v.ld.w       v19, [s38, #0]
    s.addi       s32, s33, #448
    vf.mul       v21, v19, v16
    s.movz       s34, #7
    vf.mul       v16, v21, v35
    vf.add       v19, v13, v16
    s.addi       s38, s30, #17856
    v.st.w       [s31, #0], v19
    a.vread      v13, a7, s35
    v.extract    s31, v27, #7
    v.splat      v16, s31
    v.ld.w       v19, [s37, #0]
    s.addi       s31, s33, #512
    vf.mul       v21, v19, v18
    s.movz       s35, #8
    vf.mul       v18, v21, v35
    vf.add       v19, v13, v18
    s.addi       s37, s30, #17920
    v.st.w       [s11, #0], v19
    a.vread      v13, a7, s34
    v.extract    s11, v27, #8
    v.splat      v18, s11
    v.ld.w       v19, [s38, #0]
    s.addi       s11, s33, #576
    vf.mul       v21, v19, v16
    s.movz       s34, #9
    vf.mul       v16, v21, v35
    vf.add       v19, v13, v16
    s.addi       s38, s30, #17984
    v.st.w       [s32, #0], v19
    a.vread      v13, a7, s35
    v.extract    s32, v27, #9
    v.splat      v16, s32
    v.ld.w       v19, [s37, #0]
    s.addi       s32, s33, #640
    vf.mul       v21, v19, v18
    s.movz       s35, #10
    vf.mul       v18, v21, v35
    vf.add       v19, v13, v18
    s.addi       s37, s30, #18048
    v.st.w       [s31, #0], v19
    a.vread      v13, a7, s34
    v.extract    s31, v27, #10
    v.splat      v18, s31
    v.ld.w       v19, [s38, #0]
    s.addi       s31, s33, #704
    vf.mul       v21, v19, v16
    s.movz       s34, #11
    vf.mul       v16, v21, v35
    vf.add       v19, v13, v16
    s.addi       s38, s30, #18112
    v.st.w       [s11, #0], v19
    a.vread      v13, a7, s35
    v.extract    s11, v27, #11
    v.splat      v16, s11
    v.ld.w       v19, [s37, #0]
    s.addi       s11, s33, #768
    vf.mul       v21, v19, v18
    s.movz       s35, #12
    vf.mul       v18, v21, v35
    vf.add       v19, v13, v18
    s.addi       s37, s30, #18176
    v.st.w       [s32, #0], v19
    a.vread      v13, a7, s34
    v.extract    s32, v27, #12
    v.splat      v18, s32
    v.ld.w       v19, [s38, #0]
    s.addi       s32, s33, #832
    vf.mul       v21, v19, v16
    s.movz       s34, #13
    vf.mul       v16, v21, v35
    vf.add       v19, v13, v16
    s.addi       s38, s30, #18240
    v.st.w       [s31, #0], v19
    a.vread      v13, a7, s35
    v.extract    s31, v27, #13
    v.splat      v16, s31
    v.ld.w       v19, [s37, #0]
    s.addi       s31, s33, #896
    vf.mul       v21, v19, v18
    s.movz       s35, #14
    vf.mul       v18, v21, v35
    vf.add       v19, v13, v18
    s.addi       s37, s30, #18304
    v.st.w       [s11, #0], v19
    a.vread      v13, a7, s34
    v.extract    s11, v27, #14
    v.splat      v18, s11
    v.ld.w       v19, [s38, #0]
    s.addi       s11, s33, #960
    vf.mul       v21, v19, v16
    s.movz       s33, #15
    vf.mul       v16, v21, v35
    vf.add       v19, v13, v16
    s.addi       s34, s30, #18368
    v.st.w       [s32, #0], v19
    a.vread      v13, a7, s35
    v.extract    s32, v27, #15
    v.splat      v16, s32
    v.ld.w       v19, [s37, #0]
    vf.mul       v21, v19, v18
    s.addi       s32, s27, #128
    vf.mul       v18, v21, v35
    s.addi       s35, s32, #0
    vf.add       v19, v13, v18
    s.addi       s32, s24, #128
    v.st.w       [s31, #0], v19
    a.vread      v13, a7, s33
    s.addi       s31, s16, #4                    // &ptr_carry_18[1] (a constant offset, x4)
    s.addi       s33, s32, #0
    s.addi       s32, s31, #0
    s.addi       s31, s16, #4                    // &ptr_carry_19[1] (a constant offset, x4)
    s.addi       s31, s16, #4                    // &ptr_carry_20[1] (a constant offset, x4)
    v.ld.w       v18, [s34, #0]
    s.addi       s31, s16, #4                    // &ptr_carry_21[1] (a constant offset, x4)
    s.addi       s31, s16, #4                    // &ptr_carry_22[1] (a constant offset, x4)
    s.addi       s31, s16, #4                    // &ptr_carry_23[1] (a constant offset, x4)
    vf.mul       v19, v18, v16
    s.addi       s31, s16, #4                    // &ptr_carry_24[1] (a constant offset, x4)
    vf.mul       v16, v19, v35
    s.addi       s31, s16, #4                    // &ptr_carry_25[1] (a constant offset, x4)
    vf.add       v18, v13, v16
    v.st.w       [s11, #0], v18
    fence.acq_rel.device
    s.addi       s11, s30, #18432
    s.mov        s27, s35
    s.mov        s24, s33
    s.mov        s16, s32
    s.movz       s31, #0
    s.addi       s32, s30, #18496
    s.movz       s33, #1
    s.addi       s34, s30, #18560
    s.movz       s35, #2
    s.addi       s37, s30, #18624
    s.movz       s38, #3
    s.addi       s39, s30, #18688
    s.movz       s40, #4
    v.ld.w       v13, [s11, #0]
    a.vwrite     a0, s31, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s11, s30, #18752
    s.movz       s31, #5
    a.vwrite     a0, s33, v13
    v.ld.w       v13, [s34, #0]
    s.addi       s32, s30, #18816
    s.movz       s33, #6
    a.vwrite     a0, s35, v13
    v.ld.w       v13, [s37, #0]
    s.addi       s34, s30, #18880
    s.movz       s35, #7
    a.vwrite     a0, s38, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s37, s30, #18944
    s.movz       s38, #8
    a.vwrite     a0, s40, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #19008
    s.movz       s39, #9
    a.vwrite     a0, s31, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s31, s30, #19072
    s.movz       s32, #10
    a.vwrite     a0, s33, v13
    v.ld.w       v13, [s34, #0]
    s.addi       s33, s30, #19136
    s.movz       s34, #11
    a.vwrite     a0, s35, v13
    v.ld.w       v13, [s37, #0]
    s.addi       s35, s30, #19200
    s.movz       s37, #12
    a.vwrite     a0, s38, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #19264
    s.movz       s38, #13
    a.vwrite     a0, s39, v13
    v.ld.w       v13, [s31, #0]
    s.addi       s31, s30, #19328
    s.movz       s39, #14
    a.vwrite     a0, s32, v13
    v.ld.w       v13, [s33, #0]
    s.addi       s32, s30, #19392
    s.movz       s33, #15
    a.vwrite     a0, s34, v13
    v.ld.w       v13, [s35, #0]
    s.addi       s34, s30, #19456
    s.movz       s35, #0
    a.vwrite     a0, s37, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #19520
    s.movz       s37, #1
    a.vwrite     a0, s38, v13
    v.ld.w       v13, [s31, #0]
    s.addi       s31, s30, #19584
    s.movz       s38, #2
    a.vwrite     a0, s39, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s32, s30, #19648
    s.movz       s39, #3
    a.vwrite     a0, s33, v13
    v.ld.w       v13, [s34, #0]
    s.addi       s33, s30, #19712
    s.movz       s34, #4
    a.vwrite     a1, s35, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #19776
    s.movz       s35, #5
    a.vwrite     a1, s37, v13
    v.ld.w       v13, [s31, #0]
    s.addi       s31, s30, #19840
    s.movz       s37, #6
    a.vwrite     a1, s38, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s32, s30, #19904
    s.movz       s38, #7
    a.vwrite     a1, s39, v13
    v.ld.w       v13, [s33, #0]
    s.addi       s33, s30, #19968
    s.movz       s39, #8
    a.vwrite     a1, s34, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #20032
    s.movz       s34, #9
    a.vwrite     a1, s35, v13
    v.ld.w       v13, [s31, #0]
    s.addi       s31, s30, #20096
    s.movz       s35, #10
    a.vwrite     a1, s37, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s32, s30, #20160
    s.movz       s37, #11
    a.vwrite     a1, s38, v13
    v.ld.w       v13, [s33, #0]
    s.addi       s33, s30, #20224
    s.movz       s38, #12
    a.vwrite     a1, s39, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #20288
    s.movz       s39, #13
    a.vwrite     a1, s34, v13
    v.ld.w       v13, [s31, #0]
    s.addi       s31, s30, #20352
    s.movz       s34, #14
    a.vwrite     a1, s35, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s32, s30, #20416
    s.movz       s35, #15
    a.vwrite     a1, s37, v13
    v.ld.w       v13, [s33, #0]
    s.addi       s33, s30, #20480
    s.movz       s37, #0
    a.vwrite     a1, s38, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #20544
    s.movz       s38, #1
    a.vwrite     a1, s39, v13
    v.ld.w       v13, [s31, #0]
    s.addi       s31, s30, #20608
    s.movz       s39, #2
    a.vwrite     a1, s34, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s32, s30, #20672
    s.movz       s34, #3
    a.vwrite     a1, s35, v13
    v.ld.w       v13, [s33, #0]
    s.addi       s33, s30, #20736
    s.movz       s35, #4
    a.vwrite     a2, s37, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #20800
    s.movz       s37, #5
    a.vwrite     a2, s38, v13
    v.ld.w       v13, [s31, #0]
    s.addi       s31, s30, #20864
    s.movz       s38, #6
    a.vwrite     a2, s39, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s32, s30, #20928
    s.movz       s39, #7
    a.vwrite     a2, s34, v13
    v.ld.w       v13, [s33, #0]
    s.addi       s33, s30, #20992
    s.movz       s34, #8
    a.vwrite     a2, s35, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #21056
    s.movz       s35, #9
    a.vwrite     a2, s37, v13
    v.ld.w       v13, [s31, #0]
    s.addi       s31, s30, #21120
    s.movz       s37, #10
    a.vwrite     a2, s38, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s32, s30, #21184
    s.movz       s38, #11
    a.vwrite     a2, s39, v13
    v.ld.w       v13, [s33, #0]
    s.addi       s33, s30, #21248
    s.movz       s39, #12
    a.vwrite     a2, s34, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #21312
    s.movz       s34, #13
    a.vwrite     a2, s35, v13
    v.ld.w       v13, [s31, #0]
    s.addi       s31, s30, #21376
    s.movz       s35, #14
    a.vwrite     a2, s37, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s32, s30, #21440
    s.movz       s37, #15
    a.vwrite     a2, s38, v13
    v.ld.w       v13, [s33, #0]
    s.addi       s33, s30, #21504
    s.movz       s38, #0
    a.vwrite     a2, s39, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #21568
    s.movz       s39, #1
    a.vwrite     a2, s34, v13
    v.ld.w       v13, [s31, #0]
    s.addi       s31, s30, #21632
    s.movz       s34, #2
    a.vwrite     a2, s35, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s32, s30, #21696
    s.movz       s35, #3
    a.vwrite     a2, s37, v13
    v.ld.w       v13, [s33, #0]
    s.addi       s33, s30, #21760
    s.movz       s37, #4
    a.vwrite     a3, s38, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #21824
    s.movz       s38, #5
    a.vwrite     a3, s39, v13
    v.ld.w       v13, [s31, #0]
    s.addi       s31, s30, #21888
    s.movz       s39, #6
    a.vwrite     a3, s34, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s32, s30, #21952
    s.movz       s34, #7
    a.vwrite     a3, s35, v13
    v.ld.w       v13, [s33, #0]
    s.addi       s33, s30, #22016
    s.movz       s35, #8
    a.vwrite     a3, s37, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #22080
    s.movz       s37, #9
    a.vwrite     a3, s38, v13
    v.ld.w       v13, [s31, #0]
    s.addi       s31, s30, #22144
    s.movz       s38, #10
    a.vwrite     a3, s39, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s32, s30, #22208
    s.movz       s39, #11
    a.vwrite     a3, s34, v13
    v.ld.w       v13, [s33, #0]
    s.addi       s33, s30, #22272
    s.movz       s34, #12
    a.vwrite     a3, s35, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #22336
    s.movz       s35, #13
    a.vwrite     a3, s37, v13
    v.ld.w       v13, [s31, #0]
    s.addi       s31, s30, #22400
    s.movz       s37, #14
    a.vwrite     a3, s38, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s32, s30, #22464
    s.movz       s38, #15
    a.vwrite     a3, s39, v13
    v.ld.w       v13, [s33, #0]
    s.addi       s33, s30, #22528
    s.movz       s39, #0
    a.vwrite     a3, s34, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #22592
    s.movz       s34, #1
    a.vwrite     a3, s35, v13
    v.ld.w       v13, [s31, #0]
    s.addi       s31, s30, #22656
    s.movz       s35, #2
    a.vwrite     a3, s37, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s32, s30, #22720
    s.movz       s37, #3
    a.vwrite     a3, s38, v13
    v.ld.w       v13, [s33, #0]
    s.addi       s33, s30, #22784
    s.movz       s38, #4
    a.vwrite     a4, s39, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #22848
    s.movz       s39, #5
    a.vwrite     a4, s34, v13
    v.ld.w       v13, [s31, #0]
    s.addi       s31, s30, #22912
    s.movz       s34, #6
    a.vwrite     a4, s35, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s32, s30, #22976
    s.movz       s35, #7
    a.vwrite     a4, s37, v13
    v.ld.w       v13, [s33, #0]
    s.addi       s33, s30, #23040
    s.movz       s37, #8
    a.vwrite     a4, s38, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #23104
    s.movz       s38, #9
    a.vwrite     a4, s39, v13
    v.ld.w       v13, [s31, #0]
    s.addi       s31, s30, #23168
    s.movz       s39, #10
    a.vwrite     a4, s34, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s32, s30, #23232
    s.movz       s34, #11
    a.vwrite     a4, s35, v13
    v.ld.w       v13, [s33, #0]
    s.addi       s33, s30, #23296
    s.movz       s35, #12
    a.vwrite     a4, s37, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #23360
    s.movz       s37, #13
    a.vwrite     a4, s38, v13
    v.ld.w       v13, [s31, #0]
    s.addi       s31, s30, #23424
    s.movz       s38, #14
    a.vwrite     a4, s39, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s32, s30, #23488
    s.movz       s39, #15
    a.vwrite     a4, s34, v13
    v.ld.w       v13, [s33, #0]
    s.addi       s33, s30, #23552
    s.movz       s34, #0
    a.vwrite     a4, s35, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #23616
    s.movz       s35, #1
    a.vwrite     a4, s37, v13
    v.ld.w       v13, [s31, #0]
    s.addi       s31, s30, #23680
    s.movz       s37, #2
    a.vwrite     a4, s38, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s32, s30, #23744
    s.movz       s38, #3
    a.vwrite     a4, s39, v13
    v.ld.w       v13, [s33, #0]
    s.addi       s33, s30, #23808
    s.movz       s39, #4
    a.vwrite     a5, s34, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #23872
    s.movz       s34, #5
    a.vwrite     a5, s35, v13
    v.ld.w       v13, [s31, #0]
    s.addi       s31, s30, #23936
    s.movz       s35, #6
    a.vwrite     a5, s37, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s32, s30, #24000
    s.movz       s37, #7
    a.vwrite     a5, s38, v13
    v.ld.w       v13, [s33, #0]
    s.addi       s33, s30, #24064
    s.movz       s38, #8
    a.vwrite     a5, s39, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #24128
    s.movz       s39, #9
    a.vwrite     a5, s34, v13
    v.ld.w       v13, [s31, #0]
    s.addi       s31, s30, #24192
    s.movz       s34, #10
    a.vwrite     a5, s35, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s32, s30, #24256
    s.movz       s35, #11
    a.vwrite     a5, s37, v13
    v.ld.w       v13, [s33, #0]
    s.addi       s33, s30, #24320
    s.movz       s37, #12
    a.vwrite     a5, s38, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #24384
    s.movz       s38, #13
    a.vwrite     a5, s39, v13
    v.ld.w       v13, [s31, #0]
    s.addi       s31, s30, #24448
    s.movz       s39, #14
    a.vwrite     a5, s34, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s32, s30, #24512
    s.movz       s34, #15
    a.vwrite     a5, s35, v13
    v.ld.w       v13, [s33, #0]
    s.addi       s33, s30, #24576
    s.movz       s35, #0
    a.vwrite     a5, s37, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #24640
    s.movz       s37, #1
    a.vwrite     a5, s38, v13
    v.ld.w       v13, [s31, #0]
    s.addi       s31, s30, #24704
    s.movz       s38, #2
    a.vwrite     a5, s39, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s32, s30, #24768
    s.movz       s39, #3
    a.vwrite     a5, s34, v13
    v.ld.w       v13, [s33, #0]
    s.addi       s33, s30, #24832
    s.movz       s34, #4
    a.vwrite     a6, s35, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #24896
    s.movz       s35, #5
    a.vwrite     a6, s37, v13
    v.ld.w       v13, [s31, #0]
    s.addi       s31, s30, #24960
    s.movz       s37, #6
    a.vwrite     a6, s38, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s32, s30, #25024
    s.movz       s38, #7
    a.vwrite     a6, s39, v13
    v.ld.w       v13, [s33, #0]
    s.addi       s33, s30, #25088
    s.movz       s39, #8
    a.vwrite     a6, s34, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #25152
    s.movz       s34, #9
    a.vwrite     a6, s35, v13
    v.ld.w       v13, [s31, #0]
    s.addi       s31, s30, #25216
    s.movz       s35, #10
    a.vwrite     a6, s37, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s32, s30, #25280
    s.movz       s37, #11
    a.vwrite     a6, s38, v13
    v.ld.w       v13, [s33, #0]
    s.addi       s33, s30, #25344
    s.movz       s38, #12
    a.vwrite     a6, s39, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #25408
    s.movz       s39, #13
    a.vwrite     a6, s34, v13
    v.ld.w       v13, [s31, #0]
    s.addi       s31, s30, #25472
    s.movz       s34, #14
    a.vwrite     a6, s35, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s32, s30, #25536
    s.movz       s35, #15
    a.vwrite     a6, s37, v13
    v.ld.w       v13, [s33, #0]
    s.addi       s33, s30, #25600
    s.movz       s37, #0
    a.vwrite     a6, s38, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #25664
    s.movz       s38, #1
    a.vwrite     a6, s39, v13
    v.ld.w       v13, [s31, #0]
    s.addi       s31, s30, #25728
    s.movz       s39, #2
    a.vwrite     a6, s34, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s32, s30, #25792
    s.movz       s34, #3
    a.vwrite     a6, s35, v13
    v.ld.w       v13, [s33, #0]
    s.addi       s33, s30, #25856
    s.movz       s35, #4
    a.vwrite     a7, s37, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #25920
    s.movz       s37, #5
    a.vwrite     a7, s38, v13
    v.ld.w       v13, [s31, #0]
    s.addi       s31, s30, #25984
    s.movz       s38, #6
    a.vwrite     a7, s39, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s32, s30, #26048
    s.movz       s39, #7
    a.vwrite     a7, s34, v13
    v.ld.w       v13, [s33, #0]
    s.addi       s33, s30, #26112
    s.movz       s34, #8
    a.vwrite     a7, s35, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #26176
    s.movz       s35, #9
    a.vwrite     a7, s37, v13
    v.ld.w       v13, [s31, #0]
    s.addi       s31, s30, #26240
    s.movz       s37, #10
    a.vwrite     a7, s38, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s32, s30, #26304
    s.movz       s38, #11
    a.vwrite     a7, s39, v13
    v.ld.w       v13, [s33, #0]
    s.addi       s33, s30, #26368
    s.movz       s39, #12
    a.vwrite     a7, s34, v13
    v.ld.w       v13, [s11, #0]
    s.addi       s11, s30, #26432
    s.movz       s34, #13
    a.vwrite     a7, s35, v13
    v.ld.w       v13, [s31, #0]
    s.addi       s31, s30, #26496
    s.movz       s35, #14
    a.vwrite     a7, s37, v13
    v.ld.w       v13, [s32, #0]
    s.addi       s32, s30, #26560
    s.movz       s30, #15
    a.vwrite     a7, s38, v13
    v.ld.w       v13, [s33, #0]
    s.add        s33, s26, s1
    s.movz       s37, #1
    a.vwrite     a7, s39, v13
    v.ld.w       v13, [s11, #0]
    a.vwrite     a7, s34, v13
    v.ld.w       v13, [s31, #0]
    a.vwrite     a7, s35, v13
    v.ld.w       v13, [s32, #0]
    a.vwrite     a7, s30, v13
    s.mov        s26, s33
    br.nz        s37, for_26
endfor_27:
    s.mul        s1, s4, s8
    s.movz       s2, #0
    s.muli       s6, s5, #2
    a.vread      v0, a0, s2
    s.muli       s2, s8, #2
    s.muli       s8, s1, #2
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s5, #16
    s.movz       s9, #0
    s.addi       s10, s5, #32
    s.add        s11, s9, s4                     // the tile origin
    s.add        s4, s8, s6
    s.addi       s9, s5, #48
    v.splat      v0, s11
    s.add        s13, s12, s4
    s.addi       s4, s5, #64
    s.movz       s14, #0
    s.addi       s15, s5, #80
    s.add        s16, s14, s7                    // the tile origin
    s.addi       s7, s5, #96
    v.splat      v2, s16
    s.addi       s14, s5, #112
    s.movz       s16, #0
    s.movz       s17, #0
    s.add        s18, s16, s5                    // the tile origin
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v4, s18
    s.add        s5, s17, s3                     // the tile origin
    v.cmp.lt     p1, v0, v2
    v.add        v0, v3, v4
    v.splat      v4, s5
    s.muli       s5, s2, #1
    s.movz       s16, #1
    v.cmp.lt     p2, v0, v4
    p.and        p3, p1, p2
    s.addi       s17, s11, #1
    @p3 v.st.h       [s13, #0], v1
    a.vread      v0, a0, s16
    s.add        s13, s5, s8
    v.splat      v1, s17
    vf.cvt.f32.bf16 v4, v0
    s.add        s5, s13, s6
    v.cmp.lt     p1, v1, v2
    s.muli       s13, s2, #2
    s.add        s16, s12, s5
    p.and        p3, p1, p2
    s.movz       s5, #2
    s.addi       s17, s11, #2
    s.add        s18, s13, s8
    v.splat      v0, s17
    @p3 v.st.h       [s16, #0], v4
    a.vread      v1, a0, s5
    s.add        s5, s18, s6
    v.cmp.lt     p1, v0, v2
    vf.cvt.f32.bf16 v0, v1
    s.muli       s13, s2, #3
    s.add        s16, s12, s5
    p.and        p3, p1, p2
    s.movz       s5, #3
    s.addi       s17, s11, #3
    s.add        s18, s13, s8
    v.splat      v1, s17
    s.add        s13, s18, s6
    s.movz       s17, #4
    @p3 v.st.h       [s16, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p1, v1, v2
    s.muli       s5, s2, #4
    vf.cvt.f32.bf16 v1, v0
    s.add        s16, s12, s13
    p.and        p3, p1, p2
    s.addi       s13, s11, #4
    s.add        s18, s5, s8
    v.splat      v0, s13
    s.add        s5, s18, s6
    s.movz       s13, #5
    s.add        s18, s12, s5
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a0, s17
    v.cmp.lt     p1, v0, v2
    s.muli       s5, s2, #5
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s16, s11, #5
    s.add        s17, s5, s8
    v.splat      v1, s16
    s.add        s5, s17, s6
    s.movz       s16, #6
    s.add        s17, s12, s5
    @p3 v.st.h       [s18, #0], v0
    a.vread      v0, a0, s13
    v.cmp.lt     p1, v1, v2
    s.muli       s5, s2, #6
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s13, s11, #6
    s.add        s18, s5, s8
    v.splat      v0, s13
    s.add        s5, s18, s6
    s.movz       s13, #7
    s.add        s18, s12, s5
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a0, s16
    v.cmp.lt     p1, v0, v2
    s.muli       s5, s2, #7
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s16, s11, #7
    s.add        s17, s5, s8
    v.splat      v1, s16
    s.add        s5, s17, s6
    s.movz       s16, #8
    s.add        s17, s12, s5
    @p3 v.st.h       [s18, #0], v0
    a.vread      v0, a0, s13
    v.cmp.lt     p1, v1, v2
    s.muli       s5, s2, #8
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s13, s11, #8
    s.add        s18, s5, s8
    v.splat      v0, s13
    s.add        s5, s18, s6
    s.movz       s13, #9
    s.add        s18, s12, s5
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a0, s16
    v.cmp.lt     p1, v0, v2
    s.muli       s5, s2, #9
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s16, s11, #9
    s.add        s17, s5, s8
    v.splat      v1, s16
    s.add        s5, s17, s6
    s.movz       s16, #10
    s.add        s17, s12, s5
    @p3 v.st.h       [s18, #0], v0
    a.vread      v0, a0, s13
    v.cmp.lt     p1, v1, v2
    s.muli       s5, s2, #10
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s13, s11, #10
    s.add        s18, s5, s8
    v.splat      v0, s13
    s.add        s5, s18, s6
    s.movz       s13, #11
    s.add        s18, s12, s5
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a0, s16
    v.cmp.lt     p1, v0, v2
    s.muli       s5, s2, #11
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s16, s11, #11
    s.add        s17, s5, s8
    v.splat      v1, s16
    s.add        s5, s17, s6
    s.movz       s16, #12
    s.add        s17, s12, s5
    @p3 v.st.h       [s18, #0], v0
    a.vread      v0, a0, s13
    v.cmp.lt     p1, v1, v2
    s.muli       s5, s2, #12
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s13, s11, #12
    s.add        s18, s5, s8
    v.splat      v0, s13
    s.add        s5, s18, s6
    s.movz       s13, #13
    s.add        s18, s12, s5
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a0, s16
    v.cmp.lt     p1, v0, v2
    s.muli       s5, s2, #13
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s16, s11, #13
    s.add        s17, s5, s8
    v.splat      v1, s16
    s.add        s5, s17, s6
    s.movz       s16, #14
    s.add        s17, s12, s5
    @p3 v.st.h       [s18, #0], v0
    a.vread      v0, a0, s13
    v.cmp.lt     p1, v1, v2
    s.muli       s5, s2, #14
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s13, s11, #14
    s.add        s18, s5, s8
    v.splat      v0, s13
    s.add        s5, s18, s6
    s.movz       s13, #15
    s.add        s18, s12, s5
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a0, s16
    v.cmp.lt     p1, v0, v2
    s.muli       s5, s2, #15
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s16, s11, #15
    s.add        s17, s5, s8
    v.splat      v1, s16
    s.add        s5, s17, s6
    s.movz       s6, #0
    s.add        s16, s12, s5
    @p3 v.st.h       [s18, #0], v0
    a.vread      v0, a0, s13
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v0
    s.movz       s5, #0
    s.movz       s13, #0
    s.add        s17, s5, s1                     // the tile origin
    s.muli       s5, s1, #2
    v.splat      v0, s17
    s.add        s1, s13, s3                     // the tile origin
    v.splat      v4, s11
    v.add        v5, v3, v0
    s.add        s13, s8, s5
    @p3 v.st.h       [s16, #0], v1
    a.vread      v0, a1, s6
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s1
    vf.cvt.f32.bf16 v4, v0
    s.add        s1, s12, s13
    v.cmp.lt     p2, v5, v1
    s.muli       s6, s2, #1
    p.and        p3, p1, p2
    s.movz       s13, #1
    s.addi       s16, s11, #1
    s.movz       s17, #2
    s.add        s18, s6, s8
    v.splat      v0, s16
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a1, s13
    s.add        s1, s18, s5
    v.cmp.lt     p1, v0, v2
    vf.cvt.f32.bf16 v0, v1
    s.muli       s6, s2, #2
    s.add        s13, s12, s1
    p.and        p3, p1, p2
    s.addi       s1, s11, #2
    s.movz       s16, #3
    s.add        s18, s6, s8
    v.splat      v1, s1
    s.add        s1, s18, s5
    @p3 v.st.h       [s13, #0], v0
    a.vread      v0, a1, s17
    v.cmp.lt     p1, v1, v2
    s.muli       s6, s2, #3
    vf.cvt.f32.bf16 v1, v0
    s.add        s13, s12, s1
    p.and        p3, p1, p2
    s.addi       s1, s11, #3
    s.add        s17, s6, s8
    v.splat      v0, s1
    s.add        s1, s17, s5
    s.movz       s6, #4
    s.add        s17, s12, s1
    @p3 v.st.h       [s13, #0], v1
    a.vread      v1, a1, s16
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s2, #4
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s13, s11, #4
    s.movz       s16, #5
    s.add        s18, s1, s8
    v.splat      v1, s13
    s.add        s1, s18, s5
    s.add        s13, s12, s1
    @p3 v.st.h       [s17, #0], v0
    a.vread      v0, a1, s6
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s2, #5
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s6, s11, #5
    s.movz       s17, #6
    s.add        s18, s1, s8
    v.splat      v0, s6
    s.add        s1, s18, s5
    s.add        s6, s12, s1
    @p3 v.st.h       [s13, #0], v1
    a.vread      v1, a1, s16
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s2, #6
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s13, s11, #6
    s.movz       s16, #7
    s.add        s18, s1, s8
    v.splat      v1, s13
    s.add        s1, s18, s5
    s.add        s13, s12, s1
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a1, s17
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s2, #7
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s6, s11, #7
    s.movz       s17, #8
    s.add        s18, s1, s8
    v.splat      v0, s6
    s.add        s1, s18, s5
    s.add        s6, s12, s1
    @p3 v.st.h       [s13, #0], v1
    a.vread      v1, a1, s16
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s2, #8
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s13, s11, #8
    s.movz       s16, #9
    s.add        s18, s1, s8
    v.splat      v1, s13
    s.add        s1, s18, s5
    s.add        s13, s12, s1
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a1, s17
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s2, #9
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s6, s11, #9
    s.movz       s17, #10
    s.add        s18, s1, s8
    v.splat      v0, s6
    s.add        s1, s18, s5
    s.add        s6, s12, s1
    @p3 v.st.h       [s13, #0], v1
    a.vread      v1, a1, s16
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s2, #10
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s13, s11, #10
    s.movz       s16, #11
    s.add        s18, s1, s8
    v.splat      v1, s13
    s.add        s1, s18, s5
    s.add        s13, s12, s1
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a1, s17
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s2, #11
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s6, s11, #11
    s.movz       s17, #12
    s.add        s18, s1, s8
    v.splat      v0, s6
    s.add        s1, s18, s5
    s.add        s6, s12, s1
    @p3 v.st.h       [s13, #0], v1
    a.vread      v1, a1, s16
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s2, #12
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s13, s11, #12
    s.movz       s16, #13
    s.add        s18, s1, s8
    v.splat      v1, s13
    s.add        s1, s18, s5
    s.add        s13, s12, s1
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a1, s17
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s2, #13
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s6, s11, #13
    s.movz       s17, #14
    s.add        s18, s1, s8
    v.splat      v0, s6
    s.add        s1, s18, s5
    s.add        s6, s12, s1
    @p3 v.st.h       [s13, #0], v1
    a.vread      v1, a1, s16
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s2, #14
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s13, s11, #14
    s.movz       s16, #15
    s.add        s18, s1, s8
    v.splat      v1, s13
    s.add        s1, s18, s5
    s.add        s13, s12, s1
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a1, s17
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s2, #15
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s6, s11, #15
    s.movz       s17, #0
    s.add        s18, s1, s8
    v.splat      v0, s6
    s.add        s1, s18, s5
    s.add        s5, s12, s1
    @p3 v.st.h       [s13, #0], v1
    a.vread      v1, a1, s16
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.movz       s1, #0
    s.movz       s6, #0
    s.add        s13, s1, s10                    // the tile origin
    s.muli       s1, s10, #2
    v.splat      v1, s13
    s.add        s10, s6, s3                     // the tile origin
    v.splat      v4, s11
    v.add        v5, v3, v1
    s.add        s6, s8, s1
    @p3 v.st.h       [s5, #0], v0
    a.vread      v0, a2, s17
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s10
    vf.cvt.f32.bf16 v4, v0
    s.add        s5, s12, s6
    v.cmp.lt     p2, v5, v1
    s.muli       s6, s2, #1
    p.and        p3, p1, p2
    s.movz       s10, #1
    s.addi       s13, s11, #1
    s.movz       s16, #2
    s.add        s17, s6, s8
    v.splat      v0, s13
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a2, s10
    s.add        s5, s17, s1
    v.cmp.lt     p1, v0, v2
    vf.cvt.f32.bf16 v0, v1
    s.muli       s6, s2, #2
    s.add        s10, s12, s5
    p.and        p3, p1, p2
    s.addi       s5, s11, #2
    s.movz       s13, #3
    s.add        s17, s6, s8
    v.splat      v1, s5
    s.add        s5, s17, s1
    @p3 v.st.h       [s10, #0], v0
    a.vread      v0, a2, s16
    v.cmp.lt     p1, v1, v2
    s.muli       s6, s2, #3
    vf.cvt.f32.bf16 v1, v0
    s.add        s10, s12, s5
    p.and        p3, p1, p2
    s.addi       s5, s11, #3
    s.add        s16, s6, s8
    v.splat      v0, s5
    s.add        s5, s16, s1
    s.movz       s6, #4
    s.add        s16, s12, s5
    @p3 v.st.h       [s10, #0], v1
    a.vread      v1, a2, s13
    v.cmp.lt     p1, v0, v2
    s.muli       s5, s2, #4
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s10, s11, #4
    s.movz       s13, #5
    s.add        s17, s5, s8
    v.splat      v1, s10
    s.add        s5, s17, s1
    s.add        s10, s12, s5
    @p3 v.st.h       [s16, #0], v0
    a.vread      v0, a2, s6
    v.cmp.lt     p1, v1, v2
    s.muli       s5, s2, #5
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s6, s11, #5
    s.movz       s16, #6
    s.add        s17, s5, s8
    v.splat      v0, s6
    s.add        s5, s17, s1
    s.add        s6, s12, s5
    @p3 v.st.h       [s10, #0], v1
    a.vread      v1, a2, s13
    v.cmp.lt     p1, v0, v2
    s.muli       s5, s2, #6
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s10, s11, #6
    s.movz       s13, #7
    s.add        s17, s5, s8
    v.splat      v1, s10
    s.add        s5, s17, s1
    s.add        s10, s12, s5
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a2, s16
    v.cmp.lt     p1, v1, v2
    s.muli       s5, s2, #7
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s6, s11, #7
    s.movz       s16, #8
    s.add        s17, s5, s8
    v.splat      v0, s6
    s.add        s5, s17, s1
    s.add        s6, s12, s5
    @p3 v.st.h       [s10, #0], v1
    a.vread      v1, a2, s13
    v.cmp.lt     p1, v0, v2
    s.muli       s5, s2, #8
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s10, s11, #8
    s.movz       s13, #9
    s.add        s17, s5, s8
    v.splat      v1, s10
    s.add        s5, s17, s1
    s.add        s10, s12, s5
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a2, s16
    v.cmp.lt     p1, v1, v2
    s.muli       s5, s2, #9
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s6, s11, #9
    s.movz       s16, #10
    s.add        s17, s5, s8
    v.splat      v0, s6
    s.add        s5, s17, s1
    s.add        s6, s12, s5
    @p3 v.st.h       [s10, #0], v1
    a.vread      v1, a2, s13
    v.cmp.lt     p1, v0, v2
    s.muli       s5, s2, #10
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s10, s11, #10
    s.movz       s13, #11
    s.add        s17, s5, s8
    v.splat      v1, s10
    s.add        s5, s17, s1
    s.add        s10, s12, s5
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a2, s16
    v.cmp.lt     p1, v1, v2
    s.muli       s5, s2, #11
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s6, s11, #11
    s.movz       s16, #12
    s.add        s17, s5, s8
    v.splat      v0, s6
    s.add        s5, s17, s1
    s.add        s6, s12, s5
    @p3 v.st.h       [s10, #0], v1
    a.vread      v1, a2, s13
    v.cmp.lt     p1, v0, v2
    s.muli       s5, s2, #12
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s10, s11, #12
    s.movz       s13, #13
    s.add        s17, s5, s8
    v.splat      v1, s10
    s.add        s5, s17, s1
    s.add        s10, s12, s5
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a2, s16
    v.cmp.lt     p1, v1, v2
    s.muli       s5, s2, #13
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s6, s11, #13
    s.movz       s16, #14
    s.add        s17, s5, s8
    v.splat      v0, s6
    s.add        s5, s17, s1
    s.add        s6, s12, s5
    @p3 v.st.h       [s10, #0], v1
    a.vread      v1, a2, s13
    v.cmp.lt     p1, v0, v2
    s.muli       s5, s2, #14
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s10, s11, #14
    s.movz       s13, #15
    s.add        s17, s5, s8
    v.splat      v1, s10
    s.add        s5, s17, s1
    s.add        s10, s12, s5
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a2, s16
    v.cmp.lt     p1, v1, v2
    s.muli       s5, s2, #15
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s6, s11, #15
    s.movz       s16, #0
    s.add        s17, s5, s8
    v.splat      v0, s6
    s.add        s5, s17, s1
    s.add        s1, s12, s5
    @p3 v.st.h       [s10, #0], v1
    a.vread      v1, a2, s13
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.movz       s5, #0
    s.movz       s6, #0
    s.add        s10, s5, s9                     // the tile origin
    s.muli       s5, s9, #2
    v.splat      v1, s10
    s.add        s9, s6, s3                      // the tile origin
    v.splat      v4, s11
    v.add        v5, v3, v1
    s.add        s6, s8, s5
    @p3 v.st.h       [s1, #0], v0
    a.vread      v0, a3, s16
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s9
    vf.cvt.f32.bf16 v4, v0
    s.add        s1, s12, s6
    v.cmp.lt     p2, v5, v1
    s.muli       s6, s2, #1
    p.and        p3, p1, p2
    s.movz       s9, #1
    s.addi       s10, s11, #1
    s.movz       s13, #2
    s.add        s16, s6, s8
    v.splat      v0, s10
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a3, s9
    s.add        s1, s16, s5
    v.cmp.lt     p1, v0, v2
    vf.cvt.f32.bf16 v0, v1
    s.muli       s6, s2, #2
    s.add        s9, s12, s1
    p.and        p3, p1, p2
    s.addi       s1, s11, #2
    s.movz       s10, #3
    s.add        s16, s6, s8
    v.splat      v1, s1
    s.add        s1, s16, s5
    @p3 v.st.h       [s9, #0], v0
    a.vread      v0, a3, s13
    v.cmp.lt     p1, v1, v2
    s.muli       s6, s2, #3
    vf.cvt.f32.bf16 v1, v0
    s.add        s9, s12, s1
    p.and        p3, p1, p2
    s.addi       s1, s11, #3
    s.add        s13, s6, s8
    v.splat      v0, s1
    s.add        s1, s13, s5
    s.movz       s6, #4
    s.add        s13, s12, s1
    @p3 v.st.h       [s9, #0], v1
    a.vread      v1, a3, s10
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s2, #4
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s9, s11, #4
    s.movz       s10, #5
    s.add        s16, s1, s8
    v.splat      v1, s9
    s.add        s1, s16, s5
    s.add        s9, s12, s1
    @p3 v.st.h       [s13, #0], v0
    a.vread      v0, a3, s6
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s2, #5
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s6, s11, #5
    s.movz       s13, #6
    s.add        s16, s1, s8
    v.splat      v0, s6
    s.add        s1, s16, s5
    s.add        s6, s12, s1
    @p3 v.st.h       [s9, #0], v1
    a.vread      v1, a3, s10
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s2, #6
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s9, s11, #6
    s.movz       s10, #7
    s.add        s16, s1, s8
    v.splat      v1, s9
    s.add        s1, s16, s5
    s.add        s9, s12, s1
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a3, s13
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s2, #7
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s6, s11, #7
    s.movz       s13, #8
    s.add        s16, s1, s8
    v.splat      v0, s6
    s.add        s1, s16, s5
    s.add        s6, s12, s1
    @p3 v.st.h       [s9, #0], v1
    a.vread      v1, a3, s10
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s2, #8
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s9, s11, #8
    s.movz       s10, #9
    s.add        s16, s1, s8
    v.splat      v1, s9
    s.add        s1, s16, s5
    s.add        s9, s12, s1
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a3, s13
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s2, #9
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s6, s11, #9
    s.movz       s13, #10
    s.add        s16, s1, s8
    v.splat      v0, s6
    s.add        s1, s16, s5
    s.add        s6, s12, s1
    @p3 v.st.h       [s9, #0], v1
    a.vread      v1, a3, s10
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s2, #10
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s9, s11, #10
    s.movz       s10, #11
    s.add        s16, s1, s8
    v.splat      v1, s9
    s.add        s1, s16, s5
    s.add        s9, s12, s1
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a3, s13
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s2, #11
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s6, s11, #11
    s.movz       s13, #12
    s.add        s16, s1, s8
    v.splat      v0, s6
    s.add        s1, s16, s5
    s.add        s6, s12, s1
    @p3 v.st.h       [s9, #0], v1
    a.vread      v1, a3, s10
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s2, #12
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s9, s11, #12
    s.movz       s10, #13
    s.add        s16, s1, s8
    v.splat      v1, s9
    s.add        s1, s16, s5
    s.add        s9, s12, s1
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a3, s13
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s2, #13
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s6, s11, #13
    s.movz       s13, #14
    s.add        s16, s1, s8
    v.splat      v0, s6
    s.add        s1, s16, s5
    s.add        s6, s12, s1
    @p3 v.st.h       [s9, #0], v1
    a.vread      v1, a3, s10
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s2, #14
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s9, s11, #14
    s.movz       s10, #15
    s.add        s16, s1, s8
    v.splat      v1, s9
    s.add        s1, s16, s5
    s.add        s9, s12, s1
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a3, s13
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s2, #15
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s6, s11, #15
    s.movz       s13, #0
    s.add        s16, s1, s8
    v.splat      v0, s6
    s.add        s1, s16, s5
    s.add        s5, s12, s1
    @p3 v.st.h       [s9, #0], v1
    a.vread      v1, a3, s10
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.movz       s1, #0
    s.movz       s6, #0
    s.add        s9, s1, s4                      // the tile origin
    s.muli       s1, s4, #2
    v.splat      v1, s9
    s.add        s4, s6, s3                      // the tile origin
    v.splat      v4, s11
    v.add        v5, v3, v1
    s.add        s6, s8, s1
    @p3 v.st.h       [s5, #0], v0
    a.vread      v0, a4, s13
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s4
    vf.cvt.f32.bf16 v4, v0
    s.add        s4, s12, s6
    v.cmp.lt     p2, v5, v1
    s.muli       s5, s2, #1
    p.and        p3, p1, p2
    s.movz       s6, #1
    s.addi       s9, s11, #1
    s.movz       s10, #2
    s.add        s13, s5, s8
    v.splat      v0, s9
    @p3 v.st.h       [s4, #0], v4
    a.vread      v1, a4, s6
    s.add        s4, s13, s1
    v.cmp.lt     p1, v0, v2
    vf.cvt.f32.bf16 v0, v1
    s.muli       s5, s2, #2
    s.add        s6, s12, s4
    p.and        p3, p1, p2
    s.addi       s4, s11, #2
    s.movz       s9, #3
    s.add        s13, s5, s8
    v.splat      v1, s4
    s.add        s4, s13, s1
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a4, s10
    v.cmp.lt     p1, v1, v2
    s.muli       s5, s2, #3
    vf.cvt.f32.bf16 v1, v0
    s.add        s6, s12, s4
    p.and        p3, p1, p2
    s.addi       s4, s11, #3
    s.add        s10, s5, s8
    v.splat      v0, s4
    s.add        s4, s10, s1
    s.movz       s5, #4
    s.add        s10, s12, s4
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a4, s9
    v.cmp.lt     p1, v0, v2
    s.muli       s4, s2, #4
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s6, s11, #4
    s.movz       s9, #5
    s.add        s13, s4, s8
    v.splat      v1, s6
    s.add        s4, s13, s1
    s.add        s6, s12, s4
    @p3 v.st.h       [s10, #0], v0
    a.vread      v0, a4, s5
    v.cmp.lt     p1, v1, v2
    s.muli       s4, s2, #5
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s5, s11, #5
    s.movz       s10, #6
    s.add        s13, s4, s8
    v.splat      v0, s5
    s.add        s4, s13, s1
    s.add        s5, s12, s4
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a4, s9
    v.cmp.lt     p1, v0, v2
    s.muli       s4, s2, #6
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s6, s11, #6
    s.movz       s9, #7
    s.add        s13, s4, s8
    v.splat      v1, s6
    s.add        s4, s13, s1
    s.add        s6, s12, s4
    @p3 v.st.h       [s5, #0], v0
    a.vread      v0, a4, s10
    v.cmp.lt     p1, v1, v2
    s.muli       s4, s2, #7
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s5, s11, #7
    s.movz       s10, #8
    s.add        s13, s4, s8
    v.splat      v0, s5
    s.add        s4, s13, s1
    s.add        s5, s12, s4
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a4, s9
    v.cmp.lt     p1, v0, v2
    s.muli       s4, s2, #8
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s6, s11, #8
    s.movz       s9, #9
    s.add        s13, s4, s8
    v.splat      v1, s6
    s.add        s4, s13, s1
    s.add        s6, s12, s4
    @p3 v.st.h       [s5, #0], v0
    a.vread      v0, a4, s10
    v.cmp.lt     p1, v1, v2
    s.muli       s4, s2, #9
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s5, s11, #9
    s.movz       s10, #10
    s.add        s13, s4, s8
    v.splat      v0, s5
    s.add        s4, s13, s1
    s.add        s5, s12, s4
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a4, s9
    v.cmp.lt     p1, v0, v2
    s.muli       s4, s2, #10
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s6, s11, #10
    s.movz       s9, #11
    s.add        s13, s4, s8
    v.splat      v1, s6
    s.add        s4, s13, s1
    s.add        s6, s12, s4
    @p3 v.st.h       [s5, #0], v0
    a.vread      v0, a4, s10
    v.cmp.lt     p1, v1, v2
    s.muli       s4, s2, #11
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s5, s11, #11
    s.movz       s10, #12
    s.add        s13, s4, s8
    v.splat      v0, s5
    s.add        s4, s13, s1
    s.add        s5, s12, s4
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a4, s9
    v.cmp.lt     p1, v0, v2
    s.muli       s4, s2, #12
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s6, s11, #12
    s.movz       s9, #13
    s.add        s13, s4, s8
    v.splat      v1, s6
    s.add        s4, s13, s1
    s.add        s6, s12, s4
    @p3 v.st.h       [s5, #0], v0
    a.vread      v0, a4, s10
    v.cmp.lt     p1, v1, v2
    s.muli       s4, s2, #13
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s5, s11, #13
    s.movz       s10, #14
    s.add        s13, s4, s8
    v.splat      v0, s5
    s.add        s4, s13, s1
    s.add        s5, s12, s4
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a4, s9
    v.cmp.lt     p1, v0, v2
    s.muli       s4, s2, #14
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s6, s11, #14
    s.movz       s9, #15
    s.add        s13, s4, s8
    v.splat      v1, s6
    s.add        s4, s13, s1
    s.add        s6, s12, s4
    @p3 v.st.h       [s5, #0], v0
    a.vread      v0, a4, s10
    v.cmp.lt     p1, v1, v2
    s.muli       s4, s2, #15
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s5, s11, #15
    s.movz       s10, #0
    s.add        s13, s4, s8
    v.splat      v0, s5
    s.add        s4, s13, s1
    s.add        s1, s12, s4
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a4, s9
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.movz       s4, #0
    s.movz       s5, #0
    s.add        s6, s4, s15                     // the tile origin
    s.muli       s4, s15, #2
    v.splat      v1, s6
    s.add        s6, s5, s3                      // the tile origin
    v.splat      v4, s11
    v.add        v5, v3, v1
    s.add        s5, s8, s4
    @p3 v.st.h       [s1, #0], v0
    a.vread      v0, a5, s10
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s6
    vf.cvt.f32.bf16 v4, v0
    s.add        s1, s12, s5
    v.cmp.lt     p2, v5, v1
    s.muli       s5, s2, #1
    p.and        p3, p1, p2
    s.movz       s6, #1
    s.addi       s9, s11, #1
    s.movz       s10, #2
    s.add        s13, s5, s8
    v.splat      v0, s9
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a5, s6
    s.add        s1, s13, s4
    v.cmp.lt     p1, v0, v2
    vf.cvt.f32.bf16 v0, v1
    s.muli       s5, s2, #2
    s.add        s6, s12, s1
    p.and        p3, p1, p2
    s.addi       s1, s11, #2
    s.movz       s9, #3
    s.add        s13, s5, s8
    v.splat      v1, s1
    s.add        s1, s13, s4
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a5, s10
    v.cmp.lt     p1, v1, v2
    s.muli       s5, s2, #3
    vf.cvt.f32.bf16 v1, v0
    s.add        s6, s12, s1
    p.and        p3, p1, p2
    s.addi       s1, s11, #3
    s.add        s10, s5, s8
    v.splat      v0, s1
    s.add        s1, s10, s4
    s.movz       s5, #4
    s.add        s10, s12, s1
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a5, s9
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s2, #4
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s6, s11, #4
    s.movz       s9, #5
    s.add        s13, s1, s8
    v.splat      v1, s6
    s.add        s1, s13, s4
    s.add        s6, s12, s1
    @p3 v.st.h       [s10, #0], v0
    a.vread      v0, a5, s5
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s2, #5
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s5, s11, #5
    s.movz       s10, #6
    s.add        s13, s1, s8
    v.splat      v0, s5
    s.add        s1, s13, s4
    s.add        s5, s12, s1
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a5, s9
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s2, #6
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s6, s11, #6
    s.movz       s9, #7
    s.add        s13, s1, s8
    v.splat      v1, s6
    s.add        s1, s13, s4
    s.add        s6, s12, s1
    @p3 v.st.h       [s5, #0], v0
    a.vread      v0, a5, s10
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s2, #7
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s5, s11, #7
    s.movz       s10, #8
    s.add        s13, s1, s8
    v.splat      v0, s5
    s.add        s1, s13, s4
    s.add        s5, s12, s1
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a5, s9
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s2, #8
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s6, s11, #8
    s.movz       s9, #9
    s.add        s13, s1, s8
    v.splat      v1, s6
    s.add        s1, s13, s4
    s.add        s6, s12, s1
    @p3 v.st.h       [s5, #0], v0
    a.vread      v0, a5, s10
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s2, #9
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s5, s11, #9
    s.movz       s10, #10
    s.add        s13, s1, s8
    v.splat      v0, s5
    s.add        s1, s13, s4
    s.add        s5, s12, s1
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a5, s9
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s2, #10
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s6, s11, #10
    s.movz       s9, #11
    s.add        s13, s1, s8
    v.splat      v1, s6
    s.add        s1, s13, s4
    s.add        s6, s12, s1
    @p3 v.st.h       [s5, #0], v0
    a.vread      v0, a5, s10
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s2, #11
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s5, s11, #11
    s.movz       s10, #12
    s.add        s13, s1, s8
    v.splat      v0, s5
    s.add        s1, s13, s4
    s.add        s5, s12, s1
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a5, s9
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s2, #12
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s6, s11, #12
    s.movz       s9, #13
    s.add        s13, s1, s8
    v.splat      v1, s6
    s.add        s1, s13, s4
    s.add        s6, s12, s1
    @p3 v.st.h       [s5, #0], v0
    a.vread      v0, a5, s10
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s2, #13
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s5, s11, #13
    s.movz       s10, #14
    s.add        s13, s1, s8
    v.splat      v0, s5
    s.add        s1, s13, s4
    s.add        s5, s12, s1
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a5, s9
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s2, #14
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s6, s11, #14
    s.movz       s9, #15
    s.add        s13, s1, s8
    v.splat      v1, s6
    s.add        s1, s13, s4
    s.add        s6, s12, s1
    @p3 v.st.h       [s5, #0], v0
    a.vread      v0, a5, s10
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s2, #15
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s5, s11, #15
    s.movz       s10, #0
    s.add        s13, s1, s8
    v.splat      v0, s5
    s.add        s1, s13, s4
    s.add        s4, s12, s1
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a5, s9
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.movz       s1, #0
    s.movz       s5, #0
    s.add        s6, s1, s7                      // the tile origin
    s.muli       s1, s7, #2
    v.splat      v1, s6
    s.add        s6, s5, s3                      // the tile origin
    v.splat      v4, s11
    v.add        v5, v3, v1
    s.add        s5, s8, s1
    @p3 v.st.h       [s4, #0], v0
    a.vread      v0, a6, s10
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s6
    vf.cvt.f32.bf16 v4, v0
    s.add        s4, s12, s5
    v.cmp.lt     p2, v5, v1
    s.muli       s5, s2, #1
    p.and        p3, p1, p2
    s.movz       s6, #1
    s.addi       s7, s11, #1
    s.movz       s9, #2
    s.add        s10, s5, s8
    v.splat      v0, s7
    @p3 v.st.h       [s4, #0], v4
    a.vread      v1, a6, s6
    s.add        s4, s10, s1
    v.cmp.lt     p1, v0, v2
    vf.cvt.f32.bf16 v0, v1
    s.muli       s5, s2, #2
    s.add        s6, s12, s4
    p.and        p3, p1, p2
    s.addi       s4, s11, #2
    s.movz       s7, #3
    s.add        s10, s5, s8
    v.splat      v1, s4
    s.add        s4, s10, s1
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a6, s9
    v.cmp.lt     p1, v1, v2
    s.muli       s5, s2, #3
    vf.cvt.f32.bf16 v1, v0
    s.add        s6, s12, s4
    p.and        p3, p1, p2
    s.addi       s4, s11, #3
    s.add        s9, s5, s8
    v.splat      v0, s4
    s.add        s4, s9, s1
    s.movz       s5, #4
    s.add        s9, s12, s4
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a6, s7
    v.cmp.lt     p1, v0, v2
    s.muli       s4, s2, #4
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s6, s11, #4
    s.movz       s7, #5
    s.add        s10, s4, s8
    v.splat      v1, s6
    s.add        s4, s10, s1
    s.add        s6, s12, s4
    @p3 v.st.h       [s9, #0], v0
    a.vread      v0, a6, s5
    v.cmp.lt     p1, v1, v2
    s.muli       s4, s2, #5
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s5, s11, #5
    s.movz       s9, #6
    s.add        s10, s4, s8
    v.splat      v0, s5
    s.add        s4, s10, s1
    s.add        s5, s12, s4
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a6, s7
    v.cmp.lt     p1, v0, v2
    s.muli       s4, s2, #6
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s6, s11, #6
    s.movz       s7, #7
    s.add        s10, s4, s8
    v.splat      v1, s6
    s.add        s4, s10, s1
    s.add        s6, s12, s4
    @p3 v.st.h       [s5, #0], v0
    a.vread      v0, a6, s9
    v.cmp.lt     p1, v1, v2
    s.muli       s4, s2, #7
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s5, s11, #7
    s.movz       s9, #8
    s.add        s10, s4, s8
    v.splat      v0, s5
    s.add        s4, s10, s1
    s.add        s5, s12, s4
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a6, s7
    v.cmp.lt     p1, v0, v2
    s.muli       s4, s2, #8
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s6, s11, #8
    s.movz       s7, #9
    s.add        s10, s4, s8
    v.splat      v1, s6
    s.add        s4, s10, s1
    s.add        s6, s12, s4
    @p3 v.st.h       [s5, #0], v0
    a.vread      v0, a6, s9
    v.cmp.lt     p1, v1, v2
    s.muli       s4, s2, #9
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s5, s11, #9
    s.movz       s9, #10
    s.add        s10, s4, s8
    v.splat      v0, s5
    s.add        s4, s10, s1
    s.add        s5, s12, s4
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a6, s7
    v.cmp.lt     p1, v0, v2
    s.muli       s4, s2, #10
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s6, s11, #10
    s.movz       s7, #11
    s.add        s10, s4, s8
    v.splat      v1, s6
    s.add        s4, s10, s1
    s.add        s6, s12, s4
    @p3 v.st.h       [s5, #0], v0
    a.vread      v0, a6, s9
    v.cmp.lt     p1, v1, v2
    s.muli       s4, s2, #11
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s5, s11, #11
    s.movz       s9, #12
    s.add        s10, s4, s8
    v.splat      v0, s5
    s.add        s4, s10, s1
    s.add        s5, s12, s4
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a6, s7
    v.cmp.lt     p1, v0, v2
    s.muli       s4, s2, #12
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s6, s11, #12
    s.movz       s7, #13
    s.add        s10, s4, s8
    v.splat      v1, s6
    s.add        s4, s10, s1
    s.add        s6, s12, s4
    @p3 v.st.h       [s5, #0], v0
    a.vread      v0, a6, s9
    v.cmp.lt     p1, v1, v2
    s.muli       s4, s2, #13
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s5, s11, #13
    s.movz       s9, #14
    s.add        s10, s4, s8
    v.splat      v0, s5
    s.add        s4, s10, s1
    s.add        s5, s12, s4
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a6, s7
    v.cmp.lt     p1, v0, v2
    s.muli       s4, s2, #14
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s6, s11, #14
    s.movz       s7, #15
    s.add        s10, s4, s8
    v.splat      v1, s6
    s.add        s4, s10, s1
    s.add        s6, s12, s4
    @p3 v.st.h       [s5, #0], v0
    a.vread      v0, a6, s9
    v.cmp.lt     p1, v1, v2
    s.muli       s4, s2, #15
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s5, s11, #15
    s.movz       s9, #0
    s.add        s10, s4, s8
    v.splat      v0, s5
    s.add        s4, s10, s1
    s.add        s1, s12, s4
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a6, s7
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.movz       s4, #0
    s.movz       s5, #0
    s.add        s6, s4, s14                     // the tile origin
    s.muli       s4, s14, #2
    v.splat      v1, s6
    s.add        s6, s5, s3                      // the tile origin
    v.splat      v4, s11
    v.add        v5, v3, v1
    v.splat      v1, s6
    @p3 v.st.h       [s1, #0], v0
    a.vread      v0, a7, s9
    s.add        s1, s8, s4
    v.cmp.lt     p1, v4, v2
    vf.cvt.f32.bf16 v3, v0
    v.cmp.lt     p2, v5, v1
    s.add        s3, s12, s1
    s.muli       s1, s2, #1
    p.and        p3, p1, p2
    s.movz       s5, #1
    s.addi       s6, s11, #1
    s.movz       s7, #2
    s.add        s9, s1, s8
    v.splat      v0, s6
    @p3 v.st.h       [s3, #0], v3
    a.vread      v1, a7, s5
    s.add        s1, s9, s4
    v.cmp.lt     p1, v0, v2
    vf.cvt.f32.bf16 v0, v1
    s.muli       s3, s2, #2
    s.add        s5, s12, s1
    p.and        p3, p1, p2
    s.addi       s1, s11, #2
    s.movz       s6, #3
    s.add        s9, s3, s8
    v.splat      v1, s1
    s.add        s1, s9, s4
    @p3 v.st.h       [s5, #0], v0
    a.vread      v0, a7, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s3, s2, #3
    vf.cvt.f32.bf16 v1, v0
    s.add        s5, s12, s1
    p.and        p3, p1, p2
    s.addi       s1, s11, #3
    s.add        s7, s3, s8
    v.splat      v0, s1
    s.add        s1, s7, s4
    s.movz       s3, #4
    s.add        s7, s12, s1
    @p3 v.st.h       [s5, #0], v1
    a.vread      v1, a7, s6
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s2, #4
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s5, s11, #4
    s.movz       s6, #5
    s.add        s9, s1, s8
    v.splat      v1, s5
    s.add        s1, s9, s4
    s.add        s5, s12, s1
    @p3 v.st.h       [s7, #0], v0
    a.vread      v0, a7, s3
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s2, #5
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s3, s11, #5
    s.movz       s7, #6
    s.add        s9, s1, s8
    v.splat      v0, s3
    s.add        s1, s9, s4
    s.add        s3, s12, s1
    @p3 v.st.h       [s5, #0], v1
    a.vread      v1, a7, s6
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s2, #6
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s5, s11, #6
    s.movz       s6, #7
    s.add        s9, s1, s8
    v.splat      v1, s5
    s.add        s1, s9, s4
    s.add        s5, s12, s1
    @p3 v.st.h       [s3, #0], v0
    a.vread      v0, a7, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s2, #7
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s3, s11, #7
    s.movz       s7, #8
    s.add        s9, s1, s8
    v.splat      v0, s3
    s.add        s1, s9, s4
    s.add        s3, s12, s1
    @p3 v.st.h       [s5, #0], v1
    a.vread      v1, a7, s6
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s2, #8
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s5, s11, #8
    s.movz       s6, #9
    s.add        s9, s1, s8
    v.splat      v1, s5
    s.add        s1, s9, s4
    s.add        s5, s12, s1
    @p3 v.st.h       [s3, #0], v0
    a.vread      v0, a7, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s2, #9
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s3, s11, #9
    s.movz       s7, #10
    s.add        s9, s1, s8
    v.splat      v0, s3
    s.add        s1, s9, s4
    s.add        s3, s12, s1
    @p3 v.st.h       [s5, #0], v1
    a.vread      v1, a7, s6
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s2, #10
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s5, s11, #10
    s.movz       s6, #11
    s.add        s9, s1, s8
    v.splat      v1, s5
    s.add        s1, s9, s4
    s.add        s5, s12, s1
    @p3 v.st.h       [s3, #0], v0
    a.vread      v0, a7, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s2, #11
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s3, s11, #11
    s.movz       s7, #12
    s.add        s9, s1, s8
    v.splat      v0, s3
    s.add        s1, s9, s4
    s.add        s3, s12, s1
    @p3 v.st.h       [s5, #0], v1
    a.vread      v1, a7, s6
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s2, #12
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s5, s11, #12
    s.movz       s6, #13
    s.add        s9, s1, s8
    v.splat      v1, s5
    s.add        s1, s9, s4
    s.add        s5, s12, s1
    @p3 v.st.h       [s3, #0], v0
    a.vread      v0, a7, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s2, #13
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s3, s11, #13
    s.movz       s7, #14
    s.add        s9, s1, s8
    v.splat      v0, s3
    s.add        s1, s9, s4
    s.add        s3, s12, s1
    @p3 v.st.h       [s5, #0], v1
    a.vread      v1, a7, s6
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s2, #14
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s5, s11, #14
    s.movz       s6, #15
    s.add        s9, s1, s8
    v.splat      v1, s5
    s.add        s1, s9, s4
    s.add        s5, s12, s1
    @p3 v.st.h       [s3, #0], v0
    a.vread      v0, a7, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s2, #15
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s2, s11, #15
    s.add        s3, s1, s8
    v.splat      v0, s2
    s.add        s1, s3, s4
    s.add        s2, s12, s1
    @p3 v.st.h       [s5, #0], v1
    a.vread      v1, a7, s6
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v0, v1
    @p3 v.st.h       [s2, #0], v0
    exit
    exit
