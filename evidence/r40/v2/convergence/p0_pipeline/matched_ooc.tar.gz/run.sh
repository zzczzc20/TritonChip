source /tools/Xilinx/Vivado/2023.2/settings64.sh
cd /home/zzhouch/tnca_build/r40_p0ab_screen
for cfg in 00 10 01 11; do
 sync=${cfg:0:1}
 owner=${cfg:1:1}
 timeout -k 15 1800 vivado -mode batch -source /home/zzhouch/tnca_build/r40_p0ab_screen/source/flow/fpga/synth_r40_range_slice.tcl -tclargs /home/zzhouch/tnca_build/r40_p0ab_screen/source /home/zzhouch/tnca_build/r40_p0ab_screen/case$cfg 1 32 5 $sync $owner > /home/zzhouch/tnca_build/r40_p0ab_screen/case$cfg.log 2>&1
 result=$?
 echo $result > /home/zzhouch/tnca_build/r40_p0ab_screen/case$cfg.exit
 if [ "$result" -ne 0 ]; then exit "$result"; fi
done
