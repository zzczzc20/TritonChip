    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_out_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr1: device_ptr64 at arg_base+16
    s.rdspecial  s1, arg_base
    s.ld.d       s6, [s1, #40]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s7, #512
    s.mul        s8, s1, s7
    s.add        s1, s6, s8                      // this context's own scratch
    s.addi       s6, s1, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s7, #0
    s.st.d       [s6, #0], s3
    s.movz       s7, #16
    s.st.d       [s6, #8], s7
    s.movz       s7, #128
    s.st.d       [s6, #16], s7
    s.movz       s7, #512
    s.st.d       [s6, #48], s7
    s.movz       s7, #4
    s.st.d       [s6, #56], s7
    .li       s7, #68719476737
    s.st.d       [s6, #88], s7
    .li       s7, #2207613190144
    s.st.d       [s6, #104], s7
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s6, #0
    s.movz       s7, #128
    s.movz       s8, #16
    v.splat      v0, s4
    v.iota       v0                              // arange(0, VLEN)
    s.addi       s9, s6, #0
    v.movi       v1, #0
    v.movi       v2, #0
    v.mov        v2, v1
for_1:
    s.cmp.ge     s10, s9, s7
    br.nz        s10, endfor_2
    v.splat      v1, s9
    v.iota       v3                              // arange(0, VLEN)
    s.movz       s10, #128
    s.movz       s11, #16
    s.muli       s12, s4, #512
    v.add        v4, v1, v3
    v.movi       v1, #0
    v.splat      v3, s10
    v.splat      v5, s4
    v.movi       v6, #0
    v.splat      v7, s11
    s.muli       s10, s9, #4
    v.cmp.ge     p1, v4, v1
    v.cmp.lt     p2, v4, v3
    v.cmp.ge     p3, v5, v6
    v.cmp.lt     p4, v5, v7
    s.add        s11, s3, s12
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s12, s11, s10
    p.and        p2, p5, p1
    v.splat      v1, s9
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v3, [s12, #0]
    v.movi       v4, #128
    v.add        v5, v1, v0
    v.movi       v1, #0
    s.add        s10, s9, s8
    v.cmp.lt     p1, v5, v4
    s.movz       s11, #1
    vf.mul       v4, v3, v3
    vf.add       v3, v2, v4
    @p1 v.sel        v4, v3, v2
    v.mov        v1, v4
    v.mov        v2, v1
    s.mov        s9, s10
    br.nz        s11, for_1
endfor_2:
    vf.reduce.add.b v1, v2
    v.movi       v2, #0
    vf.add       v3, v1, v2
    s.addi       s9, s1, #256                    // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s9, #0], s2
    s.movz       s1, #16
    s.st.d       [s9, #8], s1
    s.movz       s1, #128
    s.st.d       [s9, #16], s1
    s.movz       s1, #256
    s.st.d       [s9, #48], s1
    s.movz       s1, #2
    s.st.d       [s9, #56], s1
    .li       s1, #68719476737
    s.st.d       [s9, #88], s1
    .li       s1, #1108101562368
    s.st.d       [s9, #104], s1
    fence.release.device
    td.load      d1, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s6, #0
for_3:
    s.cmp.ge     s6, s1, s7
    br.nz        s6, endfor_4
    v.splat      v1, s1
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s6, #128
    s.movz       s9, #16
    s.muli       s10, s4, #256
    v.add        v4, v1, v2
    v.movi       v1, #0
    v.splat      v2, s6
    v.splat      v5, s4
    v.movi       v6, #0
    v.splat      v7, s9
    s.muli       s6, s1, #2
    v.cmp.ge     p1, v4, v1
    v.cmp.lt     p2, v4, v2
    v.cmp.ge     p3, v5, v6
    v.cmp.lt     p4, v5, v7
    s.add        s9, s2, s10
    p.and        p5, p1, p2
    s.add        s10, s9, s6
    v.splat      v1, s1
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s6, #128
    s.movz       s9, #16
    s.muli       s11, s4, #512
    v.add        v4, v1, v2
    v.movi       v1, #0
    v.splat      v2, s6
    v.splat      v5, s4
    v.movi       v6, #0
    v.splat      v7, s9
    s.muli       s6, s1, #4
    v.cmp.ge     p1, v4, v1
    v.cmp.lt     p2, v4, v2
    s.add        s9, s3, s11
    p.and        p6, p1, p2
    v.cmp.ge     p1, v5, v6
    v.splat      v1, s1
    p.and        p2, p3, p4
    v.cmp.lt     p3, v5, v7
    p.and        p4, p1, p3
    s.add        s11, s9, s6
    p.and        p1, p6, p4
    v.add        v2, v1, v0
    p.and        p3, p5, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s11, #0]
    v.movi       v4, #128
    s.shli       s6, s1, #2                      // element offset -> bytes (x4)
    s.add        s9, s5, s6                      // &in_ptr1[...]
    v.cmp.lt     p1, v2, v4
    .li       s6, #1124073472
    v.splat      v4, s6                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v5, v4                          // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v6, [s10, #0]
    vf.cvt.bf16.f32 v7, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s9, #0]
    .li       s6, #1069066811
    v.splat      v8, s6                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s6, #1065353216
    v.splat      v9, s6                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s6, #1060205080
    v.splat      v10, s6                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.neg       v11, v7
    vf.fms       v12, v4, v5, v9
    .li       s6, #897988541
    v.splat      v4, s6                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s6, #1065353216
    v.splat      v13, s6                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.mul        s6, s4, s7
    vf.fms       v14, v5, v12, v5
    s.add        s9, s1, s8
    s.add        s10, s1, s6
    vf.neg       v12, v14                        // Newton step: r0*(2 - x*r0)
    s.shli       s11, s10, #1                    // element offset -> bytes (x2)
    s.add        s10, s2, s11                    // &in_out_ptr0[...]
    vf.cmp.o     p2, v12, v12
    @p2 v.sel        v14, v12, v5
    vf.mul       v5, v11, v8
    s.movz       s11, #1
    vf.mul       v12, v3, v14                    // a/y as a refined reciprocal (ISA has no divide)
    .li       s12, #1077936128
    v.splat      v14, s12                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v15, v11, v8, v5                // the exact rounding error of x*log2(e)
    v.exp2.approx v8, v5                         // ISA 8.8: <= 2**-22 relative
    vf.add       v5, v12, v4
    .li       s12, #3204448256
    v.splat      v4, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v11, s6
    vf.mul       v12, v15, v10
    v.rsqrt.approx v10, v5                       // ISA 8.8: <= 2**-22 relative
    v.add        v15, v2, v11
    vf.fma       v2, v8, v12, v8                 // 2**t * 2**d
    vf.cmp.o     p2, v2, v2
    @p2 v.sel        v11, v2, v8
    vf.mul       v2, v10, v10
    vf.mul       v8, v10, v4
    vf.add       v4, v11, v13
    vf.fms       v11, v5, v2, v14
    v.rcp.approx v2, v4                          // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v8, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v5, v5
    @p2 v.sel        v8, v5, v10
    v.extract    s6, v8, #0
    v.splat      v5, s6
    vf.mul       v8, v1, v5
    vf.mul       v1, v6, v8
    vf.fms       v5, v4, v2, v9
    vf.fms       v4, v2, v5, v2
    vf.neg       v5, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v5, v5
    @p2 v.sel        v4, v5, v2
    vf.mul       v2, v7, v4                      // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v4, v1, v2
    vf.cvt.f32.bf16 v1, v4
    @p1 v.st.h       [s10, #0], v1
    s.mov        s1, s9
    br.nz        s11, for_3
endfor_4:
__rctx_next:
    exit
