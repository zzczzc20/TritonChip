    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.movi       v0, #0
    v.movi       v1, #0
    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    s.ld.d       s3, [s1, #0]                    // in_out_ptr0: device_ptr64 at arg_base+0
    s.movz       s5, #128
    s.movz       s6, #16
    v.splat      v2, s4
    v.iota       v3                              // arange(0, VLEN)
    s.addi       s7, s2, #0
    s.ld.d       s8, [s1, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    s.ld.d       s9, [s1, #16]                   // in_ptr1: device_ptr64 at arg_base+16
    s.ld.d       s10, [s1, #24]                  // in_ptr2: device_ptr64 at arg_base+24
    s.ld.d       s11, [s1, #32]                  // in_ptr3: device_ptr64 at arg_base+32
    s.ld.d       s12, [s1, #40]                  // in_ptr4: device_ptr64 at arg_base+40
    v.mov        v1, v0
for_1:
    s.cmp.ge     s1, s7, s5
    br.nz        s1, endfor_2
    v.movi       v4, #0
    v.movi       v5, #4
    v.movi       v6, #0
    v.sub        v7, v4, v2
    v.cmp.lt     p1, v2, v4
    v.movi       v8, #0
    @p1 v.sel        v9, v7, v2
    v.movi       v7, #63
    v.sub        v10, v8, v2
    v.lshr       v11, v9, v5
    v.cmp.lt     p2, v2, v8
    @p2 v.sel        v5, v10, v2
    v.sub        v9, v4, v11
    v.movi       v10, #15
    v.movi       v12, #128
    @p1 v.sel        v13, v9, v11
    v.and        v9, v5, v10
    v.splat      v5, s7
    v.sub        v10, v6, v13
    v.cmp.lt     p1, v13, v6
    v.sub        v11, v8, v9
    @p1 v.sel        v14, v10, v13
    v.movi       v10, #8192
    @p2 v.sel        v13, v11, v9
    v.and        v9, v14, v7
    v.add        v7, v5, v3
    v.mul        v5, v13, v10
    v.sub        v10, v6, v9
    v.movi       v11, #128
    v.extract    s1, v5, #0
    @p1 v.sel        v5, v10, v9
    v.cmp.lt     p1, v7, v11
    v.splat      v9, s1
    v.mul        v10, v5, v12
    v.movi       v5, #16
    v.movi       v11, #64
    v.extract    s1, v10, #0
    v.sub        v10, v4, v5
    v.splat      v12, s1
    v.sub        v13, v6, v11
    v.sub        v14, v8, v5
    v.add        v15, v7, v12
    v.cmp.lt     p2, v5, v4
    v.cmp.lt     p3, v11, v6
    v.add        v4, v15, v9
    v.cmp.lt     p4, v5, v8
    v.movi       v6, #1
    v.movi       v6, #0
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v7, [s10, v4]              // index is in elements (ISA sec 9.1)
    v.movi       v8, #1024
    @p2 v.sel        v9, v10, v5
    v.sub        v9, v6, v2
    v.cmp.lt     p2, v2, v6
    v.movi       v10, #10
    @p2 v.sel        v12, v9, v2
    v.sub        v9, v6, v8
    v.movi       v15, #1
    v.lshr       v15, v12, v10
    v.movi       v10, #1
    @p3 v.sel        v12, v13, v11
    v.sub        v11, v6, v15
    v.movi       v12, #0
    v.movi       v13, #1
    @p2 v.sel        v16, v11, v15
    v.movi       v11, #0
    v.cmp.lt     p2, v8, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v6, [s11, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.eq     p3, v16, v12
    @p3 v.sel        v12, v13, v11
    v.cmp.eq     p3, v16, v10
    v.movi       v10, #0
    v.extract    s1, v12, #0
    v.movi       v11, #1
    v.movi       v11, #1
    v.movi       v12, #0
    v.splat      v13, s1
    v.movi       v15, #0
    @p3 v.sel        v16, v11, v12
    v.cmp.ne     p3, v13, v10
    @p4 v.sel        v10, v14, v5
    v.extract    s1, v16, #0
    s.movz       s13, #8192
    v.splat      v5, s1
    v.movi       v10, #0
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.w v11, [s8, v4]              // index is in elements (ISA sec 9.1)
    vf.add       v12, v7, v6
    v.cmp.ne     p4, v5, v15
    s.add        s1, s7, s6
    s.movz       s13, #1
    v.movi       v5, #1
    @p3 v.sel        v5, v12, v0
    @p2 v.sel        v6, v9, v8
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v6, [s9, v4]               // index is in elements (ISA sec 9.1)
    vf.add       v4, v11, v6
    @p4 v.sel        v6, v4, v5
    vf.mul       v4, v6, v6
    vf.add       v5, v1, v4
    @p1 v.sel        v4, v5, v1
    v.mov        v10, v4
    v.mov        v1, v10
    s.mov        s7, s1
    br.nz        s13, for_1
endfor_2:
    s.rdspecial  s1, arg_base
    s.rdspecial  s7, role_id
    s.ld.d       s13, [s1, #64]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.movz       s1, #256
    vf.reduce.add.b v4, v1
    s.mul        s14, s7, s1
    v.movi       v1, #0
    s.movz       s1, #2048
    s.movz       s7, #128
    s.movz       s15, #256
    s.movz       s16, #2
    .li       s17, #68719476737
    vf.add       v5, v4, v1
    s.add        s18, s13, s14                   // this context's own scratch
    .li       s13, #1108101562368
    s.addi       s14, s18, #0                    // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s18, #0
    s.st.d       [s14, #0], s3
    s.addi       s18, s2, #0
    s.st.d       [s14, #8], s1
    s.st.d       [s14, #16], s7
    s.st.d       [s14, #48], s15
    s.st.d       [s14, #56], s16
    s.st.d       [s14, #88], s17
    s.st.d       [s14, #104], s13
    fence.release.device
    td.load      d0, [s14]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
for_3:
    s.cmp.ge     s1, s18, s5
    br.nz        s1, endfor_4
    v.movi       v1, #0
    v.movi       v4, #4
    v.movi       v6, #0
    v.sub        v7, v1, v2
    v.cmp.lt     p1, v2, v1
    v.movi       v8, #0
    @p1 v.sel        v9, v7, v2
    v.movi       v7, #63
    v.sub        v10, v8, v2
    v.lshr       v11, v9, v4
    v.cmp.lt     p2, v2, v8
    @p2 v.sel        v4, v10, v2
    v.sub        v9, v1, v11
    v.movi       v10, #15
    v.movi       v12, #128
    @p1 v.sel        v13, v9, v11
    v.and        v9, v4, v10
    v.splat      v4, s18
    v.sub        v10, v6, v13
    v.cmp.lt     p1, v13, v6
    v.sub        v11, v8, v9
    @p1 v.sel        v14, v10, v13
    v.add        v10, v4, v3
    @p2 v.sel        v4, v11, v9
    v.and        v9, v14, v7
    v.movi       v7, #128
    s.shli       s1, s18, #2                     // element offset -> bytes (x4)
    v.sub        v11, v6, v9
    v.cmp.lt     p2, v10, v7
    v.movi       v7, #8192
    @p1 v.sel        v13, v11, v9
    s.add        s2, s12, s1                     // &in_ptr4[...]
    v.mul        v9, v4, v7
    v.mul        v4, v13, v12
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s2, #0]
    v.extract    s1, v9, #0
    v.extract    s2, v4, #0
    v.splat      v4, s1
    v.splat      v9, s2
    v.movi       v11, #16
    v.movi       v12, #64
    v.add        v13, v10, v9
    v.sub        v9, v1, v11
    v.sub        v14, v6, v12
    v.add        v15, v13, v4
    v.sub        v4, v8, v11
    v.cmp.lt     p1, v11, v1
    v.cmp.lt     p3, v12, v6
    v.cmp.lt     p4, v11, v8
    v.movi       v1, #1
    s.muli       s1, s4, #256
    s.muli       s2, s18, #2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s10, v15]             // index is in elements (ISA sec 9.1)
    @p1 v.sel        v6, v9, v11
    v.splat      v6, s18
    v.iota       v8                              // arange(0, VLEN)
    s.movz       s7, #128
    v.movi       v9, #0
    v.add        v13, v6, v8
    s.add        s13, s3, s1
    v.movi       v6, #1
    v.splat      v6, s7
    v.splat      v8, s4
    v.movi       v16, #0
    v.cmp.ge     p1, v13, v9
    v.cmp.lt     p5, v13, v6
    p.and        p6, p1, p5
    v.cmp.ge     p1, v8, v16
    s.add        s1, s13, s2
    @p3 v.sel        v6, v14, v12
    s.movz       s2, #2048
    v.movi       v6, #0
    v.splat      v9, s2
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v12, [s11, v15]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v2, v6
    v.movi       v13, #1024
    v.movi       v14, #1
    v.sub        v14, v6, v2
    v.movi       v16, #10
    v.sub        v17, v6, v13
    @p3 v.sel        v18, v14, v2
    @p4 v.sel        v14, v4, v11
    v.cmp.lt     p4, v8, v9
    p.and        p5, p1, p4
    v.lshr       v4, v18, v16
    p.and        p1, p6, p5
    v.movi       v8, #1
    v.sub        v9, v6, v4
    v.cmp.lt     p4, v13, v6
    s.movz       s2, #8192
    @p3 v.sel        v6, v9, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s1, #0]
    v.movi       v9, #0
    v.movi       v11, #1
    v.movi       v14, #0
    v.cmp.eq     p1, v6, v9
    v.cmp.eq     p3, v6, v8
    vf.add       v6, v1, v12
    v.movi       v1, #1
    @p4 v.sel        v1, v17, v13
    vf.cvt.bf16.f32 v1, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s8, v15]              // index is in elements (ISA sec 9.1)
    @p1 v.sel        v8, v11, v14
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v9, [s9, v15]              // index is in elements (ISA sec 9.1)
    .li       s1, #1124073472
    v.splat      v11, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.neg       v12, v1
    .li       s1, #1069066811
    v.splat      v13, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v14, v11                        // ISA 8.8: <= 2**-22 relative
    .li       s1, #1065353216
    v.splat      v15, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #897988541
    v.splat      v16, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v17, v12, v13
    .li       s1, #1077936128
    v.splat      v18, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.extract    s1, v8, #0
    .li       s2, #3204448256
    v.splat      v8, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v19, v12, v13, v17              // the exact rounding error of x*log2(e)
    v.movi       v12, #1
    vf.add       v13, v4, v9
    v.exp2.approx v4, v17                        // ISA 8.8: <= 2**-22 relative
    .li       s2, #1060205080
    v.splat      v9, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v17, v19, v9
    .li       s2, #1065353216
    v.splat      v9, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v19, v11, v14, v15
    vf.fms       v11, v14, v19, v14
    vf.neg       v19, v11                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v11, v19, v14
    vf.fma       v14, v4, v17, v4                // 2**t * 2**d
    v.movi       v17, #0
    vf.mul       v19, v5, v11                    // a/y as a refined reciprocal (ISA has no divide)
    v.splat      v11, s1
    @p3 v.sel        v20, v12, v17
    vf.cmp.o     p1, v14, v14
    @p1 v.sel        v12, v14, v4
    vf.add       v4, v19, v16
    v.movi       v14, #0
    vf.add       v16, v12, v9
    v.extract    s1, v20, #0
    v.cmp.ne     p1, v11, v14
    v.rsqrt.approx v9, v4                        // ISA 8.8: <= 2**-22 relative
    v.splat      v11, s1
    v.rcp.approx v12, v16                        // ISA 8.8: <= 2**-22 relative
    v.movi       v14, #0
    @p1 v.sel        v17, v6, v0
    s.mul        s1, s4, s5
    v.cmp.ne     p1, v11, v14
    @p1 v.sel        v6, v13, v17
    s.add        s2, s18, s6
    s.movz       s7, #1
    s.add        s13, s18, s1
    v.splat      v11, s1
    s.shli       s1, s13, #1                     // element offset -> bytes (x2)
    s.add        s13, s3, s1                     // &in_out_ptr0[...]
    v.add        v13, v10, v11
    vf.mul       v10, v9, v9
    vf.mul       v11, v9, v8
    vf.fms       v8, v16, v12, v15
    vf.fms       v13, v4, v10, v18
    vf.fms       v4, v12, v8, v12
    vf.mul       v8, v11, v13                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.neg       v10, v4                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v9
    vf.cmp.o     p1, v10, v10
    @p1 v.sel        v8, v10, v12
    v.extract    s1, v4, #0
    v.splat      v4, s1
    vf.mul       v9, v1, v8                      // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v1, v6, v4
    vf.mul       v4, v7, v1
    vf.mul       v1, v4, v9
    vf.cvt.f32.bf16 v4, v1
    @p2 v.st.h       [s13, #0], v4
    s.mov        s18, s2
    br.nz        s7, for_3
endfor_4:
__rctx_next:
    exit
