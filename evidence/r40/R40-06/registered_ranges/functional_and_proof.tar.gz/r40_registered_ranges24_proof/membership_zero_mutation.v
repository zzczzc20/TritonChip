`default_nettype none
module member_gold(input [63:0] a,b,z,output result);
assign result=(a >= b) && ((z == 64'd0) || (a-b < z));
endmodule
module member_gate(input [63:0] a,b,z,output result);
wire [64:0] endpoint=(z == 64'd0) ?
                            {1'b0, 64'd0} :
                            ({1'b0, b} + {1'b0, z});
assign result=(a >= b) && (endpoint[64] || (a < endpoint[63:0]));
endmodule
