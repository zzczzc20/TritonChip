    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.shli       s2, s4, #4                      // x16 as a shift
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s2
    s.ld.d       s4, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.shli       s5, s2, #1                      // element offset -> bytes (x2)
    v.add        v2, v1, v0
    .li       s2, #217600
    v.splat      v0, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s2, s3, s5                      // &in_ptr0[...]
    s.add        s3, s4, s5                      // &in_ptr1[...]
    s.ld.d       s4, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.cmp.lt     p1, v2, v0
    @p1 v.ld.h       v0, [s2, #0]
    s.add        s2, s4, s5                      // &in_ptr2[...]
    @p1 v.ld.h       v1, [s3, #0]
    vf.cvt.bf16.f32 v2, v0
    @p1 v.ld.h       v0, [s2, #0]
    vf.cvt.bf16.f32 v3, v1
    vf.add       v1, v2, v3
    vf.cvt.bf16.f32 v2, v0
    s.ld.d       s2, [s1, #24]                   // out_ptr0: device_ptr64 at arg_base+24
    vf.add       v0, v1, v2
    s.add        s1, s2, s5                      // &out_ptr0[...]
    vf.cvt.f32.bf16 v1, v0
    @p1 v.st.h       [s1, #0], v1
__rctx_next:
    exit
