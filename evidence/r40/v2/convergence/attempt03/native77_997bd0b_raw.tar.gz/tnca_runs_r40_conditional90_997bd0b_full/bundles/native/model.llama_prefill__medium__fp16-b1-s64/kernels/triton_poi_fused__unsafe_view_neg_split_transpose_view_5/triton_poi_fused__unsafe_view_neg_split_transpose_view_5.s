    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #4
    v.add        v4, v1, v0
    v.movi       v0, #0
    v.movi       v1, #0
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    v.sub        v6, v0, v4
    @p1 v.sel        v7, v5, v4
    v.movi       v5, #0
    v.cmp.lt     p2, v4, v0
    v.lshr       v8, v7, v3
    v.cmp.lt     p3, v4, v1
    @p2 v.sel        v3, v6, v4
    v.sub        v6, v2, v8
    v.movi       v7, #15
    v.movi       v9, #63
    @p1 v.sel        v10, v6, v8
    v.and        v6, v3, v7
    s.rdspecial  s1, arg_base
    v.sub        v3, v1, v4
    v.sub        v7, v5, v10
    v.cmp.lt     p1, v10, v5
    v.sub        v8, v0, v6
    @p1 v.sel        v11, v7, v10
    v.movi       v7, #16
    @p2 v.sel        v12, v8, v6
    v.and        v6, v11, v9
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    @p3 v.sel        v8, v3, v4
    v.sub        v3, v5, v6
    v.movi       v9, #64
    v.movi       v11, #2048
    @p1 v.sel        v13, v3, v6
    v.movi       v3, #1024
    v.cmp.lt     p1, v4, v11
    v.sub        v4, v0, v7
    v.sub        v6, v2, v7
    v.cmp.lt     p2, v7, v0
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.movi       v0, #10
    v.mul        v11, v13, v9
    v.cmp.lt     p4, v7, v2
    v.lshr       v2, v8, v0
    v.movi       v0, #32
    v.add        v8, v12, v7
    @p2 v.sel        v13, v4, v7
    v.sub        v4, v1, v2
    v.mul        v13, v10, v0
    v.cmp.lt     p2, v9, v5
    @p3 v.sel        v10, v4, v2
    v.sub        v2, v5, v9
    v.sub        v4, v1, v3
    v.mul        v5, v10, v0
    v.add        v0, v12, v13
    v.cmp.lt     p3, v3, v1
    v.add        v1, v8, v5
    @p4 v.sel        v5, v6, v7
    @p2 v.sel        v5, v2, v9
    v.add        v2, v1, v11
    @p3 v.sel        v1, v4, v3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s2, v2]               // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v2, v1
    vf.neg       v1, v2
    vf.cvt.f32.f16 v2, v1
    @p1 v.st.scatter.h [s3, v0], v2
__rctx_next:
    exit
