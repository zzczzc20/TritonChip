#!/bin/bash
source ~/tc_env/env.sh
cd /tmp/r40_tmu_control18 || exit 2
export PYTHONPATH="$PWD/python:$PWD/compiler/python:$PWD/tools/asm"
CUDA_VISIBLE_DEVICES='' "$HOME/tc_env/torchenv/bin/python" tools/r40/tmu_control_rtl_tests.py --out /tmp/r40_tmu_control18_results > /tmp/r40_tmu_control18.log 2>&1
rc=$?
printf '%s
' "$rc" > /tmp/r40_tmu_control18.exit
exit "$rc"
