    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #5
    v.add        v4, v1, v0
    v.movi       v0, #0
    v.movi       v1, #0
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    v.movi       v6, #0
    @p1 v.sel        v7, v5, v4
    v.cmp.lt     p2, v4, v0
    v.sub        v5, v1, v4
    v.lshr       v8, v7, v3
    v.cmp.lt     p3, v4, v1
    @p3 v.sel        v3, v5, v4
    v.sub        v5, v2, v8
    v.movi       v7, #31
    v.movi       v9, #63
    @p1 v.sel        v10, v5, v8
    v.and        v5, v3, v7
    s.rdspecial  s2, arg_base
    v.sub        v3, v0, v4
    v.sub        v7, v6, v10
    v.cmp.lt     p1, v10, v6
    v.movi       v8, #32
    @p1 v.sel        v11, v7, v10
    v.sub        v7, v1, v5
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    @p2 v.sel        v10, v3, v4
    v.and        v3, v11, v9
    @p3 v.sel        v9, v7, v5
    v.movi       v5, #10240
    v.sub        v7, v6, v3
    v.cmp.lt     p3, v8, v1
    v.cmp.lt     p4, v4, v5
    @p1 v.sel        v4, v7, v3
    v.movi       v3, #64
    v.movi       v5, #2048
    s.ld.d       s4, [s2, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.movi       v7, #11
    v.sub        v11, v1, v8
    v.cmp.lt     p1, v8, v2
    v.lshr       v1, v10, v7
    v.movi       v7, #480
    v.sub        v10, v2, v8
    @p3 v.sel        v2, v11, v8
    v.sub        v2, v0, v1
    v.mul        v11, v4, v7
    .li       s2, #1054295293
    v.splat      v4, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p2 v.sel        v7, v2, v1
    s.shli       s2, s1, #2                      // element offset -> bytes (x4)
    v.sub        v1, v6, v3
    v.mul        v2, v7, v8
    s.add        s1, s4, s2                      // &out_ptr0[...]
    v.cmp.lt     p2, v3, v6
    v.add        v6, v9, v2
    v.sub        v2, v0, v5
    v.cmp.lt     p3, v5, v0
    v.add        v0, v6, v11
    @p1 v.sel        v6, v10, v8
    @p2 v.sel        v6, v1, v3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v1, [s3, v0]               // index is in elements (ISA sec 9.1)
    @p3 v.sel        v0, v2, v5
    vf.cvt.f16.f32 v0, v1
    vf.mul       v1, v0, v4
    @p4 v.st.w       [s1, #0], v1
__rctx_next:
    exit
