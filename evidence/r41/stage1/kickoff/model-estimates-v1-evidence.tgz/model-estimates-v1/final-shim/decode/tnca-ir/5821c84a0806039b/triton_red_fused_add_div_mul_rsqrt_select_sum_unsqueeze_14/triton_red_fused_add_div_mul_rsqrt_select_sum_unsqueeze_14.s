    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // out_ptr0: device_ptr64 at arg_base+24
    s.rdspecial  s1, arg_base
    s.ld.d       s7, [s1, #48]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s8, #256
    s.mul        s9, s1, s8
    s.add        s1, s7, s9                      // this context's own scratch
    s.addi       s7, s1, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s7, #0], s3
    s.movz       s1, #16
    s.st.d       [s7, #8], s1
    s.movz       s1, #128
    s.st.d       [s7, #16], s1
    s.movz       s1, #512
    s.st.d       [s7, #48], s1
    s.movz       s1, #4
    s.st.d       [s7, #56], s1
    .li       s1, #68719476737
    s.st.d       [s7, #88], s1
    .li       s1, #2207613190144
    s.st.d       [s7, #104], s1
    fence.release.device
    td.load      d0, [s7]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #1
    s.movz       s7, #0
    s.movz       s8, #128
    s.movz       s9, #16
    v.splat      v0, s4
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v2, #128
    v.movi       v3, #0
    v.movi       v4, #1
    v.cmp.lt     p1, v0, v3
    v.cmp.lt     p2, v2, v3
    v.sub        v4, v3, v0
    @p1 v.sel        v5, v4, v0
    v.sub        v4, v3, v2
    @p2 v.sel        v6, v4, v2
    v.movi       v4, #127
    v.and        v6, v5, v4
    v.sub        v4, v3, v6
    @p1 v.sel        v3, v4, v6
    v.movi       v4, #0
    v.movi       v5, #1
    v.cmp.lt     p1, v0, v4
    v.cmp.lt     p2, v2, v4
    v.sub        v5, v4, v0
    @p1 v.sel        v6, v5, v0
    v.sub        v0, v4, v2
    @p2 v.sel        v5, v0, v2
    v.movi       v0, #7
    v.lshr       v2, v6, v0
    v.sub        v0, v4, v2
    @p1 v.sel        v4, v0, v2
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v2, s1
    v.cmp.lt     p1, v0, v2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v0, [s5, v4]               // index is in elements (ISA sec 9.1)
    s.addi       s1, s7, #0
    v.movi       v2, #0
    v.movi       v5, #0
    v.mov        v5, v2
for_1:
    s.cmp.ge     s5, s1, s8
    br.nz        s5, endfor_2
    s.movz       s5, #0
    s.movz       s7, #0
    s.cmp.lt     s10, s4, s5
    s.movz       s5, #0
    s.sub        s11, s7, s10
    s.movz       s7, #0
    s.cmp.lt     s10, s8, s5
    s.xor        s5, s4, s11
    s.sub        s12, s7, s10
    s.sub        s7, s5, s11
    s.xor        s5, s11, s12
    s.lshri      s10, s7, #7
    v.splat      v2, s1
    s.xor        s11, s10, s5
    v.iota       v6                              // arange(0, VLEN)
    s.sub        s13, s11, s5
    s.movz       s5, #128
    s.muli       s11, s13, #512
    v.add        v7, v2, v6
    v.movi       v2, #0
    v.splat      v6, s5
    v.splat      v8, s13
    v.movi       v9, #0
    s.muli       s5, s1, #4
    v.splat      v10, s1
    v.cmp.ge     p1, v7, v2
    v.cmp.lt     p2, v7, v6
    v.cmp.ge     p3, v8, v9
    v.movi       v2, #16384
    s.add        s13, s3, s11
    p.and        p4, p1, p2
    v.add        v6, v10, v1
    s.movz       s11, #16
    v.movi       v7, #128
    v.splat      v9, s11
    s.add        s11, s13, s5
    v.extract    s5, v3, #0
    v.mul        v10, v4, v2
    v.mul        v2, v6, v7
    v.splat      v11, s5
    v.extract    s5, v10, #0
    v.cmp.lt     p1, v6, v7
    v.cmp.lt     p2, v8, v9
    p.and        p5, p3, p2
    v.add        v6, v11, v2
    .li       s13, #897988541
    v.splat      v2, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    p.and        p2, p4, p5
    v.splat      v7, s5
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v8, [s11, #0]
    s.muli       s5, s10, #128
    v.add        v9, v6, v7
    s.xor        s10, s8, s12
    s.movz       s11, #16384
    vf.add       v6, v0, v2
    .li       s11, #1077936128
    v.splat      v2, s11                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s11, #3204448256
    v.splat      v7, s11                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.sub        s11, s10, s12
    s.sub        s10, s7, s5
    v.rsqrt.approx v10, v6                       // ISA 8.8: <= 2**-22 relative
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.w v11, [s2, v9]              // index is in elements (ISA sec 9.1)
    .li       s5, #1035273459
    v.splat      v9, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v12, #0
    s.add        s5, s1, s9
    s.movz       s7, #1
    vf.mul       v13, v10, v10
    vf.mul       v14, v10, v7
    vf.fms       v7, v6, v13, v2
    vf.mul       v2, v14, v7                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v2, v2
    @p2 v.sel        v6, v2, v10
    v.extract    s10, v6, #0
    v.splat      v2, s10
    vf.mul       v6, v8, v2
    vf.mul       v2, v6, v9
    vf.mul       v6, v11, v2
    vf.add       v2, v5, v6
    @p1 v.sel        v6, v2, v5
    v.mov        v12, v6
    v.mov        v5, v12
    s.mov        s1, s5
    br.nz        s7, for_1
endfor_2:
    vf.reduce.add.b v0, v5
    v.movi       v1, #0
    s.movz       s1, #1
    s.shli       s2, s4, #2                      // element offset -> bytes (x4)
    vf.add       v2, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.add        s1, s6, s2                      // &out_ptr0[...]
    v.cmp.lt     p1, v0, v1
    @p1 v.st.w       [s1, #0], v2
__rctx_next:
    exit
