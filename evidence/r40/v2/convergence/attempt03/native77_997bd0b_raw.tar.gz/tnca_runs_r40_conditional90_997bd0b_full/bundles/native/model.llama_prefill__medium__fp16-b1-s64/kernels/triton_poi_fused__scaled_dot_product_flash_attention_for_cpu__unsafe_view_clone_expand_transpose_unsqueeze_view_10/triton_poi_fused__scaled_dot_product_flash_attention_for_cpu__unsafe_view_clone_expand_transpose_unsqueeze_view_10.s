    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    v.movi       v1, #0
    v.movi       v2, #5
    v.movi       v3, #0
    v.movi       v4, #0
    v.splat      v5, s2
    v.movi       v6, #0
    v.movi       v7, #31
    v.add        v8, v5, v0
    v.movi       v0, #63
    v.movi       v5, #32
    v.sub        v9, v1, v8
    v.cmp.lt     p1, v8, v1
    v.sub        v10, v4, v8
    @p1 v.sel        v11, v9, v8
    v.cmp.lt     p2, v8, v4
    @p2 v.sel        v9, v10, v8
    v.lshr       v10, v11, v2
    v.movi       v2, #64
    v.and        v11, v9, v7
    v.sub        v7, v1, v10
    v.movi       v9, #2048
    v.sub        v12, v4, v5
    @p1 v.sel        v13, v7, v10
    v.sub        v7, v4, v11
    v.sub        v10, v1, v5
    v.cmp.lt     p1, v13, v6
    s.rdspecial  s1, arg_base
    v.cmp.lt     p3, v5, v4
    v.sub        v4, v6, v13
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v14, #1
    @p1 v.sel        v14, v4, v13
    v.sub        v4, v6, v2
    @p3 v.sel        v13, v12, v5
    v.cmp.lt     p3, v8, v3
    v.and        v12, v14, v0
    @p2 v.sel        v0, v7, v11
    v.cmp.lt     p2, v5, v1
    v.sub        v1, v6, v12
    v.movi       v7, #1
    s.ld.d       s4, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.sub        v7, v3, v8
    v.movi       v11, #11
    v.movi       v13, #3
    @p3 v.sel        v14, v7, v8
    v.movi       v7, #0
    @p2 v.sel        v8, v10, v5
    v.lshr       v8, v14, v11
    v.sub        v10, v3, v9
    v.sub        v11, v7, v13
    v.cmp.lt     p2, v2, v6
    v.sub        v6, v3, v8
    v.movi       v14, #1
    @p2 v.sel        v14, v4, v2
    @p3 v.sel        v4, v6, v8
    v.cmp.lt     p2, v9, v3
    v.cmp.lt     p3, v13, v7
    v.sub        v3, v7, v4
    @p1 v.sel        v6, v1, v12
    v.cmp.lt     p1, v4, v7
    v.movi       v1, #1
    @p2 v.sel        v1, v10, v9
    v.movi       v1, #1
    @p1 v.sel        v8, v3, v4
    @p3 v.sel        v3, v11, v13
    v.movi       v4, #0
    v.movi       v9, #0
    s.movz       s1, #31
idiv_1:
    v.splat      v10, s1
    v.shl        v11, v9, v1
    v.cmp.lt     p2, v9, v7
    v.lshr       v12, v8, v10
    v.shl        v13, v1, v10
    s.subi       s5, s1, #1
    v.and        v10, v12, v1
    s.movz       s6, #0
    v.or         v12, v11, v10
    v.cmp.geu    p4, v12, v3
    p.or         p5, p2, p4
    v.sub        v10, v12, v3
    @p5 v.sel        v11, v13, v7
    @p5 v.sel        v13, v10, v12
    v.or         v10, v4, v11
    v.mov        v9, v13
    v.mov        v4, v10
    s.mov        s1, s5
    s.cmp.ge     s5, s1, s6
    br.nz        s5, idiv_1
    v.sub        v1, v7, v4
    p.xor        p2, p1, p3
    v.mul        v3, v6, v2
    @p2 v.sel        v2, v1, v4
    s.shli       s1, s2, #2                      // element offset -> bytes (x4)
    s.movz       s2, #32
    v.mul        v1, v2, v5
    s.add        s2, s4, s1                      // &out_ptr0[...]
    s.movz       s1, #64
    v.add        v2, v0, v1
    v.add        v0, v2, v3
    v.ld.gather.h v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v0, v1
    v.st.w       [s2, #0], v0
__rctx_next:
    exit
