from pathlib import Path
import subprocess,json
r=Path.cwd();out=r/'results';out.mkdir(exist_ok=False);records=[]
def step(name,args,expected=0):
 p=subprocess.run(args,capture_output=True,text=True,timeout=600);s=p.stdout+p.stderr;(out/(name+'.log')).write_text(s);assert p.returncode==expected,(name,p.returncode,s[-3500:]);return s
def record(name,text):
 records.append(dict(name=name,stdout=text));(out/'report.json').write_text(json.dumps(records,indent=2)+'\n');print(name,flush=True)
cmd='read_verilog formal_tlw.v; prep -top miter -flatten; sat -verify -prove mismatch 0 -show-inputs'
s=step('formal',['yosys','-p',cmd]);assert 'SUCCESS' in s,s;record('formal_all_inputs_equivalent',s)
src=(r/'formal_tlw.v').read_text();assert src.count('(cur_lsb > tlw_bit)')==1
(r/'mutant.v').write_text(src.replace('(cur_lsb > tlw_bit)','(cur_lsb >= tlw_bit)'))
s=step('formal_mutation',['yosys','-p',cmd.replace('formal_tlw.v','mutant.v')],1);assert 'proof did fail' in s or 'FAIL' in s,s;record('formal_off_by_one_mutation_detected',s)
for policy in [46,78]:
 for seed in [1,7]:
  name=f'policy{policy}_seed{seed}';binary=str(out/(name+'.vvp'));args=['iverilog','-g2012','-I','rtl/common','-s','tb_nuca_slice','-Ptb_nuca_slice.SETS=32','-Ptb_nuca_slice.SET_W=5','-Ptb_nuca_slice.WAYS=8','-Ptb_nuca_slice.WAY_W=3','-Ptb_nuca_slice.REGISTER_VICTIM_OWNER=1','-Ptb_nuca_slice.DCO_REGISTERED_RANGES=1','-Ptb_nuca_slice.AMO_TRAFFIC=1',f'-Ptb_nuca_slice.POLICY={policy}','-o',binary,'rtl/nuca/tnca_nuca_slice.v','rtl/nuca/tnca_nuca_slice_before.v','tb/common/tnca_dram_model.v','tb/nuca/tb_tlw_predicate.v']
  step(name+'_build',args);s=step(name,['vvp',binary,'+nreq=4000',f'+seed={seed}','+min_wb=1']);assert 'PASS' in s.splitlines() and 'FATAL' not in s and 'FAIL' not in s,s;record(name+'_pass',s)
print('TLW_PREDICATE_FUNCTIONAL_DONE',flush=True)
