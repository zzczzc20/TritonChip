# AOT ID: ['47_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /home/zhongchun/r41-fp8-ops-work/v3/std/inductor-cache/ac/cac7cmfgnxg32pw6tjsjct6l226poapahr2i7ypk7hto7pebe57a.py
# Topologically Sorted Source Nodes: [eq, getitem], Original ATen: [aten.eq, aten.index]
# Source node to ATen node mapping:
#   eq => eq
#   getitem => cumsum, sum_1, view
# Graph fragment:
#   %arg0_1 : Tensor "i64[2, 128][128, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %eq : Tensor "b8[2, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.eq.Scalar](args = (%arg0_1, 7), kwargs = {})
#   %view : Tensor "b8[256][1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.reshape.default](args = (%eq, [-1]), kwargs = {})
#   %sum_1 : Tensor "i64[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sum.default](args = (%view,), kwargs = {})
#   %cumsum : Tensor "i64[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cumsum.default](args = (%view, 0), kwargs = {})
#   return %sum_1,%cumsum
triton_red_fused_eq_index_0 = async_compile.triton('triton_red_fused_eq_index_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton.jit
def _triton_helper_fn_add0(arg0_0, arg1_0):
    tmp0 = arg0_0 + arg1_0
    return tmp0

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 256},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'out_ptr0': '*i64', 'out_ptr1': '*i64', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_eq_index_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 1, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 6144}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_eq_index_0(in_ptr0, out_ptr0, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 256
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    _tmp5 = tl.full([R0_BLOCK], 0, tl.int64)
    tmp9 = tl.full([1], 0, tl.int64)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0)
        tmp1 = tl.full([1], 7, tl.int64)
        tmp2 = tmp0 == tmp1
        tmp3 = tmp2.to(tl.int64)
        tmp4 = tl.broadcast_to(tmp3, [R0_BLOCK])
        tmp6 = _tmp5 + tmp4
        _tmp5 = tl.where(r0_mask, tmp6, _tmp5)
        tmp7 = tmp3.to(tl.int64)
        tmp8 = tl.broadcast_to(tmp7, [R0_BLOCK])
        tmp10, = tl.associative_scan((tmp8,), 0, _triton_helper_fn_add0)
        tmp11 = triton_helpers.select_one((tmp10), rbase == (RBLOCK - 1), dim=-1, keep_dims=True)
        tmp12 = tmp9 + tmp11
        tmp13 = tmp9 + tmp10
        tmp14 = tl.where(roffset > 0, tmp13, tmp10)
        tmp9 = tl.where(roffset > 0, tmp12, tmp11)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp14, r0_mask)
    tmp5 = triton_helpers.promote_to_tensor(tl.sum(_tmp5, 0))
    tl.store(out_ptr0 + (tl.full([1], 0, tl.int32)), tmp5, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-fp8-ops-work/v3/std/inductor-cache/hm/chm2r6fhgncqcuirzhfowoubo2cf34jizkdviklmtb6j7adlhf6w.py
# Topologically Sorted Source Nodes: [getitem], Original ATen: [aten.index]
# Source node to ATen node mapping:
#   getitem => full_1
# Graph fragment:
#   %buf1 : Tensor  = PlaceHolder[target=buf1]
#   %full_1 : Tensor "i64[u0 + 1][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([%add], 0), kwargs = {dtype: torch.int64, layout: torch.strided, device: tnca:0, pin_memory: False})
#   return %index_put
triton_poi_fused_index_1 = async_compile.triton('triton_poi_fused_index_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 512}, 
    filename=__file__,
    triton_meta={'signature': {'out_ptr0': '*i64', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_index_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 0, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 4112}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_index_1(out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.full([1], 0, tl.int64)
    tl.store(out_ptr0 + (x0), tmp0, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-fp8-ops-work/v3/std/inductor-cache/pj/cpjzf3sup3srwwfp524fp4zsuv4aeoiwaujgriec5evyqlrccufm.py
# Topologically Sorted Source Nodes: [eq, getitem], Original ATen: [aten.eq, aten.index]
# Source node to ATen node mapping:
#   eq => eq
#   getitem => full, full_1, index_put, iota, sub, view, where
# Graph fragment:
#   %arg0_1 : Tensor "i64[2, 128][128, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %cumsum : Tensor "i64[256][1]tnca:0" = PlaceHolder[target=cumsum]
#   %buf1 : Tensor  = PlaceHolder[target=buf1]
#   %index_put : Tensor "i64[u0 + 1][1]tnca:0" = PlaceHolder[target=index_put]
#   %eq : Tensor "b8[2, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.eq.Scalar](args = (%arg0_1, 7), kwargs = {})
#   %view : Tensor "b8[256][1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.reshape.default](args = (%eq, [-1]), kwargs = {})
#   %full_1 : Tensor "i64[u0 + 1][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([%add], 0), kwargs = {dtype: torch.int64, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %sub : Tensor "i64[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%cumsum, 1), kwargs = {})
#   %full : Tensor "i64[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([256], %_local_scalar_dense), kwargs = {dtype: torch.int64, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %where : Tensor "i64[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%view, %sub, %full), kwargs = {})
#   %iota : Tensor "i64[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (256,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %index_put : Tensor "i64[u0 + 1][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.index_put_.default](args = (%full_1, [%where], %iota), kwargs = {})
#   return %buf6
triton_poi_fused_eq_index_2 = async_compile.triton('triton_poi_fused_eq_index_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 256}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*i64', 'out_ptr0': '*i64', 'ks0': 'i64', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_eq_index_2', 'mutated_arg_names': ['out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 4096}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_eq_index_2(in_ptr0, in_ptr1, out_ptr0, ks0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 256
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask)
    tmp3 = tl.load(in_ptr1 + (x0), xmask)
    tmp1 = tl.full([1], 7, tl.int64)
    tmp2 = tmp0 == tmp1
    tmp4 = tl.full([1], 1, tl.int64)
    tmp5 = tmp3 - tmp4
    tmp6 = (ks0).to(tl.int32)
    tmp7 = tl.where(tmp2, tmp5, tmp6)
    tmp8 = (1 + ks0).to(tl.int32)
    tmp9 = tmp7 + tmp8
    tmp10 = tmp7 < 0
    tmp11 = tl.where(tmp10, tmp9, tmp7)
    tl.device_assert(((0 <= tmp11) & (tmp11 < 1 + ks0)) | ~(xmask), "index out of bounds: 0 <= tmp11 < 1 + ks0")
    tmp13 = (x0).to(tl.int64)
    tmp14 = (tmp13).to(tl.int64)
    tl.store(out_ptr0 + (tl.broadcast_to(tmp11, [XBLOCK])), tmp14, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-fp8-ops-work/v3/std/inductor-cache/ro/crocd7llne754zjc2bcdq3wh4us24tht2uaqt3jmt5nv3kindrug.py
# Topologically Sorted Source Nodes: [getitem, mul], Original ATen: [aten.index, aten.mul]
# Source node to ATen node mapping:
#   getitem => index, slice_1, view_1
#   mul => mul_2
# Graph fragment:
#   %buf6 : Tensor "i64[u0 + 1][1]tnca:0" = PlaceHolder[target=buf6]
#   %arg1_1 : Tensor "f32[2, 128, 64][8192, 64, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %buf1 : Tensor  = PlaceHolder[target=buf1]
#   %slice_1 : Tensor "i64[u0][1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.slice.Tensor](args = (%index_put, 0, 0, %_local_scalar_dense), kwargs = {})
#   %view_1 : Tensor "f32[256, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%arg1_1, [256, 64]), kwargs = {})
#   %index : Tensor "f32[u0, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.index.Tensor](args = (%view_1, [%slice_1]), kwargs = {})
#   %mul_2 : Tensor "f32[u0, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%index, 2), kwargs = {})
#   return %mul_2
triton_poi_fused_index_mul_3 = async_compile.triton('triton_poi_fused_index_mul_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 16384}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_index_mul_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 131072}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_index_mul_3(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x1 = xindex // 64
    x0 = (xindex % 64)
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (x1), xmask, eviction_policy='evict_last')
    tmp1 = (tl.full([XBLOCK], 256, tl.int32)).to(tl.int32)
    tmp2 = tmp0 + tmp1
    tmp3 = tmp0 < 0
    tmp4 = tl.where(tmp3, tmp2, tmp0)
    tl.device_assert(((0 <= tmp4) & (tmp4 < 256)) | ~(xmask), "index out of bounds: 0 <= tmp4 < 256")
    tmp6 = tl.load(in_ptr1 + (x0 + 64*tmp4), xmask)
    tmp7 = tl.full([1], 2.0, tl.float32)
    tmp8 = tmp6 * tmp7
    tl.store(out_ptr0 + (x2), tmp8, xmask)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1 = args
        args.clear()
        assert_size_stride(arg0_1, (2, 128), (128, 1), 'input')
        buf0 = empty_strided((), (), device='tnca', dtype=torch.int64)
        buf4 = empty_strided((256, ), (1, ), device='tnca', dtype=torch.int64)
        # Topologically Sorted Source Nodes: [eq, getitem], Original ATen: [aten.eq, aten.index]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_eq_index_0.run(arg0_1, buf0, buf4, 1, 256, stream=raw_stream0)
        u0 = buf0.item()
        buf1 = None
        del buf0
        if not (u0 >= 0):
            raise RuntimeError('u0 >= 0')
        buf2 = None
        if not (u0 <= 256):
            raise RuntimeError('u0 <= 256')
        buf3 = None
        buf5 = empty_strided((1 + u0, ), (1, ), device='tnca', dtype=torch.int64)
        # Topologically Sorted Source Nodes: [getitem], Original ATen: [aten.index]
        triton_poi_fused_index_1_xnumel = 1 + u0
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_1.run(buf5, triton_poi_fused_index_1_xnumel, stream=raw_stream0)
        # Topologically Sorted Source Nodes: [eq, getitem], Original ATen: [aten.eq, aten.index]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_eq_index_2.run(arg0_1, buf4, buf5, u0, 256, stream=raw_stream0)
        del arg0_1
        del buf4
        assert_size_stride(arg1_1, (2, 128, 64), (8192, 64, 1), 'input')
        buf7 = empty_strided((u0, 64), (64, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [getitem, mul], Original ATen: [aten.index, aten.mul]
        triton_poi_fused_index_mul_3_xnumel = 64*u0
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_mul_3.run(buf5, arg1_1, buf7, triton_poi_fused_index_mul_3_xnumel, stream=raw_stream0)
        del arg1_1
        return (buf7, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((2, 128), (128, 1), device='tnca:0', dtype=torch.int64)
    arg1_1 = rand_strided((2, 128, 64), (8192, 64, 1), device='tnca:0', dtype=torch.float32)
    return [arg0_1, arg1_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
