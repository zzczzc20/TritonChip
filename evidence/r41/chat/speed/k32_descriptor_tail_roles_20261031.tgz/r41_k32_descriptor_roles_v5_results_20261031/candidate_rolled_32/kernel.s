    // R39-12: role0 on even contexts, role1 on odd ones (ROLE_ID mod 2)
    s.rdspecial  s61, role_id
    s.andi       s61, s61, #1
    br.nz        s61, __tnca_role1
    w.def        w0, #56, #8                     // v56..v63
    w.def        w1, #48, #8                     // v48..v55
    .li       s1, #196608
    td.load      d0, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    .li       s1, #196864
    td.load      d1, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    // role 0: partition P, k loop rolled -- 1 trip(s) of 1 step(s). Every W and V number in the body is static.
    .li       s1, #0
    .li       s2, #0
p_loop:
    mb.arm       s3, b0, #0, #2                  // 0 arrival(s), 2 operation(s)
    .li       s4, #0
    s.mov        s5, s4                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s6, s2                          // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w0, d0, s5, s3
    .li       s4, #0
    s.mov        s5, s2                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s6, s4                          // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w1, d1, s5, s3
    s.addi       s4, s2, #32
    s.mov        s2, s4
    s.addi       s4, s1, #1
    s.mov        s1, s4
    .li       s4, #1
    s.cmp.lt     s5, s1, s4
    br.nz        s5, p_loop
    exit
__tnca_role1:
    // role 1: partitions M+E, the same loop cloned. The generation is derived from this role's own trip counter (sec 7.3).
    m.zero       a0
    .li       s1, #0
c_loop:
    s.addi       s2, s1, #1
    s.shli       s3, s2, #16                     // epoch into the token (ISA sec 9A.2)
    s.ori        s3, s3, #0                      // barrier b0
    mb.wait      s3
    mb.arm       s2, b2, #0, #1                  // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a0, v56, v48, s2
    mb.wait      s2
    mb.arm       s4, b1, #1, #0                  // 1 arrival(s), 0 operation(s)
    mb.arrive    b1
    s.addi       s5, s1, #1
    s.mov        s1, s5
    .li       s5, #1
    s.cmp.lt     s6, s1, s5
    br.nz        s6, c_loop
    // epilogue
    .li       s1, #393216
    .li       s5, #0
    a.vread      v0, a0, s5
    v.st.w       [s1, #0], v0
    .li       s5, #1
    a.vread      v0, a0, s5
    s.addi       s5, s1, #64
    v.st.w       [s5, #0], v0
    .li       s5, #2
    a.vread      v0, a0, s5
    s.addi       s5, s1, #128
    v.st.w       [s5, #0], v0
    .li       s5, #3
    a.vread      v0, a0, s5
    s.addi       s5, s1, #192
    v.st.w       [s5, #0], v0
    .li       s5, #4
    a.vread      v0, a0, s5
    s.addi       s5, s1, #256
    v.st.w       [s5, #0], v0
    .li       s5, #5
    a.vread      v0, a0, s5
    s.addi       s5, s1, #320
    v.st.w       [s5, #0], v0
    .li       s5, #6
    a.vread      v0, a0, s5
    s.addi       s5, s1, #384
    v.st.w       [s5, #0], v0
    .li       s5, #7
    a.vread      v0, a0, s5
    s.addi       s5, s1, #448
    v.st.w       [s5, #0], v0
    .li       s5, #8
    a.vread      v0, a0, s5
    s.addi       s5, s1, #512
    v.st.w       [s5, #0], v0
    .li       s5, #9
    a.vread      v0, a0, s5
    s.addi       s5, s1, #576
    v.st.w       [s5, #0], v0
    .li       s5, #10
    a.vread      v0, a0, s5
    s.addi       s5, s1, #640
    v.st.w       [s5, #0], v0
    .li       s5, #11
    a.vread      v0, a0, s5
    s.addi       s5, s1, #704
    v.st.w       [s5, #0], v0
    .li       s5, #12
    a.vread      v0, a0, s5
    s.addi       s5, s1, #768
    v.st.w       [s5, #0], v0
    .li       s5, #13
    a.vread      v0, a0, s5
    s.addi       s5, s1, #832
    v.st.w       [s5, #0], v0
    .li       s5, #14
    a.vread      v0, a0, s5
    s.addi       s5, s1, #896
    v.st.w       [s5, #0], v0
    .li       s5, #15
    a.vread      v0, a0, s5
    s.addi       s5, s1, #960
    v.st.w       [s5, #0], v0
    exit
