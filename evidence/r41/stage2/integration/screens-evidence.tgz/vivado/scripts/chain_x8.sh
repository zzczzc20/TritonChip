#!/bin/bash
# r41s2-int + X8 (8aca2a9) screens: kernel synthesis with the Stage 2 image parameters
# (evidence/r41/stage2/integration/image.tcl: attempt 3 with HAS_TENSOR_XPOSE=2), then tile 1 in SLR1 and tile 0 in SLR0.
set -u
R=$HOME/r41s2int; SRC=$R/src-x8; SL=$R/slot.sh; O=$R/x8
V="vivado -mode batch -nojournal -nolog"
mkdir -p $O; cd $O
echo "$(date -u +%FT%TZ) chain start" >> chain.log
$SL --min-gb 10 $O/kernel_synth.log -- $V -source $R/synth6.tcl -tclargs $SRC $SRC/evidence/r41/stage2/integration/image.tcl $O/kernel_synth
echo "$(date -u +%FT%TZ) kernel synth exit $?" >> chain.log
[ -f $O/kernel_synth/synth.dcp ] || { echo "$(date -u +%FT%TZ) no kernel synth.dcp" >> chain.log; exit 1; }
$SL --min-gb 8 $O/tile1_screen.log -- $V -source $SRC/flow/fpga/screen_r41_tile.tcl -tclargs $O/kernel_synth/synth.dcp 1 1 $O/tile1_screen &
sleep 120
$SL --min-gb 8 $O/tile0_screen.log -- $V -source $SRC/flow/fpga/screen_r41_tile.tcl -tclargs $O/kernel_synth/synth.dcp 0 0 $O/tile0_screen &
wait
echo "$(date -u +%FT%TZ) CHAIN-DONE" >> chain.log
