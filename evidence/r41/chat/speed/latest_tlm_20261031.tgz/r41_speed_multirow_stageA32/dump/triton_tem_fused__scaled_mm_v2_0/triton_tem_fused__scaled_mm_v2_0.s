    s.rdspecial  s1, pid.x
    s.movz       s2, #0
    s.movz       s3, #64
    s.cmp.lt     s4, s1, s2
    v.iota       v0                              // arange(0, VLEN)
    s.sub        s5, s2, s4
    v.movi       v1, #16
    s.xor        s4, s1, s5
    v.movi       v2, #32
    s.sub        s1, s4, s5
    v.movi       v3, #48
    s.lshri      s4, s1, #2
    v.add        v4, v0, v1
    s.muli       s6, s4, #4
    v.add        v1, v0, v2
    v.add        v2, v0, v3
    s.movz       s7, #4
    s.movz       s8, #32
    s.sub        s9, s1, s6
    s.cmp.lt     s1, s7, s2
    s.xor        s6, s9, s5
    s.sub        s9, s2, s1
    s.sub        s1, s6, s5
    s.xor        s2, s5, s9
    s.mul        s5, s1, s3
    s.xor        s1, s4, s2
    v.iota       v3                              // arange(0, VLEN)
    s.sub        s4, s1, s2
    v.movi       v5, #16
    v.splat      v6, s5
    s.mul        s1, s4, s8
    v.add        v7, v3, v5
    v.add        v5, v6, v0
    v.add        v0, v6, v4
    v.add        v4, v6, v1
    v.add        v1, v6, v2
    v.splat      v2, s1
    v.movi       v6, #64
    s.rdspecial  s2, arg_base
    v.add        v8, v2, v3
    v.add        v3, v2, v7
    v.movi       v2, #0
    s.xor        s4, s7, s9
    s.ld.d       s6, [s2, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.sub        s7, s4, s9
    v.movi       v7, #1
    s.ld.d       s4, [s2, #8]                    // arg_B: device_ptr64 at arg_base+8
    v.cmp.lt     p1, v8, v2
    s.ld.d       s7, [s2, #16]                   // arg_SA: device_ptr64 at arg_base+16
    v.cmp.lt     p2, v6, v2
    s.ld.d       s9, [s2, #24]                   // arg_SB: device_ptr64 at arg_base+24
    v.sub        v7, v2, v8
    s.ld.d       s10, [s2, #32]                  // out_ptr1: device_ptr64 at arg_base+32
    v.movi       v9, #0
    v.movi       v10, #0
    v.movi       v11, #0
    v.sub        v12, v9, v5
    v.sub        v13, v10, v0
    v.cmp.lt     p3, v5, v9
    @p3 v.sel        v14, v12, v5
    v.movi       v5, #255
    v.movi       v12, #255
    v.movi       v15, #0
    v.and        v16, v14, v5
    @p1 v.sel        v5, v7, v8
    v.sub        v7, v15, v3
    v.sub        v8, v9, v16
    v.movi       v14, #63
    v.movi       v17, #1
    @p3 v.sel        v17, v8, v16
    v.cmp.lt     p3, v0, v10
    @p3 v.sel        v8, v13, v0
    v.movi       v0, #63
    v.and        v13, v5, v14
    v.and        v5, v8, v12
    v.movi       v8, #64
    v.movi       v12, #256
    v.sub        v14, v10, v5
    v.movi       v16, #1
    v.movi       v16, #1
    @p3 v.sel        v16, v14, v5
    v.cmp.lt     p3, v3, v15
    @p3 v.sel        v5, v7, v3
    v.movi       v3, #256
    v.movi       v7, #256
    v.and        v14, v5, v0
    v.sub        v0, v2, v6
    v.sub        v5, v2, v13
    v.movi       v2, #1
    @p2 v.sel        v2, v0, v6
    v.sub        v0, v11, v4
    v.cmp.lt     p2, v4, v11
    v.sub        v2, v15, v8
    @p2 v.sel        v6, v0, v4
    v.sub        v0, v15, v14
    @p1 v.sel        v4, v5, v13
    v.movi       v5, #255
    v.cmp.lt     p1, v8, v15
    v.movi       v13, #0
    v.and        v15, v6, v5
    v.movi       v5, #256
    @p1 v.sel        v6, v2, v8
    v.sub        v2, v13, v1
    v.cmp.lt     p1, v1, v13
    v.sub        v6, v11, v15
    @p1 v.sel        v8, v2, v1
    v.sub        v1, v9, v12
    @p2 v.sel        v2, v6, v15
    v.sub        v6, v10, v3
    v.cmp.lt     p2, v12, v9
    v.sub        v9, v11, v7
    @p3 v.sel        v15, v0, v14
    v.movi       v0, #255
    v.cmp.lt     p3, v3, v10
    v.sub        v10, v13, v5
    v.and        v14, v8, v0
    v.iota       v0                              // arange(0, VLEN)
    @p2 v.sel        v8, v1, v12
    v.sub        v1, v13, v14
    v.movi       v8, #16
    v.cmp.lt     p2, v7, v11
    @p1 v.sel        v11, v1, v14
    v.movi       v1, #32
    v.movi       v12, #48
    v.cmp.lt     p1, v5, v13
    v.iota       v13                             // arange(0, VLEN)
    @p3 v.sel        v14, v6, v3
    v.movi       v3, #0
    v.movi       v6, #128
    @p2 v.sel        v14, v9, v7
    v.movi       v7, #0
    v.sub        v9, v3, v17
    v.cmp.lt     p2, v17, v3
    v.cmp.lt     p3, v6, v3
    @p2 v.sel        v14, v9, v17
    v.movi       v9, #1
    @p1 v.sel        v9, v10, v5
    v.movi       v5, #0
    v.sub        v9, v7, v16
    v.cmp.lt     p1, v16, v7
    v.add        v10, v0, v8
    v.movi       v8, #7
    @p1 v.sel        v10, v9, v16
    v.add        v9, v0, v1
    v.sub        v1, v5, v2
    v.lshr       v9, v14, v8
    v.movi       v8, #7
    v.add        v14, v0, v12
    v.sub        v0, v3, v9
    v.lshr       v12, v10, v8
    v.movi       v8, #128
    v.movi       v10, #128
    v.sub        v14, v3, v6
    @p2 v.sel        v3, v0, v9
    v.cmp.lt     p2, v2, v5
    @p2 v.sel        v0, v1, v2
    v.sub        v1, v7, v12
    s.movz       s2, #16
    s.movz       s11, #48
    @p1 v.sel        v9, v1, v12
    v.movi       v1, #64
    v.cmp.lt     p1, v8, v7
    v.sub        v12, v7, v8
    v.add        v7, v13, v1
    v.movi       v1, #7
    s.movz       s12, #80
    s.movz       s13, #96
    s.movz       s14, #112
    v.movi       v7, #1
    @p3 v.sel        v7, v14, v6
    v.movi       v6, #80
    v.lshr       v7, v0, v1
    v.movi       v0, #96
    v.iota       v1                              // arange(0, VLEN)
    v.cmp.lt     p3, v10, v5
    v.add        v14, v13, v6
    v.sub        v6, v5, v7
    v.sub        v14, v5, v10
    v.add        v5, v13, v0
    v.movi       v0, #0
    v.movi       v5, #128
    @p2 v.sel        v13, v6, v7
    v.movi       v6, #112
    v.movi       v7, #1
    @p1 v.sel        v7, v12, v8
    v.add        v7, v1, v6
    v.sub        v1, v0, v11
    v.cmp.lt     p1, v11, v0
    v.movi       v6, #7
    @p1 v.sel        v7, v1, v11
    v.sub        v1, v0, v5
    v.movi       v8, #4
    v.lshr       v12, v7, v6
    s.movz       s15, #0
    v.cmp.lt     p2, v5, v0
    v.sub        v6, v0, v12
    v.movi       v0, #1
    @p3 v.sel        v0, v14, v10
    @p1 v.sel        v0, v6, v12
    v.movi       v6, #1
    @p2 v.sel        v6, v1, v5
    v.mul        v1, v3, v8
    v.mul        v3, v9, v8
    v.mul        v5, v13, v8
    v.mul        v6, v0, v8
    s.movz       s16, #2
    s.movz       s17, #1
    s.addi       s18, s15, #0
    s.addi       s19, s15, #0
    s.addi       s20, s15, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_1:
    s.cmp.ge     s21, s18, s16
    br.nz        s21, endfor_2
    v.extract    s21, v17, #0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v7, s21
    v.extract    s22, v16, #0
    s.movz       s23, #128
    v.add        v8, v7, v0
    v.splat      v7, s22
    s.mul        s24, s18, s23
    v.sub        v9, v17, v8
    v.add        v8, v7, v0
    s.movz       s23, #256
    s.mul        s25, s18, s3
    s.sub        s26, s23, s24
    s.movz       s24, #0
    v.reduce.or  s27, v9
    v.sub        v7, v16, v8
    s.add        s28, s15, s26
    // tl.dot 32x128 by 128x64 FP8, B as W's rows written transposed by the engine (ISA sec 9E, tensor_transpose_8bit)
    s.rdspecial  s29, arg_base
    s.cmp.eq     s30, s27, s24
    s.cmp.ge     s27, s21, s24
    v.reduce.or  s31, v7
    s.shli       s32, s25, #2                    // element offset -> bytes (x4)
    s.shli       s33, s18, #2                    // element offset -> bytes (x4)
    s.ld.d       s34, [s29, #40]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.and        s29, s30, s27
    s.cmp.ge     s27, s28, s24
    v.movi       v7, #0
    v.movi       v8, #0
    s.cmp.eq     s30, s31, s24
    s.add        s31, s7, s32                    // &arg_SA[...]
    s.add        s32, s9, s33                    // &arg_SB[...]
    s.and        s33, s29, s27
    v.splat      v9, s23
    v.splat      v10, s23
    s.cmp.ge     s23, s22, s24
    v.ld.gather.w v12, [s31, v4]                 // index is in elements (ISA sec 9.1)
    s.and        s29, s30, s23
    v.splat      v13, s25
    v.extract    s23, v2, #0
    s.and        s25, s29, s27
    v.splat      v13, s18
    v.splat      v13, s18
    v.splat      v13, s18
    v.splat      v13, s18
    v.mul        v13, v17, v9
    v.mul        v14, v16, v9
    v.mul        v18, v2, v9
    v.mul        v9, v11, v10
    v.ld.gather.w v10, [s31, v15]                // index is in elements (ISA sec 9.1)
    v.splat      v19, s23
    s.cmp.ge     s29, s23, s24
    v.add        v20, v19, v0
    v.sub        v19, v2, v20
    v.reduce.or  s30, v19
    s.cmp.eq     s31, s30, s24
    s.and        s30, s31, s29
    v.ld.gather.w v19, [s32, v1]                 // index is in elements (ISA sec 9.1)
    s.and        s29, s30, s27
    v.ld.gather.w v20, [s32, v3]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v21, [s32, v5]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v22, [s32, v6]                 // index is in elements (ISA sec 9.1)
    v.extract    s30, v11, #0
    s.movz       s31, #256
    v.splat      v23, s30
    v.insert     v7, s33, #0
    v.insert     v8, s21, #0
    v.add        v24, v23, v0
    s.movz       s21, #0
    v.insert     v7, s25, #1
    v.sub        v0, v11, v24
    v.insert     v8, s22, #1
    s.cmp.ge     s22, s30, s24
    v.reduce.or  s25, v0
    v.insert     v7, s29, #2
    s.cmp.eq     s29, s25, s24
    v.insert     v8, s23, #2
    v.splat      v0, s31
    s.and        s23, s29, s22
    s.add        s22, s4, s20
    v.mul        v23, v4, v0
    s.and        s24, s23, s27
    v.iota       v0                              // arange(0, VLEN)
    v.extract    s23, v23, #0
    s.addi       s25, s34, #0                    // TensorMap 0: W's rows for a transposed FP8 B
    s.add        s27, s23, s19
    .li       s23, #2147483647
    s.movz       s29, #1
    .li       s32, #137438953488
    s.add        s33, s6, s27
    v.insert     v7, s24, #3
    s.add        s24, s21, s26                   // the tile origin
    .li       s21, #7705171329024
    v.insert     v8, s30, #3
    v.splat      v24, s24
    s.addi       s24, s34, #256
    s.addi       s27, s34, #768                  // TensorMap 1: the gathered fallback B tile
    v.cmp.lt     p1, v0, v24
    s.st.d       [s25, #0], s22
    s.movz       s22, #32
    s.st.d       [s25, #8], s23
    s.movz       s23, #16
    s.st.d       [s25, #16], s28
    s.st.d       [s25, #48], s31
    .li       s30, #68719476768
    s.st.d       [s25, #56], s29
    s.st.d       [s25, #88], s32
    v.extract    s31, v23, #1
    s.add        s32, s31, s19
    s.add        s31, s6, s32
    s.st.d       [s25, #104], s21
    fence.release.device
    td.load      d0, [s25]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s25, s34, #1024                 // 512 bytes of repack scratch
    s.st.d       [s27, #0], s24
    s.addi       s24, s25, #0
    s.st.d       [s27, #8], s22
    v.extract    s22, v23, #2
    s.add        s32, s22, s19
    s.add        s22, s6, s32
    s.st.d       [s27, #16], s23
    s.st.d       [s27, #48], s23
    s.addi       s23, s25, #32
    s.st.d       [s27, #56], s29
    v.extract    s29, v23, #3
    s.add        s32, s29, s19
    s.add        s29, s6, s32
    s.st.d       [s27, #88], s30
    s.addi       s30, s25, #64
    s.st.d       [s27, #104], s21
    fence.release.device
    td.load      d1, [s27]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s33, #0]
    v.extract    s21, v23, #4
    s.addi       s27, s25, #96
    s.add        s32, s21, s19
    v.extract    s21, v23, #5
    s.add        s33, s6, s32
    s.add        s32, s21, s19
    s.add        s21, s6, s32
    v.st.b       [s24, #0], v24
    s.addi       s24, s25, #128
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s31, #0]
    v.extract    s31, v23, #6
    s.add        s32, s31, s19
    s.add        s31, s6, s32
    v.st.b       [s23, #0], v24
    s.addi       s23, s25, #160
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s22, #0]
    v.extract    s22, v23, #7
    s.add        s32, s22, s19
    s.add        s22, s6, s32
    v.st.b       [s30, #0], v24
    s.addi       s30, s25, #192
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s29, #0]
    v.extract    s29, v23, #8
    s.add        s32, s29, s19
    s.add        s29, s6, s32
    v.st.b       [s27, #0], v24
    s.addi       s27, s25, #224
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s33, #0]
    v.extract    s32, v23, #9
    s.add        s33, s32, s19
    s.add        s32, s6, s33
    v.st.b       [s24, #0], v24
    s.addi       s24, s25, #256
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s21, #0]
    v.extract    s21, v23, #10
    s.add        s33, s21, s19
    s.add        s21, s6, s33
    v.st.b       [s23, #0], v24
    s.addi       s23, s25, #288
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s31, #0]
    v.extract    s31, v23, #11
    s.add        s33, s31, s19
    s.add        s31, s6, s33
    v.st.b       [s30, #0], v24
    s.addi       s30, s25, #320
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s22, #0]
    v.extract    s22, v23, #12
    s.add        s33, s22, s19
    s.add        s22, s6, s33
    v.st.b       [s27, #0], v24
    s.addi       s27, s25, #352
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s29, #0]
    v.extract    s29, v23, #13
    s.add        s33, s29, s19
    s.add        s29, s6, s33
    v.st.b       [s24, #0], v24
    s.addi       s24, s25, #384
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s32, #0]
    v.extract    s32, v23, #14
    s.add        s33, s32, s19
    s.add        s32, s6, s33
    v.st.b       [s23, #0], v24
    s.addi       s23, s25, #416
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s21, #0]
    v.extract    s21, v23, #15
    s.add        s33, s21, s19
    s.add        s21, s6, s33
    v.st.b       [s30, #0], v24
    s.addi       s30, s25, #448
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s31, #0]
    s.movz       s31, #0
    v.st.b       [s27, #0], v24
    s.add        s27, s31, s2                    // the tile origin
    s.add        s33, s31, s26                   // the tile origin
    v.splat      v24, s27
    v.extract    s27, v23, #0
    v.splat      v25, s33
    s.add        s31, s27, s19
    v.add        v26, v0, v24
    s.addi       s27, s31, #16
    s.addi       s31, s25, #480
    s.add        s33, s6, s27
    v.cmp.lt     p2, v26, v25
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s22, #0]
    v.extract    s22, v23, #1
    s.add        s27, s22, s19
    s.addi       s22, s27, #16
    s.add        s27, s6, s22
    v.st.b       [s24, #0], v24
    s.addi       s22, s25, #16
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s29, #0]
    v.extract    s24, v23, #2
    s.add        s29, s24, s19
    s.addi       s24, s29, #16
    s.add        s29, s6, s24
    v.st.b       [s23, #0], v24
    s.addi       s23, s25, #48
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s32, #0]
    v.extract    s24, v23, #3
    s.add        s32, s24, s19
    s.addi       s24, s32, #16
    s.add        s32, s6, s24
    v.st.b       [s30, #0], v24
    s.addi       s24, s25, #80
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s21, #0]
    v.extract    s21, v23, #4
    s.add        s30, s21, s19
    s.addi       s21, s30, #16
    s.add        s30, s6, s21
    v.st.b       [s31, #0], v24
    s.addi       s21, s25, #112
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s33, #0]
    v.extract    s31, v23, #5
    s.add        s33, s31, s19
    s.addi       s31, s33, #16
    s.add        s33, s6, s31
    v.st.b       [s22, #0], v24
    s.addi       s22, s25, #144
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s27, #0]
    v.extract    s27, v23, #6
    s.add        s31, s27, s19
    s.addi       s27, s31, #16
    s.add        s31, s6, s27
    v.st.b       [s23, #0], v24
    s.addi       s23, s25, #176
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s29, #0]
    v.extract    s27, v23, #7
    s.add        s29, s27, s19
    s.addi       s27, s29, #16
    s.add        s29, s6, s27
    v.st.b       [s24, #0], v24
    s.addi       s24, s25, #208
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s32, #0]
    v.extract    s27, v23, #8
    s.add        s32, s27, s19
    s.addi       s27, s32, #16
    s.add        s32, s6, s27
    v.st.b       [s21, #0], v24
    s.addi       s21, s25, #240
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s30, #0]
    v.extract    s27, v23, #9
    s.add        s30, s27, s19
    s.addi       s27, s30, #16
    s.add        s30, s6, s27
    v.st.b       [s22, #0], v24
    s.addi       s22, s25, #272
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s33, #0]
    v.extract    s27, v23, #10
    s.add        s33, s27, s19
    s.addi       s27, s33, #16
    s.add        s33, s6, s27
    v.st.b       [s23, #0], v24
    s.addi       s23, s25, #304
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s31, #0]
    v.extract    s27, v23, #11
    s.add        s31, s27, s19
    s.addi       s27, s31, #16
    s.add        s31, s6, s27
    v.st.b       [s24, #0], v24
    s.addi       s24, s25, #336
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s29, #0]
    v.extract    s27, v23, #12
    s.add        s29, s27, s19
    s.addi       s27, s29, #16
    s.add        s29, s6, s27
    v.st.b       [s21, #0], v24
    s.addi       s21, s25, #368
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s32, #0]
    v.extract    s27, v23, #13
    s.add        s32, s27, s19
    s.addi       s27, s32, #16
    s.add        s32, s6, s27
    v.st.b       [s22, #0], v24
    s.addi       s22, s25, #400
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s30, #0]
    v.extract    s27, v23, #14
    s.add        s30, s27, s19
    s.addi       s27, s30, #16
    s.add        s30, s6, s27
    v.st.b       [s23, #0], v24
    s.addi       s23, s25, #432
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s33, #0]
    v.extract    s27, v23, #15
    s.add        s33, s27, s19
    s.addi       s27, s33, #16
    s.add        s33, s6, s27
    v.st.b       [s24, #0], v24
    s.addi       s24, s25, #464
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s31, #0]
    s.movz       s27, #256
    v.splat      v25, s27
    s.addi       s27, s25, #496
    v.mul        v26, v15, v25
    v.st.b       [s21, #0], v24
    v.extract    s21, v26, #0
    s.add        s31, s21, s19
    s.add        s21, s6, s31
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s29, #0]
    v.extract    s29, v26, #1
    s.add        s31, s29, s19
    s.add        s29, s6, s31
    v.st.b       [s22, #0], v24
    s.addi       s22, s34, #1536                 // 512 bytes of repack scratch
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s32, #0]
    s.addi       s31, s22, #0
    v.st.b       [s23, #0], v24
    v.extract    s23, v26, #2
    s.add        s32, s23, s19
    s.add        s23, s6, s32
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s30, #0]
    s.addi       s30, s22, #32
    v.st.b       [s24, #0], v24
    v.extract    s24, v26, #3
    s.add        s32, s24, s19
    s.add        s24, s6, s32
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s33, #0]
    s.addi       s32, s22, #64
    v.st.b       [s27, #0], v24
    v.extract    s27, v26, #4
    s.add        s33, s27, s19
    s.add        s27, s6, s33
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s21, #0]
    s.addi       s21, s22, #96
    v.st.b       [s31, #0], v24
    v.extract    s31, v26, #5
    s.add        s33, s31, s19
    s.add        s31, s6, s33
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s29, #0]
    s.addi       s29, s22, #128
    v.st.b       [s30, #0], v24
    v.extract    s30, v26, #6
    s.add        s33, s30, s19
    s.add        s30, s6, s33
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s23, #0]
    s.addi       s23, s22, #160
    v.st.b       [s32, #0], v24
    v.extract    s32, v26, #7
    s.add        s33, s32, s19
    s.add        s32, s6, s33
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s24, #0]
    s.addi       s24, s22, #192
    v.st.b       [s21, #0], v24
    v.extract    s21, v26, #8
    s.add        s33, s21, s19
    s.add        s21, s6, s33
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s27, #0]
    s.addi       s27, s22, #224
    v.st.b       [s29, #0], v24
    v.extract    s29, v26, #9
    s.add        s33, s29, s19
    s.add        s29, s6, s33
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s31, #0]
    s.addi       s31, s22, #256
    v.st.b       [s23, #0], v24
    v.extract    s23, v26, #10
    s.add        s33, s23, s19
    s.add        s23, s6, s33
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s30, #0]
    s.addi       s30, s22, #288
    v.st.b       [s24, #0], v24
    v.extract    s24, v26, #11
    s.add        s33, s24, s19
    s.add        s24, s6, s33
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s32, #0]
    s.addi       s32, s22, #320
    v.st.b       [s27, #0], v24
    v.extract    s27, v26, #12
    s.add        s33, s27, s19
    s.add        s27, s6, s33
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s21, #0]
    s.addi       s21, s22, #352
    v.st.b       [s31, #0], v24
    v.extract    s31, v26, #13
    s.add        s33, s31, s19
    s.add        s31, s6, s33
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s29, #0]
    s.addi       s29, s22, #384
    v.st.b       [s30, #0], v24
    v.extract    s30, v26, #14
    s.add        s33, s30, s19
    s.add        s30, s6, s33
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s23, #0]
    s.addi       s23, s22, #416
    v.st.b       [s32, #0], v24
    v.extract    s32, v26, #15
    s.add        s33, s32, s19
    s.add        s32, s6, s33
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s24, #0]
    s.addi       s24, s22, #448
    v.st.b       [s21, #0], v24
    v.extract    s21, v26, #0
    s.add        s33, s21, s19
    s.addi       s21, s33, #16
    s.add        s33, s6, s21
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s27, #0]
    s.addi       s21, s22, #480
    v.st.b       [s29, #0], v24
    v.extract    s27, v26, #1
    s.add        s29, s27, s19
    s.addi       s27, s29, #16
    s.add        s29, s6, s27
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s31, #0]
    s.addi       s27, s22, #16
    v.st.b       [s23, #0], v24
    v.extract    s23, v26, #2
    s.add        s31, s23, s19
    s.addi       s23, s31, #16
    s.add        s31, s6, s23
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s30, #0]
    s.addi       s23, s22, #48
    v.st.b       [s24, #0], v24
    v.extract    s24, v26, #3
    s.add        s30, s24, s19
    s.addi       s24, s30, #16
    s.add        s30, s6, s24
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s32, #0]
    s.addi       s24, s22, #80
    v.st.b       [s21, #0], v24
    v.extract    s21, v26, #4
    s.add        s32, s21, s19
    s.addi       s21, s32, #16
    s.add        s32, s6, s21
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s33, #0]
    s.addi       s21, s22, #112
    v.st.b       [s27, #0], v24
    v.extract    s27, v26, #5
    s.add        s33, s27, s19
    s.addi       s27, s33, #16
    s.add        s33, s6, s27
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s29, #0]
    s.addi       s27, s22, #144
    v.st.b       [s23, #0], v24
    v.extract    s23, v26, #6
    s.add        s29, s23, s19
    s.addi       s23, s29, #16
    s.add        s29, s6, s23
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s31, #0]
    s.addi       s23, s22, #176
    v.st.b       [s24, #0], v24
    v.extract    s24, v26, #7
    s.add        s31, s24, s19
    s.addi       s24, s31, #16
    s.add        s31, s6, s24
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s30, #0]
    s.addi       s24, s22, #208
    v.st.b       [s21, #0], v24
    v.extract    s21, v26, #8
    s.add        s30, s21, s19
    s.addi       s21, s30, #16
    s.add        s30, s6, s21
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s32, #0]
    s.addi       s21, s22, #240
    v.st.b       [s27, #0], v24
    v.extract    s27, v26, #9
    s.add        s32, s27, s19
    s.addi       s27, s32, #16
    s.add        s32, s6, s27
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s33, #0]
    s.addi       s27, s22, #272
    v.st.b       [s23, #0], v24
    v.extract    s23, v26, #10
    s.add        s33, s23, s19
    s.addi       s23, s33, #16
    s.add        s33, s6, s23
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s29, #0]
    s.addi       s23, s22, #304
    v.st.b       [s24, #0], v24
    v.extract    s24, v26, #11
    s.add        s29, s24, s19
    s.addi       s24, s29, #16
    s.add        s29, s6, s24
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s31, #0]
    s.addi       s24, s22, #336
    v.st.b       [s21, #0], v24
    v.extract    s21, v26, #12
    s.add        s31, s21, s19
    s.addi       s21, s31, #16
    s.add        s31, s6, s21
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s30, #0]
    s.addi       s21, s22, #368
    v.st.b       [s27, #0], v24
    v.extract    s27, v26, #13
    s.add        s30, s27, s19
    s.addi       s27, s30, #16
    s.add        s30, s6, s27
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s32, #0]
    s.addi       s27, s22, #400
    v.st.b       [s23, #0], v24
    v.extract    s23, v26, #14
    s.add        s32, s23, s19
    s.addi       s23, s32, #16
    s.add        s32, s6, s23
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s33, #0]
    s.addi       s23, s22, #432
    v.st.b       [s24, #0], v24
    v.extract    s24, v26, #15
    s.add        s33, s24, s19
    s.addi       s24, s33, #16
    s.add        s33, s6, s24
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s29, #0]
    s.addi       s24, s22, #464
    v.st.b       [s21, #0], v24
    s.addi       s21, s22, #496
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s31, #0]
    v.extract    s29, v7, #0
    v.st.b       [s27, #0], v24
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s30, #0]
    v.st.b       [s23, #0], v24
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s32, #0]
    v.st.b       [s24, #0], v24
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s33, #0]
    v.st.b       [s21, #0], v24
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s29, x8dot_done_3
    s.movz       s21, #0
    s.add        s23, s4, s20
    s.addi       s24, s21, #0
    s.addi       s21, s34, #256
x8dot_row_4:
    s.addi       s27, s28, #0
    v.movi       v24, #0
    s.sub        s30, s27, s24
    s.add        s27, s23, s24
    v.splat      v25, s30
    s.shli       s30, s24, #4
    s.addi       s31, s24, #1
    v.cmp.gt     p1, v25, v24
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v24, [s27, v13]            // index is in elements (ISA sec 9.1)
    s.add        s27, s21, s30
    s.movz       s30, #32
    v.st.b       [s27, #0], v24
    fence.acq_rel.device
    s.mov        s24, s31
    s.cmp.lt     s27, s24, s30
    br.nz        s27, x8dot_row_4
x8dot_done_3:
    v.splat      v24, s29
    v.movi       v25, #0
    mb.arm       s21, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s23, #0
    v.extract    s24, v8, #0
    v.cmp.ne     p1, v24, v25
    v.cmp.eq     p2, v24, v25
    s.mov        s29, s23                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s30, s23                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s29, s21            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s29, s24                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s30, s23                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s29, s21          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s21
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v24, [s25, #0]
    s.addi       s24, s25, #64
    s.addi       s27, s25, #128
    s.addi       s29, s25, #192
    s.addi       s30, s25, #256
    s.addi       s31, s25, #320
    v.mov        v56, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s24, #0]
    s.addi       s24, s25, #384
    v.mov        v57, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s27, #0]
    s.addi       s27, s25, #448
    v.mov        v58, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s29, #0]
    s.addi       s29, s22, #64
    v.mov        v59, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s30, #0]
    s.addi       s30, s22, #128
    v.mov        v60, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s31, #0]
    s.addi       s31, s22, #192
    v.mov        v61, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s24, #0]
    s.addi       s24, s22, #256
    v.mov        v62, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s27, #0]
    s.addi       s27, s22, #320
    v.mov        v63, v24                        // hand off through the shared window (sec 7.3)
    mb.arm       s32, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v48, s32
    mb.wait      s32
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v24, [s22, #0]
    v.mov        v56, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s29, #0]
    s.addi       s29, s22, #384
    v.mov        v57, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s30, #0]
    s.addi       s30, s22, #448
    v.mov        v58, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s31, #0]
    v.extract    s31, v7, #1
    v.mov        v59, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s24, #0]
    v.mov        v60, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s27, #0]
    v.mov        v61, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s29, #0]
    v.mov        v62, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s30, #0]
    v.mov        v63, v24                        // hand off through the shared window (sec 7.3)
    mb.arm       s24, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a12, v56, v48, s24
    mb.wait      s24
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s31, x8dot_done_5
    s.addi       s27, s23, #0
    s.add        s23, s4, s20
    s.addi       s29, s34, #256
x8dot_row_6:
    s.addi       s30, s28, #0
    v.movi       v24, #0
    s.sub        s33, s30, s27
    s.add        s30, s23, s27
    v.splat      v25, s33
    s.shli       s33, s27, #4
    s.addi       s35, s27, #1
    v.cmp.gt     p1, v25, v24
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v24, [s30, v14]            // index is in elements (ISA sec 9.1)
    s.add        s30, s29, s33
    s.movz       s33, #32
    v.st.b       [s30, #0], v24
    fence.acq_rel.device
    s.mov        s27, s35
    s.cmp.lt     s30, s27, s33
    br.nz        s30, x8dot_row_6
x8dot_done_5:
    v.splat      v24, s31
    v.movi       v25, #0
    mb.arm       s23, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s27, #0
    v.extract    s29, v8, #1
    v.cmp.ne     p1, v24, v25
    v.cmp.eq     p2, v24, v25
    s.mov        s30, s27                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s31, s27                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s30, s23            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s30, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s31, s27                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s30, s23          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s23
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v24, [s25, #0]
    s.addi       s29, s25, #64
    s.addi       s30, s25, #128
    s.addi       s31, s25, #192
    s.addi       s33, s25, #256
    s.addi       s35, s25, #320
    v.mov        v56, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s29, #0]
    s.addi       s29, s25, #384
    v.mov        v57, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s30, #0]
    s.addi       s30, s25, #448
    v.mov        v58, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s31, #0]
    s.addi       s31, s22, #64
    v.mov        v59, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s33, #0]
    s.addi       s33, s22, #128
    v.mov        v60, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s35, #0]
    s.addi       s35, s22, #192
    v.mov        v61, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s29, #0]
    s.addi       s29, s22, #256
    v.mov        v62, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s30, #0]
    s.addi       s30, s22, #320
    v.mov        v63, v24                        // hand off through the shared window (sec 7.3)
    mb.arm       s36, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s36
    mb.wait      s36
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v24, [s22, #0]
    v.mov        v56, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s31, #0]
    s.addi       s31, s22, #384
    v.mov        v57, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s33, #0]
    s.addi       s33, s22, #448
    v.mov        v58, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s35, #0]
    v.extract    s35, v7, #2
    v.mov        v59, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s29, #0]
    v.mov        v60, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s30, #0]
    v.mov        v61, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s31, #0]
    v.mov        v62, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s33, #0]
    v.mov        v63, v24                        // hand off through the shared window (sec 7.3)
    mb.arm       s29, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s29
    mb.wait      s29
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s35, x8dot_done_7
    s.addi       s30, s27, #0
    s.add        s27, s4, s20
    s.addi       s31, s34, #256
x8dot_row_8:
    s.addi       s33, s28, #0
    v.movi       v24, #0
    s.sub        s37, s33, s30
    s.add        s33, s27, s30
    v.splat      v25, s37
    s.shli       s37, s30, #4
    s.addi       s38, s30, #1
    v.cmp.gt     p1, v25, v24
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v24, [s33, v18]            // index is in elements (ISA sec 9.1)
    s.add        s33, s31, s37
    s.movz       s37, #32
    v.st.b       [s33, #0], v24
    fence.acq_rel.device
    s.mov        s30, s38
    s.cmp.lt     s33, s30, s37
    br.nz        s33, x8dot_row_8
x8dot_done_7:
    v.splat      v24, s35
    v.movi       v25, #0
    mb.arm       s27, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s30, #0
    v.extract    s31, v8, #2
    v.cmp.ne     p1, v24, v25
    v.cmp.eq     p2, v24, v25
    s.mov        s37, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s37, s27            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s37, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s37, s27          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s27
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v24, [s25, #0]
    s.addi       s31, s25, #64
    s.addi       s33, s25, #128
    s.addi       s35, s25, #192
    s.addi       s37, s25, #256
    s.addi       s38, s25, #320
    v.mov        v56, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s31, #0]
    s.addi       s31, s25, #384
    v.mov        v57, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s33, #0]
    s.addi       s33, s25, #448
    v.mov        v58, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s35, #0]
    s.addi       s35, s22, #64
    v.mov        v59, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s37, #0]
    s.addi       s37, s22, #128
    v.mov        v60, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s38, #0]
    s.addi       s38, s22, #192
    v.mov        v61, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s31, #0]
    s.addi       s31, s22, #256
    v.mov        v62, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s33, #0]
    s.addi       s33, s22, #320
    v.mov        v63, v24                        // hand off through the shared window (sec 7.3)
    mb.arm       s39, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a10, v56, v48, s39
    mb.wait      s39
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v24, [s22, #0]
    v.mov        v56, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s35, #0]
    s.addi       s35, s22, #384
    v.mov        v57, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s37, #0]
    s.addi       s37, s22, #448
    v.mov        v58, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s38, #0]
    v.extract    s38, v7, #3
    v.mov        v59, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s31, #0]
    v.mov        v60, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s33, #0]
    v.mov        v61, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s35, #0]
    v.mov        v62, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s37, #0]
    v.mov        v63, v24                        // hand off through the shared window (sec 7.3)
    mb.arm       s31, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a14, v56, v48, s31
    mb.wait      s31
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s38, x8dot_done_9
    s.addi       s33, s30, #0
    s.add        s30, s4, s20
    s.addi       s35, s34, #256
x8dot_row_10:
    s.addi       s37, s28, #0
    v.movi       v24, #0
    s.sub        s40, s37, s33
    s.add        s37, s30, s33
    v.splat      v25, s40
    s.shli       s40, s33, #4
    s.addi       s41, s33, #1
    v.cmp.gt     p1, v25, v24
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v24, [s37, v9]             // index is in elements (ISA sec 9.1)
    s.add        s37, s35, s40
    s.movz       s40, #32
    v.st.b       [s37, #0], v24
    fence.acq_rel.device
    s.mov        s33, s41
    s.cmp.lt     s37, s33, s40
    br.nz        s37, x8dot_row_10
x8dot_done_9:
    v.splat      v24, s38
    v.movi       v25, #0
    mb.arm       s30, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s33, #0
    v.extract    s35, v8, #3
    v.cmp.ne     p1, v24, v25
    v.cmp.eq     p2, v24, v25
    s.mov        s37, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s37, s30            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s37, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s37, s30          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s30
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v24, [s25, #0]
    s.addi       s33, s25, #64
    s.addi       s35, s25, #128
    s.addi       s37, s25, #192
    s.addi       s38, s25, #256
    s.addi       s40, s25, #320
    s.addi       s41, s25, #384
    s.addi       s42, s25, #448
    v.mov        v56, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s33, #0]
    s.addi       s25, s22, #64
    v.mov        v57, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s35, #0]
    s.addi       s33, s22, #128
    v.mov        v58, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s37, #0]
    s.addi       s35, s22, #192
    v.mov        v59, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s38, #0]
    s.addi       s37, s22, #256
    v.mov        v60, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s40, #0]
    s.addi       s38, s22, #320
    v.mov        v61, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s41, #0]
    s.addi       s40, s22, #384
    v.mov        v62, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s42, #0]
    s.addi       s41, s22, #448
    v.mov        v63, v24                        // hand off through the shared window (sec 7.3)
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s42
    mb.wait      s42
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v24, [s22, #0]
    s.movz       s22, #0
    v.mov        v56, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s25, #0]
    s.add        s25, s22, s8                    // the tile origin
    s.add        s43, s22, s26                   // the tile origin
    v.splat      v25, s25
    v.extract    s22, v23, #0
    v.splat      v27, s43
    s.add        s25, s22, s19
    v.add        v28, v0, v25
    s.addi       s22, s25, #32
    v.extract    s25, v23, #1
    s.add        s43, s6, s22
    v.cmp.lt     p1, v28, v27
    s.add        s22, s25, s19
    s.addi       s25, s22, #32
    s.add        s22, s6, s25
    v.mov        v57, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s33, #0]
    s.addi       s25, s34, #2048                 // 512 bytes of repack scratch
    v.mov        v58, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s35, #0]
    s.addi       s33, s25, #0
    v.mov        v59, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s37, #0]
    v.extract    s35, v23, #2
    s.add        s37, s35, s19
    s.addi       s35, s37, #32
    s.add        s37, s6, s35
    v.mov        v60, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s38, #0]
    s.addi       s35, s25, #32
    v.mov        v61, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s40, #0]
    v.extract    s38, v23, #3
    s.add        s40, s38, s19
    s.addi       s38, s40, #32
    s.add        s40, s6, s38
    v.mov        v62, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s41, #0]
    s.addi       s38, s25, #64
    v.mov        v63, v24                        // hand off through the shared window (sec 7.3)
    mb.arm       s41, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s41
    mb.wait      s41
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s43, #0]
    v.extract    s43, v23, #4
    s.add        s44, s43, s19
    s.addi       s43, s44, #32
    s.add        s44, s6, s43
    v.st.b       [s33, #0], v24
    s.addi       s33, s25, #96
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s22, #0]
    v.extract    s22, v23, #5
    s.add        s43, s22, s19
    s.addi       s22, s43, #32
    s.add        s43, s6, s22
    v.st.b       [s35, #0], v24
    s.addi       s22, s25, #128
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s37, #0]
    v.extract    s35, v23, #6
    s.add        s37, s35, s19
    s.addi       s35, s37, #32
    s.add        s37, s6, s35
    v.st.b       [s38, #0], v24
    s.addi       s35, s25, #160
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s40, #0]
    v.extract    s38, v23, #7
    s.add        s40, s38, s19
    s.addi       s38, s40, #32
    s.add        s40, s6, s38
    v.st.b       [s33, #0], v24
    s.addi       s33, s25, #192
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s44, #0]
    v.extract    s38, v23, #8
    s.add        s44, s38, s19
    s.addi       s38, s44, #32
    s.add        s44, s6, s38
    v.st.b       [s22, #0], v24
    s.addi       s22, s25, #224
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s43, #0]
    v.extract    s38, v23, #9
    s.add        s43, s38, s19
    s.addi       s38, s43, #32
    s.add        s43, s6, s38
    v.st.b       [s35, #0], v24
    s.addi       s35, s25, #256
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s37, #0]
    v.extract    s37, v23, #10
    s.add        s38, s37, s19
    s.addi       s37, s38, #32
    s.add        s38, s6, s37
    v.st.b       [s33, #0], v24
    s.addi       s33, s25, #288
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s40, #0]
    v.extract    s37, v23, #11
    s.add        s40, s37, s19
    s.addi       s37, s40, #32
    s.add        s40, s6, s37
    v.st.b       [s22, #0], v24
    s.addi       s22, s25, #320
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s44, #0]
    v.extract    s37, v23, #12
    s.add        s44, s37, s19
    s.addi       s37, s44, #32
    s.add        s44, s6, s37
    v.st.b       [s35, #0], v24
    s.addi       s35, s25, #352
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s43, #0]
    v.extract    s37, v23, #13
    s.add        s43, s37, s19
    s.addi       s37, s43, #32
    s.add        s43, s6, s37
    v.st.b       [s33, #0], v24
    s.addi       s33, s25, #384
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s38, #0]
    v.extract    s37, v23, #14
    s.add        s38, s37, s19
    s.addi       s37, s38, #32
    s.add        s38, s6, s37
    v.st.b       [s22, #0], v24
    s.addi       s22, s25, #416
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s40, #0]
    v.extract    s37, v23, #15
    s.add        s40, s37, s19
    s.addi       s37, s40, #32
    s.add        s40, s6, s37
    v.st.b       [s35, #0], v24
    s.addi       s35, s25, #448
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s44, #0]
    s.movz       s37, #0
    v.st.b       [s33, #0], v24
    s.add        s33, s37, s11                   // the tile origin
    s.add        s44, s37, s26                   // the tile origin
    v.splat      v24, s33
    v.extract    s33, v23, #0
    v.splat      v25, s44
    s.add        s37, s33, s19
    v.add        v27, v0, v24
    s.addi       s33, s37, #48
    s.addi       s37, s25, #480
    s.add        s44, s6, s33
    v.cmp.lt     p2, v27, v25
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s43, #0]
    v.extract    s33, v23, #1
    s.add        s43, s33, s19
    s.addi       s33, s43, #48
    s.add        s43, s6, s33
    v.st.b       [s22, #0], v24
    s.addi       s22, s25, #16
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s38, #0]
    v.extract    s33, v23, #2
    s.add        s38, s33, s19
    s.addi       s33, s38, #48
    s.add        s38, s6, s33
    v.st.b       [s35, #0], v24
    s.addi       s33, s25, #48
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s40, #0]
    v.extract    s35, v23, #3
    s.add        s40, s35, s19
    s.addi       s35, s40, #48
    s.add        s40, s6, s35
    v.st.b       [s37, #0], v24
    s.addi       s35, s25, #80
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s44, #0]
    v.extract    s37, v23, #4
    s.add        s44, s37, s19
    s.addi       s37, s44, #48
    s.add        s44, s6, s37
    v.st.b       [s22, #0], v24
    s.addi       s22, s25, #112
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s43, #0]
    v.extract    s37, v23, #5
    s.add        s43, s37, s19
    s.addi       s37, s43, #48
    s.add        s43, s6, s37
    v.st.b       [s33, #0], v24
    s.addi       s33, s25, #144
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s38, #0]
    v.extract    s37, v23, #6
    s.add        s38, s37, s19
    s.addi       s37, s38, #48
    s.add        s38, s6, s37
    v.st.b       [s35, #0], v24
    s.addi       s35, s25, #176
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s40, #0]
    v.extract    s37, v23, #7
    s.add        s40, s37, s19
    s.addi       s37, s40, #48
    s.add        s40, s6, s37
    v.st.b       [s22, #0], v24
    s.addi       s22, s25, #208
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s44, #0]
    v.extract    s37, v23, #8
    s.add        s44, s37, s19
    s.addi       s37, s44, #48
    s.add        s44, s6, s37
    v.st.b       [s33, #0], v24
    s.addi       s33, s25, #240
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s43, #0]
    v.extract    s37, v23, #9
    s.add        s43, s37, s19
    s.addi       s37, s43, #48
    s.add        s43, s6, s37
    v.st.b       [s35, #0], v24
    s.addi       s35, s25, #272
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s38, #0]
    v.extract    s37, v23, #10
    s.add        s38, s37, s19
    s.addi       s37, s38, #48
    s.add        s38, s6, s37
    v.st.b       [s22, #0], v24
    s.addi       s22, s25, #304
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s40, #0]
    v.extract    s37, v23, #11
    s.add        s40, s37, s19
    s.addi       s37, s40, #48
    s.add        s40, s6, s37
    v.st.b       [s33, #0], v24
    s.addi       s33, s25, #336
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s44, #0]
    v.extract    s37, v23, #12
    s.add        s44, s37, s19
    s.addi       s37, s44, #48
    s.add        s44, s6, s37
    v.st.b       [s35, #0], v24
    s.addi       s35, s25, #368
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s43, #0]
    v.extract    s37, v23, #13
    s.add        s43, s37, s19
    s.addi       s37, s43, #48
    s.add        s43, s6, s37
    v.st.b       [s22, #0], v24
    s.addi       s22, s25, #400
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s38, #0]
    v.extract    s37, v23, #14
    s.add        s38, s37, s19
    s.addi       s37, s38, #48
    s.add        s38, s6, s37
    v.st.b       [s33, #0], v24
    s.addi       s33, s25, #432
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s40, #0]
    v.extract    s37, v23, #15
    s.add        s40, s37, s19
    s.addi       s37, s40, #48
    s.add        s40, s6, s37
    v.st.b       [s35, #0], v24
    s.addi       s35, s25, #464
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s44, #0]
    v.extract    s37, v26, #0
    s.add        s44, s37, s19
    s.addi       s37, s44, #32
    s.add        s44, s6, s37
    v.st.b       [s22, #0], v24
    s.addi       s22, s25, #496
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s43, #0]
    v.extract    s37, v26, #1
    s.add        s43, s37, s19
    s.addi       s37, s43, #32
    s.add        s43, s6, s37
    v.st.b       [s33, #0], v24
    s.addi       s33, s34, #2560                 // 512 bytes of repack scratch
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s38, #0]
    s.addi       s37, s33, #0
    v.st.b       [s35, #0], v24
    v.extract    s35, v26, #2
    s.add        s38, s35, s19
    s.addi       s35, s38, #32
    s.add        s38, s6, s35
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s40, #0]
    s.addi       s35, s33, #32
    v.st.b       [s22, #0], v24
    v.extract    s22, v26, #3
    s.add        s40, s22, s19
    s.addi       s22, s40, #32
    s.add        s40, s6, s22
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s44, #0]
    s.addi       s22, s33, #64
    v.st.b       [s37, #0], v24
    v.extract    s37, v26, #4
    s.add        s44, s37, s19
    s.addi       s37, s44, #32
    s.add        s44, s6, s37
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s43, #0]
    s.addi       s37, s33, #96
    v.st.b       [s35, #0], v24
    v.extract    s35, v26, #5
    s.add        s43, s35, s19
    s.addi       s35, s43, #32
    s.add        s43, s6, s35
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s38, #0]
    s.addi       s35, s33, #128
    v.st.b       [s22, #0], v24
    v.extract    s22, v26, #6
    s.add        s38, s22, s19
    s.addi       s22, s38, #32
    s.add        s38, s6, s22
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s40, #0]
    s.addi       s22, s33, #160
    v.st.b       [s37, #0], v24
    v.extract    s37, v26, #7
    s.add        s40, s37, s19
    s.addi       s37, s40, #32
    s.add        s40, s6, s37
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s44, #0]
    s.addi       s37, s33, #192
    v.st.b       [s35, #0], v24
    v.extract    s35, v26, #8
    s.add        s44, s35, s19
    s.addi       s35, s44, #32
    s.add        s44, s6, s35
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s43, #0]
    s.addi       s35, s33, #224
    v.st.b       [s22, #0], v24
    v.extract    s22, v26, #9
    s.add        s43, s22, s19
    s.addi       s22, s43, #32
    s.add        s43, s6, s22
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s38, #0]
    s.addi       s22, s33, #256
    v.st.b       [s37, #0], v24
    v.extract    s37, v26, #10
    s.add        s38, s37, s19
    s.addi       s37, s38, #32
    s.add        s38, s6, s37
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s40, #0]
    s.addi       s37, s33, #288
    v.st.b       [s35, #0], v24
    v.extract    s35, v26, #11
    s.add        s40, s35, s19
    s.addi       s35, s40, #32
    s.add        s40, s6, s35
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s44, #0]
    s.addi       s35, s33, #320
    v.st.b       [s22, #0], v24
    v.extract    s22, v26, #12
    s.add        s44, s22, s19
    s.addi       s22, s44, #32
    s.add        s44, s6, s22
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s43, #0]
    s.addi       s22, s33, #352
    v.st.b       [s37, #0], v24
    v.extract    s37, v26, #13
    s.add        s43, s37, s19
    s.addi       s37, s43, #32
    s.add        s43, s6, s37
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s38, #0]
    s.addi       s37, s33, #384
    v.st.b       [s35, #0], v24
    v.extract    s35, v26, #14
    s.add        s38, s35, s19
    s.addi       s35, s38, #32
    s.add        s38, s6, s35
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s40, #0]
    s.addi       s35, s33, #416
    v.st.b       [s22, #0], v24
    v.extract    s22, v26, #15
    s.add        s40, s22, s19
    s.addi       s22, s40, #32
    s.add        s40, s6, s22
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s44, #0]
    s.addi       s22, s33, #448
    v.st.b       [s37, #0], v24
    v.extract    s37, v26, #0
    s.add        s44, s37, s19
    s.addi       s37, s44, #48
    s.add        s44, s6, s37
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s43, #0]
    s.addi       s37, s33, #480
    v.st.b       [s35, #0], v24
    v.extract    s35, v26, #1
    s.add        s43, s35, s19
    s.addi       s35, s43, #48
    s.add        s43, s6, s35
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s38, #0]
    s.addi       s35, s33, #16
    v.st.b       [s22, #0], v24
    v.extract    s22, v26, #2
    s.add        s38, s22, s19
    s.addi       s22, s38, #48
    s.add        s38, s6, s22
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s40, #0]
    s.addi       s22, s33, #48
    v.st.b       [s37, #0], v24
    v.extract    s37, v26, #3
    s.add        s40, s37, s19
    s.addi       s37, s40, #48
    s.add        s40, s6, s37
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s44, #0]
    s.addi       s37, s33, #80
    v.st.b       [s35, #0], v24
    v.extract    s35, v26, #4
    s.add        s44, s35, s19
    s.addi       s35, s44, #48
    s.add        s44, s6, s35
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s43, #0]
    s.addi       s35, s33, #112
    v.st.b       [s22, #0], v24
    v.extract    s22, v26, #5
    s.add        s43, s22, s19
    s.addi       s22, s43, #48
    s.add        s43, s6, s22
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s38, #0]
    s.addi       s22, s33, #144
    v.st.b       [s37, #0], v24
    v.extract    s37, v26, #6
    s.add        s38, s37, s19
    s.addi       s37, s38, #48
    s.add        s38, s6, s37
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s40, #0]
    s.addi       s37, s33, #176
    v.st.b       [s35, #0], v24
    v.extract    s35, v26, #7
    s.add        s40, s35, s19
    s.addi       s35, s40, #48
    s.add        s40, s6, s35
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s44, #0]
    s.addi       s35, s33, #208
    v.st.b       [s22, #0], v24
    v.extract    s22, v26, #8
    s.add        s44, s22, s19
    s.addi       s22, s44, #48
    s.add        s44, s6, s22
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s43, #0]
    s.addi       s22, s33, #240
    v.st.b       [s37, #0], v24
    v.extract    s37, v26, #9
    s.add        s43, s37, s19
    s.addi       s37, s43, #48
    s.add        s43, s6, s37
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s38, #0]
    s.addi       s37, s33, #272
    v.st.b       [s35, #0], v24
    v.extract    s35, v26, #10
    s.add        s38, s35, s19
    s.addi       s35, s38, #48
    s.add        s38, s6, s35
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s40, #0]
    s.addi       s35, s33, #304
    v.st.b       [s22, #0], v24
    v.extract    s22, v26, #11
    s.add        s40, s22, s19
    s.addi       s22, s40, #48
    s.add        s40, s6, s22
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s44, #0]
    s.addi       s22, s33, #336
    v.st.b       [s37, #0], v24
    v.extract    s37, v26, #12
    s.add        s44, s37, s19
    s.addi       s37, s44, #48
    s.add        s44, s6, s37
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s43, #0]
    s.addi       s37, s33, #368
    v.st.b       [s35, #0], v24
    v.extract    s35, v26, #13
    s.add        s43, s35, s19
    s.addi       s35, s43, #48
    s.add        s43, s6, s35
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s38, #0]
    s.addi       s35, s33, #400
    v.st.b       [s22, #0], v24
    v.extract    s22, v26, #14
    s.add        s38, s22, s19
    s.addi       s22, s38, #48
    s.add        s38, s6, s22
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s40, #0]
    s.addi       s22, s33, #432
    v.st.b       [s37, #0], v24
    v.extract    s37, v26, #15
    s.add        s40, s37, s19
    s.addi       s37, s40, #48
    s.add        s40, s6, s37
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s44, #0]
    s.addi       s37, s33, #464
    v.st.b       [s35, #0], v24
    s.addi       s35, s33, #496
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s43, #0]
    v.extract    s43, v7, #0
    v.st.b       [s22, #0], v24
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s38, #0]
    v.st.b       [s37, #0], v24
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s40, #0]
    v.st.b       [s35, #0], v24
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s43, x8dot_done_11
    s.movz       s22, #0
    s.add        s35, s4, s20
    s.addi       s37, s22, #0
    s.addi       s22, s35, #32
    s.addi       s35, s34, #256
x8dot_row_12:
    s.addi       s38, s28, #-32
    v.movi       v24, #0
    s.sub        s40, s38, s37
    s.add        s38, s22, s37
    v.splat      v25, s40
    s.shli       s40, s37, #4
    s.addi       s44, s37, #1
    v.cmp.gt     p1, v25, v24
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v24, [s38, v13]            // index is in elements (ISA sec 9.1)
    s.add        s38, s35, s40
    s.movz       s40, #32
    v.st.b       [s38, #0], v24
    fence.acq_rel.device
    s.mov        s37, s44
    s.cmp.lt     s38, s37, s40
    br.nz        s38, x8dot_row_12
x8dot_done_11:
    v.splat      v24, s43
    v.movi       v25, #0
    mb.arm       s22, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s35, #0
    v.extract    s37, v8, #0
    s.movz       s38, #32
    v.cmp.ne     p1, v24, v25
    v.cmp.eq     p2, v24, v25
    s.mov        s43, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s43, s22            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s43, s22          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s22
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v24, [s25, #0]
    s.addi       s37, s25, #64
    s.addi       s38, s25, #128
    s.addi       s40, s25, #192
    s.addi       s43, s25, #256
    s.addi       s44, s25, #320
    s.addi       s45, s25, #384
    v.mov        v56, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s37, #0]
    s.addi       s37, s25, #448
    v.mov        v57, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s38, #0]
    s.addi       s38, s33, #64
    v.mov        v58, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s40, #0]
    s.addi       s40, s33, #128
    v.mov        v59, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s43, #0]
    s.addi       s43, s33, #192
    v.mov        v60, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s44, #0]
    s.addi       s44, s33, #256
    v.mov        v61, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s45, #0]
    s.addi       s45, s33, #320
    v.mov        v62, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s37, #0]
    s.addi       s37, s33, #384
    v.mov        v63, v24                        // hand off through the shared window (sec 7.3)
    mb.arm       s46, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v48, s46
    mb.wait      s46
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v24, [s33, #0]
    v.mov        v56, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s38, #0]
    s.addi       s38, s33, #448
    v.mov        v57, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s40, #0]
    v.extract    s40, v7, #1
    v.mov        v58, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s43, #0]
    v.mov        v59, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s44, #0]
    v.mov        v60, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s45, #0]
    v.mov        v61, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s37, #0]
    v.mov        v62, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s38, #0]
    v.mov        v63, v24                        // hand off through the shared window (sec 7.3)
    mb.arm       s37, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a12, v56, v48, s37
    mb.wait      s37
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s40, x8dot_done_13
    s.add        s38, s4, s20
    s.addi       s43, s35, #0
    s.addi       s35, s38, #32
    s.addi       s38, s34, #256
x8dot_row_14:
    s.addi       s44, s28, #-32
    v.movi       v24, #0
    s.sub        s45, s44, s43
    s.add        s44, s35, s43
    v.splat      v25, s45
    s.shli       s45, s43, #4
    s.addi       s47, s43, #1
    v.cmp.gt     p1, v25, v24
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v24, [s44, v14]            // index is in elements (ISA sec 9.1)
    s.add        s44, s38, s45
    s.movz       s45, #32
    v.st.b       [s44, #0], v24
    fence.acq_rel.device
    s.mov        s43, s47
    s.cmp.lt     s44, s43, s45
    br.nz        s44, x8dot_row_14
x8dot_done_13:
    v.splat      v24, s40
    v.movi       v25, #0
    mb.arm       s35, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s38, #0
    v.extract    s40, v8, #1
    s.movz       s43, #32
    v.cmp.ne     p1, v24, v25
    v.cmp.eq     p2, v24, v25
    s.mov        s44, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s44, s35            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s44, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v24, [s25, #0]
    s.addi       s40, s25, #64
    s.addi       s43, s25, #128
    s.addi       s44, s25, #192
    s.addi       s45, s25, #256
    s.addi       s47, s25, #320
    s.addi       s48, s25, #384
    v.mov        v56, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s40, #0]
    s.addi       s40, s25, #448
    v.mov        v57, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s43, #0]
    s.addi       s43, s33, #64
    v.mov        v58, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s44, #0]
    s.addi       s44, s33, #128
    v.mov        v59, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s45, #0]
    s.addi       s45, s33, #192
    v.mov        v60, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s47, #0]
    s.addi       s47, s33, #256
    v.mov        v61, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s48, #0]
    s.addi       s48, s33, #320
    v.mov        v62, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s40, #0]
    s.addi       s40, s33, #384
    v.mov        v63, v24                        // hand off through the shared window (sec 7.3)
    mb.arm       s49, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s49
    mb.wait      s49
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v24, [s33, #0]
    v.mov        v56, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s43, #0]
    s.addi       s43, s33, #448
    v.mov        v57, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s44, #0]
    v.extract    s44, v7, #2
    v.mov        v58, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s45, #0]
    v.mov        v59, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s47, #0]
    v.mov        v60, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s48, #0]
    v.mov        v61, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s40, #0]
    v.mov        v62, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s43, #0]
    v.mov        v63, v24                        // hand off through the shared window (sec 7.3)
    mb.arm       s40, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s40
    mb.wait      s40
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s44, x8dot_done_15
    s.add        s43, s4, s20
    s.addi       s45, s38, #0
    s.addi       s38, s43, #32
    s.addi       s43, s34, #256
x8dot_row_16:
    s.addi       s47, s28, #-32
    v.movi       v24, #0
    s.sub        s48, s47, s45
    s.add        s47, s38, s45
    v.splat      v25, s48
    s.shli       s48, s45, #4
    s.addi       s50, s45, #1
    v.cmp.gt     p1, v25, v24
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v24, [s47, v18]            // index is in elements (ISA sec 9.1)
    s.add        s47, s43, s48
    s.movz       s48, #32
    v.st.b       [s47, #0], v24
    fence.acq_rel.device
    s.mov        s45, s50
    s.cmp.lt     s47, s45, s48
    br.nz        s47, x8dot_row_16
x8dot_done_15:
    v.splat      v24, s44
    v.movi       v25, #0
    mb.arm       s38, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s43, #0
    v.extract    s44, v8, #2
    s.movz       s45, #32
    v.cmp.ne     p1, v24, v25
    v.cmp.eq     p2, v24, v25
    s.mov        s47, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s47, s38            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s47, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s47, s38          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s38
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v24, [s25, #0]
    s.addi       s44, s25, #64
    s.addi       s45, s25, #128
    s.addi       s47, s25, #192
    s.addi       s48, s25, #256
    s.addi       s50, s25, #320
    s.addi       s51, s25, #384
    v.mov        v56, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s44, #0]
    s.addi       s44, s25, #448
    v.mov        v57, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s45, #0]
    s.addi       s45, s33, #64
    v.mov        v58, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s47, #0]
    s.addi       s47, s33, #128
    v.mov        v59, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s48, #0]
    s.addi       s48, s33, #192
    v.mov        v60, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s50, #0]
    s.addi       s50, s33, #256
    v.mov        v61, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s51, #0]
    s.addi       s51, s33, #320
    v.mov        v62, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s44, #0]
    s.addi       s44, s33, #384
    v.mov        v63, v24                        // hand off through the shared window (sec 7.3)
    mb.arm       s52, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a10, v56, v48, s52
    mb.wait      s52
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v24, [s33, #0]
    v.mov        v56, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s45, #0]
    s.addi       s45, s33, #448
    v.mov        v57, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s47, #0]
    v.extract    s47, v7, #3
    v.mov        v58, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s48, #0]
    v.mov        v59, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s50, #0]
    v.mov        v60, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s51, #0]
    v.mov        v61, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s44, #0]
    v.mov        v62, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s45, #0]
    v.mov        v63, v24                        // hand off through the shared window (sec 7.3)
    mb.arm       s44, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a14, v56, v48, s44
    mb.wait      s44
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s47, x8dot_done_17
    s.add        s45, s4, s20
    s.addi       s48, s43, #0
    s.addi       s43, s45, #32
    s.addi       s45, s34, #256
x8dot_row_18:
    s.addi       s50, s28, #-32
    v.movi       v24, #0
    s.sub        s51, s50, s48
    s.add        s50, s43, s48
    v.splat      v25, s51
    s.shli       s51, s48, #4
    s.addi       s53, s48, #1
    v.cmp.gt     p1, v25, v24
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v24, [s50, v9]             // index is in elements (ISA sec 9.1)
    s.add        s50, s45, s51
    s.movz       s51, #32
    v.st.b       [s50, #0], v24
    fence.acq_rel.device
    s.mov        s48, s53
    s.cmp.lt     s50, s48, s51
    br.nz        s50, x8dot_row_18
x8dot_done_17:
    v.splat      v24, s47
    v.movi       v25, #0
    mb.arm       s43, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s45, #0
    v.extract    s47, v8, #3
    s.movz       s48, #32
    v.cmp.ne     p1, v24, v25
    v.cmp.eq     p2, v24, v25
    s.mov        s50, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s50, s43            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s50, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s50, s43          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s43
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v24, [s25, #0]
    s.addi       s45, s25, #64
    s.addi       s47, s25, #128
    s.addi       s48, s25, #192
    s.addi       s50, s25, #256
    s.addi       s51, s25, #320
    s.addi       s53, s25, #384
    s.addi       s54, s25, #448
    v.mov        v56, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s45, #0]
    s.addi       s25, s33, #64
    v.mov        v57, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s47, #0]
    s.addi       s45, s33, #128
    v.mov        v58, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s48, #0]
    s.addi       s47, s33, #192
    v.mov        v59, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s50, #0]
    s.addi       s48, s33, #256
    v.mov        v60, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s51, #0]
    s.addi       s50, s33, #320
    v.mov        v61, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s53, #0]
    s.addi       s51, s33, #384
    v.mov        v62, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s54, #0]
    s.addi       s53, s33, #448
    v.mov        v63, v24                        // hand off through the shared window (sec 7.3)
    mb.arm       s54, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s54
    mb.wait      s54
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v24, [s33, #0]
    s.movz       s33, #0
    v.mov        v56, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s25, #0]
    s.add        s25, s33, s3                    // the tile origin
    s.add        s55, s33, s26                   // the tile origin
    v.splat      v25, s25
    v.extract    s25, v23, #0
    v.splat      v27, s55
    s.add        s33, s25, s19
    v.add        v28, v0, v25
    s.addi       s25, s33, #64
    v.extract    s33, v23, #1
    s.add        s55, s6, s25
    v.cmp.lt     p1, v28, v27
    s.add        s25, s33, s19
    s.addi       s33, s25, #64
    s.add        s25, s6, s33
    v.mov        v57, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s45, #0]
    s.addi       s33, s34, #3072                 // 512 bytes of repack scratch
    v.mov        v58, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s47, #0]
    s.addi       s45, s33, #0
    v.mov        v59, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s48, #0]
    v.extract    s47, v23, #2
    s.add        s48, s47, s19
    s.addi       s47, s48, #64
    s.add        s48, s6, s47
    v.mov        v60, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s50, #0]
    s.addi       s47, s33, #32
    v.mov        v61, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s51, #0]
    v.extract    s50, v23, #3
    s.add        s51, s50, s19
    s.addi       s50, s51, #64
    s.add        s51, s6, s50
    v.mov        v62, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s53, #0]
    s.addi       s50, s33, #64
    v.mov        v63, v24                        // hand off through the shared window (sec 7.3)
    mb.arm       s53, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s53
    mb.wait      s53
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s55, #0]
    v.extract    s55, v23, #4
    s.add        s56, s55, s19
    s.addi       s55, s56, #64
    s.add        s56, s6, s55
    v.st.b       [s45, #0], v24
    s.addi       s45, s33, #96
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s25, #0]
    v.extract    s25, v23, #5
    s.add        s55, s25, s19
    s.addi       s25, s55, #64
    s.add        s55, s6, s25
    v.st.b       [s47, #0], v24
    s.addi       s25, s33, #128
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s48, #0]
    v.extract    s47, v23, #6
    s.add        s48, s47, s19
    s.addi       s47, s48, #64
    s.add        s48, s6, s47
    v.st.b       [s50, #0], v24
    s.addi       s47, s33, #160
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s51, #0]
    v.extract    s50, v23, #7
    s.add        s51, s50, s19
    s.addi       s50, s51, #64
    s.add        s51, s6, s50
    v.st.b       [s45, #0], v24
    s.addi       s45, s33, #192
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s56, #0]
    v.extract    s50, v23, #8
    s.add        s56, s50, s19
    s.addi       s50, s56, #64
    s.add        s56, s6, s50
    v.st.b       [s25, #0], v24
    s.addi       s25, s33, #224
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s55, #0]
    v.extract    s50, v23, #9
    s.add        s55, s50, s19
    s.addi       s50, s55, #64
    s.add        s55, s6, s50
    v.st.b       [s47, #0], v24
    s.addi       s47, s33, #256
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s48, #0]
    v.extract    s48, v23, #10
    s.add        s50, s48, s19
    s.addi       s48, s50, #64
    s.add        s50, s6, s48
    v.st.b       [s45, #0], v24
    s.addi       s45, s33, #288
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s51, #0]
    v.extract    s48, v23, #11
    s.add        s51, s48, s19
    s.addi       s48, s51, #64
    s.add        s51, s6, s48
    v.st.b       [s25, #0], v24
    s.addi       s25, s33, #320
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s56, #0]
    v.extract    s48, v23, #12
    s.add        s56, s48, s19
    s.addi       s48, s56, #64
    s.add        s56, s6, s48
    v.st.b       [s47, #0], v24
    s.addi       s47, s33, #352
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s55, #0]
    v.extract    s48, v23, #13
    s.add        s55, s48, s19
    s.addi       s48, s55, #64
    s.add        s55, s6, s48
    v.st.b       [s45, #0], v24
    s.addi       s45, s33, #384
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s50, #0]
    v.extract    s48, v23, #14
    s.add        s50, s48, s19
    s.addi       s48, s50, #64
    s.add        s50, s6, s48
    v.st.b       [s25, #0], v24
    s.addi       s25, s33, #416
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s51, #0]
    v.extract    s48, v23, #15
    s.add        s51, s48, s19
    s.addi       s48, s51, #64
    s.add        s51, s6, s48
    v.st.b       [s47, #0], v24
    s.addi       s47, s33, #448
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s56, #0]
    s.movz       s48, #0
    v.st.b       [s45, #0], v24
    s.add        s45, s48, s12                   // the tile origin
    s.add        s56, s48, s26                   // the tile origin
    v.splat      v24, s45
    v.extract    s45, v23, #0
    v.splat      v25, s56
    s.add        s48, s45, s19
    v.add        v27, v0, v24
    s.addi       s45, s48, #80
    s.addi       s48, s33, #480
    s.add        s56, s6, s45
    v.cmp.lt     p2, v27, v25
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s55, #0]
    v.extract    s45, v23, #1
    s.add        s55, s45, s19
    s.addi       s45, s55, #80
    s.add        s55, s6, s45
    v.st.b       [s25, #0], v24
    s.addi       s25, s33, #16
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s50, #0]
    v.extract    s45, v23, #2
    s.add        s50, s45, s19
    s.addi       s45, s50, #80
    s.add        s50, s6, s45
    v.st.b       [s47, #0], v24
    s.addi       s45, s33, #48
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s51, #0]
    v.extract    s47, v23, #3
    s.add        s51, s47, s19
    s.addi       s47, s51, #80
    s.add        s51, s6, s47
    v.st.b       [s48, #0], v24
    s.addi       s47, s33, #80
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s56, #0]
    v.extract    s48, v23, #4
    s.add        s56, s48, s19
    s.addi       s48, s56, #80
    s.add        s56, s6, s48
    v.st.b       [s25, #0], v24
    s.addi       s25, s33, #112
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s55, #0]
    v.extract    s48, v23, #5
    s.add        s55, s48, s19
    s.addi       s48, s55, #80
    s.add        s55, s6, s48
    v.st.b       [s45, #0], v24
    s.addi       s45, s33, #144
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s50, #0]
    v.extract    s48, v23, #6
    s.add        s50, s48, s19
    s.addi       s48, s50, #80
    s.add        s50, s6, s48
    v.st.b       [s47, #0], v24
    s.addi       s47, s33, #176
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s51, #0]
    v.extract    s48, v23, #7
    s.add        s51, s48, s19
    s.addi       s48, s51, #80
    s.add        s51, s6, s48
    v.st.b       [s25, #0], v24
    s.addi       s25, s33, #208
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s56, #0]
    v.extract    s48, v23, #8
    s.add        s56, s48, s19
    s.addi       s48, s56, #80
    s.add        s56, s6, s48
    v.st.b       [s45, #0], v24
    s.addi       s45, s33, #240
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s55, #0]
    v.extract    s48, v23, #9
    s.add        s55, s48, s19
    s.addi       s48, s55, #80
    s.add        s55, s6, s48
    v.st.b       [s47, #0], v24
    s.addi       s47, s33, #272
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s50, #0]
    v.extract    s48, v23, #10
    s.add        s50, s48, s19
    s.addi       s48, s50, #80
    s.add        s50, s6, s48
    v.st.b       [s25, #0], v24
    s.addi       s25, s33, #304
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s51, #0]
    v.extract    s48, v23, #11
    s.add        s51, s48, s19
    s.addi       s48, s51, #80
    s.add        s51, s6, s48
    v.st.b       [s45, #0], v24
    s.addi       s45, s33, #336
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s56, #0]
    v.extract    s48, v23, #12
    s.add        s56, s48, s19
    s.addi       s48, s56, #80
    s.add        s56, s6, s48
    v.st.b       [s47, #0], v24
    s.addi       s47, s33, #368
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s55, #0]
    v.extract    s48, v23, #13
    s.add        s55, s48, s19
    s.addi       s48, s55, #80
    s.add        s55, s6, s48
    v.st.b       [s25, #0], v24
    s.addi       s25, s33, #400
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s50, #0]
    v.extract    s48, v23, #14
    s.add        s50, s48, s19
    s.addi       s48, s50, #80
    s.add        s50, s6, s48
    v.st.b       [s45, #0], v24
    s.addi       s45, s33, #432
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s51, #0]
    v.extract    s48, v23, #15
    s.add        s51, s48, s19
    s.addi       s48, s51, #80
    s.add        s51, s6, s48
    v.st.b       [s47, #0], v24
    s.addi       s47, s33, #464
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s56, #0]
    v.extract    s48, v26, #0
    s.add        s56, s48, s19
    s.addi       s48, s56, #64
    s.add        s56, s6, s48
    v.st.b       [s25, #0], v24
    s.addi       s25, s33, #496
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s55, #0]
    v.extract    s48, v26, #1
    s.add        s55, s48, s19
    s.addi       s48, s55, #64
    s.add        s55, s6, s48
    v.st.b       [s45, #0], v24
    s.addi       s45, s34, #3584                 // 512 bytes of repack scratch
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s50, #0]
    s.addi       s48, s45, #0
    v.st.b       [s47, #0], v24
    v.extract    s47, v26, #2
    s.add        s50, s47, s19
    s.addi       s47, s50, #64
    s.add        s50, s6, s47
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s51, #0]
    s.addi       s47, s45, #32
    v.st.b       [s25, #0], v24
    v.extract    s25, v26, #3
    s.add        s51, s25, s19
    s.addi       s25, s51, #64
    s.add        s51, s6, s25
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s56, #0]
    s.addi       s25, s45, #64
    v.st.b       [s48, #0], v24
    v.extract    s48, v26, #4
    s.add        s56, s48, s19
    s.addi       s48, s56, #64
    s.add        s56, s6, s48
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s55, #0]
    s.addi       s48, s45, #96
    v.st.b       [s47, #0], v24
    v.extract    s47, v26, #5
    s.add        s55, s47, s19
    s.addi       s47, s55, #64
    s.add        s55, s6, s47
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s50, #0]
    s.addi       s47, s45, #128
    v.st.b       [s25, #0], v24
    v.extract    s25, v26, #6
    s.add        s50, s25, s19
    s.addi       s25, s50, #64
    s.add        s50, s6, s25
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s51, #0]
    s.addi       s25, s45, #160
    v.st.b       [s48, #0], v24
    v.extract    s48, v26, #7
    s.add        s51, s48, s19
    s.addi       s48, s51, #64
    s.add        s51, s6, s48
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s56, #0]
    s.addi       s48, s45, #192
    v.st.b       [s47, #0], v24
    v.extract    s47, v26, #8
    s.add        s56, s47, s19
    s.addi       s47, s56, #64
    s.add        s56, s6, s47
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s55, #0]
    s.addi       s47, s45, #224
    v.st.b       [s25, #0], v24
    v.extract    s25, v26, #9
    s.add        s55, s25, s19
    s.addi       s25, s55, #64
    s.add        s55, s6, s25
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s50, #0]
    s.addi       s25, s45, #256
    v.st.b       [s48, #0], v24
    v.extract    s48, v26, #10
    s.add        s50, s48, s19
    s.addi       s48, s50, #64
    s.add        s50, s6, s48
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s51, #0]
    s.addi       s48, s45, #288
    v.st.b       [s47, #0], v24
    v.extract    s47, v26, #11
    s.add        s51, s47, s19
    s.addi       s47, s51, #64
    s.add        s51, s6, s47
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s56, #0]
    s.addi       s47, s45, #320
    v.st.b       [s25, #0], v24
    v.extract    s25, v26, #12
    s.add        s56, s25, s19
    s.addi       s25, s56, #64
    s.add        s56, s6, s25
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s55, #0]
    s.addi       s25, s45, #352
    v.st.b       [s48, #0], v24
    v.extract    s48, v26, #13
    s.add        s55, s48, s19
    s.addi       s48, s55, #64
    s.add        s55, s6, s48
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s50, #0]
    s.addi       s48, s45, #384
    v.st.b       [s47, #0], v24
    v.extract    s47, v26, #14
    s.add        s50, s47, s19
    s.addi       s47, s50, #64
    s.add        s50, s6, s47
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s51, #0]
    s.addi       s47, s45, #416
    v.st.b       [s25, #0], v24
    v.extract    s25, v26, #15
    s.add        s51, s25, s19
    s.addi       s25, s51, #64
    s.add        s51, s6, s25
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s56, #0]
    s.addi       s25, s45, #448
    v.st.b       [s48, #0], v24
    v.extract    s48, v26, #0
    s.add        s56, s48, s19
    s.addi       s48, s56, #80
    s.add        s56, s6, s48
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s55, #0]
    s.addi       s48, s45, #480
    v.st.b       [s47, #0], v24
    v.extract    s47, v26, #1
    s.add        s55, s47, s19
    s.addi       s47, s55, #80
    s.add        s55, s6, s47
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s50, #0]
    s.addi       s47, s45, #16
    v.st.b       [s25, #0], v24
    v.extract    s25, v26, #2
    s.add        s50, s25, s19
    s.addi       s25, s50, #80
    s.add        s50, s6, s25
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s51, #0]
    s.addi       s25, s45, #48
    v.st.b       [s48, #0], v24
    v.extract    s48, v26, #3
    s.add        s51, s48, s19
    s.addi       s48, s51, #80
    s.add        s51, s6, s48
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s56, #0]
    s.addi       s48, s45, #80
    v.st.b       [s47, #0], v24
    v.extract    s47, v26, #4
    s.add        s56, s47, s19
    s.addi       s47, s56, #80
    s.add        s56, s6, s47
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s55, #0]
    s.addi       s47, s45, #112
    v.st.b       [s25, #0], v24
    v.extract    s25, v26, #5
    s.add        s55, s25, s19
    s.addi       s25, s55, #80
    s.add        s55, s6, s25
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s50, #0]
    s.addi       s25, s45, #144
    v.st.b       [s48, #0], v24
    v.extract    s48, v26, #6
    s.add        s50, s48, s19
    s.addi       s48, s50, #80
    s.add        s50, s6, s48
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s51, #0]
    s.addi       s48, s45, #176
    v.st.b       [s47, #0], v24
    v.extract    s47, v26, #7
    s.add        s51, s47, s19
    s.addi       s47, s51, #80
    s.add        s51, s6, s47
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s56, #0]
    s.addi       s47, s45, #208
    v.st.b       [s25, #0], v24
    v.extract    s25, v26, #8
    s.add        s56, s25, s19
    s.addi       s25, s56, #80
    s.add        s56, s6, s25
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s55, #0]
    s.addi       s25, s45, #240
    v.st.b       [s48, #0], v24
    v.extract    s48, v26, #9
    s.add        s55, s48, s19
    s.addi       s48, s55, #80
    s.add        s55, s6, s48
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s50, #0]
    s.addi       s48, s45, #272
    v.st.b       [s47, #0], v24
    v.extract    s47, v26, #10
    s.add        s50, s47, s19
    s.addi       s47, s50, #80
    s.add        s50, s6, s47
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s51, #0]
    s.addi       s47, s45, #304
    v.st.b       [s25, #0], v24
    v.extract    s25, v26, #11
    s.add        s51, s25, s19
    s.addi       s25, s51, #80
    s.add        s51, s6, s25
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s56, #0]
    s.addi       s25, s45, #336
    v.st.b       [s48, #0], v24
    v.extract    s48, v26, #12
    s.add        s56, s48, s19
    s.addi       s48, s56, #80
    s.add        s56, s6, s48
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s55, #0]
    s.addi       s48, s45, #368
    v.st.b       [s47, #0], v24
    v.extract    s47, v26, #13
    s.add        s55, s47, s19
    s.addi       s47, s55, #80
    s.add        s55, s6, s47
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s50, #0]
    s.addi       s47, s45, #400
    v.st.b       [s25, #0], v24
    v.extract    s25, v26, #14
    s.add        s50, s25, s19
    s.addi       s25, s50, #80
    s.add        s50, s6, s25
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s51, #0]
    s.addi       s25, s45, #432
    v.st.b       [s48, #0], v24
    v.extract    s48, v26, #15
    s.add        s51, s48, s19
    s.addi       s48, s51, #80
    s.add        s51, s6, s48
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s56, #0]
    s.addi       s48, s45, #464
    v.st.b       [s47, #0], v24
    s.addi       s47, s45, #496
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s55, #0]
    v.extract    s55, v7, #0
    v.st.b       [s25, #0], v24
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s50, #0]
    v.st.b       [s48, #0], v24
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v24, [s51, #0]
    v.st.b       [s47, #0], v24
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s55, x8dot_done_19
    s.movz       s25, #0
    s.add        s47, s4, s20
    s.addi       s48, s25, #0
    s.addi       s25, s47, #64
    s.addi       s47, s34, #256
x8dot_row_20:
    s.addi       s50, s28, #-64
    v.movi       v24, #0
    s.sub        s51, s50, s48
    s.add        s50, s25, s48
    v.splat      v25, s51
    s.shli       s51, s48, #4
    s.addi       s56, s48, #1
    v.cmp.gt     p1, v25, v24
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v24, [s50, v13]            // index is in elements (ISA sec 9.1)
    s.add        s50, s47, s51
    s.movz       s51, #32
    v.st.b       [s50, #0], v24
    fence.acq_rel.device
    s.mov        s48, s56
    s.cmp.lt     s50, s48, s51
    br.nz        s50, x8dot_row_20
x8dot_done_19:
    v.splat      v24, s55
    v.movi       v25, #0
    mb.arm       s25, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s47, #0
    v.extract    s48, v8, #0
    s.movz       s50, #64
    v.cmp.ne     p1, v24, v25
    v.cmp.eq     p2, v24, v25
    s.mov        s55, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s55, s25            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s55, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s55, s25          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s25
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v24, [s33, #0]
    s.addi       s48, s33, #64
    s.addi       s50, s33, #128
    s.addi       s51, s33, #192
    s.addi       s55, s33, #256
    s.addi       s56, s33, #320
    s.addi       s57, s33, #384
    v.mov        v56, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s48, #0]
    s.addi       s48, s33, #448
    v.mov        v57, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s50, #0]
    s.addi       s50, s45, #64
    v.mov        v58, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s51, #0]
    s.addi       s51, s45, #128
    v.mov        v59, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s55, #0]
    s.addi       s55, s45, #192
    v.mov        v60, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s56, #0]
    s.addi       s56, s45, #256
    v.mov        v61, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s57, #0]
    s.addi       s57, s45, #320
    v.mov        v62, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s48, #0]
    s.addi       s48, s45, #384
    v.mov        v63, v24                        // hand off through the shared window (sec 7.3)
    mb.arm       s58, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v48, s58
    mb.wait      s58
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v24, [s45, #0]
    v.mov        v56, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s50, #0]
    s.addi       s50, s45, #448
    v.mov        v57, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s51, #0]
    v.extract    s51, v7, #1
    v.mov        v58, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s55, #0]
    v.mov        v59, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s56, #0]
    v.mov        v60, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s57, #0]
    v.mov        v61, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s48, #0]
    v.mov        v62, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s50, #0]
    v.mov        v63, v24                        // hand off through the shared window (sec 7.3)
    mb.arm       s48, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a12, v56, v48, s48
    mb.wait      s48
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s51, x8dot_done_21
    s.add        s50, s4, s20
    s.addi       s55, s47, #0
    s.addi       s47, s50, #64
    s.addi       s50, s34, #256
x8dot_row_22:
    s.addi       s56, s28, #-64
    v.movi       v24, #0
    s.sub        s57, s56, s55
    s.add        s56, s47, s55
    v.splat      v25, s57
    s.shli       s57, s55, #4
    s.addi       s59, s55, #1
    v.cmp.gt     p1, v25, v24
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v24, [s56, v14]            // index is in elements (ISA sec 9.1)
    s.add        s56, s50, s57
    s.movz       s57, #32
    v.st.b       [s56, #0], v24
    fence.acq_rel.device
    s.mov        s55, s59
    s.cmp.lt     s56, s55, s57
    br.nz        s56, x8dot_row_22
x8dot_done_21:
    v.splat      v24, s51
    v.movi       v25, #0
    mb.arm       s47, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s50, #0
    v.extract    s51, v8, #1
    s.movz       s55, #64
    v.cmp.ne     p1, v24, v25
    v.cmp.eq     p2, v24, v25
    s.mov        s56, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s56, s47            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s56, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s56, s47          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s47
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v24, [s33, #0]
    s.addi       s51, s33, #64
    s.addi       s55, s33, #128
    s.addi       s56, s33, #192
    s.addi       s57, s33, #256
    s.addi       s59, s33, #320
    s.addi       s60, s33, #384
    v.mov        v56, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s51, #0]
    s.addi       s51, s33, #448
    v.mov        v57, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s55, #0]
    s.addi       s55, s45, #64
    v.mov        v58, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s56, #0]
    s.addi       s56, s45, #128
    v.mov        v59, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s57, #0]
    s.addi       s57, s45, #192
    v.mov        v60, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s59, #0]
    s.addi       s59, s45, #256
    v.mov        v61, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s60, #0]
    s.addi       s60, s45, #320
    v.mov        v62, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s51, #0]
    s.addi       s51, s45, #384
    v.mov        v63, v24                        // hand off through the shared window (sec 7.3)
    mb.arm       s21, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s21
    mb.wait      s21
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v24, [s45, #0]
    v.mov        v56, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s55, #0]
    s.addi       s22, s45, #448
    v.mov        v57, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s56, #0]
    v.extract    s23, v7, #2
    v.mov        v58, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s57, #0]
    v.mov        v59, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s59, #0]
    v.mov        v60, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s60, #0]
    v.mov        v61, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s51, #0]
    v.mov        v62, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s22, #0]
    v.mov        v63, v24                        // hand off through the shared window (sec 7.3)
    mb.arm       s22, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s22
    mb.wait      s22
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s23, x8dot_done_23
    s.add        s24, s4, s20
    s.addi       s25, s50, #0
    s.addi       s27, s24, #64
    s.addi       s24, s34, #256
x8dot_row_24:
    s.addi       s29, s28, #-64
    v.movi       v24, #0
    s.sub        s30, s29, s25
    s.add        s29, s27, s25
    v.splat      v25, s30
    s.shli       s30, s25, #4
    s.addi       s31, s25, #1
    v.cmp.gt     p1, v25, v24
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v24, [s29, v18]            // index is in elements (ISA sec 9.1)
    s.add        s29, s24, s30
    s.movz       s30, #32
    v.st.b       [s29, #0], v24
    fence.acq_rel.device
    s.mov        s25, s31
    s.cmp.lt     s29, s25, s30
    br.nz        s29, x8dot_row_24
x8dot_done_23:
    v.splat      v24, s23
    v.movi       v25, #0
    mb.arm       s23, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s24, #0
    v.extract    s25, v8, #2
    s.movz       s27, #64
    v.cmp.ne     p1, v24, v25
    v.cmp.eq     p2, v24, v25
    s.mov        s29, s24                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s30, s24                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s29, s23            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s29, s25                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s30, s27                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s29, s23          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s23
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v24, [s33, #0]
    s.addi       s25, s33, #64
    s.addi       s27, s33, #128
    s.addi       s29, s33, #192
    s.addi       s30, s33, #256
    s.addi       s31, s33, #320
    s.addi       s32, s33, #384
    v.mov        v56, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s25, #0]
    s.addi       s25, s33, #448
    v.mov        v57, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s27, #0]
    s.addi       s27, s45, #64
    v.mov        v58, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s29, #0]
    s.addi       s29, s45, #128
    v.mov        v59, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s30, #0]
    s.addi       s30, s45, #192
    v.mov        v60, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s31, #0]
    s.addi       s31, s45, #256
    v.mov        v61, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s32, #0]
    s.addi       s32, s45, #320
    v.mov        v62, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s25, #0]
    s.addi       s25, s45, #384
    v.mov        v63, v24                        // hand off through the shared window (sec 7.3)
    mb.arm       s35, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a10, v56, v48, s35
    mb.wait      s35
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v24, [s45, #0]
    v.mov        v56, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s27, #0]
    s.addi       s27, s45, #448
    v.mov        v57, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s29, #0]
    v.extract    s29, v7, #3
    v.mov        v58, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s30, #0]
    v.mov        v59, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s31, #0]
    v.mov        v60, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s32, #0]
    v.mov        v61, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s25, #0]
    v.mov        v62, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s27, #0]
    v.mov        v63, v24                        // hand off through the shared window (sec 7.3)
    mb.arm       s25, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a14, v56, v48, s25
    mb.wait      s25
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s29, x8dot_done_25
    s.add        s27, s4, s20
    s.addi       s30, s24, #0
    s.addi       s24, s27, #64
    s.addi       s27, s34, #256
x8dot_row_26:
    s.addi       s31, s28, #-64
    v.movi       v24, #0
    s.sub        s32, s31, s30
    s.add        s31, s24, s30
    v.splat      v25, s32
    s.shli       s32, s30, #4
    s.addi       s36, s30, #1
    v.cmp.gt     p1, v25, v24
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v24, [s31, v9]             // index is in elements (ISA sec 9.1)
    s.add        s31, s27, s32
    s.movz       s32, #32
    v.st.b       [s31, #0], v24
    fence.acq_rel.device
    s.mov        s30, s36
    s.cmp.lt     s31, s30, s32
    br.nz        s31, x8dot_row_26
x8dot_done_25:
    v.splat      v24, s29
    v.movi       v25, #0
    mb.arm       s24, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s27, #0
    v.extract    s29, v8, #3
    s.movz       s30, #64
    v.cmp.ne     p1, v24, v25
    v.cmp.eq     p2, v24, v25
    s.mov        s31, s27                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s32, s27                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s31, s24            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s31, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s32, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s31, s24          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s24
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v24, [s33, #0]
    s.addi       s27, s33, #64
    s.addi       s29, s33, #128
    s.addi       s30, s33, #192
    s.addi       s31, s33, #256
    s.addi       s32, s33, #320
    s.addi       s36, s33, #384
    s.addi       s37, s33, #448
    v.mov        v56, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s27, #0]
    s.addi       s27, s45, #64
    v.mov        v57, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s29, #0]
    s.addi       s29, s45, #128
    v.mov        v58, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s30, #0]
    s.addi       s30, s45, #192
    v.mov        v59, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s31, #0]
    s.addi       s31, s45, #256
    v.mov        v60, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s32, #0]
    s.addi       s32, s45, #320
    v.mov        v61, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s36, #0]
    s.addi       s33, s45, #384
    v.mov        v62, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s37, #0]
    s.addi       s36, s45, #448
    v.mov        v63, v24                        // hand off through the shared window (sec 7.3)
    mb.arm       s37, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s37
    mb.wait      s37
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v24, [s45, #0]
    s.movz       s38, #0
    v.mov        v56, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s27, #0]
    s.add        s27, s38, s13                   // the tile origin
    s.add        s39, s38, s26                   // the tile origin
    v.splat      v25, s27
    v.extract    s27, v23, #0
    v.splat      v27, s39
    s.add        s38, s27, s19
    v.add        v28, v0, v25
    s.addi       s27, s38, #96
    v.extract    s38, v23, #1
    s.add        s39, s6, s27
    v.cmp.lt     p1, v28, v27
    s.add        s27, s38, s19
    s.addi       s38, s27, #96
    s.add        s27, s6, s38
    v.mov        v57, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s29, #0]
    s.addi       s29, s34, #4096                 // 512 bytes of repack scratch
    v.mov        v58, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s30, #0]
    s.addi       s30, s29, #0
    v.mov        v59, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s31, #0]
    v.extract    s31, v23, #2
    s.add        s38, s31, s19
    s.addi       s31, s38, #96
    s.add        s38, s6, s31
    v.mov        v60, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s32, #0]
    s.addi       s31, s29, #32
    v.mov        v61, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s33, #0]
    v.extract    s32, v23, #3
    s.add        s33, s32, s19
    s.addi       s32, s33, #96
    s.add        s33, s6, s32
    v.mov        v62, v24                        // hand off through the shared window (sec 7.3)
    v.ld.w       v24, [s36, #0]
    s.addi       s32, s29, #64
    v.mov        v63, v24                        // hand off through the shared window (sec 7.3)
    mb.arm       s36, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s36
    mb.wait      s36
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s39, #0]
    v.extract    s39, v23, #4
    s.add        s40, s39, s19
    s.addi       s39, s40, #96
    s.add        s40, s6, s39
    v.st.b       [s30, #0], v24
    s.addi       s30, s29, #96
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s27, #0]
    v.extract    s27, v23, #5
    s.add        s39, s27, s19
    s.addi       s27, s39, #96
    s.add        s39, s6, s27
    v.st.b       [s31, #0], v24
    s.addi       s27, s29, #128
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s38, #0]
    v.extract    s31, v23, #6
    s.add        s38, s31, s19
    s.addi       s31, s38, #96
    s.add        s38, s6, s31
    v.st.b       [s32, #0], v24
    s.addi       s31, s29, #160
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s33, #0]
    v.extract    s32, v23, #7
    s.add        s33, s32, s19
    s.addi       s32, s33, #96
    s.add        s33, s6, s32
    v.st.b       [s30, #0], v24
    s.addi       s30, s29, #192
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s40, #0]
    v.extract    s32, v23, #8
    s.add        s40, s32, s19
    s.addi       s32, s40, #96
    s.add        s40, s6, s32
    v.st.b       [s27, #0], v24
    s.addi       s27, s29, #224
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s39, #0]
    v.extract    s32, v23, #9
    s.add        s39, s32, s19
    s.addi       s32, s39, #96
    s.add        s39, s6, s32
    v.st.b       [s31, #0], v24
    s.addi       s31, s29, #256
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s38, #0]
    v.extract    s32, v23, #10
    s.add        s38, s32, s19
    s.addi       s32, s38, #96
    s.add        s38, s6, s32
    v.st.b       [s30, #0], v24
    s.addi       s30, s29, #288
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s33, #0]
    v.extract    s32, v23, #11
    s.add        s33, s32, s19
    s.addi       s32, s33, #96
    s.add        s33, s6, s32
    v.st.b       [s27, #0], v24
    s.addi       s27, s29, #320
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s40, #0]
    v.extract    s32, v23, #12
    s.add        s40, s32, s19
    s.addi       s32, s40, #96
    s.add        s40, s6, s32
    v.st.b       [s31, #0], v24
    s.addi       s31, s29, #352
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s39, #0]
    v.extract    s32, v23, #13
    s.add        s39, s32, s19
    s.addi       s32, s39, #96
    s.add        s39, s6, s32
    v.st.b       [s30, #0], v24
    s.addi       s30, s29, #384
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s38, #0]
    v.extract    s32, v23, #14
    s.add        s38, s32, s19
    s.addi       s32, s38, #96
    s.add        s38, s6, s32
    v.st.b       [s27, #0], v24
    s.addi       s27, s29, #416
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s33, #0]
    v.extract    s32, v23, #15
    s.add        s33, s32, s19
    s.addi       s32, s33, #96
    s.add        s33, s6, s32
    v.st.b       [s31, #0], v24
    s.addi       s31, s29, #448
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v24, [s40, #0]
    s.movz       s32, #0
    s.add        s40, s32, s26                   // the tile origin
    s.add        s26, s32, s14                   // the tile origin
    v.splat      v25, s40
    v.extract    s32, v23, #0
    v.splat      v27, s26
    s.add        s26, s32, s19
    s.addi       s32, s29, #480
    s.addi       s40, s26, #112
    v.add        v28, v0, v27
    v.st.b       [s30, #0], v24
    s.add        s26, s6, s40
    v.cmp.lt     p2, v28, v25
    v.extract    s30, v23, #1
    s.add        s40, s30, s19
    s.addi       s30, s40, #112
    s.add        s40, s6, s30
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s39, #0]
    s.addi       s30, s29, #16
    v.st.b       [s27, #0], v0
    v.extract    s27, v23, #2
    s.add        s39, s27, s19
    s.addi       s27, s39, #112
    s.add        s39, s6, s27
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s38, #0]
    s.addi       s27, s29, #48
    v.st.b       [s31, #0], v0
    v.extract    s31, v23, #3
    s.add        s38, s31, s19
    s.addi       s31, s38, #112
    s.add        s38, s6, s31
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s33, #0]
    s.addi       s31, s29, #80
    v.st.b       [s32, #0], v0
    v.extract    s32, v23, #4
    s.add        s33, s32, s19
    s.addi       s32, s33, #112
    s.add        s33, s6, s32
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s26, #0]
    s.addi       s26, s29, #112
    v.st.b       [s30, #0], v0
    v.extract    s30, v23, #5
    s.add        s32, s30, s19
    s.addi       s30, s32, #112
    s.add        s32, s6, s30
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s40, #0]
    s.addi       s30, s29, #144
    v.st.b       [s27, #0], v0
    v.extract    s27, v23, #6
    s.add        s40, s27, s19
    s.addi       s27, s40, #112
    s.add        s40, s6, s27
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s39, #0]
    s.addi       s27, s29, #176
    v.st.b       [s31, #0], v0
    v.extract    s31, v23, #7
    s.add        s39, s31, s19
    s.addi       s31, s39, #112
    s.add        s39, s6, s31
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s38, #0]
    s.addi       s31, s29, #208
    v.st.b       [s26, #0], v0
    v.extract    s26, v23, #8
    s.add        s38, s26, s19
    s.addi       s26, s38, #112
    s.add        s38, s6, s26
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s33, #0]
    s.addi       s26, s29, #240
    v.st.b       [s30, #0], v0
    v.extract    s30, v23, #9
    s.add        s33, s30, s19
    s.addi       s30, s33, #112
    s.add        s33, s6, s30
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s32, #0]
    s.addi       s30, s29, #272
    v.st.b       [s27, #0], v0
    v.extract    s27, v23, #10
    s.add        s32, s27, s19
    s.addi       s27, s32, #112
    s.add        s32, s6, s27
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s40, #0]
    s.addi       s27, s29, #304
    v.st.b       [s31, #0], v0
    v.extract    s31, v23, #11
    s.add        s40, s31, s19
    s.addi       s31, s40, #112
    s.add        s40, s6, s31
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s39, #0]
    s.addi       s31, s29, #336
    v.st.b       [s26, #0], v0
    v.extract    s26, v23, #12
    s.add        s39, s26, s19
    s.addi       s26, s39, #112
    s.add        s39, s6, s26
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s38, #0]
    s.addi       s26, s29, #368
    v.st.b       [s30, #0], v0
    v.extract    s30, v23, #13
    s.add        s38, s30, s19
    s.addi       s30, s38, #112
    s.add        s38, s6, s30
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s33, #0]
    s.addi       s30, s29, #400
    v.st.b       [s27, #0], v0
    v.extract    s27, v23, #14
    s.add        s33, s27, s19
    s.addi       s27, s33, #112
    s.add        s33, s6, s27
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s32, #0]
    s.addi       s27, s29, #432
    v.st.b       [s31, #0], v0
    v.extract    s31, v23, #15
    s.add        s32, s31, s19
    s.addi       s31, s32, #112
    s.add        s32, s6, s31
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s40, #0]
    s.addi       s31, s29, #464
    v.st.b       [s26, #0], v0
    v.extract    s26, v26, #0
    s.add        s40, s26, s19
    s.addi       s26, s40, #96
    s.add        s40, s6, s26
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s39, #0]
    s.addi       s26, s29, #496
    v.st.b       [s30, #0], v0
    v.extract    s30, v26, #1
    s.add        s39, s30, s19
    s.addi       s30, s39, #96
    s.add        s39, s6, s30
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s38, #0]
    s.addi       s30, s34, #4608                 // 512 bytes of repack scratch
    v.st.b       [s27, #0], v0
    s.addi       s27, s30, #0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s33, #0]
    v.extract    s33, v26, #2
    s.add        s38, s33, s19
    s.addi       s33, s38, #96
    s.add        s38, s6, s33
    v.st.b       [s31, #0], v0
    s.addi       s31, s30, #32
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s32, #0]
    v.extract    s32, v26, #3
    s.add        s33, s32, s19
    s.addi       s32, s33, #96
    s.add        s33, s6, s32
    v.st.b       [s26, #0], v0
    s.addi       s26, s30, #64
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s40, #0]
    v.extract    s32, v26, #4
    s.add        s40, s32, s19
    s.addi       s32, s40, #96
    s.add        s40, s6, s32
    v.st.b       [s27, #0], v0
    s.addi       s27, s30, #96
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s39, #0]
    v.extract    s32, v26, #5
    s.add        s39, s32, s19
    s.addi       s32, s39, #96
    s.add        s39, s6, s32
    v.st.b       [s31, #0], v0
    s.addi       s31, s30, #128
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s38, #0]
    v.extract    s32, v26, #6
    s.add        s38, s32, s19
    s.addi       s32, s38, #96
    s.add        s38, s6, s32
    v.st.b       [s26, #0], v0
    s.addi       s26, s30, #160
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s33, #0]
    v.extract    s32, v26, #7
    s.add        s33, s32, s19
    s.addi       s32, s33, #96
    s.add        s33, s6, s32
    v.st.b       [s27, #0], v0
    s.addi       s27, s30, #192
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s40, #0]
    v.extract    s32, v26, #8
    s.add        s40, s32, s19
    s.addi       s32, s40, #96
    s.add        s40, s6, s32
    v.st.b       [s31, #0], v0
    s.addi       s31, s30, #224
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s39, #0]
    v.extract    s32, v26, #9
    s.add        s39, s32, s19
    s.addi       s32, s39, #96
    s.add        s39, s6, s32
    v.st.b       [s26, #0], v0
    s.addi       s26, s30, #256
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s38, #0]
    v.extract    s32, v26, #10
    s.add        s38, s32, s19
    s.addi       s32, s38, #96
    s.add        s38, s6, s32
    v.st.b       [s27, #0], v0
    s.addi       s27, s30, #288
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s33, #0]
    v.extract    s32, v26, #11
    s.add        s33, s32, s19
    s.addi       s32, s33, #96
    s.add        s33, s6, s32
    v.st.b       [s31, #0], v0
    s.addi       s31, s30, #320
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s40, #0]
    v.extract    s32, v26, #12
    s.add        s40, s32, s19
    s.addi       s32, s40, #96
    s.add        s40, s6, s32
    v.st.b       [s26, #0], v0
    s.addi       s26, s30, #352
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s39, #0]
    v.extract    s32, v26, #13
    s.add        s39, s32, s19
    s.addi       s32, s39, #96
    s.add        s39, s6, s32
    v.st.b       [s27, #0], v0
    s.addi       s27, s30, #384
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s38, #0]
    v.extract    s32, v26, #14
    s.add        s38, s32, s19
    s.addi       s32, s38, #96
    s.add        s38, s6, s32
    v.st.b       [s31, #0], v0
    s.addi       s31, s30, #416
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s33, #0]
    v.extract    s32, v26, #15
    s.add        s33, s32, s19
    s.addi       s32, s33, #96
    s.add        s33, s6, s32
    v.st.b       [s26, #0], v0
    s.addi       s26, s30, #448
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s40, #0]
    v.extract    s32, v26, #0
    s.add        s40, s32, s19
    s.addi       s32, s40, #112
    s.add        s40, s6, s32
    v.st.b       [s27, #0], v0
    s.addi       s27, s30, #480
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s39, #0]
    v.extract    s32, v26, #1
    s.add        s39, s32, s19
    s.addi       s32, s39, #112
    s.add        s39, s6, s32
    v.st.b       [s31, #0], v0
    s.addi       s31, s30, #16
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s38, #0]
    v.extract    s32, v26, #2
    s.add        s38, s32, s19
    s.addi       s32, s38, #112
    s.add        s38, s6, s32
    v.st.b       [s26, #0], v0
    s.addi       s26, s30, #48
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s33, #0]
    v.extract    s32, v26, #3
    s.add        s33, s32, s19
    s.addi       s32, s33, #112
    s.add        s33, s6, s32
    v.st.b       [s27, #0], v0
    s.addi       s27, s30, #80
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s40, #0]
    v.extract    s32, v26, #4
    s.add        s40, s32, s19
    s.addi       s32, s40, #112
    s.add        s40, s6, s32
    v.st.b       [s31, #0], v0
    s.addi       s31, s30, #112
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s39, #0]
    v.extract    s32, v26, #5
    s.add        s39, s32, s19
    s.addi       s32, s39, #112
    s.add        s39, s6, s32
    v.st.b       [s26, #0], v0
    s.addi       s26, s30, #144
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s38, #0]
    v.extract    s32, v26, #6
    s.add        s38, s32, s19
    s.addi       s32, s38, #112
    s.add        s38, s6, s32
    v.st.b       [s27, #0], v0
    s.addi       s27, s30, #176
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s33, #0]
    v.extract    s32, v26, #7
    s.add        s33, s32, s19
    s.addi       s32, s33, #112
    s.add        s33, s6, s32
    v.st.b       [s31, #0], v0
    s.addi       s31, s30, #208
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s40, #0]
    v.extract    s32, v26, #8
    s.add        s40, s32, s19
    s.addi       s32, s40, #112
    s.add        s40, s6, s32
    v.st.b       [s26, #0], v0
    s.addi       s26, s30, #240
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s39, #0]
    v.extract    s32, v26, #9
    s.add        s39, s32, s19
    s.addi       s32, s39, #112
    s.add        s39, s6, s32
    v.st.b       [s27, #0], v0
    s.addi       s27, s30, #272
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s38, #0]
    v.extract    s32, v26, #10
    s.add        s38, s32, s19
    s.addi       s32, s38, #112
    s.add        s38, s6, s32
    v.st.b       [s31, #0], v0
    s.addi       s31, s30, #304
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s33, #0]
    v.extract    s32, v26, #11
    s.add        s33, s32, s19
    s.addi       s32, s33, #112
    s.add        s33, s6, s32
    v.st.b       [s26, #0], v0
    s.addi       s26, s30, #336
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s40, #0]
    v.extract    s32, v26, #12
    s.add        s40, s32, s19
    s.addi       s32, s40, #112
    s.add        s40, s6, s32
    v.st.b       [s27, #0], v0
    s.addi       s27, s30, #368
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s39, #0]
    v.extract    s32, v26, #13
    s.add        s39, s32, s19
    s.addi       s32, s39, #112
    s.add        s39, s6, s32
    v.st.b       [s31, #0], v0
    s.addi       s31, s30, #400
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s38, #0]
    v.extract    s32, v26, #14
    s.add        s38, s32, s19
    s.addi       s32, s38, #112
    s.add        s38, s6, s32
    v.st.b       [s26, #0], v0
    s.addi       s26, s30, #432
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s33, #0]
    v.extract    s32, v26, #15
    s.add        s33, s32, s19
    s.addi       s32, s33, #112
    s.add        s33, s6, s32
    v.st.b       [s27, #0], v0
    s.addi       s27, s30, #464
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s40, #0]
    s.addi       s32, s30, #496
    v.st.b       [s31, #0], v0
    v.extract    s31, v7, #0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s39, #0]
    v.st.b       [s26, #0], v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s38, #0]
    v.st.b       [s27, #0], v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v0, [s33, #0]
    v.st.b       [s32, #0], v0
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s31, x8dot_done_27
    s.movz       s26, #0
    s.add        s27, s4, s20
    s.addi       s32, s26, #0
    s.addi       s26, s27, #96
    s.addi       s27, s34, #256
x8dot_row_28:
    s.addi       s33, s28, #-96
    v.movi       v0, #0
    s.sub        s38, s33, s32
    s.add        s33, s26, s32
    v.splat      v23, s38
    s.shli       s38, s32, #4
    s.addi       s39, s32, #1
    v.cmp.gt     p1, v23, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v0, [s33, v13]             // index is in elements (ISA sec 9.1)
    s.add        s33, s27, s38
    s.movz       s38, #32
    v.st.b       [s33, #0], v0
    fence.acq_rel.device
    s.mov        s32, s39
    s.cmp.lt     s33, s32, s38
    br.nz        s33, x8dot_row_28
x8dot_done_27:
    v.splat      v0, s31
    v.movi       v13, #0
    mb.arm       s26, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s27, #0
    v.extract    s31, v8, #0
    s.movz       s32, #96
    v.cmp.ne     p1, v0, v13
    v.cmp.eq     p2, v0, v13
    s.mov        s38, s27                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s27                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s38, s26            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s38, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s38, s26          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s26
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v0, [s29, #0]
    s.addi       s31, s29, #64
    s.addi       s32, s29, #128
    s.addi       s33, s29, #192
    s.addi       s38, s29, #256
    s.addi       s39, s29, #320
    s.addi       s40, s29, #384
    v.mov        v56, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s31, #0]
    s.addi       s31, s29, #448
    v.mov        v57, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s32, #0]
    s.addi       s32, s30, #64
    v.mov        v58, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s33, #0]
    s.addi       s33, s30, #128
    v.mov        v59, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s38, #0]
    s.addi       s38, s30, #192
    v.mov        v60, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s39, #0]
    s.addi       s39, s30, #256
    v.mov        v61, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s40, #0]
    s.addi       s40, s30, #320
    v.mov        v62, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s31, #0]
    s.addi       s31, s30, #384
    v.mov        v63, v0                         // hand off through the shared window (sec 7.3)
    mb.arm       s41, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v48, s41
    mb.wait      s41
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v0, [s30, #0]
    v.mov        v56, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s32, #0]
    s.addi       s32, s30, #448
    v.mov        v57, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s33, #0]
    v.extract    s33, v7, #1
    v.mov        v58, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s38, #0]
    v.mov        v59, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s39, #0]
    v.mov        v60, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s40, #0]
    v.mov        v61, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s31, #0]
    v.mov        v62, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s32, #0]
    v.mov        v63, v0                         // hand off through the shared window (sec 7.3)
    mb.arm       s31, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a12, v56, v48, s31
    mb.wait      s31
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s33, x8dot_done_29
    s.add        s32, s4, s20
    s.addi       s38, s27, #0
    s.addi       s27, s32, #96
    s.addi       s32, s34, #256
x8dot_row_30:
    s.addi       s39, s28, #-96
    v.movi       v0, #0
    s.sub        s40, s39, s38
    s.add        s39, s27, s38
    v.splat      v13, s40
    s.shli       s40, s38, #4
    s.addi       s42, s38, #1
    v.cmp.gt     p1, v13, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v0, [s39, v14]             // index is in elements (ISA sec 9.1)
    s.add        s39, s32, s40
    s.movz       s40, #32
    v.st.b       [s39, #0], v0
    fence.acq_rel.device
    s.mov        s38, s42
    s.cmp.lt     s39, s38, s40
    br.nz        s39, x8dot_row_30
x8dot_done_29:
    v.splat      v0, s33
    v.movi       v13, #0
    mb.arm       s27, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s32, #0
    v.extract    s33, v8, #1
    s.movz       s38, #96
    v.cmp.ne     p1, v0, v13
    v.cmp.eq     p2, v0, v13
    s.mov        s39, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s39, s27            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s39, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s39, s27          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s27
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v0, [s29, #0]
    s.addi       s33, s29, #64
    s.addi       s38, s29, #128
    s.addi       s39, s29, #192
    s.addi       s40, s29, #256
    s.addi       s42, s29, #320
    s.addi       s43, s29, #384
    v.mov        v56, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s33, #0]
    s.addi       s33, s29, #448
    v.mov        v57, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s38, #0]
    s.addi       s38, s30, #64
    v.mov        v58, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s39, #0]
    s.addi       s39, s30, #128
    v.mov        v59, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s40, #0]
    s.addi       s40, s30, #192
    v.mov        v60, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s42, #0]
    s.addi       s42, s30, #256
    v.mov        v61, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s43, #0]
    s.addi       s43, s30, #320
    v.mov        v62, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s33, #0]
    s.addi       s33, s30, #384
    v.mov        v63, v0                         // hand off through the shared window (sec 7.3)
    mb.arm       s44, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s44
    mb.wait      s44
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v0, [s30, #0]
    v.mov        v56, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s38, #0]
    s.addi       s38, s30, #448
    v.mov        v57, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s39, #0]
    v.extract    s39, v7, #2
    v.mov        v58, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s40, #0]
    v.mov        v59, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s42, #0]
    v.mov        v60, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s43, #0]
    v.mov        v61, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s33, #0]
    v.mov        v62, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s38, #0]
    v.mov        v63, v0                         // hand off through the shared window (sec 7.3)
    mb.arm       s33, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s33
    mb.wait      s33
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s39, x8dot_done_31
    s.add        s38, s4, s20
    s.addi       s40, s32, #0
    s.addi       s32, s38, #96
    s.addi       s38, s34, #256
x8dot_row_32:
    s.addi       s42, s28, #-96
    v.movi       v0, #0
    s.sub        s43, s42, s40
    s.add        s42, s32, s40
    v.splat      v13, s43
    s.shli       s43, s40, #4
    s.addi       s45, s40, #1
    v.cmp.gt     p1, v13, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v0, [s42, v18]             // index is in elements (ISA sec 9.1)
    s.add        s42, s38, s43
    s.movz       s43, #32
    v.st.b       [s42, #0], v0
    fence.acq_rel.device
    s.mov        s40, s45
    s.cmp.lt     s42, s40, s43
    br.nz        s42, x8dot_row_32
x8dot_done_31:
    v.splat      v0, s39
    v.movi       v13, #0
    mb.arm       s32, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s38, #0
    v.extract    s39, v8, #2
    s.movz       s40, #96
    v.cmp.ne     p1, v0, v13
    v.cmp.eq     p2, v0, v13
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s42, s32            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s42, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s42, s32          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s32
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v0, [s29, #0]
    s.addi       s39, s29, #64
    s.addi       s40, s29, #128
    s.addi       s42, s29, #192
    s.addi       s43, s29, #256
    s.addi       s45, s29, #320
    s.addi       s46, s29, #384
    v.mov        v56, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s39, #0]
    s.addi       s39, s29, #448
    v.mov        v57, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s40, #0]
    s.addi       s40, s30, #64
    v.mov        v58, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s42, #0]
    s.addi       s42, s30, #128
    v.mov        v59, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s43, #0]
    s.addi       s43, s30, #192
    v.mov        v60, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s45, #0]
    s.addi       s45, s30, #256
    v.mov        v61, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s46, #0]
    s.addi       s46, s30, #320
    v.mov        v62, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s39, #0]
    s.addi       s39, s30, #384
    v.mov        v63, v0                         // hand off through the shared window (sec 7.3)
    mb.arm       s47, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a10, v56, v48, s47
    mb.wait      s47
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v0, [s30, #0]
    v.mov        v56, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s40, #0]
    s.addi       s40, s30, #448
    v.mov        v57, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s42, #0]
    v.extract    s42, v7, #3
    v.mov        v58, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s43, #0]
    v.mov        v59, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s45, #0]
    v.mov        v60, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s46, #0]
    v.mov        v61, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s39, #0]
    v.mov        v62, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s40, #0]
    v.mov        v63, v0                         // hand off through the shared window (sec 7.3)
    mb.arm       s39, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a14, v56, v48, s39
    mb.wait      s39
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s42, x8dot_done_33
    s.add        s40, s4, s20
    s.addi       s43, s38, #0
    s.addi       s38, s40, #96
    s.addi       s40, s34, #256
x8dot_row_34:
    s.addi       s45, s28, #-96
    v.movi       v0, #0
    s.sub        s46, s45, s43
    s.add        s45, s38, s43
    v.splat      v7, s46
    s.shli       s46, s43, #4
    s.addi       s48, s43, #1
    v.cmp.gt     p1, v7, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v0, [s45, v9]              // index is in elements (ISA sec 9.1)
    s.add        s45, s40, s46
    s.movz       s46, #32
    v.st.b       [s45, #0], v0
    fence.acq_rel.device
    s.mov        s43, s48
    s.cmp.lt     s45, s43, s46
    br.nz        s45, x8dot_row_34
x8dot_done_33:
    v.splat      v0, s42
    v.movi       v7, #0
    mb.arm       s28, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s38, #0
    v.extract    s40, v8, #3
    s.movz       s42, #96
    v.cmp.ne     p1, v0, v7
    v.cmp.eq     p2, v0, v7
    s.mov        s45, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s45, s28            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s45, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s45, s28          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s28
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v0, [s29, #0]
    s.addi       s40, s29, #64
    s.addi       s42, s29, #128
    s.addi       s43, s29, #192
    s.addi       s45, s29, #256
    s.addi       s46, s29, #320
    s.addi       s48, s29, #384
    s.addi       s49, s29, #448
    s.addi       s29, s30, #64
    s.addi       s50, s30, #128
    s.addi       s51, s30, #192
    s.addi       s52, s30, #256
    s.addi       s53, s30, #320
    s.addi       s54, s30, #384
    s.addi       s55, s30, #448
    v.mov        v56, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s40, #0]
    v.mov        v57, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s42, #0]
    s.addi       s40, s34, #5120
    v.mov        v58, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s43, #0]
    s.movz       s42, #1
    s.addi       s43, s40, #64
    v.mov        v59, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s45, #0]
    s.addi       s45, s40, #128
    v.mov        v60, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s46, #0]
    s.movz       s46, #2
    v.mov        v61, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s48, #0]
    s.movz       s48, #3
    s.addi       s56, s40, #192
    v.mov        v62, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s49, #0]
    s.movz       s49, #4
    s.addi       s57, s40, #256
    v.mov        v63, v0                         // hand off through the shared window (sec 7.3)
    mb.arm       s58, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s58
    mb.wait      s58
    w.def        w1, #56, #8                     // v56..v63
    v.ld.w       v0, [s30, #0]
    s.movz       s30, #5
    s.addi       s59, s40, #320
    v.mov        v56, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s29, #0]
    s.movz       s29, #6
    v.mov        v57, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s50, #0]
    s.addi       s50, s40, #384
    v.mov        v58, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s51, #0]
    s.movz       s51, #7
    v.mov        v59, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s52, #0]
    s.addi       s52, s40, #448
    v.mov        v60, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s53, #0]
    s.movz       s53, #8
    v.mov        v61, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s40, #512
    v.mov        v62, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s55, #0]
    s.movz       s55, #9
    v.mov        v63, v0                         // hand off through the shared window (sec 7.3)
    mb.arm       s60, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s60
    mb.wait      s60
    a.vread      v0, a8, s38
    s.addi       s38, s40, #576
    v.st.w       [s40, #0], v0
    a.vread      v0, a8, s42
    s.movz       s42, #10
    v.st.w       [s43, #0], v0
    a.vread      v0, a8, s46
    s.addi       s43, s40, #640
    s.movz       s46, #11
    v.st.w       [s45, #0], v0
    a.vread      v0, a8, s48
    s.addi       s45, s40, #704
    s.movz       s48, #12
    v.st.w       [s56, #0], v0
    a.vread      v0, a8, s49
    s.addi       s49, s40, #768
    s.movz       s56, #13
    v.st.w       [s57, #0], v0
    a.vread      v0, a8, s30
    s.addi       s30, s40, #832
    s.movz       s57, #14
    v.st.w       [s59, #0], v0
    a.vread      v0, a8, s29
    s.addi       s29, s40, #896
    s.movz       s59, #15
    s.addi       s21, s40, #960
    v.st.w       [s50, #0], v0
    a.vread      v0, a8, s51
    s.movz       s22, #0
    s.addi       s23, s34, #6144
    v.st.w       [s52, #0], v0
    a.vread      v0, a8, s53
    s.movz       s24, #1
    s.addi       s25, s23, #64
    v.st.w       [s54, #0], v0
    a.vread      v0, a8, s55
    s.movz       s26, #2
    s.addi       s27, s23, #128
    v.st.w       [s38, #0], v0
    a.vread      v0, a8, s42
    s.movz       s28, #3
    s.addi       s31, s23, #192
    v.st.w       [s43, #0], v0
    a.vread      v0, a8, s46
    s.movz       s32, #4
    s.addi       s33, s23, #256
    v.st.w       [s45, #0], v0
    a.vread      v0, a8, s48
    s.movz       s35, #5
    s.addi       s36, s23, #320
    v.st.w       [s49, #0], v0
    a.vread      v0, a8, s56
    s.movz       s37, #6
    s.addi       s38, s23, #384
    v.st.w       [s30, #0], v0
    a.vread      v0, a8, s57
    s.movz       s30, #7
    s.addi       s39, s23, #448
    v.st.w       [s29, #0], v0
    a.vread      v0, a8, s59
    s.movz       s29, #8
    s.addi       s40, s23, #512
    v.st.w       [s21, #0], v0
    fence.acq_rel.device
    a.vread      v0, a9, s22
    s.movz       s21, #9
    s.addi       s22, s23, #576
    v.st.w       [s23, #0], v0
    a.vread      v0, a9, s24
    s.movz       s24, #10
    v.st.w       [s25, #0], v0
    a.vread      v0, a9, s26
    s.addi       s25, s23, #640
    s.movz       s26, #11
    v.st.w       [s27, #0], v0
    a.vread      v0, a9, s28
    s.addi       s27, s23, #704
    s.movz       s28, #12
    v.st.w       [s31, #0], v0
    a.vread      v0, a9, s32
    s.addi       s31, s23, #768
    s.movz       s32, #13
    v.st.w       [s33, #0], v0
    a.vread      v0, a9, s35
    s.addi       s33, s23, #832
    s.movz       s35, #14
    v.st.w       [s36, #0], v0
    a.vread      v0, a9, s37
    s.addi       s36, s23, #896
    s.movz       s37, #15
    s.addi       s41, s23, #960
    v.st.w       [s38, #0], v0
    a.vread      v0, a9, s30
    s.movz       s23, #0
    s.addi       s30, s34, #7168
    v.st.w       [s39, #0], v0
    a.vread      v0, a9, s29
    s.movz       s29, #1
    s.addi       s38, s30, #64
    v.st.w       [s40, #0], v0
    a.vread      v0, a9, s21
    s.movz       s21, #2
    s.addi       s39, s30, #128
    v.st.w       [s22, #0], v0
    a.vread      v0, a9, s24
    s.movz       s22, #3
    s.addi       s24, s30, #192
    v.st.w       [s25, #0], v0
    a.vread      v0, a9, s26
    s.movz       s25, #4
    s.addi       s26, s30, #256
    v.st.w       [s27, #0], v0
    a.vread      v0, a9, s28
    s.movz       s27, #5
    s.addi       s28, s30, #320
    v.st.w       [s31, #0], v0
    a.vread      v0, a9, s32
    s.movz       s31, #6
    s.addi       s32, s30, #384
    v.st.w       [s33, #0], v0
    a.vread      v0, a9, s35
    s.movz       s33, #7
    s.addi       s35, s30, #448
    v.st.w       [s36, #0], v0
    a.vread      v0, a9, s37
    s.movz       s36, #8
    s.addi       s37, s30, #512
    v.st.w       [s41, #0], v0
    fence.acq_rel.device
    a.vread      v0, a10, s23
    s.movz       s23, #9
    s.addi       s40, s30, #576
    v.st.w       [s30, #0], v0
    a.vread      v0, a10, s29
    s.movz       s29, #10
    v.st.w       [s38, #0], v0
    a.vread      v0, a10, s21
    s.addi       s21, s30, #640
    s.movz       s38, #11
    v.st.w       [s39, #0], v0
    a.vread      v0, a10, s22
    s.addi       s22, s30, #704
    s.movz       s39, #12
    v.st.w       [s24, #0], v0
    a.vread      v0, a10, s25
    s.addi       s24, s30, #768
    s.movz       s25, #13
    v.st.w       [s26, #0], v0
    a.vread      v0, a10, s27
    s.addi       s26, s30, #832
    s.movz       s27, #14
    v.st.w       [s28, #0], v0
    a.vread      v0, a10, s31
    s.addi       s28, s30, #896
    s.movz       s31, #15
    s.addi       s41, s30, #960
    v.st.w       [s32, #0], v0
    a.vread      v0, a10, s33
    s.movz       s30, #0
    s.addi       s32, s34, #8192
    v.st.w       [s35, #0], v0
    a.vread      v0, a10, s36
    s.movz       s33, #1
    s.addi       s35, s32, #64
    v.st.w       [s37, #0], v0
    a.vread      v0, a10, s23
    s.movz       s23, #2
    s.addi       s36, s32, #128
    v.st.w       [s40, #0], v0
    a.vread      v0, a10, s29
    s.movz       s29, #3
    s.addi       s37, s32, #192
    v.st.w       [s21, #0], v0
    a.vread      v0, a10, s38
    s.movz       s21, #4
    s.addi       s38, s32, #256
    v.st.w       [s22, #0], v0
    a.vread      v0, a10, s39
    s.movz       s22, #5
    s.addi       s39, s32, #320
    v.st.w       [s24, #0], v0
    a.vread      v0, a10, s25
    s.movz       s24, #6
    s.addi       s25, s32, #384
    v.st.w       [s26, #0], v0
    a.vread      v0, a10, s27
    s.movz       s26, #7
    s.addi       s27, s32, #448
    v.st.w       [s28, #0], v0
    a.vread      v0, a10, s31
    s.movz       s28, #8
    s.addi       s31, s32, #512
    v.st.w       [s41, #0], v0
    fence.acq_rel.device
    a.vread      v0, a11, s30
    s.movz       s30, #9
    s.addi       s40, s32, #576
    v.st.w       [s32, #0], v0
    a.vread      v0, a11, s33
    s.movz       s33, #10
    v.st.w       [s35, #0], v0
    a.vread      v0, a11, s23
    s.addi       s23, s32, #640
    s.movz       s35, #11
    v.st.w       [s36, #0], v0
    a.vread      v0, a11, s29
    s.addi       s29, s32, #704
    s.movz       s36, #12
    v.st.w       [s37, #0], v0
    a.vread      v0, a11, s21
    s.addi       s21, s32, #768
    s.movz       s37, #13
    v.st.w       [s38, #0], v0
    a.vread      v0, a11, s22
    s.addi       s22, s32, #832
    s.movz       s38, #14
    v.st.w       [s39, #0], v0
    a.vread      v0, a11, s24
    s.addi       s24, s32, #896
    s.movz       s39, #15
    s.addi       s41, s32, #960
    v.st.w       [s25, #0], v0
    a.vread      v0, a11, s26
    s.movz       s25, #0
    s.addi       s26, s34, #9216
    v.st.w       [s27, #0], v0
    a.vread      v0, a11, s28
    s.movz       s27, #1
    s.addi       s28, s26, #64
    v.st.w       [s31, #0], v0
    a.vread      v0, a11, s30
    s.movz       s30, #2
    s.addi       s31, s26, #128
    v.st.w       [s40, #0], v0
    a.vread      v0, a11, s33
    s.movz       s32, #3
    s.addi       s33, s26, #192
    v.st.w       [s23, #0], v0
    a.vread      v0, a11, s35
    s.movz       s23, #4
    s.addi       s35, s26, #256
    v.st.w       [s29, #0], v0
    a.vread      v0, a11, s36
    s.movz       s29, #5
    s.addi       s36, s26, #320
    v.st.w       [s21, #0], v0
    a.vread      v0, a11, s37
    s.movz       s21, #6
    s.addi       s37, s26, #384
    v.st.w       [s22, #0], v0
    a.vread      v0, a11, s38
    s.movz       s22, #7
    s.addi       s38, s26, #448
    v.st.w       [s24, #0], v0
    a.vread      v0, a11, s39
    s.movz       s24, #8
    s.addi       s39, s26, #512
    v.st.w       [s41, #0], v0
    fence.acq_rel.device
    a.vread      v0, a12, s25
    s.movz       s25, #9
    s.addi       s40, s26, #576
    v.st.w       [s26, #0], v0
    a.vread      v0, a12, s27
    s.movz       s27, #10
    v.st.w       [s28, #0], v0
    a.vread      v0, a12, s30
    s.addi       s28, s26, #640
    s.movz       s30, #11
    v.st.w       [s31, #0], v0
    a.vread      v0, a12, s32
    s.addi       s31, s26, #704
    s.movz       s32, #12
    v.st.w       [s33, #0], v0
    a.vread      v0, a12, s23
    s.addi       s23, s26, #768
    s.movz       s33, #13
    v.st.w       [s35, #0], v0
    a.vread      v0, a12, s29
    s.addi       s29, s26, #832
    s.movz       s35, #14
    v.st.w       [s36, #0], v0
    a.vread      v0, a12, s21
    s.addi       s21, s26, #896
    s.movz       s36, #15
    s.addi       s41, s26, #960
    v.st.w       [s37, #0], v0
    a.vread      v0, a12, s22
    s.movz       s22, #0
    s.addi       s26, s34, #10240
    v.st.w       [s38, #0], v0
    a.vread      v0, a12, s24
    s.movz       s24, #1
    s.addi       s37, s26, #64
    v.st.w       [s39, #0], v0
    a.vread      v0, a12, s25
    s.movz       s25, #2
    s.addi       s38, s26, #128
    v.st.w       [s40, #0], v0
    a.vread      v0, a12, s27
    s.movz       s27, #3
    s.addi       s39, s26, #192
    v.st.w       [s28, #0], v0
    a.vread      v0, a12, s30
    s.movz       s28, #4
    s.addi       s30, s26, #256
    v.st.w       [s31, #0], v0
    a.vread      v0, a12, s32
    s.movz       s31, #5
    s.addi       s32, s26, #320
    v.st.w       [s23, #0], v0
    a.vread      v0, a12, s33
    s.movz       s23, #6
    s.addi       s33, s26, #384
    v.st.w       [s29, #0], v0
    a.vread      v0, a12, s35
    s.movz       s29, #7
    s.addi       s35, s26, #448
    v.st.w       [s21, #0], v0
    a.vread      v0, a12, s36
    s.movz       s21, #8
    s.addi       s36, s26, #512
    v.st.w       [s41, #0], v0
    fence.acq_rel.device
    a.vread      v0, a13, s22
    s.movz       s22, #9
    s.addi       s40, s26, #576
    v.st.w       [s26, #0], v0
    a.vread      v0, a13, s24
    s.movz       s24, #10
    v.st.w       [s37, #0], v0
    a.vread      v0, a13, s25
    s.addi       s25, s26, #640
    s.movz       s37, #11
    v.st.w       [s38, #0], v0
    a.vread      v0, a13, s27
    s.addi       s27, s26, #704
    s.movz       s38, #12
    v.st.w       [s39, #0], v0
    a.vread      v0, a13, s28
    s.addi       s28, s26, #768
    s.movz       s39, #13
    v.st.w       [s30, #0], v0
    a.vread      v0, a13, s31
    s.addi       s30, s26, #832
    s.movz       s31, #14
    v.st.w       [s32, #0], v0
    a.vread      v0, a13, s23
    s.addi       s23, s26, #896
    s.movz       s32, #15
    s.addi       s41, s26, #960
    v.st.w       [s33, #0], v0
    a.vread      v0, a13, s29
    s.movz       s26, #0
    s.addi       s29, s34, #11264
    v.st.w       [s35, #0], v0
    a.vread      v0, a13, s21
    s.movz       s21, #1
    s.addi       s33, s29, #64
    v.st.w       [s36, #0], v0
    a.vread      v0, a13, s22
    s.movz       s22, #2
    s.addi       s35, s29, #128
    v.st.w       [s40, #0], v0
    a.vread      v0, a13, s24
    s.movz       s24, #3
    s.addi       s36, s29, #192
    v.st.w       [s25, #0], v0
    a.vread      v0, a13, s37
    s.movz       s25, #4
    s.addi       s37, s29, #256
    v.st.w       [s27, #0], v0
    a.vread      v0, a13, s38
    s.movz       s27, #5
    s.addi       s38, s29, #320
    v.st.w       [s28, #0], v0
    a.vread      v0, a13, s39
    s.movz       s28, #6
    s.addi       s39, s29, #384
    v.st.w       [s30, #0], v0
    a.vread      v0, a13, s31
    s.movz       s30, #7
    s.addi       s31, s29, #448
    v.st.w       [s23, #0], v0
    a.vread      v0, a13, s32
    s.movz       s23, #8
    s.addi       s32, s29, #512
    v.st.w       [s41, #0], v0
    fence.acq_rel.device
    a.vread      v0, a14, s26
    s.movz       s26, #9
    s.addi       s40, s29, #576
    v.st.w       [s29, #0], v0
    a.vread      v0, a14, s21
    s.movz       s21, #10
    v.st.w       [s33, #0], v0
    a.vread      v0, a14, s22
    s.addi       s22, s29, #640
    s.movz       s33, #11
    v.st.w       [s35, #0], v0
    a.vread      v0, a14, s24
    s.addi       s24, s29, #704
    s.movz       s35, #12
    v.st.w       [s36, #0], v0
    a.vread      v0, a14, s25
    s.addi       s25, s29, #768
    s.movz       s36, #13
    v.st.w       [s37, #0], v0
    a.vread      v0, a14, s27
    s.addi       s27, s29, #832
    s.movz       s37, #14
    v.st.w       [s38, #0], v0
    a.vread      v0, a14, s28
    s.addi       s28, s29, #896
    s.movz       s38, #15
    s.addi       s41, s29, #960
    v.st.w       [s39, #0], v0
    a.vread      v0, a14, s30
    s.movz       s29, #0
    s.addi       s30, s34, #12288
    v.st.w       [s31, #0], v0
    a.vread      v0, a14, s23
    s.movz       s23, #1
    s.addi       s31, s30, #64
    v.st.w       [s32, #0], v0
    a.vread      v0, a14, s26
    s.movz       s26, #2
    s.addi       s32, s30, #128
    v.st.w       [s40, #0], v0
    a.vread      v0, a14, s21
    s.movz       s21, #3
    s.addi       s39, s30, #192
    v.st.w       [s22, #0], v0
    a.vread      v0, a14, s33
    s.movz       s22, #4
    s.addi       s33, s30, #256
    v.st.w       [s24, #0], v0
    a.vread      v0, a14, s35
    s.movz       s24, #5
    s.addi       s35, s30, #320
    v.st.w       [s25, #0], v0
    a.vread      v0, a14, s36
    s.movz       s25, #6
    s.addi       s36, s30, #384
    v.st.w       [s27, #0], v0
    a.vread      v0, a14, s37
    s.movz       s27, #7
    s.addi       s37, s30, #448
    v.st.w       [s28, #0], v0
    a.vread      v0, a14, s38
    s.movz       s28, #8
    s.addi       s38, s30, #512
    v.st.w       [s41, #0], v0
    fence.acq_rel.device
    a.vread      v0, a15, s29
    s.movz       s29, #9
    s.addi       s40, s30, #576
    v.st.w       [s30, #0], v0
    a.vread      v0, a15, s23
    s.movz       s23, #10
    v.st.w       [s31, #0], v0
    a.vread      v0, a15, s26
    s.addi       s26, s30, #640
    s.movz       s31, #11
    v.st.w       [s32, #0], v0
    a.vread      v0, a15, s21
    s.addi       s21, s30, #704
    s.movz       s32, #12
    v.st.w       [s39, #0], v0
    a.vread      v0, a15, s22
    s.addi       s22, s30, #768
    s.movz       s39, #13
    v.st.w       [s33, #0], v0
    a.vread      v0, a15, s24
    s.addi       s24, s30, #832
    s.movz       s33, #14
    v.st.w       [s35, #0], v0
    a.vread      v0, a15, s25
    s.addi       s25, s30, #896
    s.movz       s35, #15
    s.addi       s41, s30, #960
    v.st.w       [s36, #0], v0
    a.vread      v0, a15, s27
    s.movz       s27, #0
    s.addi       s30, s34, #5120
    v.st.w       [s37, #0], v0
    a.vread      v0, a15, s28
    v.extract    s28, v12, #0
    s.addi       s36, s34, #13312
    v.splat      v7, s28
    s.movz       s28, #1
    v.st.w       [s38, #0], v0
    a.vread      v0, a15, s29
    s.addi       s29, s34, #5184
    v.extract    s37, v12, #1
    v.splat      v8, s37
    s.addi       s37, s36, #64
    v.st.w       [s40, #0], v0
    a.vread      v0, a15, s23
    s.movz       s23, #2
    s.addi       s38, s34, #5248
    v.st.w       [s26, #0], v0
    a.vread      v0, a15, s31
    v.extract    s26, v12, #2
    s.addi       s31, s36, #128
    v.splat      v9, s26
    v.st.w       [s21, #0], v0
    a.vread      v0, a15, s32
    s.addi       s21, s36, #192
    v.st.w       [s22, #0], v0
    a.vread      v0, a15, s39
    s.movz       s22, #3
    s.addi       s26, s34, #5312
    v.st.w       [s24, #0], v0
    a.vread      v0, a15, s33
    v.extract    s24, v12, #3
    v.splat      v13, s24
    v.st.w       [s25, #0], v0
    a.vread      v0, a15, s35
    s.movz       s24, #4
    s.addi       s25, s36, #256
    v.st.w       [s41, #0], v0
    fence.acq_rel.device
    a.vread      v0, a0, s27
    s.addi       s27, s34, #5376
    v.extract    s32, v12, #4
    v.splat      v14, s32
    v.ld.w       v18, [s30, #0]
    vf.mul       v23, v18, v7
    s.addi       s30, s36, #320
    vf.mul       v7, v23, v19
    s.movz       s32, #5
    vf.add       v18, v0, v7
    v.st.w       [s36, #0], v18
    a.vread      v0, a0, s28
    s.addi       s28, s34, #5440
    v.extract    s33, v12, #5
    v.splat      v7, s33
    v.ld.w       v18, [s29, #0]
    vf.mul       v23, v18, v8
    s.addi       s29, s36, #384
    vf.mul       v8, v23, v19
    s.movz       s33, #6
    vf.add       v18, v0, v8
    v.st.w       [s37, #0], v18
    a.vread      v0, a0, s23
    s.addi       s23, s34, #5504
    v.extract    s35, v12, #6
    v.splat      v8, s35
    v.ld.w       v18, [s38, #0]
    vf.mul       v23, v18, v9
    s.addi       s35, s36, #448
    vf.mul       v9, v23, v19
    s.movz       s37, #7
    vf.add       v18, v0, v9
    v.st.w       [s31, #0], v18
    a.vread      v0, a0, s22
    s.addi       s22, s34, #5568
    v.extract    s31, v12, #7
    v.splat      v9, s31
    v.ld.w       v18, [s26, #0]
    vf.mul       v23, v18, v13
    s.addi       s26, s36, #512
    vf.mul       v13, v23, v19
    s.movz       s31, #8
    vf.add       v18, v0, v13
    v.st.w       [s21, #0], v18
    a.vread      v0, a0, s24
    s.addi       s21, s34, #5632
    v.extract    s24, v12, #8
    v.splat      v13, s24
    v.ld.w       v18, [s27, #0]
    vf.mul       v23, v18, v14
    s.addi       s24, s36, #576
    vf.mul       v14, v23, v19
    s.movz       s27, #9
    vf.add       v18, v0, v14
    v.st.w       [s25, #0], v18
    a.vread      v0, a0, s32
    s.addi       s25, s34, #5696
    v.extract    s32, v12, #9
    v.splat      v14, s32
    v.ld.w       v18, [s28, #0]
    vf.mul       v23, v18, v7
    s.addi       s28, s36, #640
    vf.mul       v7, v23, v19
    s.movz       s32, #10
    vf.add       v18, v0, v7
    v.st.w       [s30, #0], v18
    a.vread      v0, a0, s33
    s.addi       s30, s34, #5760
    v.extract    s33, v12, #10
    v.splat      v7, s33
    v.ld.w       v18, [s23, #0]
    vf.mul       v23, v18, v8
    s.addi       s23, s36, #704
    vf.mul       v8, v23, v19
    s.movz       s33, #11
    vf.add       v18, v0, v8
    v.st.w       [s29, #0], v18
    a.vread      v0, a0, s37
    s.addi       s29, s34, #5824
    v.extract    s37, v12, #11
    v.splat      v8, s37
    v.ld.w       v18, [s22, #0]
    vf.mul       v23, v18, v9
    s.addi       s22, s36, #768
    vf.mul       v9, v23, v19
    s.movz       s37, #12
    vf.add       v18, v0, v9
    v.st.w       [s35, #0], v18
    a.vread      v0, a0, s31
    s.addi       s31, s34, #5888
    v.extract    s35, v12, #12
    v.splat      v9, s35
    v.ld.w       v18, [s21, #0]
    vf.mul       v23, v18, v13
    s.addi       s21, s36, #832
    vf.mul       v13, v23, v19
    s.movz       s35, #13
    vf.add       v18, v0, v13
    v.st.w       [s26, #0], v18
    a.vread      v0, a0, s27
    s.addi       s26, s34, #5952
    v.extract    s27, v12, #13
    v.splat      v13, s27
    v.ld.w       v18, [s25, #0]
    vf.mul       v23, v18, v14
    s.addi       s25, s36, #896
    vf.mul       v14, v23, v19
    s.movz       s27, #14
    vf.add       v18, v0, v14
    v.st.w       [s24, #0], v18
    a.vread      v0, a0, s32
    s.addi       s24, s34, #6016
    v.extract    s32, v12, #14
    v.splat      v14, s32
    v.ld.w       v18, [s30, #0]
    vf.mul       v23, v18, v7
    s.addi       s30, s36, #960
    vf.mul       v7, v23, v19
    s.movz       s32, #15
    vf.add       v18, v0, v7
    v.st.w       [s28, #0], v18
    a.vread      v0, a0, s33
    s.addi       s28, s34, #6080
    v.extract    s33, v12, #15
    v.splat      v7, s33
    v.ld.w       v18, [s29, #0]
    vf.mul       v23, v18, v8
    vf.mul       v8, v23, v19
    s.addi       s29, s34, #14336
    vf.add       v18, v0, v8
    s.movz       s33, #0
    v.st.w       [s23, #0], v18
    a.vread      v0, a0, s37
    s.addi       s23, s34, #6144
    v.extract    s36, v12, #0
    v.splat      v8, s36
    v.ld.w       v18, [s31, #0]
    vf.mul       v23, v18, v9
    vf.mul       v9, v23, v19
    s.addi       s31, s29, #64
    vf.add       v18, v0, v9
    s.movz       s36, #1
    v.st.w       [s22, #0], v18
    a.vread      v0, a0, s35
    s.addi       s22, s34, #6208
    v.extract    s35, v12, #1
    v.splat      v9, s35
    v.ld.w       v18, [s26, #0]
    vf.mul       v23, v18, v13
    vf.mul       v13, v23, v19
    s.addi       s26, s29, #128
    vf.add       v18, v0, v13
    s.movz       s35, #2
    v.st.w       [s21, #0], v18
    a.vread      v0, a0, s27
    s.addi       s21, s34, #6272
    v.extract    s27, v12, #2
    v.splat      v13, s27
    v.ld.w       v18, [s24, #0]
    vf.mul       v23, v18, v14
    vf.mul       v14, v23, v19
    s.addi       s24, s29, #192
    vf.add       v18, v0, v14
    s.movz       s27, #3
    v.st.w       [s25, #0], v18
    a.vread      v0, a0, s32
    s.addi       s25, s34, #6336
    v.extract    s32, v12, #3
    v.splat      v14, s32
    v.ld.w       v18, [s28, #0]
    vf.mul       v23, v18, v7
    vf.mul       v7, v23, v19
    s.addi       s28, s29, #256
    vf.add       v18, v0, v7
    s.movz       s32, #4
    v.st.w       [s30, #0], v18
    fence.acq_rel.device
    a.vread      v0, a1, s33
    s.addi       s30, s34, #6400
    v.extract    s33, v12, #4
    v.splat      v7, s33
    v.ld.w       v18, [s23, #0]
    vf.mul       v23, v18, v8
    s.addi       s23, s29, #320
    vf.mul       v8, v23, v20
    s.movz       s33, #5
    vf.add       v18, v0, v8
    v.st.w       [s29, #0], v18
    a.vread      v0, a1, s36
    s.addi       s36, s34, #6464
    v.extract    s37, v12, #5
    v.splat      v8, s37
    v.ld.w       v18, [s22, #0]
    vf.mul       v23, v18, v9
    s.addi       s22, s29, #384
    vf.mul       v9, v23, v20
    s.movz       s37, #6
    vf.add       v18, v0, v9
    v.st.w       [s31, #0], v18
    a.vread      v0, a1, s35
    s.addi       s31, s34, #6528
    v.extract    s35, v12, #6
    v.splat      v9, s35
    v.ld.w       v18, [s21, #0]
    vf.mul       v23, v18, v13
    s.addi       s21, s29, #448
    vf.mul       v13, v23, v20
    s.movz       s35, #7
    vf.add       v18, v0, v13
    v.st.w       [s26, #0], v18
    a.vread      v0, a1, s27
    s.addi       s26, s34, #6592
    v.extract    s27, v12, #7
    v.splat      v13, s27
    v.ld.w       v18, [s25, #0]
    vf.mul       v23, v18, v14
    s.addi       s25, s29, #512
    vf.mul       v14, v23, v20
    s.movz       s27, #8
    vf.add       v18, v0, v14
    v.st.w       [s24, #0], v18
    a.vread      v0, a1, s32
    s.addi       s24, s34, #6656
    v.extract    s32, v12, #8
    v.splat      v14, s32
    v.ld.w       v18, [s30, #0]
    vf.mul       v23, v18, v7
    s.addi       s30, s29, #576
    vf.mul       v7, v23, v20
    s.movz       s32, #9
    vf.add       v18, v0, v7
    v.st.w       [s28, #0], v18
    a.vread      v0, a1, s33
    s.addi       s28, s34, #6720
    v.extract    s33, v12, #9
    v.splat      v7, s33
    v.ld.w       v18, [s36, #0]
    vf.mul       v23, v18, v8
    s.addi       s33, s29, #640
    vf.mul       v8, v23, v20
    s.movz       s36, #10
    vf.add       v18, v0, v8
    v.st.w       [s23, #0], v18
    a.vread      v0, a1, s37
    s.addi       s23, s34, #6784
    v.extract    s37, v12, #10
    v.splat      v8, s37
    v.ld.w       v18, [s31, #0]
    vf.mul       v23, v18, v9
    s.addi       s31, s29, #704
    vf.mul       v9, v23, v20
    s.movz       s37, #11
    vf.add       v18, v0, v9
    v.st.w       [s22, #0], v18
    a.vread      v0, a1, s35
    s.addi       s22, s34, #6848
    v.extract    s35, v12, #11
    v.splat      v9, s35
    v.ld.w       v18, [s26, #0]
    vf.mul       v23, v18, v13
    s.addi       s26, s29, #768
    vf.mul       v13, v23, v20
    s.movz       s35, #12
    vf.add       v18, v0, v13
    v.st.w       [s21, #0], v18
    a.vread      v0, a1, s27
    s.addi       s21, s34, #6912
    v.extract    s27, v12, #12
    v.splat      v13, s27
    v.ld.w       v18, [s24, #0]
    vf.mul       v23, v18, v14
    s.addi       s24, s29, #832
    vf.mul       v14, v23, v20
    s.movz       s27, #13
    vf.add       v18, v0, v14
    v.st.w       [s25, #0], v18
    a.vread      v0, a1, s32
    s.addi       s25, s34, #6976
    v.extract    s32, v12, #13
    v.splat      v14, s32
    v.ld.w       v18, [s28, #0]
    vf.mul       v23, v18, v7
    s.addi       s28, s29, #896
    vf.mul       v7, v23, v20
    s.movz       s32, #14
    vf.add       v18, v0, v7
    v.st.w       [s30, #0], v18
    a.vread      v0, a1, s36
    s.addi       s30, s34, #7040
    v.extract    s36, v12, #14
    v.splat      v7, s36
    v.ld.w       v18, [s23, #0]
    vf.mul       v23, v18, v8
    s.addi       s23, s29, #960
    vf.mul       v8, v23, v20
    s.movz       s29, #15
    vf.add       v18, v0, v8
    v.st.w       [s33, #0], v18
    a.vread      v0, a1, s37
    s.addi       s33, s34, #7104
    v.extract    s36, v12, #15
    v.splat      v8, s36
    v.ld.w       v18, [s22, #0]
    vf.mul       v23, v18, v9
    vf.mul       v9, v23, v20
    s.addi       s22, s34, #15360
    vf.add       v18, v0, v9
    s.movz       s36, #0
    v.st.w       [s31, #0], v18
    a.vread      v0, a1, s35
    s.addi       s31, s34, #7168
    v.extract    s35, v12, #0
    v.splat      v9, s35
    v.ld.w       v18, [s21, #0]
    vf.mul       v23, v18, v13
    vf.mul       v13, v23, v20
    s.addi       s21, s22, #64
    vf.add       v18, v0, v13
    s.movz       s35, #1
    v.st.w       [s26, #0], v18
    a.vread      v0, a1, s27
    s.addi       s26, s34, #7232
    v.extract    s27, v12, #1
    v.splat      v13, s27
    v.ld.w       v18, [s25, #0]
    vf.mul       v23, v18, v14
    vf.mul       v14, v23, v20
    s.addi       s25, s22, #128
    vf.add       v18, v0, v14
    s.movz       s27, #2
    v.st.w       [s24, #0], v18
    a.vread      v0, a1, s32
    s.addi       s24, s34, #7296
    v.extract    s32, v12, #2
    v.splat      v14, s32
    v.ld.w       v18, [s30, #0]
    vf.mul       v23, v18, v7
    vf.mul       v7, v23, v20
    s.addi       s30, s22, #192
    vf.add       v18, v0, v7
    s.movz       s32, #3
    v.st.w       [s28, #0], v18
    a.vread      v0, a1, s29
    s.addi       s28, s34, #7360
    v.extract    s29, v12, #3
    v.splat      v7, s29
    v.ld.w       v18, [s33, #0]
    vf.mul       v23, v18, v8
    vf.mul       v8, v23, v20
    s.addi       s29, s22, #256
    vf.add       v18, v0, v8
    s.movz       s33, #4
    v.st.w       [s23, #0], v18
    fence.acq_rel.device
    a.vread      v0, a2, s36
    s.addi       s23, s34, #7424
    v.extract    s36, v12, #4
    v.splat      v8, s36
    v.ld.w       v18, [s31, #0]
    vf.mul       v23, v18, v9
    s.addi       s31, s22, #320
    vf.mul       v9, v23, v21
    s.movz       s36, #5
    vf.add       v18, v0, v9
    v.st.w       [s22, #0], v18
    a.vread      v0, a2, s35
    s.addi       s35, s34, #7488
    v.extract    s37, v12, #5
    v.splat      v9, s37
    v.ld.w       v18, [s26, #0]
    vf.mul       v23, v18, v13
    s.addi       s26, s22, #384
    vf.mul       v13, v23, v21
    s.movz       s37, #6
    vf.add       v18, v0, v13
    v.st.w       [s21, #0], v18
    a.vread      v0, a2, s27
    s.addi       s21, s34, #7552
    v.extract    s27, v12, #6
    v.splat      v13, s27
    v.ld.w       v18, [s24, #0]
    vf.mul       v23, v18, v14
    s.addi       s24, s22, #448
    vf.mul       v14, v23, v21
    s.movz       s27, #7
    vf.add       v18, v0, v14
    v.st.w       [s25, #0], v18
    a.vread      v0, a2, s32
    s.addi       s25, s34, #7616
    v.extract    s32, v12, #7
    v.splat      v14, s32
    v.ld.w       v18, [s28, #0]
    vf.mul       v23, v18, v7
    s.addi       s28, s22, #512
    vf.mul       v7, v23, v21
    s.movz       s32, #8
    vf.add       v18, v0, v7
    v.st.w       [s30, #0], v18
    a.vread      v0, a2, s33
    s.addi       s30, s34, #7680
    v.extract    s33, v12, #8
    v.splat      v7, s33
    v.ld.w       v18, [s23, #0]
    vf.mul       v23, v18, v8
    s.addi       s23, s22, #576
    vf.mul       v8, v23, v21
    s.movz       s33, #9
    vf.add       v18, v0, v8
    v.st.w       [s29, #0], v18
    a.vread      v0, a2, s36
    s.addi       s29, s34, #7744
    v.extract    s36, v12, #9
    v.splat      v8, s36
    v.ld.w       v18, [s35, #0]
    vf.mul       v23, v18, v9
    s.addi       s35, s22, #640
    vf.mul       v9, v23, v21
    s.movz       s36, #10
    vf.add       v18, v0, v9
    v.st.w       [s31, #0], v18
    a.vread      v0, a2, s37
    s.addi       s31, s34, #7808
    v.extract    s37, v12, #10
    v.splat      v9, s37
    v.ld.w       v18, [s21, #0]
    vf.mul       v23, v18, v13
    s.addi       s21, s22, #704
    vf.mul       v13, v23, v21
    s.movz       s37, #11
    vf.add       v18, v0, v13
    v.st.w       [s26, #0], v18
    a.vread      v0, a2, s27
    s.addi       s26, s34, #7872
    v.extract    s27, v12, #11
    v.splat      v13, s27
    v.ld.w       v18, [s25, #0]
    vf.mul       v23, v18, v14
    s.addi       s25, s22, #768
    vf.mul       v14, v23, v21
    s.movz       s27, #12
    vf.add       v18, v0, v14
    v.st.w       [s24, #0], v18
    a.vread      v0, a2, s32
    s.addi       s24, s34, #7936
    v.extract    s32, v12, #12
    v.splat      v14, s32
    v.ld.w       v18, [s30, #0]
    vf.mul       v23, v18, v7
    s.addi       s30, s22, #832
    vf.mul       v7, v23, v21
    s.movz       s32, #13
    vf.add       v18, v0, v7
    v.st.w       [s28, #0], v18
    a.vread      v0, a2, s33
    s.addi       s28, s34, #8000
    v.extract    s33, v12, #13
    v.splat      v7, s33
    v.ld.w       v18, [s29, #0]
    vf.mul       v23, v18, v8
    s.addi       s29, s22, #896
    vf.mul       v8, v23, v21
    s.movz       s33, #14
    vf.add       v18, v0, v8
    v.st.w       [s23, #0], v18
    a.vread      v0, a2, s36
    s.addi       s23, s34, #8064
    v.extract    s36, v12, #14
    v.splat      v8, s36
    v.ld.w       v18, [s31, #0]
    vf.mul       v23, v18, v9
    s.addi       s31, s22, #960
    vf.mul       v9, v23, v21
    s.movz       s22, #15
    vf.add       v18, v0, v9
    v.st.w       [s35, #0], v18
    a.vread      v0, a2, s37
    s.addi       s35, s34, #8128
    v.extract    s36, v12, #15
    v.splat      v9, s36
    v.ld.w       v18, [s26, #0]
    vf.mul       v23, v18, v13
    vf.mul       v13, v23, v21
    s.addi       s26, s34, #16384
    vf.add       v18, v0, v13
    s.movz       s36, #0
    v.st.w       [s21, #0], v18
    a.vread      v0, a2, s27
    s.addi       s21, s34, #8192
    v.extract    s27, v12, #0
    v.splat      v13, s27
    v.ld.w       v18, [s24, #0]
    vf.mul       v23, v18, v14
    vf.mul       v14, v23, v21
    s.addi       s24, s26, #64
    vf.add       v18, v0, v14
    s.movz       s27, #1
    v.st.w       [s25, #0], v18
    a.vread      v0, a2, s32
    s.addi       s25, s34, #8256
    v.extract    s32, v12, #1
    v.splat      v14, s32
    v.ld.w       v18, [s28, #0]
    vf.mul       v23, v18, v7
    vf.mul       v7, v23, v21
    s.addi       s28, s26, #128
    vf.add       v18, v0, v7
    s.movz       s32, #2
    v.st.w       [s30, #0], v18
    a.vread      v0, a2, s33
    s.addi       s30, s34, #8320
    v.extract    s33, v12, #2
    v.splat      v7, s33
    v.ld.w       v18, [s23, #0]
    vf.mul       v23, v18, v8
    vf.mul       v8, v23, v21
    s.addi       s23, s26, #192
    vf.add       v18, v0, v8
    s.movz       s33, #3
    v.st.w       [s29, #0], v18
    a.vread      v0, a2, s22
    s.addi       s22, s34, #8384
    v.extract    s29, v12, #3
    v.splat      v8, s29
    v.ld.w       v18, [s35, #0]
    vf.mul       v23, v18, v9
    vf.mul       v9, v23, v21
    s.addi       s29, s26, #256
    vf.add       v18, v0, v9
    s.movz       s35, #4
    v.st.w       [s31, #0], v18
    fence.acq_rel.device
    a.vread      v0, a3, s36
    s.addi       s31, s34, #8448
    v.extract    s36, v12, #4
    v.splat      v9, s36
    v.ld.w       v18, [s21, #0]
    vf.mul       v23, v18, v13
    s.addi       s21, s26, #320
    vf.mul       v13, v23, v22
    s.movz       s36, #5
    vf.add       v18, v0, v13
    v.st.w       [s26, #0], v18
    a.vread      v0, a3, s27
    s.addi       s27, s34, #8512
    v.extract    s37, v12, #5
    v.splat      v13, s37
    v.ld.w       v18, [s25, #0]
    vf.mul       v23, v18, v14
    s.addi       s25, s26, #384
    vf.mul       v14, v23, v22
    s.movz       s37, #6
    vf.add       v18, v0, v14
    v.st.w       [s24, #0], v18
    a.vread      v0, a3, s32
    s.addi       s24, s34, #8576
    v.extract    s32, v12, #6
    v.splat      v14, s32
    v.ld.w       v18, [s30, #0]
    vf.mul       v23, v18, v7
    s.addi       s30, s26, #448
    vf.mul       v7, v23, v22
    s.movz       s32, #7
    vf.add       v18, v0, v7
    v.st.w       [s28, #0], v18
    a.vread      v0, a3, s33
    s.addi       s28, s34, #8640
    v.extract    s33, v12, #7
    v.splat      v7, s33
    v.ld.w       v18, [s22, #0]
    vf.mul       v23, v18, v8
    s.addi       s22, s26, #512
    vf.mul       v8, v23, v22
    s.movz       s33, #8
    vf.add       v18, v0, v8
    v.st.w       [s23, #0], v18
    a.vread      v0, a3, s35
    s.addi       s23, s34, #8704
    v.extract    s35, v12, #8
    v.splat      v8, s35
    v.ld.w       v18, [s31, #0]
    vf.mul       v23, v18, v9
    s.addi       s31, s26, #576
    vf.mul       v9, v23, v22
    s.movz       s35, #9
    vf.add       v18, v0, v9
    v.st.w       [s29, #0], v18
    a.vread      v0, a3, s36
    s.addi       s29, s34, #8768
    v.extract    s36, v12, #9
    v.splat      v9, s36
    v.ld.w       v18, [s27, #0]
    vf.mul       v23, v18, v13
    s.addi       s27, s26, #640
    vf.mul       v13, v23, v22
    s.movz       s36, #10
    vf.add       v18, v0, v13
    v.st.w       [s21, #0], v18
    a.vread      v0, a3, s37
    s.addi       s21, s34, #8832
    v.extract    s37, v12, #10
    v.splat      v13, s37
    v.ld.w       v18, [s24, #0]
    vf.mul       v23, v18, v14
    s.addi       s24, s26, #704
    vf.mul       v14, v23, v22
    s.movz       s37, #11
    vf.add       v18, v0, v14
    v.st.w       [s25, #0], v18
    a.vread      v0, a3, s32
    s.addi       s25, s34, #8896
    v.extract    s32, v12, #11
    v.splat      v14, s32
    v.ld.w       v18, [s28, #0]
    vf.mul       v23, v18, v7
    s.addi       s28, s26, #768
    vf.mul       v7, v23, v22
    s.movz       s32, #12
    vf.add       v18, v0, v7
    v.st.w       [s30, #0], v18
    a.vread      v0, a3, s33
    s.addi       s30, s34, #8960
    v.extract    s33, v12, #12
    v.splat      v7, s33
    v.ld.w       v18, [s23, #0]
    vf.mul       v23, v18, v8
    s.addi       s23, s26, #832
    vf.mul       v8, v23, v22
    s.movz       s33, #13
    vf.add       v18, v0, v8
    v.st.w       [s22, #0], v18
    a.vread      v0, a3, s35
    s.addi       s22, s34, #9024
    v.extract    s35, v12, #13
    v.splat      v8, s35
    v.ld.w       v18, [s29, #0]
    vf.mul       v23, v18, v9
    s.addi       s29, s26, #896
    vf.mul       v9, v23, v22
    s.movz       s35, #14
    vf.add       v18, v0, v9
    v.st.w       [s31, #0], v18
    a.vread      v0, a3, s36
    s.addi       s31, s34, #9088
    v.extract    s36, v12, #14
    v.splat      v9, s36
    v.ld.w       v18, [s21, #0]
    vf.mul       v23, v18, v13
    s.addi       s21, s26, #960
    vf.mul       v13, v23, v22
    s.movz       s26, #15
    vf.add       v18, v0, v13
    v.st.w       [s27, #0], v18
    a.vread      v0, a3, s37
    s.addi       s27, s34, #9152
    v.extract    s36, v12, #15
    v.splat      v12, s36
    v.ld.w       v13, [s25, #0]
    vf.mul       v18, v13, v14
    vf.mul       v13, v18, v22
    s.addi       s25, s34, #17408
    vf.add       v14, v0, v13
    s.movz       s36, #0
    v.st.w       [s24, #0], v14
    a.vread      v0, a3, s32
    s.addi       s24, s34, #9216
    v.extract    s32, v10, #0
    v.splat      v13, s32
    v.ld.w       v14, [s30, #0]
    vf.mul       v18, v14, v7
    vf.mul       v7, v18, v22
    s.addi       s30, s25, #64
    vf.add       v14, v0, v7
    s.movz       s32, #1
    v.st.w       [s28, #0], v14
    a.vread      v0, a3, s33
    s.addi       s28, s34, #9280
    v.extract    s33, v10, #1
    v.splat      v7, s33
    v.ld.w       v14, [s22, #0]
    vf.mul       v18, v14, v8
    vf.mul       v8, v18, v22
    s.addi       s22, s25, #128
    vf.add       v14, v0, v8
    s.movz       s33, #2
    v.st.w       [s23, #0], v14
    a.vread      v0, a3, s35
    s.addi       s23, s34, #9344
    v.extract    s35, v10, #2
    v.splat      v8, s35
    v.ld.w       v14, [s31, #0]
    vf.mul       v18, v14, v9
    vf.mul       v9, v18, v22
    s.addi       s31, s25, #192
    vf.add       v14, v0, v9
    s.movz       s35, #3
    v.st.w       [s29, #0], v14
    a.vread      v0, a3, s26
    s.addi       s26, s34, #9408
    v.extract    s29, v10, #3
    v.splat      v9, s29
    v.ld.w       v14, [s27, #0]
    vf.mul       v18, v14, v12
    vf.mul       v12, v18, v22
    s.addi       s27, s25, #256
    vf.add       v14, v0, v12
    s.movz       s29, #4
    v.st.w       [s21, #0], v14
    fence.acq_rel.device
    a.vread      v0, a4, s36
    s.addi       s21, s34, #9472
    v.extract    s36, v10, #4
    v.splat      v12, s36
    v.ld.w       v14, [s24, #0]
    vf.mul       v18, v14, v13
    s.addi       s24, s25, #320
    vf.mul       v13, v18, v19
    s.movz       s36, #5
    vf.add       v14, v0, v13
    v.st.w       [s25, #0], v14
    a.vread      v0, a4, s32
    s.addi       s32, s34, #9536
    v.extract    s37, v10, #5
    v.splat      v13, s37
    v.ld.w       v14, [s28, #0]
    vf.mul       v18, v14, v7
    s.addi       s28, s25, #384
    vf.mul       v7, v18, v19
    s.movz       s37, #6
    vf.add       v14, v0, v7
    v.st.w       [s30, #0], v14
    a.vread      v0, a4, s33
    s.addi       s30, s34, #9600
    v.extract    s33, v10, #6
    v.splat      v7, s33
    v.ld.w       v14, [s23, #0]
    vf.mul       v18, v14, v8
    s.addi       s23, s25, #448
    vf.mul       v8, v18, v19
    s.movz       s33, #7
    vf.add       v14, v0, v8
    v.st.w       [s22, #0], v14
    a.vread      v0, a4, s35
    s.addi       s22, s34, #9664
    v.extract    s35, v10, #7
    v.splat      v8, s35
    v.ld.w       v14, [s26, #0]
    vf.mul       v18, v14, v9
    s.addi       s26, s25, #512
    vf.mul       v9, v18, v19
    s.movz       s35, #8
    vf.add       v14, v0, v9
    v.st.w       [s31, #0], v14
    a.vread      v0, a4, s29
    s.addi       s29, s34, #9728
    v.extract    s31, v10, #8
    v.splat      v9, s31
    v.ld.w       v14, [s21, #0]
    vf.mul       v18, v14, v12
    s.addi       s21, s25, #576
    vf.mul       v12, v18, v19
    s.movz       s31, #9
    vf.add       v14, v0, v12
    v.st.w       [s27, #0], v14
    a.vread      v0, a4, s36
    s.addi       s27, s34, #9792
    v.extract    s36, v10, #9
    v.splat      v12, s36
    v.ld.w       v14, [s32, #0]
    vf.mul       v18, v14, v13
    s.addi       s32, s25, #640
    vf.mul       v13, v18, v19
    s.movz       s36, #10
    vf.add       v14, v0, v13
    v.st.w       [s24, #0], v14
    a.vread      v0, a4, s37
    s.addi       s24, s34, #9856
    v.extract    s37, v10, #10
    v.splat      v13, s37
    v.ld.w       v14, [s30, #0]
    vf.mul       v18, v14, v7
    s.addi       s30, s25, #704
    vf.mul       v7, v18, v19
    s.movz       s37, #11
    vf.add       v14, v0, v7
    v.st.w       [s28, #0], v14
    a.vread      v0, a4, s33
    s.addi       s28, s34, #9920
    v.extract    s33, v10, #11
    v.splat      v7, s33
    v.ld.w       v14, [s22, #0]
    vf.mul       v18, v14, v8
    s.addi       s22, s25, #768
    vf.mul       v8, v18, v19
    s.movz       s33, #12
    vf.add       v14, v0, v8
    v.st.w       [s23, #0], v14
    a.vread      v0, a4, s35
    s.addi       s23, s34, #9984
    v.extract    s35, v10, #12
    v.splat      v8, s35
    v.ld.w       v14, [s29, #0]
    vf.mul       v18, v14, v9
    s.addi       s29, s25, #832
    vf.mul       v9, v18, v19
    s.movz       s35, #13
    vf.add       v14, v0, v9
    v.st.w       [s26, #0], v14
    a.vread      v0, a4, s31
    s.addi       s26, s34, #10048
    v.extract    s31, v10, #13
    v.splat      v9, s31
    v.ld.w       v14, [s27, #0]
    vf.mul       v18, v14, v12
    s.addi       s27, s25, #896
    vf.mul       v12, v18, v19
    s.movz       s31, #14
    vf.add       v14, v0, v12
    v.st.w       [s21, #0], v14
    a.vread      v0, a4, s36
    s.addi       s21, s34, #10112
    v.extract    s36, v10, #14
    v.splat      v12, s36
    v.ld.w       v14, [s24, #0]
    vf.mul       v18, v14, v13
    s.addi       s24, s25, #960
    vf.mul       v13, v18, v19
    s.movz       s25, #15
    vf.add       v14, v0, v13
    v.st.w       [s32, #0], v14
    a.vread      v0, a4, s37
    s.addi       s32, s34, #10176
    v.extract    s36, v10, #15
    v.splat      v13, s36
    v.ld.w       v14, [s28, #0]
    vf.mul       v18, v14, v7
    vf.mul       v7, v18, v19
    s.addi       s28, s34, #18432
    vf.add       v14, v0, v7
    s.movz       s36, #0
    v.st.w       [s30, #0], v14
    a.vread      v0, a4, s33
    s.addi       s30, s34, #10240
    v.extract    s33, v10, #0
    v.splat      v7, s33
    v.ld.w       v14, [s23, #0]
    vf.mul       v18, v14, v8
    vf.mul       v8, v18, v19
    s.addi       s23, s28, #64
    vf.add       v14, v0, v8
    s.movz       s33, #1
    v.st.w       [s22, #0], v14
    a.vread      v0, a4, s35
    s.addi       s22, s34, #10304
    v.extract    s35, v10, #1
    v.splat      v8, s35
    v.ld.w       v14, [s26, #0]
    vf.mul       v18, v14, v9
    vf.mul       v9, v18, v19
    s.addi       s26, s28, #128
    vf.add       v14, v0, v9
    s.movz       s35, #2
    v.st.w       [s29, #0], v14
    a.vread      v0, a4, s31
    s.addi       s29, s34, #10368
    v.extract    s31, v10, #2
    v.splat      v9, s31
    v.ld.w       v14, [s21, #0]
    vf.mul       v18, v14, v12
    vf.mul       v12, v18, v19
    s.addi       s21, s28, #192
    vf.add       v14, v0, v12
    s.movz       s31, #3
    v.st.w       [s27, #0], v14
    a.vread      v0, a4, s25
    s.addi       s25, s34, #10432
    v.extract    s27, v10, #3
    v.splat      v12, s27
    v.ld.w       v14, [s32, #0]
    vf.mul       v18, v14, v13
    vf.mul       v13, v18, v19
    s.addi       s27, s28, #256
    vf.add       v14, v0, v13
    s.movz       s32, #4
    v.st.w       [s24, #0], v14
    fence.acq_rel.device
    a.vread      v0, a5, s36
    s.addi       s24, s34, #10496
    v.extract    s36, v10, #4
    v.splat      v13, s36
    v.ld.w       v14, [s30, #0]
    vf.mul       v18, v14, v7
    s.addi       s30, s28, #320
    vf.mul       v7, v18, v20
    s.movz       s36, #5
    vf.add       v14, v0, v7
    v.st.w       [s28, #0], v14
    a.vread      v0, a5, s33
    s.addi       s33, s34, #10560
    v.extract    s37, v10, #5
    v.splat      v7, s37
    v.ld.w       v14, [s22, #0]
    vf.mul       v18, v14, v8
    s.addi       s22, s28, #384
    vf.mul       v8, v18, v20
    s.movz       s37, #6
    vf.add       v14, v0, v8
    v.st.w       [s23, #0], v14
    a.vread      v0, a5, s35
    s.addi       s23, s34, #10624
    v.extract    s35, v10, #6
    v.splat      v8, s35
    v.ld.w       v14, [s29, #0]
    vf.mul       v18, v14, v9
    s.addi       s29, s28, #448
    vf.mul       v9, v18, v20
    s.movz       s35, #7
    vf.add       v14, v0, v9
    v.st.w       [s26, #0], v14
    a.vread      v0, a5, s31
    s.addi       s26, s34, #10688
    v.extract    s31, v10, #7
    v.splat      v9, s31
    v.ld.w       v14, [s25, #0]
    vf.mul       v18, v14, v12
    s.addi       s25, s28, #512
    vf.mul       v12, v18, v20
    s.movz       s31, #8
    vf.add       v14, v0, v12
    v.st.w       [s21, #0], v14
    a.vread      v0, a5, s32
    s.addi       s21, s34, #10752
    v.extract    s32, v10, #8
    v.splat      v12, s32
    v.ld.w       v14, [s24, #0]
    vf.mul       v18, v14, v13
    s.addi       s24, s28, #576
    vf.mul       v13, v18, v20
    s.movz       s32, #9
    vf.add       v14, v0, v13
    v.st.w       [s27, #0], v14
    a.vread      v0, a5, s36
    s.addi       s27, s34, #10816
    v.extract    s36, v10, #9
    v.splat      v13, s36
    v.ld.w       v14, [s33, #0]
    vf.mul       v18, v14, v7
    s.addi       s33, s28, #640
    vf.mul       v7, v18, v20
    s.movz       s36, #10
    vf.add       v14, v0, v7
    v.st.w       [s30, #0], v14
    a.vread      v0, a5, s37
    s.addi       s30, s34, #10880
    v.extract    s37, v10, #10
    v.splat      v7, s37
    v.ld.w       v14, [s23, #0]
    vf.mul       v18, v14, v8
    s.addi       s23, s28, #704
    vf.mul       v8, v18, v20
    s.movz       s37, #11
    vf.add       v14, v0, v8
    v.st.w       [s22, #0], v14
    a.vread      v0, a5, s35
    s.addi       s22, s34, #10944
    v.extract    s35, v10, #11
    v.splat      v8, s35
    v.ld.w       v14, [s26, #0]
    vf.mul       v18, v14, v9
    s.addi       s26, s28, #768
    vf.mul       v9, v18, v20
    s.movz       s35, #12
    vf.add       v14, v0, v9
    v.st.w       [s29, #0], v14
    a.vread      v0, a5, s31
    s.addi       s29, s34, #11008
    v.extract    s31, v10, #12
    v.splat      v9, s31
    v.ld.w       v14, [s21, #0]
    vf.mul       v18, v14, v12
    s.addi       s21, s28, #832
    vf.mul       v12, v18, v20
    s.movz       s31, #13
    vf.add       v14, v0, v12
    v.st.w       [s25, #0], v14
    a.vread      v0, a5, s32
    s.addi       s25, s34, #11072
    v.extract    s32, v10, #13
    v.splat      v12, s32
    v.ld.w       v14, [s27, #0]
    vf.mul       v18, v14, v13
    s.addi       s27, s28, #896
    vf.mul       v13, v18, v20
    s.movz       s32, #14
    vf.add       v14, v0, v13
    v.st.w       [s24, #0], v14
    a.vread      v0, a5, s36
    s.addi       s24, s34, #11136
    v.extract    s36, v10, #14
    v.splat      v13, s36
    v.ld.w       v14, [s30, #0]
    vf.mul       v18, v14, v7
    s.addi       s30, s28, #960
    vf.mul       v7, v18, v20
    s.movz       s28, #15
    vf.add       v14, v0, v7
    v.st.w       [s33, #0], v14
    a.vread      v0, a5, s37
    s.addi       s33, s34, #11200
    v.extract    s36, v10, #15
    v.splat      v7, s36
    v.ld.w       v14, [s22, #0]
    vf.mul       v18, v14, v8
    vf.mul       v8, v18, v20
    s.addi       s22, s34, #19456
    vf.add       v14, v0, v8
    s.movz       s36, #0
    v.st.w       [s23, #0], v14
    a.vread      v0, a5, s35
    s.addi       s23, s34, #11264
    v.extract    s35, v10, #0
    v.splat      v8, s35
    v.ld.w       v14, [s29, #0]
    vf.mul       v18, v14, v9
    vf.mul       v9, v18, v20
    s.addi       s29, s22, #64
    vf.add       v14, v0, v9
    s.movz       s35, #1
    v.st.w       [s26, #0], v14
    a.vread      v0, a5, s31
    s.addi       s26, s34, #11328
    v.extract    s31, v10, #1
    v.splat      v9, s31
    v.ld.w       v14, [s25, #0]
    vf.mul       v18, v14, v12
    vf.mul       v12, v18, v20
    s.addi       s25, s22, #128
    vf.add       v14, v0, v12
    s.movz       s31, #2
    v.st.w       [s21, #0], v14
    a.vread      v0, a5, s32
    s.addi       s21, s34, #11392
    v.extract    s32, v10, #2
    v.splat      v12, s32
    v.ld.w       v14, [s24, #0]
    vf.mul       v18, v14, v13
    vf.mul       v13, v18, v20
    s.addi       s24, s22, #192
    vf.add       v14, v0, v13
    s.movz       s32, #3
    v.st.w       [s27, #0], v14
    a.vread      v0, a5, s28
    s.addi       s27, s34, #11456
    v.extract    s28, v10, #3
    v.splat      v13, s28
    v.ld.w       v14, [s33, #0]
    vf.mul       v18, v14, v7
    vf.mul       v7, v18, v20
    s.addi       s28, s22, #256
    vf.add       v14, v0, v7
    s.movz       s33, #4
    v.st.w       [s30, #0], v14
    fence.acq_rel.device
    a.vread      v0, a6, s36
    s.addi       s30, s34, #11520
    v.extract    s36, v10, #4
    v.splat      v7, s36
    v.ld.w       v14, [s23, #0]
    vf.mul       v18, v14, v8
    s.addi       s23, s22, #320
    vf.mul       v8, v18, v21
    s.movz       s36, #5
    vf.add       v14, v0, v8
    v.st.w       [s22, #0], v14
    a.vread      v0, a6, s35
    s.addi       s35, s34, #11584
    v.extract    s37, v10, #5
    v.splat      v8, s37
    v.ld.w       v14, [s26, #0]
    vf.mul       v18, v14, v9
    s.addi       s26, s22, #384
    vf.mul       v9, v18, v21
    s.movz       s37, #6
    vf.add       v14, v0, v9
    v.st.w       [s29, #0], v14
    a.vread      v0, a6, s31
    s.addi       s29, s34, #11648
    v.extract    s31, v10, #6
    v.splat      v9, s31
    v.ld.w       v14, [s21, #0]
    vf.mul       v18, v14, v12
    s.addi       s21, s22, #448
    vf.mul       v12, v18, v21
    s.movz       s31, #7
    vf.add       v14, v0, v12
    v.st.w       [s25, #0], v14
    a.vread      v0, a6, s32
    s.addi       s25, s34, #11712
    v.extract    s32, v10, #7
    v.splat      v12, s32
    v.ld.w       v14, [s27, #0]
    vf.mul       v18, v14, v13
    s.addi       s27, s22, #512
    vf.mul       v13, v18, v21
    s.movz       s32, #8
    vf.add       v14, v0, v13
    v.st.w       [s24, #0], v14
    a.vread      v0, a6, s33
    s.addi       s24, s34, #11776
    v.extract    s33, v10, #8
    v.splat      v13, s33
    v.ld.w       v14, [s30, #0]
    vf.mul       v18, v14, v7
    s.addi       s30, s22, #576
    vf.mul       v7, v18, v21
    s.movz       s33, #9
    vf.add       v14, v0, v7
    v.st.w       [s28, #0], v14
    a.vread      v0, a6, s36
    s.addi       s28, s34, #11840
    v.extract    s36, v10, #9
    v.splat      v7, s36
    v.ld.w       v14, [s35, #0]
    vf.mul       v18, v14, v8
    s.addi       s35, s22, #640
    vf.mul       v8, v18, v21
    s.movz       s36, #10
    vf.add       v14, v0, v8
    v.st.w       [s23, #0], v14
    a.vread      v0, a6, s37
    s.addi       s23, s34, #11904
    v.extract    s37, v10, #10
    v.splat      v8, s37
    v.ld.w       v14, [s29, #0]
    vf.mul       v18, v14, v9
    s.addi       s29, s22, #704
    vf.mul       v9, v18, v21
    s.movz       s37, #11
    vf.add       v14, v0, v9
    v.st.w       [s26, #0], v14
    a.vread      v0, a6, s31
    s.addi       s26, s34, #11968
    v.extract    s31, v10, #11
    v.splat      v9, s31
    v.ld.w       v14, [s25, #0]
    vf.mul       v18, v14, v12
    s.addi       s25, s22, #768
    vf.mul       v12, v18, v21
    s.movz       s31, #12
    vf.add       v14, v0, v12
    v.st.w       [s21, #0], v14
    a.vread      v0, a6, s32
    s.addi       s21, s34, #12032
    v.extract    s32, v10, #12
    v.splat      v12, s32
    v.ld.w       v14, [s24, #0]
    vf.mul       v18, v14, v13
    s.addi       s24, s22, #832
    vf.mul       v13, v18, v21
    s.movz       s32, #13
    vf.add       v14, v0, v13
    v.st.w       [s27, #0], v14
    a.vread      v0, a6, s33
    s.addi       s27, s34, #12096
    v.extract    s33, v10, #13
    v.splat      v13, s33
    v.ld.w       v14, [s28, #0]
    vf.mul       v18, v14, v7
    s.addi       s28, s22, #896
    vf.mul       v7, v18, v21
    s.movz       s33, #14
    vf.add       v14, v0, v7
    v.st.w       [s30, #0], v14
    a.vread      v0, a6, s36
    s.addi       s30, s34, #12160
    v.extract    s36, v10, #14
    v.splat      v7, s36
    v.ld.w       v14, [s23, #0]
    vf.mul       v18, v14, v8
    s.addi       s23, s22, #960
    vf.mul       v8, v18, v21
    s.movz       s22, #15
    vf.add       v14, v0, v8
    v.st.w       [s35, #0], v14
    a.vread      v0, a6, s37
    s.addi       s35, s34, #12224
    v.extract    s36, v10, #15
    v.splat      v8, s36
    v.ld.w       v14, [s26, #0]
    vf.mul       v18, v14, v9
    vf.mul       v9, v18, v21
    s.addi       s26, s34, #20480
    vf.add       v14, v0, v9
    s.movz       s36, #0
    v.st.w       [s29, #0], v14
    a.vread      v0, a6, s31
    s.addi       s29, s34, #12288
    v.extract    s31, v10, #0
    v.splat      v9, s31
    v.ld.w       v14, [s21, #0]
    vf.mul       v18, v14, v12
    vf.mul       v12, v18, v21
    s.addi       s21, s26, #64
    vf.add       v14, v0, v12
    s.movz       s31, #1
    v.st.w       [s25, #0], v14
    a.vread      v0, a6, s32
    s.addi       s25, s34, #12352
    v.extract    s32, v10, #1
    v.splat      v12, s32
    v.ld.w       v14, [s27, #0]
    vf.mul       v18, v14, v13
    vf.mul       v13, v18, v21
    s.addi       s27, s26, #128
    vf.add       v14, v0, v13
    s.movz       s32, #2
    v.st.w       [s24, #0], v14
    a.vread      v0, a6, s33
    s.addi       s24, s34, #12416
    v.extract    s33, v10, #2
    v.splat      v13, s33
    v.ld.w       v14, [s30, #0]
    vf.mul       v18, v14, v7
    vf.mul       v7, v18, v21
    s.addi       s30, s26, #192
    vf.add       v14, v0, v7
    s.movz       s33, #3
    v.st.w       [s28, #0], v14
    a.vread      v0, a6, s22
    s.addi       s22, s34, #12480
    v.extract    s28, v10, #3
    v.splat      v7, s28
    v.ld.w       v14, [s35, #0]
    vf.mul       v18, v14, v8
    vf.mul       v8, v18, v21
    s.addi       s28, s26, #256
    vf.add       v14, v0, v8
    s.movz       s35, #4
    v.st.w       [s23, #0], v14
    fence.acq_rel.device
    a.vread      v0, a7, s36
    s.addi       s23, s34, #12544
    v.extract    s36, v10, #4
    v.splat      v8, s36
    v.ld.w       v14, [s29, #0]
    vf.mul       v18, v14, v9
    s.addi       s29, s26, #320
    vf.mul       v9, v18, v22
    s.movz       s36, #5
    vf.add       v14, v0, v9
    v.st.w       [s26, #0], v14
    a.vread      v0, a7, s31
    s.addi       s31, s34, #12608
    v.extract    s37, v10, #5
    v.splat      v9, s37
    v.ld.w       v14, [s25, #0]
    vf.mul       v18, v14, v12
    s.addi       s25, s26, #384
    vf.mul       v12, v18, v22
    s.movz       s37, #6
    vf.add       v14, v0, v12
    v.st.w       [s21, #0], v14
    a.vread      v0, a7, s32
    s.addi       s21, s34, #12672
    v.extract    s32, v10, #6
    v.splat      v12, s32
    v.ld.w       v14, [s24, #0]
    vf.mul       v18, v14, v13
    s.addi       s24, s26, #448
    vf.mul       v13, v18, v22
    s.movz       s32, #7
    vf.add       v14, v0, v13
    v.st.w       [s27, #0], v14
    a.vread      v0, a7, s33
    s.addi       s27, s34, #12736
    v.extract    s33, v10, #7
    v.splat      v13, s33
    v.ld.w       v14, [s22, #0]
    vf.mul       v18, v14, v7
    s.addi       s22, s26, #512
    vf.mul       v7, v18, v22
    s.movz       s33, #8
    vf.add       v14, v0, v7
    v.st.w       [s30, #0], v14
    a.vread      v0, a7, s35
    s.addi       s30, s34, #12800
    v.extract    s35, v10, #8
    v.splat      v7, s35
    v.ld.w       v14, [s23, #0]
    vf.mul       v18, v14, v8
    s.addi       s23, s26, #576
    vf.mul       v8, v18, v22
    s.movz       s35, #9
    vf.add       v14, v0, v8
    v.st.w       [s28, #0], v14
    a.vread      v0, a7, s36
    s.addi       s28, s34, #12864
    v.extract    s36, v10, #9
    v.splat      v8, s36
    v.ld.w       v14, [s31, #0]
    vf.mul       v18, v14, v9
    s.addi       s31, s26, #640
    vf.mul       v9, v18, v22
    s.movz       s36, #10
    vf.add       v14, v0, v9
    v.st.w       [s29, #0], v14
    a.vread      v0, a7, s37
    s.addi       s29, s34, #12928
    v.extract    s37, v10, #10
    v.splat      v9, s37
    v.ld.w       v14, [s21, #0]
    vf.mul       v18, v14, v12
    s.addi       s21, s26, #704
    vf.mul       v12, v18, v22
    s.movz       s37, #11
    vf.add       v14, v0, v12
    v.st.w       [s25, #0], v14
    a.vread      v0, a7, s32
    s.addi       s25, s34, #12992
    v.extract    s32, v10, #11
    v.splat      v12, s32
    v.ld.w       v14, [s27, #0]
    vf.mul       v18, v14, v13
    s.addi       s27, s26, #768
    vf.mul       v13, v18, v22
    s.movz       s32, #12
    vf.add       v14, v0, v13
    v.st.w       [s24, #0], v14
    a.vread      v0, a7, s33
    s.addi       s24, s34, #13056
    v.extract    s33, v10, #12
    v.splat      v13, s33
    v.ld.w       v14, [s30, #0]
    vf.mul       v18, v14, v7
    s.addi       s30, s26, #832
    vf.mul       v7, v18, v22
    s.movz       s33, #13
    vf.add       v14, v0, v7
    v.st.w       [s22, #0], v14
    a.vread      v0, a7, s35
    s.addi       s22, s34, #13120
    v.extract    s35, v10, #13
    v.splat      v7, s35
    v.ld.w       v14, [s28, #0]
    vf.mul       v18, v14, v8
    s.addi       s28, s26, #896
    vf.mul       v8, v18, v22
    s.movz       s35, #14
    vf.add       v14, v0, v8
    v.st.w       [s23, #0], v14
    a.vread      v0, a7, s36
    s.addi       s23, s34, #13184
    v.extract    s36, v10, #14
    v.splat      v8, s36
    v.ld.w       v14, [s29, #0]
    vf.mul       v18, v14, v9
    s.addi       s29, s26, #960
    vf.mul       v9, v18, v22
    s.movz       s26, #15
    vf.add       v14, v0, v9
    v.st.w       [s31, #0], v14
    a.vread      v0, a7, s37
    s.addi       s31, s34, #13248
    v.extract    s36, v10, #15
    v.splat      v9, s36
    v.ld.w       v10, [s25, #0]
    vf.mul       v14, v10, v12
    vf.mul       v10, v14, v22
    s.addi       s25, s19, #128
    vf.add       v12, v0, v10
    s.addi       s36, s25, #0
    v.st.w       [s21, #0], v12
    a.vread      v0, a7, s32
    s.addi       s21, s20, #128
    s.movz       s25, #0
    s.addi       s32, s21, #0
    v.ld.w       v10, [s24, #0]
    s.addi       s21, s34, #13312
    vf.mul       v12, v10, v13
    s.movz       s24, #1
    vf.mul       v10, v12, v22
    s.addi       s37, s34, #13376
    vf.add       v12, v0, v10
    v.st.w       [s27, #0], v12
    a.vread      v0, a7, s33
    s.addi       s27, s34, #13440
    s.movz       s33, #2
    v.ld.w       v10, [s22, #0]
    s.addi       s22, s34, #13504
    s.movz       s38, #3
    vf.mul       v12, v10, v7
    vf.mul       v7, v12, v22
    s.movz       s39, #4
    vf.add       v10, v0, v7
    s.addi       s40, s34, #13568
    v.st.w       [s30, #0], v10
    a.vread      v0, a7, s35
    s.addi       s30, s34, #13632
    s.movz       s35, #5
    v.ld.w       v7, [s23, #0]
    s.addi       s23, s34, #13696
    vf.mul       v10, v7, v8
    vf.mul       v7, v10, v22
    vf.add       v8, v0, v7
    v.st.w       [s28, #0], v8
    a.vread      v0, a7, s26
    s.movz       s26, #6
    s.addi       s28, s34, #13760
    v.ld.w       v7, [s31, #0]
    s.movz       s31, #7
    vf.mul       v8, v7, v9
    vf.mul       v7, v8, v22
    vf.add       v8, v0, v7
    v.st.w       [s29, #0], v8
    fence.acq_rel.device
    s.mov        s19, s36
    s.mov        s20, s32
    s.addi       s29, s34, #13824
    s.movz       s32, #8
    s.addi       s36, s34, #13888
    s.movz       s41, #9
    s.addi       s42, s34, #13952
    v.ld.w       v0, [s21, #0]
    s.movz       s21, #10
    a.vwrite     a0, s25, v0
    v.ld.w       v0, [s37, #0]
    s.addi       s37, s34, #14016
    a.vwrite     a0, s24, v0
    v.ld.w       v0, [s27, #0]
    s.movz       s27, #11
    a.vwrite     a0, s33, v0
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s34, #14080
    a.vwrite     a0, s38, v0
    v.ld.w       v0, [s40, #0]
    s.movz       s40, #12
    a.vwrite     a0, s39, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s34, #14144
    a.vwrite     a0, s35, v0
    v.ld.w       v0, [s23, #0]
    s.movz       s23, #13
    a.vwrite     a0, s26, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s34, #14208
    a.vwrite     a0, s31, v0
    v.ld.w       v0, [s29, #0]
    s.movz       s29, #14
    a.vwrite     a0, s32, v0
    v.ld.w       v0, [s36, #0]
    s.addi       s36, s34, #14272
    a.vwrite     a0, s41, v0
    v.ld.w       v0, [s42, #0]
    s.movz       s42, #15
    a.vwrite     a0, s21, v0
    v.ld.w       v0, [s37, #0]
    s.addi       s37, s34, #14336
    a.vwrite     a0, s27, v0
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s34, #14400
    a.vwrite     a0, s40, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s34, #14464
    a.vwrite     a0, s23, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s34, #14528
    a.vwrite     a0, s29, v0
    v.ld.w       v0, [s36, #0]
    s.addi       s36, s34, #14592
    a.vwrite     a0, s42, v0
    v.ld.w       v0, [s37, #0]
    s.addi       s37, s34, #14656
    a.vwrite     a1, s25, v0
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s34, #14720
    s.addi       s25, s34, #14784
    a.vwrite     a1, s24, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s24, s34, #14848
    s.addi       s30, s34, #14912
    a.vwrite     a1, s33, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s34, #14976
    s.addi       s33, s34, #15040
    a.vwrite     a1, s38, v0
    v.ld.w       v0, [s36, #0]
    s.addi       s36, s34, #15104
    s.addi       s38, s34, #15168
    a.vwrite     a1, s39, v0
    v.ld.w       v0, [s37, #0]
    s.addi       s37, s34, #15232
    s.addi       s39, s34, #15296
    a.vwrite     a1, s35, v0
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s34, #15360
    s.movz       s35, #0
    a.vwrite     a1, s26, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s34, #15424
    s.movz       s26, #1
    a.vwrite     a1, s31, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s34, #15488
    s.movz       s31, #2
    a.vwrite     a1, s32, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s34, #15552
    s.movz       s32, #3
    a.vwrite     a1, s41, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s34, #15616
    s.movz       s41, #4
    a.vwrite     a1, s21, v0
    v.ld.w       v0, [s33, #0]
    s.addi       s21, s34, #15680
    s.movz       s33, #5
    a.vwrite     a1, s27, v0
    v.ld.w       v0, [s36, #0]
    s.addi       s27, s34, #15744
    s.movz       s36, #6
    a.vwrite     a1, s40, v0
    v.ld.w       v0, [s38, #0]
    s.addi       s38, s34, #15808
    s.movz       s40, #7
    a.vwrite     a1, s23, v0
    v.ld.w       v0, [s37, #0]
    s.addi       s23, s34, #15872
    s.movz       s37, #8
    a.vwrite     a1, s29, v0
    v.ld.w       v0, [s39, #0]
    s.addi       s29, s34, #15936
    s.movz       s39, #9
    a.vwrite     a1, s42, v0
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s34, #16000
    s.movz       s42, #10
    a.vwrite     a2, s35, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s34, #16064
    a.vwrite     a2, s26, v0
    v.ld.w       v0, [s24, #0]
    s.movz       s24, #11
    a.vwrite     a2, s31, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s34, #16128
    a.vwrite     a2, s32, v0
    v.ld.w       v0, [s28, #0]
    s.movz       s28, #12
    a.vwrite     a2, s41, v0
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s34, #16192
    a.vwrite     a2, s33, v0
    v.ld.w       v0, [s27, #0]
    s.movz       s27, #13
    a.vwrite     a2, s36, v0
    v.ld.w       v0, [s38, #0]
    s.addi       s38, s34, #16256
    a.vwrite     a2, s40, v0
    v.ld.w       v0, [s23, #0]
    s.movz       s23, #14
    a.vwrite     a2, s37, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s34, #16320
    a.vwrite     a2, s39, v0
    v.ld.w       v0, [s22, #0]
    s.movz       s22, #15
    a.vwrite     a2, s42, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s34, #16384
    a.vwrite     a2, s24, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s34, #16448
    a.vwrite     a2, s28, v0
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s34, #16512
    a.vwrite     a2, s27, v0
    v.ld.w       v0, [s38, #0]
    s.addi       s38, s34, #16576
    a.vwrite     a2, s23, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s34, #16640
    a.vwrite     a2, s22, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s34, #16704
    a.vwrite     a3, s35, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s34, #16768
    s.addi       s35, s34, #16832
    a.vwrite     a3, s26, v0
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s34, #16896
    s.addi       s26, s34, #16960
    a.vwrite     a3, s31, v0
    v.ld.w       v0, [s38, #0]
    s.addi       s31, s34, #17024
    s.addi       s38, s34, #17088
    a.vwrite     a3, s32, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s34, #17152
    s.addi       s32, s34, #17216
    a.vwrite     a3, s41, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s34, #17280
    s.addi       s41, s34, #17344
    a.vwrite     a3, s33, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s34, #17408
    s.movz       s33, #0
    a.vwrite     a3, s36, v0
    v.ld.w       v0, [s35, #0]
    s.addi       s35, s34, #17472
    s.movz       s36, #1
    a.vwrite     a3, s40, v0
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s34, #17536
    s.movz       s40, #2
    a.vwrite     a3, s37, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s34, #17600
    s.movz       s37, #3
    a.vwrite     a3, s39, v0
    v.ld.w       v0, [s31, #0]
    s.addi       s31, s34, #17664
    s.movz       s39, #4
    a.vwrite     a3, s42, v0
    v.ld.w       v0, [s38, #0]
    s.addi       s38, s34, #17728
    s.movz       s42, #5
    a.vwrite     a3, s24, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s24, s34, #17792
    s.movz       s29, #6
    a.vwrite     a3, s28, v0
    v.ld.w       v0, [s32, #0]
    s.addi       s28, s34, #17856
    s.movz       s32, #7
    a.vwrite     a3, s27, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s34, #17920
    s.movz       s27, #8
    a.vwrite     a3, s23, v0
    v.ld.w       v0, [s41, #0]
    s.addi       s23, s34, #17984
    s.movz       s41, #9
    a.vwrite     a3, s22, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s22, s34, #18048
    s.movz       s30, #10
    a.vwrite     a4, s33, v0
    v.ld.w       v0, [s35, #0]
    s.addi       s35, s34, #18112
    a.vwrite     a4, s36, v0
    v.ld.w       v0, [s21, #0]
    s.movz       s21, #11
    a.vwrite     a4, s40, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s34, #18176
    a.vwrite     a4, s37, v0
    v.ld.w       v0, [s31, #0]
    s.movz       s31, #12
    a.vwrite     a4, s39, v0
    v.ld.w       v0, [s38, #0]
    s.addi       s38, s34, #18240
    a.vwrite     a4, s42, v0
    v.ld.w       v0, [s24, #0]
    s.movz       s24, #13
    a.vwrite     a4, s29, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s34, #18304
    a.vwrite     a4, s32, v0
    v.ld.w       v0, [s25, #0]
    s.movz       s25, #14
    a.vwrite     a4, s27, v0
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s34, #18368
    a.vwrite     a4, s41, v0
    v.ld.w       v0, [s22, #0]
    s.movz       s22, #15
    a.vwrite     a4, s30, v0
    v.ld.w       v0, [s35, #0]
    s.addi       s35, s34, #18432
    a.vwrite     a4, s21, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s34, #18496
    a.vwrite     a4, s31, v0
    v.ld.w       v0, [s38, #0]
    s.addi       s38, s34, #18560
    a.vwrite     a4, s24, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s34, #18624
    a.vwrite     a4, s25, v0
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s34, #18688
    a.vwrite     a4, s22, v0
    v.ld.w       v0, [s35, #0]
    s.addi       s35, s34, #18752
    a.vwrite     a5, s33, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s34, #18816
    s.addi       s33, s34, #18880
    a.vwrite     a5, s36, v0
    v.ld.w       v0, [s38, #0]
    s.addi       s36, s34, #18944
    s.addi       s38, s34, #19008
    a.vwrite     a5, s40, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s34, #19072
    s.addi       s40, s34, #19136
    a.vwrite     a5, s37, v0
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s34, #19200
    s.addi       s37, s34, #19264
    a.vwrite     a5, s39, v0
    v.ld.w       v0, [s35, #0]
    s.addi       s35, s34, #19328
    s.addi       s39, s34, #19392
    a.vwrite     a5, s42, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s34, #19456
    s.movz       s42, #0
    a.vwrite     a5, s29, v0
    v.ld.w       v0, [s33, #0]
    s.addi       s29, s34, #19520
    s.movz       s33, #1
    a.vwrite     a5, s32, v0
    v.ld.w       v0, [s36, #0]
    s.addi       s32, s34, #19584
    s.movz       s36, #2
    a.vwrite     a5, s27, v0
    v.ld.w       v0, [s38, #0]
    s.addi       s27, s34, #19648
    s.movz       s38, #3
    a.vwrite     a5, s41, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s34, #19712
    s.movz       s41, #4
    a.vwrite     a5, s30, v0
    v.ld.w       v0, [s40, #0]
    s.addi       s30, s34, #19776
    s.movz       s40, #5
    a.vwrite     a5, s21, v0
    v.ld.w       v0, [s23, #0]
    s.addi       s21, s34, #19840
    s.movz       s23, #6
    a.vwrite     a5, s31, v0
    v.ld.w       v0, [s37, #0]
    s.addi       s31, s34, #19904
    s.movz       s37, #7
    a.vwrite     a5, s24, v0
    v.ld.w       v0, [s35, #0]
    s.addi       s24, s34, #19968
    s.movz       s35, #8
    a.vwrite     a5, s25, v0
    v.ld.w       v0, [s39, #0]
    s.addi       s25, s34, #20032
    s.movz       s39, #9
    a.vwrite     a5, s22, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s22, s34, #20096
    s.movz       s26, #10
    a.vwrite     a6, s42, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s34, #20160
    a.vwrite     a6, s33, v0
    v.ld.w       v0, [s32, #0]
    s.movz       s32, #11
    a.vwrite     a6, s36, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s34, #20224
    a.vwrite     a6, s38, v0
    v.ld.w       v0, [s28, #0]
    s.movz       s28, #12
    a.vwrite     a6, s41, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s34, #20288
    a.vwrite     a6, s40, v0
    v.ld.w       v0, [s21, #0]
    s.movz       s21, #13
    a.vwrite     a6, s23, v0
    v.ld.w       v0, [s31, #0]
    s.addi       s31, s34, #20352
    a.vwrite     a6, s37, v0
    v.ld.w       v0, [s24, #0]
    s.movz       s24, #14
    a.vwrite     a6, s35, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s34, #20416
    a.vwrite     a6, s39, v0
    v.ld.w       v0, [s22, #0]
    s.movz       s22, #15
    a.vwrite     a6, s26, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s34, #20480
    a.vwrite     a6, s32, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s34, #20544
    a.vwrite     a6, s28, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s34, #20608
    a.vwrite     a6, s21, v0
    v.ld.w       v0, [s31, #0]
    s.addi       s31, s34, #20672
    a.vwrite     a6, s24, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s34, #20736
    a.vwrite     a6, s22, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s34, #20800
    s.add        s43, s18, s17
    a.vwrite     a7, s42, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s34, #20864
    s.addi       s42, s34, #20928
    a.vwrite     a7, s33, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s34, #20992
    s.addi       s33, s34, #21056
    a.vwrite     a7, s36, v0
    v.ld.w       v0, [s31, #0]
    s.addi       s31, s34, #21120
    s.addi       s36, s34, #21184
    a.vwrite     a7, s38, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s34, #21248
    s.addi       s38, s34, #21312
    a.vwrite     a7, s41, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s34, #21376
    s.addi       s41, s34, #21440
    s.movz       s34, #1
    a.vwrite     a7, s40, v0
    v.ld.w       v0, [s27, #0]
    a.vwrite     a7, s23, v0
    v.ld.w       v0, [s42, #0]
    a.vwrite     a7, s37, v0
    v.ld.w       v0, [s30, #0]
    a.vwrite     a7, s35, v0
    v.ld.w       v0, [s33, #0]
    a.vwrite     a7, s39, v0
    v.ld.w       v0, [s31, #0]
    a.vwrite     a7, s26, v0
    v.ld.w       v0, [s36, #0]
    a.vwrite     a7, s32, v0
    v.ld.w       v0, [s25, #0]
    a.vwrite     a7, s28, v0
    v.ld.w       v0, [s38, #0]
    a.vwrite     a7, s21, v0
    v.ld.w       v0, [s29, #0]
    a.vwrite     a7, s24, v0
    v.ld.w       v0, [s41, #0]
    a.vwrite     a7, s22, v0
    s.mov        s18, s43
    br.nz        s34, for_1
endfor_2:
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s2, #0
    s.muli       s4, s5, #2                      // a runtime tile origin, x2
    s.add        s6, s2, s5                      // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s6
    a.vread      v2, a0, s2
    s.add        s6, s2, s1                      // the tile origin
    s.movz       s2, #256
    s.muli       s7, s1, #512                    // a runtime tile origin, x512
    v.splat      v3, s6
    v.splat      v4, s3
    v.add        v5, v0, v1
    v.splat      v1, s2
    vf.cvt.f32.bf16 v6, v2
    s.add        s8, s10, s4                     // the tile origin
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v1
    s.add        s4, s8, s7                      // the tile origin
    p.and        p3, p1, p2
    s.movz       s7, #1
    @p3 v.st.h       [s4, #0], v6
    a.vread      v1, a0, s7
    s.addi       s7, s6, #1
    s.addi       s8, s4, #512                    // row 1
    v.splat      v2, s7
    vf.cvt.f32.bf16 v3, v1
    s.movz       s7, #2
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    s.addi       s9, s6, #2
    s.addi       s11, s4, #1024                  // row 2
    v.splat      v1, s9
    s.movz       s9, #3
    s.addi       s12, s6, #3
    @p3 v.st.h       [s8, #0], v3
    a.vread      v2, a0, s7
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    v.splat      v2, s12
    s.addi       s7, s4, #1536                   // row 3
    s.addi       s8, s5, #16
    s.addi       s12, s5, #32
    s.addi       s13, s5, #48
    s.addi       s14, s1, #16
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.movz       s15, #4
    @p3 v.st.h       [s11, #0], v1
    a.vread      v1, a0, s9
    s.addi       s9, s6, #4
    s.addi       s11, s4, #2048                  // row 4
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s9
    s.movz       s9, #5
    s.addi       s16, s6, #5
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    v.splat      v1, s16
    s.addi       s16, s4, #2560                  // row 5
    s.movz       s17, #6
    v.cmp.lt     p1, v1, v4
    @p4 v.st.h       [s7, #0], v2
    a.vread      v1, a0, s15
    p.and        p4, p1, p2
    s.addi       s7, s6, #6
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s7
    s.addi       s7, s4, #3072                   // row 6
    s.movz       s15, #7
    v.cmp.lt     p1, v1, v4
    p.and        p5, p1, p2
    @p3 v.st.h       [s11, #0], v2
    a.vread      v1, a0, s9
    s.addi       s9, s6, #7
    s.addi       s11, s4, #3584                  // row 7
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s9
    s.movz       s9, #8
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    @p4 v.st.h       [s16, #0], v2
    a.vread      v1, a0, s17
    s.addi       s16, s6, #8
    s.addi       s17, s4, #4096                  // row 8
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s16
    s.movz       s16, #9
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    @p5 v.st.h       [s7, #0], v2
    a.vread      v1, a0, s15
    s.addi       s7, s6, #9
    s.addi       s15, s4, #4608                  // row 9
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s7
    s.movz       s7, #10
    v.cmp.lt     p1, v1, v4
    p.and        p5, p1, p2
    @p3 v.st.h       [s11, #0], v2
    a.vread      v1, a0, s9
    s.addi       s9, s6, #10
    s.addi       s11, s4, #5120                  // row 10
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s9
    s.movz       s9, #11
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    @p4 v.st.h       [s17, #0], v2
    a.vread      v1, a0, s16
    s.addi       s16, s6, #11
    s.addi       s17, s4, #5632                  // row 11
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s16
    s.movz       s16, #12
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    @p5 v.st.h       [s15, #0], v2
    a.vread      v1, a0, s7
    s.addi       s7, s6, #12
    s.addi       s15, s4, #6144                  // row 12
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s7
    s.movz       s7, #13
    v.cmp.lt     p1, v1, v4
    p.and        p5, p1, p2
    @p3 v.st.h       [s11, #0], v2
    a.vread      v1, a0, s9
    s.addi       s9, s6, #13
    s.addi       s11, s4, #6656                  // row 13
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s9
    s.movz       s9, #14
    v.splat      v3, s6
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    v.cmp.lt     p1, v3, v4
    @p4 v.st.h       [s17, #0], v2
    a.vread      v1, a0, s16
    s.addi       s16, s6, #14
    s.addi       s17, s4, #7168                  // row 14
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s16
    s.movz       s16, #15
    s.addi       s18, s4, #7680                  // row 15
    v.cmp.lt     p4, v1, v4
    p.and        p6, p4, p2
    v.splat      v1, s2
    @p5 v.st.h       [s15, #0], v2
    a.vread      v2, a0, s7
    s.addi       s4, s6, #15
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s7, #0
    vf.cvt.f32.bf16 v3, v2
    v.splat      v2, s4
    s.add        s4, s7, s8                      // the tile origin
    v.cmp.lt     p4, v2, v4
    p.and        p5, p4, p2
    v.splat      v2, s4
    s.muli       s4, s8, #2                      // a runtime tile origin, x2
    v.add        v5, v0, v2
    @p3 v.st.h       [s11, #0], v3
    a.vread      v2, a0, s9
    s.muli       s9, s1, #512                    // a runtime tile origin, x512
    s.add        s11, s10, s4                    // the tile origin
    vf.cvt.f32.bf16 v3, v2
    v.cmp.lt     p3, v5, v1
    p.and        p4, p1, p3
    s.add        s4, s11, s9                     // the tile origin
    s.movz       s9, #1
    s.addi       s11, s6, #1
    v.splat      v1, s11
    s.addi       s11, s4, #512                   // row 1
    @p6 v.st.h       [s17, #0], v3
    a.vread      v2, a0, s16
    v.cmp.lt     p1, v1, v4
    p.and        p6, p1, p3
    vf.cvt.f32.bf16 v1, v2
    s.movz       s15, #2
    s.addi       s16, s6, #2
    v.splat      v2, s16
    s.addi       s16, s4, #1024                  // row 2
    v.cmp.lt     p1, v2, v4
    p.and        p7, p1, p3
    @p5 v.st.h       [s18, #0], v1
    a.vread      v1, a1, s7
    s.movz       s7, #3
    s.addi       s17, s6, #3
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s17
    s.addi       s17, s4, #1536                  // row 3
    v.cmp.lt     p1, v1, v4
    p.and        p5, p1, p3
    @p4 v.st.h       [s4, #0], v2
    a.vread      v1, a1, s9
    s.movz       s9, #4
    vf.cvt.f32.bf16 v2, v1
    @p6 v.st.h       [s11, #0], v2
    a.vread      v1, a1, s15
    s.addi       s11, s6, #4
    s.addi       s15, s4, #2048                  // row 4
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s11
    s.movz       s11, #5
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p3
    @p7 v.st.h       [s16, #0], v2
    a.vread      v1, a1, s7
    s.addi       s7, s6, #5
    s.addi       s16, s4, #2560                  // row 5
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s7
    s.movz       s7, #6
    v.cmp.lt     p1, v1, v4
    p.and        p6, p1, p3
    @p5 v.st.h       [s17, #0], v2
    a.vread      v1, a1, s9
    s.addi       s9, s6, #6
    s.addi       s17, s4, #3072                  // row 6
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s9
    s.movz       s9, #7
    v.cmp.lt     p1, v1, v4
    p.and        p5, p1, p3
    @p4 v.st.h       [s15, #0], v2
    a.vread      v1, a1, s11
    s.addi       s11, s6, #7
    s.addi       s15, s4, #3584                  // row 7
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s11
    s.movz       s11, #8
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p3
    @p6 v.st.h       [s16, #0], v2
    a.vread      v1, a1, s7
    s.addi       s7, s6, #8
    s.addi       s16, s4, #4096                  // row 8
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s7
    s.movz       s7, #9
    v.cmp.lt     p1, v1, v4
    p.and        p6, p1, p3
    @p5 v.st.h       [s17, #0], v2
    a.vread      v1, a1, s9
    s.addi       s9, s6, #9
    s.addi       s17, s4, #4608                  // row 9
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s9
    s.movz       s9, #10
    v.cmp.lt     p1, v1, v4
    p.and        p5, p1, p3
    @p4 v.st.h       [s15, #0], v2
    a.vread      v1, a1, s11
    s.addi       s11, s6, #10
    s.addi       s15, s4, #5120                  // row 10
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s11
    s.movz       s11, #11
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p3
    @p6 v.st.h       [s16, #0], v2
    a.vread      v1, a1, s7
    s.addi       s7, s6, #11
    s.addi       s16, s4, #5632                  // row 11
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s7
    s.movz       s7, #12
    v.cmp.lt     p1, v1, v4
    p.and        p6, p1, p3
    @p5 v.st.h       [s17, #0], v2
    a.vread      v1, a1, s9
    s.addi       s9, s6, #12
    s.addi       s17, s4, #6144                  // row 12
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s9
    s.movz       s9, #13
    v.cmp.lt     p1, v1, v4
    p.and        p5, p1, p3
    @p4 v.st.h       [s15, #0], v2
    a.vread      v1, a1, s11
    s.addi       s11, s6, #13
    s.addi       s15, s4, #6656                  // row 13
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s11
    s.movz       s11, #14
    v.splat      v3, s6
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p3
    v.cmp.lt     p1, v3, v4
    @p6 v.st.h       [s16, #0], v2
    a.vread      v1, a1, s7
    s.addi       s7, s6, #14
    s.addi       s16, s4, #7168                  // row 14
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s7
    s.movz       s7, #15
    s.addi       s18, s4, #7680                  // row 15
    v.cmp.lt     p6, v1, v4
    p.and        p7, p6, p3
    v.splat      v1, s2
    @p5 v.st.h       [s17, #0], v2
    a.vread      v2, a1, s9
    s.addi       s4, s6, #15
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s9, #0
    vf.cvt.f32.bf16 v3, v2
    v.splat      v2, s4
    s.add        s4, s9, s12                     // the tile origin
    v.cmp.lt     p5, v2, v4
    p.and        p6, p5, p3
    v.splat      v2, s4
    s.muli       s4, s12, #2                     // a runtime tile origin, x2
    v.add        v5, v0, v2
    @p4 v.st.h       [s15, #0], v3
    a.vread      v2, a1, s11
    s.muli       s11, s1, #512                   // a runtime tile origin, x512
    s.add        s15, s10, s4                    // the tile origin
    vf.cvt.f32.bf16 v3, v2
    v.cmp.lt     p4, v5, v1
    p.and        p5, p1, p4
    s.add        s4, s15, s11                    // the tile origin
    s.movz       s11, #1
    s.addi       s15, s6, #1
    v.splat      v1, s15
    s.addi       s15, s4, #512                   // row 1
    @p7 v.st.h       [s16, #0], v3
    a.vread      v2, a1, s7
    v.cmp.lt     p1, v1, v4
    p.and        p7, p1, p4
    vf.cvt.f32.bf16 v1, v2
    s.movz       s7, #2
    s.addi       s16, s6, #2
    v.splat      v2, s16
    s.addi       s16, s4, #1024                  // row 2
    @p6 v.st.h       [s18, #0], v1
    a.vread      v1, a2, s9
    v.cmp.lt     p1, v2, v4
    p.and        p6, p1, p4
    vf.cvt.f32.bf16 v2, v1
    s.movz       s9, #3
    s.addi       s17, s6, #3
    v.splat      v1, s17
    s.addi       s17, s4, #1536                  // row 3
    @p5 v.st.h       [s4, #0], v2
    a.vread      v2, a2, s11
    v.cmp.lt     p1, v1, v4
    p.and        p5, p1, p4
    vf.cvt.f32.bf16 v1, v2
    s.movz       s11, #4
    @p7 v.st.h       [s15, #0], v1
    a.vread      v1, a2, s7
    s.addi       s7, s6, #4
    s.addi       s15, s4, #2048                  // row 4
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s7
    s.movz       s7, #5
    v.cmp.lt     p1, v1, v4
    p.and        p7, p1, p4
    @p6 v.st.h       [s16, #0], v2
    a.vread      v1, a2, s9
    s.addi       s9, s6, #5
    s.addi       s16, s4, #2560                  // row 5
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s9
    s.movz       s9, #6
    v.cmp.lt     p1, v1, v4
    p.and        p6, p1, p4
    @p5 v.st.h       [s17, #0], v2
    a.vread      v1, a2, s11
    s.addi       s11, s6, #6
    s.addi       s17, s4, #3072                  // row 6
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s11
    s.movz       s11, #7
    v.cmp.lt     p1, v1, v4
    p.and        p5, p1, p4
    @p7 v.st.h       [s15, #0], v2
    a.vread      v1, a2, s7
    s.addi       s7, s6, #7
    s.addi       s15, s4, #3584                  // row 7
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s7
    s.movz       s7, #8
    v.cmp.lt     p1, v1, v4
    p.and        p7, p1, p4
    @p6 v.st.h       [s16, #0], v2
    a.vread      v1, a2, s9
    s.addi       s9, s6, #8
    s.addi       s16, s4, #4096                  // row 8
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s9
    s.movz       s9, #9
    v.cmp.lt     p1, v1, v4
    p.and        p6, p1, p4
    @p5 v.st.h       [s17, #0], v2
    a.vread      v1, a2, s11
    s.addi       s11, s6, #9
    s.addi       s17, s4, #4608                  // row 9
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s11
    s.movz       s11, #10
    v.cmp.lt     p1, v1, v4
    p.and        p5, p1, p4
    @p7 v.st.h       [s15, #0], v2
    a.vread      v1, a2, s7
    s.addi       s7, s6, #10
    s.addi       s15, s4, #5120                  // row 10
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s7
    s.movz       s7, #11
    v.cmp.lt     p1, v1, v4
    p.and        p7, p1, p4
    @p6 v.st.h       [s16, #0], v2
    a.vread      v1, a2, s9
    s.addi       s9, s6, #11
    s.addi       s16, s4, #5632                  // row 11
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s9
    s.movz       s9, #12
    v.cmp.lt     p1, v1, v4
    p.and        p6, p1, p4
    @p5 v.st.h       [s17, #0], v2
    a.vread      v1, a2, s11
    s.addi       s11, s6, #12
    s.addi       s17, s4, #6144                  // row 12
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s11
    s.movz       s11, #13
    v.cmp.lt     p1, v1, v4
    p.and        p5, p1, p4
    @p7 v.st.h       [s15, #0], v2
    a.vread      v1, a2, s7
    s.addi       s7, s6, #13
    s.addi       s15, s4, #6656                  // row 13
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s7
    s.movz       s7, #14
    s.muli       s18, s1, #512                   // a runtime tile origin, x512
    v.cmp.lt     p1, v1, v4
    p.and        p7, p1, p4
    v.splat      v1, s6
    @p6 v.st.h       [s16, #0], v2
    a.vread      v2, a2, s9
    s.addi       s1, s6, #14
    s.addi       s9, s4, #7168                   // row 14
    vf.cvt.f32.bf16 v3, v2
    v.splat      v2, s1
    s.movz       s1, #15
    s.addi       s16, s4, #7680                  // row 15
    v.cmp.lt     p1, v2, v4
    p.and        p6, p1, p4
    v.splat      v2, s2
    s.addi       s2, s6, #15
    v.splat      v5, s2
    @p5 v.st.h       [s17, #0], v3
    a.vread      v3, a2, s11
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s2, #0
    v.cmp.lt     p1, v5, v4
    vf.cvt.f32.bf16 v5, v3
    s.add        s4, s2, s13                     // the tile origin
    p.and        p5, p1, p4
    s.muli       s11, s13, #2                    // a runtime tile origin, x2
    v.splat      v3, s4
    s.movz       s4, #1
    v.add        v6, v0, v3
    s.add        s17, s10, s11                   // the tile origin
    @p7 v.st.h       [s15, #0], v5
    a.vread      v0, a2, s7
    v.cmp.lt     p1, v1, v4
    s.add        s7, s17, s18                    // the tile origin
    vf.cvt.f32.bf16 v1, v0
    s.addi       s11, s6, #1
    s.addi       s15, s7, #512                   // row 1
    v.splat      v0, s11
    s.movz       s11, #2
    s.addi       s17, s6, #2
    v.splat      v3, s17
    s.addi       s17, s7, #1024                  // row 2
    @p6 v.st.h       [s9, #0], v1
    a.vread      v1, a2, s1
    v.cmp.lt     p6, v6, v2
    p.and        p7, p1, p6
    vf.cvt.f32.bf16 v2, v1
    s.movz       s1, #3
    s.addi       s9, s6, #3
    v.splat      v1, s9
    s.addi       s9, s7, #1536                   // row 3
    @p5 v.st.h       [s16, #0], v2
    a.vread      v2, a3, s2
    v.cmp.lt     p1, v0, v4
    p.and        p5, p1, p6
    vf.cvt.f32.bf16 v0, v2
    s.movz       s2, #4
    s.addi       s16, s6, #4
    v.splat      v2, s16
    s.addi       s16, s7, #2048                  // row 4
    @p7 v.st.h       [s7, #0], v0
    a.vread      v0, a3, s4
    v.cmp.lt     p1, v3, v4
    p.and        p7, p1, p6
    vf.cvt.f32.bf16 v3, v0
    s.movz       s4, #5
    @p5 v.st.h       [s15, #0], v3
    a.vread      v0, a3, s11
    v.cmp.lt     p1, v1, v4
    p.and        p5, p1, p6
    vf.cvt.f32.bf16 v1, v0
    s.addi       s11, s6, #5
    s.addi       s15, s7, #2560                  // row 5
    v.splat      v0, s11
    s.movz       s11, #6
    @p7 v.st.h       [s17, #0], v1
    a.vread      v1, a3, s1
    v.cmp.lt     p1, v2, v4
    p.and        p7, p1, p6
    vf.cvt.f32.bf16 v2, v1
    s.addi       s1, s6, #6
    s.addi       s17, s7, #3072                  // row 6
    v.splat      v1, s1
    s.movz       s1, #7
    @p5 v.st.h       [s9, #0], v2
    a.vread      v2, a3, s2
    v.cmp.lt     p1, v0, v4
    p.and        p5, p1, p6
    vf.cvt.f32.bf16 v0, v2
    s.addi       s2, s6, #7
    s.addi       s9, s7, #3584                   // row 7
    v.splat      v2, s2
    s.movz       s2, #8
    @p7 v.st.h       [s16, #0], v0
    a.vread      v0, a3, s4
    v.cmp.lt     p1, v1, v4
    p.and        p7, p1, p6
    vf.cvt.f32.bf16 v1, v0
    s.addi       s4, s6, #8
    s.addi       s16, s7, #4096                  // row 8
    v.splat      v0, s4
    s.movz       s4, #9
    @p5 v.st.h       [s15, #0], v1
    a.vread      v1, a3, s11
    v.cmp.lt     p1, v2, v4
    p.and        p5, p1, p6
    vf.cvt.f32.bf16 v2, v1
    s.addi       s11, s6, #9
    s.addi       s15, s7, #4608                  // row 9
    v.splat      v1, s11
    s.movz       s11, #10
    @p7 v.st.h       [s17, #0], v2
    a.vread      v2, a3, s1
    v.cmp.lt     p1, v0, v4
    p.and        p7, p1, p6
    vf.cvt.f32.bf16 v0, v2
    s.addi       s1, s6, #10
    s.addi       s17, s7, #5120                  // row 10
    v.splat      v2, s1
    s.movz       s1, #11
    @p5 v.st.h       [s9, #0], v0
    a.vread      v0, a3, s2
    v.cmp.lt     p1, v1, v4
    p.and        p5, p1, p6
    vf.cvt.f32.bf16 v1, v0
    s.addi       s2, s6, #11
    s.addi       s9, s7, #5632                   // row 11
    v.splat      v0, s2
    s.movz       s2, #12
    @p7 v.st.h       [s16, #0], v1
    a.vread      v1, a3, s4
    v.cmp.lt     p1, v2, v4
    p.and        p7, p1, p6
    vf.cvt.f32.bf16 v2, v1
    s.addi       s4, s6, #12
    s.addi       s16, s7, #6144                  // row 12
    v.splat      v1, s4
    s.movz       s4, #13
    @p5 v.st.h       [s15, #0], v2
    a.vread      v2, a3, s11
    v.cmp.lt     p1, v0, v4
    p.and        p5, p1, p6
    vf.cvt.f32.bf16 v0, v2
    s.addi       s11, s6, #13
    s.addi       s15, s7, #6656                  // row 13
    v.splat      v2, s11
    s.movz       s11, #14
    s.muli       s18, s5, #2                     // a runtime tile origin, x2
    @p7 v.st.h       [s17, #0], v0
    a.vread      v0, a3, s1
    v.cmp.lt     p1, v1, v4
    p.and        p7, p1, p6
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s6, #14
    s.addi       s5, s7, #7168                   // row 14
    v.splat      v0, s1
    s.movz       s1, #15
    s.addi       s17, s6, #15
    s.addi       s6, s7, #7680                   // row 15
    v.splat      v3, s17
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s7, #0
    v.splat      v5, s3
    @p5 v.st.h       [s9, #0], v1
    a.vread      v1, a3, s2
    v.cmp.lt     p1, v2, v4
    p.and        p5, p1, p6
    vf.cvt.f32.bf16 v2, v1
    s.add        s2, s7, s14                     // the tile origin
    s.muli       s3, s14, #512                   // a runtime tile origin, x512
    v.splat      v1, s2
    s.add        s9, s10, s18                    // the tile origin
    s.movz       s17, #1
    s.add        s18, s9, s3                     // the tile origin
    s.addi       s3, s2, #1
    @p7 v.st.h       [s16, #0], v2
    a.vread      v2, a3, s4
    v.cmp.lt     p1, v0, v4
    p.and        p7, p1, p6
    vf.cvt.f32.bf16 v0, v2
    v.splat      v2, s3
    s.addi       s3, s18, #512                   // row 1
    s.movz       s4, #2
    s.addi       s9, s2, #2
    v.splat      v6, s9
    s.addi       s9, s18, #1024                  // row 2
    @p5 v.st.h       [s15, #0], v0
    a.vread      v0, a3, s11
    v.cmp.lt     p1, v3, v4
    p.and        p5, p1, p6
    vf.cvt.f32.bf16 v3, v0
    s.movz       s11, #3
    s.addi       s15, s2, #3
    v.splat      v0, s15
    s.addi       s15, s18, #1536                 // row 3
    @p7 v.st.h       [s5, #0], v3
    a.vread      v3, a3, s1
    v.cmp.lt     p1, v1, v5
    p.and        p7, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.movz       s1, #4
    s.addi       s5, s2, #4
    v.splat      v3, s5
    s.addi       s5, s18, #2048                  // row 4
    @p5 v.st.h       [s6, #0], v1
    a.vread      v1, a4, s7
    v.cmp.lt     p1, v2, v5
    p.and        p5, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.movz       s6, #5
    s.addi       s7, s2, #5
    v.splat      v1, s7
    s.addi       s7, s18, #2560                  // row 5
    @p7 v.st.h       [s18, #0], v2
    a.vread      v2, a4, s17
    v.cmp.lt     p1, v6, v5
    p.and        p7, p1, p2
    vf.cvt.f32.bf16 v4, v2
    s.movz       s16, #6
    @p5 v.st.h       [s3, #0], v4
    a.vread      v2, a4, s4
    v.cmp.lt     p1, v0, v5
    p.and        p5, p1, p2
    vf.cvt.f32.bf16 v0, v2
    s.addi       s3, s2, #6
    s.addi       s4, s18, #3072                  // row 6
    v.splat      v2, s3
    s.movz       s3, #7
    @p7 v.st.h       [s9, #0], v0
    a.vread      v0, a4, s11
    v.cmp.lt     p1, v3, v5
    p.and        p7, p1, p2
    vf.cvt.f32.bf16 v3, v0
    s.addi       s9, s2, #7
    s.addi       s11, s18, #3584                 // row 7
    v.splat      v0, s9
    s.movz       s9, #8
    @p5 v.st.h       [s15, #0], v3
    a.vread      v3, a4, s1
    v.cmp.lt     p1, v1, v5
    p.and        p5, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s1, s2, #8
    s.addi       s15, s18, #4096                 // row 8
    v.splat      v3, s1
    s.movz       s1, #9
    @p7 v.st.h       [s5, #0], v1
    a.vread      v1, a4, s6
    v.cmp.lt     p1, v2, v5
    p.and        p7, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s5, s2, #9
    s.addi       s6, s18, #4608                  // row 9
    v.splat      v1, s5
    s.movz       s5, #10
    @p5 v.st.h       [s7, #0], v2
    a.vread      v2, a4, s16
    v.cmp.lt     p1, v0, v5
    p.and        p5, p1, p2
    vf.cvt.f32.bf16 v0, v2
    s.addi       s7, s2, #10
    s.addi       s16, s18, #5120                 // row 10
    v.splat      v2, s7
    s.movz       s7, #11
    @p7 v.st.h       [s4, #0], v0
    a.vread      v0, a4, s3
    v.cmp.lt     p1, v3, v5
    p.and        p7, p1, p2
    vf.cvt.f32.bf16 v3, v0
    s.addi       s3, s2, #11
    s.addi       s4, s18, #5632                  // row 11
    v.splat      v0, s3
    s.movz       s3, #12
    @p5 v.st.h       [s11, #0], v3
    a.vread      v3, a4, s9
    v.cmp.lt     p1, v1, v5
    p.and        p5, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s9, s2, #12
    s.addi       s11, s18, #6144                 // row 12
    v.splat      v3, s9
    s.movz       s9, #13
    @p7 v.st.h       [s15, #0], v1
    a.vread      v1, a4, s1
    v.cmp.lt     p1, v2, v5
    p.and        p7, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s1, s2, #13
    s.addi       s15, s18, #6656                 // row 13
    v.splat      v1, s1
    s.movz       s1, #14
    @p5 v.st.h       [s6, #0], v2
    a.vread      v2, a4, s5
    v.cmp.lt     p1, v0, v5
    p.and        p5, p1, p2
    vf.cvt.f32.bf16 v0, v2
    s.addi       s5, s2, #14
    s.addi       s6, s18, #7168                  // row 14
    v.splat      v2, s5
    s.movz       s5, #15
    s.addi       s17, s18, #7680                 // row 15
    s.muli       s18, s8, #2                     // a runtime tile origin, x2
    @p7 v.st.h       [s16, #0], v0
    a.vread      v0, a4, s7
    v.cmp.lt     p1, v3, v5
    p.and        p7, p1, p2
    vf.cvt.f32.bf16 v3, v0
    s.addi       s7, s2, #15
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s8, #0
    v.splat      v0, s7
    s.muli       s7, s14, #512                   // a runtime tile origin, x512
    v.splat      v4, s2
    s.add        s16, s10, s18                   // the tile origin
    s.add        s18, s16, s7                    // the tile origin
    @p5 v.st.h       [s4, #0], v3
    a.vread      v3, a4, s3
    v.cmp.lt     p1, v1, v5
    p.and        p5, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.movz       s3, #1
    s.addi       s4, s2, #1
    s.addi       s7, s18, #512                   // row 1
    v.splat      v3, s4
    @p7 v.st.h       [s11, #0], v1
    a.vread      v1, a4, s9
    v.cmp.lt     p1, v2, v5
    p.and        p7, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.movz       s4, #2
    s.addi       s9, s2, #2
    s.addi       s11, s18, #1024                 // row 2
    v.splat      v1, s9
    @p5 v.st.h       [s15, #0], v2
    a.vread      v2, a4, s1
    v.cmp.lt     p1, v0, v5
    p.and        p5, p1, p2
    vf.cvt.f32.bf16 v0, v2
    v.cmp.lt     p1, v4, v5
    p.and        p2, p1, p3
    s.movz       s1, #3
    s.addi       s9, s2, #3
    s.addi       s15, s18, #1536                 // row 3
    v.splat      v2, s9
    @p7 v.st.h       [s6, #0], v0
    a.vread      v0, a4, s5
    v.cmp.lt     p1, v3, v5
    p.and        p7, p1, p3
    vf.cvt.f32.bf16 v3, v0
    s.movz       s5, #4
    s.addi       s6, s2, #4
    s.addi       s9, s18, #2048                  // row 4
    v.splat      v0, s6
    @p5 v.st.h       [s17, #0], v3
    a.vread      v3, a5, s8
    v.cmp.lt     p1, v1, v5
    p.and        p5, p1, p3
    vf.cvt.f32.bf16 v1, v3
    s.movz       s6, #5
    s.addi       s8, s2, #5
    s.addi       s16, s18, #2560                 // row 5
    v.splat      v3, s8
    s.movz       s8, #6
    @p2 v.st.h       [s18, #0], v1
    a.vread      v1, a5, s3
    v.cmp.lt     p1, v2, v5
    p.and        p2, p1, p3
    vf.cvt.f32.bf16 v2, v1
    s.addi       s3, s2, #6
    v.splat      v1, s3
    s.addi       s3, s18, #3072                  // row 6
    @p7 v.st.h       [s7, #0], v2
    a.vread      v2, a5, s4
    v.cmp.lt     p1, v0, v5
    p.and        p7, p1, p3
    vf.cvt.f32.bf16 v0, v2
    s.movz       s4, #7
    s.addi       s7, s2, #7
    v.splat      v2, s7
    s.addi       s7, s18, #3584                  // row 7
    @p5 v.st.h       [s11, #0], v0
    a.vread      v0, a5, s1
    v.cmp.lt     p1, v3, v5
    p.and        p5, p1, p3
    vf.cvt.f32.bf16 v3, v0
    s.movz       s1, #8
    s.addi       s11, s2, #8
    v.splat      v0, s11
    s.addi       s11, s18, #4096                 // row 8
    @p2 v.st.h       [s15, #0], v3
    a.vread      v3, a5, s5
    v.cmp.lt     p1, v1, v5
    p.and        p2, p1, p3
    vf.cvt.f32.bf16 v1, v3
    s.movz       s5, #9
    s.addi       s15, s2, #9
    v.splat      v3, s15
    s.addi       s15, s18, #4608                 // row 9
    @p7 v.st.h       [s9, #0], v1
    a.vread      v1, a5, s6
    v.cmp.lt     p1, v2, v5
    p.and        p7, p1, p3
    vf.cvt.f32.bf16 v2, v1
    s.movz       s6, #10
    s.addi       s9, s2, #10
    v.splat      v1, s9
    s.addi       s9, s18, #5120                  // row 10
    @p5 v.st.h       [s16, #0], v2
    a.vread      v2, a5, s8
    v.cmp.lt     p1, v0, v5
    p.and        p5, p1, p3
    vf.cvt.f32.bf16 v0, v2
    s.movz       s8, #11
    s.addi       s16, s2, #11
    v.splat      v2, s16
    s.addi       s16, s18, #5632                 // row 11
    @p2 v.st.h       [s3, #0], v0
    a.vread      v0, a5, s4
    v.cmp.lt     p1, v3, v5
    p.and        p2, p1, p3
    vf.cvt.f32.bf16 v3, v0
    s.movz       s3, #12
    s.addi       s4, s2, #12
    v.splat      v0, s4
    s.addi       s4, s18, #6144                  // row 12
    @p7 v.st.h       [s7, #0], v3
    a.vread      v3, a5, s1
    v.cmp.lt     p1, v1, v5
    p.and        p7, p1, p3
    vf.cvt.f32.bf16 v1, v3
    s.movz       s1, #13
    s.addi       s7, s2, #13
    v.splat      v3, s7
    s.addi       s7, s18, #6656                  // row 13
    @p5 v.st.h       [s11, #0], v1
    a.vread      v1, a5, s5
    v.cmp.lt     p1, v2, v5
    p.and        p5, p1, p3
    vf.cvt.f32.bf16 v2, v1
    s.movz       s5, #14
    s.addi       s11, s2, #14
    v.splat      v1, s11
    s.addi       s11, s18, #7168                 // row 14
    @p2 v.st.h       [s15, #0], v2
    a.vread      v2, a5, s6
    v.cmp.lt     p1, v0, v5
    p.and        p2, p1, p3
    vf.cvt.f32.bf16 v0, v2
    s.movz       s6, #15
    s.addi       s15, s2, #15
    s.addi       s17, s18, #7680                 // row 15
    v.splat      v2, s15
    s.muli       s15, s12, #2                    // a runtime tile origin, x2
    @p7 v.st.h       [s9, #0], v0
    a.vread      v0, a5, s8
    v.cmp.lt     p1, v3, v5
    p.and        p7, p1, p3
    vf.cvt.f32.bf16 v3, v0
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s8, #0
    s.muli       s9, s14, #512                   // a runtime tile origin, x512
    v.splat      v0, s2
    s.add        s12, s10, s15                   // the tile origin
    s.add        s15, s12, s9                    // the tile origin
    @p5 v.st.h       [s16, #0], v3
    a.vread      v3, a5, s3
    v.cmp.lt     p1, v1, v5
    p.and        p5, p1, p3
    vf.cvt.f32.bf16 v1, v3
    s.movz       s3, #1
    s.addi       s9, s2, #1
    s.addi       s12, s15, #512                  // row 1
    v.splat      v3, s9
    @p2 v.st.h       [s4, #0], v1
    a.vread      v1, a5, s1
    v.cmp.lt     p1, v2, v5
    p.and        p2, p1, p3
    vf.cvt.f32.bf16 v2, v1
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p4
    s.movz       s1, #2
    s.addi       s4, s2, #2
    s.addi       s9, s15, #1024                  // row 2
    v.splat      v0, s4
    @p7 v.st.h       [s7, #0], v2
    a.vread      v1, a5, s5
    v.cmp.lt     p1, v3, v5
    p.and        p7, p1, p4
    vf.cvt.f32.bf16 v2, v1
    s.movz       s4, #3
    s.addi       s5, s2, #3
    s.addi       s7, s15, #1536                  // row 3
    v.splat      v1, s5
    @p5 v.st.h       [s11, #0], v2
    a.vread      v2, a5, s6
    v.cmp.lt     p1, v0, v5
    p.and        p5, p1, p4
    vf.cvt.f32.bf16 v0, v2
    s.movz       s5, #4
    s.addi       s6, s2, #4
    s.addi       s11, s15, #2048                 // row 4
    v.splat      v2, s6
    @p2 v.st.h       [s17, #0], v0
    a.vread      v0, a6, s8
    v.cmp.lt     p1, v1, v5
    p.and        p2, p1, p4
    vf.cvt.f32.bf16 v1, v0
    s.movz       s6, #5
    s.addi       s8, s2, #5
    s.addi       s16, s15, #2560                 // row 5
    v.splat      v0, s8
    s.movz       s8, #6
    @p3 v.st.h       [s15, #0], v1
    a.vread      v1, a6, s3
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p4
    vf.cvt.f32.bf16 v2, v1
    s.addi       s3, s2, #6
    s.addi       s17, s15, #3072                 // row 6
    v.splat      v1, s3
    s.movz       s3, #7
    @p7 v.st.h       [s12, #0], v2
    a.vread      v2, a6, s1
    v.cmp.lt     p1, v0, v5
    p.and        p7, p1, p4
    vf.cvt.f32.bf16 v0, v2
    s.addi       s1, s2, #7
    s.addi       s12, s15, #3584                 // row 7
    v.splat      v2, s1
    s.movz       s1, #8
    @p5 v.st.h       [s9, #0], v0
    a.vread      v0, a6, s4
    v.cmp.lt     p1, v1, v5
    p.and        p5, p1, p4
    vf.cvt.f32.bf16 v1, v0
    s.addi       s4, s2, #8
    s.addi       s9, s15, #4096                  // row 8
    v.splat      v0, s4
    s.movz       s4, #9
    @p2 v.st.h       [s7, #0], v1
    a.vread      v1, a6, s5
    v.cmp.lt     p1, v2, v5
    p.and        p2, p1, p4
    vf.cvt.f32.bf16 v2, v1
    s.addi       s5, s2, #9
    s.addi       s7, s15, #4608                  // row 9
    v.splat      v1, s5
    s.movz       s5, #10
    @p3 v.st.h       [s11, #0], v2
    a.vread      v2, a6, s6
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p4
    vf.cvt.f32.bf16 v0, v2
    s.addi       s6, s2, #10
    s.addi       s11, s15, #5120                 // row 10
    v.splat      v2, s6
    s.movz       s6, #11
    @p7 v.st.h       [s16, #0], v0
    a.vread      v0, a6, s8
    v.cmp.lt     p1, v1, v5
    p.and        p7, p1, p4
    vf.cvt.f32.bf16 v1, v0
    s.addi       s8, s2, #11
    s.addi       s16, s15, #5632                 // row 11
    v.splat      v0, s8
    s.movz       s8, #12
    @p5 v.st.h       [s17, #0], v1
    a.vread      v1, a6, s3
    v.cmp.lt     p1, v2, v5
    p.and        p5, p1, p4
    vf.cvt.f32.bf16 v2, v1
    s.addi       s3, s2, #12
    s.addi       s17, s15, #6144                 // row 12
    v.splat      v1, s3
    s.movz       s3, #13
    @p2 v.st.h       [s12, #0], v2
    a.vread      v2, a6, s1
    v.cmp.lt     p1, v0, v5
    p.and        p2, p1, p4
    vf.cvt.f32.bf16 v0, v2
    s.addi       s1, s2, #13
    s.addi       s12, s15, #6656                 // row 13
    v.splat      v2, s1
    s.movz       s1, #14
    @p3 v.st.h       [s9, #0], v0
    a.vread      v0, a6, s4
    v.cmp.lt     p1, v1, v5
    p.and        p3, p1, p4
    vf.cvt.f32.bf16 v1, v0
    s.addi       s4, s2, #14
    s.addi       s9, s15, #7168                  // row 14
    v.splat      v0, s4
    s.movz       s4, #15
    @p7 v.st.h       [s7, #0], v1
    a.vread      v1, a6, s5
    v.cmp.lt     p1, v2, v5
    p.and        p7, p1, p4
    vf.cvt.f32.bf16 v2, v1
    s.addi       s5, s2, #15
    s.addi       s7, s15, #7680                  // row 15
    v.splat      v1, s5
    s.muli       s5, s13, #2                     // a runtime tile origin, x2
    s.add        s13, s10, s5                    // the tile origin
    @p5 v.st.h       [s11, #0], v2
    a.vread      v2, a6, s6
    v.cmp.lt     p1, v0, v5
    p.and        p5, p1, p4
    vf.cvt.f32.bf16 v0, v2
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s5, #0
    s.muli       s6, s14, #512                   // a runtime tile origin, x512
    v.splat      v2, s2
    s.add        s10, s13, s6                    // the tile origin
    @p2 v.st.h       [s16, #0], v0
    a.vread      v0, a6, s8
    v.cmp.lt     p1, v1, v5
    p.and        p2, p1, p4
    vf.cvt.f32.bf16 v1, v0
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p6
    s.movz       s6, #1
    s.addi       s8, s2, #1
    s.addi       s11, s10, #512                  // row 1
    v.splat      v0, s8
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a6, s3
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p6
    vf.cvt.f32.bf16 v0, v1
    s.movz       s3, #2
    s.addi       s8, s2, #2
    s.addi       s13, s10, #1024                 // row 2
    v.splat      v1, s8
    @p7 v.st.h       [s12, #0], v0
    a.vread      v0, a6, s1
    v.cmp.lt     p1, v1, v5
    p.and        p7, p1, p6
    vf.cvt.f32.bf16 v1, v0
    s.movz       s1, #3
    s.addi       s8, s2, #3
    s.addi       s12, s10, #1536                 // row 3
    v.splat      v0, s8
    @p5 v.st.h       [s9, #0], v1
    a.vread      v1, a6, s4
    v.cmp.lt     p1, v0, v5
    p.and        p5, p1, p6
    vf.cvt.f32.bf16 v0, v1
    s.movz       s4, #4
    s.addi       s8, s2, #4
    s.addi       s9, s10, #2048                  // row 4
    v.splat      v1, s8
    @p2 v.st.h       [s7, #0], v0
    a.vread      v0, a7, s5
    v.cmp.lt     p1, v1, v5
    p.and        p2, p1, p6
    vf.cvt.f32.bf16 v1, v0
    s.movz       s5, #5
    s.addi       s7, s2, #5
    s.addi       s8, s10, #2560                  // row 5
    v.splat      v0, s7
    s.movz       s7, #6
    @p4 v.st.h       [s10, #0], v1
    a.vread      v1, a7, s6
    v.cmp.lt     p1, v0, v5
    p.and        p4, p1, p6
    vf.cvt.f32.bf16 v0, v1
    s.addi       s6, s2, #6
    s.addi       s14, s10, #3072                 // row 6
    v.splat      v1, s6
    s.movz       s6, #7
    @p3 v.st.h       [s11, #0], v0
    a.vread      v0, a7, s3
    v.cmp.lt     p1, v1, v5
    p.and        p3, p1, p6
    vf.cvt.f32.bf16 v1, v0
    s.addi       s3, s2, #7
    s.addi       s11, s10, #3584                 // row 7
    v.splat      v0, s3
    s.movz       s3, #8
    @p7 v.st.h       [s13, #0], v1
    a.vread      v1, a7, s1
    v.cmp.lt     p1, v0, v5
    p.and        p7, p1, p6
    vf.cvt.f32.bf16 v0, v1
    s.addi       s1, s2, #8
    s.addi       s13, s10, #4096                 // row 8
    v.splat      v1, s1
    s.movz       s1, #9
    @p5 v.st.h       [s12, #0], v0
    a.vread      v0, a7, s4
    v.cmp.lt     p1, v1, v5
    p.and        p5, p1, p6
    vf.cvt.f32.bf16 v1, v0
    s.addi       s4, s2, #9
    s.addi       s12, s10, #4608                 // row 9
    v.splat      v0, s4
    s.movz       s4, #10
    @p2 v.st.h       [s9, #0], v1
    a.vread      v1, a7, s5
    v.cmp.lt     p1, v0, v5
    p.and        p2, p1, p6
    vf.cvt.f32.bf16 v0, v1
    s.addi       s5, s2, #10
    s.addi       s9, s10, #5120                  // row 10
    v.splat      v1, s5
    s.movz       s5, #11
    @p4 v.st.h       [s8, #0], v0
    a.vread      v0, a7, s7
    v.cmp.lt     p1, v1, v5
    p.and        p4, p1, p6
    vf.cvt.f32.bf16 v1, v0
    s.addi       s7, s2, #11
    s.addi       s8, s10, #5632                  // row 11
    v.splat      v0, s7
    s.movz       s7, #12
    @p3 v.st.h       [s14, #0], v1
    a.vread      v1, a7, s6
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p6
    vf.cvt.f32.bf16 v0, v1
    s.addi       s6, s2, #12
    s.addi       s14, s10, #6144                 // row 12
    v.splat      v1, s6
    s.movz       s6, #13
    @p7 v.st.h       [s11, #0], v0
    a.vread      v0, a7, s3
    v.cmp.lt     p1, v1, v5
    p.and        p7, p1, p6
    vf.cvt.f32.bf16 v1, v0
    s.addi       s3, s2, #13
    s.addi       s11, s10, #6656                 // row 13
    v.splat      v0, s3
    s.movz       s3, #14
    @p5 v.st.h       [s13, #0], v1
    a.vread      v1, a7, s1
    v.cmp.lt     p1, v0, v5
    p.and        p5, p1, p6
    vf.cvt.f32.bf16 v0, v1
    s.addi       s1, s2, #14
    s.addi       s13, s10, #7168                 // row 14
    v.splat      v1, s1
    s.movz       s1, #15
    @p2 v.st.h       [s12, #0], v0
    a.vread      v0, a7, s4
    v.cmp.lt     p1, v1, v5
    p.and        p2, p1, p6
    vf.cvt.f32.bf16 v1, v0
    s.addi       s4, s2, #15
    s.addi       s2, s10, #7680                  // row 15
    v.splat      v0, s4
    @p4 v.st.h       [s9, #0], v1
    a.vread      v1, a7, s5
    v.cmp.lt     p1, v0, v5
    p.and        p4, p1, p6
    vf.cvt.f32.bf16 v0, v1
    @p3 v.st.h       [s8, #0], v0
    a.vread      v0, a7, s7
    vf.cvt.f32.bf16 v1, v0
    @p7 v.st.h       [s14, #0], v1
    a.vread      v0, a7, s6
    vf.cvt.f32.bf16 v1, v0
    @p5 v.st.h       [s11, #0], v1
    a.vread      v0, a7, s3
    vf.cvt.f32.bf16 v1, v0
    @p2 v.st.h       [s13, #0], v1
    a.vread      v0, a7, s1
    vf.cvt.f32.bf16 v1, v0
    @p4 v.st.h       [s2, #0], v1
    exit
    exit
