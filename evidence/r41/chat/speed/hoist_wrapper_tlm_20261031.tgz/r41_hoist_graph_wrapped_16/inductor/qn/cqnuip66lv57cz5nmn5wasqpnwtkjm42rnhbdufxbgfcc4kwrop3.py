

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[],
    inductor_meta={'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'declared_constexpr_names': ['BLOCK'], 'kernel_name': '_precise_block_quant_0', 'backend_hash': 'A93B31D6EDF73560C15AA73ED6DE7E8C6F4FC7BA4A2D9DB4959968968952E588', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    triton_meta={'signature': {'X': '*bf16', 'Y': '*fp8e4nv', 'S': '*fp32', 'BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'BLOCK': 128}, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def _precise_block_quant(X, Y, S, BLOCK: tl.constexpr):
    p = tl.program_id(0)
    i = p * BLOCK + tl.arange(0, BLOCK)
    x = tl.load(X + i).to(tl.float32)
    scale = tl.div_rn(tl.max(tl.abs(x), axis=0), 448.0)
    q = tl.div_rn(x, tl.maximum(scale, 1e-12)).to(tl.float8e4nv)
    tl.store(Y + i, q)
    tl.store(S + p, scale)
