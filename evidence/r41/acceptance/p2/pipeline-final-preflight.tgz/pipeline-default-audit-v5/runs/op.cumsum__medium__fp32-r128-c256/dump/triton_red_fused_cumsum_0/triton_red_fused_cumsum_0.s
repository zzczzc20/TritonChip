    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    .li       s1, #2143289344
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v1, #0
    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s5, #256
    s.movz       s6, #16
    v.splat      v2, s4
    v.iota       v2                              // arange(0, VLEN)
    s.addi       s7, s2, #0
    s.ld.d       s8, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.mov        v1, v0
for_1:
    s.cmp.ge     s1, s7, s5
    br.nz        s1, endfor_2
    s.mul        s1, s4, s5
    v.splat      v0, s7
    v.movi       v3, #256
    v.add        v4, v0, v2
    s.add        s9, s7, s1
    v.splat      v0, s1
    s.shli       s1, s9, #2                      // element offset -> bytes (x4)
    v.cmp.lt     p1, v4, v3
    s.add        s9, s3, s1                      // &in_ptr0[...]
    v.add        v3, v4, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v0, [s9, #0]
    v.movi       v3, #0
    v.extract    s9, v0, #0
    v.extract    s10, v0, #1
    v.splat      v4, s9
    v.splat      v5, s10
    v.extract    s9, v0, #2
    v.extract    s10, v0, #3
    vf.add       v6, v4, v5
    v.splat      v5, s9
    v.splat      v7, s10
    v.extract    s9, v0, #4
    v.extract    s10, v0, #5
    vf.add       v8, v6, v5
    v.splat      v5, s9
    v.splat      v9, s10
    v.extract    s9, v0, #6
    v.extract    s10, v0, #7
    vf.add       v10, v8, v7
    v.splat      v7, s9
    v.splat      v11, s10
    v.extract    s9, v0, #8
    // one value per row into one vector (ISA 0x09)
    v.extract    s10, v4, #0
    vf.add       v4, v10, v5
    v.splat      v5, s9
    v.insert     v3, s10, #0
    v.extract    s9, v6, #0
    v.extract    s10, v0, #9
    vf.add       v6, v4, v9
    v.insert     v3, s9, #1
    v.extract    s9, v8, #0
    v.splat      v8, s10
    v.insert     v3, s9, #2
    vf.add       v9, v6, v7
    v.extract    s9, v10, #0
    v.extract    s10, v0, #10
    v.insert     v3, s9, #3
    v.splat      v7, s10
    vf.add       v10, v9, v11
    v.extract    s9, v4, #0
    v.extract    s10, v0, #11
    v.insert     v3, s9, #4
    v.extract    s9, v6, #0
    vf.add       v4, v10, v5
    v.splat      v5, s10
    v.insert     v3, s9, #5
    v.extract    s9, v9, #0
    v.extract    s10, v0, #12
    vf.add       v6, v4, v8
    v.insert     v3, s9, #6
    v.extract    s9, v10, #0
    v.splat      v8, s10
    v.insert     v3, s9, #7
    vf.add       v9, v6, v7
    v.extract    s9, v4, #0
    v.extract    s10, v0, #13
    v.insert     v3, s9, #8
    v.splat      v4, s10
    vf.add       v7, v9, v5
    v.extract    s9, v6, #0
    v.extract    s10, v0, #14
    v.insert     v3, s9, #9
    v.extract    s9, v9, #0
    vf.add       v5, v7, v8
    v.splat      v6, s10
    v.insert     v3, s9, #10
    v.extract    s9, v7, #0
    v.extract    s10, v0, #15
    vf.add       v0, v5, v4
    v.insert     v3, s9, #11
    v.extract    s9, v5, #0
    v.splat      v4, s10
    v.insert     v3, s9, #12
    vf.add       v5, v0, v6
    v.extract    s9, v0, #0
    v.movi       v0, #15
    v.insert     v3, s9, #13
    v.movi       v6, #1
    vf.add       v7, v5, v4
    v.extract    s9, v5, #0
    v.movi       v4, #0
    v.insert     v3, s9, #14
    v.cmp.eq     p2, v2, v0
    v.extract    s9, v7, #0
    @p2 v.sel        v0, v6, v4
    v.insert     v3, s9, #15
    v.extract    s9, v1, #0
    v.splat      v4, s7
    v.mul        v5, v3, v0
    v.splat      v0, s9
    v.splat      v6, s2
    v.reduce.add s9, v5
    vf.add       v5, v0, v3
    v.splat      v0, s9
    v.cmp.gt     p2, v4, v6
    v.movi       v4, #0
    vf.add       v6, v1, v0
    @p2 v.sel        v7, v5, v3
    s.add        s9, s8, s1                      // &out_ptr0[...]
    s.add        s1, s7, s6
    @p1 v.st.w       [s9, #0], v7
    @p2 v.sel        v3, v6, v0
    s.movz       s9, #1
    v.mov        v4, v3
    v.mov        v1, v4
    s.mov        s7, s1
    br.nz        s9, for_1
endfor_2:
__rctx_next:
    exit
