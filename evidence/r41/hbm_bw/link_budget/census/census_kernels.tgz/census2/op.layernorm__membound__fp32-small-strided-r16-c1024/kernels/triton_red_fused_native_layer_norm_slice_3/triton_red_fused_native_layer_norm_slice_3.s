    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.rdspecial  s2, arg_base
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s5, #0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s5
    s.rdspecial  s6, role_id
    s.movz       s7, #256
    v.add        v2, v1, v0
    v.movi       v0, #0
    v.splat      v1, s4
    v.movi       v3, #0
    s.mul        s8, s6, s7
    s.ld.d       s6, [s2, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.muli       s2, s4, #32
    v.cmp.ge     p1, v2, v0
    v.cmpi.lt    p2, v2, #8
    v.cmp.ge     p3, v1, v3
    v.cmpi.lt    p4, v1, #16
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    s.add        s7, s3, s2
    p.and        p2, p5, p1
    s.add        s2, s6, s8                      // this context's own scratch
    v.cmpi.lt    p1, v0, #8
    s.addi       s6, s2, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s2, #16
    s.movz       s8, #8
    s.movz       s9, #32
    s.movz       s10, #4
    s.add        s11, s7, s5
    .li       s5, #34359738369
    p.and        p3, p1, p2
    s.ld.d       s7, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.movi       v0, #0
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v2, #8
    v.iota       v3                              // arange(0, VLEN)
    v.movi       v4, #0
    v.cmp.lt     p1, v1, v2
    v.cmpi.lt    p2, v3, #8
    s.shli       s1, s4, #2                      // element offset -> bytes (x4)
    s.st.d       [s6, #0], s3
    .li       s3, #2207613190144
    v.iota       v1                              // arange(0, VLEN)
    s.add        s4, s7, s1                      // &out_ptr0[...]
    v.cmpi.lt    p4, v1, #1
    s.st.d       [s6, #8], s2
    s.st.d       [s6, #16], s8
    s.st.d       [s6, #48], s9
    s.st.d       [s6, #56], s10
    s.st.d       [s6, #88], s5
    s.st.d       [s6, #104], s3
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s11, #0]
    vf.add       v2, v1, v0
    @p1 v.sel        v1, v2, v0
    @p2 vf.reduce.add.b v0, v1
    vf.add       v1, v0, v4
    @p4 v.st.w       [s4, #0], v1
__rctx_next:
    exit
