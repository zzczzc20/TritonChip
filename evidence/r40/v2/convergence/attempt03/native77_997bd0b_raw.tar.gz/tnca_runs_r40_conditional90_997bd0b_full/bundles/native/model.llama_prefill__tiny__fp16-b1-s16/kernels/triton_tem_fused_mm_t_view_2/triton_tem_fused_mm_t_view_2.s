    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.rdspecial  s2, arg_base
    s.ld.d       s3, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s5, #512
    .li       s6, #2147483647
    s.mul        s7, s1, s5
    .li       s1, #2147483647
    s.movz       s5, #128
    s.movz       s8, #2
    .li       s9, #68719476752
    .li       s10, #8589934592
    s.rdspecial  s11, arg_base
    s.ld.d       s12, [s2, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.add        s13, s3, s7                     // this context's own scratch
    s.rdspecial  s3, role_id
    s.addi       s7, s13, #0                     // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.movz       s13, #512
    .li       s14, #2147483647
    s.mul        s15, s3, s13
    .li       s3, #2147483647
    s.movz       s13, #128
    s.movz       s16, #2
    .li       s17, #68719476752
    s.ld.d       s18, [s2, #8]                   // arg_B: device_ptr64 at arg_base+8
    s.movz       s19, #2
    .li       s20, #8589934592
    s.movz       s21, #0
    s.movz       s21, #0
    s.ld.d       s21, [s2, #16]                  // out_ptr0: device_ptr64 at arg_base+16
    s.st.d       [s7, #0], s12
    s.movz       s2, #0
    s.st.d       [s7, #8], s6
    s.movz       s6, #0
    s.st.d       [s7, #16], s1
    s.movz       s1, #0
    s.cmp.lt     s12, s19, s1
    s.st.d       [s7, #48], s5
    s.cmp.lt     s1, s4, s2
    s.movz       s2, #0
    s.sub        s5, s2, s12
    s.movz       s2, #1
    s.st.d       [s7, #56], s8
    s.sub        s8, s6, s1
    s.movz       s1, #0
    s.xor        s6, s4, s8
    s.st.d       [s7, #88], s9
    s.sub        s9, s6, s8
    s.movz       s6, #0
    s.st.d       [s7, #104], s10
    s.lshri      s10, s9, #1
    fence.release.device
    td.load      d0, [s7]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.xor        s7, s8, s5
    s.movz       s8, #0
    s.ld.d       s12, [s11, #24]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.cmp.lt     s11, s4, s6
    s.add        s6, s12, s15                    // this context's own scratch
    s.xor        s12, s10, s7
    s.muli       s15, s10, #2
    s.sub        s10, s12, s7
    s.movz       s7, #0
    s.addi       s12, s6, #256                   // TensorMap 1: a tile contiguous down its columns (built once, at entry)
    s.sub        s6, s7, s11
    s.sub        s7, s2, s10
    s.st.d       [s12, #0], s18
    s.min.s      s11, s7, s2
    s.movz       s7, #0
    s.cmp.lt     s18, s11, s1
    s.sub        s1, s9, s15
    s.sub        s1, s8, s18
    s.movz       s8, #1
    s.xor        s9, s4, s6
    s.xor        s15, s19, s5
    s.sub        s18, s9, s6
    s.sub        s9, s15, s5
    s.movz       s5, #0
    s.st.d       [s12, #8], s14
    s.xor        s9, s11, s1
    s.sub        s14, s9, s1
    s.st.d       [s12, #16], s3
    s.addi       s1, s7, #0
    s.addi       s3, s5, #0
    s.st.d       [s12, #48], s13
    s.cmp.eq     s5, s14, s8
    s.st.d       [s12, #56], s16
    s.st.d       [s12, #88], s17
    s.st.d       [s12, #104], s20
    fence.release.device
    td.load      d1, [s12]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.mov        s1, s18
    br.nz        s5, sdiv_done_1
    s.movz       s5, #0
    s.movz       s7, #31
    s.mov        s1, s5
    s.addi       s5, s7, #0
sdiv_2:
    s.lshr       s7, s18, s5
    s.shli       s8, s3, #1
    s.andi       s9, s7, #1
    s.movz       s7, #0
    s.or         s12, s8, s9
    s.movz       s8, #1
    s.cmp.geu    s9, s12, s14
    s.shl        s13, s8, s5
    s.sub        s8, s7, s9
    s.subi       s7, s5, #1
    s.and        s9, s14, s8
    s.and        s15, s13, s8
    s.sub        s8, s12, s9
    s.or         s9, s1, s15
    s.mov        s3, s8
    s.mov        s1, s9
    s.mov        s5, s7
    s.movz       s7, #0
    s.cmp.ge     s8, s5, s7
    br.nz        s8, sdiv_2
sdiv_done_1:
    s.movz       s1, #0
    s.movz       s5, #0
    s.cmp.lt     s7, s4, s1
    s.movz       s1, #0
    s.sub        s8, s5, s7
    s.movz       s5, #0
    s.xor        s7, s4, s8
    s.movz       s4, #0
    s.sub        s9, s7, s8
    s.cmp.lt     s7, s11, s1
    s.lshri      s1, s9, #1
    s.movz       s12, #0
    s.muli       s13, s1, #2
    s.sub        s1, s4, s7
    s.movz       s4, #0
    s.cmp.lt     s7, s19, s12
    s.xor        s12, s11, s1
    s.sub        s11, s9, s13
    s.movz       s9, #0
    s.xor        s13, s11, s8
    s.xor        s11, s3, s6
    s.sub        s3, s13, s8
    s.sub        s8, s9, s7
    s.cmp.lt     s7, s3, s5
    s.sub        s5, s12, s1
    s.sub        s9, s4, s7
    s.movz       s4, #0
    s.xor        s7, s3, s9
    s.movz       s3, #1
    s.sub        s12, s11, s6
    s.xor        s6, s19, s8
    s.sub        s11, s7, s9
    s.movz       s7, #0
    s.addi       s13, s4, #0
    s.cmp.eq     s4, s5, s3
    s.add        s3, s10, s12
    s.sub        s10, s6, s8
    s.addi       s6, s7, #0
    s.mov        s13, s11
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.movz       s7, #31
    s.mov        s13, s4
    s.addi       s4, s7, #0
sdiv_4:
    s.lshr       s7, s11, s4
    s.shli       s8, s6, #1
    s.andi       s10, s7, #1
    s.movz       s7, #0
    s.or         s12, s8, s10
    s.movz       s8, #1
    s.cmp.geu    s10, s12, s5
    s.shl        s14, s8, s4
    s.sub        s8, s7, s10
    s.subi       s7, s4, #1
    s.and        s10, s5, s8
    s.and        s15, s14, s8
    s.sub        s8, s12, s10
    s.or         s10, s13, s15
    s.mov        s6, s8
    s.mov        s13, s10
    s.mov        s4, s7
    s.movz       s7, #0
    s.cmp.ge     s8, s4, s7
    br.nz        s8, sdiv_4
sdiv_done_3:
    s.xor        s4, s9, s1
    s.movz       s1, #16
    s.xor        s5, s13, s4
    s.mul        s6, s3, s1
    s.sub        s7, s5, s4
    s.movz       s4, #0
    s.mul        s5, s7, s1
    v.splat      v0, s3
    s.andi       s3, s6, #15
    v.splat      v1, s4
    v.splat      v2, s7
    s.andi       s7, s5, #31
    v.splat      v3, s4
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s6
    v.cmp.ge     p1, v0, v1
    v.splat      v0, s5
    v.splat      v1, s3
    v.cmp.ge     p1, v2, v3
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s7
    v.add        v6, v5, v4
    v.iota       v5                              // arange(0, VLEN)
    v.add        v6, v0, v4
    v.add        v0, v1, v2
    v.add        v0, v3, v5
    s.movz       s8, #4
    s.addi       s9, s4, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s4, s9, s8
    br.nz        s4, endfor_6
    s.mul        s4, s9, s1
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s10, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s11, s9, s2
    s.movz       s12, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s13, s3                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s14, s4                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s13, s10
    mb.wait      s10
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s13, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s14, s7                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s4                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s14, s13
    mb.wait      s13
    mb.arm       s4, b2, #0, #1                  // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.f16 a0, v56, v48, s4
    mb.wait      s4
    s.mov        s9, s11
    br.nz        s12, for_5
endfor_6:
    s.movz       s2, #0
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s3, #0
    s.add        s7, s2, s5                      // the tile origin
    s.movz       s2, #0
    s.muli       s8, s5, #2                      // a runtime tile origin, x2
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s7
    a.vread      v2, a0, s3
    s.add        s3, s2, s6                      // the tile origin
    s.movz       s2, #32
    s.muli       s5, s6, #64                     // a runtime tile origin, x64
    v.splat      v3, s3
    v.splat      v4, s1
    v.add        v5, v0, v1
    v.splat      v0, s2
    vf.cvt.f32.f16 v1, v2
    s.add        s1, s21, s8                     // the tile origin
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v0
    s.add        s2, s1, s5                      // the tile origin
    p.and        p3, p1, p2
    s.movz       s1, #1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v0, a0, s1
    s.addi       s1, s3, #1
    s.addi       s5, s2, #64                     // row 1
    v.splat      v1, s1
    vf.cvt.f32.f16 v2, v0
    s.movz       s1, #2
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.addi       s6, s3, #2
    s.addi       s7, s2, #128                    // row 2
    v.splat      v0, s6
    s.movz       s6, #3
    s.addi       s8, s3, #3
    @p3 v.st.h       [s5, #0], v2
    a.vread      v1, a0, s1
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v0, v1
    v.splat      v1, s8
    s.addi       s1, s2, #192                    // row 3
    s.movz       s5, #4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    s.addi       s8, s3, #4
    s.addi       s9, s2, #256                    // row 4
    v.splat      v1, s8
    s.movz       s8, #5
    @p3 v.st.h       [s7, #0], v0
    a.vread      v0, a0, s6
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v0
    s.addi       s6, s3, #5
    s.addi       s7, s2, #320                    // row 5
    v.splat      v0, s6
    s.movz       s6, #6
    s.addi       s11, s3, #6
    v.splat      v2, s11
    s.addi       s11, s2, #384                   // row 6
    @p4 v.st.h       [s1, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v0, v1
    s.movz       s1, #7
    s.addi       s5, s3, #7
    v.splat      v1, s5
    s.addi       s5, s2, #448                    // row 7
    @p3 v.st.h       [s9, #0], v0
    a.vread      v0, a0, s8
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v0
    s.movz       s8, #8
    s.addi       s9, s3, #8
    v.splat      v0, s9
    s.addi       s9, s2, #512                    // row 8
    @p4 v.st.h       [s7, #0], v2
    a.vread      v2, a0, s6
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v2
    s.movz       s6, #9
    s.addi       s7, s3, #9
    v.splat      v2, s7
    s.addi       s7, s2, #576                    // row 9
    @p3 v.st.h       [s11, #0], v1
    a.vread      v1, a0, s1
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v0, v1
    s.movz       s1, #10
    s.addi       s11, s3, #10
    v.splat      v1, s11
    s.addi       s11, s2, #640                   // row 10
    @p4 v.st.h       [s5, #0], v0
    a.vread      v0, a0, s8
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v0
    s.movz       s5, #11
    s.addi       s8, s3, #11
    v.splat      v0, s8
    s.addi       s8, s2, #704                    // row 11
    @p3 v.st.h       [s9, #0], v2
    a.vread      v2, a0, s6
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v2
    s.movz       s6, #12
    s.addi       s9, s3, #12
    v.splat      v2, s9
    s.addi       s9, s2, #768                    // row 12
    @p4 v.st.h       [s7, #0], v1
    a.vread      v1, a0, s1
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v0, v1
    s.movz       s1, #13
    s.addi       s7, s3, #13
    v.splat      v1, s7
    s.addi       s7, s2, #832                    // row 13
    @p3 v.st.h       [s11, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v0
    s.movz       s5, #14
    s.addi       s11, s3, #14
    s.addi       s12, s3, #15
    v.splat      v0, s11
    s.addi       s3, s2, #896                    // row 14
    v.splat      v3, s12
    s.movz       s11, #15
    s.addi       s12, s2, #960                   // row 15
    @p4 v.st.h       [s8, #0], v2
    a.vread      v2, a0, s6
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v2
    @p3 v.st.h       [s9, #0], v1
    a.vread      v1, a0, s1
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v0, v1
    @p4 v.st.h       [s7, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v0
    @p3 v.st.h       [s3, #0], v1
    a.vread      v0, a0, s11
    vf.cvt.f32.f16 v1, v0
    @p4 v.st.h       [s12, #0], v1
__rctx_next:
    exit
