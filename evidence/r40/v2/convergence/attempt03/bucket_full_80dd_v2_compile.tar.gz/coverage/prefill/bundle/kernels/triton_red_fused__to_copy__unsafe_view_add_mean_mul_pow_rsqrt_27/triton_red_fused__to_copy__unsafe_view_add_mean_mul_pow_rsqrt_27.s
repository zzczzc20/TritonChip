    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_out_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // in_ptr1: device_ptr64 at arg_base+16
    s.ld.d       s5, [s1, #24]                   // in_ptr2: device_ptr64 at arg_base+24
    s.ld.d       s6, [s1, #32]                   // in_ptr3: device_ptr64 at arg_base+32
    s.ld.d       s7, [s1, #40]                   // in_ptr4: device_ptr64 at arg_base+40
    s.ld.d       s8, [s1, #48]                   // out_ptr1: device_ptr64 at arg_base+48
    s.rdspecial  s1, arg_base
    s.ld.d       s9, [s1, #72]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s10, #1280
    s.mul        s11, s1, s10
    s.add        s1, s9, s11                     // this context's own scratch
    s.addi       s9, s1, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s10, #0
    s.st.d       [s9, #0], s2
    s.movz       s10, #512
    s.st.d       [s9, #8], s10
    s.movz       s10, #1024
    s.st.d       [s9, #16], s10
    s.movz       s10, #2048
    s.st.d       [s9, #48], s10
    s.movz       s10, #2
    s.st.d       [s9, #56], s10
    .li       s10, #68719476737
    s.st.d       [s9, #88], s10
    .li       s10, #8589934592
    s.st.d       [s9, #104], s10
    fence.release.device
    td.load      d0, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s9, s1, #256                    // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s10, #0
    s.st.d       [s9, #0], s3
    s.movz       s10, #512
    s.st.d       [s9, #8], s10
    s.movz       s10, #1024
    s.st.d       [s9, #16], s10
    s.movz       s10, #2048
    s.st.d       [s9, #48], s10
    s.movz       s10, #2
    s.st.d       [s9, #56], s10
    .li       s10, #68719476737
    s.st.d       [s9, #88], s10
    .li       s10, #8589934592
    s.st.d       [s9, #104], s10
    fence.release.device
    td.load      d1, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s9, s1, #512                    // TensorMap 2: tl.make_tensor_descriptor (rank 2)
    s.movz       s10, #0
    s.st.d       [s9, #0], s4
    s.movz       s10, #512
    s.st.d       [s9, #8], s10
    s.movz       s10, #1024
    s.st.d       [s9, #16], s10
    s.movz       s10, #2048
    s.st.d       [s9, #48], s10
    s.movz       s10, #2
    s.st.d       [s9, #56], s10
    .li       s10, #68719476737
    s.st.d       [s9, #88], s10
    .li       s10, #8589934592
    s.st.d       [s9, #104], s10
    fence.release.device
    td.load      d2, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s9, s1, #768                    // TensorMap 3: tl.make_tensor_descriptor (rank 2)
    s.movz       s10, #0
    s.st.d       [s9, #0], s5
    s.movz       s10, #512
    s.st.d       [s9, #8], s10
    s.movz       s10, #1024
    s.st.d       [s9, #16], s10
    s.movz       s10, #2048
    s.st.d       [s9, #48], s10
    s.movz       s10, #2
    s.st.d       [s9, #56], s10
    .li       s10, #68719476737
    s.st.d       [s9, #88], s10
    .li       s10, #8589934592
    s.st.d       [s9, #104], s10
    fence.release.device
    td.load      d3, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s9, s1, #1024                   // TensorMap 4: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s9, #0], s6
    s.movz       s1, #512
    s.st.d       [s9, #8], s1
    s.movz       s1, #1024
    s.st.d       [s9, #16], s1
    s.movz       s1, #2048
    s.st.d       [s9, #48], s1
    s.movz       s1, #2
    s.st.d       [s9, #56], s1
    .li       s1, #68719476737
    s.st.d       [s9, #88], s1
    .li       s1, #8589934592
    s.st.d       [s9, #104], s1
    fence.release.device
    td.load      d4, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s9, #1024
    s.movz       s10, #16
    s.rdspecial  s11, role_id
    s.rdspecial  s12, npid.x
__rctx_program:
    v.movi       v0, #0
    v.movi       v1, #0
    v.splat      v2, s11
    v.iota       v2                              // arange(0, VLEN)
    s.addi       s13, s1, #0
    v.mov        v1, v0
for_1:
    s.cmp.ge     s14, s13, s9
    br.nz        s14, endfor_2
    v.splat      v0, s13
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v4, s13
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s14, #1024
    s.movz       s15, #512
    s.movz       s16, #1024
    s.movz       s17, #512
    s.muli       s18, s11, #2048
    s.muli       s19, s11, #2048
    v.add        v6, v0, v3
    v.movi       v0, #0
    v.splat      v3, s14
    v.splat      v7, s11
    v.movi       v8, #0
    v.splat      v9, s15
    v.add        v10, v4, v5
    v.movi       v4, #0
    v.splat      v5, s16
    v.splat      v11, s11
    v.movi       v12, #0
    s.muli       s14, s13, #2
    s.muli       s15, s13, #2
    v.cmp.ge     p1, v6, v0
    v.splat      v0, s17
    v.cmp.lt     p2, v6, v3
    v.cmp.ge     p3, v7, v8
    v.cmp.lt     p4, v7, v9
    v.cmp.ge     p5, v10, v4
    s.add        s16, s2, s18
    p.and        p6, p1, p2
    v.cmp.lt     p1, v10, v5
    p.and        p2, p3, p4
    v.cmp.ge     p3, v11, v12
    s.add        s17, s3, s19
    p.and        p4, p5, p1
    v.cmp.lt     p1, v11, v0
    p.and        p5, p3, p1
    s.add        s18, s16, s14
    p.and        p1, p6, p2
    s.add        s14, s17, s15
    p.and        p2, p4, p5
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s18, #0]
    v.splat      v3, s13
    v.movi       v4, #1024
    v.add        v5, v3, v2
    s.muli       s15, s11, #2048
    v.cmp.lt     p1, v5, v4
    v.splat      v3, s13
    v.iota       v4                              // arange(0, VLEN)
    s.movz       s16, #1024
    s.movz       s17, #512
    v.add        v6, v3, v4
    v.movi       v3, #0
    v.splat      v4, s16
    v.splat      v7, s11
    v.movi       v8, #0
    v.splat      v9, s17
    s.muli       s16, s13, #2
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v10, [s14, #0]
    v.cmp.ge     p2, v6, v3
    v.cmp.lt     p3, v6, v4
    v.cmp.ge     p4, v7, v8
    v.cmp.lt     p5, v7, v9
    s.add        s14, s4, s15
    p.and        p6, p2, p3
    p.and        p2, p4, p5
    s.muli       s15, s11, #2048
    s.add        s17, s14, s16
    p.and        p3, p6, p2
    vf.cvt.f16.f32 v3, v0
    v.splat      v0, s13
    v.iota       v4                              // arange(0, VLEN)
    s.movz       s14, #1024
    s.movz       s16, #512
    v.add        v6, v0, v4
    v.movi       v0, #0
    v.splat      v4, s14
    v.splat      v7, s11
    v.movi       v8, #0
    v.splat      v9, s16
    s.muli       s14, s13, #2
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v11, [s17, #0]
    v.cmp.ge     p2, v6, v0
    v.cmp.lt     p3, v6, v4
    v.cmp.ge     p4, v7, v8
    v.cmp.lt     p5, v7, v9
    s.add        s16, s5, s15
    p.and        p6, p2, p3
    p.and        p2, p4, p5
    s.muli       s15, s11, #2048
    s.add        s17, s16, s14
    p.and        p3, p6, p2
    vf.cvt.f16.f32 v0, v10
    v.splat      v4, s13
    v.iota       v6                              // arange(0, VLEN)
    s.movz       s14, #1024
    s.movz       s16, #512
    v.add        v7, v4, v6
    v.movi       v4, #0
    v.splat      v6, s14
    v.splat      v8, s11
    v.movi       v9, #0
    v.splat      v10, s16
    s.muli       s14, s13, #2
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v12, [s17, #0]
    v.cmp.ge     p2, v7, v4
    v.cmp.lt     p3, v7, v6
    v.cmp.ge     p4, v8, v9
    v.cmp.lt     p5, v8, v10
    s.add        s16, s6, s15
    p.and        p6, p2, p3
    p.and        p2, p4, p5
    s.add        s15, s16, s14
    p.and        p3, p6, p2
    vf.cvt.f16.f32 v4, v11
    vf.add       v6, v3, v0
    s.mul        s14, s11, s9
    v.movi       v0, #0
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s15, #0]
    vf.cvt.f16.f32 v7, v12
    vf.add       v8, v6, v4
    s.add        s15, s13, s14
    v.splat      v4, s14
    s.shli       s14, s15, #1                    // element offset -> bytes (x2)
    s.add        s15, s13, s10
    vf.add       v6, v8, v7
    s.add        s16, s2, s14                    // &in_out_ptr0[...]
    s.movz       s14, #1
    v.add        v7, v5, v4
    vf.cvt.f16.f32 v4, v3
    vf.add       v3, v6, v4
    vf.mul       v4, v3, v3
    vf.cvt.f32.f16 v5, v3
    vf.add       v3, v1, v4
    @p1 v.st.h       [s16, #0], v5
    @p1 v.sel        v4, v3, v1
    v.mov        v0, v4
    v.mov        v1, v0
    s.mov        s13, s15
    br.nz        s14, for_1
endfor_2:
    vf.reduce.add.b v0, v1
    v.movi       v1, #0
    s.addi       s13, s1, #0
    vf.add       v3, v0, v1
for_3:
    s.cmp.ge     s14, s13, s9
    br.nz        s14, endfor_4
    .li       s14, #1149239296
    v.splat      v0, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s14, #1065353216
    v.splat      v1, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s14, #925353388
    v.splat      v4, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    v.splat      v6, s13
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s14, #1024
    s.movz       s15, #512
    s.muli       s16, s11, #2048
    v.add        v8, v6, v7
    v.movi       v6, #0
    v.splat      v7, s14
    v.splat      v9, s11
    v.movi       v10, #0
    s.muli       s14, s13, #2
    v.cmp.ge     p1, v8, v6
    v.splat      v6, s15
    v.cmp.lt     p2, v8, v7
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v6
    s.add        s15, s2, s16
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    .li       s16, #1077936128
    v.splat      v6, s16                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s16, #3204448256
    v.splat      v7, s16                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v8, s13
    s.add        s16, s15, s14
    p.and        p2, p5, p1
    v.add        v9, v8, v2
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v8, [s16, #0]
    v.movi       v10, #1024
    vf.fms       v11, v0, v5, v1
    s.shli       s14, s13, #1                    // element offset -> bytes (x2)
    v.cmp.lt     p1, v9, v10
    s.add        s15, s7, s14                    // &in_ptr4[...]
    s.mul        s14, s11, s9
    vf.fms       v0, v5, v11, v5
    s.add        s16, s13, s10
    s.movz       s17, #1
    s.add        s18, s13, s14
    vf.neg       v1, v0                          // Newton step: r0*(2 - x*r0)
    s.shli       s19, s18, #1                    // element offset -> bytes (x2)
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s15, #0]
    vf.cvt.f16.f32 v10, v8
    v.splat      v8, s14
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v11, v1, v5
    s.add        s14, s8, s19                    // &out_ptr1[...]
    v.add        v1, v9, v8
    vf.mul       v1, v3, v11                     // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v5, v1, v4
    vf.cvt.f16.f32 v1, v0
    v.rsqrt.approx v0, v5                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v0, v0
    vf.mul       v8, v0, v7
    vf.fms       v7, v5, v4, v6
    vf.mul       v4, v8, v7                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v5, v4, v0
    v.extract    s15, v5, #0
    v.splat      v0, s15
    vf.mul       v4, v10, v0
    vf.mul       v0, v4, v1
    vf.cvt.f32.f16 v1, v0
    @p1 v.st.h       [s14, #0], v1
    s.mov        s13, s16
    br.nz        s17, for_3
endfor_4:
__rctx_next:
    s.addi       s13, s11, #2                    // the next program of this context: + 2
    s.cmp.lt     s14, s13, s12
    s.mov        s11, s13
    br.nz        s14, __rctx_program
    exit
