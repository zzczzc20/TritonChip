module {
  tt.func public @pure() -> (i64, i64, i64, i64, i64, i64, i64, i64) {
    %v0 = arith.constant 128 : i64
    %v1 = arith.constant 16 : i64
    %v2 = arith.constant 32 : i64
    %v3 = arith.constant 48 : i64
    %v4 = arith.constant 64 : i64
    %v5 = arith.constant 80 : i64
    %v6 = arith.constant 96 : i64
    %v7 = arith.constant 112 : i64
    tt.return %v0, %v1, %v2, %v3, %v4, %v5, %v6, %v7 : i64, i64, i64, i64, i64, i64, i64, i64
  }
}
