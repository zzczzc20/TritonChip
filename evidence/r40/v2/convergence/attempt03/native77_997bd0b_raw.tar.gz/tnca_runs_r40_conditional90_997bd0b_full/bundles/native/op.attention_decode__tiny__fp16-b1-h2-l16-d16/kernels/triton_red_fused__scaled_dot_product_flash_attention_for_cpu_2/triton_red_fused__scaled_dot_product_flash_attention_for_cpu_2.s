    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // out_ptr1: device_ptr64 at arg_base+32
    s.rdspecial  s1, arg_base
    s.ld.d       s8, [s1, #56]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s9, #256
    s.mul        s10, s1, s9
    s.add        s1, s8, s10                     // this context's own scratch
    s.addi       s8, s1, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.st.d       [s8, #0], s3
    s.movz       s1, #2
    s.st.d       [s8, #8], s1
    s.movz       s1, #16
    s.st.d       [s8, #16], s1
    s.movz       s9, #64
    s.st.d       [s8, #48], s9
    s.movz       s9, #4
    s.st.d       [s8, #56], s9
    .li       s9, #68719476737
    s.st.d       [s8, #88], s9
    .li       s9, #2207613190144
    s.st.d       [s8, #104], s9
    fence.release.device
    td.load      d0, [s8]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s8, #0
    s.movz       s9, #0
    s.movz       s10, #0
    s.movz       s11, #0
    s.cmp.lt     s12, s1, s11
    s.sub        s1, s10, s12
    s.movz       s10, #0
    s.muli       s11, s10, #4
    v.splat      v0, s4
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v2, #16
    v.movi       v3, #0
    v.cmp.lt     p1, v0, v3
    v.cmp.lt     p2, v2, v3
    v.sub        v4, v3, v0
    @p1 v.sel        v5, v4, v0
    v.sub        v4, v3, v2
    @p2 v.sel        v6, v4, v2
    v.movi       v4, #4
    v.lshr       v6, v5, v4
    v.sub        v4, v3, v6
    @p1 v.sel        v3, v4, v6
    v.iota       v4                              // arange(0, VLEN)
    v.cmpi.lt    p1, v4, #1
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.sb v4, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v5, #0
    v.cmp.ne     p1, v4, v5
    v.iota       v4                              // arange(0, VLEN)
    v.cmpi.lt    p2, v4, #1
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s5, v3]               // index is in elements (ISA sec 9.1)
    v.movi       v5, #0
    v.cmp.lt     p2, v0, v5
    v.cmp.lt     p3, v2, v5
    v.sub        v6, v5, v0
    @p2 v.sel        v7, v6, v0
    v.sub        v0, v5, v2
    @p3 v.sel        v6, v0, v2
    v.movi       v0, #15
    v.and        v2, v7, v0
    v.sub        v0, v5, v2
    @p2 v.sel        v5, v0, v2
    v.movi       v0, #16
    v.cmp.lt     p2, v1, v0
    s.cmp.lt     s2, s4, s9
    s.sub        s5, s8, s2
    s.xor        s2, s4, s5
    s.sub        s8, s2, s5
    s.lshri      s2, s8, #4
    s.xor        s8, s5, s1
    s.xor        s1, s2, s8
    s.sub        s2, s1, s8
    s.muli       s1, s2, #64
    s.add        s5, s3, s1
    s.add        s1, s5, s11
    v.splat      v2, s10
    v.iota       v6                              // arange(0, VLEN)
    v.add        v7, v2, v6
    v.movi       v2, #0
    v.cmp.ge     p3, v7, v2
    v.cmpi.lt    p4, v7, #16
    p.and        p5, p3, p4
    v.splat      v2, s2
    v.movi       v6, #0
    v.cmp.ge     p3, v2, v6
    v.cmpi.lt    p4, v2, #2
    p.and        p6, p3, p4
    p.and        p3, p5, p6
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v2, [s1, #0]
    v.mul        v6, v1, v0
    v.extract    s1, v5, #0
    v.splat      v0, s1
    v.add        v1, v0, v6
    v.movi       v0, #256
    v.mul        v5, v3, v0
    v.extract    s1, v5, #0
    v.splat      v0, s1
    v.add        v3, v1, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v0, [s6, v3]               // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v1, v0
    v.movi       v0, #1
    v.movi       v3, #0
    @p1 v.sel        v5, v0, v3
    v.movi       v0, #0
    v.cmp.eq     p1, v5, v0
    v.extract    s1, v4, #0
    v.splat      v0, s1
    v.rcp.approx v3, v0                          // ISA 8.8: <= 2**-22 relative
    .li       s1, #1065353216
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v5, v0, v3, v4
    vf.fms       v0, v3, v5, v3
    vf.neg       v4, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v4, v4
    @p3 v.sel        v0, v4, v3
    vf.mul       v3, v2, v0                      // a/y as a refined reciprocal (ISA has no divide)
    v.movi       v0, #1
    v.movi       v2, #0
    @p1 v.sel        v4, v0, v2
    v.extract    s1, v4, #0
    v.splat      v0, s1
    v.movi       v2, #0
    v.cmp.ne     p1, v0, v2
    v.movi       v0, #0
    @p1 v.sel        v2, v0, v3
    vf.mul       v3, v2, v1
    vf.add       v1, v3, v0
    @p2 v.sel        v2, v1, v0
    vf.reduce.add.b v0, v2
    v.movi       v1, #0
    vf.add       v2, v0, v1
    vf.cvt.f32.f16 v0, v2
    s.shli       s1, s4, #1                      // element offset -> bytes (x2)
    s.add        s2, s7, s1                      // &out_ptr1[...]
    v.iota       v1                              // arange(0, VLEN)
    v.cmpi.lt    p1, v1, #1
    @p1 v.st.h       [s2, #0], v0
__rctx_next:
    exit
