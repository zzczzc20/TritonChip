// barrier_alias_0_ooo -- emitted by tnca_cc; data and assertions
// appended, the instructions untouched (sec 15 C1).
.org 0
start:
    .li       s1, #16384
    .li       s2, #1065353216
    v.splat      v0, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.ld.w       v1, [s1, #0]
    v.iota       v2                              // arange(0, VLEN)
    v.movi       v3, #1
    .li       s1, #20480
    v.xor        v4, v2, v3
    .li       s2, #24576
    .li       s3, #1
    vf.add       v2, v1, v0
    v.st.w       [s1, #0], v2
    fence.acq_rel.device
    v.ld.gather.w v0, [s1, v4]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s2, #0], v0
    exit
    exit
    .li       s20, #24576
    s.ld.w    s21, [s20, #0]
    .assert_eq s21, #0x41300000, #1
    s.ld.w    s21, [s20, #4]
    .assert_eq s21, #0x40800000, #2
    s.ld.w    s21, [s20, #8]
    .assert_eq s21, #0x41c80000, #3
    s.ld.w    s21, [s20, #12]
    .assert_eq s21, #0x41900000, #4
    s.ld.w    s21, [s20, #16]
    .assert_eq s21, #0x421c0000, #5
    s.ld.w    s21, [s20, #20]
    .assert_eq s21, #0x42000000, #6
    s.ld.w    s21, [s20, #24]
    .assert_eq s21, #0x42540000, #7
    s.ld.w    s21, [s20, #28]
    .assert_eq s21, #0x42380000, #8
    s.ld.w    s21, [s20, #32]
    .assert_eq s21, #0x42860000, #9
    s.ld.w    s21, [s20, #36]
    .assert_eq s21, #0x42700000, #10
    s.ld.w    s21, [s20, #40]
    .assert_eq s21, #0x42a20000, #11
    s.ld.w    s21, [s20, #44]
    .assert_eq s21, #0x42940000, #12
    s.ld.w    s21, [s20, #48]
    .assert_eq s21, #0x42be0000, #13
    s.ld.w    s21, [s20, #52]
    .assert_eq s21, #0x42b00000, #14
    s.ld.w    s21, [s20, #56]
    .assert_eq s21, #0x42da0000, #15
    s.ld.w    s21, [s20, #60]
    .assert_eq s21, #0x42cc0000, #16
    exit

.org 0x4000
input:
    .dword 0x4120000040400000
    .dword 0x41c0000041880000
    .dword 0x4218000041f80000
    .dword 0x4250000042340000
    .dword 0x42840000426c0000
    .dword 0x42a0000042920000
    .dword 0x42bc000042ae0000
    .dword 0x42d8000042ca0000

.org 0x5000
intermediate:
    .dword 0xdeadbeefdeadbeef
    .dword 0xdeadbeefdeadbeef
    .dword 0xdeadbeefdeadbeef
    .dword 0xdeadbeefdeadbeef
    .dword 0xdeadbeefdeadbeef
    .dword 0xdeadbeefdeadbeef
    .dword 0xdeadbeefdeadbeef
    .dword 0xdeadbeefdeadbeef

.org 0x6000
output:
    .dword 0xdeadbeefdeadbeef
    .dword 0xdeadbeefdeadbeef
    .dword 0xdeadbeefdeadbeef
    .dword 0xdeadbeefdeadbeef
    .dword 0xdeadbeefdeadbeef
    .dword 0xdeadbeefdeadbeef
    .dword 0xdeadbeefdeadbeef
    .dword 0xdeadbeefdeadbeef

