    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.rdspecial  s1, arg_base
    s.ld.d       s6, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s7, #512
    s.mul        s8, s1, s7
    s.add        s1, s6, s8                      // this context's own scratch
    s.addi       s6, s1, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.movz       s1, #0
    s.st.d       [s6, #0], s2
    .li       s1, #2147483647
    s.st.d       [s6, #8], s1
    .li       s1, #2147483647
    s.st.d       [s6, #16], s1
    s.movz       s1, #64
    s.st.d       [s6, #48], s1
    s.movz       s1, #2
    s.st.d       [s6, #56], s1
    .li       s1, #68719476752
    s.st.d       [s6, #88], s1
    .li       s1, #8589934592
    s.st.d       [s6, #104], s1
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s6, #512
    s.mul        s7, s1, s6
    s.add        s1, s2, s7                      // this context's own scratch
    s.addi       s2, s1, #256                    // TensorMap 1: a 2-D tt.load (built once, at entry)
    s.movz       s1, #0
    s.st.d       [s2, #0], s3
    .li       s1, #2147483647
    s.st.d       [s2, #8], s1
    .li       s1, #2147483647
    s.st.d       [s2, #16], s1
    s.movz       s1, #32
    s.st.d       [s2, #48], s1
    s.movz       s1, #2
    s.st.d       [s2, #56], s1
    .li       s1, #68719476752
    s.st.d       [s2, #88], s1
    .li       s1, #8589934592
    s.st.d       [s2, #104], s1
    fence.release.device
    td.load      d1, [s2]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #1
    s.movz       s2, #0
    s.movz       s3, #0
    s.movz       s6, #0
    s.movz       s7, #0
    s.movz       s8, #0
    s.movz       s9, #0
    s.movz       s10, #1
    s.sub        s11, s1, s4
    s.min.s      s12, s11, s1
    s.cmp.lt     s11, s4, s3
    s.sub        s3, s2, s11
    s.cmp.lt     s2, s12, s7
    s.sub        s7, s6, s2
    s.xor        s2, s4, s3
    s.sub        s6, s2, s3
    s.xor        s2, s12, s7
    s.sub        s11, s2, s7
    s.addi       s2, s8, #0
    s.addi       s7, s9, #0
    s.cmp.eq     s8, s11, s10
    s.mov        s2, s6
    br.nz        s8, sdiv_done_1
    s.movz       s8, #0
    s.movz       s9, #31
    s.mov        s2, s8
    s.addi       s8, s9, #0
sdiv_2:
    s.lshr       s9, s6, s8
    s.shli       s10, s7, #1
    s.andi       s13, s9, #1
    s.movz       s9, #0
    s.or         s14, s10, s13
    s.movz       s10, #1
    s.cmp.geu    s13, s14, s11
    s.shl        s15, s10, s8
    s.sub        s10, s9, s13
    s.subi       s9, s8, #1
    s.and        s13, s11, s10
    s.and        s16, s15, s10
    s.sub        s10, s14, s13
    s.or         s13, s2, s16
    s.mov        s7, s10
    s.mov        s2, s13
    s.mov        s8, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s8, s9
    br.nz        s10, sdiv_2
sdiv_done_1:
    s.movz       s2, #0
    s.movz       s6, #0
    s.movz       s8, #0
    s.movz       s9, #0
    s.cmp.lt     s10, s12, s2
    s.movz       s2, #0
    s.cmp.lt     s11, s6, s8
    s.sub        s8, s9, s10
    s.sub        s9, s2, s11
    s.xor        s2, s12, s8
    s.xor        s10, s7, s3
    s.xor        s7, s6, s9
    s.sub        s11, s2, s8
    s.movz       s2, #0
    s.movz       s12, #1
    s.sub        s13, s10, s3
    s.sub        s3, s7, s9
    s.movz       s7, #0
    s.addi       s10, s2, #0
    s.cmp.eq     s2, s11, s12
    s.add        s12, s4, s13
    s.addi       s4, s7, #0
    s.mov        s10, s3
    br.nz        s2, sdiv_done_3
    s.movz       s2, #0
    s.movz       s7, #31
    s.mov        s10, s2
    s.addi       s2, s7, #0
sdiv_4:
    s.lshr       s7, s3, s2
    s.shli       s13, s4, #1
    s.andi       s14, s7, #1
    s.movz       s7, #0
    s.or         s15, s13, s14
    s.movz       s13, #1
    s.cmp.geu    s14, s15, s11
    s.shl        s16, s13, s2
    s.sub        s13, s7, s14
    s.subi       s7, s2, #1
    s.and        s14, s11, s13
    s.and        s17, s16, s13
    s.sub        s13, s15, s14
    s.or         s14, s10, s17
    s.mov        s4, s13
    s.mov        s10, s14
    s.mov        s2, s7
    s.movz       s7, #0
    s.cmp.ge     s13, s2, s7
    br.nz        s13, sdiv_4
sdiv_done_3:
    s.xor        s2, s9, s8
    s.movz       s3, #16
    s.xor        s4, s10, s2
    s.mul        s7, s12, s3
    s.sub        s8, s4, s2
    v.splat      v0, s12
    s.mul        s2, s8, s3
    v.splat      v1, s6
    s.andi       s4, s7, #15
    v.splat      v2, s8
    v.splat      v3, s6
    s.andi       s8, s2, #15
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s7
    v.cmp.ge     p1, v0, v1
    v.splat      v0, s2
    v.splat      v1, s4
    v.cmp.ge     p1, v2, v3
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s8
    v.add        v6, v5, v4
    v.iota       v5                              // arange(0, VLEN)
    v.add        v6, v0, v4
    v.add        v0, v1, v2
    v.add        v0, v3, v5
    s.movz       s9, #2
    s.addi       s10, s6, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s6, s10, s9
    br.nz        s6, endfor_6
    s.mul        s6, s10, s3
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s11, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s12, s10, s1
    s.movz       s13, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s14, s4                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s6                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s14, s11
    mb.wait      s11
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s14, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s15, s6                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s16, s8                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s15, s14
    mb.wait      s14
    mb.arm       s6, b2, #0, #1                  // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.f16 a0, v56, v48, s6
    mb.wait      s6
    s.mov        s10, s12
    br.nz        s13, for_5
endfor_6:
    s.movz       s1, #0
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s4, #0
    s.add        s8, s1, s2                      // the tile origin
    s.movz       s1, #0
    s.muli       s9, s2, #2                      // a runtime tile origin, x2
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s8
    a.vread      v2, a0, s4
    s.add        s2, s1, s7                      // the tile origin
    s.muli       s1, s7, #32                     // a runtime tile origin, x32
    v.splat      v3, s2
    v.splat      v4, s3
    v.add        v5, v0, v1
    v.splat      v0, s3
    vf.cvt.f32.f16 v1, v2
    s.add        s3, s5, s9                      // the tile origin
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v0
    s.add        s4, s3, s1                      // the tile origin
    p.and        p3, p1, p2
    s.movz       s1, #1
    @p3 v.st.h       [s4, #0], v1
    a.vread      v0, a0, s1
    s.addi       s1, s2, #1
    s.addi       s3, s4, #32                     // row 1
    v.splat      v1, s1
    vf.cvt.f32.f16 v2, v0
    s.movz       s1, #2
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.addi       s5, s2, #2
    s.addi       s7, s4, #64                     // row 2
    v.splat      v0, s5
    s.movz       s5, #3
    s.addi       s8, s2, #3
    @p3 v.st.h       [s3, #0], v2
    a.vread      v1, a0, s1
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v0, v1
    v.splat      v1, s8
    s.addi       s1, s4, #96                     // row 3
    s.movz       s3, #4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    s.addi       s8, s2, #4
    s.addi       s9, s4, #128                    // row 4
    v.splat      v1, s8
    s.movz       s8, #5
    @p3 v.st.h       [s7, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v0
    s.addi       s5, s2, #5
    s.addi       s7, s4, #160                    // row 5
    v.splat      v0, s5
    s.movz       s5, #6
    s.addi       s10, s2, #6
    v.splat      v2, s10
    s.addi       s10, s4, #192                   // row 6
    @p4 v.st.h       [s1, #0], v1
    a.vread      v1, a0, s3
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v0, v1
    s.movz       s1, #7
    s.addi       s3, s2, #7
    v.splat      v1, s3
    s.addi       s3, s4, #224                    // row 7
    @p3 v.st.h       [s9, #0], v0
    a.vread      v0, a0, s8
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v0
    s.movz       s8, #8
    s.addi       s9, s2, #8
    v.splat      v0, s9
    s.addi       s9, s4, #256                    // row 8
    @p4 v.st.h       [s7, #0], v2
    a.vread      v2, a0, s5
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v2
    s.movz       s5, #9
    s.addi       s7, s2, #9
    v.splat      v2, s7
    s.addi       s7, s4, #288                    // row 9
    @p3 v.st.h       [s10, #0], v1
    a.vread      v1, a0, s1
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v0, v1
    s.movz       s1, #10
    s.addi       s10, s2, #10
    v.splat      v1, s10
    s.addi       s10, s4, #320                   // row 10
    @p4 v.st.h       [s3, #0], v0
    a.vread      v0, a0, s8
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v0
    s.movz       s3, #11
    s.addi       s8, s2, #11
    v.splat      v0, s8
    s.addi       s8, s4, #352                    // row 11
    @p3 v.st.h       [s9, #0], v2
    a.vread      v2, a0, s5
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v2
    s.movz       s5, #12
    s.addi       s9, s2, #12
    v.splat      v2, s9
    s.addi       s9, s4, #384                    // row 12
    @p4 v.st.h       [s7, #0], v1
    a.vread      v1, a0, s1
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v0, v1
    s.movz       s1, #13
    s.addi       s7, s2, #13
    v.splat      v1, s7
    s.addi       s7, s4, #416                    // row 13
    @p3 v.st.h       [s10, #0], v0
    a.vread      v0, a0, s3
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v0
    s.movz       s3, #14
    s.addi       s10, s2, #14
    s.addi       s12, s2, #15
    v.splat      v0, s10
    s.addi       s2, s4, #448                    // row 14
    v.splat      v3, s12
    s.movz       s10, #15
    s.addi       s12, s4, #480                   // row 15
    @p4 v.st.h       [s8, #0], v2
    a.vread      v2, a0, s5
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v2
    @p3 v.st.h       [s9, #0], v1
    a.vread      v1, a0, s1
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v0, v1
    @p4 v.st.h       [s7, #0], v0
    a.vread      v0, a0, s3
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v0
    @p3 v.st.h       [s2, #0], v1
    a.vread      v0, a0, s10
    vf.cvt.f32.f16 v1, v0
    @p4 v.st.h       [s12, #0], v1
__rctx_next:
    exit
