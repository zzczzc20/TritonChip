    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // out_ptr2: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // out_ptr3: device_ptr64 at arg_base+32
    s.rdspecial  s1, arg_base
    s.ld.d       s8, [s1, #56]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s9, #256
    s.mul        s10, s1, s9
    s.add        s1, s8, s10                     // this context's own scratch
    s.addi       s8, s1, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s8, #0], s2
    s.movz       s1, #16
    s.st.d       [s8, #8], s1
    s.movz       s1, #32
    s.st.d       [s8, #16], s1
    s.movz       s1, #128
    s.st.d       [s8, #48], s1
    s.movz       s1, #4
    s.st.d       [s8, #56], s1
    .li       s1, #68719476737
    s.st.d       [s8, #88], s1
    .li       s1, #2207613190144
    s.st.d       [s8, #104], s1
    fence.release.device
    td.load      d0, [s8]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s8, #32
    s.movz       s9, #16
    v.splat      v0, s4
    v.iota       v0                              // arange(0, VLEN)
    s.addi       s10, s1, #0
    v.movi       v1, #0
    v.movi       v2, #0
    v.cmp.ne     p1, v1, v2
    p.mov        p2, p1
    .li       s11, #4286578688
    v.splat      v1, s11                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v2, #0
    v.mov        v2, v1
for_1:
    s.cmp.ge     s11, s10, s8
    br.nz        s11, endfor_2
    s.muli       s11, s4, #128
    v.splat      v3, s10
    v.iota       v4                              // arange(0, VLEN)
    s.movz       s12, #32
    s.movz       s13, #16
    v.splat      v5, s10
    s.muli       s14, s10, #4
    v.add        v6, v3, v4
    v.movi       v3, #0
    v.splat      v4, s12
    v.splat      v7, s4
    v.movi       v8, #0
    v.splat      v9, s13
    s.shli       s12, s10, #0                    // element offset -> bytes (x1)
    v.add        v10, v5, v0
    v.movi       v5, #32
    v.cmp.ge     p1, v6, v3
    v.cmp.lt     p3, v6, v4
    v.cmp.ge     p4, v7, v8
    v.cmp.lt     p5, v7, v9
    s.add        s13, s3, s12                    // &in_ptr1[...]
    v.cmp.lt     p6, v10, v5
    s.add        s12, s2, s11
    p.and        p7, p1, p3
    p.and        p1, p4, p5
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p6 v.ld.sb      v3, [s13, #0]
    s.add        s11, s12, s14
    p.and        p3, p7, p1
    v.movi       v4, #0
    v.movi       v5, #0
    v.movi       v6, #1
    v.movi       v7, #0
    v.movi       v8, #0
    v.movi       v9, #1
    v.movi       v10, #0
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v11, [s11, #0]
    v.cmp.ne     p1, v3, v4
    @p1 v.sel        v3, v5, v1
    v.movi       v4, #1
    v.movi       v5, #0
    vf.add       v12, v11, v3
    v.movi       v3, #1
    vf.cmp.eq    p1, v12, v1
    @p1 v.sel        v11, v6, v7
    v.movi       v6, #0
    v.cmp.eq     p1, v11, v8
    @p1 v.sel        v7, v9, v10
    @p1 v.sel        v8, v4, v5
    v.extract    s11, v7, #0
    v.movi       v4, #0
    v.movi       v5, #0
    s.lshri      s12, s11, #32
    v.extract    s13, v8, #1
    @p1 v.sel        v7, v3, v6
    v.movi       v3, #1
    v.movi       v6, #0
    v.insert     v4, s11, #0
    v.insert     v5, s12, #0
    s.lshri      s11, s13, #32
    v.extract    s12, v7, #2
    @p1 v.sel        v7, v3, v6
    v.movi       v3, #1
    v.movi       v6, #0
    v.insert     v4, s13, #1
    v.insert     v5, s11, #1
    s.lshri      s11, s12, #32
    v.extract    s13, v7, #3
    @p1 v.sel        v7, v3, v6
    v.movi       v3, #1
    v.movi       v6, #0
    v.insert     v4, s12, #2
    v.insert     v5, s11, #2
    s.lshri      s11, s13, #32
    v.extract    s12, v7, #4
    @p1 v.sel        v7, v3, v6
    v.movi       v3, #1
    v.movi       v6, #0
    v.insert     v4, s13, #3
    v.insert     v5, s11, #3
    s.lshri      s11, s12, #32
    v.extract    s13, v7, #5
    @p1 v.sel        v7, v3, v6
    v.movi       v3, #1
    v.movi       v6, #0
    v.insert     v4, s12, #4
    v.insert     v5, s11, #4
    s.lshri      s11, s13, #32
    v.extract    s12, v7, #6
    @p1 v.sel        v7, v3, v6
    v.movi       v3, #1
    v.movi       v6, #0
    v.insert     v4, s13, #5
    v.insert     v5, s11, #5
    s.lshri      s11, s12, #32
    v.extract    s13, v7, #7
    @p1 v.sel        v7, v3, v6
    v.movi       v3, #1
    v.movi       v6, #0
    v.insert     v4, s12, #6
    v.insert     v5, s11, #6
    s.lshri      s11, s13, #32
    v.extract    s12, v7, #8
    @p1 v.sel        v7, v3, v6
    v.movi       v3, #1
    v.movi       v6, #0
    v.insert     v4, s13, #7
    v.insert     v5, s11, #7
    s.lshri      s11, s12, #32
    v.extract    s13, v7, #9
    @p1 v.sel        v7, v3, v6
    v.movi       v3, #1
    v.movi       v6, #0
    v.insert     v4, s12, #8
    v.insert     v5, s11, #8
    s.lshri      s11, s13, #32
    v.extract    s12, v7, #10
    @p1 v.sel        v7, v3, v6
    v.movi       v3, #1
    v.movi       v6, #0
    v.insert     v4, s13, #9
    v.insert     v5, s11, #9
    s.lshri      s11, s12, #32
    v.extract    s13, v7, #11
    @p1 v.sel        v7, v3, v6
    v.movi       v3, #1
    v.movi       v6, #0
    v.insert     v4, s12, #10
    v.insert     v5, s11, #10
    s.lshri      s11, s13, #32
    v.extract    s12, v7, #12
    @p1 v.sel        v7, v3, v6
    v.movi       v3, #1
    v.movi       v6, #0
    v.insert     v4, s13, #11
    v.insert     v5, s11, #11
    s.lshri      s11, s12, #32
    v.extract    s13, v7, #13
    @p1 v.sel        v7, v3, v6
    v.movi       v3, #1
    v.movi       v6, #0
    v.insert     v4, s12, #12
    v.insert     v5, s11, #12
    s.lshri      s11, s13, #32
    v.extract    s12, v7, #14
    @p1 v.sel        v7, v3, v6
    v.insert     v4, s13, #13
    v.insert     v5, s11, #13
    s.lshri      s11, s12, #32
    v.extract    s13, v7, #15
    v.insert     v4, s12, #14
    v.insert     v5, s11, #14
    s.lshri      s11, s13, #32
    v.insert     v4, s13, #15
    v.insert     v5, s11, #15
    v.extract    s11, v4, #0
    v.extract    s12, v5, #0
    s.shli       s13, s12, #32
    v.extract    s12, v5, #1
    s.or         s14, s11, s13
    s.movz       s11, #0
    s.shli       s13, s12, #32
    v.extract    s12, v4, #1
    v.extract    s15, v5, #2
    v.movi       v3, #0
    s.cmp.ne     s16, s14, s11
    s.or         s11, s12, s13
    s.movz       s12, #0
    s.shli       s13, s15, #32
    v.extract    s14, v4, #2
    v.extract    s15, v5, #3
    v.insert     v3, s16, #0
    s.cmp.ne     s16, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #0
    s.shli       s13, s15, #32
    v.extract    s14, v4, #3
    v.extract    s15, v5, #4
    v.insert     v3, s16, #1
    s.cmp.ne     s16, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #0
    s.shli       s13, s15, #32
    v.extract    s14, v4, #4
    v.extract    s15, v5, #5
    v.insert     v3, s16, #2
    s.cmp.ne     s16, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #0
    s.shli       s13, s15, #32
    v.extract    s14, v4, #5
    v.extract    s15, v5, #6
    v.insert     v3, s16, #3
    s.cmp.ne     s16, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #0
    s.shli       s13, s15, #32
    v.extract    s14, v4, #6
    v.extract    s15, v5, #7
    v.insert     v3, s16, #4
    s.cmp.ne     s16, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #0
    s.shli       s13, s15, #32
    v.extract    s14, v4, #7
    v.extract    s15, v5, #8
    v.insert     v3, s16, #5
    s.cmp.ne     s16, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #0
    s.shli       s13, s15, #32
    v.extract    s14, v4, #8
    v.extract    s15, v5, #9
    v.insert     v3, s16, #6
    s.cmp.ne     s16, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #0
    s.shli       s13, s15, #32
    v.extract    s14, v4, #9
    v.extract    s15, v5, #10
    v.insert     v3, s16, #7
    s.cmp.ne     s16, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #0
    s.shli       s13, s15, #32
    v.extract    s14, v4, #10
    v.extract    s15, v5, #11
    v.insert     v3, s16, #8
    s.cmp.ne     s16, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #0
    s.shli       s13, s15, #32
    v.extract    s14, v4, #11
    v.extract    s15, v5, #12
    v.insert     v3, s16, #9
    s.cmp.ne     s16, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #0
    s.shli       s13, s15, #32
    v.extract    s14, v4, #12
    v.extract    s15, v5, #13
    v.insert     v3, s16, #10
    s.cmp.ne     s16, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #0
    s.shli       s13, s15, #32
    v.extract    s14, v4, #13
    v.extract    s15, v5, #14
    v.insert     v3, s16, #11
    s.cmp.ne     s16, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #0
    s.shli       s13, s15, #32
    v.extract    s14, v4, #14
    v.extract    s15, v5, #15
    v.insert     v3, s16, #12
    s.cmp.ne     s16, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #0
    s.shli       s13, s15, #32
    v.extract    s14, v4, #15
    v.insert     v3, s16, #13
    s.cmp.ne     s15, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #0
    v.insert     v3, s15, #14
    s.cmp.ne     s13, s11, s12
    v.movi       v4, #0
    v.insert     v3, s13, #15
    p.not        p1, p6
    v.cmp.ne     p3, v3, v4
    p.or         p4, p2, p3
    vf.max       v3, v2, v12
    p.and        p3, p6, p4
    p.and        p4, p1, p2
    v.movi       v4, #0
    p.or         p1, p3, p4
    @p6 v.sel        v5, v3, v2
    p.mov        p3, p1
    v.mov        v4, v5
    s.add        s11, s10, s9
    s.movz       s12, #1
    p.mov        p2, p3
    v.mov        v2, v4
    s.mov        s10, s11
    br.nz        s12, for_1
endfor_2:
    v.movi       v3, #1
    v.movi       v4, #0
    vf.cmp.uo    p1, v2, v2
    v.movi       v5, #1
    v.movi       v6, #0
    @p1 v.sel        v7, v3, v4
    @p2 v.sel        v3, v5, v6
    v.reduce.or.b v4, v7
    v.movi       v5, #0
    s.movz       s10, #1
    vf.reduce.max.b v6, v2
    .li       s11, #2143289344
    v.splat      v2, s11                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s11, s4, #0                     // element offset -> bytes (x1)
    v.reduce.or  s12, v3
    v.cmp.ne     p1, v4, v5
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v4, s10
    v.splat      v5, s12
    @p1 v.sel        v7, v2, v6
    v.movi       v2, #0
    s.add        s10, s5, s11                    // &out_ptr0[...]
    v.movi       v6, #0
    v.movi       v8, #0
    v.cmp.lt     p1, v3, v4
    vf.add       v3, v7, v2
    @p1 v.st.b       [s10, #0], v5
    s.addi       s5, s1, #0
    v.mov        v8, v6
for_3:
    s.cmp.ge     s1, s5, s8
    br.nz        s1, endfor_4
    s.muli       s1, s4, #128
    v.splat      v4, s5
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s10, #32
    s.movz       s11, #16
    v.splat      v7, s5
    s.muli       s12, s5, #4
    v.add        v9, v4, v5
    v.movi       v4, #0
    v.splat      v5, s10
    v.splat      v10, s4
    v.movi       v11, #0
    v.splat      v12, s11
    s.shli       s10, s5, #0                     // element offset -> bytes (x1)
    v.add        v13, v7, v0
    v.movi       v7, #32
    v.cmp.ge     p1, v9, v4
    v.cmp.lt     p2, v9, v5
    v.cmp.ge     p3, v10, v11
    v.cmp.lt     p4, v10, v12
    s.add        s11, s3, s10                    // &in_ptr1[...]
    v.cmp.lt     p5, v13, v7
    s.add        s10, s2, s1
    p.and        p6, p1, p2
    p.and        p1, p3, p4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.sb      v4, [s11, #0]
    s.add        s1, s10, s12
    p.and        p2, p6, p1
    v.movi       v5, #0
    v.extract    s10, v3, #0
    v.splat      v7, s10
    .li       s10, #1069066811
    v.splat      v9, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s10, #1060205080
    v.splat      v10, s10                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.mul        s10, s4, s8
    v.movi       v11, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v12, [s1, #0]
    v.cmp.ne     p1, v4, v5
    @p1 v.sel        v4, v6, v1
    s.add        s1, s5, s10
    v.splat      v5, s10
    s.shli       s10, s1, #2                     // element offset -> bytes (x4)
    s.add        s1, s5, s9
    s.add        s11, s6, s10                    // &out_ptr2[...]
    s.movz       s10, #1
    v.add        v14, v13, v5
    vf.add       v5, v12, v4
    vf.sub       v4, v5, v7
    vf.mul       v5, v4, v9
    v.exp2.approx v7, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v12, v4, v9, v5                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v12, v10
    vf.fma       v5, v7, v4, v7                  // 2**t * 2**d
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v4, v5, v7
    vf.add       v5, v8, v4
    @p5 v.st.w       [s11, #0], v4
    @p5 v.sel        v4, v5, v8
    v.mov        v11, v4
    v.mov        v8, v11
    s.mov        s5, s1
    br.nz        s10, for_3
endfor_4:
    vf.reduce.add.b v0, v8
    s.movz       s1, #1
    vf.add       v1, v0, v2
    s.shli       s2, s4, #2                      // element offset -> bytes (x4)
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v2, s1
    s.add        s1, s7, s2                      // &out_ptr3[...]
    v.cmp.lt     p1, v0, v2
    @p1 v.st.w       [s1, #0], v1
__rctx_next:
    exit
