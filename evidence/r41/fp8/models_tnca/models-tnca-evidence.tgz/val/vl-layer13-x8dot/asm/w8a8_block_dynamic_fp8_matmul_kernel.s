    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    s.ld.d       s3, [s1, #0]                    // A: device_ptr64 at arg_base+0
    s.addi       s4, s2, #0
    s.ld.d       s2, [s1, #8]                    // B: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // C: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // Bs: device_ptr64 at arg_base+24
    s.ld.sw      s7, [s1, #32]                   // M: i32 at arg_base+32
    s.ld.sw      s8, [s1, #40]                   // N: i32 at arg_base+40
    s.ld.sw      s9, [s1, #48]                   // K: i32 at arg_base+48
    s.ld.sw      s10, [s1, #56]                  // stride_am: i32 at arg_base+56
    s.ld.sw      s11, [s1, #64]                  // stride_bn: i32 at arg_base+64
    s.ld.sw      s12, [s1, #72]                  // stride_cm: i32 at arg_base+72
    s.ld.sw      s13, [s1, #80]                  // stride_bs_n: i32 at arg_base+80
rows_1:
    s.movz       s1, #127
    s.movz       s14, #128
    s.rdspecial  s15, pid.x
    s.add        s16, s7, s1
    s.movz       s17, #0
    s.movz       s18, #0
    s.cmp.lt     s19, s16, s17
    s.rdspecial  s17, pid.y
    s.sub        s20, s18, s19
    s.movz       s18, #0
    s.movz       s19, #0
    s.cmp.lt     s21, s14, s18
    // rows [r0, r0 + 16) of a 128-row program (row_split)
    v.iota       v0                              // arange(0, VLEN)
    s.xor        s18, s16, s20
    s.sub        s16, s19, s21
    v.splat      v1, s4
    s.sub        s19, s18, s20
    v.add        v2, v0, v1
    s.add        s18, s8, s1
    s.movz       s21, #0
    s.movz       s22, #0
    s.cmp.lt     s23, s18, s21
    s.movz       s21, #0
    s.sub        s24, s22, s23
    s.movz       s22, #0
    s.cmp.lt     s23, s14, s21
    s.lshri      s21, s19, #7
    s.xor        s25, s20, s16
    s.muli       s20, s21, #128
    s.xor        s26, s21, s25
    s.sub        s21, s26, s25
    s.xor        s25, s14, s16
    s.sub        s26, s22, s23
    s.sub        s22, s25, s16
    s.xor        s16, s18, s24
    s.xor        s18, s14, s26
    s.sub        s22, s16, s24
    s.sub        s16, s19, s20
    s.lshri      s16, s22, #7
    s.xor        s19, s24, s26
    s.movz       s20, #8
    s.xor        s23, s16, s19
    s.movz       s24, #0
    s.sub        s25, s23, s19
    s.movz       s19, #0
    s.mul        s23, s15, s25
    s.mul        s15, s25, s20
    s.muli       s25, s16, #128
    s.sub        s16, s18, s26
    s.movz       s16, #0
    s.add        s18, s23, s17
    s.cmp.lt     s17, s15, s16
    s.movz       s16, #0
    s.cmp.lt     s23, s18, s24
    s.sub        s24, s19, s17
    s.sub        s17, s16, s23
    s.sub        s16, s22, s25
    s.xor        s16, s15, s24
    s.xor        s19, s18, s17
    s.sub        s22, s16, s24
    s.movz       s16, #0
    s.movz       s23, #1
    s.sub        s25, s19, s17
    s.movz       s19, #0
    s.addi       s26, s16, #0
    s.cmp.eq     s16, s22, s23
    s.addi       s23, s19, #0
    s.mov        s26, s25
    br.nz        s16, sdiv_done_3
    s.movz       s16, #0
    s.mov        s26, s16
    s.movz       s16, #31
    s.addi       s19, s16, #0
sdiv_4:
    s.lshr       s16, s25, s19
    s.andi       s27, s16, #1
    s.shli       s16, s23, #1
    s.or         s28, s16, s27
    s.movz       s16, #0
    s.cmp.geu    s27, s28, s22
    s.sub        s29, s16, s27
    s.and        s16, s22, s29
    s.sub        s27, s28, s16
    s.mov        s23, s27
    s.movz       s16, #1
    s.shl        s27, s16, s19
    s.and        s16, s27, s29
    s.or         s27, s26, s16
    s.mov        s26, s27
    s.subi       s16, s19, #1
    s.mov        s19, s16
    s.movz       s16, #0
    s.cmp.ge     s27, s19, s16
    br.nz        s27, sdiv_4
sdiv_done_3:
    s.xor        s16, s17, s24
    s.movz       s17, #0
    s.xor        s19, s26, s16
    s.movz       s22, #0
    s.cmp.lt     s23, s15, s17
    s.sub        s17, s19, s16
    s.movz       s16, #0
    s.cmp.lt     s19, s18, s22
    s.sub        s22, s16, s23
    s.movz       s16, #0
    s.mul        s23, s17, s20
    s.sub        s17, s16, s19
    s.xor        s16, s15, s22
    s.xor        s15, s18, s17
    s.sub        s18, s16, s22
    s.movz       s16, #0
    s.sub        s19, s21, s23
    s.sub        s21, s15, s17
    s.movz       s15, #0
    s.addi       s22, s16, #0
    s.min.s      s16, s19, s20
    s.movz       s19, #1
    s.addi       s20, s15, #0
    s.cmp.eq     s15, s18, s19
    s.mov        s22, s21
    br.nz        s15, sdiv_done_5
    s.movz       s15, #0
    s.mov        s22, s15
    s.movz       s15, #31
    s.addi       s19, s15, #0
sdiv_6:
    s.lshr       s15, s21, s19
    s.andi       s24, s15, #1
    s.shli       s15, s20, #1
    s.or         s25, s15, s24
    s.movz       s15, #0
    s.cmp.geu    s24, s25, s18
    s.sub        s26, s15, s24
    s.and        s15, s18, s26
    s.sub        s24, s25, s15
    s.mov        s20, s24
    s.movz       s15, #1
    s.shl        s24, s15, s19
    s.and        s15, s24, s26
    s.or         s24, s22, s15
    s.mov        s22, s24
    s.subi       s15, s19, #1
    s.mov        s19, s15
    s.movz       s15, #0
    s.cmp.ge     s24, s19, s15
    br.nz        s24, sdiv_6
sdiv_done_5:
    s.xor        s15, s20, s17
    s.movz       s18, #0
    s.sub        s19, s15, s17
    s.movz       s15, #0
    s.movz       s17, #0
    s.cmp.lt     s20, s16, s18
    s.movz       s18, #0
    s.cmp.lt     s21, s19, s15
    s.sub        s15, s17, s20
    s.sub        s17, s18, s21
    s.xor        s18, s16, s15
    s.xor        s20, s19, s17
    s.sub        s21, s18, s15
    s.movz       s15, #0
    s.movz       s18, #1
    s.sub        s22, s20, s17
    s.movz       s20, #0
    s.addi       s24, s15, #0
    s.cmp.eq     s15, s21, s18
    s.addi       s18, s20, #0
    s.mov        s24, s22
    br.nz        s15, sdiv_done_7
    s.movz       s15, #0
    s.mov        s24, s15
    s.movz       s15, #31
    s.addi       s20, s15, #0
sdiv_8:
    s.lshr       s15, s22, s20
    s.andi       s25, s15, #1
    s.shli       s15, s18, #1
    s.or         s26, s15, s25
    s.movz       s15, #0
    s.cmp.geu    s25, s26, s21
    s.sub        s27, s15, s25
    s.and        s15, s21, s27
    s.sub        s25, s26, s15
    s.mov        s18, s25
    s.movz       s15, #1
    s.shl        s25, s15, s20
    s.and        s15, s25, s27
    s.or         s25, s24, s15
    s.mov        s24, s25
    s.subi       s15, s20, #1
    s.mov        s20, s15
    s.movz       s15, #0
    s.cmp.ge     s25, s20, s15
    br.nz        s25, sdiv_8
sdiv_done_7:
    s.movz       s15, #0
    s.movz       s20, #0
    s.movz       s21, #0
    s.cmp.lt     s22, s16, s15
    s.cmp.lt     s15, s19, s20
    s.sub        s20, s21, s22
    s.movz       s21, #0
    s.xor        s22, s16, s20
    s.sub        s16, s21, s15
    s.xor        s15, s18, s17
    s.xor        s18, s19, s16
    s.sub        s19, s22, s20
    s.movz       s21, #0
    s.sub        s22, s15, s17
    s.sub        s15, s18, s16
    s.movz       s17, #0
    s.addi       s18, s21, #0
    s.add        s21, s23, s22
    s.movz       s22, #1
    s.addi       s23, s17, #0
    s.cmp.eq     s17, s19, s22
    s.mov        s18, s15
    br.nz        s17, sdiv_done_9
    s.movz       s17, #0
    s.mov        s18, s17
    s.movz       s17, #31
    s.addi       s22, s17, #0
sdiv_10:
    s.lshr       s17, s15, s22
    s.andi       s24, s17, #1
    s.shli       s17, s23, #1
    s.or         s25, s17, s24
    s.movz       s17, #0
    s.cmp.geu    s24, s25, s19
    s.sub        s26, s17, s24
    s.and        s17, s19, s26
    s.sub        s24, s25, s17
    s.mov        s23, s24
    s.movz       s17, #1
    s.shl        s24, s17, s22
    s.and        s17, s24, s26
    s.or         s24, s18, s17
    s.mov        s18, s24
    s.subi       s17, s22, #1
    s.mov        s22, s17
    s.movz       s17, #0
    s.cmp.ge     s24, s22, s17
    br.nz        s24, sdiv_10
sdiv_done_9:
    s.mul        s15, s21, s14
    s.xor        s17, s16, s20
    v.iota       v0                              // arange(0, VLEN)
    s.xor        s16, s18, s17
    v.movi       v1, #16
    v.iota       v3                              // arange(0, VLEN)
    v.movi       v4, #32
    v.iota       v5                              // arange(0, VLEN)
    v.movi       v6, #48
    v.iota       v7                              // arange(0, VLEN)
    v.movi       v8, #64
    v.iota       v9                              // arange(0, VLEN)
    s.sub        s18, s16, s17
    v.movi       v10, #80
    v.iota       v11                             // arange(0, VLEN)
    v.iota       v12                             // arange(0, VLEN)
    v.movi       v13, #96
    v.add        v14, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.add        v1, v3, v4
    v.splat      v3, s15
    v.add        v4, v5, v6
    v.movi       v5, #112
    v.add        v6, v7, v8
    v.add        v7, v9, v10
    v.add        v8, v3, v2
    v.splat      v2, s7
    v.add        v3, v12, v13
    v.add        v9, v0, v5
    v.splat      v0, s15
    v.splat      v0, s15
    v.splat      v0, s15
    v.splat      v0, s15
    v.movi       v0, #0
    v.splat      v5, s15
    v.splat      v5, s15
    v.cmp.lt     p1, v8, v0
    v.splat      v5, s15
    v.cmp.lt     p2, v2, v0
    v.splat      v5, s15
    v.sub        v5, v0, v8
    s.add        s16, s4, s15
    v.sub        v10, v0, v2
    v.splat      v12, s7
    v.splat      v12, s7
    v.splat      v12, s7
    v.splat      v12, s7
    v.splat      v12, s7
    v.splat      v12, s7
    v.splat      v12, s7
    v.splat      v12, s7
    v.movi       v12, #1
    @p1 v.sel        v13, v5, v8
    @p2 v.sel        v5, v10, v2
    v.movi       v2, #0
    v.movi       v8, #0
    s.movz       s15, #31
idiv_11:
    v.splat      v10, s15
    v.shl        v15, v8, v12
    v.lshr       v16, v13, v10
    v.cmp.lt     p2, v8, v0
    v.and        v17, v16, v12
    v.shl        v16, v12, v10
    v.or         v10, v15, v17
    s.subi       s17, s15, #1
    v.cmp.geu    p3, v10, v5
    p.or         p4, p2, p3
    v.sub        v15, v10, v5
    @p4 v.sel        v17, v16, v0
    @p4 v.sel        v16, v15, v10
    v.or         v10, v2, v17
    v.mov        v8, v16
    v.mov        v2, v10
    s.mov        s15, s17
    s.movz       s17, #0
    s.cmp.ge     s19, s15, s17
    br.nz        s19, idiv_11
    s.mul        s15, s18, s14
    v.sub        v2, v0, v8
    @p1 v.sel        v0, v2, v8
    v.splat      v2, s15
    v.splat      v5, s8
    v.add        v8, v2, v11
    v.splat      v2, s15
    v.splat      v10, s15
    v.splat      v11, s15
    v.splat      v12, s15
    v.splat      v13, s15
    v.splat      v15, s15
    v.splat      v16, s15
    v.movi       v17, #0
    v.add        v18, v2, v14
    v.add        v2, v10, v1
    v.cmp.lt     p1, v8, v17
    v.add        v1, v11, v4
    v.cmp.lt     p2, v5, v17
    v.add        v4, v12, v6
    v.sub        v6, v17, v8
    v.add        v10, v13, v7
    v.add        v7, v15, v3
    v.sub        v3, v17, v5
    v.add        v11, v16, v9
    v.splat      v9, s8
    v.splat      v12, s8
    v.splat      v13, s8
    v.splat      v14, s8
    v.splat      v15, s8
    v.splat      v16, s8
    v.splat      v19, s8
    v.movi       v20, #1
    @p1 v.sel        v21, v6, v8
    @p2 v.sel        v6, v3, v5
    v.movi       v3, #0
    v.movi       v5, #0
    s.movz       s17, #31
idiv_12:
    v.splat      v8, s17
    v.shl        v22, v5, v20
    v.lshr       v23, v21, v8
    v.cmp.lt     p2, v5, v17
    v.and        v24, v23, v20
    v.shl        v23, v20, v8
    v.or         v8, v22, v24
    s.subi       s18, s17, #1
    v.cmp.geu    p3, v8, v6
    p.or         p4, p2, p3
    v.sub        v22, v8, v6
    @p4 v.sel        v24, v23, v17
    @p4 v.sel        v23, v22, v8
    v.or         v8, v3, v24
    v.mov        v5, v23
    v.mov        v3, v8
    s.mov        s17, s18
    s.movz       s18, #0
    s.cmp.ge     s19, s17, s18
    br.nz        s19, idiv_12
    v.movi       v3, #0
    v.sub        v6, v17, v5
    v.sub        v8, v3, v18
    v.sub        v17, v3, v9
    v.cmp.lt     p2, v18, v3
    @p1 v.sel        v20, v6, v5
    v.cmp.lt     p1, v9, v3
    v.movi       v5, #1
    @p2 v.sel        v6, v8, v18
    @p1 v.sel        v8, v17, v9
    v.movi       v9, #0
    v.movi       v17, #0
    s.movz       s17, #31
idiv_13:
    v.splat      v18, s17
    v.shl        v21, v17, v5
    v.lshr       v22, v6, v18
    v.cmp.lt     p1, v17, v3
    v.and        v23, v22, v5
    v.shl        v22, v5, v18
    v.or         v18, v21, v23
    s.subi       s18, s17, #1
    v.cmp.geu    p3, v18, v8
    p.or         p4, p1, p3
    v.sub        v21, v18, v8
    @p4 v.sel        v23, v22, v3
    @p4 v.sel        v22, v21, v18
    v.or         v18, v9, v23
    v.mov        v17, v22
    v.mov        v9, v18
    s.mov        s17, s18
    s.movz       s18, #0
    s.cmp.ge     s19, s17, s18
    br.nz        s19, idiv_13
    v.movi       v5, #0
    v.sub        v6, v3, v17
    v.sub        v3, v5, v2
    v.sub        v8, v5, v12
    v.cmp.lt     p1, v2, v5
    @p2 v.sel        v9, v6, v17
    v.cmp.lt     p2, v12, v5
    v.movi       v6, #1
    @p1 v.sel        v17, v3, v2
    @p2 v.sel        v2, v8, v12
    v.movi       v3, #0
    v.movi       v8, #0
    s.movz       s17, #31
idiv_14:
    v.splat      v12, s17
    v.shl        v18, v8, v6
    v.lshr       v21, v17, v12
    v.cmp.lt     p2, v8, v5
    v.and        v22, v21, v6
    v.shl        v21, v6, v12
    v.or         v12, v18, v22
    s.subi       s18, s17, #1
    v.cmp.geu    p3, v12, v2
    p.or         p4, p2, p3
    v.sub        v18, v12, v2
    @p4 v.sel        v22, v21, v5
    @p4 v.sel        v21, v18, v12
    v.or         v12, v3, v22
    v.mov        v8, v21
    v.mov        v3, v12
    s.mov        s17, s18
    s.movz       s18, #0
    s.cmp.ge     s19, s17, s18
    br.nz        s19, idiv_14
    v.movi       v2, #0
    v.sub        v3, v5, v8
    v.sub        v5, v2, v1
    v.sub        v6, v2, v13
    v.cmp.lt     p2, v1, v2
    @p1 v.sel        v12, v3, v8
    v.cmp.lt     p1, v13, v2
    v.movi       v3, #1
    @p2 v.sel        v8, v5, v1
    @p1 v.sel        v1, v6, v13
    v.movi       v5, #0
    v.movi       v6, #0
    s.movz       s17, #31
idiv_15:
    v.splat      v13, s17
    v.shl        v17, v6, v3
    v.lshr       v18, v8, v13
    v.cmp.lt     p1, v6, v2
    v.and        v21, v18, v3
    v.shl        v18, v3, v13
    v.or         v13, v17, v21
    s.subi       s18, s17, #1
    v.cmp.geu    p3, v13, v1
    p.or         p4, p1, p3
    v.sub        v17, v13, v1
    @p4 v.sel        v21, v18, v2
    @p4 v.sel        v18, v17, v13
    v.or         v13, v5, v21
    v.mov        v6, v18
    v.mov        v5, v13
    s.mov        s17, s18
    s.movz       s18, #0
    s.cmp.ge     s19, s17, s18
    br.nz        s19, idiv_15
    v.movi       v1, #0
    v.sub        v3, v2, v6
    v.sub        v2, v1, v4
    v.sub        v5, v1, v14
    v.cmp.lt     p1, v4, v1
    @p2 v.sel        v8, v3, v6
    v.cmp.lt     p2, v14, v1
    v.movi       v3, #1
    @p1 v.sel        v6, v2, v4
    @p2 v.sel        v2, v5, v14
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s17, #31
idiv_16:
    v.splat      v13, s17
    v.shl        v14, v5, v3
    v.lshr       v17, v6, v13
    v.cmp.lt     p2, v5, v1
    v.and        v18, v17, v3
    v.shl        v17, v3, v13
    v.or         v13, v14, v18
    s.subi       s18, s17, #1
    v.cmp.geu    p3, v13, v2
    p.or         p4, p2, p3
    v.sub        v14, v13, v2
    @p4 v.sel        v18, v17, v1
    @p4 v.sel        v17, v14, v13
    v.or         v13, v4, v18
    v.mov        v5, v17
    v.mov        v4, v13
    s.mov        s17, s18
    s.movz       s18, #0
    s.cmp.ge     s19, s17, s18
    br.nz        s19, idiv_16
    v.movi       v2, #0
    v.sub        v3, v1, v5
    v.sub        v1, v2, v10
    v.sub        v4, v2, v15
    v.cmp.lt     p2, v10, v2
    @p1 v.sel        v6, v3, v5
    v.cmp.lt     p1, v15, v2
    v.movi       v3, #1
    @p2 v.sel        v5, v1, v10
    @p1 v.sel        v1, v4, v15
    v.movi       v4, #0
    v.movi       v10, #0
    s.movz       s17, #31
idiv_17:
    v.splat      v13, s17
    v.shl        v14, v10, v3
    v.lshr       v15, v5, v13
    v.cmp.lt     p1, v10, v2
    v.and        v17, v15, v3
    v.shl        v15, v3, v13
    v.or         v13, v14, v17
    s.subi       s18, s17, #1
    v.cmp.geu    p3, v13, v1
    p.or         p4, p1, p3
    v.sub        v14, v13, v1
    @p4 v.sel        v17, v15, v2
    @p4 v.sel        v15, v14, v13
    v.or         v13, v4, v17
    v.mov        v10, v15
    v.mov        v4, v13
    s.mov        s17, s18
    s.movz       s18, #0
    s.cmp.ge     s19, s17, s18
    br.nz        s19, idiv_17
    v.movi       v1, #0
    v.sub        v3, v2, v10
    v.sub        v2, v1, v7
    v.sub        v4, v1, v16
    v.cmp.lt     p1, v7, v1
    @p2 v.sel        v5, v3, v10
    v.cmp.lt     p2, v16, v1
    v.movi       v3, #1
    @p1 v.sel        v10, v2, v7
    @p2 v.sel        v2, v4, v16
    v.movi       v4, #0
    v.movi       v7, #0
    s.movz       s17, #31
idiv_18:
    v.splat      v13, s17
    v.shl        v14, v7, v3
    v.lshr       v15, v10, v13
    v.cmp.lt     p2, v7, v1
    v.and        v16, v15, v3
    v.shl        v15, v3, v13
    v.or         v13, v14, v16
    s.subi       s18, s17, #1
    v.cmp.geu    p3, v13, v2
    p.or         p4, p2, p3
    v.sub        v14, v13, v2
    @p4 v.sel        v16, v15, v1
    @p4 v.sel        v15, v14, v13
    v.or         v13, v4, v16
    v.mov        v7, v15
    v.mov        v4, v13
    s.mov        s17, s18
    s.movz       s18, #0
    s.cmp.ge     s19, s17, s18
    br.nz        s19, idiv_18
    v.movi       v2, #0
    v.sub        v3, v1, v7
    v.sub        v1, v2, v11
    v.sub        v4, v2, v19
    v.cmp.lt     p2, v11, v2
    @p1 v.sel        v10, v3, v7
    v.cmp.lt     p1, v19, v2
    v.movi       v3, #1
    @p2 v.sel        v7, v1, v11
    @p1 v.sel        v1, v4, v19
    v.movi       v4, #0
    v.movi       v11, #0
    s.movz       s17, #31
idiv_19:
    v.splat      v13, s17
    v.shl        v14, v11, v3
    v.lshr       v15, v7, v13
    v.cmp.lt     p1, v11, v2
    v.and        v16, v15, v3
    v.shl        v15, v3, v13
    v.or         v13, v14, v16
    s.subi       s18, s17, #1
    v.cmp.geu    p3, v13, v1
    p.or         p4, p1, p3
    v.sub        v14, v13, v1
    @p4 v.sel        v16, v15, v2
    @p4 v.sel        v15, v14, v13
    v.or         v13, v4, v16
    v.mov        v11, v15
    v.mov        v4, v13
    s.mov        s17, s18
    s.movz       s18, #0
    s.cmp.ge     s19, s17, s18
    br.nz        s19, idiv_19
    v.sub        v1, v2, v11
    v.movi       v2, #0
    @p2 v.sel        v3, v1, v11
    v.sub        v1, v2, v20
    v.cmp.lt     p1, v20, v2
    @p1 v.sel        v4, v1, v20
    v.movi       v1, #128
    s.movz       s17, #16
    v.movi       v7, #7
    v.sub        v11, v2, v1
    v.cmp.lt     p2, v1, v2
    s.movz       s18, #32
    v.lshr       v13, v4, v7
    s.movz       s19, #48
    v.sub        v4, v2, v13
    s.movz       s20, #64
    @p1 v.sel        v2, v4, v13
    s.movz       s21, #80
    v.movi       v4, #128
    s.movz       s22, #96
    v.movi       v7, #0
    s.movz       s23, #112
    v.cmp.lt     p1, v9, v7
    v.movi       v13, #1
    v.sub        v13, v7, v9
    v.movi       v14, #7
    @p1 v.sel        v15, v13, v9
    v.sub        v13, v7, v4
    v.lshr       v16, v15, v14
    @p2 v.sel        v14, v11, v1
    v.movi       v1, #0
    v.sub        v11, v7, v16
    v.cmp.lt     p2, v12, v1
    v.movi       v14, #128
    @p1 v.sel        v15, v11, v16
    v.cmp.lt     p1, v4, v7
    v.movi       v7, #1
    v.sub        v7, v1, v12
    v.movi       v11, #7
    @p2 v.sel        v16, v7, v12
    v.sub        v7, v1, v14
    v.lshr       v17, v16, v11
    @p1 v.sel        v11, v13, v4
    v.movi       v4, #0
    v.sub        v11, v1, v17
    v.cmp.lt     p1, v8, v4
    v.movi       v13, #128
    @p2 v.sel        v16, v11, v17
    v.cmp.lt     p2, v14, v1
    v.movi       v1, #1
    v.sub        v1, v4, v8
    v.movi       v11, #7
    @p1 v.sel        v17, v1, v8
    v.sub        v1, v4, v13
    v.lshr       v18, v17, v11
    @p2 v.sel        v11, v7, v14
    v.movi       v7, #0
    v.sub        v11, v4, v18
    v.cmp.lt     p2, v6, v7
    v.movi       v14, #128
    @p1 v.sel        v17, v11, v18
    v.cmp.lt     p1, v13, v4
    v.movi       v4, #1
    v.sub        v4, v7, v6
    v.movi       v11, #7
    @p2 v.sel        v18, v4, v6
    v.sub        v4, v7, v14
    v.lshr       v19, v18, v11
    @p1 v.sel        v11, v1, v13
    v.movi       v1, #0
    v.sub        v11, v7, v19
    v.cmp.lt     p1, v5, v1
    v.movi       v13, #128
    @p2 v.sel        v18, v11, v19
    v.cmp.lt     p2, v14, v7
    v.movi       v7, #1
    v.sub        v7, v1, v5
    v.movi       v11, #7
    @p1 v.sel        v19, v7, v5
    v.sub        v7, v1, v13
    v.lshr       v21, v19, v11
    @p2 v.sel        v11, v4, v14
    v.movi       v4, #0
    v.sub        v11, v1, v21
    v.cmp.lt     p2, v10, v4
    v.movi       v14, #128
    @p1 v.sel        v19, v11, v21
    v.cmp.lt     p1, v13, v1
    v.movi       v1, #1
    v.sub        v1, v4, v10
    v.movi       v11, #7
    @p2 v.sel        v21, v1, v10
    v.sub        v1, v4, v14
    v.lshr       v22, v21, v11
    @p1 v.sel        v11, v7, v13
    v.movi       v7, #0
    v.sub        v11, v4, v22
    v.cmp.lt     p1, v3, v7
    v.movi       v13, #128
    @p2 v.sel        v21, v11, v22
    v.cmp.lt     p2, v14, v4
    v.movi       v4, #1
    v.sub        v4, v7, v3
    v.movi       v11, #7
    @p1 v.sel        v22, v4, v3
    v.sub        v4, v7, v13
    v.lshr       v23, v22, v11
    @p2 v.sel        v11, v1, v14
    v.sub        v1, v7, v23
    v.splat      v11, s13
    @p1 v.sel        v14, v1, v23
    v.splat      v1, s13
    v.splat      v22, s13
    v.splat      v23, s13
    v.splat      v24, s13
    v.cmp.lt     p1, v13, v7
    v.movi       v7, #1
    v.splat      v7, s13
    @p1 v.sel        v25, v4, v13
    s.add        s24, s9, s1
    s.movz       s1, #0
    s.movz       s25, #0
    s.cmp.lt     s26, s24, s1
    s.movz       s1, #0
    s.sub        s27, s25, s26
    v.splat      v4, s13
    s.movz       s25, #0
    v.splat      v13, s13
    s.cmp.lt     s26, s14, s25
    v.mul        v25, v2, v11
    s.sub        s25, s1, s26
    v.mul        v2, v15, v1
    s.xor        s1, s24, s27
    v.mul        v1, v16, v22
    s.sub        s24, s1, s27
    v.mul        v11, v17, v23
    s.xor        s1, s14, s25
    v.mul        v15, v18, v24
    v.mul        v16, v19, v7
    s.lshri      s26, s24, #7
    v.mul        v7, v21, v4
    s.muli       s28, s26, #128
    v.mul        v4, v14, v13
    s.xor        s29, s27, s25
    s.movz       s27, #0
    s.xor        s30, s26, s29
    s.sub        s26, s1, s25
    s.movz       s1, #0
    s.movz       s25, #0
    s.sub        s26, s24, s28
    s.sub        s24, s30, s29
    s.movz       s26, #1
    s.addi       s28, s27, #0
    s.addi       s29, s1, #0
    s.addi       s1, s25, #0
    s.addi       s25, s6, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_28:
    s.cmp.ge     s30, s28, s24
    br.nz        s30, endfor_29
    s.mul        s30, s28, s14
    s.sub        s31, s9, s30
    s.rdspecial  s30, arg_base
    s.ld.d       s32, [s30, #88]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.addi       s30, s32, #0
    s.muli       s33, s10, #2
    s.muli       s34, s29, #2
    v.splat      v13, s33
    v.mul        v14, v0, v13
    v.extract    s33, v14, #0
    s.add        s35, s33, s34
    s.add        s33, s3, s35
    v.iota       v13                             // arange(0, VLEN)
    s.movz       s35, #0
    s.add        s36, s35, s31                   // the tile origin
    v.splat      v17, s36
    v.cmp.lt     p1, v13, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s33, s30, #64
    v.extract    s35, v14, #1
    s.add        s36, s35, s34
    s.add        s35, s3, s36
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #128
    v.extract    s35, v14, #2
    s.add        s36, s35, s34
    s.add        s35, s3, s36
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #192
    v.extract    s35, v14, #3
    s.add        s36, s35, s34
    s.add        s35, s3, s36
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #256
    v.extract    s35, v14, #4
    s.add        s36, s35, s34
    s.add        s35, s3, s36
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #320
    v.extract    s35, v14, #5
    s.add        s36, s35, s34
    s.add        s35, s3, s36
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #384
    v.extract    s35, v14, #6
    s.add        s36, s35, s34
    s.add        s35, s3, s36
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #448
    v.extract    s35, v14, #7
    s.add        s36, s35, s34
    s.add        s35, s3, s36
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #512
    v.extract    s35, v14, #8
    s.add        s36, s35, s34
    s.add        s35, s3, s36
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #576
    v.extract    s35, v14, #9
    s.add        s36, s35, s34
    s.add        s35, s3, s36
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #640
    v.extract    s35, v14, #10
    s.add        s36, s35, s34
    s.add        s35, s3, s36
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #704
    v.extract    s35, v14, #11
    s.add        s36, s35, s34
    s.add        s35, s3, s36
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #768
    v.extract    s35, v14, #12
    s.add        s36, s35, s34
    s.add        s35, s3, s36
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #832
    v.extract    s35, v14, #13
    s.add        s36, s35, s34
    s.add        s35, s3, s36
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #896
    v.extract    s35, v14, #14
    s.add        s36, s35, s34
    s.add        s35, s3, s36
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #960
    v.extract    s30, v14, #15
    s.add        s35, s30, s34
    s.add        s30, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s30, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    fence.acq_rel.device
    s.addi       s30, s32, #1024
    v.extract    s33, v14, #0
    s.add        s35, s33, s34
    s.addi       s33, s35, #32
    s.add        s35, s3, s33
    s.movz       s33, #0
    s.add        s36, s33, s17                   // the tile origin
    v.splat      v17, s36
    v.add        v18, v13, v17
    s.movz       s33, #0
    s.add        s36, s33, s31                   // the tile origin
    v.splat      v17, s36
    v.cmp.lt     p1, v18, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s33, s30, #64
    v.extract    s35, v14, #1
    s.add        s36, s35, s34
    s.addi       s35, s36, #32
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #128
    v.extract    s35, v14, #2
    s.add        s36, s35, s34
    s.addi       s35, s36, #32
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #192
    v.extract    s35, v14, #3
    s.add        s36, s35, s34
    s.addi       s35, s36, #32
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #256
    v.extract    s35, v14, #4
    s.add        s36, s35, s34
    s.addi       s35, s36, #32
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #320
    v.extract    s35, v14, #5
    s.add        s36, s35, s34
    s.addi       s35, s36, #32
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #384
    v.extract    s35, v14, #6
    s.add        s36, s35, s34
    s.addi       s35, s36, #32
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #448
    v.extract    s35, v14, #7
    s.add        s36, s35, s34
    s.addi       s35, s36, #32
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #512
    v.extract    s35, v14, #8
    s.add        s36, s35, s34
    s.addi       s35, s36, #32
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #576
    v.extract    s35, v14, #9
    s.add        s36, s35, s34
    s.addi       s35, s36, #32
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #640
    v.extract    s35, v14, #10
    s.add        s36, s35, s34
    s.addi       s35, s36, #32
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #704
    v.extract    s35, v14, #11
    s.add        s36, s35, s34
    s.addi       s35, s36, #32
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #768
    v.extract    s35, v14, #12
    s.add        s36, s35, s34
    s.addi       s35, s36, #32
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #832
    v.extract    s35, v14, #13
    s.add        s36, s35, s34
    s.addi       s35, s36, #32
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #896
    v.extract    s35, v14, #14
    s.add        s36, s35, s34
    s.addi       s35, s36, #32
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #960
    v.extract    s30, v14, #15
    s.add        s35, s30, s34
    s.addi       s30, s35, #32
    s.add        s35, s3, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    fence.acq_rel.device
    s.addi       s30, s32, #2048
    v.extract    s33, v14, #0
    s.add        s35, s33, s34
    s.addi       s33, s35, #64
    s.add        s35, s3, s33
    s.movz       s33, #0
    s.add        s36, s33, s18                   // the tile origin
    v.splat      v17, s36
    v.add        v18, v13, v17
    s.movz       s33, #0
    s.add        s36, s33, s31                   // the tile origin
    v.splat      v17, s36
    v.cmp.lt     p1, v18, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s33, s30, #64
    v.extract    s35, v14, #1
    s.add        s36, s35, s34
    s.addi       s35, s36, #64
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #128
    v.extract    s35, v14, #2
    s.add        s36, s35, s34
    s.addi       s35, s36, #64
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #192
    v.extract    s35, v14, #3
    s.add        s36, s35, s34
    s.addi       s35, s36, #64
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #256
    v.extract    s35, v14, #4
    s.add        s36, s35, s34
    s.addi       s35, s36, #64
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #320
    v.extract    s35, v14, #5
    s.add        s36, s35, s34
    s.addi       s35, s36, #64
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #384
    v.extract    s35, v14, #6
    s.add        s36, s35, s34
    s.addi       s35, s36, #64
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #448
    v.extract    s35, v14, #7
    s.add        s36, s35, s34
    s.addi       s35, s36, #64
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #512
    v.extract    s35, v14, #8
    s.add        s36, s35, s34
    s.addi       s35, s36, #64
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #576
    v.extract    s35, v14, #9
    s.add        s36, s35, s34
    s.addi       s35, s36, #64
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #640
    v.extract    s35, v14, #10
    s.add        s36, s35, s34
    s.addi       s35, s36, #64
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #704
    v.extract    s35, v14, #11
    s.add        s36, s35, s34
    s.addi       s35, s36, #64
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #768
    v.extract    s35, v14, #12
    s.add        s36, s35, s34
    s.addi       s35, s36, #64
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #832
    v.extract    s35, v14, #13
    s.add        s36, s35, s34
    s.addi       s35, s36, #64
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #896
    v.extract    s35, v14, #14
    s.add        s36, s35, s34
    s.addi       s35, s36, #64
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #960
    v.extract    s30, v14, #15
    s.add        s35, s30, s34
    s.addi       s30, s35, #64
    s.add        s35, s3, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    fence.acq_rel.device
    s.addi       s30, s32, #3072
    v.extract    s33, v14, #0
    s.add        s35, s33, s34
    s.addi       s33, s35, #96
    s.add        s35, s3, s33
    s.movz       s33, #0
    s.add        s36, s33, s19                   // the tile origin
    v.splat      v17, s36
    v.add        v18, v13, v17
    s.movz       s33, #0
    s.add        s36, s33, s31                   // the tile origin
    v.splat      v17, s36
    v.cmp.lt     p1, v18, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s33, s30, #64
    v.extract    s35, v14, #1
    s.add        s36, s35, s34
    s.addi       s35, s36, #96
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #128
    v.extract    s35, v14, #2
    s.add        s36, s35, s34
    s.addi       s35, s36, #96
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #192
    v.extract    s35, v14, #3
    s.add        s36, s35, s34
    s.addi       s35, s36, #96
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #256
    v.extract    s35, v14, #4
    s.add        s36, s35, s34
    s.addi       s35, s36, #96
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #320
    v.extract    s35, v14, #5
    s.add        s36, s35, s34
    s.addi       s35, s36, #96
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #384
    v.extract    s35, v14, #6
    s.add        s36, s35, s34
    s.addi       s35, s36, #96
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #448
    v.extract    s35, v14, #7
    s.add        s36, s35, s34
    s.addi       s35, s36, #96
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #512
    v.extract    s35, v14, #8
    s.add        s36, s35, s34
    s.addi       s35, s36, #96
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #576
    v.extract    s35, v14, #9
    s.add        s36, s35, s34
    s.addi       s35, s36, #96
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #640
    v.extract    s35, v14, #10
    s.add        s36, s35, s34
    s.addi       s35, s36, #96
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #704
    v.extract    s35, v14, #11
    s.add        s36, s35, s34
    s.addi       s35, s36, #96
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #768
    v.extract    s35, v14, #12
    s.add        s36, s35, s34
    s.addi       s35, s36, #96
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #832
    v.extract    s35, v14, #13
    s.add        s36, s35, s34
    s.addi       s35, s36, #96
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #896
    v.extract    s35, v14, #14
    s.add        s36, s35, s34
    s.addi       s35, s36, #96
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #960
    v.extract    s30, v14, #15
    s.add        s35, s30, s34
    s.addi       s30, s35, #96
    s.add        s35, s3, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    fence.acq_rel.device
    s.addi       s30, s32, #4096
    v.extract    s33, v14, #0
    s.add        s35, s33, s34
    s.addi       s33, s35, #128
    s.add        s35, s3, s33
    s.movz       s33, #0
    s.add        s36, s33, s20                   // the tile origin
    v.splat      v17, s36
    v.add        v18, v13, v17
    s.movz       s33, #0
    s.add        s36, s33, s31                   // the tile origin
    v.splat      v17, s36
    v.cmp.lt     p1, v18, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s33, s30, #64
    v.extract    s35, v14, #1
    s.add        s36, s35, s34
    s.addi       s35, s36, #128
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #128
    v.extract    s35, v14, #2
    s.add        s36, s35, s34
    s.addi       s35, s36, #128
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #192
    v.extract    s35, v14, #3
    s.add        s36, s35, s34
    s.addi       s35, s36, #128
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #256
    v.extract    s35, v14, #4
    s.add        s36, s35, s34
    s.addi       s35, s36, #128
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #320
    v.extract    s35, v14, #5
    s.add        s36, s35, s34
    s.addi       s35, s36, #128
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #384
    v.extract    s35, v14, #6
    s.add        s36, s35, s34
    s.addi       s35, s36, #128
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #448
    v.extract    s35, v14, #7
    s.add        s36, s35, s34
    s.addi       s35, s36, #128
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #512
    v.extract    s35, v14, #8
    s.add        s36, s35, s34
    s.addi       s35, s36, #128
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #576
    v.extract    s35, v14, #9
    s.add        s36, s35, s34
    s.addi       s35, s36, #128
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #640
    v.extract    s35, v14, #10
    s.add        s36, s35, s34
    s.addi       s35, s36, #128
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #704
    v.extract    s35, v14, #11
    s.add        s36, s35, s34
    s.addi       s35, s36, #128
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #768
    v.extract    s35, v14, #12
    s.add        s36, s35, s34
    s.addi       s35, s36, #128
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #832
    v.extract    s35, v14, #13
    s.add        s36, s35, s34
    s.addi       s35, s36, #128
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #896
    v.extract    s35, v14, #14
    s.add        s36, s35, s34
    s.addi       s35, s36, #128
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #960
    v.extract    s30, v14, #15
    s.add        s35, s30, s34
    s.addi       s30, s35, #128
    s.add        s35, s3, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    fence.acq_rel.device
    s.addi       s30, s32, #5120
    v.extract    s33, v14, #0
    s.add        s35, s33, s34
    s.addi       s33, s35, #160
    s.add        s35, s3, s33
    s.movz       s33, #0
    s.add        s36, s33, s21                   // the tile origin
    v.splat      v17, s36
    v.add        v18, v13, v17
    s.movz       s33, #0
    s.add        s36, s33, s31                   // the tile origin
    v.splat      v17, s36
    v.cmp.lt     p1, v18, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s33, s30, #64
    v.extract    s35, v14, #1
    s.add        s36, s35, s34
    s.addi       s35, s36, #160
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #128
    v.extract    s35, v14, #2
    s.add        s36, s35, s34
    s.addi       s35, s36, #160
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #192
    v.extract    s35, v14, #3
    s.add        s36, s35, s34
    s.addi       s35, s36, #160
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #256
    v.extract    s35, v14, #4
    s.add        s36, s35, s34
    s.addi       s35, s36, #160
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #320
    v.extract    s35, v14, #5
    s.add        s36, s35, s34
    s.addi       s35, s36, #160
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #384
    v.extract    s35, v14, #6
    s.add        s36, s35, s34
    s.addi       s35, s36, #160
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #448
    v.extract    s35, v14, #7
    s.add        s36, s35, s34
    s.addi       s35, s36, #160
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #512
    v.extract    s35, v14, #8
    s.add        s36, s35, s34
    s.addi       s35, s36, #160
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #576
    v.extract    s35, v14, #9
    s.add        s36, s35, s34
    s.addi       s35, s36, #160
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #640
    v.extract    s35, v14, #10
    s.add        s36, s35, s34
    s.addi       s35, s36, #160
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #704
    v.extract    s35, v14, #11
    s.add        s36, s35, s34
    s.addi       s35, s36, #160
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #768
    v.extract    s35, v14, #12
    s.add        s36, s35, s34
    s.addi       s35, s36, #160
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #832
    v.extract    s35, v14, #13
    s.add        s36, s35, s34
    s.addi       s35, s36, #160
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #896
    v.extract    s35, v14, #14
    s.add        s36, s35, s34
    s.addi       s35, s36, #160
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #960
    v.extract    s30, v14, #15
    s.add        s35, s30, s34
    s.addi       s30, s35, #160
    s.add        s35, s3, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    fence.acq_rel.device
    s.addi       s30, s32, #6144
    v.extract    s33, v14, #0
    s.add        s35, s33, s34
    s.addi       s33, s35, #192
    s.add        s35, s3, s33
    s.movz       s33, #0
    s.add        s36, s33, s22                   // the tile origin
    v.splat      v17, s36
    v.add        v18, v13, v17
    s.movz       s33, #0
    s.add        s36, s33, s31                   // the tile origin
    v.splat      v17, s36
    v.cmp.lt     p1, v18, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s33, s30, #64
    v.extract    s35, v14, #1
    s.add        s36, s35, s34
    s.addi       s35, s36, #192
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #128
    v.extract    s35, v14, #2
    s.add        s36, s35, s34
    s.addi       s35, s36, #192
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #192
    v.extract    s35, v14, #3
    s.add        s36, s35, s34
    s.addi       s35, s36, #192
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #256
    v.extract    s35, v14, #4
    s.add        s36, s35, s34
    s.addi       s35, s36, #192
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #320
    v.extract    s35, v14, #5
    s.add        s36, s35, s34
    s.addi       s35, s36, #192
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #384
    v.extract    s35, v14, #6
    s.add        s36, s35, s34
    s.addi       s35, s36, #192
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #448
    v.extract    s35, v14, #7
    s.add        s36, s35, s34
    s.addi       s35, s36, #192
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #512
    v.extract    s35, v14, #8
    s.add        s36, s35, s34
    s.addi       s35, s36, #192
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #576
    v.extract    s35, v14, #9
    s.add        s36, s35, s34
    s.addi       s35, s36, #192
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #640
    v.extract    s35, v14, #10
    s.add        s36, s35, s34
    s.addi       s35, s36, #192
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #704
    v.extract    s35, v14, #11
    s.add        s36, s35, s34
    s.addi       s35, s36, #192
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #768
    v.extract    s35, v14, #12
    s.add        s36, s35, s34
    s.addi       s35, s36, #192
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #832
    v.extract    s35, v14, #13
    s.add        s36, s35, s34
    s.addi       s35, s36, #192
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #896
    v.extract    s35, v14, #14
    s.add        s36, s35, s34
    s.addi       s35, s36, #192
    s.add        s36, s3, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    s.addi       s33, s30, #960
    v.extract    s30, v14, #15
    s.add        s35, s30, s34
    s.addi       s30, s35, #192
    s.add        s35, s3, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s33, #0], v18
    fence.acq_rel.device
    s.addi       s30, s32, #7168
    v.extract    s33, v14, #0
    s.add        s35, s33, s34
    s.addi       s33, s35, #224
    s.add        s35, s3, s33
    s.movz       s33, #0
    s.add        s36, s33, s23                   // the tile origin
    v.splat      v17, s36
    v.add        v18, v13, v17
    s.movz       s33, #0
    s.add        s36, s33, s31                   // the tile origin
    v.splat      v13, s36
    v.cmp.lt     p1, v18, v13
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s35, #0]
    vf.cvt.bf16.f32 v17, v13
    v.st.w       [s30, #0], v17
    s.addi       s33, s30, #64
    v.extract    s35, v14, #1
    s.add        s36, s35, s34
    s.addi       s35, s36, #224
    s.add        s36, s3, s35
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s36, #0]
    vf.cvt.bf16.f32 v17, v13
    v.st.w       [s33, #0], v17
    s.addi       s33, s30, #128
    v.extract    s35, v14, #2
    s.add        s36, s35, s34
    s.addi       s35, s36, #224
    s.add        s36, s3, s35
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s36, #0]
    vf.cvt.bf16.f32 v17, v13
    v.st.w       [s33, #0], v17
    s.addi       s33, s30, #192
    v.extract    s35, v14, #3
    s.add        s36, s35, s34
    s.addi       s35, s36, #224
    s.add        s36, s3, s35
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s36, #0]
    vf.cvt.bf16.f32 v17, v13
    v.st.w       [s33, #0], v17
    s.addi       s33, s30, #256
    v.extract    s35, v14, #4
    s.add        s36, s35, s34
    s.addi       s35, s36, #224
    s.add        s36, s3, s35
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s36, #0]
    vf.cvt.bf16.f32 v17, v13
    v.st.w       [s33, #0], v17
    s.addi       s33, s30, #320
    v.extract    s35, v14, #5
    s.add        s36, s35, s34
    s.addi       s35, s36, #224
    s.add        s36, s3, s35
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s36, #0]
    vf.cvt.bf16.f32 v17, v13
    v.st.w       [s33, #0], v17
    s.addi       s33, s30, #384
    v.extract    s35, v14, #6
    s.add        s36, s35, s34
    s.addi       s35, s36, #224
    s.add        s36, s3, s35
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s36, #0]
    vf.cvt.bf16.f32 v17, v13
    v.st.w       [s33, #0], v17
    s.addi       s33, s30, #448
    v.extract    s35, v14, #7
    s.add        s36, s35, s34
    s.addi       s35, s36, #224
    s.add        s36, s3, s35
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s36, #0]
    vf.cvt.bf16.f32 v17, v13
    v.st.w       [s33, #0], v17
    s.addi       s33, s30, #512
    v.extract    s35, v14, #8
    s.add        s36, s35, s34
    s.addi       s35, s36, #224
    s.add        s36, s3, s35
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s36, #0]
    vf.cvt.bf16.f32 v17, v13
    v.st.w       [s33, #0], v17
    s.addi       s33, s30, #576
    v.extract    s35, v14, #9
    s.add        s36, s35, s34
    s.addi       s35, s36, #224
    s.add        s36, s3, s35
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s36, #0]
    vf.cvt.bf16.f32 v17, v13
    v.st.w       [s33, #0], v17
    s.addi       s33, s30, #640
    v.extract    s35, v14, #10
    s.add        s36, s35, s34
    s.addi       s35, s36, #224
    s.add        s36, s3, s35
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s36, #0]
    vf.cvt.bf16.f32 v17, v13
    v.st.w       [s33, #0], v17
    s.addi       s33, s30, #704
    v.extract    s35, v14, #11
    s.add        s36, s35, s34
    s.addi       s35, s36, #224
    s.add        s36, s3, s35
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s36, #0]
    vf.cvt.bf16.f32 v17, v13
    v.st.w       [s33, #0], v17
    s.addi       s33, s30, #768
    v.extract    s35, v14, #12
    s.add        s36, s35, s34
    s.addi       s35, s36, #224
    s.add        s36, s3, s35
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s36, #0]
    vf.cvt.bf16.f32 v17, v13
    v.st.w       [s33, #0], v17
    s.addi       s33, s30, #832
    v.extract    s35, v14, #13
    s.add        s36, s35, s34
    s.addi       s35, s36, #224
    s.add        s36, s3, s35
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s36, #0]
    vf.cvt.bf16.f32 v17, v13
    v.st.w       [s33, #0], v17
    s.addi       s33, s30, #896
    v.extract    s35, v14, #14
    s.add        s36, s35, s34
    s.addi       s35, s36, #224
    s.add        s36, s3, s35
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s36, #0]
    vf.cvt.bf16.f32 v17, v13
    v.st.w       [s33, #0], v17
    s.addi       s33, s30, #960
    v.extract    s30, v14, #15
    s.add        s35, s30, s34
    s.addi       s30, s35, #224
    s.add        s34, s3, s30
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s34, #0]
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s33, #0], v14
    fence.acq_rel.device
    s.addi       s30, s32, #0
    v.ld.w       v13, [s30, #0]
    vf.abs       v14, v13
    s.addi       s30, s32, #1024
    v.ld.w       v13, [s30, #0]
    vf.abs       v17, v13
    vf.max.ieee  v13, v14, v17
    s.addi       s30, s32, #2048
    v.ld.w       v14, [s30, #0]
    vf.abs       v17, v14
    vf.max.ieee  v14, v13, v17
    s.addi       s30, s32, #3072
    v.ld.w       v13, [s30, #0]
    vf.abs       v17, v13
    vf.max.ieee  v13, v14, v17
    s.addi       s30, s32, #4096
    v.ld.w       v14, [s30, #0]
    vf.abs       v17, v14
    vf.max.ieee  v14, v13, v17
    s.addi       s30, s32, #5120
    v.ld.w       v13, [s30, #0]
    vf.abs       v17, v13
    vf.max.ieee  v13, v14, v17
    s.addi       s30, s32, #6144
    v.ld.w       v14, [s30, #0]
    vf.abs       v17, v14
    vf.max.ieee  v14, v13, v17
    s.addi       s30, s32, #7168
    v.ld.w       v13, [s30, #0]
    vf.abs       v17, v13
    vf.max.ieee  v13, v14, v17
    vf.reduce.max.b v14, v13
    s.addi       s30, s32, #64
    v.ld.w       v13, [s30, #0]
    vf.abs       v17, v13
    s.addi       s30, s32, #1088
    v.ld.w       v13, [s30, #0]
    vf.abs       v18, v13
    vf.max.ieee  v13, v17, v18
    s.addi       s30, s32, #2112
    v.ld.w       v17, [s30, #0]
    vf.abs       v18, v17
    vf.max.ieee  v17, v13, v18
    s.addi       s30, s32, #3136
    v.ld.w       v13, [s30, #0]
    vf.abs       v18, v13
    vf.max.ieee  v13, v17, v18
    s.addi       s30, s32, #4160
    v.ld.w       v17, [s30, #0]
    vf.abs       v18, v17
    vf.max.ieee  v17, v13, v18
    s.addi       s30, s32, #5184
    v.ld.w       v13, [s30, #0]
    vf.abs       v18, v13
    vf.max.ieee  v13, v17, v18
    s.addi       s30, s32, #6208
    v.ld.w       v17, [s30, #0]
    vf.abs       v18, v17
    vf.max.ieee  v17, v13, v18
    s.addi       s30, s32, #7232
    v.ld.w       v13, [s30, #0]
    vf.abs       v18, v13
    vf.max.ieee  v13, v17, v18
    vf.reduce.max.b v17, v13
    s.addi       s30, s32, #128
    v.ld.w       v13, [s30, #0]
    vf.abs       v18, v13
    s.addi       s30, s32, #1152
    v.ld.w       v13, [s30, #0]
    vf.abs       v19, v13
    vf.max.ieee  v13, v18, v19
    s.addi       s30, s32, #2176
    v.ld.w       v18, [s30, #0]
    vf.abs       v19, v18
    vf.max.ieee  v18, v13, v19
    s.addi       s30, s32, #3200
    v.ld.w       v13, [s30, #0]
    vf.abs       v19, v13
    vf.max.ieee  v13, v18, v19
    s.addi       s30, s32, #4224
    v.ld.w       v18, [s30, #0]
    vf.abs       v19, v18
    vf.max.ieee  v18, v13, v19
    s.addi       s30, s32, #5248
    v.ld.w       v13, [s30, #0]
    vf.abs       v19, v13
    vf.max.ieee  v13, v18, v19
    s.addi       s30, s32, #6272
    v.ld.w       v18, [s30, #0]
    vf.abs       v19, v18
    vf.max.ieee  v18, v13, v19
    s.addi       s30, s32, #7296
    v.ld.w       v13, [s30, #0]
    vf.abs       v19, v13
    vf.max.ieee  v13, v18, v19
    vf.reduce.max.b v18, v13
    s.addi       s30, s32, #192
    v.ld.w       v13, [s30, #0]
    vf.abs       v19, v13
    s.addi       s30, s32, #1216
    v.ld.w       v13, [s30, #0]
    vf.abs       v21, v13
    vf.max.ieee  v13, v19, v21
    s.addi       s30, s32, #2240
    v.ld.w       v19, [s30, #0]
    vf.abs       v21, v19
    vf.max.ieee  v19, v13, v21
    s.addi       s30, s32, #3264
    v.ld.w       v13, [s30, #0]
    vf.abs       v21, v13
    vf.max.ieee  v13, v19, v21
    s.addi       s30, s32, #4288
    v.ld.w       v19, [s30, #0]
    vf.abs       v21, v19
    vf.max.ieee  v19, v13, v21
    s.addi       s30, s32, #5312
    v.ld.w       v13, [s30, #0]
    vf.abs       v21, v13
    vf.max.ieee  v13, v19, v21
    s.addi       s30, s32, #6336
    v.ld.w       v19, [s30, #0]
    vf.abs       v21, v19
    vf.max.ieee  v19, v13, v21
    s.addi       s30, s32, #7360
    v.ld.w       v13, [s30, #0]
    vf.abs       v21, v13
    vf.max.ieee  v13, v19, v21
    vf.reduce.max.b v19, v13
    s.addi       s30, s32, #256
    v.ld.w       v13, [s30, #0]
    vf.abs       v21, v13
    s.addi       s30, s32, #1280
    v.ld.w       v13, [s30, #0]
    vf.abs       v22, v13
    vf.max.ieee  v13, v21, v22
    s.addi       s30, s32, #2304
    v.ld.w       v21, [s30, #0]
    vf.abs       v22, v21
    vf.max.ieee  v21, v13, v22
    s.addi       s30, s32, #3328
    v.ld.w       v13, [s30, #0]
    vf.abs       v22, v13
    vf.max.ieee  v13, v21, v22
    s.addi       s30, s32, #4352
    v.ld.w       v21, [s30, #0]
    vf.abs       v22, v21
    vf.max.ieee  v21, v13, v22
    s.addi       s30, s32, #5376
    v.ld.w       v13, [s30, #0]
    vf.abs       v22, v13
    vf.max.ieee  v13, v21, v22
    s.addi       s30, s32, #6400
    v.ld.w       v21, [s30, #0]
    vf.abs       v22, v21
    vf.max.ieee  v21, v13, v22
    s.addi       s30, s32, #7424
    v.ld.w       v13, [s30, #0]
    vf.abs       v22, v13
    vf.max.ieee  v13, v21, v22
    vf.reduce.max.b v21, v13
    s.addi       s30, s32, #320
    v.ld.w       v13, [s30, #0]
    vf.abs       v22, v13
    s.addi       s30, s32, #1344
    v.ld.w       v13, [s30, #0]
    vf.abs       v23, v13
    vf.max.ieee  v13, v22, v23
    s.addi       s30, s32, #2368
    v.ld.w       v22, [s30, #0]
    vf.abs       v23, v22
    vf.max.ieee  v22, v13, v23
    s.addi       s30, s32, #3392
    v.ld.w       v13, [s30, #0]
    vf.abs       v23, v13
    vf.max.ieee  v13, v22, v23
    s.addi       s30, s32, #4416
    v.ld.w       v22, [s30, #0]
    vf.abs       v23, v22
    vf.max.ieee  v22, v13, v23
    s.addi       s30, s32, #5440
    v.ld.w       v13, [s30, #0]
    vf.abs       v23, v13
    vf.max.ieee  v13, v22, v23
    s.addi       s30, s32, #6464
    v.ld.w       v22, [s30, #0]
    vf.abs       v23, v22
    vf.max.ieee  v22, v13, v23
    s.addi       s30, s32, #7488
    v.ld.w       v13, [s30, #0]
    vf.abs       v23, v13
    vf.max.ieee  v13, v22, v23
    vf.reduce.max.b v22, v13
    s.addi       s30, s32, #384
    v.ld.w       v13, [s30, #0]
    vf.abs       v23, v13
    s.addi       s30, s32, #1408
    v.ld.w       v13, [s30, #0]
    vf.abs       v24, v13
    vf.max.ieee  v13, v23, v24
    s.addi       s30, s32, #2432
    v.ld.w       v23, [s30, #0]
    vf.abs       v24, v23
    vf.max.ieee  v23, v13, v24
    s.addi       s30, s32, #3456
    v.ld.w       v13, [s30, #0]
    vf.abs       v24, v13
    vf.max.ieee  v13, v23, v24
    s.addi       s30, s32, #4480
    v.ld.w       v23, [s30, #0]
    vf.abs       v24, v23
    vf.max.ieee  v23, v13, v24
    s.addi       s30, s32, #5504
    v.ld.w       v13, [s30, #0]
    vf.abs       v24, v13
    vf.max.ieee  v13, v23, v24
    s.addi       s30, s32, #6528
    v.ld.w       v23, [s30, #0]
    vf.abs       v24, v23
    vf.max.ieee  v23, v13, v24
    s.addi       s30, s32, #7552
    v.ld.w       v13, [s30, #0]
    vf.abs       v24, v13
    vf.max.ieee  v13, v23, v24
    vf.reduce.max.b v23, v13
    s.addi       s30, s32, #448
    v.ld.w       v13, [s30, #0]
    vf.abs       v24, v13
    s.addi       s30, s32, #1472
    v.ld.w       v13, [s30, #0]
    vf.abs       v26, v13
    vf.max.ieee  v13, v24, v26
    s.addi       s30, s32, #2496
    v.ld.w       v24, [s30, #0]
    vf.abs       v26, v24
    vf.max.ieee  v24, v13, v26
    s.addi       s30, s32, #3520
    v.ld.w       v13, [s30, #0]
    vf.abs       v26, v13
    vf.max.ieee  v13, v24, v26
    s.addi       s30, s32, #4544
    v.ld.w       v24, [s30, #0]
    vf.abs       v26, v24
    vf.max.ieee  v24, v13, v26
    s.addi       s30, s32, #5568
    v.ld.w       v13, [s30, #0]
    vf.abs       v26, v13
    vf.max.ieee  v13, v24, v26
    s.addi       s30, s32, #6592
    v.ld.w       v24, [s30, #0]
    vf.abs       v26, v24
    vf.max.ieee  v24, v13, v26
    s.addi       s30, s32, #7616
    v.ld.w       v13, [s30, #0]
    vf.abs       v26, v13
    vf.max.ieee  v13, v24, v26
    vf.reduce.max.b v24, v13
    s.addi       s30, s32, #512
    v.ld.w       v13, [s30, #0]
    vf.abs       v26, v13
    s.addi       s30, s32, #1536
    v.ld.w       v13, [s30, #0]
    vf.abs       v27, v13
    vf.max.ieee  v13, v26, v27
    s.addi       s30, s32, #2560
    v.ld.w       v26, [s30, #0]
    vf.abs       v27, v26
    vf.max.ieee  v26, v13, v27
    s.addi       s30, s32, #3584
    v.ld.w       v13, [s30, #0]
    vf.abs       v27, v13
    vf.max.ieee  v13, v26, v27
    s.addi       s30, s32, #4608
    v.ld.w       v26, [s30, #0]
    vf.abs       v27, v26
    vf.max.ieee  v26, v13, v27
    s.addi       s30, s32, #5632
    v.ld.w       v13, [s30, #0]
    vf.abs       v27, v13
    vf.max.ieee  v13, v26, v27
    s.addi       s30, s32, #6656
    v.ld.w       v26, [s30, #0]
    vf.abs       v27, v26
    vf.max.ieee  v26, v13, v27
    s.addi       s30, s32, #7680
    v.ld.w       v13, [s30, #0]
    vf.abs       v27, v13
    vf.max.ieee  v13, v26, v27
    vf.reduce.max.b v26, v13
    s.addi       s30, s32, #576
    v.ld.w       v13, [s30, #0]
    vf.abs       v27, v13
    s.addi       s30, s32, #1600
    v.ld.w       v13, [s30, #0]
    vf.abs       v28, v13
    vf.max.ieee  v13, v27, v28
    s.addi       s30, s32, #2624
    v.ld.w       v27, [s30, #0]
    vf.abs       v28, v27
    vf.max.ieee  v27, v13, v28
    s.addi       s30, s32, #3648
    v.ld.w       v13, [s30, #0]
    vf.abs       v28, v13
    vf.max.ieee  v13, v27, v28
    s.addi       s30, s32, #4672
    v.ld.w       v27, [s30, #0]
    vf.abs       v28, v27
    vf.max.ieee  v27, v13, v28
    s.addi       s30, s32, #5696
    v.ld.w       v13, [s30, #0]
    vf.abs       v28, v13
    vf.max.ieee  v13, v27, v28
    s.addi       s30, s32, #6720
    v.ld.w       v27, [s30, #0]
    vf.abs       v28, v27
    vf.max.ieee  v27, v13, v28
    s.addi       s30, s32, #7744
    v.ld.w       v13, [s30, #0]
    vf.abs       v28, v13
    vf.max.ieee  v13, v27, v28
    vf.reduce.max.b v27, v13
    s.addi       s30, s32, #640
    v.ld.w       v13, [s30, #0]
    vf.abs       v28, v13
    s.addi       s30, s32, #1664
    v.ld.w       v13, [s30, #0]
    vf.abs       v29, v13
    vf.max.ieee  v13, v28, v29
    s.addi       s30, s32, #2688
    v.ld.w       v28, [s30, #0]
    vf.abs       v29, v28
    vf.max.ieee  v28, v13, v29
    s.addi       s30, s32, #3712
    v.ld.w       v13, [s30, #0]
    vf.abs       v29, v13
    vf.max.ieee  v13, v28, v29
    s.addi       s30, s32, #4736
    v.ld.w       v28, [s30, #0]
    vf.abs       v29, v28
    vf.max.ieee  v28, v13, v29
    s.addi       s30, s32, #5760
    v.ld.w       v13, [s30, #0]
    vf.abs       v29, v13
    vf.max.ieee  v13, v28, v29
    s.addi       s30, s32, #6784
    v.ld.w       v28, [s30, #0]
    vf.abs       v29, v28
    vf.max.ieee  v28, v13, v29
    s.addi       s30, s32, #7808
    v.ld.w       v13, [s30, #0]
    vf.abs       v29, v13
    vf.max.ieee  v13, v28, v29
    vf.reduce.max.b v28, v13
    s.addi       s30, s32, #704
    v.ld.w       v13, [s30, #0]
    vf.abs       v29, v13
    s.addi       s30, s32, #1728
    v.ld.w       v13, [s30, #0]
    vf.abs       v30, v13
    vf.max.ieee  v13, v29, v30
    s.addi       s30, s32, #2752
    v.ld.w       v29, [s30, #0]
    vf.abs       v30, v29
    vf.max.ieee  v29, v13, v30
    s.addi       s30, s32, #3776
    v.ld.w       v13, [s30, #0]
    vf.abs       v30, v13
    vf.max.ieee  v13, v29, v30
    s.addi       s30, s32, #4800
    v.ld.w       v29, [s30, #0]
    vf.abs       v30, v29
    vf.max.ieee  v29, v13, v30
    s.addi       s30, s32, #5824
    v.ld.w       v13, [s30, #0]
    vf.abs       v30, v13
    vf.max.ieee  v13, v29, v30
    s.addi       s30, s32, #6848
    v.ld.w       v29, [s30, #0]
    vf.abs       v30, v29
    vf.max.ieee  v29, v13, v30
    s.addi       s30, s32, #7872
    v.ld.w       v13, [s30, #0]
    vf.abs       v30, v13
    vf.max.ieee  v13, v29, v30
    vf.reduce.max.b v29, v13
    s.addi       s30, s32, #768
    v.ld.w       v13, [s30, #0]
    vf.abs       v30, v13
    s.addi       s30, s32, #1792
    v.ld.w       v13, [s30, #0]
    vf.abs       v31, v13
    vf.max.ieee  v13, v30, v31
    s.addi       s30, s32, #2816
    v.ld.w       v30, [s30, #0]
    vf.abs       v31, v30
    vf.max.ieee  v30, v13, v31
    s.addi       s30, s32, #3840
    v.ld.w       v13, [s30, #0]
    vf.abs       v31, v13
    vf.max.ieee  v13, v30, v31
    s.addi       s30, s32, #4864
    v.ld.w       v30, [s30, #0]
    vf.abs       v31, v30
    vf.max.ieee  v30, v13, v31
    s.addi       s30, s32, #5888
    v.ld.w       v13, [s30, #0]
    vf.abs       v31, v13
    vf.max.ieee  v13, v30, v31
    s.addi       s30, s32, #6912
    v.ld.w       v30, [s30, #0]
    vf.abs       v31, v30
    vf.max.ieee  v30, v13, v31
    s.addi       s30, s32, #7936
    v.ld.w       v13, [s30, #0]
    vf.abs       v31, v13
    vf.max.ieee  v13, v30, v31
    vf.reduce.max.b v30, v13
    s.addi       s30, s32, #832
    v.ld.w       v13, [s30, #0]
    vf.abs       v31, v13
    s.addi       s30, s32, #1856
    v.ld.w       v13, [s30, #0]
    vf.abs       v32, v13
    vf.max.ieee  v13, v31, v32
    s.addi       s30, s32, #2880
    v.ld.w       v31, [s30, #0]
    vf.abs       v32, v31
    vf.max.ieee  v31, v13, v32
    s.addi       s30, s32, #3904
    v.ld.w       v13, [s30, #0]
    vf.abs       v32, v13
    vf.max.ieee  v13, v31, v32
    s.addi       s30, s32, #4928
    v.ld.w       v31, [s30, #0]
    vf.abs       v32, v31
    vf.max.ieee  v31, v13, v32
    s.addi       s30, s32, #5952
    v.ld.w       v13, [s30, #0]
    vf.abs       v32, v13
    vf.max.ieee  v13, v31, v32
    s.addi       s30, s32, #6976
    v.ld.w       v31, [s30, #0]
    vf.abs       v32, v31
    vf.max.ieee  v31, v13, v32
    s.addi       s30, s32, #8000
    v.ld.w       v13, [s30, #0]
    vf.abs       v32, v13
    vf.max.ieee  v13, v31, v32
    vf.reduce.max.b v31, v13
    s.addi       s30, s32, #896
    v.ld.w       v13, [s30, #0]
    vf.abs       v32, v13
    s.addi       s30, s32, #1920
    v.ld.w       v13, [s30, #0]
    vf.abs       v33, v13
    vf.max.ieee  v13, v32, v33
    s.addi       s30, s32, #2944
    v.ld.w       v32, [s30, #0]
    vf.abs       v33, v32
    vf.max.ieee  v32, v13, v33
    s.addi       s30, s32, #3968
    v.ld.w       v13, [s30, #0]
    vf.abs       v33, v13
    vf.max.ieee  v13, v32, v33
    s.addi       s30, s32, #4992
    v.ld.w       v32, [s30, #0]
    vf.abs       v33, v32
    vf.max.ieee  v32, v13, v33
    s.addi       s30, s32, #6016
    v.ld.w       v13, [s30, #0]
    vf.abs       v33, v13
    vf.max.ieee  v13, v32, v33
    s.addi       s30, s32, #7040
    v.ld.w       v32, [s30, #0]
    vf.abs       v33, v32
    vf.max.ieee  v32, v13, v33
    s.addi       s30, s32, #8064
    v.ld.w       v13, [s30, #0]
    vf.abs       v33, v13
    vf.max.ieee  v13, v32, v33
    vf.reduce.max.b v32, v13
    s.addi       s30, s32, #960
    v.ld.w       v13, [s30, #0]
    vf.abs       v33, v13
    s.addi       s30, s32, #1984
    v.ld.w       v13, [s30, #0]
    vf.abs       v34, v13
    vf.max.ieee  v13, v33, v34
    s.addi       s30, s32, #3008
    v.ld.w       v33, [s30, #0]
    vf.abs       v34, v33
    vf.max.ieee  v33, v13, v34
    s.addi       s30, s32, #4032
    v.ld.w       v13, [s30, #0]
    vf.abs       v34, v13
    vf.max.ieee  v13, v33, v34
    s.addi       s30, s32, #5056
    v.ld.w       v33, [s30, #0]
    vf.abs       v34, v33
    vf.max.ieee  v33, v13, v34
    s.addi       s30, s32, #6080
    v.ld.w       v13, [s30, #0]
    vf.abs       v34, v13
    vf.max.ieee  v13, v33, v34
    s.addi       s30, s32, #7104
    v.ld.w       v33, [s30, #0]
    vf.abs       v34, v33
    vf.max.ieee  v33, v13, v34
    s.addi       s30, s32, #8128
    v.ld.w       v13, [s30, #0]
    vf.abs       v34, v13
    vf.max.ieee  v13, v33, v34
    vf.reduce.max.b v33, v13
    v.movi       v13, #0
    // one value per row into one vector (ISA 0x09)
    v.extract    s30, v14, #0
    v.insert     v13, s30, #0
    v.extract    s30, v17, #0
    v.insert     v13, s30, #1
    v.extract    s30, v18, #0
    v.insert     v13, s30, #2
    v.extract    s30, v19, #0
    v.insert     v13, s30, #3
    v.extract    s30, v21, #0
    v.insert     v13, s30, #4
    v.extract    s30, v22, #0
    v.insert     v13, s30, #5
    v.extract    s30, v23, #0
    v.insert     v13, s30, #6
    v.extract    s30, v24, #0
    v.insert     v13, s30, #7
    v.extract    s30, v26, #0
    v.insert     v13, s30, #8
    v.extract    s30, v27, #0
    v.insert     v13, s30, #9
    v.extract    s30, v28, #0
    v.insert     v13, s30, #10
    v.extract    s30, v29, #0
    v.insert     v13, s30, #11
    v.extract    s30, v30, #0
    v.insert     v13, s30, #12
    v.extract    s30, v31, #0
    v.insert     v13, s30, #13
    v.extract    s30, v32, #0
    v.insert     v13, s30, #14
    v.extract    s30, v33, #0
    v.insert     v13, s30, #15
    .li       s30, #1138753536
    v.splat      v14, s30                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v17, v14                        // ISA 8.8: <= 2**-22 relative
    .li       s30, #1065353216
    v.splat      v18, s30                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v19, v14, v17, v18
    vf.fms       v21, v17, v19, v17
    vf.neg       v19, v21                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v21, v19, v17
    vf.mul       v17, v13, v21                   // a/y: faithful quotient
    vf.fms       v19, v17, v14, v13
    vf.fms       v13, v19, v21, v17
    vf.neg       v14, v13                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v14, v14
    @p1 v.sel        v13, v14, v17
    .li       s30, #730643660
    v.splat      v14, s30                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v17, s11
    v.mul        v19, v20, v17
    v.splat      v17, s11
    v.mul        v21, v9, v17
    v.splat      v17, s11
    v.mul        v22, v12, v17
    v.splat      v17, s11
    v.mul        v23, v8, v17
    v.splat      v17, s11
    v.mul        v24, v6, v17
    v.splat      v17, s11
    v.mul        v26, v5, v17
    v.splat      v17, s11
    v.mul        v27, v10, v17
    v.splat      v17, s11
    v.mul        v28, v3, v17
    v.ld.gather.w v17, [s25, v25]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v29, [s25, v2]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v30, [s25, v1]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v31, [s25, v11]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v32, [s25, v15]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v33, [s25, v16]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v34, [s25, v7]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v35, [s25, v4]                 // index is in elements (ISA sec 9.1)
    s.add        s30, s27, s31
    // tl.dot 16x128 by 128x128 FP8, B as W's rows written transposed by the engine (ISA sec 9E, tensor_transpose_8bit)
    v.movi       v36, #0
    v.movi       v37, #0
    v.iota       v38                             // arange(0, VLEN)
    s.movz       s31, #0
    s.cmp.ge     s33, s30, s31
    v.extract    s31, v20, #0
    v.splat      v39, s31
    v.add        v40, v39, v38
    v.sub        v39, v20, v40
    v.reduce.or  s34, v39
    s.movz       s35, #0
    s.cmp.eq     s36, s34, s35
    s.movz       s34, #0
    s.cmp.ge     s35, s31, s34
    s.and        s34, s36, s35
    s.and        s35, s34, s33
    v.insert     v36, s35, #0
    v.insert     v37, s31, #0
    v.extract    s31, v9, #0
    v.splat      v39, s31
    v.add        v40, v39, v38
    v.sub        v39, v9, v40
    v.reduce.or  s34, v39
    s.movz       s35, #0
    s.cmp.eq     s36, s34, s35
    s.movz       s34, #0
    s.cmp.ge     s35, s31, s34
    s.and        s34, s36, s35
    s.and        s35, s34, s33
    v.insert     v36, s35, #1
    v.insert     v37, s31, #1
    v.extract    s31, v12, #0
    v.splat      v39, s31
    v.add        v40, v39, v38
    v.sub        v39, v12, v40
    v.reduce.or  s34, v39
    s.movz       s35, #0
    s.cmp.eq     s36, s34, s35
    s.movz       s34, #0
    s.cmp.ge     s35, s31, s34
    s.and        s34, s36, s35
    s.and        s35, s34, s33
    v.insert     v36, s35, #2
    v.insert     v37, s31, #2
    v.extract    s31, v8, #0
    v.splat      v39, s31
    v.add        v40, v39, v38
    v.sub        v39, v8, v40
    v.reduce.or  s34, v39
    s.movz       s35, #0
    s.cmp.eq     s36, s34, s35
    s.movz       s34, #0
    s.cmp.ge     s35, s31, s34
    s.and        s34, s36, s35
    s.and        s35, s34, s33
    v.insert     v36, s35, #3
    v.insert     v37, s31, #3
    v.extract    s31, v6, #0
    v.splat      v39, s31
    v.add        v40, v39, v38
    v.sub        v39, v6, v40
    v.reduce.or  s34, v39
    s.movz       s35, #0
    s.cmp.eq     s36, s34, s35
    s.movz       s34, #0
    s.cmp.ge     s35, s31, s34
    s.and        s34, s36, s35
    s.and        s35, s34, s33
    v.insert     v36, s35, #4
    v.insert     v37, s31, #4
    v.extract    s31, v5, #0
    v.splat      v39, s31
    v.add        v40, v39, v38
    v.sub        v39, v5, v40
    v.reduce.or  s34, v39
    s.movz       s35, #0
    s.cmp.eq     s36, s34, s35
    s.movz       s34, #0
    s.cmp.ge     s35, s31, s34
    s.and        s34, s36, s35
    s.and        s35, s34, s33
    v.insert     v36, s35, #5
    v.insert     v37, s31, #5
    v.extract    s31, v10, #0
    v.splat      v39, s31
    v.add        v40, v39, v38
    v.sub        v39, v10, v40
    v.reduce.or  s34, v39
    s.movz       s35, #0
    s.cmp.eq     s36, s34, s35
    s.movz       s34, #0
    s.cmp.ge     s35, s31, s34
    s.and        s34, s36, s35
    s.and        s35, s34, s33
    v.insert     v36, s35, #6
    v.insert     v37, s31, #6
    v.extract    s31, v3, #0
    v.splat      v39, s31
    v.add        v40, v39, v38
    v.sub        v38, v3, v40
    v.reduce.or  s34, v38
    s.movz       s35, #0
    s.cmp.eq     s36, s34, s35
    s.movz       s34, #0
    s.cmp.ge     s35, s31, s34
    s.and        s34, s36, s35
    s.and        s35, s34, s33
    v.insert     v36, s35, #7
    v.insert     v37, s31, #7
    s.add        s31, s2, s1
    s.addi       s33, s32, #8192                 // TensorMap 0: W's rows for a transposed FP8 B
    s.movz       s34, #0
    s.st.d       [s33, #0], s31
    .li       s31, #2147483647
    s.st.d       [s33, #8], s31
    s.st.d       [s33, #16], s30
    s.st.d       [s33, #48], s11
    s.movz       s31, #1
    s.st.d       [s33, #56], s31
    .li       s31, #137438953488
    s.st.d       [s33, #88], s31
    .li       s31, #7705171329024
    s.st.d       [s33, #104], s31
    td.load      d0, [s33]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s31, s32, #8448
    s.addi       s33, s32, #8960                 // TensorMap 1: the gathered fallback B tile
    s.movz       s34, #0
    s.st.d       [s33, #0], s31
    s.movz       s31, #32
    s.st.d       [s33, #8], s31
    s.movz       s31, #16
    s.st.d       [s33, #16], s31
    s.movz       s31, #16
    s.st.d       [s33, #48], s31
    s.movz       s31, #1
    s.st.d       [s33, #56], s31
    .li       s31, #68719476768
    s.st.d       [s33, #88], s31
    .li       s31, #7705171329024
    s.st.d       [s33, #104], s31
    td.load      d1, [s33]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    s.addi       s31, s32, #9216                 // 512 bytes of repack scratch
    s.addi       s33, s32, #0
    v.ld.w       v38, [s33, #0]
    v.extract    s33, v13, #0
    v.splat      v39, s33
    vf.max.ieee  v40, v39, v14
    v.rcp.approx v39, v40                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v41, v40, v39, v18
    vf.fms       v42, v39, v41, v39
    vf.neg       v41, v42                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v42, v41, v39
    vf.mul       v39, v38, v42                   // a/y: faithful quotient
    vf.fms       v41, v39, v40, v38
    vf.fms       v38, v41, v42, v39
    vf.neg       v40, v38                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v38, v40, v39
    vf.cvt.f32.e4m3 v39, v38
    v.movi       v40, #24
    v.lshr       v41, v38, v40
    v.movi       v38, #128
    v.and        v42, v41, v38
    v.or         v41, v39, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #0
    v.st.b       [s33, #0], v41
    s.addi       s33, s32, #64
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #1
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #32
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #128
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #2
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #64
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #192
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #3
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #96
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #256
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #4
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #128
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #320
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #5
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #160
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #384
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #6
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #192
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #448
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #7
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #224
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #512
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #8
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #256
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #576
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #9
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #288
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #640
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #10
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #320
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #704
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #11
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #352
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #768
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #12
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #384
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #832
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #13
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #416
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #896
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #14
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #448
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #960
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #15
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #480
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #1024
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #0
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #16
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #1088
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #1
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #48
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #1152
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #2
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #80
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #1216
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #3
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #112
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #1280
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #4
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #144
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #1344
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #5
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #176
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #1408
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #6
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #208
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #1472
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #7
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #240
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #1536
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #8
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #272
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #1600
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #9
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #304
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #1664
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #10
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #336
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #1728
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #11
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #368
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #1792
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #12
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #400
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #1856
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #13
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #432
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #1920
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #14
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #464
    v.st.b       [s33, #0], v42
    s.addi       s33, s32, #1984
    v.ld.w       v39, [s33, #0]
    v.extract    s33, v13, #15
    v.splat      v41, s33
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s31, #496
    v.st.b       [s33, #0], v42
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    v.ld.w       v39, [s31, #0]
    v.mov        v48, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s33, s31, #64
    v.ld.w       v39, [s33, #0]
    v.mov        v49, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s33, s31, #128
    v.ld.w       v39, [s33, #0]
    v.mov        v50, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s33, s31, #192
    v.ld.w       v39, [s33, #0]
    v.mov        v51, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s33, s31, #256
    v.ld.w       v39, [s33, #0]
    v.mov        v52, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s33, s31, #320
    v.ld.w       v39, [s33, #0]
    v.mov        v53, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s33, s31, #384
    v.ld.w       v39, [s33, #0]
    v.mov        v54, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s33, s31, #448
    v.ld.w       v39, [s33, #0]
    v.mov        v55, v39                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s31, v36, #0
    br.nz        s31, x8dot_done_30
    s.movz       s33, #0
    s.add        s34, s2, s1
    s.addi       s35, s33, #0
    s.addi       s33, s32, #8448
x8dot_row_31:
    s.addi       s36, s30, #0
    v.movi       v39, #0
    s.sub        s37, s36, s35
    s.add        s36, s34, s35
    v.splat      v41, s37
    s.shli       s37, s35, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s36, v19]            // index is in elements (ISA sec 9.1)
    s.add        s36, s33, s37
    s.addi       s37, s35, #1
    s.movz       s38, #32
    v.st.b       [s36, #0], v39
    fence.acq_rel.device
    s.mov        s35, s37
    s.cmp.lt     s36, s35, s38
    br.nz        s36, x8dot_row_31
x8dot_done_30:
    v.splat      v39, s31
    v.movi       v41, #0
    mb.arm       s33, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s34, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s31
    v.movi       v41, #0
    s.movz       s31, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s35, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s35, s33            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s31, #0
    v.extract    s34, v37, #0
    s.mov        s35, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s35, s33          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s33
    mb.arm       s31, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s34, v36, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s31
    mb.wait      s31
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s34, x8dot_done_32
    s.movz       s35, #0
    s.add        s36, s2, s1
    s.addi       s37, s35, #0
    s.addi       s35, s32, #8448
x8dot_row_33:
    s.addi       s38, s30, #0
    v.movi       v39, #0
    s.sub        s39, s38, s37
    s.add        s38, s36, s37
    v.splat      v41, s39
    s.shli       s39, s37, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s38, v21]            // index is in elements (ISA sec 9.1)
    s.add        s38, s35, s39
    s.addi       s39, s37, #1
    s.movz       s40, #32
    v.st.b       [s38, #0], v39
    fence.acq_rel.device
    s.mov        s37, s39
    s.cmp.lt     s38, s37, s40
    br.nz        s38, x8dot_row_33
x8dot_done_32:
    v.splat      v39, s34
    v.movi       v41, #0
    mb.arm       s35, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s36, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s34
    v.movi       v41, #0
    s.movz       s34, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s37, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s37, s35            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s34, #0
    v.extract    s36, v37, #1
    s.mov        s37, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s37, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    mb.arm       s34, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s36, v36, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s34
    mb.wait      s34
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s36, x8dot_done_34
    s.movz       s37, #0
    s.add        s38, s2, s1
    s.addi       s39, s37, #0
    s.addi       s37, s32, #8448
x8dot_row_35:
    s.addi       s40, s30, #0
    v.movi       v39, #0
    s.sub        s41, s40, s39
    s.add        s40, s38, s39
    v.splat      v41, s41
    s.shli       s41, s39, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s40, v22]            // index is in elements (ISA sec 9.1)
    s.add        s40, s37, s41
    s.addi       s41, s39, #1
    s.movz       s42, #32
    v.st.b       [s40, #0], v39
    fence.acq_rel.device
    s.mov        s39, s41
    s.cmp.lt     s40, s39, s42
    br.nz        s40, x8dot_row_35
x8dot_done_34:
    v.splat      v39, s36
    v.movi       v41, #0
    mb.arm       s37, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s38, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s36
    v.movi       v41, #0
    s.movz       s36, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s39, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s39, s37            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s36, #0
    v.extract    s38, v37, #2
    s.mov        s39, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s39, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s36, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s38, v36, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s36
    mb.wait      s36
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s38, x8dot_done_36
    s.movz       s39, #0
    s.add        s40, s2, s1
    s.addi       s41, s39, #0
    s.addi       s39, s32, #8448
x8dot_row_37:
    s.addi       s42, s30, #0
    v.movi       v39, #0
    s.sub        s43, s42, s41
    s.add        s42, s40, s41
    v.splat      v41, s43
    s.shli       s43, s41, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s42, v23]            // index is in elements (ISA sec 9.1)
    s.add        s42, s39, s43
    s.addi       s43, s41, #1
    s.movz       s44, #32
    v.st.b       [s42, #0], v39
    fence.acq_rel.device
    s.mov        s41, s43
    s.cmp.lt     s42, s41, s44
    br.nz        s42, x8dot_row_37
x8dot_done_36:
    v.splat      v39, s38
    v.movi       v41, #0
    mb.arm       s39, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s40, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s38
    v.movi       v41, #0
    s.movz       s38, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s41, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s41, s39            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s38, #0
    v.extract    s40, v37, #3
    s.mov        s41, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s39          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s39
    mb.arm       s38, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s40, v36, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s38
    mb.wait      s38
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s40, x8dot_done_38
    s.movz       s41, #0
    s.add        s42, s2, s1
    s.addi       s43, s41, #0
    s.addi       s41, s32, #8448
x8dot_row_39:
    s.addi       s44, s30, #0
    v.movi       v39, #0
    s.sub        s45, s44, s43
    s.add        s44, s42, s43
    v.splat      v41, s45
    s.shli       s45, s43, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s44, v24]            // index is in elements (ISA sec 9.1)
    s.add        s44, s41, s45
    s.addi       s45, s43, #1
    s.movz       s46, #32
    v.st.b       [s44, #0], v39
    fence.acq_rel.device
    s.mov        s43, s45
    s.cmp.lt     s44, s43, s46
    br.nz        s44, x8dot_row_39
x8dot_done_38:
    v.splat      v39, s40
    v.movi       v41, #0
    mb.arm       s41, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s42, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s40
    v.movi       v41, #0
    s.movz       s40, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s43, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s43, s41            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s40, #0
    v.extract    s42, v37, #4
    s.mov        s43, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s43, s41          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s41
    mb.arm       s40, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s42, v36, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s40
    mb.wait      s40
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s42, x8dot_done_40
    s.movz       s43, #0
    s.add        s44, s2, s1
    s.addi       s45, s43, #0
    s.addi       s43, s32, #8448
x8dot_row_41:
    s.addi       s46, s30, #0
    v.movi       v39, #0
    s.sub        s47, s46, s45
    s.add        s46, s44, s45
    v.splat      v41, s47
    s.shli       s47, s45, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s46, v26]            // index is in elements (ISA sec 9.1)
    s.add        s46, s43, s47
    s.addi       s47, s45, #1
    s.movz       s48, #32
    v.st.b       [s46, #0], v39
    fence.acq_rel.device
    s.mov        s45, s47
    s.cmp.lt     s46, s45, s48
    br.nz        s46, x8dot_row_41
x8dot_done_40:
    v.splat      v39, s42
    v.movi       v41, #0
    mb.arm       s43, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s44, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s42
    v.movi       v41, #0
    s.movz       s42, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s45, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s45, s43            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s42, #0
    v.extract    s44, v37, #5
    s.mov        s45, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s45, s43          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s43
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s44, v36, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s42
    mb.wait      s42
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s44, x8dot_done_42
    s.movz       s45, #0
    s.add        s46, s2, s1
    s.addi       s47, s45, #0
    s.addi       s45, s32, #8448
x8dot_row_43:
    s.addi       s48, s30, #0
    v.movi       v39, #0
    s.sub        s49, s48, s47
    s.add        s48, s46, s47
    v.splat      v41, s49
    s.shli       s49, s47, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s48, v27]            // index is in elements (ISA sec 9.1)
    s.add        s48, s45, s49
    s.addi       s49, s47, #1
    s.movz       s50, #32
    v.st.b       [s48, #0], v39
    fence.acq_rel.device
    s.mov        s47, s49
    s.cmp.lt     s48, s47, s50
    br.nz        s48, x8dot_row_43
x8dot_done_42:
    v.splat      v39, s44
    v.movi       v41, #0
    mb.arm       s45, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s46, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s44
    v.movi       v41, #0
    s.movz       s44, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s47, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s47, s45            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s44, #0
    v.extract    s46, v37, #6
    s.mov        s47, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s47, s45          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s45
    mb.arm       s44, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s46, v36, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s44
    mb.wait      s44
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s46, x8dot_done_44
    s.movz       s47, #0
    s.add        s48, s2, s1
    s.addi       s49, s47, #0
    s.addi       s47, s32, #8448
x8dot_row_45:
    s.addi       s50, s30, #0
    v.movi       v39, #0
    s.sub        s51, s50, s49
    s.add        s50, s48, s49
    v.splat      v41, s51
    s.shli       s51, s49, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s50, v28]            // index is in elements (ISA sec 9.1)
    s.add        s50, s47, s51
    s.addi       s51, s49, #1
    s.movz       s52, #32
    v.st.b       [s50, #0], v39
    fence.acq_rel.device
    s.mov        s49, s51
    s.cmp.lt     s50, s49, s52
    br.nz        s50, x8dot_row_45
x8dot_done_44:
    v.splat      v39, s46
    v.movi       v41, #0
    v.splat      v42, s46
    v.movi       v43, #0
    mb.arm       s46, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s47, #0
    s.movz       s48, #0
    v.cmp.ne     p1, v39, v41
    v.cmp.eq     p2, v42, v43
    s.mov        s49, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s49, s46            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s47, v13, #0
    v.splat      v39, s47
    s.movz       s47, #0
    vf.max.ieee  v41, v39, v14
    v.extract    s48, v37, #7
    s.mov        s49, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s49, s46          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s46
    v.rcp.approx v39, v41                        // ISA 8.8: <= 2**-22 relative
    mb.arm       s47, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s48, s32, #2048
    m.mma.async.k32.e4m3 a15, v48, v56, s47
    mb.wait      s47
    v.ld.w       v42, [s48, #0]
    s.addi       s48, s32, #9728                 // 512 bytes of repack scratch
    s.addi       s49, s48, #0
    vf.fms       v43, v41, v39, v18
    vf.fms       v44, v39, v43, v39
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v39
    vf.mul       v39, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v39, v41, v42
    vf.fms       v41, v43, v44, v39
    vf.neg       v42, v41                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v41, v42, v39
    vf.cvt.f32.e4m3 v39, v41
    v.lshr       v42, v41, v40
    v.and        v41, v42, v38
    v.or         v42, v39, v41                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #1
    v.splat      v39, s49
    s.addi       s49, s32, #2112
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #32
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #2
    v.splat      v39, s49
    s.addi       s49, s32, #2176
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #64
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #3
    v.splat      v39, s49
    s.addi       s49, s32, #2240
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #96
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #4
    v.splat      v39, s49
    s.addi       s49, s32, #2304
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #128
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #5
    v.splat      v39, s49
    s.addi       s49, s32, #2368
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #160
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #6
    v.splat      v39, s49
    s.addi       s49, s32, #2432
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #192
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #7
    v.splat      v39, s49
    s.addi       s49, s32, #2496
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #224
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #8
    v.splat      v39, s49
    s.addi       s49, s32, #2560
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #256
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #9
    v.splat      v39, s49
    s.addi       s49, s32, #2624
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #288
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #10
    v.splat      v39, s49
    s.addi       s49, s32, #2688
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #320
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #11
    v.splat      v39, s49
    s.addi       s49, s32, #2752
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #352
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #12
    v.splat      v39, s49
    s.addi       s49, s32, #2816
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #384
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #13
    v.splat      v39, s49
    s.addi       s49, s32, #2880
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #416
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #14
    v.splat      v39, s49
    s.addi       s49, s32, #2944
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #448
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #15
    v.splat      v39, s49
    s.addi       s49, s32, #3008
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #480
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #0
    v.splat      v39, s49
    s.addi       s49, s32, #3072
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #16
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #1
    v.splat      v39, s49
    s.addi       s49, s32, #3136
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #48
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #2
    v.splat      v39, s49
    s.addi       s49, s32, #3200
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #80
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #3
    v.splat      v39, s49
    s.addi       s49, s32, #3264
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #112
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #4
    v.splat      v39, s49
    s.addi       s49, s32, #3328
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #144
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #5
    v.splat      v39, s49
    s.addi       s49, s32, #3392
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #176
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #6
    v.splat      v39, s49
    s.addi       s49, s32, #3456
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #208
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #7
    v.splat      v39, s49
    s.addi       s49, s32, #3520
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #240
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #8
    v.splat      v39, s49
    s.addi       s49, s32, #3584
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #272
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #9
    v.splat      v39, s49
    s.addi       s49, s32, #3648
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #304
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #10
    v.splat      v39, s49
    s.addi       s49, s32, #3712
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #336
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #11
    v.splat      v39, s49
    s.addi       s49, s32, #3776
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #368
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #12
    v.splat      v39, s49
    s.addi       s49, s32, #3840
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #400
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #13
    v.splat      v39, s49
    s.addi       s49, s32, #3904
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #432
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #14
    v.splat      v39, s49
    s.addi       s49, s32, #3968
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #464
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    v.extract    s49, v13, #15
    v.splat      v39, s49
    s.addi       s49, s32, #4032
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s49, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s49, s48, #496
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s49, s48, #64
    v.ld.w       v39, [s48, #0]
    v.mov        v48, v39                        // hand off through the shared window (sec 7.3)
    v.ld.w       v39, [s49, #0]
    s.addi       s49, s48, #128
    v.mov        v49, v39                        // hand off through the shared window (sec 7.3)
    v.ld.w       v39, [s49, #0]
    s.addi       s49, s48, #192
    v.mov        v50, v39                        // hand off through the shared window (sec 7.3)
    v.ld.w       v39, [s49, #0]
    s.addi       s49, s48, #256
    v.mov        v51, v39                        // hand off through the shared window (sec 7.3)
    v.ld.w       v39, [s49, #0]
    s.addi       s49, s48, #320
    v.mov        v52, v39                        // hand off through the shared window (sec 7.3)
    v.ld.w       v39, [s49, #0]
    s.addi       s49, s48, #384
    s.addi       s50, s48, #448
    v.mov        v53, v39                        // hand off through the shared window (sec 7.3)
    v.ld.w       v39, [s49, #0]
    v.extract    s48, v36, #0
    v.mov        v54, v39                        // hand off through the shared window (sec 7.3)
    v.ld.w       v39, [s50, #0]
    v.mov        v55, v39                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s48, x8dot_done_46
    s.movz       s49, #0
    s.add        s50, s2, s1
    s.addi       s51, s49, #0
    s.addi       s49, s50, #32
    s.addi       s50, s32, #8448
x8dot_row_47:
    s.addi       s52, s30, #-32
    v.movi       v39, #0
    s.sub        s53, s52, s51
    s.add        s52, s49, s51
    v.splat      v41, s53
    s.shli       s53, s51, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s52, v19]            // index is in elements (ISA sec 9.1)
    s.add        s52, s50, s53
    s.addi       s53, s51, #1
    s.movz       s54, #32
    v.st.b       [s52, #0], v39
    fence.acq_rel.device
    s.mov        s51, s53
    s.cmp.lt     s52, s51, s54
    br.nz        s52, x8dot_row_47
x8dot_done_46:
    v.splat      v39, s48
    v.movi       v41, #0
    mb.arm       s49, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s50, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s48
    v.movi       v41, #0
    s.movz       s48, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s51, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s51, s49            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s48, #32
    v.extract    s50, v37, #0
    s.mov        s51, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s51, s49          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s49
    mb.arm       s48, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s50, v36, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s48
    mb.wait      s48
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s50, x8dot_done_48
    s.movz       s51, #0
    s.add        s52, s2, s1
    s.addi       s53, s51, #0
    s.addi       s51, s52, #32
    s.addi       s52, s32, #8448
x8dot_row_49:
    s.addi       s54, s30, #-32
    v.movi       v39, #0
    s.sub        s55, s54, s53
    s.add        s54, s51, s53
    v.splat      v41, s55
    s.shli       s55, s53, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s54, v21]            // index is in elements (ISA sec 9.1)
    s.add        s54, s52, s55
    s.addi       s55, s53, #1
    s.movz       s56, #32
    v.st.b       [s54, #0], v39
    fence.acq_rel.device
    s.mov        s53, s55
    s.cmp.lt     s54, s53, s56
    br.nz        s54, x8dot_row_49
x8dot_done_48:
    v.splat      v39, s50
    v.movi       v41, #0
    mb.arm       s51, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s52, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s50
    v.movi       v41, #0
    s.movz       s50, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s53, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s53, s51            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s50, #32
    v.extract    s52, v37, #1
    s.mov        s53, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s53, s51          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s51
    mb.arm       s50, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s52, v36, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s50
    mb.wait      s50
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s52, x8dot_done_50
    s.movz       s53, #0
    s.add        s54, s2, s1
    s.addi       s55, s53, #0
    s.addi       s53, s54, #32
    s.addi       s54, s32, #8448
x8dot_row_51:
    s.addi       s56, s30, #-32
    v.movi       v39, #0
    s.sub        s57, s56, s55
    s.add        s56, s53, s55
    v.splat      v41, s57
    s.shli       s57, s55, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s56, v22]            // index is in elements (ISA sec 9.1)
    s.add        s56, s54, s57
    s.addi       s57, s55, #1
    s.movz       s58, #32
    v.st.b       [s56, #0], v39
    fence.acq_rel.device
    s.mov        s55, s57
    s.cmp.lt     s56, s55, s58
    br.nz        s56, x8dot_row_51
x8dot_done_50:
    v.splat      v39, s52
    v.movi       v41, #0
    mb.arm       s53, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s54, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s52
    v.movi       v41, #0
    s.movz       s52, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s55, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s55, s53            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s52, #32
    v.extract    s54, v37, #2
    s.mov        s55, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s55, s53          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s53
    mb.arm       s52, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s54, v36, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s52
    mb.wait      s52
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s54, x8dot_done_52
    s.movz       s55, #0
    s.add        s56, s2, s1
    s.addi       s57, s55, #0
    s.addi       s55, s56, #32
    s.addi       s56, s32, #8448
x8dot_row_53:
    s.addi       s58, s30, #-32
    v.movi       v39, #0
    s.sub        s59, s58, s57
    s.add        s58, s55, s57
    v.splat      v41, s59
    s.shli       s59, s57, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s58, v23]            // index is in elements (ISA sec 9.1)
    s.add        s58, s56, s59
    s.addi       s59, s57, #1
    s.movz       s60, #32
    v.st.b       [s58, #0], v39
    fence.acq_rel.device
    s.mov        s57, s59
    s.cmp.lt     s58, s57, s60
    br.nz        s58, x8dot_row_53
x8dot_done_52:
    v.splat      v39, s54
    v.movi       v41, #0
    mb.arm       s55, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s56, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s54
    v.movi       v41, #0
    s.movz       s54, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s57, s56                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s57, s55            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s54, #32
    v.extract    s56, v37, #3
    s.mov        s57, s56                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s57, s55          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s55
    mb.arm       s54, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s56, v36, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s54
    mb.wait      s54
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s56, x8dot_done_54
    s.movz       s57, #0
    s.add        s58, s2, s1
    s.addi       s59, s57, #0
    s.addi       s57, s58, #32
    s.addi       s58, s32, #8448
x8dot_row_55:
    s.addi       s60, s30, #-32
    v.movi       v39, #0
    s.sub        s31, s60, s59
    s.add        s33, s57, s59
    v.splat      v41, s31
    s.shli       s31, s59, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s33, v24]            // index is in elements (ISA sec 9.1)
    s.add        s33, s58, s31
    s.addi       s31, s59, #1
    s.movz       s34, #32
    v.st.b       [s33, #0], v39
    fence.acq_rel.device
    s.mov        s59, s31
    s.cmp.lt     s31, s59, s34
    br.nz        s31, x8dot_row_55
x8dot_done_54:
    v.splat      v39, s56
    v.movi       v41, #0
    mb.arm       s31, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s33, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s56
    v.movi       v41, #0
    s.movz       s34, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s35, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s35, s31            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s33, #32
    v.extract    s34, v37, #4
    s.mov        s35, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s35, s31          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s31
    mb.arm       s33, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s34, v36, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s33
    mb.wait      s33
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s34, x8dot_done_56
    s.movz       s35, #0
    s.add        s36, s2, s1
    s.addi       s37, s35, #0
    s.addi       s35, s36, #32
    s.addi       s36, s32, #8448
x8dot_row_57:
    s.addi       s38, s30, #-32
    v.movi       v39, #0
    s.sub        s39, s38, s37
    s.add        s38, s35, s37
    v.splat      v41, s39
    s.shli       s39, s37, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s38, v26]            // index is in elements (ISA sec 9.1)
    s.add        s38, s36, s39
    s.addi       s39, s37, #1
    s.movz       s40, #32
    v.st.b       [s38, #0], v39
    fence.acq_rel.device
    s.mov        s37, s39
    s.cmp.lt     s38, s37, s40
    br.nz        s38, x8dot_row_57
x8dot_done_56:
    v.splat      v39, s34
    v.movi       v41, #0
    mb.arm       s35, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s36, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s34
    v.movi       v41, #0
    s.movz       s34, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s37, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s37, s35            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s34, #32
    v.extract    s36, v37, #5
    s.mov        s37, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s37, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    mb.arm       s34, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s36, v36, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s34
    mb.wait      s34
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s36, x8dot_done_58
    s.movz       s37, #0
    s.add        s38, s2, s1
    s.addi       s39, s37, #0
    s.addi       s37, s38, #32
    s.addi       s38, s32, #8448
x8dot_row_59:
    s.addi       s40, s30, #-32
    v.movi       v39, #0
    s.sub        s41, s40, s39
    s.add        s40, s37, s39
    v.splat      v41, s41
    s.shli       s41, s39, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s40, v27]            // index is in elements (ISA sec 9.1)
    s.add        s40, s38, s41
    s.addi       s41, s39, #1
    s.movz       s42, #32
    v.st.b       [s40, #0], v39
    fence.acq_rel.device
    s.mov        s39, s41
    s.cmp.lt     s40, s39, s42
    br.nz        s40, x8dot_row_59
x8dot_done_58:
    v.splat      v39, s36
    v.movi       v41, #0
    mb.arm       s37, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s38, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s36
    v.movi       v41, #0
    s.movz       s36, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s39, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s39, s37            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s36, #32
    v.extract    s38, v37, #6
    s.mov        s39, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s39, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s36, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s38, v36, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s36
    mb.wait      s36
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s38, x8dot_done_60
    s.movz       s39, #0
    s.add        s40, s2, s1
    s.addi       s41, s39, #0
    s.addi       s39, s40, #32
    s.addi       s40, s32, #8448
x8dot_row_61:
    s.addi       s42, s30, #-32
    v.movi       v39, #0
    s.sub        s43, s42, s41
    s.add        s42, s39, s41
    v.splat      v41, s43
    s.shli       s43, s41, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s42, v28]            // index is in elements (ISA sec 9.1)
    s.add        s42, s40, s43
    s.addi       s43, s41, #1
    s.movz       s44, #32
    v.st.b       [s42, #0], v39
    fence.acq_rel.device
    s.mov        s41, s43
    s.cmp.lt     s42, s41, s44
    br.nz        s42, x8dot_row_61
x8dot_done_60:
    v.splat      v39, s38
    v.movi       v41, #0
    v.splat      v42, s38
    v.movi       v43, #0
    mb.arm       s38, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s39, #0
    s.movz       s40, #0
    v.cmp.ne     p1, v39, v41
    v.cmp.eq     p2, v42, v43
    s.mov        s41, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s41, s38            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s39, v13, #0
    v.splat      v39, s39
    s.movz       s39, #32
    vf.max.ieee  v41, v39, v14
    v.extract    s40, v37, #7
    s.mov        s41, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s38          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s38
    v.rcp.approx v39, v41                        // ISA 8.8: <= 2**-22 relative
    mb.arm       s39, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s40, s32, #4096
    m.mma.async.k32.e4m3 a15, v48, v56, s39
    mb.wait      s39
    v.ld.w       v42, [s40, #0]
    s.addi       s40, s32, #10240                // 512 bytes of repack scratch
    s.addi       s41, s40, #0
    vf.fms       v43, v41, v39, v18
    vf.fms       v44, v39, v43, v39
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v39
    vf.mul       v39, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v39, v41, v42
    vf.fms       v41, v43, v44, v39
    vf.neg       v42, v41                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v41, v42, v39
    vf.cvt.f32.e4m3 v39, v41
    v.lshr       v42, v41, v40
    v.and        v41, v42, v38
    v.or         v42, v39, v41                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #1
    v.splat      v39, s41
    s.addi       s41, s32, #4160
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #32
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #2
    v.splat      v39, s41
    s.addi       s41, s32, #4224
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #64
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #3
    v.splat      v39, s41
    s.addi       s41, s32, #4288
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #96
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #4
    v.splat      v39, s41
    s.addi       s41, s32, #4352
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #128
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #5
    v.splat      v39, s41
    s.addi       s41, s32, #4416
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #160
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #6
    v.splat      v39, s41
    s.addi       s41, s32, #4480
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #192
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #7
    v.splat      v39, s41
    s.addi       s41, s32, #4544
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #224
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #8
    v.splat      v39, s41
    s.addi       s41, s32, #4608
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #256
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #9
    v.splat      v39, s41
    s.addi       s41, s32, #4672
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #288
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #10
    v.splat      v39, s41
    s.addi       s41, s32, #4736
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #320
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #11
    v.splat      v39, s41
    s.addi       s41, s32, #4800
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #352
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #12
    v.splat      v39, s41
    s.addi       s41, s32, #4864
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #384
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #13
    v.splat      v39, s41
    s.addi       s41, s32, #4928
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #416
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #14
    v.splat      v39, s41
    s.addi       s41, s32, #4992
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #448
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #15
    v.splat      v39, s41
    s.addi       s41, s32, #5056
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #480
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #0
    v.splat      v39, s41
    s.addi       s41, s32, #5120
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #16
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #1
    v.splat      v39, s41
    s.addi       s41, s32, #5184
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #48
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #2
    v.splat      v39, s41
    s.addi       s41, s32, #5248
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #80
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #3
    v.splat      v39, s41
    s.addi       s41, s32, #5312
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #112
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #4
    v.splat      v39, s41
    s.addi       s41, s32, #5376
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #144
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #5
    v.splat      v39, s41
    s.addi       s41, s32, #5440
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #176
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #6
    v.splat      v39, s41
    s.addi       s41, s32, #5504
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #208
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #7
    v.splat      v39, s41
    s.addi       s41, s32, #5568
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #240
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #8
    v.splat      v39, s41
    s.addi       s41, s32, #5632
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #272
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #9
    v.splat      v39, s41
    s.addi       s41, s32, #5696
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #304
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #10
    v.splat      v39, s41
    s.addi       s41, s32, #5760
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #336
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #11
    v.splat      v39, s41
    s.addi       s41, s32, #5824
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #368
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #12
    v.splat      v39, s41
    s.addi       s41, s32, #5888
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #400
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #13
    v.splat      v39, s41
    s.addi       s41, s32, #5952
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #432
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #14
    v.splat      v39, s41
    s.addi       s41, s32, #6016
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #464
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    v.extract    s41, v13, #15
    v.splat      v39, s41
    s.addi       s41, s32, #6080
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s41, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s41, s40, #496
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s41, s40, #64
    v.ld.w       v39, [s40, #0]
    v.mov        v48, v39                        // hand off through the shared window (sec 7.3)
    v.ld.w       v39, [s41, #0]
    s.addi       s41, s40, #128
    v.mov        v49, v39                        // hand off through the shared window (sec 7.3)
    v.ld.w       v39, [s41, #0]
    s.addi       s41, s40, #192
    v.mov        v50, v39                        // hand off through the shared window (sec 7.3)
    v.ld.w       v39, [s41, #0]
    s.addi       s41, s40, #256
    v.mov        v51, v39                        // hand off through the shared window (sec 7.3)
    v.ld.w       v39, [s41, #0]
    s.addi       s41, s40, #320
    v.mov        v52, v39                        // hand off through the shared window (sec 7.3)
    v.ld.w       v39, [s41, #0]
    s.addi       s41, s40, #384
    s.addi       s42, s40, #448
    v.mov        v53, v39                        // hand off through the shared window (sec 7.3)
    v.ld.w       v39, [s41, #0]
    v.extract    s40, v36, #0
    v.mov        v54, v39                        // hand off through the shared window (sec 7.3)
    v.ld.w       v39, [s42, #0]
    v.mov        v55, v39                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s40, x8dot_done_62
    s.movz       s41, #0
    s.add        s42, s2, s1
    s.addi       s43, s41, #0
    s.addi       s41, s42, #64
    s.addi       s42, s32, #8448
x8dot_row_63:
    s.addi       s44, s30, #-64
    v.movi       v39, #0
    s.sub        s45, s44, s43
    s.add        s44, s41, s43
    v.splat      v41, s45
    s.shli       s45, s43, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s44, v19]            // index is in elements (ISA sec 9.1)
    s.add        s44, s42, s45
    s.addi       s45, s43, #1
    s.movz       s46, #32
    v.st.b       [s44, #0], v39
    fence.acq_rel.device
    s.mov        s43, s45
    s.cmp.lt     s44, s43, s46
    br.nz        s44, x8dot_row_63
x8dot_done_62:
    v.splat      v39, s40
    v.movi       v41, #0
    mb.arm       s41, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s42, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s40
    v.movi       v41, #0
    s.movz       s40, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s43, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s43, s41            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s40, #64
    v.extract    s42, v37, #0
    s.mov        s43, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s43, s41          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s41
    mb.arm       s40, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s42, v36, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s40
    mb.wait      s40
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s42, x8dot_done_64
    s.movz       s43, #0
    s.add        s44, s2, s1
    s.addi       s45, s43, #0
    s.addi       s43, s44, #64
    s.addi       s44, s32, #8448
x8dot_row_65:
    s.addi       s46, s30, #-64
    v.movi       v39, #0
    s.sub        s47, s46, s45
    s.add        s46, s43, s45
    v.splat      v41, s47
    s.shli       s47, s45, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s46, v21]            // index is in elements (ISA sec 9.1)
    s.add        s46, s44, s47
    s.addi       s47, s45, #1
    s.movz       s48, #32
    v.st.b       [s46, #0], v39
    fence.acq_rel.device
    s.mov        s45, s47
    s.cmp.lt     s46, s45, s48
    br.nz        s46, x8dot_row_65
x8dot_done_64:
    v.splat      v39, s42
    v.movi       v41, #0
    mb.arm       s43, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s44, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s42
    v.movi       v41, #0
    s.movz       s42, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s45, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s45, s43            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s42, #64
    v.extract    s44, v37, #1
    s.mov        s45, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s45, s43          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s43
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s44, v36, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s42
    mb.wait      s42
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s44, x8dot_done_66
    s.movz       s45, #0
    s.add        s46, s2, s1
    s.addi       s47, s45, #0
    s.addi       s45, s46, #64
    s.addi       s46, s32, #8448
x8dot_row_67:
    s.addi       s48, s30, #-64
    v.movi       v39, #0
    s.sub        s49, s48, s47
    s.add        s48, s45, s47
    v.splat      v41, s49
    s.shli       s49, s47, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s48, v22]            // index is in elements (ISA sec 9.1)
    s.add        s48, s46, s49
    s.addi       s49, s47, #1
    s.movz       s50, #32
    v.st.b       [s48, #0], v39
    fence.acq_rel.device
    s.mov        s47, s49
    s.cmp.lt     s48, s47, s50
    br.nz        s48, x8dot_row_67
x8dot_done_66:
    v.splat      v39, s44
    v.movi       v41, #0
    mb.arm       s45, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s46, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s44
    v.movi       v41, #0
    s.movz       s44, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s47, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s47, s45            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s44, #64
    v.extract    s46, v37, #2
    s.mov        s47, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s47, s45          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s45
    mb.arm       s44, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s46, v36, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s44
    mb.wait      s44
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s46, x8dot_done_68
    s.movz       s47, #0
    s.add        s48, s2, s1
    s.addi       s49, s47, #0
    s.addi       s47, s48, #64
    s.addi       s48, s32, #8448
x8dot_row_69:
    s.addi       s50, s30, #-64
    v.movi       v39, #0
    s.sub        s51, s50, s49
    s.add        s50, s47, s49
    v.splat      v41, s51
    s.shli       s51, s49, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s50, v23]            // index is in elements (ISA sec 9.1)
    s.add        s50, s48, s51
    s.addi       s51, s49, #1
    s.movz       s52, #32
    v.st.b       [s50, #0], v39
    fence.acq_rel.device
    s.mov        s49, s51
    s.cmp.lt     s50, s49, s52
    br.nz        s50, x8dot_row_69
x8dot_done_68:
    v.splat      v39, s46
    v.movi       v41, #0
    mb.arm       s47, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s48, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s46
    v.movi       v41, #0
    s.movz       s46, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s49, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s49, s47            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s46, #64
    v.extract    s48, v37, #3
    s.mov        s49, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s49, s47          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s47
    mb.arm       s46, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s48, v36, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s46
    mb.wait      s46
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s48, x8dot_done_70
    s.movz       s49, #0
    s.add        s50, s2, s1
    s.addi       s51, s49, #0
    s.addi       s49, s50, #64
    s.addi       s50, s32, #8448
x8dot_row_71:
    s.addi       s52, s30, #-64
    v.movi       v39, #0
    s.sub        s53, s52, s51
    s.add        s52, s49, s51
    v.splat      v41, s53
    s.shli       s53, s51, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s52, v24]            // index is in elements (ISA sec 9.1)
    s.add        s52, s50, s53
    s.addi       s53, s51, #1
    s.movz       s54, #32
    v.st.b       [s52, #0], v39
    fence.acq_rel.device
    s.mov        s51, s53
    s.cmp.lt     s52, s51, s54
    br.nz        s52, x8dot_row_71
x8dot_done_70:
    v.splat      v39, s48
    v.movi       v41, #0
    mb.arm       s49, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s50, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s48
    v.movi       v41, #0
    s.movz       s48, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s51, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s51, s49            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s48, #64
    v.extract    s50, v37, #4
    s.mov        s51, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s51, s49          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s49
    mb.arm       s48, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s50, v36, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s48
    mb.wait      s48
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s50, x8dot_done_72
    s.movz       s51, #0
    s.add        s52, s2, s1
    s.addi       s53, s51, #0
    s.addi       s51, s52, #64
    s.addi       s52, s32, #8448
x8dot_row_73:
    s.addi       s54, s30, #-64
    v.movi       v39, #0
    s.sub        s55, s54, s53
    s.add        s54, s51, s53
    v.splat      v41, s55
    s.shli       s55, s53, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s54, v26]            // index is in elements (ISA sec 9.1)
    s.add        s54, s52, s55
    s.addi       s55, s53, #1
    s.movz       s56, #32
    v.st.b       [s54, #0], v39
    fence.acq_rel.device
    s.mov        s53, s55
    s.cmp.lt     s54, s53, s56
    br.nz        s54, x8dot_row_73
x8dot_done_72:
    v.splat      v39, s50
    v.movi       v41, #0
    mb.arm       s51, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s52, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s50
    v.movi       v41, #0
    s.movz       s50, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s53, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s53, s51            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s50, #64
    v.extract    s52, v37, #5
    s.mov        s53, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s53, s51          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s51
    mb.arm       s50, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s52, v36, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s50
    mb.wait      s50
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s52, x8dot_done_74
    s.movz       s53, #0
    s.add        s54, s2, s1
    s.addi       s55, s53, #0
    s.addi       s53, s54, #64
    s.addi       s54, s32, #8448
x8dot_row_75:
    s.addi       s56, s30, #-64
    v.movi       v39, #0
    s.sub        s57, s56, s55
    s.add        s56, s53, s55
    v.splat      v41, s57
    s.shli       s57, s55, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s56, v27]            // index is in elements (ISA sec 9.1)
    s.add        s56, s54, s57
    s.addi       s57, s55, #1
    s.movz       s58, #32
    v.st.b       [s56, #0], v39
    fence.acq_rel.device
    s.mov        s55, s57
    s.cmp.lt     s56, s55, s58
    br.nz        s56, x8dot_row_75
x8dot_done_74:
    v.splat      v39, s52
    v.movi       v41, #0
    mb.arm       s53, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s54, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s52
    v.movi       v41, #0
    s.movz       s52, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s55, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s55, s53            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s52, #64
    v.extract    s54, v37, #6
    s.mov        s55, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s55, s53          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s53
    mb.arm       s52, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s54, v36, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s52
    mb.wait      s52
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s54, x8dot_done_76
    s.movz       s55, #0
    s.add        s56, s2, s1
    s.addi       s57, s55, #0
    s.addi       s55, s56, #64
    s.addi       s56, s32, #8448
x8dot_row_77:
    s.addi       s58, s30, #-64
    v.movi       v39, #0
    s.sub        s59, s58, s57
    s.add        s58, s55, s57
    v.splat      v41, s59
    s.shli       s59, s57, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s58, v28]            // index is in elements (ISA sec 9.1)
    s.add        s58, s56, s59
    s.addi       s59, s57, #1
    s.movz       s60, #32
    v.st.b       [s58, #0], v39
    fence.acq_rel.device
    s.mov        s57, s59
    s.cmp.lt     s58, s57, s60
    br.nz        s58, x8dot_row_77
x8dot_done_76:
    v.splat      v39, s54
    v.movi       v41, #0
    v.splat      v42, s54
    v.movi       v43, #0
    mb.arm       s54, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s55, #0
    s.movz       s56, #0
    v.cmp.ne     p1, v39, v41
    v.cmp.eq     p2, v42, v43
    s.mov        s57, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s57, s54            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s55, v13, #0
    v.splat      v39, s55
    s.movz       s55, #64
    vf.max.ieee  v41, v39, v14
    v.extract    s56, v37, #7
    s.mov        s57, s56                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s57, s54          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s54
    v.rcp.approx v39, v41                        // ISA 8.8: <= 2**-22 relative
    mb.arm       s55, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s56, s32, #6144
    m.mma.async.k32.e4m3 a15, v48, v56, s55
    mb.wait      s55
    v.ld.w       v42, [s56, #0]
    s.addi       s56, s32, #10752                // 512 bytes of repack scratch
    s.addi       s57, s56, #0
    vf.fms       v43, v41, v39, v18
    vf.fms       v44, v39, v43, v39
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v39
    vf.mul       v39, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v39, v41, v42
    vf.fms       v41, v43, v44, v39
    vf.neg       v42, v41                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v41, v42, v39
    vf.cvt.f32.e4m3 v39, v41
    v.lshr       v42, v41, v40
    v.and        v41, v42, v38
    v.or         v42, v39, v41                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #1
    v.splat      v39, s57
    s.addi       s57, s32, #6208
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #32
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #2
    v.splat      v39, s57
    s.addi       s57, s32, #6272
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #64
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #3
    v.splat      v39, s57
    s.addi       s57, s32, #6336
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #96
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #4
    v.splat      v39, s57
    s.addi       s57, s32, #6400
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #128
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #5
    v.splat      v39, s57
    s.addi       s57, s32, #6464
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #160
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #6
    v.splat      v39, s57
    s.addi       s57, s32, #6528
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #192
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #7
    v.splat      v39, s57
    s.addi       s57, s32, #6592
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #224
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #8
    v.splat      v39, s57
    s.addi       s57, s32, #6656
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #256
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #9
    v.splat      v39, s57
    s.addi       s57, s32, #6720
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #288
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #10
    v.splat      v39, s57
    s.addi       s57, s32, #6784
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #320
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #11
    v.splat      v39, s57
    s.addi       s57, s32, #6848
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #352
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #12
    v.splat      v39, s57
    s.addi       s57, s32, #6912
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #384
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #13
    v.splat      v39, s57
    s.addi       s57, s32, #6976
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #416
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #14
    v.splat      v39, s57
    s.addi       s57, s32, #7040
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #448
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #15
    v.splat      v39, s57
    s.addi       s57, s32, #7104
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #480
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #0
    v.splat      v39, s57
    s.addi       s57, s32, #7168
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #16
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #1
    v.splat      v39, s57
    s.addi       s57, s32, #7232
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #48
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #2
    v.splat      v39, s57
    s.addi       s57, s32, #7296
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #80
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #3
    v.splat      v39, s57
    s.addi       s57, s32, #7360
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #112
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #4
    v.splat      v39, s57
    s.addi       s57, s32, #7424
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #144
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #5
    v.splat      v39, s57
    s.addi       s57, s32, #7488
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #176
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #6
    v.splat      v39, s57
    s.addi       s57, s32, #7552
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #208
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #7
    v.splat      v39, s57
    s.addi       s57, s32, #7616
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #240
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #8
    v.splat      v39, s57
    s.addi       s57, s32, #7680
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #272
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #9
    v.splat      v39, s57
    s.addi       s57, s32, #7744
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #304
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #10
    v.splat      v39, s57
    s.addi       s57, s32, #7808
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #336
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #11
    v.splat      v39, s57
    s.addi       s57, s32, #7872
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #368
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #12
    v.splat      v39, s57
    s.addi       s57, s32, #7936
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #400
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #13
    v.splat      v39, s57
    s.addi       s57, s32, #8000
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #432
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #14
    v.splat      v39, s57
    s.addi       s57, s32, #8064
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s57, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #464
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v42
    v.extract    s57, v13, #15
    v.splat      v39, s57
    s.addi       s57, s32, #8128
    vf.max.ieee  v41, v39, v14
    v.ld.w       v14, [s57, #0]
    v.rcp.approx v39, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s57, s56, #496
    vf.fms       v42, v41, v39, v18
    vf.fms       v18, v39, v42, v39
    vf.neg       v42, v18                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v18, v42, v39
    vf.mul       v39, v14, v18                   // a/y: faithful quotient
    vf.fms       v42, v39, v41, v14
    vf.fms       v14, v42, v18, v39
    vf.neg       v18, v14                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v18, v18
    @p1 v.sel        v14, v18, v39
    vf.cvt.f32.e4m3 v18, v14
    v.lshr       v39, v14, v40
    v.and        v14, v39, v38
    v.or         v38, v18, v14                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v38
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s57, s56, #64
    v.ld.w       v14, [s56, #0]
    v.mov        v48, v14                        // hand off through the shared window (sec 7.3)
    v.ld.w       v14, [s57, #0]
    s.addi       s57, s56, #128
    v.mov        v49, v14                        // hand off through the shared window (sec 7.3)
    v.ld.w       v14, [s57, #0]
    s.addi       s57, s56, #192
    v.mov        v50, v14                        // hand off through the shared window (sec 7.3)
    v.ld.w       v14, [s57, #0]
    s.addi       s57, s56, #256
    v.mov        v51, v14                        // hand off through the shared window (sec 7.3)
    v.ld.w       v14, [s57, #0]
    s.addi       s57, s56, #320
    v.mov        v52, v14                        // hand off through the shared window (sec 7.3)
    v.ld.w       v14, [s57, #0]
    s.addi       s57, s56, #384
    s.addi       s58, s56, #448
    v.mov        v53, v14                        // hand off through the shared window (sec 7.3)
    v.ld.w       v14, [s57, #0]
    v.extract    s56, v36, #0
    v.mov        v54, v14                        // hand off through the shared window (sec 7.3)
    v.ld.w       v14, [s58, #0]
    v.mov        v55, v14                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s56, x8dot_done_78
    s.movz       s57, #0
    s.add        s58, s2, s1
    s.addi       s59, s57, #0
    s.addi       s57, s58, #96
    s.addi       s58, s32, #8448
x8dot_row_79:
    s.addi       s60, s30, #-96
    v.movi       v14, #0
    s.sub        s31, s60, s59
    s.add        s33, s57, s59
    v.splat      v18, s31
    s.shli       s31, s59, #4
    v.cmp.gt     p1, v18, v14
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v14, [s33, v19]            // index is in elements (ISA sec 9.1)
    s.add        s33, s58, s31
    s.addi       s31, s59, #1
    s.movz       s34, #32
    v.st.b       [s33, #0], v14
    fence.acq_rel.device
    s.mov        s59, s31
    s.cmp.lt     s31, s59, s34
    br.nz        s31, x8dot_row_79
x8dot_done_78:
    v.splat      v14, s56
    v.movi       v18, #0
    mb.arm       s31, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s33, #0
    v.cmp.ne     p1, v14, v18
    v.splat      v14, s56
    v.movi       v18, #0
    s.movz       s34, #0
    v.cmp.eq     p2, v14, v18
    s.mov        s35, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s35, s31            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s33, #96
    v.extract    s34, v37, #0
    s.mov        s35, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s35, s31          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s31
    mb.arm       s33, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s34, v36, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s33
    mb.wait      s33
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s34, x8dot_done_80
    s.movz       s35, #0
    s.add        s36, s2, s1
    s.addi       s37, s35, #0
    s.addi       s35, s36, #96
    s.addi       s36, s32, #8448
x8dot_row_81:
    s.addi       s38, s30, #-96
    v.movi       v14, #0
    s.sub        s39, s38, s37
    s.add        s38, s35, s37
    v.splat      v18, s39
    s.shli       s39, s37, #4
    v.cmp.gt     p1, v18, v14
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v14, [s38, v21]            // index is in elements (ISA sec 9.1)
    s.add        s38, s36, s39
    s.addi       s39, s37, #1
    s.movz       s40, #32
    v.st.b       [s38, #0], v14
    fence.acq_rel.device
    s.mov        s37, s39
    s.cmp.lt     s38, s37, s40
    br.nz        s38, x8dot_row_81
x8dot_done_80:
    v.splat      v14, s34
    v.movi       v18, #0
    mb.arm       s35, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s36, #0
    v.cmp.ne     p1, v14, v18
    v.splat      v14, s34
    v.movi       v18, #0
    s.movz       s34, #0
    v.cmp.eq     p2, v14, v18
    s.mov        s37, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s37, s35            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s34, #96
    v.extract    s36, v37, #1
    s.mov        s37, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s37, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    mb.arm       s34, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s36, v36, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s34
    mb.wait      s34
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s36, x8dot_done_82
    s.movz       s37, #0
    s.add        s38, s2, s1
    s.addi       s39, s37, #0
    s.addi       s37, s38, #96
    s.addi       s38, s32, #8448
x8dot_row_83:
    s.addi       s40, s30, #-96
    v.movi       v14, #0
    s.sub        s41, s40, s39
    s.add        s40, s37, s39
    v.splat      v18, s41
    s.shli       s41, s39, #4
    v.cmp.gt     p1, v18, v14
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v14, [s40, v22]            // index is in elements (ISA sec 9.1)
    s.add        s40, s38, s41
    s.addi       s41, s39, #1
    s.movz       s42, #32
    v.st.b       [s40, #0], v14
    fence.acq_rel.device
    s.mov        s39, s41
    s.cmp.lt     s40, s39, s42
    br.nz        s40, x8dot_row_83
x8dot_done_82:
    v.splat      v14, s36
    v.movi       v18, #0
    mb.arm       s37, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s38, #0
    v.cmp.ne     p1, v14, v18
    v.splat      v14, s36
    v.movi       v18, #0
    s.movz       s36, #0
    v.cmp.eq     p2, v14, v18
    s.mov        s39, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s39, s37            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s36, #96
    v.extract    s38, v37, #2
    s.mov        s39, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s39, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s36, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s38, v36, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s36
    mb.wait      s36
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s38, x8dot_done_84
    s.movz       s39, #0
    s.add        s40, s2, s1
    s.addi       s41, s39, #0
    s.addi       s39, s40, #96
    s.addi       s40, s32, #8448
x8dot_row_85:
    s.addi       s42, s30, #-96
    v.movi       v14, #0
    s.sub        s43, s42, s41
    s.add        s42, s39, s41
    v.splat      v18, s43
    s.shli       s43, s41, #4
    v.cmp.gt     p1, v18, v14
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v14, [s42, v23]            // index is in elements (ISA sec 9.1)
    s.add        s42, s40, s43
    s.addi       s43, s41, #1
    s.movz       s44, #32
    v.st.b       [s42, #0], v14
    fence.acq_rel.device
    s.mov        s41, s43
    s.cmp.lt     s42, s41, s44
    br.nz        s42, x8dot_row_85
x8dot_done_84:
    v.splat      v14, s38
    v.movi       v18, #0
    mb.arm       s39, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s40, #0
    v.cmp.ne     p1, v14, v18
    v.splat      v14, s38
    v.movi       v18, #0
    s.movz       s38, #0
    v.cmp.eq     p2, v14, v18
    s.mov        s41, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s41, s39            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s38, #96
    v.extract    s40, v37, #3
    s.mov        s41, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s39          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s39
    mb.arm       s38, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s40, v36, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s38
    mb.wait      s38
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s40, x8dot_done_86
    s.movz       s41, #0
    s.add        s42, s2, s1
    s.addi       s43, s41, #0
    s.addi       s41, s42, #96
    s.addi       s42, s32, #8448
x8dot_row_87:
    s.addi       s44, s30, #-96
    v.movi       v14, #0
    s.sub        s45, s44, s43
    s.add        s44, s41, s43
    v.splat      v18, s45
    s.shli       s45, s43, #4
    v.cmp.gt     p1, v18, v14
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v14, [s44, v24]            // index is in elements (ISA sec 9.1)
    s.add        s44, s42, s45
    s.addi       s45, s43, #1
    s.movz       s46, #32
    v.st.b       [s44, #0], v14
    fence.acq_rel.device
    s.mov        s43, s45
    s.cmp.lt     s44, s43, s46
    br.nz        s44, x8dot_row_87
x8dot_done_86:
    v.splat      v14, s40
    v.movi       v18, #0
    mb.arm       s41, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s42, #0
    v.cmp.ne     p1, v14, v18
    v.splat      v14, s40
    v.movi       v18, #0
    s.movz       s40, #0
    v.cmp.eq     p2, v14, v18
    s.mov        s43, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s43, s41            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s40, #96
    v.extract    s42, v37, #4
    s.mov        s43, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s43, s41          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s41
    mb.arm       s40, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s42, v36, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s40
    mb.wait      s40
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s42, x8dot_done_88
    s.movz       s43, #0
    s.add        s44, s2, s1
    s.addi       s45, s43, #0
    s.addi       s43, s44, #96
    s.addi       s44, s32, #8448
x8dot_row_89:
    s.addi       s46, s30, #-96
    v.movi       v14, #0
    s.sub        s47, s46, s45
    s.add        s46, s43, s45
    v.splat      v18, s47
    s.shli       s47, s45, #4
    v.cmp.gt     p1, v18, v14
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v14, [s46, v26]            // index is in elements (ISA sec 9.1)
    s.add        s46, s44, s47
    s.addi       s47, s45, #1
    s.movz       s48, #32
    v.st.b       [s46, #0], v14
    fence.acq_rel.device
    s.mov        s45, s47
    s.cmp.lt     s46, s45, s48
    br.nz        s46, x8dot_row_89
x8dot_done_88:
    v.splat      v14, s42
    v.movi       v18, #0
    mb.arm       s43, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s44, #0
    v.cmp.ne     p1, v14, v18
    v.splat      v14, s42
    v.movi       v18, #0
    s.movz       s42, #0
    v.cmp.eq     p2, v14, v18
    s.mov        s45, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s45, s43            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s42, #96
    v.extract    s44, v37, #5
    s.mov        s45, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s45, s43          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s43
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s44, v36, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s42
    mb.wait      s42
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s44, x8dot_done_90
    s.movz       s45, #0
    s.add        s46, s2, s1
    s.addi       s47, s45, #0
    s.addi       s45, s46, #96
    s.addi       s46, s32, #8448
x8dot_row_91:
    s.addi       s48, s30, #-96
    v.movi       v14, #0
    s.sub        s49, s48, s47
    s.add        s48, s45, s47
    v.splat      v18, s49
    s.shli       s49, s47, #4
    v.cmp.gt     p1, v18, v14
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v14, [s48, v27]            // index is in elements (ISA sec 9.1)
    s.add        s48, s46, s49
    s.addi       s49, s47, #1
    s.movz       s50, #32
    v.st.b       [s48, #0], v14
    fence.acq_rel.device
    s.mov        s47, s49
    s.cmp.lt     s48, s47, s50
    br.nz        s48, x8dot_row_91
x8dot_done_90:
    v.splat      v14, s44
    v.movi       v18, #0
    mb.arm       s45, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s46, #0
    v.cmp.ne     p1, v14, v18
    v.splat      v14, s44
    v.movi       v18, #0
    s.movz       s44, #0
    v.cmp.eq     p2, v14, v18
    s.mov        s47, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s47, s45            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s44, #96
    v.extract    s46, v37, #6
    s.mov        s47, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s47, s45          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s45
    mb.arm       s44, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s46, v36, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s44
    mb.wait      s44
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s46, x8dot_done_92
    s.movz       s47, #0
    s.add        s48, s2, s1
    s.addi       s49, s47, #0
    s.addi       s47, s48, #96
    s.addi       s48, s32, #8448
x8dot_row_93:
    s.addi       s50, s30, #-96
    v.movi       v14, #0
    s.sub        s51, s50, s49
    s.add        s50, s47, s49
    v.splat      v18, s51
    s.shli       s51, s49, #4
    v.cmp.gt     p1, v18, v14
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v14, [s50, v28]            // index is in elements (ISA sec 9.1)
    s.add        s50, s48, s51
    s.addi       s51, s49, #1
    s.movz       s52, #32
    v.st.b       [s50, #0], v14
    fence.acq_rel.device
    s.mov        s49, s51
    s.cmp.lt     s50, s49, s52
    br.nz        s50, x8dot_row_93
x8dot_done_92:
    v.splat      v14, s46
    v.movi       v18, #0
    mb.arm       s30, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s47, #0
    s.movz       s48, #0
    v.cmp.ne     p1, v14, v18
    v.splat      v14, s46
    v.movi       v18, #0
    s.movz       s46, #96
    v.cmp.eq     p2, v14, v18
    s.mov        s49, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s49, s30            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s47, v37, #7
    s.mov        s48, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s48, s30          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s30
    mb.arm       s46, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s47, #0
    m.mma.async.k32.e4m3 a15, v48, v56, s46
    mb.wait      s46
    s.addi       s48, s32, #11264
    a.vread      v14, a8, s47
    s.movz       s47, #1
    v.st.w       [s48, #0], v14
    s.addi       s49, s48, #64
    a.vread      v14, a8, s47
    s.movz       s47, #2
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #128
    a.vread      v14, a8, s47
    s.movz       s47, #3
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #192
    a.vread      v14, a8, s47
    s.movz       s47, #4
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #256
    a.vread      v14, a8, s47
    s.movz       s47, #5
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #320
    a.vread      v14, a8, s47
    s.movz       s47, #6
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #384
    a.vread      v14, a8, s47
    s.movz       s47, #7
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #448
    a.vread      v14, a8, s47
    s.movz       s47, #8
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #512
    a.vread      v14, a8, s47
    s.movz       s47, #9
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #576
    a.vread      v14, a8, s47
    s.movz       s47, #10
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #640
    a.vread      v14, a8, s47
    s.movz       s47, #11
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #704
    a.vread      v14, a8, s47
    s.movz       s47, #12
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #768
    a.vread      v14, a8, s47
    s.movz       s47, #13
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #832
    a.vread      v14, a8, s47
    s.movz       s47, #14
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #896
    a.vread      v14, a8, s47
    s.movz       s47, #15
    s.addi       s50, s48, #960
    v.st.w       [s49, #0], v14
    a.vread      v14, a8, s47
    s.movz       s47, #0
    s.addi       s48, s32, #12288
    v.st.w       [s50, #0], v14
    fence.acq_rel.device
    a.vread      v14, a9, s47
    s.movz       s47, #1
    s.addi       s49, s48, #64
    v.st.w       [s48, #0], v14
    a.vread      v14, a9, s47
    s.movz       s47, #2
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #128
    a.vread      v14, a9, s47
    s.movz       s47, #3
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #192
    a.vread      v14, a9, s47
    s.movz       s47, #4
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #256
    a.vread      v14, a9, s47
    s.movz       s47, #5
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #320
    a.vread      v14, a9, s47
    s.movz       s47, #6
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #384
    a.vread      v14, a9, s47
    s.movz       s47, #7
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #448
    a.vread      v14, a9, s47
    s.movz       s47, #8
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #512
    a.vread      v14, a9, s47
    s.movz       s47, #9
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #576
    a.vread      v14, a9, s47
    s.movz       s47, #10
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #640
    a.vread      v14, a9, s47
    s.movz       s47, #11
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #704
    a.vread      v14, a9, s47
    s.movz       s47, #12
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #768
    a.vread      v14, a9, s47
    s.movz       s47, #13
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #832
    a.vread      v14, a9, s47
    s.movz       s47, #14
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #896
    a.vread      v14, a9, s47
    s.movz       s47, #15
    s.addi       s50, s48, #960
    v.st.w       [s49, #0], v14
    a.vread      v14, a9, s47
    s.movz       s47, #0
    s.addi       s48, s32, #13312
    v.st.w       [s50, #0], v14
    fence.acq_rel.device
    a.vread      v14, a10, s47
    s.movz       s47, #1
    s.addi       s49, s48, #64
    v.st.w       [s48, #0], v14
    a.vread      v14, a10, s47
    s.movz       s47, #2
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #128
    a.vread      v14, a10, s47
    s.movz       s47, #3
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #192
    a.vread      v14, a10, s47
    s.movz       s47, #4
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #256
    a.vread      v14, a10, s47
    s.movz       s47, #5
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #320
    a.vread      v14, a10, s47
    s.movz       s47, #6
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #384
    a.vread      v14, a10, s47
    s.movz       s47, #7
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #448
    a.vread      v14, a10, s47
    s.movz       s47, #8
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #512
    a.vread      v14, a10, s47
    s.movz       s47, #9
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #576
    a.vread      v14, a10, s47
    s.movz       s47, #10
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #640
    a.vread      v14, a10, s47
    s.movz       s47, #11
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #704
    a.vread      v14, a10, s47
    s.movz       s47, #12
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #768
    a.vread      v14, a10, s47
    s.movz       s47, #13
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #832
    a.vread      v14, a10, s47
    s.movz       s47, #14
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #896
    a.vread      v14, a10, s47
    s.movz       s47, #15
    s.addi       s50, s48, #960
    v.st.w       [s49, #0], v14
    a.vread      v14, a10, s47
    s.movz       s47, #0
    s.addi       s48, s32, #14336
    v.st.w       [s50, #0], v14
    fence.acq_rel.device
    a.vread      v14, a11, s47
    s.movz       s47, #1
    s.addi       s49, s48, #64
    v.st.w       [s48, #0], v14
    a.vread      v14, a11, s47
    s.movz       s47, #2
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #128
    a.vread      v14, a11, s47
    s.movz       s47, #3
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #192
    a.vread      v14, a11, s47
    s.movz       s47, #4
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #256
    a.vread      v14, a11, s47
    s.movz       s47, #5
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #320
    a.vread      v14, a11, s47
    s.movz       s47, #6
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #384
    a.vread      v14, a11, s47
    s.movz       s47, #7
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #448
    a.vread      v14, a11, s47
    s.movz       s47, #8
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #512
    a.vread      v14, a11, s47
    s.movz       s47, #9
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #576
    a.vread      v14, a11, s47
    s.movz       s47, #10
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #640
    a.vread      v14, a11, s47
    s.movz       s47, #11
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #704
    a.vread      v14, a11, s47
    s.movz       s47, #12
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #768
    a.vread      v14, a11, s47
    s.movz       s47, #13
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #832
    a.vread      v14, a11, s47
    s.movz       s47, #14
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #896
    a.vread      v14, a11, s47
    s.movz       s47, #15
    s.addi       s50, s48, #960
    v.st.w       [s49, #0], v14
    a.vread      v14, a11, s47
    s.movz       s47, #0
    s.addi       s48, s32, #15360
    v.st.w       [s50, #0], v14
    fence.acq_rel.device
    a.vread      v14, a12, s47
    s.movz       s47, #1
    s.addi       s49, s48, #64
    v.st.w       [s48, #0], v14
    a.vread      v14, a12, s47
    s.movz       s47, #2
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #128
    a.vread      v14, a12, s47
    s.movz       s47, #3
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #192
    a.vread      v14, a12, s47
    s.movz       s47, #4
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #256
    a.vread      v14, a12, s47
    s.movz       s47, #5
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #320
    a.vread      v14, a12, s47
    s.movz       s47, #6
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #384
    a.vread      v14, a12, s47
    s.movz       s47, #7
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #448
    a.vread      v14, a12, s47
    s.movz       s47, #8
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #512
    a.vread      v14, a12, s47
    s.movz       s47, #9
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #576
    a.vread      v14, a12, s47
    s.movz       s47, #10
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #640
    a.vread      v14, a12, s47
    s.movz       s47, #11
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #704
    a.vread      v14, a12, s47
    s.movz       s47, #12
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #768
    a.vread      v14, a12, s47
    s.movz       s47, #13
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #832
    a.vread      v14, a12, s47
    s.movz       s47, #14
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #896
    a.vread      v14, a12, s47
    s.movz       s47, #15
    s.addi       s50, s48, #960
    v.st.w       [s49, #0], v14
    a.vread      v14, a12, s47
    s.movz       s47, #0
    s.addi       s48, s32, #16384
    v.st.w       [s50, #0], v14
    fence.acq_rel.device
    a.vread      v14, a13, s47
    s.movz       s47, #1
    s.addi       s49, s48, #64
    v.st.w       [s48, #0], v14
    a.vread      v14, a13, s47
    s.movz       s47, #2
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #128
    a.vread      v14, a13, s47
    s.movz       s47, #3
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #192
    a.vread      v14, a13, s47
    s.movz       s47, #4
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #256
    a.vread      v14, a13, s47
    s.movz       s47, #5
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #320
    a.vread      v14, a13, s47
    s.movz       s47, #6
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #384
    a.vread      v14, a13, s47
    s.movz       s47, #7
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #448
    a.vread      v14, a13, s47
    s.movz       s47, #8
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #512
    a.vread      v14, a13, s47
    s.movz       s47, #9
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #576
    a.vread      v14, a13, s47
    s.movz       s47, #10
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #640
    a.vread      v14, a13, s47
    s.movz       s47, #11
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #704
    a.vread      v14, a13, s47
    s.movz       s47, #12
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #768
    a.vread      v14, a13, s47
    s.movz       s47, #13
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #832
    a.vread      v14, a13, s47
    s.movz       s47, #14
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #896
    a.vread      v14, a13, s47
    s.movz       s47, #15
    s.addi       s50, s48, #960
    v.st.w       [s49, #0], v14
    a.vread      v14, a13, s47
    s.movz       s47, #0
    s.addi       s48, s32, #17408
    v.st.w       [s50, #0], v14
    fence.acq_rel.device
    a.vread      v14, a14, s47
    s.movz       s47, #1
    s.addi       s49, s48, #64
    v.st.w       [s48, #0], v14
    a.vread      v14, a14, s47
    s.movz       s47, #2
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #128
    a.vread      v14, a14, s47
    s.movz       s47, #3
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #192
    a.vread      v14, a14, s47
    s.movz       s47, #4
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #256
    a.vread      v14, a14, s47
    s.movz       s47, #5
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #320
    a.vread      v14, a14, s47
    s.movz       s47, #6
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #384
    a.vread      v14, a14, s47
    s.movz       s47, #7
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #448
    a.vread      v14, a14, s47
    s.movz       s47, #8
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #512
    a.vread      v14, a14, s47
    s.movz       s47, #9
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #576
    a.vread      v14, a14, s47
    s.movz       s47, #10
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #640
    a.vread      v14, a14, s47
    s.movz       s47, #11
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #704
    a.vread      v14, a14, s47
    s.movz       s47, #12
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #768
    a.vread      v14, a14, s47
    s.movz       s47, #13
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #832
    a.vread      v14, a14, s47
    s.movz       s47, #14
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #896
    a.vread      v14, a14, s47
    s.movz       s47, #15
    s.addi       s50, s48, #960
    v.st.w       [s49, #0], v14
    a.vread      v14, a14, s47
    s.movz       s47, #0
    s.addi       s48, s32, #18432
    v.st.w       [s50, #0], v14
    fence.acq_rel.device
    a.vread      v14, a15, s47
    s.movz       s47, #1
    s.addi       s49, s48, #64
    v.st.w       [s48, #0], v14
    a.vread      v14, a15, s47
    s.movz       s47, #2
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #128
    a.vread      v14, a15, s47
    s.movz       s47, #3
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #192
    a.vread      v14, a15, s47
    s.movz       s47, #4
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #256
    a.vread      v14, a15, s47
    s.movz       s47, #5
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #320
    a.vread      v14, a15, s47
    s.movz       s47, #6
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #384
    a.vread      v14, a15, s47
    s.movz       s47, #7
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #448
    a.vread      v14, a15, s47
    s.movz       s47, #8
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #512
    a.vread      v14, a15, s47
    s.movz       s47, #9
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #576
    a.vread      v14, a15, s47
    s.movz       s47, #10
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #640
    a.vread      v14, a15, s47
    s.movz       s47, #11
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #704
    a.vread      v14, a15, s47
    s.movz       s47, #12
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #768
    a.vread      v14, a15, s47
    s.movz       s47, #13
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #832
    a.vread      v14, a15, s47
    s.movz       s47, #14
    v.st.w       [s49, #0], v14
    s.addi       s49, s48, #896
    a.vread      v14, a15, s47
    s.movz       s47, #15
    s.addi       s50, s48, #960
    v.st.w       [s49, #0], v14
    a.vread      v14, a15, s47
    s.movz       s47, #0
    s.addi       s48, s32, #11264
    v.st.w       [s50, #0], v14
    fence.acq_rel.device
    a.vread      v14, a0, s47
    v.extract    s47, v13, #0
    v.splat      v18, s47
    s.addi       s47, s32, #19456
    s.movz       s49, #1
    v.ld.w       v19, [s48, #0]
    s.addi       s48, s32, #11328
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s47, #0], v19
    a.vread      v14, a0, s49
    v.extract    s49, v13, #1
    v.splat      v18, s49
    s.addi       s49, s47, #64
    v.ld.w       v19, [s48, #0]
    s.movz       s48, #2
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s49, #0], v19
    s.addi       s49, s32, #11392
    a.vread      v14, a0, s48
    v.extract    s48, v13, #2
    v.splat      v18, s48
    s.addi       s48, s47, #128
    v.ld.w       v19, [s49, #0]
    s.movz       s49, #3
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s48, #0], v19
    s.addi       s48, s32, #11456
    a.vread      v14, a0, s49
    v.extract    s49, v13, #3
    v.splat      v18, s49
    s.addi       s49, s47, #192
    v.ld.w       v19, [s48, #0]
    s.movz       s48, #4
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s49, #0], v19
    s.addi       s49, s32, #11520
    a.vread      v14, a0, s48
    v.extract    s48, v13, #4
    v.splat      v18, s48
    s.addi       s48, s47, #256
    v.ld.w       v19, [s49, #0]
    s.movz       s49, #5
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s48, #0], v19
    s.addi       s48, s32, #11584
    a.vread      v14, a0, s49
    v.extract    s49, v13, #5
    v.splat      v18, s49
    s.addi       s49, s47, #320
    v.ld.w       v19, [s48, #0]
    s.movz       s48, #6
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s49, #0], v19
    s.addi       s49, s32, #11648
    a.vread      v14, a0, s48
    v.extract    s48, v13, #6
    v.splat      v18, s48
    s.addi       s48, s47, #384
    v.ld.w       v19, [s49, #0]
    s.movz       s49, #7
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s48, #0], v19
    s.addi       s48, s32, #11712
    a.vread      v14, a0, s49
    v.extract    s49, v13, #7
    v.splat      v18, s49
    s.addi       s49, s47, #448
    v.ld.w       v19, [s48, #0]
    s.movz       s48, #8
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s49, #0], v19
    s.addi       s49, s32, #11776
    a.vread      v14, a0, s48
    v.extract    s48, v13, #8
    v.splat      v18, s48
    s.addi       s48, s47, #512
    v.ld.w       v19, [s49, #0]
    s.movz       s49, #9
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s48, #0], v19
    s.addi       s48, s32, #11840
    a.vread      v14, a0, s49
    v.extract    s49, v13, #9
    v.splat      v18, s49
    s.addi       s49, s47, #576
    v.ld.w       v19, [s48, #0]
    s.movz       s48, #10
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s49, #0], v19
    s.addi       s49, s32, #11904
    a.vread      v14, a0, s48
    v.extract    s48, v13, #10
    v.splat      v18, s48
    s.addi       s48, s47, #640
    v.ld.w       v19, [s49, #0]
    s.movz       s49, #11
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s48, #0], v19
    s.addi       s48, s32, #11968
    a.vread      v14, a0, s49
    v.extract    s49, v13, #11
    v.splat      v18, s49
    s.addi       s49, s47, #704
    v.ld.w       v19, [s48, #0]
    s.movz       s48, #12
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s49, #0], v19
    s.addi       s49, s32, #12032
    a.vread      v14, a0, s48
    v.extract    s48, v13, #12
    v.splat      v18, s48
    s.addi       s48, s47, #768
    v.ld.w       v19, [s49, #0]
    s.movz       s49, #13
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s48, #0], v19
    s.addi       s48, s32, #12096
    a.vread      v14, a0, s49
    v.extract    s49, v13, #13
    v.splat      v18, s49
    s.addi       s49, s47, #832
    v.ld.w       v19, [s48, #0]
    s.movz       s48, #14
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s49, #0], v19
    s.addi       s49, s32, #12160
    a.vread      v14, a0, s48
    v.extract    s48, v13, #14
    v.splat      v18, s48
    s.addi       s48, s47, #896
    s.addi       s50, s47, #960
    v.ld.w       v19, [s49, #0]
    s.movz       s47, #15
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s48, #0], v19
    s.addi       s48, s32, #12224
    a.vread      v14, a0, s47
    v.extract    s47, v13, #15
    v.splat      v18, s47
    s.movz       s47, #0
    v.ld.w       v19, [s48, #0]
    s.addi       s48, s32, #12288
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v17, v14, v18
    v.st.w       [s50, #0], v17
    fence.acq_rel.device
    a.vread      v14, a1, s47
    v.extract    s47, v13, #0
    v.splat      v17, s47
    s.addi       s47, s32, #20480
    s.movz       s49, #1
    v.ld.w       v18, [s48, #0]
    s.addi       s48, s32, #12352
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s47, #0], v18
    a.vread      v14, a1, s49
    v.extract    s49, v13, #1
    v.splat      v17, s49
    s.addi       s49, s47, #64
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #2
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #12416
    a.vread      v14, a1, s48
    v.extract    s48, v13, #2
    v.splat      v17, s48
    s.addi       s48, s47, #128
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #3
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #12480
    a.vread      v14, a1, s49
    v.extract    s49, v13, #3
    v.splat      v17, s49
    s.addi       s49, s47, #192
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #4
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #12544
    a.vread      v14, a1, s48
    v.extract    s48, v13, #4
    v.splat      v17, s48
    s.addi       s48, s47, #256
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #5
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #12608
    a.vread      v14, a1, s49
    v.extract    s49, v13, #5
    v.splat      v17, s49
    s.addi       s49, s47, #320
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #6
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #12672
    a.vread      v14, a1, s48
    v.extract    s48, v13, #6
    v.splat      v17, s48
    s.addi       s48, s47, #384
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #7
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #12736
    a.vread      v14, a1, s49
    v.extract    s49, v13, #7
    v.splat      v17, s49
    s.addi       s49, s47, #448
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #8
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #12800
    a.vread      v14, a1, s48
    v.extract    s48, v13, #8
    v.splat      v17, s48
    s.addi       s48, s47, #512
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #9
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #12864
    a.vread      v14, a1, s49
    v.extract    s49, v13, #9
    v.splat      v17, s49
    s.addi       s49, s47, #576
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #10
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #12928
    a.vread      v14, a1, s48
    v.extract    s48, v13, #10
    v.splat      v17, s48
    s.addi       s48, s47, #640
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #11
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #12992
    a.vread      v14, a1, s49
    v.extract    s49, v13, #11
    v.splat      v17, s49
    s.addi       s49, s47, #704
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #12
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #13056
    a.vread      v14, a1, s48
    v.extract    s48, v13, #12
    v.splat      v17, s48
    s.addi       s48, s47, #768
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #13
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #13120
    a.vread      v14, a1, s49
    v.extract    s49, v13, #13
    v.splat      v17, s49
    s.addi       s49, s47, #832
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #14
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #13184
    a.vread      v14, a1, s48
    v.extract    s48, v13, #14
    v.splat      v17, s48
    s.addi       s48, s47, #896
    s.addi       s50, s47, #960
    v.ld.w       v18, [s49, #0]
    s.movz       s47, #15
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #13248
    a.vread      v14, a1, s47
    v.extract    s47, v13, #15
    v.splat      v17, s47
    s.movz       s47, #0
    v.ld.w       v18, [s48, #0]
    s.addi       s48, s32, #13312
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s50, #0], v18
    fence.acq_rel.device
    a.vread      v14, a2, s47
    v.extract    s47, v13, #0
    v.splat      v17, s47
    s.addi       s47, s32, #21504
    s.movz       s49, #1
    v.ld.w       v18, [s48, #0]
    s.addi       s48, s32, #13376
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s47, #0], v18
    a.vread      v14, a2, s49
    v.extract    s49, v13, #1
    v.splat      v17, s49
    s.addi       s49, s47, #64
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #2
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #13440
    a.vread      v14, a2, s48
    v.extract    s48, v13, #2
    v.splat      v17, s48
    s.addi       s48, s47, #128
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #3
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #13504
    a.vread      v14, a2, s49
    v.extract    s49, v13, #3
    v.splat      v17, s49
    s.addi       s49, s47, #192
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #4
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #13568
    a.vread      v14, a2, s48
    v.extract    s48, v13, #4
    v.splat      v17, s48
    s.addi       s48, s47, #256
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #5
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #13632
    a.vread      v14, a2, s49
    v.extract    s49, v13, #5
    v.splat      v17, s49
    s.addi       s49, s47, #320
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #6
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #13696
    a.vread      v14, a2, s48
    v.extract    s48, v13, #6
    v.splat      v17, s48
    s.addi       s48, s47, #384
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #7
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #13760
    a.vread      v14, a2, s49
    v.extract    s49, v13, #7
    v.splat      v17, s49
    s.addi       s49, s47, #448
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #8
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #13824
    a.vread      v14, a2, s48
    v.extract    s48, v13, #8
    v.splat      v17, s48
    s.addi       s48, s47, #512
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #9
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #13888
    a.vread      v14, a2, s49
    v.extract    s49, v13, #9
    v.splat      v17, s49
    s.addi       s49, s47, #576
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #10
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #13952
    a.vread      v14, a2, s48
    v.extract    s48, v13, #10
    v.splat      v17, s48
    s.addi       s48, s47, #640
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #11
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #14016
    a.vread      v14, a2, s49
    v.extract    s49, v13, #11
    v.splat      v17, s49
    s.addi       s49, s47, #704
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #12
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #14080
    a.vread      v14, a2, s48
    v.extract    s48, v13, #12
    v.splat      v17, s48
    s.addi       s48, s47, #768
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #13
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #14144
    a.vread      v14, a2, s49
    v.extract    s49, v13, #13
    v.splat      v17, s49
    s.addi       s49, s47, #832
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #14
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #14208
    a.vread      v14, a2, s48
    v.extract    s48, v13, #14
    v.splat      v17, s48
    s.addi       s48, s47, #896
    s.addi       s50, s47, #960
    v.ld.w       v18, [s49, #0]
    s.movz       s47, #15
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #14272
    a.vread      v14, a2, s47
    v.extract    s47, v13, #15
    v.splat      v17, s47
    s.movz       s47, #0
    v.ld.w       v18, [s48, #0]
    s.addi       s48, s32, #14336
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s50, #0], v18
    fence.acq_rel.device
    a.vread      v14, a3, s47
    v.extract    s47, v13, #0
    v.splat      v17, s47
    s.addi       s47, s32, #22528
    s.movz       s49, #1
    v.ld.w       v18, [s48, #0]
    s.addi       s48, s32, #14400
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s47, #0], v18
    a.vread      v14, a3, s49
    v.extract    s49, v13, #1
    v.splat      v17, s49
    s.addi       s49, s47, #64
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #2
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #14464
    a.vread      v14, a3, s48
    v.extract    s48, v13, #2
    v.splat      v17, s48
    s.addi       s48, s47, #128
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #3
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #14528
    a.vread      v14, a3, s49
    v.extract    s49, v13, #3
    v.splat      v17, s49
    s.addi       s49, s47, #192
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #4
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #14592
    a.vread      v14, a3, s48
    v.extract    s48, v13, #4
    v.splat      v17, s48
    s.addi       s48, s47, #256
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #5
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #14656
    a.vread      v14, a3, s49
    v.extract    s49, v13, #5
    v.splat      v17, s49
    s.addi       s49, s47, #320
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #6
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #14720
    a.vread      v14, a3, s48
    v.extract    s48, v13, #6
    v.splat      v17, s48
    s.addi       s48, s47, #384
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #7
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #14784
    a.vread      v14, a3, s49
    v.extract    s49, v13, #7
    v.splat      v17, s49
    s.addi       s49, s47, #448
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #8
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #14848
    a.vread      v14, a3, s48
    v.extract    s48, v13, #8
    v.splat      v17, s48
    s.addi       s48, s47, #512
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #9
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #14912
    a.vread      v14, a3, s49
    v.extract    s49, v13, #9
    v.splat      v17, s49
    s.addi       s49, s47, #576
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #10
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #14976
    a.vread      v14, a3, s48
    v.extract    s48, v13, #10
    v.splat      v17, s48
    s.addi       s48, s47, #640
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #11
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #15040
    a.vread      v14, a3, s49
    v.extract    s49, v13, #11
    v.splat      v17, s49
    s.addi       s49, s47, #704
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #12
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #15104
    a.vread      v14, a3, s48
    v.extract    s48, v13, #12
    v.splat      v17, s48
    s.addi       s48, s47, #768
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #13
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #15168
    a.vread      v14, a3, s49
    v.extract    s49, v13, #13
    v.splat      v17, s49
    s.addi       s49, s47, #832
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #14
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #15232
    a.vread      v14, a3, s48
    v.extract    s48, v13, #14
    v.splat      v17, s48
    s.addi       s48, s47, #896
    s.addi       s50, s47, #960
    v.ld.w       v18, [s49, #0]
    s.movz       s47, #15
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #15296
    a.vread      v14, a3, s47
    v.extract    s47, v13, #15
    v.splat      v17, s47
    s.movz       s47, #0
    v.ld.w       v18, [s48, #0]
    s.addi       s48, s32, #15360
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s50, #0], v18
    fence.acq_rel.device
    a.vread      v14, a4, s47
    v.extract    s47, v13, #0
    v.splat      v17, s47
    s.addi       s47, s32, #23552
    s.movz       s49, #1
    v.ld.w       v18, [s48, #0]
    s.addi       s48, s32, #15424
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s47, #0], v18
    a.vread      v14, a4, s49
    v.extract    s49, v13, #1
    v.splat      v17, s49
    s.addi       s49, s47, #64
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #2
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #15488
    a.vread      v14, a4, s48
    v.extract    s48, v13, #2
    v.splat      v17, s48
    s.addi       s48, s47, #128
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #3
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #15552
    a.vread      v14, a4, s49
    v.extract    s49, v13, #3
    v.splat      v17, s49
    s.addi       s49, s47, #192
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #4
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #15616
    a.vread      v14, a4, s48
    v.extract    s48, v13, #4
    v.splat      v17, s48
    s.addi       s48, s47, #256
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #5
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #15680
    a.vread      v14, a4, s49
    v.extract    s49, v13, #5
    v.splat      v17, s49
    s.addi       s49, s47, #320
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #6
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #15744
    a.vread      v14, a4, s48
    v.extract    s48, v13, #6
    v.splat      v17, s48
    s.addi       s48, s47, #384
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #7
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #15808
    a.vread      v14, a4, s49
    v.extract    s49, v13, #7
    v.splat      v17, s49
    s.addi       s49, s47, #448
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #8
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #15872
    a.vread      v14, a4, s48
    v.extract    s48, v13, #8
    v.splat      v17, s48
    s.addi       s48, s47, #512
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #9
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #15936
    a.vread      v14, a4, s49
    v.extract    s49, v13, #9
    v.splat      v17, s49
    s.addi       s49, s47, #576
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #10
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #16000
    a.vread      v14, a4, s48
    v.extract    s48, v13, #10
    v.splat      v17, s48
    s.addi       s48, s47, #640
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #11
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #16064
    a.vread      v14, a4, s49
    v.extract    s49, v13, #11
    v.splat      v17, s49
    s.addi       s49, s47, #704
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #12
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #16128
    a.vread      v14, a4, s48
    v.extract    s48, v13, #12
    v.splat      v17, s48
    s.addi       s48, s47, #768
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #13
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #16192
    a.vread      v14, a4, s49
    v.extract    s49, v13, #13
    v.splat      v17, s49
    s.addi       s49, s47, #832
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #14
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #16256
    a.vread      v14, a4, s48
    v.extract    s48, v13, #14
    v.splat      v17, s48
    s.addi       s48, s47, #896
    s.addi       s50, s47, #960
    v.ld.w       v18, [s49, #0]
    s.movz       s47, #15
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #16320
    a.vread      v14, a4, s47
    v.extract    s47, v13, #15
    v.splat      v17, s47
    s.movz       s47, #0
    v.ld.w       v18, [s48, #0]
    s.addi       s48, s32, #16384
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s50, #0], v18
    fence.acq_rel.device
    a.vread      v14, a5, s47
    v.extract    s47, v13, #0
    v.splat      v17, s47
    s.addi       s47, s32, #24576
    s.movz       s49, #1
    v.ld.w       v18, [s48, #0]
    s.addi       s48, s32, #16448
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s47, #0], v18
    a.vread      v14, a5, s49
    v.extract    s49, v13, #1
    v.splat      v17, s49
    s.addi       s49, s47, #64
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #2
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #16512
    a.vread      v14, a5, s48
    v.extract    s48, v13, #2
    v.splat      v17, s48
    s.addi       s48, s47, #128
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #3
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #16576
    a.vread      v14, a5, s49
    v.extract    s49, v13, #3
    v.splat      v17, s49
    s.addi       s49, s47, #192
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #4
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #16640
    a.vread      v14, a5, s48
    v.extract    s48, v13, #4
    v.splat      v17, s48
    s.addi       s48, s47, #256
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #5
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #16704
    a.vread      v14, a5, s49
    v.extract    s49, v13, #5
    v.splat      v17, s49
    s.addi       s49, s47, #320
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #6
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #16768
    a.vread      v14, a5, s48
    v.extract    s48, v13, #6
    v.splat      v17, s48
    s.addi       s48, s47, #384
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #7
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #16832
    a.vread      v14, a5, s49
    v.extract    s49, v13, #7
    v.splat      v17, s49
    s.addi       s49, s47, #448
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #8
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #16896
    a.vread      v14, a5, s48
    v.extract    s48, v13, #8
    v.splat      v17, s48
    s.addi       s48, s47, #512
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #9
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #16960
    a.vread      v14, a5, s49
    v.extract    s49, v13, #9
    v.splat      v17, s49
    s.addi       s49, s47, #576
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #10
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #17024
    a.vread      v14, a5, s48
    v.extract    s48, v13, #10
    v.splat      v17, s48
    s.addi       s48, s47, #640
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #11
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #17088
    a.vread      v14, a5, s49
    v.extract    s49, v13, #11
    v.splat      v17, s49
    s.addi       s49, s47, #704
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #12
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #17152
    a.vread      v14, a5, s48
    v.extract    s48, v13, #12
    v.splat      v17, s48
    s.addi       s48, s47, #768
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #13
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #17216
    a.vread      v14, a5, s49
    v.extract    s49, v13, #13
    v.splat      v17, s49
    s.addi       s49, s47, #832
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #14
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #17280
    a.vread      v14, a5, s48
    v.extract    s48, v13, #14
    v.splat      v17, s48
    s.addi       s48, s47, #896
    s.addi       s50, s47, #960
    v.ld.w       v18, [s49, #0]
    s.movz       s47, #15
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #17344
    a.vread      v14, a5, s47
    v.extract    s47, v13, #15
    v.splat      v17, s47
    s.movz       s47, #0
    v.ld.w       v18, [s48, #0]
    s.addi       s48, s32, #17408
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s50, #0], v18
    fence.acq_rel.device
    a.vread      v14, a6, s47
    v.extract    s47, v13, #0
    v.splat      v17, s47
    s.addi       s47, s32, #25600
    s.movz       s49, #1
    v.ld.w       v18, [s48, #0]
    s.addi       s48, s32, #17472
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s47, #0], v18
    a.vread      v14, a6, s49
    v.extract    s49, v13, #1
    v.splat      v17, s49
    s.addi       s49, s47, #64
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #2
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #17536
    a.vread      v14, a6, s48
    v.extract    s48, v13, #2
    v.splat      v17, s48
    s.addi       s48, s47, #128
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #3
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #17600
    a.vread      v14, a6, s49
    v.extract    s49, v13, #3
    v.splat      v17, s49
    s.addi       s49, s47, #192
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #4
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #17664
    a.vread      v14, a6, s48
    v.extract    s48, v13, #4
    v.splat      v17, s48
    s.addi       s48, s47, #256
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #5
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #17728
    a.vread      v14, a6, s49
    v.extract    s49, v13, #5
    v.splat      v17, s49
    s.addi       s49, s47, #320
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #6
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #17792
    a.vread      v14, a6, s48
    v.extract    s48, v13, #6
    v.splat      v17, s48
    s.addi       s48, s47, #384
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #7
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #17856
    a.vread      v14, a6, s49
    v.extract    s49, v13, #7
    v.splat      v17, s49
    s.addi       s49, s47, #448
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #8
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #17920
    a.vread      v14, a6, s48
    v.extract    s48, v13, #8
    v.splat      v17, s48
    s.addi       s48, s47, #512
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #9
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #17984
    a.vread      v14, a6, s49
    v.extract    s49, v13, #9
    v.splat      v17, s49
    s.addi       s49, s47, #576
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #10
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #18048
    a.vread      v14, a6, s48
    v.extract    s48, v13, #10
    v.splat      v17, s48
    s.addi       s48, s47, #640
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #11
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #18112
    a.vread      v14, a6, s49
    v.extract    s49, v13, #11
    v.splat      v17, s49
    s.addi       s49, s47, #704
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #12
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #18176
    a.vread      v14, a6, s48
    v.extract    s48, v13, #12
    v.splat      v17, s48
    s.addi       s48, s47, #768
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #13
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #18240
    a.vread      v14, a6, s49
    v.extract    s49, v13, #13
    v.splat      v17, s49
    s.addi       s49, s47, #832
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #14
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #18304
    a.vread      v14, a6, s48
    v.extract    s48, v13, #14
    v.splat      v17, s48
    s.addi       s48, s47, #896
    s.addi       s50, s47, #960
    v.ld.w       v18, [s49, #0]
    s.movz       s47, #15
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #18368
    a.vread      v14, a6, s47
    v.extract    s47, v13, #15
    v.splat      v17, s47
    s.movz       s47, #0
    v.ld.w       v18, [s48, #0]
    s.addi       s48, s32, #18432
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s50, #0], v18
    fence.acq_rel.device
    a.vread      v14, a7, s47
    v.extract    s47, v13, #0
    v.splat      v17, s47
    s.addi       s47, s32, #26624
    s.movz       s49, #1
    v.ld.w       v18, [s48, #0]
    s.addi       s48, s32, #18496
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s47, #0], v18
    a.vread      v14, a7, s49
    v.extract    s49, v13, #1
    v.splat      v17, s49
    s.addi       s49, s47, #64
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #2
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #18560
    a.vread      v14, a7, s48
    v.extract    s48, v13, #2
    v.splat      v17, s48
    s.addi       s48, s47, #128
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #3
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #18624
    a.vread      v14, a7, s49
    v.extract    s49, v13, #3
    v.splat      v17, s49
    s.addi       s49, s47, #192
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #4
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #18688
    a.vread      v14, a7, s48
    v.extract    s48, v13, #4
    v.splat      v17, s48
    s.addi       s48, s47, #256
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #5
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #18752
    a.vread      v14, a7, s49
    v.extract    s49, v13, #5
    v.splat      v17, s49
    s.addi       s49, s47, #320
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #6
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #18816
    a.vread      v14, a7, s48
    v.extract    s48, v13, #6
    v.splat      v17, s48
    s.addi       s48, s47, #384
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #7
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #18880
    a.vread      v14, a7, s49
    v.extract    s49, v13, #7
    v.splat      v17, s49
    s.addi       s49, s47, #448
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #8
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #18944
    a.vread      v14, a7, s48
    v.extract    s48, v13, #8
    v.splat      v17, s48
    s.addi       s48, s47, #512
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #9
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #19008
    a.vread      v14, a7, s49
    v.extract    s49, v13, #9
    v.splat      v17, s49
    s.addi       s49, s47, #576
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #10
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #19072
    a.vread      v14, a7, s48
    v.extract    s48, v13, #10
    v.splat      v17, s48
    s.addi       s48, s47, #640
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #11
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #19136
    a.vread      v14, a7, s49
    v.extract    s49, v13, #11
    v.splat      v17, s49
    s.addi       s49, s47, #704
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #12
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #19200
    a.vread      v14, a7, s48
    v.extract    s48, v13, #12
    v.splat      v17, s48
    s.addi       s48, s47, #768
    v.ld.w       v18, [s49, #0]
    s.movz       s49, #13
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #19264
    a.vread      v14, a7, s49
    v.extract    s49, v13, #13
    v.splat      v17, s49
    s.addi       s49, s47, #832
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #14
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s49, #0], v18
    s.addi       s49, s32, #19328
    a.vread      v14, a7, s48
    v.extract    s48, v13, #14
    v.splat      v17, s48
    s.addi       s48, s47, #896
    s.addi       s50, s47, #960
    v.ld.w       v18, [s49, #0]
    s.movz       s47, #15
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s48, #0], v18
    s.addi       s48, s32, #19392
    a.vread      v14, a7, s47
    v.extract    s47, v13, #15
    v.splat      v13, s47
    s.addi       s47, s29, #128
    s.addi       s49, s25, #4                    // &ptr_carry_21[1] (a constant offset, x4)
    s.addi       s49, s47, #0
    s.addi       s47, s25, #4                    // &ptr_carry_22[1] (a constant offset, x4)
    v.ld.w       v17, [s48, #0]
    s.addi       s47, s1, #128
    s.addi       s48, s25, #4                    // &ptr_carry_23[1] (a constant offset, x4)
    s.addi       s48, s47, #0
    s.addi       s47, s25, #4                    // &ptr_carry_24[1] (a constant offset, x4)
    s.addi       s47, s25, #4                    // &ptr_carry_25[1] (a constant offset, x4)
    vf.mul       v18, v17, v13
    s.addi       s47, s25, #4                    // &ptr_carry_26[1] (a constant offset, x4)
    vf.mul       v13, v18, v35
    s.addi       s47, s25, #4                    // &ptr_carry_27[1] (a constant offset, x4)
    vf.add       v17, v14, v13
    v.st.w       [s50, #0], v17
    s.addi       s47, s25, #4                    // &ptr_carry_20[1] (a constant offset, x4)
    fence.acq_rel.device
    s.addi       s50, s47, #0
    s.mov        s29, s49
    s.addi       s47, s32, #19456
    s.mov        s1, s48
    s.mov        s25, s50
    s.movz       s48, #0
    s.addi       s49, s32, #19520
    v.ld.w       v13, [s47, #0]
    s.movz       s47, #1
    s.addi       s50, s32, #19584
    s.movz       s51, #2
    s.addi       s52, s32, #19648
    a.vwrite     a0, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #3
    s.addi       s49, s32, #19712
    a.vwrite     a0, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #4
    s.addi       s50, s32, #19776
    a.vwrite     a0, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #5
    s.addi       s52, s32, #19840
    a.vwrite     a0, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #6
    s.addi       s49, s32, #19904
    a.vwrite     a0, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #7
    s.addi       s50, s32, #19968
    a.vwrite     a0, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #8
    s.addi       s52, s32, #20032
    a.vwrite     a0, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #9
    s.addi       s49, s32, #20096
    a.vwrite     a0, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #10
    s.addi       s50, s32, #20160
    a.vwrite     a0, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #11
    s.addi       s52, s32, #20224
    a.vwrite     a0, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #12
    s.addi       s49, s32, #20288
    a.vwrite     a0, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #13
    s.addi       s50, s32, #20352
    a.vwrite     a0, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #14
    s.addi       s52, s32, #20416
    a.vwrite     a0, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #15
    s.addi       s49, s32, #20480
    a.vwrite     a0, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #0
    s.addi       s50, s32, #20544
    a.vwrite     a0, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #1
    s.addi       s52, s32, #20608
    a.vwrite     a0, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #2
    s.addi       s49, s32, #20672
    a.vwrite     a1, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #3
    s.addi       s50, s32, #20736
    a.vwrite     a1, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #4
    s.addi       s52, s32, #20800
    a.vwrite     a1, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #5
    s.addi       s49, s32, #20864
    a.vwrite     a1, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #6
    s.addi       s50, s32, #20928
    a.vwrite     a1, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #7
    s.addi       s52, s32, #20992
    a.vwrite     a1, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #8
    s.addi       s49, s32, #21056
    a.vwrite     a1, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #9
    s.addi       s50, s32, #21120
    a.vwrite     a1, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #10
    s.addi       s52, s32, #21184
    a.vwrite     a1, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #11
    s.addi       s49, s32, #21248
    a.vwrite     a1, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #12
    s.addi       s50, s32, #21312
    a.vwrite     a1, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #13
    s.addi       s52, s32, #21376
    a.vwrite     a1, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #14
    s.addi       s49, s32, #21440
    a.vwrite     a1, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #15
    s.addi       s50, s32, #21504
    a.vwrite     a1, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #0
    s.addi       s52, s32, #21568
    a.vwrite     a1, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #1
    s.addi       s49, s32, #21632
    a.vwrite     a1, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #2
    s.addi       s50, s32, #21696
    a.vwrite     a2, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #3
    s.addi       s52, s32, #21760
    a.vwrite     a2, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #4
    s.addi       s49, s32, #21824
    a.vwrite     a2, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #5
    s.addi       s50, s32, #21888
    a.vwrite     a2, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #6
    s.addi       s52, s32, #21952
    a.vwrite     a2, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #7
    s.addi       s49, s32, #22016
    a.vwrite     a2, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #8
    s.addi       s50, s32, #22080
    a.vwrite     a2, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #9
    s.addi       s52, s32, #22144
    a.vwrite     a2, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #10
    s.addi       s49, s32, #22208
    a.vwrite     a2, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #11
    s.addi       s50, s32, #22272
    a.vwrite     a2, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #12
    s.addi       s52, s32, #22336
    a.vwrite     a2, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #13
    s.addi       s49, s32, #22400
    a.vwrite     a2, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #14
    s.addi       s50, s32, #22464
    a.vwrite     a2, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #15
    s.addi       s52, s32, #22528
    a.vwrite     a2, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #0
    s.addi       s49, s32, #22592
    a.vwrite     a2, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #1
    s.addi       s50, s32, #22656
    a.vwrite     a2, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #2
    s.addi       s52, s32, #22720
    a.vwrite     a3, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #3
    s.addi       s49, s32, #22784
    a.vwrite     a3, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #4
    s.addi       s50, s32, #22848
    a.vwrite     a3, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #5
    s.addi       s52, s32, #22912
    a.vwrite     a3, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #6
    s.addi       s49, s32, #22976
    a.vwrite     a3, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #7
    s.addi       s50, s32, #23040
    a.vwrite     a3, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #8
    s.addi       s52, s32, #23104
    a.vwrite     a3, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #9
    s.addi       s49, s32, #23168
    a.vwrite     a3, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #10
    s.addi       s50, s32, #23232
    a.vwrite     a3, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #11
    s.addi       s52, s32, #23296
    a.vwrite     a3, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #12
    s.addi       s49, s32, #23360
    a.vwrite     a3, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #13
    s.addi       s50, s32, #23424
    a.vwrite     a3, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #14
    s.addi       s52, s32, #23488
    a.vwrite     a3, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #15
    s.addi       s49, s32, #23552
    a.vwrite     a3, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #0
    s.addi       s50, s32, #23616
    a.vwrite     a3, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #1
    s.addi       s52, s32, #23680
    a.vwrite     a3, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #2
    s.addi       s49, s32, #23744
    a.vwrite     a4, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #3
    s.addi       s50, s32, #23808
    a.vwrite     a4, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #4
    s.addi       s52, s32, #23872
    a.vwrite     a4, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #5
    s.addi       s49, s32, #23936
    a.vwrite     a4, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #6
    s.addi       s50, s32, #24000
    a.vwrite     a4, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #7
    s.addi       s52, s32, #24064
    a.vwrite     a4, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #8
    s.addi       s49, s32, #24128
    a.vwrite     a4, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #9
    s.addi       s50, s32, #24192
    a.vwrite     a4, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #10
    s.addi       s52, s32, #24256
    a.vwrite     a4, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #11
    s.addi       s49, s32, #24320
    a.vwrite     a4, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #12
    s.addi       s50, s32, #24384
    a.vwrite     a4, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #13
    s.addi       s52, s32, #24448
    a.vwrite     a4, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #14
    s.addi       s49, s32, #24512
    a.vwrite     a4, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #15
    s.addi       s50, s32, #24576
    a.vwrite     a4, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #0
    s.addi       s52, s32, #24640
    a.vwrite     a4, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #1
    s.addi       s49, s32, #24704
    a.vwrite     a4, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #2
    s.addi       s50, s32, #24768
    a.vwrite     a5, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #3
    s.addi       s52, s32, #24832
    a.vwrite     a5, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #4
    s.addi       s49, s32, #24896
    a.vwrite     a5, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #5
    s.addi       s50, s32, #24960
    a.vwrite     a5, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #6
    s.addi       s52, s32, #25024
    a.vwrite     a5, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #7
    s.addi       s49, s32, #25088
    a.vwrite     a5, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #8
    s.addi       s50, s32, #25152
    a.vwrite     a5, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #9
    s.addi       s52, s32, #25216
    a.vwrite     a5, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #10
    s.addi       s49, s32, #25280
    a.vwrite     a5, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #11
    s.addi       s50, s32, #25344
    a.vwrite     a5, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #12
    s.addi       s52, s32, #25408
    a.vwrite     a5, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #13
    s.addi       s49, s32, #25472
    a.vwrite     a5, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #14
    s.addi       s50, s32, #25536
    a.vwrite     a5, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #15
    s.addi       s52, s32, #25600
    a.vwrite     a5, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #0
    s.addi       s49, s32, #25664
    a.vwrite     a5, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #1
    s.addi       s50, s32, #25728
    a.vwrite     a5, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #2
    s.addi       s52, s32, #25792
    a.vwrite     a6, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #3
    s.addi       s49, s32, #25856
    a.vwrite     a6, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #4
    s.addi       s50, s32, #25920
    a.vwrite     a6, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #5
    s.addi       s52, s32, #25984
    a.vwrite     a6, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #6
    s.addi       s49, s32, #26048
    a.vwrite     a6, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #7
    s.addi       s50, s32, #26112
    a.vwrite     a6, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #8
    s.addi       s52, s32, #26176
    a.vwrite     a6, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #9
    s.addi       s49, s32, #26240
    a.vwrite     a6, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #10
    s.addi       s50, s32, #26304
    a.vwrite     a6, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #11
    s.addi       s52, s32, #26368
    a.vwrite     a6, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #12
    s.addi       s49, s32, #26432
    a.vwrite     a6, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #13
    s.addi       s50, s32, #26496
    a.vwrite     a6, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #14
    s.addi       s52, s32, #26560
    a.vwrite     a6, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #15
    s.addi       s49, s32, #26624
    a.vwrite     a6, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #0
    s.addi       s50, s32, #26688
    a.vwrite     a6, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #1
    s.addi       s52, s32, #26752
    a.vwrite     a6, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #2
    s.addi       s49, s32, #26816
    a.vwrite     a7, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #3
    s.addi       s50, s32, #26880
    a.vwrite     a7, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #4
    s.addi       s52, s32, #26944
    a.vwrite     a7, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #5
    s.addi       s49, s32, #27008
    a.vwrite     a7, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #6
    s.addi       s50, s32, #27072
    a.vwrite     a7, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #7
    s.addi       s52, s32, #27136
    a.vwrite     a7, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #8
    s.addi       s49, s32, #27200
    a.vwrite     a7, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #9
    s.addi       s50, s32, #27264
    a.vwrite     a7, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #10
    s.addi       s52, s32, #27328
    a.vwrite     a7, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #11
    s.addi       s49, s32, #27392
    a.vwrite     a7, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #12
    s.addi       s50, s32, #27456
    a.vwrite     a7, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #13
    s.addi       s52, s32, #27520
    s.addi       s53, s32, #27584
    a.vwrite     a7, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s32, #14
    s.movz       s48, #15
    s.add        s49, s28, s26
    a.vwrite     a7, s47, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s47, #1
    a.vwrite     a7, s51, v13
    v.ld.w       v13, [s52, #0]
    a.vwrite     a7, s32, v13
    v.ld.w       v13, [s53, #0]
    a.vwrite     a7, s48, v13
    s.mov        s28, s49
    br.nz        s47, for_28
endfor_29:
    s.mul        s1, s16, s12
    s.muli       s14, s12, #2
    s.muli       s17, s15, #2
    s.movz       s18, #0
    s.addi       s19, s15, #16
    s.muli       s20, s1, #2
    s.movz       s1, #0
    a.vread      v0, a0, s18
    s.addi       s18, s15, #32
    s.add        s21, s1, s16                    // the tile origin
    vf.cvt.f32.bf16 v1, v0
    s.add        s1, s20, s17
    s.addi       s16, s15, #48
    v.splat      v0, s21
    s.add        s22, s5, s1
    s.addi       s1, s15, #64
    s.movz       s23, #0
    s.addi       s24, s15, #80
    s.add        s25, s23, s7                    // the tile origin
    s.addi       s23, s15, #96
    v.splat      v2, s25
    s.addi       s25, s15, #112
    s.movz       s26, #0
    s.movz       s27, #0
    s.add        s28, s26, s15                   // the tile origin
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v4, s28
    s.add        s15, s27, s8                    // the tile origin
    v.add        v5, v3, v4
    s.muli       s26, s14, #1
    v.cmp.lt     p1, v0, v2
    v.splat      v0, s15
    s.movz       s15, #1
    v.cmp.lt     p2, v5, v0
    p.and        p3, p1, p2
    s.addi       s27, s21, #1
    @p3 v.st.h       [s22, #0], v1
    a.vread      v0, a0, s15
    s.add        s15, s26, s20
    v.splat      v1, s27
    s.muli       s22, s14, #2
    vf.cvt.f32.bf16 v4, v0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.add        s15, s5, s26
    p.and        p3, p1, p2
    s.movz       s26, #2
    s.addi       s27, s21, #2
    @p3 v.st.h       [s15, #0], v4
    a.vread      v0, a0, s26
    s.add        s15, s22, s20
    v.splat      v1, s27
    s.muli       s22, s14, #3
    vf.cvt.f32.bf16 v4, v0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.add        s15, s5, s26
    p.and        p3, p1, p2
    s.movz       s26, #3
    s.addi       s27, s21, #3
    @p3 v.st.h       [s15, #0], v4
    a.vread      v0, a0, s26
    s.add        s15, s22, s20
    v.splat      v1, s27
    s.muli       s22, s14, #4
    vf.cvt.f32.bf16 v4, v0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.add        s15, s5, s26
    p.and        p3, p1, p2
    s.movz       s26, #4
    s.addi       s27, s21, #4
    @p3 v.st.h       [s15, #0], v4
    a.vread      v0, a0, s26
    s.add        s15, s22, s20
    v.splat      v1, s27
    s.muli       s22, s14, #5
    vf.cvt.f32.bf16 v4, v0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.add        s15, s5, s26
    p.and        p3, p1, p2
    s.movz       s26, #5
    s.addi       s27, s21, #5
    @p3 v.st.h       [s15, #0], v4
    a.vread      v0, a0, s26
    s.add        s15, s22, s20
    v.splat      v1, s27
    s.muli       s22, s14, #6
    vf.cvt.f32.bf16 v4, v0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.add        s15, s5, s26
    p.and        p3, p1, p2
    s.movz       s26, #6
    s.addi       s27, s21, #6
    @p3 v.st.h       [s15, #0], v4
    a.vread      v0, a0, s26
    s.add        s15, s22, s20
    v.splat      v1, s27
    s.muli       s22, s14, #7
    vf.cvt.f32.bf16 v4, v0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.add        s15, s5, s26
    p.and        p3, p1, p2
    s.movz       s26, #7
    s.addi       s27, s21, #7
    @p3 v.st.h       [s15, #0], v4
    a.vread      v0, a0, s26
    s.add        s15, s22, s20
    v.splat      v1, s27
    s.muli       s22, s14, #8
    vf.cvt.f32.bf16 v4, v0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.add        s15, s5, s26
    p.and        p3, p1, p2
    s.movz       s26, #8
    s.addi       s27, s21, #8
    @p3 v.st.h       [s15, #0], v4
    a.vread      v0, a0, s26
    s.add        s15, s22, s20
    v.splat      v1, s27
    s.muli       s22, s14, #9
    vf.cvt.f32.bf16 v4, v0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.add        s15, s5, s26
    p.and        p3, p1, p2
    s.movz       s26, #9
    s.addi       s27, s21, #9
    @p3 v.st.h       [s15, #0], v4
    a.vread      v0, a0, s26
    s.add        s15, s22, s20
    v.splat      v1, s27
    s.muli       s22, s14, #10
    vf.cvt.f32.bf16 v4, v0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.add        s15, s5, s26
    p.and        p3, p1, p2
    s.movz       s26, #10
    s.addi       s27, s21, #10
    @p3 v.st.h       [s15, #0], v4
    a.vread      v0, a0, s26
    s.add        s15, s22, s20
    v.splat      v1, s27
    s.muli       s22, s14, #11
    vf.cvt.f32.bf16 v4, v0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.add        s15, s5, s26
    p.and        p3, p1, p2
    s.movz       s26, #11
    s.addi       s27, s21, #11
    @p3 v.st.h       [s15, #0], v4
    a.vread      v0, a0, s26
    s.add        s15, s22, s20
    v.splat      v1, s27
    s.muli       s22, s14, #12
    vf.cvt.f32.bf16 v4, v0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.add        s15, s5, s26
    p.and        p3, p1, p2
    s.movz       s26, #12
    s.addi       s27, s21, #12
    @p3 v.st.h       [s15, #0], v4
    a.vread      v0, a0, s26
    s.add        s15, s22, s20
    v.splat      v1, s27
    s.muli       s22, s14, #13
    vf.cvt.f32.bf16 v4, v0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.add        s15, s5, s26
    p.and        p3, p1, p2
    s.movz       s26, #13
    s.addi       s27, s21, #13
    @p3 v.st.h       [s15, #0], v4
    a.vread      v0, a0, s26
    s.add        s15, s22, s20
    v.splat      v1, s27
    s.muli       s22, s14, #14
    vf.cvt.f32.bf16 v4, v0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.add        s15, s5, s26
    p.and        p3, p1, p2
    s.movz       s26, #14
    s.addi       s27, s21, #14
    @p3 v.st.h       [s15, #0], v4
    a.vread      v0, a0, s26
    s.add        s15, s22, s20
    v.splat      v1, s27
    s.muli       s22, s14, #15
    vf.cvt.f32.bf16 v4, v0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.add        s15, s5, s26
    p.and        p3, p1, p2
    s.movz       s26, #15
    s.addi       s27, s21, #15
    @p3 v.st.h       [s15, #0], v4
    a.vread      v0, a0, s26
    s.add        s15, s22, s20
    v.splat      v1, s27
    vf.cvt.f32.bf16 v4, v0
    s.movz       s22, #0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.muli       s15, s19, #2
    s.add        s17, s22, s19                   // the tile origin
    s.add        s19, s5, s26
    s.movz       s22, #0
    p.and        p3, p1, p2
    s.movz       s26, #0
    v.splat      v0, s17
    s.add        s17, s22, s8                    // the tile origin
    @p3 v.st.h       [s19, #0], v4
    a.vread      v1, a1, s26
    v.splat      v4, s21
    v.add        v5, v3, v0
    vf.cvt.f32.bf16 v0, v1
    s.add        s19, s20, s15
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s17
    s.add        s17, s5, s19
    s.muli       s19, s14, #1
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    s.movz       s22, #1
    s.addi       s26, s21, #1
    @p3 v.st.h       [s17, #0], v0
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    s.muli       s19, s14, #2
    vf.cvt.f32.bf16 v4, v0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s22
    p.and        p3, p1, p2
    s.movz       s22, #2
    s.addi       s26, s21, #2
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    s.muli       s19, s14, #3
    vf.cvt.f32.bf16 v4, v0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s22
    p.and        p3, p1, p2
    s.movz       s22, #3
    s.addi       s26, s21, #3
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    s.muli       s19, s14, #4
    vf.cvt.f32.bf16 v4, v0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s22
    p.and        p3, p1, p2
    s.movz       s22, #4
    s.addi       s26, s21, #4
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    s.muli       s19, s14, #5
    vf.cvt.f32.bf16 v4, v0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s22
    p.and        p3, p1, p2
    s.movz       s22, #5
    s.addi       s26, s21, #5
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    s.muli       s19, s14, #6
    vf.cvt.f32.bf16 v4, v0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s22
    p.and        p3, p1, p2
    s.movz       s22, #6
    s.addi       s26, s21, #6
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    s.muli       s19, s14, #7
    vf.cvt.f32.bf16 v4, v0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s22
    p.and        p3, p1, p2
    s.movz       s22, #7
    s.addi       s26, s21, #7
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    s.muli       s19, s14, #8
    vf.cvt.f32.bf16 v4, v0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s22
    p.and        p3, p1, p2
    s.movz       s22, #8
    s.addi       s26, s21, #8
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    s.muli       s19, s14, #9
    vf.cvt.f32.bf16 v4, v0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s22
    p.and        p3, p1, p2
    s.movz       s22, #9
    s.addi       s26, s21, #9
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    s.muli       s19, s14, #10
    vf.cvt.f32.bf16 v4, v0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s22
    p.and        p3, p1, p2
    s.movz       s22, #10
    s.addi       s26, s21, #10
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    s.muli       s19, s14, #11
    vf.cvt.f32.bf16 v4, v0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s22
    p.and        p3, p1, p2
    s.movz       s22, #11
    s.addi       s26, s21, #11
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    s.muli       s19, s14, #12
    vf.cvt.f32.bf16 v4, v0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s22
    p.and        p3, p1, p2
    s.movz       s22, #12
    s.addi       s26, s21, #12
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    s.muli       s19, s14, #13
    vf.cvt.f32.bf16 v4, v0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s22
    p.and        p3, p1, p2
    s.movz       s22, #13
    s.addi       s26, s21, #13
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    s.muli       s19, s14, #14
    vf.cvt.f32.bf16 v4, v0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s22
    p.and        p3, p1, p2
    s.movz       s22, #14
    s.addi       s26, s21, #14
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    s.muli       s19, s14, #15
    vf.cvt.f32.bf16 v4, v0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s22
    p.and        p3, p1, p2
    s.movz       s22, #15
    s.addi       s26, s21, #15
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    vf.cvt.f32.bf16 v4, v0
    s.movz       s19, #0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.muli       s15, s18, #2
    s.add        s17, s19, s18                   // the tile origin
    s.add        s18, s5, s22
    s.movz       s19, #0
    p.and        p3, p1, p2
    s.movz       s22, #0
    v.splat      v0, s17
    s.add        s17, s19, s8                    // the tile origin
    @p3 v.st.h       [s18, #0], v4
    a.vread      v1, a2, s22
    v.splat      v4, s21
    v.add        v5, v3, v0
    vf.cvt.f32.bf16 v0, v1
    s.add        s18, s20, s15
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s17
    s.add        s17, s5, s18
    s.muli       s18, s14, #1
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    s.movz       s19, #1
    s.addi       s22, s21, #1
    @p3 v.st.h       [s17, #0], v0
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    s.muli       s18, s14, #2
    vf.cvt.f32.bf16 v4, v0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s19
    p.and        p3, p1, p2
    s.movz       s19, #2
    s.addi       s22, s21, #2
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    s.muli       s18, s14, #3
    vf.cvt.f32.bf16 v4, v0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s19
    p.and        p3, p1, p2
    s.movz       s19, #3
    s.addi       s22, s21, #3
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    s.muli       s18, s14, #4
    vf.cvt.f32.bf16 v4, v0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s19
    p.and        p3, p1, p2
    s.movz       s19, #4
    s.addi       s22, s21, #4
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    s.muli       s18, s14, #5
    vf.cvt.f32.bf16 v4, v0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s19
    p.and        p3, p1, p2
    s.movz       s19, #5
    s.addi       s22, s21, #5
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    s.muli       s18, s14, #6
    vf.cvt.f32.bf16 v4, v0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s19
    p.and        p3, p1, p2
    s.movz       s19, #6
    s.addi       s22, s21, #6
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    s.muli       s18, s14, #7
    vf.cvt.f32.bf16 v4, v0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s19
    p.and        p3, p1, p2
    s.movz       s19, #7
    s.addi       s22, s21, #7
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    s.muli       s18, s14, #8
    vf.cvt.f32.bf16 v4, v0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s19
    p.and        p3, p1, p2
    s.movz       s19, #8
    s.addi       s22, s21, #8
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    s.muli       s18, s14, #9
    vf.cvt.f32.bf16 v4, v0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s19
    p.and        p3, p1, p2
    s.movz       s19, #9
    s.addi       s22, s21, #9
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    s.muli       s18, s14, #10
    vf.cvt.f32.bf16 v4, v0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s19
    p.and        p3, p1, p2
    s.movz       s19, #10
    s.addi       s22, s21, #10
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    s.muli       s18, s14, #11
    vf.cvt.f32.bf16 v4, v0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s19
    p.and        p3, p1, p2
    s.movz       s19, #11
    s.addi       s22, s21, #11
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    s.muli       s18, s14, #12
    vf.cvt.f32.bf16 v4, v0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s19
    p.and        p3, p1, p2
    s.movz       s19, #12
    s.addi       s22, s21, #12
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    s.muli       s18, s14, #13
    vf.cvt.f32.bf16 v4, v0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s19
    p.and        p3, p1, p2
    s.movz       s19, #13
    s.addi       s22, s21, #13
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    s.muli       s18, s14, #14
    vf.cvt.f32.bf16 v4, v0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s19
    p.and        p3, p1, p2
    s.movz       s19, #14
    s.addi       s22, s21, #14
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    s.muli       s18, s14, #15
    vf.cvt.f32.bf16 v4, v0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s19
    p.and        p3, p1, p2
    s.movz       s19, #15
    s.addi       s22, s21, #15
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    vf.cvt.f32.bf16 v4, v0
    s.movz       s18, #0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.muli       s15, s16, #2
    s.add        s17, s18, s16                   // the tile origin
    s.add        s16, s5, s19
    s.movz       s18, #0
    p.and        p3, p1, p2
    s.movz       s19, #0
    v.splat      v0, s17
    s.add        s17, s18, s8                    // the tile origin
    @p3 v.st.h       [s16, #0], v4
    a.vread      v1, a3, s19
    v.splat      v4, s21
    v.add        v5, v3, v0
    vf.cvt.f32.bf16 v0, v1
    s.add        s16, s20, s15
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s17
    s.add        s17, s5, s16
    s.muli       s16, s14, #1
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    s.movz       s18, #1
    s.addi       s19, s21, #1
    @p3 v.st.h       [s17, #0], v0
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    s.muli       s16, s14, #2
    vf.cvt.f32.bf16 v4, v0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s18
    p.and        p3, p1, p2
    s.movz       s18, #2
    s.addi       s19, s21, #2
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    s.muli       s16, s14, #3
    vf.cvt.f32.bf16 v4, v0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s18
    p.and        p3, p1, p2
    s.movz       s18, #3
    s.addi       s19, s21, #3
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    s.muli       s16, s14, #4
    vf.cvt.f32.bf16 v4, v0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s18
    p.and        p3, p1, p2
    s.movz       s18, #4
    s.addi       s19, s21, #4
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    s.muli       s16, s14, #5
    vf.cvt.f32.bf16 v4, v0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s18
    p.and        p3, p1, p2
    s.movz       s18, #5
    s.addi       s19, s21, #5
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    s.muli       s16, s14, #6
    vf.cvt.f32.bf16 v4, v0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s18
    p.and        p3, p1, p2
    s.movz       s18, #6
    s.addi       s19, s21, #6
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    s.muli       s16, s14, #7
    vf.cvt.f32.bf16 v4, v0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s18
    p.and        p3, p1, p2
    s.movz       s18, #7
    s.addi       s19, s21, #7
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    s.muli       s16, s14, #8
    vf.cvt.f32.bf16 v4, v0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s18
    p.and        p3, p1, p2
    s.movz       s18, #8
    s.addi       s19, s21, #8
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    s.muli       s16, s14, #9
    vf.cvt.f32.bf16 v4, v0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s18
    p.and        p3, p1, p2
    s.movz       s18, #9
    s.addi       s19, s21, #9
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    s.muli       s16, s14, #10
    vf.cvt.f32.bf16 v4, v0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s18
    p.and        p3, p1, p2
    s.movz       s18, #10
    s.addi       s19, s21, #10
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    s.muli       s16, s14, #11
    vf.cvt.f32.bf16 v4, v0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s18
    p.and        p3, p1, p2
    s.movz       s18, #11
    s.addi       s19, s21, #11
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    s.muli       s16, s14, #12
    vf.cvt.f32.bf16 v4, v0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s18
    p.and        p3, p1, p2
    s.movz       s18, #12
    s.addi       s19, s21, #12
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    s.muli       s16, s14, #13
    vf.cvt.f32.bf16 v4, v0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s18
    p.and        p3, p1, p2
    s.movz       s18, #13
    s.addi       s19, s21, #13
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    s.muli       s16, s14, #14
    vf.cvt.f32.bf16 v4, v0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s18
    p.and        p3, p1, p2
    s.movz       s18, #14
    s.addi       s19, s21, #14
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    s.muli       s16, s14, #15
    vf.cvt.f32.bf16 v4, v0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s18
    p.and        p3, p1, p2
    s.movz       s18, #15
    s.addi       s19, s21, #15
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    vf.cvt.f32.bf16 v4, v0
    s.movz       s16, #0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.muli       s15, s1, #2
    s.add        s17, s16, s1                    // the tile origin
    s.add        s1, s5, s18
    s.movz       s16, #0
    p.and        p3, p1, p2
    s.movz       s18, #0
    v.splat      v0, s17
    s.add        s17, s16, s8                    // the tile origin
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a4, s18
    v.splat      v4, s21
    v.add        v5, v3, v0
    vf.cvt.f32.bf16 v0, v1
    s.add        s1, s20, s15
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s17
    s.add        s16, s5, s1
    s.muli       s1, s14, #1
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    s.movz       s17, #1
    s.addi       s18, s21, #1
    @p3 v.st.h       [s16, #0], v0
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #2
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #2
    s.addi       s18, s21, #2
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #3
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #3
    s.addi       s18, s21, #3
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #4
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #4
    s.addi       s18, s21, #4
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #5
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #5
    s.addi       s18, s21, #5
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #6
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #6
    s.addi       s18, s21, #6
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #7
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #7
    s.addi       s18, s21, #7
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #8
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #8
    s.addi       s18, s21, #8
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #9
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #9
    s.addi       s18, s21, #9
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #10
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #10
    s.addi       s18, s21, #10
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #11
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #11
    s.addi       s18, s21, #11
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #12
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #12
    s.addi       s18, s21, #12
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #13
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #13
    s.addi       s18, s21, #13
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #14
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #14
    s.addi       s18, s21, #14
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #15
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #15
    s.addi       s18, s21, #15
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    vf.cvt.f32.bf16 v4, v0
    s.movz       s1, #0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.muli       s15, s24, #2
    s.add        s16, s1, s24                    // the tile origin
    s.add        s1, s5, s17
    s.movz       s17, #0
    p.and        p3, p1, p2
    s.movz       s18, #0
    v.splat      v0, s16
    s.add        s16, s17, s8                    // the tile origin
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a5, s18
    v.splat      v4, s21
    v.add        v5, v3, v0
    vf.cvt.f32.bf16 v0, v1
    s.add        s1, s20, s15
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s16
    s.add        s16, s5, s1
    s.muli       s1, s14, #1
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    s.movz       s17, #1
    s.addi       s18, s21, #1
    @p3 v.st.h       [s16, #0], v0
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #2
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #2
    s.addi       s18, s21, #2
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #3
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #3
    s.addi       s18, s21, #3
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #4
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #4
    s.addi       s18, s21, #4
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #5
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #5
    s.addi       s18, s21, #5
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #6
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #6
    s.addi       s18, s21, #6
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #7
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #7
    s.addi       s18, s21, #7
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #8
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #8
    s.addi       s18, s21, #8
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #9
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #9
    s.addi       s18, s21, #9
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #10
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #10
    s.addi       s18, s21, #10
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #11
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #11
    s.addi       s18, s21, #11
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #12
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #12
    s.addi       s18, s21, #12
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #13
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #13
    s.addi       s18, s21, #13
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #14
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #14
    s.addi       s18, s21, #14
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #15
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #15
    s.addi       s18, s21, #15
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    vf.cvt.f32.bf16 v4, v0
    s.movz       s1, #0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.muli       s15, s23, #2
    s.add        s16, s1, s23                    // the tile origin
    s.add        s1, s5, s17
    s.movz       s17, #0
    p.and        p3, p1, p2
    s.movz       s18, #0
    v.splat      v0, s16
    s.add        s16, s17, s8                    // the tile origin
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a6, s18
    v.splat      v4, s21
    v.add        v5, v3, v0
    vf.cvt.f32.bf16 v0, v1
    s.add        s1, s20, s15
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s16
    s.add        s16, s5, s1
    s.muli       s1, s14, #1
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    s.movz       s17, #1
    s.addi       s18, s21, #1
    @p3 v.st.h       [s16, #0], v0
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #2
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #2
    s.addi       s18, s21, #2
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #3
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #3
    s.addi       s18, s21, #3
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #4
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #4
    s.addi       s18, s21, #4
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #5
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #5
    s.addi       s18, s21, #5
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #6
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #6
    s.addi       s18, s21, #6
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #7
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #7
    s.addi       s18, s21, #7
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #8
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #8
    s.addi       s18, s21, #8
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #9
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #9
    s.addi       s18, s21, #9
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #10
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #10
    s.addi       s18, s21, #10
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #11
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #11
    s.addi       s18, s21, #11
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #12
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #12
    s.addi       s18, s21, #12
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #13
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #13
    s.addi       s18, s21, #13
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #14
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #14
    s.addi       s18, s21, #14
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #15
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #15
    s.addi       s18, s21, #15
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    vf.cvt.f32.bf16 v4, v0
    s.movz       s1, #0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.muli       s15, s25, #2
    s.add        s16, s1, s25                    // the tile origin
    s.add        s1, s5, s17
    s.movz       s17, #0
    p.and        p3, p1, p2
    s.movz       s18, #0
    v.splat      v0, s16
    s.add        s16, s17, s8                    // the tile origin
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a7, s18
    v.splat      v4, s21
    v.add        v5, v3, v0
    v.splat      v0, s16
    vf.cvt.f32.bf16 v3, v1
    s.add        s1, s20, s15
    v.cmp.lt     p1, v4, v2
    v.cmp.lt     p2, v5, v0
    s.add        s16, s5, s1
    s.muli       s1, s14, #1
    p.and        p3, p1, p2
    s.movz       s17, #1
    s.addi       s18, s21, #1
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #2
    vf.cvt.f32.bf16 v3, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #2
    s.addi       s18, s21, #2
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #3
    vf.cvt.f32.bf16 v3, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #3
    s.addi       s18, s21, #3
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #4
    vf.cvt.f32.bf16 v3, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #4
    s.addi       s18, s21, #4
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #5
    vf.cvt.f32.bf16 v3, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #5
    s.addi       s18, s21, #5
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #6
    vf.cvt.f32.bf16 v3, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #6
    s.addi       s18, s21, #6
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #7
    vf.cvt.f32.bf16 v3, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #7
    s.addi       s18, s21, #7
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #8
    vf.cvt.f32.bf16 v3, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #8
    s.addi       s18, s21, #8
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #9
    vf.cvt.f32.bf16 v3, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #9
    s.addi       s18, s21, #9
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #10
    vf.cvt.f32.bf16 v3, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #10
    s.addi       s18, s21, #10
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #11
    vf.cvt.f32.bf16 v3, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #11
    s.addi       s18, s21, #11
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #12
    vf.cvt.f32.bf16 v3, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #12
    s.addi       s18, s21, #12
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #13
    vf.cvt.f32.bf16 v3, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #13
    s.addi       s18, s21, #13
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #14
    vf.cvt.f32.bf16 v3, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #14
    s.addi       s18, s21, #14
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #15
    vf.cvt.f32.bf16 v3, v0
    s.add        s14, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s14
    p.and        p3, p1, p2
    s.movz       s14, #15
    s.addi       s17, s21, #15
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s14
    s.add        s14, s1, s20
    v.splat      v1, s17
    vf.cvt.f32.bf16 v3, v0
    s.add        s1, s14, s15
    v.cmp.lt     p1, v1, v2
    s.add        s14, s5, s1
    p.and        p3, p1, p2
    s.addi       s1, s4, #16
    @p3 v.st.h       [s14, #0], v3
    s.mov        s4, s1
    s.movz       s1, #128
    s.cmp.lt     s14, s4, s1
    br.nz        s14, rows_1
endrows_2:
    exit
    exit
