    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.rdspecial  s1, arg_base
    s.ld.d       s5, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s6, #512
    s.mul        s7, s1, s6
    s.add        s1, s5, s7                      // this context's own scratch
    s.addi       s5, s1, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.st.d       [s5, #0], s2
    .li       s1, #2147483647
    s.st.d       [s5, #8], s1
    s.st.d       [s5, #16], s1
    s.movz       s2, #64
    s.st.d       [s5, #48], s2
    s.movz       s2, #2
    s.st.d       [s5, #56], s2
    .li       s6, #68719476752
    s.st.d       [s5, #88], s6
    .li       s7, #8589934592
    s.st.d       [s5, #104], s7
    fence.release.device
    td.load      d0, [s5]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.rdspecial  s5, arg_base
    s.ld.d       s8, [s5, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s5, role_id
    s.movz       s9, #512
    s.mul        s10, s5, s9
    s.add        s5, s8, s10                     // this context's own scratch
    s.addi       s8, s5, #256                    // TensorMap 1: a 2-D tt.load (built once, at entry)
    s.st.d       [s8, #0], s3
    s.st.d       [s8, #8], s1
    s.st.d       [s8, #16], s1
    s.movz       s1, #128
    s.st.d       [s8, #48], s1
    s.st.d       [s8, #56], s2
    s.st.d       [s8, #88], s6
    s.st.d       [s8, #104], s7
    fence.release.device
    td.load      d1, [s8]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #4
    s.movz       s2, #0
    s.cmp.lt     s3, s1, s2
    s.sub        s5, s2, s3
    s.movz       s3, #1
    s.rdspecial  s6, role_id
    s.rdspecial  s7, npid.x
__rctx_program:
    s.cmp.lt     s8, s6, s2
    s.addi       s9, s2, #0
    s.sub        s10, s2, s8
    s.addi       s8, s2, #0
    s.xor        s11, s6, s10
    s.xor        s12, s10, s5
    s.sub        s13, s11, s10
    s.lshri      s14, s13, #2
    s.mov        s9, s13
    s.xor        s15, s14, s12
    s.sub        s14, s15, s12
    s.sub        s12, s1, s14
    s.min.s      s15, s12, s3
    s.cmp.lt     s12, s15, s2
    s.sub        s16, s2, s12
    s.xor        s12, s15, s16
    s.sub        s15, s12, s16
    s.cmp.eq     s12, s15, s3
    br.nz        s12, sdiv_done_1
    s.movz       s17, #0
    s.movz       s18, #31
    s.mov        s9, s17
    s.addi       s19, s18, #0
sdiv_2:
    s.lshr       s18, s13, s19
    s.shli       s20, s8, #1
    s.andi       s21, s18, #1
    s.shl        s18, s3, s19
    s.or         s22, s20, s21
    s.cmp.geu    s20, s22, s15
    s.sub        s21, s17, s20
    s.and        s20, s15, s21
    s.and        s23, s18, s21
    s.sub        s8, s22, s20
    s.or         s9, s9, s23
    s.subi       s19, s19, #1
    s.cmp.ge     s18, s19, s17
    br.nz        s18, sdiv_2
sdiv_done_1:
    s.sub        s9, s11, s10
    s.xor        s11, s8, s10
    s.lshri      s8, s9, #2
    s.sub        s13, s11, s10
    s.muli       s11, s8, #4
    s.addi       s8, s2, #0
    s.add        s17, s14, s13
    s.addi       s13, s2, #0
    s.sub        s14, s9, s11
    s.xor        s9, s14, s10
    s.sub        s11, s9, s10
    s.cmp.lt     s9, s11, s2
    s.sub        s10, s2, s9
    s.xor        s9, s11, s10
    s.sub        s11, s9, s10
    s.mov        s8, s11
    br.nz        s12, sdiv_done_3
    s.movz       s9, #0
    s.movz       s12, #31
    s.mov        s8, s9
    s.addi       s14, s12, #0
    s.movz       s12, #1
sdiv_4:
    s.lshr       s18, s11, s14
    s.shli       s19, s13, #1
    s.andi       s20, s18, #1
    s.shl        s18, s12, s14
    s.or         s21, s19, s20
    s.cmp.geu    s19, s21, s15
    s.sub        s20, s9, s19
    s.and        s19, s15, s20
    s.and        s22, s18, s20
    s.sub        s13, s21, s19
    s.or         s8, s8, s22
    s.subi       s14, s14, #1
    s.cmp.ge     s18, s14, s9
    br.nz        s18, sdiv_4
sdiv_done_3:
    s.xor        s9, s10, s16
    s.rdspecial  s10, pid.z
    s.rdspecial  s11, npid.y
    s.xor        s12, s8, s9
    s.mul        s8, s10, s11
    s.sub        s10, s12, s9
    s.movz       s9, #16
    s.rdspecial  s11, pid.y
    s.mul        s12, s17, s9
    s.mul        s13, s10, s9
    s.add        s10, s11, s8
    s.movz       s8, #7
    s.movz       s11, #0
    s.min.s      s14, s10, s8
    s.movz       s8, #2048
    s.andi       s15, s12, #63
    s.andi       s16, s13, #63
    s.mul        s17, s14, s8
    s.movz       s8, #32
    s.addi       s14, s11, #0
    s.addi       s18, s11, #0
    s.addi       s19, s11, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s20, s14, s8
    br.nz        s20, endfor_6
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s20, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.add        s21, s17, s18
    s.add        s22, s16, s17
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s23, s15                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s24, s21                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s23, s20
    w.def        w1, #48, #8                     // v48..v55
    s.add        s21, s22, s19
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s22, s11                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s23, s21                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s22, s20
    mb.wait      s20
gemm_pipe:
    mb.arm       s21, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.dp.async.k16.f16 a0, v56, v48, s21
    s.addi       s18, s18, #16
    s.addi       s19, s19, #1024
    s.add        s14, s14, s9
    s.movz       s22, #1
    s.cmp.ge     s22, s14, s8
    br.nz        s22, gemm_pipe_drain0
    w.def        w2, #40, #8                     // v40..v47
    mb.arm       s22, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.add        s23, s17, s18
    s.add        s24, s16, s17
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s25, s15                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s26, s23                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w2, d0, s25, s22
    w.def        w3, #32, #8                     // v32..v39
    s.add        s23, s24, s19
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s24, s11                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s25, s23                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w3, d1, s24, s22
    mb.wait      s22
    mb.wait      s21
    mb.arm       s23, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.dp.async.k16.f16 a0, v40, v32, s23
    s.addi       s18, s18, #16
    s.addi       s19, s19, #1024
    s.add        s14, s14, s9
    s.movz       s24, #1
    s.cmp.ge     s24, s14, s8
    br.nz        s24, gemm_pipe_drain1
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s24, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.add        s25, s17, s18
    s.add        s26, s16, s17
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s27, s15                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s28, s25                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s27, s24
    w.def        w1, #48, #8                     // v48..v55
    s.add        s25, s26, s19
    s.movz       s26, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s27, s11                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s28, s25                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s27, s24
    mb.wait      s24
    mb.wait      s23
    br.nz        s26, gemm_pipe
gemm_pipe_drain0:
    s.movz       s8, #1
    mb.wait      s21
    br.nz        s8, endfor_6
gemm_pipe_drain1:
    mb.wait      s23
endfor_6:
    s.movz       s8, #4096
    s.add        s9, s11, s13                    // the tile origin
    s.mul        s14, s10, s8
    s.muli       s8, s13, #2                     // a runtime tile origin, x2
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s9
    s.add        s9, s11, s12                    // the tile origin
    s.movz       s13, #64
    s.muli       s15, s12, #128                  // a runtime tile origin, x128
    s.movz       s12, #8
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    a.vread      v2, a0, s11
    v.splat      v3, s9
    v.splat      v4, s13
    v.add        v5, v0, v1
    s.muli       s11, s14, #2                    // a runtime tile origin, x2
    v.splat      v0, s10
    v.splat      v1, s12
    s.add        s10, s4, s8                     // the tile origin
    vf.cvt.f32.f16 v6, v2
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v4
    s.add        s8, s10, s15                    // the tile origin
    p.and        p3, p1, p2
    v.cmp.lt     p1, v0, v1
    s.add        s10, s8, s11                    // the tile origin
    p.and        p4, p3, p1
    s.movz       s8, #1
    s.addi       s11, s9, #1
    @p4 v.st.h       [s10, #0], v6
    a.vread      v0, a0, s8
    v.splat      v1, s11
    s.addi       s8, s10, #128                   // row 1
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p3, v1, v4
    p.and        p4, p3, p2
    s.movz       s11, #2
    p.and        p3, p4, p1
    s.addi       s13, s9, #2
    s.addi       s14, s10, #256                  // row 2
    v.splat      v0, s13
    s.movz       s13, #3
    s.addi       s15, s9, #3
    @p3 v.st.h       [s8, #0], v2
    a.vread      v1, a0, s11
    v.cmp.lt     p3, v0, v4
    p.and        p4, p3, p2
    vf.cvt.f32.f16 v0, v1
    p.and        p3, p4, p1
    v.splat      v1, s15
    s.addi       s8, s10, #384                   // row 3
    s.movz       s11, #4
    v.cmp.lt     p4, v1, v4
    p.and        p5, p4, p2
    s.addi       s15, s9, #4
    p.and        p4, p5, p1
    v.splat      v1, s15
    @p3 v.st.h       [s14, #0], v0
    a.vread      v0, a0, s13
    v.cmp.lt     p3, v1, v4
    p.and        p5, p3, p2
    vf.cvt.f32.f16 v1, v0
    s.addi       s13, s10, #512                  // row 4
    p.and        p3, p5, p1
    s.movz       s14, #5
    s.addi       s15, s9, #5
    s.addi       s16, s10, #640                  // row 5
    v.splat      v0, s15
    s.movz       s15, #6
    s.addi       s17, s9, #6
    s.addi       s18, s10, #768                  // row 6
    @p4 v.st.h       [s8, #0], v1
    a.vread      v1, a0, s11
    v.cmp.lt     p4, v0, v4
    p.and        p5, p4, p2
    vf.cvt.f32.f16 v0, v1
    p.and        p4, p5, p1
    v.splat      v1, s17
    s.movz       s8, #7
    s.addi       s11, s9, #7
    s.addi       s17, s10, #896                  // row 7
    v.splat      v2, s11
    s.addi       s11, s9, #8
    v.splat      v3, s11
    @p3 v.st.h       [s13, #0], v0
    a.vread      v0, a0, s14
    v.cmp.lt     p3, v1, v4
    p.and        p5, p3, p2
    vf.cvt.f32.f16 v1, v0
    p.and        p3, p5, p1
    s.addi       s11, s10, #1024                 // row 8
    s.movz       s13, #9
    s.addi       s14, s9, #9
    v.splat      v0, s14
    s.addi       s14, s10, #1152                 // row 9
    @p4 v.st.h       [s16, #0], v1
    a.vread      v1, a0, s15
    v.cmp.lt     p4, v2, v4
    p.and        p5, p4, p2
    vf.cvt.f32.f16 v2, v1
    p.and        p4, p5, p1
    s.movz       s15, #10
    s.addi       s16, s9, #10
    v.splat      v1, s16
    s.addi       s16, s10, #1280                 // row 10
    @p3 v.st.h       [s18, #0], v2
    a.vread      v2, a0, s8
    v.cmp.lt     p3, v3, v4
    p.and        p5, p3, p2
    vf.cvt.f32.f16 v3, v2
    p.and        p3, p5, p1
    s.movz       s8, #11
    s.addi       s18, s9, #11
    v.splat      v2, s18
    s.addi       s18, s10, #1408                 // row 11
    @p4 v.st.h       [s17, #0], v3
    a.vread      v3, a0, s12
    v.cmp.lt     p4, v0, v4
    p.and        p5, p4, p2
    vf.cvt.f32.f16 v0, v3
    p.and        p4, p5, p1
    s.movz       s12, #12
    s.addi       s17, s9, #12
    v.splat      v3, s17
    s.addi       s17, s10, #1536                 // row 12
    @p3 v.st.h       [s11, #0], v0
    a.vread      v0, a0, s13
    v.cmp.lt     p3, v1, v4
    p.and        p5, p3, p2
    vf.cvt.f32.f16 v1, v0
    p.and        p3, p5, p1
    s.movz       s11, #13
    s.addi       s13, s9, #13
    v.splat      v0, s13
    s.addi       s13, s10, #1664                 // row 13
    @p4 v.st.h       [s14, #0], v1
    a.vread      v1, a0, s15
    v.cmp.lt     p4, v2, v4
    p.and        p5, p4, p2
    vf.cvt.f32.f16 v2, v1
    p.and        p4, p5, p1
    s.movz       s14, #14
    s.addi       s15, s9, #14
    s.addi       s19, s9, #15
    v.splat      v1, s15
    s.addi       s9, s10, #1792                  // row 14
    v.splat      v5, s19
    s.movz       s15, #15
    s.addi       s19, s10, #1920                 // row 15
    @p3 v.st.h       [s16, #0], v2
    a.vread      v2, a0, s8
    v.cmp.lt     p3, v3, v4
    p.and        p5, p3, p2
    vf.cvt.f32.f16 v3, v2
    p.and        p3, p5, p1
    @p4 v.st.h       [s18, #0], v3
    a.vread      v2, a0, s12
    v.cmp.lt     p4, v0, v4
    p.and        p5, p4, p2
    vf.cvt.f32.f16 v0, v2
    p.and        p4, p5, p1
    @p3 v.st.h       [s17, #0], v0
    a.vread      v0, a0, s11
    v.cmp.lt     p3, v1, v4
    p.and        p5, p3, p2
    vf.cvt.f32.f16 v1, v0
    p.and        p3, p5, p1
    @p4 v.st.h       [s13, #0], v1
    a.vread      v0, a0, s14
    v.cmp.lt     p4, v5, v4
    p.and        p5, p4, p2
    vf.cvt.f32.f16 v1, v0
    p.and        p2, p5, p1
    @p3 v.st.h       [s9, #0], v1
    a.vread      v0, a0, s15
    vf.cvt.f32.f16 v1, v0
    @p2 v.st.h       [s19, #0], v1
__rctx_next:
    s.addi       s8, s6, #2                      // the next program of this context: + 2
    s.cmp.lt     s9, s8, s7
    s.mov        s6, s8
    br.nz        s9, __rctx_program
    exit
