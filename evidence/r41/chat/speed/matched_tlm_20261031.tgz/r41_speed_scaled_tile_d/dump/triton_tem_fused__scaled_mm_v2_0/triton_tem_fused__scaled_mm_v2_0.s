    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    s.ld.d       s3, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.addi       s4, s2, #0
    s.ld.d       s5, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s6, [s1, #16]                   // arg_SA: device_ptr64 at arg_base+16
    s.ld.d       s7, [s1, #24]                   // arg_SB: device_ptr64 at arg_base+24
    s.ld.d       s8, [s1, #32]                   // out_ptr1: device_ptr64 at arg_base+32
rows_1:
    s.rdspecial  s1, pid.x
    s.movz       s9, #64
    s.cmp.lt     s10, s1, s2
    v.iota       v0                              // arange(0, VLEN)
    s.sub        s11, s2, s10
    v.movi       v1, #16
    s.xor        s10, s1, s11
    v.movi       v2, #32
    s.sub        s1, s10, s11
    v.movi       v3, #48
    s.lshri      s10, s1, #2
    v.add        v4, v0, v1
    s.muli       s12, s10, #4
    v.add        v1, v0, v2
    v.add        v2, v0, v3
    s.movz       s13, #4
    // rows [r0, r0 + 16) of a 64-row program (row_split)
    v.iota       v3                              // arange(0, VLEN)
    s.sub        s14, s1, s12
    s.cmp.lt     s1, s13, s2
    s.xor        s12, s14, s11
    s.sub        s14, s2, s1
    s.sub        s1, s12, s11
    s.xor        s12, s11, s14
    s.mul        s11, s1, s9
    s.xor        s1, s10, s12
    v.splat      v5, s4
    s.sub        s10, s1, s12
    v.movi       v6, #0
    v.splat      v7, s11
    s.mul        s1, s10, s9
    v.add        v8, v3, v5
    v.add        v3, v7, v0
    v.add        v0, v7, v4
    v.add        v4, v7, v1
    v.add        v1, v7, v2
    v.movi       v2, #0
    v.splat      v5, s1
    v.movi       v7, #63
    v.sub        v9, v2, v3
    v.cmp.lt     p1, v3, v2
    v.add        v10, v5, v8
    @p1 v.sel        v5, v9, v3
    v.movi       v3, #64
    v.sub        v8, v6, v10
    v.cmp.lt     p2, v10, v6
    v.movi       v9, #256
    @p2 v.sel        v11, v8, v10
    v.sub        v8, v6, v3
    s.xor        s10, s13, s14
    v.and        v10, v11, v7
    v.sub        v7, v2, v9
    v.cmp.lt     p3, v3, v6
    v.sub        v11, v6, v10
    s.sub        s12, s10, s14
    v.movi       v6, #0
    v.movi       v12, #0
    v.movi       v13, #255
    v.sub        v14, v6, v0
    v.movi       v15, #255
    v.and        v16, v5, v13
    v.movi       v5, #256
    s.add        s10, s4, s1
    v.movi       v13, #1
    @p3 v.sel        v13, v8, v3
    v.movi       v3, #0
    v.sub        v8, v12, v4
    v.cmp.lt     p3, v0, v6
    @p3 v.sel        v13, v14, v0
    v.sub        v0, v3, v1
    @p2 v.sel        v14, v11, v10
    v.cmp.lt     p2, v4, v12
    @p2 v.sel        v10, v8, v4
    v.movi       v4, #255
    v.movi       v8, #255
    v.and        v11, v13, v15
    v.and        v13, v10, v4
    v.sub        v4, v2, v16
    v.sub        v10, v6, v11
    v.movi       v15, #1
    @p1 v.sel        v15, v4, v16
    v.cmp.lt     p1, v1, v3
    @p1 v.sel        v4, v0, v1
    v.sub        v0, v12, v13
    @p3 v.sel        v1, v10, v11
    v.and        v10, v4, v8
    @p2 v.sel        v4, v0, v13
    v.movi       v0, #256
    v.sub        v8, v3, v10
    v.movi       v11, #256
    v.sub        v13, v6, v5
    @p1 v.sel        v16, v8, v10
    v.sub        v8, v12, v0
    v.cmp.lt     p1, v9, v2
    v.sub        v2, v3, v11
    v.cmp.lt     p2, v5, v6
    v.iota       v6                              // arange(0, VLEN)
    v.cmp.lt     p3, v0, v12
    v.movi       v10, #16
    @p1 v.sel        v12, v7, v9
    v.movi       v7, #32
    v.movi       v9, #48
    v.cmp.lt     p1, v11, v3
    v.iota       v3                              // arange(0, VLEN)
    v.movi       v12, #1
    @p2 v.sel        v12, v13, v5
    v.movi       v5, #128
    v.movi       v12, #64
    v.movi       v13, #1
    @p3 v.sel        v13, v8, v0
    v.movi       v0, #0
    v.movi       v8, #7
    v.movi       v13, #1
    v.cmp.lt     p2, v15, v0
    v.cmp.lt     p3, v5, v0
    @p1 v.sel        v13, v2, v11
    v.movi       v2, #0
    v.sub        v11, v0, v15
    v.add        v13, v6, v10
    v.movi       v10, #0
    v.cmp.lt     p1, v1, v2
    @p2 v.sel        v13, v11, v15
    v.add        v11, v6, v7
    v.sub        v7, v2, v1
    v.lshr       v11, v13, v8
    v.movi       v8, #7
    @p1 v.sel        v13, v7, v1
    v.add        v7, v6, v9
    v.sub        v6, v10, v4
    v.lshr       v7, v13, v8
    v.sub        v8, v0, v11
    v.movi       v9, #128
    v.sub        v13, v0, v5
    @p2 v.sel        v0, v8, v11
    v.cmp.lt     p2, v4, v10
    @p2 v.sel        v8, v6, v4
    v.sub        v6, v2, v7
    v.add        v11, v3, v12
    v.movi       v11, #128
    @p1 v.sel        v12, v6, v7
    v.movi       v6, #80
    v.cmp.lt     p1, v9, v2
    v.sub        v7, v2, v9
    v.add        v2, v3, v6
    v.movi       v2, #7
    s.movz       s1, #16
    s.movz       s12, #32
    v.lshr       v6, v8, v2
    v.movi       v2, #96
    s.movz       s13, #48
    s.movz       s14, #80
    v.add        v8, v3, v2
    v.sub        v2, v10, v6
    v.iota       v3                              // arange(0, VLEN)
    s.movz       s15, #96
    @p2 v.sel        v8, v2, v6
    v.movi       v2, #128
    v.cmp.lt     p2, v11, v10
    v.sub        v6, v10, v11
    s.movz       s16, #112
    v.movi       v10, #1
    @p3 v.sel        v10, v13, v5
    v.movi       v5, #112
    v.movi       v10, #0
    v.movi       v13, #1
    v.add        v13, v3, v5
    v.sub        v3, v10, v16
    v.cmp.lt     p3, v16, v10
    v.movi       v5, #7
    @p3 v.sel        v13, v3, v16
    s.movz       s17, #0
    @p1 v.sel        v3, v7, v9
    v.lshr       v3, v13, v5
    v.sub        v5, v10, v2
    v.movi       v7, #4
    v.sub        v9, v10, v3
    v.cmp.lt     p1, v2, v10
    v.movi       v10, #1
    @p3 v.sel        v10, v9, v3
    @p2 v.sel        v3, v6, v11
    v.movi       v3, #1
    @p1 v.sel        v3, v5, v2
    v.mul        v2, v0, v7
    v.mul        v0, v12, v7
    v.mul        v3, v8, v7
    v.mul        v5, v10, v7
    s.movz       s18, #2
    s.movz       s19, #1
    s.addi       s20, s17, #0
    s.addi       s21, s17, #0
    s.addi       s22, s17, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
for_3:
    s.cmp.ge     s23, s20, s18
    br.nz        s23, endfor_4
    v.extract    s23, v15, #0
    v.iota       v6                              // arange(0, VLEN)
    v.splat      v7, s23
    v.extract    s24, v1, #0
    s.movz       s25, #128
    v.add        v8, v7, v6
    v.splat      v7, s24
    s.mul        s26, s20, s25
    v.sub        v9, v15, v8
    v.add        v8, v7, v6
    s.movz       s25, #256
    s.mul        s27, s20, s9
    s.sub        s28, s25, s26
    v.reduce.or  s26, v9
    s.movz       s29, #0
    v.sub        v7, v1, v8
    s.add        s30, s17, s28
    s.cmp.eq     s31, s26, s29
    s.cmp.ge     s26, s23, s29
    v.reduce.or  s32, v7
    s.shli       s33, s27, #2                    // element offset -> bytes (x4)
    s.shli       s34, s20, #2                    // element offset -> bytes (x4)
    s.cmp.ge     s35, s30, s17
    s.and        s36, s31, s26
    v.movi       v7, #0
    s.cmp.eq     s26, s32, s29
    s.cmp.ge     s31, s24, s29
    s.add        s32, s6, s33                    // &arg_SA[...]
    s.add        s33, s7, s34                    // &arg_SB[...]
    // tl.dot 16x128 by 128x64 FP8, B as W's rows written transposed by the engine (ISA sec 9E, tensor_transpose_8bit)
    s.rdspecial  s34, arg_base
    s.and        s37, s36, s35
    s.and        s36, s26, s31
    v.ld.gather.w v8, [s32, v14]                 // index is in elements (ISA sec 9.1)
    v.movi       v9, #0
    s.and        s26, s36, s35
    v.splat      v10, s25
    v.splat      v11, s25
    v.splat      v12, s27
    v.extract    s25, v4, #0
    v.splat      v12, s20
    v.splat      v12, s25
    v.splat      v13, s20
    v.splat      v13, s20
    v.add        v13, v12, v6
    v.splat      v12, s20
    s.cmp.ge     s27, s25, s29
    v.sub        v12, v4, v13
    v.mul        v13, v15, v10
    v.mul        v17, v1, v10
    v.reduce.or  s31, v12
    v.ld.gather.w v12, [s33, v2]                 // index is in elements (ISA sec 9.1)
    s.cmp.eq     s32, s31, s29
    v.mul        v18, v4, v10
    s.and        s31, s32, s27
    v.mul        v10, v16, v11
    s.and        s27, s31, s35
    v.ld.gather.w v11, [s33, v0]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v19, [s33, v3]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v20, [s33, v5]                 // index is in elements (ISA sec 9.1)
    v.extract    s31, v16, #0
    v.splat      v21, s31
    s.cmp.ge     s32, s31, s29
    v.add        v22, v21, v6
    v.sub        v6, v16, v22
    v.reduce.or  s33, v6
    s.cmp.eq     s36, s33, s29
    s.and        s29, s36, s32
    s.ld.d       s32, [s34, #40]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.insert     v7, s37, #0
    v.insert     v9, s23, #0
    s.and        s23, s29, s35
    v.insert     v7, s26, #1
    v.insert     v9, s24, #1
    s.add        s24, s5, s22
    v.insert     v7, s27, #2
    v.insert     v9, s25, #2
    .li       s25, #2147483647
    v.insert     v7, s23, #3
    s.addi       s23, s32, #0                    // TensorMap 0: W's rows for a transposed FP8 B
    s.movz       s26, #256
    s.movz       s27, #1
    .li       s29, #137438953488
    .li       s33, #7705171329024
    s.addi       s34, s32, #256
    s.addi       s35, s32, #768                  // TensorMap 1: the gathered fallback B tile
    s.movz       s36, #32
    v.insert     v9, s31, #3
    s.movz       s31, #16
    s.st.d       [s23, #0], s24
    .li       s24, #68719476768
    s.st.d       [s23, #8], s25
    v.extract    s25, v7, #0
    s.st.d       [s23, #16], s30
    s.st.d       [s23, #48], s26
    s.movz       s26, #0
    s.st.d       [s23, #56], s27
    s.st.d       [s23, #88], s29
    s.st.d       [s23, #104], s33
    fence.release.device
    td.load      d0, [s23]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.st.d       [s35, #0], s34
    s.st.d       [s35, #8], s36
    s.st.d       [s35, #16], s31
    s.st.d       [s35, #48], s31
    s.st.d       [s35, #56], s27
    s.st.d       [s35, #88], s24
    s.st.d       [s35, #104], s33
    fence.release.device
    td.load      d1, [s35]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    m.zero       a4
    m.zero       a5
    m.zero       a6
    m.zero       a7
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s25, x8dot_done_5
    s.addi       s23, s26, #0
    s.add        s24, s5, s22
x8dot_row_6:
    s.addi       s27, s30, #0
    v.movi       v6, #0
    s.sub        s29, s27, s23
    s.add        s27, s24, s23
    v.splat      v21, s29
    s.shli       s29, s23, #4
    s.addi       s31, s23, #1
    v.cmp.gt     p1, v21, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v6, [s27, v13]             // index is in elements (ISA sec 9.1)
    s.add        s27, s34, s29
    v.st.b       [s27, #0], v6
    fence.acq_rel.device
    s.mov        s23, s31
    s.cmp.lt     s27, s23, s36
    br.nz        s27, x8dot_row_6
x8dot_done_5:
    v.splat      v6, s25
    v.movi       v21, #0
    mb.arm       s23, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s24, v9, #0
    v.extract    s25, v7, #1
    v.cmp.ne     p1, v6, v21
    v.cmp.eq     p2, v6, v21
    s.mov        s33, s26                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s26                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s33, s23            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s33, s24                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s26                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s33, s23          // predicated off still completes once (ISA sec 9A.3)
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s25, x8dot_done_7
    s.addi       s24, s26, #0
    s.add        s26, s5, s22
    s.addi       s27, s32, #256
x8dot_row_8:
    s.addi       s29, s30, #0
    v.movi       v6, #0
    s.sub        s31, s29, s24
    s.add        s29, s26, s24
    v.splat      v21, s31
    s.shli       s31, s24, #4
    s.addi       s33, s24, #1
    v.cmp.gt     p1, v21, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v6, [s29, v17]             // index is in elements (ISA sec 9.1)
    s.add        s29, s27, s31
    s.movz       s31, #32
    v.st.b       [s29, #0], v6
    fence.acq_rel.device
    s.mov        s24, s33
    s.cmp.lt     s29, s24, s31
    br.nz        s29, x8dot_row_8
x8dot_done_7:
    s.movz       s24, #256
    s.movz       s26, #0
    v.splat      v6, s24
    s.add        s24, s26, s28                   // the tile origin
    v.splat      v21, s25
    v.mul        v22, v14, v6
    v.movi       v6, #0
    v.iota       v23                             // arange(0, VLEN)
    v.extract    s25, v22, #0
    v.splat      v24, s24
    s.add        s24, s25, s21
    mb.arm       s25, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s27, v9, #1
    s.add        s29, s3, s24
    v.cmp.ne     p1, v21, v6
    v.cmp.eq     p2, v21, v6
    v.cmp.lt     p3, v23, v24
    s.mov        s33, s26                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s26                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s33, s25            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s33, s27                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s26                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s33, s25          // predicated off still completes once (ISA sec 9A.3)
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s29, #0]
    v.extract    s24, v22, #1
    s.addi       s26, s32, #1024                 // 512 bytes of repack scratch
    s.add        s27, s24, s21
    s.addi       s24, s26, #0
    s.add        s29, s3, s27
    v.extract    s27, v22, #2
    s.addi       s31, s26, #32
    s.add        s33, s27, s21
    v.extract    s27, v22, #3
    s.add        s34, s3, s33
    s.add        s33, s27, s21
    v.st.b       [s24, #0], v6
    s.addi       s24, s26, #64
    s.add        s27, s3, s33
    v.extract    s33, v22, #4
    s.addi       s35, s26, #96
    s.add        s36, s33, s21
    s.add        s33, s3, s36
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s29, #0]
    v.extract    s29, v22, #5
    s.add        s36, s29, s21
    s.add        s29, s3, s36
    v.st.b       [s31, #0], v6
    s.addi       s31, s26, #128
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s34, #0]
    v.extract    s34, v22, #6
    s.add        s36, s34, s21
    s.add        s34, s3, s36
    v.st.b       [s24, #0], v6
    s.addi       s24, s26, #160
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s27, #0]
    v.extract    s27, v22, #7
    s.add        s36, s27, s21
    s.add        s27, s3, s36
    v.st.b       [s35, #0], v6
    s.addi       s35, s26, #192
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s33, #0]
    v.extract    s33, v22, #8
    s.add        s36, s33, s21
    s.add        s33, s3, s36
    v.st.b       [s31, #0], v6
    s.addi       s31, s26, #224
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s29, #0]
    v.extract    s29, v22, #9
    s.add        s36, s29, s21
    s.add        s29, s3, s36
    v.st.b       [s24, #0], v6
    s.addi       s24, s26, #256
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s34, #0]
    v.extract    s34, v22, #10
    s.add        s36, s34, s21
    s.add        s34, s3, s36
    v.st.b       [s35, #0], v6
    s.addi       s35, s26, #288
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s27, #0]
    v.extract    s27, v22, #11
    s.add        s36, s27, s21
    s.add        s27, s3, s36
    v.st.b       [s31, #0], v6
    s.addi       s31, s26, #320
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s33, #0]
    v.extract    s33, v22, #12
    s.add        s36, s33, s21
    s.add        s33, s3, s36
    v.st.b       [s24, #0], v6
    s.addi       s24, s26, #352
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s29, #0]
    v.extract    s29, v22, #13
    s.add        s36, s29, s21
    s.add        s29, s3, s36
    v.st.b       [s35, #0], v6
    s.addi       s35, s26, #384
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s34, #0]
    v.extract    s34, v22, #14
    s.add        s36, s34, s21
    s.add        s34, s3, s36
    v.st.b       [s31, #0], v6
    s.addi       s31, s26, #416
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s27, #0]
    v.extract    s27, v22, #15
    s.add        s36, s27, s21
    s.add        s27, s3, s36
    v.st.b       [s24, #0], v6
    s.addi       s24, s26, #448
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s33, #0]
    s.movz       s33, #0
    v.st.b       [s35, #0], v6
    s.add        s35, s33, s1                    // the tile origin
    s.add        s36, s33, s28                   // the tile origin
    v.splat      v6, s35
    v.extract    s33, v22, #0
    v.splat      v21, s36
    s.add        s35, s33, s21
    v.add        v24, v23, v6
    s.addi       s33, s35, #16
    s.addi       s35, s26, #480
    s.add        s36, s3, s33
    v.cmp.lt     p1, v24, v21
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s29, #0]
    v.extract    s29, v22, #1
    s.add        s33, s29, s21
    s.addi       s29, s33, #16
    s.add        s33, s3, s29
    v.st.b       [s31, #0], v6
    s.addi       s29, s26, #16
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s34, #0]
    v.extract    s31, v22, #2
    s.add        s34, s31, s21
    s.addi       s31, s34, #16
    s.add        s34, s3, s31
    v.st.b       [s24, #0], v6
    s.addi       s24, s26, #48
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s27, #0]
    v.extract    s27, v22, #3
    s.add        s31, s27, s21
    s.addi       s27, s31, #16
    s.add        s31, s3, s27
    v.st.b       [s35, #0], v6
    s.addi       s27, s26, #80
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s36, #0]
    v.extract    s35, v22, #4
    s.add        s36, s35, s21
    s.addi       s35, s36, #16
    s.add        s36, s3, s35
    v.st.b       [s29, #0], v6
    s.addi       s29, s26, #112
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s33, #0]
    v.extract    s33, v22, #5
    s.add        s35, s33, s21
    s.addi       s33, s35, #16
    s.add        s35, s3, s33
    v.st.b       [s24, #0], v6
    s.addi       s24, s26, #144
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s34, #0]
    v.extract    s33, v22, #6
    s.add        s34, s33, s21
    s.addi       s33, s34, #16
    s.add        s34, s3, s33
    v.st.b       [s27, #0], v6
    s.addi       s27, s26, #176
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s31, #0]
    v.extract    s31, v22, #7
    s.add        s33, s31, s21
    s.addi       s31, s33, #16
    s.add        s33, s3, s31
    v.st.b       [s29, #0], v6
    s.addi       s29, s26, #208
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s36, #0]
    v.extract    s31, v22, #8
    s.add        s36, s31, s21
    s.addi       s31, s36, #16
    s.add        s36, s3, s31
    v.st.b       [s24, #0], v6
    s.addi       s24, s26, #240
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s35, #0]
    v.extract    s31, v22, #9
    s.add        s35, s31, s21
    s.addi       s31, s35, #16
    s.add        s35, s3, s31
    v.st.b       [s27, #0], v6
    s.addi       s27, s26, #272
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s34, #0]
    v.extract    s31, v22, #10
    s.add        s34, s31, s21
    s.addi       s31, s34, #16
    s.add        s34, s3, s31
    v.st.b       [s29, #0], v6
    s.addi       s29, s26, #304
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s33, #0]
    v.extract    s31, v22, #11
    s.add        s33, s31, s21
    s.addi       s31, s33, #16
    s.add        s33, s3, s31
    v.st.b       [s24, #0], v6
    s.addi       s24, s26, #336
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s36, #0]
    v.extract    s31, v22, #12
    s.add        s36, s31, s21
    s.addi       s31, s36, #16
    s.add        s36, s3, s31
    v.st.b       [s27, #0], v6
    s.addi       s27, s26, #368
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s35, #0]
    v.extract    s31, v22, #13
    s.add        s35, s31, s21
    s.addi       s31, s35, #16
    s.add        s35, s3, s31
    v.st.b       [s29, #0], v6
    s.addi       s29, s26, #400
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s34, #0]
    v.extract    s31, v22, #14
    s.add        s34, s31, s21
    s.addi       s31, s34, #16
    s.add        s34, s3, s31
    v.st.b       [s24, #0], v6
    s.addi       s24, s26, #432
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s33, #0]
    v.extract    s31, v22, #15
    s.add        s33, s31, s21
    s.addi       s31, s33, #16
    s.add        s33, s3, s31
    v.st.b       [s27, #0], v6
    s.addi       s27, s26, #464
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s36, #0]
    s.addi       s31, s26, #496
    v.st.b       [s29, #0], v6
    s.addi       s29, s26, #64
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s35, #0]
    s.addi       s35, s26, #128
    v.st.b       [s24, #0], v6
    s.addi       s24, s26, #192
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s34, #0]
    s.addi       s34, s26, #256
    v.st.b       [s27, #0], v6
    s.addi       s27, s26, #320
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s33, #0]
    s.addi       s33, s26, #384
    v.st.b       [s31, #0], v6
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    s.addi       s31, s26, #448
    v.ld.w       v6, [s26, #0]
    v.extract    s26, v7, #2
    v.mov        v56, v6                         // hand off through the shared window (sec 7.3)
    v.ld.w       v6, [s29, #0]
    v.mov        v57, v6                         // hand off through the shared window (sec 7.3)
    v.ld.w       v6, [s35, #0]
    v.mov        v58, v6                         // hand off through the shared window (sec 7.3)
    v.ld.w       v6, [s24, #0]
    v.mov        v59, v6                         // hand off through the shared window (sec 7.3)
    v.ld.w       v6, [s34, #0]
    v.mov        v60, v6                         // hand off through the shared window (sec 7.3)
    v.ld.w       v6, [s27, #0]
    v.mov        v61, v6                         // hand off through the shared window (sec 7.3)
    v.ld.w       v6, [s33, #0]
    v.mov        v62, v6                         // hand off through the shared window (sec 7.3)
    v.ld.w       v6, [s31, #0]
    v.mov        v63, v6                         // hand off through the shared window (sec 7.3)
    mb.wait      s23
    mb.arm       s24, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a4, v56, v40, s24
    mb.wait      s24
    w.def        w3, #40, #8                     // v40..v47
    br.nz        s26, x8dot_done_9
    s.movz       s27, #0
    s.add        s29, s5, s22
    s.addi       s31, s27, #0
    s.addi       s27, s32, #256
x8dot_row_10:
    s.addi       s33, s30, #0
    v.movi       v6, #0
    s.sub        s34, s33, s31
    s.add        s33, s29, s31
    v.splat      v21, s34
    s.shli       s34, s31, #4
    s.addi       s35, s31, #1
    v.cmp.gt     p1, v21, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v6, [s33, v18]             // index is in elements (ISA sec 9.1)
    s.add        s33, s27, s34
    s.movz       s34, #32
    v.st.b       [s33, #0], v6
    fence.acq_rel.device
    s.mov        s31, s35
    s.cmp.lt     s33, s31, s34
    br.nz        s33, x8dot_row_10
x8dot_done_9:
    v.splat      v6, s26
    v.movi       v21, #0
    mb.arm       s26, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s27, #0
    v.extract    s29, v9, #2
    v.cmp.ne     p1, v6, v21
    v.cmp.eq     p2, v6, v21
    s.mov        s33, s27                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s27                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w3, d1, s33, s26            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s33, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s27                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w3, d0, s33, s26          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s25
    mb.arm       s29, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s31, v7, #3
    m.mma.dp.async.k32.e4m3 a5, v56, v48, s29
    mb.wait      s29
    w.def        w4, #48, #8                     // v48..v55
    br.nz        s31, x8dot_done_11
    s.addi       s33, s27, #0
    s.add        s34, s5, s22
    s.addi       s35, s32, #256
x8dot_row_12:
    s.addi       s36, s30, #0
    v.movi       v6, #0
    s.sub        s37, s36, s33
    s.add        s36, s34, s33
    v.splat      v21, s37
    s.shli       s37, s33, #4
    s.addi       s38, s33, #1
    v.cmp.gt     p1, v21, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v6, [s36, v10]             // index is in elements (ISA sec 9.1)
    s.add        s36, s35, s37
    s.movz       s37, #32
    v.st.b       [s36, #0], v6
    fence.acq_rel.device
    s.mov        s33, s38
    s.cmp.lt     s36, s33, s37
    br.nz        s36, x8dot_row_12
x8dot_done_11:
    v.splat      v6, s31
    v.movi       v21, #0
    mb.arm       s31, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s33, v9, #3
    v.cmp.ne     p1, v6, v21
    v.cmp.eq     p2, v6, v21
    s.mov        s34, s27                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s27                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w4, d1, s34, s31            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s34, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s27                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w4, d0, s34, s31          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s26
    mb.arm       s33, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s34, v7, #0
    m.mma.dp.async.k32.e4m3 a6, v56, v40, s33
    mb.wait      s33
    w.def        w5, #40, #8                     // v40..v47
    br.nz        s34, x8dot_done_13
    s.add        s35, s5, s22
    s.addi       s36, s27, #0
    s.addi       s27, s35, #32
    s.addi       s35, s32, #256
x8dot_row_14:
    s.addi       s37, s30, #-32
    v.movi       v6, #0
    s.sub        s38, s37, s36
    s.add        s37, s27, s36
    v.splat      v21, s38
    s.shli       s38, s36, #4
    s.addi       s39, s36, #1
    v.cmp.gt     p1, v21, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v6, [s37, v13]             // index is in elements (ISA sec 9.1)
    s.add        s37, s35, s38
    s.movz       s38, #32
    v.st.b       [s37, #0], v6
    fence.acq_rel.device
    s.mov        s36, s39
    s.cmp.lt     s37, s36, s38
    br.nz        s37, x8dot_row_14
x8dot_done_13:
    v.splat      v6, s34
    v.movi       v21, #0
    mb.arm       s27, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s34, #0
    v.extract    s35, v9, #0
    s.movz       s36, #32
    v.cmp.ne     p1, v6, v21
    v.cmp.eq     p2, v6, v21
    s.mov        s37, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w5, d1, s37, s27            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s37, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w5, d0, s37, s27          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s31
    mb.arm       s35, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s37, v7, #1
    m.mma.dp.async.k32.e4m3 a7, v56, v48, s35
    mb.wait      s35
    w.def        w6, #48, #8                     // v48..v55
    br.nz        s37, x8dot_done_15
    s.add        s38, s5, s22
    s.addi       s39, s34, #0
    s.addi       s40, s38, #32
    s.addi       s38, s32, #256
x8dot_row_16:
    s.addi       s41, s30, #-32
    v.movi       v6, #0
    s.sub        s42, s41, s39
    s.add        s41, s40, s39
    v.splat      v21, s42
    s.shli       s42, s39, #4
    s.addi       s43, s39, #1
    v.cmp.gt     p1, v21, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v6, [s41, v17]             // index is in elements (ISA sec 9.1)
    s.add        s41, s38, s42
    v.st.b       [s41, #0], v6
    fence.acq_rel.device
    s.mov        s39, s43
    s.cmp.lt     s41, s39, s36
    br.nz        s41, x8dot_row_16
x8dot_done_15:
    s.add        s38, s34, s12                   // the tile origin
    v.extract    s39, v22, #0
    v.splat      v6, s38
    s.add        s38, s39, s21
    s.add        s39, s34, s28                   // the tile origin
    v.splat      v21, s37
    v.movi       v24, #0
    s.addi       s37, s38, #32
    v.add        v25, v23, v6
    v.splat      v6, s39
    mb.arm       s38, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s39, v9, #1
    s.add        s40, s3, s37
    v.cmp.ne     p1, v21, v24
    v.cmp.eq     p2, v21, v24
    v.cmp.lt     p3, v25, v6
    s.mov        s41, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w6, d1, s41, s38            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s41, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w6, d0, s41, s38          // predicated off still completes once (ISA sec 9A.3)
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s40, #0]
    v.extract    s34, v22, #1
    s.addi       s36, s32, #1536                 // 512 bytes of repack scratch
    s.add        s37, s34, s21
    s.addi       s34, s36, #0
    s.addi       s39, s37, #32
    v.extract    s37, v22, #2
    s.add        s40, s3, s39
    s.add        s39, s37, s21
    s.addi       s37, s36, #32
    s.addi       s41, s39, #32
    v.extract    s39, v22, #3
    v.st.b       [s34, #0], v6
    s.add        s34, s3, s41
    s.add        s41, s39, s21
    s.addi       s39, s36, #64
    s.addi       s42, s41, #32
    v.extract    s41, v22, #4
    s.add        s43, s3, s42
    s.add        s42, s41, s21
    s.addi       s41, s36, #96
    s.addi       s44, s42, #32
    s.add        s42, s3, s44
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s40, #0]
    v.extract    s40, v22, #5
    s.add        s44, s40, s21
    s.addi       s40, s44, #32
    s.add        s44, s3, s40
    v.st.b       [s37, #0], v6
    s.addi       s37, s36, #128
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s34, #0]
    v.extract    s34, v22, #6
    s.add        s40, s34, s21
    s.addi       s34, s40, #32
    s.add        s40, s3, s34
    v.st.b       [s39, #0], v6
    s.addi       s34, s36, #160
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s43, #0]
    v.extract    s39, v22, #7
    s.add        s43, s39, s21
    s.addi       s39, s43, #32
    s.add        s43, s3, s39
    v.st.b       [s41, #0], v6
    s.addi       s39, s36, #192
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s42, #0]
    v.extract    s41, v22, #8
    s.add        s42, s41, s21
    s.addi       s41, s42, #32
    s.add        s42, s3, s41
    v.st.b       [s37, #0], v6
    s.addi       s37, s36, #224
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s44, #0]
    v.extract    s41, v22, #9
    s.add        s44, s41, s21
    s.addi       s41, s44, #32
    s.add        s44, s3, s41
    v.st.b       [s34, #0], v6
    s.addi       s34, s36, #256
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s40, #0]
    v.extract    s40, v22, #10
    s.add        s41, s40, s21
    s.addi       s40, s41, #32
    s.add        s41, s3, s40
    v.st.b       [s39, #0], v6
    s.addi       s39, s36, #288
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s43, #0]
    v.extract    s40, v22, #11
    s.add        s43, s40, s21
    s.addi       s40, s43, #32
    s.add        s43, s3, s40
    v.st.b       [s37, #0], v6
    s.addi       s37, s36, #320
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s42, #0]
    v.extract    s40, v22, #12
    s.add        s42, s40, s21
    s.addi       s40, s42, #32
    s.add        s42, s3, s40
    v.st.b       [s34, #0], v6
    s.addi       s34, s36, #352
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s44, #0]
    v.extract    s40, v22, #13
    s.add        s44, s40, s21
    s.addi       s40, s44, #32
    s.add        s44, s3, s40
    v.st.b       [s39, #0], v6
    s.addi       s39, s36, #384
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s41, #0]
    v.extract    s40, v22, #14
    s.add        s41, s40, s21
    s.addi       s40, s41, #32
    s.add        s41, s3, s40
    v.st.b       [s37, #0], v6
    s.addi       s37, s36, #416
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s43, #0]
    v.extract    s40, v22, #15
    s.add        s43, s40, s21
    s.addi       s40, s43, #32
    s.add        s43, s3, s40
    v.st.b       [s34, #0], v6
    s.addi       s34, s36, #448
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s42, #0]
    s.movz       s40, #0
    v.st.b       [s39, #0], v6
    s.add        s39, s40, s13                   // the tile origin
    s.add        s42, s40, s28                   // the tile origin
    v.splat      v6, s39
    v.extract    s39, v22, #0
    v.splat      v21, s42
    s.add        s40, s39, s21
    v.add        v24, v23, v6
    s.addi       s39, s40, #48
    s.addi       s40, s36, #480
    s.add        s42, s3, s39
    v.cmp.lt     p1, v24, v21
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s44, #0]
    v.extract    s39, v22, #1
    s.add        s44, s39, s21
    s.addi       s39, s44, #48
    s.add        s44, s3, s39
    v.st.b       [s37, #0], v6
    s.addi       s37, s36, #16
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s41, #0]
    v.extract    s39, v22, #2
    s.add        s41, s39, s21
    s.addi       s39, s41, #48
    s.add        s41, s3, s39
    v.st.b       [s34, #0], v6
    s.addi       s34, s36, #48
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s43, #0]
    v.extract    s39, v22, #3
    s.add        s43, s39, s21
    s.addi       s39, s43, #48
    s.add        s43, s3, s39
    v.st.b       [s40, #0], v6
    s.addi       s39, s36, #80
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s42, #0]
    v.extract    s40, v22, #4
    s.add        s42, s40, s21
    s.addi       s40, s42, #48
    s.add        s42, s3, s40
    v.st.b       [s37, #0], v6
    s.addi       s37, s36, #112
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s44, #0]
    v.extract    s40, v22, #5
    s.add        s44, s40, s21
    s.addi       s40, s44, #48
    s.add        s44, s3, s40
    v.st.b       [s34, #0], v6
    s.addi       s34, s36, #144
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s41, #0]
    v.extract    s40, v22, #6
    s.add        s41, s40, s21
    s.addi       s40, s41, #48
    s.add        s41, s3, s40
    v.st.b       [s39, #0], v6
    s.addi       s39, s36, #176
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s43, #0]
    v.extract    s40, v22, #7
    s.add        s43, s40, s21
    s.addi       s40, s43, #48
    s.add        s43, s3, s40
    v.st.b       [s37, #0], v6
    s.addi       s37, s36, #208
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s42, #0]
    v.extract    s40, v22, #8
    s.add        s42, s40, s21
    s.addi       s40, s42, #48
    s.add        s42, s3, s40
    v.st.b       [s34, #0], v6
    s.addi       s34, s36, #240
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s44, #0]
    v.extract    s40, v22, #9
    s.add        s44, s40, s21
    s.addi       s40, s44, #48
    s.add        s44, s3, s40
    v.st.b       [s39, #0], v6
    s.addi       s39, s36, #272
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s41, #0]
    v.extract    s40, v22, #10
    s.add        s41, s40, s21
    s.addi       s40, s41, #48
    s.add        s41, s3, s40
    v.st.b       [s37, #0], v6
    s.addi       s37, s36, #304
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s43, #0]
    v.extract    s40, v22, #11
    s.add        s43, s40, s21
    s.addi       s40, s43, #48
    s.add        s43, s3, s40
    v.st.b       [s34, #0], v6
    s.addi       s34, s36, #336
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s42, #0]
    v.extract    s40, v22, #12
    s.add        s42, s40, s21
    s.addi       s40, s42, #48
    s.add        s42, s3, s40
    v.st.b       [s39, #0], v6
    s.addi       s39, s36, #368
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s44, #0]
    v.extract    s40, v22, #13
    s.add        s44, s40, s21
    s.addi       s40, s44, #48
    s.add        s44, s3, s40
    v.st.b       [s37, #0], v6
    s.addi       s37, s36, #400
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s41, #0]
    v.extract    s40, v22, #14
    s.add        s41, s40, s21
    s.addi       s40, s41, #48
    s.add        s41, s3, s40
    v.st.b       [s34, #0], v6
    s.addi       s34, s36, #432
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s43, #0]
    v.extract    s40, v22, #15
    s.add        s43, s40, s21
    s.addi       s40, s43, #48
    s.add        s43, s3, s40
    v.st.b       [s39, #0], v6
    s.addi       s39, s36, #464
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s42, #0]
    s.addi       s40, s36, #496
    v.st.b       [s37, #0], v6
    s.addi       s37, s36, #64
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s44, #0]
    s.addi       s42, s36, #128
    v.st.b       [s34, #0], v6
    s.addi       s34, s36, #192
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s41, #0]
    s.addi       s41, s36, #256
    v.st.b       [s39, #0], v6
    s.addi       s39, s36, #320
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s43, #0]
    s.addi       s43, s36, #384
    v.st.b       [s40, #0], v6
    fence.acq_rel.device
    w.def        w7, #56, #8                     // v56..v63
    s.addi       s40, s36, #448
    v.ld.w       v6, [s36, #0]
    v.extract    s36, v7, #2
    v.mov        v56, v6                         // hand off through the shared window (sec 7.3)
    v.ld.w       v6, [s37, #0]
    v.mov        v57, v6                         // hand off through the shared window (sec 7.3)
    v.ld.w       v6, [s42, #0]
    v.mov        v58, v6                         // hand off through the shared window (sec 7.3)
    v.ld.w       v6, [s34, #0]
    v.mov        v59, v6                         // hand off through the shared window (sec 7.3)
    v.ld.w       v6, [s41, #0]
    v.mov        v60, v6                         // hand off through the shared window (sec 7.3)
    v.ld.w       v6, [s39, #0]
    v.mov        v61, v6                         // hand off through the shared window (sec 7.3)
    v.ld.w       v6, [s43, #0]
    v.mov        v62, v6                         // hand off through the shared window (sec 7.3)
    v.ld.w       v6, [s40, #0]
    v.mov        v63, v6                         // hand off through the shared window (sec 7.3)
    mb.wait      s27
    mb.arm       s34, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a4, v56, v40, s34
    mb.wait      s34
    w.def        w8, #40, #8                     // v40..v47
    br.nz        s36, x8dot_done_17
    s.movz       s37, #0
    s.add        s39, s5, s22
    s.addi       s40, s37, #0
    s.addi       s37, s39, #32
    s.addi       s39, s32, #256
x8dot_row_18:
    s.addi       s41, s30, #-32
    v.movi       v6, #0
    s.sub        s42, s41, s40
    s.add        s41, s37, s40
    v.splat      v21, s42
    s.shli       s42, s40, #4
    s.addi       s43, s40, #1
    v.cmp.gt     p1, v21, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v6, [s41, v18]             // index is in elements (ISA sec 9.1)
    s.add        s41, s39, s42
    s.movz       s42, #32
    v.st.b       [s41, #0], v6
    fence.acq_rel.device
    s.mov        s40, s43
    s.cmp.lt     s41, s40, s42
    br.nz        s41, x8dot_row_18
x8dot_done_17:
    v.splat      v6, s36
    v.movi       v21, #0
    mb.arm       s36, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s37, #0
    v.extract    s39, v9, #2
    s.movz       s40, #32
    v.cmp.ne     p1, v6, v21
    v.cmp.eq     p2, v6, v21
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w8, d1, s41, s36            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s41, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w8, d0, s41, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s38
    mb.arm       s39, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s41, v7, #3
    m.mma.dp.async.k32.e4m3 a5, v56, v48, s39
    mb.wait      s39
    w.def        w9, #48, #8                     // v48..v55
    br.nz        s41, x8dot_done_19
    s.add        s42, s5, s22
    s.addi       s43, s37, #0
    s.addi       s44, s42, #32
    s.addi       s42, s32, #256
x8dot_row_20:
    s.addi       s45, s30, #-32
    v.movi       v6, #0
    s.sub        s46, s45, s43
    s.add        s45, s44, s43
    v.splat      v21, s46
    s.shli       s46, s43, #4
    s.addi       s47, s43, #1
    v.cmp.gt     p1, v21, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v6, [s45, v10]             // index is in elements (ISA sec 9.1)
    s.add        s45, s42, s46
    v.st.b       [s45, #0], v6
    fence.acq_rel.device
    s.mov        s43, s47
    s.cmp.lt     s45, s43, s40
    br.nz        s45, x8dot_row_20
x8dot_done_19:
    v.splat      v6, s41
    v.movi       v21, #0
    mb.arm       s41, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s42, v9, #3
    v.cmp.ne     p1, v6, v21
    v.cmp.eq     p2, v6, v21
    s.mov        s43, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w9, d1, s43, s41            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w9, d0, s43, s41          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    mb.arm       s40, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s42, v7, #0
    m.mma.dp.async.k32.e4m3 a6, v56, v40, s40
    mb.wait      s40
    w.def        w10, #40, #8                    // v40..v47
    br.nz        s42, x8dot_done_21
    s.add        s43, s5, s22
    s.addi       s44, s37, #0
    s.addi       s37, s43, #64
    s.addi       s43, s32, #256
x8dot_row_22:
    s.addi       s45, s30, #-64
    v.movi       v6, #0
    s.sub        s46, s45, s44
    s.add        s45, s37, s44
    v.splat      v21, s46
    s.shli       s46, s44, #4
    s.addi       s47, s44, #1
    v.cmp.gt     p1, v21, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v6, [s45, v13]             // index is in elements (ISA sec 9.1)
    s.add        s45, s43, s46
    s.movz       s46, #32
    v.st.b       [s45, #0], v6
    fence.acq_rel.device
    s.mov        s44, s47
    s.cmp.lt     s45, s44, s46
    br.nz        s45, x8dot_row_22
x8dot_done_21:
    v.splat      v6, s42
    v.movi       v21, #0
    mb.arm       s37, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s42, #0
    v.extract    s43, v9, #0
    s.movz       s44, #64
    v.cmp.ne     p1, v6, v21
    v.cmp.eq     p2, v6, v21
    s.mov        s45, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w10, d1, s45, s37           // predicated off still completes once (ISA sec 9A.3)
    s.mov        s45, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w10, d0, s45, s37         // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s41
    mb.arm       s43, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s45, v7, #1
    m.mma.dp.async.k32.e4m3 a7, v56, v48, s43
    mb.wait      s43
    w.def        w11, #48, #8                    // v48..v55
    br.nz        s45, x8dot_done_23
    s.add        s46, s5, s22
    s.addi       s47, s42, #0
    s.addi       s48, s46, #64
    s.addi       s46, s32, #256
x8dot_row_24:
    s.addi       s49, s30, #-64
    v.movi       v6, #0
    s.sub        s50, s49, s47
    s.add        s49, s48, s47
    v.splat      v21, s50
    s.shli       s50, s47, #4
    s.addi       s51, s47, #1
    v.cmp.gt     p1, v21, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v6, [s49, v17]             // index is in elements (ISA sec 9.1)
    s.add        s49, s46, s50
    s.movz       s50, #32
    v.st.b       [s49, #0], v6
    fence.acq_rel.device
    s.mov        s47, s51
    s.cmp.lt     s49, s47, s50
    br.nz        s49, x8dot_row_24
x8dot_done_23:
    s.add        s46, s42, s9                    // the tile origin
    v.extract    s47, v22, #0
    v.splat      v6, s46
    s.add        s46, s47, s21
    s.add        s47, s42, s28                   // the tile origin
    v.splat      v21, s45
    v.movi       v24, #0
    s.addi       s45, s46, #64
    v.add        v25, v23, v6
    v.splat      v6, s47
    mb.arm       s46, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s47, v9, #1
    s.add        s48, s3, s45
    v.cmp.ne     p1, v21, v24
    v.cmp.eq     p2, v21, v24
    v.cmp.lt     p3, v25, v6
    s.mov        s49, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w11, d1, s49, s46           // predicated off still completes once (ISA sec 9A.3)
    s.mov        s49, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w11, d0, s49, s46         // predicated off still completes once (ISA sec 9A.3)
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s48, #0]
    v.extract    s42, v22, #1
    s.addi       s44, s32, #2048                 // 512 bytes of repack scratch
    s.add        s45, s42, s21
    s.addi       s42, s44, #0
    s.addi       s47, s45, #64
    v.extract    s45, v22, #2
    s.add        s48, s3, s47
    s.add        s47, s45, s21
    s.addi       s45, s44, #32
    s.addi       s49, s47, #64
    v.extract    s47, v22, #3
    v.st.b       [s42, #0], v6
    s.add        s42, s3, s49
    s.add        s49, s47, s21
    s.addi       s47, s44, #64
    s.addi       s50, s49, #64
    v.extract    s49, v22, #4
    s.add        s51, s3, s50
    s.add        s50, s49, s21
    s.addi       s49, s44, #96
    s.addi       s52, s50, #64
    s.add        s50, s3, s52
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s48, #0]
    v.extract    s48, v22, #5
    s.add        s52, s48, s21
    s.addi       s48, s52, #64
    s.add        s52, s3, s48
    v.st.b       [s45, #0], v6
    s.addi       s45, s44, #128
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s42, #0]
    v.extract    s42, v22, #6
    s.add        s48, s42, s21
    s.addi       s42, s48, #64
    s.add        s48, s3, s42
    v.st.b       [s47, #0], v6
    s.addi       s42, s44, #160
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s51, #0]
    v.extract    s47, v22, #7
    s.add        s51, s47, s21
    s.addi       s47, s51, #64
    s.add        s51, s3, s47
    v.st.b       [s49, #0], v6
    s.addi       s47, s44, #192
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s50, #0]
    v.extract    s49, v22, #8
    s.add        s50, s49, s21
    s.addi       s49, s50, #64
    s.add        s50, s3, s49
    v.st.b       [s45, #0], v6
    s.addi       s45, s44, #224
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s52, #0]
    v.extract    s49, v22, #9
    s.add        s52, s49, s21
    s.addi       s49, s52, #64
    s.add        s52, s3, s49
    v.st.b       [s42, #0], v6
    s.addi       s42, s44, #256
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s48, #0]
    v.extract    s48, v22, #10
    s.add        s49, s48, s21
    s.addi       s48, s49, #64
    s.add        s49, s3, s48
    v.st.b       [s47, #0], v6
    s.addi       s47, s44, #288
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s51, #0]
    v.extract    s48, v22, #11
    s.add        s51, s48, s21
    s.addi       s48, s51, #64
    s.add        s51, s3, s48
    v.st.b       [s45, #0], v6
    s.addi       s45, s44, #320
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s50, #0]
    v.extract    s48, v22, #12
    s.add        s50, s48, s21
    s.addi       s48, s50, #64
    s.add        s50, s3, s48
    v.st.b       [s42, #0], v6
    s.addi       s42, s44, #352
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s52, #0]
    v.extract    s48, v22, #13
    s.add        s52, s48, s21
    s.addi       s48, s52, #64
    s.add        s52, s3, s48
    v.st.b       [s47, #0], v6
    s.addi       s47, s44, #384
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s49, #0]
    v.extract    s48, v22, #14
    s.add        s49, s48, s21
    s.addi       s48, s49, #64
    s.add        s49, s3, s48
    v.st.b       [s45, #0], v6
    s.addi       s45, s44, #416
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s51, #0]
    v.extract    s48, v22, #15
    s.add        s51, s48, s21
    s.addi       s48, s51, #64
    s.add        s51, s3, s48
    v.st.b       [s42, #0], v6
    s.addi       s42, s44, #448
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s50, #0]
    s.movz       s48, #0
    v.st.b       [s47, #0], v6
    s.add        s47, s48, s14                   // the tile origin
    s.add        s50, s48, s28                   // the tile origin
    v.splat      v6, s47
    v.extract    s47, v22, #0
    v.splat      v21, s50
    s.add        s48, s47, s21
    v.add        v24, v23, v6
    s.addi       s47, s48, #80
    s.addi       s48, s44, #480
    s.add        s50, s3, s47
    v.cmp.lt     p1, v24, v21
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s52, #0]
    v.extract    s47, v22, #1
    s.add        s52, s47, s21
    s.addi       s47, s52, #80
    s.add        s52, s3, s47
    v.st.b       [s45, #0], v6
    s.addi       s45, s44, #16
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s49, #0]
    v.extract    s47, v22, #2
    s.add        s49, s47, s21
    s.addi       s47, s49, #80
    s.add        s49, s3, s47
    v.st.b       [s42, #0], v6
    s.addi       s42, s44, #48
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s51, #0]
    v.extract    s47, v22, #3
    s.add        s51, s47, s21
    s.addi       s47, s51, #80
    s.add        s51, s3, s47
    v.st.b       [s48, #0], v6
    s.addi       s47, s44, #80
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s50, #0]
    v.extract    s48, v22, #4
    s.add        s50, s48, s21
    s.addi       s48, s50, #80
    s.add        s50, s3, s48
    v.st.b       [s45, #0], v6
    s.addi       s45, s44, #112
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s52, #0]
    v.extract    s48, v22, #5
    s.add        s52, s48, s21
    s.addi       s48, s52, #80
    s.add        s52, s3, s48
    v.st.b       [s42, #0], v6
    s.addi       s42, s44, #144
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s49, #0]
    v.extract    s48, v22, #6
    s.add        s49, s48, s21
    s.addi       s48, s49, #80
    s.add        s49, s3, s48
    v.st.b       [s47, #0], v6
    s.addi       s47, s44, #176
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s51, #0]
    v.extract    s48, v22, #7
    s.add        s51, s48, s21
    s.addi       s48, s51, #80
    s.add        s51, s3, s48
    v.st.b       [s45, #0], v6
    s.addi       s45, s44, #208
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s50, #0]
    v.extract    s48, v22, #8
    s.add        s50, s48, s21
    s.addi       s48, s50, #80
    s.add        s50, s3, s48
    v.st.b       [s42, #0], v6
    s.addi       s42, s44, #240
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s52, #0]
    v.extract    s48, v22, #9
    s.add        s52, s48, s21
    s.addi       s48, s52, #80
    s.add        s52, s3, s48
    v.st.b       [s47, #0], v6
    s.addi       s47, s44, #272
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s49, #0]
    v.extract    s48, v22, #10
    s.add        s49, s48, s21
    s.addi       s48, s49, #80
    s.add        s49, s3, s48
    v.st.b       [s45, #0], v6
    s.addi       s45, s44, #304
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s51, #0]
    v.extract    s48, v22, #11
    s.add        s51, s48, s21
    s.addi       s48, s51, #80
    s.add        s51, s3, s48
    v.st.b       [s42, #0], v6
    s.addi       s42, s44, #336
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s50, #0]
    v.extract    s48, v22, #12
    s.add        s50, s48, s21
    s.addi       s48, s50, #80
    s.add        s50, s3, s48
    v.st.b       [s47, #0], v6
    s.addi       s47, s44, #368
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s52, #0]
    v.extract    s48, v22, #13
    s.add        s52, s48, s21
    s.addi       s48, s52, #80
    s.add        s52, s3, s48
    v.st.b       [s45, #0], v6
    s.addi       s45, s44, #400
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s49, #0]
    v.extract    s48, v22, #14
    s.add        s49, s48, s21
    s.addi       s48, s49, #80
    s.add        s49, s3, s48
    v.st.b       [s42, #0], v6
    s.addi       s42, s44, #432
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s51, #0]
    v.extract    s48, v22, #15
    s.add        s51, s48, s21
    s.addi       s48, s51, #80
    s.add        s51, s3, s48
    v.st.b       [s47, #0], v6
    s.addi       s47, s44, #464
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s50, #0]
    s.addi       s48, s44, #496
    v.st.b       [s45, #0], v6
    s.addi       s45, s44, #64
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s52, #0]
    s.addi       s50, s44, #128
    v.st.b       [s42, #0], v6
    s.addi       s42, s44, #192
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s49, #0]
    s.addi       s49, s44, #256
    v.st.b       [s47, #0], v6
    s.addi       s47, s44, #320
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s51, #0]
    s.addi       s51, s44, #384
    v.st.b       [s48, #0], v6
    fence.acq_rel.device
    w.def        w12, #56, #8                    // v56..v63
    s.addi       s48, s44, #448
    v.ld.w       v6, [s44, #0]
    v.extract    s44, v7, #2
    v.mov        v56, v6                         // hand off through the shared window (sec 7.3)
    v.ld.w       v6, [s45, #0]
    v.mov        v57, v6                         // hand off through the shared window (sec 7.3)
    v.ld.w       v6, [s50, #0]
    v.mov        v58, v6                         // hand off through the shared window (sec 7.3)
    v.ld.w       v6, [s42, #0]
    v.mov        v59, v6                         // hand off through the shared window (sec 7.3)
    v.ld.w       v6, [s49, #0]
    v.mov        v60, v6                         // hand off through the shared window (sec 7.3)
    v.ld.w       v6, [s47, #0]
    v.mov        v61, v6                         // hand off through the shared window (sec 7.3)
    v.ld.w       v6, [s51, #0]
    v.mov        v62, v6                         // hand off through the shared window (sec 7.3)
    v.ld.w       v6, [s48, #0]
    v.mov        v63, v6                         // hand off through the shared window (sec 7.3)
    mb.wait      s37
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a4, v56, v40, s42
    mb.wait      s42
    w.def        w13, #40, #8                    // v40..v47
    br.nz        s44, x8dot_done_25
    s.movz       s45, #0
    s.add        s47, s5, s22
    s.addi       s48, s45, #0
    s.addi       s45, s47, #64
    s.addi       s47, s32, #256
x8dot_row_26:
    s.addi       s49, s30, #-64
    v.movi       v6, #0
    s.sub        s50, s49, s48
    s.add        s49, s45, s48
    v.splat      v21, s50
    s.shli       s50, s48, #4
    s.addi       s51, s48, #1
    v.cmp.gt     p1, v21, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v6, [s49, v18]             // index is in elements (ISA sec 9.1)
    s.add        s49, s47, s50
    s.movz       s50, #32
    v.st.b       [s49, #0], v6
    fence.acq_rel.device
    s.mov        s48, s51
    s.cmp.lt     s49, s48, s50
    br.nz        s49, x8dot_row_26
x8dot_done_25:
    v.splat      v6, s44
    v.movi       v21, #0
    mb.arm       s44, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s45, #0
    v.extract    s47, v9, #2
    s.movz       s48, #64
    v.cmp.ne     p1, v6, v21
    v.cmp.eq     p2, v6, v21
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w13, d1, s49, s44           // predicated off still completes once (ISA sec 9A.3)
    s.mov        s49, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w13, d0, s49, s44         // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s46
    mb.arm       s47, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s49, v7, #3
    m.mma.dp.async.k32.e4m3 a5, v56, v48, s47
    mb.wait      s47
    w.def        w14, #48, #8                    // v48..v55
    br.nz        s49, x8dot_done_27
    s.add        s50, s5, s22
    s.addi       s51, s45, #0
    s.addi       s52, s50, #64
    s.addi       s50, s32, #256
x8dot_row_28:
    s.addi       s53, s30, #-64
    v.movi       v6, #0
    s.sub        s54, s53, s51
    s.add        s53, s52, s51
    v.splat      v21, s54
    s.shli       s54, s51, #4
    s.addi       s55, s51, #1
    v.cmp.gt     p1, v21, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v6, [s53, v10]             // index is in elements (ISA sec 9.1)
    s.add        s53, s50, s54
    s.movz       s54, #32
    v.st.b       [s53, #0], v6
    fence.acq_rel.device
    s.mov        s51, s55
    s.cmp.lt     s53, s51, s54
    br.nz        s53, x8dot_row_28
x8dot_done_27:
    v.splat      v6, s49
    v.movi       v21, #0
    mb.arm       s49, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s50, v9, #3
    v.cmp.ne     p1, v6, v21
    v.cmp.eq     p2, v6, v21
    s.mov        s51, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w14, d1, s51, s49           // predicated off still completes once (ISA sec 9A.3)
    s.mov        s51, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w14, d0, s51, s49         // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s44
    mb.arm       s48, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s50, v7, #0
    m.mma.dp.async.k32.e4m3 a6, v56, v40, s48
    mb.wait      s48
    w.def        w15, #40, #8                    // v40..v47
    br.nz        s50, x8dot_done_29
    s.add        s51, s5, s22
    s.addi       s52, s45, #0
    s.addi       s45, s51, #96
    s.addi       s51, s32, #256
x8dot_row_30:
    s.addi       s53, s30, #-96
    v.movi       v6, #0
    s.sub        s54, s53, s52
    s.add        s53, s45, s52
    v.splat      v21, s54
    s.shli       s54, s52, #4
    s.addi       s55, s52, #1
    v.cmp.gt     p1, v21, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v6, [s53, v13]             // index is in elements (ISA sec 9.1)
    s.add        s53, s51, s54
    s.movz       s54, #32
    v.st.b       [s53, #0], v6
    fence.acq_rel.device
    s.mov        s52, s55
    s.cmp.lt     s53, s52, s54
    br.nz        s53, x8dot_row_30
x8dot_done_29:
    v.splat      v6, s50
    v.movi       v13, #0
    mb.arm       s45, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s50, #0
    v.extract    s51, v9, #0
    s.movz       s52, #96
    v.cmp.ne     p1, v6, v13
    v.cmp.eq     p2, v6, v13
    s.mov        s53, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w15, d1, s53, s45           // predicated off still completes once (ISA sec 9A.3)
    s.mov        s53, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w15, d0, s53, s45         // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s49
    mb.arm       s51, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s53, v7, #1
    m.mma.dp.async.k32.e4m3 a7, v56, v48, s51
    mb.wait      s51
    w.def        w16, #48, #8                    // v48..v55
    br.nz        s53, x8dot_done_31
    s.add        s54, s5, s22
    s.addi       s55, s50, #0
    s.addi       s56, s54, #96
    s.addi       s54, s32, #256
x8dot_row_32:
    s.addi       s57, s30, #-96
    v.movi       v6, #0
    s.sub        s58, s57, s55
    s.add        s57, s56, s55
    v.splat      v13, s58
    s.shli       s58, s55, #4
    s.addi       s59, s55, #1
    v.cmp.gt     p1, v13, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v6, [s57, v17]             // index is in elements (ISA sec 9.1)
    s.add        s57, s54, s58
    s.movz       s58, #32
    v.st.b       [s57, #0], v6
    fence.acq_rel.device
    s.mov        s55, s59
    s.cmp.lt     s57, s55, s58
    br.nz        s57, x8dot_row_32
x8dot_done_31:
    s.add        s54, s50, s15                   // the tile origin
    v.extract    s55, v22, #0
    v.splat      v6, s54
    s.add        s54, s55, s21
    s.add        s55, s50, s28                   // the tile origin
    v.splat      v13, s53
    v.movi       v17, #0
    s.addi       s53, s54, #96
    v.add        v21, v23, v6
    v.splat      v6, s55
    mb.arm       s54, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s55, v9, #1
    s.add        s56, s3, s53
    v.cmp.ne     p1, v13, v17
    v.cmp.eq     p2, v13, v17
    v.cmp.lt     p3, v21, v6
    s.mov        s57, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w16, d1, s57, s54           // predicated off still completes once (ISA sec 9A.3)
    s.mov        s57, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w16, d0, s57, s54         // predicated off still completes once (ISA sec 9A.3)
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s56, #0]
    v.extract    s50, v22, #1
    s.addi       s52, s32, #2560                 // 512 bytes of repack scratch
    s.add        s53, s50, s21
    s.addi       s50, s52, #0
    s.addi       s55, s53, #96
    v.extract    s53, v22, #2
    s.add        s56, s3, s55
    s.add        s55, s53, s21
    s.addi       s53, s52, #32
    s.addi       s57, s55, #96
    v.extract    s55, v22, #3
    v.st.b       [s50, #0], v6
    s.add        s50, s3, s57
    s.add        s57, s55, s21
    s.addi       s55, s52, #64
    s.addi       s58, s57, #96
    v.extract    s57, v22, #4
    s.add        s59, s3, s58
    s.add        s58, s57, s21
    s.addi       s57, s52, #96
    s.addi       s60, s58, #96
    s.add        s58, s3, s60
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s56, #0]
    v.extract    s56, v22, #5
    s.add        s60, s56, s21
    s.addi       s56, s60, #96
    s.add        s60, s3, s56
    v.st.b       [s53, #0], v6
    s.addi       s53, s52, #128
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s50, #0]
    v.extract    s50, v22, #6
    s.add        s56, s50, s21
    s.addi       s50, s56, #96
    s.add        s56, s3, s50
    v.st.b       [s55, #0], v6
    s.addi       s50, s52, #160
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s59, #0]
    v.extract    s55, v22, #7
    s.add        s59, s55, s21
    s.addi       s55, s59, #96
    s.add        s59, s3, s55
    v.st.b       [s57, #0], v6
    s.addi       s55, s52, #192
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s58, #0]
    v.extract    s57, v22, #8
    s.add        s58, s57, s21
    s.addi       s57, s58, #96
    s.add        s58, s3, s57
    v.st.b       [s53, #0], v6
    s.addi       s53, s52, #224
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s60, #0]
    v.extract    s57, v22, #9
    s.add        s60, s57, s21
    s.addi       s57, s60, #96
    s.add        s60, s3, s57
    v.st.b       [s50, #0], v6
    s.addi       s50, s52, #256
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s56, #0]
    v.extract    s56, v22, #10
    s.add        s57, s56, s21
    s.addi       s56, s57, #96
    s.add        s57, s3, s56
    v.st.b       [s55, #0], v6
    s.addi       s55, s52, #288
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s59, #0]
    v.extract    s56, v22, #11
    s.add        s59, s56, s21
    s.addi       s56, s59, #96
    s.add        s59, s3, s56
    v.st.b       [s53, #0], v6
    s.addi       s53, s52, #320
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s58, #0]
    v.extract    s56, v22, #12
    s.add        s58, s56, s21
    s.addi       s56, s58, #96
    s.add        s58, s3, s56
    v.st.b       [s50, #0], v6
    s.addi       s50, s52, #352
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s60, #0]
    v.extract    s56, v22, #13
    s.add        s60, s56, s21
    s.addi       s56, s60, #96
    s.add        s60, s3, s56
    v.st.b       [s55, #0], v6
    s.addi       s55, s52, #384
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s57, #0]
    v.extract    s56, v22, #14
    s.add        s57, s56, s21
    s.addi       s56, s57, #96
    s.add        s57, s3, s56
    v.st.b       [s53, #0], v6
    s.addi       s53, s52, #416
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s59, #0]
    v.extract    s56, v22, #15
    s.add        s59, s56, s21
    s.addi       s56, s59, #96
    s.add        s59, s3, s56
    v.st.b       [s50, #0], v6
    s.addi       s50, s52, #448
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s58, #0]
    s.movz       s56, #0
    s.add        s58, s56, s28                   // the tile origin
    s.add        s28, s56, s16                   // the tile origin
    v.splat      v13, s58
    v.extract    s56, v22, #0
    v.splat      v17, s28
    s.add        s28, s56, s21
    s.addi       s56, s52, #480
    s.addi       s58, s28, #112
    v.add        v21, v23, v17
    v.st.b       [s55, #0], v6
    s.add        s28, s3, s58
    v.cmp.lt     p1, v21, v13
    v.extract    s55, v22, #1
    s.add        s58, s55, s21
    s.addi       s55, s58, #112
    s.add        s58, s3, s55
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s60, #0]
    s.addi       s55, s52, #16
    v.st.b       [s53, #0], v6
    v.extract    s53, v22, #2
    s.add        s60, s53, s21
    s.addi       s53, s60, #112
    s.add        s60, s3, s53
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s57, #0]
    s.addi       s53, s52, #48
    v.st.b       [s50, #0], v6
    v.extract    s50, v22, #3
    s.add        s57, s50, s21
    s.addi       s50, s57, #112
    s.add        s57, s3, s50
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v6, [s59, #0]
    s.addi       s50, s52, #80
    v.st.b       [s56, #0], v6
    v.extract    s56, v22, #4
    s.add        s59, s56, s21
    s.addi       s56, s59, #112
    s.add        s59, s3, s56
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s28, #0]
    s.addi       s28, s52, #112
    v.st.b       [s55, #0], v6
    v.extract    s55, v22, #5
    s.add        s56, s55, s21
    s.addi       s55, s56, #112
    s.add        s56, s3, s55
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s58, #0]
    s.addi       s55, s52, #144
    v.st.b       [s53, #0], v6
    v.extract    s53, v22, #6
    s.add        s58, s53, s21
    s.addi       s53, s58, #112
    s.add        s58, s3, s53
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s60, #0]
    s.addi       s53, s52, #176
    v.st.b       [s50, #0], v6
    v.extract    s50, v22, #7
    s.add        s60, s50, s21
    s.addi       s50, s60, #112
    s.add        s60, s3, s50
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s57, #0]
    s.addi       s50, s52, #208
    v.st.b       [s28, #0], v6
    v.extract    s28, v22, #8
    s.add        s57, s28, s21
    s.addi       s28, s57, #112
    s.add        s57, s3, s28
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s59, #0]
    s.addi       s28, s52, #240
    v.st.b       [s55, #0], v6
    v.extract    s55, v22, #9
    s.add        s59, s55, s21
    s.addi       s55, s59, #112
    s.add        s59, s3, s55
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s56, #0]
    s.addi       s55, s52, #272
    v.st.b       [s53, #0], v6
    v.extract    s53, v22, #10
    s.add        s56, s53, s21
    s.addi       s53, s56, #112
    s.add        s56, s3, s53
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s58, #0]
    s.addi       s53, s52, #304
    v.st.b       [s50, #0], v6
    v.extract    s50, v22, #11
    s.add        s58, s50, s21
    s.addi       s50, s58, #112
    s.add        s58, s3, s50
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s60, #0]
    s.addi       s50, s52, #336
    v.st.b       [s28, #0], v6
    v.extract    s28, v22, #12
    s.add        s60, s28, s21
    s.addi       s28, s60, #112
    s.add        s60, s3, s28
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s57, #0]
    s.addi       s28, s52, #368
    v.st.b       [s55, #0], v6
    v.extract    s55, v22, #13
    s.add        s57, s55, s21
    s.addi       s55, s57, #112
    s.add        s57, s3, s55
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s59, #0]
    s.addi       s55, s52, #400
    v.st.b       [s53, #0], v6
    v.extract    s53, v22, #14
    s.add        s59, s53, s21
    s.addi       s53, s59, #112
    s.add        s59, s3, s53
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s56, #0]
    s.addi       s53, s52, #432
    v.st.b       [s50, #0], v6
    v.extract    s50, v22, #15
    s.add        s56, s50, s21
    s.addi       s50, s56, #112
    s.add        s56, s3, s50
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s58, #0]
    s.addi       s50, s52, #464
    v.st.b       [s28, #0], v6
    s.addi       s28, s52, #496
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s60, #0]
    s.addi       s58, s52, #64
    v.st.b       [s55, #0], v6
    s.addi       s55, s52, #128
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s57, #0]
    s.addi       s57, s52, #192
    v.st.b       [s53, #0], v6
    s.addi       s53, s52, #256
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s59, #0]
    s.addi       s59, s52, #320
    v.st.b       [s50, #0], v6
    s.addi       s50, s52, #384
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v6, [s56, #0]
    s.addi       s56, s52, #448
    v.st.b       [s28, #0], v6
    fence.acq_rel.device
    w.def        w17, #56, #8                    // v56..v63
    v.extract    s28, v7, #2
    v.ld.w       v6, [s52, #0]
    v.mov        v56, v6                         // hand off through the shared window (sec 7.3)
    v.ld.w       v6, [s58, #0]
    v.mov        v57, v6                         // hand off through the shared window (sec 7.3)
    v.ld.w       v6, [s55, #0]
    v.mov        v58, v6                         // hand off through the shared window (sec 7.3)
    v.ld.w       v6, [s57, #0]
    v.mov        v59, v6                         // hand off through the shared window (sec 7.3)
    v.ld.w       v6, [s53, #0]
    v.mov        v60, v6                         // hand off through the shared window (sec 7.3)
    v.ld.w       v6, [s59, #0]
    v.mov        v61, v6                         // hand off through the shared window (sec 7.3)
    v.ld.w       v6, [s50, #0]
    v.mov        v62, v6                         // hand off through the shared window (sec 7.3)
    v.ld.w       v6, [s56, #0]
    v.mov        v63, v6                         // hand off through the shared window (sec 7.3)
    mb.wait      s45
    mb.arm       s50, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a4, v56, v40, s50
    mb.wait      s50
    w.def        w18, #40, #8                    // v40..v47
    br.nz        s28, x8dot_done_33
    s.movz       s52, #0
    s.add        s53, s5, s22
    s.addi       s55, s52, #0
    s.addi       s52, s53, #96
    s.addi       s53, s32, #256
x8dot_row_34:
    s.addi       s56, s30, #-96
    v.movi       v6, #0
    s.sub        s57, s56, s55
    s.add        s56, s52, s55
    v.splat      v13, s57
    s.shli       s57, s55, #4
    s.addi       s58, s55, #1
    v.cmp.gt     p1, v13, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v6, [s56, v18]             // index is in elements (ISA sec 9.1)
    s.add        s56, s53, s57
    s.movz       s57, #32
    v.st.b       [s56, #0], v6
    fence.acq_rel.device
    s.mov        s55, s58
    s.cmp.lt     s56, s55, s57
    br.nz        s56, x8dot_row_34
x8dot_done_33:
    v.splat      v6, s28
    v.movi       v13, #0
    mb.arm       s28, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s52, #0
    v.extract    s53, v9, #2
    s.movz       s55, #96
    v.cmp.ne     p1, v6, v13
    v.cmp.eq     p2, v6, v13
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w18, d1, s56, s28           // predicated off still completes once (ISA sec 9A.3)
    s.mov        s56, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w18, d0, s56, s28         // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s54
    mb.arm       s53, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s56, v7, #3
    m.mma.dp.async.k32.e4m3 a5, v56, v48, s53
    mb.wait      s53
    w.def        w19, #48, #8                    // v48..v55
    br.nz        s56, x8dot_done_35
    s.add        s57, s5, s22
    s.addi       s58, s52, #0
    s.addi       s59, s57, #96
    s.addi       s57, s32, #256
x8dot_row_36:
    s.addi       s60, s30, #-96
    v.movi       v6, #0
    s.sub        s23, s60, s58
    s.add        s24, s59, s58
    v.splat      v7, s23
    s.shli       s23, s58, #4
    s.addi       s25, s58, #1
    v.cmp.gt     p1, v7, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v6, [s24, v10]             // index is in elements (ISA sec 9.1)
    s.add        s24, s57, s23
    s.movz       s23, #32
    v.st.b       [s24, #0], v6
    fence.acq_rel.device
    s.mov        s58, s25
    s.cmp.lt     s24, s58, s23
    br.nz        s24, x8dot_row_36
x8dot_done_35:
    v.splat      v6, s56
    v.movi       v7, #0
    mb.arm       s23, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s24, v9, #3
    v.cmp.ne     p1, v6, v7
    v.cmp.eq     p2, v6, v7
    s.mov        s25, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s26, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w19, d1, s25, s23           // predicated off still completes once (ISA sec 9A.3)
    s.mov        s25, s24                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s26, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w19, d0, s25, s23         // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s28
    mb.arm       s24, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s25, s32, #3072
    s.movz       s26, #1
    m.mma.dp.async.k32.e4m3 a6, v56, v40, s24
    mb.wait      s24
    mb.wait      s23
    mb.arm       s27, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s29, s25, #64
    s.movz       s30, #2
    m.mma.dp.async.k32.e4m3 a7, v56, v48, s27
    mb.wait      s27
    a.vread      v6, a4, s52
    s.addi       s31, s25, #128
    s.movz       s33, #3
    v.st.w       [s25, #0], v6
    a.vread      v6, a4, s26
    s.addi       s26, s25, #192
    s.movz       s34, #4
    s.addi       s35, s25, #256
    s.movz       s36, #5
    s.addi       s37, s25, #320
    s.movz       s38, #6
    s.addi       s39, s25, #384
    s.movz       s40, #7
    s.addi       s41, s25, #448
    s.movz       s42, #8
    s.addi       s43, s25, #512
    s.movz       s44, #9
    s.addi       s45, s25, #576
    s.movz       s46, #10
    v.st.w       [s29, #0], v6
    a.vread      v6, a4, s30
    s.addi       s29, s25, #640
    s.movz       s30, #11
    v.st.w       [s31, #0], v6
    a.vread      v6, a4, s33
    s.addi       s31, s25, #704
    s.movz       s33, #12
    v.st.w       [s26, #0], v6
    a.vread      v6, a4, s34
    s.addi       s26, s25, #768
    s.movz       s34, #13
    v.st.w       [s35, #0], v6
    a.vread      v6, a4, s36
    s.addi       s35, s25, #832
    s.movz       s36, #14
    v.st.w       [s37, #0], v6
    a.vread      v6, a4, s38
    s.addi       s37, s25, #896
    s.movz       s38, #15
    s.addi       s47, s25, #960
    v.st.w       [s39, #0], v6
    a.vread      v6, a4, s40
    s.movz       s25, #0
    s.addi       s39, s32, #4096
    v.st.w       [s41, #0], v6
    a.vread      v6, a4, s42
    s.movz       s40, #1
    s.addi       s41, s39, #64
    v.st.w       [s43, #0], v6
    a.vread      v6, a4, s44
    s.movz       s42, #2
    s.addi       s43, s39, #128
    v.st.w       [s45, #0], v6
    a.vread      v6, a4, s46
    s.movz       s44, #3
    s.addi       s45, s39, #192
    v.st.w       [s29, #0], v6
    a.vread      v6, a4, s30
    s.movz       s29, #4
    s.addi       s30, s39, #256
    v.st.w       [s31, #0], v6
    a.vread      v6, a4, s33
    s.movz       s31, #5
    s.addi       s33, s39, #320
    v.st.w       [s26, #0], v6
    a.vread      v6, a4, s34
    s.movz       s26, #6
    s.addi       s34, s39, #384
    v.st.w       [s35, #0], v6
    a.vread      v6, a4, s36
    s.movz       s35, #7
    s.addi       s36, s39, #448
    v.st.w       [s37, #0], v6
    a.vread      v6, a4, s38
    s.movz       s37, #8
    s.addi       s38, s39, #512
    v.st.w       [s47, #0], v6
    fence.acq_rel.device
    a.vread      v6, a5, s25
    s.movz       s25, #9
    s.addi       s46, s39, #576
    v.st.w       [s39, #0], v6
    a.vread      v6, a5, s40
    s.movz       s40, #10
    v.st.w       [s41, #0], v6
    a.vread      v6, a5, s42
    s.addi       s41, s39, #640
    s.movz       s42, #11
    v.st.w       [s43, #0], v6
    a.vread      v6, a5, s44
    s.addi       s43, s39, #704
    s.movz       s44, #12
    v.st.w       [s45, #0], v6
    a.vread      v6, a5, s29
    s.addi       s29, s39, #768
    s.movz       s45, #13
    v.st.w       [s30, #0], v6
    a.vread      v6, a5, s31
    s.addi       s30, s39, #832
    s.movz       s31, #14
    v.st.w       [s33, #0], v6
    a.vread      v6, a5, s26
    s.addi       s26, s39, #896
    s.movz       s33, #15
    s.addi       s47, s39, #960
    v.st.w       [s34, #0], v6
    a.vread      v6, a5, s35
    s.movz       s34, #0
    s.addi       s35, s32, #5120
    v.st.w       [s36, #0], v6
    a.vread      v6, a5, s37
    s.movz       s36, #1
    s.addi       s37, s35, #64
    v.st.w       [s38, #0], v6
    a.vread      v6, a5, s25
    s.movz       s25, #2
    s.addi       s38, s35, #128
    v.st.w       [s46, #0], v6
    a.vread      v6, a5, s40
    s.movz       s39, #3
    s.addi       s40, s35, #192
    v.st.w       [s41, #0], v6
    a.vread      v6, a5, s42
    s.movz       s41, #4
    s.addi       s42, s35, #256
    v.st.w       [s43, #0], v6
    a.vread      v6, a5, s44
    s.movz       s43, #5
    s.addi       s44, s35, #320
    v.st.w       [s29, #0], v6
    a.vread      v6, a5, s45
    s.movz       s29, #6
    s.addi       s45, s35, #384
    v.st.w       [s30, #0], v6
    a.vread      v6, a5, s31
    s.movz       s30, #7
    s.addi       s31, s35, #448
    v.st.w       [s26, #0], v6
    a.vread      v6, a5, s33
    s.movz       s26, #8
    s.addi       s33, s35, #512
    v.st.w       [s47, #0], v6
    fence.acq_rel.device
    a.vread      v6, a6, s34
    s.movz       s34, #9
    s.addi       s46, s35, #576
    v.st.w       [s35, #0], v6
    a.vread      v6, a6, s36
    s.movz       s36, #10
    v.st.w       [s37, #0], v6
    a.vread      v6, a6, s25
    s.addi       s25, s35, #640
    s.movz       s37, #11
    v.st.w       [s38, #0], v6
    a.vread      v6, a6, s39
    s.addi       s38, s35, #704
    s.movz       s39, #12
    v.st.w       [s40, #0], v6
    a.vread      v6, a6, s41
    s.addi       s40, s35, #768
    s.movz       s41, #13
    v.st.w       [s42, #0], v6
    a.vread      v6, a6, s43
    s.addi       s42, s35, #832
    s.movz       s43, #14
    v.st.w       [s44, #0], v6
    a.vread      v6, a6, s29
    s.addi       s29, s35, #896
    s.movz       s44, #15
    s.addi       s47, s35, #960
    v.st.w       [s45, #0], v6
    a.vread      v6, a6, s30
    s.movz       s30, #0
    s.addi       s35, s32, #6144
    v.st.w       [s31, #0], v6
    a.vread      v6, a6, s26
    s.movz       s26, #1
    s.addi       s31, s35, #64
    v.st.w       [s33, #0], v6
    a.vread      v6, a6, s34
    s.movz       s33, #2
    s.addi       s34, s35, #128
    v.st.w       [s46, #0], v6
    a.vread      v6, a6, s36
    s.movz       s36, #3
    s.addi       s45, s35, #192
    v.st.w       [s25, #0], v6
    a.vread      v6, a6, s37
    s.movz       s25, #4
    s.addi       s37, s35, #256
    v.st.w       [s38, #0], v6
    a.vread      v6, a6, s39
    s.movz       s38, #5
    s.addi       s39, s35, #320
    v.st.w       [s40, #0], v6
    a.vread      v6, a6, s41
    s.movz       s40, #6
    s.addi       s41, s35, #384
    v.st.w       [s42, #0], v6
    a.vread      v6, a6, s43
    s.movz       s42, #7
    s.addi       s43, s35, #448
    v.st.w       [s29, #0], v6
    a.vread      v6, a6, s44
    s.movz       s29, #8
    s.addi       s44, s35, #512
    v.st.w       [s47, #0], v6
    fence.acq_rel.device
    a.vread      v6, a7, s30
    s.movz       s30, #9
    s.addi       s46, s35, #576
    v.st.w       [s35, #0], v6
    a.vread      v6, a7, s26
    s.movz       s26, #10
    v.st.w       [s31, #0], v6
    a.vread      v6, a7, s33
    s.addi       s31, s35, #640
    s.movz       s33, #11
    v.st.w       [s34, #0], v6
    a.vread      v6, a7, s36
    s.addi       s34, s35, #704
    s.movz       s36, #12
    v.st.w       [s45, #0], v6
    a.vread      v6, a7, s25
    s.addi       s25, s35, #768
    s.movz       s45, #13
    v.st.w       [s37, #0], v6
    a.vread      v6, a7, s38
    s.addi       s37, s35, #832
    s.movz       s38, #14
    v.st.w       [s39, #0], v6
    a.vread      v6, a7, s40
    s.addi       s39, s35, #896
    s.movz       s40, #15
    s.addi       s47, s35, #960
    v.st.w       [s41, #0], v6
    a.vread      v6, a7, s42
    s.movz       s35, #0
    s.addi       s41, s32, #3072
    v.st.w       [s43, #0], v6
    a.vread      v6, a7, s29
    v.extract    s29, v8, #0
    s.addi       s42, s32, #7168
    v.splat      v7, s29
    s.movz       s29, #1
    v.st.w       [s44, #0], v6
    a.vread      v6, a7, s30
    s.addi       s30, s32, #3136
    v.extract    s43, v8, #1
    v.splat      v9, s43
    s.addi       s43, s42, #64
    v.st.w       [s46, #0], v6
    a.vread      v6, a7, s26
    s.movz       s26, #2
    s.addi       s44, s32, #3200
    v.st.w       [s31, #0], v6
    a.vread      v6, a7, s33
    v.extract    s31, v8, #2
    s.addi       s33, s42, #128
    v.splat      v10, s31
    v.st.w       [s34, #0], v6
    a.vread      v6, a7, s36
    s.addi       s31, s42, #192
    v.st.w       [s25, #0], v6
    a.vread      v6, a7, s45
    s.movz       s25, #3
    s.addi       s34, s32, #3264
    v.st.w       [s37, #0], v6
    a.vread      v6, a7, s38
    v.extract    s36, v8, #3
    v.splat      v13, s36
    v.st.w       [s39, #0], v6
    a.vread      v6, a7, s40
    s.movz       s36, #4
    s.addi       s37, s42, #256
    v.st.w       [s47, #0], v6
    fence.acq_rel.device
    a.vread      v6, a0, s35
    s.addi       s35, s32, #3328
    v.extract    s38, v8, #4
    v.splat      v17, s38
    v.ld.w       v18, [s41, #0]
    vf.mul       v21, v18, v7
    s.addi       s38, s42, #320
    vf.mul       v7, v21, v12
    s.movz       s39, #5
    vf.add       v18, v6, v7
    v.st.w       [s42, #0], v18
    a.vread      v6, a0, s29
    s.addi       s29, s32, #3392
    v.extract    s40, v8, #5
    v.splat      v7, s40
    v.ld.w       v18, [s30, #0]
    vf.mul       v21, v18, v9
    s.addi       s30, s42, #384
    vf.mul       v9, v21, v12
    s.movz       s40, #6
    vf.add       v18, v6, v9
    v.st.w       [s43, #0], v18
    a.vread      v6, a0, s26
    s.addi       s26, s32, #3456
    v.extract    s41, v8, #6
    v.splat      v9, s41
    v.ld.w       v18, [s44, #0]
    vf.mul       v21, v18, v10
    s.addi       s41, s42, #448
    vf.mul       v10, v21, v12
    s.movz       s43, #7
    vf.add       v18, v6, v10
    v.st.w       [s33, #0], v18
    a.vread      v6, a0, s25
    s.addi       s25, s32, #3520
    v.extract    s33, v8, #7
    v.splat      v10, s33
    v.ld.w       v18, [s34, #0]
    vf.mul       v21, v18, v13
    s.addi       s33, s42, #512
    vf.mul       v13, v21, v12
    s.movz       s34, #8
    vf.add       v18, v6, v13
    v.st.w       [s31, #0], v18
    a.vread      v6, a0, s36
    s.addi       s31, s32, #3584
    v.extract    s36, v8, #8
    v.splat      v13, s36
    v.ld.w       v18, [s35, #0]
    vf.mul       v21, v18, v17
    s.addi       s35, s42, #576
    vf.mul       v17, v21, v12
    s.movz       s36, #9
    vf.add       v18, v6, v17
    v.st.w       [s37, #0], v18
    a.vread      v6, a0, s39
    s.addi       s37, s32, #3648
    v.extract    s39, v8, #9
    v.splat      v17, s39
    v.ld.w       v18, [s29, #0]
    vf.mul       v21, v18, v7
    s.addi       s29, s42, #640
    vf.mul       v7, v21, v12
    s.movz       s39, #10
    vf.add       v18, v6, v7
    v.st.w       [s38, #0], v18
    a.vread      v6, a0, s40
    s.addi       s38, s32, #3712
    v.extract    s40, v8, #10
    v.splat      v7, s40
    v.ld.w       v18, [s26, #0]
    vf.mul       v21, v18, v9
    s.addi       s26, s42, #704
    vf.mul       v9, v21, v12
    s.movz       s40, #11
    vf.add       v18, v6, v9
    v.st.w       [s30, #0], v18
    a.vread      v6, a0, s43
    s.addi       s30, s32, #3776
    v.extract    s43, v8, #11
    v.splat      v9, s43
    v.ld.w       v18, [s25, #0]
    vf.mul       v21, v18, v10
    s.addi       s25, s42, #768
    vf.mul       v10, v21, v12
    s.movz       s43, #12
    vf.add       v18, v6, v10
    v.st.w       [s41, #0], v18
    a.vread      v6, a0, s34
    s.addi       s34, s32, #3840
    v.extract    s41, v8, #12
    v.splat      v10, s41
    v.ld.w       v18, [s31, #0]
    vf.mul       v21, v18, v13
    s.addi       s31, s42, #832
    vf.mul       v13, v21, v12
    s.movz       s41, #13
    vf.add       v18, v6, v13
    v.st.w       [s33, #0], v18
    a.vread      v6, a0, s36
    s.addi       s33, s32, #3904
    v.extract    s36, v8, #13
    v.splat      v13, s36
    v.ld.w       v18, [s37, #0]
    vf.mul       v21, v18, v17
    s.addi       s36, s42, #896
    vf.mul       v17, v21, v12
    s.movz       s37, #14
    vf.add       v18, v6, v17
    v.st.w       [s35, #0], v18
    a.vread      v6, a0, s39
    s.addi       s35, s32, #3968
    v.extract    s39, v8, #14
    v.splat      v17, s39
    v.ld.w       v18, [s38, #0]
    vf.mul       v21, v18, v7
    s.addi       s38, s42, #960
    vf.mul       v7, v21, v12
    s.movz       s39, #15
    vf.add       v18, v6, v7
    v.st.w       [s29, #0], v18
    a.vread      v6, a0, s40
    s.addi       s29, s32, #4032
    v.extract    s40, v8, #15
    v.splat      v7, s40
    v.ld.w       v18, [s30, #0]
    vf.mul       v21, v18, v9
    vf.mul       v9, v21, v12
    s.addi       s30, s32, #8192
    vf.add       v18, v6, v9
    s.movz       s40, #0
    v.st.w       [s26, #0], v18
    a.vread      v6, a0, s43
    s.addi       s26, s32, #4096
    v.extract    s42, v8, #0
    v.splat      v9, s42
    v.ld.w       v18, [s34, #0]
    vf.mul       v21, v18, v10
    vf.mul       v10, v21, v12
    s.addi       s34, s30, #64
    vf.add       v18, v6, v10
    s.movz       s42, #1
    v.st.w       [s25, #0], v18
    a.vread      v6, a0, s41
    s.addi       s25, s32, #4160
    v.extract    s41, v8, #1
    v.splat      v10, s41
    v.ld.w       v18, [s33, #0]
    vf.mul       v21, v18, v13
    vf.mul       v13, v21, v12
    s.addi       s33, s30, #128
    vf.add       v18, v6, v13
    s.movz       s41, #2
    v.st.w       [s31, #0], v18
    a.vread      v6, a0, s37
    s.addi       s31, s32, #4224
    v.extract    s37, v8, #2
    v.splat      v13, s37
    v.ld.w       v18, [s35, #0]
    vf.mul       v21, v18, v17
    vf.mul       v17, v21, v12
    s.addi       s35, s30, #192
    vf.add       v18, v6, v17
    s.movz       s37, #3
    v.st.w       [s36, #0], v18
    a.vread      v6, a0, s39
    s.addi       s36, s32, #4288
    v.extract    s39, v8, #3
    v.splat      v17, s39
    v.ld.w       v18, [s29, #0]
    vf.mul       v21, v18, v7
    vf.mul       v7, v21, v12
    s.addi       s29, s30, #256
    vf.add       v12, v6, v7
    s.movz       s39, #4
    v.st.w       [s38, #0], v12
    fence.acq_rel.device
    a.vread      v6, a1, s40
    s.addi       s38, s32, #4352
    v.extract    s40, v8, #4
    v.splat      v7, s40
    v.ld.w       v12, [s26, #0]
    vf.mul       v18, v12, v9
    s.addi       s26, s30, #320
    vf.mul       v9, v18, v11
    s.movz       s40, #5
    vf.add       v12, v6, v9
    v.st.w       [s30, #0], v12
    a.vread      v6, a1, s42
    s.addi       s42, s32, #4416
    v.extract    s43, v8, #5
    v.splat      v9, s43
    v.ld.w       v12, [s25, #0]
    vf.mul       v18, v12, v10
    s.addi       s25, s30, #384
    vf.mul       v10, v18, v11
    s.movz       s43, #6
    vf.add       v12, v6, v10
    v.st.w       [s34, #0], v12
    a.vread      v6, a1, s41
    s.addi       s34, s32, #4480
    v.extract    s41, v8, #6
    v.splat      v10, s41
    v.ld.w       v12, [s31, #0]
    vf.mul       v18, v12, v13
    s.addi       s31, s30, #448
    vf.mul       v12, v18, v11
    s.movz       s41, #7
    vf.add       v13, v6, v12
    v.st.w       [s33, #0], v13
    a.vread      v6, a1, s37
    s.addi       s33, s32, #4544
    v.extract    s37, v8, #7
    v.splat      v12, s37
    v.ld.w       v13, [s36, #0]
    vf.mul       v18, v13, v17
    s.addi       s36, s30, #512
    vf.mul       v13, v18, v11
    s.movz       s37, #8
    vf.add       v17, v6, v13
    v.st.w       [s35, #0], v17
    a.vread      v6, a1, s39
    s.addi       s35, s32, #4608
    v.extract    s39, v8, #8
    v.splat      v13, s39
    v.ld.w       v17, [s38, #0]
    vf.mul       v18, v17, v7
    s.addi       s38, s30, #576
    vf.mul       v7, v18, v11
    s.movz       s39, #9
    vf.add       v17, v6, v7
    v.st.w       [s29, #0], v17
    a.vread      v6, a1, s40
    s.addi       s29, s32, #4672
    v.extract    s40, v8, #9
    v.splat      v7, s40
    v.ld.w       v17, [s42, #0]
    vf.mul       v18, v17, v9
    s.addi       s40, s30, #640
    vf.mul       v9, v18, v11
    s.movz       s42, #10
    vf.add       v17, v6, v9
    v.st.w       [s26, #0], v17
    a.vread      v6, a1, s43
    s.addi       s26, s32, #4736
    v.extract    s43, v8, #10
    v.splat      v9, s43
    v.ld.w       v17, [s34, #0]
    vf.mul       v18, v17, v10
    s.addi       s34, s30, #704
    vf.mul       v10, v18, v11
    s.movz       s43, #11
    vf.add       v17, v6, v10
    v.st.w       [s25, #0], v17
    a.vread      v6, a1, s41
    s.addi       s25, s32, #4800
    v.extract    s41, v8, #11
    v.splat      v10, s41
    v.ld.w       v17, [s33, #0]
    vf.mul       v18, v17, v12
    s.addi       s33, s30, #768
    vf.mul       v12, v18, v11
    s.movz       s41, #12
    vf.add       v17, v6, v12
    v.st.w       [s31, #0], v17
    a.vread      v6, a1, s37
    s.addi       s31, s32, #4864
    v.extract    s37, v8, #12
    v.splat      v12, s37
    v.ld.w       v17, [s35, #0]
    vf.mul       v18, v17, v13
    s.addi       s35, s30, #832
    vf.mul       v13, v18, v11
    s.movz       s37, #13
    vf.add       v17, v6, v13
    v.st.w       [s36, #0], v17
    a.vread      v6, a1, s39
    s.addi       s36, s32, #4928
    v.extract    s39, v8, #13
    v.splat      v13, s39
    v.ld.w       v17, [s29, #0]
    vf.mul       v18, v17, v7
    s.addi       s29, s30, #896
    vf.mul       v7, v18, v11
    s.movz       s39, #14
    vf.add       v17, v6, v7
    v.st.w       [s38, #0], v17
    a.vread      v6, a1, s42
    s.addi       s38, s32, #4992
    v.extract    s42, v8, #14
    v.splat      v7, s42
    v.ld.w       v17, [s26, #0]
    vf.mul       v18, v17, v9
    s.addi       s26, s30, #960
    vf.mul       v9, v18, v11
    s.movz       s30, #15
    vf.add       v17, v6, v9
    v.st.w       [s40, #0], v17
    a.vread      v6, a1, s43
    s.addi       s40, s32, #5056
    v.extract    s42, v8, #15
    v.splat      v9, s42
    v.ld.w       v17, [s25, #0]
    vf.mul       v18, v17, v10
    vf.mul       v10, v18, v11
    s.addi       s25, s32, #9216
    vf.add       v17, v6, v10
    s.movz       s42, #0
    v.st.w       [s34, #0], v17
    a.vread      v6, a1, s41
    s.addi       s34, s32, #5120
    v.extract    s41, v8, #0
    v.splat      v10, s41
    v.ld.w       v17, [s31, #0]
    vf.mul       v18, v17, v12
    vf.mul       v12, v18, v11
    s.addi       s31, s25, #64
    vf.add       v17, v6, v12
    s.movz       s41, #1
    v.st.w       [s33, #0], v17
    a.vread      v6, a1, s37
    s.addi       s33, s32, #5184
    v.extract    s37, v8, #1
    v.splat      v12, s37
    v.ld.w       v17, [s36, #0]
    vf.mul       v18, v17, v13
    vf.mul       v13, v18, v11
    s.addi       s36, s25, #128
    vf.add       v17, v6, v13
    s.movz       s37, #2
    v.st.w       [s35, #0], v17
    a.vread      v6, a1, s39
    s.addi       s35, s32, #5248
    v.extract    s39, v8, #2
    v.splat      v13, s39
    v.ld.w       v17, [s38, #0]
    vf.mul       v18, v17, v7
    vf.mul       v7, v18, v11
    s.addi       s38, s25, #192
    vf.add       v17, v6, v7
    s.movz       s39, #3
    v.st.w       [s29, #0], v17
    a.vread      v6, a1, s30
    s.addi       s29, s32, #5312
    v.extract    s30, v8, #3
    v.splat      v7, s30
    v.ld.w       v17, [s40, #0]
    vf.mul       v18, v17, v9
    vf.mul       v9, v18, v11
    s.addi       s30, s25, #256
    vf.add       v11, v6, v9
    s.movz       s40, #4
    v.st.w       [s26, #0], v11
    fence.acq_rel.device
    a.vread      v6, a2, s42
    s.addi       s26, s32, #5376
    v.extract    s42, v8, #4
    v.splat      v9, s42
    v.ld.w       v11, [s34, #0]
    vf.mul       v17, v11, v10
    s.addi       s34, s25, #320
    vf.mul       v10, v17, v19
    s.movz       s42, #5
    vf.add       v11, v6, v10
    v.st.w       [s25, #0], v11
    a.vread      v6, a2, s41
    s.addi       s41, s32, #5440
    v.extract    s43, v8, #5
    v.splat      v10, s43
    v.ld.w       v11, [s33, #0]
    vf.mul       v17, v11, v12
    s.addi       s33, s25, #384
    vf.mul       v11, v17, v19
    s.movz       s43, #6
    vf.add       v12, v6, v11
    v.st.w       [s31, #0], v12
    a.vread      v6, a2, s37
    s.addi       s31, s32, #5504
    v.extract    s37, v8, #6
    v.splat      v11, s37
    v.ld.w       v12, [s35, #0]
    vf.mul       v17, v12, v13
    s.addi       s35, s25, #448
    vf.mul       v12, v17, v19
    s.movz       s37, #7
    vf.add       v13, v6, v12
    v.st.w       [s36, #0], v13
    a.vread      v6, a2, s39
    s.addi       s36, s32, #5568
    v.extract    s39, v8, #7
    v.splat      v12, s39
    v.ld.w       v13, [s29, #0]
    vf.mul       v17, v13, v7
    s.addi       s29, s25, #512
    vf.mul       v7, v17, v19
    s.movz       s39, #8
    vf.add       v13, v6, v7
    v.st.w       [s38, #0], v13
    a.vread      v6, a2, s40
    s.addi       s38, s32, #5632
    v.extract    s40, v8, #8
    v.splat      v7, s40
    v.ld.w       v13, [s26, #0]
    vf.mul       v17, v13, v9
    s.addi       s26, s25, #576
    vf.mul       v9, v17, v19
    s.movz       s40, #9
    vf.add       v13, v6, v9
    v.st.w       [s30, #0], v13
    a.vread      v6, a2, s42
    s.addi       s30, s32, #5696
    v.extract    s42, v8, #9
    v.splat      v9, s42
    v.ld.w       v13, [s41, #0]
    vf.mul       v17, v13, v10
    s.addi       s41, s25, #640
    vf.mul       v10, v17, v19
    s.movz       s42, #10
    vf.add       v13, v6, v10
    v.st.w       [s34, #0], v13
    a.vread      v6, a2, s43
    s.addi       s34, s32, #5760
    v.extract    s43, v8, #10
    v.splat      v10, s43
    v.ld.w       v13, [s31, #0]
    vf.mul       v17, v13, v11
    s.addi       s31, s25, #704
    vf.mul       v11, v17, v19
    s.movz       s43, #11
    vf.add       v13, v6, v11
    v.st.w       [s33, #0], v13
    a.vread      v6, a2, s37
    s.addi       s33, s32, #5824
    v.extract    s37, v8, #11
    v.splat      v11, s37
    v.ld.w       v13, [s36, #0]
    vf.mul       v17, v13, v12
    s.addi       s36, s25, #768
    vf.mul       v12, v17, v19
    s.movz       s37, #12
    vf.add       v13, v6, v12
    v.st.w       [s35, #0], v13
    a.vread      v6, a2, s39
    s.addi       s35, s32, #5888
    v.extract    s39, v8, #12
    v.splat      v12, s39
    v.ld.w       v13, [s38, #0]
    vf.mul       v17, v13, v7
    s.addi       s38, s25, #832
    vf.mul       v7, v17, v19
    s.movz       s39, #13
    vf.add       v13, v6, v7
    v.st.w       [s29, #0], v13
    a.vread      v6, a2, s40
    s.addi       s29, s32, #5952
    v.extract    s40, v8, #13
    v.splat      v7, s40
    v.ld.w       v13, [s30, #0]
    vf.mul       v17, v13, v9
    s.addi       s30, s25, #896
    vf.mul       v9, v17, v19
    s.movz       s40, #14
    vf.add       v13, v6, v9
    v.st.w       [s26, #0], v13
    a.vread      v6, a2, s42
    s.addi       s26, s32, #6016
    v.extract    s42, v8, #14
    v.splat      v9, s42
    v.ld.w       v13, [s34, #0]
    vf.mul       v17, v13, v10
    s.addi       s34, s25, #960
    vf.mul       v10, v17, v19
    s.movz       s25, #15
    vf.add       v13, v6, v10
    v.st.w       [s41, #0], v13
    a.vread      v6, a2, s43
    s.addi       s41, s32, #6080
    v.extract    s42, v8, #15
    v.splat      v10, s42
    v.ld.w       v13, [s33, #0]
    vf.mul       v17, v13, v11
    vf.mul       v11, v17, v19
    s.addi       s33, s32, #10240
    vf.add       v13, v6, v11
    s.movz       s42, #0
    v.st.w       [s31, #0], v13
    a.vread      v6, a2, s37
    s.addi       s31, s32, #6144
    v.extract    s37, v8, #0
    v.splat      v11, s37
    v.ld.w       v13, [s35, #0]
    vf.mul       v17, v13, v12
    vf.mul       v12, v17, v19
    s.addi       s35, s33, #64
    vf.add       v13, v6, v12
    s.movz       s37, #1
    v.st.w       [s36, #0], v13
    a.vread      v6, a2, s39
    s.addi       s36, s32, #6208
    v.extract    s39, v8, #1
    v.splat      v12, s39
    v.ld.w       v13, [s29, #0]
    vf.mul       v17, v13, v7
    vf.mul       v7, v17, v19
    s.addi       s29, s33, #128
    vf.add       v13, v6, v7
    s.movz       s39, #2
    v.st.w       [s38, #0], v13
    a.vread      v6, a2, s40
    s.addi       s38, s32, #6272
    v.extract    s40, v8, #2
    v.splat      v7, s40
    v.ld.w       v13, [s26, #0]
    vf.mul       v17, v13, v9
    vf.mul       v9, v17, v19
    s.addi       s26, s33, #192
    vf.add       v13, v6, v9
    s.movz       s40, #3
    v.st.w       [s30, #0], v13
    a.vread      v6, a2, s25
    s.addi       s25, s32, #6336
    v.extract    s30, v8, #3
    v.splat      v9, s30
    v.ld.w       v13, [s41, #0]
    vf.mul       v17, v13, v10
    vf.mul       v10, v17, v19
    s.addi       s30, s33, #256
    vf.add       v13, v6, v10
    s.movz       s41, #4
    v.st.w       [s34, #0], v13
    fence.acq_rel.device
    a.vread      v6, a3, s42
    s.addi       s34, s32, #6400
    v.extract    s42, v8, #4
    v.splat      v10, s42
    v.ld.w       v13, [s31, #0]
    vf.mul       v17, v13, v11
    s.addi       s31, s33, #320
    vf.mul       v11, v17, v20
    s.movz       s42, #5
    vf.add       v13, v6, v11
    v.st.w       [s33, #0], v13
    a.vread      v6, a3, s37
    s.addi       s37, s32, #6464
    v.extract    s43, v8, #5
    v.splat      v11, s43
    v.ld.w       v13, [s36, #0]
    vf.mul       v17, v13, v12
    s.addi       s36, s33, #384
    vf.mul       v12, v17, v20
    s.movz       s43, #6
    vf.add       v13, v6, v12
    v.st.w       [s35, #0], v13
    a.vread      v6, a3, s39
    s.addi       s35, s32, #6528
    v.extract    s39, v8, #6
    v.splat      v12, s39
    v.ld.w       v13, [s38, #0]
    vf.mul       v17, v13, v7
    s.addi       s38, s33, #448
    vf.mul       v7, v17, v20
    s.movz       s39, #7
    vf.add       v13, v6, v7
    v.st.w       [s29, #0], v13
    a.vread      v6, a3, s40
    s.addi       s29, s32, #6592
    v.extract    s40, v8, #7
    v.splat      v7, s40
    v.ld.w       v13, [s25, #0]
    vf.mul       v17, v13, v9
    s.addi       s25, s33, #512
    vf.mul       v9, v17, v20
    s.movz       s40, #8
    vf.add       v13, v6, v9
    v.st.w       [s26, #0], v13
    a.vread      v6, a3, s41
    s.addi       s26, s32, #6656
    v.extract    s41, v8, #8
    v.splat      v9, s41
    v.ld.w       v13, [s34, #0]
    vf.mul       v17, v13, v10
    s.addi       s34, s33, #576
    vf.mul       v10, v17, v20
    s.movz       s41, #9
    vf.add       v13, v6, v10
    v.st.w       [s30, #0], v13
    a.vread      v6, a3, s42
    s.addi       s30, s32, #6720
    v.extract    s42, v8, #9
    v.splat      v10, s42
    v.ld.w       v13, [s37, #0]
    vf.mul       v17, v13, v11
    s.addi       s37, s33, #640
    vf.mul       v11, v17, v20
    s.movz       s42, #10
    vf.add       v13, v6, v11
    v.st.w       [s31, #0], v13
    a.vread      v6, a3, s43
    s.addi       s31, s32, #6784
    v.extract    s43, v8, #10
    v.splat      v11, s43
    v.ld.w       v13, [s35, #0]
    vf.mul       v17, v13, v12
    s.addi       s35, s33, #704
    vf.mul       v12, v17, v20
    s.movz       s43, #11
    vf.add       v13, v6, v12
    v.st.w       [s36, #0], v13
    a.vread      v6, a3, s39
    s.addi       s36, s32, #6848
    v.extract    s39, v8, #11
    v.splat      v12, s39
    v.ld.w       v13, [s29, #0]
    vf.mul       v17, v13, v7
    s.addi       s29, s33, #768
    vf.mul       v7, v17, v20
    s.movz       s39, #12
    vf.add       v13, v6, v7
    v.st.w       [s38, #0], v13
    a.vread      v6, a3, s40
    s.addi       s38, s32, #6912
    v.extract    s40, v8, #12
    v.splat      v7, s40
    v.ld.w       v13, [s26, #0]
    vf.mul       v17, v13, v9
    s.addi       s26, s33, #832
    vf.mul       v9, v17, v20
    s.movz       s40, #13
    vf.add       v13, v6, v9
    v.st.w       [s25, #0], v13
    a.vread      v6, a3, s41
    s.addi       s25, s32, #6976
    v.extract    s41, v8, #13
    v.splat      v9, s41
    v.ld.w       v13, [s30, #0]
    vf.mul       v17, v13, v10
    s.addi       s30, s33, #896
    vf.mul       v10, v17, v20
    s.movz       s41, #14
    vf.add       v13, v6, v10
    v.st.w       [s34, #0], v13
    a.vread      v6, a3, s42
    s.addi       s34, s32, #7040
    v.extract    s42, v8, #14
    v.splat      v10, s42
    v.ld.w       v13, [s31, #0]
    vf.mul       v17, v13, v11
    s.addi       s31, s33, #960
    vf.mul       v11, v17, v20
    s.movz       s33, #15
    vf.add       v13, v6, v11
    v.st.w       [s37, #0], v13
    a.vread      v6, a3, s43
    s.addi       s37, s32, #7104
    v.extract    s42, v8, #15
    v.splat      v8, s42
    v.ld.w       v11, [s36, #0]
    vf.mul       v13, v11, v12
    vf.mul       v11, v13, v20
    s.addi       s36, s21, #128
    vf.add       v12, v6, v11
    s.addi       s42, s36, #0
    v.st.w       [s35, #0], v12
    a.vread      v6, a3, s39
    s.addi       s35, s22, #128
    s.movz       s36, #0
    s.addi       s39, s35, #0
    v.ld.w       v11, [s38, #0]
    s.addi       s35, s32, #7168
    vf.mul       v12, v11, v7
    s.movz       s38, #1
    vf.mul       v7, v12, v20
    s.addi       s43, s32, #7232
    vf.add       v11, v6, v7
    v.st.w       [s29, #0], v11
    a.vread      v6, a3, s40
    s.addi       s29, s32, #7296
    s.movz       s40, #2
    v.ld.w       v7, [s25, #0]
    s.addi       s25, s32, #7360
    s.movz       s44, #3
    vf.mul       v11, v7, v9
    vf.mul       v7, v11, v20
    s.movz       s45, #4
    vf.add       v9, v6, v7
    s.addi       s46, s32, #7424
    v.st.w       [s26, #0], v9
    a.vread      v6, a3, s41
    s.addi       s26, s32, #7488
    s.movz       s41, #5
    v.ld.w       v7, [s34, #0]
    s.addi       s34, s32, #7552
    vf.mul       v9, v7, v10
    vf.mul       v7, v9, v20
    vf.add       v9, v6, v7
    v.st.w       [s30, #0], v9
    a.vread      v6, a3, s33
    s.movz       s30, #6
    s.addi       s33, s32, #7616
    v.ld.w       v7, [s37, #0]
    s.movz       s37, #7
    vf.mul       v9, v7, v8
    vf.mul       v7, v9, v20
    vf.add       v8, v6, v7
    v.st.w       [s31, #0], v8
    fence.acq_rel.device
    s.mov        s21, s42
    s.mov        s22, s39
    s.addi       s31, s32, #7680
    s.movz       s39, #8
    s.addi       s42, s32, #7744
    s.movz       s47, #9
    s.addi       s48, s32, #7808
    v.ld.w       v6, [s35, #0]
    s.movz       s35, #10
    a.vwrite     a0, s36, v6
    v.ld.w       v6, [s43, #0]
    s.addi       s43, s32, #7872
    a.vwrite     a0, s38, v6
    v.ld.w       v6, [s29, #0]
    s.movz       s29, #11
    a.vwrite     a0, s40, v6
    v.ld.w       v6, [s25, #0]
    s.addi       s25, s32, #7936
    a.vwrite     a0, s44, v6
    v.ld.w       v6, [s46, #0]
    s.movz       s46, #12
    a.vwrite     a0, s45, v6
    v.ld.w       v6, [s26, #0]
    s.addi       s26, s32, #8000
    a.vwrite     a0, s41, v6
    v.ld.w       v6, [s34, #0]
    s.movz       s34, #13
    a.vwrite     a0, s30, v6
    v.ld.w       v6, [s33, #0]
    s.addi       s33, s32, #8064
    a.vwrite     a0, s37, v6
    v.ld.w       v6, [s31, #0]
    s.movz       s31, #14
    a.vwrite     a0, s39, v6
    v.ld.w       v6, [s42, #0]
    s.addi       s42, s32, #8128
    a.vwrite     a0, s47, v6
    v.ld.w       v6, [s48, #0]
    s.movz       s48, #15
    a.vwrite     a0, s35, v6
    v.ld.w       v6, [s43, #0]
    s.addi       s43, s32, #8192
    a.vwrite     a0, s29, v6
    v.ld.w       v6, [s25, #0]
    s.addi       s25, s32, #8256
    a.vwrite     a0, s46, v6
    v.ld.w       v6, [s26, #0]
    s.addi       s26, s32, #8320
    a.vwrite     a0, s34, v6
    v.ld.w       v6, [s33, #0]
    s.addi       s33, s32, #8384
    a.vwrite     a0, s31, v6
    v.ld.w       v6, [s42, #0]
    s.addi       s42, s32, #8448
    a.vwrite     a0, s48, v6
    v.ld.w       v6, [s43, #0]
    s.addi       s43, s32, #8512
    a.vwrite     a1, s36, v6
    v.ld.w       v6, [s25, #0]
    s.addi       s25, s32, #8576
    s.addi       s36, s32, #8640
    a.vwrite     a1, s38, v6
    v.ld.w       v6, [s26, #0]
    s.addi       s26, s32, #8704
    s.addi       s38, s32, #8768
    a.vwrite     a1, s40, v6
    v.ld.w       v6, [s33, #0]
    s.addi       s33, s32, #8832
    s.addi       s40, s32, #8896
    a.vwrite     a1, s44, v6
    v.ld.w       v6, [s42, #0]
    s.addi       s42, s32, #8960
    s.addi       s44, s32, #9024
    a.vwrite     a1, s45, v6
    v.ld.w       v6, [s43, #0]
    s.addi       s43, s32, #9088
    s.addi       s45, s32, #9152
    a.vwrite     a1, s41, v6
    v.ld.w       v6, [s25, #0]
    s.addi       s25, s32, #9216
    s.movz       s41, #0
    a.vwrite     a1, s30, v6
    v.ld.w       v6, [s36, #0]
    s.addi       s30, s32, #9280
    s.movz       s36, #1
    a.vwrite     a1, s37, v6
    v.ld.w       v6, [s26, #0]
    s.addi       s26, s32, #9344
    s.movz       s37, #2
    a.vwrite     a1, s39, v6
    v.ld.w       v6, [s38, #0]
    s.addi       s38, s32, #9408
    s.movz       s39, #3
    a.vwrite     a1, s47, v6
    v.ld.w       v6, [s33, #0]
    s.addi       s33, s32, #9472
    s.movz       s47, #4
    a.vwrite     a1, s35, v6
    v.ld.w       v6, [s40, #0]
    s.addi       s35, s32, #9536
    s.movz       s40, #5
    a.vwrite     a1, s29, v6
    v.ld.w       v6, [s42, #0]
    s.addi       s29, s32, #9600
    s.movz       s42, #6
    a.vwrite     a1, s46, v6
    v.ld.w       v6, [s44, #0]
    s.addi       s44, s32, #9664
    s.movz       s46, #7
    a.vwrite     a1, s34, v6
    v.ld.w       v6, [s43, #0]
    s.addi       s34, s32, #9728
    s.movz       s43, #8
    a.vwrite     a1, s31, v6
    v.ld.w       v6, [s45, #0]
    s.addi       s31, s32, #9792
    s.movz       s45, #9
    a.vwrite     a1, s48, v6
    v.ld.w       v6, [s25, #0]
    s.addi       s25, s32, #9856
    s.movz       s48, #10
    a.vwrite     a2, s41, v6
    v.ld.w       v6, [s30, #0]
    s.addi       s30, s32, #9920
    a.vwrite     a2, s36, v6
    v.ld.w       v6, [s26, #0]
    s.movz       s26, #11
    a.vwrite     a2, s37, v6
    v.ld.w       v6, [s38, #0]
    s.addi       s38, s32, #9984
    a.vwrite     a2, s39, v6
    v.ld.w       v6, [s33, #0]
    s.movz       s33, #12
    a.vwrite     a2, s47, v6
    v.ld.w       v6, [s35, #0]
    s.addi       s35, s32, #10048
    a.vwrite     a2, s40, v6
    v.ld.w       v6, [s29, #0]
    s.movz       s29, #13
    a.vwrite     a2, s42, v6
    v.ld.w       v6, [s44, #0]
    s.addi       s44, s32, #10112
    a.vwrite     a2, s46, v6
    v.ld.w       v6, [s34, #0]
    s.movz       s34, #14
    a.vwrite     a2, s43, v6
    v.ld.w       v6, [s31, #0]
    s.addi       s31, s32, #10176
    a.vwrite     a2, s45, v6
    v.ld.w       v6, [s25, #0]
    s.movz       s25, #15
    a.vwrite     a2, s48, v6
    v.ld.w       v6, [s30, #0]
    s.addi       s30, s32, #10240
    a.vwrite     a2, s26, v6
    v.ld.w       v6, [s38, #0]
    s.addi       s38, s32, #10304
    a.vwrite     a2, s33, v6
    v.ld.w       v6, [s35, #0]
    s.addi       s35, s32, #10368
    a.vwrite     a2, s29, v6
    v.ld.w       v6, [s44, #0]
    s.addi       s44, s32, #10432
    a.vwrite     a2, s34, v6
    v.ld.w       v6, [s31, #0]
    s.addi       s31, s32, #10496
    a.vwrite     a2, s25, v6
    v.ld.w       v6, [s30, #0]
    s.addi       s30, s32, #10560
    s.add        s49, s20, s19
    a.vwrite     a3, s41, v6
    v.ld.w       v6, [s38, #0]
    s.addi       s38, s32, #10624
    s.addi       s41, s32, #10688
    a.vwrite     a3, s36, v6
    v.ld.w       v6, [s35, #0]
    s.addi       s35, s32, #10752
    s.addi       s36, s32, #10816
    a.vwrite     a3, s37, v6
    v.ld.w       v6, [s44, #0]
    s.addi       s37, s32, #10880
    s.addi       s44, s32, #10944
    a.vwrite     a3, s39, v6
    v.ld.w       v6, [s31, #0]
    s.addi       s31, s32, #11008
    s.addi       s39, s32, #11072
    a.vwrite     a3, s47, v6
    v.ld.w       v6, [s30, #0]
    s.addi       s30, s32, #11136
    s.addi       s47, s32, #11200
    s.movz       s32, #1
    a.vwrite     a3, s40, v6
    v.ld.w       v6, [s38, #0]
    a.vwrite     a3, s42, v6
    v.ld.w       v6, [s41, #0]
    a.vwrite     a3, s46, v6
    v.ld.w       v6, [s35, #0]
    a.vwrite     a3, s43, v6
    v.ld.w       v6, [s36, #0]
    a.vwrite     a3, s45, v6
    v.ld.w       v6, [s37, #0]
    a.vwrite     a3, s48, v6
    v.ld.w       v6, [s44, #0]
    a.vwrite     a3, s26, v6
    v.ld.w       v6, [s31, #0]
    a.vwrite     a3, s33, v6
    v.ld.w       v6, [s39, #0]
    a.vwrite     a3, s29, v6
    v.ld.w       v6, [s30, #0]
    a.vwrite     a3, s34, v6
    v.ld.w       v6, [s47, #0]
    a.vwrite     a3, s25, v6
    s.mov        s20, s49
    br.nz        s32, for_3
endfor_4:
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    s.muli       s12, s11, #2                    // a runtime tile origin, x2
    s.add        s13, s1, s11                    // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s13
    a.vread      v2, a0, s1
    s.add        s13, s1, s10                    // the tile origin
    s.movz       s1, #256
    s.muli       s14, s10, #512                  // a runtime tile origin, x512
    v.splat      v3, s13
    v.splat      v4, s9
    v.add        v5, v0, v1
    v.splat      v1, s1
    vf.cvt.f32.bf16 v6, v2
    s.add        s9, s8, s12                     // the tile origin
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v1
    s.add        s12, s9, s14                    // the tile origin
    p.and        p3, p1, p2
    s.movz       s9, #1
    @p3 v.st.h       [s12, #0], v6
    a.vread      v1, a0, s9
    s.addi       s9, s13, #1
    s.addi       s14, s12, #512                  // row 1
    v.splat      v2, s9
    vf.cvt.f32.bf16 v3, v1
    s.movz       s9, #2
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    s.addi       s15, s13, #2
    s.addi       s16, s12, #1024                 // row 2
    v.splat      v1, s15
    s.movz       s15, #3
    s.addi       s17, s13, #3
    @p3 v.st.h       [s14, #0], v3
    a.vread      v2, a0, s9
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    v.splat      v2, s17
    s.addi       s9, s12, #1536                  // row 3
    s.addi       s14, s11, #16
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.addi       s17, s11, #32
    s.addi       s18, s11, #48
    s.movz       s11, #4
    s.addi       s19, s13, #4
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a0, s15
    v.splat      v2, s19
    s.addi       s15, s12, #2048                 // row 4
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    s.movz       s16, #5
    s.addi       s19, s13, #5
    s.addi       s20, s12, #2560                 // row 5
    v.splat      v1, s19
    s.movz       s19, #6
    @p4 v.st.h       [s9, #0], v3
    a.vread      v2, a0, s11
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.addi       s9, s13, #6
    s.addi       s11, s12, #3072                 // row 6
    v.splat      v2, s9
    s.movz       s9, #7
    @p3 v.st.h       [s15, #0], v1
    a.vread      v1, a0, s16
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s15, s13, #7
    s.addi       s16, s12, #3584                 // row 7
    v.splat      v1, s15
    s.movz       s15, #8
    @p4 v.st.h       [s20, #0], v2
    a.vread      v2, a0, s19
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.addi       s19, s13, #8
    s.addi       s20, s12, #4096                 // row 8
    v.splat      v2, s19
    s.movz       s19, #9
    @p3 v.st.h       [s11, #0], v1
    a.vread      v1, a0, s9
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s9, s13, #9
    s.addi       s11, s12, #4608                 // row 9
    v.splat      v1, s9
    s.movz       s9, #10
    @p4 v.st.h       [s16, #0], v2
    a.vread      v2, a0, s15
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.addi       s15, s13, #10
    s.addi       s16, s12, #5120                 // row 10
    v.splat      v2, s15
    s.movz       s15, #11
    @p3 v.st.h       [s20, #0], v1
    a.vread      v1, a0, s19
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s19, s13, #11
    s.addi       s20, s12, #5632                 // row 11
    v.splat      v1, s19
    s.movz       s19, #12
    @p4 v.st.h       [s11, #0], v2
    a.vread      v2, a0, s9
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.addi       s9, s13, #12
    s.addi       s11, s12, #6144                 // row 12
    v.splat      v2, s9
    s.movz       s9, #13
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a0, s15
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s15, s13, #13
    s.addi       s16, s12, #6656                 // row 13
    v.splat      v1, s15
    s.movz       s15, #14
    v.splat      v3, s13
    @p4 v.st.h       [s20, #0], v2
    a.vread      v2, a0, s19
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.addi       s19, s13, #14
    s.addi       s20, s12, #7168                 // row 14
    v.splat      v2, s19
    s.movz       s19, #15
    s.addi       s21, s12, #7680                 // row 15
    v.splat      v5, s1
    @p3 v.st.h       [s11, #0], v1
    a.vread      v1, a0, s9
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s9, s13, #15
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s11, #0
    v.splat      v1, s9
    s.add        s9, s11, s14                    // the tile origin
    s.muli       s12, s14, #2                    // a runtime tile origin, x2
    v.splat      v6, s9
    s.muli       s9, s10, #512                   // a runtime tile origin, x512
    v.add        v7, v0, v6
    @p4 v.st.h       [s16, #0], v2
    a.vread      v2, a0, s15
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.add        s14, s8, s12                    // the tile origin
    v.cmp.lt     p1, v3, v4
    s.add        s12, s14, s9                    // the tile origin
    s.movz       s9, #1
    s.addi       s14, s13, #1
    s.addi       s15, s12, #512                  // row 1
    v.splat      v2, s14
    s.movz       s14, #2
    @p3 v.st.h       [s20, #0], v1
    a.vread      v1, a0, s19
    v.cmp.lt     p2, v7, v5
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.addi       s16, s13, #2
    s.addi       s19, s12, #1024                 // row 2
    v.splat      v1, s16
    s.movz       s16, #3
    @p4 v.st.h       [s21, #0], v3
    a.vread      v3, a1, s11
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.addi       s11, s13, #3
    s.addi       s20, s12, #1536                 // row 3
    v.splat      v3, s11
    s.movz       s11, #4
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a1, s9
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.addi       s9, s13, #4
    v.splat      v2, s9
    s.addi       s9, s12, #2048                  // row 4
    @p4 v.st.h       [s15, #0], v1
    a.vread      v1, a1, s14
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.movz       s14, #5
    s.addi       s15, s13, #5
    v.splat      v1, s15
    s.addi       s15, s12, #2560                 // row 5
    @p3 v.st.h       [s19, #0], v3
    a.vread      v3, a1, s16
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.movz       s16, #6
    s.addi       s19, s13, #6
    v.splat      v3, s19
    s.addi       s19, s12, #3072                 // row 6
    @p4 v.st.h       [s20, #0], v2
    a.vread      v2, a1, s11
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.movz       s11, #7
    s.addi       s20, s13, #7
    v.splat      v2, s20
    s.addi       s20, s12, #3584                 // row 7
    @p3 v.st.h       [s9, #0], v1
    a.vread      v1, a1, s14
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.movz       s9, #8
    s.addi       s14, s13, #8
    v.splat      v1, s14
    s.addi       s14, s12, #4096                 // row 8
    @p4 v.st.h       [s15, #0], v3
    a.vread      v3, a1, s16
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.movz       s15, #9
    s.addi       s16, s13, #9
    v.splat      v3, s16
    s.addi       s16, s12, #4608                 // row 9
    @p3 v.st.h       [s19, #0], v2
    a.vread      v2, a1, s11
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.movz       s11, #10
    s.addi       s19, s13, #10
    v.splat      v2, s19
    s.addi       s19, s12, #5120                 // row 10
    @p4 v.st.h       [s20, #0], v1
    a.vread      v1, a1, s9
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.movz       s9, #11
    s.addi       s20, s13, #11
    v.splat      v1, s20
    s.addi       s20, s12, #5632                 // row 11
    @p3 v.st.h       [s14, #0], v3
    a.vread      v3, a1, s15
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.movz       s14, #12
    s.addi       s15, s13, #12
    v.splat      v3, s15
    s.addi       s15, s12, #6144                 // row 12
    @p4 v.st.h       [s16, #0], v2
    a.vread      v2, a1, s11
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.movz       s11, #13
    s.addi       s16, s13, #13
    v.splat      v2, s16
    s.addi       s16, s12, #6656                 // row 13
    @p3 v.st.h       [s19, #0], v1
    a.vread      v1, a1, s9
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.movz       s9, #14
    s.addi       s19, s13, #14
    v.splat      v1, s13
    v.splat      v5, s19
    s.addi       s19, s12, #7168                 // row 14
    s.addi       s21, s12, #7680                 // row 15
    @p4 v.st.h       [s20, #0], v3
    a.vread      v3, a1, s14
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.movz       s12, #15
    s.addi       s14, s13, #15
    v.splat      v3, s1
    v.splat      v6, s14
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s14, #0
    @p3 v.st.h       [s15, #0], v2
    a.vread      v2, a1, s11
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.add        s11, s14, s17                   // the tile origin
    s.muli       s15, s17, #2                    // a runtime tile origin, x2
    v.splat      v2, s11
    s.muli       s11, s10, #512                  // a runtime tile origin, x512
    s.movz       s17, #1
    v.add        v7, v0, v2
    s.add        s20, s8, s15                    // the tile origin
    s.add        s15, s20, s11                   // the tile origin
    @p4 v.st.h       [s16, #0], v5
    a.vread      v2, a1, s9
    v.cmp.lt     p1, v6, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v2
    v.cmp.lt     p1, v1, v4
    s.addi       s9, s13, #1
    s.addi       s11, s15, #512                  // row 1
    v.splat      v1, s9
    s.movz       s9, #2
    s.addi       s16, s13, #2
    v.splat      v2, s16
    s.addi       s16, s15, #1024                 // row 2
    @p3 v.st.h       [s19, #0], v5
    a.vread      v5, a1, s12
    v.cmp.lt     p2, v7, v3
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v5
    s.movz       s12, #3
    s.addi       s19, s13, #3
    v.splat      v5, s19
    s.addi       s19, s15, #1536                 // row 3
    @p4 v.st.h       [s21, #0], v3
    a.vread      v3, a2, s14
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.movz       s14, #4
    s.addi       s20, s13, #4
    v.splat      v3, s20
    s.addi       s20, s15, #2048                 // row 4
    @p3 v.st.h       [s15, #0], v1
    a.vread      v1, a2, s17
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.movz       s17, #5
    @p4 v.st.h       [s11, #0], v2
    a.vread      v1, a2, s9
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s9, s13, #5
    s.addi       s11, s15, #2560                 // row 5
    v.splat      v1, s9
    s.movz       s9, #6
    @p3 v.st.h       [s16, #0], v2
    a.vread      v2, a2, s12
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s12, s13, #6
    s.addi       s16, s15, #3072                 // row 6
    v.splat      v2, s12
    s.movz       s12, #7
    @p4 v.st.h       [s19, #0], v3
    a.vread      v3, a2, s14
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s14, s13, #7
    s.addi       s19, s15, #3584                 // row 7
    v.splat      v3, s14
    s.movz       s14, #8
    @p3 v.st.h       [s20, #0], v1
    a.vread      v1, a2, s17
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s17, s13, #8
    s.addi       s20, s15, #4096                 // row 8
    v.splat      v1, s17
    s.movz       s17, #9
    @p4 v.st.h       [s11, #0], v2
    a.vread      v2, a2, s9
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s9, s13, #9
    s.addi       s11, s15, #4608                 // row 9
    v.splat      v2, s9
    s.movz       s9, #10
    @p3 v.st.h       [s16, #0], v3
    a.vread      v3, a2, s12
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s12, s13, #10
    s.addi       s16, s15, #5120                 // row 10
    v.splat      v3, s12
    s.movz       s12, #11
    @p4 v.st.h       [s19, #0], v1
    a.vread      v1, a2, s14
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s14, s13, #11
    s.addi       s19, s15, #5632                 // row 11
    v.splat      v1, s14
    s.movz       s14, #12
    @p3 v.st.h       [s20, #0], v2
    a.vread      v2, a2, s17
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s17, s13, #12
    s.addi       s20, s15, #6144                 // row 12
    v.splat      v2, s17
    s.movz       s17, #13
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a2, s9
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s9, s13, #13
    s.addi       s11, s15, #6656                 // row 13
    v.splat      v3, s9
    s.movz       s9, #14
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a2, s12
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s12, s13, #14
    s.addi       s16, s15, #7168                 // row 14
    v.splat      v1, s12
    s.movz       s12, #15
    s.addi       s21, s15, #7680                 // row 15
    s.muli       s15, s10, #512                  // a runtime tile origin, x512
    v.splat      v5, s13
    @p4 v.st.h       [s19, #0], v2
    a.vread      v2, a2, s14
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s10, s13, #15
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s14, #0
    v.splat      v2, s10
    s.add        s10, s14, s18                   // the tile origin
    s.muli       s19, s18, #2                    // a runtime tile origin, x2
    v.splat      v6, s10
    v.splat      v7, s1
    s.movz       s1, #1
    v.add        v8, v0, v6
    @p3 v.st.h       [s20, #0], v3
    a.vread      v0, a2, s17
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v0
    s.add        s10, s8, s19                    // the tile origin
    s.addi       s17, s13, #1
    s.add        s18, s10, s15                   // the tile origin
    v.splat      v0, s17
    s.addi       s10, s18, #512                  // row 1
    s.movz       s15, #2
    s.addi       s17, s18, #1024                 // row 2
    @p4 v.st.h       [s11, #0], v1
    a.vread      v1, a2, s9
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    v.cmp.lt     p1, v5, v4
    s.addi       s9, s13, #2
    s.movz       s11, #3
    v.splat      v1, s9
    s.addi       s9, s18, #1536                  // row 3
    @p3 v.st.h       [s16, #0], v2
    a.vread      v2, a2, s12
    v.cmp.lt     p2, v8, v7
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s12, s13, #3
    s.movz       s16, #4
    v.splat      v2, s12
    s.addi       s12, s18, #2048                 // row 4
    @p4 v.st.h       [s21, #0], v3
    a.vread      v3, a3, s14
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v3
    s.addi       s14, s13, #4
    s.movz       s19, #5
    v.splat      v3, s14
    s.addi       s14, s13, #5
    s.addi       s20, s18, #2560                 // row 5
    v.splat      v5, s14
    s.movz       s14, #6
    @p3 v.st.h       [s18, #0], v0
    a.vread      v0, a3, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s13, #6
    s.addi       s21, s18, #3072                 // row 6
    v.splat      v0, s1
    s.movz       s1, #7
    @p4 v.st.h       [s10, #0], v1
    a.vread      v1, a3, s15
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s10, s13, #7
    s.addi       s15, s18, #3584                 // row 7
    v.splat      v1, s10
    s.movz       s10, #8
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a3, s11
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s11, s13, #8
    s.addi       s17, s18, #4096                 // row 8
    v.splat      v2, s11
    s.movz       s11, #9
    @p4 v.st.h       [s9, #0], v3
    a.vread      v3, a3, s16
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v3
    s.addi       s9, s13, #9
    s.addi       s16, s18, #4608                 // row 9
    v.splat      v3, s9
    s.movz       s9, #10
    @p3 v.st.h       [s12, #0], v5
    a.vread      v5, a3, s19
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v0, v5
    s.addi       s12, s13, #10
    s.addi       s19, s18, #5120                 // row 10
    v.splat      v5, s12
    s.movz       s12, #11
    @p4 v.st.h       [s20, #0], v0
    a.vread      v0, a3, s14
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v0
    s.addi       s14, s13, #11
    s.addi       s20, s18, #5632                 // row 11
    v.splat      v0, s14
    s.movz       s14, #12
    @p3 v.st.h       [s21, #0], v1
    a.vread      v1, a3, s1
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s1, s13, #12
    s.addi       s21, s18, #6144                 // row 12
    v.splat      v1, s1
    s.movz       s1, #13
    @p4 v.st.h       [s15, #0], v2
    a.vread      v2, a3, s10
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s10, s13, #13
    s.addi       s15, s18, #6656                 // row 13
    v.splat      v2, s10
    s.movz       s10, #14
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a3, s11
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v3
    s.addi       s11, s13, #14
    s.addi       s17, s18, #7168                 // row 14
    v.splat      v3, s11
    s.movz       s11, #15
    @p4 v.st.h       [s16, #0], v5
    a.vread      v5, a3, s9
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v5
    s.addi       s9, s13, #15
    s.addi       s13, s18, #7680                 // row 15
    v.splat      v5, s9
    s.addi       s9, s4, #16
    @p3 v.st.h       [s19, #0], v0
    a.vread      v0, a3, s12
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v0
    s.movz       s12, #64
    @p4 v.st.h       [s20, #0], v1
    a.vread      v0, a3, s14
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v0
    @p3 v.st.h       [s21, #0], v1
    a.vread      v0, a3, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v0
    @p4 v.st.h       [s15, #0], v1
    a.vread      v0, a3, s10
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v0
    @p3 v.st.h       [s17, #0], v1
    a.vread      v0, a3, s11
    vf.cvt.f32.bf16 v1, v0
    @p4 v.st.h       [s13, #0], v1
    s.mov        s4, s9
    s.cmp.lt     s1, s4, s12
    br.nz        s1, rows_1
endrows_2:
    exit
    exit
