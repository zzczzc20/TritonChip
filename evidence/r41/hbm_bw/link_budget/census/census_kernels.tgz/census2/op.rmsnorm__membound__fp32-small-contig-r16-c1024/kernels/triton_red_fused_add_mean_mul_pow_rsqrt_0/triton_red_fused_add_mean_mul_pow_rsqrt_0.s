    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.movi       v0, #0
    v.movi       v1, #0
    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s5, #1024
    s.movz       s6, #16
    v.splat      v2, s4
    v.iota       v2                              // arange(0, VLEN)
    s.addi       s7, s2, #0
    s.ld.d       s8, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s9, [s1, #16]                   // out_ptr1: device_ptr64 at arg_base+16
    v.mov        v1, v0
for_1:
    s.cmp.ge     s1, s7, s5
    br.nz        s1, endfor_2
    s.mul        s1, s4, s5
    v.splat      v0, s7
    v.movi       v3, #1024
    v.movi       v4, #0
    v.add        v5, v0, v2
    s.add        s10, s7, s1
    v.splat      v0, s1
    s.shli       s1, s10, #2                     // element offset -> bytes (x4)
    v.cmp.lt     p1, v5, v3
    s.add        s10, s3, s1                     // &in_ptr0[...]
    s.add        s1, s7, s6
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v3, [s10, #0]
    s.movz       s10, #1
    v.add        v6, v5, v0
    vf.mul       v0, v3, v3
    vf.add       v3, v1, v0
    @p1 v.sel        v0, v3, v1
    v.mov        v4, v0
    v.mov        v1, v4
    s.mov        s7, s1
    br.nz        s10, for_1
endfor_2:
    vf.reduce.add.b v0, v1
    v.movi       v1, #0
    s.addi       s1, s2, #0
    vf.add       v3, v0, v1
for_3:
    s.cmp.ge     s2, s1, s5
    br.nz        s2, endfor_4
    .li       s2, #1149239296
    v.splat      v0, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1065353216
    v.splat      v1, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #925353388
    v.splat      v4, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    s.mul        s2, s4, s5
    v.splat      v6, s1
    v.movi       v7, #1024
    .li       s7, #1077936128
    v.splat      v8, s7                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v9, v6, v2
    s.add        s7, s1, s2
    .li       s10, #3204448256
    v.splat      v6, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s10, s7, #2                     // element offset -> bytes (x4)
    v.cmp.lt     p1, v9, v7
    s.add        s7, s3, s10                     // &in_ptr0[...]
    s.shli       s11, s1, #2                     // element offset -> bytes (x4)
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v7, [s7, #0]
    s.add        s7, s8, s11                     // &in_ptr1[...]
    v.splat      v10, s2
    s.add        s2, s9, s10                     // &out_ptr1[...]
    s.add        s10, s1, s6
    s.movz       s11, #1
    v.add        v11, v9, v10
    vf.fms       v9, v0, v5, v1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v0, [s7, #0]
    vf.fms       v1, v5, v9, v5
    vf.neg       v9, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v9, v9
    @p2 v.sel        v1, v9, v5
    vf.mul       v5, v3, v1                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v1, v5, v4
    v.rsqrt.approx v4, v1                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v4, v4
    vf.mul       v9, v4, v6
    vf.fms       v6, v1, v5, v8
    vf.mul       v1, v9, v6                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v5, v1, v4
    v.extract    s7, v5, #0
    v.splat      v1, s7
    vf.mul       v4, v7, v1
    vf.mul       v1, v4, v0
    @p1 v.st.w       [s2, #0], v1
    s.mov        s1, s10
    br.nz        s11, for_3
endfor_4:
__rctx_next:
    exit
