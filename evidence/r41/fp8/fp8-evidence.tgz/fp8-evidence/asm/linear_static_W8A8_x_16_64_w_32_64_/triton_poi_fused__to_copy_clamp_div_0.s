    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.shli       s2, s4, #4                      // x16 as a shift
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s2
    v.movi       v2, #1024
    s.shli       s4, s2, #1                      // element offset -> bytes (x2)
    v.add        v3, v1, v0
    .li       s5, #1065353216
    v.splat      v0, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s5, #3286237184
    v.splat      v1, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.lt     p1, v3, v2
    .li       s5, #1138753536
    v.splat      v2, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v3, #24
    s.ld.w       s5, [s3, #0]                    // one element, not a vector
    v.movi       v4, #128
    s.shli       s3, s2, #0                      // element offset -> bytes (x1)
    v.splat      v5, s5
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.rcp.approx v6, v5                          // ISA 8.8: <= 2**-22 relative
    s.add        s5, s2, s4                      // &in_ptr0[...]
    s.ld.d       s2, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    @p1 v.ld.h       v7, [s5, #0]
    s.add        s1, s2, s3                      // &out_ptr0[...]
    vf.fms       v8, v5, v6, v0
    vf.fms       v0, v6, v8, v6
    vf.cvt.bf16.f32 v5, v7
    vf.neg       v7, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v7, v7
    @p2 v.sel        v0, v7, v6
    vf.mul       v6, v5, v0                      // a/y as a refined reciprocal (ISA has no divide)
    vf.max.prop  v0, v6, v1
    vf.min.prop  v1, v0, v2
    v.lshr       v0, v1, v3
    vf.cvt.f32.e4m3 v2, v1
    v.and        v1, v0, v4
    v.or         v0, v2, v1                      // f32 -> f8E4M3FN: a NaN keeps its sign
    @p1 v.st.b       [s1, #0], v0
__rctx_next:
    exit
