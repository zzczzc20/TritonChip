    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.shli       s2, s4, #4                      // x16 as a shift
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.shli       s4, s2, #1                      // element offset -> bytes (x2)
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s2
    v.add        v2, v1, v0
    s.ld.d       s2, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.add        s5, s3, s4                      // &in_ptr0[...]
    s.add        s3, s2, s4                      // &in_ptr1[...]
    v.ld.h       v0, [s5, #0]
    v.ld.h       v1, [s3, #0]
    vf.cvt.bf16.f32 v2, v0
    vf.cvt.bf16.f32 v0, v1
    s.ld.d       s2, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    vf.mul       v1, v2, v0
    vf.cvt.f32.bf16 v0, v1
    s.add        s1, s2, s4                      // &out_ptr0[...]
    v.st.h       [s1, #0], v0
__rctx_next:
    exit
