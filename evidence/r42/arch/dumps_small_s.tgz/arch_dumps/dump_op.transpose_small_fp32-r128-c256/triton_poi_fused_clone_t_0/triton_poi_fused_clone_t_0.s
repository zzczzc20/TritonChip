    s.rdspecial  s1, role_id
    s.rdspecial  s2, npid.x
__rctx_program:
    s.shli       s3, s1, #4                      // x16 as a shift
    s.rdspecial  s4, pid.y
    s.rdspecial  s5, arg_base
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s6, #0
    s.muli       s7, s3, #256                    // a runtime tile origin, x256
    s.shli       s8, s4, #4                      // x16 as a shift
    s.ld.d       s4, [s5, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s9, #256
    s.add        s10, s6, s3                     // the tile origin
    s.add        s11, s6, s8                     // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s9
    v.splat      v2, s10
    s.add        s9, s11, s7                     // the tile origin
    v.mul        v3, v0, v1
    v.splat      v1, s9
    v.add        v4, v0, v2
    v.splat      v0, s11
    v.add        v2, v3, v1
    v.cmpi.lt    p1, v4, #128
    v.cmpi.lt    p2, v0, #256
    p.and        p3, p1, p2
    s.addi       s7, s9, #1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s4, v2]               // index is in elements (ISA sec 9.1)
    s.addi       s10, s11, #1
    v.splat      v1, s7
    v.splat      v2, s10
    s.addi       s7, s9, #2
    v.add        v4, v3, v1
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    s.addi       s10, s11, #2
    v.splat      v1, s7
    v.splat      v2, s10
    s.movz       s7, #1
    v.add        v5, v3, v1
    v.cmpi.lt    p2, v2, #256
    p.and        p4, p1, p2
    s.addi       s10, s9, #3
    s.addi       s12, s11, #3
    v.splat      v1, s10
    s.ld.d       s10, [s5, #8]                   // out_ptr0: device_ptr64 at arg_base+8
    a.vwrite     a0, s6, v0
    v.splat      v0, s12
    v.add        v2, v3, v1
    s.movz       s5, #2
    s.addi       s6, s9, #4
    s.addi       s12, s11, #4
    v.splat      v1, s6
    v.splat      v6, s12
    s.movz       s6, #3
    v.add        v7, v3, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v1, [s4, v4]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v0, #256
    p.and        p3, p1, p2
    s.addi       s12, s9, #5
    s.addi       s13, s11, #5
    v.splat      v0, s12
    v.splat      v4, s13
    s.movz       s12, #4
    v.add        v8, v3, v0
    s.addi       s13, s9, #6
    s.addi       s14, s11, #6
    a.vwrite     a0, s7, v1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s4, v5]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v6, #256
    p.and        p4, p1, p2
    v.splat      v1, s13
    v.splat      v5, s14
    s.movz       s7, #5
    v.add        v6, v3, v1
    s.addi       s13, s9, #7
    s.addi       s14, s11, #7
    a.vwrite     a0, s5, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s4, v2]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v4, #256
    p.and        p3, p1, p2
    v.splat      v1, s13
    v.splat      v2, s14
    s.movz       s5, #6
    v.add        v4, v3, v1
    s.addi       s13, s9, #8
    s.addi       s14, s11, #8
    a.vwrite     a0, s6, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s4, v7]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v5, #256
    p.and        p4, p1, p2
    v.splat      v1, s13
    v.splat      v5, s14
    s.movz       s6, #7
    v.add        v7, v3, v1
    s.addi       s13, s9, #9
    s.addi       s14, s11, #9
    a.vwrite     a0, s12, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s4, v8]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.splat      v1, s13
    v.splat      v2, s14
    s.movz       s12, #8
    v.add        v8, v3, v1
    s.addi       s13, s9, #10
    s.addi       s14, s11, #10
    a.vwrite     a0, s7, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s4, v6]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v5, #256
    p.and        p4, p1, p2
    v.splat      v1, s13
    v.splat      v5, s14
    s.movz       s7, #9
    v.add        v6, v3, v1
    s.addi       s13, s9, #11
    s.addi       s14, s11, #11
    a.vwrite     a0, s5, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s4, v4]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.splat      v1, s13
    v.splat      v2, s14
    s.movz       s5, #10
    v.add        v4, v3, v1
    s.addi       s13, s9, #12
    s.addi       s14, s11, #12
    a.vwrite     a0, s6, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s4, v7]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v5, #256
    p.and        p4, p1, p2
    v.splat      v1, s13
    v.splat      v5, s14
    s.movz       s6, #11
    v.add        v7, v3, v1
    s.addi       s13, s9, #13
    s.addi       s14, s11, #13
    a.vwrite     a0, s12, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s4, v8]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.splat      v1, s13
    v.splat      v2, s14
    s.movz       s12, #12
    v.add        v8, v3, v1
    s.addi       s13, s9, #14
    s.addi       s14, s11, #14
    a.vwrite     a0, s7, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s4, v6]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v5, #256
    p.and        p4, p1, p2
    v.splat      v1, s13
    v.splat      v5, s14
    s.movz       s7, #13
    v.add        v6, v3, v1
    s.addi       s13, s9, #15
    s.addi       s9, s11, #15
    s.movz       s14, #14
    a.vwrite     a0, s5, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s4, v4]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.splat      v1, s13
    v.splat      v2, s9
    s.muli       s5, s3, #4                      // a runtime tile origin, x4
    v.add        v4, v3, v1
    s.muli       s3, s8, #512                    // a runtime tile origin, x512
    v.splat      v1, s11
    s.movz       s8, #15
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s9, #0
    s.add        s13, s10, s5                    // the tile origin
    s.add        s5, s13, s3                     // the tile origin
    a.vwrite     a0, s6, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s4, v7]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v5, #256
    p.and        p4, p1, p2
    s.addi       s3, s11, #1
    s.movz       s6, #1
    v.splat      v3, s3
    s.addi       s3, s5, #512                    // row 1
    a.vwrite     a0, s12, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s4, v8]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    s.addi       s10, s11, #2
    s.movz       s12, #2
    v.splat      v2, s10
    s.addi       s10, s5, #1024                  // row 2
    s.movz       s13, #3
    a.vwrite     a0, s7, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s4, v6]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #256
    p.and        p4, p1, p2
    s.addi       s7, s11, #3
    v.splat      v1, s7
    s.addi       s7, s5, #1536                   // row 3
    a.vwrite     a0, s14, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s4, v4]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v3, #256
    p.and        p3, p1, p2
    s.addi       s4, s11, #4
    s.movz       s14, #4
    v.splat      v3, s4
    s.addi       s4, s11, #5
    v.splat      v4, s4
    s.addi       s4, s5, #2048                   // row 4
    a.vwrite     a0, s8, v0
    a.vread      v0, a0, s9
    s.movz       s8, #5
    s.addi       s9, s11, #6
    @p4 v.st.w       [s5, #0], v0
    a.vread      v0, a0, s6
    v.cmpi.lt    p2, v2, #256
    p.and        p4, p1, p2
    v.splat      v2, s9
    s.addi       s6, s5, #2560                   // row 5
    s.movz       s9, #6
    @p3 v.st.w       [s3, #0], v0
    a.vread      v0, a0, s12
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    s.addi       s3, s11, #7
    s.addi       s12, s5, #3072                  // row 6
    v.splat      v1, s3
    s.movz       s3, #7
    @p4 v.st.w       [s10, #0], v0
    a.vread      v0, a0, s13
    v.cmpi.lt    p2, v3, #256
    p.and        p4, p1, p2
    s.addi       s10, s11, #8
    s.addi       s13, s5, #3584                  // row 7
    v.splat      v3, s10
    s.movz       s10, #8
    @p3 v.st.w       [s7, #0], v0
    a.vread      v0, a0, s14
    v.cmpi.lt    p2, v4, #256
    p.and        p3, p1, p2
    s.addi       s7, s11, #9
    s.addi       s14, s5, #4096                  // row 8
    v.splat      v4, s7
    s.movz       s7, #9
    @p4 v.st.w       [s4, #0], v0
    a.vread      v0, a0, s8
    v.cmpi.lt    p2, v2, #256
    p.and        p4, p1, p2
    s.addi       s4, s11, #10
    s.addi       s8, s5, #4608                   // row 9
    v.splat      v2, s4
    s.movz       s4, #10
    @p3 v.st.w       [s6, #0], v0
    a.vread      v0, a0, s9
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    s.addi       s6, s11, #11
    s.addi       s9, s5, #5120                   // row 10
    v.splat      v1, s6
    s.movz       s6, #11
    @p4 v.st.w       [s12, #0], v0
    a.vread      v0, a0, s3
    v.cmpi.lt    p2, v3, #256
    p.and        p4, p1, p2
    s.addi       s3, s11, #12
    s.addi       s12, s5, #5632                  // row 11
    v.splat      v3, s3
    s.movz       s3, #12
    @p3 v.st.w       [s13, #0], v0
    a.vread      v0, a0, s10
    v.cmpi.lt    p2, v4, #256
    p.and        p3, p1, p2
    s.addi       s10, s11, #13
    s.addi       s13, s5, #6144                  // row 12
    v.splat      v4, s10
    s.movz       s10, #13
    @p4 v.st.w       [s14, #0], v0
    a.vread      v0, a0, s7
    v.cmpi.lt    p2, v2, #256
    p.and        p4, p1, p2
    s.addi       s7, s11, #14
    s.addi       s14, s5, #6656                  // row 13
    v.splat      v2, s7
    s.movz       s7, #14
    s.addi       s15, s11, #15
    v.splat      v5, s15
    s.addi       s11, s5, #7168                  // row 14
    s.addi       s15, s5, #7680                  // row 15
    @p3 v.st.w       [s8, #0], v0
    a.vread      v0, a0, s4
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    s.movz       s4, #15
    @p4 v.st.w       [s9, #0], v0
    a.vread      v0, a0, s6
    v.cmpi.lt    p2, v3, #256
    p.and        p4, p1, p2
    @p3 v.st.w       [s12, #0], v0
    a.vread      v0, a0, s3
    v.cmpi.lt    p2, v4, #256
    p.and        p3, p1, p2
    @p4 v.st.w       [s13, #0], v0
    a.vread      v0, a0, s10
    v.cmpi.lt    p2, v2, #256
    p.and        p4, p1, p2
    @p3 v.st.w       [s14, #0], v0
    a.vread      v0, a0, s7
    v.cmpi.lt    p2, v5, #256
    p.and        p3, p1, p2
    @p4 v.st.w       [s11, #0], v0
    a.vread      v0, a0, s4
    @p3 v.st.w       [s15, #0], v0
__rctx_next:
    s.addi       s3, s1, #2                      // the next program of this context: + 2
    s.cmp.lt     s4, s3, s2
    s.mov        s1, s3
    br.nz        s4, __rctx_program
    exit
