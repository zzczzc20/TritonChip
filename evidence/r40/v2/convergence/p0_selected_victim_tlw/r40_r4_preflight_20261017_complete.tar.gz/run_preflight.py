from pathlib import Path
import subprocess,json,os,sys,hashlib
root=Path.cwd();out=root/'preflight_results';out.mkdir(exist_ok=False)
record=json.loads((root/'preflight_manifest.json').read_text());record['steps']=[]
def step(name,args,cap):
 with (out/(name+'.log')).open('x') as log:
  p=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=cap)
 item={'name':name,'command':args,'exit_code':p.returncode,'log':name+'.log','log_sha256':hashlib.sha256((out/(name+'.log')).read_bytes()).hexdigest()};record['steps'].append(item);(out/'report.json').write_text(json.dumps(record,indent=2)+'\n');print(name,p.returncode,flush=True);return p.returncode==0
assert step('environment',[sys.executable,'-c','import sys,torch,triton;print(sys.version);print(torch.__version__);print(triton.__version__)'],120)
assert step('ownership',['python3','tools/r40/multicore_dma_tests.py','--cores','3','--ports','3','--pipeline','2','--board-top'],1800)
assert step('native_controls',[sys.executable,'tools/r40/native_memory_control_tests.py'],7200)
assert step('backend',[sys.executable,'tools/r36/backend_tests.py'],1800)
print('R40_INTEGRATED_PREFLIGHT_DONE_NO_ACCEPTANCE_CREDIT',flush=True)
