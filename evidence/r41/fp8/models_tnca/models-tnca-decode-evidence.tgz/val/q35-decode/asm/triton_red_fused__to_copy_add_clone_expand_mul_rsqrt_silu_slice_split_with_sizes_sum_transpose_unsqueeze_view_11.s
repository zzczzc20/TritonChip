    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.splat      v0, s4
    v.movi       v1, #17
    v.movi       v2, #0
    s.rdspecial  s1, arg_base
    v.sub        v3, v2, v0
    v.sub        v4, v2, v1
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.iota       v5                              // arange(0, VLEN)
    v.movi       v6, #1
    s.ld.d       s3, [s1, #8]                    // out_ptr1: device_ptr64 at arg_base+8
    @p1 v.sel        v7, v3, v0
    @p2 v.sel        v3, v4, v1
    v.movi       v4, #0
    v.movi       v8, #0
    s.movz       s1, #31
idiv_1:
    v.splat      v9, s1
    v.shl        v10, v8, v6
    v.lshr       v11, v7, v9
    v.cmp.lt     p2, v8, v2
    v.and        v12, v11, v6
    v.shl        v11, v6, v9
    v.or         v9, v10, v12
    s.subi       s4, s1, #1
    v.cmp.geu    p3, v9, v3
    p.or         p4, p2, p3
    v.sub        v10, v9, v3
    @p4 v.sel        v12, v11, v2
    @p4 v.sel        v11, v10, v9
    v.or         v9, v4, v12
    v.mov        v8, v11
    v.mov        v4, v9
    s.mov        s1, s4
    s.movz       s4, #0
    s.cmp.ge     s5, s1, s4
    br.nz        s5, idiv_1
    v.movi       v3, #0
    v.sub        v4, v2, v8
    v.sub        v2, v3, v0
    v.sub        v6, v3, v1
    v.cmp.lt     p2, v0, v3
    v.cmp.lt     p3, v1, v3
    @p1 v.sel        v7, v4, v8
    v.movi       v4, #1
    @p2 v.sel        v8, v2, v0
    @p3 v.sel        v0, v6, v1
    v.movi       v1, #0
    v.movi       v2, #0
    s.movz       s1, #31
idiv_2:
    v.splat      v6, s1
    v.shl        v9, v2, v4
    v.lshr       v10, v8, v6
    v.cmp.lt     p1, v2, v3
    v.and        v11, v10, v4
    v.shl        v10, v4, v6
    v.or         v6, v9, v11
    s.subi       s4, s1, #1
    v.cmp.geu    p4, v6, v0
    p.or         p5, p1, p4
    v.sub        v9, v6, v0
    @p5 v.sel        v11, v10, v3
    @p5 v.sel        v10, v9, v6
    v.or         v6, v1, v11
    v.mov        v2, v10
    v.mov        v1, v6
    s.mov        s1, s4
    s.movz       s4, #0
    s.cmp.ge     s5, s1, s4
    br.nz        s5, idiv_2
    p.xor        p1, p2, p3
    v.sub        v0, v3, v1
    s.movz       s1, #0
    v.movi       v2, #0
    v.movi       v3, #0
    @p1 v.sel        v4, v0, v1
    s.movz       s4, #128
    s.movz       s5, #16
    s.addi       s6, s1, #0
    v.mov        v3, v2
for_3:
    s.cmp.ge     s7, s6, s4
    br.nz        s7, endfor_4
    v.movi       v0, #0
    v.movi       v1, #1
    v.sub        v2, v0, v4
    v.cmp.lt     p1, v4, v0
    @p1 v.sel        v6, v2, v4
    v.movi       v2, #128
    v.lshr       v8, v6, v1
    v.movi       v1, #8192
    v.sub        v6, v0, v8
    v.splat      v9, s6
    @p1 v.sel        v10, v6, v8
    v.mul        v6, v7, v1
    v.mul        v1, v10, v2
    v.add        v2, v9, v5
    v.extract    s7, v1, #0
    v.splat      v1, s7
    v.extract    s7, v6, #0
    v.add        v6, v2, v1
    v.splat      v1, s7
    v.movi       v8, #128
    v.add        v9, v6, v1
    v.cmp.lt     p1, v2, v8
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s2, v9]               // index is in elements (ISA sec 9.1)
    v.movi       v2, #2
    v.movi       v6, #0
    v.sub        v8, v0, v2
    s.add        s7, s6, s5
    s.movz       s8, #1
    vf.cvt.bf16.f32 v9, v1
    v.cmp.lt     p2, v2, v0
    v.movi       v0, #1
    @p2 v.sel        v0, v8, v2
    vf.mul       v0, v9, v9
    s.movz       s9, #8192
    vf.add       v1, v3, v0
    @p1 v.sel        v0, v1, v3
    v.mov        v6, v0
    v.mov        v3, v6
    s.mov        s6, s7
    br.nz        s8, for_3
endfor_4:
    vf.reduce.add.b v0, v3
    v.movi       v1, #0
    s.addi       s6, s1, #0
    vf.add       v2, v0, v1
for_5:
    s.cmp.ge     s1, s6, s4
    br.nz        s1, endfor_6
    .li       s1, #897988541
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v1, #0
    vf.add       v3, v2, v0
    v.sub        v0, v1, v4
    v.cmp.lt     p1, v4, v1
    @p1 v.sel        v6, v0, v4
    v.rsqrt.approx v0, v3                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #1
    v.movi       v9, #128
    v.lshr       v10, v6, v8
    v.movi       v6, #8192
    v.sub        v8, v1, v10
    v.splat      v11, s6
    @p1 v.sel        v12, v8, v10
    v.mul        v8, v7, v6
    v.mul        v10, v12, v9
    v.add        v12, v11, v5
    v.extract    s1, v10, #0
    v.splat      v10, s1
    .li       s1, #1077936128
    v.splat      v11, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #3204448256
    v.splat      v13, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.extract    s1, v8, #0
    v.add        v8, v12, v10
    v.splat      v10, s1
    v.movi       v14, #128
    v.add        v15, v8, v10
    v.cmp.lt     p1, v12, v14
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v8, [s2, v15]              // index is in elements (ISA sec 9.1)
    v.mul        v10, v7, v9
    v.mul        v9, v4, v6
    v.extract    s1, v10, #0
    .li       s7, #1035273459
    v.splat      v6, s7                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v10, s1
    vf.mul       v14, v0, v0
    vf.mul       v15, v0, v13
    vf.cvt.bf16.f32 v13, v8
    v.extract    s1, v9, #0
    vf.fms       v8, v3, v14, v11
    v.movi       v3, #2
    v.add        v9, v12, v10
    v.splat      v10, s1
    vf.mul       v11, v15, v8                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.sub        v8, v1, v3
    v.add        v12, v9, v10
    v.cmp.lt     p2, v3, v1
    vf.cmp.o     p3, v11, v11
    @p3 v.sel        v1, v11, v0
    v.movi       v0, #1
    v.extract    s1, v1, #0
    v.splat      v0, s1
    s.add        s1, s6, s5
    vf.mul       v1, v13, v0
    s.movz       s7, #1
    @p2 v.sel        v0, v8, v3
    s.movz       s8, #8192
    vf.mul       v0, v1, v6
    @p1 v.st.scatter.w [s3, v12], v0
    s.mov        s6, s1
    br.nz        s7, for_5
endfor_6:
__rctx_next:
    exit
