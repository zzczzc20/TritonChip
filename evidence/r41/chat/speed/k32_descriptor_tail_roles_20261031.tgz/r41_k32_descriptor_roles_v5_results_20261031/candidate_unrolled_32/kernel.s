    // R39-12: role0 on even contexts, role1 on odd ones (ROLE_ID mod 2)
    s.rdspecial  s61, role_id
    s.andi       s61, s61, #1
    br.nz        s61, __tnca_role1
    w.def        w0, #56, #8                     // v56..v63
    w.def        w1, #48, #8                     // v48..v55
    .li       s1, #196608
    td.load      d0, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    .li       s1, #196864
    td.load      d1, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    // role 0: partition P (load/transfer). 1 k step(s) over a 1-slot RF channel.
    // k step 0: slot 0, generation 1
    mb.arm       s1, b0, #0, #2                  // 0 arrival(s), 2 operation(s)
    .li       s2, #0
    .li       s3, #0
    s.mov        s4, s2                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s5, s3                          // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w0, d0, s4, s1
    .li       s2, #0
    .li       s3, #0
    s.mov        s4, s2                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s5, s3                          // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w1, d1, s4, s1
    exit
__tnca_role1:
    // role 1: partitions M (matrix, and the epilogue merged in because this target has 4 Role Contexts -- sec 7.6)
    m.zero       a0
    // k step 0: slot 0, generation 1
    .li       s1, #65536          // b0 generation 1 (ISA sec 9A.2)
    mb.wait      s1
    mb.arm       s2, b2, #0, #1                  // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a0, v56, v48, s2
    mb.wait      s2
    mb.arm       s3, b1, #1, #0                  // 1 arrival(s), 0 operation(s)
    mb.arrive    b1
    // epilogue: the accumulator leaves a row at a time
    .li       s4, #393216
    .li       s5, #0
    a.vread      v0, a0, s5
    v.st.w       [s4, #0], v0
    .li       s5, #1
    a.vread      v0, a0, s5
    s.addi       s5, s4, #64
    v.st.w       [s5, #0], v0
    .li       s5, #2
    a.vread      v0, a0, s5
    s.addi       s5, s4, #128
    v.st.w       [s5, #0], v0
    .li       s5, #3
    a.vread      v0, a0, s5
    s.addi       s5, s4, #192
    v.st.w       [s5, #0], v0
    .li       s5, #4
    a.vread      v0, a0, s5
    s.addi       s5, s4, #256
    v.st.w       [s5, #0], v0
    .li       s5, #5
    a.vread      v0, a0, s5
    s.addi       s5, s4, #320
    v.st.w       [s5, #0], v0
    .li       s5, #6
    a.vread      v0, a0, s5
    s.addi       s5, s4, #384
    v.st.w       [s5, #0], v0
    .li       s5, #7
    a.vread      v0, a0, s5
    s.addi       s5, s4, #448
    v.st.w       [s5, #0], v0
    .li       s5, #8
    a.vread      v0, a0, s5
    s.addi       s5, s4, #512
    v.st.w       [s5, #0], v0
    .li       s5, #9
    a.vread      v0, a0, s5
    s.addi       s5, s4, #576
    v.st.w       [s5, #0], v0
    .li       s5, #10
    a.vread      v0, a0, s5
    s.addi       s5, s4, #640
    v.st.w       [s5, #0], v0
    .li       s5, #11
    a.vread      v0, a0, s5
    s.addi       s5, s4, #704
    v.st.w       [s5, #0], v0
    .li       s5, #12
    a.vread      v0, a0, s5
    s.addi       s5, s4, #768
    v.st.w       [s5, #0], v0
    .li       s5, #13
    a.vread      v0, a0, s5
    s.addi       s5, s4, #832
    v.st.w       [s5, #0], v0
    .li       s5, #14
    a.vread      v0, a0, s5
    s.addi       s5, s4, #896
    v.st.w       [s5, #0], v0
    .li       s5, #15
    a.vread      v0, a0, s5
    s.addi       s5, s4, #960
    v.st.w       [s5, #0], v0
    exit
