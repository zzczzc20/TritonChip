    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    s.rdspecial  s2, arg_base
    v.add        v3, v1, v0
    v.movi       v0, #1023
    s.ld.d       s3, [s2, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    s.shli       s4, s1, #2                      // element offset -> bytes (x4)
    @p1 v.sel        v4, v1, v3
    .li       s1, #1065353216
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v3, #1024
    v.and        v5, v4, v0
    v.sub        v0, v2, v3
    v.sub        v4, v2, v5
    s.ld.d       s1, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.cmp.lt     p2, v3, v2
    @p1 v.sel        v2, v4, v5
    @p2 v.sel        v4, v0, v3
    v.ld.gather.w v0, [s3, v2]                   // index is in elements (ISA sec 9.1)
    s.add        s3, s1, s4                      // &in_ptr0[...]
    v.rcp.approx v2, v0                          // ISA 8.8: <= 2**-22 relative
    v.ld.w       v3, [s3, #0]
    s.ld.d       s1, [s2, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    vf.fms       v4, v0, v2, v1
    s.add        s2, s1, s4                      // &out_ptr0[...]
    vf.fms       v0, v2, v4, v2
    vf.neg       v1, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v0, v1, v2
    vf.mul       v1, v3, v0                      // a/y as a refined reciprocal (ISA has no divide)
    v.st.w       [s2, #0], v1
__rctx_next:
    exit
