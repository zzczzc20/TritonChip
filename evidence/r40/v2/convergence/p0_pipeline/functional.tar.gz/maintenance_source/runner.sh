source ~/tc_env/env.sh
cd /tmp/r40_p0_maintenance_source
python3 run.py > /tmp/r40_p0_maintenance.log 2>&1
echo $? > /tmp/r40_p0_maintenance.exit
