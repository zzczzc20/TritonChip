    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #6
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    @p1 v.sel        v4, v1, v3
    s.rdspecial  s1, arg_base
    v.lshr       v1, v4, v0
    s.ld.d       s2, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.sub        v0, v2, v1
    v.movi       v4, #512
    @p1 v.sel        v5, v0, v1
    v.cmp.lt     p1, v3, v4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v0, [s2, v5]               // index is in elements (ISA sec 9.1)
    v.movi       v1, #0
    v.movi       v4, #63
    v.sub        v6, v1, v3
    v.cmp.lt     p2, v3, v1
    @p2 v.sel        v7, v6, v3
    v.movi       v3, #64
    v.and        v6, v7, v4
    v.movi       v4, #128
    v.sub        v7, v1, v6
    v.mul        v8, v5, v4
    @p2 v.sel        v4, v7, v6
    s.ld.d       s2, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.add        v5, v4, v3
    v.add        v6, v4, v8
    v.add        v7, v5, v8
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    .li       s4, #1124073472
    v.splat      v8, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s4, #1065353216
    v.splat      v9, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v10, v8                         // ISA 8.8: <= 2**-22 relative
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v11, [s2, v7]              // index is in elements (ISA sec 9.1)
    v.sub        v7, v1, v3
    v.sub        v12, v2, v3
    v.cmp.lt     p2, v3, v1
    v.cmp.lt     p3, v3, v2
    @p2 v.sel        v1, v7, v3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s3, v5]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v2, v11
    @p3 v.sel        v5, v12, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v3, [s2, v6]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v5, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s3, v4]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v4, v3
    vf.cvt.bf16.f32 v3, v1
    s.ld.d       s2, [s1, #24]                   // out_ptr0: device_ptr64 at arg_base+24
    vf.fms       v1, v8, v10, v9
    s.ld.d       s3, [s1, #32]                   // out_ptr1: device_ptr64 at arg_base+32
    .li       s1, #897988541
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v9, v10, v1, v10
    .li       s1, #1077936128
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #3204448256
    v.splat      v11, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.neg       v12, v9                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v12, v12
    @p2 v.sel        v9, v12, v10
    vf.mul       v10, v0, v9                     // a/y: faithful quotient
    vf.fms       v12, v10, v8, v0
    vf.fms       v0, v12, v9, v10
    vf.neg       v8, v0                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v8, v8
    @p2 v.sel        v0, v8, v10
    vf.add       v8, v0, v7
    v.rsqrt.approx v0, v8                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v7, v0, v0
    vf.mul       v9, v0, v11
    vf.fms       v10, v8, v7, v1
    vf.mul       v1, v9, v10                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v7, v1, v0
    vf.mul       v0, v2, v7
    vf.mul       v1, v4, v7
    vf.mul       v2, v5, v0
    vf.mul       v0, v3, v1
    vf.neg       v1, v2
    vf.cvt.f32.bf16 v2, v0
    vf.cvt.f32.bf16 v0, v1
    @p1 v.st.scatter.h [s2, v6], v0
    @p1 v.st.scatter.h [s3, v6], v2
__rctx_next:
    exit
