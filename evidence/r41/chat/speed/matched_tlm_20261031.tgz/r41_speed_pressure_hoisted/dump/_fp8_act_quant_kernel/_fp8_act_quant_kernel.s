    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.movz       s2, #16
    s.ld.d       s3, [s1, #0]                    // x_ptr: device_ptr64 at arg_base+0
    s.movz       s5, #32
    s.movz       s6, #48
    s.movz       s7, #64
    s.movz       s8, #80
    s.movz       s9, #96
    s.movz       s10, #112
    s.shli       s11, s4, #7                     // x128 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #16
    v.movi       v2, #32
    v.iota       v3                              // arange(0, VLEN)
    v.movi       v4, #48
    v.movi       v5, #64
    v.movi       v6, #80
    v.iota       v7                              // arange(0, VLEN)
    v.movi       v8, #96
    v.movi       v9, #112
    s.add        s12, s2, s11
    s.add        s2, s5, s11
    s.add        s5, s6, s11
    s.add        s6, s7, s11
    s.add        s7, s8, s11
    s.add        s8, s9, s11
    s.add        s9, s10, s11
    v.add        v10, v0, v1
    v.add        v1, v0, v2
    v.add        v2, v3, v4
    v.add        v4, v3, v5
    v.add        v5, v3, v6
    v.add        v3, v7, v8
    v.add        v6, v7, v9
    v.movi       v7, #128
    s.shli       s10, s11, #1                    // element offset -> bytes (x2)
    s.ld.d       s13, [s1, #8]                   // y_ptr: device_ptr64 at arg_base+8
    s.add        s14, s3, s10                    // &x_ptr[...]
    v.cmp.lt     p1, v0, v7
    v.cmp.lt     p2, v10, v7
    v.splat      v8, s11
    v.add        v9, v8, v0
    v.add        v9, v8, v10
    v.add        v9, v8, v1
    v.add        v9, v8, v2
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v9, [s14, #0]
    v.add        v11, v8, v4
    v.add        v11, v8, v5
    v.add        v11, v8, v3
    v.add        v11, v8, v6
    s.ld.d       s10, [s1, #16]                  // s_ptr: device_ptr64 at arg_base+16
    s.shli       s1, s12, #1                     // element offset -> bytes (x2)
    v.movi       v8, #128
    s.shli       s14, s2, #1                     // element offset -> bytes (x2)
    s.shli       s15, s5, #1                     // element offset -> bytes (x2)
    v.movi       v11, #128
    s.shli       s16, s6, #1                     // element offset -> bytes (x2)
    s.shli       s17, s7, #1                     // element offset -> bytes (x2)
    v.movi       v12, #128
    s.add        s18, s3, s1                     // &x_ptr[...]
    s.add        s1, s3, s14                     // &x_ptr[...]
    s.add        s14, s3, s15                    // &x_ptr[...]
    s.add        s15, s3, s16                    // &x_ptr[...]
    s.add        s16, s3, s17                    // &x_ptr[...]
    v.cmp.lt     p1, v1, v8
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s18, #0]
    s.shli       s17, s8, #1                     // element offset -> bytes (x2)
    v.cmp.lt     p2, v2, v8
    s.add        s18, s3, s17                    // &x_ptr[...]
    vf.cvt.bf16.f32 v14, v9
    vf.abs       v9, v14
    v.movi       v15, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v15, [s1, #0]
    s.shli       s1, s9, #1                      // element offset -> bytes (x2)
    v.cmp.lt     p1, v4, v11
    s.add        s17, s3, s1                     // &x_ptr[...]
    vf.cvt.bf16.f32 v16, v13
    vf.reduce.max.b v13, v9
    vf.abs       v9, v16
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v17, [s14, #0]
    .li       s1, #1138753536
    v.splat      v18, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.lt     p2, v5, v11
    vf.cvt.bf16.f32 v19, v15
    v.rcp.approx v15, v18                        // ISA 8.8: <= 2**-22 relative
    .li       s1, #1065353216
    v.splat      v20, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.reduce.max.b v21, v9
    vf.abs       v9, v19
    vf.max       v22, v13, v21
    vf.reduce.max.b v13, v9
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v9, [s15, #0]
    v.cmp.lt     p1, v3, v12
    vf.cvt.bf16.f32 v21, v17
    vf.abs       v17, v21
    vf.reduce.max.b v23, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v17, [s16, #0]
    v.cmp.lt     p2, v6, v12
    vf.cvt.bf16.f32 v24, v9
    vf.max       v9, v13, v23
    vf.fms       v13, v18, v15, v20
    vf.abs       v23, v24
    vf.max       v25, v22, v9
    vf.fms       v9, v15, v13, v15
    vf.reduce.max.b v13, v23
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v22, [s18, #0]
    vf.cvt.bf16.f32 v23, v17
    vf.neg       v17, v9                         // Newton step: r0*(2 - x*r0)
    .li       s1, #730643660
    v.splat      v9, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.abs       v26, v23
    vf.cmp.o     p1, v17, v17
    @p1 v.sel        v27, v17, v15
    vf.reduce.max.b v15, v26
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v17, [s17, #0]
    vf.cvt.bf16.f32 v26, v22
    vf.max       v22, v13, v15
    vf.abs       v13, v26
    vf.reduce.max.b v15, v13
    vf.cvt.bf16.f32 v13, v17
    vf.abs       v17, v13
    vf.reduce.max.b v28, v17
    vf.max       v17, v15, v28
    vf.max       v15, v22, v17
    vf.max       v17, v25, v15
    vf.mul       v15, v17, v27                   // a/y: faithful quotient
    vf.fms       v22, v15, v18, v17
    vf.fms       v17, v22, v27, v15
    vf.neg       v18, v17                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v18, v18
    @p1 v.sel        v17, v18, v15
    vf.max.ieee  v15, v17, v9
    v.rcp.approx v9, v15                         // ISA 8.8: <= 2**-22 relative
    v.rcp.approx v18, v15                        // ISA 8.8: <= 2**-22 relative
    v.rcp.approx v22, v15                        // ISA 8.8: <= 2**-22 relative
    v.rcp.approx v25, v15                        // ISA 8.8: <= 2**-22 relative
    v.rcp.approx v27, v15                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v28, v15, v9, v20
    vf.fms       v29, v15, v18, v20
    vf.fms       v30, v15, v22, v20
    vf.fms       v31, v15, v25, v20
    vf.fms       v32, v9, v28, v9
    vf.fms       v28, v18, v29, v18
    vf.fms       v29, v22, v30, v22
    vf.fms       v30, v25, v31, v25
    vf.neg       v31, v32                        // Newton step: r0*(2 - x*r0)
    vf.neg       v32, v28                        // Newton step: r0*(2 - x*r0)
    vf.neg       v28, v29                        // Newton step: r0*(2 - x*r0)
    vf.neg       v29, v30                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v31, v31
    vf.cmp.o     p2, v32, v32
    @p1 v.sel        v30, v31, v9
    vf.fms       v9, v15, v27, v20
    vf.cmp.o     p1, v28, v28
    @p2 v.sel        v31, v32, v18
    vf.cmp.o     p2, v29, v29
    @p1 v.sel        v18, v28, v22
    vf.fms       v22, v27, v9, v27
    @p2 v.sel        v9, v29, v25
    vf.mul       v25, v14, v30                   // a/y: faithful quotient
    vf.mul       v28, v16, v31                   // a/y: faithful quotient
    vf.mul       v29, v19, v18                   // a/y: faithful quotient
    vf.neg       v32, v22                        // Newton step: r0*(2 - x*r0)
    vf.fms       v22, v25, v15, v14
    vf.fms       v14, v28, v15, v16
    vf.fms       v16, v29, v15, v19
    vf.cmp.o     p1, v32, v32
    @p1 v.sel        v19, v32, v27
    vf.mul       v27, v21, v9                    // a/y: faithful quotient
    vf.fms       v32, v22, v30, v25
    vf.mul       v22, v24, v19                   // a/y: faithful quotient
    vf.fms       v30, v14, v31, v28
    vf.fms       v14, v16, v18, v29
    vf.fms       v16, v27, v15, v21
    vf.neg       v18, v32                        // a/y: one correction to the IEEE quotient
    vf.fms       v21, v22, v15, v24
    vf.neg       v24, v30                        // a/y: one correction to the IEEE quotient
    vf.neg       v30, v14                        // a/y: one correction to the IEEE quotient
    vf.fms       v14, v16, v9, v27
    vf.cmp.o     p1, v18, v18
    vf.fms       v9, v21, v19, v22
    vf.cmp.o     p2, v24, v24
    @p1 v.sel        v16, v18, v25
    v.rcp.approx v18, v15                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v19, v14                        // a/y: one correction to the IEEE quotient
    vf.neg       v14, v9                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v30, v30
    @p2 v.sel        v9, v24, v28
    v.rcp.approx v21, v15                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p2, v19, v19
    @p1 v.sel        v24, v30, v29
    v.rcp.approx v25, v15                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v14, v14
    @p2 v.sel        v28, v19, v27
    @p1 v.sel        v19, v14, v22
    v.movi       v14, #24
    v.movi       v22, #128
    vf.cvt.f32.e4m3 v27, v16
    v.lshr       v29, v16, v14
    v.lshr       v16, v9, v14
    v.lshr       v30, v24, v14
    vf.cvt.f32.e4m3 v31, v9
    vf.cvt.f32.e4m3 v9, v24
    v.and        v24, v29, v22
    v.and        v29, v16, v22
    v.and        v16, v30, v22
    v.or         v30, v27, v24                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.or         v24, v31, v29                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v27, v15, v18, v20
    v.or         v29, v9, v16                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v9, v15, v21, v20
    vf.fms       v16, v18, v27, v18
    vf.cvt.f32.e4m3 v27, v28
    vf.fms       v31, v15, v25, v20
    vf.fms       v20, v21, v9, v21
    vf.neg       v9, v16                         // Newton step: r0*(2 - x*r0)
    v.lshr       v16, v28, v14
    vf.fms       v28, v25, v31, v25
    vf.neg       v31, v20                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v20, v9, v18
    vf.neg       v9, v28                         // Newton step: r0*(2 - x*r0)
    v.and        v18, v16, v22
    vf.cmp.o     p1, v31, v31
    @p1 v.sel        v16, v31, v21
    vf.mul       v21, v23, v20                   // a/y: faithful quotient
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v28, v9, v25
    vf.mul       v9, v26, v16                    // a/y: faithful quotient
    vf.cvt.f32.e4m3 v25, v19
    vf.mul       v31, v13, v28                   // a/y: faithful quotient
    vf.fms       v32, v21, v15, v23
    v.lshr       v23, v19, v14
    vf.fms       v19, v9, v15, v26
    v.or         v26, v27, v18                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v18, v31, v15, v13
    vf.fms       v13, v32, v20, v21
    v.and        v15, v23, v22
    vf.fms       v20, v19, v16, v9
    vf.fms       v16, v18, v28, v31
    vf.neg       v18, v13                        // a/y: one correction to the IEEE quotient
    v.or         v13, v25, v15                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v15, v20                        // a/y: one correction to the IEEE quotient
    vf.neg       v19, v16                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v18, v18
    @p1 v.sel        v16, v18, v21
    vf.cmp.o     p1, v15, v15
    @p1 v.sel        v18, v15, v9
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v9, v19, v31
    v.lshr       v15, v16, v14
    v.lshr       v19, v18, v14
    v.lshr       v20, v9, v14
    vf.cvt.f32.e4m3 v14, v16
    vf.cvt.f32.e4m3 v16, v18
    vf.cvt.f32.e4m3 v18, v9
    v.and        v9, v15, v22
    v.and        v15, v19, v22
    v.and        v19, v20, v22
    s.shli       s1, s11, #0                     // element offset -> bytes (x1)
    s.shli       s3, s12, #0                     // element offset -> bytes (x1)
    s.shli       s11, s2, #0                     // element offset -> bytes (x1)
    s.shli       s2, s5, #0                      // element offset -> bytes (x1)
    s.shli       s5, s6, #0                      // element offset -> bytes (x1)
    s.shli       s6, s7, #0                      // element offset -> bytes (x1)
    s.shli       s7, s8, #0                      // element offset -> bytes (x1)
    s.shli       s8, s9, #0                      // element offset -> bytes (x1)
    s.shli       s9, s4, #2                      // element offset -> bytes (x4)
    v.iota       v20                             // arange(0, VLEN)
    v.or         v21, v14, v9                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.or         v9, v16, v15                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.or         v14, v18, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.add        s4, s13, s1                     // &y_ptr[...]
    s.add        s1, s13, s3                     // &y_ptr[...]
    s.add        s3, s13, s11                    // &y_ptr[...]
    s.add        s11, s13, s2                    // &y_ptr[...]
    s.add        s2, s13, s5                     // &y_ptr[...]
    s.add        s5, s13, s6                     // &y_ptr[...]
    s.add        s6, s13, s7                     // &y_ptr[...]
    s.add        s7, s13, s8                     // &y_ptr[...]
    s.add        s8, s10, s9                     // &s_ptr[...]
    v.cmp.lt     p1, v0, v7
    v.cmp.lt     p2, v10, v7
    @p1 v.st.b       [s4, #0], v30
    v.cmp.lt     p1, v1, v8
    @p2 v.st.b       [s1, #0], v24
    v.cmp.lt     p2, v2, v8
    @p1 v.st.b       [s3, #0], v29
    v.cmp.lt     p1, v4, v11
    @p2 v.st.b       [s11, #0], v26
    v.cmp.lt     p2, v5, v11
    @p1 v.st.b       [s2, #0], v13
    v.cmp.lt     p1, v3, v12
    @p2 v.st.b       [s5, #0], v21
    v.cmp.lt     p2, v6, v12
    @p1 v.st.b       [s6, #0], v9
    v.cmpi.lt    p1, v20, #1
    @p2 v.st.b       [s7, #0], v14
    @p1 v.st.w       [s8, #0], v17
__rctx_next:
    exit
