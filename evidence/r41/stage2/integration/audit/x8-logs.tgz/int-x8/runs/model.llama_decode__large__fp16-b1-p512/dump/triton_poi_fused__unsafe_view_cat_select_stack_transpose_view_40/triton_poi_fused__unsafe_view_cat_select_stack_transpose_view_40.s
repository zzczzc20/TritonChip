    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #0
    v.sub        v1, v2, v3
    s.rdspecial  s2, arg_base
    v.cmp.lt     p1, v3, v2
    v.sub        v4, v0, v3
    @p1 v.sel        v5, v1, v3
    v.movi       v1, #6
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.cmp.lt     p2, v3, v0
    @p2 v.sel        v6, v4, v3
    v.movi       v4, #63
    v.lshr       v7, v5, v1
    s.shli       s4, s1, #1                      // element offset -> bytes (x2)
    v.movi       v1, #512
    v.and        v5, v6, v4
    v.sub        v4, v2, v7
    s.add        s1, s3, s4                      // &in_ptr0[...]
    v.cmp.lt     p3, v3, v1
    v.sub        v1, v0, v5
    @p1 v.sel        v3, v4, v7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s1, #0]
    s.movz       s1, #32832
    v.splat      v6, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v7, #64
    @p2 v.sel        v8, v1, v5
    v.mul        v1, v3, v6
    v.sub        v3, v0, v7
    s.ld.d       s1, [s2, #16]                   // out_ptr1: device_ptr64 at arg_base+16
    v.sub        v5, v2, v7
    v.add        v6, v8, v1
    s.ld.d       s3, [s2, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.add        s2, s1, s4                      // &out_ptr1[...]
    v.cmp.lt     p1, v7, v0
    v.cmp.lt     p2, v7, v2
    @p1 v.sel        v0, v3, v7
    @p2 v.sel        v0, v5, v7
    @p3 v.st.scatter.h [s3, v6], v4
    @p3 v.st.h       [s2, #0], v4
__rctx_next:
    exit
