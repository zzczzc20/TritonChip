#!/bin/bash
set -u
source ~/tc_env/env.sh
cd ~/tritonchip-r40-convergence-8abf527 || exit 2
export PYTHONPATH=python:compiler/python:tools/asm CUDA_VISIBLE_DEVICES= OMP_NUM_THREADS=12 MKL_NUM_THREADS=12
~/tc_env/torchenv/bin/python -u -c 'exec(compile(open("/tmp/r40_independent_model_reference.py").read(),"/tmp/r40_independent_model_reference.py","exec"))'
r40_independent_rc=$?
printf '%s\n' "$r40_independent_rc" > /tmp/r40_independent_model_reference.exit
exit "$r40_independent_rc"
