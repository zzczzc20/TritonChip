# Paired module screen only: three actual caches plus replicated logical TMU, no cores/HBM.
if {[llength $argv]!=2} {error "expected SOURCE_ROOT FRESH_OUTPUT"}
set root [file normalize [lindex $argv 0]]
set out [file normalize [lindex $argv 1]]
if {[file exists $out]} {error "fresh output required"}
file mkdir $out
set_param general.maxThreads 2
set f [open $root/flow/fpga/tnca_range_grid_ooc.v r]
set wrapper [read $f]
close $f
set marker {// P1_CACHE_BOUNDARY_ATTRIBUTE: experiment varies only this instance attribute.}
if {[string first $marker $wrapper]<0} {error "cache boundary marker missing"}
set wrapper [string map [list $marker {(* KEEP_HIERARCHY = "yes" *)}] $wrapper]
set marker "input wire clk,"
if {[string first $marker $wrapper]<0} {error "clock port marker missing"}
set wrapper [string map [list $marker "input wire raw_clk,"] $wrapper]
set marker {wire [N*(76)-1:0] dco_cfg;}
if {[string first $marker $wrapper]<0} {error "clock insertion marker missing"}
set wrapper [string map [list $marker "wire clk;\nBUFG clock_buffer(.I(raw_clk),.O(clk));\n$marker"] $wrapper]
set f [open $out/wrapper.v {WRONLY CREAT EXCL}]
puts $f $wrapper
close $f
read_verilog -sv [list $root/rtl/nuca/tnca_tmu.v $root/rtl/nuca/tnca_replicated_tmu.v $root/rtl/nuca/tnca_nuca_slice.v $out/wrapper.v]
set_property include_dirs [list $root/rtl/common] [current_fileset]
synth_design -top tnca_range_grid_ooc -part xcu280-fsvh2892-2L-e \
    -mode out_of_context -flatten_hierarchy rebuilt \
    -generic {N=3 MAINTENANCE=1 FULL_LINE_TAG=1 TAG_W=5 DCO_REGISTERED_RANGES=1 SYNC_TAG_BANK=1 REGISTER_VICTIM_OWNER=1 BALANCED_VICTIM=1 SETS=32 SET_W=5}
create_clock -name clk -period 10 [get_ports raw_clk]
opt_design
report_utilization -hierarchical -file $out/optimized_utilization.rpt
report_timing -max_paths 30 -nworst 1 -path_type full_clock_expanded -file $out/optimized_paths.rpt
for {set tile 0} {$tile<3} {incr tile} {
    set name [format {g_tile[%d].u_slice} $tile]
    set matches [get_cells -hierarchical -quiet -filter [format {NAME == "%s"} $name]]
    if {[llength $matches]!=1} {error "missing cache boundary $name"}
    set block [create_pblock p0_cache$tile]
    resize_pblock $block -add SLR$tile
    add_cells_to_pblock $block $matches
}
for {set tile 0} {$tile<3} {incr tile} {
    set suffix [format {tmu/g_replica[%d].local_tmu} $tile]
    set tmu [get_cells -hierarchical -quiet -filter [format {NAME == "%s"} $suffix]]
    if {[llength $tmu]!=1} {error "expected exactly one local TMU: $suffix"}
    set block [create_pblock p1_local_tmu$tile]
    resize_pblock $block -add SLR$tile
    add_cells_to_pblock $block $tmu
}
place_design -directive SSI_SpreadSLLs
phys_opt_design
route_design
report_route_status -file $out/route_status.rpt
report_utilization -slr -file $out/utilization_slr.rpt
report_utilization -hierarchical -file $out/utilization_hierarchy.rpt
report_timing_summary -delay_type min_max -file $out/timing.rpt
report_timing -max_paths 30 -nworst 1 -path_type full_clock_expanded -file $out/critical_paths.rpt
check_timing -verbose -file $out/checks.rpt
# Check preserved state instances and actual locations, not assignment alone.
set f [open $out/tmu_state_locations.tsv {WRONLY CREAT EXCL}]
puts $f "replica\tcell\tprimitive\tloc\tslr"
for {set tile 0} {$tile<3} {incr tile} {
    set prefix [format {tmu/g_replica[%d].local_tmu/} $tile]
    set count 0
    foreach cell [get_cells -hierarchical -quiet -filter {IS_PRIMITIVE == 1}] {
        set name [get_property NAME $cell]
        set ref [get_property REF_NAME $cell]
        if {[string first $prefix $name]!=0 || ![regexp {^(FD|RAM|SRL)} $ref]} {continue}
        set slrs [get_property NAME [get_slrs -quiet -of_objects $cell]]
        if {$slrs ne "SLR$tile"} {error "local TMU state outside expected region: $name $slrs"}
        puts $f "$tile\t$name\t$ref\t[get_property LOC $cell]\t$slrs"
        incr count
    }
    if {$count<10} {error "replica state optimized away: $prefix"}
}
close $f
set owners [get_cells -hierarchical -quiet -filter {REF_NAME =~ "FD*" && NAME =~ "*victim_owner_q_reg*"}]
set selected [get_cells -hierarchical -quiet -filter {REF_NAME =~ "FD*" && NAME =~ "*selected_way_q_reg*"}]
set f [open $out/registered_boundaries.tsv {WRONLY CREAT EXCL}]
puts $f "kind\tcell\tprimitive\tloc"
foreach {kind cells} [list owner $owners selected_way $selected] {
    foreach cell $cells {puts $f "$kind\t[get_property NAME $cell]\t[get_property REF_NAME $cell]\t[get_property LOC $cell]"}
}
close $f
if {[llength $selected]} {
    report_timing -from $owners -to $selected -max_paths 10 -file $out/owner_to_selected.rpt
    report_timing -from $selected -max_paths 10 -file $out/selected_output.rpt
}
set f [open $out/tag_mapping.tsv {WRONLY CREAT EXCL}]
puts $f "cell\tprimitive\tis_primitive\tloc"
set tags [get_cells -hierarchical -quiet -filter {NAME =~ "*g_sync_tags*" && NAME =~ "*bank_reg*"}]
foreach name [get_property NAME $tags] ref [get_property REF_NAME $tags] primitive [get_property IS_PRIMITIVE $tags] loc [get_property LOC $tags] {
    puts $f "$name\t$ref\t$primitive\t$loc"
}
close $f
set f [open $out/scope.txt {WRONLY CREAT EXCL}]
puts $f "three actual slices and three cycle-equivalent copies of the logical TMU; no cores, NoC or HBM platform"
puts $f "10ns BUFG-driven clock; private cache and local TMU state in each SLR0/1/2; SSI_SpreadSLLs unchanged"
puts $f "external I/O timing unspecified; no full-image packing, clock/CDC/image or workload qualification"
puts $f "owner_flops [llength $owners]; selected_way_flops [llength $selected]; tag_mapping_rows [llength $tags]"
close $f
write_checkpoint $out/routed.dcp
puts "R40_REPLICATED_TMU_MODULE_SCREEN_DONE"
exit
