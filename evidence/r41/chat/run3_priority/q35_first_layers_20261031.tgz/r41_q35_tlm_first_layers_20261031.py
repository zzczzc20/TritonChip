#!/usr/bin/env python3
"""Capture whole-prefill hidden states for diagnostic CPU/DP-TLM comparisons.

Instrumentation changes the compiled graph; this is not an acceptance run.
"""
import argparse, hashlib, json, sys, time
from pathlib import Path
import torch
from safetensors.torch import save_file

p=argparse.ArgumentParser();p.add_argument('--mode',choices=['cpu','tlm'],required=True);p.add_argument('--tree',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--layers',type=int,default=2);a=p.parse_args()
sys.path[:0]=[str(a.tree/'tools/models'),str(a.tree),str(a.tree/'python'),str(a.tree/'compiler/python'),str(a.tree/'tools/asm')]
import chat
if a.mode=='tlm':chat.L.use_tnca(str(a.tree))
args=chat.parser().parse_args(['--model','q35','--device','cpu','--threads','4','--bucket','256','--new-tokens','1'])
start=time.monotonic();app=chat.ChatApplication(args)
chat.L.install_fp8_route('official' if a.mode=='tlm' else 'reference',dot='exact',scale_div='ieee')
all_layers=app.model.model.language_model.layers
if not 2 <= a.layers <= len(all_layers): raise ValueError('expected at least two layers')
app.model.model.language_model.layers=torch.nn.ModuleList(list(all_layers[:a.layers]))
prompt='My name is Alice. Please remember it and reply with one short sentence.'
inputs,text=chat.make_inputs(app.spec,app.processor,[chat.user_message(prompt)])
device='tnca' if a.mode=='tlm' else 'cpu'
skip=None if device=='tnca' else chat.L.vision_tower(app.model)
stage,dev=chat.L.place(chat.L.PrefillStage(app.model,all_logits=False,hidden_states=True),device,'eager',skip=skip)
cache=chat.L.make_cache(app.model,256,dev)
ids=inputs['input_ids'].clone(memory_format=torch.contiguous_format).to(dev)
pos=chat.L.prefill_position_ids(app.model,inputs).clone(memory_format=torch.contiguous_format).to(dev)
with torch.no_grad(): out=stage(ids,pos,cache,None)
vals={'logits':out[0][0,-1].detach().cpu().contiguous()}
for i,x in enumerate(out[1:]): vals[f'hidden_{i:02d}']=x.detach().cpu().contiguous()
a.out.mkdir(parents=True,exist_ok=False);save_file(vals,str(a.out/'states.safetensors'))
result={'schema':'r41-q35-instrumented-whole-layers/1','scope':'truncated diagnostic model; hidden_00 is embedding, hidden_01 is first-layer output; final state has final norm; not board/acceptance','layers':a.layers,'mode':a.mode,'model':app.spec.name,'revision':app.spec.revision,'prompt':prompt,'prompt_text':text,'input_ids':inputs['input_ids'].tolist(),'chat_sha256':hashlib.sha256((a.tree/'tools/models/chat.py').read_bytes()).hexdigest(),'seconds':time.monotonic()-start,'shapes':{k:list(v.shape) for k,v in vals.items()},'versions':chat.L.versions()}
(a.out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
