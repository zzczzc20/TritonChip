    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #4
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    @p1 v.sel        v4, v1, v3
    v.movi       v1, #0
    v.lshr       v5, v4, v0
    v.movi       v0, #0
    v.sub        v4, v2, v5
    v.sub        v6, v1, v3
    @p1 v.sel        v7, v4, v5
    v.movi       v4, #0
    v.cmp.lt     p1, v3, v1
    v.cmp.lt     p2, v3, v0
    @p1 v.sel        v5, v6, v3
    v.movi       v6, #15
    v.sub        v8, v4, v7
    v.cmp.lt     p3, v7, v4
    v.and        v9, v5, v6
    @p3 v.sel        v5, v8, v7
    v.movi       v6, #63
    v.sub        v8, v1, v9
    v.and        v10, v5, v6
    v.movi       v5, #16
    @p1 v.sel        v6, v8, v9
    v.sub        v8, v4, v10
    v.movi       v9, #64
    @p3 v.sel        v11, v8, v10
    s.rdspecial  s1, arg_base
    v.sub        v8, v0, v3
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    @p2 v.sel        v10, v8, v3
    v.movi       v8, #2048
    v.movi       v12, #1024
    v.cmp.lt     p1, v3, v8
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.movi       v3, #10
    v.movi       v8, #32
    v.lshr       v13, v10, v3
    v.add        v3, v6, v5
    v.cmp.lt     p3, v5, v1
    v.mul        v10, v11, v9
    v.sub        v11, v1, v5
    v.cmp.lt     p4, v5, v2
    v.sub        v1, v2, v5
    @p3 v.sel        v2, v11, v5
    v.sub        v2, v0, v13
    v.mul        v11, v7, v8
    @p2 v.sel        v7, v2, v13
    v.sub        v2, v4, v9
    v.mul        v13, v7, v8
    v.sub        v7, v0, v12
    v.add        v8, v3, v13
    v.add        v3, v6, v11
    v.add        v6, v8, v10
    v.cmp.lt     p2, v9, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v4, [s2, v6]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v12, v0
    @p4 v.sel        v0, v1, v5
    @p2 v.sel        v0, v2, v9
    @p3 v.sel        v0, v7, v12
    vf.cvt.f16.f32 v0, v4
    vf.neg       v1, v0
    vf.cvt.f32.f16 v0, v1
    @p1 v.st.scatter.h [s3, v3], v0
__rctx_next:
    exit
