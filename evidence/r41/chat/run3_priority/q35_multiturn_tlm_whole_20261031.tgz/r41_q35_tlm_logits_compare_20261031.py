#!/usr/bin/env python3
import argparse,json
from pathlib import Path
import torch
from safetensors.torch import load_file
p=argparse.ArgumentParser();p.add_argument('--candidate',type=Path,required=True);p.add_argument('--reference',type=Path,required=True);p.add_argument('--path',choices=['whole','grouped_chunk8'],required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
r=json.loads((a.reference/'result.json').read_text());t=json.loads((a.candidate/'result.json').read_text())
for k in ('prompt','input_ids','model','revision'):
 if r[k]!=t[k]:raise ValueError(f'reference/candidate metadata differs: {k}')
xraw=load_file(str(a.candidate/'logits.safetensors'))[a.path].contiguous().flatten(); x=xraw.float();refs=load_file(str(a.reference/'logits.safetensors'))
out={'schema':'r41-q35-first-logits-compare/1','scope':'full-checkpoint CPU vs DP TLM; board logits not captured', 'candidate_path':a.path,'input_ids':t['input_ids'],'candidate_top5':t['paths'][a.path]['logits'],'comparisons':{}}
for name in ('whole','grouped_chunk8'):
 yraw=refs[name].contiguous().flatten(); y=yraw.float()
 if x.shape!=y.shape or not torch.isfinite(x).all() or not torch.isfinite(y).all():raise ValueError('invalid logits')
 
 if xraw.dtype != yraw.dtype:raise ValueError('logits dtype mismatch')
 itype={2:torch.int16,4:torch.int32}.get(xraw.element_size())
 if itype is None:raise ValueError('unsupported logits width')
 d=x-y;out['comparisons'][name]={'reference_top5':r['paths'][name]['logits'],'rel_l2':float(torch.linalg.vector_norm(d)/torch.linalg.vector_norm(y)),'max_abs':float(d.abs().max()),'argmax_equal':bool(x.argmax()==y.argmax()),'bit_mismatches':int((xraw.view(itype)!=yraw.view(itype)).sum()),'elements':int(x.numel())}
a.out.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n');print(json.dumps(out,indent=2,ensure_ascii=False))
