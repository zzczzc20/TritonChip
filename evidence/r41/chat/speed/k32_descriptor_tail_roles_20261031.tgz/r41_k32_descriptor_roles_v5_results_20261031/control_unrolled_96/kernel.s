    // R39-12: role0 on even contexts, role1 on odd ones (ROLE_ID mod 2)
    s.rdspecial  s61, role_id
    s.andi       s61, s61, #1
    br.nz        s61, __tnca_role1
    w.def        w0, #60, #4                     // v60..v63
    w.def        w1, #56, #4                     // v56..v59
    w.def        w2, #52, #4                     // v52..v55
    w.def        w3, #48, #4                     // v48..v51
    .li       s1, #196608
    td.load      d0, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    .li       s1, #196864
    td.load      d1, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    // role 0: partition P (load/transfer). 6 k step(s) over a 2-slot RF channel.
    // k step 0: slot 0, generation 1
    mb.arm       s1, b0, #0, #2                  // 0 arrival(s), 2 operation(s)
    .li       s2, #0
    .li       s3, #0
    s.mov        s4, s2                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s5, s3                          // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w0, d0, s4, s1
    .li       s2, #0
    .li       s3, #0
    s.mov        s4, s2                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s5, s3                          // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w2, d1, s4, s1
    // k step 1: slot 1, generation 1
    mb.arm       s2, b1, #0, #2                  // 0 arrival(s), 2 operation(s)
    .li       s3, #0
    .li       s4, #16
    s.mov        s5, s3                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s6, s4                          // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w1, d0, s5, s2
    .li       s3, #16
    .li       s4, #0
    s.mov        s5, s3                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s6, s4                          // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w3, d1, s5, s2
    // k step 2: slot 0, generation 2
    .li       s3, #65538          // b2 generation 1 (ISA sec 9A.2)
    mb.wait      s3
    mb.arm       s4, b0, #0, #2                  // 0 arrival(s), 2 operation(s)
    .li       s5, #0
    .li       s6, #32
    s.mov        s7, s5                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s8, s6                          // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w0, d0, s7, s4
    .li       s5, #32
    .li       s6, #0
    s.mov        s7, s5                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s8, s6                          // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w2, d1, s7, s4
    // k step 3: slot 1, generation 2
    .li       s5, #65539          // b3 generation 1 (ISA sec 9A.2)
    mb.wait      s5
    mb.arm       s6, b1, #0, #2                  // 0 arrival(s), 2 operation(s)
    .li       s7, #0
    .li       s8, #48
    s.mov        s9, s7                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s10, s8                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w1, d0, s9, s6
    .li       s7, #48
    .li       s8, #0
    s.mov        s9, s7                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s10, s8                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w3, d1, s9, s6
    // k step 4: slot 0, generation 3
    .li       s7, #131074          // b2 generation 2 (ISA sec 9A.2)
    mb.wait      s7
    mb.arm       s8, b0, #0, #2                  // 0 arrival(s), 2 operation(s)
    .li       s9, #0
    .li       s10, #64
    s.mov        s11, s9                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s12, s10                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w0, d0, s11, s8
    .li       s9, #64
    .li       s10, #0
    s.mov        s11, s9                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s12, s10                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w2, d1, s11, s8
    // k step 5: slot 1, generation 3
    .li       s9, #131075          // b3 generation 2 (ISA sec 9A.2)
    mb.wait      s9
    mb.arm       s10, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    .li       s11, #0
    .li       s12, #80
    s.mov        s13, s11                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s14, s12                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w1, d0, s13, s10
    .li       s11, #80
    .li       s12, #0
    s.mov        s13, s11                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s14, s12                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w3, d1, s13, s10
    exit
__tnca_role1:
    // role 1: partitions M (matrix, and the epilogue merged in because this target has 4 Role Contexts -- sec 7.6)
    m.zero       a0
    // k step 0: slot 0, generation 1
    .li       s1, #65536          // b0 generation 1 (ISA sec 9A.2)
    mb.wait      s1
    mb.arm       s2, b4, #0, #1                  // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k16.e4m3 a0, v60, v52, s2
    mb.wait      s2
    mb.arm       s3, b2, #1, #0                  // 1 arrival(s), 0 operation(s)
    mb.arrive    b2
    // k step 1: slot 1, generation 1
    .li       s4, #65537          // b1 generation 1 (ISA sec 9A.2)
    mb.wait      s4
    mb.arm       s5, b4, #0, #1                  // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k16.e4m3 a0, v56, v48, s5
    mb.wait      s5
    mb.arm       s6, b3, #1, #0                  // 1 arrival(s), 0 operation(s)
    mb.arrive    b3
    // k step 2: slot 0, generation 2
    .li       s7, #131072          // b0 generation 2 (ISA sec 9A.2)
    mb.wait      s7
    mb.arm       s8, b4, #0, #1                  // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k16.e4m3 a0, v60, v52, s8
    mb.wait      s8
    mb.arm       s9, b2, #1, #0                  // 1 arrival(s), 0 operation(s)
    mb.arrive    b2
    // k step 3: slot 1, generation 2
    .li       s10, #131073          // b1 generation 2 (ISA sec 9A.2)
    mb.wait      s10
    mb.arm       s11, b4, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k16.e4m3 a0, v56, v48, s11
    mb.wait      s11
    mb.arm       s12, b3, #1, #0                 // 1 arrival(s), 0 operation(s)
    mb.arrive    b3
    // k step 4: slot 0, generation 3
    .li       s13, #196608          // b0 generation 3 (ISA sec 9A.2)
    mb.wait      s13
    mb.arm       s14, b4, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k16.e4m3 a0, v60, v52, s14
    mb.wait      s14
    mb.arm       s15, b2, #1, #0                 // 1 arrival(s), 0 operation(s)
    mb.arrive    b2
    // k step 5: slot 1, generation 3
    .li       s16, #196609          // b1 generation 3 (ISA sec 9A.2)
    mb.wait      s16
    mb.arm       s17, b4, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k16.e4m3 a0, v56, v48, s17
    mb.wait      s17
    mb.arm       s18, b3, #1, #0                 // 1 arrival(s), 0 operation(s)
    mb.arrive    b3
    // epilogue: the accumulator leaves a row at a time
    .li       s19, #393216
    .li       s20, #0
    a.vread      v0, a0, s20
    v.st.w       [s19, #0], v0
    .li       s20, #1
    a.vread      v0, a0, s20
    s.addi       s20, s19, #64
    v.st.w       [s20, #0], v0
    .li       s20, #2
    a.vread      v0, a0, s20
    s.addi       s20, s19, #128
    v.st.w       [s20, #0], v0
    .li       s20, #3
    a.vread      v0, a0, s20
    s.addi       s20, s19, #192
    v.st.w       [s20, #0], v0
    .li       s20, #4
    a.vread      v0, a0, s20
    s.addi       s20, s19, #256
    v.st.w       [s20, #0], v0
    .li       s20, #5
    a.vread      v0, a0, s20
    s.addi       s20, s19, #320
    v.st.w       [s20, #0], v0
    .li       s20, #6
    a.vread      v0, a0, s20
    s.addi       s20, s19, #384
    v.st.w       [s20, #0], v0
    .li       s20, #7
    a.vread      v0, a0, s20
    s.addi       s20, s19, #448
    v.st.w       [s20, #0], v0
    .li       s20, #8
    a.vread      v0, a0, s20
    s.addi       s20, s19, #512
    v.st.w       [s20, #0], v0
    .li       s20, #9
    a.vread      v0, a0, s20
    s.addi       s20, s19, #576
    v.st.w       [s20, #0], v0
    .li       s20, #10
    a.vread      v0, a0, s20
    s.addi       s20, s19, #640
    v.st.w       [s20, #0], v0
    .li       s20, #11
    a.vread      v0, a0, s20
    s.addi       s20, s19, #704
    v.st.w       [s20, #0], v0
    .li       s20, #12
    a.vread      v0, a0, s20
    s.addi       s20, s19, #768
    v.st.w       [s20, #0], v0
    .li       s20, #13
    a.vread      v0, a0, s20
    s.addi       s20, s19, #832
    v.st.w       [s20, #0], v0
    .li       s20, #14
    a.vread      v0, a0, s20
    s.addi       s20, s19, #896
    v.st.w       [s20, #0], v0
    .li       s20, #15
    a.vread      v0, a0, s20
    s.addi       s20, s19, #960
    v.st.w       [s20, #0], v0
    exit
