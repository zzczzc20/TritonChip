# query_f06.tcl DCP OUT : census family F06 on a unit OOC checkpoint.
set dcp [lindex $argv 0]; set out [lindex $argv 1]
open_checkpoint $dcp
set fh [open $out w]
proc one {fh label from to} {
    set p [get_timing_paths -from $from -to $to -max_paths 1 -nworst 1 -setup]
    if {[llength $p]==0} { puts $fh "$label\tnone"; return }
    puts $fh [format "%s\tslack=%.3f\tdelay=%.3f\tlevels=%d\t%s -> %s" $label [get_property SLACK $p] \
        [get_property DATAPATH_DELAY $p] [get_property LOGIC_LEVELS $p] \
        [get_property PARENT_CELL [get_property STARTPOINT_PIN $p]] [get_property PARENT_CELL [get_property ENDPOINT_PIN $p]]]
}
set disp [get_cells -hier -filter {NAME =~ u_dispatch/*}]
set state [get_cells -hier -filter {IS_SEQUENTIAL && (NAME =~ u_dispatch/remaining_reg* || NAME =~ u_dispatch/done_valid_reg* || NAME =~ u_dispatch/done_status_reg* || NAME =~ u_dispatch/running_reg*)}]
one $fh "launch_to_state" [all_registers] $state
one $fh "any_to_remaining" [all_registers] [get_cells -hier -filter {IS_SEQUENTIAL && NAME =~ u_dispatch/remaining_reg*}]
one $fh "worst_into_dispatch" [all_registers] [get_cells -hier -filter {IS_SEQUENTIAL && NAME =~ u_dispatch/*}]
one $fh "worst_from_dispatch" [get_cells -hier -filter {IS_SEQUENTIAL && NAME =~ u_dispatch/*}] [all_registers]
close $fh
report_timing -to $state -max_paths 3 -nworst 1 -file ${out}.state_paths.rpt
