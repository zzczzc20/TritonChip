    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_A: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // arg_B: device_ptr64 at arg_base+16
    s.ld.d       s5, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s6, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s7, [s1, #40]                   // out_ptr1: device_ptr64 at arg_base+40
    s.rdspecial  s1, arg_base
    s.ld.d       s8, [s1, #48]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s9, #512
    s.mul        s10, s1, s9
    s.add        s1, s8, s10                     // this context's own scratch
    s.addi       s8, s1, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.st.d       [s8, #0], s3
    .li       s1, #2147483647
    s.st.d       [s8, #8], s1
    s.st.d       [s8, #16], s1
    s.movz       s3, #1024
    s.st.d       [s8, #48], s3
    s.movz       s9, #2
    s.st.d       [s8, #56], s9
    .li       s10, #68719476752
    s.st.d       [s8, #88], s10
    .li       s11, #8589934592
    s.st.d       [s8, #104], s11
    fence.release.device
    td.load      d0, [s8]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.rdspecial  s8, arg_base
    s.ld.d       s12, [s8, #48]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s8, role_id
    s.movz       s13, #512
    s.mul        s14, s8, s13
    s.add        s8, s12, s14                    // this context's own scratch
    s.addi       s12, s8, #256                   // TensorMap 1: a tile contiguous down its columns (built once, at entry)
    s.st.d       [s12, #0], s4
    s.st.d       [s12, #8], s1
    s.st.d       [s12, #16], s1
    s.st.d       [s12, #48], s3
    s.st.d       [s12, #56], s9
    s.st.d       [s12, #88], s10
    s.st.d       [s12, #104], s11
    fence.release.device
    td.load      d1, [s12]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #8
    s.movz       s3, #0
    s.cmp.lt     s4, s1, s3
    s.sub        s1, s3, s4
    s.movz       s4, #4
    s.movz       s8, #1
    s.rdspecial  s9, role_id
    s.rdspecial  s10, npid.x
__rctx_program:
    s.cmp.lt     s11, s9, s3
    s.addi       s12, s3, #0
    s.sub        s13, s3, s11
    s.addi       s11, s3, #0
    s.xor        s14, s9, s13
    s.xor        s15, s13, s1
    s.sub        s16, s14, s13
    s.lshri      s17, s16, #3
    s.mov        s12, s16
    s.xor        s18, s17, s15
    s.sub        s17, s18, s15
    s.sub        s15, s4, s17
    s.min.s      s18, s15, s8
    s.cmp.lt     s15, s18, s3
    s.sub        s19, s3, s15
    s.xor        s15, s18, s19
    s.sub        s18, s15, s19
    s.cmp.eq     s15, s18, s8
    br.nz        s15, sdiv_done_1
    s.movz       s20, #0
    s.movz       s21, #31
    s.mov        s12, s20
    s.addi       s22, s21, #0
sdiv_2:
    s.lshr       s21, s16, s22
    s.shli       s23, s11, #1
    s.andi       s24, s21, #1
    s.shl        s21, s8, s22
    s.or         s25, s23, s24
    s.cmp.geu    s23, s25, s18
    s.sub        s24, s20, s23
    s.and        s23, s18, s24
    s.and        s26, s21, s24
    s.sub        s11, s25, s23
    s.or         s12, s12, s26
    s.subi       s22, s22, #1
    s.cmp.ge     s21, s22, s20
    br.nz        s21, sdiv_2
sdiv_done_1:
    s.sub        s12, s14, s13
    s.xor        s14, s11, s13
    s.lshri      s11, s12, #3
    s.sub        s16, s14, s13
    s.muli       s14, s11, #8
    s.addi       s11, s3, #0
    s.add        s20, s17, s16
    s.addi       s16, s3, #0
    s.sub        s17, s12, s14
    s.xor        s12, s17, s13
    s.sub        s14, s12, s13
    s.cmp.lt     s12, s14, s3
    s.sub        s13, s3, s12
    s.xor        s12, s14, s13
    s.sub        s14, s12, s13
    s.mov        s11, s14
    br.nz        s15, sdiv_done_3
    s.movz       s12, #0
    s.movz       s15, #31
    s.mov        s11, s12
    s.addi       s17, s15, #0
    s.movz       s15, #1
sdiv_4:
    s.lshr       s21, s14, s17
    s.shli       s22, s16, #1
    s.andi       s23, s21, #1
    s.shl        s21, s15, s17
    s.or         s24, s22, s23
    s.cmp.geu    s22, s24, s18
    s.sub        s23, s12, s22
    s.and        s22, s18, s23
    s.and        s25, s21, s23
    s.sub        s16, s24, s22
    s.or         s11, s11, s25
    s.subi       s17, s17, #1
    s.cmp.ge     s21, s17, s12
    br.nz        s21, sdiv_4
sdiv_done_3:
    s.xor        s12, s13, s19
    s.movz       s13, #16
    s.xor        s14, s11, s12
    s.mul        s11, s20, s13
    s.sub        s15, s14, s12
    s.movz       s12, #0
    s.mul        s14, s15, s13
    s.movz       s15, #32
    s.andi       s16, s11, #63
    s.addi       s17, s12, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    s.andi       s18, s14, #127
for_5:
    s.cmp.ge     s19, s17, s15
    br.nz        s19, endfor_6
    s.mul        s19, s17, s13
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s20, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s21, s16                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s22, s19                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s21, s20
    w.def        w1, #48, #8                     // v48..v55
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s21, s18                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s22, s19                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s21, s20
    mb.wait      s20
gemm_pipe:
    mb.arm       s19, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s21, #1
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.dp.async.k16.f16 a0, v56, v48, s19
    s.add        s17, s17, s8
    s.cmp.ge     s21, s17, s15
    br.nz        s21, gemm_pipe_drain0
    s.mul        s21, s17, s13
    w.def        w2, #40, #8                     // v40..v47
    mb.arm       s22, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s23, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s23, s16                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s24, s21                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w2, d0, s23, s22
    w.def        w3, #32, #8                     // v32..v39
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s23, s18                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s24, s21                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w3, d1, s23, s22
    mb.wait      s22
    mb.wait      s19
    mb.arm       s21, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.dp.async.k16.f16 a0, v40, v32, s21
    s.add        s17, s17, s8
    s.cmp.ge     s23, s17, s15
    br.nz        s23, gemm_pipe_drain1
    s.mul        s23, s17, s13
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s24, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s25, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s26, s16                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s27, s23                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s26, s24
    w.def        w1, #48, #8                     // v48..v55
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s26, s18                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s27, s23                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s26, s24
    mb.wait      s24
    mb.wait      s21
    br.nz        s25, gemm_pipe
gemm_pipe_drain0:
    s.movz       s13, #1
    mb.wait      s19
    br.nz        s13, endfor_6
gemm_pipe_drain1:
    mb.wait      s21
endfor_6:
    s.add        s13, s12, s14                   // the tile origin
    s.muli       s15, s14, #2                    // a runtime tile origin, x2
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s13
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.add        s13, s12, s11                   // the tile origin
    s.movz       s14, #64
    s.movz       s16, #128
    s.muli       s17, s11, #256                  // a runtime tile origin, x256
    v.splat      v2, s13
    v.splat      v3, s14
    v.add        v4, v0, v1
    v.splat      v0, s16
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.add        s11, s5, s15                    // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.add        s14, s6, s15                    // the tile origin
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v4, v0
    s.add        s16, s2, s15                    // the tile origin
    s.add        s18, s11, s17                   // the tile origin
    s.add        s11, s14, s17                   // the tile origin
    p.and        p3, p1, p2
    s.addi       s14, s13, #1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s18, #0]
    v.splat      v1, s14
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.add        s14, s7, s15                    // the tile origin
    s.addi       s15, s18, #256                  // row 1
    v.cmp.lt     p1, v1, v3
    s.add        s23, s14, s17                   // the tile origin
    p.and        p4, p1, p2
    s.addi       s14, s11, #256                  // row 1
    s.movz       s17, #1
    s.addi       s25, s13, #2
    s.addi       s26, s23, #256                  // row 1
    v.splat      v1, s25
    s.addi       s25, s18, #512                  // row 2
    s.addi       s27, s11, #512                  // row 2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s11, #0]
    a.vread      v4, a0, s12
    vf.cvt.f16.f32 v5, v0
    s.movz       s12, #2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s16, #0]
    vf.cvt.f16.f32 v6, v2
    vf.add       v2, v5, v6
    vf.cvt.f16.f32 v5, v0
    vf.add       v0, v4, v5
    vf.cvt.f32.f16 v4, v0
    vf.cvt.f16.f32 v0, v4
    vf.add       v4, v2, v0
    vf.cvt.f32.f16 v0, v4
    @p3 v.st.h       [s23, #0], v0
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v0, [s15, #0]
    s.addi       s15, s13, #3
    v.splat      v1, s15
    s.addi       s15, s23, #512                  // row 2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s14, #0]
    a.vread      v4, a0, s17
    vf.cvt.f16.f32 v5, v0
    s.addi       s14, s18, #768                  // row 3
    s.addi       s17, s11, #768                  // row 3
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v0, [s16, #0]
    vf.cvt.f16.f32 v6, v2
    vf.add       v2, v5, v6
    vf.cvt.f16.f32 v5, v0
    vf.add       v0, v4, v5
    vf.cvt.f32.f16 v4, v0
    vf.cvt.f16.f32 v0, v4
    vf.add       v4, v2, v0
    vf.cvt.f32.f16 v0, v4
    @p4 v.st.h       [s26, #0], v0
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.movz       s26, #3
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s25, #0]
    s.addi       s25, s13, #4
    v.splat      v1, s25
    s.addi       s25, s23, #768                  // row 3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s27, #0]
    a.vread      v4, a0, s12
    vf.cvt.f16.f32 v5, v0
    s.addi       s12, s18, #1024                 // row 4
    s.addi       s27, s11, #1024                 // row 4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s16, #0]
    vf.cvt.f16.f32 v6, v2
    vf.add       v2, v5, v6
    vf.cvt.f16.f32 v5, v0
    vf.add       v0, v4, v5
    vf.cvt.f32.f16 v4, v0
    vf.cvt.f16.f32 v0, v4
    vf.add       v4, v2, v0
    vf.cvt.f32.f16 v0, v4
    @p3 v.st.h       [s15, #0], v0
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    s.movz       s15, #4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v0, [s14, #0]
    s.addi       s14, s13, #5
    v.splat      v1, s14
    s.addi       s14, s23, #1024                 // row 4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s17, #0]
    a.vread      v4, a0, s26
    vf.cvt.f16.f32 v5, v0
    s.addi       s17, s18, #1280                 // row 5
    s.addi       s26, s11, #1280                 // row 5
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v0, [s16, #0]
    vf.cvt.f16.f32 v6, v2
    vf.add       v2, v5, v6
    vf.cvt.f16.f32 v5, v0
    vf.add       v0, v4, v5
    vf.cvt.f32.f16 v4, v0
    vf.cvt.f16.f32 v0, v4
    vf.add       v4, v2, v0
    vf.cvt.f32.f16 v0, v4
    @p4 v.st.h       [s25, #0], v0
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.movz       s25, #5
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s12, #0]
    s.addi       s12, s13, #6
    v.splat      v1, s12
    s.addi       s12, s23, #1280                 // row 5
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s27, #0]
    a.vread      v4, a0, s15
    vf.cvt.f16.f32 v5, v0
    s.addi       s15, s18, #1536                 // row 6
    s.addi       s27, s11, #1536                 // row 6
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s16, #0]
    vf.cvt.f16.f32 v6, v2
    vf.add       v2, v5, v6
    vf.cvt.f16.f32 v5, v0
    vf.add       v0, v4, v5
    vf.cvt.f32.f16 v4, v0
    vf.cvt.f16.f32 v0, v4
    vf.add       v4, v2, v0
    vf.cvt.f32.f16 v0, v4
    @p3 v.st.h       [s14, #0], v0
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    s.movz       s14, #6
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v0, [s17, #0]
    s.addi       s17, s13, #7
    v.splat      v1, s17
    s.addi       s17, s23, #1536                 // row 6
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s26, #0]
    a.vread      v4, a0, s25
    vf.cvt.f16.f32 v5, v0
    s.addi       s25, s18, #1792                 // row 7
    s.addi       s26, s11, #1792                 // row 7
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v0, [s16, #0]
    vf.cvt.f16.f32 v6, v2
    vf.add       v2, v5, v6
    vf.cvt.f16.f32 v5, v0
    vf.add       v0, v4, v5
    vf.cvt.f32.f16 v4, v0
    vf.cvt.f16.f32 v0, v4
    vf.add       v4, v2, v0
    vf.cvt.f32.f16 v0, v4
    @p4 v.st.h       [s12, #0], v0
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.movz       s12, #7
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s15, #0]
    s.addi       s15, s13, #8
    v.splat      v1, s15
    s.addi       s15, s23, #1792                 // row 7
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s27, #0]
    a.vread      v4, a0, s14
    vf.cvt.f16.f32 v5, v0
    s.addi       s14, s18, #2048                 // row 8
    s.addi       s27, s11, #2048                 // row 8
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s16, #0]
    vf.cvt.f16.f32 v6, v2
    vf.add       v2, v5, v6
    vf.cvt.f16.f32 v5, v0
    vf.add       v0, v4, v5
    vf.cvt.f32.f16 v4, v0
    vf.cvt.f16.f32 v0, v4
    vf.add       v4, v2, v0
    vf.cvt.f32.f16 v0, v4
    @p3 v.st.h       [s17, #0], v0
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    s.movz       s17, #8
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v0, [s25, #0]
    s.addi       s25, s13, #9
    v.splat      v1, s25
    s.addi       s25, s23, #2048                 // row 8
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s26, #0]
    a.vread      v4, a0, s12
    vf.cvt.f16.f32 v5, v0
    s.addi       s12, s18, #2304                 // row 9
    s.addi       s26, s11, #2304                 // row 9
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v0, [s16, #0]
    vf.cvt.f16.f32 v6, v2
    vf.add       v2, v5, v6
    vf.cvt.f16.f32 v5, v0
    vf.add       v0, v4, v5
    vf.cvt.f32.f16 v4, v0
    vf.cvt.f16.f32 v0, v4
    vf.add       v4, v2, v0
    vf.cvt.f32.f16 v0, v4
    @p4 v.st.h       [s15, #0], v0
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.movz       s15, #9
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s14, #0]
    s.addi       s14, s13, #10
    v.splat      v1, s14
    s.addi       s14, s23, #2304                 // row 9
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s27, #0]
    a.vread      v4, a0, s17
    vf.cvt.f16.f32 v5, v0
    s.addi       s17, s18, #2560                 // row 10
    s.addi       s27, s11, #2560                 // row 10
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s16, #0]
    vf.cvt.f16.f32 v6, v2
    vf.add       v2, v5, v6
    vf.cvt.f16.f32 v5, v0
    vf.add       v0, v4, v5
    vf.cvt.f32.f16 v4, v0
    vf.cvt.f16.f32 v0, v4
    vf.add       v4, v2, v0
    vf.cvt.f32.f16 v0, v4
    @p3 v.st.h       [s25, #0], v0
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    s.movz       s25, #10
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v0, [s12, #0]
    s.addi       s12, s13, #11
    v.splat      v1, s12
    s.addi       s12, s23, #2560                 // row 10
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s26, #0]
    a.vread      v4, a0, s15
    vf.cvt.f16.f32 v5, v0
    s.addi       s15, s18, #2816                 // row 11
    s.addi       s26, s11, #2816                 // row 11
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v0, [s16, #0]
    vf.cvt.f16.f32 v6, v2
    vf.add       v2, v5, v6
    vf.cvt.f16.f32 v5, v0
    vf.add       v0, v4, v5
    vf.cvt.f32.f16 v4, v0
    vf.cvt.f16.f32 v0, v4
    vf.add       v4, v2, v0
    vf.cvt.f32.f16 v0, v4
    @p4 v.st.h       [s14, #0], v0
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.movz       s14, #11
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s17, #0]
    s.addi       s17, s13, #12
    v.splat      v1, s17
    s.addi       s17, s23, #2816                 // row 11
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s27, #0]
    a.vread      v4, a0, s25
    vf.cvt.f16.f32 v5, v0
    s.addi       s25, s18, #3072                 // row 12
    s.addi       s27, s11, #3072                 // row 12
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s16, #0]
    vf.cvt.f16.f32 v6, v2
    vf.add       v2, v5, v6
    vf.cvt.f16.f32 v5, v0
    vf.add       v0, v4, v5
    vf.cvt.f32.f16 v4, v0
    vf.cvt.f16.f32 v0, v4
    vf.add       v4, v2, v0
    vf.cvt.f32.f16 v0, v4
    @p3 v.st.h       [s12, #0], v0
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    s.movz       s12, #12
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v0, [s15, #0]
    s.addi       s15, s13, #13
    v.splat      v1, s15
    s.addi       s15, s23, #3072                 // row 12
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s26, #0]
    a.vread      v4, a0, s14
    vf.cvt.f16.f32 v5, v0
    s.addi       s14, s18, #3328                 // row 13
    s.addi       s26, s11, #3328                 // row 13
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v0, [s16, #0]
    vf.cvt.f16.f32 v6, v2
    vf.add       v2, v5, v6
    vf.cvt.f16.f32 v5, v0
    vf.add       v0, v4, v5
    vf.cvt.f32.f16 v4, v0
    vf.cvt.f16.f32 v0, v4
    vf.add       v4, v2, v0
    vf.cvt.f32.f16 v0, v4
    @p4 v.st.h       [s17, #0], v0
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.movz       s17, #13
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s25, #0]
    s.addi       s25, s13, #14
    v.splat      v1, s25
    s.addi       s25, s23, #3328                 // row 13
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s27, #0]
    a.vread      v4, a0, s12
    vf.cvt.f16.f32 v5, v0
    s.addi       s12, s18, #3584                 // row 14
    s.addi       s27, s11, #3584                 // row 14
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s16, #0]
    vf.cvt.f16.f32 v6, v2
    vf.add       v2, v5, v6
    vf.cvt.f16.f32 v5, v0
    vf.add       v0, v4, v5
    vf.cvt.f32.f16 v4, v0
    vf.cvt.f16.f32 v0, v4
    vf.add       v4, v2, v0
    s.addi       s28, s18, #3840                 // row 15
    vf.cvt.f32.f16 v0, v4
    s.addi       s18, s13, #15
    v.splat      v2, s18
    s.movz       s13, #14
    @p3 v.st.h       [s15, #0], v0
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    s.addi       s15, s23, #3584                 // row 14
    s.addi       s18, s11, #3840                 // row 15
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v0, [s14, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v1, [s26, #0]
    a.vread      v4, a0, s17
    vf.cvt.f16.f32 v5, v0
    s.movz       s11, #15
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v0, [s16, #0]
    vf.cvt.f16.f32 v6, v1
    vf.add       v1, v5, v6
    vf.cvt.f16.f32 v5, v0
    vf.add       v0, v4, v5
    vf.cvt.f32.f16 v4, v0
    s.addi       s14, s23, #3840                 // row 15
    vf.cvt.f16.f32 v0, v4
    vf.add       v4, v1, v0
    vf.cvt.f32.f16 v0, v4
    @p4 v.st.h       [s25, #0], v0
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s12, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s27, #0]
    a.vread      v2, a0, s13
    vf.cvt.f16.f32 v3, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s16, #0]
    vf.cvt.f16.f32 v4, v1
    vf.add       v1, v3, v4
    vf.cvt.f16.f32 v3, v0
    vf.add       v0, v2, v3
    vf.cvt.f32.f16 v2, v0
    vf.cvt.f16.f32 v0, v2
    vf.add       v2, v1, v0
    vf.cvt.f32.f16 v0, v2
    @p3 v.st.h       [s15, #0], v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v0, [s28, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v1, [s18, #0]
    a.vread      v2, a0, s11
    vf.cvt.f16.f32 v3, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v0, [s16, #0]
    vf.cvt.f16.f32 v4, v1
    vf.add       v1, v3, v4
    vf.cvt.f16.f32 v3, v0
    vf.add       v0, v2, v3
    vf.cvt.f32.f16 v2, v0
    vf.cvt.f16.f32 v0, v2
    vf.add       v2, v1, v0
    vf.cvt.f32.f16 v0, v2
    @p4 v.st.h       [s14, #0], v0
__rctx_next:
    s.addi       s11, s9, #2                     // the next program of this context: + 2
    s.cmp.lt     s12, s11, s10
    s.mov        s9, s11
    br.nz        s12, __rctx_program
    exit
