# AOT ID: ['38_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /home/zhongchun/r41-fp8-ops-work/v3/std/inductor-cache/lt/clt2elfhbmvvj3p4zj2dqudilkwre6ztvaf26b7x6nhizkop32md.py
# Topologically Sorted Source Nodes: [xf, pow_1, mean], Original ATen: [aten._to_copy, aten.pow, aten.mean]
# Source node to ATen node mapping:
#   mean => mean
#   pow_1 => pow_1
#   xf => convert_element_type_1
# Graph fragment:
#   %arg2_1 : Tensor "bf16[2, 4, 1, 64][256, 64, 64, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %convert_element_type_1 : Tensor "f32[2, 4, 1, 64][256, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg2_1, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[2, 4, 1, 64][256, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_1, 2), kwargs = {})
#   %mean : Tensor "f32[2, 4, 1, 1][4, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [-1], True), kwargs = {})
#   return %buf0
triton_red_fused__to_copy_mean_pow_0 = async_compile.triton('triton_red_fused__to_copy_mean_pow_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 8, 'r0_': 64},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_mean_pow_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 64, 'r0_': 1024}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy_mean_pow_0(in_ptr0, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 8
    XBLOCK: tl.constexpr = 1
    r0_numel = 64
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    _tmp4 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 64*x0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp2 = tmp1 * tmp1
        tmp3 = tl.broadcast_to(tmp2, [R0_BLOCK])
        tmp5 = _tmp4 + tmp3
        _tmp4 = tl.where(r0_mask, tmp5, _tmp4)
    tmp4 = triton_helpers.promote_to_tensor(tl.sum(_tmp4, 0))
    tl.store(out_ptr0 + (x0), tmp4, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-fp8-ops-work/v3/std/inductor-cache/ro/crobvdgdoqjkw5tlpqn43mnogykf4326y26gkapnttpzlrizmyvb.py
# Topologically Sorted Source Nodes: [xf, pow_1, mean, add, rsqrt, mul, xn, getitem_3, neg, getitem_4, rot], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.slice, aten.neg, aten.cat]
# Source node to ATen node mapping:
#   add => add
#   getitem_3 => slice_1
#   getitem_4 => slice_2
#   mean => mean
#   mul => mul_1
#   neg => neg
#   pow_1 => pow_1
#   rot => cat
#   rsqrt => rsqrt
#   xf => convert_element_type_1
#   xn => mul_2
# Graph fragment:
#   %arg2_1 : Tensor "bf16[2, 4, 1, 64][256, 64, 64, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %buf0 : Tensor "f32[2, 4, 1, 1][4, 1, 8, 8]tnca:0" = PlaceHolder[target=buf0]
#   %arg3_1 : Tensor "f32[64][1]tnca:0" = PlaceHolder[target=arg3_1]
#   %convert_element_type_1 : Tensor "f32[2, 4, 1, 64][256, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg2_1, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[2, 4, 1, 64][256, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_1, 2), kwargs = {})
#   %mean : Tensor "f32[2, 4, 1, 1][4, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [-1], True), kwargs = {})
#   %add : Tensor "f32[2, 4, 1, 1][4, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean, 1e-06), kwargs = {})
#   %rsqrt : Tensor "f32[2, 4, 1, 1][4, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %mul_1 : Tensor "f32[2, 4, 1, 64][256, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_1, %rsqrt), kwargs = {})
#   %mul_2 : Tensor "f32[2, 4, 1, 64][256, 64, 64, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_1, %arg3_1), kwargs = {})
#   %slice_1 : Tensor "f32[2, 4, 1, 32][256, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%mul_2, 3, 32, 9223372036854775807), kwargs = {})
#   %neg : Tensor "f32[2, 4, 1, 32][128, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_1,), kwargs = {})
#   %slice_2 : Tensor "f32[2, 4, 1, 32][256, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%mul_2, 3, 0, 32), kwargs = {})
#   %cat : Tensor "f32[2, 4, 1, 64][256, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg, %slice_2], -1), kwargs = {})
#   return %neg,%buf2
triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_1 = async_compile.triton('triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 256}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 5408}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_1(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 256
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 32)
    x1 = xindex // 32
    tmp0 = tl.load(in_ptr0 + (32 + x0 + 64*x1), xmask).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (x1), xmask, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr2 + (32 + x0), xmask, eviction_policy='evict_last')
    tmp12 = tl.load(in_ptr0 + (x0 + 64*x1), xmask).to(tl.float32)
    tmp15 = tl.load(in_ptr2 + (x0), xmask, eviction_policy='evict_last')
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tl.full([1], 64.0, tl.float32)
    tmp4 = (tmp2 / tmp3)
    tmp5 = tl.full([1], 1e-06, tl.float32)
    tmp6 = tmp4 + tmp5
    tmp7 = libdevice.rsqrt(tmp6)
    tmp8 = tmp1 * tmp7
    tmp10 = tmp8 * tmp9
    tmp11 = -tmp10
    tmp13 = tmp12.to(tl.float32)
    tmp14 = tmp13 * tmp7
    tmp16 = tmp14 * tmp15
    tl.store(out_ptr0 + (x0 + 64*x1), tmp11, xmask)
    tl.store(out_ptr1 + (x0 + 64*x1), tmp16, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-fp8-ops-work/v3/std/inductor-cache/rv/crveehm6hrv5xr5kbyaqtfvubab2j4nslhk3e3wqssl4a2js4mal.py
# Topologically Sorted Source Nodes: [xf, pow_1, mean, add, rsqrt, mul, xn, getitem, expand, getitem_1, float_1, f, transpose, cat, emb, cos, mul_2, sin, mul_3, add_1], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.unsqueeze, aten.expand, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin]
# Source node to ATen node mapping:
#   add => add
#   add_1 => add_1
#   cat => clone, expand_3, unsqueeze_3, view_3
#   cos => cos
#   emb => unsqueeze_4
#   expand => expand
#   f => mul
#   float_1 => convert_element_type
#   getitem => unsqueeze, unsqueeze_1
#   getitem_1 => unsqueeze_2
#   mean => mean
#   mul => mul_1
#   mul_2 => mul_3
#   mul_3 => mul_4
#   pow_1 => pow_1
#   rsqrt => rsqrt
#   sin => sin
#   transpose => permute
#   xf => convert_element_type_1
#   xn => mul_2
# Graph fragment:
#   %arg2_1 : Tensor "bf16[2, 4, 1, 64][256, 64, 64, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %buf0 : Tensor "f32[2, 4, 1, 1][4, 1, 8, 8]tnca:0" = PlaceHolder[target=buf0]
#   %arg3_1 : Tensor "f32[64][1]tnca:0" = PlaceHolder[target=arg3_1]
#   %arg1_1 : Tensor "f32[32][1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "i64[2, 1][1, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %cat : Tensor "f32[2, 4, 1, 64][256, 64, 64, 1]tnca:0" = PlaceHolder[target=cat]
#   %convert_element_type_1 : Tensor "f32[2, 4, 1, 64][256, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg2_1, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[2, 4, 1, 64][256, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_1, 2), kwargs = {})
#   %mean : Tensor "f32[2, 4, 1, 1][4, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [-1], True), kwargs = {})
#   %add : Tensor "f32[2, 4, 1, 1][4, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean, 1e-06), kwargs = {})
#   %rsqrt : Tensor "f32[2, 4, 1, 1][4, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %mul_1 : Tensor "f32[2, 4, 1, 64][256, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_1, %rsqrt), kwargs = {})
#   %mul_2 : Tensor "f32[2, 4, 1, 64][256, 64, 64, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_1, %arg3_1), kwargs = {})
#   %unsqueeze : Tensor "f32[1, 32][32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg1_1, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[1, 32, 1][32, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze, 2), kwargs = {})
#   %expand : Tensor "f32[2, 32, 1][0, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [2, -1, 1]), kwargs = {})
#   %unsqueeze_2 : Tensor "i64[2, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg0_1, 1), kwargs = {})
#   %convert_element_type : Tensor "f32[2, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_2, torch.float32), kwargs = {})
#   %mul : Tensor "f32[2, 32, 1][32, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%expand_1, %expand_2), kwargs = {})
#   %permute : Tensor "f32[2, 1, 32][32, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%mul, [0, 2, 1]), kwargs = {})
#   %unsqueeze_3 : Tensor "f32[2, 1, 1, 32][32, 1, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute, 2), kwargs = {})
#   %expand_3 : Tensor "f32[2, 1, 2, 32][32, 1, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_3, [2, 1, 2, 32]), kwargs = {})
#   %clone : Tensor "f32[2, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_3 : Tensor "f32[2, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [2, 1, 64]), kwargs = {})
#   %unsqueeze_4 : Tensor "f32[2, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%view_3, 1), kwargs = {})
#   %cos : Tensor "f32[2, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cos.default](args = (%unsqueeze_4,), kwargs = {})
#   %mul_3 : Tensor "f32[2, 4, 1, 64][256, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_2, %cos), kwargs = {})
#   %sin : Tensor "f32[2, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%unsqueeze_4,), kwargs = {})
#   %mul_4 : Tensor "f32[2, 4, 1, 64][256, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat, %sin), kwargs = {})
#   %add_1 : Tensor "f32[2, 4, 1, 64][256, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_3, %mul_4), kwargs = {})
#   return %add_1
triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mean_mul_pow_rsqrt_sin_transpose_unsqueeze_2 = async_compile.triton('triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mean_mul_pow_rsqrt_sin_transpose_unsqueeze_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 512}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*i64', 'in_ptr5': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mean_mul_pow_rsqrt_sin_transpose_unsqueeze_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 7600}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mean_mul_pow_rsqrt_sin_transpose_unsqueeze_2(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 512
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x3 = xindex
    x4 = xindex // 64
    x0 = (xindex % 64)
    x2 = xindex // 256
    tmp0 = tl.load(in_ptr0 + (x3), xmask).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (x4), xmask, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr2 + (x0), xmask, eviction_policy='evict_last')
    tmp11 = tl.load(in_ptr3 + ((x3 % 32)), xmask, eviction_policy='evict_last')
    tmp12 = tl.load(in_ptr4 + (x2), xmask, eviction_policy='evict_last')
    tmp17 = tl.load(in_ptr5 + (x3), xmask)
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tl.full([1], 64.0, tl.float32)
    tmp4 = (tmp2 / tmp3)
    tmp5 = tl.full([1], 1e-06, tl.float32)
    tmp6 = tmp4 + tmp5
    tmp7 = libdevice.rsqrt(tmp6)
    tmp8 = tmp1 * tmp7
    tmp10 = tmp8 * tmp9
    tmp13 = tmp12.to(tl.float32)
    tmp14 = tmp11 * tmp13
    tmp15 = tl_math.cos(tmp14)
    tmp16 = tmp10 * tmp15
    tmp18 = tl_math.sin(tmp14)
    tmp19 = tmp17 * tmp18
    tmp20 = tmp16 + tmp19
    tl.store(out_ptr0 + (x3), tmp20, xmask)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1 = args
        args.clear()
        assert_size_stride(arg2_1, (2, 4, 1, 64), (256, 64, 64, 1), 'input')
        buf0 = empty_strided((2, 4, 1, 1), (4, 1, 8, 8), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [xf, pow_1, mean], Original ATen: [aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_0.run(arg2_1, buf0, 8, 64, stream=raw_stream0)
        assert_size_stride(arg3_1, (64, ), (1, ), 'input')
        buf3 = empty_strided((2, 4, 1, 64), (256, 64, 64, 1), device='tnca', dtype=torch.float32)
        buf1 = reinterpret_tensor(buf3, (2, 4, 1, 32), (256, 64, 64, 1), 0)  # alias
        buf2 = reinterpret_tensor(buf3, (2, 4, 1, 32), (256, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [xf, pow_1, mean, add, rsqrt, mul, xn, getitem_3, neg, getitem_4, rot], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_1.run(arg2_1, buf0, arg3_1, buf1, buf2, 256, stream=raw_stream0)
        assert_size_stride_grouped((arg1_1, arg0_1), ((32, ), (2, 1)), ((1, ), (1, 1)), 'input')
        buf4 = empty_strided((2, 4, 1, 64), (256, 64, 64, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [xf, pow_1, mean, add, rsqrt, mul, xn, getitem, expand, getitem_1, float_1, f, transpose, cat, emb, cos, mul_2, sin, mul_3, add_1], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.unsqueeze, aten.expand, aten.bmm, aten.transpose, aten.cat, aten.cos, aten.sin]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_bmm_cat_cos_expand_mean_mul_pow_rsqrt_sin_transpose_unsqueeze_2.run(arg2_1, buf0, arg3_1, arg1_1, arg0_1, buf3, buf4, 512, stream=raw_stream0)
        del arg0_1
        del arg1_1
        del arg2_1
        del arg3_1
        return (buf4, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((2, 1), (1, 1), device='tnca:0', dtype=torch.int64)
    arg1_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg2_1 = rand_strided((2, 4, 1, 64), (256, 64, 64, 1), device='tnca:0', dtype=torch.bfloat16)
    arg3_1 = rand_strided((64, ), (1, ), device='tnca:0', dtype=torch.float32)
    return [arg0_1, arg1_1, arg2_1, arg3_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
