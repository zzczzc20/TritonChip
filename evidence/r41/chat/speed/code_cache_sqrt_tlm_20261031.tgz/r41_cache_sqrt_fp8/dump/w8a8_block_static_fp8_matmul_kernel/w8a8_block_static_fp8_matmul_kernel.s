    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    s.ld.d       s3, [s1, #0]                    // A: device_ptr64 at arg_base+0
    s.addi       s4, s2, #0
    s.ld.d       s5, [s1, #8]                    // B: device_ptr64 at arg_base+8
    s.ld.d       s6, [s1, #16]                   // C: device_ptr64 at arg_base+16
    s.ld.d       s7, [s1, #24]                   // As: device_ptr64 at arg_base+24
    s.ld.d       s8, [s1, #32]                   // Bs: device_ptr64 at arg_base+32
    s.ld.sw      s9, [s1, #40]                   // M: i32 at arg_base+40
    s.ld.sw      s10, [s1, #48]                  // N: i32 at arg_base+48
    s.ld.sw      s11, [s1, #56]                  // K: i32 at arg_base+56
    s.ld.sw      s12, [s1, #64]                  // stride_am: i32 at arg_base+64
    s.ld.sw      s13, [s1, #72]                  // stride_bn: i32 at arg_base+72
    s.ld.sw      s14, [s1, #80]                  // stride_cm: i32 at arg_base+80
    s.ld.sw      s15, [s1, #88]                  // stride_bs_n: i32 at arg_base+88
rows_1:
    s.movz       s1, #127
    s.movz       s16, #128
    s.rdspecial  s17, pid.x
    s.cmp.lt     s18, s16, s2
    s.add        s19, s9, s1
    s.sub        s20, s2, s18
    s.cmp.lt     s18, s19, s2
    s.rdspecial  s21, pid.y
    s.sub        s22, s2, s18
    // rows [r0, r0 + 16) of a 128-row program (row_split)
    v.iota       v0                              // arange(0, VLEN)
    s.xor        s18, s19, s22
    v.splat      v1, s4
    s.sub        s19, s18, s22
    s.xor        s18, s16, s20
    s.lshri      s23, s19, #7
    v.add        v2, v0, v1
    s.add        s24, s10, s1
    s.muli       s25, s23, #128
    s.cmp.lt     s26, s24, s2
    s.xor        s27, s22, s20
    s.sub        s22, s2, s26
    s.xor        s26, s23, s27
    s.xor        s23, s24, s22
    s.xor        s24, s22, s20
    s.sub        s28, s23, s22
    s.sub        s22, s18, s20
    s.lshri      s18, s28, #7
    s.sub        s20, s19, s25
    s.xor        s19, s18, s24
    s.movz       s20, #8
    s.sub        s22, s19, s24
    s.muli       s19, s18, #128
    s.mul        s18, s17, s22
    s.mul        s17, s22, s20
    s.sub        s22, s26, s27
    s.sub        s23, s28, s19
    s.add        s19, s18, s21
    s.cmp.lt     s18, s17, s2
    s.cmp.lt     s21, s19, s2
    s.sub        s23, s2, s18
    s.sub        s18, s2, s21
    s.xor        s21, s17, s23
    s.xor        s24, s19, s18
    s.sub        s25, s21, s23
    s.movz       s21, #0
    s.movz       s26, #1
    s.sub        s27, s24, s18
    s.addi       s24, s21, #0
    s.cmp.eq     s28, s25, s26
    s.addi       s29, s21, #0
    s.mov        s24, s27
    br.nz        s28, sdiv_done_3
    s.movz       s28, #0
    s.mov        s24, s28
    s.movz       s28, #31
    s.addi       s30, s28, #0
sdiv_4:
    s.lshr       s28, s27, s30
    s.andi       s31, s28, #1
    s.shli       s28, s29, #1
    s.or         s32, s28, s31
    s.cmp.geu    s28, s32, s25
    s.sub        s31, s21, s28
    s.and        s28, s25, s31
    s.sub        s33, s32, s28
    s.mov        s29, s33
    s.shl        s28, s26, s30
    s.and        s32, s28, s31
    s.or         s28, s24, s32
    s.mov        s24, s28
    s.subi       s28, s30, #1
    s.mov        s30, s28
    s.cmp.ge     s28, s30, s21
    br.nz        s28, sdiv_4
sdiv_done_3:
    s.xor        s25, s18, s23
    s.cmp.lt     s18, s17, s21
    s.xor        s23, s24, s25
    s.sub        s24, s21, s18
    s.sub        s18, s23, s25
    s.cmp.lt     s23, s19, s21
    s.mul        s25, s18, s20
    s.sub        s18, s21, s23
    s.xor        s23, s17, s24
    s.xor        s17, s19, s18
    s.sub        s19, s23, s24
    s.sub        s23, s22, s25
    s.sub        s22, s17, s18
    s.addi       s17, s21, #0
    s.cmp.eq     s24, s19, s26
    s.min.s      s26, s23, s20
    s.addi       s20, s21, #0
    s.mov        s17, s22
    br.nz        s24, sdiv_done_5
    s.movz       s21, #0
    s.mov        s17, s21
    s.movz       s21, #31
    s.addi       s23, s21, #0
sdiv_6:
    s.lshr       s21, s22, s23
    s.andi       s24, s21, #1
    s.shli       s21, s20, #1
    s.or         s27, s21, s24
    s.movz       s21, #0
    s.cmp.geu    s24, s27, s19
    s.sub        s28, s21, s24
    s.and        s24, s19, s28
    s.sub        s29, s27, s24
    s.mov        s20, s29
    s.movz       s24, #1
    s.shl        s27, s24, s23
    s.and        s24, s27, s28
    s.or         s27, s17, s24
    s.mov        s17, s27
    s.subi       s24, s23, #1
    s.mov        s23, s24
    s.cmp.ge     s24, s23, s21
    br.nz        s24, sdiv_6
sdiv_done_5:
    s.xor        s17, s20, s18
    s.movz       s19, #0
    s.sub        s20, s17, s18
    s.cmp.lt     s17, s26, s19
    s.cmp.lt     s18, s20, s19
    s.sub        s21, s19, s17
    s.sub        s17, s19, s18
    s.xor        s18, s26, s21
    s.xor        s22, s20, s17
    s.sub        s20, s18, s21
    s.movz       s18, #1
    s.sub        s23, s22, s17
    s.addi       s24, s19, #0
    s.cmp.eq     s26, s20, s18
    s.addi       s27, s19, #0
    s.mov        s24, s23
    br.nz        s26, sdiv_done_7
    s.movz       s28, #0
    s.mov        s24, s28
    s.movz       s28, #31
    s.addi       s29, s28, #0
sdiv_8:
    s.lshr       s28, s23, s29
    s.shli       s30, s27, #1
    s.andi       s31, s28, #1
    s.shl        s28, s18, s29
    s.or         s32, s30, s31
    s.subi       s30, s29, #1
    s.cmp.geu    s31, s32, s20
    s.sub        s33, s19, s31
    s.and        s31, s28, s33
    s.and        s28, s20, s33
    s.or         s33, s24, s31
    s.sub        s31, s32, s28
    s.mov        s27, s31
    s.mov        s24, s33
    s.mov        s29, s30
    s.cmp.ge     s28, s29, s19
    br.nz        s28, sdiv_8
sdiv_done_7:
    s.xor        s18, s27, s17
    s.sub        s23, s22, s17
    s.sub        s22, s18, s17
    s.add        s18, s25, s22
    s.addi       s22, s19, #0
    s.addi       s24, s19, #0
    s.mov        s22, s23
    br.nz        s26, sdiv_done_9
    s.movz       s19, #0
    s.mov        s22, s19
    s.movz       s19, #31
    s.addi       s25, s19, #0
sdiv_10:
    s.lshr       s19, s23, s25
    s.andi       s26, s19, #1
    s.shli       s19, s24, #1
    s.or         s27, s19, s26
    s.movz       s19, #0
    s.cmp.geu    s26, s27, s20
    s.sub        s28, s19, s26
    s.and        s26, s20, s28
    s.sub        s29, s27, s26
    s.mov        s24, s29
    s.movz       s26, #1
    s.shl        s27, s26, s25
    s.and        s26, s27, s28
    s.or         s27, s22, s26
    s.mov        s22, s27
    s.subi       s26, s25, #1
    s.mov        s25, s26
    s.cmp.ge     s26, s25, s19
    br.nz        s26, sdiv_10
sdiv_done_9:
    s.mul        s19, s18, s16
    s.xor        s18, s17, s21
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #16
    v.movi       v3, #32
    v.movi       v4, #48
    v.iota       v5                              // arange(0, VLEN)
    v.movi       v6, #64
    v.movi       v7, #80
    v.movi       v8, #96
    s.xor        s17, s22, s18
    v.add        v9, v0, v1
    s.sub        s20, s17, s18
    v.splat      v1, s19
    v.iota       v10                             // arange(0, VLEN)
    v.movi       v11, #112
    v.add        v12, v1, v2
    v.add        v1, v0, v3
    v.splat      v2, s9
    v.movi       v3, #0
    v.add        v13, v0, v4
    v.add        v4, v5, v6
    v.sub        v6, v3, v12
    v.cmp.lt     p1, v12, v3
    v.cmp.lt     p2, v2, v3
    v.add        v14, v5, v7
    v.add        v7, v5, v8
    v.sub        v5, v3, v2
    v.add        v8, v10, v11
    s.add        s17, s4, s19
    v.movi       v10, #1
    @p1 v.sel        v11, v6, v12
    @p2 v.sel        v6, v5, v2
    v.movi       v2, #0
    v.movi       v5, #0
    s.movz       s18, #31
idiv_11:
    v.splat      v12, s18
    v.shl        v15, v5, v10
    v.cmp.lt     p2, v5, v3
    v.lshr       v16, v11, v12
    v.shl        v17, v10, v12
    s.subi       s19, s18, #1
    v.and        v12, v16, v10
    v.or         v16, v15, v12
    v.cmp.geu    p3, v16, v6
    p.or         p4, p2, p3
    v.sub        v12, v16, v6
    @p4 v.sel        v15, v17, v3
    @p4 v.sel        v17, v12, v16
    v.or         v12, v2, v15
    v.mov        v5, v17
    v.mov        v2, v12
    s.mov        s18, s19
    s.movz       s19, #0
    s.cmp.ge     s21, s18, s19
    br.nz        s21, idiv_11
    s.mul        s18, s20, s16
    v.splat      v2, s10
    v.movi       v6, #0
    v.sub        v10, v3, v5
    v.movi       v3, #1
    v.splat      v11, s18
    v.cmp.lt     p2, v2, v6
    @p1 v.sel        v12, v10, v5
    v.add        v5, v11, v0
    v.sub        v0, v6, v2
    v.add        v10, v11, v9
    v.sub        v9, v6, v5
    v.cmp.lt     p1, v5, v6
    v.add        v15, v11, v1
    v.add        v1, v11, v13
    v.add        v13, v11, v4
    v.add        v4, v11, v14
    v.add        v14, v11, v7
    v.add        v7, v11, v8
    @p1 v.sel        v8, v9, v5
    @p2 v.sel        v5, v0, v2
    v.movi       v0, #0
    v.movi       v9, #0
    s.movz       s20, #31
idiv_12:
    v.splat      v11, s20
    v.shl        v16, v9, v3
    v.cmp.lt     p2, v9, v6
    v.lshr       v17, v8, v11
    v.shl        v18, v3, v11
    s.subi       s21, s20, #1
    v.and        v11, v17, v3
    v.or         v17, v16, v11
    v.cmp.geu    p3, v17, v5
    p.or         p4, p2, p3
    v.sub        v11, v17, v5
    @p4 v.sel        v16, v18, v6
    @p4 v.sel        v18, v11, v17
    v.or         v11, v0, v16
    v.mov        v9, v18
    v.mov        v0, v11
    s.mov        s20, s21
    s.cmp.ge     s21, s20, s19
    br.nz        s21, idiv_12
    v.movi       v0, #0
    v.sub        v3, v6, v9
    v.movi       v5, #1
    v.sub        v6, v0, v10
    v.sub        v8, v0, v2
    v.cmp.lt     p2, v10, v0
    @p1 v.sel        v11, v3, v9
    v.cmp.lt     p1, v2, v0
    @p2 v.sel        v3, v6, v10
    @p1 v.sel        v6, v8, v2
    v.movi       v8, #0
    v.movi       v9, #0
    s.movz       s19, #31
idiv_13:
    v.splat      v10, s19
    v.shl        v16, v9, v5
    v.cmp.lt     p1, v9, v0
    v.lshr       v17, v3, v10
    v.shl        v18, v5, v10
    s.subi       s20, s19, #1
    v.and        v10, v17, v5
    v.or         v17, v16, v10
    v.cmp.geu    p3, v17, v6
    p.or         p4, p1, p3
    v.sub        v10, v17, v6
    @p4 v.sel        v16, v18, v0
    @p4 v.sel        v18, v10, v17
    v.or         v10, v8, v16
    v.mov        v9, v18
    v.mov        v8, v10
    s.mov        s19, s20
    s.movz       s20, #0
    s.cmp.ge     s21, s19, s20
    br.nz        s21, idiv_13
    v.movi       v3, #0
    v.sub        v5, v0, v9
    v.movi       v0, #1
    v.sub        v6, v3, v15
    v.sub        v8, v3, v2
    v.cmp.lt     p1, v15, v3
    @p2 v.sel        v10, v5, v9
    v.cmp.lt     p2, v2, v3
    @p1 v.sel        v5, v6, v15
    @p2 v.sel        v6, v8, v2
    v.movi       v8, #0
    v.movi       v9, #0
    s.movz       s19, #31
idiv_14:
    v.splat      v15, s19
    v.shl        v16, v9, v0
    v.cmp.lt     p2, v9, v3
    v.lshr       v17, v5, v15
    v.shl        v18, v0, v15
    s.subi       s21, s19, #1
    v.and        v15, v17, v0
    v.or         v17, v16, v15
    v.cmp.geu    p3, v17, v6
    p.or         p4, p2, p3
    v.sub        v15, v17, v6
    @p4 v.sel        v16, v18, v3
    @p4 v.sel        v18, v15, v17
    v.or         v15, v8, v16
    v.mov        v9, v18
    v.mov        v8, v15
    s.mov        s19, s21
    s.cmp.ge     s21, s19, s20
    br.nz        s21, idiv_14
    v.movi       v0, #0
    v.sub        v5, v3, v9
    v.movi       v3, #1
    v.sub        v6, v0, v1
    v.sub        v8, v0, v2
    v.cmp.lt     p2, v1, v0
    @p1 v.sel        v15, v5, v9
    v.cmp.lt     p1, v2, v0
    @p2 v.sel        v5, v6, v1
    @p1 v.sel        v1, v8, v2
    v.movi       v6, #0
    v.movi       v8, #0
    s.movz       s19, #31
idiv_15:
    v.splat      v9, s19
    v.shl        v16, v8, v3
    v.cmp.lt     p1, v8, v0
    v.lshr       v17, v5, v9
    v.shl        v18, v3, v9
    s.subi       s20, s19, #1
    v.and        v9, v17, v3
    v.or         v17, v16, v9
    v.cmp.geu    p3, v17, v1
    p.or         p4, p1, p3
    v.sub        v9, v17, v1
    @p4 v.sel        v16, v18, v0
    @p4 v.sel        v18, v9, v17
    v.or         v9, v6, v16
    v.mov        v8, v18
    v.mov        v6, v9
    s.mov        s19, s20
    s.movz       s20, #0
    s.cmp.ge     s21, s19, s20
    br.nz        s21, idiv_15
    v.movi       v1, #0
    v.sub        v3, v0, v8
    v.movi       v0, #1
    v.sub        v5, v1, v13
    v.sub        v6, v1, v2
    v.cmp.lt     p1, v13, v1
    @p2 v.sel        v9, v3, v8
    v.cmp.lt     p2, v2, v1
    @p1 v.sel        v3, v5, v13
    @p2 v.sel        v5, v6, v2
    v.movi       v6, #0
    v.movi       v8, #0
    s.movz       s19, #31
idiv_16:
    v.splat      v13, s19
    v.shl        v16, v8, v0
    v.cmp.lt     p2, v8, v1
    v.lshr       v17, v3, v13
    v.shl        v18, v0, v13
    s.subi       s21, s19, #1
    v.and        v13, v17, v0
    v.or         v17, v16, v13
    v.cmp.geu    p3, v17, v5
    p.or         p4, p2, p3
    v.sub        v13, v17, v5
    @p4 v.sel        v16, v18, v1
    @p4 v.sel        v18, v13, v17
    v.or         v13, v6, v16
    v.mov        v8, v18
    v.mov        v6, v13
    s.mov        s19, s21
    s.cmp.ge     s21, s19, s20
    br.nz        s21, idiv_16
    v.movi       v0, #0
    v.sub        v3, v1, v8
    v.movi       v1, #1
    v.sub        v5, v0, v4
    v.sub        v6, v0, v2
    v.cmp.lt     p2, v4, v0
    @p1 v.sel        v13, v3, v8
    v.cmp.lt     p1, v2, v0
    @p2 v.sel        v3, v5, v4
    @p1 v.sel        v4, v6, v2
    v.movi       v5, #0
    v.movi       v6, #0
    s.movz       s19, #31
idiv_17:
    v.splat      v8, s19
    v.shl        v16, v6, v1
    v.cmp.lt     p1, v6, v0
    v.lshr       v17, v3, v8
    v.shl        v18, v1, v8
    s.subi       s20, s19, #1
    v.and        v8, v17, v1
    v.or         v17, v16, v8
    v.cmp.geu    p3, v17, v4
    p.or         p4, p1, p3
    v.sub        v8, v17, v4
    @p4 v.sel        v16, v18, v0
    @p4 v.sel        v18, v8, v17
    v.or         v8, v5, v16
    v.mov        v6, v18
    v.mov        v5, v8
    s.mov        s19, s20
    s.movz       s20, #0
    s.cmp.ge     s21, s19, s20
    br.nz        s21, idiv_17
    v.movi       v1, #0
    v.sub        v3, v0, v6
    v.movi       v0, #1
    v.sub        v4, v1, v14
    v.sub        v5, v1, v2
    v.cmp.lt     p1, v14, v1
    @p2 v.sel        v8, v3, v6
    v.cmp.lt     p2, v2, v1
    @p1 v.sel        v3, v4, v14
    @p2 v.sel        v4, v5, v2
    v.movi       v5, #0
    v.movi       v6, #0
    s.movz       s19, #31
idiv_18:
    v.splat      v14, s19
    v.shl        v16, v6, v0
    v.cmp.lt     p2, v6, v1
    v.lshr       v17, v3, v14
    v.shl        v18, v0, v14
    s.subi       s21, s19, #1
    v.and        v14, v17, v0
    v.or         v17, v16, v14
    v.cmp.geu    p3, v17, v4
    p.or         p4, p2, p3
    v.sub        v14, v17, v4
    @p4 v.sel        v16, v18, v1
    @p4 v.sel        v18, v14, v17
    v.or         v14, v5, v16
    v.mov        v6, v18
    v.mov        v5, v14
    s.mov        s19, s21
    s.cmp.ge     s21, s19, s20
    br.nz        s21, idiv_18
    v.movi       v0, #0
    v.sub        v3, v1, v6
    v.movi       v1, #1
    v.sub        v4, v0, v7
    v.cmp.lt     p2, v7, v0
    @p1 v.sel        v5, v3, v6
    v.sub        v3, v0, v2
    v.cmp.lt     p1, v2, v0
    @p2 v.sel        v6, v4, v7
    @p1 v.sel        v4, v3, v2
    v.movi       v2, #0
    v.movi       v3, #0
    s.movz       s19, #31
idiv_19:
    v.splat      v7, s19
    v.shl        v14, v3, v1
    v.cmp.lt     p1, v3, v0
    v.lshr       v16, v6, v7
    v.shl        v17, v1, v7
    s.subi       s20, s19, #1
    v.and        v7, v16, v1
    v.or         v16, v14, v7
    v.cmp.geu    p3, v16, v4
    p.or         p4, p1, p3
    v.sub        v7, v16, v4
    @p4 v.sel        v14, v17, v0
    @p4 v.sel        v17, v7, v16
    v.or         v7, v2, v14
    v.mov        v3, v17
    v.mov        v2, v7
    s.mov        s19, s20
    s.movz       s20, #0
    s.cmp.ge     s21, s19, s20
    br.nz        s21, idiv_19
    v.sub        v1, v0, v3
    @p2 v.sel        v0, v1, v3
    s.movz       s19, #16
    s.movz       s20, #32
    s.movz       s21, #48
    s.movz       s22, #64
    s.movz       s23, #80
    s.movz       s24, #96
    s.movz       s25, #112
    v.movi       v1, #128
    v.movi       v2, #0
    v.movi       v3, #1
    v.cmp.lt     p1, v11, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v11
    @p1 v.sel        v4, v3, v11
    v.sub        v3, v2, v1
    @p2 v.sel        v6, v3, v1
    v.movi       v1, #7
    v.lshr       v3, v4, v1
    v.sub        v1, v2, v3
    @p1 v.sel        v2, v1, v3
    v.movi       v1, #128
    v.movi       v3, #0
    v.movi       v4, #1
    v.cmp.lt     p1, v10, v3
    v.cmp.lt     p2, v1, v3
    v.sub        v4, v3, v10
    @p1 v.sel        v6, v4, v10
    v.sub        v4, v3, v1
    @p2 v.sel        v7, v4, v1
    v.movi       v1, #7
    v.lshr       v4, v6, v1
    v.sub        v1, v3, v4
    @p1 v.sel        v3, v1, v4
    v.movi       v1, #128
    v.movi       v4, #0
    v.movi       v6, #1
    v.cmp.lt     p1, v15, v4
    v.cmp.lt     p2, v1, v4
    v.sub        v6, v4, v15
    @p1 v.sel        v7, v6, v15
    v.sub        v6, v4, v1
    @p2 v.sel        v14, v6, v1
    v.movi       v1, #7
    v.lshr       v6, v7, v1
    v.sub        v1, v4, v6
    @p1 v.sel        v4, v1, v6
    v.movi       v1, #128
    v.movi       v6, #0
    v.movi       v7, #1
    v.cmp.lt     p1, v9, v6
    v.cmp.lt     p2, v1, v6
    v.sub        v7, v6, v9
    @p1 v.sel        v14, v7, v9
    v.sub        v7, v6, v1
    @p2 v.sel        v16, v7, v1
    v.movi       v1, #7
    v.lshr       v7, v14, v1
    v.sub        v1, v6, v7
    @p1 v.sel        v6, v1, v7
    v.movi       v1, #128
    v.movi       v7, #0
    v.movi       v14, #1
    v.cmp.lt     p1, v13, v7
    v.cmp.lt     p2, v1, v7
    v.sub        v14, v7, v13
    @p1 v.sel        v16, v14, v13
    v.sub        v14, v7, v1
    @p2 v.sel        v17, v14, v1
    v.movi       v1, #7
    v.lshr       v14, v16, v1
    v.sub        v1, v7, v14
    @p1 v.sel        v7, v1, v14
    v.movi       v1, #128
    v.movi       v14, #0
    v.movi       v16, #1
    v.cmp.lt     p1, v8, v14
    v.cmp.lt     p2, v1, v14
    v.sub        v16, v14, v8
    @p1 v.sel        v17, v16, v8
    v.sub        v16, v14, v1
    @p2 v.sel        v18, v16, v1
    v.movi       v1, #7
    v.lshr       v16, v17, v1
    v.sub        v1, v14, v16
    @p1 v.sel        v14, v1, v16
    v.movi       v1, #128
    v.movi       v16, #0
    v.movi       v17, #1
    v.cmp.lt     p1, v5, v16
    v.cmp.lt     p2, v1, v16
    v.sub        v17, v16, v5
    @p1 v.sel        v18, v17, v5
    v.sub        v17, v16, v1
    @p2 v.sel        v19, v17, v1
    v.movi       v1, #7
    v.lshr       v17, v18, v1
    v.sub        v1, v16, v17
    @p1 v.sel        v16, v1, v17
    v.movi       v1, #128
    v.movi       v17, #0
    v.movi       v18, #1
    v.cmp.lt     p1, v0, v17
    v.cmp.lt     p2, v1, v17
    v.sub        v18, v17, v0
    @p1 v.sel        v19, v18, v0
    v.sub        v18, v17, v1
    @p2 v.sel        v20, v18, v1
    v.movi       v1, #7
    v.lshr       v18, v19, v1
    v.sub        v1, v17, v18
    @p1 v.sel        v17, v1, v18
    v.splat      v1, s15
    v.mul        v18, v2, v1
    v.mul        v2, v3, v1
    v.mul        v3, v4, v1
    v.mul        v4, v6, v1
    v.mul        v6, v7, v1
    v.mul        v7, v14, v1
    v.mul        v14, v16, v1
    v.mul        v16, v17, v1
    s.ld.w       s26, [s7, #0]                   // one element, not a vector
    s.add        s27, s11, s1
    s.movz       s1, #0
    s.cmp.lt     s28, s27, s1
    s.sub        s29, s1, s28
    s.cmp.lt     s28, s16, s1
    s.sub        s30, s1, s28
    s.xor        s28, s27, s29
    s.sub        s27, s28, s29
    s.xor        s28, s16, s30
    s.sub        s31, s28, s30
    s.lshri      s28, s27, #7
    s.muli       s31, s28, #128
    s.sub        s32, s27, s31
    s.xor        s27, s29, s30
    s.xor        s29, s28, s27
    s.sub        s28, s29, s27
    s.movz       s27, #1
    s.addi       s29, s1, #0
    s.addi       s30, s1, #0
    s.addi       s31, s1, #0
    s.addi       s32, s8, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_28:
    s.cmp.ge     s33, s29, s28
    br.nz        s33, endfor_29
    s.mul        s33, s29, s16
    v.splat      v1, s13
    v.splat      v17, s13
    v.ld.gather.w v19, [s32, v18]                // index is in elements (ISA sec 9.1)
    v.mul        v20, v11, v1
    s.sub        s34, s11, s33
    v.mul        v21, v10, v1
    v.mul        v22, v15, v1
    v.mul        v23, v9, v1
    v.mul        v24, v13, v1
    v.mul        v1, v8, v17
    v.mul        v25, v5, v17
    v.mul        v26, v0, v17
    v.splat      v17, s26
    // tl.dot 16x128 by 128x128 FP8, B as W's rows written transposed by the engine (ISA sec 9E, tensor_transpose_8bit)
    s.rdspecial  s33, arg_base
    s.add        s35, s1, s34
    s.ld.d       s36, [s33, #96]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.addi       s33, s36, #0
    s.addi       s37, s36, #64
    s.addi       s38, s36, #128
    v.ld.gather.w v27, [s32, v2]                 // index is in elements (ISA sec 9.1)
    s.addi       s39, s36, #192
    v.ld.gather.w v28, [s32, v3]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v29, [s32, v4]                 // index is in elements (ISA sec 9.1)
    s.addi       s40, s36, #256
    v.ld.gather.w v30, [s32, v6]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v31, [s32, v7]                 // index is in elements (ISA sec 9.1)
    s.addi       s41, s36, #320
    v.ld.gather.w v32, [s32, v14]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v33, [s32, v16]                // index is in elements (ISA sec 9.1)
    s.addi       s42, s36, #384
    s.addi       s43, s36, #448
    v.st.w       [s33, #0], v20
    v.movi       v20, #0
    v.st.w       [s37, #0], v21
    v.iota       v21                             // arange(0, VLEN)
    s.movz       s33, #0
    v.st.w       [s38, #0], v22
    v.extract    s37, v11, #0
    s.cmp.ge     s38, s35, s33
    v.movi       v22, #0
    v.st.w       [s39, #0], v23
    v.splat      v23, s37
    v.add        v34, v23, v21
    v.st.w       [s40, #0], v24
    v.sub        v23, v11, v34
    v.reduce.or  s39, v23
    v.st.w       [s41, #0], v1
    s.cmp.eq     s40, s39, s33
    s.cmp.ge     s39, s37, s33
    v.st.w       [s42, #0], v25
    s.and        s41, s40, s39
    s.and        s39, s41, s38
    v.st.w       [s43, #0], v26
    fence.acq_rel.device
    v.extract    s40, v10, #0
    v.extract    s41, v15, #0
    v.splat      v1, s40
    v.splat      v23, s41
    s.cmp.ge     s42, s40, s33
    v.add        v24, v1, v21
    v.add        v1, v23, v21
    v.insert     v20, s39, #0
    v.sub        v23, v10, v24
    v.sub        v24, v15, v1
    v.insert     v22, s37, #0
    v.reduce.or  s37, v23
    v.reduce.or  s39, v24
    s.cmp.eq     s43, s37, s33
    v.extract    s37, v9, #0
    s.and        s44, s43, s42
    v.splat      v1, s37
    s.cmp.eq     s42, s39, s33
    s.cmp.ge     s39, s41, s33
    s.and        s43, s44, s38
    v.add        v23, v1, v21
    s.and        s44, s42, s39
    v.insert     v20, s43, #1
    v.sub        v1, v9, v23
    s.and        s39, s44, s38
    v.insert     v22, s40, #1
    v.extract    s40, v13, #0
    v.reduce.or  s42, v1
    v.splat      v1, s40
    s.cmp.eq     s43, s42, s33
    s.cmp.ge     s42, s37, s33
    v.add        v23, v1, v21
    s.and        s44, s43, s42
    v.insert     v20, s39, #2
    v.sub        v1, v13, v23
    s.and        s39, s44, s38
    v.insert     v22, s41, #2
    v.extract    s41, v8, #0
    v.reduce.or  s42, v1
    v.splat      v1, s41
    s.cmp.eq     s43, s42, s33
    s.cmp.ge     s42, s40, s33
    v.add        v23, v1, v21
    s.and        s33, s43, s42
    v.insert     v20, s39, #3
    v.sub        v1, v8, v23
    s.and        s39, s33, s38
    v.insert     v22, s37, #3
    v.extract    s33, v5, #0
    v.reduce.or  s37, v1
    v.splat      v1, s33
    s.movz       s42, #0
    v.insert     v20, s39, #4
    v.add        v23, v1, v21
    s.cmp.eq     s39, s37, s42
    s.cmp.ge     s37, s41, s42
    v.insert     v22, s40, #4
    v.extract    s40, v0, #0
    v.sub        v1, v5, v23
    s.and        s43, s39, s37
    v.splat      v23, s40
    v.reduce.or  s37, v1
    s.cmp.ge     s39, s33, s42
    s.cmp.eq     s44, s37, s42
    s.and        s37, s43, s38
    v.add        v1, v23, v21
    s.and        s43, s44, s39
    v.insert     v20, s37, #5
    v.sub        v21, v0, v1
    s.and        s37, s43, s38
    v.insert     v22, s41, #5
    v.reduce.or  s39, v21
    s.cmp.ge     s41, s40, s42
    s.cmp.eq     s43, s39, s42
    v.insert     v20, s37, #6
    s.and        s37, s43, s41
    v.insert     v22, s33, #6
    s.and        s33, s37, s38
    s.add        s37, s5, s31
    v.insert     v20, s33, #7
    s.addi       s33, s36, #512                  // TensorMap 0: W's rows for a transposed FP8 B
    .li       s38, #2147483647
    s.movz       s39, #1
    .li       s41, #137438953488
    .li       s42, #7705171329024
    v.insert     v22, s40, #7
    s.addi       s40, s36, #768
    s.addi       s43, s36, #1792                 // TensorMap 1: the gathered fallback B tile
    s.st.d       [s33, #0], s37
    s.movz       s37, #32
    s.st.d       [s33, #8], s38
    s.movz       s38, #16
    s.st.d       [s33, #16], s35
    s.st.d       [s33, #48], s13
    s.st.d       [s33, #56], s39
    .li       s44, #68719476768
    s.st.d       [s33, #88], s41
    s.st.d       [s33, #104], s42
    fence.release.device
    s.addi       s41, s36, #1280
    td.load      d0, [s33]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s33, s36, #2048                 // TensorMap 2: the gathered fallback B tile
    s.st.d       [s43, #0], s40
    s.st.d       [s43, #8], s37
    s.st.d       [s43, #16], s38
    s.st.d       [s43, #48], s38
    s.st.d       [s43, #56], s39
    s.st.d       [s43, #88], s44
    s.st.d       [s43, #104], s42
    fence.release.device
    td.load      d1, [s43]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s43, #0
    s.st.d       [s33, #0], s41
    s.st.d       [s33, #8], s37
    s.st.d       [s33, #16], s38
    v.extract    s41, v20, #0
    s.st.d       [s33, #48], s38
    s.st.d       [s33, #56], s39
    s.st.d       [s33, #88], s44
    s.st.d       [s33, #104], s42
    fence.release.device
    td.load      d2, [s33]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s41, x8dot_done_30
    s.addi       s33, s36, #0
    s.addi       s38, s43, #0
    v.ld.w       v1, [s33, #0]
    s.add        s33, s5, s31
x8dot_row_31:
    s.addi       s39, s35, #0
    v.movi       v21, #0
    s.sub        s42, s39, s38
    s.add        s39, s33, s38
    v.splat      v23, s42
    s.shli       s42, s38, #4
    v.cmp.gt     p1, v23, v21
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v21, [s39, v1]             // index is in elements (ISA sec 9.1)
    s.add        s39, s40, s42
    s.addi       s42, s38, #1
    v.st.b       [s39, #0], v21
    fence.acq_rel.device
    s.mov        s38, s42
    s.cmp.lt     s39, s38, s37
    br.nz        s39, x8dot_row_31
x8dot_done_30:
    v.splat      v1, s41
    v.movi       v21, #0
    mb.arm       s33, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s37, v22, #0
    v.cmp.ne     p1, v1, v21
    v.cmp.eq     p2, v1, v21
    s.mov        s38, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s38, s33            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s38, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s38, s33          // predicated off still completes once (ISA sec 9A.3)
    v.extract    s37, v20, #1
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s37, x8dot_done_32
    s.movz       s38, #0
    s.addi       s39, s36, #64
    s.addi       s40, s38, #0
    v.ld.w       v1, [s39, #0]
    s.add        s38, s5, s31
    s.addi       s39, s36, #1280
x8dot_row_33:
    s.addi       s41, s35, #0
    v.movi       v21, #0
    s.sub        s42, s41, s40
    s.add        s41, s38, s40
    v.splat      v23, s42
    s.shli       s42, s40, #4
    v.cmp.gt     p1, v23, v21
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v21, [s41, v1]             // index is in elements (ISA sec 9.1)
    s.add        s41, s39, s42
    s.addi       s42, s40, #1
    s.movz       s43, #32
    v.st.b       [s41, #0], v21
    fence.acq_rel.device
    s.mov        s40, s42
    s.cmp.lt     s41, s40, s43
    br.nz        s41, x8dot_row_33
x8dot_done_32:
    s.muli       s38, s12, #2
    s.muli       s39, s30, #2
    s.movz       s40, #0
    v.splat      v1, s37
    v.movi       v21, #0
    v.splat      v23, s38
    mb.arm       s37, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.add        s38, s40, s34                   // the tile origin
    v.mul        v24, v12, v23
    v.iota       v23                             // arange(0, VLEN)
    v.extract    s41, v22, #1
    v.extract    s42, v24, #0
    v.cmp.ne     p1, v1, v21
    s.add        s43, s42, s39
    v.splat      v25, s38
    s.add        s38, s3, s43
    v.cmp.eq     p2, v1, v21
    s.mov        s42, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s42, s37            // predicated off still completes once (ISA sec 9A.3)
    v.rcp.approx v1, v17                         // ISA 8.8: <= 2**-22 relative
    v.cmp.lt     p2, v23, v25
    s.mov        s42, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s42, s37          // predicated off still completes once (ISA sec 9A.3)
    .li       s40, #1065353216
    v.splat      v21, s40                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v25, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v25, [s38, #0]
    s.addi       s38, s36, #2304                 // 512 bytes of repack scratch
    v.movi       v26, #24
    vf.cvt.bf16.f32 v34, v25
    v.movi       v25, #128
    vf.fms       v35, v17, v1, v21
    vf.fms       v36, v1, v35, v1
    s.addi       s40, s38, #0
    vf.neg       v35, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v35, v35
    @p1 v.sel        v36, v35, v1
    v.extract    s41, v24, #1
    vf.mul       v1, v34, v36                    // a/y: faithful quotient
    s.add        s42, s41, s39
    s.add        s41, s3, s42
    vf.fms       v35, v1, v17, v34
    vf.fms       v34, v35, v36, v1
    vf.neg       v35, v34                        // a/y: one correction to the IEEE quotient
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v35, v35
    @p1 v.sel        v36, v35, v1
    v.lshr       v1, v36, v26
    vf.cvt.f32.e4m3 v35, v36
    v.and        v36, v1, v25
    v.or         v1, v35, v36                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v35, [s41, #0]
    vf.fms       v36, v34, v1, v34
    vf.neg       v1, v36                         // Newton step: r0*(2 - x*r0)
    vf.cvt.bf16.f32 v36, v35
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v35, v1, v34
    v.extract    s40, v24, #2
    s.addi       s41, s38, #32
    vf.mul       v1, v36, v35                    // a/y: faithful quotient
    s.add        s42, s40, s39
    s.add        s40, s3, s42
    vf.fms       v34, v1, v17, v36
    vf.fms       v36, v34, v35, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v35, v36                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v35, v35
    @p1 v.sel        v36, v35, v1
    v.lshr       v1, v36, v26
    vf.cvt.f32.e4m3 v35, v36
    v.and        v36, v1, v25
    v.or         v1, v35, v36                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s40, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s40, v24, #3
    s.addi       s41, s38, #64
    s.add        s42, s40, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.add        s40, s3, s42
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s40, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s40, v24, #4
    s.addi       s41, s38, #96
    s.add        s42, s40, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.add        s40, s3, s42
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s40, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s40, v24, #5
    s.addi       s41, s38, #128
    s.add        s42, s40, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.add        s40, s3, s42
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s40, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s40, v24, #6
    s.addi       s41, s38, #160
    s.add        s42, s40, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.add        s40, s3, s42
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s40, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s40, v24, #7
    s.addi       s41, s38, #192
    s.add        s42, s40, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.add        s40, s3, s42
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s40, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s40, v24, #8
    s.addi       s41, s38, #224
    s.add        s42, s40, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.add        s40, s3, s42
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s40, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s40, v24, #9
    s.addi       s41, s38, #256
    s.add        s42, s40, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.add        s40, s3, s42
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s40, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s40, v24, #10
    s.addi       s41, s38, #288
    s.add        s42, s40, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.add        s40, s3, s42
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s40, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s40, v24, #11
    s.addi       s41, s38, #320
    s.add        s42, s40, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.add        s40, s3, s42
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s40, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s40, v24, #12
    s.addi       s41, s38, #352
    s.add        s42, s40, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.add        s40, s3, s42
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s40, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s40, v24, #13
    s.addi       s41, s38, #384
    s.add        s42, s40, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.add        s40, s3, s42
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s40, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s40, v24, #14
    s.addi       s41, s38, #416
    s.add        s42, s40, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.add        s40, s3, s42
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s40, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s40, v24, #15
    s.addi       s41, s38, #448
    s.add        s42, s40, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.add        s40, s3, s42
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s40, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s40, v24, #0
    s.addi       s41, s38, #480
    s.add        s42, s40, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.movz       s40, #0
    s.addi       s43, s42, #32
    s.add        s42, s3, s43
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    vf.neg       v34, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v35, v34, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v34, v35
    v.and        v35, v1, v25
    v.or         v1, v34, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    v.st.b       [s41, #0], v1
    s.add        s41, s40, s19                   // the tile origin
    s.add        s43, s40, s34                   // the tile origin
    v.splat      v1, s41
    v.splat      v35, s43
    v.add        v36, v23, v1
    v.cmp.lt     p1, v36, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s42, #0]
    vf.fms       v35, v17, v34, v21
    vf.cvt.bf16.f32 v36, v1
    s.addi       s40, s38, #16
    vf.fms       v1, v34, v35, v34
    v.extract    s41, v24, #1
    vf.neg       v35, v1                         // Newton step: r0*(2 - x*r0)
    s.add        s42, s41, s39
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v1, v35, v34
    s.addi       s41, s42, #32
    vf.mul       v34, v36, v1                    // a/y: faithful quotient
    s.add        s42, s3, s41
    vf.fms       v35, v34, v17, v36
    vf.fms       v36, v35, v1, v34
    v.rcp.approx v1, v17                         // ISA 8.8: <= 2**-22 relative
    vf.neg       v35, v36                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v36, v35, v34
    v.lshr       v34, v36, v26
    vf.cvt.f32.e4m3 v35, v36
    v.and        v36, v34, v25
    v.or         v34, v35, v36                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v34
    vf.fms       v34, v17, v1, v21
    vf.fms       v35, v1, v34, v1
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v34, [s42, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v1
    vf.cvt.bf16.f32 v1, v34
    v.extract    s40, v24, #2
    s.addi       s41, s38, #48
    s.add        s42, s40, s39
    vf.mul       v34, v1, v35                    // a/y: faithful quotient
    s.addi       s40, s42, #32
    s.add        s42, s3, s40
    vf.fms       v36, v34, v17, v1
    vf.fms       v1, v36, v35, v34
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v1                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v1, v36, v34
    v.lshr       v34, v1, v26
    vf.cvt.f32.e4m3 v36, v1
    v.and        v1, v34, v25
    v.or         v34, v36, v1                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v34
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s42, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s40, v24, #3
    s.addi       s41, s38, #80
    s.add        s42, s40, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s40, s42, #32
    s.add        s42, s3, s40
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s42, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s40, v24, #4
    s.addi       s41, s38, #112
    s.add        s42, s40, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s40, s42, #32
    s.add        s42, s3, s40
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s42, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s40, v24, #5
    s.addi       s41, s38, #144
    s.add        s42, s40, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s40, s42, #32
    s.add        s42, s3, s40
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s42, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s40, v24, #6
    s.addi       s41, s38, #176
    s.add        s42, s40, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s40, s42, #32
    s.add        s42, s3, s40
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s42, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s40, v24, #7
    s.addi       s41, s38, #208
    s.add        s42, s40, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s40, s42, #32
    s.add        s42, s3, s40
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s42, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s40, v24, #8
    s.addi       s41, s38, #240
    s.add        s42, s40, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s40, s42, #32
    s.add        s42, s3, s40
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s42, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s40, v24, #9
    s.addi       s41, s38, #272
    s.add        s42, s40, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s40, s42, #32
    s.add        s42, s3, s40
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s42, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s40, v24, #10
    s.addi       s41, s38, #304
    s.add        s42, s40, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s40, s42, #32
    s.add        s42, s3, s40
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s42, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s40, v24, #11
    s.addi       s41, s38, #336
    s.add        s42, s40, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s40, s42, #32
    s.add        s42, s3, s40
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s42, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s40, v24, #12
    s.addi       s41, s38, #368
    s.add        s42, s40, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s40, s42, #32
    s.add        s42, s3, s40
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s42, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s40, v24, #13
    s.addi       s41, s38, #400
    s.add        s42, s40, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s40, s42, #32
    s.add        s42, s3, s40
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s42, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s40, v24, #14
    s.addi       s41, s38, #432
    s.add        s42, s40, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s40, s42, #32
    s.add        s42, s3, s40
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s42, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s40, v24, #15
    s.addi       s41, s38, #464
    s.add        s42, s40, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s40, s42, #32
    s.add        s42, s3, s40
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s42, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    s.addi       s40, s38, #496
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s41, s38, #64
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    vf.neg       v35, v34                        // a/y: one correction to the IEEE quotient
    s.addi       s42, s38, #128
    vf.cmp.o     p1, v35, v35
    @p1 v.sel        v34, v35, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v35, v34
    v.and        v34, v1, v25
    v.or         v1, v35, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    s.addi       s40, s38, #192
    v.ld.w       v1, [s38, #0]
    v.mov        v56, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s41, #0]
    s.addi       s41, s38, #256
    v.mov        v57, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s42, #0]
    s.addi       s42, s38, #320
    v.mov        v58, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s40, #0]
    s.addi       s40, s38, #384
    s.addi       s43, s38, #448
    v.mov        v59, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s41, #0]
    v.extract    s38, v20, #2
    v.mov        v60, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s42, #0]
    v.mov        v61, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s40, #0]
    v.mov        v62, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s43, #0]
    v.mov        v63, v1                         // hand off through the shared window (sec 7.3)
    mb.wait      s33
    mb.arm       s40, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s40
    mb.wait      s40
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s38, x8dot_done_34
    s.movz       s41, #0
    s.addi       s42, s36, #128
    s.addi       s43, s41, #0
    v.ld.w       v1, [s42, #0]
    s.add        s41, s5, s31
    s.addi       s42, s36, #768
x8dot_row_35:
    s.addi       s44, s35, #0
    v.movi       v34, #0
    s.sub        s45, s44, s43
    s.add        s44, s41, s43
    v.splat      v35, s45
    s.shli       s45, s43, #4
    v.cmp.gt     p1, v35, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s44, v1]             // index is in elements (ISA sec 9.1)
    s.add        s44, s42, s45
    s.addi       s45, s43, #1
    s.movz       s46, #32
    v.st.b       [s44, #0], v34
    fence.acq_rel.device
    s.mov        s43, s45
    s.cmp.lt     s44, s43, s46
    br.nz        s44, x8dot_row_35
x8dot_done_34:
    v.splat      v1, s38
    v.movi       v34, #0
    mb.arm       s38, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s41, #0
    v.extract    s42, v22, #2
    v.cmp.ne     p1, v1, v34
    v.cmp.eq     p2, v1, v34
    s.mov        s43, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s43, s38            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s43, s38          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s42, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s43, v20, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s42
    mb.wait      s42
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s43, x8dot_done_36
    s.addi       s44, s36, #192
    s.addi       s45, s41, #0
    v.ld.w       v1, [s44, #0]
    s.add        s44, s5, s31
    s.addi       s46, s36, #1280
x8dot_row_37:
    s.addi       s47, s35, #0
    v.movi       v34, #0
    s.sub        s48, s47, s45
    s.add        s47, s44, s45
    v.splat      v35, s48
    s.shli       s48, s45, #4
    v.cmp.gt     p1, v35, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s47, v1]             // index is in elements (ISA sec 9.1)
    s.add        s47, s46, s48
    s.addi       s48, s45, #1
    s.movz       s49, #32
    v.st.b       [s47, #0], v34
    fence.acq_rel.device
    s.mov        s45, s48
    s.cmp.lt     s47, s45, s49
    br.nz        s47, x8dot_row_37
x8dot_done_36:
    v.splat      v1, s43
    v.movi       v34, #0
    mb.arm       s43, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s44, v22, #3
    v.cmp.ne     p1, v1, v34
    v.cmp.eq     p2, v1, v34
    s.mov        s45, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s45, s43            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s45, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s45, s43          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s38
    mb.arm       s44, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s45, v20, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s44
    mb.wait      s44
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s45, x8dot_done_38
    s.addi       s46, s36, #256
    s.addi       s47, s41, #0
    v.ld.w       v1, [s46, #0]
    s.add        s41, s5, s31
    s.addi       s46, s36, #768
x8dot_row_39:
    s.addi       s48, s35, #0
    v.movi       v34, #0
    s.sub        s49, s48, s47
    s.add        s48, s41, s47
    v.splat      v35, s49
    s.shli       s49, s47, #4
    v.cmp.gt     p1, v35, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s48, v1]             // index is in elements (ISA sec 9.1)
    s.add        s48, s46, s49
    s.addi       s49, s47, #1
    s.movz       s50, #32
    v.st.b       [s48, #0], v34
    fence.acq_rel.device
    s.mov        s47, s49
    s.cmp.lt     s48, s47, s50
    br.nz        s48, x8dot_row_39
x8dot_done_38:
    v.splat      v1, s45
    v.movi       v34, #0
    mb.arm       s41, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s45, #0
    v.extract    s46, v22, #4
    v.cmp.ne     p1, v1, v34
    v.cmp.eq     p2, v1, v34
    s.mov        s47, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s47, s41            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s47, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s47, s41          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s43
    mb.arm       s46, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s47, v20, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s46
    mb.wait      s46
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s47, x8dot_done_40
    s.addi       s48, s36, #320
    s.addi       s49, s45, #0
    v.ld.w       v1, [s48, #0]
    s.add        s48, s5, s31
    s.addi       s50, s36, #1280
x8dot_row_41:
    s.addi       s51, s35, #0
    v.movi       v34, #0
    s.sub        s52, s51, s49
    s.add        s51, s48, s49
    v.splat      v35, s52
    s.shli       s52, s49, #4
    v.cmp.gt     p1, v35, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s51, v1]             // index is in elements (ISA sec 9.1)
    s.add        s51, s50, s52
    s.addi       s52, s49, #1
    s.movz       s53, #32
    v.st.b       [s51, #0], v34
    fence.acq_rel.device
    s.mov        s49, s52
    s.cmp.lt     s51, s49, s53
    br.nz        s51, x8dot_row_41
x8dot_done_40:
    v.splat      v1, s47
    v.movi       v34, #0
    mb.arm       s47, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s48, v22, #5
    v.cmp.ne     p1, v1, v34
    v.cmp.eq     p2, v1, v34
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s49, s47            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s49, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s49, s47          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s41
    mb.arm       s48, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s49, v20, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s48
    mb.wait      s48
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s49, x8dot_done_42
    s.addi       s50, s36, #384
    s.addi       s51, s45, #0
    v.ld.w       v1, [s50, #0]
    s.add        s45, s5, s31
    s.addi       s50, s36, #768
x8dot_row_43:
    s.addi       s52, s35, #0
    v.movi       v34, #0
    s.sub        s53, s52, s51
    s.add        s52, s45, s51
    v.splat      v35, s53
    s.shli       s53, s51, #4
    v.cmp.gt     p1, v35, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s52, v1]             // index is in elements (ISA sec 9.1)
    s.add        s52, s50, s53
    s.addi       s53, s51, #1
    s.movz       s54, #32
    v.st.b       [s52, #0], v34
    fence.acq_rel.device
    s.mov        s51, s53
    s.cmp.lt     s52, s51, s54
    br.nz        s52, x8dot_row_43
x8dot_done_42:
    v.splat      v1, s49
    v.movi       v34, #0
    mb.arm       s45, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s49, #0
    v.extract    s50, v22, #6
    v.cmp.ne     p1, v1, v34
    v.cmp.eq     p2, v1, v34
    s.mov        s51, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s51, s45            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s51, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s51, s45          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s47
    mb.arm       s50, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s51, v20, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s50
    mb.wait      s50
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s51, x8dot_done_44
    s.addi       s52, s36, #448
    s.addi       s53, s49, #0
    v.ld.w       v1, [s52, #0]
    s.add        s52, s5, s31
    s.addi       s54, s36, #1280
x8dot_row_45:
    s.addi       s55, s35, #0
    v.movi       v34, #0
    s.sub        s56, s55, s53
    s.add        s55, s52, s53
    v.splat      v35, s56
    s.shli       s56, s53, #4
    v.cmp.gt     p1, v35, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s55, v1]             // index is in elements (ISA sec 9.1)
    s.add        s55, s54, s56
    s.addi       s56, s53, #1
    s.movz       s57, #32
    v.st.b       [s55, #0], v34
    fence.acq_rel.device
    s.mov        s53, s56
    s.cmp.lt     s55, s53, s57
    br.nz        s55, x8dot_row_45
x8dot_done_44:
    v.splat      v1, s51
    v.movi       v34, #0
    mb.arm       s51, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s52, v22, #7
    v.cmp.ne     p1, v1, v34
    v.cmp.eq     p2, v1, v34
    s.mov        s53, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s53, s51            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s53, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s53, s51          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s45
    mb.arm       s52, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s53, v20, #0
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s52
    mb.wait      s52
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s53, x8dot_done_46
    s.addi       s54, s36, #0
    s.add        s55, s5, s31
    s.addi       s56, s49, #0
    v.ld.w       v1, [s54, #0]
    s.addi       s49, s55, #32
    s.addi       s54, s36, #768
x8dot_row_47:
    s.addi       s55, s35, #-32
    v.movi       v34, #0
    s.sub        s57, s55, s56
    s.add        s55, s49, s56
    v.splat      v35, s57
    s.shli       s57, s56, #4
    v.cmp.gt     p1, v35, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s55, v1]             // index is in elements (ISA sec 9.1)
    s.add        s55, s54, s57
    s.addi       s57, s56, #1
    s.movz       s58, #32
    v.st.b       [s55, #0], v34
    fence.acq_rel.device
    s.mov        s56, s57
    s.cmp.lt     s55, s56, s58
    br.nz        s55, x8dot_row_47
x8dot_done_46:
    v.splat      v1, s53
    v.movi       v34, #0
    mb.arm       s49, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s53, #0
    v.extract    s54, v22, #0
    s.movz       s55, #32
    v.cmp.ne     p1, v1, v34
    v.cmp.eq     p2, v1, v34
    s.mov        s56, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s56, s49            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s56, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s56, s49          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s51
    mb.arm       s54, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s56, v20, #1
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s54
    mb.wait      s54
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s56, x8dot_done_48
    s.addi       s57, s36, #64
    s.add        s58, s5, s31
    s.addi       s59, s53, #0
    v.ld.w       v1, [s57, #0]
    s.addi       s57, s58, #32
    s.addi       s58, s36, #1280
x8dot_row_49:
    s.addi       s60, s35, #-32
    v.movi       v34, #0
    s.sub        s33, s60, s59
    s.add        s37, s57, s59
    v.splat      v35, s33
    s.shli       s33, s59, #4
    v.cmp.gt     p1, v35, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s37, v1]             // index is in elements (ISA sec 9.1)
    s.add        s37, s58, s33
    s.addi       s33, s59, #1
    v.st.b       [s37, #0], v34
    fence.acq_rel.device
    s.mov        s59, s33
    s.cmp.lt     s33, s59, s55
    br.nz        s33, x8dot_row_49
x8dot_done_48:
    s.add        s33, s53, s20                   // the tile origin
    v.splat      v1, s56
    v.extract    s37, v24, #0
    v.splat      v34, s33
    s.add        s33, s37, s39
    v.movi       v35, #0
    s.addi       s37, s33, #64
    v.add        v36, v23, v34
    mb.arm       s33, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.add        s38, s53, s34                   // the tile origin
    s.add        s40, s3, s37
    v.cmp.ne     p1, v1, v35
    v.cmp.eq     p2, v1, v35
    v.splat      v1, s38
    v.extract    s37, v22, #1
    s.mov        s41, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s41, s33            // predicated off still completes once (ISA sec 9A.3)
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    v.cmp.lt     p2, v36, v1
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s33          // predicated off still completes once (ISA sec 9A.3)
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s40, #0]
    s.addi       s37, s36, #2816                 // 512 bytes of repack scratch
    vf.cvt.bf16.f32 v35, v1
    s.addi       s38, s37, #0
    vf.fms       v1, v17, v34, v21
    vf.fms       v36, v34, v1, v34
    v.extract    s40, v24, #1
    vf.neg       v1, v36                         // Newton step: r0*(2 - x*r0)
    s.add        s41, s40, s39
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v36, v1, v34
    s.addi       s40, s41, #64
    vf.mul       v1, v35, v36                    // a/y: faithful quotient
    s.add        s41, s3, s40
    vf.fms       v34, v1, v17, v35
    vf.fms       v35, v34, v36, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #2
    s.addi       s40, s37, #32
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #64
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #3
    s.addi       s40, s37, #64
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #64
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #4
    s.addi       s40, s37, #96
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #64
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #5
    s.addi       s40, s37, #128
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #64
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #6
    s.addi       s40, s37, #160
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #64
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #7
    s.addi       s40, s37, #192
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #64
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #8
    s.addi       s40, s37, #224
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #64
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #9
    s.addi       s40, s37, #256
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #64
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #10
    s.addi       s40, s37, #288
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #64
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #11
    s.addi       s40, s37, #320
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #64
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #12
    s.addi       s40, s37, #352
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #64
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #13
    s.addi       s40, s37, #384
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #64
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #14
    s.addi       s40, s37, #416
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #64
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #15
    s.addi       s40, s37, #448
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #64
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #0
    s.addi       s40, s37, #480
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.movz       s38, #0
    s.addi       s42, s41, #96
    s.add        s41, s3, s42
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    vf.neg       v35, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v35, v35
    @p1 v.sel        v34, v35, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v35, v34
    v.and        v34, v1, v25
    v.or         v1, v35, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    v.st.b       [s40, #0], v1
    s.add        s40, s38, s21                   // the tile origin
    s.add        s42, s38, s34                   // the tile origin
    v.splat      v1, s40
    v.splat      v35, s42
    v.add        v36, v23, v1
    v.cmp.lt     p1, v36, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.fms       v35, v17, v34, v21
    vf.cvt.bf16.f32 v36, v1
    s.addi       s38, s37, #16
    vf.fms       v1, v34, v35, v34
    v.extract    s40, v24, #1
    vf.neg       v35, v1                         // Newton step: r0*(2 - x*r0)
    s.add        s41, s40, s39
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v1, v35, v34
    s.addi       s40, s41, #96
    vf.mul       v34, v36, v1                    // a/y: faithful quotient
    s.add        s41, s3, s40
    vf.fms       v35, v34, v17, v36
    vf.fms       v36, v35, v1, v34
    v.rcp.approx v1, v17                         // ISA 8.8: <= 2**-22 relative
    vf.neg       v35, v36                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v36, v35, v34
    v.lshr       v34, v36, v26
    vf.cvt.f32.e4m3 v35, v36
    v.and        v36, v34, v25
    v.or         v34, v35, v36                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v34
    vf.fms       v34, v17, v1, v21
    vf.fms       v35, v1, v34, v1
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v34, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v1
    vf.cvt.bf16.f32 v1, v34
    v.extract    s38, v24, #2
    s.addi       s40, s37, #48
    s.add        s41, s38, s39
    vf.mul       v34, v1, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #96
    s.add        s41, s3, s38
    vf.fms       v36, v34, v17, v1
    vf.fms       v1, v36, v35, v34
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v1                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v1, v36, v34
    v.lshr       v34, v1, v26
    vf.cvt.f32.e4m3 v36, v1
    v.and        v1, v34, v25
    v.or         v34, v36, v1                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v34
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #3
    s.addi       s40, s37, #80
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #96
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #4
    s.addi       s40, s37, #112
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #96
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #5
    s.addi       s40, s37, #144
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #96
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #6
    s.addi       s40, s37, #176
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #96
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #7
    s.addi       s40, s37, #208
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #96
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #8
    s.addi       s40, s37, #240
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #96
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #9
    s.addi       s40, s37, #272
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #96
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #10
    s.addi       s40, s37, #304
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #96
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #11
    s.addi       s40, s37, #336
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #96
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #12
    s.addi       s40, s37, #368
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #96
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #13
    s.addi       s40, s37, #400
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #96
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #14
    s.addi       s40, s37, #432
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #96
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #15
    s.addi       s40, s37, #464
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #96
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    s.addi       s38, s37, #496
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s40, s37, #64
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    vf.neg       v35, v34                        // a/y: one correction to the IEEE quotient
    s.addi       s41, s37, #128
    vf.cmp.o     p1, v35, v35
    @p1 v.sel        v34, v35, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v35, v34
    v.and        v34, v1, v25
    v.or         v1, v35, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v1
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    s.addi       s38, s37, #192
    v.ld.w       v1, [s37, #0]
    v.mov        v56, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s40, #0]
    s.addi       s40, s37, #256
    v.mov        v57, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s41, #0]
    s.addi       s41, s37, #320
    v.mov        v58, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s38, #0]
    s.addi       s38, s37, #384
    s.addi       s42, s37, #448
    v.mov        v59, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s40, #0]
    v.extract    s37, v20, #2
    v.mov        v60, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s41, #0]
    v.mov        v61, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s38, #0]
    v.mov        v62, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s42, #0]
    v.mov        v63, v1                         // hand off through the shared window (sec 7.3)
    mb.wait      s49
    mb.arm       s38, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s38
    mb.wait      s38
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s37, x8dot_done_50
    s.movz       s40, #0
    s.addi       s41, s36, #128
    s.add        s42, s5, s31
    s.addi       s43, s40, #0
    v.ld.w       v1, [s41, #0]
    s.addi       s40, s42, #32
    s.addi       s41, s36, #768
x8dot_row_51:
    s.addi       s42, s35, #-32
    v.movi       v34, #0
    s.sub        s44, s42, s43
    s.add        s42, s40, s43
    v.splat      v35, s44
    s.shli       s44, s43, #4
    v.cmp.gt     p1, v35, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s42, v1]             // index is in elements (ISA sec 9.1)
    s.add        s42, s41, s44
    s.addi       s44, s43, #1
    s.movz       s45, #32
    v.st.b       [s42, #0], v34
    fence.acq_rel.device
    s.mov        s43, s44
    s.cmp.lt     s42, s43, s45
    br.nz        s42, x8dot_row_51
x8dot_done_50:
    v.splat      v1, s37
    v.movi       v34, #0
    mb.arm       s37, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s40, #0
    v.extract    s41, v22, #2
    s.movz       s42, #32
    v.cmp.ne     p1, v1, v34
    v.cmp.eq     p2, v1, v34
    s.mov        s43, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s43, s37            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s43, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s33
    mb.arm       s41, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s43, v20, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s41
    mb.wait      s41
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s43, x8dot_done_52
    s.addi       s44, s36, #192
    s.add        s45, s5, s31
    s.addi       s46, s40, #0
    v.ld.w       v1, [s44, #0]
    s.addi       s44, s45, #32
    s.addi       s45, s36, #1280
x8dot_row_53:
    s.addi       s47, s35, #-32
    v.movi       v34, #0
    s.sub        s48, s47, s46
    s.add        s47, s44, s46
    v.splat      v35, s48
    s.shli       s48, s46, #4
    v.cmp.gt     p1, v35, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s47, v1]             // index is in elements (ISA sec 9.1)
    s.add        s47, s45, s48
    s.addi       s48, s46, #1
    v.st.b       [s47, #0], v34
    fence.acq_rel.device
    s.mov        s46, s48
    s.cmp.lt     s47, s46, s42
    br.nz        s47, x8dot_row_53
x8dot_done_52:
    v.splat      v1, s43
    v.movi       v34, #0
    mb.arm       s43, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s44, v22, #3
    v.cmp.ne     p1, v1, v34
    v.cmp.eq     p2, v1, v34
    s.mov        s45, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s45, s43            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s45, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s45, s43          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s44, v20, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s42
    mb.wait      s42
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s44, x8dot_done_54
    s.addi       s45, s36, #256
    s.add        s46, s5, s31
    s.addi       s47, s40, #0
    v.ld.w       v1, [s45, #0]
    s.addi       s40, s46, #32
    s.addi       s45, s36, #768
x8dot_row_55:
    s.addi       s46, s35, #-32
    v.movi       v34, #0
    s.sub        s48, s46, s47
    s.add        s46, s40, s47
    v.splat      v35, s48
    s.shli       s48, s47, #4
    v.cmp.gt     p1, v35, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s46, v1]             // index is in elements (ISA sec 9.1)
    s.add        s46, s45, s48
    s.addi       s48, s47, #1
    s.movz       s50, #32
    v.st.b       [s46, #0], v34
    fence.acq_rel.device
    s.mov        s47, s48
    s.cmp.lt     s46, s47, s50
    br.nz        s46, x8dot_row_55
x8dot_done_54:
    v.splat      v1, s44
    v.movi       v34, #0
    mb.arm       s40, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s44, #0
    v.extract    s45, v22, #4
    s.movz       s46, #32
    v.cmp.ne     p1, v1, v34
    v.cmp.eq     p2, v1, v34
    s.mov        s47, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s47, s40            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s47, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s47, s40          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s43
    mb.arm       s45, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s47, v20, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s45
    mb.wait      s45
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s47, x8dot_done_56
    s.addi       s48, s36, #320
    s.add        s50, s5, s31
    s.addi       s51, s44, #0
    v.ld.w       v1, [s48, #0]
    s.addi       s48, s50, #32
    s.addi       s50, s36, #1280
x8dot_row_57:
    s.addi       s52, s35, #-32
    v.movi       v34, #0
    s.sub        s53, s52, s51
    s.add        s52, s48, s51
    v.splat      v35, s53
    s.shli       s53, s51, #4
    v.cmp.gt     p1, v35, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s52, v1]             // index is in elements (ISA sec 9.1)
    s.add        s52, s50, s53
    s.addi       s53, s51, #1
    v.st.b       [s52, #0], v34
    fence.acq_rel.device
    s.mov        s51, s53
    s.cmp.lt     s52, s51, s46
    br.nz        s52, x8dot_row_57
x8dot_done_56:
    v.splat      v1, s47
    v.movi       v34, #0
    mb.arm       s47, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s48, v22, #5
    v.cmp.ne     p1, v1, v34
    v.cmp.eq     p2, v1, v34
    s.mov        s50, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s50, s47            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s50, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s50, s47          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s40
    mb.arm       s46, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s48, v20, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s46
    mb.wait      s46
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s48, x8dot_done_58
    s.addi       s50, s36, #384
    s.add        s51, s5, s31
    s.addi       s52, s44, #0
    v.ld.w       v1, [s50, #0]
    s.addi       s44, s51, #32
    s.addi       s50, s36, #768
x8dot_row_59:
    s.addi       s51, s35, #-32
    v.movi       v34, #0
    s.sub        s53, s51, s52
    s.add        s51, s44, s52
    v.splat      v35, s53
    s.shli       s53, s52, #4
    v.cmp.gt     p1, v35, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s51, v1]             // index is in elements (ISA sec 9.1)
    s.add        s51, s50, s53
    s.addi       s53, s52, #1
    s.movz       s54, #32
    v.st.b       [s51, #0], v34
    fence.acq_rel.device
    s.mov        s52, s53
    s.cmp.lt     s51, s52, s54
    br.nz        s51, x8dot_row_59
x8dot_done_58:
    v.splat      v1, s48
    v.movi       v34, #0
    mb.arm       s44, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s48, #0
    v.extract    s50, v22, #6
    s.movz       s51, #32
    v.cmp.ne     p1, v1, v34
    v.cmp.eq     p2, v1, v34
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s52, s44            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s52, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s52, s44          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s47
    mb.arm       s50, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s52, v20, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s50
    mb.wait      s50
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s52, x8dot_done_60
    s.addi       s53, s36, #448
    s.add        s54, s5, s31
    s.addi       s55, s48, #0
    v.ld.w       v1, [s53, #0]
    s.addi       s53, s54, #32
    s.addi       s54, s36, #1280
x8dot_row_61:
    s.addi       s56, s35, #-32
    v.movi       v34, #0
    s.sub        s57, s56, s55
    s.add        s56, s53, s55
    v.splat      v35, s57
    s.shli       s57, s55, #4
    v.cmp.gt     p1, v35, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s56, v1]             // index is in elements (ISA sec 9.1)
    s.add        s56, s54, s57
    s.addi       s57, s55, #1
    v.st.b       [s56, #0], v34
    fence.acq_rel.device
    s.mov        s55, s57
    s.cmp.lt     s56, s55, s51
    br.nz        s56, x8dot_row_61
x8dot_done_60:
    v.splat      v1, s52
    v.movi       v34, #0
    mb.arm       s52, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s53, v22, #7
    v.cmp.ne     p1, v1, v34
    v.cmp.eq     p2, v1, v34
    s.mov        s54, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s54, s52            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s54, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s54, s52          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s44
    mb.arm       s51, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s53, v20, #0
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s51
    mb.wait      s51
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s53, x8dot_done_62
    s.addi       s54, s36, #0
    s.add        s55, s5, s31
    s.addi       s56, s48, #0
    v.ld.w       v1, [s54, #0]
    s.addi       s48, s55, #64
    s.addi       s54, s36, #768
x8dot_row_63:
    s.addi       s55, s35, #-64
    v.movi       v34, #0
    s.sub        s57, s55, s56
    s.add        s55, s48, s56
    v.splat      v35, s57
    s.shli       s57, s56, #4
    v.cmp.gt     p1, v35, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s55, v1]             // index is in elements (ISA sec 9.1)
    s.add        s55, s54, s57
    s.addi       s57, s56, #1
    s.movz       s58, #32
    v.st.b       [s55, #0], v34
    fence.acq_rel.device
    s.mov        s56, s57
    s.cmp.lt     s55, s56, s58
    br.nz        s55, x8dot_row_63
x8dot_done_62:
    v.splat      v1, s53
    v.movi       v34, #0
    mb.arm       s48, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s53, #0
    v.extract    s54, v22, #0
    s.movz       s55, #64
    v.cmp.ne     p1, v1, v34
    v.cmp.eq     p2, v1, v34
    s.mov        s56, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s56, s48            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s56, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s56, s48          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s52
    mb.arm       s54, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s56, v20, #1
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s54
    mb.wait      s54
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s56, x8dot_done_64
    s.addi       s57, s36, #64
    s.add        s58, s5, s31
    s.addi       s59, s53, #0
    v.ld.w       v1, [s57, #0]
    s.addi       s57, s58, #64
    s.addi       s58, s36, #1280
x8dot_row_65:
    s.addi       s60, s35, #-64
    v.movi       v34, #0
    s.sub        s33, s60, s59
    s.add        s37, s57, s59
    v.splat      v35, s33
    s.shli       s33, s59, #4
    v.cmp.gt     p1, v35, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s37, v1]             // index is in elements (ISA sec 9.1)
    s.add        s37, s58, s33
    s.addi       s33, s59, #1
    s.movz       s38, #32
    v.st.b       [s37, #0], v34
    fence.acq_rel.device
    s.mov        s59, s33
    s.cmp.lt     s33, s59, s38
    br.nz        s33, x8dot_row_65
x8dot_done_64:
    s.add        s33, s53, s22                   // the tile origin
    v.splat      v1, s56
    v.extract    s37, v24, #0
    v.splat      v34, s33
    s.add        s33, s37, s39
    v.movi       v35, #0
    s.addi       s37, s33, #128
    v.add        v36, v23, v34
    mb.arm       s33, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.add        s38, s53, s34                   // the tile origin
    s.add        s40, s3, s37
    v.cmp.ne     p1, v1, v35
    v.cmp.eq     p2, v1, v35
    v.splat      v1, s38
    v.extract    s37, v22, #1
    s.mov        s41, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s41, s33            // predicated off still completes once (ISA sec 9A.3)
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    v.cmp.lt     p2, v36, v1
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s33          // predicated off still completes once (ISA sec 9A.3)
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s40, #0]
    s.addi       s37, s36, #3328                 // 512 bytes of repack scratch
    vf.cvt.bf16.f32 v35, v1
    s.addi       s38, s37, #0
    vf.fms       v1, v17, v34, v21
    vf.fms       v36, v34, v1, v34
    v.extract    s40, v24, #1
    vf.neg       v1, v36                         // Newton step: r0*(2 - x*r0)
    s.add        s41, s40, s39
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v36, v1, v34
    s.addi       s40, s41, #128
    vf.mul       v1, v35, v36                    // a/y: faithful quotient
    s.add        s41, s3, s40
    vf.fms       v34, v1, v17, v35
    vf.fms       v35, v34, v36, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #2
    s.addi       s40, s37, #32
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #128
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #3
    s.addi       s40, s37, #64
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #128
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #4
    s.addi       s40, s37, #96
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #128
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #5
    s.addi       s40, s37, #128
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #128
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #6
    s.addi       s40, s37, #160
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #128
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #7
    s.addi       s40, s37, #192
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #128
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #8
    s.addi       s40, s37, #224
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #128
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #9
    s.addi       s40, s37, #256
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #128
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #10
    s.addi       s40, s37, #288
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #128
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #11
    s.addi       s40, s37, #320
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #128
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #12
    s.addi       s40, s37, #352
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #128
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #13
    s.addi       s40, s37, #384
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #128
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #14
    s.addi       s40, s37, #416
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #128
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #15
    s.addi       s40, s37, #448
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #128
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #0
    s.addi       s40, s37, #480
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.movz       s38, #0
    s.addi       s42, s41, #160
    s.add        s41, s3, s42
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    vf.neg       v35, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v35, v35
    @p1 v.sel        v34, v35, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v35, v34
    v.and        v34, v1, v25
    v.or         v1, v35, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    v.st.b       [s40, #0], v1
    s.add        s40, s38, s23                   // the tile origin
    s.add        s42, s38, s34                   // the tile origin
    v.splat      v1, s40
    v.splat      v35, s42
    v.add        v36, v23, v1
    v.cmp.lt     p1, v36, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.fms       v35, v17, v34, v21
    vf.cvt.bf16.f32 v36, v1
    s.addi       s38, s37, #16
    vf.fms       v1, v34, v35, v34
    v.extract    s40, v24, #1
    vf.neg       v35, v1                         // Newton step: r0*(2 - x*r0)
    s.add        s41, s40, s39
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v1, v35, v34
    s.addi       s40, s41, #160
    vf.mul       v34, v36, v1                    // a/y: faithful quotient
    s.add        s41, s3, s40
    vf.fms       v35, v34, v17, v36
    vf.fms       v36, v35, v1, v34
    v.rcp.approx v1, v17                         // ISA 8.8: <= 2**-22 relative
    vf.neg       v35, v36                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v36, v35, v34
    v.lshr       v34, v36, v26
    vf.cvt.f32.e4m3 v35, v36
    v.and        v36, v34, v25
    v.or         v34, v35, v36                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v34
    vf.fms       v34, v17, v1, v21
    vf.fms       v35, v1, v34, v1
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v34, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v1
    vf.cvt.bf16.f32 v1, v34
    v.extract    s38, v24, #2
    s.addi       s40, s37, #48
    s.add        s41, s38, s39
    vf.mul       v34, v1, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #160
    s.add        s41, s3, s38
    vf.fms       v36, v34, v17, v1
    vf.fms       v1, v36, v35, v34
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v1                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v1, v36, v34
    v.lshr       v34, v1, v26
    vf.cvt.f32.e4m3 v36, v1
    v.and        v1, v34, v25
    v.or         v34, v36, v1                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v34
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #3
    s.addi       s40, s37, #80
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #160
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #4
    s.addi       s40, s37, #112
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #160
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #5
    s.addi       s40, s37, #144
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #160
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #6
    s.addi       s40, s37, #176
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #160
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #7
    s.addi       s40, s37, #208
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #160
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #8
    s.addi       s40, s37, #240
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #160
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #9
    s.addi       s40, s37, #272
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #160
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #10
    s.addi       s40, s37, #304
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #160
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #11
    s.addi       s40, s37, #336
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #160
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #12
    s.addi       s40, s37, #368
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #160
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #13
    s.addi       s40, s37, #400
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #160
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #14
    s.addi       s40, s37, #432
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #160
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #15
    s.addi       s40, s37, #464
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #160
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    s.addi       s38, s37, #496
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s40, s37, #64
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    vf.neg       v35, v34                        // a/y: one correction to the IEEE quotient
    s.addi       s41, s37, #128
    vf.cmp.o     p1, v35, v35
    @p1 v.sel        v34, v35, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v35, v34
    v.and        v34, v1, v25
    v.or         v1, v35, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v1
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    s.addi       s38, s37, #192
    v.ld.w       v1, [s37, #0]
    v.mov        v56, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s40, #0]
    s.addi       s40, s37, #256
    v.mov        v57, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s41, #0]
    s.addi       s41, s37, #320
    v.mov        v58, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s38, #0]
    s.addi       s38, s37, #384
    s.addi       s42, s37, #448
    v.mov        v59, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s40, #0]
    v.extract    s37, v20, #2
    v.mov        v60, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s41, #0]
    v.mov        v61, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s38, #0]
    v.mov        v62, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s42, #0]
    v.mov        v63, v1                         // hand off through the shared window (sec 7.3)
    mb.wait      s48
    mb.arm       s38, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s38
    mb.wait      s38
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s37, x8dot_done_66
    s.movz       s40, #0
    s.addi       s41, s36, #128
    s.add        s42, s5, s31
    s.addi       s43, s40, #0
    v.ld.w       v1, [s41, #0]
    s.addi       s40, s42, #64
    s.addi       s41, s36, #768
x8dot_row_67:
    s.addi       s42, s35, #-64
    v.movi       v34, #0
    s.sub        s44, s42, s43
    s.add        s42, s40, s43
    v.splat      v35, s44
    s.shli       s44, s43, #4
    v.cmp.gt     p1, v35, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s42, v1]             // index is in elements (ISA sec 9.1)
    s.add        s42, s41, s44
    s.addi       s44, s43, #1
    s.movz       s45, #32
    v.st.b       [s42, #0], v34
    fence.acq_rel.device
    s.mov        s43, s44
    s.cmp.lt     s42, s43, s45
    br.nz        s42, x8dot_row_67
x8dot_done_66:
    v.splat      v1, s37
    v.movi       v34, #0
    mb.arm       s37, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s40, #0
    v.extract    s41, v22, #2
    s.movz       s42, #64
    v.cmp.ne     p1, v1, v34
    v.cmp.eq     p2, v1, v34
    s.mov        s43, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s43, s37            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s43, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s33
    mb.arm       s41, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s43, v20, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s41
    mb.wait      s41
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s43, x8dot_done_68
    s.addi       s44, s36, #192
    s.add        s45, s5, s31
    s.addi       s46, s40, #0
    v.ld.w       v1, [s44, #0]
    s.addi       s44, s45, #64
    s.addi       s45, s36, #1280
x8dot_row_69:
    s.addi       s47, s35, #-64
    v.movi       v34, #0
    s.sub        s49, s47, s46
    s.add        s47, s44, s46
    v.splat      v35, s49
    s.shli       s49, s46, #4
    v.cmp.gt     p1, v35, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s47, v1]             // index is in elements (ISA sec 9.1)
    s.add        s47, s45, s49
    s.addi       s49, s46, #1
    s.movz       s50, #32
    v.st.b       [s47, #0], v34
    fence.acq_rel.device
    s.mov        s46, s49
    s.cmp.lt     s47, s46, s50
    br.nz        s47, x8dot_row_69
x8dot_done_68:
    v.splat      v1, s43
    v.movi       v34, #0
    mb.arm       s43, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s44, v22, #3
    v.cmp.ne     p1, v1, v34
    v.cmp.eq     p2, v1, v34
    s.mov        s45, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s45, s43            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s45, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s45, s43          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s44, v20, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s42
    mb.wait      s42
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s44, x8dot_done_70
    s.addi       s45, s36, #256
    s.add        s46, s5, s31
    s.addi       s47, s40, #0
    v.ld.w       v1, [s45, #0]
    s.addi       s40, s46, #64
    s.addi       s45, s36, #768
x8dot_row_71:
    s.addi       s46, s35, #-64
    v.movi       v34, #0
    s.sub        s49, s46, s47
    s.add        s46, s40, s47
    v.splat      v35, s49
    s.shli       s49, s47, #4
    v.cmp.gt     p1, v35, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s46, v1]             // index is in elements (ISA sec 9.1)
    s.add        s46, s45, s49
    s.addi       s49, s47, #1
    s.movz       s50, #32
    v.st.b       [s46, #0], v34
    fence.acq_rel.device
    s.mov        s47, s49
    s.cmp.lt     s46, s47, s50
    br.nz        s46, x8dot_row_71
x8dot_done_70:
    v.splat      v1, s44
    v.movi       v34, #0
    mb.arm       s40, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s44, #0
    v.extract    s45, v22, #4
    s.movz       s46, #64
    v.cmp.ne     p1, v1, v34
    v.cmp.eq     p2, v1, v34
    s.mov        s49, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s49, s40            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s49, s40          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s43
    mb.arm       s45, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s47, v20, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s45
    mb.wait      s45
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s47, x8dot_done_72
    s.addi       s49, s36, #320
    s.add        s50, s5, s31
    s.addi       s51, s44, #0
    v.ld.w       v1, [s49, #0]
    s.addi       s49, s50, #64
    s.addi       s50, s36, #1280
x8dot_row_73:
    s.addi       s52, s35, #-64
    v.movi       v34, #0
    s.sub        s53, s52, s51
    s.add        s52, s49, s51
    v.splat      v35, s53
    s.shli       s53, s51, #4
    v.cmp.gt     p1, v35, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s52, v1]             // index is in elements (ISA sec 9.1)
    s.add        s52, s50, s53
    s.addi       s53, s51, #1
    s.movz       s54, #32
    v.st.b       [s52, #0], v34
    fence.acq_rel.device
    s.mov        s51, s53
    s.cmp.lt     s52, s51, s54
    br.nz        s52, x8dot_row_73
x8dot_done_72:
    v.splat      v1, s47
    v.movi       v34, #0
    mb.arm       s47, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s49, v22, #5
    v.cmp.ne     p1, v1, v34
    v.cmp.eq     p2, v1, v34
    s.mov        s50, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s50, s47            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s50, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s50, s47          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s40
    mb.arm       s46, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s49, v20, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s46
    mb.wait      s46
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s49, x8dot_done_74
    s.addi       s50, s36, #384
    s.add        s51, s5, s31
    s.addi       s52, s44, #0
    v.ld.w       v1, [s50, #0]
    s.addi       s44, s51, #64
    s.addi       s50, s36, #768
x8dot_row_75:
    s.addi       s51, s35, #-64
    v.movi       v34, #0
    s.sub        s53, s51, s52
    s.add        s51, s44, s52
    v.splat      v35, s53
    s.shli       s53, s52, #4
    v.cmp.gt     p1, v35, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s51, v1]             // index is in elements (ISA sec 9.1)
    s.add        s51, s50, s53
    s.addi       s53, s52, #1
    s.movz       s54, #32
    v.st.b       [s51, #0], v34
    fence.acq_rel.device
    s.mov        s52, s53
    s.cmp.lt     s51, s52, s54
    br.nz        s51, x8dot_row_75
x8dot_done_74:
    v.splat      v1, s49
    v.movi       v34, #0
    mb.arm       s44, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s49, #0
    v.extract    s50, v22, #6
    s.movz       s51, #64
    v.cmp.ne     p1, v1, v34
    v.cmp.eq     p2, v1, v34
    s.mov        s52, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s52, s44            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s52, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s52, s44          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s47
    mb.arm       s50, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s52, v20, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s50
    mb.wait      s50
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s52, x8dot_done_76
    s.addi       s53, s36, #448
    s.add        s54, s5, s31
    s.addi       s55, s49, #0
    v.ld.w       v1, [s53, #0]
    s.addi       s53, s54, #64
    s.addi       s54, s36, #1280
x8dot_row_77:
    s.addi       s56, s35, #-64
    v.movi       v34, #0
    s.sub        s57, s56, s55
    s.add        s56, s53, s55
    v.splat      v35, s57
    s.shli       s57, s55, #4
    v.cmp.gt     p1, v35, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s56, v1]             // index is in elements (ISA sec 9.1)
    s.add        s56, s54, s57
    s.addi       s57, s55, #1
    s.movz       s58, #32
    v.st.b       [s56, #0], v34
    fence.acq_rel.device
    s.mov        s55, s57
    s.cmp.lt     s56, s55, s58
    br.nz        s56, x8dot_row_77
x8dot_done_76:
    v.splat      v1, s52
    v.movi       v34, #0
    mb.arm       s52, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s53, v22, #7
    v.cmp.ne     p1, v1, v34
    v.cmp.eq     p2, v1, v34
    s.mov        s54, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s54, s52            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s54, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s54, s52          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s44
    mb.arm       s51, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s53, v20, #0
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s51
    mb.wait      s51
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s53, x8dot_done_78
    s.addi       s54, s36, #0
    s.add        s55, s5, s31
    s.addi       s56, s49, #0
    v.ld.w       v1, [s54, #0]
    s.addi       s49, s55, #96
    s.addi       s54, s36, #768
x8dot_row_79:
    s.addi       s55, s35, #-96
    v.movi       v34, #0
    s.sub        s57, s55, s56
    s.add        s55, s49, s56
    v.splat      v35, s57
    s.shli       s57, s56, #4
    v.cmp.gt     p1, v35, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s55, v1]             // index is in elements (ISA sec 9.1)
    s.add        s55, s54, s57
    s.addi       s57, s56, #1
    s.movz       s58, #32
    v.st.b       [s55, #0], v34
    fence.acq_rel.device
    s.mov        s56, s57
    s.cmp.lt     s55, s56, s58
    br.nz        s55, x8dot_row_79
x8dot_done_78:
    v.splat      v1, s53
    v.movi       v34, #0
    mb.arm       s49, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s53, #0
    v.extract    s54, v22, #0
    s.movz       s55, #96
    v.cmp.ne     p1, v1, v34
    v.cmp.eq     p2, v1, v34
    s.mov        s56, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s56, s49            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s56, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s56, s49          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s52
    mb.arm       s54, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s56, v20, #1
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s54
    mb.wait      s54
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s56, x8dot_done_80
    s.addi       s57, s36, #64
    s.add        s58, s5, s31
    s.addi       s59, s53, #0
    v.ld.w       v1, [s57, #0]
    s.addi       s57, s58, #96
    s.addi       s58, s36, #1280
x8dot_row_81:
    s.addi       s60, s35, #-96
    v.movi       v34, #0
    s.sub        s33, s60, s59
    s.add        s37, s57, s59
    v.splat      v35, s33
    s.shli       s33, s59, #4
    v.cmp.gt     p1, v35, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s37, v1]             // index is in elements (ISA sec 9.1)
    s.add        s37, s58, s33
    s.addi       s33, s59, #1
    s.movz       s38, #32
    v.st.b       [s37, #0], v34
    fence.acq_rel.device
    s.mov        s59, s33
    s.cmp.lt     s33, s59, s38
    br.nz        s33, x8dot_row_81
x8dot_done_80:
    s.add        s33, s53, s24                   // the tile origin
    v.splat      v1, s56
    v.extract    s37, v24, #0
    v.splat      v34, s33
    s.add        s33, s37, s39
    v.movi       v35, #0
    s.addi       s37, s33, #192
    v.add        v36, v23, v34
    mb.arm       s33, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.add        s38, s53, s34                   // the tile origin
    s.add        s40, s3, s37
    v.cmp.ne     p1, v1, v35
    v.cmp.eq     p2, v1, v35
    v.splat      v1, s38
    v.extract    s37, v22, #1
    s.mov        s41, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s41, s33            // predicated off still completes once (ISA sec 9A.3)
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    v.cmp.lt     p2, v36, v1
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s33          // predicated off still completes once (ISA sec 9A.3)
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s40, #0]
    s.addi       s37, s36, #3840                 // 512 bytes of repack scratch
    vf.cvt.bf16.f32 v35, v1
    s.addi       s38, s37, #0
    vf.fms       v1, v17, v34, v21
    vf.fms       v36, v34, v1, v34
    v.extract    s40, v24, #1
    vf.neg       v1, v36                         // Newton step: r0*(2 - x*r0)
    s.add        s41, s40, s39
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v36, v1, v34
    s.addi       s40, s41, #192
    vf.mul       v1, v35, v36                    // a/y: faithful quotient
    s.add        s41, s3, s40
    vf.fms       v34, v1, v17, v35
    vf.fms       v35, v34, v36, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #2
    s.addi       s40, s37, #32
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #192
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #3
    s.addi       s40, s37, #64
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #192
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #4
    s.addi       s40, s37, #96
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #192
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #5
    s.addi       s40, s37, #128
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #192
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #6
    s.addi       s40, s37, #160
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #192
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #7
    s.addi       s40, s37, #192
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #192
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #8
    s.addi       s40, s37, #224
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #192
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #9
    s.addi       s40, s37, #256
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #192
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #10
    s.addi       s40, s37, #288
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #192
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #11
    s.addi       s40, s37, #320
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #192
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #12
    s.addi       s40, s37, #352
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #192
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #13
    s.addi       s40, s37, #384
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #192
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #14
    s.addi       s40, s37, #416
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.addi       s38, s41, #192
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v36, v34
    v.and        v34, v1, v25
    v.or         v1, v36, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v35, v21
    vf.fms       v34, v35, v1, v35
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v34, v36, v35
    vf.cvt.bf16.f32 v35, v1
    v.extract    s38, v24, #15
    s.addi       s40, s37, #448
    s.add        s41, s38, s39
    vf.mul       v1, v35, v34                    // a/y: faithful quotient
    s.addi       s38, s41, #192
    s.add        s41, s3, s38
    vf.fms       v36, v1, v17, v35
    vf.fms       v35, v36, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v1
    v.lshr       v1, v35, v26
    vf.cvt.f32.e4m3 v36, v35
    v.and        v35, v1, v25
    v.or         v1, v36, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v35, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s41, #0]
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s38, v24, #0
    s.addi       s40, s37, #480
    s.add        s41, s38, s39
    vf.mul       v1, v34, v35                    // a/y: faithful quotient
    s.movz       s38, #0
    s.addi       s42, s41, #224
    s.add        s41, s3, s42
    vf.fms       v36, v1, v17, v34
    vf.fms       v34, v36, v35, v1
    vf.neg       v35, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v35, v35
    @p1 v.sel        v34, v35, v1
    s.add        s42, s38, s34                   // the tile origin
    s.add        s34, s38, s25                   // the tile origin
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v35, v34
    v.splat      v34, s34
    v.and        v36, v1, v25
    v.add        v1, v23, v34
    v.splat      v23, s42
    v.or         v34, v35, v36                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.rcp.approx v35, v17                        // ISA 8.8: <= 2**-22 relative
    v.cmp.lt     p1, v1, v23
    v.st.b       [s40, #0], v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s41, #0]
    vf.fms       v23, v17, v35, v21
    vf.cvt.bf16.f32 v34, v1
    s.addi       s34, s37, #16
    vf.fms       v1, v35, v23, v35
    v.extract    s38, v24, #1
    vf.neg       v23, v1                         // Newton step: r0*(2 - x*r0)
    s.add        s40, s38, s39
    vf.cmp.o     p2, v23, v23
    @p2 v.sel        v1, v23, v35
    s.addi       s38, s40, #224
    vf.mul       v23, v34, v1                    // a/y: faithful quotient
    s.add        s40, s3, s38
    vf.fms       v35, v23, v17, v34
    vf.fms       v34, v35, v1, v23
    v.rcp.approx v1, v17                         // ISA 8.8: <= 2**-22 relative
    vf.neg       v35, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v34, v35, v23
    v.lshr       v23, v34, v26
    vf.cvt.f32.e4m3 v35, v34
    v.and        v34, v23, v25
    v.or         v23, v35, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s34, #0], v23
    vf.fms       v23, v17, v1, v21
    vf.fms       v34, v1, v23, v1
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v23, [s40, #0]
    vf.neg       v35, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v34, v35, v1
    vf.cvt.bf16.f32 v1, v23
    v.extract    s34, v24, #2
    s.addi       s38, s37, #48
    s.add        s40, s34, s39
    vf.mul       v23, v1, v34                    // a/y: faithful quotient
    s.addi       s34, s40, #224
    s.add        s40, s3, s34
    vf.fms       v35, v23, v17, v1
    vf.fms       v1, v35, v34, v23
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v35, v1                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v1, v35, v23
    v.lshr       v23, v1, v26
    vf.cvt.f32.e4m3 v35, v1
    v.and        v1, v23, v25
    v.or         v23, v35, v1                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v23
    vf.fms       v1, v17, v34, v21
    vf.fms       v23, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s40, #0]
    vf.neg       v35, v23                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v23, v35, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s34, v24, #3
    s.addi       s38, s37, #80
    s.add        s40, s34, s39
    vf.mul       v1, v34, v23                    // a/y: faithful quotient
    s.addi       s34, s40, #224
    s.add        s40, s3, s34
    vf.fms       v35, v1, v17, v34
    vf.fms       v34, v35, v23, v1
    v.rcp.approx v23, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v35, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v34, v35, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v35, v34
    v.and        v34, v1, v25
    v.or         v1, v35, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v1
    vf.fms       v1, v17, v23, v21
    vf.fms       v34, v23, v1, v23
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s40, #0]
    vf.neg       v35, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v34, v35, v23
    vf.cvt.bf16.f32 v23, v1
    v.extract    s34, v24, #4
    s.addi       s38, s37, #112
    s.add        s40, s34, s39
    vf.mul       v1, v23, v34                    // a/y: faithful quotient
    s.addi       s34, s40, #224
    s.add        s40, s3, s34
    vf.fms       v35, v1, v17, v23
    vf.fms       v23, v35, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v35, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v23, v35, v1
    v.lshr       v1, v23, v26
    vf.cvt.f32.e4m3 v35, v23
    v.and        v23, v1, v25
    v.or         v1, v35, v23                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v23, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s40, #0]
    vf.neg       v35, v23                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v23, v35, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s34, v24, #5
    s.addi       s38, s37, #144
    s.add        s40, s34, s39
    vf.mul       v1, v34, v23                    // a/y: faithful quotient
    s.addi       s34, s40, #224
    s.add        s40, s3, s34
    vf.fms       v35, v1, v17, v34
    vf.fms       v34, v35, v23, v1
    v.rcp.approx v23, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v35, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v34, v35, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v35, v34
    v.and        v34, v1, v25
    v.or         v1, v35, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v1
    vf.fms       v1, v17, v23, v21
    vf.fms       v34, v23, v1, v23
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s40, #0]
    vf.neg       v35, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v34, v35, v23
    vf.cvt.bf16.f32 v23, v1
    v.extract    s34, v24, #6
    s.addi       s38, s37, #176
    s.add        s40, s34, s39
    vf.mul       v1, v23, v34                    // a/y: faithful quotient
    s.addi       s34, s40, #224
    s.add        s40, s3, s34
    vf.fms       v35, v1, v17, v23
    vf.fms       v23, v35, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v35, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v23, v35, v1
    v.lshr       v1, v23, v26
    vf.cvt.f32.e4m3 v35, v23
    v.and        v23, v1, v25
    v.or         v1, v35, v23                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v23, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s40, #0]
    vf.neg       v35, v23                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v23, v35, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s34, v24, #7
    s.addi       s38, s37, #208
    s.add        s40, s34, s39
    vf.mul       v1, v34, v23                    // a/y: faithful quotient
    s.addi       s34, s40, #224
    s.add        s40, s3, s34
    vf.fms       v35, v1, v17, v34
    vf.fms       v34, v35, v23, v1
    v.rcp.approx v23, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v35, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v34, v35, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v35, v34
    v.and        v34, v1, v25
    v.or         v1, v35, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v1
    vf.fms       v1, v17, v23, v21
    vf.fms       v34, v23, v1, v23
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s40, #0]
    vf.neg       v35, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v34, v35, v23
    vf.cvt.bf16.f32 v23, v1
    v.extract    s34, v24, #8
    s.addi       s38, s37, #240
    s.add        s40, s34, s39
    vf.mul       v1, v23, v34                    // a/y: faithful quotient
    s.addi       s34, s40, #224
    s.add        s40, s3, s34
    vf.fms       v35, v1, v17, v23
    vf.fms       v23, v35, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v35, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v23, v35, v1
    v.lshr       v1, v23, v26
    vf.cvt.f32.e4m3 v35, v23
    v.and        v23, v1, v25
    v.or         v1, v35, v23                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v23, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s40, #0]
    vf.neg       v35, v23                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v23, v35, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s34, v24, #9
    s.addi       s38, s37, #272
    s.add        s40, s34, s39
    vf.mul       v1, v34, v23                    // a/y: faithful quotient
    s.addi       s34, s40, #224
    s.add        s40, s3, s34
    vf.fms       v35, v1, v17, v34
    vf.fms       v34, v35, v23, v1
    v.rcp.approx v23, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v35, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v34, v35, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v35, v34
    v.and        v34, v1, v25
    v.or         v1, v35, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v1
    vf.fms       v1, v17, v23, v21
    vf.fms       v34, v23, v1, v23
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s40, #0]
    vf.neg       v35, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v34, v35, v23
    vf.cvt.bf16.f32 v23, v1
    v.extract    s34, v24, #10
    s.addi       s38, s37, #304
    s.add        s40, s34, s39
    vf.mul       v1, v23, v34                    // a/y: faithful quotient
    s.addi       s34, s40, #224
    s.add        s40, s3, s34
    vf.fms       v35, v1, v17, v23
    vf.fms       v23, v35, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v35, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v23, v35, v1
    v.lshr       v1, v23, v26
    vf.cvt.f32.e4m3 v35, v23
    v.and        v23, v1, v25
    v.or         v1, v35, v23                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v23, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s40, #0]
    vf.neg       v35, v23                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v23, v35, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s34, v24, #11
    s.addi       s38, s37, #336
    s.add        s40, s34, s39
    vf.mul       v1, v34, v23                    // a/y: faithful quotient
    s.addi       s34, s40, #224
    s.add        s40, s3, s34
    vf.fms       v35, v1, v17, v34
    vf.fms       v34, v35, v23, v1
    v.rcp.approx v23, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v35, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v34, v35, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v35, v34
    v.and        v34, v1, v25
    v.or         v1, v35, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v1
    vf.fms       v1, v17, v23, v21
    vf.fms       v34, v23, v1, v23
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s40, #0]
    vf.neg       v35, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v34, v35, v23
    vf.cvt.bf16.f32 v23, v1
    v.extract    s34, v24, #12
    s.addi       s38, s37, #368
    s.add        s40, s34, s39
    vf.mul       v1, v23, v34                    // a/y: faithful quotient
    s.addi       s34, s40, #224
    s.add        s40, s3, s34
    vf.fms       v35, v1, v17, v23
    vf.fms       v23, v35, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v35, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v23, v35, v1
    v.lshr       v1, v23, v26
    vf.cvt.f32.e4m3 v35, v23
    v.and        v23, v1, v25
    v.or         v1, v35, v23                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v23, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s40, #0]
    vf.neg       v35, v23                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v23, v35, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s34, v24, #13
    s.addi       s38, s37, #400
    s.add        s40, s34, s39
    vf.mul       v1, v34, v23                    // a/y: faithful quotient
    s.addi       s34, s40, #224
    s.add        s40, s3, s34
    vf.fms       v35, v1, v17, v34
    vf.fms       v34, v35, v23, v1
    v.rcp.approx v23, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v35, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v34, v35, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v35, v34
    v.and        v34, v1, v25
    v.or         v1, v35, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v1
    vf.fms       v1, v17, v23, v21
    vf.fms       v34, v23, v1, v23
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s40, #0]
    vf.neg       v35, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v34, v35, v23
    vf.cvt.bf16.f32 v23, v1
    v.extract    s34, v24, #14
    s.addi       s38, s37, #432
    s.add        s40, s34, s39
    vf.mul       v1, v23, v34                    // a/y: faithful quotient
    s.addi       s34, s40, #224
    s.add        s40, s3, s34
    vf.fms       v35, v1, v17, v23
    vf.fms       v23, v35, v34, v1
    v.rcp.approx v34, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v35, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v23, v35, v1
    v.lshr       v1, v23, v26
    vf.cvt.f32.e4m3 v35, v23
    v.and        v23, v1, v25
    v.or         v1, v35, v23                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v1
    vf.fms       v1, v17, v34, v21
    vf.fms       v23, v34, v1, v34
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s40, #0]
    vf.neg       v35, v23                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v35, v35
    @p2 v.sel        v23, v35, v34
    vf.cvt.bf16.f32 v34, v1
    v.extract    s34, v24, #15
    s.addi       s38, s37, #464
    s.add        s40, s34, s39
    vf.mul       v1, v34, v23                    // a/y: faithful quotient
    s.addi       s34, s40, #224
    s.add        s39, s3, s34
    vf.fms       v24, v1, v17, v34
    vf.fms       v34, v24, v23, v1
    v.rcp.approx v23, v17                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v24, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v24, v24
    @p2 v.sel        v34, v24, v1
    v.lshr       v1, v34, v26
    vf.cvt.f32.e4m3 v24, v34
    v.and        v34, v1, v25
    v.or         v1, v24, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v1
    vf.fms       v1, v17, v23, v21
    vf.fms       v21, v23, v1, v23
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s39, #0]
    vf.neg       v24, v21                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v24, v24
    @p1 v.sel        v21, v24, v23
    vf.cvt.bf16.f32 v23, v1
    s.addi       s34, s37, #496
    vf.mul       v1, v23, v21                    // a/y: faithful quotient
    s.addi       s38, s37, #64
    vf.fms       v24, v1, v17, v23
    vf.fms       v17, v24, v21, v1
    vf.neg       v21, v17                        // a/y: one correction to the IEEE quotient
    s.addi       s39, s37, #128
    vf.cmp.o     p1, v21, v21
    @p1 v.sel        v17, v21, v1
    v.lshr       v1, v17, v26
    vf.cvt.f32.e4m3 v21, v17
    s.addi       s40, s37, #192
    v.and        v17, v1, v25
    v.or         v1, v21, v17                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s37, #256
    v.st.b       [s34, #0], v1
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    s.addi       s34, s37, #320
    v.ld.w       v1, [s37, #0]
    v.mov        v56, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s38, #0]
    s.addi       s38, s37, #384
    v.mov        v57, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s39, #0]
    s.addi       s39, s37, #448
    v.mov        v58, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s40, #0]
    v.mov        v59, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s41, #0]
    v.extract    s37, v20, #2
    v.mov        v60, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s34, #0]
    v.mov        v61, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s38, #0]
    v.mov        v62, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s39, #0]
    v.mov        v63, v1                         // hand off through the shared window (sec 7.3)
    mb.wait      s49
    mb.arm       s34, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s34
    mb.wait      s34
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s37, x8dot_done_82
    s.movz       s38, #0
    s.addi       s39, s36, #128
    s.add        s40, s5, s31
    s.addi       s41, s38, #0
    v.ld.w       v1, [s39, #0]
    s.addi       s38, s40, #96
    s.addi       s39, s36, #768
x8dot_row_83:
    s.addi       s40, s35, #-96
    v.movi       v17, #0
    s.sub        s42, s40, s41
    s.add        s40, s38, s41
    v.splat      v21, s42
    s.shli       s42, s41, #4
    v.cmp.gt     p1, v21, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v17, [s40, v1]             // index is in elements (ISA sec 9.1)
    s.add        s40, s39, s42
    s.addi       s42, s41, #1
    s.movz       s43, #32
    v.st.b       [s40, #0], v17
    fence.acq_rel.device
    s.mov        s41, s42
    s.cmp.lt     s40, s41, s43
    br.nz        s40, x8dot_row_83
x8dot_done_82:
    v.splat      v1, s37
    v.movi       v17, #0
    mb.arm       s37, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s38, #0
    v.extract    s39, v22, #2
    s.movz       s40, #96
    v.cmp.ne     p1, v1, v17
    v.cmp.eq     p2, v1, v17
    s.mov        s41, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s41, s37            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s41, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s41, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s33
    mb.arm       s39, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s41, v20, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s39
    mb.wait      s39
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s41, x8dot_done_84
    s.addi       s42, s36, #192
    s.add        s43, s5, s31
    s.addi       s44, s38, #0
    v.ld.w       v1, [s42, #0]
    s.addi       s42, s43, #96
    s.addi       s43, s36, #1280
x8dot_row_85:
    s.addi       s45, s35, #-96
    v.movi       v17, #0
    s.sub        s46, s45, s44
    s.add        s45, s42, s44
    v.splat      v21, s46
    s.shli       s46, s44, #4
    v.cmp.gt     p1, v21, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v17, [s45, v1]             // index is in elements (ISA sec 9.1)
    s.add        s45, s43, s46
    s.addi       s46, s44, #1
    s.movz       s47, #32
    v.st.b       [s45, #0], v17
    fence.acq_rel.device
    s.mov        s44, s46
    s.cmp.lt     s45, s44, s47
    br.nz        s45, x8dot_row_85
x8dot_done_84:
    v.splat      v1, s41
    v.movi       v17, #0
    mb.arm       s41, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s42, v22, #3
    v.cmp.ne     p1, v1, v17
    v.cmp.eq     p2, v1, v17
    s.mov        s43, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s43, s41            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s43, s41          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s40, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s42, v20, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s40
    mb.wait      s40
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s42, x8dot_done_86
    s.addi       s43, s36, #256
    s.add        s44, s5, s31
    s.addi       s45, s38, #0
    v.ld.w       v1, [s43, #0]
    s.addi       s38, s44, #96
    s.addi       s43, s36, #768
x8dot_row_87:
    s.addi       s44, s35, #-96
    v.movi       v17, #0
    s.sub        s46, s44, s45
    s.add        s44, s38, s45
    v.splat      v21, s46
    s.shli       s46, s45, #4
    v.cmp.gt     p1, v21, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v17, [s44, v1]             // index is in elements (ISA sec 9.1)
    s.add        s44, s43, s46
    s.addi       s46, s45, #1
    s.movz       s47, #32
    v.st.b       [s44, #0], v17
    fence.acq_rel.device
    s.mov        s45, s46
    s.cmp.lt     s44, s45, s47
    br.nz        s44, x8dot_row_87
x8dot_done_86:
    v.splat      v1, s42
    v.movi       v17, #0
    mb.arm       s38, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s42, #0
    v.extract    s43, v22, #4
    s.movz       s44, #96
    v.cmp.ne     p1, v1, v17
    v.cmp.eq     p2, v1, v17
    s.mov        s45, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s45, s38            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s45, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s45, s38          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s41
    mb.arm       s43, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s45, v20, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s43
    mb.wait      s43
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s45, x8dot_done_88
    s.addi       s46, s36, #320
    s.add        s47, s5, s31
    s.addi       s48, s42, #0
    v.ld.w       v1, [s46, #0]
    s.addi       s46, s47, #96
    s.addi       s47, s36, #1280
x8dot_row_89:
    s.addi       s50, s35, #-96
    v.movi       v17, #0
    s.sub        s51, s50, s48
    s.add        s50, s46, s48
    v.splat      v21, s51
    s.shli       s51, s48, #4
    v.cmp.gt     p1, v21, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v17, [s50, v1]             // index is in elements (ISA sec 9.1)
    s.add        s50, s47, s51
    s.addi       s51, s48, #1
    s.movz       s52, #32
    v.st.b       [s50, #0], v17
    fence.acq_rel.device
    s.mov        s48, s51
    s.cmp.lt     s50, s48, s52
    br.nz        s50, x8dot_row_89
x8dot_done_88:
    v.splat      v1, s45
    v.movi       v17, #0
    mb.arm       s45, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s46, v22, #5
    v.cmp.ne     p1, v1, v17
    v.cmp.eq     p2, v1, v17
    s.mov        s47, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s47, s45            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s47, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s47, s45          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s38
    mb.arm       s44, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s46, v20, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s44
    mb.wait      s44
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s46, x8dot_done_90
    s.addi       s47, s36, #384
    s.add        s48, s5, s31
    s.addi       s50, s42, #0
    v.ld.w       v1, [s47, #0]
    s.addi       s42, s48, #96
    s.addi       s47, s36, #768
x8dot_row_91:
    s.addi       s48, s35, #-96
    v.movi       v17, #0
    s.sub        s51, s48, s50
    s.add        s48, s42, s50
    v.splat      v21, s51
    s.shli       s51, s50, #4
    v.cmp.gt     p1, v21, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v17, [s48, v1]             // index is in elements (ISA sec 9.1)
    s.add        s48, s47, s51
    s.addi       s51, s50, #1
    s.movz       s52, #32
    v.st.b       [s48, #0], v17
    fence.acq_rel.device
    s.mov        s50, s51
    s.cmp.lt     s48, s50, s52
    br.nz        s48, x8dot_row_91
x8dot_done_90:
    v.splat      v1, s46
    v.movi       v17, #0
    mb.arm       s42, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s46, #0
    v.extract    s47, v22, #6
    s.movz       s48, #96
    v.cmp.ne     p1, v1, v17
    v.cmp.eq     p2, v1, v17
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s50, s42            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s50, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s50, s42          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s45
    mb.arm       s47, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s50, v20, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s47
    mb.wait      s47
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s50, x8dot_done_92
    s.addi       s51, s36, #448
    s.add        s52, s5, s31
    s.addi       s53, s46, #0
    v.ld.w       v1, [s51, #0]
    s.addi       s51, s52, #96
    s.addi       s52, s36, #1280
x8dot_row_93:
    s.addi       s54, s35, #-96
    v.movi       v17, #0
    s.sub        s55, s54, s53
    s.add        s54, s51, s53
    v.splat      v20, s55
    s.shli       s55, s53, #4
    v.cmp.gt     p1, v20, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v17, [s54, v1]             // index is in elements (ISA sec 9.1)
    s.add        s54, s52, s55
    s.addi       s55, s53, #1
    s.movz       s56, #32
    v.st.b       [s54, #0], v17
    fence.acq_rel.device
    s.mov        s53, s55
    s.cmp.lt     s54, s53, s56
    br.nz        s54, x8dot_row_93
x8dot_done_92:
    v.splat      v1, s50
    v.movi       v17, #0
    mb.arm       s35, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s50, v22, #7
    v.cmp.ne     p1, v1, v17
    v.cmp.eq     p2, v1, v17
    s.mov        s51, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s51, s35            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s51, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s51, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s42
    mb.arm       s48, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s50, s36, #4352
    s.movz       s51, #1
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s48
    mb.wait      s48
    mb.wait      s35
    mb.arm       s52, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s53, s50, #64
    s.movz       s54, #2
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s52
    mb.wait      s52
    a.vread      v1, a8, s46
    s.addi       s46, s50, #128
    s.movz       s55, #3
    v.st.w       [s50, #0], v1
    a.vread      v1, a8, s51
    s.addi       s51, s50, #192
    s.movz       s56, #4
    s.addi       s57, s50, #256
    s.movz       s58, #5
    s.addi       s59, s50, #320
    v.st.w       [s53, #0], v1
    a.vread      v1, a8, s54
    s.movz       s53, #6
    s.addi       s54, s50, #384
    v.st.w       [s46, #0], v1
    a.vread      v1, a8, s55
    s.movz       s46, #7
    s.addi       s55, s50, #448
    v.st.w       [s51, #0], v1
    a.vread      v1, a8, s56
    s.movz       s51, #8
    s.addi       s56, s50, #512
    v.st.w       [s57, #0], v1
    a.vread      v1, a8, s58
    s.movz       s57, #9
    s.addi       s58, s50, #576
    v.st.w       [s59, #0], v1
    a.vread      v1, a8, s53
    s.movz       s53, #10
    s.addi       s59, s50, #640
    v.st.w       [s54, #0], v1
    a.vread      v1, a8, s46
    s.movz       s46, #11
    s.addi       s54, s50, #704
    v.st.w       [s55, #0], v1
    a.vread      v1, a8, s51
    s.movz       s51, #12
    s.addi       s55, s50, #768
    v.st.w       [s56, #0], v1
    a.vread      v1, a8, s57
    s.movz       s56, #13
    s.addi       s57, s50, #832
    v.st.w       [s58, #0], v1
    a.vread      v1, a8, s53
    s.movz       s53, #14
    s.addi       s58, s50, #896
    v.st.w       [s59, #0], v1
    a.vread      v1, a8, s46
    s.movz       s46, #15
    s.addi       s59, s50, #960
    v.st.w       [s54, #0], v1
    a.vread      v1, a8, s51
    s.movz       s50, #0
    s.addi       s51, s36, #5376
    v.st.w       [s55, #0], v1
    a.vread      v1, a8, s56
    s.movz       s54, #1
    s.addi       s55, s51, #64
    v.st.w       [s57, #0], v1
    a.vread      v1, a8, s53
    s.movz       s53, #2
    s.addi       s56, s51, #128
    v.st.w       [s58, #0], v1
    a.vread      v1, a8, s46
    s.movz       s46, #3
    s.addi       s57, s51, #192
    v.st.w       [s59, #0], v1
    fence.acq_rel.device
    a.vread      v1, a9, s50
    s.movz       s50, #4
    s.addi       s58, s51, #256
    v.st.w       [s51, #0], v1
    a.vread      v1, a9, s54
    s.movz       s54, #5
    s.addi       s59, s51, #320
    v.st.w       [s55, #0], v1
    a.vread      v1, a9, s53
    s.movz       s53, #6
    s.addi       s55, s51, #384
    v.st.w       [s56, #0], v1
    a.vread      v1, a9, s46
    s.movz       s46, #7
    s.addi       s56, s51, #448
    v.st.w       [s57, #0], v1
    a.vread      v1, a9, s50
    s.movz       s50, #8
    s.addi       s57, s51, #512
    v.st.w       [s58, #0], v1
    a.vread      v1, a9, s54
    s.movz       s54, #9
    s.addi       s58, s51, #576
    v.st.w       [s59, #0], v1
    a.vread      v1, a9, s53
    s.movz       s53, #10
    s.addi       s59, s51, #640
    v.st.w       [s55, #0], v1
    a.vread      v1, a9, s46
    s.movz       s46, #11
    s.addi       s55, s51, #704
    v.st.w       [s56, #0], v1
    a.vread      v1, a9, s50
    s.movz       s50, #12
    s.addi       s56, s51, #768
    v.st.w       [s57, #0], v1
    a.vread      v1, a9, s54
    s.movz       s54, #13
    s.addi       s57, s51, #832
    v.st.w       [s58, #0], v1
    a.vread      v1, a9, s53
    s.movz       s53, #14
    s.addi       s58, s51, #896
    v.st.w       [s59, #0], v1
    a.vread      v1, a9, s46
    s.movz       s46, #15
    s.addi       s59, s51, #960
    v.st.w       [s55, #0], v1
    a.vread      v1, a9, s50
    s.movz       s50, #0
    s.addi       s51, s36, #6400
    v.st.w       [s56, #0], v1
    a.vread      v1, a9, s54
    s.movz       s54, #1
    s.addi       s55, s51, #64
    v.st.w       [s57, #0], v1
    a.vread      v1, a9, s53
    s.movz       s53, #2
    s.addi       s56, s51, #128
    v.st.w       [s58, #0], v1
    a.vread      v1, a9, s46
    s.movz       s46, #3
    s.addi       s57, s51, #192
    v.st.w       [s59, #0], v1
    fence.acq_rel.device
    a.vread      v1, a10, s50
    s.movz       s50, #4
    s.addi       s58, s51, #256
    v.st.w       [s51, #0], v1
    a.vread      v1, a10, s54
    s.movz       s54, #5
    s.addi       s59, s51, #320
    v.st.w       [s55, #0], v1
    a.vread      v1, a10, s53
    s.movz       s53, #6
    s.addi       s55, s51, #384
    v.st.w       [s56, #0], v1
    a.vread      v1, a10, s46
    s.movz       s46, #7
    s.addi       s56, s51, #448
    v.st.w       [s57, #0], v1
    a.vread      v1, a10, s50
    s.movz       s50, #8
    s.addi       s57, s51, #512
    v.st.w       [s58, #0], v1
    a.vread      v1, a10, s54
    s.movz       s54, #9
    s.addi       s58, s51, #576
    v.st.w       [s59, #0], v1
    a.vread      v1, a10, s53
    s.movz       s53, #10
    s.addi       s59, s51, #640
    v.st.w       [s55, #0], v1
    a.vread      v1, a10, s46
    s.movz       s46, #11
    s.addi       s55, s51, #704
    v.st.w       [s56, #0], v1
    a.vread      v1, a10, s50
    s.movz       s50, #12
    s.addi       s56, s51, #768
    v.st.w       [s57, #0], v1
    a.vread      v1, a10, s54
    s.movz       s54, #13
    s.addi       s57, s51, #832
    v.st.w       [s58, #0], v1
    a.vread      v1, a10, s53
    s.movz       s53, #14
    s.addi       s58, s51, #896
    v.st.w       [s59, #0], v1
    a.vread      v1, a10, s46
    s.movz       s46, #15
    s.addi       s59, s51, #960
    v.st.w       [s55, #0], v1
    a.vread      v1, a10, s50
    s.movz       s50, #0
    s.addi       s51, s36, #7424
    v.st.w       [s56, #0], v1
    a.vread      v1, a10, s54
    s.movz       s54, #1
    s.addi       s55, s51, #64
    v.st.w       [s57, #0], v1
    a.vread      v1, a10, s53
    s.movz       s53, #2
    s.addi       s56, s51, #128
    v.st.w       [s58, #0], v1
    a.vread      v1, a10, s46
    s.movz       s46, #3
    s.addi       s57, s51, #192
    v.st.w       [s59, #0], v1
    fence.acq_rel.device
    a.vread      v1, a11, s50
    s.movz       s50, #4
    s.addi       s58, s51, #256
    v.st.w       [s51, #0], v1
    a.vread      v1, a11, s54
    s.movz       s54, #5
    s.addi       s59, s51, #320
    v.st.w       [s55, #0], v1
    a.vread      v1, a11, s53
    s.movz       s53, #6
    s.addi       s55, s51, #384
    v.st.w       [s56, #0], v1
    a.vread      v1, a11, s46
    s.movz       s46, #7
    s.addi       s56, s51, #448
    v.st.w       [s57, #0], v1
    a.vread      v1, a11, s50
    s.movz       s50, #8
    s.addi       s57, s51, #512
    v.st.w       [s58, #0], v1
    a.vread      v1, a11, s54
    s.movz       s54, #9
    s.addi       s58, s51, #576
    v.st.w       [s59, #0], v1
    a.vread      v1, a11, s53
    s.movz       s53, #10
    s.addi       s59, s51, #640
    v.st.w       [s55, #0], v1
    a.vread      v1, a11, s46
    s.movz       s46, #11
    s.addi       s55, s51, #704
    v.st.w       [s56, #0], v1
    a.vread      v1, a11, s50
    s.movz       s50, #12
    s.addi       s56, s51, #768
    v.st.w       [s57, #0], v1
    a.vread      v1, a11, s54
    s.movz       s54, #13
    s.addi       s57, s51, #832
    v.st.w       [s58, #0], v1
    a.vread      v1, a11, s53
    s.movz       s53, #14
    s.addi       s58, s51, #896
    v.st.w       [s59, #0], v1
    a.vread      v1, a11, s46
    s.movz       s46, #15
    s.addi       s59, s51, #960
    v.st.w       [s55, #0], v1
    a.vread      v1, a11, s50
    s.movz       s50, #0
    s.addi       s51, s36, #8448
    v.st.w       [s56, #0], v1
    a.vread      v1, a11, s54
    s.movz       s54, #1
    s.addi       s55, s51, #64
    v.st.w       [s57, #0], v1
    a.vread      v1, a11, s53
    s.movz       s53, #2
    s.addi       s56, s51, #128
    v.st.w       [s58, #0], v1
    a.vread      v1, a11, s46
    s.movz       s46, #3
    s.addi       s57, s51, #192
    v.st.w       [s59, #0], v1
    fence.acq_rel.device
    a.vread      v1, a12, s50
    s.movz       s50, #4
    s.addi       s58, s51, #256
    v.st.w       [s51, #0], v1
    a.vread      v1, a12, s54
    s.movz       s54, #5
    s.addi       s59, s51, #320
    v.st.w       [s55, #0], v1
    a.vread      v1, a12, s53
    s.movz       s53, #6
    s.addi       s55, s51, #384
    v.st.w       [s56, #0], v1
    a.vread      v1, a12, s46
    s.movz       s46, #7
    s.addi       s56, s51, #448
    v.st.w       [s57, #0], v1
    a.vread      v1, a12, s50
    s.movz       s50, #8
    s.addi       s57, s51, #512
    v.st.w       [s58, #0], v1
    a.vread      v1, a12, s54
    s.movz       s54, #9
    s.addi       s58, s51, #576
    v.st.w       [s59, #0], v1
    a.vread      v1, a12, s53
    s.movz       s53, #10
    s.addi       s59, s51, #640
    v.st.w       [s55, #0], v1
    a.vread      v1, a12, s46
    s.movz       s46, #11
    s.addi       s55, s51, #704
    v.st.w       [s56, #0], v1
    a.vread      v1, a12, s50
    s.movz       s50, #12
    s.addi       s56, s51, #768
    v.st.w       [s57, #0], v1
    a.vread      v1, a12, s54
    s.movz       s54, #13
    s.addi       s57, s51, #832
    v.st.w       [s58, #0], v1
    a.vread      v1, a12, s53
    s.movz       s53, #14
    s.addi       s58, s51, #896
    v.st.w       [s59, #0], v1
    a.vread      v1, a12, s46
    s.movz       s46, #15
    s.addi       s59, s51, #960
    v.st.w       [s55, #0], v1
    a.vread      v1, a12, s50
    s.movz       s50, #0
    s.addi       s51, s36, #9472
    v.st.w       [s56, #0], v1
    a.vread      v1, a12, s54
    s.movz       s54, #1
    s.addi       s55, s51, #64
    v.st.w       [s57, #0], v1
    a.vread      v1, a12, s53
    s.movz       s53, #2
    s.addi       s56, s51, #128
    v.st.w       [s58, #0], v1
    a.vread      v1, a12, s46
    s.movz       s46, #3
    s.addi       s57, s51, #192
    v.st.w       [s59, #0], v1
    fence.acq_rel.device
    a.vread      v1, a13, s50
    s.movz       s50, #4
    s.addi       s58, s51, #256
    v.st.w       [s51, #0], v1
    a.vread      v1, a13, s54
    s.movz       s54, #5
    s.addi       s59, s51, #320
    v.st.w       [s55, #0], v1
    a.vread      v1, a13, s53
    s.movz       s53, #6
    s.addi       s55, s51, #384
    v.st.w       [s56, #0], v1
    a.vread      v1, a13, s46
    s.movz       s46, #7
    s.addi       s56, s51, #448
    v.st.w       [s57, #0], v1
    a.vread      v1, a13, s50
    s.movz       s50, #8
    s.addi       s57, s51, #512
    v.st.w       [s58, #0], v1
    a.vread      v1, a13, s54
    s.movz       s54, #9
    s.addi       s58, s51, #576
    v.st.w       [s59, #0], v1
    a.vread      v1, a13, s53
    s.movz       s53, #10
    s.addi       s59, s51, #640
    v.st.w       [s55, #0], v1
    a.vread      v1, a13, s46
    s.movz       s46, #11
    s.addi       s55, s51, #704
    v.st.w       [s56, #0], v1
    a.vread      v1, a13, s50
    s.movz       s50, #12
    s.addi       s56, s51, #768
    v.st.w       [s57, #0], v1
    a.vread      v1, a13, s54
    s.movz       s54, #13
    s.addi       s57, s51, #832
    v.st.w       [s58, #0], v1
    a.vread      v1, a13, s53
    s.movz       s53, #14
    s.addi       s58, s51, #896
    v.st.w       [s59, #0], v1
    a.vread      v1, a13, s46
    s.movz       s46, #15
    s.addi       s59, s51, #960
    v.st.w       [s55, #0], v1
    a.vread      v1, a13, s50
    s.movz       s50, #0
    s.addi       s51, s36, #10496
    v.st.w       [s56, #0], v1
    a.vread      v1, a13, s54
    s.movz       s54, #1
    s.addi       s55, s51, #64
    v.st.w       [s57, #0], v1
    a.vread      v1, a13, s53
    s.movz       s53, #2
    s.addi       s56, s51, #128
    v.st.w       [s58, #0], v1
    a.vread      v1, a13, s46
    s.movz       s46, #3
    s.addi       s57, s51, #192
    v.st.w       [s59, #0], v1
    fence.acq_rel.device
    a.vread      v1, a14, s50
    s.movz       s50, #4
    s.addi       s58, s51, #256
    v.st.w       [s51, #0], v1
    a.vread      v1, a14, s54
    s.movz       s54, #5
    s.addi       s59, s51, #320
    v.st.w       [s55, #0], v1
    a.vread      v1, a14, s53
    s.movz       s53, #6
    s.addi       s55, s51, #384
    v.st.w       [s56, #0], v1
    a.vread      v1, a14, s46
    s.movz       s46, #7
    s.addi       s56, s51, #448
    v.st.w       [s57, #0], v1
    a.vread      v1, a14, s50
    s.movz       s50, #8
    s.addi       s57, s51, #512
    v.st.w       [s58, #0], v1
    a.vread      v1, a14, s54
    s.movz       s54, #9
    s.addi       s58, s51, #576
    v.st.w       [s59, #0], v1
    a.vread      v1, a14, s53
    s.movz       s53, #10
    s.addi       s59, s51, #640
    v.st.w       [s55, #0], v1
    a.vread      v1, a14, s46
    s.movz       s46, #11
    s.addi       s55, s51, #704
    v.st.w       [s56, #0], v1
    a.vread      v1, a14, s50
    s.movz       s50, #12
    s.addi       s56, s51, #768
    v.st.w       [s57, #0], v1
    a.vread      v1, a14, s54
    s.movz       s54, #13
    s.addi       s57, s51, #832
    v.st.w       [s58, #0], v1
    a.vread      v1, a14, s53
    s.movz       s53, #14
    s.addi       s58, s51, #896
    v.st.w       [s59, #0], v1
    a.vread      v1, a14, s46
    s.movz       s46, #15
    s.addi       s59, s51, #960
    v.st.w       [s55, #0], v1
    a.vread      v1, a14, s50
    s.movz       s50, #0
    s.addi       s51, s36, #11520
    v.st.w       [s56, #0], v1
    a.vread      v1, a14, s54
    s.movz       s54, #1
    s.addi       s55, s51, #64
    v.st.w       [s57, #0], v1
    a.vread      v1, a14, s53
    s.movz       s53, #2
    s.addi       s56, s51, #128
    v.st.w       [s58, #0], v1
    a.vread      v1, a14, s46
    s.movz       s46, #3
    s.addi       s57, s51, #192
    v.st.w       [s59, #0], v1
    fence.acq_rel.device
    a.vread      v1, a15, s50
    s.movz       s50, #4
    s.addi       s58, s51, #256
    v.st.w       [s51, #0], v1
    a.vread      v1, a15, s54
    s.movz       s54, #5
    s.addi       s59, s51, #320
    v.st.w       [s55, #0], v1
    a.vread      v1, a15, s53
    s.movz       s53, #6
    s.addi       s55, s51, #384
    v.st.w       [s56, #0], v1
    a.vread      v1, a15, s46
    s.movz       s46, #7
    s.addi       s56, s51, #448
    v.st.w       [s57, #0], v1
    a.vread      v1, a15, s50
    s.movz       s50, #8
    s.addi       s57, s51, #512
    v.st.w       [s58, #0], v1
    a.vread      v1, a15, s54
    s.movz       s54, #9
    s.addi       s58, s51, #576
    v.st.w       [s59, #0], v1
    a.vread      v1, a15, s53
    s.movz       s53, #10
    s.addi       s59, s51, #640
    v.st.w       [s55, #0], v1
    a.vread      v1, a15, s46
    s.movz       s46, #11
    s.addi       s55, s51, #704
    v.st.w       [s56, #0], v1
    a.vread      v1, a15, s50
    s.movz       s50, #12
    s.addi       s56, s51, #768
    v.st.w       [s57, #0], v1
    a.vread      v1, a15, s54
    s.movz       s54, #13
    s.addi       s57, s51, #832
    v.st.w       [s58, #0], v1
    a.vread      v1, a15, s53
    s.movz       s53, #14
    s.addi       s58, s51, #896
    v.st.w       [s59, #0], v1
    a.vread      v1, a15, s46
    s.movz       s46, #15
    s.addi       s59, s51, #960
    v.st.w       [s55, #0], v1
    a.vread      v1, a15, s50
    s.movz       s50, #0
    s.addi       s51, s36, #12544
    v.st.w       [s56, #0], v1
    a.vread      v1, a15, s54
    s.addi       s54, s36, #4352
    v.st.w       [s57, #0], v1
    a.vread      v1, a15, s53
    s.movz       s53, #1
    s.addi       s55, s51, #64
    v.st.w       [s58, #0], v1
    a.vread      v1, a15, s46
    s.addi       s46, s36, #4416
    v.st.w       [s59, #0], v1
    fence.acq_rel.device
    a.vread      v1, a0, s50
    s.movz       s50, #2
    s.addi       s56, s36, #4480
    s.addi       s57, s51, #128
    v.ld.w       v17, [s54, #0]
    vf.mul       v20, v17, v19
    vf.add       v17, v1, v20
    v.st.w       [s51, #0], v17
    a.vread      v1, a0, s53
    s.movz       s53, #3
    s.addi       s54, s36, #4544
    s.addi       s58, s51, #192
    v.ld.w       v17, [s46, #0]
    vf.mul       v20, v17, v19
    vf.add       v17, v1, v20
    v.st.w       [s55, #0], v17
    a.vread      v1, a0, s50
    s.movz       s46, #4
    s.addi       s50, s36, #4608
    s.addi       s55, s51, #256
    v.ld.w       v17, [s56, #0]
    vf.mul       v20, v17, v19
    vf.add       v17, v1, v20
    v.st.w       [s57, #0], v17
    a.vread      v1, a0, s53
    s.movz       s53, #5
    s.addi       s56, s36, #4672
    s.addi       s57, s51, #320
    v.ld.w       v17, [s54, #0]
    vf.mul       v20, v17, v19
    vf.add       v17, v1, v20
    v.st.w       [s58, #0], v17
    a.vread      v1, a0, s46
    s.movz       s46, #6
    s.addi       s54, s36, #4736
    s.addi       s58, s51, #384
    v.ld.w       v17, [s50, #0]
    vf.mul       v20, v17, v19
    vf.add       v17, v1, v20
    v.st.w       [s55, #0], v17
    a.vread      v1, a0, s53
    s.movz       s50, #7
    s.addi       s53, s36, #4800
    s.addi       s55, s51, #448
    v.ld.w       v17, [s56, #0]
    vf.mul       v20, v17, v19
    vf.add       v17, v1, v20
    v.st.w       [s57, #0], v17
    a.vread      v1, a0, s46
    s.movz       s46, #8
    s.addi       s56, s36, #4864
    s.addi       s57, s51, #512
    v.ld.w       v17, [s54, #0]
    vf.mul       v20, v17, v19
    vf.add       v17, v1, v20
    v.st.w       [s58, #0], v17
    a.vread      v1, a0, s50
    s.movz       s50, #9
    s.addi       s54, s36, #4928
    s.addi       s58, s51, #576
    v.ld.w       v17, [s53, #0]
    vf.mul       v20, v17, v19
    vf.add       v17, v1, v20
    v.st.w       [s55, #0], v17
    a.vread      v1, a0, s46
    s.movz       s46, #10
    s.addi       s53, s36, #4992
    s.addi       s55, s51, #640
    v.ld.w       v17, [s56, #0]
    vf.mul       v20, v17, v19
    vf.add       v17, v1, v20
    v.st.w       [s57, #0], v17
    a.vread      v1, a0, s50
    s.movz       s50, #11
    s.addi       s56, s36, #5056
    s.addi       s57, s51, #704
    v.ld.w       v17, [s54, #0]
    vf.mul       v20, v17, v19
    vf.add       v17, v1, v20
    v.st.w       [s58, #0], v17
    a.vread      v1, a0, s46
    s.movz       s46, #12
    s.addi       s54, s36, #5120
    s.addi       s58, s51, #768
    v.ld.w       v17, [s53, #0]
    vf.mul       v20, v17, v19
    vf.add       v17, v1, v20
    v.st.w       [s55, #0], v17
    a.vread      v1, a0, s50
    s.movz       s50, #13
    s.addi       s53, s36, #5184
    s.addi       s55, s51, #832
    v.ld.w       v17, [s56, #0]
    vf.mul       v20, v17, v19
    vf.add       v17, v1, v20
    v.st.w       [s57, #0], v17
    a.vread      v1, a0, s46
    s.movz       s46, #14
    s.addi       s56, s36, #5248
    s.addi       s57, s51, #896
    v.ld.w       v17, [s54, #0]
    vf.mul       v20, v17, v19
    vf.add       v17, v1, v20
    v.st.w       [s58, #0], v17
    a.vread      v1, a0, s50
    s.movz       s50, #15
    s.addi       s54, s36, #5312
    s.addi       s58, s51, #960
    v.ld.w       v17, [s53, #0]
    vf.mul       v20, v17, v19
    vf.add       v17, v1, v20
    v.st.w       [s55, #0], v17
    a.vread      v1, a0, s46
    s.movz       s46, #0
    s.addi       s51, s36, #13568
    v.ld.w       v17, [s56, #0]
    s.addi       s53, s36, #5376
    vf.mul       v20, v17, v19
    vf.add       v17, v1, v20
    v.st.w       [s57, #0], v17
    a.vread      v1, a0, s50
    s.movz       s50, #1
    s.addi       s55, s51, #64
    v.ld.w       v17, [s54, #0]
    s.addi       s54, s36, #5440
    vf.mul       v20, v17, v19
    vf.add       v17, v1, v20
    v.st.w       [s58, #0], v17
    fence.acq_rel.device
    a.vread      v1, a1, s46
    s.movz       s46, #2
    s.addi       s56, s36, #5504
    s.addi       s57, s51, #128
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v27
    vf.add       v17, v1, v19
    v.st.w       [s51, #0], v17
    a.vread      v1, a1, s50
    s.movz       s50, #3
    s.addi       s53, s36, #5568
    s.addi       s58, s51, #192
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v27
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a1, s46
    s.movz       s46, #4
    s.addi       s54, s36, #5632
    s.addi       s55, s51, #256
    v.ld.w       v17, [s56, #0]
    vf.mul       v19, v17, v27
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a1, s50
    s.movz       s50, #5
    s.addi       s56, s36, #5696
    s.addi       s57, s51, #320
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v27
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    a.vread      v1, a1, s46
    s.movz       s46, #6
    s.addi       s53, s36, #5760
    s.addi       s58, s51, #384
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v27
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a1, s50
    s.movz       s50, #7
    s.addi       s54, s36, #5824
    s.addi       s55, s51, #448
    v.ld.w       v17, [s56, #0]
    vf.mul       v19, v17, v27
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a1, s46
    s.movz       s46, #8
    s.addi       s56, s36, #5888
    s.addi       s57, s51, #512
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v27
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    a.vread      v1, a1, s50
    s.movz       s50, #9
    s.addi       s53, s36, #5952
    s.addi       s58, s51, #576
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v27
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a1, s46
    s.movz       s46, #10
    s.addi       s54, s36, #6016
    s.addi       s55, s51, #640
    v.ld.w       v17, [s56, #0]
    vf.mul       v19, v17, v27
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a1, s50
    s.movz       s50, #11
    s.addi       s56, s36, #6080
    s.addi       s57, s51, #704
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v27
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    a.vread      v1, a1, s46
    s.movz       s46, #12
    s.addi       s53, s36, #6144
    s.addi       s58, s51, #768
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v27
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a1, s50
    s.movz       s50, #13
    s.addi       s54, s36, #6208
    s.addi       s55, s51, #832
    v.ld.w       v17, [s56, #0]
    vf.mul       v19, v17, v27
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a1, s46
    s.movz       s46, #14
    s.addi       s56, s36, #6272
    s.addi       s57, s51, #896
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v27
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    a.vread      v1, a1, s50
    s.movz       s50, #15
    s.addi       s53, s36, #6336
    s.addi       s58, s51, #960
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v27
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a1, s46
    s.movz       s46, #0
    s.addi       s51, s36, #14592
    v.ld.w       v17, [s56, #0]
    s.addi       s54, s36, #6400
    vf.mul       v19, v17, v27
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a1, s50
    s.movz       s50, #1
    s.addi       s55, s51, #64
    v.ld.w       v17, [s53, #0]
    s.addi       s53, s36, #6464
    vf.mul       v19, v17, v27
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    fence.acq_rel.device
    a.vread      v1, a2, s46
    s.movz       s46, #2
    s.addi       s56, s36, #6528
    s.addi       s57, s51, #128
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v28
    vf.add       v17, v1, v19
    v.st.w       [s51, #0], v17
    a.vread      v1, a2, s50
    s.movz       s50, #3
    s.addi       s54, s36, #6592
    s.addi       s58, s51, #192
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v28
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a2, s46
    s.movz       s46, #4
    s.addi       s53, s36, #6656
    s.addi       s55, s51, #256
    v.ld.w       v17, [s56, #0]
    vf.mul       v19, v17, v28
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a2, s50
    s.movz       s50, #5
    s.addi       s56, s36, #6720
    s.addi       s57, s51, #320
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v28
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    a.vread      v1, a2, s46
    s.movz       s46, #6
    s.addi       s54, s36, #6784
    s.addi       s58, s51, #384
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v28
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a2, s50
    s.movz       s50, #7
    s.addi       s53, s36, #6848
    s.addi       s55, s51, #448
    v.ld.w       v17, [s56, #0]
    vf.mul       v19, v17, v28
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a2, s46
    s.movz       s46, #8
    s.addi       s56, s36, #6912
    s.addi       s57, s51, #512
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v28
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    a.vread      v1, a2, s50
    s.movz       s50, #9
    s.addi       s54, s36, #6976
    s.addi       s58, s51, #576
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v28
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a2, s46
    s.movz       s46, #10
    s.addi       s53, s36, #7040
    s.addi       s55, s51, #640
    v.ld.w       v17, [s56, #0]
    vf.mul       v19, v17, v28
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a2, s50
    s.movz       s50, #11
    s.addi       s56, s36, #7104
    s.addi       s57, s51, #704
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v28
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    a.vread      v1, a2, s46
    s.movz       s46, #12
    s.addi       s54, s36, #7168
    s.addi       s58, s51, #768
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v28
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a2, s50
    s.movz       s50, #13
    s.addi       s53, s36, #7232
    s.addi       s55, s51, #832
    v.ld.w       v17, [s56, #0]
    vf.mul       v19, v17, v28
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a2, s46
    s.movz       s46, #14
    s.addi       s56, s36, #7296
    s.addi       s57, s51, #896
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v28
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    a.vread      v1, a2, s50
    s.movz       s50, #15
    s.addi       s54, s36, #7360
    s.addi       s58, s51, #960
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v28
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a2, s46
    s.movz       s46, #0
    s.addi       s51, s36, #15616
    v.ld.w       v17, [s56, #0]
    s.addi       s53, s36, #7424
    vf.mul       v19, v17, v28
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a2, s50
    s.movz       s50, #1
    s.addi       s55, s51, #64
    v.ld.w       v17, [s54, #0]
    s.addi       s54, s36, #7488
    vf.mul       v19, v17, v28
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    fence.acq_rel.device
    a.vread      v1, a3, s46
    s.movz       s46, #2
    s.addi       s56, s36, #7552
    s.addi       s57, s51, #128
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v29
    vf.add       v17, v1, v19
    v.st.w       [s51, #0], v17
    a.vread      v1, a3, s50
    s.movz       s50, #3
    s.addi       s53, s36, #7616
    s.addi       s58, s51, #192
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v29
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a3, s46
    s.movz       s46, #4
    s.addi       s54, s36, #7680
    s.addi       s55, s51, #256
    v.ld.w       v17, [s56, #0]
    vf.mul       v19, v17, v29
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a3, s50
    s.movz       s50, #5
    s.addi       s56, s36, #7744
    s.addi       s57, s51, #320
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v29
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    a.vread      v1, a3, s46
    s.movz       s46, #6
    s.addi       s53, s36, #7808
    s.addi       s58, s51, #384
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v29
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a3, s50
    s.movz       s50, #7
    s.addi       s54, s36, #7872
    s.addi       s55, s51, #448
    v.ld.w       v17, [s56, #0]
    vf.mul       v19, v17, v29
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a3, s46
    s.movz       s46, #8
    s.addi       s56, s36, #7936
    s.addi       s57, s51, #512
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v29
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    a.vread      v1, a3, s50
    s.movz       s50, #9
    s.addi       s53, s36, #8000
    s.addi       s58, s51, #576
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v29
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a3, s46
    s.movz       s46, #10
    s.addi       s54, s36, #8064
    s.addi       s55, s51, #640
    v.ld.w       v17, [s56, #0]
    vf.mul       v19, v17, v29
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a3, s50
    s.movz       s50, #11
    s.addi       s56, s36, #8128
    s.addi       s57, s51, #704
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v29
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    a.vread      v1, a3, s46
    s.movz       s46, #12
    s.addi       s53, s36, #8192
    s.addi       s58, s51, #768
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v29
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a3, s50
    s.movz       s50, #13
    s.addi       s54, s36, #8256
    s.addi       s55, s51, #832
    v.ld.w       v17, [s56, #0]
    vf.mul       v19, v17, v29
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a3, s46
    s.movz       s46, #14
    s.addi       s56, s36, #8320
    s.addi       s57, s51, #896
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v29
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    a.vread      v1, a3, s50
    s.movz       s50, #15
    s.addi       s53, s36, #8384
    s.addi       s58, s51, #960
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v29
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a3, s46
    s.movz       s46, #0
    s.addi       s51, s36, #16640
    v.ld.w       v17, [s56, #0]
    s.addi       s54, s36, #8448
    vf.mul       v19, v17, v29
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a3, s50
    s.movz       s50, #1
    s.addi       s55, s51, #64
    v.ld.w       v17, [s53, #0]
    s.addi       s53, s36, #8512
    vf.mul       v19, v17, v29
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    fence.acq_rel.device
    a.vread      v1, a4, s46
    s.movz       s46, #2
    s.addi       s56, s36, #8576
    s.addi       s57, s51, #128
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v30
    vf.add       v17, v1, v19
    v.st.w       [s51, #0], v17
    a.vread      v1, a4, s50
    s.movz       s50, #3
    s.addi       s54, s36, #8640
    s.addi       s58, s51, #192
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v30
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a4, s46
    s.movz       s46, #4
    s.addi       s53, s36, #8704
    s.addi       s55, s51, #256
    v.ld.w       v17, [s56, #0]
    vf.mul       v19, v17, v30
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a4, s50
    s.movz       s50, #5
    s.addi       s56, s36, #8768
    s.addi       s57, s51, #320
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v30
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    a.vread      v1, a4, s46
    s.movz       s46, #6
    s.addi       s54, s36, #8832
    s.addi       s58, s51, #384
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v30
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a4, s50
    s.movz       s50, #7
    s.addi       s53, s36, #8896
    s.addi       s55, s51, #448
    v.ld.w       v17, [s56, #0]
    vf.mul       v19, v17, v30
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a4, s46
    s.movz       s46, #8
    s.addi       s56, s36, #8960
    s.addi       s57, s51, #512
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v30
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    a.vread      v1, a4, s50
    s.movz       s50, #9
    s.addi       s54, s36, #9024
    s.addi       s58, s51, #576
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v30
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a4, s46
    s.movz       s46, #10
    s.addi       s53, s36, #9088
    s.addi       s55, s51, #640
    v.ld.w       v17, [s56, #0]
    vf.mul       v19, v17, v30
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a4, s50
    s.movz       s50, #11
    s.addi       s56, s36, #9152
    s.addi       s57, s51, #704
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v30
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    a.vread      v1, a4, s46
    s.movz       s46, #12
    s.addi       s54, s36, #9216
    s.addi       s58, s51, #768
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v30
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a4, s50
    s.movz       s50, #13
    s.addi       s53, s36, #9280
    s.addi       s55, s51, #832
    v.ld.w       v17, [s56, #0]
    vf.mul       v19, v17, v30
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a4, s46
    s.movz       s46, #14
    s.addi       s56, s36, #9344
    s.addi       s57, s51, #896
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v30
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    a.vread      v1, a4, s50
    s.movz       s50, #15
    s.addi       s54, s36, #9408
    s.addi       s58, s51, #960
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v30
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a4, s46
    s.movz       s46, #0
    s.addi       s51, s36, #17664
    v.ld.w       v17, [s56, #0]
    s.addi       s53, s36, #9472
    vf.mul       v19, v17, v30
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a4, s50
    s.movz       s50, #1
    s.addi       s55, s51, #64
    v.ld.w       v17, [s54, #0]
    s.addi       s54, s36, #9536
    vf.mul       v19, v17, v30
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    fence.acq_rel.device
    a.vread      v1, a5, s46
    s.movz       s46, #2
    s.addi       s56, s36, #9600
    s.addi       s57, s51, #128
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v31
    vf.add       v17, v1, v19
    v.st.w       [s51, #0], v17
    a.vread      v1, a5, s50
    s.movz       s50, #3
    s.addi       s53, s36, #9664
    s.addi       s58, s51, #192
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v31
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a5, s46
    s.movz       s46, #4
    s.addi       s54, s36, #9728
    s.addi       s55, s51, #256
    v.ld.w       v17, [s56, #0]
    vf.mul       v19, v17, v31
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a5, s50
    s.movz       s50, #5
    s.addi       s56, s36, #9792
    s.addi       s57, s51, #320
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v31
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    a.vread      v1, a5, s46
    s.movz       s46, #6
    s.addi       s53, s36, #9856
    s.addi       s58, s51, #384
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v31
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a5, s50
    s.movz       s50, #7
    s.addi       s54, s36, #9920
    s.addi       s55, s51, #448
    v.ld.w       v17, [s56, #0]
    vf.mul       v19, v17, v31
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a5, s46
    s.movz       s46, #8
    s.addi       s56, s36, #9984
    s.addi       s57, s51, #512
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v31
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    a.vread      v1, a5, s50
    s.movz       s50, #9
    s.addi       s53, s36, #10048
    s.addi       s58, s51, #576
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v31
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a5, s46
    s.movz       s46, #10
    s.addi       s54, s36, #10112
    s.addi       s55, s51, #640
    v.ld.w       v17, [s56, #0]
    vf.mul       v19, v17, v31
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a5, s50
    s.movz       s50, #11
    s.addi       s56, s36, #10176
    s.addi       s57, s51, #704
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v31
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    a.vread      v1, a5, s46
    s.movz       s46, #12
    s.addi       s53, s36, #10240
    s.addi       s58, s51, #768
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v31
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a5, s50
    s.movz       s50, #13
    s.addi       s54, s36, #10304
    s.addi       s55, s51, #832
    v.ld.w       v17, [s56, #0]
    vf.mul       v19, v17, v31
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a5, s46
    s.movz       s46, #14
    s.addi       s56, s36, #10368
    s.addi       s57, s51, #896
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v31
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    a.vread      v1, a5, s50
    s.movz       s50, #15
    s.addi       s53, s36, #10432
    s.addi       s58, s51, #960
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v31
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a5, s46
    s.movz       s46, #0
    s.addi       s51, s36, #18688
    v.ld.w       v17, [s56, #0]
    s.addi       s54, s36, #10496
    vf.mul       v19, v17, v31
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a5, s50
    s.movz       s50, #1
    s.addi       s55, s51, #64
    v.ld.w       v17, [s53, #0]
    s.addi       s53, s36, #10560
    vf.mul       v19, v17, v31
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    fence.acq_rel.device
    a.vread      v1, a6, s46
    s.movz       s46, #2
    s.addi       s56, s36, #10624
    s.addi       s57, s51, #128
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v32
    vf.add       v17, v1, v19
    v.st.w       [s51, #0], v17
    a.vread      v1, a6, s50
    s.movz       s50, #3
    s.addi       s54, s36, #10688
    s.addi       s58, s51, #192
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v32
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a6, s46
    s.movz       s46, #4
    s.addi       s53, s36, #10752
    s.addi       s55, s51, #256
    v.ld.w       v17, [s56, #0]
    vf.mul       v19, v17, v32
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a6, s50
    s.movz       s50, #5
    s.addi       s56, s36, #10816
    s.addi       s57, s51, #320
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v32
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    a.vread      v1, a6, s46
    s.movz       s46, #6
    s.addi       s54, s36, #10880
    s.addi       s58, s51, #384
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v32
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a6, s50
    s.movz       s50, #7
    s.addi       s53, s36, #10944
    s.addi       s55, s51, #448
    v.ld.w       v17, [s56, #0]
    vf.mul       v19, v17, v32
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a6, s46
    s.movz       s46, #8
    s.addi       s56, s36, #11008
    s.addi       s57, s51, #512
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v32
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    a.vread      v1, a6, s50
    s.movz       s50, #9
    s.addi       s54, s36, #11072
    s.addi       s58, s51, #576
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v32
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a6, s46
    s.movz       s46, #10
    s.addi       s53, s36, #11136
    s.addi       s55, s51, #640
    v.ld.w       v17, [s56, #0]
    vf.mul       v19, v17, v32
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a6, s50
    s.movz       s50, #11
    s.addi       s56, s36, #11200
    s.addi       s57, s51, #704
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v32
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    a.vread      v1, a6, s46
    s.movz       s46, #12
    s.addi       s54, s36, #11264
    s.addi       s58, s51, #768
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v32
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a6, s50
    s.movz       s50, #13
    s.addi       s53, s36, #11328
    s.addi       s55, s51, #832
    v.ld.w       v17, [s56, #0]
    vf.mul       v19, v17, v32
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a6, s46
    s.movz       s46, #14
    s.addi       s56, s36, #11392
    s.addi       s57, s51, #896
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v32
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    a.vread      v1, a6, s50
    s.movz       s50, #15
    s.addi       s54, s36, #11456
    s.addi       s58, s51, #960
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v32
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a6, s46
    s.movz       s46, #0
    s.addi       s51, s36, #19712
    v.ld.w       v17, [s56, #0]
    s.addi       s53, s36, #11520
    vf.mul       v19, v17, v32
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a6, s50
    s.movz       s50, #1
    s.addi       s55, s51, #64
    v.ld.w       v17, [s54, #0]
    s.addi       s54, s36, #11584
    vf.mul       v19, v17, v32
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    fence.acq_rel.device
    a.vread      v1, a7, s46
    s.movz       s46, #2
    s.addi       s56, s36, #11648
    s.addi       s57, s51, #128
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v33
    vf.add       v17, v1, v19
    v.st.w       [s51, #0], v17
    a.vread      v1, a7, s50
    s.movz       s50, #3
    s.addi       s53, s36, #11712
    s.addi       s58, s51, #192
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v33
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a7, s46
    s.movz       s46, #4
    s.addi       s54, s36, #11776
    s.addi       s55, s51, #256
    v.ld.w       v17, [s56, #0]
    vf.mul       v19, v17, v33
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a7, s50
    s.movz       s50, #5
    s.addi       s56, s36, #11840
    s.addi       s57, s51, #320
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v33
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    a.vread      v1, a7, s46
    s.movz       s46, #6
    s.addi       s53, s36, #11904
    s.addi       s58, s51, #384
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v33
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a7, s50
    s.movz       s50, #7
    s.addi       s54, s36, #11968
    s.addi       s55, s51, #448
    v.ld.w       v17, [s56, #0]
    vf.mul       v19, v17, v33
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a7, s46
    s.movz       s46, #8
    s.addi       s56, s36, #12032
    s.addi       s57, s51, #512
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v33
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    a.vread      v1, a7, s50
    s.movz       s50, #9
    s.addi       s53, s36, #12096
    s.addi       s58, s51, #576
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v33
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a7, s46
    s.movz       s46, #10
    s.addi       s54, s36, #12160
    s.addi       s55, s51, #640
    v.ld.w       v17, [s56, #0]
    vf.mul       v19, v17, v33
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a7, s50
    s.movz       s50, #11
    s.addi       s56, s36, #12224
    s.addi       s57, s51, #704
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v33
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    a.vread      v1, a7, s46
    s.movz       s46, #12
    s.addi       s53, s36, #12288
    s.addi       s58, s51, #768
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v33
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a7, s50
    s.movz       s50, #13
    s.addi       s54, s36, #12352
    s.addi       s55, s51, #832
    v.ld.w       v17, [s56, #0]
    vf.mul       v19, v17, v33
    vf.add       v17, v1, v19
    v.st.w       [s57, #0], v17
    a.vread      v1, a7, s46
    s.movz       s46, #14
    s.addi       s56, s36, #12416
    s.addi       s57, s51, #896
    v.ld.w       v17, [s53, #0]
    vf.mul       v19, v17, v33
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    a.vread      v1, a7, s50
    s.movz       s50, #15
    s.addi       s53, s36, #12480
    s.addi       s58, s51, #960
    v.ld.w       v17, [s54, #0]
    vf.mul       v19, v17, v33
    vf.add       v17, v1, v19
    v.st.w       [s55, #0], v17
    a.vread      v1, a7, s46
    s.addi       s46, s30, #128
    s.addi       s51, s31, #128
    s.addi       s54, s46, #0
    v.ld.w       v17, [s56, #0]
    s.addi       s46, s51, #0
    vf.mul       v19, v17, v33
    s.addi       s51, s32, #4                    // &ptr_carry_20[1] (a constant offset, x4)
    vf.add       v17, v1, v19
    s.addi       s55, s51, #0
    v.st.w       [s57, #0], v17
    a.vread      v1, a7, s50
    s.addi       s50, s32, #4                    // &ptr_carry_21[1] (a constant offset, x4)
    s.addi       s50, s32, #4                    // &ptr_carry_22[1] (a constant offset, x4)
    s.addi       s50, s32, #4                    // &ptr_carry_23[1] (a constant offset, x4)
    s.addi       s50, s32, #4                    // &ptr_carry_24[1] (a constant offset, x4)
    s.addi       s50, s32, #4                    // &ptr_carry_25[1] (a constant offset, x4)
    v.ld.w       v17, [s53, #0]
    s.addi       s50, s32, #4                    // &ptr_carry_26[1] (a constant offset, x4)
    vf.mul       v19, v17, v33
    s.addi       s50, s32, #4                    // &ptr_carry_27[1] (a constant offset, x4)
    vf.add       v17, v1, v19
    v.st.w       [s58, #0], v17
    fence.acq_rel.device
    s.addi       s50, s36, #12544
    s.mov        s30, s54
    s.mov        s31, s46
    s.mov        s32, s55
    s.movz       s46, #0
    s.addi       s51, s36, #12608
    s.movz       s53, #1
    s.addi       s54, s36, #12672
    s.movz       s55, #2
    s.addi       s56, s36, #12736
    s.movz       s57, #3
    s.addi       s58, s36, #12800
    s.movz       s59, #4
    v.ld.w       v1, [s50, #0]
    a.vwrite     a0, s46, v1
    v.ld.w       v1, [s51, #0]
    s.addi       s50, s36, #12864
    s.movz       s51, #5
    a.vwrite     a0, s53, v1
    v.ld.w       v1, [s54, #0]
    s.addi       s54, s36, #12928
    s.movz       s60, #6
    a.vwrite     a0, s55, v1
    v.ld.w       v1, [s56, #0]
    s.addi       s56, s36, #12992
    s.movz       s33, #7
    a.vwrite     a0, s57, v1
    v.ld.w       v1, [s58, #0]
    s.addi       s34, s36, #13056
    s.movz       s35, #8
    a.vwrite     a0, s59, v1
    v.ld.w       v1, [s50, #0]
    s.addi       s37, s36, #13120
    s.movz       s38, #9
    a.vwrite     a0, s51, v1
    v.ld.w       v1, [s54, #0]
    s.addi       s39, s36, #13184
    s.movz       s40, #10
    a.vwrite     a0, s60, v1
    v.ld.w       v1, [s56, #0]
    s.addi       s41, s36, #13248
    s.movz       s42, #11
    a.vwrite     a0, s33, v1
    v.ld.w       v1, [s34, #0]
    s.addi       s34, s36, #13312
    s.movz       s43, #12
    a.vwrite     a0, s35, v1
    v.ld.w       v1, [s37, #0]
    s.addi       s37, s36, #13376
    a.vwrite     a0, s38, v1
    v.ld.w       v1, [s39, #0]
    s.movz       s39, #13
    a.vwrite     a0, s40, v1
    v.ld.w       v1, [s41, #0]
    s.addi       s41, s36, #13440
    a.vwrite     a0, s42, v1
    v.ld.w       v1, [s34, #0]
    s.movz       s34, #14
    a.vwrite     a0, s43, v1
    v.ld.w       v1, [s37, #0]
    s.addi       s37, s36, #13504
    a.vwrite     a0, s39, v1
    v.ld.w       v1, [s41, #0]
    s.movz       s41, #15
    a.vwrite     a0, s34, v1
    v.ld.w       v1, [s37, #0]
    s.addi       s37, s36, #13568
    a.vwrite     a0, s41, v1
    v.ld.w       v1, [s37, #0]
    s.addi       s37, s36, #13632
    a.vwrite     a1, s46, v1
    v.ld.w       v1, [s37, #0]
    s.addi       s37, s36, #13696
    s.addi       s44, s36, #13760
    a.vwrite     a1, s53, v1
    v.ld.w       v1, [s37, #0]
    s.addi       s37, s36, #13824
    s.addi       s45, s36, #13888
    a.vwrite     a1, s55, v1
    v.ld.w       v1, [s44, #0]
    s.addi       s44, s36, #13952
    s.addi       s46, s36, #14016
    a.vwrite     a1, s57, v1
    v.ld.w       v1, [s37, #0]
    s.addi       s37, s36, #14080
    s.addi       s47, s36, #14144
    a.vwrite     a1, s59, v1
    v.ld.w       v1, [s45, #0]
    s.addi       s45, s36, #14208
    a.vwrite     a1, s51, v1
    v.ld.w       v1, [s44, #0]
    s.addi       s44, s36, #14272
    a.vwrite     a1, s60, v1
    v.ld.w       v1, [s46, #0]
    s.addi       s46, s36, #14336
    a.vwrite     a1, s33, v1
    v.ld.w       v1, [s37, #0]
    s.addi       s33, s36, #14400
    a.vwrite     a1, s35, v1
    v.ld.w       v1, [s47, #0]
    s.addi       s35, s36, #14464
    a.vwrite     a1, s38, v1
    v.ld.w       v1, [s45, #0]
    s.addi       s37, s36, #14528
    a.vwrite     a1, s40, v1
    v.ld.w       v1, [s44, #0]
    s.addi       s38, s36, #14592
    s.movz       s40, #0
    a.vwrite     a1, s42, v1
    v.ld.w       v1, [s46, #0]
    s.addi       s42, s36, #14656
    s.movz       s44, #1
    a.vwrite     a1, s43, v1
    v.ld.w       v1, [s33, #0]
    s.movz       s33, #2
    a.vwrite     a1, s39, v1
    v.ld.w       v1, [s35, #0]
    s.addi       s35, s36, #14720
    a.vwrite     a1, s34, v1
    v.ld.w       v1, [s37, #0]
    s.addi       s34, s36, #14784
    s.movz       s37, #3
    a.vwrite     a1, s41, v1
    v.ld.w       v1, [s38, #0]
    s.addi       s38, s36, #14848
    s.movz       s39, #4
    a.vwrite     a2, s40, v1
    v.ld.w       v1, [s42, #0]
    s.addi       s41, s36, #14912
    s.movz       s42, #5
    a.vwrite     a2, s44, v1
    v.ld.w       v1, [s35, #0]
    s.addi       s35, s36, #14976
    s.movz       s43, #6
    a.vwrite     a2, s33, v1
    v.ld.w       v1, [s34, #0]
    s.addi       s34, s36, #15040
    s.movz       s45, #7
    a.vwrite     a2, s37, v1
    v.ld.w       v1, [s38, #0]
    s.addi       s38, s36, #15104
    s.movz       s46, #8
    a.vwrite     a2, s39, v1
    v.ld.w       v1, [s41, #0]
    s.addi       s41, s36, #15168
    s.movz       s47, #9
    a.vwrite     a2, s42, v1
    v.ld.w       v1, [s35, #0]
    s.addi       s35, s36, #15232
    s.movz       s48, #10
    a.vwrite     a2, s43, v1
    v.ld.w       v1, [s34, #0]
    s.addi       s34, s36, #15296
    s.movz       s49, #11
    a.vwrite     a2, s45, v1
    v.ld.w       v1, [s38, #0]
    s.addi       s38, s36, #15360
    s.movz       s50, #12
    a.vwrite     a2, s46, v1
    v.ld.w       v1, [s41, #0]
    s.addi       s41, s36, #15424
    a.vwrite     a2, s47, v1
    v.ld.w       v1, [s35, #0]
    s.movz       s35, #13
    a.vwrite     a2, s48, v1
    v.ld.w       v1, [s34, #0]
    s.addi       s34, s36, #15488
    a.vwrite     a2, s49, v1
    v.ld.w       v1, [s38, #0]
    s.movz       s38, #14
    a.vwrite     a2, s50, v1
    v.ld.w       v1, [s41, #0]
    s.addi       s41, s36, #15552
    a.vwrite     a2, s35, v1
    v.ld.w       v1, [s34, #0]
    s.movz       s34, #15
    a.vwrite     a2, s38, v1
    v.ld.w       v1, [s41, #0]
    s.addi       s41, s36, #15616
    a.vwrite     a2, s34, v1
    v.ld.w       v1, [s41, #0]
    s.addi       s41, s36, #15680
    a.vwrite     a3, s40, v1
    v.ld.w       v1, [s41, #0]
    s.addi       s40, s36, #15744
    s.addi       s41, s36, #15808
    a.vwrite     a3, s44, v1
    v.ld.w       v1, [s40, #0]
    s.addi       s40, s36, #15872
    s.addi       s44, s36, #15936
    a.vwrite     a3, s33, v1
    v.ld.w       v1, [s41, #0]
    s.addi       s33, s36, #16000
    s.addi       s41, s36, #16064
    a.vwrite     a3, s37, v1
    v.ld.w       v1, [s40, #0]
    s.addi       s37, s36, #16128
    s.addi       s40, s36, #16192
    a.vwrite     a3, s39, v1
    v.ld.w       v1, [s44, #0]
    s.addi       s39, s36, #16256
    a.vwrite     a3, s42, v1
    v.ld.w       v1, [s33, #0]
    s.addi       s33, s36, #16320
    a.vwrite     a3, s43, v1
    v.ld.w       v1, [s41, #0]
    s.addi       s41, s36, #16384
    a.vwrite     a3, s45, v1
    v.ld.w       v1, [s37, #0]
    s.addi       s37, s36, #16448
    a.vwrite     a3, s46, v1
    v.ld.w       v1, [s40, #0]
    s.addi       s40, s36, #16512
    a.vwrite     a3, s47, v1
    v.ld.w       v1, [s39, #0]
    s.addi       s39, s36, #16576
    a.vwrite     a3, s48, v1
    v.ld.w       v1, [s33, #0]
    s.addi       s33, s36, #16640
    s.movz       s42, #0
    a.vwrite     a3, s49, v1
    v.ld.w       v1, [s41, #0]
    s.addi       s41, s36, #16704
    s.movz       s43, #1
    a.vwrite     a3, s50, v1
    v.ld.w       v1, [s37, #0]
    s.movz       s37, #2
    a.vwrite     a3, s35, v1
    v.ld.w       v1, [s40, #0]
    s.addi       s35, s36, #16768
    a.vwrite     a3, s38, v1
    v.ld.w       v1, [s39, #0]
    s.addi       s38, s36, #16832
    s.movz       s39, #3
    a.vwrite     a3, s34, v1
    v.ld.w       v1, [s33, #0]
    s.addi       s33, s36, #16896
    s.movz       s34, #4
    a.vwrite     a4, s42, v1
    v.ld.w       v1, [s41, #0]
    s.addi       s40, s36, #16960
    s.movz       s41, #5
    a.vwrite     a4, s43, v1
    v.ld.w       v1, [s35, #0]
    s.addi       s35, s36, #17024
    s.movz       s44, #6
    a.vwrite     a4, s37, v1
    v.ld.w       v1, [s38, #0]
    s.addi       s38, s36, #17088
    s.movz       s45, #7
    a.vwrite     a4, s39, v1
    v.ld.w       v1, [s33, #0]
    s.addi       s33, s36, #17152
    s.movz       s46, #8
    a.vwrite     a4, s34, v1
    v.ld.w       v1, [s40, #0]
    s.addi       s40, s36, #17216
    s.movz       s47, #9
    a.vwrite     a4, s41, v1
    v.ld.w       v1, [s35, #0]
    s.addi       s35, s36, #17280
    s.movz       s48, #10
    a.vwrite     a4, s44, v1
    v.ld.w       v1, [s38, #0]
    s.addi       s38, s36, #17344
    s.movz       s49, #11
    a.vwrite     a4, s45, v1
    v.ld.w       v1, [s33, #0]
    s.addi       s33, s36, #17408
    s.movz       s50, #12
    a.vwrite     a4, s46, v1
    v.ld.w       v1, [s40, #0]
    s.addi       s40, s36, #17472
    a.vwrite     a4, s47, v1
    v.ld.w       v1, [s35, #0]
    s.movz       s35, #13
    a.vwrite     a4, s48, v1
    v.ld.w       v1, [s38, #0]
    s.addi       s38, s36, #17536
    a.vwrite     a4, s49, v1
    v.ld.w       v1, [s33, #0]
    s.movz       s33, #14
    a.vwrite     a4, s50, v1
    v.ld.w       v1, [s40, #0]
    s.addi       s40, s36, #17600
    a.vwrite     a4, s35, v1
    v.ld.w       v1, [s38, #0]
    s.movz       s38, #15
    a.vwrite     a4, s33, v1
    v.ld.w       v1, [s40, #0]
    s.addi       s40, s36, #17664
    a.vwrite     a4, s38, v1
    v.ld.w       v1, [s40, #0]
    s.addi       s40, s36, #17728
    a.vwrite     a5, s42, v1
    v.ld.w       v1, [s40, #0]
    s.addi       s40, s36, #17792
    s.addi       s42, s36, #17856
    a.vwrite     a5, s43, v1
    v.ld.w       v1, [s40, #0]
    s.addi       s40, s36, #17920
    s.addi       s43, s36, #17984
    a.vwrite     a5, s37, v1
    v.ld.w       v1, [s42, #0]
    s.addi       s37, s36, #18048
    s.addi       s42, s36, #18112
    a.vwrite     a5, s39, v1
    v.ld.w       v1, [s40, #0]
    s.addi       s39, s36, #18176
    s.addi       s40, s36, #18240
    a.vwrite     a5, s34, v1
    v.ld.w       v1, [s43, #0]
    s.addi       s34, s36, #18304
    a.vwrite     a5, s41, v1
    v.ld.w       v1, [s37, #0]
    s.addi       s37, s36, #18368
    a.vwrite     a5, s44, v1
    v.ld.w       v1, [s42, #0]
    s.addi       s41, s36, #18432
    a.vwrite     a5, s45, v1
    v.ld.w       v1, [s39, #0]
    s.addi       s39, s36, #18496
    a.vwrite     a5, s46, v1
    v.ld.w       v1, [s40, #0]
    s.addi       s40, s36, #18560
    a.vwrite     a5, s47, v1
    v.ld.w       v1, [s34, #0]
    s.addi       s34, s36, #18624
    a.vwrite     a5, s48, v1
    v.ld.w       v1, [s37, #0]
    s.addi       s37, s36, #18688
    s.movz       s42, #0
    a.vwrite     a5, s49, v1
    v.ld.w       v1, [s41, #0]
    s.addi       s41, s36, #18752
    s.movz       s43, #1
    a.vwrite     a5, s50, v1
    v.ld.w       v1, [s39, #0]
    s.movz       s39, #2
    a.vwrite     a5, s35, v1
    v.ld.w       v1, [s40, #0]
    s.addi       s35, s36, #18816
    a.vwrite     a5, s33, v1
    v.ld.w       v1, [s34, #0]
    s.addi       s33, s36, #18880
    s.movz       s34, #3
    a.vwrite     a5, s38, v1
    v.ld.w       v1, [s37, #0]
    s.addi       s37, s36, #18944
    s.movz       s38, #4
    a.vwrite     a6, s42, v1
    v.ld.w       v1, [s41, #0]
    s.addi       s40, s36, #19008
    s.movz       s41, #5
    a.vwrite     a6, s43, v1
    v.ld.w       v1, [s35, #0]
    s.addi       s35, s36, #19072
    s.movz       s44, #6
    a.vwrite     a6, s39, v1
    v.ld.w       v1, [s33, #0]
    s.addi       s33, s36, #19136
    s.movz       s45, #7
    a.vwrite     a6, s34, v1
    v.ld.w       v1, [s37, #0]
    s.addi       s37, s36, #19200
    s.movz       s46, #8
    a.vwrite     a6, s38, v1
    v.ld.w       v1, [s40, #0]
    s.addi       s40, s36, #19264
    s.movz       s47, #9
    a.vwrite     a6, s41, v1
    v.ld.w       v1, [s35, #0]
    s.addi       s35, s36, #19328
    s.movz       s48, #10
    a.vwrite     a6, s44, v1
    v.ld.w       v1, [s33, #0]
    s.addi       s33, s36, #19392
    s.movz       s49, #11
    a.vwrite     a6, s45, v1
    v.ld.w       v1, [s37, #0]
    s.addi       s37, s36, #19456
    s.movz       s50, #12
    a.vwrite     a6, s46, v1
    v.ld.w       v1, [s40, #0]
    s.addi       s40, s36, #19520
    a.vwrite     a6, s47, v1
    v.ld.w       v1, [s35, #0]
    s.movz       s35, #13
    a.vwrite     a6, s48, v1
    v.ld.w       v1, [s33, #0]
    s.addi       s33, s36, #19584
    a.vwrite     a6, s49, v1
    v.ld.w       v1, [s37, #0]
    s.movz       s37, #14
    a.vwrite     a6, s50, v1
    v.ld.w       v1, [s40, #0]
    s.addi       s40, s36, #19648
    a.vwrite     a6, s35, v1
    v.ld.w       v1, [s33, #0]
    s.movz       s33, #15
    a.vwrite     a6, s37, v1
    v.ld.w       v1, [s40, #0]
    s.addi       s40, s36, #19712
    a.vwrite     a6, s33, v1
    v.ld.w       v1, [s40, #0]
    s.addi       s40, s36, #19776
    a.vwrite     a7, s42, v1
    v.ld.w       v1, [s40, #0]
    s.addi       s40, s36, #19840
    s.addi       s42, s36, #19904
    a.vwrite     a7, s43, v1
    v.ld.w       v1, [s40, #0]
    s.addi       s40, s36, #19968
    s.addi       s43, s36, #20032
    a.vwrite     a7, s39, v1
    v.ld.w       v1, [s42, #0]
    s.addi       s39, s36, #20096
    s.addi       s42, s36, #20160
    a.vwrite     a7, s34, v1
    v.ld.w       v1, [s40, #0]
    s.addi       s34, s36, #20224
    s.addi       s40, s36, #20288
    a.vwrite     a7, s38, v1
    v.ld.w       v1, [s43, #0]
    s.addi       s38, s36, #20352
    a.vwrite     a7, s41, v1
    v.ld.w       v1, [s39, #0]
    s.addi       s39, s36, #20416
    a.vwrite     a7, s44, v1
    v.ld.w       v1, [s42, #0]
    s.addi       s41, s36, #20480
    a.vwrite     a7, s45, v1
    v.ld.w       v1, [s34, #0]
    s.addi       s34, s36, #20544
    a.vwrite     a7, s46, v1
    v.ld.w       v1, [s40, #0]
    s.addi       s40, s36, #20608
    a.vwrite     a7, s47, v1
    v.ld.w       v1, [s38, #0]
    s.addi       s38, s36, #20672
    a.vwrite     a7, s48, v1
    v.ld.w       v1, [s39, #0]
    s.add        s36, s29, s27
    s.movz       s39, #1
    a.vwrite     a7, s49, v1
    v.ld.w       v1, [s41, #0]
    a.vwrite     a7, s50, v1
    v.ld.w       v1, [s34, #0]
    a.vwrite     a7, s35, v1
    v.ld.w       v1, [s40, #0]
    a.vwrite     a7, s37, v1
    v.ld.w       v1, [s38, #0]
    a.vwrite     a7, s33, v1
    s.mov        s29, s36
    br.nz        s39, for_28
endfor_29:
    s.movz       s1, #0
    s.mul        s16, s17, s14
    v.splat      v0, s26
    a.vread      v1, a0, s1
    s.muli       s19, s18, #2
    s.muli       s20, s14, #2
    vf.mul       v2, v1, v0
    s.muli       s21, s16, #2
    s.addi       s16, s18, #16
    s.addi       s22, s18, #32
    s.add        s23, s1, s17                    // the tile origin
    vf.cvt.f32.bf16 v1, v2
    s.add        s17, s21, s19
    s.addi       s24, s18, #48
    v.splat      v2, s23
    s.add        s25, s6, s17
    s.addi       s17, s18, #64
    s.add        s26, s1, s9                     // the tile origin
    s.addi       s27, s18, #80
    v.splat      v3, s26
    s.addi       s26, s18, #96
    s.addi       s28, s18, #112
    s.add        s29, s1, s18                    // the tile origin
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s29
    s.add        s18, s1, s10                    // the tile origin
    v.cmp.lt     p1, v2, v3
    v.add        v2, v4, v5
    v.splat      v5, s18
    s.movz       s1, #1
    s.muli       s18, s20, #1
    v.cmp.lt     p2, v2, v5
    p.and        p3, p1, p2
    s.addi       s29, s23, #1
    @p3 v.st.h       [s25, #0], v1
    a.vread      v1, a0, s1
    s.add        s1, s18, s21
    v.splat      v2, s29
    vf.mul       v5, v1, v0
    s.add        s18, s1, s19
    v.cmp.lt     p1, v2, v3
    s.add        s1, s6, s18
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.movz       s18, #2
    s.muli       s25, s20, #2
    s.addi       s29, s23, #2
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a0, s18
    s.add        s1, s25, s21
    v.splat      v2, s29
    vf.mul       v5, v1, v0
    s.add        s18, s1, s19
    v.cmp.lt     p1, v2, v3
    s.add        s1, s6, s18
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.movz       s18, #3
    s.muli       s25, s20, #3
    s.addi       s29, s23, #3
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a0, s18
    s.add        s1, s25, s21
    v.splat      v2, s29
    vf.mul       v5, v1, v0
    s.add        s18, s1, s19
    v.cmp.lt     p1, v2, v3
    s.add        s1, s6, s18
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.movz       s18, #4
    s.muli       s25, s20, #4
    s.addi       s29, s23, #4
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a0, s18
    s.add        s1, s25, s21
    v.splat      v2, s29
    vf.mul       v5, v1, v0
    s.add        s18, s1, s19
    v.cmp.lt     p1, v2, v3
    s.add        s1, s6, s18
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.movz       s18, #5
    s.muli       s25, s20, #5
    s.addi       s29, s23, #5
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a0, s18
    s.add        s1, s25, s21
    v.splat      v2, s29
    vf.mul       v5, v1, v0
    s.add        s18, s1, s19
    v.cmp.lt     p1, v2, v3
    s.add        s1, s6, s18
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.movz       s18, #6
    s.muli       s25, s20, #6
    s.addi       s29, s23, #6
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a0, s18
    s.add        s1, s25, s21
    v.splat      v2, s29
    vf.mul       v5, v1, v0
    s.add        s18, s1, s19
    v.cmp.lt     p1, v2, v3
    s.add        s1, s6, s18
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.movz       s18, #7
    s.muli       s25, s20, #7
    s.addi       s29, s23, #7
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a0, s18
    s.add        s1, s25, s21
    v.splat      v2, s29
    vf.mul       v5, v1, v0
    s.add        s18, s1, s19
    v.cmp.lt     p1, v2, v3
    s.add        s1, s6, s18
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.movz       s18, #8
    s.muli       s25, s20, #8
    s.addi       s29, s23, #8
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a0, s18
    s.add        s1, s25, s21
    v.splat      v2, s29
    vf.mul       v5, v1, v0
    s.add        s18, s1, s19
    v.cmp.lt     p1, v2, v3
    s.add        s1, s6, s18
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.movz       s18, #9
    s.muli       s25, s20, #9
    s.addi       s29, s23, #9
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a0, s18
    s.add        s1, s25, s21
    v.splat      v2, s29
    vf.mul       v5, v1, v0
    s.add        s18, s1, s19
    v.cmp.lt     p1, v2, v3
    s.add        s1, s6, s18
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.movz       s18, #10
    s.muli       s25, s20, #10
    s.addi       s29, s23, #10
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a0, s18
    s.add        s1, s25, s21
    v.splat      v2, s29
    vf.mul       v5, v1, v0
    s.add        s18, s1, s19
    v.cmp.lt     p1, v2, v3
    s.add        s1, s6, s18
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.movz       s18, #11
    s.muli       s25, s20, #11
    s.addi       s29, s23, #11
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a0, s18
    s.add        s1, s25, s21
    v.splat      v2, s29
    vf.mul       v5, v1, v0
    s.add        s18, s1, s19
    v.cmp.lt     p1, v2, v3
    s.add        s1, s6, s18
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.movz       s18, #12
    s.muli       s25, s20, #12
    s.addi       s29, s23, #12
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a0, s18
    s.add        s1, s25, s21
    v.splat      v2, s29
    vf.mul       v5, v1, v0
    s.add        s18, s1, s19
    v.cmp.lt     p1, v2, v3
    s.add        s1, s6, s18
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.movz       s18, #13
    s.muli       s25, s20, #13
    s.addi       s29, s23, #13
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a0, s18
    s.add        s1, s25, s21
    v.splat      v2, s29
    vf.mul       v5, v1, v0
    s.add        s18, s1, s19
    v.cmp.lt     p1, v2, v3
    s.add        s1, s6, s18
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.movz       s18, #14
    s.muli       s25, s20, #14
    s.addi       s29, s23, #14
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a0, s18
    s.add        s1, s25, s21
    v.splat      v2, s29
    vf.mul       v5, v1, v0
    s.add        s18, s1, s19
    v.cmp.lt     p1, v2, v3
    s.add        s1, s6, s18
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.movz       s18, #15
    s.muli       s25, s20, #15
    s.addi       s29, s23, #15
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a0, s18
    s.add        s1, s25, s21
    v.splat      v2, s29
    vf.mul       v5, v1, v0
    s.add        s18, s1, s19
    v.cmp.lt     p1, v2, v3
    s.add        s1, s6, s18
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.movz       s18, #0
    s.muli       s19, s16, #2
    s.add        s25, s18, s16                   // the tile origin
    s.add        s16, s18, s10                   // the tile origin
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a1, s18
    v.splat      v2, s25
    v.splat      v5, s23
    vf.mul       v6, v1, v0
    v.add        v1, v4, v2
    s.add        s1, s21, s19
    v.cmp.lt     p1, v5, v3
    v.splat      v2, s16
    vf.cvt.f32.bf16 v5, v6
    s.add        s16, s6, s1
    v.cmp.lt     p2, v1, v2
    p.and        p3, p1, p2
    s.movz       s1, #1
    @p3 v.st.h       [s16, #0], v5
    a.vread      v1, a1, s1
    s.muli       s1, s20, #1
    s.addi       s16, s23, #1
    vf.mul       v2, v1, v0
    v.splat      v1, s16
    s.movz       s16, #2
    s.add        s18, s1, s21
    v.cmp.lt     p1, v1, v3
    vf.cvt.f32.bf16 v1, v2
    s.add        s1, s18, s19
    p.and        p3, p1, p2
    s.add        s18, s6, s1
    s.muli       s1, s20, #2
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a1, s16
    s.addi       s16, s23, #2
    s.movz       s18, #3
    vf.mul       v2, v1, v0
    s.add        s25, s1, s21
    v.splat      v1, s16
    s.add        s1, s25, s19
    s.muli       s16, s20, #3
    vf.cvt.f32.bf16 v5, v2
    v.cmp.lt     p1, v1, v3
    s.add        s25, s6, s1
    p.and        p3, p1, p2
    s.addi       s1, s23, #3
    @p3 v.st.h       [s25, #0], v5
    a.vread      v1, a1, s18
    s.add        s18, s16, s21
    v.splat      v2, s1
    vf.mul       v5, v1, v0
    s.add        s1, s18, s19
    v.cmp.lt     p1, v2, v3
    s.add        s16, s6, s1
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.movz       s1, #4
    s.muli       s18, s20, #4
    s.addi       s25, s23, #4
    s.movz       s29, #5
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a1, s1
    s.add        s1, s18, s21
    v.splat      v2, s25
    vf.mul       v5, v1, v0
    s.add        s16, s1, s19
    v.cmp.lt     p1, v2, v3
    s.add        s1, s6, s16
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.muli       s16, s20, #5
    s.addi       s18, s23, #5
    s.movz       s25, #6
    v.splat      v2, s18
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a1, s29
    s.add        s1, s16, s21
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s16, s1, s19
    p.and        p3, p1, p2
    s.add        s1, s6, s16
    s.muli       s16, s20, #6
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #6
    s.movz       s29, #7
    v.splat      v2, s18
    s.add        s18, s16, s21
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a1, s25
    s.add        s1, s18, s19
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s16, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #7
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #7
    s.movz       s25, #8
    s.add        s30, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a1, s29
    s.add        s1, s30, s19
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s16, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #8
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #8
    s.movz       s29, #9
    s.add        s30, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a1, s25
    s.add        s1, s30, s19
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s16, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #9
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #9
    s.movz       s25, #10
    s.add        s30, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a1, s29
    s.add        s1, s30, s19
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s16, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #10
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #10
    s.movz       s29, #11
    s.add        s30, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a1, s25
    s.add        s1, s30, s19
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s16, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #11
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #11
    s.movz       s25, #12
    s.add        s30, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a1, s29
    s.add        s1, s30, s19
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s16, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #12
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #12
    s.movz       s29, #13
    s.add        s30, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a1, s25
    s.add        s1, s30, s19
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s16, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #13
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #13
    s.movz       s25, #14
    s.add        s30, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a1, s29
    s.add        s1, s30, s19
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s16, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #14
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #14
    s.movz       s29, #15
    s.add        s30, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a1, s25
    s.add        s1, s30, s19
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s16, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #15
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #15
    s.movz       s25, #0
    s.add        s30, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a1, s29
    s.add        s1, s30, s19
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s16, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s22, #2
    vf.cvt.f32.bf16 v1, v2
    s.add        s18, s25, s22                   // the tile origin
    s.add        s19, s25, s10                   // the tile origin
    v.splat      v2, s18
    v.splat      v5, s23
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a2, s25
    v.add        v6, v4, v2
    s.add        s16, s21, s1
    vf.mul       v2, v1, v0
    v.cmp.lt     p1, v5, v3
    v.splat      v1, s19
    s.add        s18, s6, s16
    s.movz       s16, #1
    vf.cvt.f32.bf16 v5, v2
    v.cmp.lt     p2, v6, v1
    p.and        p3, p1, p2
    s.muli       s19, s20, #1
    s.addi       s22, s23, #1
    @p3 v.st.h       [s18, #0], v5
    a.vread      v1, a2, s16
    v.splat      v2, s22
    s.add        s16, s19, s21
    vf.mul       v5, v1, v0
    s.add        s18, s16, s1
    v.cmp.lt     p1, v2, v3
    s.add        s16, s6, s18
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.movz       s18, #2
    s.muli       s19, s20, #2
    s.addi       s22, s23, #2
    s.movz       s25, #3
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a2, s18
    s.add        s16, s19, s21
    v.splat      v2, s22
    vf.mul       v5, v1, v0
    s.add        s18, s16, s1
    v.cmp.lt     p1, v2, v3
    s.add        s16, s6, s18
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.muli       s18, s20, #3
    s.addi       s19, s23, #3
    s.movz       s22, #4
    v.splat      v2, s19
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a2, s25
    s.add        s16, s18, s21
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s18, s16, s1
    p.and        p3, p1, p2
    s.add        s16, s6, s18
    s.muli       s18, s20, #4
    vf.cvt.f32.bf16 v1, v2
    s.addi       s19, s23, #4
    s.movz       s25, #5
    v.splat      v2, s19
    s.add        s19, s18, s21
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a2, s22
    s.add        s16, s19, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s18, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #5
    vf.cvt.f32.bf16 v1, v2
    s.addi       s19, s23, #5
    s.movz       s22, #6
    s.add        s29, s16, s21
    v.splat      v2, s19
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a2, s25
    s.add        s16, s29, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s18, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #6
    vf.cvt.f32.bf16 v1, v2
    s.addi       s19, s23, #6
    s.movz       s25, #7
    s.add        s29, s16, s21
    v.splat      v2, s19
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a2, s22
    s.add        s16, s29, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s18, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #7
    vf.cvt.f32.bf16 v1, v2
    s.addi       s19, s23, #7
    s.movz       s22, #8
    s.add        s29, s16, s21
    v.splat      v2, s19
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a2, s25
    s.add        s16, s29, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s18, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #8
    vf.cvt.f32.bf16 v1, v2
    s.addi       s19, s23, #8
    s.movz       s25, #9
    s.add        s29, s16, s21
    v.splat      v2, s19
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a2, s22
    s.add        s16, s29, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s18, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #9
    vf.cvt.f32.bf16 v1, v2
    s.addi       s19, s23, #9
    s.movz       s22, #10
    s.add        s29, s16, s21
    v.splat      v2, s19
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a2, s25
    s.add        s16, s29, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s18, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #10
    vf.cvt.f32.bf16 v1, v2
    s.addi       s19, s23, #10
    s.movz       s25, #11
    s.add        s29, s16, s21
    v.splat      v2, s19
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a2, s22
    s.add        s16, s29, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s18, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #11
    vf.cvt.f32.bf16 v1, v2
    s.addi       s19, s23, #11
    s.movz       s22, #12
    s.add        s29, s16, s21
    v.splat      v2, s19
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a2, s25
    s.add        s16, s29, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s18, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #12
    vf.cvt.f32.bf16 v1, v2
    s.addi       s19, s23, #12
    s.movz       s25, #13
    s.add        s29, s16, s21
    v.splat      v2, s19
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a2, s22
    s.add        s16, s29, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s18, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #13
    vf.cvt.f32.bf16 v1, v2
    s.addi       s19, s23, #13
    s.movz       s22, #14
    s.add        s29, s16, s21
    v.splat      v2, s19
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a2, s25
    s.add        s16, s29, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s18, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #14
    vf.cvt.f32.bf16 v1, v2
    s.addi       s19, s23, #14
    s.movz       s25, #15
    s.add        s29, s16, s21
    v.splat      v2, s19
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a2, s22
    s.add        s16, s29, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s18, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #15
    vf.cvt.f32.bf16 v1, v2
    s.addi       s19, s23, #15
    s.movz       s22, #0
    s.add        s29, s16, s21
    v.splat      v2, s19
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a2, s25
    s.add        s16, s29, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s1, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s24, #2
    vf.cvt.f32.bf16 v1, v2
    s.add        s18, s22, s24                   // the tile origin
    s.add        s19, s22, s10                   // the tile origin
    v.splat      v2, s18
    v.splat      v5, s23
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a3, s22
    v.add        v6, v4, v2
    s.add        s1, s21, s16
    vf.mul       v2, v1, v0
    v.cmp.lt     p1, v5, v3
    v.splat      v1, s19
    s.add        s18, s6, s1
    s.movz       s1, #1
    vf.cvt.f32.bf16 v5, v2
    v.cmp.lt     p2, v6, v1
    p.and        p3, p1, p2
    s.muli       s19, s20, #1
    s.addi       s22, s23, #1
    @p3 v.st.h       [s18, #0], v5
    a.vread      v1, a3, s1
    v.splat      v2, s22
    s.add        s1, s19, s21
    vf.mul       v5, v1, v0
    s.add        s18, s1, s16
    v.cmp.lt     p1, v2, v3
    s.add        s1, s6, s18
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.movz       s18, #2
    s.muli       s19, s20, #2
    s.addi       s22, s23, #2
    s.movz       s24, #3
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a3, s18
    s.add        s1, s19, s21
    v.splat      v2, s22
    vf.mul       v5, v1, v0
    s.add        s18, s1, s16
    v.cmp.lt     p1, v2, v3
    s.add        s1, s6, s18
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.muli       s18, s20, #3
    s.addi       s19, s23, #3
    s.movz       s22, #4
    v.splat      v2, s19
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a3, s24
    s.add        s1, s18, s21
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s18, s1, s16
    p.and        p3, p1, p2
    s.add        s1, s6, s18
    s.muli       s18, s20, #4
    vf.cvt.f32.bf16 v1, v2
    s.addi       s19, s23, #4
    s.movz       s24, #5
    v.splat      v2, s19
    s.add        s19, s18, s21
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a3, s22
    s.add        s1, s19, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s18, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #5
    vf.cvt.f32.bf16 v1, v2
    s.addi       s19, s23, #5
    s.movz       s22, #6
    s.add        s25, s1, s21
    v.splat      v2, s19
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a3, s24
    s.add        s1, s25, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s18, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #6
    vf.cvt.f32.bf16 v1, v2
    s.addi       s19, s23, #6
    s.movz       s24, #7
    s.add        s25, s1, s21
    v.splat      v2, s19
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a3, s22
    s.add        s1, s25, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s18, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #7
    vf.cvt.f32.bf16 v1, v2
    s.addi       s19, s23, #7
    s.movz       s22, #8
    s.add        s25, s1, s21
    v.splat      v2, s19
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a3, s24
    s.add        s1, s25, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s18, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #8
    vf.cvt.f32.bf16 v1, v2
    s.addi       s19, s23, #8
    s.movz       s24, #9
    s.add        s25, s1, s21
    v.splat      v2, s19
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a3, s22
    s.add        s1, s25, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s18, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #9
    vf.cvt.f32.bf16 v1, v2
    s.addi       s19, s23, #9
    s.movz       s22, #10
    s.add        s25, s1, s21
    v.splat      v2, s19
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a3, s24
    s.add        s1, s25, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s18, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #10
    vf.cvt.f32.bf16 v1, v2
    s.addi       s19, s23, #10
    s.movz       s24, #11
    s.add        s25, s1, s21
    v.splat      v2, s19
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a3, s22
    s.add        s1, s25, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s18, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #11
    vf.cvt.f32.bf16 v1, v2
    s.addi       s19, s23, #11
    s.movz       s22, #12
    s.add        s25, s1, s21
    v.splat      v2, s19
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a3, s24
    s.add        s1, s25, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s18, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #12
    vf.cvt.f32.bf16 v1, v2
    s.addi       s19, s23, #12
    s.movz       s24, #13
    s.add        s25, s1, s21
    v.splat      v2, s19
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a3, s22
    s.add        s1, s25, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s18, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #13
    vf.cvt.f32.bf16 v1, v2
    s.addi       s19, s23, #13
    s.movz       s22, #14
    s.add        s25, s1, s21
    v.splat      v2, s19
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a3, s24
    s.add        s1, s25, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s18, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #14
    vf.cvt.f32.bf16 v1, v2
    s.addi       s19, s23, #14
    s.movz       s24, #15
    s.add        s25, s1, s21
    v.splat      v2, s19
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a3, s22
    s.add        s1, s25, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s18, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #15
    vf.cvt.f32.bf16 v1, v2
    s.addi       s19, s23, #15
    s.movz       s22, #0
    s.add        s25, s1, s21
    v.splat      v2, s19
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a3, s24
    s.add        s1, s25, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s16, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s17, #2
    vf.cvt.f32.bf16 v1, v2
    s.add        s18, s22, s17                   // the tile origin
    s.add        s17, s22, s10                   // the tile origin
    v.splat      v2, s18
    v.splat      v5, s23
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a4, s22
    v.add        v6, v4, v2
    s.add        s16, s21, s1
    vf.mul       v2, v1, v0
    v.cmp.lt     p1, v5, v3
    v.splat      v1, s17
    s.add        s17, s6, s16
    s.movz       s16, #1
    vf.cvt.f32.bf16 v5, v2
    v.cmp.lt     p2, v6, v1
    p.and        p3, p1, p2
    s.muli       s18, s20, #1
    s.addi       s19, s23, #1
    @p3 v.st.h       [s17, #0], v5
    a.vread      v1, a4, s16
    v.splat      v2, s19
    s.add        s16, s18, s21
    vf.mul       v5, v1, v0
    s.add        s17, s16, s1
    v.cmp.lt     p1, v2, v3
    s.add        s16, s6, s17
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.movz       s17, #2
    s.muli       s18, s20, #2
    s.addi       s19, s23, #2
    s.movz       s22, #3
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a4, s17
    s.add        s16, s18, s21
    v.splat      v2, s19
    vf.mul       v5, v1, v0
    s.add        s17, s16, s1
    v.cmp.lt     p1, v2, v3
    s.add        s16, s6, s17
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.muli       s17, s20, #3
    s.addi       s18, s23, #3
    s.movz       s19, #4
    v.splat      v2, s18
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a4, s22
    s.add        s16, s17, s21
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s16, s1
    p.and        p3, p1, p2
    s.add        s16, s6, s17
    s.muli       s17, s20, #4
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #4
    s.movz       s22, #5
    v.splat      v2, s18
    s.add        s18, s17, s21
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a4, s19
    s.add        s16, s18, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #5
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #5
    s.movz       s19, #6
    s.add        s24, s16, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a4, s22
    s.add        s16, s24, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #6
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #6
    s.movz       s22, #7
    s.add        s24, s16, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a4, s19
    s.add        s16, s24, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #7
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #7
    s.movz       s19, #8
    s.add        s24, s16, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a4, s22
    s.add        s16, s24, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #8
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #8
    s.movz       s22, #9
    s.add        s24, s16, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a4, s19
    s.add        s16, s24, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #9
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #9
    s.movz       s19, #10
    s.add        s24, s16, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a4, s22
    s.add        s16, s24, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #10
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #10
    s.movz       s22, #11
    s.add        s24, s16, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a4, s19
    s.add        s16, s24, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #11
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #11
    s.movz       s19, #12
    s.add        s24, s16, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a4, s22
    s.add        s16, s24, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #12
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #12
    s.movz       s22, #13
    s.add        s24, s16, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a4, s19
    s.add        s16, s24, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #13
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #13
    s.movz       s19, #14
    s.add        s24, s16, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a4, s22
    s.add        s16, s24, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #14
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #14
    s.movz       s22, #15
    s.add        s24, s16, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a4, s19
    s.add        s16, s24, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #15
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #15
    s.movz       s19, #0
    s.add        s24, s16, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a4, s22
    s.add        s16, s24, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s1, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s27, #2
    vf.cvt.f32.bf16 v1, v2
    s.add        s17, s19, s27                   // the tile origin
    s.add        s18, s19, s10                   // the tile origin
    v.splat      v2, s17
    v.splat      v5, s23
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a5, s19
    v.add        v6, v4, v2
    s.add        s1, s21, s16
    vf.mul       v2, v1, v0
    v.cmp.lt     p1, v5, v3
    v.splat      v1, s18
    s.add        s17, s6, s1
    s.movz       s1, #1
    vf.cvt.f32.bf16 v5, v2
    v.cmp.lt     p2, v6, v1
    p.and        p3, p1, p2
    s.muli       s18, s20, #1
    s.addi       s19, s23, #1
    @p3 v.st.h       [s17, #0], v5
    a.vread      v1, a5, s1
    v.splat      v2, s19
    s.add        s1, s18, s21
    vf.mul       v5, v1, v0
    s.add        s17, s1, s16
    v.cmp.lt     p1, v2, v3
    s.add        s1, s6, s17
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.movz       s17, #2
    s.muli       s18, s20, #2
    s.addi       s19, s23, #2
    s.movz       s22, #3
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a5, s17
    s.add        s1, s18, s21
    v.splat      v2, s19
    vf.mul       v5, v1, v0
    s.add        s17, s1, s16
    v.cmp.lt     p1, v2, v3
    s.add        s1, s6, s17
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.muli       s17, s20, #3
    s.addi       s18, s23, #3
    s.movz       s19, #4
    v.splat      v2, s18
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a5, s22
    s.add        s1, s17, s21
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s1, s16
    p.and        p3, p1, p2
    s.add        s1, s6, s17
    s.muli       s17, s20, #4
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #4
    s.movz       s22, #5
    v.splat      v2, s18
    s.add        s18, s17, s21
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a5, s19
    s.add        s1, s18, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #5
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #5
    s.movz       s19, #6
    s.add        s24, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a5, s22
    s.add        s1, s24, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #6
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #6
    s.movz       s22, #7
    s.add        s24, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a5, s19
    s.add        s1, s24, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #7
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #7
    s.movz       s19, #8
    s.add        s24, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a5, s22
    s.add        s1, s24, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #8
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #8
    s.movz       s22, #9
    s.add        s24, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a5, s19
    s.add        s1, s24, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #9
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #9
    s.movz       s19, #10
    s.add        s24, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a5, s22
    s.add        s1, s24, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #10
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #10
    s.movz       s22, #11
    s.add        s24, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a5, s19
    s.add        s1, s24, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #11
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #11
    s.movz       s19, #12
    s.add        s24, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a5, s22
    s.add        s1, s24, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #12
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #12
    s.movz       s22, #13
    s.add        s24, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a5, s19
    s.add        s1, s24, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #13
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #13
    s.movz       s19, #14
    s.add        s24, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a5, s22
    s.add        s1, s24, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #14
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #14
    s.movz       s22, #15
    s.add        s24, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a5, s19
    s.add        s1, s24, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #15
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #15
    s.movz       s19, #0
    s.add        s24, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a5, s22
    s.add        s1, s24, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s16, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s26, #2
    vf.cvt.f32.bf16 v1, v2
    s.add        s17, s19, s26                   // the tile origin
    s.add        s18, s19, s10                   // the tile origin
    v.splat      v2, s17
    v.splat      v5, s23
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a6, s19
    v.add        v6, v4, v2
    s.add        s16, s21, s1
    vf.mul       v2, v1, v0
    v.cmp.lt     p1, v5, v3
    v.splat      v1, s18
    s.add        s17, s6, s16
    s.movz       s16, #1
    vf.cvt.f32.bf16 v5, v2
    v.cmp.lt     p2, v6, v1
    p.and        p3, p1, p2
    s.muli       s18, s20, #1
    s.addi       s19, s23, #1
    @p3 v.st.h       [s17, #0], v5
    a.vread      v1, a6, s16
    v.splat      v2, s19
    s.add        s16, s18, s21
    vf.mul       v5, v1, v0
    s.add        s17, s16, s1
    v.cmp.lt     p1, v2, v3
    s.add        s16, s6, s17
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.movz       s17, #2
    s.muli       s18, s20, #2
    s.addi       s19, s23, #2
    s.movz       s22, #3
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a6, s17
    s.add        s16, s18, s21
    v.splat      v2, s19
    vf.mul       v5, v1, v0
    s.add        s17, s16, s1
    v.cmp.lt     p1, v2, v3
    s.add        s16, s6, s17
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.muli       s17, s20, #3
    s.addi       s18, s23, #3
    s.movz       s19, #4
    v.splat      v2, s18
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a6, s22
    s.add        s16, s17, s21
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s16, s1
    p.and        p3, p1, p2
    s.add        s16, s6, s17
    s.muli       s17, s20, #4
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #4
    s.movz       s22, #5
    v.splat      v2, s18
    s.add        s18, s17, s21
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a6, s19
    s.add        s16, s18, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #5
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #5
    s.movz       s19, #6
    s.add        s24, s16, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a6, s22
    s.add        s16, s24, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #6
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #6
    s.movz       s22, #7
    s.add        s24, s16, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a6, s19
    s.add        s16, s24, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #7
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #7
    s.movz       s19, #8
    s.add        s24, s16, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a6, s22
    s.add        s16, s24, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #8
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #8
    s.movz       s22, #9
    s.add        s24, s16, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a6, s19
    s.add        s16, s24, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #9
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #9
    s.movz       s19, #10
    s.add        s24, s16, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a6, s22
    s.add        s16, s24, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #10
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #10
    s.movz       s22, #11
    s.add        s24, s16, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a6, s19
    s.add        s16, s24, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #11
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #11
    s.movz       s19, #12
    s.add        s24, s16, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a6, s22
    s.add        s16, s24, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #12
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #12
    s.movz       s22, #13
    s.add        s24, s16, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a6, s19
    s.add        s16, s24, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #13
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #13
    s.movz       s19, #14
    s.add        s24, s16, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a6, s22
    s.add        s16, s24, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #14
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #14
    s.movz       s22, #15
    s.add        s24, s16, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a6, s19
    s.add        s16, s24, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s20, #15
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #15
    s.movz       s19, #0
    s.add        s24, s16, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a6, s22
    s.add        s16, s24, s1
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s1, s6, s16
    p.and        p3, p1, p2
    s.muli       s16, s28, #2
    vf.cvt.f32.bf16 v1, v2
    s.add        s17, s19, s28                   // the tile origin
    s.add        s18, s19, s10                   // the tile origin
    v.splat      v2, s17
    v.splat      v5, s23
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a7, s19
    v.add        v6, v4, v2
    v.splat      v2, s18
    vf.mul       v4, v1, v0
    s.add        s1, s21, s16
    v.cmp.lt     p1, v5, v3
    v.cmp.lt     p2, v6, v2
    s.add        s17, s6, s1
    vf.cvt.f32.bf16 v1, v4
    p.and        p3, p1, p2
    s.movz       s1, #1
    s.muli       s18, s20, #1
    s.addi       s19, s23, #1
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a7, s1
    v.splat      v2, s19
    s.add        s1, s18, s21
    vf.mul       v4, v1, v0
    s.add        s17, s1, s16
    v.cmp.lt     p1, v2, v3
    s.add        s1, s6, s17
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v4
    s.movz       s17, #2
    s.muli       s18, s20, #2
    s.addi       s19, s23, #2
    s.movz       s22, #3
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a7, s17
    s.add        s1, s18, s21
    v.splat      v2, s19
    vf.mul       v4, v1, v0
    s.add        s17, s1, s16
    v.cmp.lt     p1, v2, v3
    s.add        s1, s6, s17
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v4
    s.muli       s17, s20, #3
    s.addi       s18, s23, #3
    s.movz       s19, #4
    v.splat      v2, s18
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a7, s22
    s.add        s1, s17, s21
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s1, s16
    p.and        p3, p1, p2
    s.add        s1, s6, s17
    s.muli       s17, s20, #4
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #4
    s.movz       s22, #5
    v.splat      v2, s18
    s.add        s18, s17, s21
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a7, s19
    s.add        s1, s18, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #5
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #5
    s.movz       s19, #6
    s.add        s24, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a7, s22
    s.add        s1, s24, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #6
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #6
    s.movz       s22, #7
    s.add        s24, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a7, s19
    s.add        s1, s24, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #7
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #7
    s.movz       s19, #8
    s.add        s24, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a7, s22
    s.add        s1, s24, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #8
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #8
    s.movz       s22, #9
    s.add        s24, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a7, s19
    s.add        s1, s24, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #9
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #9
    s.movz       s19, #10
    s.add        s24, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a7, s22
    s.add        s1, s24, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #10
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #10
    s.movz       s22, #11
    s.add        s24, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a7, s19
    s.add        s1, s24, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #11
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #11
    s.movz       s19, #12
    s.add        s24, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a7, s22
    s.add        s1, s24, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #12
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #12
    s.movz       s22, #13
    s.add        s24, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a7, s19
    s.add        s1, s24, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #13
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #13
    s.movz       s19, #14
    s.add        s24, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a7, s22
    s.add        s1, s24, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #14
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #14
    s.movz       s22, #15
    s.add        s24, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a7, s19
    s.add        s1, s24, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s17, s6, s1
    p.and        p3, p1, p2
    s.muli       s1, s20, #15
    vf.cvt.f32.bf16 v1, v2
    s.addi       s18, s23, #15
    s.addi       s19, s4, #16
    s.add        s20, s1, s21
    v.splat      v2, s18
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a7, s22
    s.add        s1, s20, s16
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v1, v0
    s.add        s16, s6, s1
    p.and        p3, p1, p2
    s.movz       s1, #128
    vf.cvt.f32.bf16 v0, v2
    @p3 v.st.h       [s16, #0], v0
    s.mov        s4, s19
    s.cmp.lt     s16, s4, s1
    br.nz        s16, rows_1
endrows_2:
    exit
    exit
