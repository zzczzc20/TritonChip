# AOT ID: ['1_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-v4-quality-20261031/caches/inductor/yo/cyolgfz7z36rr43o3fkapvwf6zhqrdgg333fyhro7ig74j6k3tr5.py
# Topologically Sorted Source Nodes: [position_ids, position_ids_1, getitem_6, float_1, freqs, sin_1, getitem_8, cos_1, getitem_11], Original ATen: [aten.slice, aten.expand, aten.unsqueeze, aten._to_copy, aten.mul, aten.select]
# Source node to ATen node mapping:
#   cos_1 => cos
#   float_1 => convert_element_type
#   freqs => mul
#   getitem_11 => select_13, slice_10
#   getitem_6 => unsqueeze_6
#   getitem_8 => select_1, slice_2
#   position_ids => slice_1
#   position_ids_1 => expand_1
#   sin_1 => sin
# Graph fragment:
#   %arg2_1 : Tensor "i64[4, 1, 4][4, 4, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %arg4_1 : Tensor "f32[64][1]tnca:0" = PlaceHolder[target=arg4_1]
#   %slice_1 : Tensor "i64[3, 1, 4][4, 4, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%arg2_1, 0, 1, 9223372036854775807), kwargs = {})
#   %expand_1 : Tensor "i64[3, 1, 4][4, 4, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%slice_1, [3, -1, -1]), kwargs = {})
#   %unsqueeze_6 : Tensor "i64[3, 1, 4, 1][4, 4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%expand_1, 3), kwargs = {})
#   %convert_element_type : Tensor "f32[3, 1, 4, 1][4, 4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_6, torch.float32), kwargs = {})
#   %mul : Tensor "f32[3, 1, 4, 64][256, 256, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, %arg4_1), kwargs = {})
#   %sin : Tensor "f32[3, 1, 4, 64][256, 256, 64, 1]tnca:0"[num_users=5] = call_function[target=torch.ops.aten.sin.default](args = (%mul,), kwargs = {})
#   %select_1 : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%sin, 0, 1), kwargs = {})
#   %slice_2 : Tensor "f32[1, 4, 20][256, 64, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_1, 2, 1, 60, 3), kwargs = {})
#   %select_int : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%sin, 0, 0), kwargs = {})
#   %slice_scatter_default : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int, %slice_2, 2, 1, 60, 3), kwargs = {})
#   %select_scatter_default : Tensor "f32[3, 1, 4, 64][256, 256, 64, 1]tnca:0"[num_users=5] = call_function[target=torch.ops.aten.select_scatter.default](args = (%sin, %slice_scatter_default, 0, 0), kwargs = {})
#   %cos : Tensor "f32[3, 1, 4, 64][256, 256, 64, 1]tnca:0"[num_users=5] = call_function[target=torch.ops.aten.cos.default](args = (%mul,), kwargs = {})
#   %select_13 : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%cos, 0, 1), kwargs = {})
#   %slice_10 : Tensor "f32[1, 4, 20][256, 64, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_13, 2, 1, 60, 3), kwargs = {})
#   %select_int_1 : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%cos, 0, 0), kwargs = {})
#   %slice_scatter_default_1 : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_1, %slice_10, 2, 1, 60, 3), kwargs = {})
#   %select_scatter_default_1 : Tensor "f32[3, 1, 4, 64][256, 256, 64, 1]tnca:0"[num_users=5] = call_function[target=torch.ops.aten.select_scatter.default](args = (%cos, %slice_scatter_default_1, 0, 0), kwargs = {})
#   return %select_scatter_default,%select_scatter_default_1
triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_0 = async_compile.triton('triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1024}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 12704}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_0(in_ptr0, in_ptr1, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 768
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x2 = xindex // 256
    x0 = (xindex % 64)
    x1 = ((xindex // 64) % 4)
    x3 = xindex // 64
    x4 = xindex
    tmp22 = tl.load(in_ptr0 + (4 + x1), xmask, eviction_policy='evict_last')
    tmp24 = tl.load(in_ptr1 + (x0), xmask, eviction_policy='evict_last')
    tmp28 = tl.load(in_ptr0 + (4 + x3), xmask, eviction_policy='evict_last')
    tmp0 = (x2).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int32)
    tmp2 = tmp0 == tmp1
    tmp3 = (x0).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1], 1, tl.int64)
    tmp6 = tmp4 >= tmp5
    tmp7 = tl.full([1], 60, tl.int64)
    tmp8 = tmp4 < tmp7
    tmp9 = ((((-1) + x0) % 3)).to(tl.int64)
    tmp10 = (tmp9).to(tl.int64)
    tmp11 = tl.full([1], 0, tl.int64)
    tmp12 = tmp10 == tmp11
    tmp13 = tmp6 & tmp8
    tmp14 = tmp13 & tmp12
    tmp15 = tl.load(in_ptr0 + (8 + x1), tmp14 & xmask, eviction_policy='evict_last', other=0.0)
    tmp16 = tmp15.to(tl.float32)
    tmp17 = tl.load(in_ptr1 + (1 + 3*(triton_helpers.div_floor_integer((-1) + x0,  3))), tmp14 & xmask, eviction_policy='evict_last', other=0.0)
    tmp18 = tmp16 * tmp17
    tmp19 = tl_math.sin(tmp18)
    tmp20 = tl.full(tmp19.shape, 0.0, tmp19.dtype)
    tmp21 = tl.where(tmp14, tmp19, tmp20)
    tmp23 = tmp22.to(tl.float32)
    tmp25 = tmp23 * tmp24
    tmp26 = tl_math.sin(tmp25)
    tmp27 = tl.where(tmp14, tmp21, tmp26)
    tmp29 = tmp28.to(tl.float32)
    tmp30 = tmp29 * tmp24
    tmp31 = tl_math.sin(tmp30)
    tmp32 = tl.where(tmp2, tmp27, tmp31)
    tmp33 = tl_math.cos(tmp18)
    tmp34 = tl.full(tmp33.shape, 0.0, tmp33.dtype)
    tmp35 = tl.where(tmp14, tmp33, tmp34)
    tmp36 = tl_math.cos(tmp25)
    tmp37 = tl.where(tmp14, tmp35, tmp36)
    tmp38 = tl_math.cos(tmp30)
    tmp39 = tl.where(tmp2, tmp37, tmp38)
    tl.store(out_ptr0 + (x4), tmp32, xmask)
    tl.store(out_ptr1 + (x4), tmp39, xmask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-v4-quality-20261031/caches/inductor/tm/ctm7dy5gygw2labdcp7qo4o5gefunfxkfjqr4o4pacslmfzskh2g.py
# Topologically Sorted Source Nodes: [inputs_embeds, hidden_states, pow_1, variance, add_2, rsqrt, hidden_states_1, to_5, hidden_states_2, output, output_1, output_2], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_2 => add_2
#   hidden_states => convert_element_type_3
#   hidden_states_1 => mul_3
#   hidden_states_2 => mul_4
#   inputs_embeds => embedding
#   output => triton_kernel_wrapper_mutation_195
#   output_1 => triton_kernel_wrapper_mutation_194
#   output_2 => triton_kernel_wrapper_mutation_193
#   pow_1 => pow_1
#   rsqrt => rsqrt
#   to_5 => convert_element_type_4
#   variance => mean
# Graph fragment:
#   %arg0_1 : Tensor "i64[1, 4][4, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %arg1_1 : Tensor "bf16[151936, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg5_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg5_1]
#   %buf2 : Tensor "f32[1, 4, 1][4, 1, 4]tnca:0" = PlaceHolder[target=buf2]
#   %embedding : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg1_1, %arg0_1), kwargs = {})
#   %convert_element_type_3 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%embedding, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_3, 2), kwargs = {})
#   %mean : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [-1], True), kwargs = {})
#   %add_2 : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean, 1e-06), kwargs = {})
#   %rsqrt : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_2,), kwargs = {})
#   %mul_3 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_3, %rsqrt), kwargs = {})
#   %convert_element_type_4 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_3, torch.bfloat16), kwargs = {})
#   %mul_4 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg5_1, %convert_element_type_4), kwargs = {})
#   %triton_kernel_wrapper_mutation_195 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 980, grid: [(1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1)], tma_descriptor_metadata: {}, kwargs: {A: %mul_4, B: %arg6_1, C: %empty, Bs: %arg7_1, M: 4, N: 2048, K: 2048, stride_am: 2048, stride_ak: 1, stride_bk: 1, stride_bn: 2048, stride_cm: 2048, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 16, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   %triton_kernel_wrapper_mutation_194 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 981, grid: [(1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1)], tma_descriptor_metadata: {}, kwargs: {A: %mul_4, B: %arg9_1, C: %empty_1, Bs: %arg10_1, M: 4, N: 1024, K: 2048, stride_am: 2048, stride_ak: 1, stride_bk: 1, stride_bn: 2048, stride_cm: 1024, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 16, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   %triton_kernel_wrapper_mutation_193 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 982, grid: [(1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1)], tma_descriptor_metadata: {}, kwargs: {A: %mul_4, B: %arg12_1, C: %empty_2, Bs: %arg13_1, M: 4, N: 1024, K: 2048, stride_am: 2048, stride_ak: 1, stride_bk: 1, stride_bn: 2048, stride_cm: 1024, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 16, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   return %buf2,%buf4,%buf7,%buf10
triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_1 = async_compile.triton('triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 4, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'out_ptr1': '*bf16', 'out_ptr2': '*bf16', 'out_ptr3': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 2, 'num_store': 3, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 16, 'r0_': 102400}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_1(in_ptr0, in_ptr1, in_ptr2, out_ptr1, out_ptr2, out_ptr3, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 4
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), None, eviction_policy='evict_last')
    _tmp6 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tl.device_assert((0 <= tmp0) & (tmp0 < 151936), "index out of bounds: 0 <= tmp0 < 151936")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 2048*tmp0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp3 * tmp3
        tmp5 = tl.broadcast_to(tmp4, [R0_BLOCK])
        tmp7 = _tmp6 + tmp5
        _tmp6 = tl.where(r0_mask, tmp7, _tmp6)
    tmp6 = triton_helpers.promote_to_tensor(tl.sum(_tmp6, 0))
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp8 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp0) & (tmp0 < 151936), "index out of bounds: 0 <= tmp0 < 151936")
        tmp10 = tl.load(in_ptr1 + (r0_1 + 2048*tmp0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp11 = tmp10.to(tl.float32)
        tmp12 = tl.full([1], 2048.0, tl.float32)
        tmp13 = (tmp6 / tmp12)
        tmp14 = tl.full([1], 1e-06, tl.float32)
        tmp15 = tmp13 + tmp14
        tmp16 = libdevice.rsqrt(tmp15)
        tmp17 = tmp11 * tmp16
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tmp8 * tmp18
        tl.store(out_ptr1 + (r0_1 + 2048*x0), tmp19, r0_mask)
        tl.store(out_ptr2 + (r0_1 + 2048*x0), tmp19, r0_mask)
        tl.store(out_ptr3 + (r0_1 + 2048*x0), tmp19, r0_mask)
''', device_str='tnca')


# Original path: /home/zzhouch/r41s2_fp8_inputs/hf/hub/kernels--kernels-community--finegrained-fp8/snapshots/0e5764aa5c27d0f005117a92645156481540950a/build/torch-cuda/matmul.py:96
w8a8_block_dynamic_fp8_matmul_kernel_0 = async_compile.triton('w8a8_block_dynamic_fp8_matmul_kernel', '''

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 2, 'num_stages': 2}, {'num_warps': 2, 'num_stages': 3}, {'num_warps': 2, 'num_stages': 4}, {'num_warps': 4, 'num_stages': 2}, {'num_warps': 4, 'num_stages': 3}, {'num_warps': 4, 'num_stages': 4}, {'num_warps': 8, 'num_stages': 2}, {'num_warps': 8, 'num_stages': 3}, {'num_warps': 8, 'num_stages': 4}, {'num_warps': 16, 'num_stages': 2}, {'num_warps': 16, 'num_stages': 3}, {'num_warps': 16, 'num_stages': 4}],
    inductor_meta={'grid_type': 'PrecomputedGrid', 'precomputed_grids': [{'config': {'num_warps': 2, 'num_stages': 2}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 2, 'num_stages': 3}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 2, 'num_stages': 4}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 4, 'num_stages': 2}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 4, 'num_stages': 3}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 4, 'num_stages': 4}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 8, 'num_stages': 2}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 8, 'num_stages': 3}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 8, 'num_stages': 4}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 16, 'num_stages': 2}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 16, 'num_stages': 3}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 16, 'num_stages': 4}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}], 'extra_launcher_args': [], 'declared_constexpr_names': ['BLOCK_SIZE_M', 'BLOCK_SIZE_N', 'BLOCK_SIZE_K', 'GROUP_SIZE_M'], 'kernel_name': 'w8a8_block_dynamic_fp8_matmul_kernel_0', 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    triton_meta={'signature': {'A': '*bf16', 'B': '*fp8e4nv', 'C': '*bf16', 'Bs': '*fp32', 'M': 'i32', 'N': 'i32', 'K': 'i32', 'stride_am': 'i32', 'stride_ak': 'constexpr', 'stride_bk': 'constexpr', 'stride_bn': 'i32', 'stride_cm': 'i32', 'stride_cn': 'constexpr', 'stride_bs_k': 'constexpr', 'stride_bs_n': 'i32', 'BLOCK_SIZE_M': 'constexpr', 'BLOCK_SIZE_N': 'constexpr', 'BLOCK_SIZE_K': 'constexpr', 'GROUP_SIZE_M': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'stride_ak': 1, 'stride_bk': 1, 'stride_cn': 1, 'stride_bs_k': 1, 'BLOCK_SIZE_M': 16, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'GROUP_SIZE_M': 8}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (10,): [['tt.divisibility', 16]], (11,): [['tt.divisibility', 16]], (14,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def w8a8_block_dynamic_fp8_matmul_kernel(
    A,  # (M, K) raw BF16/FP16 activations
    B,  # (N, K) FP8 weights
    C,  # (M, N) output
    Bs,  # (N // BLOCK_SIZE_N, K // BLOCK_SIZE_K) weight scales (fp32 or uint8/UE8M0)
    # Shape
    M,
    N,
    K,
    # Strides
    stride_am,
    stride_ak,
    stride_bk,
    stride_bn,
    stride_cm,
    stride_cn,
    stride_bs_k,
    stride_bs_n,
    # Meta-parameters
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """Block-scale FP8 GEMM kernel with fused activation quantization.

    Computes ``C = A @ B.T`` with bf16/fp16 ``A`` quantized to FP8 per-K-tile
    inline (one scale per M-row per BLOCK_SIZE_K) and pre-quantized FP8 weights
    with per-block scales. 2D grid with swizzle for L2 cache locality on B.
    """
    pid_m, pid_n, offs_am, offs_bn, offs_k = _swizzle_offsets(
        M, N, BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M
    )
    a_ptrs = A + (offs_am[:, None] * stride_am + offs_k[None, :] * stride_ak)
    b_ptrs = B + (offs_k[:, None] * stride_bk + offs_bn[None, :] * stride_bn)

    offs_bsn = offs_bn // BLOCK_SIZE_N
    bs_ptrs = Bs + offs_bsn * stride_bs_n

    accumulator = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    for k in range(0, tl.cdiv(K, BLOCK_SIZE_K)):
        k_remaining = K - k * BLOCK_SIZE_K
        a_raw = tl.load(a_ptrs, mask=offs_k[None, :] < k_remaining, other=0.0).to(
            tl.float32
        )
        a, a_s = fp8_act_quant_inline(a_raw)
        b = tl.load(b_ptrs, mask=offs_k[:, None] < k_remaining, other=0.0)
        b_s = decode_ue8m0_scale(tl.load(bs_ptrs))
        accumulator += tl.dot(a, b) * a_s[:, None] * b_s[None, :]
        a_ptrs += BLOCK_SIZE_K * stride_ak
        b_ptrs += BLOCK_SIZE_K * stride_bk
        bs_ptrs += stride_bs_k

    _store_masked(
        C,
        accumulator,
        pid_m,
        pid_n,
        M,
        N,
        stride_cm,
        stride_cn,
        BLOCK_SIZE_M,
        BLOCK_SIZE_N,
    )

@triton.jit
def _swizzle_offsets(
    M,
    N,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """2D-grid tile scheduling shared by the kernels below: swizzle the
    ``(pid_m, pid_n)`` program ids for L2 locality on B, then build the operand
    offset vectors. Returns ``(pid_m, pid_n, offs_am, offs_bn, offs_k)`` — the
    swizzled ids (reused by the output store) and the ``%``-wrapped row/col offsets
    plus the K range."""
    pid_m = tl.program_id(axis=0)
    pid_n = tl.program_id(axis=1)
    num_pid_m = tl.cdiv(M, BLOCK_SIZE_M)
    num_pid_n = tl.cdiv(N, BLOCK_SIZE_N)
    pid_m, pid_n = tl.swizzle2d(pid_m, pid_n, num_pid_m, num_pid_n, GROUP_SIZE_M)
    offs_am = (pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)) % M
    offs_bn = (pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)) % N
    offs_k = tl.arange(0, BLOCK_SIZE_K)
    return pid_m, pid_n, offs_am, offs_bn, offs_k

@triton.jit
def fp8_act_quant_inline(a_raw):
    """Inline FP8 (E4M3) activation quant for the W8A8 block-scale path.

    Per-row amax → fp32 scale ``amax/448`` (floored at 1e-12 against zero rows)
    → cast values to FP8. Returns ``(a_fp8, a_s)`` with shapes ``(M, K)`` and
    ``(M,)``.
    """
    a_s = tl.max(tl.abs(a_raw), axis=1) / 448.0
    a_fp8 = (a_raw / tl.maximum(a_s[:, None], 1e-12)).to(tl.float8e4nv)
    return a_fp8, a_s

@triton.jit
def decode_ue8m0_scale(scale):
    """Decode a UE8M0 weight scale to fp32: when it was loaded as ``uint8`` exponent
    bits, ``value = 2^(exp - 127)``, built directly as the fp32 bit pattern. fp32
    scales (block-dynamic with float scales) pass through. The dtype branch is a
    compile-time constant, so only the taken path is emitted (single return — Triton
    requires all ``return`` statements to share a type)."""
    if scale.dtype == tl.uint8:
        scale = (scale.to(tl.int32) << 23).to(tl.float32, bitcast=True)
    return scale

@triton.jit
def _store_masked(
    C,
    accumulator,
    pid_m,
    pid_n,
    M,
    N,
    stride_cm,
    stride_cn,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
):
    """Shared output epilogue of the kernels below: cast the fp32 accumulator to
    ``C``'s dtype and store the ``(BLOCK_SIZE_M, BLOCK_SIZE_N)`` tile at the swizzled
    ``(pid_m, pid_n)``, masked to the ``(M, N)`` bounds."""
    c = accumulator.to(C.dtype.element_ty)
    offs_cm = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_cn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    c_ptrs = C + stride_cm * offs_cm[:, None] + stride_cn * offs_cn[None, :]
    c_mask = (offs_cm[:, None] < M) & (offs_cn[None, :] < N)
    tl.store(c_ptrs, c, mask=c_mask)
''', device_str='tnca')


# Original path: /home/zzhouch/r41s2_fp8_inputs/hf/hub/kernels--kernels-community--finegrained-fp8/snapshots/0e5764aa5c27d0f005117a92645156481540950a/build/torch-cuda/matmul.py:96
w8a8_block_dynamic_fp8_matmul_kernel_1 = async_compile.triton('w8a8_block_dynamic_fp8_matmul_kernel', '''

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 2, 'num_stages': 2}, {'num_warps': 2, 'num_stages': 3}, {'num_warps': 2, 'num_stages': 4}, {'num_warps': 4, 'num_stages': 2}, {'num_warps': 4, 'num_stages': 3}, {'num_warps': 4, 'num_stages': 4}, {'num_warps': 8, 'num_stages': 2}, {'num_warps': 8, 'num_stages': 3}, {'num_warps': 8, 'num_stages': 4}, {'num_warps': 16, 'num_stages': 2}, {'num_warps': 16, 'num_stages': 3}, {'num_warps': 16, 'num_stages': 4}],
    inductor_meta={'grid_type': 'PrecomputedGrid', 'precomputed_grids': [{'config': {'num_warps': 2, 'num_stages': 2}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 2, 'num_stages': 3}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 2, 'num_stages': 4}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 4, 'num_stages': 2}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 4, 'num_stages': 3}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 4, 'num_stages': 4}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 8, 'num_stages': 2}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 8, 'num_stages': 3}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 8, 'num_stages': 4}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 16, 'num_stages': 2}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 16, 'num_stages': 3}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 16, 'num_stages': 4}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}], 'extra_launcher_args': [], 'declared_constexpr_names': ['BLOCK_SIZE_M', 'BLOCK_SIZE_N', 'BLOCK_SIZE_K', 'GROUP_SIZE_M'], 'kernel_name': 'w8a8_block_dynamic_fp8_matmul_kernel_1', 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    triton_meta={'signature': {'A': '*bf16', 'B': '*fp8e4nv', 'C': '*bf16', 'Bs': '*fp32', 'M': 'i32', 'N': 'i32', 'K': 'i32', 'stride_am': 'i32', 'stride_ak': 'constexpr', 'stride_bk': 'constexpr', 'stride_bn': 'i32', 'stride_cm': 'i32', 'stride_cn': 'constexpr', 'stride_bs_k': 'constexpr', 'stride_bs_n': 'i32', 'BLOCK_SIZE_M': 'constexpr', 'BLOCK_SIZE_N': 'constexpr', 'BLOCK_SIZE_K': 'constexpr', 'GROUP_SIZE_M': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'stride_ak': 1, 'stride_bk': 1, 'stride_cn': 1, 'stride_bs_k': 1, 'BLOCK_SIZE_M': 16, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'GROUP_SIZE_M': 8}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (10,): [['tt.divisibility', 16]], (11,): [['tt.divisibility', 16]], (14,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def w8a8_block_dynamic_fp8_matmul_kernel(
    A,  # (M, K) raw BF16/FP16 activations
    B,  # (N, K) FP8 weights
    C,  # (M, N) output
    Bs,  # (N // BLOCK_SIZE_N, K // BLOCK_SIZE_K) weight scales (fp32 or uint8/UE8M0)
    # Shape
    M,
    N,
    K,
    # Strides
    stride_am,
    stride_ak,
    stride_bk,
    stride_bn,
    stride_cm,
    stride_cn,
    stride_bs_k,
    stride_bs_n,
    # Meta-parameters
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """Block-scale FP8 GEMM kernel with fused activation quantization.

    Computes ``C = A @ B.T`` with bf16/fp16 ``A`` quantized to FP8 per-K-tile
    inline (one scale per M-row per BLOCK_SIZE_K) and pre-quantized FP8 weights
    with per-block scales. 2D grid with swizzle for L2 cache locality on B.
    """
    pid_m, pid_n, offs_am, offs_bn, offs_k = _swizzle_offsets(
        M, N, BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M
    )
    a_ptrs = A + (offs_am[:, None] * stride_am + offs_k[None, :] * stride_ak)
    b_ptrs = B + (offs_k[:, None] * stride_bk + offs_bn[None, :] * stride_bn)

    offs_bsn = offs_bn // BLOCK_SIZE_N
    bs_ptrs = Bs + offs_bsn * stride_bs_n

    accumulator = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    for k in range(0, tl.cdiv(K, BLOCK_SIZE_K)):
        k_remaining = K - k * BLOCK_SIZE_K
        a_raw = tl.load(a_ptrs, mask=offs_k[None, :] < k_remaining, other=0.0).to(
            tl.float32
        )
        a, a_s = fp8_act_quant_inline(a_raw)
        b = tl.load(b_ptrs, mask=offs_k[:, None] < k_remaining, other=0.0)
        b_s = decode_ue8m0_scale(tl.load(bs_ptrs))
        accumulator += tl.dot(a, b) * a_s[:, None] * b_s[None, :]
        a_ptrs += BLOCK_SIZE_K * stride_ak
        b_ptrs += BLOCK_SIZE_K * stride_bk
        bs_ptrs += stride_bs_k

    _store_masked(
        C,
        accumulator,
        pid_m,
        pid_n,
        M,
        N,
        stride_cm,
        stride_cn,
        BLOCK_SIZE_M,
        BLOCK_SIZE_N,
    )

@triton.jit
def _swizzle_offsets(
    M,
    N,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """2D-grid tile scheduling shared by the kernels below: swizzle the
    ``(pid_m, pid_n)`` program ids for L2 locality on B, then build the operand
    offset vectors. Returns ``(pid_m, pid_n, offs_am, offs_bn, offs_k)`` — the
    swizzled ids (reused by the output store) and the ``%``-wrapped row/col offsets
    plus the K range."""
    pid_m = tl.program_id(axis=0)
    pid_n = tl.program_id(axis=1)
    num_pid_m = tl.cdiv(M, BLOCK_SIZE_M)
    num_pid_n = tl.cdiv(N, BLOCK_SIZE_N)
    pid_m, pid_n = tl.swizzle2d(pid_m, pid_n, num_pid_m, num_pid_n, GROUP_SIZE_M)
    offs_am = (pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)) % M
    offs_bn = (pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)) % N
    offs_k = tl.arange(0, BLOCK_SIZE_K)
    return pid_m, pid_n, offs_am, offs_bn, offs_k

@triton.jit
def fp8_act_quant_inline(a_raw):
    """Inline FP8 (E4M3) activation quant for the W8A8 block-scale path.

    Per-row amax → fp32 scale ``amax/448`` (floored at 1e-12 against zero rows)
    → cast values to FP8. Returns ``(a_fp8, a_s)`` with shapes ``(M, K)`` and
    ``(M,)``.
    """
    a_s = tl.max(tl.abs(a_raw), axis=1) / 448.0
    a_fp8 = (a_raw / tl.maximum(a_s[:, None], 1e-12)).to(tl.float8e4nv)
    return a_fp8, a_s

@triton.jit
def decode_ue8m0_scale(scale):
    """Decode a UE8M0 weight scale to fp32: when it was loaded as ``uint8`` exponent
    bits, ``value = 2^(exp - 127)``, built directly as the fp32 bit pattern. fp32
    scales (block-dynamic with float scales) pass through. The dtype branch is a
    compile-time constant, so only the taken path is emitted (single return — Triton
    requires all ``return`` statements to share a type)."""
    if scale.dtype == tl.uint8:
        scale = (scale.to(tl.int32) << 23).to(tl.float32, bitcast=True)
    return scale

@triton.jit
def _store_masked(
    C,
    accumulator,
    pid_m,
    pid_n,
    M,
    N,
    stride_cm,
    stride_cn,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
):
    """Shared output epilogue of the kernels below: cast the fp32 accumulator to
    ``C``'s dtype and store the ``(BLOCK_SIZE_M, BLOCK_SIZE_N)`` tile at the swizzled
    ``(pid_m, pid_n)``, masked to the ``(M, N)`` bounds."""
    c = accumulator.to(C.dtype.element_ty)
    offs_cm = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_cn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    c_ptrs = C + stride_cm * offs_cm[:, None] + stride_cn * offs_cn[None, :]
    c_mask = (offs_cm[:, None] < M) & (offs_cn[None, :] < N)
    tl.store(c_ptrs, c, mask=c_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-v4-quality-20261031/caches/inductor/2f/c2fwbjbyo746fz6mjawulf3ozdyh6ul3wylffirct3eubift3mvn.py
# Topologically Sorted Source Nodes: [hidden_states_3, pow_2, variance_1], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
# Source node to ATen node mapping:
#   hidden_states_3 => convert_element_type_5, view_3
#   pow_2 => pow_2
#   variance_1 => mean_1
# Graph fragment:
#   %buf5 : Tensor  = PlaceHolder[target=buf5]
#   %view_3 : Tensor "bf16[1, 4, 16, 128][8192, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%empty, [1, 4, -1, 128]), kwargs = {})
#   %convert_element_type_5 : Tensor "f32[1, 4, 16, 128][8192, 2048, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_3, torch.float32), kwargs = {})
#   %pow_2 : Tensor "f32[1, 4, 16, 128][8192, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_5, 2), kwargs = {})
#   %mean_1 : Tensor "f32[1, 4, 16, 1][64, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_2, [-1], True), kwargs = {})
#   return %buf12
triton_red_fused__to_copy_mean_pow_view_2 = async_compile.triton('triton_red_fused__to_copy_mean_pow_view_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_mean_pow_view_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 512, 'r0_': 0}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_mean_pow_view_2(in_ptr0, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 64
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[64, 128], strides=[128, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp4 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp2 = tmp1 * tmp1
        tmp3 = tl.broadcast_to(tmp2, [R0_BLOCK])
        tmp5 = _tmp4 + tmp3
        _tmp4 = tl.where(r0_mask, tmp5, _tmp4)
    tmp4 = triton_helpers.promote_to_tensor(tl.sum(_tmp4, 0))
    tl.store(out_ptr0 + (x0), tmp4, None)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-v4-quality-20261031/caches/inductor/tm/ctmlp7zffeoqmquyhgnq3t6l4hyh2bpj6pjhgsdrktf3fjwocaus.py
# Topologically Sorted Source Nodes: [hidden_states_3, pow_2, variance_1, add_3, rsqrt_1, hidden_states_4, to_7, mul_6, query_states, x2, neg, x1, cat_2], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
# Source node to ATen node mapping:
#   add_3 => add_3
#   cat_2 => cat
#   hidden_states_3 => convert_element_type_5, view_3
#   hidden_states_4 => mul_5
#   mul_6 => mul_6
#   neg => neg
#   pow_2 => pow_2
#   query_states => permute
#   rsqrt_1 => rsqrt_1
#   to_7 => convert_element_type_6
#   variance_1 => mean_1
#   x1 => slice_18
#   x2 => slice_19
# Graph fragment:
#   %arg8_1 : Tensor "bf16[128][1]tnca:0" = PlaceHolder[target=arg8_1]
#   %buf5 : Tensor  = PlaceHolder[target=buf5]
#   %buf12 : Tensor "f32[1, 4, 16, 1][64, 16, 1, 64]tnca:0" = PlaceHolder[target=buf12]
#   %view_3 : Tensor "bf16[1, 4, 16, 128][8192, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%empty, [1, 4, -1, 128]), kwargs = {})
#   %convert_element_type_5 : Tensor "f32[1, 4, 16, 128][8192, 2048, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_3, torch.float32), kwargs = {})
#   %pow_2 : Tensor "f32[1, 4, 16, 128][8192, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_5, 2), kwargs = {})
#   %mean_1 : Tensor "f32[1, 4, 16, 1][64, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_2, [-1], True), kwargs = {})
#   %add_3 : Tensor "f32[1, 4, 16, 1][64, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_1, 1e-06), kwargs = {})
#   %rsqrt_1 : Tensor "f32[1, 4, 16, 1][64, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_3,), kwargs = {})
#   %mul_5 : Tensor "f32[1, 4, 16, 128][8192, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_5, %rsqrt_1), kwargs = {})
#   %convert_element_type_6 : Tensor "bf16[1, 4, 16, 128][8192, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_5, torch.bfloat16), kwargs = {})
#   %mul_6 : Tensor "bf16[1, 4, 16, 128][8192, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg8_1, %convert_element_type_6), kwargs = {})
#   %permute : Tensor "bf16[1, 16, 4, 128][8192, 128, 2048, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%mul_6, [0, 2, 1, 3]), kwargs = {})
#   %slice_19 : Tensor "bf16[1, 16, 4, 64][8192, 128, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute, 3, 64, 9223372036854775807), kwargs = {})
#   %neg : Tensor "bf16[1, 16, 4, 64][4096, 64, 1024, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_19,), kwargs = {})
#   %slice_18 : Tensor "bf16[1, 16, 4, 64][8192, 128, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute, 3, 0, 64), kwargs = {})
#   %cat : Tensor "bf16[1, 16, 4, 128][8192, 512, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg, %slice_18], -1), kwargs = {})
#   return %neg,%buf14
triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3 = async_compile.triton('triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 4096}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*fp32', 'out_ptr0': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 33280}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 4096
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 64)
    x3 = xindex // 64
    x1 = ((xindex // 64) % 16)
    x2 = xindex // 1024
    tmp0 = tl.load(in_ptr0 + (64 + x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tl.load(in_ptr1 + (64 + x0 + 128*x3), None).to(tl.float32)
    tmp3 = tl.load(in_ptr2 + (x3), None, eviction_policy='evict_last')
    tmp13 = tl.load(in_ptr0 + (x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp14 = tl.load(in_ptr1 + (x0 + 128*x3), None).to(tl.float32)
    tmp2 = tmp1.to(tl.float32)
    tmp4 = tl.full([1], 128.0, tl.float32)
    tmp5 = (tmp3 / tmp4)
    tmp6 = tl.full([1], 1e-06, tl.float32)
    tmp7 = tmp5 + tmp6
    tmp8 = libdevice.rsqrt(tmp7)
    tmp9 = tmp2 * tmp8
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tmp0 * tmp10
    tmp12 = -tmp11
    tmp15 = tmp14.to(tl.float32)
    tmp16 = tmp15 * tmp8
    tmp17 = tmp16.to(tl.float32)
    tmp18 = tmp13 * tmp17
    tl.store(out_ptr0 + (x0 + 128*x2 + 512*x1), tmp12, None)
    tl.store(out_ptr1 + (x0 + 128*x2 + 512*x1), tmp18, None)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-v4-quality-20261031/caches/inductor/vg/cvg4zyf4vpg7w5c7f2lz722ajnenph4hemntrkjvittxocpxuo4h.py
# Topologically Sorted Source Nodes: [hidden_states_5, pow_3, variance_2], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
# Source node to ATen node mapping:
#   hidden_states_5 => convert_element_type_7, view_5
#   pow_3 => pow_3
#   variance_2 => mean_2
# Graph fragment:
#   %buf8 : Tensor  = PlaceHolder[target=buf8]
#   %view_5 : Tensor "bf16[1, 4, 8, 128][4096, 1024, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%empty_1, [1, 4, -1, 128]), kwargs = {})
#   %convert_element_type_7 : Tensor "f32[1, 4, 8, 128][4096, 1024, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_5, torch.float32), kwargs = {})
#   %pow_3 : Tensor "f32[1, 4, 8, 128][4096, 1024, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_7, 2), kwargs = {})
#   %mean_2 : Tensor "f32[1, 4, 8, 1][32, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_3, [-1], True), kwargs = {})
#   return %buf16
triton_red_fused__to_copy_mean_pow_view_4 = async_compile.triton('triton_red_fused__to_copy_mean_pow_view_4', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 32, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_mean_pow_view_4', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 256, 'r0_': 0}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_mean_pow_view_4(in_ptr0, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 32
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[32, 128], strides=[128, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp4 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp2 = tmp1 * tmp1
        tmp3 = tl.broadcast_to(tmp2, [R0_BLOCK])
        tmp5 = _tmp4 + tmp3
        _tmp4 = tl.where(r0_mask, tmp5, _tmp4)
    tmp4 = triton_helpers.promote_to_tensor(tl.sum(_tmp4, 0))
    tl.store(out_ptr0 + (x0), tmp4, None)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-v4-quality-20261031/caches/inductor/6q/c6qh2bnchjcciglzlnfw5j5kmk5opp2s2gsur7f3voxwixkzzpyh.py
# Topologically Sorted Source Nodes: [hidden_states_5, pow_3, variance_2, add_4, rsqrt_2, hidden_states_6, to_9, mul_8, key_states, x2_1, neg_1, x1_1, cat_3], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
# Source node to ATen node mapping:
#   add_4 => add_4
#   cat_3 => cat_1
#   hidden_states_5 => convert_element_type_7, view_5
#   hidden_states_6 => mul_7
#   key_states => permute_1
#   mul_8 => mul_8
#   neg_1 => neg_1
#   pow_3 => pow_3
#   rsqrt_2 => rsqrt_2
#   to_9 => convert_element_type_8
#   variance_2 => mean_2
#   x1_1 => slice_20
#   x2_1 => slice_21
# Graph fragment:
#   %arg11_1 : Tensor "bf16[128][1]tnca:0" = PlaceHolder[target=arg11_1]
#   %buf8 : Tensor  = PlaceHolder[target=buf8]
#   %buf16 : Tensor "f32[1, 4, 8, 1][32, 8, 1, 32]tnca:0" = PlaceHolder[target=buf16]
#   %view_5 : Tensor "bf16[1, 4, 8, 128][4096, 1024, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%empty_1, [1, 4, -1, 128]), kwargs = {})
#   %convert_element_type_7 : Tensor "f32[1, 4, 8, 128][4096, 1024, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_5, torch.float32), kwargs = {})
#   %pow_3 : Tensor "f32[1, 4, 8, 128][4096, 1024, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_7, 2), kwargs = {})
#   %mean_2 : Tensor "f32[1, 4, 8, 1][32, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_3, [-1], True), kwargs = {})
#   %add_4 : Tensor "f32[1, 4, 8, 1][32, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_2, 1e-06), kwargs = {})
#   %rsqrt_2 : Tensor "f32[1, 4, 8, 1][32, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_4,), kwargs = {})
#   %mul_7 : Tensor "f32[1, 4, 8, 128][4096, 1024, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_7, %rsqrt_2), kwargs = {})
#   %convert_element_type_8 : Tensor "bf16[1, 4, 8, 128][4096, 1024, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_7, torch.bfloat16), kwargs = {})
#   %mul_8 : Tensor "bf16[1, 4, 8, 128][4096, 1024, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg11_1, %convert_element_type_8), kwargs = {})
#   %permute_1 : Tensor "bf16[1, 8, 4, 128][4096, 128, 1024, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%mul_8, [0, 2, 1, 3]), kwargs = {})
#   %slice_21 : Tensor "bf16[1, 8, 4, 64][4096, 128, 1024, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_1, 3, 64, 9223372036854775807), kwargs = {})
#   %neg_1 : Tensor "bf16[1, 8, 4, 64][2048, 64, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_21,), kwargs = {})
#   %slice_20 : Tensor "bf16[1, 8, 4, 64][4096, 128, 1024, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_1, 3, 0, 64), kwargs = {})
#   %cat_1 : Tensor "bf16[1, 8, 4, 128][4096, 512, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg_1, %slice_20], -1), kwargs = {})
#   return %neg_1,%buf18
triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5 = async_compile.triton('triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 2048}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*fp32', 'out_ptr0': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 16768}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 2048
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 64)
    x3 = xindex // 64
    x1 = ((xindex // 64) % 8)
    x2 = xindex // 512
    tmp0 = tl.load(in_ptr0 + (64 + x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tl.load(in_ptr1 + (64 + x0 + 128*x3), xmask).to(tl.float32)
    tmp3 = tl.load(in_ptr2 + (x3), xmask, eviction_policy='evict_last')
    tmp13 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp14 = tl.load(in_ptr1 + (x0 + 128*x3), xmask).to(tl.float32)
    tmp2 = tmp1.to(tl.float32)
    tmp4 = tl.full([1], 128.0, tl.float32)
    tmp5 = (tmp3 / tmp4)
    tmp6 = tl.full([1], 1e-06, tl.float32)
    tmp7 = tmp5 + tmp6
    tmp8 = libdevice.rsqrt(tmp7)
    tmp9 = tmp2 * tmp8
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tmp0 * tmp10
    tmp12 = -tmp11
    tmp15 = tmp14.to(tl.float32)
    tmp16 = tmp15 * tmp8
    tmp17 = tmp16.to(tl.float32)
    tmp18 = tmp13 * tmp17
    tl.store(out_ptr0 + (x0 + 128*x2 + 512*x1), tmp12, xmask)
    tl.store(out_ptr1 + (x0 + 128*x2 + 512*x1), tmp18, xmask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-v4-quality-20261031/caches/inductor/yx/cyxsou6ftzr534bdfxl5kxildvxyzh5eml44ug72okashvz3fzqi.py
# Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, cos_4, setitem_1, sin_2, sin_3, sin_4, arange_4, cache_position, hidden_states_5, pow_3, variance_2, add_4, rsqrt_2, hidden_states_6, to_9, mul_8, key_states, mul_11, mul_12, k_embed, index_copy_], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
# Source node to ATen node mapping:
#   add_4 => add_4
#   arange_4 => iota_4
#   cache_position => add_7
#   cos_2 => clone_2, expand_3, select_23, unsqueeze_8, view_1
#   cos_3 => convert_element_type_1
#   cos_4 => unsqueeze_9
#   hidden_states_5 => convert_element_type_7, view_5
#   hidden_states_6 => mul_7
#   index_copy_ => index_put
#   k_embed => add_6
#   key_states => permute_1
#   mul_11 => mul_11
#   mul_12 => mul_12
#   mul_8 => mul_8
#   pow_3 => pow_3
#   rsqrt_2 => rsqrt_2
#   setitem_1 => select_8, slice_8
#   setitem_3 => select_20, slice_16
#   sin_2 => clone, expand_2, select_11, unsqueeze_7, view
#   sin_3 => convert_element_type_2
#   sin_4 => unsqueeze_10
#   to_9 => convert_element_type_8
#   variance_2 => mean_2
# Graph fragment:
#   %copy_ : Tensor "i64[][]tnca:0" = PlaceHolder[target=copy_]
#   %arg11_1 : Tensor "bf16[128][1]tnca:0" = PlaceHolder[target=arg11_1]
#   %buf8 : Tensor  = PlaceHolder[target=buf8]
#   %buf16 : Tensor "f32[1, 4, 8, 1][32, 8, 1, 32]tnca:0" = PlaceHolder[target=buf16]
#   %select_scatter_default_1 : Tensor "f32[3, 1, 4, 64][256, 768, 64, 1]tnca:0" = PlaceHolder[target=select_scatter_default_1]
#   %cat_1 : Tensor "bf16[1, 8, 4, 128][4096, 512, 128, 1]tnca:0" = PlaceHolder[target=cat_1]
#   %select_scatter_default : Tensor "f32[3, 1, 4, 64][256, 768, 64, 1]tnca:0" = PlaceHolder[target=select_scatter_default]
#   %index_put : Tensor "bf16[1, 8, 256, 128][262144, 32768, 128, 1]tnca:0" = PlaceHolder[target=index_put]
#   %select_20 : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 2), kwargs = {})
#   %slice_16 : Tensor "f32[1, 4, 20][256, 64, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_20, 2, 2, 60, 3), kwargs = {})
#   %select_int_2 : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 0), kwargs = {})
#   %slice_scatter_default_2 : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_2, %slice_16, 2, 2, 60, 3), kwargs = {})
#   %select_scatter_default_2 : Tensor "f32[3, 1, 4, 64][256, 256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default_1, %slice_scatter_default_2, 0, 0), kwargs = {})
#   %select_23 : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_2, 0, 0), kwargs = {})
#   %unsqueeze_8 : Tensor "f32[1, 4, 1, 64][256, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_23, 2), kwargs = {})
#   %expand_3 : Tensor "f32[1, 4, 2, 64][256, 64, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_8, [1, 4, 2, 64]), kwargs = {})
#   %clone_2 : Tensor "f32[1, 4, 2, 64][512, 128, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_1 : Tensor "f32[1, 4, 128][512, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_2, [1, 4, 128]), kwargs = {})
#   %convert_element_type_1 : Tensor "bf16[1, 4, 128][512, 128, 1]tnca:0"[num_users=28] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_1, torch.bfloat16), kwargs = {})
#   %unsqueeze_9 : Tensor "bf16[1, 1, 4, 128][512, 512, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_1, 1), kwargs = {})
#   %select_8 : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 2), kwargs = {})
#   %slice_8 : Tensor "f32[1, 4, 20][256, 64, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_8, 2, 2, 60, 3), kwargs = {})
#   %select_int_3 : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 0), kwargs = {})
#   %slice_scatter_default_3 : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_3, %slice_8, 2, 2, 60, 3), kwargs = {})
#   %select_scatter_default_3 : Tensor "f32[3, 1, 4, 64][256, 256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default, %slice_scatter_default_3, 0, 0), kwargs = {})
#   %select_11 : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_3, 0, 0), kwargs = {})
#   %unsqueeze_7 : Tensor "f32[1, 4, 1, 64][256, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_11, 2), kwargs = {})
#   %expand_2 : Tensor "f32[1, 4, 2, 64][256, 64, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_7, [1, 4, 2, 64]), kwargs = {})
#   %clone : Tensor "f32[1, 4, 2, 64][512, 128, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_2,), kwargs = {memory_format: torch.contiguous_format})
#   %view : Tensor "f32[1, 4, 128][512, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 4, 128]), kwargs = {})
#   %convert_element_type_2 : Tensor "bf16[1, 4, 128][512, 128, 1]tnca:0"[num_users=28] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view, torch.bfloat16), kwargs = {})
#   %unsqueeze_10 : Tensor "bf16[1, 1, 4, 128][512, 512, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_2, 1), kwargs = {})
#   %iota_4 : Tensor "i64[4][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (4,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %add_7 : Tensor "i64[4][1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%iota_4, %arg3_1), kwargs = {})
#   %view_5 : Tensor "bf16[1, 4, 8, 128][4096, 1024, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%empty_1, [1, 4, -1, 128]), kwargs = {})
#   %convert_element_type_7 : Tensor "f32[1, 4, 8, 128][4096, 1024, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_5, torch.float32), kwargs = {})
#   %pow_3 : Tensor "f32[1, 4, 8, 128][4096, 1024, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_7, 2), kwargs = {})
#   %mean_2 : Tensor "f32[1, 4, 8, 1][32, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_3, [-1], True), kwargs = {})
#   %add_4 : Tensor "f32[1, 4, 8, 1][32, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_2, 1e-06), kwargs = {})
#   %rsqrt_2 : Tensor "f32[1, 4, 8, 1][32, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_4,), kwargs = {})
#   %mul_7 : Tensor "f32[1, 4, 8, 128][4096, 1024, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_7, %rsqrt_2), kwargs = {})
#   %convert_element_type_8 : Tensor "bf16[1, 4, 8, 128][4096, 1024, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_7, torch.bfloat16), kwargs = {})
#   %mul_8 : Tensor "bf16[1, 4, 8, 128][4096, 1024, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg11_1, %convert_element_type_8), kwargs = {})
#   %permute_1 : Tensor "bf16[1, 8, 4, 128][4096, 128, 1024, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%mul_8, [0, 2, 1, 3]), kwargs = {})
#   %mul_11 : Tensor "bf16[1, 8, 4, 128][4096, 128, 1024, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_1, %unsqueeze_9), kwargs = {})
#   %mul_12 : Tensor "bf16[1, 8, 4, 128][4096, 512, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_1, %unsqueeze_10), kwargs = {})
#   %add_6 : Tensor "bf16[1, 8, 4, 128][4096, 128, 1024, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_11, %mul_12), kwargs = {})
#   %index_put : Tensor "bf16[1, 8, 256, 128][262144, 32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.index_put_.default](args = (%arg14_1, [None, None, %add_7], %add_6), kwargs = {})
#   return %buf20
triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6 = async_compile.triton('triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 4096}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': '*bf16', 'in_ptr6': '*fp32', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6', 'mutated_arg_names': ['out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 9, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 16768}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 4096
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x2 = xindex // 1024
    x0 = (xindex % 128)
    x3 = xindex
    x4 = xindex // 128
    x1 = ((xindex // 128) % 8)
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK])
    tmp9 = tl.load(in_ptr1 + (x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp10 = tl.load(in_ptr2 + (x3), None).to(tl.float32)
    tmp12 = tl.load(in_ptr3 + (x4), None, eviction_policy='evict_last')
    tmp36 = tl.load(in_ptr4 + (64*x2 + ((x0 % 64))), None, eviction_policy='evict_last')
    tmp41 = tl.load(in_ptr5 + (x0 + 128*x2 + 512*x1), None).to(tl.float32)
    tmp43 = tl.load(in_ptr6 + (64*x2 + ((x0 % 64))), None, eviction_policy='evict_last')
    tmp2 = (x2).to(tl.int32)
    tmp3 = tmp2 + tmp1
    tmp4 = (tl.full([XBLOCK], 256, tl.int32)).to(tl.int32)
    tmp5 = tmp3 + tmp4
    tmp6 = tmp3 < 0
    tmp7 = tl.where(tmp6, tmp5, tmp3)
    tl.device_assert((0 <= tmp7) & (tmp7 < 256), "index out of bounds: 0 <= tmp7 < 256")
    tmp11 = tmp10.to(tl.float32)
    tmp13 = tl.full([1], 128.0, tl.float32)
    tmp14 = (tmp12 / tmp13)
    tmp15 = tl.full([1], 1e-06, tl.float32)
    tmp16 = tmp14 + tmp15
    tmp17 = libdevice.rsqrt(tmp16)
    tmp18 = tmp11 * tmp17
    tmp19 = tmp18.to(tl.float32)
    tmp20 = tmp9 * tmp19
    tmp21 = tl.full([1], 0, tl.int32)
    tmp22 = tmp21 == tmp21
    tmp23 = ((x3 % 64)).to(tl.int64)
    tmp24 = (tmp23).to(tl.int64)
    tmp25 = tl.full([1], 2, tl.int64)
    tmp26 = tmp24 >= tmp25
    tmp27 = tl.full([1], 60, tl.int64)
    tmp28 = tmp24 < tmp27
    tmp29 = ((((-2) + ((x0 % 64))) % 3)).to(tl.int64)
    tmp30 = (tmp29).to(tl.int64)
    tmp31 = tl.full([1], 0, tl.int64)
    tmp32 = tmp30 == tmp31
    tmp33 = tmp26 & tmp28
    tmp34 = tmp33 & tmp32
    tmp35 = tl.load(in_ptr4 + (514 + 3*(triton_helpers.div_floor_integer((-2) + ((x0 % 64)),  3)) + 64*x2), tmp34, eviction_policy='evict_last', other=0.0)
    tmp37 = tl.where(tmp34, tmp35, tmp36)
    tmp38 = tl.where(tmp22, tmp37, tmp36)
    tmp39 = tmp38.to(tl.float32)
    tmp40 = tmp20 * tmp39
    tmp42 = tl.load(in_ptr6 + (514 + 3*(triton_helpers.div_floor_integer((-2) + ((x0 % 64)),  3)) + 64*x2), tmp34, eviction_policy='evict_last', other=0.0)
    tmp44 = tl.where(tmp34, tmp42, tmp43)
    tmp45 = tl.where(tmp22, tmp44, tmp43)
    tmp46 = tmp45.to(tl.float32)
    tmp47 = tmp41 * tmp46
    tmp48 = tmp40 + tmp47
    tl.store(out_ptr0 + (x0 + 128*tmp7 + 32768*x1), tmp48, None)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-v4-quality-20261031/caches/inductor/d4/cd4eclqv7ecdc6uktzpm2l2xfdvzbup3akftszecv7uunnicvmx4.py
# Topologically Sorted Source Nodes: [hidden_states_3, pow_2, variance_1, add_3, rsqrt_1, hidden_states_4, to_7, mul_6, query_states, setitem_3, cos_2, cos_3, cos_4, mul_9, setitem_1, sin_2, sin_3, sin_4, mul_10, q_embed, attn_output], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.select, aten.slice, aten.cat, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   add_3 => add_3
#   attn_output => convert_element_type_9, mul_13
#   cos_2 => clone_2, expand_3, select_23, unsqueeze_8, view_1
#   cos_3 => convert_element_type_1
#   cos_4 => unsqueeze_9
#   hidden_states_3 => convert_element_type_5, view_3
#   hidden_states_4 => mul_5
#   mul_10 => mul_10
#   mul_6 => mul_6
#   mul_9 => mul_9
#   pow_2 => pow_2
#   q_embed => add_5
#   query_states => permute
#   rsqrt_1 => rsqrt_1
#   setitem_1 => select_8, slice_8
#   setitem_3 => select_20, slice_16
#   sin_2 => clone, expand_2, select_11, unsqueeze_7, view
#   sin_3 => convert_element_type_2
#   sin_4 => unsqueeze_10
#   to_7 => convert_element_type_6
#   variance_1 => mean_1
# Graph fragment:
#   %arg8_1 : Tensor "bf16[128][1]tnca:0" = PlaceHolder[target=arg8_1]
#   %buf5 : Tensor  = PlaceHolder[target=buf5]
#   %buf12 : Tensor "f32[1, 4, 16, 1][64, 16, 1, 64]tnca:0" = PlaceHolder[target=buf12]
#   %select_scatter_default_1 : Tensor "f32[3, 1, 4, 64][256, 768, 64, 1]tnca:0" = PlaceHolder[target=select_scatter_default_1]
#   %cat : Tensor "bf16[1, 16, 4, 128][8192, 512, 128, 1]tnca:0" = PlaceHolder[target=cat]
#   %select_scatter_default : Tensor "f32[3, 1, 4, 64][256, 768, 64, 1]tnca:0" = PlaceHolder[target=select_scatter_default]
#   %view_3 : Tensor "bf16[1, 4, 16, 128][8192, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%empty, [1, 4, -1, 128]), kwargs = {})
#   %convert_element_type_5 : Tensor "f32[1, 4, 16, 128][8192, 2048, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_3, torch.float32), kwargs = {})
#   %pow_2 : Tensor "f32[1, 4, 16, 128][8192, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_5, 2), kwargs = {})
#   %mean_1 : Tensor "f32[1, 4, 16, 1][64, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_2, [-1], True), kwargs = {})
#   %add_3 : Tensor "f32[1, 4, 16, 1][64, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_1, 1e-06), kwargs = {})
#   %rsqrt_1 : Tensor "f32[1, 4, 16, 1][64, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_3,), kwargs = {})
#   %mul_5 : Tensor "f32[1, 4, 16, 128][8192, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_5, %rsqrt_1), kwargs = {})
#   %convert_element_type_6 : Tensor "bf16[1, 4, 16, 128][8192, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_5, torch.bfloat16), kwargs = {})
#   %mul_6 : Tensor "bf16[1, 4, 16, 128][8192, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg8_1, %convert_element_type_6), kwargs = {})
#   %permute : Tensor "bf16[1, 16, 4, 128][8192, 128, 2048, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%mul_6, [0, 2, 1, 3]), kwargs = {})
#   %select_20 : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 2), kwargs = {})
#   %slice_16 : Tensor "f32[1, 4, 20][256, 64, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_20, 2, 2, 60, 3), kwargs = {})
#   %select_int_2 : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 0), kwargs = {})
#   %slice_scatter_default_2 : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_2, %slice_16, 2, 2, 60, 3), kwargs = {})
#   %select_scatter_default_2 : Tensor "f32[3, 1, 4, 64][256, 256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default_1, %slice_scatter_default_2, 0, 0), kwargs = {})
#   %select_23 : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_2, 0, 0), kwargs = {})
#   %unsqueeze_8 : Tensor "f32[1, 4, 1, 64][256, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_23, 2), kwargs = {})
#   %expand_3 : Tensor "f32[1, 4, 2, 64][256, 64, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_8, [1, 4, 2, 64]), kwargs = {})
#   %clone_2 : Tensor "f32[1, 4, 2, 64][512, 128, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_1 : Tensor "f32[1, 4, 128][512, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_2, [1, 4, 128]), kwargs = {})
#   %convert_element_type_1 : Tensor "bf16[1, 4, 128][512, 128, 1]tnca:0"[num_users=28] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_1, torch.bfloat16), kwargs = {})
#   %unsqueeze_9 : Tensor "bf16[1, 1, 4, 128][512, 512, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_1, 1), kwargs = {})
#   %mul_9 : Tensor "bf16[1, 16, 4, 128][8192, 128, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute, %unsqueeze_9), kwargs = {})
#   %select_8 : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 2), kwargs = {})
#   %slice_8 : Tensor "f32[1, 4, 20][256, 64, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_8, 2, 2, 60, 3), kwargs = {})
#   %select_int_3 : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 0), kwargs = {})
#   %slice_scatter_default_3 : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_3, %slice_8, 2, 2, 60, 3), kwargs = {})
#   %select_scatter_default_3 : Tensor "f32[3, 1, 4, 64][256, 256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default, %slice_scatter_default_3, 0, 0), kwargs = {})
#   %select_11 : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_3, 0, 0), kwargs = {})
#   %unsqueeze_7 : Tensor "f32[1, 4, 1, 64][256, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_11, 2), kwargs = {})
#   %expand_2 : Tensor "f32[1, 4, 2, 64][256, 64, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_7, [1, 4, 2, 64]), kwargs = {})
#   %clone : Tensor "f32[1, 4, 2, 64][512, 128, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_2,), kwargs = {memory_format: torch.contiguous_format})
#   %view : Tensor "f32[1, 4, 128][512, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 4, 128]), kwargs = {})
#   %convert_element_type_2 : Tensor "bf16[1, 4, 128][512, 128, 1]tnca:0"[num_users=28] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view, torch.bfloat16), kwargs = {})
#   %unsqueeze_10 : Tensor "bf16[1, 1, 4, 128][512, 512, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_2, 1), kwargs = {})
#   %mul_10 : Tensor "bf16[1, 16, 4, 128][8192, 512, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat, %unsqueeze_10), kwargs = {})
#   %add_5 : Tensor "bf16[1, 16, 4, 128][8192, 128, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_9, %mul_10), kwargs = {})
#   %convert_element_type_9 : Tensor "f32[1, 16, 4, 128][8192, 128, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_5, torch.float32), kwargs = {})
#   %mul_13 : Tensor "f32[1, 16, 4, 128][8192, 128, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%convert_element_type_9, 0.29730177875068026), kwargs = {})
#   return %expand_8
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 8192}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*bf16', 'in_ptr5': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 90624}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 8192
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 128)
    x1 = ((xindex // 128) % 4)
    x2 = xindex // 512
    x4 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tl.load(in_ptr1 + (x0 + 128*x2 + 2048*x1), None).to(tl.float32)
    tmp3 = tl.load(in_ptr2 + (x2 + 16*x1), None, eviction_policy='evict_last')
    tmp27 = tl.load(in_ptr3 + (64*x1 + ((x0 % 64))), None, eviction_policy='evict_last')
    tmp32 = tl.load(in_ptr4 + (x4), None).to(tl.float32)
    tmp34 = tl.load(in_ptr5 + (64*x1 + ((x0 % 64))), None, eviction_policy='evict_last')
    tmp2 = tmp1.to(tl.float32)
    tmp4 = tl.full([1], 128.0, tl.float32)
    tmp5 = (tmp3 / tmp4)
    tmp6 = tl.full([1], 1e-06, tl.float32)
    tmp7 = tmp5 + tmp6
    tmp8 = libdevice.rsqrt(tmp7)
    tmp9 = tmp2 * tmp8
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tmp0 * tmp10
    tmp12 = tl.full([1], 0, tl.int32)
    tmp13 = tmp12 == tmp12
    tmp14 = ((x4 % 64)).to(tl.int64)
    tmp15 = (tmp14).to(tl.int64)
    tmp16 = tl.full([1], 2, tl.int64)
    tmp17 = tmp15 >= tmp16
    tmp18 = tl.full([1], 60, tl.int64)
    tmp19 = tmp15 < tmp18
    tmp20 = ((((-2) + ((x0 % 64))) % 3)).to(tl.int64)
    tmp21 = (tmp20).to(tl.int64)
    tmp22 = tl.full([1], 0, tl.int64)
    tmp23 = tmp21 == tmp22
    tmp24 = tmp17 & tmp19
    tmp25 = tmp24 & tmp23
    tmp26 = tl.load(in_ptr3 + (514 + 3*(triton_helpers.div_floor_integer((-2) + ((x0 % 64)),  3)) + 64*x1), tmp25, eviction_policy='evict_last', other=0.0)
    tmp28 = tl.where(tmp25, tmp26, tmp27)
    tmp29 = tl.where(tmp13, tmp28, tmp27)
    tmp30 = tmp29.to(tl.float32)
    tmp31 = tmp11 * tmp30
    tmp33 = tl.load(in_ptr5 + (514 + 3*(triton_helpers.div_floor_integer((-2) + ((x0 % 64)),  3)) + 64*x1), tmp25, eviction_policy='evict_last', other=0.0)
    tmp35 = tl.where(tmp25, tmp33, tmp34)
    tmp36 = tl.where(tmp13, tmp35, tmp34)
    tmp37 = tmp36.to(tl.float32)
    tmp38 = tmp32 * tmp37
    tmp39 = tmp31 + tmp38
    tmp40 = tmp39.to(tl.float32)
    tmp41 = tl.full([1], 0.29730177875068026, tl.float32)
    tmp42 = tmp40 * tmp41
    tl.store(out_ptr0 + (x4), tmp42, None)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-v4-quality-20261031/caches/inductor/sr/csrvchgfvdx7d6kzextcccfjg37h33nlwyvinvdpha3sckohink6.py
# Topologically Sorted Source Nodes: [key, attn_output], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   attn_output => convert_element_type_10, mul_14, permute_4
#   key => clone_4, expand_5, unsqueeze_13, view_9
# Graph fragment:
#   %buf20 : Tensor "bf16[1, 8, 256, 128][262144, 32768, 128, 1]tnca:0" = PlaceHolder[target=buf20]
#   %unsqueeze_13 : Tensor "bf16[1, 8, 1, 256, 128][262144, 32768, 32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%index_put, 2), kwargs = {})
#   %expand_5 : Tensor "bf16[1, 8, 2, 256, 128][262144, 32768, 0, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_13, [1, 8, 2, 256, 128]), kwargs = {})
#   %clone_4 : Tensor "bf16[1, 8, 2, 256, 128][524288, 65536, 32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_5,), kwargs = {memory_format: torch.contiguous_format})
#   %view_9 : Tensor "bf16[1, 16, 256, 128][524288, 32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_4, [1, 16, 256, 128]), kwargs = {})
#   %convert_element_type_10 : Tensor "f32[1, 16, 256, 128][524288, 32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_9, torch.float32), kwargs = {})
#   %permute_4 : Tensor "f32[1, 16, 128, 256][524288, 32768, 1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_10, [0, 1, 3, 2]), kwargs = {})
#   %mul_14 : Tensor "f32[1, 16, 128, 256][524288, 32768, 1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%permute_4, 0.29730177875068026), kwargs = {})
#   return %expand_9
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 524288}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 4194304}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 524288
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 256)
    x1 = ((xindex // 256) % 128)
    x2 = xindex // 32768
    x3 = xindex
    tmp0 = tl.load(in_ptr0 + (x1 + 128*x0 + 32768*(x2 // 2)), None, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tl.full([1], 0.29730177875068026, tl.float32)
    tmp3 = tmp1 * tmp2
    tl.store(out_ptr0 + (x3), tmp3, None)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-v4-quality-20261031/caches/inductor/hr/chr6dvgrhrov4usnsdctmapsjdqzl6opqvcsmwif3ynnscy6s4yg.py
# Topologically Sorted Source Nodes: [hidden_states_3, pow_2, variance_1, add_3, rsqrt_1, hidden_states_4, to_7, mul_6, query_states, setitem_3, cos_2, cos_3, cos_4, mul_9, setitem_1, sin_2, sin_3, sin_4, mul_10, q_embed, attn_output, key], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.select, aten.slice, aten.cat, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
# Source node to ATen node mapping:
#   add_3 => add_3
#   attn_output => bmm, convert_element_type_10, convert_element_type_9, mul_13, mul_14, permute_4, view_11, view_12
#   cos_2 => clone_2, expand_3, select_23, unsqueeze_8, view_1
#   cos_3 => convert_element_type_1
#   cos_4 => unsqueeze_9
#   hidden_states_3 => convert_element_type_5, view_3
#   hidden_states_4 => mul_5
#   key => clone_4, expand_5, unsqueeze_13, view_9
#   mul_10 => mul_10
#   mul_6 => mul_6
#   mul_9 => mul_9
#   pow_2 => pow_2
#   q_embed => add_5
#   query_states => permute
#   rsqrt_1 => rsqrt_1
#   setitem_1 => select_8, slice_8
#   setitem_3 => select_20, slice_16
#   sin_2 => clone, expand_2, select_11, unsqueeze_7, view
#   sin_3 => convert_element_type_2
#   sin_4 => unsqueeze_10
#   to_7 => convert_element_type_6
#   variance_1 => mean_1
# Graph fragment:
#   %expand_8 : Tensor "f32[1, 16, 4, 128][8192, 512, 128, 1]tnca:0" = PlaceHolder[target=expand_8]
#   %expand_9 : Tensor "f32[1, 16, 128, 256][524288, 32768, 256, 1]tnca:0" = PlaceHolder[target=expand_9]
#   %view_3 : Tensor "bf16[1, 4, 16, 128][8192, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%empty, [1, 4, -1, 128]), kwargs = {})
#   %convert_element_type_5 : Tensor "f32[1, 4, 16, 128][8192, 2048, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_3, torch.float32), kwargs = {})
#   %pow_2 : Tensor "f32[1, 4, 16, 128][8192, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_5, 2), kwargs = {})
#   %mean_1 : Tensor "f32[1, 4, 16, 1][64, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_2, [-1], True), kwargs = {})
#   %add_3 : Tensor "f32[1, 4, 16, 1][64, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_1, 1e-06), kwargs = {})
#   %rsqrt_1 : Tensor "f32[1, 4, 16, 1][64, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_3,), kwargs = {})
#   %mul_5 : Tensor "f32[1, 4, 16, 128][8192, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_5, %rsqrt_1), kwargs = {})
#   %convert_element_type_6 : Tensor "bf16[1, 4, 16, 128][8192, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_5, torch.bfloat16), kwargs = {})
#   %mul_6 : Tensor "bf16[1, 4, 16, 128][8192, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg8_1, %convert_element_type_6), kwargs = {})
#   %permute : Tensor "bf16[1, 16, 4, 128][8192, 128, 2048, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%mul_6, [0, 2, 1, 3]), kwargs = {})
#   %select_20 : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 2), kwargs = {})
#   %slice_16 : Tensor "f32[1, 4, 20][256, 64, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_20, 2, 2, 60, 3), kwargs = {})
#   %select_int_2 : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 0), kwargs = {})
#   %slice_scatter_default_2 : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_2, %slice_16, 2, 2, 60, 3), kwargs = {})
#   %select_scatter_default_2 : Tensor "f32[3, 1, 4, 64][256, 256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default_1, %slice_scatter_default_2, 0, 0), kwargs = {})
#   %select_23 : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_2, 0, 0), kwargs = {})
#   %unsqueeze_8 : Tensor "f32[1, 4, 1, 64][256, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_23, 2), kwargs = {})
#   %expand_3 : Tensor "f32[1, 4, 2, 64][256, 64, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_8, [1, 4, 2, 64]), kwargs = {})
#   %clone_2 : Tensor "f32[1, 4, 2, 64][512, 128, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_1 : Tensor "f32[1, 4, 128][512, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_2, [1, 4, 128]), kwargs = {})
#   %convert_element_type_1 : Tensor "bf16[1, 4, 128][512, 128, 1]tnca:0"[num_users=28] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_1, torch.bfloat16), kwargs = {})
#   %unsqueeze_9 : Tensor "bf16[1, 1, 4, 128][512, 512, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_1, 1), kwargs = {})
#   %mul_9 : Tensor "bf16[1, 16, 4, 128][8192, 128, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute, %unsqueeze_9), kwargs = {})
#   %select_8 : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 2), kwargs = {})
#   %slice_8 : Tensor "f32[1, 4, 20][256, 64, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_8, 2, 2, 60, 3), kwargs = {})
#   %select_int_3 : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 0), kwargs = {})
#   %slice_scatter_default_3 : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_3, %slice_8, 2, 2, 60, 3), kwargs = {})
#   %select_scatter_default_3 : Tensor "f32[3, 1, 4, 64][256, 256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default, %slice_scatter_default_3, 0, 0), kwargs = {})
#   %select_11 : Tensor "f32[1, 4, 64][256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_3, 0, 0), kwargs = {})
#   %unsqueeze_7 : Tensor "f32[1, 4, 1, 64][256, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_11, 2), kwargs = {})
#   %expand_2 : Tensor "f32[1, 4, 2, 64][256, 64, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_7, [1, 4, 2, 64]), kwargs = {})
#   %clone : Tensor "f32[1, 4, 2, 64][512, 128, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_2,), kwargs = {memory_format: torch.contiguous_format})
#   %view : Tensor "f32[1, 4, 128][512, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 4, 128]), kwargs = {})
#   %convert_element_type_2 : Tensor "bf16[1, 4, 128][512, 128, 1]tnca:0"[num_users=28] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view, torch.bfloat16), kwargs = {})
#   %unsqueeze_10 : Tensor "bf16[1, 1, 4, 128][512, 512, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_2, 1), kwargs = {})
#   %mul_10 : Tensor "bf16[1, 16, 4, 128][8192, 512, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat, %unsqueeze_10), kwargs = {})
#   %add_5 : Tensor "bf16[1, 16, 4, 128][8192, 128, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_9, %mul_10), kwargs = {})
#   %convert_element_type_9 : Tensor "f32[1, 16, 4, 128][8192, 128, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_5, torch.float32), kwargs = {})
#   %mul_13 : Tensor "f32[1, 16, 4, 128][8192, 128, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%convert_element_type_9, 0.29730177875068026), kwargs = {})
#   %view_11 : Tensor "f32[16, 4, 128][128, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_8, [16, 4, 128]), kwargs = {})
#   %unsqueeze_13 : Tensor "bf16[1, 8, 1, 256, 128][262144, 32768, 32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%index_put, 2), kwargs = {})
#   %expand_5 : Tensor "bf16[1, 8, 2, 256, 128][262144, 32768, 0, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_13, [1, 8, 2, 256, 128]), kwargs = {})
#   %clone_4 : Tensor "bf16[1, 8, 2, 256, 128][524288, 65536, 32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_5,), kwargs = {memory_format: torch.contiguous_format})
#   %view_9 : Tensor "bf16[1, 16, 256, 128][524288, 32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_4, [1, 16, 256, 128]), kwargs = {})
#   %convert_element_type_10 : Tensor "f32[1, 16, 256, 128][524288, 32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_9, torch.float32), kwargs = {})
#   %permute_4 : Tensor "f32[1, 16, 128, 256][524288, 32768, 1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_10, [0, 1, 3, 2]), kwargs = {})
#   %mul_14 : Tensor "f32[1, 16, 128, 256][524288, 32768, 1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%permute_4, 0.29730177875068026), kwargs = {})
#   %view_12 : Tensor "f32[16, 128, 256][32768, 1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_9, [16, 128, 256]), kwargs = {})
#   %bmm : Tensor "f32[16, 4, 256][1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_11, %view_12), kwargs = {})
#   return %bmm
triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9 = async_compile.triton('triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp32', 'arg_B': '*fp32', 'out_ptr0': '*fp32'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9', 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 4
    N = 256
    K = 128
    BATCH = 16

    stride_aq = 512
    stride_am = 128
    stride_ak = 1

    stride_bq = 32768
    stride_bk = 256
    stride_bn = 1

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        ram = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        ram = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        rbn = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        rbn = rn % N

    rk = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)

    # Reconstruct batch index from grid_y/grid_z split (handles batch > 65535)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    # Clamp to valid range for safe pointer arithmetic; out-of-bounds CTAs are
    # masked off at the store below.
    idx_q_clamped = tl.minimum(idx_q, BATCH - 1)
    A = A + (ram[:, None] * stride_am + rk[None, :] * stride_ak + idx_q_clamped*stride_aq)
    B = B + (rk[:, None] * stride_bk + rbn[None, :] * stride_bn + idx_q_clamped*stride_bq)

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)
    for k in range(K, 0, -BLOCK_K):
        if EVEN_K:
            a = tl.load(A)
            b = tl.load(B)
        else:
            a = tl.load(A, mask=rk[None, :] < k, other=0.)
            b = tl.load(B, mask=rk[:, None] < k, other=0.)
        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32)
        A += BLOCK_K * stride_ak
        B += BLOCK_K * stride_bk

    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N) & (idx_q < BATCH)

    # inductor generates a suffix
    xindex = idx_n + 256*idx_m + 1024*idx_q
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-v4-quality-20261031/caches/inductor/f6/cf66dnuvtom6j4thzxvrl4boq37o5uu3o6pije2wrql3bptrphjo.py
# Topologically Sorted Source Nodes: [attn_output, kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten.scalar_tensor, aten.where]
# Source node to ATen node mapping:
#   arange_2 => iota_2
#   attention_mask => le
#   attention_mask_1 => expand
#   attn_output => add_9, amax, any_1, div, eq, exp, full_default, full_default_1, full_default_2, logical_not, logical_not_1, sub, sum_1, view_13, where, where_1
#   kv_arange => iota_3
#   kv_indices => unsqueeze_3, unsqueeze_4, unsqueeze_5
#   q_arange => add
#   q_indices => unsqueeze, unsqueeze_1, unsqueeze_2
# Graph fragment:
#   %bmm : Tensor "f32[16, 4, 256][1024, 256, 1]tnca:0" = PlaceHolder[target=bmm]
#   %copy_ : Tensor "i64[][]tnca:0" = PlaceHolder[target=copy_]
#   %amax : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=amax]
#   %exp : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=exp]
#   %any_1 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=any_1]
#   %sum_1 : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=sum_1]
#   %view_13 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm, [1, 16, 4, 256]), kwargs = {})
#   %iota_3 : Tensor "i64[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (256,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %unsqueeze_3 : Tensor "i64[1, 256][256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%iota_3, 0), kwargs = {})
#   %unsqueeze_4 : Tensor "i64[1, 1, 256][256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze_3, 1), kwargs = {})
#   %unsqueeze_5 : Tensor "i64[1, 1, 1, 256][256, 256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze_4, 2), kwargs = {})
#   %iota_2 : Tensor "i64[4][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (4,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %add : Tensor "i64[4][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%iota_2, %arg3_1), kwargs = {})
#   %unsqueeze : Tensor "i64[1, 4][4, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%add, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "i64[1, 1, 4][4, 4, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze, 1), kwargs = {})
#   %unsqueeze_2 : Tensor "i64[1, 1, 4, 1][4, 4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze_1, 3), kwargs = {})
#   %le : Tensor "b8[1, 1, 4, 256][1024, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.le.Tensor](args = (%unsqueeze_5, %unsqueeze_2), kwargs = {})
#   %expand : Tensor "b8[1, 1, 4, 256][1024, 1024, 256, 1]tnca:0"[num_users=28] = call_function[target=torch.ops.aten.expand.default](args = (%le, [1, -1, 4, 256]), kwargs = {})
#   %full_default_1 : Tensor "bf16[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([], 0.0), kwargs = {dtype: torch.bfloat16, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %full_default : Tensor "bf16[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([], -inf), kwargs = {dtype: torch.bfloat16, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %where : Tensor "bf16[1, 1, 4, 256][1024, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%expand, %full_default_1, %full_default), kwargs = {})
#   %add_9 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%view_13, %where), kwargs = {})
#   %eq : Tensor "b8[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.eq.Scalar](args = (%add_9, -inf), kwargs = {})
#   %logical_not : Tensor "b8[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%eq,), kwargs = {})
#   %any_1 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.any.dim](args = (%logical_not, -1, True), kwargs = {})
#   %logical_not_1 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%any_1,), kwargs = {})
#   %full_default_2 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([1, 16, 4, 256], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %amax : Tensor "f32[1, 16, 4, 1][64, 4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.amax.default](args = (%add_9, [-1], True), kwargs = {})
#   %sub : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%add_9, %amax), kwargs = {})
#   %exp : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.exp.default](args = (%sub,), kwargs = {})
#   %sum_1 : Tensor "f32[1, 16, 4, 1][64, 4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%exp, [-1], True), kwargs = {})
#   %div : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp, %sum_1), kwargs = {})
#   %where_1 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_not_1, %full_default_2, %div), kwargs = {})
#   return %any_1,%amax,%exp,%sum_1,%expand_10
triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 256},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*i64', 'out_ptr2': '*fp32', 'out_ptr4': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 2, 'num_reduction': 3, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 196608}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 4}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10(in_ptr0, in_ptr1, out_ptr2, out_ptr4, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 64
    XBLOCK: tl.constexpr = 1
    r0_numel = 256
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x3 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[64, 256], strides=[256, 1], block_shape=[XBLOCK, R0_BLOCK])
    tmp1 = tl.load(in_ptr1 + (0))
    tmp2 = tl.broadcast_to(tmp1, [R0_BLOCK])
    x0 = (xindex % 4)
    _tmp19 = tl.full([R0_BLOCK], False, tl.int1)
    _tmp23 = tl.full([R0_BLOCK], float("-inf"), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp3 = (x0).to(tl.int64)
        tmp4 = (tmp3).to(tl.int64)
        tmp5 = tmp4 + tmp2
        tmp6 = (r0_2).to(tl.int64)
        tmp7 = (tmp6).to(tl.int64)
        tmp8 = tmp7 <= tmp5
        tmp9 = tl.full([1], 0.0, tl.float32)
        tmp10 = tl.full([1], float("-inf"), tl.float32)
        tmp11 = tl.where(tmp8, tmp9, tmp10)
        tmp12 = tmp11.to(tl.float32)
        tmp13 = tmp0 + tmp12
        tmp14 = tmp13 == tmp10
        tmp15 = tmp14 == 0
        tmp16 = tmp15.to(tl.int64)
        tmp17 = (tmp16 != 0)
        tmp18 = tl.broadcast_to(tmp17, [R0_BLOCK])
        tmp20 = _tmp19 | tmp18
        _tmp19 = tl.where(r0_mask, tmp20, _tmp19)
        tmp22 = tl.broadcast_to(tmp13, [R0_BLOCK])
        tmp24 = tl.maximum(_tmp23, tmp22, tl.PropagateNan.ALL)
        _tmp23 = tl.where(r0_mask, tmp24, _tmp23)
    tmp21 = _tmp19.to(tl.int8)
    tmp19 = triton_helpers.promote_to_tensor(triton_helpers.any(tmp21, 0))
    tmp23 = triton_helpers.promote_to_tensor(triton_helpers.max2(_tmp23, 0))
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[64, 256], strides=[256, 1], block_shape=[XBLOCK, R0_BLOCK])
    tmp26 = tl.load(in_ptr1 + (0))
    tmp27 = tl.broadcast_to(tmp26, [R0_BLOCK])
    _tmp42 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp25 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp28 = (x0).to(tl.int64)
        tmp29 = (tmp28).to(tl.int64)
        tmp30 = tmp29 + tmp27
        tmp31 = (r0_2).to(tl.int64)
        tmp32 = (tmp31).to(tl.int64)
        tmp33 = tmp32 <= tmp30
        tmp34 = tl.full([1], 0.0, tl.float32)
        tmp35 = tl.full([1], float("-inf"), tl.float32)
        tmp36 = tl.where(tmp33, tmp34, tmp35)
        tmp37 = tmp36.to(tl.float32)
        tmp38 = tmp25 + tmp37
        tmp39 = tmp38 - tmp23
        tmp40 = libdevice.exp(tmp39)
        tmp41 = tl.broadcast_to(tmp40, [R0_BLOCK])
        tmp43 = _tmp42 + tmp41
        _tmp42 = tl.where(r0_mask, tmp43, _tmp42)
        tl.store(out_ptr2 + (r0_2 + 256*x3), tmp40, r0_mask)
    tmp42 = triton_helpers.promote_to_tensor(tl.sum(_tmp42, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(out_ptr2, shape=[64, 256], strides=[256, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tl.debug_barrier()
        tmp45 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp44 = tmp19 == 0
        tmp46 = (tmp45 / tmp42)
        tmp47 = tl.full([1], 0.0, tl.float32)
        tmp48 = tl.where(tmp44, tmp47, tmp46)
        tl.store(out_ptr4 + (r0_2 + 256*x3), tmp48, r0_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-v4-quality-20261031/caches/inductor/iy/ciybor2ziqbhkxh2vd662o55oy7eabyyhtglfhl6652ljngv3vqd.py
# Topologically Sorted Source Nodes: [arange_4, cache_position, index_copy__1], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
# Source node to ATen node mapping:
#   arange_4 => iota_4
#   cache_position => add_7
#   index_copy__1 => index_put_1, permute_3, view_8
# Graph fragment:
#   %copy_ : Tensor "i64[][]tnca:0" = PlaceHolder[target=copy_]
#   %buf11 : Tensor  = PlaceHolder[target=buf11]
#   %index_put_1 : Tensor "bf16[1, 8, 256, 128][262144, 32768, 128, 1]tnca:0" = PlaceHolder[target=index_put_1]
#   %iota_4 : Tensor "i64[4][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (4,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %add_7 : Tensor "i64[4][1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%iota_4, %arg3_1), kwargs = {})
#   %view_8 : Tensor "bf16[1, 4, 8, 128][4096, 1024, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%empty_2, [1, 4, -1, 128]), kwargs = {})
#   %permute_3 : Tensor "bf16[1, 8, 4, 128][4096, 128, 1024, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_8, [0, 2, 1, 3]), kwargs = {})
#   %index_put_1 : Tensor "bf16[1, 8, 256, 128][262144, 32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.index_put_.default](args = (%arg15_1, [None, None, %add_7], %permute_3), kwargs = {})
#   return %buf28
triton_poi_fused_add_arange_index_copy_transpose_view_11 = async_compile.triton('triton_poi_fused_add_arange_index_copy_transpose_view_11', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 4096}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_add_arange_index_copy_transpose_view_11', 'mutated_arg_names': ['out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 0}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_arange_index_copy_transpose_view_11(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 4096
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x2 = xindex // 1024
    x3 = xindex
    x0 = (xindex % 128)
    x1 = ((xindex // 128) % 8)
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK])
    tmp9 = tl.load(in_ptr1 + (x3), None).to(tl.float32)
    tmp2 = (x2).to(tl.int32)
    tmp3 = tmp2 + tmp1
    tmp4 = (tl.full([XBLOCK], 256, tl.int32)).to(tl.int32)
    tmp5 = tmp3 + tmp4
    tmp6 = tmp3 < 0
    tmp7 = tl.where(tmp6, tmp5, tmp3)
    tl.device_assert((0 <= tmp7) & (tmp7 < 256), "index out of bounds: 0 <= tmp7 < 256")
    tl.store(out_ptr0 + (x0 + 128*tmp7 + 32768*x1), tmp9, None)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-v4-quality-20261031/caches/inductor/43/c43ug37esfxstdu2v3l4k6hio2a5w2e2p73qstl2gxpvvekwl6hs.py
# Topologically Sorted Source Nodes: [value, attn_output], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   attn_output => convert_element_type_11
#   value => clone_5, expand_7, unsqueeze_16, view_10
# Graph fragment:
#   %buf28 : Tensor "bf16[1, 8, 256, 128][262144, 32768, 128, 1]tnca:0" = PlaceHolder[target=buf28]
#   %unsqueeze_16 : Tensor "bf16[1, 8, 1, 256, 128][262144, 32768, 32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%index_put_1, 2), kwargs = {})
#   %expand_7 : Tensor "bf16[1, 8, 2, 256, 128][262144, 32768, 0, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_16, [1, 8, 2, 256, 128]), kwargs = {})
#   %clone_5 : Tensor "bf16[1, 8, 2, 256, 128][524288, 65536, 32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_7,), kwargs = {memory_format: torch.contiguous_format})
#   %view_10 : Tensor "bf16[1, 16, 256, 128][524288, 32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_5, [1, 16, 256, 128]), kwargs = {})
#   %convert_element_type_11 : Tensor "f32[1, 16, 256, 128][524288, 32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_10, torch.float32), kwargs = {})
#   return %expand_11
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 524288}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 4194304}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 524288
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 32768)
    x1 = xindex // 32768
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 32768*(x1 // 2)), None).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tl.store(out_ptr0 + (x2), tmp1, None)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-v4-quality-20261031/caches/inductor/ec/ceclgtforiffx2a5jq3msggwkawcyabuyeqhy6lbaw7xg3zedejb.py
# Topologically Sorted Source Nodes: [attn_output, value], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
# Source node to ATen node mapping:
#   attn_output => bmm_1, convert_element_type_11, div, full_default_2, logical_not_1, view_14, view_15, where_1
#   value => clone_5, expand_7, unsqueeze_16, view_10
# Graph fragment:
#   %expand_10 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=expand_10]
#   %expand_11 : Tensor "f32[1, 16, 256, 128][524288, 32768, 128, 1]tnca:0" = PlaceHolder[target=expand_11]
#   %logical_not_1 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%any_1,), kwargs = {})
#   %full_default_2 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([1, 16, 4, 256], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %div : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp, %sum_1), kwargs = {})
#   %where_1 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_not_1, %full_default_2, %div), kwargs = {})
#   %view_14 : Tensor "f32[16, 4, 256][1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_10, [16, 4, 256]), kwargs = {})
#   %unsqueeze_16 : Tensor "bf16[1, 8, 1, 256, 128][262144, 32768, 32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%index_put_1, 2), kwargs = {})
#   %expand_7 : Tensor "bf16[1, 8, 2, 256, 128][262144, 32768, 0, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_16, [1, 8, 2, 256, 128]), kwargs = {})
#   %clone_5 : Tensor "bf16[1, 8, 2, 256, 128][524288, 65536, 32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_7,), kwargs = {memory_format: torch.contiguous_format})
#   %view_10 : Tensor "bf16[1, 16, 256, 128][524288, 32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_5, [1, 16, 256, 128]), kwargs = {})
#   %convert_element_type_11 : Tensor "f32[1, 16, 256, 128][524288, 32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_10, torch.float32), kwargs = {})
#   %view_15 : Tensor "f32[16, 256, 128][32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_11, [16, 256, 128]), kwargs = {})
#   %bmm_1 : Tensor "f32[16, 4, 128][512, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_14, %view_15), kwargs = {})
#   return %bmm_1
triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13 = async_compile.triton('triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp32', 'arg_B': '*fp32', 'out_ptr0': '*fp32'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13', 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 4
    N = 128
    K = 256
    BATCH = 16

    stride_aq = 1024
    stride_am = 256
    stride_ak = 1

    stride_bq = 32768
    stride_bk = 128
    stride_bn = 1

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        ram = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        ram = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        rbn = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        rbn = rn % N

    rk = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)

    # Reconstruct batch index from grid_y/grid_z split (handles batch > 65535)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    # Clamp to valid range for safe pointer arithmetic; out-of-bounds CTAs are
    # masked off at the store below.
    idx_q_clamped = tl.minimum(idx_q, BATCH - 1)
    A = A + (ram[:, None] * stride_am + rk[None, :] * stride_ak + idx_q_clamped*stride_aq)
    B = B + (rk[:, None] * stride_bk + rbn[None, :] * stride_bn + idx_q_clamped*stride_bq)

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)
    for k in range(K, 0, -BLOCK_K):
        if EVEN_K:
            a = tl.load(A)
            b = tl.load(B)
        else:
            a = tl.load(A, mask=rk[None, :] < k, other=0.)
            b = tl.load(B, mask=rk[:, None] < k, other=0.)
        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32)
        A += BLOCK_K * stride_ak
        B += BLOCK_K * stride_bk

    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N) & (idx_q < BATCH)

    # inductor generates a suffix
    xindex = idx_n + 128*idx_m + 512*idx_q
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-v4-quality-20261031/caches/inductor/tj/ctjgivjwuaqpkhvgtgwirnulse5zbdlnavemix64q42wi6s7c2he.py
# Topologically Sorted Source Nodes: [attn_output, transpose_3, reshape_2, output_3], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
# Source node to ATen node mapping:
#   attn_output => clone_6, convert_element_type_13, permute_5, permute_6, view_16
#   output_3 => triton_kernel_wrapper_mutation_192
#   reshape_2 => view_17
#   transpose_3 => permute_7
# Graph fragment:
#   %bmm_1 : Tensor "f32[16, 4, 128][512, 128, 1]tnca:0" = PlaceHolder[target=bmm_1]
#   %view_16 : Tensor "f32[1, 16, 4, 128][8192, 512, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_1, [1, 16, 4, 128]), kwargs = {})
#   %convert_element_type_13 : Tensor "bf16[1, 16, 4, 128][8192, 512, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_16, torch.bfloat16), kwargs = {})
#   %permute_5 : Tensor "bf16[4, 1, 16, 128][128, 8192, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_13, [2, 0, 1, 3]), kwargs = {})
#   %clone_6 : Tensor "bf16[4, 1, 16, 128][2048, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%permute_5,), kwargs = {memory_format: torch.contiguous_format})
#   %permute_6 : Tensor "bf16[1, 16, 4, 128][2048, 128, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%clone_6, [1, 2, 0, 3]), kwargs = {})
#   %permute_7 : Tensor "bf16[1, 4, 16, 128][2048, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%permute_6, [0, 2, 1, 3]), kwargs = {})
#   %view_17 : Tensor "bf16[1, 4, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%permute_7, [1, 4, -1]), kwargs = {})
#   %triton_kernel_wrapper_mutation_192 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 983, grid: [(1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1)], tma_descriptor_metadata: {}, kwargs: {A: %view_17, B: %arg16_1, C: %empty_3, Bs: %arg17_1, M: 4, N: 2048, K: 2048, stride_am: 2048, stride_ak: 1, stride_bk: 1, stride_bn: 2048, stride_cm: 2048, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 16, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   return %buf33
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 8192}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 65536}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 8192
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 2048)
    x1 = xindex // 2048
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (128*x1 + 512*(x0 // 128) + ((x0 % 128))), None)
    tmp1 = tmp0.to(tl.float32)
    tl.store(out_ptr0 + (x2), tmp1, None)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-v4-quality-20261031/caches/inductor/mf/cmfzz775egy3vikvatnpqx3xrebfjab2axqrwglrj2wzehyyyurm.py
# Topologically Sorted Source Nodes: [inputs_embeds, hidden_states_9, hidden_states_10, pow_4, variance_3, add_9, rsqrt_3, hidden_states_11, to_11, hidden_states_12], Original ATen: [aten.embedding, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_9 => add_11
#   hidden_states_10 => convert_element_type_14
#   hidden_states_11 => mul_15
#   hidden_states_12 => mul_16
#   hidden_states_9 => add_10
#   inputs_embeds => embedding
#   pow_4 => pow_4
#   rsqrt_3 => rsqrt_3
#   to_11 => convert_element_type_15
#   variance_3 => mean_3
# Graph fragment:
#   %arg0_1 : Tensor "i64[1, 4][4, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %arg1_1 : Tensor "bf16[151936, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %buf34 : Tensor  = PlaceHolder[target=buf34]
#   %arg18_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg18_1]
#   %buf35 : Tensor "f32[1, 4, 1][4, 1, 4]tnca:0" = PlaceHolder[target=buf35]
#   %embedding : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg1_1, %arg0_1), kwargs = {})
#   %add_10 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %empty_3), kwargs = {})
#   %convert_element_type_14 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_10, torch.float32), kwargs = {})
#   %pow_4 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_14, 2), kwargs = {})
#   %mean_3 : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_4, [-1], True), kwargs = {})
#   %add_11 : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_3, 1e-06), kwargs = {})
#   %rsqrt_3 : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_11,), kwargs = {})
#   %mul_15 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_14, %rsqrt_3), kwargs = {})
#   %convert_element_type_15 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_15, torch.bfloat16), kwargs = {})
#   %mul_16 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg18_1, %convert_element_type_15), kwargs = {})
#   return %buf35,%mul_16
triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_15 = async_compile.triton('triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_15', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 4, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_15', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 4, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 16, 'r0_': 36864}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_15(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 4
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), None, eviction_policy='evict_last')
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr2, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp8 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp0) & (tmp0 < 151936), "index out of bounds: 0 <= tmp0 < 151936")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 2048*tmp0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tmp5 * tmp5
        tmp7 = tl.broadcast_to(tmp6, [R0_BLOCK])
        tmp9 = _tmp8 + tmp7
        _tmp8 = tl.where(r0_mask, tmp9, _tmp8)
    tmp8 = triton_helpers.promote_to_tensor(tl.sum(_tmp8, 0))
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr2, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp10 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp13 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp0) & (tmp0 < 151936), "index out of bounds: 0 <= tmp0 < 151936")
        tmp12 = tl.load(in_ptr1 + (r0_1 + 2048*tmp0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp14 = tmp12 + tmp13
        tmp15 = tmp14.to(tl.float32)
        tmp16 = tl.full([1], 2048.0, tl.float32)
        tmp17 = (tmp8 / tmp16)
        tmp18 = tl.full([1], 1e-06, tl.float32)
        tmp19 = tmp17 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp15 * tmp20
        tmp22 = tmp21.to(tl.float32)
        tmp23 = tmp10 * tmp22
        tl.store(out_ptr1 + (r0_1 + 2048*x0), tmp23, r0_mask)
''', device_str='tnca')


# Original path: /home/zzhouch/r41s2_fp8_inputs/hf/hub/kernels--kernels-community--finegrained-fp8/snapshots/0e5764aa5c27d0f005117a92645156481540950a/build/torch-cuda/matmul.py:96
w8a8_block_dynamic_fp8_matmul_kernel_2 = async_compile.triton('w8a8_block_dynamic_fp8_matmul_kernel', '''

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 2, 'num_stages': 2}, {'num_warps': 2, 'num_stages': 3}, {'num_warps': 2, 'num_stages': 4}, {'num_warps': 4, 'num_stages': 2}, {'num_warps': 4, 'num_stages': 3}, {'num_warps': 4, 'num_stages': 4}, {'num_warps': 8, 'num_stages': 2}, {'num_warps': 8, 'num_stages': 3}, {'num_warps': 8, 'num_stages': 4}, {'num_warps': 16, 'num_stages': 2}, {'num_warps': 16, 'num_stages': 3}, {'num_warps': 16, 'num_stages': 4}],
    inductor_meta={'grid_type': 'PrecomputedGrid', 'precomputed_grids': [{'config': {'num_warps': 2, 'num_stages': 2}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 2, 'num_stages': 3}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 2, 'num_stages': 4}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 4, 'num_stages': 2}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 4, 'num_stages': 3}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 4, 'num_stages': 4}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 8, 'num_stages': 2}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 8, 'num_stages': 3}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 8, 'num_stages': 4}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 16, 'num_stages': 2}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 16, 'num_stages': 3}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 16, 'num_stages': 4}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}], 'extra_launcher_args': [], 'declared_constexpr_names': ['BLOCK_SIZE_M', 'BLOCK_SIZE_N', 'BLOCK_SIZE_K', 'GROUP_SIZE_M'], 'kernel_name': 'w8a8_block_dynamic_fp8_matmul_kernel_2', 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    triton_meta={'signature': {'A': '*bf16', 'B': '*fp8e4nv', 'C': '*bf16', 'Bs': '*fp32', 'M': 'i32', 'N': 'i32', 'K': 'i32', 'stride_am': 'i32', 'stride_ak': 'constexpr', 'stride_bk': 'constexpr', 'stride_bn': 'i32', 'stride_cm': 'i32', 'stride_cn': 'constexpr', 'stride_bs_k': 'constexpr', 'stride_bs_n': 'i32', 'BLOCK_SIZE_M': 'constexpr', 'BLOCK_SIZE_N': 'constexpr', 'BLOCK_SIZE_K': 'constexpr', 'GROUP_SIZE_M': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'stride_ak': 1, 'stride_bk': 1, 'stride_cn': 1, 'stride_bs_k': 1, 'BLOCK_SIZE_M': 16, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'GROUP_SIZE_M': 8}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (10,): [['tt.divisibility', 16]], (11,): [['tt.divisibility', 16]], (14,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def w8a8_block_dynamic_fp8_matmul_kernel(
    A,  # (M, K) raw BF16/FP16 activations
    B,  # (N, K) FP8 weights
    C,  # (M, N) output
    Bs,  # (N // BLOCK_SIZE_N, K // BLOCK_SIZE_K) weight scales (fp32 or uint8/UE8M0)
    # Shape
    M,
    N,
    K,
    # Strides
    stride_am,
    stride_ak,
    stride_bk,
    stride_bn,
    stride_cm,
    stride_cn,
    stride_bs_k,
    stride_bs_n,
    # Meta-parameters
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """Block-scale FP8 GEMM kernel with fused activation quantization.

    Computes ``C = A @ B.T`` with bf16/fp16 ``A`` quantized to FP8 per-K-tile
    inline (one scale per M-row per BLOCK_SIZE_K) and pre-quantized FP8 weights
    with per-block scales. 2D grid with swizzle for L2 cache locality on B.
    """
    pid_m, pid_n, offs_am, offs_bn, offs_k = _swizzle_offsets(
        M, N, BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M
    )
    a_ptrs = A + (offs_am[:, None] * stride_am + offs_k[None, :] * stride_ak)
    b_ptrs = B + (offs_k[:, None] * stride_bk + offs_bn[None, :] * stride_bn)

    offs_bsn = offs_bn // BLOCK_SIZE_N
    bs_ptrs = Bs + offs_bsn * stride_bs_n

    accumulator = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    for k in range(0, tl.cdiv(K, BLOCK_SIZE_K)):
        k_remaining = K - k * BLOCK_SIZE_K
        a_raw = tl.load(a_ptrs, mask=offs_k[None, :] < k_remaining, other=0.0).to(
            tl.float32
        )
        a, a_s = fp8_act_quant_inline(a_raw)
        b = tl.load(b_ptrs, mask=offs_k[:, None] < k_remaining, other=0.0)
        b_s = decode_ue8m0_scale(tl.load(bs_ptrs))
        accumulator += tl.dot(a, b) * a_s[:, None] * b_s[None, :]
        a_ptrs += BLOCK_SIZE_K * stride_ak
        b_ptrs += BLOCK_SIZE_K * stride_bk
        bs_ptrs += stride_bs_k

    _store_masked(
        C,
        accumulator,
        pid_m,
        pid_n,
        M,
        N,
        stride_cm,
        stride_cn,
        BLOCK_SIZE_M,
        BLOCK_SIZE_N,
    )

@triton.jit
def _swizzle_offsets(
    M,
    N,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """2D-grid tile scheduling shared by the kernels below: swizzle the
    ``(pid_m, pid_n)`` program ids for L2 locality on B, then build the operand
    offset vectors. Returns ``(pid_m, pid_n, offs_am, offs_bn, offs_k)`` — the
    swizzled ids (reused by the output store) and the ``%``-wrapped row/col offsets
    plus the K range."""
    pid_m = tl.program_id(axis=0)
    pid_n = tl.program_id(axis=1)
    num_pid_m = tl.cdiv(M, BLOCK_SIZE_M)
    num_pid_n = tl.cdiv(N, BLOCK_SIZE_N)
    pid_m, pid_n = tl.swizzle2d(pid_m, pid_n, num_pid_m, num_pid_n, GROUP_SIZE_M)
    offs_am = (pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)) % M
    offs_bn = (pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)) % N
    offs_k = tl.arange(0, BLOCK_SIZE_K)
    return pid_m, pid_n, offs_am, offs_bn, offs_k

@triton.jit
def fp8_act_quant_inline(a_raw):
    """Inline FP8 (E4M3) activation quant for the W8A8 block-scale path.

    Per-row amax → fp32 scale ``amax/448`` (floored at 1e-12 against zero rows)
    → cast values to FP8. Returns ``(a_fp8, a_s)`` with shapes ``(M, K)`` and
    ``(M,)``.
    """
    a_s = tl.max(tl.abs(a_raw), axis=1) / 448.0
    a_fp8 = (a_raw / tl.maximum(a_s[:, None], 1e-12)).to(tl.float8e4nv)
    return a_fp8, a_s

@triton.jit
def decode_ue8m0_scale(scale):
    """Decode a UE8M0 weight scale to fp32: when it was loaded as ``uint8`` exponent
    bits, ``value = 2^(exp - 127)``, built directly as the fp32 bit pattern. fp32
    scales (block-dynamic with float scales) pass through. The dtype branch is a
    compile-time constant, so only the taken path is emitted (single return — Triton
    requires all ``return`` statements to share a type)."""
    if scale.dtype == tl.uint8:
        scale = (scale.to(tl.int32) << 23).to(tl.float32, bitcast=True)
    return scale

@triton.jit
def _store_masked(
    C,
    accumulator,
    pid_m,
    pid_n,
    M,
    N,
    stride_cm,
    stride_cn,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
):
    """Shared output epilogue of the kernels below: cast the fp32 accumulator to
    ``C``'s dtype and store the ``(BLOCK_SIZE_M, BLOCK_SIZE_N)`` tile at the swizzled
    ``(pid_m, pid_n)``, masked to the ``(M, N)`` bounds."""
    c = accumulator.to(C.dtype.element_ty)
    offs_cm = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_cn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    c_ptrs = C + stride_cm * offs_cm[:, None] + stride_cn * offs_cn[None, :]
    c_mask = (offs_cm[:, None] < M) & (offs_cn[None, :] < N)
    tl.store(c_ptrs, c, mask=c_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-v4-quality-20261031/caches/inductor/gc/cgcv34itvjslp4liuxilmfnrde2zg3f7g33i3jmndtmw7njf4djf.py
# Topologically Sorted Source Nodes: [silu, mul_15, output_6], Original ATen: [aten.silu, aten.mul]
# Source node to ATen node mapping:
#   mul_15 => mul_17
#   output_6 => triton_kernel_wrapper_mutation_189
#   silu => add_12, convert_element_type_16, convert_element_type_17, div_1, exp_1, neg_2
# Graph fragment:
#   %buf38 : Tensor  = PlaceHolder[target=buf38]
#   %buf40 : Tensor  = PlaceHolder[target=buf40]
#   %convert_element_type_16 : Tensor "f32[1, 4, 6144][24576, 6144, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%empty_4, torch.float32), kwargs = {})
#   %neg_2 : Tensor "f32[1, 4, 6144][24576, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_16,), kwargs = {})
#   %exp_1 : Tensor "f32[1, 4, 6144][24576, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_2,), kwargs = {})
#   %add_12 : Tensor "f32[1, 4, 6144][24576, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp_1, 1), kwargs = {})
#   %div_1 : Tensor "f32[1, 4, 6144][24576, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_16, %add_12), kwargs = {})
#   %convert_element_type_17 : Tensor "bf16[1, 4, 6144][24576, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_1, torch.bfloat16), kwargs = {})
#   %mul_17 : Tensor "bf16[1, 4, 6144][24576, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_17, %empty_5), kwargs = {})
#   %triton_kernel_wrapper_mutation_189 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 986, grid: [(1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1)], tma_descriptor_metadata: {}, kwargs: {A: %mul_17, B: %arg23_1, C: %empty_6, Bs: %arg24_1, M: 4, N: 2048, K: 6144, stride_am: 6144, stride_ak: 1, stride_bk: 1, stride_bn: 6144, stride_cm: 2048, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 48, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   return %buf42
triton_poi_fused_mul_silu_16 = async_compile.triton('triton_poi_fused_mul_silu_16', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 32768}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_mul_silu_16', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 98304}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_mul_silu_16(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 24576
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), None).to(tl.float32)
    tmp8 = tl.load(in_ptr1 + (x0), None).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = -tmp1
    tmp3 = libdevice.exp(tmp2)
    tmp4 = tl.full([1], 1.0, tl.float32)
    tmp5 = tmp3 + tmp4
    tmp6 = (tmp1 / tmp5)
    tmp7 = tmp6.to(tl.float32)
    tmp9 = tmp7 * tmp8
    tl.store(out_ptr0 + (x0), tmp9, None)
''', device_str='tnca')


# Original path: /home/zzhouch/r41s2_fp8_inputs/hf/hub/kernels--kernels-community--finegrained-fp8/snapshots/0e5764aa5c27d0f005117a92645156481540950a/build/torch-cuda/matmul.py:96
w8a8_block_dynamic_fp8_matmul_kernel_3 = async_compile.triton('w8a8_block_dynamic_fp8_matmul_kernel', '''

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 2, 'num_stages': 2}, {'num_warps': 2, 'num_stages': 3}, {'num_warps': 2, 'num_stages': 4}, {'num_warps': 4, 'num_stages': 2}, {'num_warps': 4, 'num_stages': 3}, {'num_warps': 4, 'num_stages': 4}, {'num_warps': 8, 'num_stages': 2}, {'num_warps': 8, 'num_stages': 3}, {'num_warps': 8, 'num_stages': 4}, {'num_warps': 16, 'num_stages': 2}, {'num_warps': 16, 'num_stages': 3}, {'num_warps': 16, 'num_stages': 4}],
    inductor_meta={'grid_type': 'PrecomputedGrid', 'precomputed_grids': [{'config': {'num_warps': 2, 'num_stages': 2}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 2, 'num_stages': 3}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 2, 'num_stages': 4}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 4, 'num_stages': 2}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 4, 'num_stages': 3}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 4, 'num_stages': 4}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 8, 'num_stages': 2}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 8, 'num_stages': 3}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 8, 'num_stages': 4}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 16, 'num_stages': 2}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 16, 'num_stages': 3}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 16, 'num_stages': 4}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}], 'extra_launcher_args': [], 'declared_constexpr_names': ['BLOCK_SIZE_M', 'BLOCK_SIZE_N', 'BLOCK_SIZE_K', 'GROUP_SIZE_M'], 'kernel_name': 'w8a8_block_dynamic_fp8_matmul_kernel_3', 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    triton_meta={'signature': {'A': '*bf16', 'B': '*fp8e4nv', 'C': '*bf16', 'Bs': '*fp32', 'M': 'i32', 'N': 'i32', 'K': 'i32', 'stride_am': 'i32', 'stride_ak': 'constexpr', 'stride_bk': 'constexpr', 'stride_bn': 'i32', 'stride_cm': 'i32', 'stride_cn': 'constexpr', 'stride_bs_k': 'constexpr', 'stride_bs_n': 'i32', 'BLOCK_SIZE_M': 'constexpr', 'BLOCK_SIZE_N': 'constexpr', 'BLOCK_SIZE_K': 'constexpr', 'GROUP_SIZE_M': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'stride_ak': 1, 'stride_bk': 1, 'stride_cn': 1, 'stride_bs_k': 1, 'BLOCK_SIZE_M': 16, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'GROUP_SIZE_M': 8}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (10,): [['tt.divisibility', 16]], (11,): [['tt.divisibility', 16]], (14,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def w8a8_block_dynamic_fp8_matmul_kernel(
    A,  # (M, K) raw BF16/FP16 activations
    B,  # (N, K) FP8 weights
    C,  # (M, N) output
    Bs,  # (N // BLOCK_SIZE_N, K // BLOCK_SIZE_K) weight scales (fp32 or uint8/UE8M0)
    # Shape
    M,
    N,
    K,
    # Strides
    stride_am,
    stride_ak,
    stride_bk,
    stride_bn,
    stride_cm,
    stride_cn,
    stride_bs_k,
    stride_bs_n,
    # Meta-parameters
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """Block-scale FP8 GEMM kernel with fused activation quantization.

    Computes ``C = A @ B.T`` with bf16/fp16 ``A`` quantized to FP8 per-K-tile
    inline (one scale per M-row per BLOCK_SIZE_K) and pre-quantized FP8 weights
    with per-block scales. 2D grid with swizzle for L2 cache locality on B.
    """
    pid_m, pid_n, offs_am, offs_bn, offs_k = _swizzle_offsets(
        M, N, BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M
    )
    a_ptrs = A + (offs_am[:, None] * stride_am + offs_k[None, :] * stride_ak)
    b_ptrs = B + (offs_k[:, None] * stride_bk + offs_bn[None, :] * stride_bn)

    offs_bsn = offs_bn // BLOCK_SIZE_N
    bs_ptrs = Bs + offs_bsn * stride_bs_n

    accumulator = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    for k in range(0, tl.cdiv(K, BLOCK_SIZE_K)):
        k_remaining = K - k * BLOCK_SIZE_K
        a_raw = tl.load(a_ptrs, mask=offs_k[None, :] < k_remaining, other=0.0).to(
            tl.float32
        )
        a, a_s = fp8_act_quant_inline(a_raw)
        b = tl.load(b_ptrs, mask=offs_k[:, None] < k_remaining, other=0.0)
        b_s = decode_ue8m0_scale(tl.load(bs_ptrs))
        accumulator += tl.dot(a, b) * a_s[:, None] * b_s[None, :]
        a_ptrs += BLOCK_SIZE_K * stride_ak
        b_ptrs += BLOCK_SIZE_K * stride_bk
        bs_ptrs += stride_bs_k

    _store_masked(
        C,
        accumulator,
        pid_m,
        pid_n,
        M,
        N,
        stride_cm,
        stride_cn,
        BLOCK_SIZE_M,
        BLOCK_SIZE_N,
    )

@triton.jit
def _swizzle_offsets(
    M,
    N,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """2D-grid tile scheduling shared by the kernels below: swizzle the
    ``(pid_m, pid_n)`` program ids for L2 locality on B, then build the operand
    offset vectors. Returns ``(pid_m, pid_n, offs_am, offs_bn, offs_k)`` — the
    swizzled ids (reused by the output store) and the ``%``-wrapped row/col offsets
    plus the K range."""
    pid_m = tl.program_id(axis=0)
    pid_n = tl.program_id(axis=1)
    num_pid_m = tl.cdiv(M, BLOCK_SIZE_M)
    num_pid_n = tl.cdiv(N, BLOCK_SIZE_N)
    pid_m, pid_n = tl.swizzle2d(pid_m, pid_n, num_pid_m, num_pid_n, GROUP_SIZE_M)
    offs_am = (pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)) % M
    offs_bn = (pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)) % N
    offs_k = tl.arange(0, BLOCK_SIZE_K)
    return pid_m, pid_n, offs_am, offs_bn, offs_k

@triton.jit
def fp8_act_quant_inline(a_raw):
    """Inline FP8 (E4M3) activation quant for the W8A8 block-scale path.

    Per-row amax → fp32 scale ``amax/448`` (floored at 1e-12 against zero rows)
    → cast values to FP8. Returns ``(a_fp8, a_s)`` with shapes ``(M, K)`` and
    ``(M,)``.
    """
    a_s = tl.max(tl.abs(a_raw), axis=1) / 448.0
    a_fp8 = (a_raw / tl.maximum(a_s[:, None], 1e-12)).to(tl.float8e4nv)
    return a_fp8, a_s

@triton.jit
def decode_ue8m0_scale(scale):
    """Decode a UE8M0 weight scale to fp32: when it was loaded as ``uint8`` exponent
    bits, ``value = 2^(exp - 127)``, built directly as the fp32 bit pattern. fp32
    scales (block-dynamic with float scales) pass through. The dtype branch is a
    compile-time constant, so only the taken path is emitted (single return — Triton
    requires all ``return`` statements to share a type)."""
    if scale.dtype == tl.uint8:
        scale = (scale.to(tl.int32) << 23).to(tl.float32, bitcast=True)
    return scale

@triton.jit
def _store_masked(
    C,
    accumulator,
    pid_m,
    pid_n,
    M,
    N,
    stride_cm,
    stride_cn,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
):
    """Shared output epilogue of the kernels below: cast the fp32 accumulator to
    ``C``'s dtype and store the ``(BLOCK_SIZE_M, BLOCK_SIZE_N)`` tile at the swizzled
    ``(pid_m, pid_n)``, masked to the ``(M, N)`` bounds."""
    c = accumulator.to(C.dtype.element_ty)
    offs_cm = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_cn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    c_ptrs = C + stride_cm * offs_cm[:, None] + stride_cn * offs_cn[None, :]
    c_mask = (offs_cm[:, None] < M) & (offs_cn[None, :] < N)
    tl.store(c_ptrs, c, mask=c_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-v4-quality-20261031/caches/inductor/nh/cnh4myvc56zfpn4zkws6t45nvqrisnoe77jdjt7lcnrrtky7tf5o.py
# Topologically Sorted Source Nodes: [inputs_embeds, hidden_states_9, hidden_states_13, hidden_states_14, pow_5, variance_4, add_11, rsqrt_4, hidden_states_15, to_13, hidden_states_16], Original ATen: [aten.embedding, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_11 => add_14
#   hidden_states_13 => add_13
#   hidden_states_14 => convert_element_type_18
#   hidden_states_15 => mul_18
#   hidden_states_16 => mul_19
#   hidden_states_9 => add_10
#   inputs_embeds => embedding
#   pow_5 => pow_5
#   rsqrt_4 => rsqrt_4
#   to_13 => convert_element_type_19
#   variance_4 => mean_4
# Graph fragment:
#   %arg0_1 : Tensor "i64[1, 4][4, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %arg1_1 : Tensor "bf16[151936, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %buf34 : Tensor  = PlaceHolder[target=buf34]
#   %buf43 : Tensor  = PlaceHolder[target=buf43]
#   %arg25_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg25_1]
#   %buf44 : Tensor "f32[1, 4, 1][4, 1, 4]tnca:0" = PlaceHolder[target=buf44]
#   %embedding : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg1_1, %arg0_1), kwargs = {})
#   %add_10 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %empty_3), kwargs = {})
#   %add_13 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_10, %empty_6), kwargs = {})
#   %convert_element_type_18 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_13, torch.float32), kwargs = {})
#   %pow_5 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_18, 2), kwargs = {})
#   %mean_4 : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_5, [-1], True), kwargs = {})
#   %add_14 : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_4, 1e-06), kwargs = {})
#   %rsqrt_4 : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_14,), kwargs = {})
#   %mul_18 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_18, %rsqrt_4), kwargs = {})
#   %convert_element_type_19 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_18, torch.bfloat16), kwargs = {})
#   %mul_19 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg25_1, %convert_element_type_19), kwargs = {})
#   return %buf44,%mul_19
triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_17 = async_compile.triton('triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_17', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 4, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_17', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 16, 'r0_': 36864}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_17(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 4
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), None, eviction_policy='evict_last')
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr2, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr3, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp10 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp5 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp0) & (tmp0 < 151936), "index out of bounds: 0 <= tmp0 < 151936")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 2048*tmp0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tmp7 * tmp7
        tmp9 = tl.broadcast_to(tmp8, [R0_BLOCK])
        tmp11 = _tmp10 + tmp9
        _tmp10 = tl.where(r0_mask, tmp11, _tmp10)
    tmp10 = triton_helpers.promote_to_tensor(tl.sum(_tmp10, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr2, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr3, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp12 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp15 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp17 = tl.reshape(tma_descriptor3.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp0) & (tmp0 < 151936), "index out of bounds: 0 <= tmp0 < 151936")
        tmp14 = tl.load(in_ptr1 + (r0_1 + 2048*tmp0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp16 = tmp14 + tmp15
        tmp18 = tmp16 + tmp17
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tl.full([1], 2048.0, tl.float32)
        tmp21 = (tmp10 / tmp20)
        tmp22 = tl.full([1], 1e-06, tl.float32)
        tmp23 = tmp21 + tmp22
        tmp24 = libdevice.rsqrt(tmp23)
        tmp25 = tmp19 * tmp24
        tmp26 = tmp25.to(tl.float32)
        tmp27 = tmp12 * tmp26
        tl.store(out_ptr1 + (r0_1 + 2048*x0), tmp27, r0_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-v4-quality-20261031/caches/inductor/4w/c4woaeucxe6gsdf2lzgykbz3hc4kcvwlkp5y5gsuao3g2wk2ayyo.py
# Topologically Sorted Source Nodes: [inputs_embeds, hidden_states_9, hidden_states_13, hidden_states_23, hidden_states_24, pow_8, variance_7, add_18, rsqrt_7, hidden_states_25, to_19, hidden_states_26, output_11, output_12], Original ATen: [aten.embedding, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_18 => add_23
#   hidden_states_13 => add_13
#   hidden_states_23 => add_22
#   hidden_states_24 => convert_element_type_29
#   hidden_states_25 => mul_30
#   hidden_states_26 => mul_31
#   hidden_states_9 => add_10
#   inputs_embeds => embedding
#   output_11 => triton_kernel_wrapper_mutation_184
#   output_12 => triton_kernel_wrapper_mutation_183
#   pow_8 => pow_8
#   rsqrt_7 => rsqrt_7
#   to_19 => convert_element_type_30
#   variance_7 => mean_7
# Graph fragment:
#   %arg0_1 : Tensor "i64[1, 4][4, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %arg1_1 : Tensor "bf16[151936, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %buf34 : Tensor  = PlaceHolder[target=buf34]
#   %buf43 : Tensor  = PlaceHolder[target=buf43]
#   %buf74 : Tensor  = PlaceHolder[target=buf74]
#   %add_22 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0" = PlaceHolder[target=add_22]
#   %arg39_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg39_1]
#   %buf76 : Tensor "f32[1, 4, 1][4, 1, 4]tnca:0" = PlaceHolder[target=buf76]
#   %embedding : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg1_1, %arg0_1), kwargs = {})
#   %add_10 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %empty_3), kwargs = {})
#   %add_13 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_10, %empty_6), kwargs = {})
#   %add_22 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_13, %empty_10), kwargs = {})
#   %convert_element_type_29 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_22, torch.float32), kwargs = {})
#   %pow_8 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_29, 2), kwargs = {})
#   %mean_7 : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_8, [-1], True), kwargs = {})
#   %add_23 : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_7, 1e-06), kwargs = {})
#   %rsqrt_7 : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_23,), kwargs = {})
#   %mul_30 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_29, %rsqrt_7), kwargs = {})
#   %convert_element_type_30 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_30, torch.bfloat16), kwargs = {})
#   %mul_31 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg39_1, %convert_element_type_30), kwargs = {})
#   %triton_kernel_wrapper_mutation_184 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 991, grid: [(1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1)], tma_descriptor_metadata: {}, kwargs: {A: %mul_31, B: %arg40_1, C: %empty_11, Bs: %arg41_1, M: 4, N: 6144, K: 2048, stride_am: 2048, stride_ak: 1, stride_bk: 1, stride_bn: 2048, stride_cm: 6144, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 16, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   %triton_kernel_wrapper_mutation_183 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 992, grid: [(1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1)], tma_descriptor_metadata: {}, kwargs: {A: %mul_31, B: %arg42_1, C: %empty_12, Bs: %arg43_1, M: 4, N: 6144, K: 2048, stride_am: 2048, stride_ak: 1, stride_bk: 1, stride_bn: 2048, stride_cm: 6144, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 16, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   return %add_22,%buf76,%buf78,%buf81
triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_18 = async_compile.triton('triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_18', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 4, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'in_ptr5': '*bf16', 'out_ptr0': '*bf16', 'out_ptr2': '*bf16', 'out_ptr3': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]], (10,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_18', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 6, 'num_store': 3, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 16, 'r0_': 102400}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_18(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr0, out_ptr2, out_ptr3, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 4
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), None, eviction_policy='evict_last')
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr2, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr3, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr4, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp12 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp5 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp7 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp0) & (tmp0 < 151936), "index out of bounds: 0 <= tmp0 < 151936")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 2048*tmp0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp8 = tmp6 + tmp7
        tmp9 = tmp8.to(tl.float32)
        tmp10 = tmp9 * tmp9
        tmp11 = tl.broadcast_to(tmp10, [R0_BLOCK])
        tmp13 = _tmp12 + tmp11
        _tmp12 = tl.where(r0_mask, tmp13, _tmp12)
        tl.store(out_ptr0 + (r0_1 + 2048*x0), tmp8, r0_mask)
    tmp12 = triton_helpers.promote_to_tensor(tl.sum(_tmp12, 0))
    tma_descriptor3 = tl.make_tensor_descriptor(out_ptr0, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp14 = tl.load(in_ptr5 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tl.debug_barrier()
        tmp15 = tl.reshape(tma_descriptor3.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tl.debug_barrier()
        tmp16 = tmp15.to(tl.float32)
        tmp17 = tl.full([1], 2048.0, tl.float32)
        tmp18 = (tmp12 / tmp17)
        tmp19 = tl.full([1], 1e-06, tl.float32)
        tmp20 = tmp18 + tmp19
        tmp21 = libdevice.rsqrt(tmp20)
        tmp22 = tmp16 * tmp21
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tmp14 * tmp23
        tl.store(out_ptr2 + (r0_1 + 2048*x0), tmp24, r0_mask)
        tl.store(out_ptr3 + (r0_1 + 2048*x0), tmp24, r0_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-v4-quality-20261031/caches/inductor/hw/chwkrdichvazzrjfosuwwh4dcrjsssvy2j3ozkdehalkyiw6m6jh.py
# Topologically Sorted Source Nodes: [hidden_states_27, hidden_states_28, pow_9, variance_8, add_20, rsqrt_8, hidden_states_29, to_21, hidden_states_30, output_14, output_15, output_16], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_20 => add_26
#   hidden_states_27 => add_25
#   hidden_states_28 => convert_element_type_33
#   hidden_states_29 => mul_33
#   hidden_states_30 => mul_34
#   output_14 => triton_kernel_wrapper_mutation_181
#   output_15 => triton_kernel_wrapper_mutation_180
#   output_16 => triton_kernel_wrapper_mutation_179
#   pow_9 => pow_9
#   rsqrt_8 => rsqrt_8
#   to_21 => convert_element_type_34
#   variance_8 => mean_8
# Graph fragment:
#   %add_22 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0" = PlaceHolder[target=add_22]
#   %buf85 : Tensor  = PlaceHolder[target=buf85]
#   %arg46_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg46_1]
#   %buf86 : Tensor "f32[1, 4, 1][4, 1, 4]tnca:0" = PlaceHolder[target=buf86]
#   %add_25 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_22, %empty_13), kwargs = {})
#   %convert_element_type_33 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_25, torch.float32), kwargs = {})
#   %pow_9 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_33, 2), kwargs = {})
#   %mean_8 : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_9, [-1], True), kwargs = {})
#   %add_26 : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_8, 1e-06), kwargs = {})
#   %rsqrt_8 : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_26,), kwargs = {})
#   %mul_33 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_33, %rsqrt_8), kwargs = {})
#   %convert_element_type_34 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_33, torch.bfloat16), kwargs = {})
#   %mul_34 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg46_1, %convert_element_type_34), kwargs = {})
#   %triton_kernel_wrapper_mutation_181 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 994, grid: [(1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1)], tma_descriptor_metadata: {}, kwargs: {A: %mul_34, B: %arg47_1, C: %empty_14, Bs: %arg48_1, M: 4, N: 2048, K: 2048, stride_am: 2048, stride_ak: 1, stride_bk: 1, stride_bn: 2048, stride_cm: 2048, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 16, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   %triton_kernel_wrapper_mutation_180 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 995, grid: [(1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1)], tma_descriptor_metadata: {}, kwargs: {A: %mul_34, B: %arg50_1, C: %empty_15, Bs: %arg51_1, M: 4, N: 1024, K: 2048, stride_am: 2048, stride_ak: 1, stride_bk: 1, stride_bn: 2048, stride_cm: 1024, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 16, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   %triton_kernel_wrapper_mutation_179 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 996, grid: [(1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1)], tma_descriptor_metadata: {}, kwargs: {A: %mul_34, B: %arg53_1, C: %empty_16, Bs: %arg54_1, M: 4, N: 1024, K: 2048, stride_am: 2048, stride_ak: 1, stride_bk: 1, stride_bn: 2048, stride_cm: 1024, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 16, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   return %buf86,%buf88,%buf91,%buf94
triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19 = async_compile.triton('triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 4, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'out_ptr1': '*bf16', 'out_ptr2': '*bf16', 'out_ptr3': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 3, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 118784}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19(in_ptr0, in_ptr1, in_ptr2, out_ptr1, out_ptr2, out_ptr3, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 4
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp6 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp3 * tmp3
        tmp5 = tl.broadcast_to(tmp4, [R0_BLOCK])
        tmp7 = _tmp6 + tmp5
        _tmp6 = tl.where(r0_mask, tmp7, _tmp6)
    tmp6 = triton_helpers.promote_to_tensor(tl.sum(_tmp6, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr0, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr1, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp8 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp9 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp10 = tl.reshape(tma_descriptor3.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp11 = tmp9 + tmp10
        tmp12 = tmp11.to(tl.float32)
        tmp13 = tl.full([1], 2048.0, tl.float32)
        tmp14 = (tmp6 / tmp13)
        tmp15 = tl.full([1], 1e-06, tl.float32)
        tmp16 = tmp14 + tmp15
        tmp17 = libdevice.rsqrt(tmp16)
        tmp18 = tmp12 * tmp17
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tmp8 * tmp19
        tl.store(out_ptr1 + (r0_1 + 2048*x0), tmp20, r0_mask)
        tl.store(out_ptr2 + (r0_1 + 2048*x0), tmp20, r0_mask)
        tl.store(out_ptr3 + (r0_1 + 2048*x0), tmp20, r0_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-v4-quality-20261031/caches/inductor/5e/c5epoug6mq6x6zpwblot4a3tiafz6zmc3ir6slrhilrlrbdynjxw.py
# Topologically Sorted Source Nodes: [hidden_states_27, hidden_states_37, hidden_states_38, pow_12, variance_11, add_27, rsqrt_11, hidden_states_39, to_27, hidden_states_40], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_27 => add_35
#   hidden_states_27 => add_25
#   hidden_states_37 => add_34
#   hidden_states_38 => convert_element_type_44
#   hidden_states_39 => mul_45
#   hidden_states_40 => mul_46
#   pow_12 => pow_12
#   rsqrt_11 => rsqrt_11
#   to_27 => convert_element_type_45
#   variance_11 => mean_11
# Graph fragment:
#   %add_22 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0" = PlaceHolder[target=add_22]
#   %buf85 : Tensor  = PlaceHolder[target=buf85]
#   %buf118 : Tensor  = PlaceHolder[target=buf118]
#   %arg60_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg60_1]
#   %buf119 : Tensor "f32[1, 4, 1][4, 1, 4]tnca:0" = PlaceHolder[target=buf119]
#   %add_25 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_22, %empty_13), kwargs = {})
#   %add_34 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_25, %empty_17), kwargs = {})
#   %convert_element_type_44 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_34, torch.float32), kwargs = {})
#   %pow_12 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_44, 2), kwargs = {})
#   %mean_11 : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_12, [-1], True), kwargs = {})
#   %add_35 : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_11, 1e-06), kwargs = {})
#   %rsqrt_11 : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_35,), kwargs = {})
#   %mul_45 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_44, %rsqrt_11), kwargs = {})
#   %convert_element_type_45 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_45, torch.bfloat16), kwargs = {})
#   %mul_46 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg60_1, %convert_element_type_45), kwargs = {})
#   return %buf119,%mul_46
triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20 = async_compile.triton('triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 4, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 53248}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 4
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr2, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp8 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp3 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tmp5 * tmp5
        tmp7 = tl.broadcast_to(tmp6, [R0_BLOCK])
        tmp9 = _tmp8 + tmp7
        _tmp8 = tl.where(r0_mask, tmp9, _tmp8)
    tmp8 = triton_helpers.promote_to_tensor(tl.sum(_tmp8, 0))
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr0, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor4 = tl.make_tensor_descriptor(in_ptr1, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor5 = tl.make_tensor_descriptor(in_ptr2, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp10 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp11 = tl.reshape(tma_descriptor3.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp12 = tl.reshape(tma_descriptor4.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp14 = tl.reshape(tma_descriptor5.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp13 = tmp11 + tmp12
        tmp15 = tmp13 + tmp14
        tmp16 = tmp15.to(tl.float32)
        tmp17 = tl.full([1], 2048.0, tl.float32)
        tmp18 = (tmp8 / tmp17)
        tmp19 = tl.full([1], 1e-06, tl.float32)
        tmp20 = tmp18 + tmp19
        tmp21 = libdevice.rsqrt(tmp20)
        tmp22 = tmp16 * tmp21
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tmp10 * tmp23
        tl.store(out_ptr1 + (r0_1 + 2048*x0), tmp24, r0_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-v4-quality-20261031/caches/inductor/ed/cedydgrltw4io25nfhbqolzsepf4wltwndrnu7ozx5vndspms6ao.py
# Topologically Sorted Source Nodes: [hidden_states_27, hidden_states_37, hidden_states_41, hidden_states_42, pow_13, variance_12, add_29, rsqrt_12, hidden_states_43, to_29, hidden_states_44], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_29 => add_38
#   hidden_states_27 => add_25
#   hidden_states_37 => add_34
#   hidden_states_41 => add_37
#   hidden_states_42 => convert_element_type_48
#   hidden_states_43 => mul_48
#   hidden_states_44 => mul_49
#   pow_13 => pow_13
#   rsqrt_12 => rsqrt_12
#   to_29 => convert_element_type_49
#   variance_12 => mean_12
# Graph fragment:
#   %add_22 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0" = PlaceHolder[target=add_22]
#   %buf85 : Tensor  = PlaceHolder[target=buf85]
#   %buf118 : Tensor  = PlaceHolder[target=buf118]
#   %buf127 : Tensor  = PlaceHolder[target=buf127]
#   %arg67_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg67_1]
#   %buf128 : Tensor "f32[1, 4, 1][4, 1, 4]tnca:0" = PlaceHolder[target=buf128]
#   %add_25 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_22, %empty_13), kwargs = {})
#   %add_34 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_25, %empty_17), kwargs = {})
#   %add_37 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_34, %empty_20), kwargs = {})
#   %convert_element_type_48 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_37, torch.float32), kwargs = {})
#   %pow_13 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_48, 2), kwargs = {})
#   %mean_12 : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_13, [-1], True), kwargs = {})
#   %add_38 : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_12, 1e-06), kwargs = {})
#   %rsqrt_12 : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_38,), kwargs = {})
#   %mul_48 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_48, %rsqrt_12), kwargs = {})
#   %convert_element_type_49 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_48, torch.bfloat16), kwargs = {})
#   %mul_49 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg67_1, %convert_element_type_49), kwargs = {})
#   return %buf128,%mul_49
triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21 = async_compile.triton('triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 4, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 9, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 53248}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 4
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr2, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr3, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp10 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp3 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp5 = tl.reshape(tma_descriptor3.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tmp7 * tmp7
        tmp9 = tl.broadcast_to(tmp8, [R0_BLOCK])
        tmp11 = _tmp10 + tmp9
        _tmp10 = tl.where(r0_mask, tmp11, _tmp10)
    tmp10 = triton_helpers.promote_to_tensor(tl.sum(_tmp10, 0))
    tma_descriptor4 = tl.make_tensor_descriptor(in_ptr0, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor5 = tl.make_tensor_descriptor(in_ptr1, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor6 = tl.make_tensor_descriptor(in_ptr2, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor7 = tl.make_tensor_descriptor(in_ptr3, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp12 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp13 = tl.reshape(tma_descriptor4.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp14 = tl.reshape(tma_descriptor5.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp16 = tl.reshape(tma_descriptor6.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp18 = tl.reshape(tma_descriptor7.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp15 = tmp13 + tmp14
        tmp17 = tmp15 + tmp16
        tmp19 = tmp17 + tmp18
        tmp20 = tmp19.to(tl.float32)
        tmp21 = tl.full([1], 2048.0, tl.float32)
        tmp22 = (tmp10 / tmp21)
        tmp23 = tl.full([1], 1e-06, tl.float32)
        tmp24 = tmp22 + tmp23
        tmp25 = libdevice.rsqrt(tmp24)
        tmp26 = tmp20 * tmp25
        tmp27 = tmp26.to(tl.float32)
        tmp28 = tmp12 * tmp27
        tl.store(out_ptr1 + (r0_1 + 2048*x0), tmp28, r0_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-v4-quality-20261031/caches/inductor/jz/cjzewfchnhsoefasi4qq34aa3pllkxvjv6sz5wbtqxa7dn6mxodh.py
# Topologically Sorted Source Nodes: [hidden_states_27, hidden_states_37, hidden_states_41, hidden_states_51, hidden_states_52, pow_16, variance_15, add_36, rsqrt_15, hidden_states_53, to_35, hidden_states_54, output_25, output_26], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_36 => add_47
#   hidden_states_27 => add_25
#   hidden_states_37 => add_34
#   hidden_states_41 => add_37
#   hidden_states_51 => add_46
#   hidden_states_52 => convert_element_type_59
#   hidden_states_53 => mul_60
#   hidden_states_54 => mul_61
#   output_25 => triton_kernel_wrapper_mutation_170
#   output_26 => triton_kernel_wrapper_mutation_169
#   pow_16 => pow_16
#   rsqrt_15 => rsqrt_15
#   to_35 => convert_element_type_60
#   variance_15 => mean_15
# Graph fragment:
#   %add_22 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0" = PlaceHolder[target=add_22]
#   %buf85 : Tensor  = PlaceHolder[target=buf85]
#   %buf118 : Tensor  = PlaceHolder[target=buf118]
#   %buf127 : Tensor  = PlaceHolder[target=buf127]
#   %buf158 : Tensor  = PlaceHolder[target=buf158]
#   %add_46 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0" = PlaceHolder[target=add_46]
#   %arg81_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg81_1]
#   %buf160 : Tensor "f32[1, 4, 1][4, 1, 4]tnca:0" = PlaceHolder[target=buf160]
#   %add_25 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_22, %empty_13), kwargs = {})
#   %add_34 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_25, %empty_17), kwargs = {})
#   %add_37 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_34, %empty_20), kwargs = {})
#   %add_46 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_37, %empty_24), kwargs = {})
#   %convert_element_type_59 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_46, torch.float32), kwargs = {})
#   %pow_16 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_59, 2), kwargs = {})
#   %mean_15 : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_16, [-1], True), kwargs = {})
#   %add_47 : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_15, 1e-06), kwargs = {})
#   %rsqrt_15 : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_47,), kwargs = {})
#   %mul_60 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_59, %rsqrt_15), kwargs = {})
#   %convert_element_type_60 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_60, torch.bfloat16), kwargs = {})
#   %mul_61 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg81_1, %convert_element_type_60), kwargs = {})
#   %triton_kernel_wrapper_mutation_170 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 1005, grid: [(1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1)], tma_descriptor_metadata: {}, kwargs: {A: %mul_61, B: %arg82_1, C: %empty_25, Bs: %arg83_1, M: 4, N: 6144, K: 2048, stride_am: 2048, stride_ak: 1, stride_bk: 1, stride_bn: 2048, stride_cm: 6144, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 16, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   %triton_kernel_wrapper_mutation_169 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 1006, grid: [(1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1)], tma_descriptor_metadata: {}, kwargs: {A: %mul_61, B: %arg84_1, C: %empty_26, Bs: %arg85_1, M: 4, N: 6144, K: 2048, stride_am: 2048, stride_ak: 1, stride_bk: 1, stride_bn: 2048, stride_cm: 6144, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 16, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   return %add_46,%buf160,%buf162,%buf165
triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_22 = async_compile.triton('triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_22', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 4, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*bf16', 'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'out_ptr1': '*bf16', 'out_ptr2': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_22', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 7, 'num_store': 3, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 118784}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_22(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, out_ptr2, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 4
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_out_ptr0, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr1, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr2, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor4 = tl.make_tensor_descriptor(in_ptr3, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp12 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp3 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp5 = tl.reshape(tma_descriptor3.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp7 = tl.reshape(tma_descriptor4.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp8 = tmp6 + tmp7
        tmp9 = tmp8.to(tl.float32)
        tmp10 = tmp9 * tmp9
        tmp11 = tl.broadcast_to(tmp10, [R0_BLOCK])
        tmp13 = _tmp12 + tmp11
        _tmp12 = tl.where(r0_mask, tmp13, _tmp12)
        tl.store(in_out_ptr0 + (r0_1 + 2048*x0), tmp8, r0_mask)
    tmp12 = triton_helpers.promote_to_tensor(tl.sum(_tmp12, 0))
    tma_descriptor5 = tl.make_tensor_descriptor(in_out_ptr0, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp14 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tl.debug_barrier()
        tmp15 = tl.reshape(tma_descriptor5.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tl.debug_barrier()
        tmp16 = tmp15.to(tl.float32)
        tmp17 = tl.full([1], 2048.0, tl.float32)
        tmp18 = (tmp12 / tmp17)
        tmp19 = tl.full([1], 1e-06, tl.float32)
        tmp20 = tmp18 + tmp19
        tmp21 = libdevice.rsqrt(tmp20)
        tmp22 = tmp16 * tmp21
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tmp14 * tmp23
        tl.store(out_ptr1 + (r0_1 + 2048*x0), tmp24, r0_mask)
        tl.store(out_ptr2 + (r0_1 + 2048*x0), tmp24, r0_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-v4-quality-20261031/caches/inductor/i5/ci5fkxhzxn4kllnwbo6grsjc526jgymvoryjucv3qkqvsgf5bold.py
# Topologically Sorted Source Nodes: [hidden_states_391, hidden_states_392, pow_113, variance_112, add_254, rsqrt_112, hidden_states_393, to_229, hidden_states_394], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_254 => add_338
#   hidden_states_391 => add_337
#   hidden_states_392 => convert_element_type_423
#   hidden_states_393 => mul_423
#   hidden_states_394 => mul_424
#   pow_113 => pow_113
#   rsqrt_112 => rsqrt_112
#   to_229 => convert_element_type_424
#   variance_112 => mean_112
# Graph fragment:
#   %add_334 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0" = PlaceHolder[target=add_334]
#   %buf1177 : Tensor  = PlaceHolder[target=buf1177]
#   %arg592_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg592_1]
#   %buf1178 : Tensor "f32[1, 4, 1][4, 1, 4]tnca:0" = PlaceHolder[target=buf1178]
#   %add_337 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_334, %empty_195), kwargs = {})
#   %convert_element_type_423 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_337, torch.float32), kwargs = {})
#   %pow_113 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_423, 2), kwargs = {})
#   %mean_112 : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_113, [-1], True), kwargs = {})
#   %add_338 : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_112, 1e-06), kwargs = {})
#   %rsqrt_112 : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_338,), kwargs = {})
#   %mul_423 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_423, %rsqrt_112), kwargs = {})
#   %convert_element_type_424 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_423, torch.bfloat16), kwargs = {})
#   %mul_424 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg592_1, %convert_element_type_424), kwargs = {})
#   return %buf1178,%mul_424
triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_23 = async_compile.triton('triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_23', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 4, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*bf16', 'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_23', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 53248}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_23(in_out_ptr0, in_ptr0, in_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 4
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_out_ptr0, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp6 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp3 * tmp3
        tmp5 = tl.broadcast_to(tmp4, [R0_BLOCK])
        tmp7 = _tmp6 + tmp5
        _tmp6 = tl.where(r0_mask, tmp7, _tmp6)
    tmp6 = triton_helpers.promote_to_tensor(tl.sum(_tmp6, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_out_ptr0, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr0, shape=[4, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp8 = tl.load(in_ptr1 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp9 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp10 = tl.reshape(tma_descriptor3.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp11 = tmp9 + tmp10
        tmp12 = tmp11.to(tl.float32)
        tmp13 = tl.full([1], 2048.0, tl.float32)
        tmp14 = (tmp6 / tmp13)
        tmp15 = tl.full([1], 1e-06, tl.float32)
        tmp16 = tmp14 + tmp15
        tmp17 = libdevice.rsqrt(tmp16)
        tmp18 = tmp12 * tmp17
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tmp8 * tmp19
        tl.store(in_out_ptr0 + (r0_1 + 2048*x0), tmp20, r0_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-v4-quality-20261031/caches/inductor/oc/cocxvkkbsrtrixkgl2py2nts36kroedlbsyhkf2mkqbznbhcnjnr.py
# Topologically Sorted Source Nodes: [hidden_states_391, hidden_states_392, pow_113, variance_112, add_254, rsqrt_112, hidden_states_393, to_229, hidden_states_394, getitem_181, logits], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.slice, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   add_254 => add_338
#   getitem_181 => slice_130
#   hidden_states_391 => add_337
#   hidden_states_392 => convert_element_type_423
#   hidden_states_393 => mul_423
#   hidden_states_394 => mul_424
#   logits => mm, permute_224, view_450
#   pow_113 => pow_113
#   rsqrt_112 => rsqrt_112
#   to_229 => convert_element_type_424
#   variance_112 => mean_112
# Graph fragment:
#   %mul_424 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0" = PlaceHolder[target=mul_424]
#   %arg593_1 : Tensor "bf16[151936, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg593_1]
#   %add_337 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_334, %empty_195), kwargs = {})
#   %convert_element_type_423 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_337, torch.float32), kwargs = {})
#   %pow_113 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_423, 2), kwargs = {})
#   %mean_112 : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_113, [-1], True), kwargs = {})
#   %add_338 : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_112, 1e-06), kwargs = {})
#   %rsqrt_112 : Tensor "f32[1, 4, 1][4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_338,), kwargs = {})
#   %mul_423 : Tensor "f32[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_423, %rsqrt_112), kwargs = {})
#   %convert_element_type_424 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_423, torch.bfloat16), kwargs = {})
#   %mul_424 : Tensor "bf16[1, 4, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg592_1, %convert_element_type_424), kwargs = {})
#   %slice_130 : Tensor "bf16[1, 1, 2048][8192, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%mul_424, 1, -1, 9223372036854775807), kwargs = {})
#   %view_450 : Tensor "bf16[1, 2048][8192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%slice_130, [1, 2048]), kwargs = {})
#   %permute_224 : Tensor "bf16[2048, 151936][1, 2048]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg593_1, [1, 0]), kwargs = {})
#   %mm : Tensor "bf16[1, 151936][151936, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_450, %permute_224), kwargs = {})
#   return %mm
triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_slice_t_view_24 = async_compile.triton('triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_slice_t_view_24', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*bf16', 'arg_B': '*bf16', 'out_ptr0': '*bf16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_slice_t_view_24', 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_slice_t_view_24(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A + 6144
    B = arg_B

    M = 1
    N = 151936
    K = 2048
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 0
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2048

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2048*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 151936*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2048*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 151936*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-v4-quality-20261031/caches/inductor/u3/cu3mwrcisu7xhrjzjmm4us2yh2pkhn5e3w6nfiwphj7qkcn5e4gw.py
# Topologically Sorted Source Nodes: [add_], Original ATen: [aten.add, aten.copy_]
# Source node to ATen node mapping:
#   add_ => add_8
# Graph fragment:
#   %copy_ : Tensor "i64[][]tnca:0" = PlaceHolder[target=copy_]
#   %add_8 : Tensor "i64[][]tnca:0" = PlaceHolder[target=add_8]
#   %buf20 : Tensor "bf16[1, 8, 256, 128][262144, 32768, 128, 1]tnca:0" = PlaceHolder[target=buf20]
#   %any_1 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=any_1]
#   %amax : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=amax]
#   %exp : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=exp]
#   %buf28 : Tensor "bf16[1, 8, 256, 128][262144, 32768, 128, 1]tnca:0" = PlaceHolder[target=buf28]
#   %any_2 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=any_2]
#   %amax_1 : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=amax_1]
#   %exp_2 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=exp_2]
#   %any_3 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=any_3]
#   %amax_2 : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=amax_2]
#   %exp_4 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=exp_4]
#   %any_4 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=any_4]
#   %amax_3 : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=amax_3]
#   %exp_6 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=exp_6]
#   %any_5 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=any_5]
#   %amax_4 : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=amax_4]
#   %exp_8 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=exp_8]
#   %any_6 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=any_6]
#   %amax_5 : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=amax_5]
#   %exp_10 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=exp_10]
#   %any_7 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=any_7]
#   %amax_6 : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=amax_6]
#   %exp_12 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=exp_12]
#   %any_8 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=any_8]
#   %amax_7 : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=amax_7]
#   %exp_14 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=exp_14]
#   %any_9 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=any_9]
#   %amax_8 : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=amax_8]
#   %exp_16 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=exp_16]
#   %any_10 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=any_10]
#   %amax_9 : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=amax_9]
#   %exp_18 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=exp_18]
#   %any_11 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=any_11]
#   %amax_10 : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=amax_10]
#   %exp_20 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=exp_20]
#   %any_12 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=any_12]
#   %amax_11 : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=amax_11]
#   %exp_22 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=exp_22]
#   %any_13 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=any_13]
#   %amax_12 : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=amax_12]
#   %exp_24 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=exp_24]
#   %any_14 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=any_14]
#   %amax_13 : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=amax_13]
#   %exp_26 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=exp_26]
#   %any_15 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=any_15]
#   %amax_14 : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=amax_14]
#   %exp_28 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=exp_28]
#   %any_16 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=any_16]
#   %amax_15 : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=amax_15]
#   %exp_30 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=exp_30]
#   %any_17 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=any_17]
#   %amax_16 : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=amax_16]
#   %exp_32 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=exp_32]
#   %any_18 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=any_18]
#   %amax_17 : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=amax_17]
#   %exp_34 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=exp_34]
#   %any_19 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=any_19]
#   %amax_18 : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=amax_18]
#   %exp_36 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=exp_36]
#   %any_20 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=any_20]
#   %amax_19 : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=amax_19]
#   %exp_38 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=exp_38]
#   %any_21 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=any_21]
#   %amax_20 : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=amax_20]
#   %exp_40 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=exp_40]
#   %any_22 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=any_22]
#   %amax_21 : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=amax_21]
#   %exp_42 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=exp_42]
#   %any_23 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=any_23]
#   %amax_22 : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=amax_22]
#   %exp_44 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=exp_44]
#   %any_24 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=any_24]
#   %amax_23 : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=amax_23]
#   %exp_46 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=exp_46]
#   %any_25 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=any_25]
#   %amax_24 : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=amax_24]
#   %exp_48 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=exp_48]
#   %any_26 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=any_26]
#   %amax_25 : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=amax_25]
#   %exp_50 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=exp_50]
#   %any_27 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=any_27]
#   %amax_26 : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=amax_26]
#   %exp_52 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=exp_52]
#   %any_28 : Tensor "b8[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=any_28]
#   %amax_27 : Tensor "f32[1, 16, 4, 1][64, 4, 1, 64]tnca:0" = PlaceHolder[target=amax_27]
#   %exp_54 : Tensor "f32[1, 16, 4, 256][16384, 1024, 256, 1]tnca:0" = PlaceHolder[target=exp_54]
#   %add_8 : Tensor "i64[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%arg3_1, 4), kwargs = {})
#   %copy_ : Tensor "i64[][]tnca:0"[num_users=0] = call_function[target=torch.ops.aten.copy_.default](args = (%arg3_1, %add_8), kwargs = {})
#   return %add_8,%buf1325
triton_poi_fused_add_copy__25 = async_compile.triton('triton_poi_fused_add_copy__25', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'out_ptr1': '*i64', 'xnumel': 'constexpr', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_add_copy__25', 'mutated_arg_names': ['in_ptr0', 'out_ptr1'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_copy__25(in_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK])
    tmp2 = tl.full([1], 4, tl.int64)
    tmp3 = tmp1 + tmp2
    tl.store(out_ptr1 + (tl.full([XBLOCK], 0, tl.int32).broadcast_to(XBLOCK)), tmp3, None)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1, arg123_1, arg124_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg132_1, arg133_1, arg134_1, arg135_1, arg136_1, arg137_1, arg138_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg146_1, arg147_1, arg148_1, arg149_1, arg150_1, arg151_1, arg152_1, arg153_1, arg154_1, arg155_1, arg156_1, arg157_1, arg158_1, arg159_1, arg160_1, arg161_1, arg162_1, arg163_1, arg164_1, arg165_1, arg166_1, arg167_1, arg168_1, arg169_1, arg170_1, arg171_1, arg172_1, arg173_1, arg174_1, arg175_1, arg176_1, arg177_1, arg178_1, arg179_1, arg180_1, arg181_1, arg182_1, arg183_1, arg184_1, arg185_1, arg186_1, arg187_1, arg188_1, arg189_1, arg190_1, arg191_1, arg192_1, arg193_1, arg194_1, arg195_1, arg196_1, arg197_1, arg198_1, arg199_1, arg200_1, arg201_1, arg202_1, arg203_1, arg204_1, arg205_1, arg206_1, arg207_1, arg208_1, arg209_1, arg210_1, arg211_1, arg212_1, arg213_1, arg214_1, arg215_1, arg216_1, arg217_1, arg218_1, arg219_1, arg220_1, arg221_1, arg222_1, arg223_1, arg224_1, arg225_1, arg226_1, arg227_1, arg228_1, arg229_1, arg230_1, arg231_1, arg232_1, arg233_1, arg234_1, arg235_1, arg236_1, arg237_1, arg238_1, arg239_1, arg240_1, arg241_1, arg242_1, arg243_1, arg244_1, arg245_1, arg246_1, arg247_1, arg248_1, arg249_1, arg250_1, arg251_1, arg252_1, arg253_1, arg254_1, arg255_1, arg256_1, arg257_1, arg258_1, arg259_1, arg260_1, arg261_1, arg262_1, arg263_1, arg264_1, arg265_1, arg266_1, arg267_1, arg268_1, arg269_1, arg270_1, arg271_1, arg272_1, arg273_1, arg274_1, arg275_1, arg276_1, arg277_1, arg278_1, arg279_1, arg280_1, arg281_1, arg282_1, arg283_1, arg284_1, arg285_1, arg286_1, arg287_1, arg288_1, arg289_1, arg290_1, arg291_1, arg292_1, arg293_1, arg294_1, arg295_1, arg296_1, arg297_1, arg298_1, arg299_1, arg300_1, arg301_1, arg302_1, arg303_1, arg304_1, arg305_1, arg306_1, arg307_1, arg308_1, arg309_1, arg310_1, arg311_1, arg312_1, arg313_1, arg314_1, arg315_1, arg316_1, arg317_1, arg318_1, arg319_1, arg320_1, arg321_1, arg322_1, arg323_1, arg324_1, arg325_1, arg326_1, arg327_1, arg328_1, arg329_1, arg330_1, arg331_1, arg332_1, arg333_1, arg334_1, arg335_1, arg336_1, arg337_1, arg338_1, arg339_1, arg340_1, arg341_1, arg342_1, arg343_1, arg344_1, arg345_1, arg346_1, arg347_1, arg348_1, arg349_1, arg350_1, arg351_1, arg352_1, arg353_1, arg354_1, arg355_1, arg356_1, arg357_1, arg358_1, arg359_1, arg360_1, arg361_1, arg362_1, arg363_1, arg364_1, arg365_1, arg366_1, arg367_1, arg368_1, arg369_1, arg370_1, arg371_1, arg372_1, arg373_1, arg374_1, arg375_1, arg376_1, arg377_1, arg378_1, arg379_1, arg380_1, arg381_1, arg382_1, arg383_1, arg384_1, arg385_1, arg386_1, arg387_1, arg388_1, arg389_1, arg390_1, arg391_1, arg392_1, arg393_1, arg394_1, arg395_1, arg396_1, arg397_1, arg398_1, arg399_1, arg400_1, arg401_1, arg402_1, arg403_1, arg404_1, arg405_1, arg406_1, arg407_1, arg408_1, arg409_1, arg410_1, arg411_1, arg412_1, arg413_1, arg414_1, arg415_1, arg416_1, arg417_1, arg418_1, arg419_1, arg420_1, arg421_1, arg422_1, arg423_1, arg424_1, arg425_1, arg426_1, arg427_1, arg428_1, arg429_1, arg430_1, arg431_1, arg432_1, arg433_1, arg434_1, arg435_1, arg436_1, arg437_1, arg438_1, arg439_1, arg440_1, arg441_1, arg442_1, arg443_1, arg444_1, arg445_1, arg446_1, arg447_1, arg448_1, arg449_1, arg450_1, arg451_1, arg452_1, arg453_1, arg454_1, arg455_1, arg456_1, arg457_1, arg458_1, arg459_1, arg460_1, arg461_1, arg462_1, arg463_1, arg464_1, arg465_1, arg466_1, arg467_1, arg468_1, arg469_1, arg470_1, arg471_1, arg472_1, arg473_1, arg474_1, arg475_1, arg476_1, arg477_1, arg478_1, arg479_1, arg480_1, arg481_1, arg482_1, arg483_1, arg484_1, arg485_1, arg486_1, arg487_1, arg488_1, arg489_1, arg490_1, arg491_1, arg492_1, arg493_1, arg494_1, arg495_1, arg496_1, arg497_1, arg498_1, arg499_1, arg500_1, arg501_1, arg502_1, arg503_1, arg504_1, arg505_1, arg506_1, arg507_1, arg508_1, arg509_1, arg510_1, arg511_1, arg512_1, arg513_1, arg514_1, arg515_1, arg516_1, arg517_1, arg518_1, arg519_1, arg520_1, arg521_1, arg522_1, arg523_1, arg524_1, arg525_1, arg526_1, arg527_1, arg528_1, arg529_1, arg530_1, arg531_1, arg532_1, arg533_1, arg534_1, arg535_1, arg536_1, arg537_1, arg538_1, arg539_1, arg540_1, arg541_1, arg542_1, arg543_1, arg544_1, arg545_1, arg546_1, arg547_1, arg548_1, arg549_1, arg550_1, arg551_1, arg552_1, arg553_1, arg554_1, arg555_1, arg556_1, arg557_1, arg558_1, arg559_1, arg560_1, arg561_1, arg562_1, arg563_1, arg564_1, arg565_1, arg566_1, arg567_1, arg568_1, arg569_1, arg570_1, arg571_1, arg572_1, arg573_1, arg574_1, arg575_1, arg576_1, arg577_1, arg578_1, arg579_1, arg580_1, arg581_1, arg582_1, arg583_1, arg584_1, arg585_1, arg586_1, arg587_1, arg588_1, arg589_1, arg590_1, arg591_1, arg592_1, arg593_1 = args
        args.clear()
        assert_size_stride_grouped((arg2_1, arg4_1), ((4, 1, 4), (64, )), ((4, 4, 1), (1, )), 'input')
        buf0 = empty_strided((3, 1, 4, 64), (256, 768, 64, 1), device='tnca', dtype=torch.float32)
        buf1 = empty_strided((3, 1, 4, 64), (256, 768, 64, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [position_ids, position_ids_1, getitem_6, float_1, freqs, sin_1, getitem_8, cos_1, getitem_11], Original ATen: [aten.slice, aten.expand, aten.unsqueeze, aten._to_copy, aten.mul, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_0.run(arg2_1, arg4_1, buf0, buf1, 768, stream=raw_stream0)
        del arg2_1
        del arg4_1
        assert_size_stride_grouped((arg0_1, arg1_1, arg5_1), ((1, 4), (151936, 2048), (2048, )), ((4, 1), (2048, 1), (1, )), 'input')
        buf4 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        buf7 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        buf10 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [inputs_embeds, hidden_states, pow_1, variance, add_2, rsqrt, hidden_states_1, to_5, hidden_states_2, output, output_1, output_2], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_1.run(arg0_1, arg1_1, arg5_1, buf4, buf7, buf10, 4, 2048, stream=raw_stream0)
        del arg5_1
        buf3 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg6_1, arg7_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [inputs_embeds, hidden_states, pow_1, variance, add_2, rsqrt, hidden_states_1, to_5, hidden_states_2, output], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf4, arg6_1, buf3, arg7_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg6_1
        del arg7_1
        buf6 = empty_strided((1, 4, 1024), (4096, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg9_1, arg10_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [inputs_embeds, hidden_states, pow_1, variance, add_2, rsqrt, hidden_states_1, to_5, hidden_states_2, output_1], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf7, arg9_1, buf6, arg10_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg10_1
        del arg9_1
        buf9 = empty_strided((1, 4, 1024), (4096, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg12_1, arg13_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [inputs_embeds, hidden_states, pow_1, variance, add_2, rsqrt, hidden_states_1, to_5, hidden_states_2, output_2], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf10, arg12_1, buf9, arg13_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg12_1
        del arg13_1
        buf12 = empty_strided((1, 4, 16, 1), (64, 16, 1, 64), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_3, pow_2, variance_1], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf3, buf12, 64, 128, stream=raw_stream0)
        assert_size_stride(arg8_1, (128, ), (1, ), 'input')
        buf15 = reinterpret_tensor(buf10, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf10  # reuse
        buf13 = reinterpret_tensor(buf15, (1, 16, 4, 64), (8192, 512, 128, 1), 0)  # alias
        buf14 = reinterpret_tensor(buf15, (1, 16, 4, 64), (8192, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_3, pow_2, variance_1, add_3, rsqrt_1, hidden_states_4, to_7, mul_6, query_states, x2, neg, x1, cat_2], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg8_1, buf3, buf12, buf13, buf14, 4096, stream=raw_stream0)
        buf16 = empty_strided((1, 4, 8, 1), (32, 8, 1, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_5, pow_3, variance_2], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf6, buf16, 32, 128, stream=raw_stream0)
        del buf13
        del buf14
        assert_size_stride(arg11_1, (128, ), (1, ), 'input')
        buf19 = empty_strided((1, 8, 4, 128), (4096, 512, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf17 = reinterpret_tensor(buf19, (1, 8, 4, 64), (4096, 512, 128, 1), 0)  # alias
        buf18 = reinterpret_tensor(buf19, (1, 8, 4, 64), (4096, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_5, pow_3, variance_2, add_4, rsqrt_2, hidden_states_6, to_9, mul_8, key_states, x2_1, neg_1, x1_1, cat_3], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg11_1, buf6, buf16, buf17, buf18, 2048, stream=raw_stream0)
        assert_size_stride_grouped((arg3_1, arg14_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, cos_4, setitem_1, sin_2, sin_3, sin_4, arange_4, cache_position, hidden_states_5, pow_3, variance_2, add_4, rsqrt_2, hidden_states_6, to_9, mul_8, key_states, mul_11, mul_12, k_embed, index_copy_], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg3_1, arg11_1, buf6, buf16, buf1, buf19, buf0, arg14_1, 4096, stream=raw_stream0)
        del arg11_1
        del buf16
        del buf17
        del buf18
        del buf19
        del buf6
        buf21 = empty_strided((1, 16, 4, 128), (8192, 512, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_3, pow_2, variance_1, add_3, rsqrt_1, hidden_states_4, to_7, mul_6, query_states, setitem_3, cos_2, cos_3, cos_4, mul_9, setitem_1, sin_2, sin_3, sin_4, mul_10, q_embed, attn_output], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.select, aten.slice, aten.cat, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg8_1, buf3, buf12, buf1, buf15, buf0, buf21, 8192, stream=raw_stream0)
        del arg8_1
        del buf12
        buf22 = empty_strided((1, 16, 128, 256), (524288, 32768, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [key, attn_output], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8.run(arg14_1, buf22, 524288, stream=raw_stream0)
        del arg14_1
        buf23 = empty_strided((16, 4, 256), (1024, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_3, pow_2, variance_1, add_3, rsqrt_1, hidden_states_4, to_7, mul_6, query_states, setitem_3, cos_2, cos_3, cos_4, mul_9, setitem_1, sin_2, sin_3, sin_4, mul_10, q_embed, attn_output, key], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.select, aten.slice, aten.cat, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9.run(buf21, buf22, buf23, 16, 16, 1, stream=raw_stream0)
        del buf22
        buf26 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        buf29 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [attn_output, kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10.run(buf23, arg3_1, buf26, buf29, 64, 256, stream=raw_stream0)
        del buf23
        del buf26
        assert_size_stride(arg15_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_4, cache_position, index_copy__1], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_11.run(arg3_1, buf9, arg15_1, 4096, stream=raw_stream0)
        buf30 = empty_strided((1, 16, 256, 128), (524288, 32768, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [value, attn_output], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(arg15_1, buf30, 524288, stream=raw_stream0)
        del arg15_1
        buf31 = reinterpret_tensor(buf21, (16, 4, 128), (512, 128, 1), 0); del buf21  # reuse
        # Topologically Sorted Source Nodes: [attn_output, value], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13.run(buf29, buf30, buf31, 8, 16, 1, stream=raw_stream0)
        del buf30
        buf32 = buf3; del buf3  # reuse
        buf33 = reinterpret_tensor(buf15, (1, 4, 2048), (2048, 2048, 1), 0); del buf15  # reuse
        # Topologically Sorted Source Nodes: [attn_output, transpose_3, reshape_2, output_3], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14.run(buf31, buf33, 8192, stream=raw_stream0)
        assert_size_stride_grouped((arg16_1, arg17_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output, transpose_3, reshape_2, output_3], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf33, arg16_1, buf32, arg17_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg16_1
        del arg17_1
        assert_size_stride(arg18_1, (2048, ), (1, ), 'input')
        buf36 = reinterpret_tensor(buf33, (1, 4, 2048), (8192, 2048, 1), 0); del buf33  # reuse
        # Topologically Sorted Source Nodes: [inputs_embeds, hidden_states_9, hidden_states_10, pow_4, variance_3, add_9, rsqrt_3, hidden_states_11, to_11, hidden_states_12], Original ATen: [aten.embedding, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_15.run(arg0_1, arg1_1, buf32, arg18_1, buf36, 4, 2048, stream=raw_stream0)
        del arg18_1
        buf37 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg19_1, arg20_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_4], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf36, arg19_1, buf37, arg20_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg19_1
        del arg20_1
        buf39 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg21_1, arg22_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_5], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf36, arg21_1, buf39, arg22_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg21_1
        del arg22_1
        buf41 = buf36; del buf36  # reuse
        buf42 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu, mul_15, output_6], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_16.run(buf37, buf39, buf42, 24576, stream=raw_stream0)
        del buf37
        del buf39
        assert_size_stride_grouped((arg23_1, arg24_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu, mul_15, output_6], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf42, arg23_1, buf41, arg24_1, 4, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg23_1
        del arg24_1
        del buf42
        assert_size_stride(arg25_1, (2048, ), (1, ), 'input')
        buf45 = buf7; del buf7  # reuse
        # Topologically Sorted Source Nodes: [inputs_embeds, hidden_states_9, hidden_states_13, hidden_states_14, pow_5, variance_4, add_11, rsqrt_4, hidden_states_15, to_13, hidden_states_16], Original ATen: [aten.embedding, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_17.run(arg0_1, arg1_1, buf32, buf41, arg25_1, buf45, 4, 2048, stream=raw_stream0)
        del arg25_1
        buf46 = buf4; del buf4  # reuse
        assert_size_stride_grouped((arg26_1, arg27_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_7], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf45, arg26_1, buf46, arg27_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg26_1
        del arg27_1
        buf48 = buf9; del buf9  # reuse
        assert_size_stride_grouped((arg29_1, arg30_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_8], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf45, arg29_1, buf48, arg30_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg29_1
        del arg30_1
        buf50 = empty_strided((1, 4, 1024), (4096, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg32_1, arg33_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_9], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf45, arg32_1, buf50, arg33_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg32_1
        del arg33_1
        buf52 = empty_strided((1, 4, 16, 1), (64, 16, 1, 64), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_17, pow_6, variance_5], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf46, buf52, 64, 128, stream=raw_stream0)
        assert_size_stride(arg28_1, (128, ), (1, ), 'input')
        buf55 = reinterpret_tensor(buf45, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf45  # reuse
        buf53 = reinterpret_tensor(buf55, (1, 16, 4, 64), (8192, 512, 128, 1), 0)  # alias
        buf54 = reinterpret_tensor(buf55, (1, 16, 4, 64), (8192, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_17, pow_6, variance_5, add_12, rsqrt_5, hidden_states_18, to_15, mul_19, query_states_1, x2_2, neg_2, x1_2, cat_4], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg28_1, buf46, buf52, buf53, buf54, 4096, stream=raw_stream0)
        buf56 = empty_strided((1, 4, 8, 1), (32, 8, 1, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_19, pow_7, variance_6], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf48, buf56, 32, 128, stream=raw_stream0)
        del buf53
        del buf54
        assert_size_stride(arg31_1, (128, ), (1, ), 'input')
        buf59 = empty_strided((1, 8, 4, 128), (4096, 512, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf57 = reinterpret_tensor(buf59, (1, 8, 4, 64), (4096, 512, 128, 1), 0)  # alias
        buf58 = reinterpret_tensor(buf59, (1, 8, 4, 64), (4096, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_19, pow_7, variance_6, add_13, rsqrt_6, hidden_states_20, to_17, mul_21, key_states_1, x2_3, neg_3, x1_3, cat_5], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg31_1, buf48, buf56, buf57, buf58, 2048, stream=raw_stream0)
        assert_size_stride_grouped((arg34_1, arg35_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_5, sin_5, arange_5, cache_position_1, hidden_states_19, pow_7, variance_6, add_13, rsqrt_6, hidden_states_20, to_17, mul_21, key_states_1, mul_24, mul_25, k_embed_1, index_copy__2], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg34_1, arg31_1, buf48, buf56, buf1, buf59, buf0, arg35_1, 4096, stream=raw_stream0)
        del arg31_1
        del buf48
        del buf56
        del buf57
        del buf58
        del buf59
        buf61 = reinterpret_tensor(buf31, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf31  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_17, pow_6, variance_5, add_12, rsqrt_5, hidden_states_18, to_15, mul_19, query_states_1, cos_5, mul_22, sin_5, mul_23, q_embed_1, attn_output_3], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg28_1, buf46, buf52, buf1, buf55, buf0, buf61, 8192, stream=raw_stream0)
        del arg28_1
        del buf52
        buf62 = empty_strided((1, 16, 128, 256), (524288, 32768, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [key_1, attn_output_3], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8.run(arg35_1, buf62, 524288, stream=raw_stream0)
        del arg35_1
        buf63 = reinterpret_tensor(buf29, (16, 4, 256), (1024, 256, 1), 0); del buf29  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_17, pow_6, variance_5, add_12, rsqrt_5, hidden_states_18, to_15, mul_19, query_states_1, cos_5, mul_22, sin_5, mul_23, q_embed_1, attn_output_3, key_1], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9.run(buf61, buf62, buf63, 16, 16, 1, stream=raw_stream0)
        del buf62
        buf66 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        buf69 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_3], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10.run(buf63, arg3_1, buf66, buf69, 64, 256, stream=raw_stream0)
        del buf63
        del buf66
        assert_size_stride(arg36_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_5, cache_position_1, index_copy__3], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_11.run(arg34_1, buf50, arg36_1, 4096, stream=raw_stream0)
        buf70 = empty_strided((1, 16, 256, 128), (524288, 32768, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [value_1, attn_output_3], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(arg36_1, buf70, 524288, stream=raw_stream0)
        del arg36_1
        buf71 = reinterpret_tensor(buf61, (16, 4, 128), (512, 128, 1), 0); del buf61  # reuse
        # Topologically Sorted Source Nodes: [attn_output_3, value_1], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13.run(buf69, buf70, buf71, 8, 16, 1, stream=raw_stream0)
        del buf70
        buf72 = reinterpret_tensor(buf55, (1, 4, 2048), (8192, 2048, 1), 0); del buf55  # reuse
        buf73 = reinterpret_tensor(buf46, (1, 4, 2048), (2048, 2048, 1), 0); del buf46  # reuse
        # Topologically Sorted Source Nodes: [attn_output_3, transpose_7, reshape_5, output_10], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14.run(buf71, buf73, 8192, stream=raw_stream0)
        assert_size_stride_grouped((arg37_1, arg38_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_3, transpose_7, reshape_5, output_10], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf73, arg37_1, buf72, arg38_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg37_1
        del arg38_1
        assert_size_stride(arg39_1, (2048, ), (1, ), 'input')
        buf75 = reinterpret_tensor(buf73, (1, 4, 2048), (8192, 2048, 1), 0); del buf73  # reuse
        buf78 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        buf81 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [inputs_embeds, hidden_states_9, hidden_states_13, hidden_states_23, hidden_states_24, pow_8, variance_7, add_18, rsqrt_7, hidden_states_25, to_19, hidden_states_26, output_11, output_12], Original ATen: [aten.embedding, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_18.run(arg0_1, arg1_1, buf32, buf41, buf72, arg39_1, buf75, buf78, buf81, 4, 2048, stream=raw_stream0)
        del arg0_1
        del arg1_1
        del arg39_1
        buf77 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg40_1, arg41_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_24, pow_8, variance_7, add_18, rsqrt_7, hidden_states_25, to_19, hidden_states_26, output_11], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf78, arg40_1, buf77, arg41_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg40_1
        del arg41_1
        buf80 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg42_1, arg43_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_24, pow_8, variance_7, add_18, rsqrt_7, hidden_states_25, to_19, hidden_states_26, output_12], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf81, arg42_1, buf80, arg43_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg42_1
        del arg43_1
        buf83 = buf81; del buf81  # reuse
        buf84 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu_1, mul_28, output_13], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_16.run(buf77, buf80, buf84, 24576, stream=raw_stream0)
        del buf77
        del buf80
        assert_size_stride_grouped((arg44_1, arg45_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_1, mul_28, output_13], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf84, arg44_1, buf83, arg45_1, 4, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg44_1
        del arg45_1
        del buf84
        assert_size_stride(arg46_1, (2048, ), (1, ), 'input')
        buf88 = buf78; del buf78  # reuse
        buf91 = buf72; del buf72  # reuse
        buf94 = buf41; del buf41  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_27, hidden_states_28, pow_9, variance_8, add_20, rsqrt_8, hidden_states_29, to_21, hidden_states_30, output_14, output_15, output_16], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19.run(buf75, buf83, arg46_1, buf88, buf91, buf94, 4, 2048, stream=raw_stream0)
        del arg46_1
        buf87 = buf32; del buf32  # reuse
        assert_size_stride_grouped((arg47_1, arg48_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_27, hidden_states_28, pow_9, variance_8, add_20, rsqrt_8, hidden_states_29, to_21, hidden_states_30, output_14], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf88, arg47_1, buf87, arg48_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg47_1
        del arg48_1
        del buf88
        buf90 = buf50; del buf50  # reuse
        assert_size_stride_grouped((arg50_1, arg51_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_27, hidden_states_28, pow_9, variance_8, add_20, rsqrt_8, hidden_states_29, to_21, hidden_states_30, output_15], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf91, arg50_1, buf90, arg51_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg50_1
        del arg51_1
        del buf91
        buf93 = empty_strided((1, 4, 1024), (4096, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg53_1, arg54_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_27, hidden_states_28, pow_9, variance_8, add_20, rsqrt_8, hidden_states_29, to_21, hidden_states_30, output_16], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf94, arg53_1, buf93, arg54_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg53_1
        del arg54_1
        buf96 = empty_strided((1, 4, 16, 1), (64, 16, 1, 64), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_31, pow_10, variance_9], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf87, buf96, 64, 128, stream=raw_stream0)
        assert_size_stride(arg49_1, (128, ), (1, ), 'input')
        buf99 = reinterpret_tensor(buf94, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf94  # reuse
        buf97 = reinterpret_tensor(buf99, (1, 16, 4, 64), (8192, 512, 128, 1), 0)  # alias
        buf98 = reinterpret_tensor(buf99, (1, 16, 4, 64), (8192, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_31, pow_10, variance_9, add_21, rsqrt_9, hidden_states_32, to_23, mul_32, query_states_2, x2_4, neg_4, x1_4, cat_6], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg49_1, buf87, buf96, buf97, buf98, 4096, stream=raw_stream0)
        buf100 = empty_strided((1, 4, 8, 1), (32, 8, 1, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_33, pow_11, variance_10], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf90, buf100, 32, 128, stream=raw_stream0)
        del buf97
        del buf98
        assert_size_stride(arg52_1, (128, ), (1, ), 'input')
        buf103 = empty_strided((1, 8, 4, 128), (4096, 512, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf101 = reinterpret_tensor(buf103, (1, 8, 4, 64), (4096, 512, 128, 1), 0)  # alias
        buf102 = reinterpret_tensor(buf103, (1, 8, 4, 64), (4096, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_33, pow_11, variance_10, add_22, rsqrt_10, hidden_states_34, to_25, mul_34, key_states_2, x2_5, neg_5, x1_5, cat_7], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg52_1, buf90, buf100, buf101, buf102, 2048, stream=raw_stream0)
        assert_size_stride_grouped((arg55_1, arg56_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_6, sin_6, arange_6, cache_position_2, hidden_states_33, pow_11, variance_10, add_22, rsqrt_10, hidden_states_34, to_25, mul_34, key_states_2, mul_37, mul_38, k_embed_2, index_copy__4], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg55_1, arg52_1, buf90, buf100, buf1, buf103, buf0, arg56_1, 4096, stream=raw_stream0)
        del arg52_1
        del buf100
        del buf101
        del buf102
        del buf103
        del buf90
        buf105 = reinterpret_tensor(buf71, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf71  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_31, pow_10, variance_9, add_21, rsqrt_9, hidden_states_32, to_23, mul_32, query_states_2, cos_6, mul_35, sin_6, mul_36, q_embed_2, attn_output_6], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg49_1, buf87, buf96, buf1, buf99, buf0, buf105, 8192, stream=raw_stream0)
        del arg49_1
        del buf96
        buf106 = empty_strided((1, 16, 128, 256), (524288, 32768, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [key_2, attn_output_6], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8.run(arg56_1, buf106, 524288, stream=raw_stream0)
        del arg56_1
        buf107 = reinterpret_tensor(buf69, (16, 4, 256), (1024, 256, 1), 0); del buf69  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_31, pow_10, variance_9, add_21, rsqrt_9, hidden_states_32, to_23, mul_32, query_states_2, cos_6, mul_35, sin_6, mul_36, q_embed_2, attn_output_6, key_2], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9.run(buf105, buf106, buf107, 16, 16, 1, stream=raw_stream0)
        del buf106
        buf110 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        buf113 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_6], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10.run(buf107, arg3_1, buf110, buf113, 64, 256, stream=raw_stream0)
        del buf107
        del buf110
        assert_size_stride(arg57_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_6, cache_position_2, index_copy__5], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_11.run(arg55_1, buf93, arg57_1, 4096, stream=raw_stream0)
        buf114 = empty_strided((1, 16, 256, 128), (524288, 32768, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [value_2, attn_output_6], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(arg57_1, buf114, 524288, stream=raw_stream0)
        del arg57_1
        buf115 = reinterpret_tensor(buf105, (16, 4, 128), (512, 128, 1), 0); del buf105  # reuse
        # Topologically Sorted Source Nodes: [attn_output_6, value_2], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13.run(buf113, buf114, buf115, 8, 16, 1, stream=raw_stream0)
        del buf114
        buf116 = reinterpret_tensor(buf99, (1, 4, 2048), (8192, 2048, 1), 0); del buf99  # reuse
        buf117 = reinterpret_tensor(buf87, (1, 4, 2048), (2048, 2048, 1), 0); del buf87  # reuse
        # Topologically Sorted Source Nodes: [attn_output_6, transpose_11, reshape_8, output_17], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14.run(buf115, buf117, 8192, stream=raw_stream0)
        assert_size_stride_grouped((arg58_1, arg59_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_6, transpose_11, reshape_8, output_17], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf117, arg58_1, buf116, arg59_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg58_1
        del arg59_1
        assert_size_stride(arg60_1, (2048, ), (1, ), 'input')
        buf120 = reinterpret_tensor(buf117, (1, 4, 2048), (8192, 2048, 1), 0); del buf117  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_27, hidden_states_37, hidden_states_38, pow_12, variance_11, add_27, rsqrt_11, hidden_states_39, to_27, hidden_states_40], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20.run(buf75, buf83, buf116, arg60_1, buf120, 4, 2048, stream=raw_stream0)
        del arg60_1
        buf121 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg61_1, arg62_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_18], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf120, arg61_1, buf121, arg62_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg61_1
        del arg62_1
        buf123 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg63_1, arg64_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_19], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf120, arg63_1, buf123, arg64_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg63_1
        del arg64_1
        buf125 = buf120; del buf120  # reuse
        buf126 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu_2, mul_41, output_20], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_16.run(buf121, buf123, buf126, 24576, stream=raw_stream0)
        del buf121
        del buf123
        assert_size_stride_grouped((arg65_1, arg66_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_2, mul_41, output_20], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf126, arg65_1, buf125, arg66_1, 4, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg65_1
        del arg66_1
        del buf126
        assert_size_stride(arg67_1, (2048, ), (1, ), 'input')
        buf129 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_27, hidden_states_37, hidden_states_41, hidden_states_42, pow_13, variance_12, add_29, rsqrt_12, hidden_states_43, to_29, hidden_states_44], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21.run(buf75, buf83, buf116, buf125, arg67_1, buf129, 4, 2048, stream=raw_stream0)
        del arg67_1
        buf130 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg68_1, arg69_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_21], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf129, arg68_1, buf130, arg69_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg68_1
        del arg69_1
        buf132 = buf93; del buf93  # reuse
        assert_size_stride_grouped((arg71_1, arg72_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_22], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf129, arg71_1, buf132, arg72_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg71_1
        del arg72_1
        buf134 = empty_strided((1, 4, 1024), (4096, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg74_1, arg75_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_23], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf129, arg74_1, buf134, arg75_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg74_1
        del arg75_1
        buf136 = empty_strided((1, 4, 16, 1), (64, 16, 1, 64), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_45, pow_14, variance_13], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf130, buf136, 64, 128, stream=raw_stream0)
        assert_size_stride(arg70_1, (128, ), (1, ), 'input')
        buf139 = reinterpret_tensor(buf129, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf129  # reuse
        buf137 = reinterpret_tensor(buf139, (1, 16, 4, 64), (8192, 512, 128, 1), 0)  # alias
        buf138 = reinterpret_tensor(buf139, (1, 16, 4, 64), (8192, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_45, pow_14, variance_13, add_30, rsqrt_13, hidden_states_46, to_31, mul_45, query_states_3, x2_6, neg_6, x1_6, cat_8], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg70_1, buf130, buf136, buf137, buf138, 4096, stream=raw_stream0)
        buf140 = empty_strided((1, 4, 8, 1), (32, 8, 1, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_47, pow_15, variance_14], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf132, buf140, 32, 128, stream=raw_stream0)
        del buf137
        del buf138
        assert_size_stride(arg73_1, (128, ), (1, ), 'input')
        buf143 = empty_strided((1, 8, 4, 128), (4096, 512, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf141 = reinterpret_tensor(buf143, (1, 8, 4, 64), (4096, 512, 128, 1), 0)  # alias
        buf142 = reinterpret_tensor(buf143, (1, 8, 4, 64), (4096, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_47, pow_15, variance_14, add_31, rsqrt_14, hidden_states_48, to_33, mul_47, key_states_3, x2_7, neg_7, x1_7, cat_9], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg73_1, buf132, buf140, buf141, buf142, 2048, stream=raw_stream0)
        assert_size_stride_grouped((arg76_1, arg77_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_7, sin_7, arange_7, cache_position_3, hidden_states_47, pow_15, variance_14, add_31, rsqrt_14, hidden_states_48, to_33, mul_47, key_states_3, mul_50, mul_51, k_embed_3, index_copy__6], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg76_1, arg73_1, buf132, buf140, buf1, buf143, buf0, arg77_1, 4096, stream=raw_stream0)
        del arg73_1
        del buf132
        del buf140
        del buf141
        del buf142
        del buf143
        buf145 = reinterpret_tensor(buf115, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf115  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_45, pow_14, variance_13, add_30, rsqrt_13, hidden_states_46, to_31, mul_45, query_states_3, cos_7, mul_48, sin_7, mul_49, q_embed_3, attn_output_9], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg70_1, buf130, buf136, buf1, buf139, buf0, buf145, 8192, stream=raw_stream0)
        del arg70_1
        del buf130
        del buf136
        del buf139
        buf146 = empty_strided((1, 16, 128, 256), (524288, 32768, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [key_3, attn_output_9], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8.run(arg77_1, buf146, 524288, stream=raw_stream0)
        del arg77_1
        buf147 = reinterpret_tensor(buf113, (16, 4, 256), (1024, 256, 1), 0); del buf113  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_45, pow_14, variance_13, add_30, rsqrt_13, hidden_states_46, to_31, mul_45, query_states_3, cos_7, mul_48, sin_7, mul_49, q_embed_3, attn_output_9, key_3], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9.run(buf145, buf146, buf147, 16, 16, 1, stream=raw_stream0)
        del buf146
        buf150 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        buf153 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_9], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10.run(buf147, arg3_1, buf150, buf153, 64, 256, stream=raw_stream0)
        del buf147
        del buf150
        assert_size_stride(arg78_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_7, cache_position_3, index_copy__7], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_11.run(arg76_1, buf134, arg78_1, 4096, stream=raw_stream0)
        buf154 = empty_strided((1, 16, 256, 128), (524288, 32768, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [value_3, attn_output_9], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(arg78_1, buf154, 524288, stream=raw_stream0)
        del arg78_1
        buf155 = reinterpret_tensor(buf145, (16, 4, 128), (512, 128, 1), 0); del buf145  # reuse
        # Topologically Sorted Source Nodes: [attn_output_9, value_3], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13.run(buf153, buf154, buf155, 8, 16, 1, stream=raw_stream0)
        del buf154
        buf156 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        buf157 = empty_strided((1, 4, 2048), (2048, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [attn_output_9, transpose_15, reshape_11, output_24], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14.run(buf155, buf157, 8192, stream=raw_stream0)
        assert_size_stride_grouped((arg79_1, arg80_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_9, transpose_15, reshape_11, output_24], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf157, arg79_1, buf156, arg80_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg79_1
        del arg80_1
        assert_size_stride(arg81_1, (2048, ), (1, ), 'input')
        buf159 = buf75; del buf75  # reuse
        buf162 = reinterpret_tensor(buf157, (1, 4, 2048), (8192, 2048, 1), 0); del buf157  # reuse
        buf165 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_27, hidden_states_37, hidden_states_41, hidden_states_51, hidden_states_52, pow_16, variance_15, add_36, rsqrt_15, hidden_states_53, to_35, hidden_states_54, output_25, output_26], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_22.run(buf159, buf83, buf116, buf125, buf156, arg81_1, buf162, buf165, 4, 2048, stream=raw_stream0)
        del arg81_1
        del buf116
        buf161 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg82_1, arg83_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_52, pow_16, variance_15, add_36, rsqrt_15, hidden_states_53, to_35, hidden_states_54, output_25], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf162, arg82_1, buf161, arg83_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg82_1
        del arg83_1
        buf164 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg84_1, arg85_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_52, pow_16, variance_15, add_36, rsqrt_15, hidden_states_53, to_35, hidden_states_54, output_26], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf165, arg84_1, buf164, arg85_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg84_1
        del arg85_1
        buf167 = buf165; del buf165  # reuse
        buf168 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu_3, mul_54, output_27], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_16.run(buf161, buf164, buf168, 24576, stream=raw_stream0)
        del buf161
        del buf164
        assert_size_stride_grouped((arg86_1, arg87_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_3, mul_54, output_27], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf168, arg86_1, buf167, arg87_1, 4, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg86_1
        del arg87_1
        del buf168
        assert_size_stride(arg88_1, (2048, ), (1, ), 'input')
        buf172 = buf162; del buf162  # reuse
        buf175 = buf83; del buf83  # reuse
        buf178 = buf156; del buf156  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_55, hidden_states_56, pow_17, variance_16, add_38, rsqrt_16, hidden_states_57, to_37, hidden_states_58, output_28, output_29, output_30], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19.run(buf159, buf167, arg88_1, buf172, buf175, buf178, 4, 2048, stream=raw_stream0)
        del arg88_1
        buf171 = buf125; del buf125  # reuse
        assert_size_stride_grouped((arg89_1, arg90_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_55, hidden_states_56, pow_17, variance_16, add_38, rsqrt_16, hidden_states_57, to_37, hidden_states_58, output_28], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf172, arg89_1, buf171, arg90_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg89_1
        del arg90_1
        del buf172
        buf174 = buf134; del buf134  # reuse
        assert_size_stride_grouped((arg92_1, arg93_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_55, hidden_states_56, pow_17, variance_16, add_38, rsqrt_16, hidden_states_57, to_37, hidden_states_58, output_29], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf175, arg92_1, buf174, arg93_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg92_1
        del arg93_1
        del buf175
        buf177 = empty_strided((1, 4, 1024), (4096, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg95_1, arg96_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_55, hidden_states_56, pow_17, variance_16, add_38, rsqrt_16, hidden_states_57, to_37, hidden_states_58, output_30], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf178, arg95_1, buf177, arg96_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg95_1
        del arg96_1
        buf180 = empty_strided((1, 4, 16, 1), (64, 16, 1, 64), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_59, pow_18, variance_17], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf171, buf180, 64, 128, stream=raw_stream0)
        assert_size_stride(arg91_1, (128, ), (1, ), 'input')
        buf183 = reinterpret_tensor(buf178, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf178  # reuse
        buf181 = reinterpret_tensor(buf183, (1, 16, 4, 64), (8192, 512, 128, 1), 0)  # alias
        buf182 = reinterpret_tensor(buf183, (1, 16, 4, 64), (8192, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_59, pow_18, variance_17, add_39, rsqrt_17, hidden_states_60, to_39, mul_58, query_states_4, x2_8, neg_8, x1_8, cat_10], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg91_1, buf171, buf180, buf181, buf182, 4096, stream=raw_stream0)
        buf184 = empty_strided((1, 4, 8, 1), (32, 8, 1, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_61, pow_19, variance_18], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf174, buf184, 32, 128, stream=raw_stream0)
        del buf181
        del buf182
        assert_size_stride(arg94_1, (128, ), (1, ), 'input')
        buf187 = empty_strided((1, 8, 4, 128), (4096, 512, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf185 = reinterpret_tensor(buf187, (1, 8, 4, 64), (4096, 512, 128, 1), 0)  # alias
        buf186 = reinterpret_tensor(buf187, (1, 8, 4, 64), (4096, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_61, pow_19, variance_18, add_40, rsqrt_18, hidden_states_62, to_41, mul_60, key_states_4, x2_9, neg_9, x1_9, cat_11], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg94_1, buf174, buf184, buf185, buf186, 2048, stream=raw_stream0)
        assert_size_stride_grouped((arg97_1, arg98_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_8, sin_8, arange_8, cache_position_4, hidden_states_61, pow_19, variance_18, add_40, rsqrt_18, hidden_states_62, to_41, mul_60, key_states_4, mul_63, mul_64, k_embed_4, index_copy__8], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg97_1, arg94_1, buf174, buf184, buf1, buf187, buf0, arg98_1, 4096, stream=raw_stream0)
        del arg94_1
        del buf174
        del buf184
        del buf185
        del buf186
        del buf187
        buf189 = reinterpret_tensor(buf155, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf155  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_59, pow_18, variance_17, add_39, rsqrt_17, hidden_states_60, to_39, mul_58, query_states_4, cos_8, mul_61, sin_8, mul_62, q_embed_4, attn_output_12], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg91_1, buf171, buf180, buf1, buf183, buf0, buf189, 8192, stream=raw_stream0)
        del arg91_1
        del buf180
        buf190 = empty_strided((1, 16, 128, 256), (524288, 32768, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [key_4, attn_output_12], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8.run(arg98_1, buf190, 524288, stream=raw_stream0)
        del arg98_1
        buf191 = reinterpret_tensor(buf153, (16, 4, 256), (1024, 256, 1), 0); del buf153  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_59, pow_18, variance_17, add_39, rsqrt_17, hidden_states_60, to_39, mul_58, query_states_4, cos_8, mul_61, sin_8, mul_62, q_embed_4, attn_output_12, key_4], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9.run(buf189, buf190, buf191, 16, 16, 1, stream=raw_stream0)
        del buf190
        buf194 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        buf197 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_12], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10.run(buf191, arg3_1, buf194, buf197, 64, 256, stream=raw_stream0)
        del buf191
        del buf194
        assert_size_stride(arg99_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_8, cache_position_4, index_copy__9], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_11.run(arg97_1, buf177, arg99_1, 4096, stream=raw_stream0)
        buf198 = empty_strided((1, 16, 256, 128), (524288, 32768, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [value_4, attn_output_12], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(arg99_1, buf198, 524288, stream=raw_stream0)
        del arg99_1
        buf199 = reinterpret_tensor(buf189, (16, 4, 128), (512, 128, 1), 0); del buf189  # reuse
        # Topologically Sorted Source Nodes: [attn_output_12, value_4], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13.run(buf197, buf198, buf199, 8, 16, 1, stream=raw_stream0)
        del buf198
        buf200 = reinterpret_tensor(buf183, (1, 4, 2048), (8192, 2048, 1), 0); del buf183  # reuse
        buf201 = reinterpret_tensor(buf171, (1, 4, 2048), (2048, 2048, 1), 0); del buf171  # reuse
        # Topologically Sorted Source Nodes: [attn_output_12, transpose_19, reshape_14, output_31], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14.run(buf199, buf201, 8192, stream=raw_stream0)
        assert_size_stride_grouped((arg100_1, arg101_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_12, transpose_19, reshape_14, output_31], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf201, arg100_1, buf200, arg101_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg100_1
        del arg101_1
        assert_size_stride(arg102_1, (2048, ), (1, ), 'input')
        buf204 = reinterpret_tensor(buf201, (1, 4, 2048), (8192, 2048, 1), 0); del buf201  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_55, hidden_states_65, hidden_states_66, pow_20, variance_19, add_45, rsqrt_19, hidden_states_67, to_43, hidden_states_68], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20.run(buf159, buf167, buf200, arg102_1, buf204, 4, 2048, stream=raw_stream0)
        del arg102_1
        buf205 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg103_1, arg104_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_32], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf204, arg103_1, buf205, arg104_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg103_1
        del arg104_1
        buf207 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg105_1, arg106_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_33], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf204, arg105_1, buf207, arg106_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg105_1
        del arg106_1
        buf209 = buf204; del buf204  # reuse
        buf210 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu_4, mul_67, output_34], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_16.run(buf205, buf207, buf210, 24576, stream=raw_stream0)
        del buf205
        del buf207
        assert_size_stride_grouped((arg107_1, arg108_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_4, mul_67, output_34], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf210, arg107_1, buf209, arg108_1, 4, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg107_1
        del arg108_1
        del buf210
        assert_size_stride(arg109_1, (2048, ), (1, ), 'input')
        buf213 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_55, hidden_states_65, hidden_states_69, hidden_states_70, pow_21, variance_20, add_47, rsqrt_20, hidden_states_71, to_45, hidden_states_72], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21.run(buf159, buf167, buf200, buf209, arg109_1, buf213, 4, 2048, stream=raw_stream0)
        del arg109_1
        buf214 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg110_1, arg111_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_35], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf213, arg110_1, buf214, arg111_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg110_1
        del arg111_1
        buf216 = buf177; del buf177  # reuse
        assert_size_stride_grouped((arg113_1, arg114_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_36], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf213, arg113_1, buf216, arg114_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg113_1
        del arg114_1
        buf218 = empty_strided((1, 4, 1024), (4096, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg116_1, arg117_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_37], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf213, arg116_1, buf218, arg117_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg116_1
        del arg117_1
        buf220 = empty_strided((1, 4, 16, 1), (64, 16, 1, 64), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_73, pow_22, variance_21], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf214, buf220, 64, 128, stream=raw_stream0)
        assert_size_stride(arg112_1, (128, ), (1, ), 'input')
        buf223 = reinterpret_tensor(buf213, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf213  # reuse
        buf221 = reinterpret_tensor(buf223, (1, 16, 4, 64), (8192, 512, 128, 1), 0)  # alias
        buf222 = reinterpret_tensor(buf223, (1, 16, 4, 64), (8192, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_73, pow_22, variance_21, add_48, rsqrt_21, hidden_states_74, to_47, mul_71, query_states_5, x2_10, neg_10, x1_10, cat_12], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg112_1, buf214, buf220, buf221, buf222, 4096, stream=raw_stream0)
        buf224 = empty_strided((1, 4, 8, 1), (32, 8, 1, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_75, pow_23, variance_22], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf216, buf224, 32, 128, stream=raw_stream0)
        del buf221
        del buf222
        assert_size_stride(arg115_1, (128, ), (1, ), 'input')
        buf227 = empty_strided((1, 8, 4, 128), (4096, 512, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf225 = reinterpret_tensor(buf227, (1, 8, 4, 64), (4096, 512, 128, 1), 0)  # alias
        buf226 = reinterpret_tensor(buf227, (1, 8, 4, 64), (4096, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_75, pow_23, variance_22, add_49, rsqrt_22, hidden_states_76, to_49, mul_73, key_states_5, x2_11, neg_11, x1_11, cat_13], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg115_1, buf216, buf224, buf225, buf226, 2048, stream=raw_stream0)
        assert_size_stride_grouped((arg118_1, arg119_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_9, sin_9, arange_9, cache_position_5, hidden_states_75, pow_23, variance_22, add_49, rsqrt_22, hidden_states_76, to_49, mul_73, key_states_5, mul_76, mul_77, k_embed_5, index_copy__10], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg118_1, arg115_1, buf216, buf224, buf1, buf227, buf0, arg119_1, 4096, stream=raw_stream0)
        del arg115_1
        del buf216
        del buf224
        del buf225
        del buf226
        del buf227
        buf229 = reinterpret_tensor(buf199, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf199  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_73, pow_22, variance_21, add_48, rsqrt_21, hidden_states_74, to_47, mul_71, query_states_5, cos_9, mul_74, sin_9, mul_75, q_embed_5, attn_output_15], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg112_1, buf214, buf220, buf1, buf223, buf0, buf229, 8192, stream=raw_stream0)
        del arg112_1
        del buf214
        del buf220
        del buf223
        buf230 = empty_strided((1, 16, 128, 256), (524288, 32768, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [key_5, attn_output_15], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8.run(arg119_1, buf230, 524288, stream=raw_stream0)
        del arg119_1
        buf231 = reinterpret_tensor(buf197, (16, 4, 256), (1024, 256, 1), 0); del buf197  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_73, pow_22, variance_21, add_48, rsqrt_21, hidden_states_74, to_47, mul_71, query_states_5, cos_9, mul_74, sin_9, mul_75, q_embed_5, attn_output_15, key_5], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9.run(buf229, buf230, buf231, 16, 16, 1, stream=raw_stream0)
        del buf230
        buf234 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        buf237 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_15], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10.run(buf231, arg3_1, buf234, buf237, 64, 256, stream=raw_stream0)
        del buf231
        del buf234
        assert_size_stride(arg120_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_9, cache_position_5, index_copy__11], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_11.run(arg118_1, buf218, arg120_1, 4096, stream=raw_stream0)
        buf238 = empty_strided((1, 16, 256, 128), (524288, 32768, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [value_5, attn_output_15], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(arg120_1, buf238, 524288, stream=raw_stream0)
        del arg120_1
        buf239 = reinterpret_tensor(buf229, (16, 4, 128), (512, 128, 1), 0); del buf229  # reuse
        # Topologically Sorted Source Nodes: [attn_output_15, value_5], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13.run(buf237, buf238, buf239, 8, 16, 1, stream=raw_stream0)
        del buf238
        buf240 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        buf241 = empty_strided((1, 4, 2048), (2048, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [attn_output_15, transpose_23, reshape_17, output_38], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14.run(buf239, buf241, 8192, stream=raw_stream0)
        assert_size_stride_grouped((arg121_1, arg122_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_15, transpose_23, reshape_17, output_38], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf241, arg121_1, buf240, arg122_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg121_1
        del arg122_1
        assert_size_stride(arg123_1, (2048, ), (1, ), 'input')
        buf243 = buf159; del buf159  # reuse
        buf246 = reinterpret_tensor(buf241, (1, 4, 2048), (8192, 2048, 1), 0); del buf241  # reuse
        buf249 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_55, hidden_states_65, hidden_states_69, hidden_states_79, hidden_states_80, pow_24, variance_23, add_54, rsqrt_23, hidden_states_81, to_51, hidden_states_82, output_39, output_40], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_22.run(buf243, buf167, buf200, buf209, buf240, arg123_1, buf246, buf249, 4, 2048, stream=raw_stream0)
        del arg123_1
        del buf167
        buf245 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg124_1, arg125_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_80, pow_24, variance_23, add_54, rsqrt_23, hidden_states_81, to_51, hidden_states_82, output_39], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf246, arg124_1, buf245, arg125_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg124_1
        del arg125_1
        buf248 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg126_1, arg127_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_80, pow_24, variance_23, add_54, rsqrt_23, hidden_states_81, to_51, hidden_states_82, output_40], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf249, arg126_1, buf248, arg127_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg126_1
        del arg127_1
        buf251 = buf249; del buf249  # reuse
        buf252 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu_5, mul_80, output_41], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_16.run(buf245, buf248, buf252, 24576, stream=raw_stream0)
        del buf245
        del buf248
        assert_size_stride_grouped((arg128_1, arg129_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_5, mul_80, output_41], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf252, arg128_1, buf251, arg129_1, 4, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg128_1
        del arg129_1
        del buf252
        assert_size_stride(arg130_1, (2048, ), (1, ), 'input')
        buf256 = buf246; del buf246  # reuse
        buf259 = buf240; del buf240  # reuse
        buf262 = buf209; del buf209  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_83, hidden_states_84, pow_25, variance_24, add_56, rsqrt_24, hidden_states_85, to_53, hidden_states_86, output_42, output_43, output_44], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19.run(buf243, buf251, arg130_1, buf256, buf259, buf262, 4, 2048, stream=raw_stream0)
        del arg130_1
        buf255 = buf200; del buf200  # reuse
        assert_size_stride_grouped((arg131_1, arg132_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_83, hidden_states_84, pow_25, variance_24, add_56, rsqrt_24, hidden_states_85, to_53, hidden_states_86, output_42], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf256, arg131_1, buf255, arg132_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg131_1
        del arg132_1
        del buf256
        buf258 = buf218; del buf218  # reuse
        assert_size_stride_grouped((arg134_1, arg135_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_83, hidden_states_84, pow_25, variance_24, add_56, rsqrt_24, hidden_states_85, to_53, hidden_states_86, output_43], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf259, arg134_1, buf258, arg135_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg134_1
        del arg135_1
        del buf259
        buf261 = empty_strided((1, 4, 1024), (4096, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg137_1, arg138_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_83, hidden_states_84, pow_25, variance_24, add_56, rsqrt_24, hidden_states_85, to_53, hidden_states_86, output_44], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf262, arg137_1, buf261, arg138_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg137_1
        del arg138_1
        buf264 = empty_strided((1, 4, 16, 1), (64, 16, 1, 64), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_87, pow_26, variance_25], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf255, buf264, 64, 128, stream=raw_stream0)
        assert_size_stride(arg133_1, (128, ), (1, ), 'input')
        buf267 = reinterpret_tensor(buf262, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf262  # reuse
        buf265 = reinterpret_tensor(buf267, (1, 16, 4, 64), (8192, 512, 128, 1), 0)  # alias
        buf266 = reinterpret_tensor(buf267, (1, 16, 4, 64), (8192, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_87, pow_26, variance_25, add_57, rsqrt_25, hidden_states_88, to_55, mul_84, query_states_6, x2_12, neg_12, x1_12, cat_14], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg133_1, buf255, buf264, buf265, buf266, 4096, stream=raw_stream0)
        buf268 = empty_strided((1, 4, 8, 1), (32, 8, 1, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_89, pow_27, variance_26], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf258, buf268, 32, 128, stream=raw_stream0)
        del buf265
        del buf266
        assert_size_stride(arg136_1, (128, ), (1, ), 'input')
        buf271 = empty_strided((1, 8, 4, 128), (4096, 512, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf269 = reinterpret_tensor(buf271, (1, 8, 4, 64), (4096, 512, 128, 1), 0)  # alias
        buf270 = reinterpret_tensor(buf271, (1, 8, 4, 64), (4096, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_89, pow_27, variance_26, add_58, rsqrt_26, hidden_states_90, to_57, mul_86, key_states_6, x2_13, neg_13, x1_13, cat_15], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg136_1, buf258, buf268, buf269, buf270, 2048, stream=raw_stream0)
        assert_size_stride_grouped((arg139_1, arg140_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_10, sin_10, arange_10, cache_position_6, hidden_states_89, pow_27, variance_26, add_58, rsqrt_26, hidden_states_90, to_57, mul_86, key_states_6, mul_89, mul_90, k_embed_6, index_copy__12], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg139_1, arg136_1, buf258, buf268, buf1, buf271, buf0, arg140_1, 4096, stream=raw_stream0)
        del arg136_1
        del buf258
        del buf268
        del buf269
        del buf270
        del buf271
        buf273 = reinterpret_tensor(buf239, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf239  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_87, pow_26, variance_25, add_57, rsqrt_25, hidden_states_88, to_55, mul_84, query_states_6, cos_10, mul_87, sin_10, mul_88, q_embed_6, attn_output_18], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg133_1, buf255, buf264, buf1, buf267, buf0, buf273, 8192, stream=raw_stream0)
        del arg133_1
        del buf264
        buf274 = empty_strided((1, 16, 128, 256), (524288, 32768, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [key_6, attn_output_18], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8.run(arg140_1, buf274, 524288, stream=raw_stream0)
        del arg140_1
        buf275 = reinterpret_tensor(buf237, (16, 4, 256), (1024, 256, 1), 0); del buf237  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_87, pow_26, variance_25, add_57, rsqrt_25, hidden_states_88, to_55, mul_84, query_states_6, cos_10, mul_87, sin_10, mul_88, q_embed_6, attn_output_18, key_6], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9.run(buf273, buf274, buf275, 16, 16, 1, stream=raw_stream0)
        del buf274
        buf278 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        buf281 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_18], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10.run(buf275, arg3_1, buf278, buf281, 64, 256, stream=raw_stream0)
        del buf275
        del buf278
        assert_size_stride(arg141_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_10, cache_position_6, index_copy__13], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_11.run(arg139_1, buf261, arg141_1, 4096, stream=raw_stream0)
        buf282 = empty_strided((1, 16, 256, 128), (524288, 32768, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [value_6, attn_output_18], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(arg141_1, buf282, 524288, stream=raw_stream0)
        del arg141_1
        buf283 = reinterpret_tensor(buf273, (16, 4, 128), (512, 128, 1), 0); del buf273  # reuse
        # Topologically Sorted Source Nodes: [attn_output_18, value_6], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13.run(buf281, buf282, buf283, 8, 16, 1, stream=raw_stream0)
        del buf282
        buf284 = reinterpret_tensor(buf267, (1, 4, 2048), (8192, 2048, 1), 0); del buf267  # reuse
        buf285 = reinterpret_tensor(buf255, (1, 4, 2048), (2048, 2048, 1), 0); del buf255  # reuse
        # Topologically Sorted Source Nodes: [attn_output_18, transpose_27, reshape_20, output_45], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14.run(buf283, buf285, 8192, stream=raw_stream0)
        assert_size_stride_grouped((arg142_1, arg143_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_18, transpose_27, reshape_20, output_45], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf285, arg142_1, buf284, arg143_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg142_1
        del arg143_1
        assert_size_stride(arg144_1, (2048, ), (1, ), 'input')
        buf288 = reinterpret_tensor(buf285, (1, 4, 2048), (8192, 2048, 1), 0); del buf285  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_83, hidden_states_93, hidden_states_94, pow_28, variance_27, add_63, rsqrt_27, hidden_states_95, to_59, hidden_states_96], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20.run(buf243, buf251, buf284, arg144_1, buf288, 4, 2048, stream=raw_stream0)
        del arg144_1
        buf289 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg145_1, arg146_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_46], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf288, arg145_1, buf289, arg146_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg145_1
        del arg146_1
        buf291 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg147_1, arg148_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_47], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf288, arg147_1, buf291, arg148_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg147_1
        del arg148_1
        buf293 = buf288; del buf288  # reuse
        buf294 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu_6, mul_93, output_48], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_16.run(buf289, buf291, buf294, 24576, stream=raw_stream0)
        del buf289
        del buf291
        assert_size_stride_grouped((arg149_1, arg150_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_6, mul_93, output_48], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf294, arg149_1, buf293, arg150_1, 4, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg149_1
        del arg150_1
        del buf294
        assert_size_stride(arg151_1, (2048, ), (1, ), 'input')
        buf297 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_83, hidden_states_93, hidden_states_97, hidden_states_98, pow_29, variance_28, add_65, rsqrt_28, hidden_states_99, to_61, hidden_states_100], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21.run(buf243, buf251, buf284, buf293, arg151_1, buf297, 4, 2048, stream=raw_stream0)
        del arg151_1
        buf298 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg152_1, arg153_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_49], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf297, arg152_1, buf298, arg153_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg152_1
        del arg153_1
        buf300 = buf261; del buf261  # reuse
        assert_size_stride_grouped((arg155_1, arg156_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_50], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf297, arg155_1, buf300, arg156_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg155_1
        del arg156_1
        buf302 = empty_strided((1, 4, 1024), (4096, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg158_1, arg159_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_51], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf297, arg158_1, buf302, arg159_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg158_1
        del arg159_1
        buf304 = empty_strided((1, 4, 16, 1), (64, 16, 1, 64), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_101, pow_30, variance_29], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf298, buf304, 64, 128, stream=raw_stream0)
        assert_size_stride(arg154_1, (128, ), (1, ), 'input')
        buf307 = reinterpret_tensor(buf297, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf297  # reuse
        buf305 = reinterpret_tensor(buf307, (1, 16, 4, 64), (8192, 512, 128, 1), 0)  # alias
        buf306 = reinterpret_tensor(buf307, (1, 16, 4, 64), (8192, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_101, pow_30, variance_29, add_66, rsqrt_29, hidden_states_102, to_63, mul_97, query_states_7, x2_14, neg_14, x1_14, cat_16], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg154_1, buf298, buf304, buf305, buf306, 4096, stream=raw_stream0)
        buf308 = empty_strided((1, 4, 8, 1), (32, 8, 1, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_103, pow_31, variance_30], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf300, buf308, 32, 128, stream=raw_stream0)
        del buf305
        del buf306
        assert_size_stride(arg157_1, (128, ), (1, ), 'input')
        buf311 = empty_strided((1, 8, 4, 128), (4096, 512, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf309 = reinterpret_tensor(buf311, (1, 8, 4, 64), (4096, 512, 128, 1), 0)  # alias
        buf310 = reinterpret_tensor(buf311, (1, 8, 4, 64), (4096, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_103, pow_31, variance_30, add_67, rsqrt_30, hidden_states_104, to_65, mul_99, key_states_7, x2_15, neg_15, x1_15, cat_17], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg157_1, buf300, buf308, buf309, buf310, 2048, stream=raw_stream0)
        assert_size_stride_grouped((arg160_1, arg161_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_11, sin_11, arange_11, cache_position_7, hidden_states_103, pow_31, variance_30, add_67, rsqrt_30, hidden_states_104, to_65, mul_99, key_states_7, mul_102, mul_103, k_embed_7, index_copy__14], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg160_1, arg157_1, buf300, buf308, buf1, buf311, buf0, arg161_1, 4096, stream=raw_stream0)
        del arg157_1
        del buf300
        del buf308
        del buf309
        del buf310
        del buf311
        buf313 = reinterpret_tensor(buf283, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf283  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_101, pow_30, variance_29, add_66, rsqrt_29, hidden_states_102, to_63, mul_97, query_states_7, cos_11, mul_100, sin_11, mul_101, q_embed_7, attn_output_21], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg154_1, buf298, buf304, buf1, buf307, buf0, buf313, 8192, stream=raw_stream0)
        del arg154_1
        del buf298
        del buf304
        del buf307
        buf314 = empty_strided((1, 16, 128, 256), (524288, 32768, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [key_7, attn_output_21], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8.run(arg161_1, buf314, 524288, stream=raw_stream0)
        del arg161_1
        buf315 = reinterpret_tensor(buf281, (16, 4, 256), (1024, 256, 1), 0); del buf281  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_101, pow_30, variance_29, add_66, rsqrt_29, hidden_states_102, to_63, mul_97, query_states_7, cos_11, mul_100, sin_11, mul_101, q_embed_7, attn_output_21, key_7], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9.run(buf313, buf314, buf315, 16, 16, 1, stream=raw_stream0)
        del buf314
        buf318 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        buf321 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_21], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10.run(buf315, arg3_1, buf318, buf321, 64, 256, stream=raw_stream0)
        del buf315
        del buf318
        assert_size_stride(arg162_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_11, cache_position_7, index_copy__15], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_11.run(arg160_1, buf302, arg162_1, 4096, stream=raw_stream0)
        buf322 = empty_strided((1, 16, 256, 128), (524288, 32768, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [value_7, attn_output_21], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(arg162_1, buf322, 524288, stream=raw_stream0)
        del arg162_1
        buf323 = reinterpret_tensor(buf313, (16, 4, 128), (512, 128, 1), 0); del buf313  # reuse
        # Topologically Sorted Source Nodes: [attn_output_21, value_7], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13.run(buf321, buf322, buf323, 8, 16, 1, stream=raw_stream0)
        del buf322
        buf324 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        buf325 = empty_strided((1, 4, 2048), (2048, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [attn_output_21, transpose_31, reshape_23, output_52], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14.run(buf323, buf325, 8192, stream=raw_stream0)
        assert_size_stride_grouped((arg163_1, arg164_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_21, transpose_31, reshape_23, output_52], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf325, arg163_1, buf324, arg164_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg163_1
        del arg164_1
        assert_size_stride(arg165_1, (2048, ), (1, ), 'input')
        buf327 = buf243; del buf243  # reuse
        buf330 = reinterpret_tensor(buf325, (1, 4, 2048), (8192, 2048, 1), 0); del buf325  # reuse
        buf333 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_83, hidden_states_93, hidden_states_97, hidden_states_107, hidden_states_108, pow_32, variance_31, add_72, rsqrt_31, hidden_states_109, to_67, hidden_states_110, output_53, output_54], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_22.run(buf327, buf251, buf284, buf293, buf324, arg165_1, buf330, buf333, 4, 2048, stream=raw_stream0)
        del arg165_1
        del buf251
        buf329 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg166_1, arg167_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_108, pow_32, variance_31, add_72, rsqrt_31, hidden_states_109, to_67, hidden_states_110, output_53], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf330, arg166_1, buf329, arg167_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg166_1
        del arg167_1
        buf332 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg168_1, arg169_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_108, pow_32, variance_31, add_72, rsqrt_31, hidden_states_109, to_67, hidden_states_110, output_54], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf333, arg168_1, buf332, arg169_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg168_1
        del arg169_1
        buf335 = buf333; del buf333  # reuse
        buf336 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu_7, mul_106, output_55], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_16.run(buf329, buf332, buf336, 24576, stream=raw_stream0)
        del buf329
        del buf332
        assert_size_stride_grouped((arg170_1, arg171_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_7, mul_106, output_55], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf336, arg170_1, buf335, arg171_1, 4, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg170_1
        del arg171_1
        del buf336
        assert_size_stride(arg172_1, (2048, ), (1, ), 'input')
        buf340 = buf330; del buf330  # reuse
        buf343 = buf324; del buf324  # reuse
        buf346 = buf293; del buf293  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_111, hidden_states_112, pow_33, variance_32, add_74, rsqrt_32, hidden_states_113, to_69, hidden_states_114, output_56, output_57, output_58], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19.run(buf327, buf335, arg172_1, buf340, buf343, buf346, 4, 2048, stream=raw_stream0)
        del arg172_1
        buf339 = buf284; del buf284  # reuse
        assert_size_stride_grouped((arg173_1, arg174_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_111, hidden_states_112, pow_33, variance_32, add_74, rsqrt_32, hidden_states_113, to_69, hidden_states_114, output_56], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf340, arg173_1, buf339, arg174_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg173_1
        del arg174_1
        del buf340
        buf342 = buf302; del buf302  # reuse
        assert_size_stride_grouped((arg176_1, arg177_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_111, hidden_states_112, pow_33, variance_32, add_74, rsqrt_32, hidden_states_113, to_69, hidden_states_114, output_57], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf343, arg176_1, buf342, arg177_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg176_1
        del arg177_1
        del buf343
        buf345 = empty_strided((1, 4, 1024), (4096, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg179_1, arg180_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_111, hidden_states_112, pow_33, variance_32, add_74, rsqrt_32, hidden_states_113, to_69, hidden_states_114, output_58], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf346, arg179_1, buf345, arg180_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg179_1
        del arg180_1
        buf348 = empty_strided((1, 4, 16, 1), (64, 16, 1, 64), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_115, pow_34, variance_33], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf339, buf348, 64, 128, stream=raw_stream0)
        assert_size_stride(arg175_1, (128, ), (1, ), 'input')
        buf351 = reinterpret_tensor(buf346, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf346  # reuse
        buf349 = reinterpret_tensor(buf351, (1, 16, 4, 64), (8192, 512, 128, 1), 0)  # alias
        buf350 = reinterpret_tensor(buf351, (1, 16, 4, 64), (8192, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_115, pow_34, variance_33, add_75, rsqrt_33, hidden_states_116, to_71, mul_110, query_states_8, x2_16, neg_16, x1_16, cat_18], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg175_1, buf339, buf348, buf349, buf350, 4096, stream=raw_stream0)
        buf352 = empty_strided((1, 4, 8, 1), (32, 8, 1, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_117, pow_35, variance_34], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf342, buf352, 32, 128, stream=raw_stream0)
        del buf349
        del buf350
        assert_size_stride(arg178_1, (128, ), (1, ), 'input')
        buf355 = empty_strided((1, 8, 4, 128), (4096, 512, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf353 = reinterpret_tensor(buf355, (1, 8, 4, 64), (4096, 512, 128, 1), 0)  # alias
        buf354 = reinterpret_tensor(buf355, (1, 8, 4, 64), (4096, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_117, pow_35, variance_34, add_76, rsqrt_34, hidden_states_118, to_73, mul_112, key_states_8, x2_17, neg_17, x1_17, cat_19], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg178_1, buf342, buf352, buf353, buf354, 2048, stream=raw_stream0)
        assert_size_stride_grouped((arg181_1, arg182_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_12, sin_12, arange_12, cache_position_8, hidden_states_117, pow_35, variance_34, add_76, rsqrt_34, hidden_states_118, to_73, mul_112, key_states_8, mul_115, mul_116, k_embed_8, index_copy__16], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg181_1, arg178_1, buf342, buf352, buf1, buf355, buf0, arg182_1, 4096, stream=raw_stream0)
        del arg178_1
        del buf342
        del buf352
        del buf353
        del buf354
        del buf355
        buf357 = reinterpret_tensor(buf323, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf323  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_115, pow_34, variance_33, add_75, rsqrt_33, hidden_states_116, to_71, mul_110, query_states_8, cos_12, mul_113, sin_12, mul_114, q_embed_8, attn_output_24], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg175_1, buf339, buf348, buf1, buf351, buf0, buf357, 8192, stream=raw_stream0)
        del arg175_1
        del buf348
        buf358 = empty_strided((1, 16, 128, 256), (524288, 32768, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [key_8, attn_output_24], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8.run(arg182_1, buf358, 524288, stream=raw_stream0)
        del arg182_1
        buf359 = reinterpret_tensor(buf321, (16, 4, 256), (1024, 256, 1), 0); del buf321  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_115, pow_34, variance_33, add_75, rsqrt_33, hidden_states_116, to_71, mul_110, query_states_8, cos_12, mul_113, sin_12, mul_114, q_embed_8, attn_output_24, key_8], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9.run(buf357, buf358, buf359, 16, 16, 1, stream=raw_stream0)
        del buf358
        buf362 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        buf365 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_24], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10.run(buf359, arg3_1, buf362, buf365, 64, 256, stream=raw_stream0)
        del buf359
        del buf362
        assert_size_stride(arg183_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_12, cache_position_8, index_copy__17], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_11.run(arg181_1, buf345, arg183_1, 4096, stream=raw_stream0)
        buf366 = empty_strided((1, 16, 256, 128), (524288, 32768, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [value_8, attn_output_24], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(arg183_1, buf366, 524288, stream=raw_stream0)
        del arg183_1
        buf367 = reinterpret_tensor(buf357, (16, 4, 128), (512, 128, 1), 0); del buf357  # reuse
        # Topologically Sorted Source Nodes: [attn_output_24, value_8], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13.run(buf365, buf366, buf367, 8, 16, 1, stream=raw_stream0)
        del buf366
        buf368 = reinterpret_tensor(buf351, (1, 4, 2048), (8192, 2048, 1), 0); del buf351  # reuse
        buf369 = reinterpret_tensor(buf339, (1, 4, 2048), (2048, 2048, 1), 0); del buf339  # reuse
        # Topologically Sorted Source Nodes: [attn_output_24, transpose_35, reshape_26, output_59], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14.run(buf367, buf369, 8192, stream=raw_stream0)
        assert_size_stride_grouped((arg184_1, arg185_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_24, transpose_35, reshape_26, output_59], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf369, arg184_1, buf368, arg185_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg184_1
        del arg185_1
        assert_size_stride(arg186_1, (2048, ), (1, ), 'input')
        buf372 = reinterpret_tensor(buf369, (1, 4, 2048), (8192, 2048, 1), 0); del buf369  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_111, hidden_states_121, hidden_states_122, pow_36, variance_35, add_81, rsqrt_35, hidden_states_123, to_75, hidden_states_124], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20.run(buf327, buf335, buf368, arg186_1, buf372, 4, 2048, stream=raw_stream0)
        del arg186_1
        buf373 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg187_1, arg188_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_60], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf372, arg187_1, buf373, arg188_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg187_1
        del arg188_1
        buf375 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg189_1, arg190_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_61], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf372, arg189_1, buf375, arg190_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg189_1
        del arg190_1
        buf377 = buf372; del buf372  # reuse
        buf378 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu_8, mul_119, output_62], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_16.run(buf373, buf375, buf378, 24576, stream=raw_stream0)
        del buf373
        del buf375
        assert_size_stride_grouped((arg191_1, arg192_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_8, mul_119, output_62], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf378, arg191_1, buf377, arg192_1, 4, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg191_1
        del arg192_1
        del buf378
        assert_size_stride(arg193_1, (2048, ), (1, ), 'input')
        buf381 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_111, hidden_states_121, hidden_states_125, hidden_states_126, pow_37, variance_36, add_83, rsqrt_36, hidden_states_127, to_77, hidden_states_128], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21.run(buf327, buf335, buf368, buf377, arg193_1, buf381, 4, 2048, stream=raw_stream0)
        del arg193_1
        buf382 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg194_1, arg195_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_63], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf381, arg194_1, buf382, arg195_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg194_1
        del arg195_1
        buf384 = buf345; del buf345  # reuse
        assert_size_stride_grouped((arg197_1, arg198_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_64], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf381, arg197_1, buf384, arg198_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg197_1
        del arg198_1
        buf386 = empty_strided((1, 4, 1024), (4096, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg200_1, arg201_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_65], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf381, arg200_1, buf386, arg201_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg200_1
        del arg201_1
        buf388 = empty_strided((1, 4, 16, 1), (64, 16, 1, 64), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_129, pow_38, variance_37], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf382, buf388, 64, 128, stream=raw_stream0)
        assert_size_stride(arg196_1, (128, ), (1, ), 'input')
        buf391 = reinterpret_tensor(buf381, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf381  # reuse
        buf389 = reinterpret_tensor(buf391, (1, 16, 4, 64), (8192, 512, 128, 1), 0)  # alias
        buf390 = reinterpret_tensor(buf391, (1, 16, 4, 64), (8192, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_129, pow_38, variance_37, add_84, rsqrt_37, hidden_states_130, to_79, mul_123, query_states_9, x2_18, neg_18, x1_18, cat_20], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg196_1, buf382, buf388, buf389, buf390, 4096, stream=raw_stream0)
        buf392 = empty_strided((1, 4, 8, 1), (32, 8, 1, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_131, pow_39, variance_38], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf384, buf392, 32, 128, stream=raw_stream0)
        del buf389
        del buf390
        assert_size_stride(arg199_1, (128, ), (1, ), 'input')
        buf395 = empty_strided((1, 8, 4, 128), (4096, 512, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf393 = reinterpret_tensor(buf395, (1, 8, 4, 64), (4096, 512, 128, 1), 0)  # alias
        buf394 = reinterpret_tensor(buf395, (1, 8, 4, 64), (4096, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_131, pow_39, variance_38, add_85, rsqrt_38, hidden_states_132, to_81, mul_125, key_states_9, x2_19, neg_19, x1_19, cat_21], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg199_1, buf384, buf392, buf393, buf394, 2048, stream=raw_stream0)
        assert_size_stride_grouped((arg202_1, arg203_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_13, sin_13, arange_13, cache_position_9, hidden_states_131, pow_39, variance_38, add_85, rsqrt_38, hidden_states_132, to_81, mul_125, key_states_9, mul_128, mul_129, k_embed_9, index_copy__18], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg202_1, arg199_1, buf384, buf392, buf1, buf395, buf0, arg203_1, 4096, stream=raw_stream0)
        del arg199_1
        del buf384
        del buf392
        del buf393
        del buf394
        del buf395
        buf397 = reinterpret_tensor(buf367, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf367  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_129, pow_38, variance_37, add_84, rsqrt_37, hidden_states_130, to_79, mul_123, query_states_9, cos_13, mul_126, sin_13, mul_127, q_embed_9, attn_output_27], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg196_1, buf382, buf388, buf1, buf391, buf0, buf397, 8192, stream=raw_stream0)
        del arg196_1
        del buf382
        del buf388
        del buf391
        buf398 = empty_strided((1, 16, 128, 256), (524288, 32768, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [key_9, attn_output_27], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8.run(arg203_1, buf398, 524288, stream=raw_stream0)
        del arg203_1
        buf399 = reinterpret_tensor(buf365, (16, 4, 256), (1024, 256, 1), 0); del buf365  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_129, pow_38, variance_37, add_84, rsqrt_37, hidden_states_130, to_79, mul_123, query_states_9, cos_13, mul_126, sin_13, mul_127, q_embed_9, attn_output_27, key_9], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9.run(buf397, buf398, buf399, 16, 16, 1, stream=raw_stream0)
        del buf398
        buf402 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        buf405 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_27], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10.run(buf399, arg3_1, buf402, buf405, 64, 256, stream=raw_stream0)
        del buf399
        del buf402
        assert_size_stride(arg204_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_13, cache_position_9, index_copy__19], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_11.run(arg202_1, buf386, arg204_1, 4096, stream=raw_stream0)
        buf406 = empty_strided((1, 16, 256, 128), (524288, 32768, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [value_9, attn_output_27], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(arg204_1, buf406, 524288, stream=raw_stream0)
        del arg204_1
        buf407 = reinterpret_tensor(buf397, (16, 4, 128), (512, 128, 1), 0); del buf397  # reuse
        # Topologically Sorted Source Nodes: [attn_output_27, value_9], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13.run(buf405, buf406, buf407, 8, 16, 1, stream=raw_stream0)
        del buf406
        buf408 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        buf409 = empty_strided((1, 4, 2048), (2048, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [attn_output_27, transpose_39, reshape_29, output_66], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14.run(buf407, buf409, 8192, stream=raw_stream0)
        assert_size_stride_grouped((arg205_1, arg206_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_27, transpose_39, reshape_29, output_66], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf409, arg205_1, buf408, arg206_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg205_1
        del arg206_1
        assert_size_stride(arg207_1, (2048, ), (1, ), 'input')
        buf411 = buf327; del buf327  # reuse
        buf414 = reinterpret_tensor(buf409, (1, 4, 2048), (8192, 2048, 1), 0); del buf409  # reuse
        buf417 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_111, hidden_states_121, hidden_states_125, hidden_states_135, hidden_states_136, pow_40, variance_39, add_90, rsqrt_39, hidden_states_137, to_83, hidden_states_138, output_67, output_68], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_22.run(buf411, buf335, buf368, buf377, buf408, arg207_1, buf414, buf417, 4, 2048, stream=raw_stream0)
        del arg207_1
        del buf335
        buf413 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg208_1, arg209_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_136, pow_40, variance_39, add_90, rsqrt_39, hidden_states_137, to_83, hidden_states_138, output_67], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf414, arg208_1, buf413, arg209_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg208_1
        del arg209_1
        buf416 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg210_1, arg211_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_136, pow_40, variance_39, add_90, rsqrt_39, hidden_states_137, to_83, hidden_states_138, output_68], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf417, arg210_1, buf416, arg211_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg210_1
        del arg211_1
        buf419 = buf417; del buf417  # reuse
        buf420 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu_9, mul_132, output_69], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_16.run(buf413, buf416, buf420, 24576, stream=raw_stream0)
        del buf413
        del buf416
        assert_size_stride_grouped((arg212_1, arg213_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_9, mul_132, output_69], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf420, arg212_1, buf419, arg213_1, 4, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg212_1
        del arg213_1
        del buf420
        assert_size_stride(arg214_1, (2048, ), (1, ), 'input')
        buf424 = buf414; del buf414  # reuse
        buf427 = buf408; del buf408  # reuse
        buf430 = buf377; del buf377  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_139, hidden_states_140, pow_41, variance_40, add_92, rsqrt_40, hidden_states_141, to_85, hidden_states_142, output_70, output_71, output_72], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19.run(buf411, buf419, arg214_1, buf424, buf427, buf430, 4, 2048, stream=raw_stream0)
        del arg214_1
        buf423 = buf368; del buf368  # reuse
        assert_size_stride_grouped((arg215_1, arg216_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_139, hidden_states_140, pow_41, variance_40, add_92, rsqrt_40, hidden_states_141, to_85, hidden_states_142, output_70], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf424, arg215_1, buf423, arg216_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg215_1
        del arg216_1
        del buf424
        buf426 = buf386; del buf386  # reuse
        assert_size_stride_grouped((arg218_1, arg219_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_139, hidden_states_140, pow_41, variance_40, add_92, rsqrt_40, hidden_states_141, to_85, hidden_states_142, output_71], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf427, arg218_1, buf426, arg219_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg218_1
        del arg219_1
        del buf427
        buf429 = empty_strided((1, 4, 1024), (4096, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg221_1, arg222_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_139, hidden_states_140, pow_41, variance_40, add_92, rsqrt_40, hidden_states_141, to_85, hidden_states_142, output_72], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf430, arg221_1, buf429, arg222_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg221_1
        del arg222_1
        buf432 = empty_strided((1, 4, 16, 1), (64, 16, 1, 64), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_143, pow_42, variance_41], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf423, buf432, 64, 128, stream=raw_stream0)
        assert_size_stride(arg217_1, (128, ), (1, ), 'input')
        buf435 = reinterpret_tensor(buf430, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf430  # reuse
        buf433 = reinterpret_tensor(buf435, (1, 16, 4, 64), (8192, 512, 128, 1), 0)  # alias
        buf434 = reinterpret_tensor(buf435, (1, 16, 4, 64), (8192, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_143, pow_42, variance_41, add_93, rsqrt_41, hidden_states_144, to_87, mul_136, query_states_10, x2_20, neg_20, x1_20, cat_22], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg217_1, buf423, buf432, buf433, buf434, 4096, stream=raw_stream0)
        buf436 = empty_strided((1, 4, 8, 1), (32, 8, 1, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_145, pow_43, variance_42], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf426, buf436, 32, 128, stream=raw_stream0)
        del buf433
        del buf434
        assert_size_stride(arg220_1, (128, ), (1, ), 'input')
        buf439 = empty_strided((1, 8, 4, 128), (4096, 512, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf437 = reinterpret_tensor(buf439, (1, 8, 4, 64), (4096, 512, 128, 1), 0)  # alias
        buf438 = reinterpret_tensor(buf439, (1, 8, 4, 64), (4096, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_145, pow_43, variance_42, add_94, rsqrt_42, hidden_states_146, to_89, mul_138, key_states_10, x2_21, neg_21, x1_21, cat_23], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg220_1, buf426, buf436, buf437, buf438, 2048, stream=raw_stream0)
        assert_size_stride_grouped((arg223_1, arg224_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_14, sin_14, arange_14, cache_position_10, hidden_states_145, pow_43, variance_42, add_94, rsqrt_42, hidden_states_146, to_89, mul_138, key_states_10, mul_141, mul_142, k_embed_10, index_copy__20], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg223_1, arg220_1, buf426, buf436, buf1, buf439, buf0, arg224_1, 4096, stream=raw_stream0)
        del arg220_1
        del buf426
        del buf436
        del buf437
        del buf438
        del buf439
        buf441 = reinterpret_tensor(buf407, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf407  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_143, pow_42, variance_41, add_93, rsqrt_41, hidden_states_144, to_87, mul_136, query_states_10, cos_14, mul_139, sin_14, mul_140, q_embed_10, attn_output_30], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg217_1, buf423, buf432, buf1, buf435, buf0, buf441, 8192, stream=raw_stream0)
        del arg217_1
        del buf432
        buf442 = empty_strided((1, 16, 128, 256), (524288, 32768, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [key_10, attn_output_30], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8.run(arg224_1, buf442, 524288, stream=raw_stream0)
        del arg224_1
        buf443 = reinterpret_tensor(buf405, (16, 4, 256), (1024, 256, 1), 0); del buf405  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_143, pow_42, variance_41, add_93, rsqrt_41, hidden_states_144, to_87, mul_136, query_states_10, cos_14, mul_139, sin_14, mul_140, q_embed_10, attn_output_30, key_10], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9.run(buf441, buf442, buf443, 16, 16, 1, stream=raw_stream0)
        del buf442
        buf446 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        buf449 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_30], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10.run(buf443, arg3_1, buf446, buf449, 64, 256, stream=raw_stream0)
        del buf443
        del buf446
        assert_size_stride(arg225_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_14, cache_position_10, index_copy__21], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_11.run(arg223_1, buf429, arg225_1, 4096, stream=raw_stream0)
        buf450 = empty_strided((1, 16, 256, 128), (524288, 32768, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [value_10, attn_output_30], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(arg225_1, buf450, 524288, stream=raw_stream0)
        del arg225_1
        buf451 = reinterpret_tensor(buf441, (16, 4, 128), (512, 128, 1), 0); del buf441  # reuse
        # Topologically Sorted Source Nodes: [attn_output_30, value_10], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13.run(buf449, buf450, buf451, 8, 16, 1, stream=raw_stream0)
        del buf450
        buf452 = reinterpret_tensor(buf435, (1, 4, 2048), (8192, 2048, 1), 0); del buf435  # reuse
        buf453 = reinterpret_tensor(buf423, (1, 4, 2048), (2048, 2048, 1), 0); del buf423  # reuse
        # Topologically Sorted Source Nodes: [attn_output_30, transpose_43, reshape_32, output_73], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14.run(buf451, buf453, 8192, stream=raw_stream0)
        assert_size_stride_grouped((arg226_1, arg227_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_30, transpose_43, reshape_32, output_73], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf453, arg226_1, buf452, arg227_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg226_1
        del arg227_1
        assert_size_stride(arg228_1, (2048, ), (1, ), 'input')
        buf456 = reinterpret_tensor(buf453, (1, 4, 2048), (8192, 2048, 1), 0); del buf453  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_139, hidden_states_149, hidden_states_150, pow_44, variance_43, add_99, rsqrt_43, hidden_states_151, to_91, hidden_states_152], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20.run(buf411, buf419, buf452, arg228_1, buf456, 4, 2048, stream=raw_stream0)
        del arg228_1
        buf457 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg229_1, arg230_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_74], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf456, arg229_1, buf457, arg230_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg229_1
        del arg230_1
        buf459 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg231_1, arg232_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_75], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf456, arg231_1, buf459, arg232_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg231_1
        del arg232_1
        buf461 = buf456; del buf456  # reuse
        buf462 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu_10, mul_145, output_76], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_16.run(buf457, buf459, buf462, 24576, stream=raw_stream0)
        del buf457
        del buf459
        assert_size_stride_grouped((arg233_1, arg234_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_10, mul_145, output_76], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf462, arg233_1, buf461, arg234_1, 4, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg233_1
        del arg234_1
        del buf462
        assert_size_stride(arg235_1, (2048, ), (1, ), 'input')
        buf465 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_139, hidden_states_149, hidden_states_153, hidden_states_154, pow_45, variance_44, add_101, rsqrt_44, hidden_states_155, to_93, hidden_states_156], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21.run(buf411, buf419, buf452, buf461, arg235_1, buf465, 4, 2048, stream=raw_stream0)
        del arg235_1
        buf466 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg236_1, arg237_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_77], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf465, arg236_1, buf466, arg237_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg236_1
        del arg237_1
        buf468 = buf429; del buf429  # reuse
        assert_size_stride_grouped((arg239_1, arg240_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_78], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf465, arg239_1, buf468, arg240_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg239_1
        del arg240_1
        buf470 = empty_strided((1, 4, 1024), (4096, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg242_1, arg243_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_79], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf465, arg242_1, buf470, arg243_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg242_1
        del arg243_1
        buf472 = empty_strided((1, 4, 16, 1), (64, 16, 1, 64), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_157, pow_46, variance_45], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf466, buf472, 64, 128, stream=raw_stream0)
        assert_size_stride(arg238_1, (128, ), (1, ), 'input')
        buf475 = reinterpret_tensor(buf465, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf465  # reuse
        buf473 = reinterpret_tensor(buf475, (1, 16, 4, 64), (8192, 512, 128, 1), 0)  # alias
        buf474 = reinterpret_tensor(buf475, (1, 16, 4, 64), (8192, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_157, pow_46, variance_45, add_102, rsqrt_45, hidden_states_158, to_95, mul_149, query_states_11, x2_22, neg_22, x1_22, cat_24], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg238_1, buf466, buf472, buf473, buf474, 4096, stream=raw_stream0)
        buf476 = empty_strided((1, 4, 8, 1), (32, 8, 1, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_159, pow_47, variance_46], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf468, buf476, 32, 128, stream=raw_stream0)
        del buf473
        del buf474
        assert_size_stride(arg241_1, (128, ), (1, ), 'input')
        buf479 = empty_strided((1, 8, 4, 128), (4096, 512, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf477 = reinterpret_tensor(buf479, (1, 8, 4, 64), (4096, 512, 128, 1), 0)  # alias
        buf478 = reinterpret_tensor(buf479, (1, 8, 4, 64), (4096, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_159, pow_47, variance_46, add_103, rsqrt_46, hidden_states_160, to_97, mul_151, key_states_11, x2_23, neg_23, x1_23, cat_25], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg241_1, buf468, buf476, buf477, buf478, 2048, stream=raw_stream0)
        assert_size_stride_grouped((arg244_1, arg245_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_15, sin_15, arange_15, cache_position_11, hidden_states_159, pow_47, variance_46, add_103, rsqrt_46, hidden_states_160, to_97, mul_151, key_states_11, mul_154, mul_155, k_embed_11, index_copy__22], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg244_1, arg241_1, buf468, buf476, buf1, buf479, buf0, arg245_1, 4096, stream=raw_stream0)
        del arg241_1
        del buf468
        del buf476
        del buf477
        del buf478
        del buf479
        buf481 = reinterpret_tensor(buf451, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf451  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_157, pow_46, variance_45, add_102, rsqrt_45, hidden_states_158, to_95, mul_149, query_states_11, cos_15, mul_152, sin_15, mul_153, q_embed_11, attn_output_33], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg238_1, buf466, buf472, buf1, buf475, buf0, buf481, 8192, stream=raw_stream0)
        del arg238_1
        del buf466
        del buf472
        del buf475
        buf482 = empty_strided((1, 16, 128, 256), (524288, 32768, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [key_11, attn_output_33], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8.run(arg245_1, buf482, 524288, stream=raw_stream0)
        del arg245_1
        buf483 = reinterpret_tensor(buf449, (16, 4, 256), (1024, 256, 1), 0); del buf449  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_157, pow_46, variance_45, add_102, rsqrt_45, hidden_states_158, to_95, mul_149, query_states_11, cos_15, mul_152, sin_15, mul_153, q_embed_11, attn_output_33, key_11], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9.run(buf481, buf482, buf483, 16, 16, 1, stream=raw_stream0)
        del buf482
        buf486 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        buf489 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_33], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10.run(buf483, arg3_1, buf486, buf489, 64, 256, stream=raw_stream0)
        del buf483
        del buf486
        assert_size_stride(arg246_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_15, cache_position_11, index_copy__23], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_11.run(arg244_1, buf470, arg246_1, 4096, stream=raw_stream0)
        buf490 = empty_strided((1, 16, 256, 128), (524288, 32768, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [value_11, attn_output_33], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(arg246_1, buf490, 524288, stream=raw_stream0)
        del arg246_1
        buf491 = reinterpret_tensor(buf481, (16, 4, 128), (512, 128, 1), 0); del buf481  # reuse
        # Topologically Sorted Source Nodes: [attn_output_33, value_11], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13.run(buf489, buf490, buf491, 8, 16, 1, stream=raw_stream0)
        del buf490
        buf492 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        buf493 = empty_strided((1, 4, 2048), (2048, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [attn_output_33, transpose_47, reshape_35, output_80], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14.run(buf491, buf493, 8192, stream=raw_stream0)
        assert_size_stride_grouped((arg247_1, arg248_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_33, transpose_47, reshape_35, output_80], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf493, arg247_1, buf492, arg248_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg247_1
        del arg248_1
        assert_size_stride(arg249_1, (2048, ), (1, ), 'input')
        buf495 = buf411; del buf411  # reuse
        buf498 = reinterpret_tensor(buf493, (1, 4, 2048), (8192, 2048, 1), 0); del buf493  # reuse
        buf501 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_139, hidden_states_149, hidden_states_153, hidden_states_163, hidden_states_164, pow_48, variance_47, add_108, rsqrt_47, hidden_states_165, to_99, hidden_states_166, output_81, output_82], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_22.run(buf495, buf419, buf452, buf461, buf492, arg249_1, buf498, buf501, 4, 2048, stream=raw_stream0)
        del arg249_1
        del buf419
        buf497 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg250_1, arg251_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_164, pow_48, variance_47, add_108, rsqrt_47, hidden_states_165, to_99, hidden_states_166, output_81], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf498, arg250_1, buf497, arg251_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg250_1
        del arg251_1
        buf500 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg252_1, arg253_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_164, pow_48, variance_47, add_108, rsqrt_47, hidden_states_165, to_99, hidden_states_166, output_82], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf501, arg252_1, buf500, arg253_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg252_1
        del arg253_1
        buf503 = buf501; del buf501  # reuse
        buf504 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu_11, mul_158, output_83], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_16.run(buf497, buf500, buf504, 24576, stream=raw_stream0)
        del buf497
        del buf500
        assert_size_stride_grouped((arg254_1, arg255_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_11, mul_158, output_83], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf504, arg254_1, buf503, arg255_1, 4, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg254_1
        del arg255_1
        del buf504
        assert_size_stride(arg256_1, (2048, ), (1, ), 'input')
        buf508 = buf498; del buf498  # reuse
        buf511 = buf492; del buf492  # reuse
        buf514 = buf461; del buf461  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_167, hidden_states_168, pow_49, variance_48, add_110, rsqrt_48, hidden_states_169, to_101, hidden_states_170, output_84, output_85, output_86], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19.run(buf495, buf503, arg256_1, buf508, buf511, buf514, 4, 2048, stream=raw_stream0)
        del arg256_1
        buf507 = buf452; del buf452  # reuse
        assert_size_stride_grouped((arg257_1, arg258_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_167, hidden_states_168, pow_49, variance_48, add_110, rsqrt_48, hidden_states_169, to_101, hidden_states_170, output_84], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf508, arg257_1, buf507, arg258_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg257_1
        del arg258_1
        del buf508
        buf510 = buf470; del buf470  # reuse
        assert_size_stride_grouped((arg260_1, arg261_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_167, hidden_states_168, pow_49, variance_48, add_110, rsqrt_48, hidden_states_169, to_101, hidden_states_170, output_85], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf511, arg260_1, buf510, arg261_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg260_1
        del arg261_1
        del buf511
        buf513 = empty_strided((1, 4, 1024), (4096, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg263_1, arg264_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_167, hidden_states_168, pow_49, variance_48, add_110, rsqrt_48, hidden_states_169, to_101, hidden_states_170, output_86], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf514, arg263_1, buf513, arg264_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg263_1
        del arg264_1
        buf516 = empty_strided((1, 4, 16, 1), (64, 16, 1, 64), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_171, pow_50, variance_49], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf507, buf516, 64, 128, stream=raw_stream0)
        assert_size_stride(arg259_1, (128, ), (1, ), 'input')
        buf519 = reinterpret_tensor(buf514, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf514  # reuse
        buf517 = reinterpret_tensor(buf519, (1, 16, 4, 64), (8192, 512, 128, 1), 0)  # alias
        buf518 = reinterpret_tensor(buf519, (1, 16, 4, 64), (8192, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_171, pow_50, variance_49, add_111, rsqrt_49, hidden_states_172, to_103, mul_162, query_states_12, x2_24, neg_24, x1_24, cat_26], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg259_1, buf507, buf516, buf517, buf518, 4096, stream=raw_stream0)
        buf520 = empty_strided((1, 4, 8, 1), (32, 8, 1, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_173, pow_51, variance_50], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf510, buf520, 32, 128, stream=raw_stream0)
        del buf517
        del buf518
        assert_size_stride(arg262_1, (128, ), (1, ), 'input')
        buf523 = empty_strided((1, 8, 4, 128), (4096, 512, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf521 = reinterpret_tensor(buf523, (1, 8, 4, 64), (4096, 512, 128, 1), 0)  # alias
        buf522 = reinterpret_tensor(buf523, (1, 8, 4, 64), (4096, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_173, pow_51, variance_50, add_112, rsqrt_50, hidden_states_174, to_105, mul_164, key_states_12, x2_25, neg_25, x1_25, cat_27], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg262_1, buf510, buf520, buf521, buf522, 2048, stream=raw_stream0)
        assert_size_stride_grouped((arg265_1, arg266_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_16, sin_16, arange_16, cache_position_12, hidden_states_173, pow_51, variance_50, add_112, rsqrt_50, hidden_states_174, to_105, mul_164, key_states_12, mul_167, mul_168, k_embed_12, index_copy__24], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg265_1, arg262_1, buf510, buf520, buf1, buf523, buf0, arg266_1, 4096, stream=raw_stream0)
        del arg262_1
        del buf510
        del buf520
        del buf521
        del buf522
        del buf523
        buf525 = reinterpret_tensor(buf491, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf491  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_171, pow_50, variance_49, add_111, rsqrt_49, hidden_states_172, to_103, mul_162, query_states_12, cos_16, mul_165, sin_16, mul_166, q_embed_12, attn_output_36], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg259_1, buf507, buf516, buf1, buf519, buf0, buf525, 8192, stream=raw_stream0)
        del arg259_1
        del buf516
        buf526 = empty_strided((1, 16, 128, 256), (524288, 32768, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [key_12, attn_output_36], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8.run(arg266_1, buf526, 524288, stream=raw_stream0)
        del arg266_1
        buf527 = reinterpret_tensor(buf489, (16, 4, 256), (1024, 256, 1), 0); del buf489  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_171, pow_50, variance_49, add_111, rsqrt_49, hidden_states_172, to_103, mul_162, query_states_12, cos_16, mul_165, sin_16, mul_166, q_embed_12, attn_output_36, key_12], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9.run(buf525, buf526, buf527, 16, 16, 1, stream=raw_stream0)
        del buf526
        buf530 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        buf533 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_36], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10.run(buf527, arg3_1, buf530, buf533, 64, 256, stream=raw_stream0)
        del buf527
        del buf530
        assert_size_stride(arg267_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_16, cache_position_12, index_copy__25], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_11.run(arg265_1, buf513, arg267_1, 4096, stream=raw_stream0)
        buf534 = empty_strided((1, 16, 256, 128), (524288, 32768, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [value_12, attn_output_36], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(arg267_1, buf534, 524288, stream=raw_stream0)
        del arg267_1
        buf535 = reinterpret_tensor(buf525, (16, 4, 128), (512, 128, 1), 0); del buf525  # reuse
        # Topologically Sorted Source Nodes: [attn_output_36, value_12], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13.run(buf533, buf534, buf535, 8, 16, 1, stream=raw_stream0)
        del buf534
        buf536 = reinterpret_tensor(buf519, (1, 4, 2048), (8192, 2048, 1), 0); del buf519  # reuse
        buf537 = reinterpret_tensor(buf507, (1, 4, 2048), (2048, 2048, 1), 0); del buf507  # reuse
        # Topologically Sorted Source Nodes: [attn_output_36, transpose_51, reshape_38, output_87], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14.run(buf535, buf537, 8192, stream=raw_stream0)
        assert_size_stride_grouped((arg268_1, arg269_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_36, transpose_51, reshape_38, output_87], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf537, arg268_1, buf536, arg269_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg268_1
        del arg269_1
        assert_size_stride(arg270_1, (2048, ), (1, ), 'input')
        buf540 = reinterpret_tensor(buf537, (1, 4, 2048), (8192, 2048, 1), 0); del buf537  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_167, hidden_states_177, hidden_states_178, pow_52, variance_51, add_117, rsqrt_51, hidden_states_179, to_107, hidden_states_180], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20.run(buf495, buf503, buf536, arg270_1, buf540, 4, 2048, stream=raw_stream0)
        del arg270_1
        buf541 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg271_1, arg272_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_88], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf540, arg271_1, buf541, arg272_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg271_1
        del arg272_1
        buf543 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg273_1, arg274_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_89], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf540, arg273_1, buf543, arg274_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg273_1
        del arg274_1
        buf545 = buf540; del buf540  # reuse
        buf546 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu_12, mul_171, output_90], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_16.run(buf541, buf543, buf546, 24576, stream=raw_stream0)
        del buf541
        del buf543
        assert_size_stride_grouped((arg275_1, arg276_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_12, mul_171, output_90], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf546, arg275_1, buf545, arg276_1, 4, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg275_1
        del arg276_1
        del buf546
        assert_size_stride(arg277_1, (2048, ), (1, ), 'input')
        buf549 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_167, hidden_states_177, hidden_states_181, hidden_states_182, pow_53, variance_52, add_119, rsqrt_52, hidden_states_183, to_109, hidden_states_184], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21.run(buf495, buf503, buf536, buf545, arg277_1, buf549, 4, 2048, stream=raw_stream0)
        del arg277_1
        buf550 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg278_1, arg279_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_91], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf549, arg278_1, buf550, arg279_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg278_1
        del arg279_1
        buf552 = buf513; del buf513  # reuse
        assert_size_stride_grouped((arg281_1, arg282_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_92], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf549, arg281_1, buf552, arg282_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg281_1
        del arg282_1
        buf554 = empty_strided((1, 4, 1024), (4096, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg284_1, arg285_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_93], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf549, arg284_1, buf554, arg285_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg284_1
        del arg285_1
        buf556 = empty_strided((1, 4, 16, 1), (64, 16, 1, 64), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_185, pow_54, variance_53], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf550, buf556, 64, 128, stream=raw_stream0)
        assert_size_stride(arg280_1, (128, ), (1, ), 'input')
        buf559 = reinterpret_tensor(buf549, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf549  # reuse
        buf557 = reinterpret_tensor(buf559, (1, 16, 4, 64), (8192, 512, 128, 1), 0)  # alias
        buf558 = reinterpret_tensor(buf559, (1, 16, 4, 64), (8192, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_185, pow_54, variance_53, add_120, rsqrt_53, hidden_states_186, to_111, mul_175, query_states_13, x2_26, neg_26, x1_26, cat_28], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg280_1, buf550, buf556, buf557, buf558, 4096, stream=raw_stream0)
        buf560 = empty_strided((1, 4, 8, 1), (32, 8, 1, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_187, pow_55, variance_54], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf552, buf560, 32, 128, stream=raw_stream0)
        del buf557
        del buf558
        assert_size_stride(arg283_1, (128, ), (1, ), 'input')
        buf563 = empty_strided((1, 8, 4, 128), (4096, 512, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf561 = reinterpret_tensor(buf563, (1, 8, 4, 64), (4096, 512, 128, 1), 0)  # alias
        buf562 = reinterpret_tensor(buf563, (1, 8, 4, 64), (4096, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_187, pow_55, variance_54, add_121, rsqrt_54, hidden_states_188, to_113, mul_177, key_states_13, x2_27, neg_27, x1_27, cat_29], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg283_1, buf552, buf560, buf561, buf562, 2048, stream=raw_stream0)
        assert_size_stride_grouped((arg286_1, arg287_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_17, sin_17, arange_17, cache_position_13, hidden_states_187, pow_55, variance_54, add_121, rsqrt_54, hidden_states_188, to_113, mul_177, key_states_13, mul_180, mul_181, k_embed_13, index_copy__26], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg286_1, arg283_1, buf552, buf560, buf1, buf563, buf0, arg287_1, 4096, stream=raw_stream0)
        del arg283_1
        del buf552
        del buf560
        del buf561
        del buf562
        del buf563
        buf565 = reinterpret_tensor(buf535, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf535  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_185, pow_54, variance_53, add_120, rsqrt_53, hidden_states_186, to_111, mul_175, query_states_13, cos_17, mul_178, sin_17, mul_179, q_embed_13, attn_output_39], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg280_1, buf550, buf556, buf1, buf559, buf0, buf565, 8192, stream=raw_stream0)
        del arg280_1
        del buf550
        del buf556
        del buf559
        buf566 = empty_strided((1, 16, 128, 256), (524288, 32768, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [key_13, attn_output_39], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8.run(arg287_1, buf566, 524288, stream=raw_stream0)
        del arg287_1
        buf567 = reinterpret_tensor(buf533, (16, 4, 256), (1024, 256, 1), 0); del buf533  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_185, pow_54, variance_53, add_120, rsqrt_53, hidden_states_186, to_111, mul_175, query_states_13, cos_17, mul_178, sin_17, mul_179, q_embed_13, attn_output_39, key_13], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9.run(buf565, buf566, buf567, 16, 16, 1, stream=raw_stream0)
        del buf566
        buf570 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        buf573 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_39], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10.run(buf567, arg3_1, buf570, buf573, 64, 256, stream=raw_stream0)
        del buf567
        del buf570
        assert_size_stride(arg288_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_17, cache_position_13, index_copy__27], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_11.run(arg286_1, buf554, arg288_1, 4096, stream=raw_stream0)
        buf574 = empty_strided((1, 16, 256, 128), (524288, 32768, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [value_13, attn_output_39], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(arg288_1, buf574, 524288, stream=raw_stream0)
        del arg288_1
        buf575 = reinterpret_tensor(buf565, (16, 4, 128), (512, 128, 1), 0); del buf565  # reuse
        # Topologically Sorted Source Nodes: [attn_output_39, value_13], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13.run(buf573, buf574, buf575, 8, 16, 1, stream=raw_stream0)
        del buf574
        buf576 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        buf577 = empty_strided((1, 4, 2048), (2048, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [attn_output_39, transpose_55, reshape_41, output_94], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14.run(buf575, buf577, 8192, stream=raw_stream0)
        assert_size_stride_grouped((arg289_1, arg290_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_39, transpose_55, reshape_41, output_94], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf577, arg289_1, buf576, arg290_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg289_1
        del arg290_1
        assert_size_stride(arg291_1, (2048, ), (1, ), 'input')
        buf579 = buf495; del buf495  # reuse
        buf582 = reinterpret_tensor(buf577, (1, 4, 2048), (8192, 2048, 1), 0); del buf577  # reuse
        buf585 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_167, hidden_states_177, hidden_states_181, hidden_states_191, hidden_states_192, pow_56, variance_55, add_126, rsqrt_55, hidden_states_193, to_115, hidden_states_194, output_95, output_96], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_22.run(buf579, buf503, buf536, buf545, buf576, arg291_1, buf582, buf585, 4, 2048, stream=raw_stream0)
        del arg291_1
        del buf503
        buf581 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg292_1, arg293_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_192, pow_56, variance_55, add_126, rsqrt_55, hidden_states_193, to_115, hidden_states_194, output_95], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf582, arg292_1, buf581, arg293_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg292_1
        del arg293_1
        buf584 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg294_1, arg295_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_192, pow_56, variance_55, add_126, rsqrt_55, hidden_states_193, to_115, hidden_states_194, output_96], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf585, arg294_1, buf584, arg295_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg294_1
        del arg295_1
        buf587 = buf585; del buf585  # reuse
        buf588 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu_13, mul_184, output_97], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_16.run(buf581, buf584, buf588, 24576, stream=raw_stream0)
        del buf581
        del buf584
        assert_size_stride_grouped((arg296_1, arg297_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_13, mul_184, output_97], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf588, arg296_1, buf587, arg297_1, 4, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg296_1
        del arg297_1
        del buf588
        assert_size_stride(arg298_1, (2048, ), (1, ), 'input')
        buf592 = buf582; del buf582  # reuse
        buf595 = buf576; del buf576  # reuse
        buf598 = buf545; del buf545  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_195, hidden_states_196, pow_57, variance_56, add_128, rsqrt_56, hidden_states_197, to_117, hidden_states_198, output_98, output_99, output_100], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19.run(buf579, buf587, arg298_1, buf592, buf595, buf598, 4, 2048, stream=raw_stream0)
        del arg298_1
        buf591 = buf536; del buf536  # reuse
        assert_size_stride_grouped((arg299_1, arg300_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_195, hidden_states_196, pow_57, variance_56, add_128, rsqrt_56, hidden_states_197, to_117, hidden_states_198, output_98], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf592, arg299_1, buf591, arg300_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg299_1
        del arg300_1
        del buf592
        buf594 = buf554; del buf554  # reuse
        assert_size_stride_grouped((arg302_1, arg303_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_195, hidden_states_196, pow_57, variance_56, add_128, rsqrt_56, hidden_states_197, to_117, hidden_states_198, output_99], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf595, arg302_1, buf594, arg303_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg302_1
        del arg303_1
        del buf595
        buf597 = empty_strided((1, 4, 1024), (4096, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg305_1, arg306_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_195, hidden_states_196, pow_57, variance_56, add_128, rsqrt_56, hidden_states_197, to_117, hidden_states_198, output_100], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf598, arg305_1, buf597, arg306_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg305_1
        del arg306_1
        buf600 = empty_strided((1, 4, 16, 1), (64, 16, 1, 64), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_199, pow_58, variance_57], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf591, buf600, 64, 128, stream=raw_stream0)
        assert_size_stride(arg301_1, (128, ), (1, ), 'input')
        buf603 = reinterpret_tensor(buf598, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf598  # reuse
        buf601 = reinterpret_tensor(buf603, (1, 16, 4, 64), (8192, 512, 128, 1), 0)  # alias
        buf602 = reinterpret_tensor(buf603, (1, 16, 4, 64), (8192, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_199, pow_58, variance_57, add_129, rsqrt_57, hidden_states_200, to_119, mul_188, query_states_14, x2_28, neg_28, x1_28, cat_30], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg301_1, buf591, buf600, buf601, buf602, 4096, stream=raw_stream0)
        buf604 = empty_strided((1, 4, 8, 1), (32, 8, 1, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_201, pow_59, variance_58], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf594, buf604, 32, 128, stream=raw_stream0)
        del buf601
        del buf602
        assert_size_stride(arg304_1, (128, ), (1, ), 'input')
        buf607 = empty_strided((1, 8, 4, 128), (4096, 512, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf605 = reinterpret_tensor(buf607, (1, 8, 4, 64), (4096, 512, 128, 1), 0)  # alias
        buf606 = reinterpret_tensor(buf607, (1, 8, 4, 64), (4096, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_201, pow_59, variance_58, add_130, rsqrt_58, hidden_states_202, to_121, mul_190, key_states_14, x2_29, neg_29, x1_29, cat_31], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg304_1, buf594, buf604, buf605, buf606, 2048, stream=raw_stream0)
        assert_size_stride_grouped((arg307_1, arg308_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_18, sin_18, arange_18, cache_position_14, hidden_states_201, pow_59, variance_58, add_130, rsqrt_58, hidden_states_202, to_121, mul_190, key_states_14, mul_193, mul_194, k_embed_14, index_copy__28], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg307_1, arg304_1, buf594, buf604, buf1, buf607, buf0, arg308_1, 4096, stream=raw_stream0)
        del arg304_1
        del buf594
        del buf604
        del buf605
        del buf606
        del buf607
        buf609 = reinterpret_tensor(buf575, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf575  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_199, pow_58, variance_57, add_129, rsqrt_57, hidden_states_200, to_119, mul_188, query_states_14, cos_18, mul_191, sin_18, mul_192, q_embed_14, attn_output_42], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg301_1, buf591, buf600, buf1, buf603, buf0, buf609, 8192, stream=raw_stream0)
        del arg301_1
        del buf600
        buf610 = empty_strided((1, 16, 128, 256), (524288, 32768, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [key_14, attn_output_42], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8.run(arg308_1, buf610, 524288, stream=raw_stream0)
        del arg308_1
        buf611 = reinterpret_tensor(buf573, (16, 4, 256), (1024, 256, 1), 0); del buf573  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_199, pow_58, variance_57, add_129, rsqrt_57, hidden_states_200, to_119, mul_188, query_states_14, cos_18, mul_191, sin_18, mul_192, q_embed_14, attn_output_42, key_14], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9.run(buf609, buf610, buf611, 16, 16, 1, stream=raw_stream0)
        del buf610
        buf614 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        buf617 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_42], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10.run(buf611, arg3_1, buf614, buf617, 64, 256, stream=raw_stream0)
        del buf611
        del buf614
        assert_size_stride(arg309_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_18, cache_position_14, index_copy__29], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_11.run(arg307_1, buf597, arg309_1, 4096, stream=raw_stream0)
        buf618 = empty_strided((1, 16, 256, 128), (524288, 32768, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [value_14, attn_output_42], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(arg309_1, buf618, 524288, stream=raw_stream0)
        del arg309_1
        buf619 = reinterpret_tensor(buf609, (16, 4, 128), (512, 128, 1), 0); del buf609  # reuse
        # Topologically Sorted Source Nodes: [attn_output_42, value_14], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13.run(buf617, buf618, buf619, 8, 16, 1, stream=raw_stream0)
        del buf618
        buf620 = reinterpret_tensor(buf603, (1, 4, 2048), (8192, 2048, 1), 0); del buf603  # reuse
        buf621 = reinterpret_tensor(buf591, (1, 4, 2048), (2048, 2048, 1), 0); del buf591  # reuse
        # Topologically Sorted Source Nodes: [attn_output_42, transpose_59, reshape_44, output_101], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14.run(buf619, buf621, 8192, stream=raw_stream0)
        assert_size_stride_grouped((arg310_1, arg311_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_42, transpose_59, reshape_44, output_101], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf621, arg310_1, buf620, arg311_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg310_1
        del arg311_1
        assert_size_stride(arg312_1, (2048, ), (1, ), 'input')
        buf624 = reinterpret_tensor(buf621, (1, 4, 2048), (8192, 2048, 1), 0); del buf621  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_195, hidden_states_205, hidden_states_206, pow_60, variance_59, add_135, rsqrt_59, hidden_states_207, to_123, hidden_states_208], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20.run(buf579, buf587, buf620, arg312_1, buf624, 4, 2048, stream=raw_stream0)
        del arg312_1
        buf625 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg313_1, arg314_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_102], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf624, arg313_1, buf625, arg314_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg313_1
        del arg314_1
        buf627 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg315_1, arg316_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_103], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf624, arg315_1, buf627, arg316_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg315_1
        del arg316_1
        buf629 = buf624; del buf624  # reuse
        buf630 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu_14, mul_197, output_104], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_16.run(buf625, buf627, buf630, 24576, stream=raw_stream0)
        del buf625
        del buf627
        assert_size_stride_grouped((arg317_1, arg318_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_14, mul_197, output_104], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf630, arg317_1, buf629, arg318_1, 4, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg317_1
        del arg318_1
        del buf630
        assert_size_stride(arg319_1, (2048, ), (1, ), 'input')
        buf633 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_195, hidden_states_205, hidden_states_209, hidden_states_210, pow_61, variance_60, add_137, rsqrt_60, hidden_states_211, to_125, hidden_states_212], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21.run(buf579, buf587, buf620, buf629, arg319_1, buf633, 4, 2048, stream=raw_stream0)
        del arg319_1
        buf634 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg320_1, arg321_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_105], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf633, arg320_1, buf634, arg321_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg320_1
        del arg321_1
        buf636 = buf597; del buf597  # reuse
        assert_size_stride_grouped((arg323_1, arg324_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_106], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf633, arg323_1, buf636, arg324_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg323_1
        del arg324_1
        buf638 = empty_strided((1, 4, 1024), (4096, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg326_1, arg327_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_107], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf633, arg326_1, buf638, arg327_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg326_1
        del arg327_1
        buf640 = empty_strided((1, 4, 16, 1), (64, 16, 1, 64), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_213, pow_62, variance_61], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf634, buf640, 64, 128, stream=raw_stream0)
        assert_size_stride(arg322_1, (128, ), (1, ), 'input')
        buf643 = reinterpret_tensor(buf633, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf633  # reuse
        buf641 = reinterpret_tensor(buf643, (1, 16, 4, 64), (8192, 512, 128, 1), 0)  # alias
        buf642 = reinterpret_tensor(buf643, (1, 16, 4, 64), (8192, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_213, pow_62, variance_61, add_138, rsqrt_61, hidden_states_214, to_127, mul_201, query_states_15, x2_30, neg_30, x1_30, cat_32], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg322_1, buf634, buf640, buf641, buf642, 4096, stream=raw_stream0)
        buf644 = empty_strided((1, 4, 8, 1), (32, 8, 1, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_215, pow_63, variance_62], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf636, buf644, 32, 128, stream=raw_stream0)
        del buf641
        del buf642
        assert_size_stride(arg325_1, (128, ), (1, ), 'input')
        buf647 = empty_strided((1, 8, 4, 128), (4096, 512, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf645 = reinterpret_tensor(buf647, (1, 8, 4, 64), (4096, 512, 128, 1), 0)  # alias
        buf646 = reinterpret_tensor(buf647, (1, 8, 4, 64), (4096, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_215, pow_63, variance_62, add_139, rsqrt_62, hidden_states_216, to_129, mul_203, key_states_15, x2_31, neg_31, x1_31, cat_33], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg325_1, buf636, buf644, buf645, buf646, 2048, stream=raw_stream0)
        assert_size_stride_grouped((arg328_1, arg329_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_19, sin_19, arange_19, cache_position_15, hidden_states_215, pow_63, variance_62, add_139, rsqrt_62, hidden_states_216, to_129, mul_203, key_states_15, mul_206, mul_207, k_embed_15, index_copy__30], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg328_1, arg325_1, buf636, buf644, buf1, buf647, buf0, arg329_1, 4096, stream=raw_stream0)
        del arg325_1
        del buf636
        del buf644
        del buf645
        del buf646
        del buf647
        buf649 = reinterpret_tensor(buf619, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf619  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_213, pow_62, variance_61, add_138, rsqrt_61, hidden_states_214, to_127, mul_201, query_states_15, cos_19, mul_204, sin_19, mul_205, q_embed_15, attn_output_45], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg322_1, buf634, buf640, buf1, buf643, buf0, buf649, 8192, stream=raw_stream0)
        del arg322_1
        del buf634
        del buf640
        del buf643
        buf650 = empty_strided((1, 16, 128, 256), (524288, 32768, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [key_15, attn_output_45], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8.run(arg329_1, buf650, 524288, stream=raw_stream0)
        del arg329_1
        buf651 = reinterpret_tensor(buf617, (16, 4, 256), (1024, 256, 1), 0); del buf617  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_213, pow_62, variance_61, add_138, rsqrt_61, hidden_states_214, to_127, mul_201, query_states_15, cos_19, mul_204, sin_19, mul_205, q_embed_15, attn_output_45, key_15], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9.run(buf649, buf650, buf651, 16, 16, 1, stream=raw_stream0)
        del buf650
        buf654 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        buf657 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_45], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10.run(buf651, arg3_1, buf654, buf657, 64, 256, stream=raw_stream0)
        del buf651
        del buf654
        assert_size_stride(arg330_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_19, cache_position_15, index_copy__31], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_11.run(arg328_1, buf638, arg330_1, 4096, stream=raw_stream0)
        buf658 = empty_strided((1, 16, 256, 128), (524288, 32768, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [value_15, attn_output_45], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(arg330_1, buf658, 524288, stream=raw_stream0)
        del arg330_1
        buf659 = reinterpret_tensor(buf649, (16, 4, 128), (512, 128, 1), 0); del buf649  # reuse
        # Topologically Sorted Source Nodes: [attn_output_45, value_15], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13.run(buf657, buf658, buf659, 8, 16, 1, stream=raw_stream0)
        del buf658
        buf660 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        buf661 = empty_strided((1, 4, 2048), (2048, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [attn_output_45, transpose_63, reshape_47, output_108], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14.run(buf659, buf661, 8192, stream=raw_stream0)
        assert_size_stride_grouped((arg331_1, arg332_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_45, transpose_63, reshape_47, output_108], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf661, arg331_1, buf660, arg332_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg331_1
        del arg332_1
        assert_size_stride(arg333_1, (2048, ), (1, ), 'input')
        buf663 = buf579; del buf579  # reuse
        buf666 = reinterpret_tensor(buf661, (1, 4, 2048), (8192, 2048, 1), 0); del buf661  # reuse
        buf669 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_195, hidden_states_205, hidden_states_209, hidden_states_219, hidden_states_220, pow_64, variance_63, add_144, rsqrt_63, hidden_states_221, to_131, hidden_states_222, output_109, output_110], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_22.run(buf663, buf587, buf620, buf629, buf660, arg333_1, buf666, buf669, 4, 2048, stream=raw_stream0)
        del arg333_1
        del buf587
        buf665 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg334_1, arg335_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_220, pow_64, variance_63, add_144, rsqrt_63, hidden_states_221, to_131, hidden_states_222, output_109], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf666, arg334_1, buf665, arg335_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg334_1
        del arg335_1
        buf668 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg336_1, arg337_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_220, pow_64, variance_63, add_144, rsqrt_63, hidden_states_221, to_131, hidden_states_222, output_110], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf669, arg336_1, buf668, arg337_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg336_1
        del arg337_1
        buf671 = buf669; del buf669  # reuse
        buf672 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu_15, mul_210, output_111], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_16.run(buf665, buf668, buf672, 24576, stream=raw_stream0)
        del buf665
        del buf668
        assert_size_stride_grouped((arg338_1, arg339_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_15, mul_210, output_111], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf672, arg338_1, buf671, arg339_1, 4, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg338_1
        del arg339_1
        del buf672
        assert_size_stride(arg340_1, (2048, ), (1, ), 'input')
        buf676 = buf666; del buf666  # reuse
        buf679 = buf660; del buf660  # reuse
        buf682 = buf629; del buf629  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_223, hidden_states_224, pow_65, variance_64, add_146, rsqrt_64, hidden_states_225, to_133, hidden_states_226, output_112, output_113, output_114], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19.run(buf663, buf671, arg340_1, buf676, buf679, buf682, 4, 2048, stream=raw_stream0)
        del arg340_1
        buf675 = buf620; del buf620  # reuse
        assert_size_stride_grouped((arg341_1, arg342_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_223, hidden_states_224, pow_65, variance_64, add_146, rsqrt_64, hidden_states_225, to_133, hidden_states_226, output_112], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf676, arg341_1, buf675, arg342_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg341_1
        del arg342_1
        del buf676
        buf678 = buf638; del buf638  # reuse
        assert_size_stride_grouped((arg344_1, arg345_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_223, hidden_states_224, pow_65, variance_64, add_146, rsqrt_64, hidden_states_225, to_133, hidden_states_226, output_113], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf679, arg344_1, buf678, arg345_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg344_1
        del arg345_1
        del buf679
        buf681 = empty_strided((1, 4, 1024), (4096, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg347_1, arg348_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_223, hidden_states_224, pow_65, variance_64, add_146, rsqrt_64, hidden_states_225, to_133, hidden_states_226, output_114], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf682, arg347_1, buf681, arg348_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg347_1
        del arg348_1
        buf684 = empty_strided((1, 4, 16, 1), (64, 16, 1, 64), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_227, pow_66, variance_65], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf675, buf684, 64, 128, stream=raw_stream0)
        assert_size_stride(arg343_1, (128, ), (1, ), 'input')
        buf687 = reinterpret_tensor(buf682, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf682  # reuse
        buf685 = reinterpret_tensor(buf687, (1, 16, 4, 64), (8192, 512, 128, 1), 0)  # alias
        buf686 = reinterpret_tensor(buf687, (1, 16, 4, 64), (8192, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_227, pow_66, variance_65, add_147, rsqrt_65, hidden_states_228, to_135, mul_214, query_states_16, x2_32, neg_32, x1_32, cat_34], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg343_1, buf675, buf684, buf685, buf686, 4096, stream=raw_stream0)
        buf688 = empty_strided((1, 4, 8, 1), (32, 8, 1, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_229, pow_67, variance_66], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf678, buf688, 32, 128, stream=raw_stream0)
        del buf685
        del buf686
        assert_size_stride(arg346_1, (128, ), (1, ), 'input')
        buf691 = empty_strided((1, 8, 4, 128), (4096, 512, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf689 = reinterpret_tensor(buf691, (1, 8, 4, 64), (4096, 512, 128, 1), 0)  # alias
        buf690 = reinterpret_tensor(buf691, (1, 8, 4, 64), (4096, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_229, pow_67, variance_66, add_148, rsqrt_66, hidden_states_230, to_137, mul_216, key_states_16, x2_33, neg_33, x1_33, cat_35], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg346_1, buf678, buf688, buf689, buf690, 2048, stream=raw_stream0)
        assert_size_stride_grouped((arg349_1, arg350_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_20, sin_20, arange_20, cache_position_16, hidden_states_229, pow_67, variance_66, add_148, rsqrt_66, hidden_states_230, to_137, mul_216, key_states_16, mul_219, mul_220, k_embed_16, index_copy__32], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg349_1, arg346_1, buf678, buf688, buf1, buf691, buf0, arg350_1, 4096, stream=raw_stream0)
        del arg346_1
        del buf678
        del buf688
        del buf689
        del buf690
        del buf691
        buf693 = reinterpret_tensor(buf659, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf659  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_227, pow_66, variance_65, add_147, rsqrt_65, hidden_states_228, to_135, mul_214, query_states_16, cos_20, mul_217, sin_20, mul_218, q_embed_16, attn_output_48], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg343_1, buf675, buf684, buf1, buf687, buf0, buf693, 8192, stream=raw_stream0)
        del arg343_1
        del buf684
        buf694 = empty_strided((1, 16, 128, 256), (524288, 32768, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [key_16, attn_output_48], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8.run(arg350_1, buf694, 524288, stream=raw_stream0)
        del arg350_1
        buf695 = reinterpret_tensor(buf657, (16, 4, 256), (1024, 256, 1), 0); del buf657  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_227, pow_66, variance_65, add_147, rsqrt_65, hidden_states_228, to_135, mul_214, query_states_16, cos_20, mul_217, sin_20, mul_218, q_embed_16, attn_output_48, key_16], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9.run(buf693, buf694, buf695, 16, 16, 1, stream=raw_stream0)
        del buf694
        buf698 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        buf701 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_48], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10.run(buf695, arg3_1, buf698, buf701, 64, 256, stream=raw_stream0)
        del buf695
        del buf698
        assert_size_stride(arg351_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_20, cache_position_16, index_copy__33], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_11.run(arg349_1, buf681, arg351_1, 4096, stream=raw_stream0)
        buf702 = empty_strided((1, 16, 256, 128), (524288, 32768, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [value_16, attn_output_48], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(arg351_1, buf702, 524288, stream=raw_stream0)
        del arg351_1
        buf703 = reinterpret_tensor(buf693, (16, 4, 128), (512, 128, 1), 0); del buf693  # reuse
        # Topologically Sorted Source Nodes: [attn_output_48, value_16], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13.run(buf701, buf702, buf703, 8, 16, 1, stream=raw_stream0)
        del buf702
        buf704 = reinterpret_tensor(buf687, (1, 4, 2048), (8192, 2048, 1), 0); del buf687  # reuse
        buf705 = reinterpret_tensor(buf675, (1, 4, 2048), (2048, 2048, 1), 0); del buf675  # reuse
        # Topologically Sorted Source Nodes: [attn_output_48, transpose_67, reshape_50, output_115], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14.run(buf703, buf705, 8192, stream=raw_stream0)
        assert_size_stride_grouped((arg352_1, arg353_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_48, transpose_67, reshape_50, output_115], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf705, arg352_1, buf704, arg353_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg352_1
        del arg353_1
        assert_size_stride(arg354_1, (2048, ), (1, ), 'input')
        buf708 = reinterpret_tensor(buf705, (1, 4, 2048), (8192, 2048, 1), 0); del buf705  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_223, hidden_states_233, hidden_states_234, pow_68, variance_67, add_153, rsqrt_67, hidden_states_235, to_139, hidden_states_236], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20.run(buf663, buf671, buf704, arg354_1, buf708, 4, 2048, stream=raw_stream0)
        del arg354_1
        buf709 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg355_1, arg356_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_116], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf708, arg355_1, buf709, arg356_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg355_1
        del arg356_1
        buf711 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg357_1, arg358_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_117], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf708, arg357_1, buf711, arg358_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg357_1
        del arg358_1
        buf713 = buf708; del buf708  # reuse
        buf714 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu_16, mul_223, output_118], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_16.run(buf709, buf711, buf714, 24576, stream=raw_stream0)
        del buf709
        del buf711
        assert_size_stride_grouped((arg359_1, arg360_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_16, mul_223, output_118], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf714, arg359_1, buf713, arg360_1, 4, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg359_1
        del arg360_1
        del buf714
        assert_size_stride(arg361_1, (2048, ), (1, ), 'input')
        buf717 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_223, hidden_states_233, hidden_states_237, hidden_states_238, pow_69, variance_68, add_155, rsqrt_68, hidden_states_239, to_141, hidden_states_240], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21.run(buf663, buf671, buf704, buf713, arg361_1, buf717, 4, 2048, stream=raw_stream0)
        del arg361_1
        buf718 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg362_1, arg363_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_119], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf717, arg362_1, buf718, arg363_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg362_1
        del arg363_1
        buf720 = buf681; del buf681  # reuse
        assert_size_stride_grouped((arg365_1, arg366_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_120], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf717, arg365_1, buf720, arg366_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg365_1
        del arg366_1
        buf722 = empty_strided((1, 4, 1024), (4096, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg368_1, arg369_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_121], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf717, arg368_1, buf722, arg369_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg368_1
        del arg369_1
        buf724 = empty_strided((1, 4, 16, 1), (64, 16, 1, 64), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_241, pow_70, variance_69], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf718, buf724, 64, 128, stream=raw_stream0)
        assert_size_stride(arg364_1, (128, ), (1, ), 'input')
        buf727 = reinterpret_tensor(buf717, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf717  # reuse
        buf725 = reinterpret_tensor(buf727, (1, 16, 4, 64), (8192, 512, 128, 1), 0)  # alias
        buf726 = reinterpret_tensor(buf727, (1, 16, 4, 64), (8192, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_241, pow_70, variance_69, add_156, rsqrt_69, hidden_states_242, to_143, mul_227, query_states_17, x2_34, neg_34, x1_34, cat_36], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg364_1, buf718, buf724, buf725, buf726, 4096, stream=raw_stream0)
        buf728 = empty_strided((1, 4, 8, 1), (32, 8, 1, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_243, pow_71, variance_70], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf720, buf728, 32, 128, stream=raw_stream0)
        del buf725
        del buf726
        assert_size_stride(arg367_1, (128, ), (1, ), 'input')
        buf731 = empty_strided((1, 8, 4, 128), (4096, 512, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf729 = reinterpret_tensor(buf731, (1, 8, 4, 64), (4096, 512, 128, 1), 0)  # alias
        buf730 = reinterpret_tensor(buf731, (1, 8, 4, 64), (4096, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_243, pow_71, variance_70, add_157, rsqrt_70, hidden_states_244, to_145, mul_229, key_states_17, x2_35, neg_35, x1_35, cat_37], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg367_1, buf720, buf728, buf729, buf730, 2048, stream=raw_stream0)
        assert_size_stride_grouped((arg370_1, arg371_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_21, sin_21, arange_21, cache_position_17, hidden_states_243, pow_71, variance_70, add_157, rsqrt_70, hidden_states_244, to_145, mul_229, key_states_17, mul_232, mul_233, k_embed_17, index_copy__34], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg370_1, arg367_1, buf720, buf728, buf1, buf731, buf0, arg371_1, 4096, stream=raw_stream0)
        del arg367_1
        del buf720
        del buf728
        del buf729
        del buf730
        del buf731
        buf733 = reinterpret_tensor(buf703, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf703  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_241, pow_70, variance_69, add_156, rsqrt_69, hidden_states_242, to_143, mul_227, query_states_17, cos_21, mul_230, sin_21, mul_231, q_embed_17, attn_output_51], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg364_1, buf718, buf724, buf1, buf727, buf0, buf733, 8192, stream=raw_stream0)
        del arg364_1
        del buf718
        del buf724
        del buf727
        buf734 = empty_strided((1, 16, 128, 256), (524288, 32768, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [key_17, attn_output_51], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8.run(arg371_1, buf734, 524288, stream=raw_stream0)
        del arg371_1
        buf735 = reinterpret_tensor(buf701, (16, 4, 256), (1024, 256, 1), 0); del buf701  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_241, pow_70, variance_69, add_156, rsqrt_69, hidden_states_242, to_143, mul_227, query_states_17, cos_21, mul_230, sin_21, mul_231, q_embed_17, attn_output_51, key_17], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9.run(buf733, buf734, buf735, 16, 16, 1, stream=raw_stream0)
        del buf734
        buf738 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        buf741 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_51], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10.run(buf735, arg3_1, buf738, buf741, 64, 256, stream=raw_stream0)
        del buf735
        del buf738
        assert_size_stride(arg372_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_21, cache_position_17, index_copy__35], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_11.run(arg370_1, buf722, arg372_1, 4096, stream=raw_stream0)
        buf742 = empty_strided((1, 16, 256, 128), (524288, 32768, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [value_17, attn_output_51], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(arg372_1, buf742, 524288, stream=raw_stream0)
        del arg372_1
        buf743 = reinterpret_tensor(buf733, (16, 4, 128), (512, 128, 1), 0); del buf733  # reuse
        # Topologically Sorted Source Nodes: [attn_output_51, value_17], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13.run(buf741, buf742, buf743, 8, 16, 1, stream=raw_stream0)
        del buf742
        buf744 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        buf745 = empty_strided((1, 4, 2048), (2048, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [attn_output_51, transpose_71, reshape_53, output_122], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14.run(buf743, buf745, 8192, stream=raw_stream0)
        assert_size_stride_grouped((arg373_1, arg374_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_51, transpose_71, reshape_53, output_122], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf745, arg373_1, buf744, arg374_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg373_1
        del arg374_1
        assert_size_stride(arg375_1, (2048, ), (1, ), 'input')
        buf747 = buf663; del buf663  # reuse
        buf750 = reinterpret_tensor(buf745, (1, 4, 2048), (8192, 2048, 1), 0); del buf745  # reuse
        buf753 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_223, hidden_states_233, hidden_states_237, hidden_states_247, hidden_states_248, pow_72, variance_71, add_162, rsqrt_71, hidden_states_249, to_147, hidden_states_250, output_123, output_124], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_22.run(buf747, buf671, buf704, buf713, buf744, arg375_1, buf750, buf753, 4, 2048, stream=raw_stream0)
        del arg375_1
        del buf671
        buf749 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg376_1, arg377_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_248, pow_72, variance_71, add_162, rsqrt_71, hidden_states_249, to_147, hidden_states_250, output_123], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf750, arg376_1, buf749, arg377_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg376_1
        del arg377_1
        buf752 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg378_1, arg379_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_248, pow_72, variance_71, add_162, rsqrt_71, hidden_states_249, to_147, hidden_states_250, output_124], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf753, arg378_1, buf752, arg379_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg378_1
        del arg379_1
        buf755 = buf753; del buf753  # reuse
        buf756 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu_17, mul_236, output_125], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_16.run(buf749, buf752, buf756, 24576, stream=raw_stream0)
        del buf749
        del buf752
        assert_size_stride_grouped((arg380_1, arg381_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_17, mul_236, output_125], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf756, arg380_1, buf755, arg381_1, 4, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg380_1
        del arg381_1
        del buf756
        assert_size_stride(arg382_1, (2048, ), (1, ), 'input')
        buf760 = buf750; del buf750  # reuse
        buf763 = buf744; del buf744  # reuse
        buf766 = buf713; del buf713  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_251, hidden_states_252, pow_73, variance_72, add_164, rsqrt_72, hidden_states_253, to_149, hidden_states_254, output_126, output_127, output_128], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19.run(buf747, buf755, arg382_1, buf760, buf763, buf766, 4, 2048, stream=raw_stream0)
        del arg382_1
        buf759 = buf704; del buf704  # reuse
        assert_size_stride_grouped((arg383_1, arg384_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_251, hidden_states_252, pow_73, variance_72, add_164, rsqrt_72, hidden_states_253, to_149, hidden_states_254, output_126], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf760, arg383_1, buf759, arg384_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg383_1
        del arg384_1
        del buf760
        buf762 = buf722; del buf722  # reuse
        assert_size_stride_grouped((arg386_1, arg387_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_251, hidden_states_252, pow_73, variance_72, add_164, rsqrt_72, hidden_states_253, to_149, hidden_states_254, output_127], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf763, arg386_1, buf762, arg387_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg386_1
        del arg387_1
        del buf763
        buf765 = empty_strided((1, 4, 1024), (4096, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg389_1, arg390_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_251, hidden_states_252, pow_73, variance_72, add_164, rsqrt_72, hidden_states_253, to_149, hidden_states_254, output_128], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf766, arg389_1, buf765, arg390_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg389_1
        del arg390_1
        buf768 = empty_strided((1, 4, 16, 1), (64, 16, 1, 64), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_255, pow_74, variance_73], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf759, buf768, 64, 128, stream=raw_stream0)
        assert_size_stride(arg385_1, (128, ), (1, ), 'input')
        buf771 = reinterpret_tensor(buf766, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf766  # reuse
        buf769 = reinterpret_tensor(buf771, (1, 16, 4, 64), (8192, 512, 128, 1), 0)  # alias
        buf770 = reinterpret_tensor(buf771, (1, 16, 4, 64), (8192, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_255, pow_74, variance_73, add_165, rsqrt_73, hidden_states_256, to_151, mul_240, query_states_18, x2_36, neg_36, x1_36, cat_38], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg385_1, buf759, buf768, buf769, buf770, 4096, stream=raw_stream0)
        buf772 = empty_strided((1, 4, 8, 1), (32, 8, 1, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_257, pow_75, variance_74], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf762, buf772, 32, 128, stream=raw_stream0)
        del buf769
        del buf770
        assert_size_stride(arg388_1, (128, ), (1, ), 'input')
        buf775 = empty_strided((1, 8, 4, 128), (4096, 512, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf773 = reinterpret_tensor(buf775, (1, 8, 4, 64), (4096, 512, 128, 1), 0)  # alias
        buf774 = reinterpret_tensor(buf775, (1, 8, 4, 64), (4096, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_257, pow_75, variance_74, add_166, rsqrt_74, hidden_states_258, to_153, mul_242, key_states_18, x2_37, neg_37, x1_37, cat_39], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg388_1, buf762, buf772, buf773, buf774, 2048, stream=raw_stream0)
        assert_size_stride_grouped((arg391_1, arg392_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_22, sin_22, arange_22, cache_position_18, hidden_states_257, pow_75, variance_74, add_166, rsqrt_74, hidden_states_258, to_153, mul_242, key_states_18, mul_245, mul_246, k_embed_18, index_copy__36], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg391_1, arg388_1, buf762, buf772, buf1, buf775, buf0, arg392_1, 4096, stream=raw_stream0)
        del arg388_1
        del buf762
        del buf772
        del buf773
        del buf774
        del buf775
        buf777 = reinterpret_tensor(buf743, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf743  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_255, pow_74, variance_73, add_165, rsqrt_73, hidden_states_256, to_151, mul_240, query_states_18, cos_22, mul_243, sin_22, mul_244, q_embed_18, attn_output_54], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg385_1, buf759, buf768, buf1, buf771, buf0, buf777, 8192, stream=raw_stream0)
        del arg385_1
        del buf768
        buf778 = empty_strided((1, 16, 128, 256), (524288, 32768, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [key_18, attn_output_54], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8.run(arg392_1, buf778, 524288, stream=raw_stream0)
        del arg392_1
        buf779 = reinterpret_tensor(buf741, (16, 4, 256), (1024, 256, 1), 0); del buf741  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_255, pow_74, variance_73, add_165, rsqrt_73, hidden_states_256, to_151, mul_240, query_states_18, cos_22, mul_243, sin_22, mul_244, q_embed_18, attn_output_54, key_18], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9.run(buf777, buf778, buf779, 16, 16, 1, stream=raw_stream0)
        del buf778
        buf782 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        buf785 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_54], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10.run(buf779, arg3_1, buf782, buf785, 64, 256, stream=raw_stream0)
        del buf779
        del buf782
        assert_size_stride(arg393_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_22, cache_position_18, index_copy__37], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_11.run(arg391_1, buf765, arg393_1, 4096, stream=raw_stream0)
        buf786 = empty_strided((1, 16, 256, 128), (524288, 32768, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [value_18, attn_output_54], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(arg393_1, buf786, 524288, stream=raw_stream0)
        del arg393_1
        buf787 = reinterpret_tensor(buf777, (16, 4, 128), (512, 128, 1), 0); del buf777  # reuse
        # Topologically Sorted Source Nodes: [attn_output_54, value_18], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13.run(buf785, buf786, buf787, 8, 16, 1, stream=raw_stream0)
        del buf786
        buf788 = reinterpret_tensor(buf771, (1, 4, 2048), (8192, 2048, 1), 0); del buf771  # reuse
        buf789 = reinterpret_tensor(buf759, (1, 4, 2048), (2048, 2048, 1), 0); del buf759  # reuse
        # Topologically Sorted Source Nodes: [attn_output_54, transpose_75, reshape_56, output_129], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14.run(buf787, buf789, 8192, stream=raw_stream0)
        assert_size_stride_grouped((arg394_1, arg395_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_54, transpose_75, reshape_56, output_129], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf789, arg394_1, buf788, arg395_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg394_1
        del arg395_1
        assert_size_stride(arg396_1, (2048, ), (1, ), 'input')
        buf792 = reinterpret_tensor(buf789, (1, 4, 2048), (8192, 2048, 1), 0); del buf789  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_251, hidden_states_261, hidden_states_262, pow_76, variance_75, add_171, rsqrt_75, hidden_states_263, to_155, hidden_states_264], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20.run(buf747, buf755, buf788, arg396_1, buf792, 4, 2048, stream=raw_stream0)
        del arg396_1
        buf793 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg397_1, arg398_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_130], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf792, arg397_1, buf793, arg398_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg397_1
        del arg398_1
        buf795 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg399_1, arg400_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_131], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf792, arg399_1, buf795, arg400_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg399_1
        del arg400_1
        buf797 = buf792; del buf792  # reuse
        buf798 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu_18, mul_249, output_132], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_16.run(buf793, buf795, buf798, 24576, stream=raw_stream0)
        del buf793
        del buf795
        assert_size_stride_grouped((arg401_1, arg402_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_18, mul_249, output_132], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf798, arg401_1, buf797, arg402_1, 4, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg401_1
        del arg402_1
        del buf798
        assert_size_stride(arg403_1, (2048, ), (1, ), 'input')
        buf801 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_251, hidden_states_261, hidden_states_265, hidden_states_266, pow_77, variance_76, add_173, rsqrt_76, hidden_states_267, to_157, hidden_states_268], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21.run(buf747, buf755, buf788, buf797, arg403_1, buf801, 4, 2048, stream=raw_stream0)
        del arg403_1
        buf802 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg404_1, arg405_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_133], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf801, arg404_1, buf802, arg405_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg404_1
        del arg405_1
        buf804 = buf765; del buf765  # reuse
        assert_size_stride_grouped((arg407_1, arg408_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_134], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf801, arg407_1, buf804, arg408_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg407_1
        del arg408_1
        buf806 = empty_strided((1, 4, 1024), (4096, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg410_1, arg411_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_135], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf801, arg410_1, buf806, arg411_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg410_1
        del arg411_1
        buf808 = empty_strided((1, 4, 16, 1), (64, 16, 1, 64), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_269, pow_78, variance_77], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf802, buf808, 64, 128, stream=raw_stream0)
        assert_size_stride(arg406_1, (128, ), (1, ), 'input')
        buf811 = reinterpret_tensor(buf801, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf801  # reuse
        buf809 = reinterpret_tensor(buf811, (1, 16, 4, 64), (8192, 512, 128, 1), 0)  # alias
        buf810 = reinterpret_tensor(buf811, (1, 16, 4, 64), (8192, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_269, pow_78, variance_77, add_174, rsqrt_77, hidden_states_270, to_159, mul_253, query_states_19, x2_38, neg_38, x1_38, cat_40], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg406_1, buf802, buf808, buf809, buf810, 4096, stream=raw_stream0)
        buf812 = empty_strided((1, 4, 8, 1), (32, 8, 1, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_271, pow_79, variance_78], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf804, buf812, 32, 128, stream=raw_stream0)
        del buf809
        del buf810
        assert_size_stride(arg409_1, (128, ), (1, ), 'input')
        buf815 = empty_strided((1, 8, 4, 128), (4096, 512, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf813 = reinterpret_tensor(buf815, (1, 8, 4, 64), (4096, 512, 128, 1), 0)  # alias
        buf814 = reinterpret_tensor(buf815, (1, 8, 4, 64), (4096, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_271, pow_79, variance_78, add_175, rsqrt_78, hidden_states_272, to_161, mul_255, key_states_19, x2_39, neg_39, x1_39, cat_41], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg409_1, buf804, buf812, buf813, buf814, 2048, stream=raw_stream0)
        assert_size_stride_grouped((arg412_1, arg413_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_23, sin_23, arange_23, cache_position_19, hidden_states_271, pow_79, variance_78, add_175, rsqrt_78, hidden_states_272, to_161, mul_255, key_states_19, mul_258, mul_259, k_embed_19, index_copy__38], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg412_1, arg409_1, buf804, buf812, buf1, buf815, buf0, arg413_1, 4096, stream=raw_stream0)
        del arg409_1
        del buf804
        del buf812
        del buf813
        del buf814
        del buf815
        buf817 = reinterpret_tensor(buf787, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf787  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_269, pow_78, variance_77, add_174, rsqrt_77, hidden_states_270, to_159, mul_253, query_states_19, cos_23, mul_256, sin_23, mul_257, q_embed_19, attn_output_57], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg406_1, buf802, buf808, buf1, buf811, buf0, buf817, 8192, stream=raw_stream0)
        del arg406_1
        del buf802
        del buf808
        del buf811
        buf818 = empty_strided((1, 16, 128, 256), (524288, 32768, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [key_19, attn_output_57], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8.run(arg413_1, buf818, 524288, stream=raw_stream0)
        del arg413_1
        buf819 = reinterpret_tensor(buf785, (16, 4, 256), (1024, 256, 1), 0); del buf785  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_269, pow_78, variance_77, add_174, rsqrt_77, hidden_states_270, to_159, mul_253, query_states_19, cos_23, mul_256, sin_23, mul_257, q_embed_19, attn_output_57, key_19], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9.run(buf817, buf818, buf819, 16, 16, 1, stream=raw_stream0)
        del buf818
        buf822 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        buf825 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_57], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10.run(buf819, arg3_1, buf822, buf825, 64, 256, stream=raw_stream0)
        del buf819
        del buf822
        assert_size_stride(arg414_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_23, cache_position_19, index_copy__39], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_11.run(arg412_1, buf806, arg414_1, 4096, stream=raw_stream0)
        buf826 = empty_strided((1, 16, 256, 128), (524288, 32768, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [value_19, attn_output_57], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(arg414_1, buf826, 524288, stream=raw_stream0)
        del arg414_1
        buf827 = reinterpret_tensor(buf817, (16, 4, 128), (512, 128, 1), 0); del buf817  # reuse
        # Topologically Sorted Source Nodes: [attn_output_57, value_19], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13.run(buf825, buf826, buf827, 8, 16, 1, stream=raw_stream0)
        del buf826
        buf828 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        buf829 = empty_strided((1, 4, 2048), (2048, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [attn_output_57, transpose_79, reshape_59, output_136], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14.run(buf827, buf829, 8192, stream=raw_stream0)
        assert_size_stride_grouped((arg415_1, arg416_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_57, transpose_79, reshape_59, output_136], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf829, arg415_1, buf828, arg416_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg415_1
        del arg416_1
        assert_size_stride(arg417_1, (2048, ), (1, ), 'input')
        buf831 = buf747; del buf747  # reuse
        buf834 = reinterpret_tensor(buf829, (1, 4, 2048), (8192, 2048, 1), 0); del buf829  # reuse
        buf837 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_251, hidden_states_261, hidden_states_265, hidden_states_275, hidden_states_276, pow_80, variance_79, add_180, rsqrt_79, hidden_states_277, to_163, hidden_states_278, output_137, output_138], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_22.run(buf831, buf755, buf788, buf797, buf828, arg417_1, buf834, buf837, 4, 2048, stream=raw_stream0)
        del arg417_1
        del buf755
        buf833 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg418_1, arg419_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_276, pow_80, variance_79, add_180, rsqrt_79, hidden_states_277, to_163, hidden_states_278, output_137], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf834, arg418_1, buf833, arg419_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg418_1
        del arg419_1
        buf836 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg420_1, arg421_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_276, pow_80, variance_79, add_180, rsqrt_79, hidden_states_277, to_163, hidden_states_278, output_138], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf837, arg420_1, buf836, arg421_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg420_1
        del arg421_1
        buf839 = buf837; del buf837  # reuse
        buf840 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu_19, mul_262, output_139], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_16.run(buf833, buf836, buf840, 24576, stream=raw_stream0)
        del buf833
        del buf836
        assert_size_stride_grouped((arg422_1, arg423_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_19, mul_262, output_139], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf840, arg422_1, buf839, arg423_1, 4, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg422_1
        del arg423_1
        del buf840
        assert_size_stride(arg424_1, (2048, ), (1, ), 'input')
        buf844 = buf834; del buf834  # reuse
        buf847 = buf828; del buf828  # reuse
        buf850 = buf797; del buf797  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_279, hidden_states_280, pow_81, variance_80, add_182, rsqrt_80, hidden_states_281, to_165, hidden_states_282, output_140, output_141, output_142], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19.run(buf831, buf839, arg424_1, buf844, buf847, buf850, 4, 2048, stream=raw_stream0)
        del arg424_1
        buf843 = buf788; del buf788  # reuse
        assert_size_stride_grouped((arg425_1, arg426_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_279, hidden_states_280, pow_81, variance_80, add_182, rsqrt_80, hidden_states_281, to_165, hidden_states_282, output_140], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf844, arg425_1, buf843, arg426_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg425_1
        del arg426_1
        del buf844
        buf846 = buf806; del buf806  # reuse
        assert_size_stride_grouped((arg428_1, arg429_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_279, hidden_states_280, pow_81, variance_80, add_182, rsqrt_80, hidden_states_281, to_165, hidden_states_282, output_141], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf847, arg428_1, buf846, arg429_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg428_1
        del arg429_1
        del buf847
        buf849 = empty_strided((1, 4, 1024), (4096, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg431_1, arg432_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_279, hidden_states_280, pow_81, variance_80, add_182, rsqrt_80, hidden_states_281, to_165, hidden_states_282, output_142], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf850, arg431_1, buf849, arg432_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg431_1
        del arg432_1
        buf852 = empty_strided((1, 4, 16, 1), (64, 16, 1, 64), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_283, pow_82, variance_81], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf843, buf852, 64, 128, stream=raw_stream0)
        assert_size_stride(arg427_1, (128, ), (1, ), 'input')
        buf855 = reinterpret_tensor(buf850, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf850  # reuse
        buf853 = reinterpret_tensor(buf855, (1, 16, 4, 64), (8192, 512, 128, 1), 0)  # alias
        buf854 = reinterpret_tensor(buf855, (1, 16, 4, 64), (8192, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_283, pow_82, variance_81, add_183, rsqrt_81, hidden_states_284, to_167, mul_266, query_states_20, x2_40, neg_40, x1_40, cat_42], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg427_1, buf843, buf852, buf853, buf854, 4096, stream=raw_stream0)
        buf856 = empty_strided((1, 4, 8, 1), (32, 8, 1, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_285, pow_83, variance_82], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf846, buf856, 32, 128, stream=raw_stream0)
        del buf853
        del buf854
        assert_size_stride(arg430_1, (128, ), (1, ), 'input')
        buf859 = empty_strided((1, 8, 4, 128), (4096, 512, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf857 = reinterpret_tensor(buf859, (1, 8, 4, 64), (4096, 512, 128, 1), 0)  # alias
        buf858 = reinterpret_tensor(buf859, (1, 8, 4, 64), (4096, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_285, pow_83, variance_82, add_184, rsqrt_82, hidden_states_286, to_169, mul_268, key_states_20, x2_41, neg_41, x1_41, cat_43], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg430_1, buf846, buf856, buf857, buf858, 2048, stream=raw_stream0)
        assert_size_stride_grouped((arg433_1, arg434_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_24, sin_24, arange_24, cache_position_20, hidden_states_285, pow_83, variance_82, add_184, rsqrt_82, hidden_states_286, to_169, mul_268, key_states_20, mul_271, mul_272, k_embed_20, index_copy__40], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg433_1, arg430_1, buf846, buf856, buf1, buf859, buf0, arg434_1, 4096, stream=raw_stream0)
        del arg430_1
        del buf846
        del buf856
        del buf857
        del buf858
        del buf859
        buf861 = reinterpret_tensor(buf827, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf827  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_283, pow_82, variance_81, add_183, rsqrt_81, hidden_states_284, to_167, mul_266, query_states_20, cos_24, mul_269, sin_24, mul_270, q_embed_20, attn_output_60], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg427_1, buf843, buf852, buf1, buf855, buf0, buf861, 8192, stream=raw_stream0)
        del arg427_1
        del buf852
        buf862 = empty_strided((1, 16, 128, 256), (524288, 32768, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [key_20, attn_output_60], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8.run(arg434_1, buf862, 524288, stream=raw_stream0)
        del arg434_1
        buf863 = reinterpret_tensor(buf825, (16, 4, 256), (1024, 256, 1), 0); del buf825  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_283, pow_82, variance_81, add_183, rsqrt_81, hidden_states_284, to_167, mul_266, query_states_20, cos_24, mul_269, sin_24, mul_270, q_embed_20, attn_output_60, key_20], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9.run(buf861, buf862, buf863, 16, 16, 1, stream=raw_stream0)
        del buf862
        buf866 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        buf869 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_60], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10.run(buf863, arg3_1, buf866, buf869, 64, 256, stream=raw_stream0)
        del buf863
        del buf866
        assert_size_stride(arg435_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_24, cache_position_20, index_copy__41], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_11.run(arg433_1, buf849, arg435_1, 4096, stream=raw_stream0)
        buf870 = empty_strided((1, 16, 256, 128), (524288, 32768, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [value_20, attn_output_60], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(arg435_1, buf870, 524288, stream=raw_stream0)
        del arg435_1
        buf871 = reinterpret_tensor(buf861, (16, 4, 128), (512, 128, 1), 0); del buf861  # reuse
        # Topologically Sorted Source Nodes: [attn_output_60, value_20], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13.run(buf869, buf870, buf871, 8, 16, 1, stream=raw_stream0)
        del buf870
        buf872 = reinterpret_tensor(buf855, (1, 4, 2048), (8192, 2048, 1), 0); del buf855  # reuse
        buf873 = reinterpret_tensor(buf843, (1, 4, 2048), (2048, 2048, 1), 0); del buf843  # reuse
        # Topologically Sorted Source Nodes: [attn_output_60, transpose_83, reshape_62, output_143], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14.run(buf871, buf873, 8192, stream=raw_stream0)
        assert_size_stride_grouped((arg436_1, arg437_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_60, transpose_83, reshape_62, output_143], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf873, arg436_1, buf872, arg437_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg436_1
        del arg437_1
        assert_size_stride(arg438_1, (2048, ), (1, ), 'input')
        buf876 = reinterpret_tensor(buf873, (1, 4, 2048), (8192, 2048, 1), 0); del buf873  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_279, hidden_states_289, hidden_states_290, pow_84, variance_83, add_189, rsqrt_83, hidden_states_291, to_171, hidden_states_292], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20.run(buf831, buf839, buf872, arg438_1, buf876, 4, 2048, stream=raw_stream0)
        del arg438_1
        buf877 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg439_1, arg440_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_144], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf876, arg439_1, buf877, arg440_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg439_1
        del arg440_1
        buf879 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg441_1, arg442_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_145], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf876, arg441_1, buf879, arg442_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg441_1
        del arg442_1
        buf881 = buf876; del buf876  # reuse
        buf882 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu_20, mul_275, output_146], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_16.run(buf877, buf879, buf882, 24576, stream=raw_stream0)
        del buf877
        del buf879
        assert_size_stride_grouped((arg443_1, arg444_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_20, mul_275, output_146], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf882, arg443_1, buf881, arg444_1, 4, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg443_1
        del arg444_1
        del buf882
        assert_size_stride(arg445_1, (2048, ), (1, ), 'input')
        buf885 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_279, hidden_states_289, hidden_states_293, hidden_states_294, pow_85, variance_84, add_191, rsqrt_84, hidden_states_295, to_173, hidden_states_296], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21.run(buf831, buf839, buf872, buf881, arg445_1, buf885, 4, 2048, stream=raw_stream0)
        del arg445_1
        buf886 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg446_1, arg447_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_147], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf885, arg446_1, buf886, arg447_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg446_1
        del arg447_1
        buf888 = buf849; del buf849  # reuse
        assert_size_stride_grouped((arg449_1, arg450_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_148], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf885, arg449_1, buf888, arg450_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg449_1
        del arg450_1
        buf890 = empty_strided((1, 4, 1024), (4096, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg452_1, arg453_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_149], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf885, arg452_1, buf890, arg453_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg452_1
        del arg453_1
        buf892 = empty_strided((1, 4, 16, 1), (64, 16, 1, 64), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_297, pow_86, variance_85], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf886, buf892, 64, 128, stream=raw_stream0)
        assert_size_stride(arg448_1, (128, ), (1, ), 'input')
        buf895 = reinterpret_tensor(buf885, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf885  # reuse
        buf893 = reinterpret_tensor(buf895, (1, 16, 4, 64), (8192, 512, 128, 1), 0)  # alias
        buf894 = reinterpret_tensor(buf895, (1, 16, 4, 64), (8192, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_297, pow_86, variance_85, add_192, rsqrt_85, hidden_states_298, to_175, mul_279, query_states_21, x2_42, neg_42, x1_42, cat_44], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg448_1, buf886, buf892, buf893, buf894, 4096, stream=raw_stream0)
        buf896 = empty_strided((1, 4, 8, 1), (32, 8, 1, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_299, pow_87, variance_86], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf888, buf896, 32, 128, stream=raw_stream0)
        del buf893
        del buf894
        assert_size_stride(arg451_1, (128, ), (1, ), 'input')
        buf899 = empty_strided((1, 8, 4, 128), (4096, 512, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf897 = reinterpret_tensor(buf899, (1, 8, 4, 64), (4096, 512, 128, 1), 0)  # alias
        buf898 = reinterpret_tensor(buf899, (1, 8, 4, 64), (4096, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_299, pow_87, variance_86, add_193, rsqrt_86, hidden_states_300, to_177, mul_281, key_states_21, x2_43, neg_43, x1_43, cat_45], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg451_1, buf888, buf896, buf897, buf898, 2048, stream=raw_stream0)
        assert_size_stride_grouped((arg454_1, arg455_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_25, sin_25, arange_25, cache_position_21, hidden_states_299, pow_87, variance_86, add_193, rsqrt_86, hidden_states_300, to_177, mul_281, key_states_21, mul_284, mul_285, k_embed_21, index_copy__42], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg454_1, arg451_1, buf888, buf896, buf1, buf899, buf0, arg455_1, 4096, stream=raw_stream0)
        del arg451_1
        del buf888
        del buf896
        del buf897
        del buf898
        del buf899
        buf901 = reinterpret_tensor(buf871, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf871  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_297, pow_86, variance_85, add_192, rsqrt_85, hidden_states_298, to_175, mul_279, query_states_21, cos_25, mul_282, sin_25, mul_283, q_embed_21, attn_output_63], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg448_1, buf886, buf892, buf1, buf895, buf0, buf901, 8192, stream=raw_stream0)
        del arg448_1
        del buf886
        del buf892
        del buf895
        buf902 = empty_strided((1, 16, 128, 256), (524288, 32768, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [key_21, attn_output_63], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8.run(arg455_1, buf902, 524288, stream=raw_stream0)
        del arg455_1
        buf903 = reinterpret_tensor(buf869, (16, 4, 256), (1024, 256, 1), 0); del buf869  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_297, pow_86, variance_85, add_192, rsqrt_85, hidden_states_298, to_175, mul_279, query_states_21, cos_25, mul_282, sin_25, mul_283, q_embed_21, attn_output_63, key_21], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9.run(buf901, buf902, buf903, 16, 16, 1, stream=raw_stream0)
        del buf902
        buf906 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        buf909 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_63], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10.run(buf903, arg3_1, buf906, buf909, 64, 256, stream=raw_stream0)
        del buf903
        del buf906
        assert_size_stride(arg456_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_25, cache_position_21, index_copy__43], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_11.run(arg454_1, buf890, arg456_1, 4096, stream=raw_stream0)
        buf910 = empty_strided((1, 16, 256, 128), (524288, 32768, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [value_21, attn_output_63], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(arg456_1, buf910, 524288, stream=raw_stream0)
        del arg456_1
        buf911 = reinterpret_tensor(buf901, (16, 4, 128), (512, 128, 1), 0); del buf901  # reuse
        # Topologically Sorted Source Nodes: [attn_output_63, value_21], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13.run(buf909, buf910, buf911, 8, 16, 1, stream=raw_stream0)
        del buf910
        buf912 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        buf913 = empty_strided((1, 4, 2048), (2048, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [attn_output_63, transpose_87, reshape_65, output_150], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14.run(buf911, buf913, 8192, stream=raw_stream0)
        assert_size_stride_grouped((arg457_1, arg458_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_63, transpose_87, reshape_65, output_150], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf913, arg457_1, buf912, arg458_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg457_1
        del arg458_1
        assert_size_stride(arg459_1, (2048, ), (1, ), 'input')
        buf915 = buf831; del buf831  # reuse
        buf918 = reinterpret_tensor(buf913, (1, 4, 2048), (8192, 2048, 1), 0); del buf913  # reuse
        buf921 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_279, hidden_states_289, hidden_states_293, hidden_states_303, hidden_states_304, pow_88, variance_87, add_198, rsqrt_87, hidden_states_305, to_179, hidden_states_306, output_151, output_152], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_22.run(buf915, buf839, buf872, buf881, buf912, arg459_1, buf918, buf921, 4, 2048, stream=raw_stream0)
        del arg459_1
        del buf839
        buf917 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg460_1, arg461_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_304, pow_88, variance_87, add_198, rsqrt_87, hidden_states_305, to_179, hidden_states_306, output_151], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf918, arg460_1, buf917, arg461_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg460_1
        del arg461_1
        buf920 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg462_1, arg463_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_304, pow_88, variance_87, add_198, rsqrt_87, hidden_states_305, to_179, hidden_states_306, output_152], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf921, arg462_1, buf920, arg463_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg462_1
        del arg463_1
        buf923 = buf921; del buf921  # reuse
        buf924 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu_21, mul_288, output_153], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_16.run(buf917, buf920, buf924, 24576, stream=raw_stream0)
        del buf917
        del buf920
        assert_size_stride_grouped((arg464_1, arg465_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_21, mul_288, output_153], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf924, arg464_1, buf923, arg465_1, 4, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg464_1
        del arg465_1
        del buf924
        assert_size_stride(arg466_1, (2048, ), (1, ), 'input')
        buf928 = buf918; del buf918  # reuse
        buf931 = buf912; del buf912  # reuse
        buf934 = buf881; del buf881  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_307, hidden_states_308, pow_89, variance_88, add_200, rsqrt_88, hidden_states_309, to_181, hidden_states_310, output_154, output_155, output_156], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19.run(buf915, buf923, arg466_1, buf928, buf931, buf934, 4, 2048, stream=raw_stream0)
        del arg466_1
        buf927 = buf872; del buf872  # reuse
        assert_size_stride_grouped((arg467_1, arg468_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_307, hidden_states_308, pow_89, variance_88, add_200, rsqrt_88, hidden_states_309, to_181, hidden_states_310, output_154], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf928, arg467_1, buf927, arg468_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg467_1
        del arg468_1
        del buf928
        buf930 = buf890; del buf890  # reuse
        assert_size_stride_grouped((arg470_1, arg471_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_307, hidden_states_308, pow_89, variance_88, add_200, rsqrt_88, hidden_states_309, to_181, hidden_states_310, output_155], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf931, arg470_1, buf930, arg471_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg470_1
        del arg471_1
        del buf931
        buf933 = empty_strided((1, 4, 1024), (4096, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg473_1, arg474_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_307, hidden_states_308, pow_89, variance_88, add_200, rsqrt_88, hidden_states_309, to_181, hidden_states_310, output_156], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf934, arg473_1, buf933, arg474_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg473_1
        del arg474_1
        buf936 = empty_strided((1, 4, 16, 1), (64, 16, 1, 64), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_311, pow_90, variance_89], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf927, buf936, 64, 128, stream=raw_stream0)
        assert_size_stride(arg469_1, (128, ), (1, ), 'input')
        buf939 = reinterpret_tensor(buf934, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf934  # reuse
        buf937 = reinterpret_tensor(buf939, (1, 16, 4, 64), (8192, 512, 128, 1), 0)  # alias
        buf938 = reinterpret_tensor(buf939, (1, 16, 4, 64), (8192, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_311, pow_90, variance_89, add_201, rsqrt_89, hidden_states_312, to_183, mul_292, query_states_22, x2_44, neg_44, x1_44, cat_46], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg469_1, buf927, buf936, buf937, buf938, 4096, stream=raw_stream0)
        buf940 = empty_strided((1, 4, 8, 1), (32, 8, 1, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_313, pow_91, variance_90], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf930, buf940, 32, 128, stream=raw_stream0)
        del buf937
        del buf938
        assert_size_stride(arg472_1, (128, ), (1, ), 'input')
        buf943 = empty_strided((1, 8, 4, 128), (4096, 512, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf941 = reinterpret_tensor(buf943, (1, 8, 4, 64), (4096, 512, 128, 1), 0)  # alias
        buf942 = reinterpret_tensor(buf943, (1, 8, 4, 64), (4096, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_313, pow_91, variance_90, add_202, rsqrt_90, hidden_states_314, to_185, mul_294, key_states_22, x2_45, neg_45, x1_45, cat_47], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg472_1, buf930, buf940, buf941, buf942, 2048, stream=raw_stream0)
        assert_size_stride_grouped((arg475_1, arg476_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_26, sin_26, arange_26, cache_position_22, hidden_states_313, pow_91, variance_90, add_202, rsqrt_90, hidden_states_314, to_185, mul_294, key_states_22, mul_297, mul_298, k_embed_22, index_copy__44], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg475_1, arg472_1, buf930, buf940, buf1, buf943, buf0, arg476_1, 4096, stream=raw_stream0)
        del arg472_1
        del buf930
        del buf940
        del buf941
        del buf942
        del buf943
        buf945 = reinterpret_tensor(buf911, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf911  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_311, pow_90, variance_89, add_201, rsqrt_89, hidden_states_312, to_183, mul_292, query_states_22, cos_26, mul_295, sin_26, mul_296, q_embed_22, attn_output_66], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg469_1, buf927, buf936, buf1, buf939, buf0, buf945, 8192, stream=raw_stream0)
        del arg469_1
        del buf936
        buf946 = empty_strided((1, 16, 128, 256), (524288, 32768, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [key_22, attn_output_66], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8.run(arg476_1, buf946, 524288, stream=raw_stream0)
        del arg476_1
        buf947 = reinterpret_tensor(buf909, (16, 4, 256), (1024, 256, 1), 0); del buf909  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_311, pow_90, variance_89, add_201, rsqrt_89, hidden_states_312, to_183, mul_292, query_states_22, cos_26, mul_295, sin_26, mul_296, q_embed_22, attn_output_66, key_22], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9.run(buf945, buf946, buf947, 16, 16, 1, stream=raw_stream0)
        del buf946
        buf950 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        buf953 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_66], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10.run(buf947, arg3_1, buf950, buf953, 64, 256, stream=raw_stream0)
        del buf947
        del buf950
        assert_size_stride(arg477_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_26, cache_position_22, index_copy__45], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_11.run(arg475_1, buf933, arg477_1, 4096, stream=raw_stream0)
        buf954 = empty_strided((1, 16, 256, 128), (524288, 32768, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [value_22, attn_output_66], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(arg477_1, buf954, 524288, stream=raw_stream0)
        del arg477_1
        buf955 = reinterpret_tensor(buf945, (16, 4, 128), (512, 128, 1), 0); del buf945  # reuse
        # Topologically Sorted Source Nodes: [attn_output_66, value_22], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13.run(buf953, buf954, buf955, 8, 16, 1, stream=raw_stream0)
        del buf954
        buf956 = reinterpret_tensor(buf939, (1, 4, 2048), (8192, 2048, 1), 0); del buf939  # reuse
        buf957 = reinterpret_tensor(buf927, (1, 4, 2048), (2048, 2048, 1), 0); del buf927  # reuse
        # Topologically Sorted Source Nodes: [attn_output_66, transpose_91, reshape_68, output_157], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14.run(buf955, buf957, 8192, stream=raw_stream0)
        assert_size_stride_grouped((arg478_1, arg479_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_66, transpose_91, reshape_68, output_157], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf957, arg478_1, buf956, arg479_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg478_1
        del arg479_1
        assert_size_stride(arg480_1, (2048, ), (1, ), 'input')
        buf960 = reinterpret_tensor(buf957, (1, 4, 2048), (8192, 2048, 1), 0); del buf957  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_307, hidden_states_317, hidden_states_318, pow_92, variance_91, add_207, rsqrt_91, hidden_states_319, to_187, hidden_states_320], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20.run(buf915, buf923, buf956, arg480_1, buf960, 4, 2048, stream=raw_stream0)
        del arg480_1
        buf961 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg481_1, arg482_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_158], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf960, arg481_1, buf961, arg482_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg481_1
        del arg482_1
        buf963 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg483_1, arg484_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_159], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf960, arg483_1, buf963, arg484_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg483_1
        del arg484_1
        buf965 = buf960; del buf960  # reuse
        buf966 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu_22, mul_301, output_160], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_16.run(buf961, buf963, buf966, 24576, stream=raw_stream0)
        del buf961
        del buf963
        assert_size_stride_grouped((arg485_1, arg486_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_22, mul_301, output_160], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf966, arg485_1, buf965, arg486_1, 4, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg485_1
        del arg486_1
        del buf966
        assert_size_stride(arg487_1, (2048, ), (1, ), 'input')
        buf969 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_307, hidden_states_317, hidden_states_321, hidden_states_322, pow_93, variance_92, add_209, rsqrt_92, hidden_states_323, to_189, hidden_states_324], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21.run(buf915, buf923, buf956, buf965, arg487_1, buf969, 4, 2048, stream=raw_stream0)
        del arg487_1
        buf970 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg488_1, arg489_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_161], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf969, arg488_1, buf970, arg489_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg488_1
        del arg489_1
        buf972 = buf933; del buf933  # reuse
        assert_size_stride_grouped((arg491_1, arg492_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_162], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf969, arg491_1, buf972, arg492_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg491_1
        del arg492_1
        buf974 = empty_strided((1, 4, 1024), (4096, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg494_1, arg495_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_163], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf969, arg494_1, buf974, arg495_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg494_1
        del arg495_1
        buf976 = empty_strided((1, 4, 16, 1), (64, 16, 1, 64), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_325, pow_94, variance_93], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf970, buf976, 64, 128, stream=raw_stream0)
        assert_size_stride(arg490_1, (128, ), (1, ), 'input')
        buf979 = reinterpret_tensor(buf969, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf969  # reuse
        buf977 = reinterpret_tensor(buf979, (1, 16, 4, 64), (8192, 512, 128, 1), 0)  # alias
        buf978 = reinterpret_tensor(buf979, (1, 16, 4, 64), (8192, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_325, pow_94, variance_93, add_210, rsqrt_93, hidden_states_326, to_191, mul_305, query_states_23, x2_46, neg_46, x1_46, cat_48], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg490_1, buf970, buf976, buf977, buf978, 4096, stream=raw_stream0)
        buf980 = empty_strided((1, 4, 8, 1), (32, 8, 1, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_327, pow_95, variance_94], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf972, buf980, 32, 128, stream=raw_stream0)
        del buf977
        del buf978
        assert_size_stride(arg493_1, (128, ), (1, ), 'input')
        buf983 = empty_strided((1, 8, 4, 128), (4096, 512, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf981 = reinterpret_tensor(buf983, (1, 8, 4, 64), (4096, 512, 128, 1), 0)  # alias
        buf982 = reinterpret_tensor(buf983, (1, 8, 4, 64), (4096, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_327, pow_95, variance_94, add_211, rsqrt_94, hidden_states_328, to_193, mul_307, key_states_23, x2_47, neg_47, x1_47, cat_49], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg493_1, buf972, buf980, buf981, buf982, 2048, stream=raw_stream0)
        assert_size_stride_grouped((arg496_1, arg497_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_27, sin_27, arange_27, cache_position_23, hidden_states_327, pow_95, variance_94, add_211, rsqrt_94, hidden_states_328, to_193, mul_307, key_states_23, mul_310, mul_311, k_embed_23, index_copy__46], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg496_1, arg493_1, buf972, buf980, buf1, buf983, buf0, arg497_1, 4096, stream=raw_stream0)
        del arg493_1
        del buf972
        del buf980
        del buf981
        del buf982
        del buf983
        buf985 = reinterpret_tensor(buf955, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf955  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_325, pow_94, variance_93, add_210, rsqrt_93, hidden_states_326, to_191, mul_305, query_states_23, cos_27, mul_308, sin_27, mul_309, q_embed_23, attn_output_69], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg490_1, buf970, buf976, buf1, buf979, buf0, buf985, 8192, stream=raw_stream0)
        del arg490_1
        del buf970
        del buf976
        del buf979
        buf986 = empty_strided((1, 16, 128, 256), (524288, 32768, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [key_23, attn_output_69], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8.run(arg497_1, buf986, 524288, stream=raw_stream0)
        del arg497_1
        buf987 = reinterpret_tensor(buf953, (16, 4, 256), (1024, 256, 1), 0); del buf953  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_325, pow_94, variance_93, add_210, rsqrt_93, hidden_states_326, to_191, mul_305, query_states_23, cos_27, mul_308, sin_27, mul_309, q_embed_23, attn_output_69, key_23], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9.run(buf985, buf986, buf987, 16, 16, 1, stream=raw_stream0)
        del buf986
        buf990 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        buf993 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_69], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10.run(buf987, arg3_1, buf990, buf993, 64, 256, stream=raw_stream0)
        del buf987
        del buf990
        assert_size_stride(arg498_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_27, cache_position_23, index_copy__47], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_11.run(arg496_1, buf974, arg498_1, 4096, stream=raw_stream0)
        buf994 = empty_strided((1, 16, 256, 128), (524288, 32768, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [value_23, attn_output_69], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(arg498_1, buf994, 524288, stream=raw_stream0)
        del arg498_1
        buf995 = reinterpret_tensor(buf985, (16, 4, 128), (512, 128, 1), 0); del buf985  # reuse
        # Topologically Sorted Source Nodes: [attn_output_69, value_23], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13.run(buf993, buf994, buf995, 8, 16, 1, stream=raw_stream0)
        del buf994
        buf996 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        buf997 = empty_strided((1, 4, 2048), (2048, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [attn_output_69, transpose_95, reshape_71, output_164], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14.run(buf995, buf997, 8192, stream=raw_stream0)
        assert_size_stride_grouped((arg499_1, arg500_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_69, transpose_95, reshape_71, output_164], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf997, arg499_1, buf996, arg500_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg499_1
        del arg500_1
        assert_size_stride(arg501_1, (2048, ), (1, ), 'input')
        buf999 = buf915; del buf915  # reuse
        buf1002 = reinterpret_tensor(buf997, (1, 4, 2048), (8192, 2048, 1), 0); del buf997  # reuse
        buf1005 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_307, hidden_states_317, hidden_states_321, hidden_states_331, hidden_states_332, pow_96, variance_95, add_216, rsqrt_95, hidden_states_333, to_195, hidden_states_334, output_165, output_166], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_22.run(buf999, buf923, buf956, buf965, buf996, arg501_1, buf1002, buf1005, 4, 2048, stream=raw_stream0)
        del arg501_1
        del buf923
        buf1001 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg502_1, arg503_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_332, pow_96, variance_95, add_216, rsqrt_95, hidden_states_333, to_195, hidden_states_334, output_165], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf1002, arg502_1, buf1001, arg503_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg502_1
        del arg503_1
        buf1004 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg504_1, arg505_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_332, pow_96, variance_95, add_216, rsqrt_95, hidden_states_333, to_195, hidden_states_334, output_166], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf1005, arg504_1, buf1004, arg505_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg504_1
        del arg505_1
        buf1007 = buf1005; del buf1005  # reuse
        buf1008 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu_23, mul_314, output_167], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_16.run(buf1001, buf1004, buf1008, 24576, stream=raw_stream0)
        del buf1001
        del buf1004
        assert_size_stride_grouped((arg506_1, arg507_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_23, mul_314, output_167], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf1008, arg506_1, buf1007, arg507_1, 4, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg506_1
        del arg507_1
        del buf1008
        assert_size_stride(arg508_1, (2048, ), (1, ), 'input')
        buf1012 = buf1002; del buf1002  # reuse
        buf1015 = buf996; del buf996  # reuse
        buf1018 = buf965; del buf965  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_335, hidden_states_336, pow_97, variance_96, add_218, rsqrt_96, hidden_states_337, to_197, hidden_states_338, output_168, output_169, output_170], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19.run(buf999, buf1007, arg508_1, buf1012, buf1015, buf1018, 4, 2048, stream=raw_stream0)
        del arg508_1
        buf1011 = buf956; del buf956  # reuse
        assert_size_stride_grouped((arg509_1, arg510_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_335, hidden_states_336, pow_97, variance_96, add_218, rsqrt_96, hidden_states_337, to_197, hidden_states_338, output_168], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf1012, arg509_1, buf1011, arg510_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg509_1
        del arg510_1
        del buf1012
        buf1014 = buf974; del buf974  # reuse
        assert_size_stride_grouped((arg512_1, arg513_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_335, hidden_states_336, pow_97, variance_96, add_218, rsqrt_96, hidden_states_337, to_197, hidden_states_338, output_169], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf1015, arg512_1, buf1014, arg513_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg512_1
        del arg513_1
        del buf1015
        buf1017 = empty_strided((1, 4, 1024), (4096, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg515_1, arg516_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_335, hidden_states_336, pow_97, variance_96, add_218, rsqrt_96, hidden_states_337, to_197, hidden_states_338, output_170], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf1018, arg515_1, buf1017, arg516_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg515_1
        del arg516_1
        buf1020 = empty_strided((1, 4, 16, 1), (64, 16, 1, 64), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_339, pow_98, variance_97], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf1011, buf1020, 64, 128, stream=raw_stream0)
        assert_size_stride(arg511_1, (128, ), (1, ), 'input')
        buf1023 = reinterpret_tensor(buf1018, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf1018  # reuse
        buf1021 = reinterpret_tensor(buf1023, (1, 16, 4, 64), (8192, 512, 128, 1), 0)  # alias
        buf1022 = reinterpret_tensor(buf1023, (1, 16, 4, 64), (8192, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_339, pow_98, variance_97, add_219, rsqrt_97, hidden_states_340, to_199, mul_318, query_states_24, x2_48, neg_48, x1_48, cat_50], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg511_1, buf1011, buf1020, buf1021, buf1022, 4096, stream=raw_stream0)
        buf1024 = empty_strided((1, 4, 8, 1), (32, 8, 1, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_341, pow_99, variance_98], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf1014, buf1024, 32, 128, stream=raw_stream0)
        del buf1021
        del buf1022
        assert_size_stride(arg514_1, (128, ), (1, ), 'input')
        buf1027 = empty_strided((1, 8, 4, 128), (4096, 512, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf1025 = reinterpret_tensor(buf1027, (1, 8, 4, 64), (4096, 512, 128, 1), 0)  # alias
        buf1026 = reinterpret_tensor(buf1027, (1, 8, 4, 64), (4096, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_341, pow_99, variance_98, add_220, rsqrt_98, hidden_states_342, to_201, mul_320, key_states_24, x2_49, neg_49, x1_49, cat_51], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg514_1, buf1014, buf1024, buf1025, buf1026, 2048, stream=raw_stream0)
        assert_size_stride_grouped((arg517_1, arg518_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_28, sin_28, arange_28, cache_position_24, hidden_states_341, pow_99, variance_98, add_220, rsqrt_98, hidden_states_342, to_201, mul_320, key_states_24, mul_323, mul_324, k_embed_24, index_copy__48], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg517_1, arg514_1, buf1014, buf1024, buf1, buf1027, buf0, arg518_1, 4096, stream=raw_stream0)
        del arg514_1
        del buf1014
        del buf1024
        del buf1025
        del buf1026
        del buf1027
        buf1029 = reinterpret_tensor(buf995, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf995  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_339, pow_98, variance_97, add_219, rsqrt_97, hidden_states_340, to_199, mul_318, query_states_24, cos_28, mul_321, sin_28, mul_322, q_embed_24, attn_output_72], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg511_1, buf1011, buf1020, buf1, buf1023, buf0, buf1029, 8192, stream=raw_stream0)
        del arg511_1
        del buf1020
        buf1030 = empty_strided((1, 16, 128, 256), (524288, 32768, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [key_24, attn_output_72], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8.run(arg518_1, buf1030, 524288, stream=raw_stream0)
        del arg518_1
        buf1031 = reinterpret_tensor(buf993, (16, 4, 256), (1024, 256, 1), 0); del buf993  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_339, pow_98, variance_97, add_219, rsqrt_97, hidden_states_340, to_199, mul_318, query_states_24, cos_28, mul_321, sin_28, mul_322, q_embed_24, attn_output_72, key_24], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9.run(buf1029, buf1030, buf1031, 16, 16, 1, stream=raw_stream0)
        del buf1030
        buf1034 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        buf1037 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_72], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10.run(buf1031, arg3_1, buf1034, buf1037, 64, 256, stream=raw_stream0)
        del buf1031
        del buf1034
        assert_size_stride(arg519_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_28, cache_position_24, index_copy__49], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_11.run(arg517_1, buf1017, arg519_1, 4096, stream=raw_stream0)
        buf1038 = empty_strided((1, 16, 256, 128), (524288, 32768, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [value_24, attn_output_72], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(arg519_1, buf1038, 524288, stream=raw_stream0)
        del arg519_1
        buf1039 = reinterpret_tensor(buf1029, (16, 4, 128), (512, 128, 1), 0); del buf1029  # reuse
        # Topologically Sorted Source Nodes: [attn_output_72, value_24], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13.run(buf1037, buf1038, buf1039, 8, 16, 1, stream=raw_stream0)
        del buf1038
        buf1040 = reinterpret_tensor(buf1023, (1, 4, 2048), (8192, 2048, 1), 0); del buf1023  # reuse
        buf1041 = reinterpret_tensor(buf1011, (1, 4, 2048), (2048, 2048, 1), 0); del buf1011  # reuse
        # Topologically Sorted Source Nodes: [attn_output_72, transpose_99, reshape_74, output_171], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14.run(buf1039, buf1041, 8192, stream=raw_stream0)
        assert_size_stride_grouped((arg520_1, arg521_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_72, transpose_99, reshape_74, output_171], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf1041, arg520_1, buf1040, arg521_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg520_1
        del arg521_1
        assert_size_stride(arg522_1, (2048, ), (1, ), 'input')
        buf1044 = reinterpret_tensor(buf1041, (1, 4, 2048), (8192, 2048, 1), 0); del buf1041  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_335, hidden_states_345, hidden_states_346, pow_100, variance_99, add_225, rsqrt_99, hidden_states_347, to_203, hidden_states_348], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20.run(buf999, buf1007, buf1040, arg522_1, buf1044, 4, 2048, stream=raw_stream0)
        del arg522_1
        buf1045 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg523_1, arg524_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_172], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf1044, arg523_1, buf1045, arg524_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg523_1
        del arg524_1
        buf1047 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg525_1, arg526_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_173], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf1044, arg525_1, buf1047, arg526_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg525_1
        del arg526_1
        buf1049 = buf1044; del buf1044  # reuse
        buf1050 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu_24, mul_327, output_174], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_16.run(buf1045, buf1047, buf1050, 24576, stream=raw_stream0)
        del buf1045
        del buf1047
        assert_size_stride_grouped((arg527_1, arg528_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_24, mul_327, output_174], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf1050, arg527_1, buf1049, arg528_1, 4, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg527_1
        del arg528_1
        del buf1050
        assert_size_stride(arg529_1, (2048, ), (1, ), 'input')
        buf1053 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_335, hidden_states_345, hidden_states_349, hidden_states_350, pow_101, variance_100, add_227, rsqrt_100, hidden_states_351, to_205, hidden_states_352], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21.run(buf999, buf1007, buf1040, buf1049, arg529_1, buf1053, 4, 2048, stream=raw_stream0)
        del arg529_1
        buf1054 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg530_1, arg531_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_175], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf1053, arg530_1, buf1054, arg531_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg530_1
        del arg531_1
        buf1056 = buf1017; del buf1017  # reuse
        assert_size_stride_grouped((arg533_1, arg534_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_176], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf1053, arg533_1, buf1056, arg534_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg533_1
        del arg534_1
        buf1058 = empty_strided((1, 4, 1024), (4096, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg536_1, arg537_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_177], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf1053, arg536_1, buf1058, arg537_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg536_1
        del arg537_1
        buf1060 = empty_strided((1, 4, 16, 1), (64, 16, 1, 64), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_353, pow_102, variance_101], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf1054, buf1060, 64, 128, stream=raw_stream0)
        assert_size_stride(arg532_1, (128, ), (1, ), 'input')
        buf1063 = reinterpret_tensor(buf1053, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf1053  # reuse
        buf1061 = reinterpret_tensor(buf1063, (1, 16, 4, 64), (8192, 512, 128, 1), 0)  # alias
        buf1062 = reinterpret_tensor(buf1063, (1, 16, 4, 64), (8192, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_353, pow_102, variance_101, add_228, rsqrt_101, hidden_states_354, to_207, mul_331, query_states_25, x2_50, neg_50, x1_50, cat_52], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg532_1, buf1054, buf1060, buf1061, buf1062, 4096, stream=raw_stream0)
        buf1064 = empty_strided((1, 4, 8, 1), (32, 8, 1, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_355, pow_103, variance_102], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf1056, buf1064, 32, 128, stream=raw_stream0)
        del buf1061
        del buf1062
        assert_size_stride(arg535_1, (128, ), (1, ), 'input')
        buf1067 = empty_strided((1, 8, 4, 128), (4096, 512, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf1065 = reinterpret_tensor(buf1067, (1, 8, 4, 64), (4096, 512, 128, 1), 0)  # alias
        buf1066 = reinterpret_tensor(buf1067, (1, 8, 4, 64), (4096, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_355, pow_103, variance_102, add_229, rsqrt_102, hidden_states_356, to_209, mul_333, key_states_25, x2_51, neg_51, x1_51, cat_53], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg535_1, buf1056, buf1064, buf1065, buf1066, 2048, stream=raw_stream0)
        assert_size_stride_grouped((arg538_1, arg539_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_29, sin_29, arange_29, cache_position_25, hidden_states_355, pow_103, variance_102, add_229, rsqrt_102, hidden_states_356, to_209, mul_333, key_states_25, mul_336, mul_337, k_embed_25, index_copy__50], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg538_1, arg535_1, buf1056, buf1064, buf1, buf1067, buf0, arg539_1, 4096, stream=raw_stream0)
        del arg535_1
        del buf1056
        del buf1064
        del buf1065
        del buf1066
        del buf1067
        buf1069 = reinterpret_tensor(buf1039, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf1039  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_353, pow_102, variance_101, add_228, rsqrt_101, hidden_states_354, to_207, mul_331, query_states_25, cos_29, mul_334, sin_29, mul_335, q_embed_25, attn_output_75], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg532_1, buf1054, buf1060, buf1, buf1063, buf0, buf1069, 8192, stream=raw_stream0)
        del arg532_1
        del buf1054
        del buf1060
        del buf1063
        buf1070 = empty_strided((1, 16, 128, 256), (524288, 32768, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [key_25, attn_output_75], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8.run(arg539_1, buf1070, 524288, stream=raw_stream0)
        del arg539_1
        buf1071 = reinterpret_tensor(buf1037, (16, 4, 256), (1024, 256, 1), 0); del buf1037  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_353, pow_102, variance_101, add_228, rsqrt_101, hidden_states_354, to_207, mul_331, query_states_25, cos_29, mul_334, sin_29, mul_335, q_embed_25, attn_output_75, key_25], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9.run(buf1069, buf1070, buf1071, 16, 16, 1, stream=raw_stream0)
        del buf1070
        buf1074 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        buf1077 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_75], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10.run(buf1071, arg3_1, buf1074, buf1077, 64, 256, stream=raw_stream0)
        del buf1071
        del buf1074
        assert_size_stride(arg540_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_29, cache_position_25, index_copy__51], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_11.run(arg538_1, buf1058, arg540_1, 4096, stream=raw_stream0)
        buf1078 = empty_strided((1, 16, 256, 128), (524288, 32768, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [value_25, attn_output_75], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(arg540_1, buf1078, 524288, stream=raw_stream0)
        del arg540_1
        buf1079 = reinterpret_tensor(buf1069, (16, 4, 128), (512, 128, 1), 0); del buf1069  # reuse
        # Topologically Sorted Source Nodes: [attn_output_75, value_25], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13.run(buf1077, buf1078, buf1079, 8, 16, 1, stream=raw_stream0)
        del buf1078
        buf1080 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        buf1081 = empty_strided((1, 4, 2048), (2048, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [attn_output_75, transpose_103, reshape_77, output_178], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14.run(buf1079, buf1081, 8192, stream=raw_stream0)
        assert_size_stride_grouped((arg541_1, arg542_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_75, transpose_103, reshape_77, output_178], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf1081, arg541_1, buf1080, arg542_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg541_1
        del arg542_1
        assert_size_stride(arg543_1, (2048, ), (1, ), 'input')
        buf1083 = buf999; del buf999  # reuse
        buf1086 = reinterpret_tensor(buf1081, (1, 4, 2048), (8192, 2048, 1), 0); del buf1081  # reuse
        buf1089 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_335, hidden_states_345, hidden_states_349, hidden_states_359, hidden_states_360, pow_104, variance_103, add_234, rsqrt_103, hidden_states_361, to_211, hidden_states_362, output_179, output_180], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_22.run(buf1083, buf1007, buf1040, buf1049, buf1080, arg543_1, buf1086, buf1089, 4, 2048, stream=raw_stream0)
        del arg543_1
        del buf1007
        buf1085 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg544_1, arg545_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_360, pow_104, variance_103, add_234, rsqrt_103, hidden_states_361, to_211, hidden_states_362, output_179], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf1086, arg544_1, buf1085, arg545_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg544_1
        del arg545_1
        buf1088 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg546_1, arg547_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_360, pow_104, variance_103, add_234, rsqrt_103, hidden_states_361, to_211, hidden_states_362, output_180], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf1089, arg546_1, buf1088, arg547_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg546_1
        del arg547_1
        buf1091 = buf1089; del buf1089  # reuse
        buf1092 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu_25, mul_340, output_181], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_16.run(buf1085, buf1088, buf1092, 24576, stream=raw_stream0)
        del buf1085
        del buf1088
        assert_size_stride_grouped((arg548_1, arg549_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_25, mul_340, output_181], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf1092, arg548_1, buf1091, arg549_1, 4, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg548_1
        del arg549_1
        del buf1092
        assert_size_stride(arg550_1, (2048, ), (1, ), 'input')
        buf1096 = buf1086; del buf1086  # reuse
        buf1099 = buf1080; del buf1080  # reuse
        buf1102 = buf1049; del buf1049  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_363, hidden_states_364, pow_105, variance_104, add_236, rsqrt_104, hidden_states_365, to_213, hidden_states_366, output_182, output_183, output_184], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19.run(buf1083, buf1091, arg550_1, buf1096, buf1099, buf1102, 4, 2048, stream=raw_stream0)
        del arg550_1
        buf1095 = buf1040; del buf1040  # reuse
        assert_size_stride_grouped((arg551_1, arg552_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_363, hidden_states_364, pow_105, variance_104, add_236, rsqrt_104, hidden_states_365, to_213, hidden_states_366, output_182], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf1096, arg551_1, buf1095, arg552_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg551_1
        del arg552_1
        del buf1096
        buf1098 = buf1058; del buf1058  # reuse
        assert_size_stride_grouped((arg554_1, arg555_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_363, hidden_states_364, pow_105, variance_104, add_236, rsqrt_104, hidden_states_365, to_213, hidden_states_366, output_183], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf1099, arg554_1, buf1098, arg555_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg554_1
        del arg555_1
        del buf1099
        buf1101 = empty_strided((1, 4, 1024), (4096, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg557_1, arg558_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_363, hidden_states_364, pow_105, variance_104, add_236, rsqrt_104, hidden_states_365, to_213, hidden_states_366, output_184], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf1102, arg557_1, buf1101, arg558_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg557_1
        del arg558_1
        buf1104 = empty_strided((1, 4, 16, 1), (64, 16, 1, 64), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_367, pow_106, variance_105], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf1095, buf1104, 64, 128, stream=raw_stream0)
        assert_size_stride(arg553_1, (128, ), (1, ), 'input')
        buf1107 = reinterpret_tensor(buf1102, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf1102  # reuse
        buf1105 = reinterpret_tensor(buf1107, (1, 16, 4, 64), (8192, 512, 128, 1), 0)  # alias
        buf1106 = reinterpret_tensor(buf1107, (1, 16, 4, 64), (8192, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_367, pow_106, variance_105, add_237, rsqrt_105, hidden_states_368, to_215, mul_344, query_states_26, x2_52, neg_52, x1_52, cat_54], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg553_1, buf1095, buf1104, buf1105, buf1106, 4096, stream=raw_stream0)
        buf1108 = empty_strided((1, 4, 8, 1), (32, 8, 1, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_369, pow_107, variance_106], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf1098, buf1108, 32, 128, stream=raw_stream0)
        del buf1105
        del buf1106
        assert_size_stride(arg556_1, (128, ), (1, ), 'input')
        buf1111 = empty_strided((1, 8, 4, 128), (4096, 512, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf1109 = reinterpret_tensor(buf1111, (1, 8, 4, 64), (4096, 512, 128, 1), 0)  # alias
        buf1110 = reinterpret_tensor(buf1111, (1, 8, 4, 64), (4096, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_369, pow_107, variance_106, add_238, rsqrt_106, hidden_states_370, to_217, mul_346, key_states_26, x2_53, neg_53, x1_53, cat_55], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg556_1, buf1098, buf1108, buf1109, buf1110, 2048, stream=raw_stream0)
        assert_size_stride_grouped((arg559_1, arg560_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_30, sin_30, arange_30, cache_position_26, hidden_states_369, pow_107, variance_106, add_238, rsqrt_106, hidden_states_370, to_217, mul_346, key_states_26, mul_349, mul_350, k_embed_26, index_copy__52], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg559_1, arg556_1, buf1098, buf1108, buf1, buf1111, buf0, arg560_1, 4096, stream=raw_stream0)
        del arg556_1
        del buf1098
        del buf1108
        del buf1109
        del buf1110
        del buf1111
        buf1113 = reinterpret_tensor(buf1079, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf1079  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_367, pow_106, variance_105, add_237, rsqrt_105, hidden_states_368, to_215, mul_344, query_states_26, cos_30, mul_347, sin_30, mul_348, q_embed_26, attn_output_78], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg553_1, buf1095, buf1104, buf1, buf1107, buf0, buf1113, 8192, stream=raw_stream0)
        del arg553_1
        del buf1104
        buf1114 = empty_strided((1, 16, 128, 256), (524288, 32768, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [key_26, attn_output_78], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8.run(arg560_1, buf1114, 524288, stream=raw_stream0)
        del arg560_1
        buf1115 = reinterpret_tensor(buf1077, (16, 4, 256), (1024, 256, 1), 0); del buf1077  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_367, pow_106, variance_105, add_237, rsqrt_105, hidden_states_368, to_215, mul_344, query_states_26, cos_30, mul_347, sin_30, mul_348, q_embed_26, attn_output_78, key_26], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9.run(buf1113, buf1114, buf1115, 16, 16, 1, stream=raw_stream0)
        del buf1114
        buf1118 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        buf1121 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_78], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10.run(buf1115, arg3_1, buf1118, buf1121, 64, 256, stream=raw_stream0)
        del buf1115
        del buf1118
        assert_size_stride(arg561_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_30, cache_position_26, index_copy__53], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_11.run(arg559_1, buf1101, arg561_1, 4096, stream=raw_stream0)
        buf1122 = empty_strided((1, 16, 256, 128), (524288, 32768, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [value_26, attn_output_78], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(arg561_1, buf1122, 524288, stream=raw_stream0)
        del arg561_1
        buf1123 = reinterpret_tensor(buf1113, (16, 4, 128), (512, 128, 1), 0); del buf1113  # reuse
        # Topologically Sorted Source Nodes: [attn_output_78, value_26], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13.run(buf1121, buf1122, buf1123, 8, 16, 1, stream=raw_stream0)
        del buf1122
        buf1124 = reinterpret_tensor(buf1107, (1, 4, 2048), (8192, 2048, 1), 0); del buf1107  # reuse
        buf1125 = reinterpret_tensor(buf1095, (1, 4, 2048), (2048, 2048, 1), 0); del buf1095  # reuse
        # Topologically Sorted Source Nodes: [attn_output_78, transpose_107, reshape_80, output_185], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14.run(buf1123, buf1125, 8192, stream=raw_stream0)
        assert_size_stride_grouped((arg562_1, arg563_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_78, transpose_107, reshape_80, output_185], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf1125, arg562_1, buf1124, arg563_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg562_1
        del arg563_1
        assert_size_stride(arg564_1, (2048, ), (1, ), 'input')
        buf1128 = reinterpret_tensor(buf1125, (1, 4, 2048), (8192, 2048, 1), 0); del buf1125  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_363, hidden_states_373, hidden_states_374, pow_108, variance_107, add_243, rsqrt_107, hidden_states_375, to_219, hidden_states_376], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20.run(buf1083, buf1091, buf1124, arg564_1, buf1128, 4, 2048, stream=raw_stream0)
        del arg564_1
        buf1129 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg565_1, arg566_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_186], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf1128, arg565_1, buf1129, arg566_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg565_1
        del arg566_1
        buf1131 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg567_1, arg568_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_187], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf1128, arg567_1, buf1131, arg568_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg567_1
        del arg568_1
        buf1133 = buf1128; del buf1128  # reuse
        buf1134 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu_26, mul_353, output_188], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_16.run(buf1129, buf1131, buf1134, 24576, stream=raw_stream0)
        del buf1129
        del buf1131
        assert_size_stride_grouped((arg569_1, arg570_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_26, mul_353, output_188], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf1134, arg569_1, buf1133, arg570_1, 4, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg569_1
        del arg570_1
        del buf1134
        assert_size_stride(arg571_1, (2048, ), (1, ), 'input')
        buf1137 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_363, hidden_states_373, hidden_states_377, hidden_states_378, pow_109, variance_108, add_245, rsqrt_108, hidden_states_379, to_221, hidden_states_380], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21.run(buf1083, buf1091, buf1124, buf1133, arg571_1, buf1137, 4, 2048, stream=raw_stream0)
        del arg571_1
        buf1138 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg572_1, arg573_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_189], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf1137, arg572_1, buf1138, arg573_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg572_1
        del arg573_1
        buf1140 = buf1101; del buf1101  # reuse
        assert_size_stride_grouped((arg575_1, arg576_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_190], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf1137, arg575_1, buf1140, arg576_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg575_1
        del arg576_1
        buf1142 = empty_strided((1, 4, 1024), (4096, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg578_1, arg579_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_191], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf1137, arg578_1, buf1142, arg579_1, 4, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg578_1
        del arg579_1
        buf1144 = empty_strided((1, 4, 16, 1), (64, 16, 1, 64), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_381, pow_110, variance_109], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf1138, buf1144, 64, 128, stream=raw_stream0)
        assert_size_stride(arg574_1, (128, ), (1, ), 'input')
        buf1147 = reinterpret_tensor(buf1137, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf1137  # reuse
        buf1145 = reinterpret_tensor(buf1147, (1, 16, 4, 64), (8192, 512, 128, 1), 0)  # alias
        buf1146 = reinterpret_tensor(buf1147, (1, 16, 4, 64), (8192, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_381, pow_110, variance_109, add_246, rsqrt_109, hidden_states_382, to_223, mul_357, query_states_27, x2_54, neg_54, x1_54, cat_56], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg574_1, buf1138, buf1144, buf1145, buf1146, 4096, stream=raw_stream0)
        buf1148 = empty_strided((1, 4, 8, 1), (32, 8, 1, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_383, pow_111, variance_110], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf1140, buf1148, 32, 128, stream=raw_stream0)
        del buf1145
        del buf1146
        assert_size_stride(arg577_1, (128, ), (1, ), 'input')
        buf1151 = empty_strided((1, 8, 4, 128), (4096, 512, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf1149 = reinterpret_tensor(buf1151, (1, 8, 4, 64), (4096, 512, 128, 1), 0)  # alias
        buf1150 = reinterpret_tensor(buf1151, (1, 8, 4, 64), (4096, 512, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_383, pow_111, variance_110, add_247, rsqrt_110, hidden_states_384, to_225, mul_359, key_states_27, x2_55, neg_55, x1_55, cat_57], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg577_1, buf1140, buf1148, buf1149, buf1150, 2048, stream=raw_stream0)
        assert_size_stride_grouped((arg580_1, arg581_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_31, sin_31, arange_31, cache_position_27, hidden_states_383, pow_111, variance_110, add_247, rsqrt_110, hidden_states_384, to_225, mul_359, key_states_27, mul_362, mul_363, k_embed_27, index_copy__54], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg580_1, arg577_1, buf1140, buf1148, buf1, buf1151, buf0, arg581_1, 4096, stream=raw_stream0)
        del arg577_1
        del buf1140
        del buf1148
        del buf1149
        del buf1150
        del buf1151
        buf1153 = reinterpret_tensor(buf1123, (1, 16, 4, 128), (8192, 512, 128, 1), 0); del buf1123  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_381, pow_110, variance_109, add_246, rsqrt_109, hidden_states_382, to_223, mul_357, query_states_27, cos_31, mul_360, sin_31, mul_361, q_embed_27, attn_output_81], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg574_1, buf1138, buf1144, buf1, buf1147, buf0, buf1153, 8192, stream=raw_stream0)
        del arg574_1
        del buf0
        del buf1
        del buf1138
        del buf1144
        del buf1147
        buf1154 = empty_strided((1, 16, 128, 256), (524288, 32768, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [key_27, attn_output_81], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_8.run(arg581_1, buf1154, 524288, stream=raw_stream0)
        del arg581_1
        buf1155 = reinterpret_tensor(buf1121, (16, 4, 256), (1024, 256, 1), 0); del buf1121  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_381, pow_110, variance_109, add_246, rsqrt_109, hidden_states_382, to_223, mul_357, query_states_27, cos_31, mul_360, sin_31, mul_361, q_embed_27, attn_output_81, key_27], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_9.run(buf1153, buf1154, buf1155, 16, 16, 1, stream=raw_stream0)
        del buf1154
        buf1158 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        buf1161 = empty_strided((1, 16, 4, 256), (16384, 1024, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_81], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10.run(buf1155, arg3_1, buf1158, buf1161, 64, 256, stream=raw_stream0)
        del buf1155
        del buf1158
        assert_size_stride(arg582_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_31, cache_position_27, index_copy__55], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_11.run(arg580_1, buf1142, arg582_1, 4096, stream=raw_stream0)
        del buf1142
        buf1162 = empty_strided((1, 16, 256, 128), (524288, 32768, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [value_27, attn_output_81], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(arg582_1, buf1162, 524288, stream=raw_stream0)
        del arg582_1
        buf1163 = reinterpret_tensor(buf1153, (16, 4, 128), (512, 128, 1), 0); del buf1153  # reuse
        # Topologically Sorted Source Nodes: [attn_output_81, value_27], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_13.run(buf1161, buf1162, buf1163, 8, 16, 1, stream=raw_stream0)
        del buf1161
        del buf1162
        buf1164 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        buf1165 = empty_strided((1, 4, 2048), (2048, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [attn_output_81, transpose_111, reshape_83, output_192], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_transpose_view_14.run(buf1163, buf1165, 8192, stream=raw_stream0)
        del buf1163
        assert_size_stride_grouped((arg583_1, arg584_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_81, transpose_111, reshape_83, output_192], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf1165, arg583_1, buf1164, arg584_1, 4, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg583_1
        del arg584_1
        assert_size_stride(arg585_1, (2048, ), (1, ), 'input')
        buf1167 = buf1083; del buf1083  # reuse
        buf1170 = reinterpret_tensor(buf1165, (1, 4, 2048), (8192, 2048, 1), 0); del buf1165  # reuse
        buf1173 = empty_strided((1, 4, 2048), (8192, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_363, hidden_states_373, hidden_states_377, hidden_states_387, hidden_states_388, pow_112, variance_111, add_252, rsqrt_111, hidden_states_389, to_227, hidden_states_390, output_193, output_194], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_22.run(buf1167, buf1091, buf1124, buf1133, buf1164, arg585_1, buf1170, buf1173, 4, 2048, stream=raw_stream0)
        del arg585_1
        del buf1091
        del buf1124
        del buf1133
        del buf1164
        buf1169 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg586_1, arg587_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_388, pow_112, variance_111, add_252, rsqrt_111, hidden_states_389, to_227, hidden_states_390, output_193], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf1170, arg586_1, buf1169, arg587_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg586_1
        del arg587_1
        del buf1170
        buf1172 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg588_1, arg589_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_388, pow_112, variance_111, add_252, rsqrt_111, hidden_states_389, to_227, hidden_states_390, output_194], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf1173, arg588_1, buf1172, arg589_1, 4, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg588_1
        del arg589_1
        buf1175 = buf1173; del buf1173  # reuse
        buf1176 = empty_strided((1, 4, 6144), (24576, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu_27, mul_366, output_195], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_16.run(buf1169, buf1172, buf1176, 24576, stream=raw_stream0)
        del buf1169
        del buf1172
        assert_size_stride_grouped((arg590_1, arg591_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_27, mul_366, output_195], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf1176, arg590_1, buf1175, arg591_1, 4, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg590_1
        del arg591_1
        del buf1176
        assert_size_stride(arg592_1, (2048, ), (1, ), 'input')
        buf1179 = buf1167; del buf1167  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_391, hidden_states_392, pow_113, variance_112, add_254, rsqrt_112, hidden_states_393, to_229, hidden_states_394], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_23.run(buf1179, buf1175, arg592_1, 4, 2048, stream=raw_stream0)
        del arg592_1
        del buf1175
        assert_size_stride(arg593_1, (151936, 2048), (2048, 1), 'input')
        buf1180 = empty_strided((1, 151936), (151936, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_391, hidden_states_392, pow_113, variance_112, add_254, rsqrt_112, hidden_states_393, to_229, hidden_states_394, getitem_181, logits], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.slice, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_slice_t_view_24.run(buf1179, arg593_1, buf1180, 9496, 1, 1, stream=raw_stream0)
        del arg593_1
        del buf1179
        # Topologically Sorted Source Nodes: [add_], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__25.run(arg3_1, arg3_1, 1, stream=raw_stream0)
        del arg3_1
        # Topologically Sorted Source Nodes: [add__1], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__25.run(arg34_1, arg34_1, 1, stream=raw_stream0)
        del arg34_1
        # Topologically Sorted Source Nodes: [add__2], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__25.run(arg55_1, arg55_1, 1, stream=raw_stream0)
        del arg55_1
        # Topologically Sorted Source Nodes: [add__3], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__25.run(arg76_1, arg76_1, 1, stream=raw_stream0)
        del arg76_1
        # Topologically Sorted Source Nodes: [add__4], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__25.run(arg97_1, arg97_1, 1, stream=raw_stream0)
        del arg97_1
        # Topologically Sorted Source Nodes: [add__5], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__25.run(arg118_1, arg118_1, 1, stream=raw_stream0)
        del arg118_1
        # Topologically Sorted Source Nodes: [add__6], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__25.run(arg139_1, arg139_1, 1, stream=raw_stream0)
        del arg139_1
        # Topologically Sorted Source Nodes: [add__7], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__25.run(arg160_1, arg160_1, 1, stream=raw_stream0)
        del arg160_1
        # Topologically Sorted Source Nodes: [add__8], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__25.run(arg181_1, arg181_1, 1, stream=raw_stream0)
        del arg181_1
        # Topologically Sorted Source Nodes: [add__9], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__25.run(arg202_1, arg202_1, 1, stream=raw_stream0)
        del arg202_1
        # Topologically Sorted Source Nodes: [add__10], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__25.run(arg223_1, arg223_1, 1, stream=raw_stream0)
        del arg223_1
        # Topologically Sorted Source Nodes: [add__11], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__25.run(arg244_1, arg244_1, 1, stream=raw_stream0)
        del arg244_1
        # Topologically Sorted Source Nodes: [add__12], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__25.run(arg265_1, arg265_1, 1, stream=raw_stream0)
        del arg265_1
        # Topologically Sorted Source Nodes: [add__13], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__25.run(arg286_1, arg286_1, 1, stream=raw_stream0)
        del arg286_1
        # Topologically Sorted Source Nodes: [add__14], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__25.run(arg307_1, arg307_1, 1, stream=raw_stream0)
        del arg307_1
        # Topologically Sorted Source Nodes: [add__15], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__25.run(arg328_1, arg328_1, 1, stream=raw_stream0)
        del arg328_1
        # Topologically Sorted Source Nodes: [add__16], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__25.run(arg349_1, arg349_1, 1, stream=raw_stream0)
        del arg349_1
        # Topologically Sorted Source Nodes: [add__17], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__25.run(arg370_1, arg370_1, 1, stream=raw_stream0)
        del arg370_1
        # Topologically Sorted Source Nodes: [add__18], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__25.run(arg391_1, arg391_1, 1, stream=raw_stream0)
        del arg391_1
        # Topologically Sorted Source Nodes: [add__19], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__25.run(arg412_1, arg412_1, 1, stream=raw_stream0)
        del arg412_1
        # Topologically Sorted Source Nodes: [add__20], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__25.run(arg433_1, arg433_1, 1, stream=raw_stream0)
        del arg433_1
        # Topologically Sorted Source Nodes: [add__21], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__25.run(arg454_1, arg454_1, 1, stream=raw_stream0)
        del arg454_1
        # Topologically Sorted Source Nodes: [add__22], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__25.run(arg475_1, arg475_1, 1, stream=raw_stream0)
        del arg475_1
        # Topologically Sorted Source Nodes: [add__23], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__25.run(arg496_1, arg496_1, 1, stream=raw_stream0)
        del arg496_1
        # Topologically Sorted Source Nodes: [add__24], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__25.run(arg517_1, arg517_1, 1, stream=raw_stream0)
        del arg517_1
        # Topologically Sorted Source Nodes: [add__25], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__25.run(arg538_1, arg538_1, 1, stream=raw_stream0)
        del arg538_1
        # Topologically Sorted Source Nodes: [add__26], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__25.run(arg559_1, arg559_1, 1, stream=raw_stream0)
        del arg559_1
        # Topologically Sorted Source Nodes: [add__27], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__25.run(arg580_1, arg580_1, 1, stream=raw_stream0)
        del arg580_1
        return (reinterpret_tensor(buf1180, (1, 1, 151936), (151936, 151936, 1), 0), )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((1, 4), (4, 1), device='tnca:0', dtype=torch.int64)
    arg1_1 = rand_strided((151936, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg2_1 = rand_strided((4, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.int64)
    arg3_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg4_1 = rand_strided((64, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg5_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg6_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg7_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg8_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg9_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg10_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg11_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg12_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg13_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg14_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg15_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg16_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg17_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg18_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg19_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg20_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg21_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg22_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg23_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg24_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg25_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg26_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg27_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg28_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg29_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg30_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg31_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg32_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg33_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg34_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg35_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg36_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg37_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg38_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg39_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg40_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg41_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg42_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg43_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg44_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg45_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg46_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg47_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg48_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg49_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg50_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg51_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg52_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg53_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg54_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg55_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg56_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg57_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg58_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg59_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg60_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg61_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg62_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg63_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg64_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg65_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg66_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg67_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg68_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg69_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg70_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg71_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg72_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg73_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg74_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg75_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg76_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg77_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg78_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg79_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg80_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg81_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg82_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg83_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg84_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg85_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg86_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg87_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg88_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg89_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg90_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg91_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg92_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg93_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg94_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg95_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg96_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg97_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg98_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg99_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg100_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg101_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg102_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg103_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg104_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg105_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg106_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg107_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg108_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg109_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg110_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg111_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg112_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg113_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg114_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg115_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg116_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg117_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg118_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg119_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg120_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg121_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg122_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg123_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg124_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg125_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg126_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg127_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg128_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg129_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg130_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg131_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg132_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg133_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg134_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg135_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg136_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg137_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg138_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg139_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg140_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg141_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg142_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg143_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg144_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg145_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg146_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg147_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg148_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg149_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg150_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg151_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg152_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg153_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg154_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg155_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg156_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg157_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg158_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg159_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg160_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg161_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg162_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg163_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg164_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg165_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg166_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg167_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg168_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg169_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg170_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg171_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg172_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg173_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg174_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg175_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg176_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg177_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg178_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg179_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg180_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg181_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg182_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg183_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg184_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg185_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg186_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg187_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg188_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg189_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg190_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg191_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg192_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg193_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg194_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg195_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg196_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg197_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg198_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg199_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg200_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg201_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg202_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg203_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg204_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg205_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg206_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg207_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg208_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg209_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg210_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg211_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg212_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg213_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg214_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg215_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg216_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg217_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg218_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg219_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg220_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg221_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg222_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg223_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg224_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg225_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg226_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg227_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg228_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg229_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg230_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg231_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg232_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg233_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg234_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg235_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg236_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg237_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg238_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg239_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg240_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg241_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg242_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg243_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg244_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg245_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg246_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg247_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg248_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg249_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg250_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg251_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg252_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg253_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg254_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg255_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg256_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg257_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg258_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg259_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg260_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg261_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg262_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg263_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg264_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg265_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg266_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg267_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg268_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg269_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg270_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg271_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg272_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg273_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg274_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg275_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg276_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg277_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg278_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg279_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg280_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg281_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg282_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg283_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg284_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg285_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg286_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg287_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg288_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg289_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg290_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg291_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg292_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg293_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg294_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg295_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg296_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg297_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg298_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg299_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg300_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg301_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg302_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg303_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg304_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg305_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg306_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg307_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg308_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg309_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg310_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg311_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg312_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg313_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg314_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg315_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg316_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg317_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg318_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg319_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg320_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg321_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg322_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg323_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg324_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg325_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg326_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg327_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg328_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg329_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg330_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg331_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg332_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg333_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg334_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg335_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg336_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg337_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg338_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg339_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg340_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg341_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg342_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg343_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg344_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg345_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg346_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg347_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg348_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg349_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg350_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg351_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg352_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg353_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg354_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg355_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg356_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg357_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg358_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg359_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg360_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg361_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg362_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg363_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg364_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg365_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg366_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg367_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg368_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg369_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg370_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg371_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg372_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg373_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg374_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg375_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg376_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg377_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg378_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg379_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg380_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg381_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg382_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg383_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg384_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg385_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg386_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg387_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg388_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg389_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg390_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg391_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg392_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg393_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg394_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg395_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg396_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg397_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg398_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg399_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg400_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg401_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg402_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg403_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg404_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg405_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg406_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg407_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg408_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg409_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg410_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg411_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg412_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg413_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg414_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg415_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg416_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg417_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg418_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg419_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg420_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg421_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg422_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg423_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg424_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg425_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg426_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg427_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg428_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg429_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg430_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg431_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg432_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg433_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg434_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg435_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg436_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg437_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg438_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg439_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg440_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg441_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg442_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg443_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg444_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg445_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg446_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg447_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg448_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg449_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg450_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg451_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg452_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg453_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg454_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg455_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg456_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg457_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg458_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg459_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg460_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg461_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg462_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg463_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg464_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg465_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg466_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg467_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg468_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg469_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg470_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg471_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg472_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg473_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg474_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg475_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg476_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg477_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg478_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg479_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg480_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg481_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg482_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg483_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg484_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg485_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg486_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg487_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg488_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg489_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg490_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg491_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg492_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg493_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg494_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg495_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg496_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg497_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg498_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg499_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg500_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg501_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg502_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg503_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg504_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg505_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg506_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg507_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg508_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg509_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg510_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg511_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg512_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg513_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg514_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg515_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg516_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg517_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg518_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg519_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg520_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg521_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg522_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg523_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg524_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg525_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg526_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg527_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg528_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg529_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg530_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg531_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg532_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg533_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg534_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg535_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg536_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg537_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg538_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg539_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg540_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg541_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg542_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg543_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg544_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg545_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg546_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg547_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg548_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg549_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg550_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg551_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg552_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg553_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg554_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg555_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg556_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg557_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg558_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg559_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg560_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg561_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg562_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg563_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg564_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg565_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg566_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg567_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg568_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg569_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg570_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg571_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg572_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg573_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg574_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg575_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg576_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg577_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg578_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg579_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg580_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg581_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg582_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg583_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg584_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg585_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg586_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg587_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg588_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg589_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg590_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg591_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg592_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg593_1 = rand_strided((151936, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1, arg123_1, arg124_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg132_1, arg133_1, arg134_1, arg135_1, arg136_1, arg137_1, arg138_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg146_1, arg147_1, arg148_1, arg149_1, arg150_1, arg151_1, arg152_1, arg153_1, arg154_1, arg155_1, arg156_1, arg157_1, arg158_1, arg159_1, arg160_1, arg161_1, arg162_1, arg163_1, arg164_1, arg165_1, arg166_1, arg167_1, arg168_1, arg169_1, arg170_1, arg171_1, arg172_1, arg173_1, arg174_1, arg175_1, arg176_1, arg177_1, arg178_1, arg179_1, arg180_1, arg181_1, arg182_1, arg183_1, arg184_1, arg185_1, arg186_1, arg187_1, arg188_1, arg189_1, arg190_1, arg191_1, arg192_1, arg193_1, arg194_1, arg195_1, arg196_1, arg197_1, arg198_1, arg199_1, arg200_1, arg201_1, arg202_1, arg203_1, arg204_1, arg205_1, arg206_1, arg207_1, arg208_1, arg209_1, arg210_1, arg211_1, arg212_1, arg213_1, arg214_1, arg215_1, arg216_1, arg217_1, arg218_1, arg219_1, arg220_1, arg221_1, arg222_1, arg223_1, arg224_1, arg225_1, arg226_1, arg227_1, arg228_1, arg229_1, arg230_1, arg231_1, arg232_1, arg233_1, arg234_1, arg235_1, arg236_1, arg237_1, arg238_1, arg239_1, arg240_1, arg241_1, arg242_1, arg243_1, arg244_1, arg245_1, arg246_1, arg247_1, arg248_1, arg249_1, arg250_1, arg251_1, arg252_1, arg253_1, arg254_1, arg255_1, arg256_1, arg257_1, arg258_1, arg259_1, arg260_1, arg261_1, arg262_1, arg263_1, arg264_1, arg265_1, arg266_1, arg267_1, arg268_1, arg269_1, arg270_1, arg271_1, arg272_1, arg273_1, arg274_1, arg275_1, arg276_1, arg277_1, arg278_1, arg279_1, arg280_1, arg281_1, arg282_1, arg283_1, arg284_1, arg285_1, arg286_1, arg287_1, arg288_1, arg289_1, arg290_1, arg291_1, arg292_1, arg293_1, arg294_1, arg295_1, arg296_1, arg297_1, arg298_1, arg299_1, arg300_1, arg301_1, arg302_1, arg303_1, arg304_1, arg305_1, arg306_1, arg307_1, arg308_1, arg309_1, arg310_1, arg311_1, arg312_1, arg313_1, arg314_1, arg315_1, arg316_1, arg317_1, arg318_1, arg319_1, arg320_1, arg321_1, arg322_1, arg323_1, arg324_1, arg325_1, arg326_1, arg327_1, arg328_1, arg329_1, arg330_1, arg331_1, arg332_1, arg333_1, arg334_1, arg335_1, arg336_1, arg337_1, arg338_1, arg339_1, arg340_1, arg341_1, arg342_1, arg343_1, arg344_1, arg345_1, arg346_1, arg347_1, arg348_1, arg349_1, arg350_1, arg351_1, arg352_1, arg353_1, arg354_1, arg355_1, arg356_1, arg357_1, arg358_1, arg359_1, arg360_1, arg361_1, arg362_1, arg363_1, arg364_1, arg365_1, arg366_1, arg367_1, arg368_1, arg369_1, arg370_1, arg371_1, arg372_1, arg373_1, arg374_1, arg375_1, arg376_1, arg377_1, arg378_1, arg379_1, arg380_1, arg381_1, arg382_1, arg383_1, arg384_1, arg385_1, arg386_1, arg387_1, arg388_1, arg389_1, arg390_1, arg391_1, arg392_1, arg393_1, arg394_1, arg395_1, arg396_1, arg397_1, arg398_1, arg399_1, arg400_1, arg401_1, arg402_1, arg403_1, arg404_1, arg405_1, arg406_1, arg407_1, arg408_1, arg409_1, arg410_1, arg411_1, arg412_1, arg413_1, arg414_1, arg415_1, arg416_1, arg417_1, arg418_1, arg419_1, arg420_1, arg421_1, arg422_1, arg423_1, arg424_1, arg425_1, arg426_1, arg427_1, arg428_1, arg429_1, arg430_1, arg431_1, arg432_1, arg433_1, arg434_1, arg435_1, arg436_1, arg437_1, arg438_1, arg439_1, arg440_1, arg441_1, arg442_1, arg443_1, arg444_1, arg445_1, arg446_1, arg447_1, arg448_1, arg449_1, arg450_1, arg451_1, arg452_1, arg453_1, arg454_1, arg455_1, arg456_1, arg457_1, arg458_1, arg459_1, arg460_1, arg461_1, arg462_1, arg463_1, arg464_1, arg465_1, arg466_1, arg467_1, arg468_1, arg469_1, arg470_1, arg471_1, arg472_1, arg473_1, arg474_1, arg475_1, arg476_1, arg477_1, arg478_1, arg479_1, arg480_1, arg481_1, arg482_1, arg483_1, arg484_1, arg485_1, arg486_1, arg487_1, arg488_1, arg489_1, arg490_1, arg491_1, arg492_1, arg493_1, arg494_1, arg495_1, arg496_1, arg497_1, arg498_1, arg499_1, arg500_1, arg501_1, arg502_1, arg503_1, arg504_1, arg505_1, arg506_1, arg507_1, arg508_1, arg509_1, arg510_1, arg511_1, arg512_1, arg513_1, arg514_1, arg515_1, arg516_1, arg517_1, arg518_1, arg519_1, arg520_1, arg521_1, arg522_1, arg523_1, arg524_1, arg525_1, arg526_1, arg527_1, arg528_1, arg529_1, arg530_1, arg531_1, arg532_1, arg533_1, arg534_1, arg535_1, arg536_1, arg537_1, arg538_1, arg539_1, arg540_1, arg541_1, arg542_1, arg543_1, arg544_1, arg545_1, arg546_1, arg547_1, arg548_1, arg549_1, arg550_1, arg551_1, arg552_1, arg553_1, arg554_1, arg555_1, arg556_1, arg557_1, arg558_1, arg559_1, arg560_1, arg561_1, arg562_1, arg563_1, arg564_1, arg565_1, arg566_1, arg567_1, arg568_1, arg569_1, arg570_1, arg571_1, arg572_1, arg573_1, arg574_1, arg575_1, arg576_1, arg577_1, arg578_1, arg579_1, arg580_1, arg581_1, arg582_1, arg583_1, arg584_1, arg585_1, arg586_1, arg587_1, arg588_1, arg589_1, arg590_1, arg591_1, arg592_1, arg593_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
