    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.splat      v0, s4
    v.movi       v1, #257
    v.movi       v2, #0
    s.rdspecial  s1, arg_base
    v.sub        v3, v2, v0
    v.sub        v4, v2, v1
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.iota       v5                              // arange(0, VLEN)
    v.movi       v6, #1
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    @p1 v.sel        v7, v3, v0
    @p2 v.sel        v3, v4, v1
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.movi       v4, #0
    v.movi       v8, #0
    s.ld.d       s6, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.movz       s7, #31
    s.ld.d       s8, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s9, [s1, #40]                   // out_ptr0: device_ptr64 at arg_base+40
idiv_1:
    v.splat      v9, s7
    v.shl        v10, v8, v6
    v.lshr       v11, v7, v9
    v.cmp.lt     p3, v8, v2
    v.and        v12, v11, v6
    v.shl        v11, v6, v9
    v.or         v9, v10, v12
    s.subi       s1, s7, #1
    v.cmp.geu    p4, v9, v3
    p.or         p5, p3, p4
    v.sub        v10, v9, v3
    @p5 v.sel        v12, v11, v2
    @p5 v.sel        v11, v10, v9
    v.or         v9, v4, v12
    v.mov        v8, v11
    v.mov        v4, v9
    s.mov        s7, s1
    s.movz       s1, #0
    s.cmp.ge     s10, s7, s1
    br.nz        s10, idiv_1
    v.movi       v3, #0
    p.xor        p3, p1, p2
    v.sub        v6, v2, v4
    v.sub        v2, v3, v0
    v.sub        v7, v3, v1
    v.cmp.lt     p1, v0, v3
    v.cmp.lt     p2, v1, v3
    @p3 v.sel        v8, v6, v4
    v.movi       v4, #1
    @p1 v.sel        v6, v2, v0
    @p2 v.sel        v0, v7, v1
    v.movi       v1, #0
    v.movi       v2, #0
    s.movz       s1, #31
idiv_2:
    v.splat      v7, s1
    v.shl        v9, v2, v4
    v.lshr       v10, v6, v7
    v.cmp.lt     p2, v2, v3
    v.and        v11, v10, v4
    v.shl        v10, v4, v7
    v.or         v7, v9, v11
    s.subi       s7, s1, #1
    v.cmp.geu    p3, v7, v0
    p.or         p4, p2, p3
    v.sub        v9, v7, v0
    @p4 v.sel        v11, v10, v3
    @p4 v.sel        v10, v9, v7
    v.or         v7, v1, v11
    v.mov        v2, v10
    v.mov        v1, v7
    s.mov        s1, s7
    s.movz       s7, #0
    s.cmp.ge     s10, s1, s7
    br.nz        s10, idiv_2
    v.sub        v0, v3, v2
    s.movz       s1, #0
    v.movi       v1, #0
    v.movi       v3, #0
    @p1 v.sel        v4, v0, v2
    s.movz       s7, #32
    s.movz       s10, #16
    s.addi       s11, s1, #0
    v.mov        v3, v1
for_3:
    s.cmp.ge     s1, s11, s7
    br.nz        s1, endfor_4
    v.movi       v0, #32
    v.splat      v1, s11
    v.mul        v2, v8, v0
    v.add        v6, v1, v5
    v.extract    s1, v2, #0
    v.splat      v1, s1
    s.shli       s1, s11, #1                     // element offset -> bytes (x2)
    v.movi       v2, #32
    v.add        v7, v6, v1
    s.add        s12, s3, s1                     // &in_ptr1[...]
    s.add        s13, s6, s1                     // &in_ptr3[...]
    v.cmp.lt     p1, v6, v2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s2, v7]               // index is in elements (ISA sec 9.1)
    v.mul        v2, v4, v0
    v.movi       v0, #3
    v.movi       v9, #0
    v.extract    s1, v2, #0
    v.splat      v2, s1
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v10, [s12, #0]
    v.sub        v11, v9, v8
    v.sub        v12, v9, v0
    v.cmp.lt     p2, v8, v9
    v.cmp.lt     p3, v0, v9
    vf.cvt.f16.f32 v13, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s5, v7]               // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v7, v10
    v.add        v10, v6, v2
    v.movi       v2, #1
    @p2 v.sel        v6, v11, v8
    @p3 v.sel        v11, v12, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s13, #0]
    vf.cvt.f16.f32 v12, v1
    v.movi       v1, #0
    v.movi       v14, #0
    s.movz       s1, #31
    vf.cvt.f16.f32 v15, v0
idiv_5:
    v.splat      v0, s1
    v.shl        v16, v14, v2
    v.lshr       v17, v6, v0
    v.cmp.lt     p4, v14, v9
    v.and        v18, v17, v2
    v.shl        v17, v2, v0
    v.or         v0, v16, v18
    s.subi       s12, s1, #1
    v.cmp.geu    p5, v0, v11
    p.or         p6, p4, p5
    v.sub        v16, v0, v11
    @p6 v.sel        v18, v17, v9
    @p6 v.sel        v17, v16, v0
    v.or         v0, v1, v18
    v.mov        v14, v17
    v.mov        v1, v0
    s.mov        s1, s12
    s.movz       s12, #0
    s.cmp.ge     s13, s1, s12
    br.nz        s13, idiv_5
    p.xor        p4, p2, p3
    v.sub        v0, v9, v1
    v.movi       v2, #8224
    @p4 v.sel        v6, v0, v1
    vf.mul       v0, v13, v7
    v.mul        v1, v6, v2
    vf.mul       v2, v12, v15
    v.extract    s1, v1, #0
    v.splat      v1, s1
    .li       s1, #1054295293
    v.splat      v6, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v7, v10, v1
    vf.add       v1, v0, v2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v0, [s8, v7]               // index is in elements (ISA sec 9.1)
    v.movi       v2, #0
    s.add        s1, s11, s10
    vf.mul       v7, v1, v6
    s.movz       s12, #1
    s.movz       s13, #8224
    vf.cvt.f16.f32 v1, v0
    vf.mul       v0, v1, v6
    vf.mul       v1, v7, v0
    vf.add       v0, v3, v1
    @p1 v.sel        v1, v0, v3
    v.mov        v2, v1
    v.mov        v3, v2
    s.mov        s11, s1
    br.nz        s12, for_3
endfor_4:
    vf.reduce.add.b v0, v3
    v.movi       v1, #0
    s.movz       s1, #1
    vf.add       v2, v0, v1
    s.shli       s2, s4, #2                      // element offset -> bytes (x4)
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.add        s1, s9, s2                      // &out_ptr0[...]
    v.cmp.lt     p1, v0, v1
    @p1 v.st.w       [s1, #0], v2
__rctx_next:
    exit
