    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    s.rdspecial  s2, arg_base
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.ld.d       s1, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #0
    v.movi       v1, #512
    v.sub        v4, v2, v3
    v.cmp.lt     p1, v3, v2
    v.sub        v5, v0, v3
    @p1 v.sel        v6, v4, v3
    v.movi       v4, #8
    v.add        v7, v3, v1
    v.cmp.lt     p2, v3, v0
    v.cmp.lt     p3, v3, v1
    @p2 v.sel        v1, v5, v3
    v.movi       v3, #255
    v.lshr       v5, v6, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v4, [s1, v7]               // index is in elements (ISA sec 9.1)
    v.and        v6, v1, v3
    v.sub        v1, v2, v5
    v.movi       v3, #272
    v.sub        v7, v0, v6
    @p1 v.sel        v8, v1, v5
    v.movi       v1, #256
    @p2 v.sel        v5, v7, v6
    v.mul        v6, v8, v3
    v.sub        v3, v0, v1
    v.sub        v7, v2, v1
    v.add        v8, v5, v6
    v.cmp.lt     p1, v1, v0
    v.cmp.lt     p2, v1, v2
    s.ld.d       s1, [s2, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    @p1 v.sel        v0, v3, v1
    @p2 v.sel        v0, v7, v1
    @p3 v.st.scatter.h [s1, v8], v4
__rctx_next:
    exit
