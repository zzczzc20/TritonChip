#!/usr/bin/env python3
"""Compare two-pass FP32 means to exact BF16 square means on DP TLM."""
import json,os,sys,tempfile
from pathlib import Path
import torch
import triton
import triton.language as tl
from safetensors.torch import load_file

@triton.jit
def square_mean(X,Y,CORRECT:tl.constexpr,BLOCK:tl.constexpr):
 row=tl.program_id(0); k=tl.arange(0,BLOCK)
 x=tl.load(X+row*BLOCK+k).to(tl.float32);q=x*x
 mean=tl.sum(q,0)/BLOCK
 if CORRECT:
  correction=tl.sum(q-mean,0)/BLOCK
  mean=mean+correction
 tl.store(Y+row,mean)

def main():
 from tnca import aot
 from tnca.runtime import Session
 import tlm_backend
 tlm_backend.register();h=Path.home();input_path=h/'r41_q35_gate_norm_tlm_20261031_diag/states.safetensors';x=load_file(str(input_path))['core'].contiguous()
 if x.shape!=(864,128) or x.dtype!=torch.bfloat16:raise ValueError('unexpected captured input')
 exact=x.double().square().mean(-1).float().contiguous();cpu=x.float().square().mean(-1).contiguous();rows=[]
 for correct in (False,True):
  f=Path(tempfile.mkdtemp())/'mean.tnca';c=aot.compile_aot(square_mean,signature={'X':'*bf16','Y':'*fp32','CORRECT':'constexpr','BLOCK':'constexpr'},constexprs={'CORRECT':correct,'BLOCK':128},profile='core-vrf-sync-v5-x8-g2c4-dp',options={'index_opt':1},output=str(f))
  with Session(profile='core-vrf-sync-v5-x8-g2c4-dp',backend='systemc-tlm-grid',host_timeout=600) as sess:
   mod=sess.load(c.path);xx=sess.allocate(x.numel()*2);yy=sess.allocate(864*4);sess.upload(xx,x.view(torch.uint8).numpy().tobytes());before=sess.dev.counters_snapshot();ev=sess.submit(mod,{'X':xx,'Y':yy},grid=(864,1,1));sess.wait(ev);after=sess.dev.counters_snapshot()
   if not ev.ok:raise RuntimeError(str(ev.error))
   got=torch.frombuffer(bytearray(sess.download(yy)),dtype=torch.float32).clone();ins=sum(v-before.get(k,0) for k,v in after.items() if k.startswith('core_') and k.endswith('_instructions'))
   row={'corrected':correct,'elements':got.numel(),'mismatches_vs_exact':int((got.view(torch.int32)!=exact.view(torch.int32)).sum()),'mismatches_vs_cpu':int((got.view(torch.int32)!=cpu.view(torch.int32)).sum()),'row755':float(got[755]),'exact_row755':float(exact[755]),'device_cycles':ev.device_cycles,'instructions':ins,'launches':1,'loads_during_launch':0};rows.append(row);print(json.dumps(row),flush=True)
 out=Path(os.environ['R41_MEAN_OUT']);out.mkdir(parents=True,exist_ok=False);(out/'result.json').write_text(json.dumps({'scope':'isolated DP TLM on captured CPU inputs; experimental, not board','rows':rows},indent=2)+'\n')
if __name__=='__main__':main()
