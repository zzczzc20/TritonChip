#!/usr/bin/env bash
set -u
route=$1
export OMP_NUM_THREADS=1 MAX_JOBS=1 CUDA_VISIBLE_DEVICES= HF_HUB_OFFLINE=1
export HF_HOME="$HOME/r41-fp8-kern-hf"
export TNCA_TLM_BINARY="$HOME/r41_vl_reason_dp/build/tnca-chip"
export TNCA_TLM_CONFIG="$HOME/r41_vl_reason_dp/src/tools/performance_harness/systemc/configs/r41-mma-dp.cfg"
export TNCA_HOST_TIMEOUT=180 TNCA_X8_EQUAL_A_STAGE="$route"
cd "$HOME/r41_chat_astage_gate_20261031"
for shape in 1_256_256_random 1_250_384_random 1_1024_256_random 1_7_256_random 16_256_256_random 1_256_256_zero; do
 IFS=_ read -r m n k input <<< "$shape"
 export TNCA_TLM_OUT="$HOME/r41_astage_gate_${route}_${shape}_tlm"
 extra=(); if [[ $input == zero ]]; then extra+=(--zero-row); fi
 "$HOME/flux-venv/bin/python" -u tools/r41/chat_speed/bench_hoisted_fp8.py --route fused --default-div --m "$m" --n "$n" --k "$k" --v1 "$HOME/r41-fp8-kern-hf/hub/kernels--kernels-community--finegrained-fp8/snapshots/48f42b23bb4e0122d4775c6d16753dd2efc7f580" --out "$HOME/r41_astage_gate_${route}_${shape}" "${extra[@]}" || echo "FAIL $route $shape"
done
