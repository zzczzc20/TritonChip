"""_scaled_mm variants beyond the matrix: use_fast_accum=True, out_dtype FP8 with scale_result."""
import os, sys
ROOT = os.path.expanduser(os.environ.get('ROOT', '~/r41-fp8-audit/cand2'))
sys.path[:0] = [ROOT, ROOT+'/python', ROOT+'/compiler/python', ROOT+'/tools/asm', ROOT+'/tools/performance_harness/systemc', ROOT+'/tools/performance_harness']
os.environ.update(TNCA_PROFILE='core-vrf-sync-v5', TNCA_TORCH_DEVICE='native', TNCA_INDEX_OPT='1', TNCA_BACKEND='systemc-tlm-grid',
                  TNCA_TLM_BINARY=os.path.expanduser('~/r41-fp8-build/tnca-chip'))
import torch, triton, tnca, tlm_backend
tlm_backend.register()
import tnca.torch_device as D; D.register()
from fp8_cases import fp8_operands, per_k_fma, scaled_reference, compare, summary_of, to_device
E4 = torch.float8_e4m3fn
g = torch.Generator().manual_seed(3)
a, b = fp8_operands(32, 48, 64, E4, g)
sa, sb = torch.tensor(0.0371), torch.tensor(1.83)
def run(name, fn, ref, *args):
    torch._dynamo.reset()
    try:
        y = torch.compile(fn, backend='inductor', fullgraph=True)(*[to_device(t) for t in args]).cpu()
        print(name, summary_of(compare(y, ref)))
    except Exception as e:
        print(name, 'ERROR', type(e).__name__, str(e)[:300])
ref = scaled_reference(a, b, sa, sb, None, torch.bfloat16)
run('use_fast_accum=True -> bf16 (vs per-K reference)', lambda a, b, s, t: torch._scaled_mm(a, b, s, t, out_dtype=torch.bfloat16, use_fast_accum=True), ref, a, b, sa, sb)
sr = torch.tensor(4.0)
cpu = torch._scaled_mm(a, b, sa, sb, scale_result=sr, out_dtype=E4)
acc = per_k_fma(a, b)
ref8 = ((acc * (sa * sb)) * (1 / sr)).to(E4)
print('torch CPU out e4m3 with scale_result vs (acc*scale)/scale_result:', summary_of(compare(cpu, ref8)))
run('out_dtype=e4m3, scale_result=4 (vs per-K reference / scale_result)', lambda a, b, s, t, r: torch._scaled_mm(a, b, s, t, scale_result=r, out_dtype=E4), ref8, a, b, sa, sb, sr)
