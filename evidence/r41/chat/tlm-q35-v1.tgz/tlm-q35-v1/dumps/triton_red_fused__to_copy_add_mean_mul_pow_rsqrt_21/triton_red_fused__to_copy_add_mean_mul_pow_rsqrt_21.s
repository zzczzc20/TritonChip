    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s5, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s6, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s7, [s1, #40]                   // out_ptr1: device_ptr64 at arg_base+40
    v.iota       v0                              // arange(0, VLEN)
    s.rdspecial  s1, arg_base
    s.ld.d       s8, [s1, #56]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.addi       s1, s8, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 1)
    s.movz       s9, #0
    s.st.d       [s1, #0], s2
    s.movz       s9, #2560
    s.st.d       [s1, #8], s9
    s.movz       s9, #2
    s.st.d       [s1, #48], s9
    s.movz       s9, #16
    s.st.d       [s1, #88], s9
    .li       s9, #1103806595072
    s.st.d       [s1, #104], s9
    td.load      d0, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s8, #256                    // TensorMap 1: tl.make_tensor_descriptor (rank 1)
    s.movz       s9, #0
    s.st.d       [s1, #0], s3
    s.movz       s9, #2560
    s.st.d       [s1, #8], s9
    s.movz       s9, #2
    s.st.d       [s1, #48], s9
    s.movz       s9, #16
    s.st.d       [s1, #88], s9
    .li       s9, #1103806595072
    s.st.d       [s1, #104], s9
    td.load      d1, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s8, #512                    // TensorMap 2: tl.make_tensor_descriptor (rank 1)
    s.movz       s9, #0
    s.st.d       [s1, #0], s4
    s.movz       s9, #2560
    s.st.d       [s1, #8], s9
    s.movz       s9, #2
    s.st.d       [s1, #48], s9
    s.movz       s9, #16
    s.st.d       [s1, #88], s9
    .li       s9, #1103806595072
    s.st.d       [s1, #104], s9
    td.load      d2, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s8, #768                    // TensorMap 3: tl.make_tensor_descriptor (rank 1)
    s.movz       s8, #0
    s.st.d       [s1, #0], s5
    s.movz       s8, #2560
    s.st.d       [s1, #8], s8
    s.movz       s8, #2
    s.st.d       [s1, #48], s8
    s.movz       s8, #16
    s.st.d       [s1, #88], s8
    .li       s8, #1103806595072
    s.st.d       [s1, #104], s8
    td.load      d3, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s8, #2560
    s.movz       s9, #16
    s.addi       s10, s1, #0
    v.movi       v1, #0
    v.movi       v2, #0
    v.mov        v2, v1
for_1:
    s.cmp.ge     s11, s10, s8
    br.nz        s11, endfor_2
    v.splat      v1, s10
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v4, s10
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s11, #2560
    s.movz       s12, #2560
    s.muli       s13, s10, #2
    s.muli       s14, s10, #2
    v.add        v6, v1, v3
    v.movi       v1, #0
    v.splat      v3, s11
    v.add        v7, v4, v5
    v.movi       v4, #0
    v.splat      v5, s12
    v.splat      v8, s10
    v.iota       v9                              // arange(0, VLEN)
    v.cmp.ge     p1, v6, v1
    v.cmp.lt     p2, v6, v3
    v.cmp.ge     p3, v7, v4
    v.cmp.lt     p4, v7, v5
    s.movz       s11, #2560
    s.add        s12, s2, s13
    p.and        p5, p1, p2
    s.add        s13, s3, s14
    p.and        p1, p3, p4
    s.muli       s14, s10, #2
    v.add        v1, v8, v9
    v.movi       v3, #0
    v.splat      v4, s11
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v5, [s12, #0]
    v.splat      v6, s10
    v.iota       v7                              // arange(0, VLEN)
    v.cmp.ge     p2, v1, v3
    v.cmp.lt     p3, v1, v4
    s.add        s11, s4, s14
    p.and        p4, p2, p3
    s.muli       s12, s10, #2
    v.add        v1, v6, v7
    v.splat      v3, s10
    v.movi       v4, #0
    v.movi       v6, #2560
    s.add        s14, s5, s12
    v.add        v7, v3, v0
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v3, [s13, #0]
    s.movz       s12, #2560
    v.cmp.ge     p1, v1, v4
    vf.cvt.bf16.f32 v4, v5
    v.cmp.lt     p2, v7, v6
    v.splat      v5, s12
    v.movi       v6, #0
    s.add        s12, s10, s9
    v.cmp.lt     p3, v1, v5
    p.and        p5, p1, p3
    s.movz       s13, #1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v1, [s11, #0]
    vf.cvt.bf16.f32 v5, v3
    vf.add       v3, v4, v5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v4, [s14, #0]
    vf.cvt.bf16.f32 v5, v1
    vf.add       v1, v3, v5
    vf.cvt.bf16.f32 v3, v4
    vf.add       v4, v1, v3
    vf.mul       v1, v4, v4
    vf.add       v3, v2, v1
    @p2 v.sel        v1, v3, v2
    v.mov        v6, v1
    v.mov        v2, v6
    s.mov        s10, s12
    br.nz        s13, for_1
endfor_2:
    vf.reduce.add.b v1, v2
    v.movi       v2, #0
    s.addi       s10, s1, #0
    vf.add       v3, v1, v2
for_3:
    s.cmp.ge     s1, s10, s8
    br.nz        s1, endfor_4
    v.splat      v1, s10
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v4, s10
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s1, #2560
    s.movz       s11, #2560
    s.muli       s12, s10, #2
    s.muli       s13, s10, #2
    v.add        v6, v1, v2
    v.movi       v1, #0
    v.splat      v2, s1
    v.add        v7, v4, v5
    v.movi       v4, #0
    v.splat      v5, s11
    v.splat      v8, s10
    v.iota       v9                              // arange(0, VLEN)
    v.cmp.ge     p1, v6, v1
    v.cmp.lt     p2, v6, v2
    v.cmp.ge     p3, v7, v4
    v.cmp.lt     p4, v7, v5
    s.movz       s1, #2560
    s.add        s11, s2, s12
    p.and        p5, p1, p2
    s.add        s12, s3, s13
    p.and        p1, p3, p4
    s.muli       s13, s10, #2
    v.add        v1, v8, v9
    v.movi       v2, #0
    v.splat      v4, s1
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v5, [s11, #0]
    v.splat      v6, s10
    v.iota       v7                              // arange(0, VLEN)
    v.cmp.ge     p2, v1, v2
    v.cmp.lt     p3, v1, v4
    s.add        s1, s4, s13
    p.and        p4, p2, p3
    s.muli       s11, s10, #2
    v.add        v1, v6, v7
    v.splat      v2, s10
    v.movi       v4, #0
    v.movi       v6, #2560
    s.add        s13, s5, s11
    v.add        v7, v2, v0
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v2, [s12, #0]
    s.movz       s11, #2560
    v.cmp.ge     p1, v1, v4
    v.cmp.lt     p2, v7, v6
    .li       s12, #1159725056
    v.splat      v4, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v6, s11
    s.shli       s11, s10, #1                    // element offset -> bytes (x2)
    vf.cvt.bf16.f32 v7, v5
    v.rcp.approx v5, v4                          // ISA 8.8: <= 2**-22 relative
    .li       s12, #1065353216
    v.splat      v8, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.lt     p3, v1, v6
    p.and        p5, p1, p3
    s.add        s12, s6, s11                    // &in_ptr4[...]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v1, [s1, #0]
    vf.cvt.bf16.f32 v6, v2
    .li       s1, #897988541
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1077936128
    v.splat      v9, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #3204448256
    v.splat      v10, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v11, v7, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v6, [s13, #0]
    vf.cvt.bf16.f32 v7, v1
    s.add        s1, s7, s11                     // &out_ptr1[...]
    s.add        s11, s10, s9
    s.movz       s13, #1
    vf.add       v1, v11, v7
    .li       s14, #1065353216
    v.splat      v7, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v11, v4, v5, v8
    vf.fms       v8, v5, v11, v5
    vf.cvt.bf16.f32 v11, v6
    vf.neg       v6, v8                          // Newton step: r0*(2 - x*r0)
    vf.add       v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s12, #0]
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v11, v6, v5
    vf.mul       v5, v3, v11                     // a/y: faithful quotient
    vf.fms       v6, v5, v4, v3
    vf.cvt.bf16.f32 v4, v1
    vf.fms       v1, v6, v11, v5
    vf.add       v6, v4, v7
    vf.neg       v4, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v1, v4, v5
    vf.add       v4, v1, v2
    v.rsqrt.approx v1, v4                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v2, v1, v1
    vf.mul       v5, v1, v10
    vf.fms       v7, v4, v2, v9
    vf.mul       v2, v5, v7                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v4, v2, v1
    v.extract    s12, v4, #0
    v.splat      v1, s12
    vf.mul       v2, v8, v1
    vf.mul       v1, v2, v6
    vf.cvt.f32.bf16 v2, v1
    @p2 v.st.h       [s1, #0], v2
    s.mov        s10, s11
    br.nz        s13, for_3
endfor_4:
    exit
    exit
