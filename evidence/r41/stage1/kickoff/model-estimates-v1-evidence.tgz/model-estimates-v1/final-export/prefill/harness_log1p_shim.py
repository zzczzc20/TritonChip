import triton
import triton.language as tl


@triton.jit
def log1p(x):
    # Goldberg's form: exact where 1 + x rounds to 1, log(u) * x / (u - 1) elsewhere.
    u = 1.0 + x
    return tl.where(u == 1.0, x, tl.log(u) * (x / (u - 1.0)))
