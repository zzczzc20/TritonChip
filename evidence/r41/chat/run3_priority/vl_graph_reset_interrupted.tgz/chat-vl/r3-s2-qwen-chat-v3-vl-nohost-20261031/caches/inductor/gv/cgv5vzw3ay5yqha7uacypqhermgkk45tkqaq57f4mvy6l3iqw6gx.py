# AOT ID: ['13_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /home/zzhouch/r41run3/chat_nohost_v2_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-20261031/caches/inductor/af/caf74rvaelclzeihzhe2bcgrknxtvr2w3ujpbjnzbrzcji7xv2hn.py
# Topologically Sorted Source Nodes: [position_ids, position_ids_1, getitem_6, float_1, freqs, sin_1, getitem_8, cos_1, getitem_11], Original ATen: [aten.slice, aten.expand, aten.unsqueeze, aten._to_copy, aten.mul, aten.select]
# Source node to ATen node mapping:
#   cos_1 => cos
#   float_1 => convert_element_type
#   freqs => mul
#   getitem_11 => select_13, slice_10
#   getitem_6 => unsqueeze_6
#   getitem_8 => select_1, slice_2
#   position_ids => slice_1
#   position_ids_1 => expand_1
#   sin_1 => sin
# Graph fragment:
#   %arg2_1 : Tensor "i64[4, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %arg4_1 : Tensor "f32[64][1]tnca:0" = PlaceHolder[target=arg4_1]
#   %slice_1 : Tensor "i64[3, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%arg2_1, 0, 1, 9223372036854775807), kwargs = {})
#   %expand_1 : Tensor "i64[3, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%slice_1, [3, -1, -1]), kwargs = {})
#   %unsqueeze_6 : Tensor "i64[3, 1, 1, 1][1, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%expand_1, 3), kwargs = {})
#   %convert_element_type : Tensor "f32[3, 1, 1, 1][1, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_6, torch.float32), kwargs = {})
#   %mul : Tensor "f32[3, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, %arg4_1), kwargs = {})
#   %sin : Tensor "f32[3, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=5] = call_function[target=torch.ops.aten.sin.default](args = (%mul,), kwargs = {})
#   %select_1 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%sin, 0, 1), kwargs = {})
#   %slice_2 : Tensor "f32[1, 1, 20][64, 64, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_1, 2, 1, 60, 3), kwargs = {})
#   %select_int : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%sin, 0, 0), kwargs = {})
#   %slice_scatter_default : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int, %slice_2, 2, 1, 60, 3), kwargs = {})
#   %select_scatter_default : Tensor "f32[3, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=5] = call_function[target=torch.ops.aten.select_scatter.default](args = (%sin, %slice_scatter_default, 0, 0), kwargs = {})
#   %cos : Tensor "f32[3, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=5] = call_function[target=torch.ops.aten.cos.default](args = (%mul,), kwargs = {})
#   %select_13 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%cos, 0, 1), kwargs = {})
#   %slice_10 : Tensor "f32[1, 1, 20][64, 64, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_13, 2, 1, 60, 3), kwargs = {})
#   %select_int_1 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%cos, 0, 0), kwargs = {})
#   %slice_scatter_default_1 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_1, %slice_10, 2, 1, 60, 3), kwargs = {})
#   %select_scatter_default_1 : Tensor "f32[3, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=5] = call_function[target=torch.ops.aten.select_scatter.default](args = (%cos, %slice_scatter_default_1, 0, 0), kwargs = {})
#   return %select_scatter_default,%select_scatter_default_1
triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_0 = async_compile.triton('triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 256}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 3352}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_0(in_ptr0, in_ptr1, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 192
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x1 = xindex // 64
    x0 = (xindex % 64)
    x2 = xindex
    tmp24 = tl.load(in_ptr0 + (1))
    tmp25 = tl.broadcast_to(tmp24, [XBLOCK])
    tmp27 = tl.load(in_ptr1 + (x0), xmask, eviction_policy='evict_last')
    tmp31 = tl.load(in_ptr0 + (1 + x1), xmask, eviction_policy='evict_last')
    tmp0 = (x1).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int32)
    tmp2 = tmp0 == tmp1
    tmp3 = (x0).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1], 1, tl.int64)
    tmp6 = tmp4 >= tmp5
    tmp7 = tl.full([1], 60, tl.int64)
    tmp8 = tmp4 < tmp7
    tmp9 = ((((-1) + x0) % 3)).to(tl.int64)
    tmp10 = (tmp9).to(tl.int64)
    tmp11 = tl.full([1], 0, tl.int64)
    tmp12 = tmp10 == tmp11
    tmp13 = tmp6 & tmp8
    tmp14 = tmp13 & tmp12
    tmp15 = tl.load(in_ptr0 + (2))
    tmp16 = tl.broadcast_to(tmp15, [XBLOCK])
    tmp17 = tl.where(tmp14, tmp16, 0)
    tmp18 = tmp17.to(tl.float32)
    tmp19 = tl.load(in_ptr1 + (1 + 3*(triton_helpers.div_floor_integer((-1) + x0,  3))), tmp14 & xmask, eviction_policy='evict_last', other=0.0)
    tmp20 = tmp18 * tmp19
    tmp21 = tl_math.sin(tmp20)
    tmp22 = tl.full(tmp21.shape, 0.0, tmp21.dtype)
    tmp23 = tl.where(tmp14, tmp21, tmp22)
    tmp26 = tmp25.to(tl.float32)
    tmp28 = tmp26 * tmp27
    tmp29 = tl_math.sin(tmp28)
    tmp30 = tl.where(tmp14, tmp23, tmp29)
    tmp32 = tmp31.to(tl.float32)
    tmp33 = tmp32 * tmp27
    tmp34 = tl_math.sin(tmp33)
    tmp35 = tl.where(tmp2, tmp30, tmp34)
    tmp36 = tl_math.cos(tmp20)
    tmp37 = tl.full(tmp36.shape, 0.0, tmp36.dtype)
    tmp38 = tl.where(tmp14, tmp36, tmp37)
    tmp39 = tl_math.cos(tmp28)
    tmp40 = tl.where(tmp14, tmp38, tmp39)
    tmp41 = tl_math.cos(tmp33)
    tmp42 = tl.where(tmp2, tmp40, tmp41)
    tl.store(out_ptr0 + (x2), tmp35, xmask)
    tl.store(out_ptr1 + (x2), tmp42, xmask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v2_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-20261031/caches/inductor/7x/c7xrx6tc4gyggpuisac3x66ezfmmgl4bccses7uxdhkxrvnnypft.py
# Topologically Sorted Source Nodes: [inputs_embeds, hidden_states, pow_1, variance, add_2, rsqrt, hidden_states_1, to_5, hidden_states_2, output, output_1, output_2], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_2 => add_2
#   hidden_states => convert_element_type_3
#   hidden_states_1 => mul_3
#   hidden_states_2 => mul_4
#   inputs_embeds => embedding
#   output => triton_kernel_wrapper_mutation_195
#   output_1 => triton_kernel_wrapper_mutation_194
#   output_2 => triton_kernel_wrapper_mutation_193
#   pow_1 => pow_1
#   rsqrt => rsqrt
#   to_5 => convert_element_type_4
#   variance => mean
# Graph fragment:
#   %arg0_1 : Tensor "i64[1, 1][1, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %arg1_1 : Tensor "bf16[151936, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg5_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg5_1]
#   %buf2 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf2]
#   %embedding : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg1_1, %arg0_1), kwargs = {})
#   %convert_element_type_3 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%embedding, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_3, 2), kwargs = {})
#   %mean : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [-1], True), kwargs = {})
#   %add_2 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean, 1e-06), kwargs = {})
#   %rsqrt : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_2,), kwargs = {})
#   %mul_3 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_3, %rsqrt), kwargs = {})
#   %convert_element_type_4 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_3, torch.bfloat16), kwargs = {})
#   %mul_4 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg5_1, %convert_element_type_4), kwargs = {})
#   %triton_kernel_wrapper_mutation_195 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 392, grid: [(1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1)], tma_descriptor_metadata: {}, kwargs: {A: %mul_4, B: %arg6_1, C: %empty, Bs: %arg7_1, M: 1, N: 2048, K: 2048, stride_am: 2048, stride_ak: 1, stride_bk: 1, stride_bn: 2048, stride_cm: 2048, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 16, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   %triton_kernel_wrapper_mutation_194 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 393, grid: [(1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1)], tma_descriptor_metadata: {}, kwargs: {A: %mul_4, B: %arg9_1, C: %empty_1, Bs: %arg10_1, M: 1, N: 1024, K: 2048, stride_am: 2048, stride_ak: 1, stride_bk: 1, stride_bn: 2048, stride_cm: 1024, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 16, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   %triton_kernel_wrapper_mutation_193 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 394, grid: [(1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1)], tma_descriptor_metadata: {}, kwargs: {A: %mul_4, B: %arg12_1, C: %empty_2, Bs: %arg13_1, M: 1, N: 1024, K: 2048, stride_am: 2048, stride_ak: 1, stride_bk: 1, stride_bn: 2048, stride_cm: 1024, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 16, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   return %buf2,%buf4,%buf7,%buf10
triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_1 = async_compile.triton('triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'out_ptr1': '*bf16', 'out_ptr2': '*bf16', 'out_ptr3': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 3, 'num_store': 3, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 28672}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_1(in_ptr0, in_ptr1, in_ptr2, out_ptr1, out_ptr2, out_ptr3, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
    _tmp7 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tl.device_assert((0 <= tmp1) & (tmp1 < 151936), "index out of bounds: 0 <= tmp1 < 151936")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 2048*tmp1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp4 = tmp3.to(tl.float32)
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask, tmp8, _tmp7)
    tmp7 = triton_helpers.promote_to_tensor(tl.sum(_tmp7, 0))
    tmp10 = tl.load(in_ptr0 + (0))
    tmp11 = tl.broadcast_to(tmp10, [R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp9 = tl.load(in_ptr2 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp11) & (tmp11 < 151936), "index out of bounds: 0 <= tmp11 < 151936")
        tmp13 = tl.load(in_ptr1 + (r0_0 + 2048*tmp11), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp14 = tmp13.to(tl.float32)
        tmp15 = tl.full([1], 2048.0, tl.float32)
        tmp16 = (tmp7 / tmp15)
        tmp17 = tl.full([1], 1e-06, tl.float32)
        tmp18 = tmp16 + tmp17
        tmp19 = libdevice.rsqrt(tmp18)
        tmp20 = tmp14 * tmp19
        tmp21 = tmp20.to(tl.float32)
        tmp22 = tmp9 * tmp21
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp22, r0_mask)
        tl.store(out_ptr2 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp22, r0_mask)
        tl.store(out_ptr3 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp22, r0_mask)
''', device_str='tnca')


# Original path: /home/zzhouch/r41s2_fp8_inputs/hf/hub/kernels--kernels-community--finegrained-fp8/snapshots/0e5764aa5c27d0f005117a92645156481540950a/build/torch-cuda/matmul.py:96
w8a8_block_dynamic_fp8_matmul_kernel_0 = async_compile.triton('w8a8_block_dynamic_fp8_matmul_kernel', '''

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 2, 'num_stages': 2}, {'num_warps': 2, 'num_stages': 3}, {'num_warps': 2, 'num_stages': 4}, {'num_warps': 4, 'num_stages': 2}, {'num_warps': 4, 'num_stages': 3}, {'num_warps': 4, 'num_stages': 4}, {'num_warps': 8, 'num_stages': 2}, {'num_warps': 8, 'num_stages': 3}, {'num_warps': 8, 'num_stages': 4}, {'num_warps': 16, 'num_stages': 2}, {'num_warps': 16, 'num_stages': 3}, {'num_warps': 16, 'num_stages': 4}],
    inductor_meta={'grid_type': 'PrecomputedGrid', 'precomputed_grids': [{'config': {'num_warps': 2, 'num_stages': 2}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 2, 'num_stages': 3}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 2, 'num_stages': 4}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 4, 'num_stages': 2}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 4, 'num_stages': 3}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 4, 'num_stages': 4}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 8, 'num_stages': 2}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 8, 'num_stages': 3}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 8, 'num_stages': 4}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 16, 'num_stages': 2}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 16, 'num_stages': 3}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 16, 'num_stages': 4}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}], 'extra_launcher_args': [], 'declared_constexpr_names': ['BLOCK_SIZE_M', 'BLOCK_SIZE_N', 'BLOCK_SIZE_K', 'GROUP_SIZE_M'], 'kernel_name': 'w8a8_block_dynamic_fp8_matmul_kernel_0', 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    triton_meta={'signature': {'A': '*bf16', 'B': '*fp8e4nv', 'C': '*bf16', 'Bs': '*fp32', 'M': 'constexpr', 'N': 'i32', 'K': 'i32', 'stride_am': 'i32', 'stride_ak': 'constexpr', 'stride_bk': 'constexpr', 'stride_bn': 'i32', 'stride_cm': 'i32', 'stride_cn': 'constexpr', 'stride_bs_k': 'constexpr', 'stride_bs_n': 'i32', 'BLOCK_SIZE_M': 'constexpr', 'BLOCK_SIZE_N': 'constexpr', 'BLOCK_SIZE_K': 'constexpr', 'GROUP_SIZE_M': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'M': 1, 'stride_ak': 1, 'stride_bk': 1, 'stride_cn': 1, 'stride_bs_k': 1, 'BLOCK_SIZE_M': 16, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'GROUP_SIZE_M': 8}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (10,): [['tt.divisibility', 16]], (11,): [['tt.divisibility', 16]], (14,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def w8a8_block_dynamic_fp8_matmul_kernel(
    A,  # (M, K) raw BF16/FP16 activations
    B,  # (N, K) FP8 weights
    C,  # (M, N) output
    Bs,  # (N // BLOCK_SIZE_N, K // BLOCK_SIZE_K) weight scales (fp32 or uint8/UE8M0)
    # Shape
    M,
    N,
    K,
    # Strides
    stride_am,
    stride_ak,
    stride_bk,
    stride_bn,
    stride_cm,
    stride_cn,
    stride_bs_k,
    stride_bs_n,
    # Meta-parameters
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """Block-scale FP8 GEMM kernel with fused activation quantization.

    Computes ``C = A @ B.T`` with bf16/fp16 ``A`` quantized to FP8 per-K-tile
    inline (one scale per M-row per BLOCK_SIZE_K) and pre-quantized FP8 weights
    with per-block scales. 2D grid with swizzle for L2 cache locality on B.
    """
    pid_m, pid_n, offs_am, offs_bn, offs_k = _swizzle_offsets(
        M, N, BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M
    )
    a_ptrs = A + (offs_am[:, None] * stride_am + offs_k[None, :] * stride_ak)
    b_ptrs = B + (offs_k[:, None] * stride_bk + offs_bn[None, :] * stride_bn)

    offs_bsn = offs_bn // BLOCK_SIZE_N
    bs_ptrs = Bs + offs_bsn * stride_bs_n

    accumulator = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    for k in range(0, tl.cdiv(K, BLOCK_SIZE_K)):
        k_remaining = K - k * BLOCK_SIZE_K
        a_raw = tl.load(a_ptrs, mask=offs_k[None, :] < k_remaining, other=0.0).to(
            tl.float32
        )
        a, a_s = fp8_act_quant_inline(a_raw)
        b = tl.load(b_ptrs, mask=offs_k[:, None] < k_remaining, other=0.0)
        b_s = decode_ue8m0_scale(tl.load(bs_ptrs))
        accumulator += tl.dot(a, b) * a_s[:, None] * b_s[None, :]
        a_ptrs += BLOCK_SIZE_K * stride_ak
        b_ptrs += BLOCK_SIZE_K * stride_bk
        bs_ptrs += stride_bs_k

    _store_masked(
        C,
        accumulator,
        pid_m,
        pid_n,
        M,
        N,
        stride_cm,
        stride_cn,
        BLOCK_SIZE_M,
        BLOCK_SIZE_N,
    )

@triton.jit
def _swizzle_offsets(
    M,
    N,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """2D-grid tile scheduling shared by the kernels below: swizzle the
    ``(pid_m, pid_n)`` program ids for L2 locality on B, then build the operand
    offset vectors. Returns ``(pid_m, pid_n, offs_am, offs_bn, offs_k)`` — the
    swizzled ids (reused by the output store) and the ``%``-wrapped row/col offsets
    plus the K range."""
    pid_m = tl.program_id(axis=0)
    pid_n = tl.program_id(axis=1)
    num_pid_m = tl.cdiv(M, BLOCK_SIZE_M)
    num_pid_n = tl.cdiv(N, BLOCK_SIZE_N)
    pid_m, pid_n = tl.swizzle2d(pid_m, pid_n, num_pid_m, num_pid_n, GROUP_SIZE_M)
    offs_am = (pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)) % M
    offs_bn = (pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)) % N
    offs_k = tl.arange(0, BLOCK_SIZE_K)
    return pid_m, pid_n, offs_am, offs_bn, offs_k

@triton.jit
def fp8_act_quant_inline(a_raw):
    """Inline FP8 (E4M3) activation quant for the W8A8 block-scale path.

    Per-row amax → fp32 scale ``amax/448`` (floored at 1e-12 against zero rows)
    → cast values to FP8. Returns ``(a_fp8, a_s)`` with shapes ``(M, K)`` and
    ``(M,)``.
    """
    a_s = tl.max(tl.abs(a_raw), axis=1) / 448.0
    a_fp8 = (a_raw / tl.maximum(a_s[:, None], 1e-12)).to(tl.float8e4nv)
    return a_fp8, a_s

@triton.jit
def decode_ue8m0_scale(scale):
    """Decode a UE8M0 weight scale to fp32: when it was loaded as ``uint8`` exponent
    bits, ``value = 2^(exp - 127)``, built directly as the fp32 bit pattern. fp32
    scales (block-dynamic with float scales) pass through. The dtype branch is a
    compile-time constant, so only the taken path is emitted (single return — Triton
    requires all ``return`` statements to share a type)."""
    if scale.dtype == tl.uint8:
        scale = (scale.to(tl.int32) << 23).to(tl.float32, bitcast=True)
    return scale

@triton.jit
def _store_masked(
    C,
    accumulator,
    pid_m,
    pid_n,
    M,
    N,
    stride_cm,
    stride_cn,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
):
    """Shared output epilogue of the kernels below: cast the fp32 accumulator to
    ``C``'s dtype and store the ``(BLOCK_SIZE_M, BLOCK_SIZE_N)`` tile at the swizzled
    ``(pid_m, pid_n)``, masked to the ``(M, N)`` bounds."""
    c = accumulator.to(C.dtype.element_ty)
    offs_cm = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_cn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    c_ptrs = C + stride_cm * offs_cm[:, None] + stride_cn * offs_cn[None, :]
    c_mask = (offs_cm[:, None] < M) & (offs_cn[None, :] < N)
    tl.store(c_ptrs, c, mask=c_mask)
''', device_str='tnca')


# Original path: /home/zzhouch/r41s2_fp8_inputs/hf/hub/kernels--kernels-community--finegrained-fp8/snapshots/0e5764aa5c27d0f005117a92645156481540950a/build/torch-cuda/matmul.py:96
w8a8_block_dynamic_fp8_matmul_kernel_1 = async_compile.triton('w8a8_block_dynamic_fp8_matmul_kernel', '''

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 2, 'num_stages': 2}, {'num_warps': 2, 'num_stages': 3}, {'num_warps': 2, 'num_stages': 4}, {'num_warps': 4, 'num_stages': 2}, {'num_warps': 4, 'num_stages': 3}, {'num_warps': 4, 'num_stages': 4}, {'num_warps': 8, 'num_stages': 2}, {'num_warps': 8, 'num_stages': 3}, {'num_warps': 8, 'num_stages': 4}, {'num_warps': 16, 'num_stages': 2}, {'num_warps': 16, 'num_stages': 3}, {'num_warps': 16, 'num_stages': 4}],
    inductor_meta={'grid_type': 'PrecomputedGrid', 'precomputed_grids': [{'config': {'num_warps': 2, 'num_stages': 2}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 2, 'num_stages': 3}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 2, 'num_stages': 4}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 4, 'num_stages': 2}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 4, 'num_stages': 3}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 4, 'num_stages': 4}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 8, 'num_stages': 2}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 8, 'num_stages': 3}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 8, 'num_stages': 4}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 16, 'num_stages': 2}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 16, 'num_stages': 3}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 16, 'num_stages': 4}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}], 'extra_launcher_args': [], 'declared_constexpr_names': ['BLOCK_SIZE_M', 'BLOCK_SIZE_N', 'BLOCK_SIZE_K', 'GROUP_SIZE_M'], 'kernel_name': 'w8a8_block_dynamic_fp8_matmul_kernel_1', 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    triton_meta={'signature': {'A': '*bf16', 'B': '*fp8e4nv', 'C': '*bf16', 'Bs': '*fp32', 'M': 'constexpr', 'N': 'i32', 'K': 'i32', 'stride_am': 'i32', 'stride_ak': 'constexpr', 'stride_bk': 'constexpr', 'stride_bn': 'i32', 'stride_cm': 'i32', 'stride_cn': 'constexpr', 'stride_bs_k': 'constexpr', 'stride_bs_n': 'i32', 'BLOCK_SIZE_M': 'constexpr', 'BLOCK_SIZE_N': 'constexpr', 'BLOCK_SIZE_K': 'constexpr', 'GROUP_SIZE_M': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'M': 1, 'stride_ak': 1, 'stride_bk': 1, 'stride_cn': 1, 'stride_bs_k': 1, 'BLOCK_SIZE_M': 16, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'GROUP_SIZE_M': 8}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (10,): [['tt.divisibility', 16]], (11,): [['tt.divisibility', 16]], (14,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def w8a8_block_dynamic_fp8_matmul_kernel(
    A,  # (M, K) raw BF16/FP16 activations
    B,  # (N, K) FP8 weights
    C,  # (M, N) output
    Bs,  # (N // BLOCK_SIZE_N, K // BLOCK_SIZE_K) weight scales (fp32 or uint8/UE8M0)
    # Shape
    M,
    N,
    K,
    # Strides
    stride_am,
    stride_ak,
    stride_bk,
    stride_bn,
    stride_cm,
    stride_cn,
    stride_bs_k,
    stride_bs_n,
    # Meta-parameters
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """Block-scale FP8 GEMM kernel with fused activation quantization.

    Computes ``C = A @ B.T`` with bf16/fp16 ``A`` quantized to FP8 per-K-tile
    inline (one scale per M-row per BLOCK_SIZE_K) and pre-quantized FP8 weights
    with per-block scales. 2D grid with swizzle for L2 cache locality on B.
    """
    pid_m, pid_n, offs_am, offs_bn, offs_k = _swizzle_offsets(
        M, N, BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M
    )
    a_ptrs = A + (offs_am[:, None] * stride_am + offs_k[None, :] * stride_ak)
    b_ptrs = B + (offs_k[:, None] * stride_bk + offs_bn[None, :] * stride_bn)

    offs_bsn = offs_bn // BLOCK_SIZE_N
    bs_ptrs = Bs + offs_bsn * stride_bs_n

    accumulator = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    for k in range(0, tl.cdiv(K, BLOCK_SIZE_K)):
        k_remaining = K - k * BLOCK_SIZE_K
        a_raw = tl.load(a_ptrs, mask=offs_k[None, :] < k_remaining, other=0.0).to(
            tl.float32
        )
        a, a_s = fp8_act_quant_inline(a_raw)
        b = tl.load(b_ptrs, mask=offs_k[:, None] < k_remaining, other=0.0)
        b_s = decode_ue8m0_scale(tl.load(bs_ptrs))
        accumulator += tl.dot(a, b) * a_s[:, None] * b_s[None, :]
        a_ptrs += BLOCK_SIZE_K * stride_ak
        b_ptrs += BLOCK_SIZE_K * stride_bk
        bs_ptrs += stride_bs_k

    _store_masked(
        C,
        accumulator,
        pid_m,
        pid_n,
        M,
        N,
        stride_cm,
        stride_cn,
        BLOCK_SIZE_M,
        BLOCK_SIZE_N,
    )

@triton.jit
def _swizzle_offsets(
    M,
    N,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """2D-grid tile scheduling shared by the kernels below: swizzle the
    ``(pid_m, pid_n)`` program ids for L2 locality on B, then build the operand
    offset vectors. Returns ``(pid_m, pid_n, offs_am, offs_bn, offs_k)`` — the
    swizzled ids (reused by the output store) and the ``%``-wrapped row/col offsets
    plus the K range."""
    pid_m = tl.program_id(axis=0)
    pid_n = tl.program_id(axis=1)
    num_pid_m = tl.cdiv(M, BLOCK_SIZE_M)
    num_pid_n = tl.cdiv(N, BLOCK_SIZE_N)
    pid_m, pid_n = tl.swizzle2d(pid_m, pid_n, num_pid_m, num_pid_n, GROUP_SIZE_M)
    offs_am = (pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)) % M
    offs_bn = (pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)) % N
    offs_k = tl.arange(0, BLOCK_SIZE_K)
    return pid_m, pid_n, offs_am, offs_bn, offs_k

@triton.jit
def fp8_act_quant_inline(a_raw):
    """Inline FP8 (E4M3) activation quant for the W8A8 block-scale path.

    Per-row amax → fp32 scale ``amax/448`` (floored at 1e-12 against zero rows)
    → cast values to FP8. Returns ``(a_fp8, a_s)`` with shapes ``(M, K)`` and
    ``(M,)``.
    """
    a_s = tl.max(tl.abs(a_raw), axis=1) / 448.0
    a_fp8 = (a_raw / tl.maximum(a_s[:, None], 1e-12)).to(tl.float8e4nv)
    return a_fp8, a_s

@triton.jit
def decode_ue8m0_scale(scale):
    """Decode a UE8M0 weight scale to fp32: when it was loaded as ``uint8`` exponent
    bits, ``value = 2^(exp - 127)``, built directly as the fp32 bit pattern. fp32
    scales (block-dynamic with float scales) pass through. The dtype branch is a
    compile-time constant, so only the taken path is emitted (single return — Triton
    requires all ``return`` statements to share a type)."""
    if scale.dtype == tl.uint8:
        scale = (scale.to(tl.int32) << 23).to(tl.float32, bitcast=True)
    return scale

@triton.jit
def _store_masked(
    C,
    accumulator,
    pid_m,
    pid_n,
    M,
    N,
    stride_cm,
    stride_cn,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
):
    """Shared output epilogue of the kernels below: cast the fp32 accumulator to
    ``C``'s dtype and store the ``(BLOCK_SIZE_M, BLOCK_SIZE_N)`` tile at the swizzled
    ``(pid_m, pid_n)``, masked to the ``(M, N)`` bounds."""
    c = accumulator.to(C.dtype.element_ty)
    offs_cm = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_cn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    c_ptrs = C + stride_cm * offs_cm[:, None] + stride_cn * offs_cn[None, :]
    c_mask = (offs_cm[:, None] < M) & (offs_cn[None, :] < N)
    tl.store(c_ptrs, c, mask=c_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v2_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-20261031/caches/inductor/wi/cwiqbknxr65nky6fz7koeocfmphsg4cva5pm5q2ua2cm4s4h7q32.py
# Topologically Sorted Source Nodes: [hidden_states_3, pow_2, variance_1], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
# Source node to ATen node mapping:
#   hidden_states_3 => convert_element_type_5, view_3
#   pow_2 => pow_2
#   variance_1 => mean_1
# Graph fragment:
#   %buf5 : Tensor  = PlaceHolder[target=buf5]
#   %view_3 : Tensor "bf16[1, 1, 16, 128][2048, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%empty, [1, 1, -1, 128]), kwargs = {})
#   %convert_element_type_5 : Tensor "f32[1, 1, 16, 128][2048, 2048, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_3, torch.float32), kwargs = {})
#   %pow_2 : Tensor "f32[1, 1, 16, 128][2048, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_5, 2), kwargs = {})
#   %mean_1 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_2, [-1], True), kwargs = {})
#   return %buf12
triton_red_fused__to_copy_mean_pow_view_2 = async_compile.triton('triton_red_fused__to_copy_mean_pow_view_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_mean_pow_view_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 128, 'r0_': 0}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_mean_pow_view_2(in_ptr0, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 16
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[16, 128], strides=[128, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp4 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp2 = tmp1 * tmp1
        tmp3 = tl.broadcast_to(tmp2, [R0_BLOCK])
        tmp5 = _tmp4 + tmp3
        _tmp4 = tl.where(r0_mask, tmp5, _tmp4)
    tmp4 = triton_helpers.promote_to_tensor(tl.sum(_tmp4, 0))
    tl.store(out_ptr0 + (x0), tmp4, None)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v2_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-20261031/caches/inductor/om/comrgqwr524rmwwxdgxy2px4linhrh4vw5qoy75gnci3jepzpskv.py
# Topologically Sorted Source Nodes: [hidden_states_3, pow_2, variance_1, add_3, rsqrt_1, hidden_states_4, to_7, mul_6, query_states, x2, neg, x1, cat_2], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
# Source node to ATen node mapping:
#   add_3 => add_3
#   cat_2 => cat
#   hidden_states_3 => convert_element_type_5, view_3
#   hidden_states_4 => mul_5
#   mul_6 => mul_6
#   neg => neg
#   pow_2 => pow_2
#   query_states => permute
#   rsqrt_1 => rsqrt_1
#   to_7 => convert_element_type_6
#   variance_1 => mean_1
#   x1 => slice_18
#   x2 => slice_19
# Graph fragment:
#   %arg8_1 : Tensor "bf16[128][1]tnca:0" = PlaceHolder[target=arg8_1]
#   %buf5 : Tensor  = PlaceHolder[target=buf5]
#   %buf12 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 16]tnca:0" = PlaceHolder[target=buf12]
#   %view_3 : Tensor "bf16[1, 1, 16, 128][2048, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%empty, [1, 1, -1, 128]), kwargs = {})
#   %convert_element_type_5 : Tensor "f32[1, 1, 16, 128][2048, 2048, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_3, torch.float32), kwargs = {})
#   %pow_2 : Tensor "f32[1, 1, 16, 128][2048, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_5, 2), kwargs = {})
#   %mean_1 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_2, [-1], True), kwargs = {})
#   %add_3 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_1, 1e-06), kwargs = {})
#   %rsqrt_1 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_3,), kwargs = {})
#   %mul_5 : Tensor "f32[1, 1, 16, 128][2048, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_5, %rsqrt_1), kwargs = {})
#   %convert_element_type_6 : Tensor "bf16[1, 1, 16, 128][2048, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_5, torch.bfloat16), kwargs = {})
#   %mul_6 : Tensor "bf16[1, 1, 16, 128][2048, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg8_1, %convert_element_type_6), kwargs = {})
#   %permute : Tensor "bf16[1, 16, 1, 128][2048, 128, 2048, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%mul_6, [0, 2, 1, 3]), kwargs = {})
#   %slice_19 : Tensor "bf16[1, 16, 1, 64][2048, 128, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute, 3, 64, 9223372036854775807), kwargs = {})
#   %neg : Tensor "bf16[1, 16, 1, 64][1024, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_19,), kwargs = {})
#   %slice_18 : Tensor "bf16[1, 16, 1, 64][2048, 128, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute, 3, 0, 64), kwargs = {})
#   %cat : Tensor "bf16[1, 16, 1, 128][2048, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg, %slice_18], -1), kwargs = {})
#   return %neg,%buf14
triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3 = async_compile.triton('triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1024}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*fp32', 'out_ptr0': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 8512}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1024
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 64)
    x1 = xindex // 64
    tmp0 = tl.load(in_ptr0 + (64 + x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tl.load(in_ptr1 + (64 + x0 + 128*x1), xmask).to(tl.float32)
    tmp3 = tl.load(in_ptr2 + (x1), xmask, eviction_policy='evict_last')
    tmp13 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp14 = tl.load(in_ptr1 + (x0 + 128*x1), xmask).to(tl.float32)
    tmp2 = tmp1.to(tl.float32)
    tmp4 = tl.full([1], 128.0, tl.float32)
    tmp5 = (tmp3 / tmp4)
    tmp6 = tl.full([1], 1e-06, tl.float32)
    tmp7 = tmp5 + tmp6
    tmp8 = libdevice.rsqrt(tmp7)
    tmp9 = tmp2 * tmp8
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tmp0 * tmp10
    tmp12 = -tmp11
    tmp15 = tmp14.to(tl.float32)
    tmp16 = tmp15 * tmp8
    tmp17 = tmp16.to(tl.float32)
    tmp18 = tmp13 * tmp17
    tl.store(out_ptr0 + (x0 + 128*x1), tmp12, xmask)
    tl.store(out_ptr1 + (x0 + 128*x1), tmp18, xmask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v2_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-20261031/caches/inductor/wp/cwpflqyr2dpu3p25immrrkbtkbr733s5zggyoxqtrr5lcy4zyqxc.py
# Topologically Sorted Source Nodes: [hidden_states_5, pow_3, variance_2], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
# Source node to ATen node mapping:
#   hidden_states_5 => convert_element_type_7, view_5
#   pow_3 => pow_3
#   variance_2 => mean_2
# Graph fragment:
#   %buf8 : Tensor  = PlaceHolder[target=buf8]
#   %view_5 : Tensor "bf16[1, 1, 8, 128][1024, 1024, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%empty_1, [1, 1, -1, 128]), kwargs = {})
#   %convert_element_type_7 : Tensor "f32[1, 1, 8, 128][1024, 1024, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_5, torch.float32), kwargs = {})
#   %pow_3 : Tensor "f32[1, 1, 8, 128][1024, 1024, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_7, 2), kwargs = {})
#   %mean_2 : Tensor "f32[1, 1, 8, 1][8, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_3, [-1], True), kwargs = {})
#   return %buf16
triton_red_fused__to_copy_mean_pow_view_4 = async_compile.triton('triton_red_fused__to_copy_mean_pow_view_4', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 8, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_mean_pow_view_4', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 64, 'r0_': 0}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_mean_pow_view_4(in_ptr0, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 8
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[8, 128], strides=[128, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp4 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp2 = tmp1 * tmp1
        tmp3 = tl.broadcast_to(tmp2, [R0_BLOCK])
        tmp5 = _tmp4 + tmp3
        _tmp4 = tl.where(r0_mask, tmp5, _tmp4)
    tmp4 = triton_helpers.promote_to_tensor(tl.sum(_tmp4, 0))
    tl.store(out_ptr0 + (x0), tmp4, None)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v2_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-20261031/caches/inductor/74/c747yl22x7q6zcemjjj6nsv5sqhl46pzrb2oirm4u66ezhwhvqmx.py
# Topologically Sorted Source Nodes: [hidden_states_5, pow_3, variance_2, add_4, rsqrt_2, hidden_states_6, to_9, mul_8, key_states, x2_1, neg_1, x1_1, cat_3], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
# Source node to ATen node mapping:
#   add_4 => add_4
#   cat_3 => cat_1
#   hidden_states_5 => convert_element_type_7, view_5
#   hidden_states_6 => mul_7
#   key_states => permute_1
#   mul_8 => mul_8
#   neg_1 => neg_1
#   pow_3 => pow_3
#   rsqrt_2 => rsqrt_2
#   to_9 => convert_element_type_8
#   variance_2 => mean_2
#   x1_1 => slice_20
#   x2_1 => slice_21
# Graph fragment:
#   %arg11_1 : Tensor "bf16[128][1]tnca:0" = PlaceHolder[target=arg11_1]
#   %buf8 : Tensor  = PlaceHolder[target=buf8]
#   %buf16 : Tensor "f32[1, 1, 8, 1][8, 8, 1, 8]tnca:0" = PlaceHolder[target=buf16]
#   %view_5 : Tensor "bf16[1, 1, 8, 128][1024, 1024, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%empty_1, [1, 1, -1, 128]), kwargs = {})
#   %convert_element_type_7 : Tensor "f32[1, 1, 8, 128][1024, 1024, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_5, torch.float32), kwargs = {})
#   %pow_3 : Tensor "f32[1, 1, 8, 128][1024, 1024, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_7, 2), kwargs = {})
#   %mean_2 : Tensor "f32[1, 1, 8, 1][8, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_3, [-1], True), kwargs = {})
#   %add_4 : Tensor "f32[1, 1, 8, 1][8, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_2, 1e-06), kwargs = {})
#   %rsqrt_2 : Tensor "f32[1, 1, 8, 1][8, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_4,), kwargs = {})
#   %mul_7 : Tensor "f32[1, 1, 8, 128][1024, 1024, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_7, %rsqrt_2), kwargs = {})
#   %convert_element_type_8 : Tensor "bf16[1, 1, 8, 128][1024, 1024, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_7, torch.bfloat16), kwargs = {})
#   %mul_8 : Tensor "bf16[1, 1, 8, 128][1024, 1024, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg11_1, %convert_element_type_8), kwargs = {})
#   %permute_1 : Tensor "bf16[1, 8, 1, 128][1024, 128, 1024, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%mul_8, [0, 2, 1, 3]), kwargs = {})
#   %slice_21 : Tensor "bf16[1, 8, 1, 64][1024, 128, 1024, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_1, 3, 64, 9223372036854775807), kwargs = {})
#   %neg_1 : Tensor "bf16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_21,), kwargs = {})
#   %slice_20 : Tensor "bf16[1, 8, 1, 64][1024, 128, 1024, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_1, 3, 0, 64), kwargs = {})
#   %cat_1 : Tensor "bf16[1, 8, 1, 128][1024, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg_1, %slice_20], -1), kwargs = {})
#   return %neg_1,%buf18
triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5 = async_compile.triton('triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 512}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*fp32', 'out_ptr0': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 4384}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 512
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 64)
    x1 = xindex // 64
    tmp0 = tl.load(in_ptr0 + (64 + x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tl.load(in_ptr1 + (64 + x0 + 128*x1), xmask).to(tl.float32)
    tmp3 = tl.load(in_ptr2 + (x1), xmask, eviction_policy='evict_last')
    tmp13 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp14 = tl.load(in_ptr1 + (x0 + 128*x1), xmask).to(tl.float32)
    tmp2 = tmp1.to(tl.float32)
    tmp4 = tl.full([1], 128.0, tl.float32)
    tmp5 = (tmp3 / tmp4)
    tmp6 = tl.full([1], 1e-06, tl.float32)
    tmp7 = tmp5 + tmp6
    tmp8 = libdevice.rsqrt(tmp7)
    tmp9 = tmp2 * tmp8
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tmp0 * tmp10
    tmp12 = -tmp11
    tmp15 = tmp14.to(tl.float32)
    tmp16 = tmp15 * tmp8
    tmp17 = tmp16.to(tl.float32)
    tmp18 = tmp13 * tmp17
    tl.store(out_ptr0 + (x0 + 128*x1), tmp12, xmask)
    tl.store(out_ptr1 + (x0 + 128*x1), tmp18, xmask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v2_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-20261031/caches/inductor/2k/c2k3numjvqv7anyi7yc4gdqb23a5q7lkxouznr4qwh7pshqtmty7.py
# Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, cos_4, setitem_1, sin_2, sin_3, sin_4, arange_4, cache_position, hidden_states_5, pow_3, variance_2, add_4, rsqrt_2, hidden_states_6, to_9, mul_8, key_states, mul_11, mul_12, k_embed, index_copy_], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
# Source node to ATen node mapping:
#   add_4 => add_4
#   arange_4 => iota_4
#   cache_position => add_7
#   cos_2 => clone_2, expand_3, select_23, unsqueeze_8, view_1
#   cos_3 => convert_element_type_1
#   cos_4 => unsqueeze_9
#   hidden_states_5 => convert_element_type_7, view_5
#   hidden_states_6 => mul_7
#   index_copy_ => index_put
#   k_embed => add_6
#   key_states => permute_1
#   mul_11 => mul_11
#   mul_12 => mul_12
#   mul_8 => mul_8
#   pow_3 => pow_3
#   rsqrt_2 => rsqrt_2
#   setitem_1 => select_8, slice_8
#   setitem_3 => select_20, slice_16
#   sin_2 => clone, expand_2, select_11, unsqueeze_7, view
#   sin_3 => convert_element_type_2
#   sin_4 => unsqueeze_10
#   to_9 => convert_element_type_8
#   variance_2 => mean_2
# Graph fragment:
#   %copy_ : Tensor "i64[][]tnca:0" = PlaceHolder[target=copy_]
#   %arg11_1 : Tensor "bf16[128][1]tnca:0" = PlaceHolder[target=arg11_1]
#   %buf8 : Tensor  = PlaceHolder[target=buf8]
#   %buf16 : Tensor "f32[1, 1, 8, 1][8, 8, 1, 8]tnca:0" = PlaceHolder[target=buf16]
#   %select_scatter_default_1 : Tensor "f32[3, 1, 1, 64][64, 192, 192, 1]tnca:0" = PlaceHolder[target=select_scatter_default_1]
#   %cat_1 : Tensor "bf16[1, 8, 1, 128][1024, 128, 128, 1]tnca:0" = PlaceHolder[target=cat_1]
#   %select_scatter_default : Tensor "f32[3, 1, 1, 64][64, 192, 192, 1]tnca:0" = PlaceHolder[target=select_scatter_default]
#   %index_put : Tensor "bf16[1, 8, 256, 128][262144, 32768, 128, 1]tnca:0" = PlaceHolder[target=index_put]
#   %select_20 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 2), kwargs = {})
#   %slice_16 : Tensor "f32[1, 1, 20][64, 64, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_20, 2, 2, 60, 3), kwargs = {})
#   %select_int_2 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 0), kwargs = {})
#   %slice_scatter_default_2 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_2, %slice_16, 2, 2, 60, 3), kwargs = {})
#   %select_scatter_default_2 : Tensor "f32[3, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default_1, %slice_scatter_default_2, 0, 0), kwargs = {})
#   %select_23 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_2, 0, 0), kwargs = {})
#   %unsqueeze_8 : Tensor "f32[1, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_23, 2), kwargs = {})
#   %expand_3 : Tensor "f32[1, 1, 2, 64][64, 64, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_8, [1, 1, 2, 64]), kwargs = {})
#   %clone_2 : Tensor "f32[1, 1, 2, 64][128, 128, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_1 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_2, [1, 1, 128]), kwargs = {})
#   %convert_element_type_1 : Tensor "bf16[1, 1, 128][128, 128, 1]tnca:0"[num_users=28] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_1, torch.bfloat16), kwargs = {})
#   %unsqueeze_9 : Tensor "bf16[1, 1, 1, 128][128, 128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_1, 1), kwargs = {})
#   %select_8 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 2), kwargs = {})
#   %slice_8 : Tensor "f32[1, 1, 20][64, 64, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_8, 2, 2, 60, 3), kwargs = {})
#   %select_int_3 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 0), kwargs = {})
#   %slice_scatter_default_3 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_3, %slice_8, 2, 2, 60, 3), kwargs = {})
#   %select_scatter_default_3 : Tensor "f32[3, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default, %slice_scatter_default_3, 0, 0), kwargs = {})
#   %select_11 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_3, 0, 0), kwargs = {})
#   %unsqueeze_7 : Tensor "f32[1, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_11, 2), kwargs = {})
#   %expand_2 : Tensor "f32[1, 1, 2, 64][64, 64, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_7, [1, 1, 2, 64]), kwargs = {})
#   %clone : Tensor "f32[1, 1, 2, 64][128, 128, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_2,), kwargs = {memory_format: torch.contiguous_format})
#   %view : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 1, 128]), kwargs = {})
#   %convert_element_type_2 : Tensor "bf16[1, 1, 128][128, 128, 1]tnca:0"[num_users=28] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view, torch.bfloat16), kwargs = {})
#   %unsqueeze_10 : Tensor "bf16[1, 1, 1, 128][128, 128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_2, 1), kwargs = {})
#   %iota_4 : Tensor "i64[1][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (1,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %add_7 : Tensor "i64[1][1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%iota_4, %arg3_1), kwargs = {})
#   %view_5 : Tensor "bf16[1, 1, 8, 128][1024, 1024, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%empty_1, [1, 1, -1, 128]), kwargs = {})
#   %convert_element_type_7 : Tensor "f32[1, 1, 8, 128][1024, 1024, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_5, torch.float32), kwargs = {})
#   %pow_3 : Tensor "f32[1, 1, 8, 128][1024, 1024, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_7, 2), kwargs = {})
#   %mean_2 : Tensor "f32[1, 1, 8, 1][8, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_3, [-1], True), kwargs = {})
#   %add_4 : Tensor "f32[1, 1, 8, 1][8, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_2, 1e-06), kwargs = {})
#   %rsqrt_2 : Tensor "f32[1, 1, 8, 1][8, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_4,), kwargs = {})
#   %mul_7 : Tensor "f32[1, 1, 8, 128][1024, 1024, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_7, %rsqrt_2), kwargs = {})
#   %convert_element_type_8 : Tensor "bf16[1, 1, 8, 128][1024, 1024, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_7, torch.bfloat16), kwargs = {})
#   %mul_8 : Tensor "bf16[1, 1, 8, 128][1024, 1024, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg11_1, %convert_element_type_8), kwargs = {})
#   %permute_1 : Tensor "bf16[1, 8, 1, 128][1024, 128, 1024, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%mul_8, [0, 2, 1, 3]), kwargs = {})
#   %mul_11 : Tensor "bf16[1, 8, 1, 128][1024, 128, 1024, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_1, %unsqueeze_9), kwargs = {})
#   %mul_12 : Tensor "bf16[1, 8, 1, 128][1024, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_1, %unsqueeze_10), kwargs = {})
#   %add_6 : Tensor "bf16[1, 8, 1, 128][1024, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_11, %mul_12), kwargs = {})
#   %index_put : Tensor "bf16[1, 8, 256, 128][262144, 32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.index_put_.default](args = (%arg14_1, [None, None, %add_7], %add_6), kwargs = {})
#   return %buf20
triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6 = async_compile.triton('triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1024}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': '*bf16', 'in_ptr6': '*fp32', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6', 'mutated_arg_names': ['out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 9, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 4384}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1024
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 128)
    x2 = xindex
    x1 = xindex // 128
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK])
    tmp9 = tl.load(in_ptr1 + (x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp10 = tl.load(in_ptr2 + (x2), xmask).to(tl.float32)
    tmp12 = tl.load(in_ptr3 + (x1), xmask, eviction_policy='evict_last')
    tmp35 = tl.load(in_ptr4 + ((x2 % 64)), xmask, eviction_policy='evict_last')
    tmp40 = tl.load(in_ptr5 + (x2), xmask).to(tl.float32)
    tmp42 = tl.load(in_ptr6 + ((x2 % 64)), xmask, eviction_policy='evict_last')
    tmp2 = tl.full([1], 0, tl.int64)
    tmp3 = tmp2 + tmp1
    tmp4 = (tl.full([XBLOCK], 256, tl.int32)).to(tl.int32)
    tmp5 = tmp3 + tmp4
    tmp6 = tmp3 < 0
    tmp7 = tl.where(tmp6, tmp5, tmp3)
    tl.device_assert((0 <= tmp7) & (tmp7 < 256), "index out of bounds: 0 <= tmp7 < 256")
    tmp11 = tmp10.to(tl.float32)
    tmp13 = tl.full([1], 128.0, tl.float32)
    tmp14 = (tmp12 / tmp13)
    tmp15 = tl.full([1], 1e-06, tl.float32)
    tmp16 = tmp14 + tmp15
    tmp17 = libdevice.rsqrt(tmp16)
    tmp18 = tmp11 * tmp17
    tmp19 = tmp18.to(tl.float32)
    tmp20 = tmp9 * tmp19
    tmp21 = tl.full([1], 0, tl.int32)
    tmp22 = tmp21 == tmp21
    tmp23 = ((x2 % 64)).to(tl.int64)
    tmp24 = (tmp23).to(tl.int64)
    tmp25 = tl.full([1], 2, tl.int64)
    tmp26 = tmp24 >= tmp25
    tmp27 = tl.full([1], 60, tl.int64)
    tmp28 = tmp24 < tmp27
    tmp29 = ((((-2) + ((x0 % 64))) % 3)).to(tl.int64)
    tmp30 = (tmp29).to(tl.int64)
    tmp31 = tmp30 == tmp2
    tmp32 = tmp26 & tmp28
    tmp33 = tmp32 & tmp31
    tmp34 = tl.load(in_ptr4 + (130 + 3*(triton_helpers.div_floor_integer((-2) + ((x0 % 64)),  3))), tmp33 & xmask, eviction_policy='evict_last', other=0.0)
    tmp36 = tl.where(tmp33, tmp34, tmp35)
    tmp37 = tl.where(tmp22, tmp36, tmp35)
    tmp38 = tmp37.to(tl.float32)
    tmp39 = tmp20 * tmp38
    tmp41 = tl.load(in_ptr6 + (130 + 3*(triton_helpers.div_floor_integer((-2) + ((x0 % 64)),  3))), tmp33 & xmask, eviction_policy='evict_last', other=0.0)
    tmp43 = tl.where(tmp33, tmp41, tmp42)
    tmp44 = tl.where(tmp22, tmp43, tmp42)
    tmp45 = tmp44.to(tl.float32)
    tmp46 = tmp40 * tmp45
    tmp47 = tmp39 + tmp46
    tl.store(out_ptr0 + (x0 + 128*tmp7 + 32768*x1), tmp47, xmask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v2_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-20261031/caches/inductor/ei/ceizzszxpjdh2dyiwj3iqbqry2ihcd3sd2xdy7jlhvsnu2k423ni.py
# Topologically Sorted Source Nodes: [hidden_states_3, pow_2, variance_1, add_3, rsqrt_1, hidden_states_4, to_7, mul_6, query_states, setitem_3, cos_2, cos_3, cos_4, mul_9, setitem_1, sin_2, sin_3, sin_4, mul_10, q_embed, attn_output, key], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.select, aten.slice, aten.cat, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
# Source node to ATen node mapping:
#   add_3 => add_3
#   attn_output => bmm, convert_element_type_10, convert_element_type_9, mul_13, mul_14, permute_4, view_11, view_12
#   cos_2 => clone_2, expand_3, select_23, unsqueeze_8, view_1
#   cos_3 => convert_element_type_1
#   cos_4 => unsqueeze_9
#   hidden_states_3 => convert_element_type_5, view_3
#   hidden_states_4 => mul_5
#   key => clone_4, expand_5, unsqueeze_13, view_9
#   mul_10 => mul_10
#   mul_6 => mul_6
#   mul_9 => mul_9
#   pow_2 => pow_2
#   q_embed => add_5
#   query_states => permute
#   rsqrt_1 => rsqrt_1
#   setitem_1 => select_8, slice_8
#   setitem_3 => select_20, slice_16
#   sin_2 => clone, expand_2, select_11, unsqueeze_7, view
#   sin_3 => convert_element_type_2
#   sin_4 => unsqueeze_10
#   to_7 => convert_element_type_6
#   variance_1 => mean_1
# Graph fragment:
#   %arg8_1 : Tensor "bf16[128][1]tnca:0" = PlaceHolder[target=arg8_1]
#   %buf5 : Tensor  = PlaceHolder[target=buf5]
#   %buf12 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 16]tnca:0" = PlaceHolder[target=buf12]
#   %select_scatter_default_1 : Tensor "f32[3, 1, 1, 64][64, 192, 192, 1]tnca:0" = PlaceHolder[target=select_scatter_default_1]
#   %cat : Tensor "bf16[1, 16, 1, 128][2048, 128, 128, 1]tnca:0" = PlaceHolder[target=cat]
#   %select_scatter_default : Tensor "f32[3, 1, 1, 64][64, 192, 192, 1]tnca:0" = PlaceHolder[target=select_scatter_default]
#   %buf20 : Tensor "bf16[1, 8, 256, 128][262144, 32768, 128, 1]tnca:0" = PlaceHolder[target=buf20]
#   %view_3 : Tensor "bf16[1, 1, 16, 128][2048, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%empty, [1, 1, -1, 128]), kwargs = {})
#   %convert_element_type_5 : Tensor "f32[1, 1, 16, 128][2048, 2048, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_3, torch.float32), kwargs = {})
#   %pow_2 : Tensor "f32[1, 1, 16, 128][2048, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_5, 2), kwargs = {})
#   %mean_1 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_2, [-1], True), kwargs = {})
#   %add_3 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_1, 1e-06), kwargs = {})
#   %rsqrt_1 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_3,), kwargs = {})
#   %mul_5 : Tensor "f32[1, 1, 16, 128][2048, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_5, %rsqrt_1), kwargs = {})
#   %convert_element_type_6 : Tensor "bf16[1, 1, 16, 128][2048, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_5, torch.bfloat16), kwargs = {})
#   %mul_6 : Tensor "bf16[1, 1, 16, 128][2048, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg8_1, %convert_element_type_6), kwargs = {})
#   %permute : Tensor "bf16[1, 16, 1, 128][2048, 128, 2048, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%mul_6, [0, 2, 1, 3]), kwargs = {})
#   %select_20 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 2), kwargs = {})
#   %slice_16 : Tensor "f32[1, 1, 20][64, 64, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_20, 2, 2, 60, 3), kwargs = {})
#   %select_int_2 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 0), kwargs = {})
#   %slice_scatter_default_2 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_2, %slice_16, 2, 2, 60, 3), kwargs = {})
#   %select_scatter_default_2 : Tensor "f32[3, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default_1, %slice_scatter_default_2, 0, 0), kwargs = {})
#   %select_23 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_2, 0, 0), kwargs = {})
#   %unsqueeze_8 : Tensor "f32[1, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_23, 2), kwargs = {})
#   %expand_3 : Tensor "f32[1, 1, 2, 64][64, 64, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_8, [1, 1, 2, 64]), kwargs = {})
#   %clone_2 : Tensor "f32[1, 1, 2, 64][128, 128, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_1 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_2, [1, 1, 128]), kwargs = {})
#   %convert_element_type_1 : Tensor "bf16[1, 1, 128][128, 128, 1]tnca:0"[num_users=28] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_1, torch.bfloat16), kwargs = {})
#   %unsqueeze_9 : Tensor "bf16[1, 1, 1, 128][128, 128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_1, 1), kwargs = {})
#   %mul_9 : Tensor "bf16[1, 16, 1, 128][2048, 128, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute, %unsqueeze_9), kwargs = {})
#   %select_8 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 2), kwargs = {})
#   %slice_8 : Tensor "f32[1, 1, 20][64, 64, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_8, 2, 2, 60, 3), kwargs = {})
#   %select_int_3 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 0), kwargs = {})
#   %slice_scatter_default_3 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_3, %slice_8, 2, 2, 60, 3), kwargs = {})
#   %select_scatter_default_3 : Tensor "f32[3, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default, %slice_scatter_default_3, 0, 0), kwargs = {})
#   %select_11 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_3, 0, 0), kwargs = {})
#   %unsqueeze_7 : Tensor "f32[1, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_11, 2), kwargs = {})
#   %expand_2 : Tensor "f32[1, 1, 2, 64][64, 64, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_7, [1, 1, 2, 64]), kwargs = {})
#   %clone : Tensor "f32[1, 1, 2, 64][128, 128, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_2,), kwargs = {memory_format: torch.contiguous_format})
#   %view : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 1, 128]), kwargs = {})
#   %convert_element_type_2 : Tensor "bf16[1, 1, 128][128, 128, 1]tnca:0"[num_users=28] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view, torch.bfloat16), kwargs = {})
#   %unsqueeze_10 : Tensor "bf16[1, 1, 1, 128][128, 128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_2, 1), kwargs = {})
#   %mul_10 : Tensor "bf16[1, 16, 1, 128][2048, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat, %unsqueeze_10), kwargs = {})
#   %add_5 : Tensor "bf16[1, 16, 1, 128][2048, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_9, %mul_10), kwargs = {})
#   %convert_element_type_9 : Tensor "f32[1, 16, 1, 128][2048, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_5, torch.float32), kwargs = {})
#   %mul_13 : Tensor "f32[1, 16, 1, 128][2048, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%convert_element_type_9, 0.29730177875068026), kwargs = {})
#   %view_11 : Tensor "f32[16, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_8, [16, 1, 128]), kwargs = {})
#   %unsqueeze_13 : Tensor "bf16[1, 8, 1, 256, 128][262144, 32768, 32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%index_put, 2), kwargs = {})
#   %expand_5 : Tensor "bf16[1, 8, 2, 256, 128][262144, 32768, 0, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_13, [1, 8, 2, 256, 128]), kwargs = {})
#   %clone_4 : Tensor "bf16[1, 8, 2, 256, 128][524288, 65536, 32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_5,), kwargs = {memory_format: torch.contiguous_format})
#   %view_9 : Tensor "bf16[1, 16, 256, 128][524288, 32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_4, [1, 16, 256, 128]), kwargs = {})
#   %convert_element_type_10 : Tensor "f32[1, 16, 256, 128][524288, 32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_9, torch.float32), kwargs = {})
#   %permute_4 : Tensor "f32[1, 16, 128, 256][524288, 32768, 1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_10, [0, 1, 3, 2]), kwargs = {})
#   %mul_14 : Tensor "f32[1, 16, 128, 256][524288, 32768, 1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%permute_4, 0.29730177875068026), kwargs = {})
#   %view_12 : Tensor "f32[16, 128, 256][32768, 1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_9, [16, 128, 256]), kwargs = {})
#   %bmm : Tensor "f32[16, 1, 256][256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_11, %view_12), kwargs = {})
#   return %bmm
triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 4096, 'r0_': 128},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*bf16', 'in_ptr5': '*fp32', 'in_ptr6': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 9, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 32768, 'r0_': 6400}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 4096
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x1 = xindex // 256
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr1, shape=[16, 128], strides=[128, 1], block_shape=[(255 + XBLOCK) // 256, R0_BLOCK])
    tmp3 = tl.load(in_ptr2 + (x1), None, eviction_policy='evict_last')
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr4, shape=[16, 128], strides=[128, 1], block_shape=[(255 + XBLOCK) // 256, R0_BLOCK])
    x0 = (xindex % 256)
    _tmp48 = tl.full([R0_BLOCK], 0, tl.float32)
    x3 = xindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_2), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([xoffset // 256, r0_offset])[:, :, None], [(255 + XBLOCK) // 256, R0_BLOCK, ((256) * ((256) <= (XBLOCK)) + (XBLOCK) * ((XBLOCK) < (256)))]), [0, 2, 1]), [R0_BLOCK]).to(tl.float32)
        tmp27 = tl.load(in_ptr3 + ((r0_2 % 64)), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp32 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([xoffset // 256, r0_offset])[:, :, None, None], [(255 + XBLOCK) // 256, R0_BLOCK, ((1) * ((1) <= ((255 + XBLOCK) // 256)) + ((255 + XBLOCK) // 256) * (((255 + XBLOCK) // 256) < (1))), ((256) * ((256) <= (XBLOCK)) + (XBLOCK) * ((XBLOCK) < (256)))]), [0, 2, 3, 1]), [R0_BLOCK]).to(tl.float32)
        tmp34 = tl.load(in_ptr5 + ((r0_2 % 64)), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp43 = tl.load(in_ptr6 + (r0_2 + 128*x0 + 32768*(x1 // 2)), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp2 = tmp1.to(tl.float32)
        tmp4 = tl.full([1], 128.0, tl.float32)
        tmp5 = (tmp3 / tmp4)
        tmp6 = tl.full([1], 1e-06, tl.float32)
        tmp7 = tmp5 + tmp6
        tmp8 = libdevice.rsqrt(tmp7)
        tmp9 = tmp2 * tmp8
        tmp10 = tmp9.to(tl.float32)
        tmp11 = tmp0 * tmp10
        tmp12 = tl.full([1], 0, tl.int32)
        tmp13 = tmp12 == tmp12
        tmp14 = ((r0_2 % 64)).to(tl.int64)
        tmp15 = (tmp14).to(tl.int64)
        tmp16 = tl.full([1], 2, tl.int64)
        tmp17 = tmp15 >= tmp16
        tmp18 = tl.full([1], 60, tl.int64)
        tmp19 = tmp15 < tmp18
        tmp20 = ((((-2) + ((r0_2 % 64))) % 3)).to(tl.int64)
        tmp21 = (tmp20).to(tl.int64)
        tmp22 = tl.full([1], 0, tl.int64)
        tmp23 = tmp21 == tmp22
        tmp24 = tmp17 & tmp19
        tmp25 = tmp24 & tmp23
        tmp26 = tl.load(in_ptr3 + (tl.broadcast_to(130 + 3*(triton_helpers.div_floor_integer((-2) + ((r0_2 % 64)),  3)), [R0_BLOCK])), r0_mask & tmp25, eviction_policy='evict_last', other=0.0)
        tmp28 = tl.where(tmp25, tmp26, tmp27)
        tmp29 = tl.where(tmp13, tmp28, tmp27)
        tmp30 = tmp29.to(tl.float32)
        tmp31 = tmp11 * tmp30
        tmp33 = tl.load(in_ptr5 + (tl.broadcast_to(130 + 3*(triton_helpers.div_floor_integer((-2) + ((r0_2 % 64)),  3)), [R0_BLOCK])), r0_mask & tmp25, eviction_policy='evict_last', other=0.0)
        tmp35 = tl.where(tmp25, tmp33, tmp34)
        tmp36 = tl.where(tmp13, tmp35, tmp34)
        tmp37 = tmp36.to(tl.float32)
        tmp38 = tmp32 * tmp37
        tmp39 = tmp31 + tmp38
        tmp40 = tmp39.to(tl.float32)
        tmp41 = tl.full([1], 0.29730177875068026, tl.float32)
        tmp42 = tmp40 * tmp41
        tmp44 = tmp43.to(tl.float32)
        tmp45 = tmp44 * tmp41
        tmp46 = tmp42 * tmp45
        tmp47 = tl.broadcast_to(tmp46, [R0_BLOCK])
        tmp49 = _tmp48 + tmp47
        _tmp48 = tl.where(r0_mask, tmp49, _tmp48)
    tmp48 = triton_helpers.promote_to_tensor(tl.sum(_tmp48, 0))
    tl.store(out_ptr0 + (x3), tmp48, None)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v2_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-20261031/caches/inductor/gr/cgrzuv7gms7vhszojs7xe4aq5acdxw3l3msrg4kzo7p4y7bk47lq.py
# Topologically Sorted Source Nodes: [attn_output, kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten.scalar_tensor, aten.where]
# Source node to ATen node mapping:
#   arange_2 => iota_2
#   attention_mask => le
#   attention_mask_1 => expand
#   attn_output => add_9, amax, any_1, eq, exp, full_default, full_default_1, logical_not, sub, sum_1, view_13, where
#   kv_arange => iota_3
#   kv_indices => unsqueeze_3, unsqueeze_4, unsqueeze_5
#   q_arange => add
#   q_indices => unsqueeze, unsqueeze_1, unsqueeze_2
# Graph fragment:
#   %bmm : Tensor "f32[16, 1, 256][256, 256, 1]tnca:0" = PlaceHolder[target=bmm]
#   %copy_ : Tensor "i64[][]tnca:0" = PlaceHolder[target=copy_]
#   %amax : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax]
#   %exp : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp]
#   %view_13 : Tensor "f32[1, 16, 1, 256][4096, 256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm, [1, 16, 1, 256]), kwargs = {})
#   %iota_3 : Tensor "i64[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (256,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %unsqueeze_3 : Tensor "i64[1, 256][256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%iota_3, 0), kwargs = {})
#   %unsqueeze_4 : Tensor "i64[1, 1, 256][256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze_3, 1), kwargs = {})
#   %unsqueeze_5 : Tensor "i64[1, 1, 1, 256][256, 256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze_4, 2), kwargs = {})
#   %iota_2 : Tensor "i64[1][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (1,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %add : Tensor "i64[1][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%iota_2, %arg3_1), kwargs = {})
#   %unsqueeze : Tensor "i64[1, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%add, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "i64[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze, 1), kwargs = {})
#   %unsqueeze_2 : Tensor "i64[1, 1, 1, 1][1, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze_1, 3), kwargs = {})
#   %le : Tensor "b8[1, 1, 1, 256][256, 256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.le.Tensor](args = (%unsqueeze_5, %unsqueeze_2), kwargs = {})
#   %expand : Tensor "b8[1, 1, 1, 256][256, 256, 256, 1]tnca:0"[num_users=28] = call_function[target=torch.ops.aten.expand.default](args = (%le, [1, -1, 1, 256]), kwargs = {})
#   %full_default_1 : Tensor "bf16[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([], 0.0), kwargs = {dtype: torch.bfloat16, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %full_default : Tensor "bf16[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([], -inf), kwargs = {dtype: torch.bfloat16, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %where : Tensor "bf16[1, 1, 1, 256][256, 256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%expand, %full_default_1, %full_default), kwargs = {})
#   %add_9 : Tensor "f32[1, 16, 1, 256][4096, 256, 256, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%view_13, %where), kwargs = {})
#   %eq : Tensor "b8[1, 16, 1, 256][4096, 256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.eq.Scalar](args = (%add_9, -inf), kwargs = {})
#   %logical_not : Tensor "b8[1, 16, 1, 256][4096, 256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%eq,), kwargs = {})
#   %any_1 : Tensor "b8[1, 16, 1, 1][16, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.any.dim](args = (%logical_not, -1, True), kwargs = {})
#   %amax : Tensor "f32[1, 16, 1, 1][16, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.amax.default](args = (%add_9, [-1], True), kwargs = {})
#   %sub : Tensor "f32[1, 16, 1, 256][4096, 256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%add_9, %amax), kwargs = {})
#   %exp : Tensor "f32[1, 16, 1, 256][4096, 256, 256, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.exp.default](args = (%sub,), kwargs = {})
#   %sum_1 : Tensor "f32[1, 16, 1, 1][16, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%exp, [-1], True), kwargs = {})
#   return %any_1,%amax,%exp,%sum_1
triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16, 'r0_': 256},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*i64', 'out_ptr0': '*i1', 'out_ptr2': '*fp32', 'out_ptr3': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 4, 'num_store': 3, 'num_reduction': 3, 'autotune_hints': set(), 'tiling_scores': {'x': 160, 'r0_': 49152}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 4}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8(in_ptr0, in_ptr1, out_ptr0, out_ptr2, out_ptr3, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 16
    XBLOCK: tl.constexpr = 1
    r0_numel = 256
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[16, 256], strides=[256, 1], block_shape=[XBLOCK, R0_BLOCK])
    tmp1 = tl.load(in_ptr1 + (0))
    tmp2 = tl.broadcast_to(tmp1, [R0_BLOCK])
    _tmp18 = tl.full([R0_BLOCK], False, tl.int1)
    _tmp22 = tl.full([R0_BLOCK], float("-inf"), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp3 = tl.full([1], 0, tl.int64)
        tmp4 = tmp3 + tmp2
        tmp5 = (r0_1).to(tl.int64)
        tmp6 = (tmp5).to(tl.int64)
        tmp7 = tmp6 <= tmp4
        tmp8 = tl.full([1], 0.0, tl.float32)
        tmp9 = tl.full([1], float("-inf"), tl.float32)
        tmp10 = tl.where(tmp7, tmp8, tmp9)
        tmp11 = tmp10.to(tl.float32)
        tmp12 = tmp0 + tmp11
        tmp13 = tmp12 == tmp9
        tmp14 = tmp13 == 0
        tmp15 = tmp14.to(tl.int64)
        tmp16 = (tmp15 != 0)
        tmp17 = tl.broadcast_to(tmp16, [R0_BLOCK])
        tmp19 = _tmp18 | tmp17
        _tmp18 = tl.where(r0_mask, tmp19, _tmp18)
        tmp21 = tl.broadcast_to(tmp12, [R0_BLOCK])
        tmp23 = tl.maximum(_tmp22, tmp21, tl.PropagateNan.ALL)
        _tmp22 = tl.where(r0_mask, tmp23, _tmp22)
    tmp20 = _tmp18.to(tl.int8)
    tmp18 = triton_helpers.promote_to_tensor(triton_helpers.any(tmp20, 0))
    tmp22 = triton_helpers.promote_to_tensor(triton_helpers.max2(_tmp22, 0))
    tl.store(out_ptr0 + (x0), tmp18, None)
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[16, 256], strides=[256, 1], block_shape=[XBLOCK, R0_BLOCK])
    tmp25 = tl.load(in_ptr1 + (0))
    tmp26 = tl.broadcast_to(tmp25, [R0_BLOCK])
    _tmp40 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp24 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp27 = tl.full([1], 0, tl.int64)
        tmp28 = tmp27 + tmp26
        tmp29 = (r0_1).to(tl.int64)
        tmp30 = (tmp29).to(tl.int64)
        tmp31 = tmp30 <= tmp28
        tmp32 = tl.full([1], 0.0, tl.float32)
        tmp33 = tl.full([1], float("-inf"), tl.float32)
        tmp34 = tl.where(tmp31, tmp32, tmp33)
        tmp35 = tmp34.to(tl.float32)
        tmp36 = tmp24 + tmp35
        tmp37 = tmp36 - tmp22
        tmp38 = libdevice.exp(tmp37)
        tmp39 = tl.broadcast_to(tmp38, [R0_BLOCK])
        tmp41 = _tmp40 + tmp39
        _tmp40 = tl.where(r0_mask, tmp41, _tmp40)
        tl.store(out_ptr2 + (r0_1 + 256*x0), tmp38, r0_mask)
    tmp40 = triton_helpers.promote_to_tensor(tl.sum(_tmp40, 0))
    tl.store(out_ptr3 + (x0), tmp40, None)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v2_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-20261031/caches/inductor/k4/ck4ebhn2qsqtbvmubupuqaaqg4eqfbqsf7wkrvj3wh2dpotycvkt.py
# Topologically Sorted Source Nodes: [arange_4, cache_position, index_copy__1], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
# Source node to ATen node mapping:
#   arange_4 => iota_4
#   cache_position => add_7
#   index_copy__1 => index_put_1, permute_3, view_8
# Graph fragment:
#   %copy_ : Tensor "i64[][]tnca:0" = PlaceHolder[target=copy_]
#   %buf11 : Tensor  = PlaceHolder[target=buf11]
#   %index_put_1 : Tensor "bf16[1, 8, 256, 128][262144, 32768, 128, 1]tnca:0" = PlaceHolder[target=index_put_1]
#   %iota_4 : Tensor "i64[1][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (1,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %add_7 : Tensor "i64[1][1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%iota_4, %arg3_1), kwargs = {})
#   %view_8 : Tensor "bf16[1, 1, 8, 128][1024, 1024, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%empty_2, [1, 1, -1, 128]), kwargs = {})
#   %permute_3 : Tensor "bf16[1, 8, 1, 128][1024, 128, 1024, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_8, [0, 2, 1, 3]), kwargs = {})
#   %index_put_1 : Tensor "bf16[1, 8, 256, 128][262144, 32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.index_put_.default](args = (%arg15_1, [None, None, %add_7], %permute_3), kwargs = {})
#   return %buf26
triton_poi_fused_add_arange_index_copy_transpose_view_9 = async_compile.triton('triton_poi_fused_add_arange_index_copy_transpose_view_9', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1024}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_add_arange_index_copy_transpose_view_9', 'mutated_arg_names': ['out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 0}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_arange_index_copy_transpose_view_9(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1024
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x2 = xindex
    x0 = (xindex % 128)
    x1 = xindex // 128
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK])
    tmp9 = tl.load(in_ptr1 + (x2), xmask).to(tl.float32)
    tmp2 = tl.full([1], 0, tl.int64)
    tmp3 = tmp2 + tmp1
    tmp4 = (tl.full([XBLOCK], 256, tl.int32)).to(tl.int32)
    tmp5 = tmp3 + tmp4
    tmp6 = tmp3 < 0
    tmp7 = tl.where(tmp6, tmp5, tmp3)
    tl.device_assert((0 <= tmp7) & (tmp7 < 256), "index out of bounds: 0 <= tmp7 < 256")
    tl.store(out_ptr0 + (x0 + 128*tmp7 + 32768*x1), tmp9, xmask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v2_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-20261031/caches/inductor/yj/cyjx4zxcyy45kjymh3lvres3ejcguc4h4zzhbpoifqkmedg7iod3.py
# Topologically Sorted Source Nodes: [attn_output, value, transpose_3, reshape_2, output_3], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.view]
# Source node to ATen node mapping:
#   attn_output => bmm_1, convert_element_type_11, convert_element_type_13, div, full_default_2, logical_not_1, view_14, view_15, view_16, where_1
#   output_3 => triton_kernel_wrapper_mutation_192
#   reshape_2 => view_17
#   transpose_3 => permute_7
#   value => clone_5, expand_7, unsqueeze_16, view_10
# Graph fragment:
#   %any_1 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_1]
#   %exp : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp]
#   %sum_1 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=sum_1]
#   %buf26 : Tensor "bf16[1, 8, 256, 128][262144, 32768, 128, 1]tnca:0" = PlaceHolder[target=buf26]
#   %bmm_1 : Tensor "f32[16, 1, 128][128, 128, 1]tnca:0" = PlaceHolder[target=bmm_1]
#   %logical_not_1 : Tensor "b8[1, 16, 1, 1][16, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%any_1,), kwargs = {})
#   %full_default_2 : Tensor "f32[1, 16, 1, 256][4096, 256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([1, 16, 1, 256], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %div : Tensor "f32[1, 16, 1, 256][4096, 256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp, %sum_1), kwargs = {})
#   %where_1 : Tensor "f32[1, 16, 1, 256][4096, 256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_not_1, %full_default_2, %div), kwargs = {})
#   %view_14 : Tensor "f32[16, 1, 256][256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_10, [16, 1, 256]), kwargs = {})
#   %unsqueeze_16 : Tensor "bf16[1, 8, 1, 256, 128][262144, 32768, 32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%index_put_1, 2), kwargs = {})
#   %expand_7 : Tensor "bf16[1, 8, 2, 256, 128][262144, 32768, 0, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_16, [1, 8, 2, 256, 128]), kwargs = {})
#   %clone_5 : Tensor "bf16[1, 8, 2, 256, 128][524288, 65536, 32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_7,), kwargs = {memory_format: torch.contiguous_format})
#   %view_10 : Tensor "bf16[1, 16, 256, 128][524288, 32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_5, [1, 16, 256, 128]), kwargs = {})
#   %convert_element_type_11 : Tensor "f32[1, 16, 256, 128][524288, 32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_10, torch.float32), kwargs = {})
#   %view_15 : Tensor "f32[16, 256, 128][32768, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_11, [16, 256, 128]), kwargs = {})
#   %bmm_1 : Tensor "f32[16, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_14, %view_15), kwargs = {})
#   %view_16 : Tensor "f32[1, 16, 1, 128][2048, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_1, [1, 16, 1, 128]), kwargs = {})
#   %convert_element_type_13 : Tensor "bf16[1, 16, 1, 128][2048, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_16, torch.bfloat16), kwargs = {})
#   %permute_7 : Tensor "bf16[1, 1, 16, 128][2048, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_13, [0, 2, 1, 3]), kwargs = {})
#   %view_17 : Tensor "bf16[1, 1, 2048][2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%permute_7, [1, 1, -1]), kwargs = {})
#   %triton_kernel_wrapper_mutation_192 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 395, grid: [(1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1)], tma_descriptor_metadata: {}, kwargs: {A: %view_17, B: %arg16_1, C: %empty_3, Bs: %arg17_1, M: 1, N: 2048, K: 2048, stride_am: 128, stride_ak: 1, stride_bk: 1, stride_bn: 2048, stride_cm: 2048, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 16, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   return %bmm_1,%buf29
triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 2048, 'r0_': 256},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i1', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 4, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 8192, 'r0_': 16384}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 4}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 2048
    XBLOCK: tl.constexpr = 1
    r0_numel = 256
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x1 = xindex // 128
    tmp0 = tl.load(in_ptr0 + (x1), None, eviction_policy='evict_last').to(tl.int1)
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr1, shape=[16, 256], strides=[256, 1], block_shape=[(127 + XBLOCK) // 128, R0_BLOCK])
    tmp3 = tl.load(in_ptr2 + (x1), None, eviction_policy='evict_last')
    x0 = (xindex % 128)
    _tmp11 = tl.full([R0_BLOCK], 0, tl.float32)
    x3 = xindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp2 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([xoffset // 128, r0_offset])[:, :, None, None], [(127 + XBLOCK) // 128, R0_BLOCK, ((1) * ((1) <= ((127 + XBLOCK) // 128)) + ((127 + XBLOCK) // 128) * (((127 + XBLOCK) // 128) < (1))), ((128) * ((128) <= (XBLOCK)) + (XBLOCK) * ((XBLOCK) < (128)))]), [0, 2, 3, 1]), [R0_BLOCK])
        tmp7 = tl.load(in_ptr3 + (x0 + 128*r0_2 + 32768*(x1 // 2)), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp1 = tmp0 == 0
        tmp4 = (tmp2 / tmp3)
        tmp5 = tl.full([1], 0.0, tl.float32)
        tmp6 = tl.where(tmp1, tmp5, tmp4)
        tmp8 = tmp7.to(tl.float32)
        tmp9 = tmp6 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask, tmp12, _tmp11)
    tmp11 = triton_helpers.promote_to_tensor(tl.sum(_tmp11, 0))
    tmp13 = tmp11.to(tl.float32)
    tl.store(out_ptr1 + (x3), tmp13, None)
''', device_str='tnca')


# Original path: /home/zzhouch/r41s2_fp8_inputs/hf/hub/kernels--kernels-community--finegrained-fp8/snapshots/0e5764aa5c27d0f005117a92645156481540950a/build/torch-cuda/matmul.py:96
w8a8_block_dynamic_fp8_matmul_kernel_2 = async_compile.triton('w8a8_block_dynamic_fp8_matmul_kernel', '''

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 2, 'num_stages': 2}, {'num_warps': 2, 'num_stages': 3}, {'num_warps': 2, 'num_stages': 4}, {'num_warps': 4, 'num_stages': 2}, {'num_warps': 4, 'num_stages': 3}, {'num_warps': 4, 'num_stages': 4}, {'num_warps': 8, 'num_stages': 2}, {'num_warps': 8, 'num_stages': 3}, {'num_warps': 8, 'num_stages': 4}, {'num_warps': 16, 'num_stages': 2}, {'num_warps': 16, 'num_stages': 3}, {'num_warps': 16, 'num_stages': 4}],
    inductor_meta={'grid_type': 'PrecomputedGrid', 'precomputed_grids': [{'config': {'num_warps': 2, 'num_stages': 2}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 2, 'num_stages': 3}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 2, 'num_stages': 4}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 4, 'num_stages': 2}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 4, 'num_stages': 3}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 4, 'num_stages': 4}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 8, 'num_stages': 2}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 8, 'num_stages': 3}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 8, 'num_stages': 4}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 16, 'num_stages': 2}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 16, 'num_stages': 3}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 16, 'num_stages': 4}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}], 'extra_launcher_args': [], 'declared_constexpr_names': ['BLOCK_SIZE_M', 'BLOCK_SIZE_N', 'BLOCK_SIZE_K', 'GROUP_SIZE_M'], 'kernel_name': 'w8a8_block_dynamic_fp8_matmul_kernel_2', 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    triton_meta={'signature': {'A': '*bf16', 'B': '*fp8e4nv', 'C': '*bf16', 'Bs': '*fp32', 'M': 'constexpr', 'N': 'i32', 'K': 'i32', 'stride_am': 'i32', 'stride_ak': 'constexpr', 'stride_bk': 'constexpr', 'stride_bn': 'i32', 'stride_cm': 'i32', 'stride_cn': 'constexpr', 'stride_bs_k': 'constexpr', 'stride_bs_n': 'i32', 'BLOCK_SIZE_M': 'constexpr', 'BLOCK_SIZE_N': 'constexpr', 'BLOCK_SIZE_K': 'constexpr', 'GROUP_SIZE_M': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'M': 1, 'stride_ak': 1, 'stride_bk': 1, 'stride_cn': 1, 'stride_bs_k': 1, 'BLOCK_SIZE_M': 16, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'GROUP_SIZE_M': 8}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (10,): [['tt.divisibility', 16]], (11,): [['tt.divisibility', 16]], (14,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def w8a8_block_dynamic_fp8_matmul_kernel(
    A,  # (M, K) raw BF16/FP16 activations
    B,  # (N, K) FP8 weights
    C,  # (M, N) output
    Bs,  # (N // BLOCK_SIZE_N, K // BLOCK_SIZE_K) weight scales (fp32 or uint8/UE8M0)
    # Shape
    M,
    N,
    K,
    # Strides
    stride_am,
    stride_ak,
    stride_bk,
    stride_bn,
    stride_cm,
    stride_cn,
    stride_bs_k,
    stride_bs_n,
    # Meta-parameters
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """Block-scale FP8 GEMM kernel with fused activation quantization.

    Computes ``C = A @ B.T`` with bf16/fp16 ``A`` quantized to FP8 per-K-tile
    inline (one scale per M-row per BLOCK_SIZE_K) and pre-quantized FP8 weights
    with per-block scales. 2D grid with swizzle for L2 cache locality on B.
    """
    pid_m, pid_n, offs_am, offs_bn, offs_k = _swizzle_offsets(
        M, N, BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M
    )
    a_ptrs = A + (offs_am[:, None] * stride_am + offs_k[None, :] * stride_ak)
    b_ptrs = B + (offs_k[:, None] * stride_bk + offs_bn[None, :] * stride_bn)

    offs_bsn = offs_bn // BLOCK_SIZE_N
    bs_ptrs = Bs + offs_bsn * stride_bs_n

    accumulator = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    for k in range(0, tl.cdiv(K, BLOCK_SIZE_K)):
        k_remaining = K - k * BLOCK_SIZE_K
        a_raw = tl.load(a_ptrs, mask=offs_k[None, :] < k_remaining, other=0.0).to(
            tl.float32
        )
        a, a_s = fp8_act_quant_inline(a_raw)
        b = tl.load(b_ptrs, mask=offs_k[:, None] < k_remaining, other=0.0)
        b_s = decode_ue8m0_scale(tl.load(bs_ptrs))
        accumulator += tl.dot(a, b) * a_s[:, None] * b_s[None, :]
        a_ptrs += BLOCK_SIZE_K * stride_ak
        b_ptrs += BLOCK_SIZE_K * stride_bk
        bs_ptrs += stride_bs_k

    _store_masked(
        C,
        accumulator,
        pid_m,
        pid_n,
        M,
        N,
        stride_cm,
        stride_cn,
        BLOCK_SIZE_M,
        BLOCK_SIZE_N,
    )

@triton.jit
def _swizzle_offsets(
    M,
    N,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """2D-grid tile scheduling shared by the kernels below: swizzle the
    ``(pid_m, pid_n)`` program ids for L2 locality on B, then build the operand
    offset vectors. Returns ``(pid_m, pid_n, offs_am, offs_bn, offs_k)`` — the
    swizzled ids (reused by the output store) and the ``%``-wrapped row/col offsets
    plus the K range."""
    pid_m = tl.program_id(axis=0)
    pid_n = tl.program_id(axis=1)
    num_pid_m = tl.cdiv(M, BLOCK_SIZE_M)
    num_pid_n = tl.cdiv(N, BLOCK_SIZE_N)
    pid_m, pid_n = tl.swizzle2d(pid_m, pid_n, num_pid_m, num_pid_n, GROUP_SIZE_M)
    offs_am = (pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)) % M
    offs_bn = (pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)) % N
    offs_k = tl.arange(0, BLOCK_SIZE_K)
    return pid_m, pid_n, offs_am, offs_bn, offs_k

@triton.jit
def fp8_act_quant_inline(a_raw):
    """Inline FP8 (E4M3) activation quant for the W8A8 block-scale path.

    Per-row amax → fp32 scale ``amax/448`` (floored at 1e-12 against zero rows)
    → cast values to FP8. Returns ``(a_fp8, a_s)`` with shapes ``(M, K)`` and
    ``(M,)``.
    """
    a_s = tl.max(tl.abs(a_raw), axis=1) / 448.0
    a_fp8 = (a_raw / tl.maximum(a_s[:, None], 1e-12)).to(tl.float8e4nv)
    return a_fp8, a_s

@triton.jit
def decode_ue8m0_scale(scale):
    """Decode a UE8M0 weight scale to fp32: when it was loaded as ``uint8`` exponent
    bits, ``value = 2^(exp - 127)``, built directly as the fp32 bit pattern. fp32
    scales (block-dynamic with float scales) pass through. The dtype branch is a
    compile-time constant, so only the taken path is emitted (single return — Triton
    requires all ``return`` statements to share a type)."""
    if scale.dtype == tl.uint8:
        scale = (scale.to(tl.int32) << 23).to(tl.float32, bitcast=True)
    return scale

@triton.jit
def _store_masked(
    C,
    accumulator,
    pid_m,
    pid_n,
    M,
    N,
    stride_cm,
    stride_cn,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
):
    """Shared output epilogue of the kernels below: cast the fp32 accumulator to
    ``C``'s dtype and store the ``(BLOCK_SIZE_M, BLOCK_SIZE_N)`` tile at the swizzled
    ``(pid_m, pid_n)``, masked to the ``(M, N)`` bounds."""
    c = accumulator.to(C.dtype.element_ty)
    offs_cm = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_cn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    c_ptrs = C + stride_cm * offs_cm[:, None] + stride_cn * offs_cn[None, :]
    c_mask = (offs_cm[:, None] < M) & (offs_cn[None, :] < N)
    tl.store(c_ptrs, c, mask=c_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v2_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-20261031/caches/inductor/2r/c2rjkpe4pcouaqoj6wr4ez7bn4v76vspdrb7vf4d2z6dio7prw2d.py
# Topologically Sorted Source Nodes: [inputs_embeds, hidden_states_9, hidden_states_10, pow_4, variance_3, add_9, rsqrt_3, hidden_states_11, to_11, hidden_states_12], Original ATen: [aten.embedding, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_9 => add_11
#   hidden_states_10 => convert_element_type_14
#   hidden_states_11 => mul_15
#   hidden_states_12 => mul_16
#   hidden_states_9 => add_10
#   inputs_embeds => embedding
#   pow_4 => pow_4
#   rsqrt_3 => rsqrt_3
#   to_11 => convert_element_type_15
#   variance_3 => mean_3
# Graph fragment:
#   %arg0_1 : Tensor "i64[1, 1][1, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %arg1_1 : Tensor "bf16[151936, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %buf30 : Tensor  = PlaceHolder[target=buf30]
#   %arg18_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg18_1]
#   %buf31 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf31]
#   %embedding : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg1_1, %arg0_1), kwargs = {})
#   %add_10 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %empty_3), kwargs = {})
#   %convert_element_type_14 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_10, torch.float32), kwargs = {})
#   %pow_4 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_14, 2), kwargs = {})
#   %mean_3 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_4, [-1], True), kwargs = {})
#   %add_11 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_3, 1e-06), kwargs = {})
#   %rsqrt_3 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_11,), kwargs = {})
#   %mul_15 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_14, %rsqrt_3), kwargs = {})
#   %convert_element_type_15 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_15, torch.bfloat16), kwargs = {})
#   %mul_16 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg18_1, %convert_element_type_15), kwargs = {})
#   return %buf31,%mul_16
triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_11 = async_compile.triton('triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_11', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_11', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 12288}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_11(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    _tmp9 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp4 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp1) & (tmp1 < 151936), "index out of bounds: 0 <= tmp1 < 151936")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 2048*tmp1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp5 = tmp3 + tmp4
        tmp6 = tmp5.to(tl.float32)
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask, tmp10, _tmp9)
    tmp9 = triton_helpers.promote_to_tensor(tl.sum(_tmp9, 0))
    tmp12 = tl.load(in_ptr0 + (0))
    tmp13 = tl.broadcast_to(tmp12, [R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp11 = tl.load(in_ptr3 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp16 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp13) & (tmp13 < 151936), "index out of bounds: 0 <= tmp13 < 151936")
        tmp15 = tl.load(in_ptr1 + (r0_0 + 2048*tmp13), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp17 = tmp15 + tmp16
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tl.full([1], 2048.0, tl.float32)
        tmp20 = (tmp9 / tmp19)
        tmp21 = tl.full([1], 1e-06, tl.float32)
        tmp22 = tmp20 + tmp21
        tmp23 = libdevice.rsqrt(tmp22)
        tmp24 = tmp18 * tmp23
        tmp25 = tmp24.to(tl.float32)
        tmp26 = tmp11 * tmp25
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp26, r0_mask)
''', device_str='tnca')


# Original path: /home/zzhouch/r41s2_fp8_inputs/hf/hub/kernels--kernels-community--finegrained-fp8/snapshots/0e5764aa5c27d0f005117a92645156481540950a/build/torch-cuda/matmul.py:96
w8a8_block_dynamic_fp8_matmul_kernel_3 = async_compile.triton('w8a8_block_dynamic_fp8_matmul_kernel', '''

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 2, 'num_stages': 2}, {'num_warps': 2, 'num_stages': 3}, {'num_warps': 2, 'num_stages': 4}, {'num_warps': 4, 'num_stages': 2}, {'num_warps': 4, 'num_stages': 3}, {'num_warps': 4, 'num_stages': 4}, {'num_warps': 8, 'num_stages': 2}, {'num_warps': 8, 'num_stages': 3}, {'num_warps': 8, 'num_stages': 4}, {'num_warps': 16, 'num_stages': 2}, {'num_warps': 16, 'num_stages': 3}, {'num_warps': 16, 'num_stages': 4}],
    inductor_meta={'grid_type': 'PrecomputedGrid', 'precomputed_grids': [{'config': {'num_warps': 2, 'num_stages': 2}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 2, 'num_stages': 3}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 2, 'num_stages': 4}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 4, 'num_stages': 2}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 4, 'num_stages': 3}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 4, 'num_stages': 4}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 8, 'num_stages': 2}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 8, 'num_stages': 3}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 8, 'num_stages': 4}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 16, 'num_stages': 2}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 16, 'num_stages': 3}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 16, 'num_stages': 4}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}], 'extra_launcher_args': [], 'declared_constexpr_names': ['BLOCK_SIZE_M', 'BLOCK_SIZE_N', 'BLOCK_SIZE_K', 'GROUP_SIZE_M'], 'kernel_name': 'w8a8_block_dynamic_fp8_matmul_kernel_3', 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    triton_meta={'signature': {'A': '*bf16', 'B': '*fp8e4nv', 'C': '*bf16', 'Bs': '*fp32', 'M': 'constexpr', 'N': 'i32', 'K': 'i32', 'stride_am': 'i32', 'stride_ak': 'constexpr', 'stride_bk': 'constexpr', 'stride_bn': 'i32', 'stride_cm': 'i32', 'stride_cn': 'constexpr', 'stride_bs_k': 'constexpr', 'stride_bs_n': 'i32', 'BLOCK_SIZE_M': 'constexpr', 'BLOCK_SIZE_N': 'constexpr', 'BLOCK_SIZE_K': 'constexpr', 'GROUP_SIZE_M': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'M': 1, 'stride_ak': 1, 'stride_bk': 1, 'stride_cn': 1, 'stride_bs_k': 1, 'BLOCK_SIZE_M': 16, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'GROUP_SIZE_M': 8}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (10,): [['tt.divisibility', 16]], (11,): [['tt.divisibility', 16]], (14,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def w8a8_block_dynamic_fp8_matmul_kernel(
    A,  # (M, K) raw BF16/FP16 activations
    B,  # (N, K) FP8 weights
    C,  # (M, N) output
    Bs,  # (N // BLOCK_SIZE_N, K // BLOCK_SIZE_K) weight scales (fp32 or uint8/UE8M0)
    # Shape
    M,
    N,
    K,
    # Strides
    stride_am,
    stride_ak,
    stride_bk,
    stride_bn,
    stride_cm,
    stride_cn,
    stride_bs_k,
    stride_bs_n,
    # Meta-parameters
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """Block-scale FP8 GEMM kernel with fused activation quantization.

    Computes ``C = A @ B.T`` with bf16/fp16 ``A`` quantized to FP8 per-K-tile
    inline (one scale per M-row per BLOCK_SIZE_K) and pre-quantized FP8 weights
    with per-block scales. 2D grid with swizzle for L2 cache locality on B.
    """
    pid_m, pid_n, offs_am, offs_bn, offs_k = _swizzle_offsets(
        M, N, BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M
    )
    a_ptrs = A + (offs_am[:, None] * stride_am + offs_k[None, :] * stride_ak)
    b_ptrs = B + (offs_k[:, None] * stride_bk + offs_bn[None, :] * stride_bn)

    offs_bsn = offs_bn // BLOCK_SIZE_N
    bs_ptrs = Bs + offs_bsn * stride_bs_n

    accumulator = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    for k in range(0, tl.cdiv(K, BLOCK_SIZE_K)):
        k_remaining = K - k * BLOCK_SIZE_K
        a_raw = tl.load(a_ptrs, mask=offs_k[None, :] < k_remaining, other=0.0).to(
            tl.float32
        )
        a, a_s = fp8_act_quant_inline(a_raw)
        b = tl.load(b_ptrs, mask=offs_k[:, None] < k_remaining, other=0.0)
        b_s = decode_ue8m0_scale(tl.load(bs_ptrs))
        accumulator += tl.dot(a, b) * a_s[:, None] * b_s[None, :]
        a_ptrs += BLOCK_SIZE_K * stride_ak
        b_ptrs += BLOCK_SIZE_K * stride_bk
        bs_ptrs += stride_bs_k

    _store_masked(
        C,
        accumulator,
        pid_m,
        pid_n,
        M,
        N,
        stride_cm,
        stride_cn,
        BLOCK_SIZE_M,
        BLOCK_SIZE_N,
    )

@triton.jit
def _swizzle_offsets(
    M,
    N,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """2D-grid tile scheduling shared by the kernels below: swizzle the
    ``(pid_m, pid_n)`` program ids for L2 locality on B, then build the operand
    offset vectors. Returns ``(pid_m, pid_n, offs_am, offs_bn, offs_k)`` — the
    swizzled ids (reused by the output store) and the ``%``-wrapped row/col offsets
    plus the K range."""
    pid_m = tl.program_id(axis=0)
    pid_n = tl.program_id(axis=1)
    num_pid_m = tl.cdiv(M, BLOCK_SIZE_M)
    num_pid_n = tl.cdiv(N, BLOCK_SIZE_N)
    pid_m, pid_n = tl.swizzle2d(pid_m, pid_n, num_pid_m, num_pid_n, GROUP_SIZE_M)
    offs_am = (pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)) % M
    offs_bn = (pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)) % N
    offs_k = tl.arange(0, BLOCK_SIZE_K)
    return pid_m, pid_n, offs_am, offs_bn, offs_k

@triton.jit
def fp8_act_quant_inline(a_raw):
    """Inline FP8 (E4M3) activation quant for the W8A8 block-scale path.

    Per-row amax → fp32 scale ``amax/448`` (floored at 1e-12 against zero rows)
    → cast values to FP8. Returns ``(a_fp8, a_s)`` with shapes ``(M, K)`` and
    ``(M,)``.
    """
    a_s = tl.max(tl.abs(a_raw), axis=1) / 448.0
    a_fp8 = (a_raw / tl.maximum(a_s[:, None], 1e-12)).to(tl.float8e4nv)
    return a_fp8, a_s

@triton.jit
def decode_ue8m0_scale(scale):
    """Decode a UE8M0 weight scale to fp32: when it was loaded as ``uint8`` exponent
    bits, ``value = 2^(exp - 127)``, built directly as the fp32 bit pattern. fp32
    scales (block-dynamic with float scales) pass through. The dtype branch is a
    compile-time constant, so only the taken path is emitted (single return — Triton
    requires all ``return`` statements to share a type)."""
    if scale.dtype == tl.uint8:
        scale = (scale.to(tl.int32) << 23).to(tl.float32, bitcast=True)
    return scale

@triton.jit
def _store_masked(
    C,
    accumulator,
    pid_m,
    pid_n,
    M,
    N,
    stride_cm,
    stride_cn,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
):
    """Shared output epilogue of the kernels below: cast the fp32 accumulator to
    ``C``'s dtype and store the ``(BLOCK_SIZE_M, BLOCK_SIZE_N)`` tile at the swizzled
    ``(pid_m, pid_n)``, masked to the ``(M, N)`` bounds."""
    c = accumulator.to(C.dtype.element_ty)
    offs_cm = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_cn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    c_ptrs = C + stride_cm * offs_cm[:, None] + stride_cn * offs_cn[None, :]
    c_mask = (offs_cm[:, None] < M) & (offs_cn[None, :] < N)
    tl.store(c_ptrs, c, mask=c_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v2_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-20261031/caches/inductor/fm/cfmdx4xxlk67hnkhajrbx664rgzjwdzrcv4llgz3ku6rvqy2lbjx.py
# Topologically Sorted Source Nodes: [silu, mul_15, output_6], Original ATen: [aten.silu, aten.mul]
# Source node to ATen node mapping:
#   mul_15 => mul_17
#   output_6 => triton_kernel_wrapper_mutation_189
#   silu => add_12, convert_element_type_16, convert_element_type_17, div_1, exp_1, neg_2
# Graph fragment:
#   %buf34 : Tensor  = PlaceHolder[target=buf34]
#   %buf36 : Tensor  = PlaceHolder[target=buf36]
#   %convert_element_type_16 : Tensor "f32[1, 1, 6144][6144, 6144, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%empty_4, torch.float32), kwargs = {})
#   %neg_2 : Tensor "f32[1, 1, 6144][6144, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_16,), kwargs = {})
#   %exp_1 : Tensor "f32[1, 1, 6144][6144, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_2,), kwargs = {})
#   %add_12 : Tensor "f32[1, 1, 6144][6144, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp_1, 1), kwargs = {})
#   %div_1 : Tensor "f32[1, 1, 6144][6144, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_16, %add_12), kwargs = {})
#   %convert_element_type_17 : Tensor "bf16[1, 1, 6144][6144, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_1, torch.bfloat16), kwargs = {})
#   %mul_17 : Tensor "bf16[1, 1, 6144][6144, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_17, %empty_5), kwargs = {})
#   %triton_kernel_wrapper_mutation_189 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 398, grid: [(1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1)], tma_descriptor_metadata: {}, kwargs: {A: %mul_17, B: %arg23_1, C: %empty_6, Bs: %arg24_1, M: 1, N: 2048, K: 6144, stride_am: 6144, stride_ak: 1, stride_bk: 1, stride_bn: 6144, stride_cm: 2048, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 48, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   return %buf38
triton_poi_fused_mul_silu_12 = async_compile.triton('triton_poi_fused_mul_silu_12', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 8192}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_mul_silu_12', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 24576}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_mul_silu_12(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 6144
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask).to(tl.float32)
    tmp8 = tl.load(in_ptr1 + (x0), xmask).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = -tmp1
    tmp3 = libdevice.exp(tmp2)
    tmp4 = tl.full([1], 1.0, tl.float32)
    tmp5 = tmp3 + tmp4
    tmp6 = (tmp1 / tmp5)
    tmp7 = tmp6.to(tl.float32)
    tmp9 = tmp7 * tmp8
    tl.store(out_ptr0 + (x0), tmp9, xmask)
''', device_str='tnca')


# Original path: /home/zzhouch/r41s2_fp8_inputs/hf/hub/kernels--kernels-community--finegrained-fp8/snapshots/0e5764aa5c27d0f005117a92645156481540950a/build/torch-cuda/matmul.py:96
w8a8_block_dynamic_fp8_matmul_kernel_4 = async_compile.triton('w8a8_block_dynamic_fp8_matmul_kernel', '''

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 2, 'num_stages': 2}, {'num_warps': 2, 'num_stages': 3}, {'num_warps': 2, 'num_stages': 4}, {'num_warps': 4, 'num_stages': 2}, {'num_warps': 4, 'num_stages': 3}, {'num_warps': 4, 'num_stages': 4}, {'num_warps': 8, 'num_stages': 2}, {'num_warps': 8, 'num_stages': 3}, {'num_warps': 8, 'num_stages': 4}, {'num_warps': 16, 'num_stages': 2}, {'num_warps': 16, 'num_stages': 3}, {'num_warps': 16, 'num_stages': 4}],
    inductor_meta={'grid_type': 'PrecomputedGrid', 'precomputed_grids': [{'config': {'num_warps': 2, 'num_stages': 2}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 2, 'num_stages': 3}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 2, 'num_stages': 4}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 4, 'num_stages': 2}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 4, 'num_stages': 3}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 4, 'num_stages': 4}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 8, 'num_stages': 2}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 8, 'num_stages': 3}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 8, 'num_stages': 4}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 16, 'num_stages': 2}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 16, 'num_stages': 3}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}, {'config': {'num_warps': 16, 'num_stages': 4}, 'python': ['1', '16', '1'], 'cpp': ['1L', '16L', '1L'], 'python_slow': ['1', '16', '1']}], 'extra_launcher_args': [], 'declared_constexpr_names': ['BLOCK_SIZE_M', 'BLOCK_SIZE_N', 'BLOCK_SIZE_K', 'GROUP_SIZE_M'], 'kernel_name': 'w8a8_block_dynamic_fp8_matmul_kernel_4', 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    triton_meta={'signature': {'A': '*bf16', 'B': '*fp8e4nv', 'C': '*bf16', 'Bs': '*fp32', 'M': 'constexpr', 'N': 'i32', 'K': 'i32', 'stride_am': 'i32', 'stride_ak': 'constexpr', 'stride_bk': 'constexpr', 'stride_bn': 'i32', 'stride_cm': 'i32', 'stride_cn': 'constexpr', 'stride_bs_k': 'constexpr', 'stride_bs_n': 'i32', 'BLOCK_SIZE_M': 'constexpr', 'BLOCK_SIZE_N': 'constexpr', 'BLOCK_SIZE_K': 'constexpr', 'GROUP_SIZE_M': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'M': 1, 'stride_ak': 1, 'stride_bk': 1, 'stride_cn': 1, 'stride_bs_k': 1, 'BLOCK_SIZE_M': 16, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'GROUP_SIZE_M': 8}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (10,): [['tt.divisibility', 16]], (11,): [['tt.divisibility', 16]], (14,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def w8a8_block_dynamic_fp8_matmul_kernel(
    A,  # (M, K) raw BF16/FP16 activations
    B,  # (N, K) FP8 weights
    C,  # (M, N) output
    Bs,  # (N // BLOCK_SIZE_N, K // BLOCK_SIZE_K) weight scales (fp32 or uint8/UE8M0)
    # Shape
    M,
    N,
    K,
    # Strides
    stride_am,
    stride_ak,
    stride_bk,
    stride_bn,
    stride_cm,
    stride_cn,
    stride_bs_k,
    stride_bs_n,
    # Meta-parameters
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """Block-scale FP8 GEMM kernel with fused activation quantization.

    Computes ``C = A @ B.T`` with bf16/fp16 ``A`` quantized to FP8 per-K-tile
    inline (one scale per M-row per BLOCK_SIZE_K) and pre-quantized FP8 weights
    with per-block scales. 2D grid with swizzle for L2 cache locality on B.
    """
    pid_m, pid_n, offs_am, offs_bn, offs_k = _swizzle_offsets(
        M, N, BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M
    )
    a_ptrs = A + (offs_am[:, None] * stride_am + offs_k[None, :] * stride_ak)
    b_ptrs = B + (offs_k[:, None] * stride_bk + offs_bn[None, :] * stride_bn)

    offs_bsn = offs_bn // BLOCK_SIZE_N
    bs_ptrs = Bs + offs_bsn * stride_bs_n

    accumulator = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    for k in range(0, tl.cdiv(K, BLOCK_SIZE_K)):
        k_remaining = K - k * BLOCK_SIZE_K
        a_raw = tl.load(a_ptrs, mask=offs_k[None, :] < k_remaining, other=0.0).to(
            tl.float32
        )
        a, a_s = fp8_act_quant_inline(a_raw)
        b = tl.load(b_ptrs, mask=offs_k[:, None] < k_remaining, other=0.0)
        b_s = decode_ue8m0_scale(tl.load(bs_ptrs))
        accumulator += tl.dot(a, b) * a_s[:, None] * b_s[None, :]
        a_ptrs += BLOCK_SIZE_K * stride_ak
        b_ptrs += BLOCK_SIZE_K * stride_bk
        bs_ptrs += stride_bs_k

    _store_masked(
        C,
        accumulator,
        pid_m,
        pid_n,
        M,
        N,
        stride_cm,
        stride_cn,
        BLOCK_SIZE_M,
        BLOCK_SIZE_N,
    )

@triton.jit
def _swizzle_offsets(
    M,
    N,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """2D-grid tile scheduling shared by the kernels below: swizzle the
    ``(pid_m, pid_n)`` program ids for L2 locality on B, then build the operand
    offset vectors. Returns ``(pid_m, pid_n, offs_am, offs_bn, offs_k)`` — the
    swizzled ids (reused by the output store) and the ``%``-wrapped row/col offsets
    plus the K range."""
    pid_m = tl.program_id(axis=0)
    pid_n = tl.program_id(axis=1)
    num_pid_m = tl.cdiv(M, BLOCK_SIZE_M)
    num_pid_n = tl.cdiv(N, BLOCK_SIZE_N)
    pid_m, pid_n = tl.swizzle2d(pid_m, pid_n, num_pid_m, num_pid_n, GROUP_SIZE_M)
    offs_am = (pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)) % M
    offs_bn = (pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)) % N
    offs_k = tl.arange(0, BLOCK_SIZE_K)
    return pid_m, pid_n, offs_am, offs_bn, offs_k

@triton.jit
def fp8_act_quant_inline(a_raw):
    """Inline FP8 (E4M3) activation quant for the W8A8 block-scale path.

    Per-row amax → fp32 scale ``amax/448`` (floored at 1e-12 against zero rows)
    → cast values to FP8. Returns ``(a_fp8, a_s)`` with shapes ``(M, K)`` and
    ``(M,)``.
    """
    a_s = tl.max(tl.abs(a_raw), axis=1) / 448.0
    a_fp8 = (a_raw / tl.maximum(a_s[:, None], 1e-12)).to(tl.float8e4nv)
    return a_fp8, a_s

@triton.jit
def decode_ue8m0_scale(scale):
    """Decode a UE8M0 weight scale to fp32: when it was loaded as ``uint8`` exponent
    bits, ``value = 2^(exp - 127)``, built directly as the fp32 bit pattern. fp32
    scales (block-dynamic with float scales) pass through. The dtype branch is a
    compile-time constant, so only the taken path is emitted (single return — Triton
    requires all ``return`` statements to share a type)."""
    if scale.dtype == tl.uint8:
        scale = (scale.to(tl.int32) << 23).to(tl.float32, bitcast=True)
    return scale

@triton.jit
def _store_masked(
    C,
    accumulator,
    pid_m,
    pid_n,
    M,
    N,
    stride_cm,
    stride_cn,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
):
    """Shared output epilogue of the kernels below: cast the fp32 accumulator to
    ``C``'s dtype and store the ``(BLOCK_SIZE_M, BLOCK_SIZE_N)`` tile at the swizzled
    ``(pid_m, pid_n)``, masked to the ``(M, N)`` bounds."""
    c = accumulator.to(C.dtype.element_ty)
    offs_cm = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_cn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    c_ptrs = C + stride_cm * offs_cm[:, None] + stride_cn * offs_cn[None, :]
    c_mask = (offs_cm[:, None] < M) & (offs_cn[None, :] < N)
    tl.store(c_ptrs, c, mask=c_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v2_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-20261031/caches/inductor/xb/cxbcbwnbegigmp6zsld56pqrn7gjjrnt7vn7s33vp7rhmqxpby4t.py
# Topologically Sorted Source Nodes: [inputs_embeds, hidden_states_9, hidden_states_13, hidden_states_14, pow_5, variance_4, add_11, rsqrt_4, hidden_states_15, to_13, hidden_states_16], Original ATen: [aten.embedding, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_11 => add_14
#   hidden_states_13 => add_13
#   hidden_states_14 => convert_element_type_18
#   hidden_states_15 => mul_18
#   hidden_states_16 => mul_19
#   hidden_states_9 => add_10
#   inputs_embeds => embedding
#   pow_5 => pow_5
#   rsqrt_4 => rsqrt_4
#   to_13 => convert_element_type_19
#   variance_4 => mean_4
# Graph fragment:
#   %arg0_1 : Tensor "i64[1, 1][1, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %arg1_1 : Tensor "bf16[151936, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %buf30 : Tensor  = PlaceHolder[target=buf30]
#   %buf39 : Tensor  = PlaceHolder[target=buf39]
#   %arg25_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg25_1]
#   %buf40 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf40]
#   %embedding : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg1_1, %arg0_1), kwargs = {})
#   %add_10 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %empty_3), kwargs = {})
#   %add_13 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_10, %empty_6), kwargs = {})
#   %convert_element_type_18 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_13, torch.float32), kwargs = {})
#   %pow_5 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_18, 2), kwargs = {})
#   %mean_4 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_5, [-1], True), kwargs = {})
#   %add_14 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_4, 1e-06), kwargs = {})
#   %rsqrt_4 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_14,), kwargs = {})
#   %mul_18 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_18, %rsqrt_4), kwargs = {})
#   %convert_element_type_19 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_18, torch.bfloat16), kwargs = {})
#   %mul_19 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg25_1, %convert_element_type_19), kwargs = {})
#   return %buf40,%mul_19
triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_13 = async_compile.triton('triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_13', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_13', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 12288}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_13(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr3, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    _tmp11 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp4 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp6 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp1) & (tmp1 < 151936), "index out of bounds: 0 <= tmp1 < 151936")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 2048*tmp1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp5 = tmp3 + tmp4
        tmp7 = tmp5 + tmp6
        tmp8 = tmp7.to(tl.float32)
        tmp9 = tmp8 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask, tmp12, _tmp11)
    tmp11 = triton_helpers.promote_to_tensor(tl.sum(_tmp11, 0))
    tmp14 = tl.load(in_ptr0 + (0))
    tmp15 = tl.broadcast_to(tmp14, [R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr3, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp13 = tl.load(in_ptr4 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp18 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp20 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp15) & (tmp15 < 151936), "index out of bounds: 0 <= tmp15 < 151936")
        tmp17 = tl.load(in_ptr1 + (r0_0 + 2048*tmp15), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp19 = tmp17 + tmp18
        tmp21 = tmp19 + tmp20
        tmp22 = tmp21.to(tl.float32)
        tmp23 = tl.full([1], 2048.0, tl.float32)
        tmp24 = (tmp11 / tmp23)
        tmp25 = tl.full([1], 1e-06, tl.float32)
        tmp26 = tmp24 + tmp25
        tmp27 = libdevice.rsqrt(tmp26)
        tmp28 = tmp22 * tmp27
        tmp29 = tmp28.to(tl.float32)
        tmp30 = tmp13 * tmp29
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp30, r0_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v2_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-20261031/caches/inductor/d3/cd36sixmoljz5dccgbw6mwo55aj4c5gkoyqk5nxcrfnm3tgpm2s6.py
# Topologically Sorted Source Nodes: [inputs_embeds, hidden_states_9, hidden_states_13, hidden_states_23, hidden_states_24, pow_8, variance_7, add_18, rsqrt_7, hidden_states_25, to_19, hidden_states_26, output_11, output_12], Original ATen: [aten.embedding, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_18 => add_23
#   hidden_states_13 => add_13
#   hidden_states_23 => add_22
#   hidden_states_24 => convert_element_type_29
#   hidden_states_25 => mul_30
#   hidden_states_26 => mul_31
#   hidden_states_9 => add_10
#   inputs_embeds => embedding
#   output_11 => triton_kernel_wrapper_mutation_184
#   output_12 => triton_kernel_wrapper_mutation_183
#   pow_8 => pow_8
#   rsqrt_7 => rsqrt_7
#   to_19 => convert_element_type_30
#   variance_7 => mean_7
# Graph fragment:
#   %arg0_1 : Tensor "i64[1, 1][1, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %arg1_1 : Tensor "bf16[151936, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %buf30 : Tensor  = PlaceHolder[target=buf30]
#   %buf39 : Tensor  = PlaceHolder[target=buf39]
#   %buf66 : Tensor  = PlaceHolder[target=buf66]
#   %add_22 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=add_22]
#   %arg39_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg39_1]
#   %buf68 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf68]
#   %embedding : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg1_1, %arg0_1), kwargs = {})
#   %add_10 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %empty_3), kwargs = {})
#   %add_13 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_10, %empty_6), kwargs = {})
#   %add_22 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_13, %empty_10), kwargs = {})
#   %convert_element_type_29 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_22, torch.float32), kwargs = {})
#   %pow_8 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_29, 2), kwargs = {})
#   %mean_7 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_8, [-1], True), kwargs = {})
#   %add_23 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_7, 1e-06), kwargs = {})
#   %rsqrt_7 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_23,), kwargs = {})
#   %mul_30 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_29, %rsqrt_7), kwargs = {})
#   %convert_element_type_30 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_30, torch.bfloat16), kwargs = {})
#   %mul_31 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg39_1, %convert_element_type_30), kwargs = {})
#   %triton_kernel_wrapper_mutation_184 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 403, grid: [(1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1)], tma_descriptor_metadata: {}, kwargs: {A: %mul_31, B: %arg40_1, C: %empty_11, Bs: %arg41_1, M: 1, N: 6144, K: 2048, stride_am: 2048, stride_ak: 1, stride_bk: 1, stride_bn: 2048, stride_cm: 6144, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 16, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   %triton_kernel_wrapper_mutation_183 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 404, grid: [(1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1)], tma_descriptor_metadata: {}, kwargs: {A: %mul_31, B: %arg42_1, C: %empty_12, Bs: %arg43_1, M: 1, N: 6144, K: 2048, stride_am: 2048, stride_ak: 1, stride_bk: 1, stride_bn: 2048, stride_cm: 6144, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 16, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   return %add_22,%buf68,%buf70,%buf73
triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_14 = async_compile.triton('triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_14', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'in_ptr5': '*bf16', 'out_ptr0': '*bf16', 'out_ptr2': '*bf16', 'out_ptr3': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]], (10,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_14', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 6, 'num_store': 3, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 28672}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_14(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr0, out_ptr2, out_ptr3, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr3, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr4, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    _tmp13 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp4 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp6 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp8 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp1) & (tmp1 < 151936), "index out of bounds: 0 <= tmp1 < 151936")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 2048*tmp1), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp5 = tmp3 + tmp4
        tmp7 = tmp5 + tmp6
        tmp9 = tmp7 + tmp8
        tmp10 = tmp9.to(tl.float32)
        tmp11 = tmp10 * tmp10
        tmp12 = tl.broadcast_to(tmp11, [R0_BLOCK])
        tmp14 = _tmp13 + tmp12
        _tmp13 = tl.where(r0_mask, tmp14, _tmp13)
        tl.store(out_ptr0 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp9, r0_mask)
    tmp13 = triton_helpers.promote_to_tensor(tl.sum(_tmp13, 0))
    tma_descriptor3 = tl.make_tensor_descriptor(out_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp15 = tl.load(in_ptr5 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.debug_barrier()
        tmp16 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tl.debug_barrier()
        tmp17 = tmp16.to(tl.float32)
        tmp18 = tl.full([1], 2048.0, tl.float32)
        tmp19 = (tmp13 / tmp18)
        tmp20 = tl.full([1], 1e-06, tl.float32)
        tmp21 = tmp19 + tmp20
        tmp22 = libdevice.rsqrt(tmp21)
        tmp23 = tmp17 * tmp22
        tmp24 = tmp23.to(tl.float32)
        tmp25 = tmp15 * tmp24
        tl.store(out_ptr2 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp25, r0_mask)
        tl.store(out_ptr3 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp25, r0_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v2_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-20261031/caches/inductor/3q/c3qo672zpjep2dmfjnm2l2u37ve55kodh6ktn42ga2no6ywtlrzd.py
# Topologically Sorted Source Nodes: [hidden_states_27, hidden_states_28, pow_9, variance_8, add_20, rsqrt_8, hidden_states_29, to_21, hidden_states_30, output_14, output_15, output_16], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_20 => add_26
#   hidden_states_27 => add_25
#   hidden_states_28 => convert_element_type_33
#   hidden_states_29 => mul_33
#   hidden_states_30 => mul_34
#   output_14 => triton_kernel_wrapper_mutation_181
#   output_15 => triton_kernel_wrapper_mutation_180
#   output_16 => triton_kernel_wrapper_mutation_179
#   pow_9 => pow_9
#   rsqrt_8 => rsqrt_8
#   to_21 => convert_element_type_34
#   variance_8 => mean_8
# Graph fragment:
#   %add_22 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=add_22]
#   %buf77 : Tensor  = PlaceHolder[target=buf77]
#   %arg46_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg46_1]
#   %buf78 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf78]
#   %add_25 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_22, %empty_13), kwargs = {})
#   %convert_element_type_33 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_25, torch.float32), kwargs = {})
#   %pow_9 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_33, 2), kwargs = {})
#   %mean_8 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_9, [-1], True), kwargs = {})
#   %add_26 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_8, 1e-06), kwargs = {})
#   %rsqrt_8 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_26,), kwargs = {})
#   %mul_33 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_33, %rsqrt_8), kwargs = {})
#   %convert_element_type_34 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_33, torch.bfloat16), kwargs = {})
#   %mul_34 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg46_1, %convert_element_type_34), kwargs = {})
#   %triton_kernel_wrapper_mutation_181 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 406, grid: [(1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1), (1, 16, 1)], tma_descriptor_metadata: {}, kwargs: {A: %mul_34, B: %arg47_1, C: %empty_14, Bs: %arg48_1, M: 1, N: 2048, K: 2048, stride_am: 2048, stride_ak: 1, stride_bk: 1, stride_bn: 2048, stride_cm: 2048, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 16, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   %triton_kernel_wrapper_mutation_180 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 407, grid: [(1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1)], tma_descriptor_metadata: {}, kwargs: {A: %mul_34, B: %arg50_1, C: %empty_15, Bs: %arg51_1, M: 1, N: 1024, K: 2048, stride_am: 2048, stride_ak: 1, stride_bk: 1, stride_bn: 2048, stride_cm: 1024, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 16, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   %triton_kernel_wrapper_mutation_179 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 408, grid: [(1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1), (1, 8, 1)], tma_descriptor_metadata: {}, kwargs: {A: %mul_34, B: %arg53_1, C: %empty_16, Bs: %arg54_1, M: 1, N: 1024, K: 2048, stride_am: 2048, stride_ak: 1, stride_bk: 1, stride_bn: 2048, stride_cm: 1024, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 16, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   return %buf78,%buf80,%buf83,%buf86
triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_15 = async_compile.triton('triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_15', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'out_ptr1': '*bf16', 'out_ptr2': '*bf16', 'out_ptr3': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_15', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 3, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 32768}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_15(in_ptr0, in_ptr1, in_ptr2, out_ptr1, out_ptr2, out_ptr3, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    _tmp6 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp3 * tmp3
        tmp5 = tl.broadcast_to(tmp4, [R0_BLOCK])
        tmp7 = _tmp6 + tmp5
        _tmp6 = tl.where(r0_mask, tmp7, _tmp6)
    tmp6 = triton_helpers.promote_to_tensor(tl.sum(_tmp6, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr1, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp8 = tl.load(in_ptr2 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp9 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp10 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp11 = tmp9 + tmp10
        tmp12 = tmp11.to(tl.float32)
        tmp13 = tl.full([1], 2048.0, tl.float32)
        tmp14 = (tmp6 / tmp13)
        tmp15 = tl.full([1], 1e-06, tl.float32)
        tmp16 = tmp14 + tmp15
        tmp17 = libdevice.rsqrt(tmp16)
        tmp18 = tmp12 * tmp17
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tmp8 * tmp19
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp20, r0_mask)
        tl.store(out_ptr2 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp20, r0_mask)
        tl.store(out_ptr3 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp20, r0_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v2_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-20261031/caches/inductor/cb/ccb2bynjrfquplm7h7ir4cle4aum7spllzcfugugjjmx3pcossje.py
# Topologically Sorted Source Nodes: [hidden_states_27, hidden_states_37, hidden_states_38, pow_12, variance_11, add_27, rsqrt_11, hidden_states_39, to_27, hidden_states_40], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_27 => add_35
#   hidden_states_27 => add_25
#   hidden_states_37 => add_34
#   hidden_states_38 => convert_element_type_44
#   hidden_states_39 => mul_45
#   hidden_states_40 => mul_46
#   pow_12 => pow_12
#   rsqrt_11 => rsqrt_11
#   to_27 => convert_element_type_45
#   variance_11 => mean_11
# Graph fragment:
#   %add_22 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=add_22]
#   %buf77 : Tensor  = PlaceHolder[target=buf77]
#   %buf106 : Tensor  = PlaceHolder[target=buf106]
#   %arg60_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg60_1]
#   %buf107 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf107]
#   %add_25 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_22, %empty_13), kwargs = {})
#   %add_34 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_25, %empty_17), kwargs = {})
#   %convert_element_type_44 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_34, torch.float32), kwargs = {})
#   %pow_12 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_44, 2), kwargs = {})
#   %mean_11 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_12, [-1], True), kwargs = {})
#   %add_35 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_11, 1e-06), kwargs = {})
#   %rsqrt_11 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_35,), kwargs = {})
#   %mul_45 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_44, %rsqrt_11), kwargs = {})
#   %convert_element_type_45 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_45, torch.bfloat16), kwargs = {})
#   %mul_46 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg60_1, %convert_element_type_45), kwargs = {})
#   return %buf107,%mul_46
triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_16 = async_compile.triton('triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_16', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_16', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 16384}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_16(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    _tmp8 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp3 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tmp5 * tmp5
        tmp7 = tl.broadcast_to(tmp6, [R0_BLOCK])
        tmp9 = _tmp8 + tmp7
        _tmp8 = tl.where(r0_mask, tmp9, _tmp8)
    tmp8 = triton_helpers.promote_to_tensor(tl.sum(_tmp8, 0))
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor4 = tl.make_tensor_descriptor(in_ptr1, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor5 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp10 = tl.load(in_ptr3 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp11 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp12 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor4.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp14 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor5.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp13 = tmp11 + tmp12
        tmp15 = tmp13 + tmp14
        tmp16 = tmp15.to(tl.float32)
        tmp17 = tl.full([1], 2048.0, tl.float32)
        tmp18 = (tmp8 / tmp17)
        tmp19 = tl.full([1], 1e-06, tl.float32)
        tmp20 = tmp18 + tmp19
        tmp21 = libdevice.rsqrt(tmp20)
        tmp22 = tmp16 * tmp21
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tmp10 * tmp23
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp24, r0_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v2_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-20261031/caches/inductor/uz/cuzaa4djbgcoq2wzraq7u24j465ixqyshhqlnvlta3mj5ga6sqm7.py
# Topologically Sorted Source Nodes: [hidden_states_27, hidden_states_37, hidden_states_41, hidden_states_42, pow_13, variance_12, add_29, rsqrt_12, hidden_states_43, to_29, hidden_states_44], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_29 => add_38
#   hidden_states_27 => add_25
#   hidden_states_37 => add_34
#   hidden_states_41 => add_37
#   hidden_states_42 => convert_element_type_48
#   hidden_states_43 => mul_48
#   hidden_states_44 => mul_49
#   pow_13 => pow_13
#   rsqrt_12 => rsqrt_12
#   to_29 => convert_element_type_49
#   variance_12 => mean_12
# Graph fragment:
#   %add_22 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=add_22]
#   %buf77 : Tensor  = PlaceHolder[target=buf77]
#   %buf106 : Tensor  = PlaceHolder[target=buf106]
#   %buf115 : Tensor  = PlaceHolder[target=buf115]
#   %arg67_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg67_1]
#   %buf116 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf116]
#   %add_25 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_22, %empty_13), kwargs = {})
#   %add_34 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_25, %empty_17), kwargs = {})
#   %add_37 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_34, %empty_20), kwargs = {})
#   %convert_element_type_48 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_37, torch.float32), kwargs = {})
#   %pow_13 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_48, 2), kwargs = {})
#   %mean_12 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_13, [-1], True), kwargs = {})
#   %add_38 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_12, 1e-06), kwargs = {})
#   %rsqrt_12 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_38,), kwargs = {})
#   %mul_48 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_48, %rsqrt_12), kwargs = {})
#   %convert_element_type_49 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_48, torch.bfloat16), kwargs = {})
#   %mul_49 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg67_1, %convert_element_type_49), kwargs = {})
#   return %buf116,%mul_49
triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_17 = async_compile.triton('triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_17', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_17', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 9, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 16384}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_17(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr3, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    _tmp10 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp3 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp5 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tmp7 * tmp7
        tmp9 = tl.broadcast_to(tmp8, [R0_BLOCK])
        tmp11 = _tmp10 + tmp9
        _tmp10 = tl.where(r0_mask, tmp11, _tmp10)
    tmp10 = triton_helpers.promote_to_tensor(tl.sum(_tmp10, 0))
    tma_descriptor4 = tl.make_tensor_descriptor(in_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor5 = tl.make_tensor_descriptor(in_ptr1, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor6 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor7 = tl.make_tensor_descriptor(in_ptr3, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp12 = tl.load(in_ptr4 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp13 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor4.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp14 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor5.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp16 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor6.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp18 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor7.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp15 = tmp13 + tmp14
        tmp17 = tmp15 + tmp16
        tmp19 = tmp17 + tmp18
        tmp20 = tmp19.to(tl.float32)
        tmp21 = tl.full([1], 2048.0, tl.float32)
        tmp22 = (tmp10 / tmp21)
        tmp23 = tl.full([1], 1e-06, tl.float32)
        tmp24 = tmp22 + tmp23
        tmp25 = libdevice.rsqrt(tmp24)
        tmp26 = tmp20 * tmp25
        tmp27 = tmp26.to(tl.float32)
        tmp28 = tmp12 * tmp27
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp28, r0_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v2_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-20261031/caches/inductor/3a/c3aekzyacmjoi74ojk2nycey6meu55sklxzn6ovxcveuff5tgpcf.py
# Topologically Sorted Source Nodes: [hidden_states_27, hidden_states_37, hidden_states_41, hidden_states_51, hidden_states_52, pow_16, variance_15, add_36, rsqrt_15, hidden_states_53, to_35, hidden_states_54, output_25, output_26], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_36 => add_47
#   hidden_states_27 => add_25
#   hidden_states_37 => add_34
#   hidden_states_41 => add_37
#   hidden_states_51 => add_46
#   hidden_states_52 => convert_element_type_59
#   hidden_states_53 => mul_60
#   hidden_states_54 => mul_61
#   output_25 => triton_kernel_wrapper_mutation_170
#   output_26 => triton_kernel_wrapper_mutation_169
#   pow_16 => pow_16
#   rsqrt_15 => rsqrt_15
#   to_35 => convert_element_type_60
#   variance_15 => mean_15
# Graph fragment:
#   %add_22 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=add_22]
#   %buf77 : Tensor  = PlaceHolder[target=buf77]
#   %buf106 : Tensor  = PlaceHolder[target=buf106]
#   %buf115 : Tensor  = PlaceHolder[target=buf115]
#   %buf142 : Tensor  = PlaceHolder[target=buf142]
#   %add_46 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=add_46]
#   %arg81_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg81_1]
#   %buf144 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf144]
#   %add_25 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_22, %empty_13), kwargs = {})
#   %add_34 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_25, %empty_17), kwargs = {})
#   %add_37 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_34, %empty_20), kwargs = {})
#   %add_46 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_37, %empty_24), kwargs = {})
#   %convert_element_type_59 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_46, torch.float32), kwargs = {})
#   %pow_16 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_59, 2), kwargs = {})
#   %mean_15 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_16, [-1], True), kwargs = {})
#   %add_47 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_15, 1e-06), kwargs = {})
#   %rsqrt_15 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_47,), kwargs = {})
#   %mul_60 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_59, %rsqrt_15), kwargs = {})
#   %convert_element_type_60 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_60, torch.bfloat16), kwargs = {})
#   %mul_61 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg81_1, %convert_element_type_60), kwargs = {})
#   %triton_kernel_wrapper_mutation_170 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 417, grid: [(1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1)], tma_descriptor_metadata: {}, kwargs: {A: %mul_61, B: %arg82_1, C: %empty_25, Bs: %arg83_1, M: 1, N: 6144, K: 2048, stride_am: 2048, stride_ak: 1, stride_bk: 1, stride_bn: 2048, stride_cm: 6144, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 16, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   %triton_kernel_wrapper_mutation_169 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 418, grid: [(1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1), (1, 48, 1)], tma_descriptor_metadata: {}, kwargs: {A: %mul_61, B: %arg84_1, C: %empty_26, Bs: %arg85_1, M: 1, N: 6144, K: 2048, stride_am: 2048, stride_ak: 1, stride_bk: 1, stride_bn: 2048, stride_cm: 6144, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 16, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   return %add_46,%buf144,%buf146,%buf149
triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_18 = async_compile.triton('triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_18', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*bf16', 'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'out_ptr1': '*bf16', 'out_ptr2': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_18', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 7, 'num_store': 3, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 32768}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_18(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, out_ptr2, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_out_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr1, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor4 = tl.make_tensor_descriptor(in_ptr3, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    _tmp12 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp3 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp5 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp7 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor4.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp8 = tmp6 + tmp7
        tmp9 = tmp8.to(tl.float32)
        tmp10 = tmp9 * tmp9
        tmp11 = tl.broadcast_to(tmp10, [R0_BLOCK])
        tmp13 = _tmp12 + tmp11
        _tmp12 = tl.where(r0_mask, tmp13, _tmp12)
        tl.store(in_out_ptr0 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp8, r0_mask)
    tmp12 = triton_helpers.promote_to_tensor(tl.sum(_tmp12, 0))
    tma_descriptor5 = tl.make_tensor_descriptor(in_out_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp14 = tl.load(in_ptr4 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.debug_barrier()
        tmp15 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor5.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tl.debug_barrier()
        tmp16 = tmp15.to(tl.float32)
        tmp17 = tl.full([1], 2048.0, tl.float32)
        tmp18 = (tmp12 / tmp17)
        tmp19 = tl.full([1], 1e-06, tl.float32)
        tmp20 = tmp18 + tmp19
        tmp21 = libdevice.rsqrt(tmp20)
        tmp22 = tmp16 * tmp21
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tmp14 * tmp23
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp24, r0_mask)
        tl.store(out_ptr2 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp24, r0_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v2_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-20261031/caches/inductor/g7/cg7fnd5lfban2pxbcvgqf7ocd6ep36fjpbdjlrwmx7eevo2yi7wc.py
# Topologically Sorted Source Nodes: [hidden_states_391, hidden_states_392, pow_113, variance_112, add_254, rsqrt_112, hidden_states_393, to_229, hidden_states_394], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_254 => add_338
#   hidden_states_391 => add_337
#   hidden_states_392 => convert_element_type_423
#   hidden_states_393 => mul_423
#   hidden_states_394 => mul_424
#   pow_113 => pow_113
#   rsqrt_112 => rsqrt_112
#   to_229 => convert_element_type_424
#   variance_112 => mean_112
# Graph fragment:
#   %add_334 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=add_334]
#   %buf1065 : Tensor  = PlaceHolder[target=buf1065]
#   %arg592_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg592_1]
#   %buf1066 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf1066]
#   %add_337 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_334, %empty_195), kwargs = {})
#   %convert_element_type_423 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_337, torch.float32), kwargs = {})
#   %pow_113 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_423, 2), kwargs = {})
#   %mean_112 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_113, [-1], True), kwargs = {})
#   %add_338 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_112, 1e-06), kwargs = {})
#   %rsqrt_112 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_338,), kwargs = {})
#   %mul_423 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_423, %rsqrt_112), kwargs = {})
#   %convert_element_type_424 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_423, torch.bfloat16), kwargs = {})
#   %mul_424 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg592_1, %convert_element_type_424), kwargs = {})
#   return %buf1066,%mul_424
triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19 = async_compile.triton('triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*bf16', 'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 16384}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19(in_out_ptr0, in_ptr0, in_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_out_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    _tmp6 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp3 * tmp3
        tmp5 = tl.broadcast_to(tmp4, [R0_BLOCK])
        tmp7 = _tmp6 + tmp5
        _tmp6 = tl.where(r0_mask, tmp7, _tmp6)
    tmp6 = triton_helpers.promote_to_tensor(tl.sum(_tmp6, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_out_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp8 = tl.load(in_ptr1 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp9 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp10 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp11 = tmp9 + tmp10
        tmp12 = tmp11.to(tl.float32)
        tmp13 = tl.full([1], 2048.0, tl.float32)
        tmp14 = (tmp6 / tmp13)
        tmp15 = tl.full([1], 1e-06, tl.float32)
        tmp16 = tmp14 + tmp15
        tmp17 = libdevice.rsqrt(tmp16)
        tmp18 = tmp12 * tmp17
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tmp8 * tmp19
        tl.store(in_out_ptr0 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp20, r0_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v2_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-20261031/caches/inductor/ox/cox5ywx4bkpoqdvf4k5qalg2f3p7agitfonojdx4yqxulmpit47u.py
# Topologically Sorted Source Nodes: [hidden_states_391, hidden_states_392, pow_113, variance_112, add_254, rsqrt_112, hidden_states_393, to_229, hidden_states_394, getitem_181, logits], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.slice, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   add_254 => add_338
#   getitem_181 => slice_130
#   hidden_states_391 => add_337
#   hidden_states_392 => convert_element_type_423
#   hidden_states_393 => mul_423
#   hidden_states_394 => mul_424
#   logits => mm, permute_224, view_450
#   pow_113 => pow_113
#   rsqrt_112 => rsqrt_112
#   to_229 => convert_element_type_424
#   variance_112 => mean_112
# Graph fragment:
#   %mul_424 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=mul_424]
#   %arg593_1 : Tensor "bf16[151936, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg593_1]
#   %add_337 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_334, %empty_195), kwargs = {})
#   %convert_element_type_423 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_337, torch.float32), kwargs = {})
#   %pow_113 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_423, 2), kwargs = {})
#   %mean_112 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_113, [-1], True), kwargs = {})
#   %add_338 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_112, 1e-06), kwargs = {})
#   %rsqrt_112 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_338,), kwargs = {})
#   %mul_423 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_423, %rsqrt_112), kwargs = {})
#   %convert_element_type_424 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_423, torch.bfloat16), kwargs = {})
#   %mul_424 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg592_1, %convert_element_type_424), kwargs = {})
#   %slice_130 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%mul_424, 1, -1, 9223372036854775807), kwargs = {})
#   %view_450 : Tensor "bf16[1, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%slice_130, [1, 2048]), kwargs = {})
#   %permute_224 : Tensor "bf16[2048, 151936][1, 2048]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg593_1, [1, 0]), kwargs = {})
#   %mm : Tensor "bf16[1, 151936][151936, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_450, %permute_224), kwargs = {})
#   return %mm
triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_slice_t_view_20 = async_compile.triton('triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_slice_t_view_20', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*bf16', 'arg_B': '*bf16', 'out_ptr0': '*bf16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_slice_t_view_20', 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_slice_t_view_20(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 151936
    K = 2048
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 0
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2048

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2048*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 151936*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2048*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 151936*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v2_20261031/chat-vl/r3-s2-qwen-chat-v3-vl-nohost-20261031/caches/inductor/hf/chfeoamcznn7kz2j4qxojywsndwbme3hnju66l23euwcd5ncmmsb.py
# Topologically Sorted Source Nodes: [add_], Original ATen: [aten.add, aten.copy_]
# Source node to ATen node mapping:
#   add_ => add_8
# Graph fragment:
#   %copy_ : Tensor "i64[][]tnca:0" = PlaceHolder[target=copy_]
#   %add_8 : Tensor "i64[][]tnca:0" = PlaceHolder[target=add_8]
#   %buf20 : Tensor "bf16[1, 8, 256, 128][262144, 32768, 128, 1]tnca:0" = PlaceHolder[target=buf20]
#   %any_1 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_1]
#   %amax : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax]
#   %exp : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp]
#   %buf26 : Tensor "bf16[1, 8, 256, 128][262144, 32768, 128, 1]tnca:0" = PlaceHolder[target=buf26]
#   %any_2 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_2]
#   %amax_1 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_1]
#   %exp_2 : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp_2]
#   %any_3 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_3]
#   %amax_2 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_2]
#   %exp_4 : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp_4]
#   %any_4 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_4]
#   %amax_3 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_3]
#   %exp_6 : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp_6]
#   %any_5 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_5]
#   %amax_4 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_4]
#   %exp_8 : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp_8]
#   %any_6 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_6]
#   %amax_5 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_5]
#   %exp_10 : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp_10]
#   %any_7 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_7]
#   %amax_6 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_6]
#   %exp_12 : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp_12]
#   %any_8 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_8]
#   %amax_7 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_7]
#   %exp_14 : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp_14]
#   %any_9 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_9]
#   %amax_8 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_8]
#   %exp_16 : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp_16]
#   %any_10 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_10]
#   %amax_9 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_9]
#   %exp_18 : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp_18]
#   %any_11 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_11]
#   %amax_10 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_10]
#   %exp_20 : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp_20]
#   %any_12 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_12]
#   %amax_11 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_11]
#   %exp_22 : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp_22]
#   %any_13 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_13]
#   %amax_12 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_12]
#   %exp_24 : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp_24]
#   %any_14 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_14]
#   %amax_13 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_13]
#   %exp_26 : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp_26]
#   %any_15 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_15]
#   %amax_14 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_14]
#   %exp_28 : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp_28]
#   %any_16 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_16]
#   %amax_15 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_15]
#   %exp_30 : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp_30]
#   %any_17 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_17]
#   %amax_16 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_16]
#   %exp_32 : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp_32]
#   %any_18 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_18]
#   %amax_17 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_17]
#   %exp_34 : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp_34]
#   %any_19 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_19]
#   %amax_18 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_18]
#   %exp_36 : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp_36]
#   %any_20 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_20]
#   %amax_19 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_19]
#   %exp_38 : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp_38]
#   %any_21 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_21]
#   %amax_20 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_20]
#   %exp_40 : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp_40]
#   %any_22 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_22]
#   %amax_21 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_21]
#   %exp_42 : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp_42]
#   %any_23 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_23]
#   %amax_22 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_22]
#   %exp_44 : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp_44]
#   %any_24 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_24]
#   %amax_23 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_23]
#   %exp_46 : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp_46]
#   %any_25 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_25]
#   %amax_24 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_24]
#   %exp_48 : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp_48]
#   %any_26 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_26]
#   %amax_25 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_25]
#   %exp_50 : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp_50]
#   %any_27 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_27]
#   %amax_26 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_26]
#   %exp_52 : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp_52]
#   %any_28 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_28]
#   %amax_27 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_27]
#   %exp_54 : Tensor "f32[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0" = PlaceHolder[target=exp_54]
#   %add_8 : Tensor "i64[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%arg3_1, 1), kwargs = {})
#   %copy_ : Tensor "i64[][]tnca:0"[num_users=0] = call_function[target=torch.ops.aten.copy_.default](args = (%arg3_1, %add_8), kwargs = {})
#   return %add_8,%buf1213
triton_poi_fused_add_copy__21 = async_compile.triton('triton_poi_fused_add_copy__21', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'out_ptr1': '*i64', 'xnumel': 'constexpr', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_add_copy__21', 'mutated_arg_names': ['in_ptr0', 'out_ptr1'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_copy__21(in_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK])
    tmp2 = tl.full([1], 1, tl.int64)
    tmp3 = tmp1 + tmp2
    tl.store(out_ptr1 + (tl.full([XBLOCK], 0, tl.int32).broadcast_to(XBLOCK)), tmp3, None)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1, arg123_1, arg124_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg132_1, arg133_1, arg134_1, arg135_1, arg136_1, arg137_1, arg138_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg146_1, arg147_1, arg148_1, arg149_1, arg150_1, arg151_1, arg152_1, arg153_1, arg154_1, arg155_1, arg156_1, arg157_1, arg158_1, arg159_1, arg160_1, arg161_1, arg162_1, arg163_1, arg164_1, arg165_1, arg166_1, arg167_1, arg168_1, arg169_1, arg170_1, arg171_1, arg172_1, arg173_1, arg174_1, arg175_1, arg176_1, arg177_1, arg178_1, arg179_1, arg180_1, arg181_1, arg182_1, arg183_1, arg184_1, arg185_1, arg186_1, arg187_1, arg188_1, arg189_1, arg190_1, arg191_1, arg192_1, arg193_1, arg194_1, arg195_1, arg196_1, arg197_1, arg198_1, arg199_1, arg200_1, arg201_1, arg202_1, arg203_1, arg204_1, arg205_1, arg206_1, arg207_1, arg208_1, arg209_1, arg210_1, arg211_1, arg212_1, arg213_1, arg214_1, arg215_1, arg216_1, arg217_1, arg218_1, arg219_1, arg220_1, arg221_1, arg222_1, arg223_1, arg224_1, arg225_1, arg226_1, arg227_1, arg228_1, arg229_1, arg230_1, arg231_1, arg232_1, arg233_1, arg234_1, arg235_1, arg236_1, arg237_1, arg238_1, arg239_1, arg240_1, arg241_1, arg242_1, arg243_1, arg244_1, arg245_1, arg246_1, arg247_1, arg248_1, arg249_1, arg250_1, arg251_1, arg252_1, arg253_1, arg254_1, arg255_1, arg256_1, arg257_1, arg258_1, arg259_1, arg260_1, arg261_1, arg262_1, arg263_1, arg264_1, arg265_1, arg266_1, arg267_1, arg268_1, arg269_1, arg270_1, arg271_1, arg272_1, arg273_1, arg274_1, arg275_1, arg276_1, arg277_1, arg278_1, arg279_1, arg280_1, arg281_1, arg282_1, arg283_1, arg284_1, arg285_1, arg286_1, arg287_1, arg288_1, arg289_1, arg290_1, arg291_1, arg292_1, arg293_1, arg294_1, arg295_1, arg296_1, arg297_1, arg298_1, arg299_1, arg300_1, arg301_1, arg302_1, arg303_1, arg304_1, arg305_1, arg306_1, arg307_1, arg308_1, arg309_1, arg310_1, arg311_1, arg312_1, arg313_1, arg314_1, arg315_1, arg316_1, arg317_1, arg318_1, arg319_1, arg320_1, arg321_1, arg322_1, arg323_1, arg324_1, arg325_1, arg326_1, arg327_1, arg328_1, arg329_1, arg330_1, arg331_1, arg332_1, arg333_1, arg334_1, arg335_1, arg336_1, arg337_1, arg338_1, arg339_1, arg340_1, arg341_1, arg342_1, arg343_1, arg344_1, arg345_1, arg346_1, arg347_1, arg348_1, arg349_1, arg350_1, arg351_1, arg352_1, arg353_1, arg354_1, arg355_1, arg356_1, arg357_1, arg358_1, arg359_1, arg360_1, arg361_1, arg362_1, arg363_1, arg364_1, arg365_1, arg366_1, arg367_1, arg368_1, arg369_1, arg370_1, arg371_1, arg372_1, arg373_1, arg374_1, arg375_1, arg376_1, arg377_1, arg378_1, arg379_1, arg380_1, arg381_1, arg382_1, arg383_1, arg384_1, arg385_1, arg386_1, arg387_1, arg388_1, arg389_1, arg390_1, arg391_1, arg392_1, arg393_1, arg394_1, arg395_1, arg396_1, arg397_1, arg398_1, arg399_1, arg400_1, arg401_1, arg402_1, arg403_1, arg404_1, arg405_1, arg406_1, arg407_1, arg408_1, arg409_1, arg410_1, arg411_1, arg412_1, arg413_1, arg414_1, arg415_1, arg416_1, arg417_1, arg418_1, arg419_1, arg420_1, arg421_1, arg422_1, arg423_1, arg424_1, arg425_1, arg426_1, arg427_1, arg428_1, arg429_1, arg430_1, arg431_1, arg432_1, arg433_1, arg434_1, arg435_1, arg436_1, arg437_1, arg438_1, arg439_1, arg440_1, arg441_1, arg442_1, arg443_1, arg444_1, arg445_1, arg446_1, arg447_1, arg448_1, arg449_1, arg450_1, arg451_1, arg452_1, arg453_1, arg454_1, arg455_1, arg456_1, arg457_1, arg458_1, arg459_1, arg460_1, arg461_1, arg462_1, arg463_1, arg464_1, arg465_1, arg466_1, arg467_1, arg468_1, arg469_1, arg470_1, arg471_1, arg472_1, arg473_1, arg474_1, arg475_1, arg476_1, arg477_1, arg478_1, arg479_1, arg480_1, arg481_1, arg482_1, arg483_1, arg484_1, arg485_1, arg486_1, arg487_1, arg488_1, arg489_1, arg490_1, arg491_1, arg492_1, arg493_1, arg494_1, arg495_1, arg496_1, arg497_1, arg498_1, arg499_1, arg500_1, arg501_1, arg502_1, arg503_1, arg504_1, arg505_1, arg506_1, arg507_1, arg508_1, arg509_1, arg510_1, arg511_1, arg512_1, arg513_1, arg514_1, arg515_1, arg516_1, arg517_1, arg518_1, arg519_1, arg520_1, arg521_1, arg522_1, arg523_1, arg524_1, arg525_1, arg526_1, arg527_1, arg528_1, arg529_1, arg530_1, arg531_1, arg532_1, arg533_1, arg534_1, arg535_1, arg536_1, arg537_1, arg538_1, arg539_1, arg540_1, arg541_1, arg542_1, arg543_1, arg544_1, arg545_1, arg546_1, arg547_1, arg548_1, arg549_1, arg550_1, arg551_1, arg552_1, arg553_1, arg554_1, arg555_1, arg556_1, arg557_1, arg558_1, arg559_1, arg560_1, arg561_1, arg562_1, arg563_1, arg564_1, arg565_1, arg566_1, arg567_1, arg568_1, arg569_1, arg570_1, arg571_1, arg572_1, arg573_1, arg574_1, arg575_1, arg576_1, arg577_1, arg578_1, arg579_1, arg580_1, arg581_1, arg582_1, arg583_1, arg584_1, arg585_1, arg586_1, arg587_1, arg588_1, arg589_1, arg590_1, arg591_1, arg592_1, arg593_1 = args
        args.clear()
        assert_size_stride_grouped((arg2_1, arg4_1), ((4, 1, 1), (64, )), ((1, 1, 1), (1, )), 'input')
        buf0 = empty_strided((3, 1, 1, 64), (64, 192, 192, 1), device='tnca', dtype=torch.float32)
        buf1 = empty_strided((3, 1, 1, 64), (64, 192, 192, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [position_ids, position_ids_1, getitem_6, float_1, freqs, sin_1, getitem_8, cos_1, getitem_11], Original ATen: [aten.slice, aten.expand, aten.unsqueeze, aten._to_copy, aten.mul, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_0.run(arg2_1, arg4_1, buf0, buf1, 192, stream=raw_stream0)
        del arg2_1
        del arg4_1
        assert_size_stride_grouped((arg0_1, arg1_1, arg5_1), ((1, 1), (151936, 2048), (2048, )), ((1, 1), (2048, 1), (1, )), 'input')
        buf4 = empty_strided((1, 1, 2048), (2048, 2048, 1), device='tnca', dtype=torch.bfloat16)
        buf7 = empty_strided((1, 1, 2048), (2048, 2048, 1), device='tnca', dtype=torch.bfloat16)
        buf10 = empty_strided((1, 1, 2048), (2048, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [inputs_embeds, hidden_states, pow_1, variance, add_2, rsqrt, hidden_states_1, to_5, hidden_states_2, output, output_1, output_2], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_1.run(arg0_1, arg1_1, arg5_1, buf4, buf7, buf10, 1, 2048, stream=raw_stream0)
        del arg5_1
        buf3 = empty_strided((1, 1, 2048), (2048, 2048, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg6_1, arg7_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [inputs_embeds, hidden_states, pow_1, variance, add_2, rsqrt, hidden_states_1, to_5, hidden_states_2, output], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf4, arg6_1, buf3, arg7_1, 1, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg6_1
        del arg7_1
        buf6 = empty_strided((1, 1, 1024), (1024, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg9_1, arg10_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [inputs_embeds, hidden_states, pow_1, variance, add_2, rsqrt, hidden_states_1, to_5, hidden_states_2, output_1], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf7, arg9_1, buf6, arg10_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg10_1
        del arg9_1
        buf9 = empty_strided((1, 1, 1024), (1024, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg12_1, arg13_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [inputs_embeds, hidden_states, pow_1, variance, add_2, rsqrt, hidden_states_1, to_5, hidden_states_2, output_2], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf10, arg12_1, buf9, arg13_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg12_1
        del arg13_1
        buf12 = empty_strided((1, 1, 16, 1), (16, 16, 1, 16), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_3, pow_2, variance_1], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf3, buf12, 16, 128, stream=raw_stream0)
        assert_size_stride(arg8_1, (128, ), (1, ), 'input')
        buf15 = reinterpret_tensor(buf10, (1, 16, 1, 128), (2048, 128, 128, 1), 0); del buf10  # reuse
        buf13 = reinterpret_tensor(buf15, (1, 16, 1, 64), (2048, 128, 128, 1), 0)  # alias
        buf14 = reinterpret_tensor(buf15, (1, 16, 1, 64), (2048, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_3, pow_2, variance_1, add_3, rsqrt_1, hidden_states_4, to_7, mul_6, query_states, x2, neg, x1, cat_2], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg8_1, buf3, buf12, buf13, buf14, 1024, stream=raw_stream0)
        buf16 = empty_strided((1, 1, 8, 1), (8, 8, 1, 8), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_5, pow_3, variance_2], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf6, buf16, 8, 128, stream=raw_stream0)
        del buf13
        del buf14
        assert_size_stride(arg11_1, (128, ), (1, ), 'input')
        buf19 = empty_strided((1, 8, 1, 128), (1024, 128, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf17 = reinterpret_tensor(buf19, (1, 8, 1, 64), (1024, 128, 128, 1), 0)  # alias
        buf18 = reinterpret_tensor(buf19, (1, 8, 1, 64), (1024, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_5, pow_3, variance_2, add_4, rsqrt_2, hidden_states_6, to_9, mul_8, key_states, x2_1, neg_1, x1_1, cat_3], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg11_1, buf6, buf16, buf17, buf18, 512, stream=raw_stream0)
        assert_size_stride_grouped((arg3_1, arg14_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, cos_4, setitem_1, sin_2, sin_3, sin_4, arange_4, cache_position, hidden_states_5, pow_3, variance_2, add_4, rsqrt_2, hidden_states_6, to_9, mul_8, key_states, mul_11, mul_12, k_embed, index_copy_], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg3_1, arg11_1, buf6, buf16, buf1, buf19, buf0, arg14_1, 1024, stream=raw_stream0)
        del arg11_1
        del buf17
        del buf18
        buf21 = empty_strided((16, 1, 256), (256, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [hidden_states_3, pow_2, variance_1, add_3, rsqrt_1, hidden_states_4, to_7, mul_6, query_states, setitem_3, cos_2, cos_3, cos_4, mul_9, setitem_1, sin_2, sin_3, sin_4, mul_10, q_embed, attn_output, key], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.select, aten.slice, aten.cat, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg8_1, buf3, buf12, buf1, buf15, buf0, arg14_1, buf21, 4096, 128, stream=raw_stream0)
        del arg14_1
        del arg8_1
        buf22 = empty_strided((1, 16, 1, 1), (16, 1, 16, 16), device='tnca', dtype=torch.bool)
        buf24 = empty_strided((1, 16, 1, 256), (4096, 256, 4096, 1), device='tnca', dtype=torch.float32)
        buf25 = reinterpret_tensor(buf12, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf12  # reuse
        # Topologically Sorted Source Nodes: [attn_output, kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8.run(buf21, arg3_1, buf22, buf24, buf25, 16, 256, stream=raw_stream0)
        assert_size_stride(arg15_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_4, cache_position, index_copy__1], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_9.run(arg3_1, buf9, arg15_1, 1024, stream=raw_stream0)
        buf29 = reinterpret_tensor(buf3, (1, 1, 2048), (2048, 128, 1), 0); del buf3  # reuse
        # Topologically Sorted Source Nodes: [attn_output, value, transpose_3, reshape_2, output_3], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf22, buf24, buf25, arg15_1, buf29, 2048, 256, stream=raw_stream0)
        del arg15_1
        buf28 = reinterpret_tensor(buf15, (1, 1, 2048), (2048, 2048, 1), 0); del buf15  # reuse
        assert_size_stride_grouped((arg16_1, arg17_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output, transpose_3, reshape_2, output_3], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf29, arg16_1, buf28, arg17_1, 1, 2048, 2048, 128, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg16_1
        del arg17_1
        assert_size_stride(arg18_1, (2048, ), (1, ), 'input')
        buf32 = reinterpret_tensor(buf29, (1, 1, 2048), (2048, 2048, 1), 0); del buf29  # reuse
        # Topologically Sorted Source Nodes: [inputs_embeds, hidden_states_9, hidden_states_10, pow_4, variance_3, add_9, rsqrt_3, hidden_states_11, to_11, hidden_states_12], Original ATen: [aten.embedding, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_11.run(arg0_1, arg1_1, buf28, arg18_1, buf32, 1, 2048, stream=raw_stream0)
        del arg18_1
        buf33 = empty_strided((1, 1, 6144), (6144, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg19_1, arg20_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_4], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf32, arg19_1, buf33, arg20_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg19_1
        del arg20_1
        buf35 = empty_strided((1, 1, 6144), (6144, 6144, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg21_1, arg22_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_5], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf32, arg21_1, buf35, arg22_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg21_1
        del arg22_1
        buf37 = buf32; del buf32  # reuse
        buf38 = empty_strided((1, 1, 6144), (6144, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu, mul_15, output_6], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_12.run(buf33, buf35, buf38, 6144, stream=raw_stream0)
        assert_size_stride_grouped((arg23_1, arg24_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu, mul_15, output_6], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf38, arg23_1, buf37, arg24_1, 1, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg23_1
        del arg24_1
        assert_size_stride(arg25_1, (2048, ), (1, ), 'input')
        buf41 = buf7; del buf7  # reuse
        # Topologically Sorted Source Nodes: [inputs_embeds, hidden_states_9, hidden_states_13, hidden_states_14, pow_5, variance_4, add_11, rsqrt_4, hidden_states_15, to_13, hidden_states_16], Original ATen: [aten.embedding, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_13.run(arg0_1, arg1_1, buf28, buf37, arg25_1, buf41, 1, 2048, stream=raw_stream0)
        del arg25_1
        buf42 = buf4; del buf4  # reuse
        assert_size_stride_grouped((arg26_1, arg27_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_7], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf41, arg26_1, buf42, arg27_1, 1, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg26_1
        del arg27_1
        buf44 = buf9; del buf9  # reuse
        assert_size_stride_grouped((arg29_1, arg30_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_8], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf41, arg29_1, buf44, arg30_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg29_1
        del arg30_1
        buf46 = buf6; del buf6  # reuse
        assert_size_stride_grouped((arg32_1, arg33_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_9], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf41, arg32_1, buf46, arg33_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg32_1
        del arg33_1
        buf48 = reinterpret_tensor(buf25, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf25  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_17, pow_6, variance_5], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf42, buf48, 16, 128, stream=raw_stream0)
        assert_size_stride(arg28_1, (128, ), (1, ), 'input')
        buf51 = reinterpret_tensor(buf41, (1, 16, 1, 128), (2048, 128, 128, 1), 0); del buf41  # reuse
        buf49 = reinterpret_tensor(buf51, (1, 16, 1, 64), (2048, 128, 128, 1), 0)  # alias
        buf50 = reinterpret_tensor(buf51, (1, 16, 1, 64), (2048, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_17, pow_6, variance_5, add_12, rsqrt_5, hidden_states_18, to_15, mul_19, query_states_1, x2_2, neg_2, x1_2, cat_4], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg28_1, buf42, buf48, buf49, buf50, 1024, stream=raw_stream0)
        buf52 = buf16; del buf16  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_19, pow_7, variance_6], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf44, buf52, 8, 128, stream=raw_stream0)
        del buf49
        del buf50
        assert_size_stride(arg31_1, (128, ), (1, ), 'input')
        buf55 = buf19; del buf19  # reuse
        buf53 = reinterpret_tensor(buf55, (1, 8, 1, 64), (1024, 128, 128, 1), 0)  # alias
        buf54 = reinterpret_tensor(buf55, (1, 8, 1, 64), (1024, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_19, pow_7, variance_6, add_13, rsqrt_6, hidden_states_20, to_17, mul_21, key_states_1, x2_3, neg_3, x1_3, cat_5], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg31_1, buf44, buf52, buf53, buf54, 512, stream=raw_stream0)
        assert_size_stride_grouped((arg34_1, arg35_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_5, sin_5, arange_5, cache_position_1, hidden_states_19, pow_7, variance_6, add_13, rsqrt_6, hidden_states_20, to_17, mul_21, key_states_1, mul_24, mul_25, k_embed_1, index_copy__2], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg34_1, arg31_1, buf44, buf52, buf1, buf55, buf0, arg35_1, 1024, stream=raw_stream0)
        del arg31_1
        del buf53
        del buf54
        buf57 = reinterpret_tensor(buf24, (16, 1, 256), (256, 256, 1), 0); del buf24  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_17, pow_6, variance_5, add_12, rsqrt_5, hidden_states_18, to_15, mul_19, query_states_1, cos_5, mul_22, sin_5, mul_23, q_embed_1, attn_output_3, key_1], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg28_1, buf42, buf48, buf1, buf51, buf0, arg35_1, buf57, 4096, 128, stream=raw_stream0)
        del arg28_1
        del arg35_1
        buf58 = buf22; del buf22  # reuse
        buf60 = reinterpret_tensor(buf21, (1, 16, 1, 256), (4096, 256, 4096, 1), 0); del buf21  # reuse
        buf61 = reinterpret_tensor(buf48, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf48  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_3], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8.run(buf57, arg3_1, buf58, buf60, buf61, 16, 256, stream=raw_stream0)
        assert_size_stride(arg36_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_5, cache_position_1, index_copy__3], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_9.run(arg34_1, buf46, arg36_1, 1024, stream=raw_stream0)
        buf65 = reinterpret_tensor(buf51, (1, 1, 2048), (2048, 128, 1), 0); del buf51  # reuse
        # Topologically Sorted Source Nodes: [attn_output_3, value_1, transpose_7, reshape_5, output_10], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf58, buf60, buf61, arg36_1, buf65, 2048, 256, stream=raw_stream0)
        del arg36_1
        buf64 = buf42; del buf42  # reuse
        assert_size_stride_grouped((arg37_1, arg38_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_3, transpose_7, reshape_5, output_10], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf65, arg37_1, buf64, arg38_1, 1, 2048, 2048, 128, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg37_1
        del arg38_1
        assert_size_stride(arg39_1, (2048, ), (1, ), 'input')
        buf67 = reinterpret_tensor(buf65, (1, 1, 2048), (2048, 2048, 1), 0); del buf65  # reuse
        buf70 = empty_strided((1, 1, 2048), (2048, 2048, 1), device='tnca', dtype=torch.bfloat16)
        buf73 = empty_strided((1, 1, 2048), (2048, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [inputs_embeds, hidden_states_9, hidden_states_13, hidden_states_23, hidden_states_24, pow_8, variance_7, add_18, rsqrt_7, hidden_states_25, to_19, hidden_states_26, output_11, output_12], Original ATen: [aten.embedding, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_14.run(arg0_1, arg1_1, buf28, buf37, buf64, arg39_1, buf67, buf70, buf73, 1, 2048, stream=raw_stream0)
        del arg0_1
        del arg1_1
        del arg39_1
        buf69 = buf38; del buf38  # reuse
        assert_size_stride_grouped((arg40_1, arg41_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_24, pow_8, variance_7, add_18, rsqrt_7, hidden_states_25, to_19, hidden_states_26, output_11], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf70, arg40_1, buf69, arg41_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg40_1
        del arg41_1
        buf72 = buf35; del buf35  # reuse
        assert_size_stride_grouped((arg42_1, arg43_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_24, pow_8, variance_7, add_18, rsqrt_7, hidden_states_25, to_19, hidden_states_26, output_12], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf73, arg42_1, buf72, arg43_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg42_1
        del arg43_1
        buf75 = buf73; del buf73  # reuse
        buf76 = buf33; del buf33  # reuse
        # Topologically Sorted Source Nodes: [silu_1, mul_28, output_13], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_12.run(buf69, buf72, buf76, 6144, stream=raw_stream0)
        assert_size_stride_grouped((arg44_1, arg45_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_1, mul_28, output_13], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf76, arg44_1, buf75, arg45_1, 1, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg44_1
        del arg45_1
        assert_size_stride(arg46_1, (2048, ), (1, ), 'input')
        buf80 = buf70; del buf70  # reuse
        buf83 = buf64; del buf64  # reuse
        buf86 = buf37; del buf37  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_27, hidden_states_28, pow_9, variance_8, add_20, rsqrt_8, hidden_states_29, to_21, hidden_states_30, output_14, output_15, output_16], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_15.run(buf67, buf75, arg46_1, buf80, buf83, buf86, 1, 2048, stream=raw_stream0)
        del arg46_1
        buf79 = buf28; del buf28  # reuse
        assert_size_stride_grouped((arg47_1, arg48_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_27, hidden_states_28, pow_9, variance_8, add_20, rsqrt_8, hidden_states_29, to_21, hidden_states_30, output_14], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf80, arg47_1, buf79, arg48_1, 1, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg47_1
        del arg48_1
        buf82 = buf46; del buf46  # reuse
        assert_size_stride_grouped((arg50_1, arg51_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_27, hidden_states_28, pow_9, variance_8, add_20, rsqrt_8, hidden_states_29, to_21, hidden_states_30, output_15], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf83, arg50_1, buf82, arg51_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg50_1
        del arg51_1
        buf85 = reinterpret_tensor(buf55, (1, 1, 1024), (1024, 1024, 1), 0); del buf55  # reuse
        assert_size_stride_grouped((arg53_1, arg54_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_27, hidden_states_28, pow_9, variance_8, add_20, rsqrt_8, hidden_states_29, to_21, hidden_states_30, output_16], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf86, arg53_1, buf85, arg54_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg53_1
        del arg54_1
        buf88 = reinterpret_tensor(buf61, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf61  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_31, pow_10, variance_9], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf79, buf88, 16, 128, stream=raw_stream0)
        assert_size_stride(arg49_1, (128, ), (1, ), 'input')
        buf91 = reinterpret_tensor(buf86, (1, 16, 1, 128), (2048, 128, 128, 1), 0); del buf86  # reuse
        buf89 = reinterpret_tensor(buf91, (1, 16, 1, 64), (2048, 128, 128, 1), 0)  # alias
        buf90 = reinterpret_tensor(buf91, (1, 16, 1, 64), (2048, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_31, pow_10, variance_9, add_21, rsqrt_9, hidden_states_32, to_23, mul_32, query_states_2, x2_4, neg_4, x1_4, cat_6], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg49_1, buf79, buf88, buf89, buf90, 1024, stream=raw_stream0)
        buf92 = buf52; del buf52  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_33, pow_11, variance_10], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf82, buf92, 8, 128, stream=raw_stream0)
        del buf89
        del buf90
        assert_size_stride(arg52_1, (128, ), (1, ), 'input')
        buf95 = reinterpret_tensor(buf44, (1, 8, 1, 128), (1024, 128, 128, 1), 0); del buf44  # reuse
        buf93 = reinterpret_tensor(buf95, (1, 8, 1, 64), (1024, 128, 128, 1), 0)  # alias
        buf94 = reinterpret_tensor(buf95, (1, 8, 1, 64), (1024, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_33, pow_11, variance_10, add_22, rsqrt_10, hidden_states_34, to_25, mul_34, key_states_2, x2_5, neg_5, x1_5, cat_7], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg52_1, buf82, buf92, buf93, buf94, 512, stream=raw_stream0)
        assert_size_stride_grouped((arg55_1, arg56_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_6, sin_6, arange_6, cache_position_2, hidden_states_33, pow_11, variance_10, add_22, rsqrt_10, hidden_states_34, to_25, mul_34, key_states_2, mul_37, mul_38, k_embed_2, index_copy__4], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg55_1, arg52_1, buf82, buf92, buf1, buf95, buf0, arg56_1, 1024, stream=raw_stream0)
        del arg52_1
        del buf93
        del buf94
        buf97 = reinterpret_tensor(buf60, (16, 1, 256), (256, 256, 1), 0); del buf60  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_31, pow_10, variance_9, add_21, rsqrt_9, hidden_states_32, to_23, mul_32, query_states_2, cos_6, mul_35, sin_6, mul_36, q_embed_2, attn_output_6, key_2], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg49_1, buf79, buf88, buf1, buf91, buf0, arg56_1, buf97, 4096, 128, stream=raw_stream0)
        del arg49_1
        del arg56_1
        buf98 = buf58; del buf58  # reuse
        buf100 = reinterpret_tensor(buf57, (1, 16, 1, 256), (4096, 256, 4096, 1), 0); del buf57  # reuse
        buf101 = reinterpret_tensor(buf88, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf88  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_6], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8.run(buf97, arg3_1, buf98, buf100, buf101, 16, 256, stream=raw_stream0)
        assert_size_stride(arg57_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_6, cache_position_2, index_copy__5], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_9.run(arg55_1, buf85, arg57_1, 1024, stream=raw_stream0)
        buf105 = reinterpret_tensor(buf91, (1, 1, 2048), (2048, 128, 1), 0); del buf91  # reuse
        # Topologically Sorted Source Nodes: [attn_output_6, value_2, transpose_11, reshape_8, output_17], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf98, buf100, buf101, arg57_1, buf105, 2048, 256, stream=raw_stream0)
        del arg57_1
        buf104 = buf79; del buf79  # reuse
        assert_size_stride_grouped((arg58_1, arg59_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_6, transpose_11, reshape_8, output_17], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf105, arg58_1, buf104, arg59_1, 1, 2048, 2048, 128, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg58_1
        del arg59_1
        assert_size_stride(arg60_1, (2048, ), (1, ), 'input')
        buf108 = reinterpret_tensor(buf105, (1, 1, 2048), (2048, 2048, 1), 0); del buf105  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_27, hidden_states_37, hidden_states_38, pow_12, variance_11, add_27, rsqrt_11, hidden_states_39, to_27, hidden_states_40], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_16.run(buf67, buf75, buf104, arg60_1, buf108, 1, 2048, stream=raw_stream0)
        del arg60_1
        buf109 = buf76; del buf76  # reuse
        assert_size_stride_grouped((arg61_1, arg62_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_18], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf108, arg61_1, buf109, arg62_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg61_1
        del arg62_1
        buf111 = buf72; del buf72  # reuse
        assert_size_stride_grouped((arg63_1, arg64_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_19], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf108, arg63_1, buf111, arg64_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg63_1
        del arg64_1
        buf113 = buf108; del buf108  # reuse
        buf114 = buf69; del buf69  # reuse
        # Topologically Sorted Source Nodes: [silu_2, mul_41, output_20], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_12.run(buf109, buf111, buf114, 6144, stream=raw_stream0)
        assert_size_stride_grouped((arg65_1, arg66_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_2, mul_41, output_20], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf114, arg65_1, buf113, arg66_1, 1, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg65_1
        del arg66_1
        assert_size_stride(arg67_1, (2048, ), (1, ), 'input')
        buf117 = buf83; del buf83  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_27, hidden_states_37, hidden_states_41, hidden_states_42, pow_13, variance_12, add_29, rsqrt_12, hidden_states_43, to_29, hidden_states_44], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_17.run(buf67, buf75, buf104, buf113, arg67_1, buf117, 1, 2048, stream=raw_stream0)
        del arg67_1
        buf118 = buf80; del buf80  # reuse
        assert_size_stride_grouped((arg68_1, arg69_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_21], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf117, arg68_1, buf118, arg69_1, 1, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg68_1
        del arg69_1
        buf120 = buf85; del buf85  # reuse
        assert_size_stride_grouped((arg71_1, arg72_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_22], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf117, arg71_1, buf120, arg72_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg71_1
        del arg72_1
        buf122 = reinterpret_tensor(buf95, (1, 1, 1024), (1024, 1024, 1), 0); del buf95  # reuse
        assert_size_stride_grouped((arg74_1, arg75_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_23], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf117, arg74_1, buf122, arg75_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg74_1
        del arg75_1
        buf124 = reinterpret_tensor(buf101, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf101  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_45, pow_14, variance_13], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf118, buf124, 16, 128, stream=raw_stream0)
        assert_size_stride(arg70_1, (128, ), (1, ), 'input')
        buf127 = reinterpret_tensor(buf117, (1, 16, 1, 128), (2048, 128, 128, 1), 0); del buf117  # reuse
        buf125 = reinterpret_tensor(buf127, (1, 16, 1, 64), (2048, 128, 128, 1), 0)  # alias
        buf126 = reinterpret_tensor(buf127, (1, 16, 1, 64), (2048, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_45, pow_14, variance_13, add_30, rsqrt_13, hidden_states_46, to_31, mul_45, query_states_3, x2_6, neg_6, x1_6, cat_8], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg70_1, buf118, buf124, buf125, buf126, 1024, stream=raw_stream0)
        buf128 = buf92; del buf92  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_47, pow_15, variance_14], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf120, buf128, 8, 128, stream=raw_stream0)
        del buf125
        del buf126
        assert_size_stride(arg73_1, (128, ), (1, ), 'input')
        buf131 = reinterpret_tensor(buf82, (1, 8, 1, 128), (1024, 128, 128, 1), 0); del buf82  # reuse
        buf129 = reinterpret_tensor(buf131, (1, 8, 1, 64), (1024, 128, 128, 1), 0)  # alias
        buf130 = reinterpret_tensor(buf131, (1, 8, 1, 64), (1024, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_47, pow_15, variance_14, add_31, rsqrt_14, hidden_states_48, to_33, mul_47, key_states_3, x2_7, neg_7, x1_7, cat_9], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg73_1, buf120, buf128, buf129, buf130, 512, stream=raw_stream0)
        assert_size_stride_grouped((arg76_1, arg77_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_7, sin_7, arange_7, cache_position_3, hidden_states_47, pow_15, variance_14, add_31, rsqrt_14, hidden_states_48, to_33, mul_47, key_states_3, mul_50, mul_51, k_embed_3, index_copy__6], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg76_1, arg73_1, buf120, buf128, buf1, buf131, buf0, arg77_1, 1024, stream=raw_stream0)
        del arg73_1
        del buf129
        del buf130
        buf133 = reinterpret_tensor(buf100, (16, 1, 256), (256, 256, 1), 0); del buf100  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_45, pow_14, variance_13, add_30, rsqrt_13, hidden_states_46, to_31, mul_45, query_states_3, cos_7, mul_48, sin_7, mul_49, q_embed_3, attn_output_9, key_3], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg70_1, buf118, buf124, buf1, buf127, buf0, arg77_1, buf133, 4096, 128, stream=raw_stream0)
        del arg70_1
        del arg77_1
        buf134 = buf98; del buf98  # reuse
        buf136 = reinterpret_tensor(buf97, (1, 16, 1, 256), (4096, 256, 4096, 1), 0); del buf97  # reuse
        buf137 = reinterpret_tensor(buf124, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf124  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_9], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8.run(buf133, arg3_1, buf134, buf136, buf137, 16, 256, stream=raw_stream0)
        assert_size_stride(arg78_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_7, cache_position_3, index_copy__7], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_9.run(arg76_1, buf122, arg78_1, 1024, stream=raw_stream0)
        buf141 = reinterpret_tensor(buf127, (1, 1, 2048), (2048, 128, 1), 0); del buf127  # reuse
        # Topologically Sorted Source Nodes: [attn_output_9, value_3, transpose_15, reshape_11, output_24], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf134, buf136, buf137, arg78_1, buf141, 2048, 256, stream=raw_stream0)
        del arg78_1
        buf140 = buf118; del buf118  # reuse
        assert_size_stride_grouped((arg79_1, arg80_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_9, transpose_15, reshape_11, output_24], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf141, arg79_1, buf140, arg80_1, 1, 2048, 2048, 128, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg79_1
        del arg80_1
        assert_size_stride(arg81_1, (2048, ), (1, ), 'input')
        buf143 = buf67; del buf67  # reuse
        buf146 = reinterpret_tensor(buf141, (1, 1, 2048), (2048, 2048, 1), 0); del buf141  # reuse
        buf149 = empty_strided((1, 1, 2048), (2048, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_27, hidden_states_37, hidden_states_41, hidden_states_51, hidden_states_52, pow_16, variance_15, add_36, rsqrt_15, hidden_states_53, to_35, hidden_states_54, output_25, output_26], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_18.run(buf143, buf75, buf104, buf113, buf140, arg81_1, buf146, buf149, 1, 2048, stream=raw_stream0)
        del arg81_1
        buf145 = buf114; del buf114  # reuse
        assert_size_stride_grouped((arg82_1, arg83_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_52, pow_16, variance_15, add_36, rsqrt_15, hidden_states_53, to_35, hidden_states_54, output_25], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf146, arg82_1, buf145, arg83_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg82_1
        del arg83_1
        buf148 = buf111; del buf111  # reuse
        assert_size_stride_grouped((arg84_1, arg85_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_52, pow_16, variance_15, add_36, rsqrt_15, hidden_states_53, to_35, hidden_states_54, output_26], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf149, arg84_1, buf148, arg85_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg84_1
        del arg85_1
        buf151 = buf149; del buf149  # reuse
        buf152 = buf109; del buf109  # reuse
        # Topologically Sorted Source Nodes: [silu_3, mul_54, output_27], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_12.run(buf145, buf148, buf152, 6144, stream=raw_stream0)
        assert_size_stride_grouped((arg86_1, arg87_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_3, mul_54, output_27], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf152, arg86_1, buf151, arg87_1, 1, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg86_1
        del arg87_1
        assert_size_stride(arg88_1, (2048, ), (1, ), 'input')
        buf156 = buf146; del buf146  # reuse
        buf159 = buf75; del buf75  # reuse
        buf162 = buf140; del buf140  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_55, hidden_states_56, pow_17, variance_16, add_38, rsqrt_16, hidden_states_57, to_37, hidden_states_58, output_28, output_29, output_30], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_15.run(buf143, buf151, arg88_1, buf156, buf159, buf162, 1, 2048, stream=raw_stream0)
        del arg88_1
        buf155 = buf113; del buf113  # reuse
        assert_size_stride_grouped((arg89_1, arg90_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_55, hidden_states_56, pow_17, variance_16, add_38, rsqrt_16, hidden_states_57, to_37, hidden_states_58, output_28], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf156, arg89_1, buf155, arg90_1, 1, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg89_1
        del arg90_1
        buf158 = buf122; del buf122  # reuse
        assert_size_stride_grouped((arg92_1, arg93_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_55, hidden_states_56, pow_17, variance_16, add_38, rsqrt_16, hidden_states_57, to_37, hidden_states_58, output_29], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf159, arg92_1, buf158, arg93_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg92_1
        del arg93_1
        buf161 = reinterpret_tensor(buf131, (1, 1, 1024), (1024, 1024, 1), 0); del buf131  # reuse
        assert_size_stride_grouped((arg95_1, arg96_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_55, hidden_states_56, pow_17, variance_16, add_38, rsqrt_16, hidden_states_57, to_37, hidden_states_58, output_30], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf162, arg95_1, buf161, arg96_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg95_1
        del arg96_1
        buf164 = reinterpret_tensor(buf137, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf137  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_59, pow_18, variance_17], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf155, buf164, 16, 128, stream=raw_stream0)
        assert_size_stride(arg91_1, (128, ), (1, ), 'input')
        buf167 = reinterpret_tensor(buf162, (1, 16, 1, 128), (2048, 128, 128, 1), 0); del buf162  # reuse
        buf165 = reinterpret_tensor(buf167, (1, 16, 1, 64), (2048, 128, 128, 1), 0)  # alias
        buf166 = reinterpret_tensor(buf167, (1, 16, 1, 64), (2048, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_59, pow_18, variance_17, add_39, rsqrt_17, hidden_states_60, to_39, mul_58, query_states_4, x2_8, neg_8, x1_8, cat_10], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg91_1, buf155, buf164, buf165, buf166, 1024, stream=raw_stream0)
        buf168 = buf128; del buf128  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_61, pow_19, variance_18], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf158, buf168, 8, 128, stream=raw_stream0)
        del buf165
        del buf166
        assert_size_stride(arg94_1, (128, ), (1, ), 'input')
        buf171 = reinterpret_tensor(buf120, (1, 8, 1, 128), (1024, 128, 128, 1), 0); del buf120  # reuse
        buf169 = reinterpret_tensor(buf171, (1, 8, 1, 64), (1024, 128, 128, 1), 0)  # alias
        buf170 = reinterpret_tensor(buf171, (1, 8, 1, 64), (1024, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_61, pow_19, variance_18, add_40, rsqrt_18, hidden_states_62, to_41, mul_60, key_states_4, x2_9, neg_9, x1_9, cat_11], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg94_1, buf158, buf168, buf169, buf170, 512, stream=raw_stream0)
        assert_size_stride_grouped((arg97_1, arg98_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_8, sin_8, arange_8, cache_position_4, hidden_states_61, pow_19, variance_18, add_40, rsqrt_18, hidden_states_62, to_41, mul_60, key_states_4, mul_63, mul_64, k_embed_4, index_copy__8], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg97_1, arg94_1, buf158, buf168, buf1, buf171, buf0, arg98_1, 1024, stream=raw_stream0)
        del arg94_1
        del buf169
        del buf170
        buf173 = reinterpret_tensor(buf136, (16, 1, 256), (256, 256, 1), 0); del buf136  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_59, pow_18, variance_17, add_39, rsqrt_17, hidden_states_60, to_39, mul_58, query_states_4, cos_8, mul_61, sin_8, mul_62, q_embed_4, attn_output_12, key_4], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg91_1, buf155, buf164, buf1, buf167, buf0, arg98_1, buf173, 4096, 128, stream=raw_stream0)
        del arg91_1
        del arg98_1
        buf174 = buf134; del buf134  # reuse
        buf176 = reinterpret_tensor(buf133, (1, 16, 1, 256), (4096, 256, 4096, 1), 0); del buf133  # reuse
        buf177 = reinterpret_tensor(buf164, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf164  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_12], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8.run(buf173, arg3_1, buf174, buf176, buf177, 16, 256, stream=raw_stream0)
        assert_size_stride(arg99_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_8, cache_position_4, index_copy__9], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_9.run(arg97_1, buf161, arg99_1, 1024, stream=raw_stream0)
        buf181 = reinterpret_tensor(buf167, (1, 1, 2048), (2048, 128, 1), 0); del buf167  # reuse
        # Topologically Sorted Source Nodes: [attn_output_12, value_4, transpose_19, reshape_14, output_31], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf174, buf176, buf177, arg99_1, buf181, 2048, 256, stream=raw_stream0)
        del arg99_1
        buf180 = buf155; del buf155  # reuse
        assert_size_stride_grouped((arg100_1, arg101_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_12, transpose_19, reshape_14, output_31], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf181, arg100_1, buf180, arg101_1, 1, 2048, 2048, 128, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg100_1
        del arg101_1
        assert_size_stride(arg102_1, (2048, ), (1, ), 'input')
        buf184 = reinterpret_tensor(buf181, (1, 1, 2048), (2048, 2048, 1), 0); del buf181  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_55, hidden_states_65, hidden_states_66, pow_20, variance_19, add_45, rsqrt_19, hidden_states_67, to_43, hidden_states_68], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_16.run(buf143, buf151, buf180, arg102_1, buf184, 1, 2048, stream=raw_stream0)
        del arg102_1
        buf185 = buf152; del buf152  # reuse
        assert_size_stride_grouped((arg103_1, arg104_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_32], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf184, arg103_1, buf185, arg104_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg103_1
        del arg104_1
        buf187 = buf148; del buf148  # reuse
        assert_size_stride_grouped((arg105_1, arg106_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_33], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf184, arg105_1, buf187, arg106_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg105_1
        del arg106_1
        buf189 = buf184; del buf184  # reuse
        buf190 = buf145; del buf145  # reuse
        # Topologically Sorted Source Nodes: [silu_4, mul_67, output_34], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_12.run(buf185, buf187, buf190, 6144, stream=raw_stream0)
        assert_size_stride_grouped((arg107_1, arg108_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_4, mul_67, output_34], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf190, arg107_1, buf189, arg108_1, 1, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg107_1
        del arg108_1
        assert_size_stride(arg109_1, (2048, ), (1, ), 'input')
        buf193 = buf159; del buf159  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_55, hidden_states_65, hidden_states_69, hidden_states_70, pow_21, variance_20, add_47, rsqrt_20, hidden_states_71, to_45, hidden_states_72], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_17.run(buf143, buf151, buf180, buf189, arg109_1, buf193, 1, 2048, stream=raw_stream0)
        del arg109_1
        buf194 = buf156; del buf156  # reuse
        assert_size_stride_grouped((arg110_1, arg111_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_35], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf193, arg110_1, buf194, arg111_1, 1, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg110_1
        del arg111_1
        buf196 = buf161; del buf161  # reuse
        assert_size_stride_grouped((arg113_1, arg114_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_36], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf193, arg113_1, buf196, arg114_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg113_1
        del arg114_1
        buf198 = reinterpret_tensor(buf171, (1, 1, 1024), (1024, 1024, 1), 0); del buf171  # reuse
        assert_size_stride_grouped((arg116_1, arg117_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_37], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf193, arg116_1, buf198, arg117_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg116_1
        del arg117_1
        buf200 = reinterpret_tensor(buf177, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf177  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_73, pow_22, variance_21], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf194, buf200, 16, 128, stream=raw_stream0)
        assert_size_stride(arg112_1, (128, ), (1, ), 'input')
        buf203 = reinterpret_tensor(buf193, (1, 16, 1, 128), (2048, 128, 128, 1), 0); del buf193  # reuse
        buf201 = reinterpret_tensor(buf203, (1, 16, 1, 64), (2048, 128, 128, 1), 0)  # alias
        buf202 = reinterpret_tensor(buf203, (1, 16, 1, 64), (2048, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_73, pow_22, variance_21, add_48, rsqrt_21, hidden_states_74, to_47, mul_71, query_states_5, x2_10, neg_10, x1_10, cat_12], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg112_1, buf194, buf200, buf201, buf202, 1024, stream=raw_stream0)
        buf204 = buf168; del buf168  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_75, pow_23, variance_22], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf196, buf204, 8, 128, stream=raw_stream0)
        del buf201
        del buf202
        assert_size_stride(arg115_1, (128, ), (1, ), 'input')
        buf207 = reinterpret_tensor(buf158, (1, 8, 1, 128), (1024, 128, 128, 1), 0); del buf158  # reuse
        buf205 = reinterpret_tensor(buf207, (1, 8, 1, 64), (1024, 128, 128, 1), 0)  # alias
        buf206 = reinterpret_tensor(buf207, (1, 8, 1, 64), (1024, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_75, pow_23, variance_22, add_49, rsqrt_22, hidden_states_76, to_49, mul_73, key_states_5, x2_11, neg_11, x1_11, cat_13], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg115_1, buf196, buf204, buf205, buf206, 512, stream=raw_stream0)
        assert_size_stride_grouped((arg118_1, arg119_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_9, sin_9, arange_9, cache_position_5, hidden_states_75, pow_23, variance_22, add_49, rsqrt_22, hidden_states_76, to_49, mul_73, key_states_5, mul_76, mul_77, k_embed_5, index_copy__10], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg118_1, arg115_1, buf196, buf204, buf1, buf207, buf0, arg119_1, 1024, stream=raw_stream0)
        del arg115_1
        del buf205
        del buf206
        buf209 = reinterpret_tensor(buf176, (16, 1, 256), (256, 256, 1), 0); del buf176  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_73, pow_22, variance_21, add_48, rsqrt_21, hidden_states_74, to_47, mul_71, query_states_5, cos_9, mul_74, sin_9, mul_75, q_embed_5, attn_output_15, key_5], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg112_1, buf194, buf200, buf1, buf203, buf0, arg119_1, buf209, 4096, 128, stream=raw_stream0)
        del arg112_1
        del arg119_1
        buf210 = buf174; del buf174  # reuse
        buf212 = reinterpret_tensor(buf173, (1, 16, 1, 256), (4096, 256, 4096, 1), 0); del buf173  # reuse
        buf213 = reinterpret_tensor(buf200, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf200  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_15], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8.run(buf209, arg3_1, buf210, buf212, buf213, 16, 256, stream=raw_stream0)
        assert_size_stride(arg120_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_9, cache_position_5, index_copy__11], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_9.run(arg118_1, buf198, arg120_1, 1024, stream=raw_stream0)
        buf217 = reinterpret_tensor(buf203, (1, 1, 2048), (2048, 128, 1), 0); del buf203  # reuse
        # Topologically Sorted Source Nodes: [attn_output_15, value_5, transpose_23, reshape_17, output_38], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf210, buf212, buf213, arg120_1, buf217, 2048, 256, stream=raw_stream0)
        del arg120_1
        buf216 = buf194; del buf194  # reuse
        assert_size_stride_grouped((arg121_1, arg122_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_15, transpose_23, reshape_17, output_38], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf217, arg121_1, buf216, arg122_1, 1, 2048, 2048, 128, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg121_1
        del arg122_1
        assert_size_stride(arg123_1, (2048, ), (1, ), 'input')
        buf219 = buf143; del buf143  # reuse
        buf222 = reinterpret_tensor(buf217, (1, 1, 2048), (2048, 2048, 1), 0); del buf217  # reuse
        buf225 = buf104; del buf104  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_55, hidden_states_65, hidden_states_69, hidden_states_79, hidden_states_80, pow_24, variance_23, add_54, rsqrt_23, hidden_states_81, to_51, hidden_states_82, output_39, output_40], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_18.run(buf219, buf151, buf180, buf189, buf216, arg123_1, buf222, buf225, 1, 2048, stream=raw_stream0)
        del arg123_1
        buf221 = buf190; del buf190  # reuse
        assert_size_stride_grouped((arg124_1, arg125_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_80, pow_24, variance_23, add_54, rsqrt_23, hidden_states_81, to_51, hidden_states_82, output_39], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf222, arg124_1, buf221, arg125_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg124_1
        del arg125_1
        buf224 = buf187; del buf187  # reuse
        assert_size_stride_grouped((arg126_1, arg127_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_80, pow_24, variance_23, add_54, rsqrt_23, hidden_states_81, to_51, hidden_states_82, output_40], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf225, arg126_1, buf224, arg127_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg126_1
        del arg127_1
        buf227 = buf225; del buf225  # reuse
        buf228 = buf185; del buf185  # reuse
        # Topologically Sorted Source Nodes: [silu_5, mul_80, output_41], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_12.run(buf221, buf224, buf228, 6144, stream=raw_stream0)
        assert_size_stride_grouped((arg128_1, arg129_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_5, mul_80, output_41], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf228, arg128_1, buf227, arg129_1, 1, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg128_1
        del arg129_1
        assert_size_stride(arg130_1, (2048, ), (1, ), 'input')
        buf232 = buf222; del buf222  # reuse
        buf235 = buf216; del buf216  # reuse
        buf238 = buf189; del buf189  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_83, hidden_states_84, pow_25, variance_24, add_56, rsqrt_24, hidden_states_85, to_53, hidden_states_86, output_42, output_43, output_44], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_15.run(buf219, buf227, arg130_1, buf232, buf235, buf238, 1, 2048, stream=raw_stream0)
        del arg130_1
        buf231 = buf180; del buf180  # reuse
        assert_size_stride_grouped((arg131_1, arg132_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_83, hidden_states_84, pow_25, variance_24, add_56, rsqrt_24, hidden_states_85, to_53, hidden_states_86, output_42], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf232, arg131_1, buf231, arg132_1, 1, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg131_1
        del arg132_1
        buf234 = buf198; del buf198  # reuse
        assert_size_stride_grouped((arg134_1, arg135_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_83, hidden_states_84, pow_25, variance_24, add_56, rsqrt_24, hidden_states_85, to_53, hidden_states_86, output_43], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf235, arg134_1, buf234, arg135_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg134_1
        del arg135_1
        buf237 = reinterpret_tensor(buf207, (1, 1, 1024), (1024, 1024, 1), 0); del buf207  # reuse
        assert_size_stride_grouped((arg137_1, arg138_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_83, hidden_states_84, pow_25, variance_24, add_56, rsqrt_24, hidden_states_85, to_53, hidden_states_86, output_44], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf238, arg137_1, buf237, arg138_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg137_1
        del arg138_1
        buf240 = reinterpret_tensor(buf213, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf213  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_87, pow_26, variance_25], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf231, buf240, 16, 128, stream=raw_stream0)
        assert_size_stride(arg133_1, (128, ), (1, ), 'input')
        buf243 = reinterpret_tensor(buf238, (1, 16, 1, 128), (2048, 128, 128, 1), 0); del buf238  # reuse
        buf241 = reinterpret_tensor(buf243, (1, 16, 1, 64), (2048, 128, 128, 1), 0)  # alias
        buf242 = reinterpret_tensor(buf243, (1, 16, 1, 64), (2048, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_87, pow_26, variance_25, add_57, rsqrt_25, hidden_states_88, to_55, mul_84, query_states_6, x2_12, neg_12, x1_12, cat_14], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg133_1, buf231, buf240, buf241, buf242, 1024, stream=raw_stream0)
        buf244 = buf204; del buf204  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_89, pow_27, variance_26], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf234, buf244, 8, 128, stream=raw_stream0)
        del buf241
        del buf242
        assert_size_stride(arg136_1, (128, ), (1, ), 'input')
        buf247 = reinterpret_tensor(buf196, (1, 8, 1, 128), (1024, 128, 128, 1), 0); del buf196  # reuse
        buf245 = reinterpret_tensor(buf247, (1, 8, 1, 64), (1024, 128, 128, 1), 0)  # alias
        buf246 = reinterpret_tensor(buf247, (1, 8, 1, 64), (1024, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_89, pow_27, variance_26, add_58, rsqrt_26, hidden_states_90, to_57, mul_86, key_states_6, x2_13, neg_13, x1_13, cat_15], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg136_1, buf234, buf244, buf245, buf246, 512, stream=raw_stream0)
        assert_size_stride_grouped((arg139_1, arg140_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_10, sin_10, arange_10, cache_position_6, hidden_states_89, pow_27, variance_26, add_58, rsqrt_26, hidden_states_90, to_57, mul_86, key_states_6, mul_89, mul_90, k_embed_6, index_copy__12], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg139_1, arg136_1, buf234, buf244, buf1, buf247, buf0, arg140_1, 1024, stream=raw_stream0)
        del arg136_1
        del buf245
        del buf246
        buf249 = reinterpret_tensor(buf212, (16, 1, 256), (256, 256, 1), 0); del buf212  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_87, pow_26, variance_25, add_57, rsqrt_25, hidden_states_88, to_55, mul_84, query_states_6, cos_10, mul_87, sin_10, mul_88, q_embed_6, attn_output_18, key_6], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg133_1, buf231, buf240, buf1, buf243, buf0, arg140_1, buf249, 4096, 128, stream=raw_stream0)
        del arg133_1
        del arg140_1
        buf250 = buf210; del buf210  # reuse
        buf252 = reinterpret_tensor(buf209, (1, 16, 1, 256), (4096, 256, 4096, 1), 0); del buf209  # reuse
        buf253 = reinterpret_tensor(buf240, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf240  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_18], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8.run(buf249, arg3_1, buf250, buf252, buf253, 16, 256, stream=raw_stream0)
        assert_size_stride(arg141_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_10, cache_position_6, index_copy__13], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_9.run(arg139_1, buf237, arg141_1, 1024, stream=raw_stream0)
        buf257 = reinterpret_tensor(buf243, (1, 1, 2048), (2048, 128, 1), 0); del buf243  # reuse
        # Topologically Sorted Source Nodes: [attn_output_18, value_6, transpose_27, reshape_20, output_45], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf250, buf252, buf253, arg141_1, buf257, 2048, 256, stream=raw_stream0)
        del arg141_1
        buf256 = buf231; del buf231  # reuse
        assert_size_stride_grouped((arg142_1, arg143_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_18, transpose_27, reshape_20, output_45], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf257, arg142_1, buf256, arg143_1, 1, 2048, 2048, 128, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg142_1
        del arg143_1
        assert_size_stride(arg144_1, (2048, ), (1, ), 'input')
        buf260 = reinterpret_tensor(buf257, (1, 1, 2048), (2048, 2048, 1), 0); del buf257  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_83, hidden_states_93, hidden_states_94, pow_28, variance_27, add_63, rsqrt_27, hidden_states_95, to_59, hidden_states_96], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_16.run(buf219, buf227, buf256, arg144_1, buf260, 1, 2048, stream=raw_stream0)
        del arg144_1
        buf261 = buf228; del buf228  # reuse
        assert_size_stride_grouped((arg145_1, arg146_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_46], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf260, arg145_1, buf261, arg146_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg145_1
        del arg146_1
        buf263 = buf224; del buf224  # reuse
        assert_size_stride_grouped((arg147_1, arg148_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_47], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf260, arg147_1, buf263, arg148_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg147_1
        del arg148_1
        buf265 = buf260; del buf260  # reuse
        buf266 = buf221; del buf221  # reuse
        # Topologically Sorted Source Nodes: [silu_6, mul_93, output_48], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_12.run(buf261, buf263, buf266, 6144, stream=raw_stream0)
        assert_size_stride_grouped((arg149_1, arg150_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_6, mul_93, output_48], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf266, arg149_1, buf265, arg150_1, 1, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg149_1
        del arg150_1
        assert_size_stride(arg151_1, (2048, ), (1, ), 'input')
        buf269 = buf235; del buf235  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_83, hidden_states_93, hidden_states_97, hidden_states_98, pow_29, variance_28, add_65, rsqrt_28, hidden_states_99, to_61, hidden_states_100], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_17.run(buf219, buf227, buf256, buf265, arg151_1, buf269, 1, 2048, stream=raw_stream0)
        del arg151_1
        buf270 = buf232; del buf232  # reuse
        assert_size_stride_grouped((arg152_1, arg153_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_49], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf269, arg152_1, buf270, arg153_1, 1, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg152_1
        del arg153_1
        buf272 = buf237; del buf237  # reuse
        assert_size_stride_grouped((arg155_1, arg156_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_50], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf269, arg155_1, buf272, arg156_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg155_1
        del arg156_1
        buf274 = reinterpret_tensor(buf247, (1, 1, 1024), (1024, 1024, 1), 0); del buf247  # reuse
        assert_size_stride_grouped((arg158_1, arg159_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_51], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf269, arg158_1, buf274, arg159_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg158_1
        del arg159_1
        buf276 = reinterpret_tensor(buf253, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf253  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_101, pow_30, variance_29], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf270, buf276, 16, 128, stream=raw_stream0)
        assert_size_stride(arg154_1, (128, ), (1, ), 'input')
        buf279 = reinterpret_tensor(buf269, (1, 16, 1, 128), (2048, 128, 128, 1), 0); del buf269  # reuse
        buf277 = reinterpret_tensor(buf279, (1, 16, 1, 64), (2048, 128, 128, 1), 0)  # alias
        buf278 = reinterpret_tensor(buf279, (1, 16, 1, 64), (2048, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_101, pow_30, variance_29, add_66, rsqrt_29, hidden_states_102, to_63, mul_97, query_states_7, x2_14, neg_14, x1_14, cat_16], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg154_1, buf270, buf276, buf277, buf278, 1024, stream=raw_stream0)
        buf280 = buf244; del buf244  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_103, pow_31, variance_30], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf272, buf280, 8, 128, stream=raw_stream0)
        del buf277
        del buf278
        assert_size_stride(arg157_1, (128, ), (1, ), 'input')
        buf283 = reinterpret_tensor(buf234, (1, 8, 1, 128), (1024, 128, 128, 1), 0); del buf234  # reuse
        buf281 = reinterpret_tensor(buf283, (1, 8, 1, 64), (1024, 128, 128, 1), 0)  # alias
        buf282 = reinterpret_tensor(buf283, (1, 8, 1, 64), (1024, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_103, pow_31, variance_30, add_67, rsqrt_30, hidden_states_104, to_65, mul_99, key_states_7, x2_15, neg_15, x1_15, cat_17], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg157_1, buf272, buf280, buf281, buf282, 512, stream=raw_stream0)
        assert_size_stride_grouped((arg160_1, arg161_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_11, sin_11, arange_11, cache_position_7, hidden_states_103, pow_31, variance_30, add_67, rsqrt_30, hidden_states_104, to_65, mul_99, key_states_7, mul_102, mul_103, k_embed_7, index_copy__14], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg160_1, arg157_1, buf272, buf280, buf1, buf283, buf0, arg161_1, 1024, stream=raw_stream0)
        del arg157_1
        del buf281
        del buf282
        buf285 = reinterpret_tensor(buf252, (16, 1, 256), (256, 256, 1), 0); del buf252  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_101, pow_30, variance_29, add_66, rsqrt_29, hidden_states_102, to_63, mul_97, query_states_7, cos_11, mul_100, sin_11, mul_101, q_embed_7, attn_output_21, key_7], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg154_1, buf270, buf276, buf1, buf279, buf0, arg161_1, buf285, 4096, 128, stream=raw_stream0)
        del arg154_1
        del arg161_1
        buf286 = buf250; del buf250  # reuse
        buf288 = reinterpret_tensor(buf249, (1, 16, 1, 256), (4096, 256, 4096, 1), 0); del buf249  # reuse
        buf289 = reinterpret_tensor(buf276, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf276  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_21], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8.run(buf285, arg3_1, buf286, buf288, buf289, 16, 256, stream=raw_stream0)
        assert_size_stride(arg162_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_11, cache_position_7, index_copy__15], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_9.run(arg160_1, buf274, arg162_1, 1024, stream=raw_stream0)
        buf293 = reinterpret_tensor(buf279, (1, 1, 2048), (2048, 128, 1), 0); del buf279  # reuse
        # Topologically Sorted Source Nodes: [attn_output_21, value_7, transpose_31, reshape_23, output_52], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf286, buf288, buf289, arg162_1, buf293, 2048, 256, stream=raw_stream0)
        del arg162_1
        buf292 = buf270; del buf270  # reuse
        assert_size_stride_grouped((arg163_1, arg164_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_21, transpose_31, reshape_23, output_52], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf293, arg163_1, buf292, arg164_1, 1, 2048, 2048, 128, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg163_1
        del arg164_1
        assert_size_stride(arg165_1, (2048, ), (1, ), 'input')
        buf295 = buf219; del buf219  # reuse
        buf298 = reinterpret_tensor(buf293, (1, 1, 2048), (2048, 2048, 1), 0); del buf293  # reuse
        buf301 = buf151; del buf151  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_83, hidden_states_93, hidden_states_97, hidden_states_107, hidden_states_108, pow_32, variance_31, add_72, rsqrt_31, hidden_states_109, to_67, hidden_states_110, output_53, output_54], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_18.run(buf295, buf227, buf256, buf265, buf292, arg165_1, buf298, buf301, 1, 2048, stream=raw_stream0)
        del arg165_1
        buf297 = buf266; del buf266  # reuse
        assert_size_stride_grouped((arg166_1, arg167_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_108, pow_32, variance_31, add_72, rsqrt_31, hidden_states_109, to_67, hidden_states_110, output_53], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf298, arg166_1, buf297, arg167_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg166_1
        del arg167_1
        buf300 = buf263; del buf263  # reuse
        assert_size_stride_grouped((arg168_1, arg169_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_108, pow_32, variance_31, add_72, rsqrt_31, hidden_states_109, to_67, hidden_states_110, output_54], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf301, arg168_1, buf300, arg169_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg168_1
        del arg169_1
        buf303 = buf301; del buf301  # reuse
        buf304 = buf261; del buf261  # reuse
        # Topologically Sorted Source Nodes: [silu_7, mul_106, output_55], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_12.run(buf297, buf300, buf304, 6144, stream=raw_stream0)
        assert_size_stride_grouped((arg170_1, arg171_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_7, mul_106, output_55], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf304, arg170_1, buf303, arg171_1, 1, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg170_1
        del arg171_1
        assert_size_stride(arg172_1, (2048, ), (1, ), 'input')
        buf308 = buf298; del buf298  # reuse
        buf311 = buf292; del buf292  # reuse
        buf314 = buf265; del buf265  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_111, hidden_states_112, pow_33, variance_32, add_74, rsqrt_32, hidden_states_113, to_69, hidden_states_114, output_56, output_57, output_58], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_15.run(buf295, buf303, arg172_1, buf308, buf311, buf314, 1, 2048, stream=raw_stream0)
        del arg172_1
        buf307 = buf256; del buf256  # reuse
        assert_size_stride_grouped((arg173_1, arg174_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_111, hidden_states_112, pow_33, variance_32, add_74, rsqrt_32, hidden_states_113, to_69, hidden_states_114, output_56], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf308, arg173_1, buf307, arg174_1, 1, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg173_1
        del arg174_1
        buf310 = buf274; del buf274  # reuse
        assert_size_stride_grouped((arg176_1, arg177_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_111, hidden_states_112, pow_33, variance_32, add_74, rsqrt_32, hidden_states_113, to_69, hidden_states_114, output_57], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf311, arg176_1, buf310, arg177_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg176_1
        del arg177_1
        buf313 = reinterpret_tensor(buf283, (1, 1, 1024), (1024, 1024, 1), 0); del buf283  # reuse
        assert_size_stride_grouped((arg179_1, arg180_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_111, hidden_states_112, pow_33, variance_32, add_74, rsqrt_32, hidden_states_113, to_69, hidden_states_114, output_58], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf314, arg179_1, buf313, arg180_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg179_1
        del arg180_1
        buf316 = reinterpret_tensor(buf289, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf289  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_115, pow_34, variance_33], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf307, buf316, 16, 128, stream=raw_stream0)
        assert_size_stride(arg175_1, (128, ), (1, ), 'input')
        buf319 = reinterpret_tensor(buf314, (1, 16, 1, 128), (2048, 128, 128, 1), 0); del buf314  # reuse
        buf317 = reinterpret_tensor(buf319, (1, 16, 1, 64), (2048, 128, 128, 1), 0)  # alias
        buf318 = reinterpret_tensor(buf319, (1, 16, 1, 64), (2048, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_115, pow_34, variance_33, add_75, rsqrt_33, hidden_states_116, to_71, mul_110, query_states_8, x2_16, neg_16, x1_16, cat_18], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg175_1, buf307, buf316, buf317, buf318, 1024, stream=raw_stream0)
        buf320 = buf280; del buf280  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_117, pow_35, variance_34], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf310, buf320, 8, 128, stream=raw_stream0)
        del buf317
        del buf318
        assert_size_stride(arg178_1, (128, ), (1, ), 'input')
        buf323 = reinterpret_tensor(buf272, (1, 8, 1, 128), (1024, 128, 128, 1), 0); del buf272  # reuse
        buf321 = reinterpret_tensor(buf323, (1, 8, 1, 64), (1024, 128, 128, 1), 0)  # alias
        buf322 = reinterpret_tensor(buf323, (1, 8, 1, 64), (1024, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_117, pow_35, variance_34, add_76, rsqrt_34, hidden_states_118, to_73, mul_112, key_states_8, x2_17, neg_17, x1_17, cat_19], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg178_1, buf310, buf320, buf321, buf322, 512, stream=raw_stream0)
        assert_size_stride_grouped((arg181_1, arg182_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_12, sin_12, arange_12, cache_position_8, hidden_states_117, pow_35, variance_34, add_76, rsqrt_34, hidden_states_118, to_73, mul_112, key_states_8, mul_115, mul_116, k_embed_8, index_copy__16], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg181_1, arg178_1, buf310, buf320, buf1, buf323, buf0, arg182_1, 1024, stream=raw_stream0)
        del arg178_1
        del buf321
        del buf322
        buf325 = reinterpret_tensor(buf288, (16, 1, 256), (256, 256, 1), 0); del buf288  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_115, pow_34, variance_33, add_75, rsqrt_33, hidden_states_116, to_71, mul_110, query_states_8, cos_12, mul_113, sin_12, mul_114, q_embed_8, attn_output_24, key_8], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg175_1, buf307, buf316, buf1, buf319, buf0, arg182_1, buf325, 4096, 128, stream=raw_stream0)
        del arg175_1
        del arg182_1
        buf326 = buf286; del buf286  # reuse
        buf328 = reinterpret_tensor(buf285, (1, 16, 1, 256), (4096, 256, 4096, 1), 0); del buf285  # reuse
        buf329 = reinterpret_tensor(buf316, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf316  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_24], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8.run(buf325, arg3_1, buf326, buf328, buf329, 16, 256, stream=raw_stream0)
        assert_size_stride(arg183_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_12, cache_position_8, index_copy__17], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_9.run(arg181_1, buf313, arg183_1, 1024, stream=raw_stream0)
        buf333 = reinterpret_tensor(buf319, (1, 1, 2048), (2048, 128, 1), 0); del buf319  # reuse
        # Topologically Sorted Source Nodes: [attn_output_24, value_8, transpose_35, reshape_26, output_59], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf326, buf328, buf329, arg183_1, buf333, 2048, 256, stream=raw_stream0)
        del arg183_1
        buf332 = buf307; del buf307  # reuse
        assert_size_stride_grouped((arg184_1, arg185_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_24, transpose_35, reshape_26, output_59], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf333, arg184_1, buf332, arg185_1, 1, 2048, 2048, 128, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg184_1
        del arg185_1
        assert_size_stride(arg186_1, (2048, ), (1, ), 'input')
        buf336 = reinterpret_tensor(buf333, (1, 1, 2048), (2048, 2048, 1), 0); del buf333  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_111, hidden_states_121, hidden_states_122, pow_36, variance_35, add_81, rsqrt_35, hidden_states_123, to_75, hidden_states_124], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_16.run(buf295, buf303, buf332, arg186_1, buf336, 1, 2048, stream=raw_stream0)
        del arg186_1
        buf337 = buf304; del buf304  # reuse
        assert_size_stride_grouped((arg187_1, arg188_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_60], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf336, arg187_1, buf337, arg188_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg187_1
        del arg188_1
        buf339 = buf300; del buf300  # reuse
        assert_size_stride_grouped((arg189_1, arg190_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_61], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf336, arg189_1, buf339, arg190_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg189_1
        del arg190_1
        buf341 = buf336; del buf336  # reuse
        buf342 = buf297; del buf297  # reuse
        # Topologically Sorted Source Nodes: [silu_8, mul_119, output_62], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_12.run(buf337, buf339, buf342, 6144, stream=raw_stream0)
        assert_size_stride_grouped((arg191_1, arg192_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_8, mul_119, output_62], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf342, arg191_1, buf341, arg192_1, 1, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg191_1
        del arg192_1
        assert_size_stride(arg193_1, (2048, ), (1, ), 'input')
        buf345 = buf311; del buf311  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_111, hidden_states_121, hidden_states_125, hidden_states_126, pow_37, variance_36, add_83, rsqrt_36, hidden_states_127, to_77, hidden_states_128], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_17.run(buf295, buf303, buf332, buf341, arg193_1, buf345, 1, 2048, stream=raw_stream0)
        del arg193_1
        buf346 = buf308; del buf308  # reuse
        assert_size_stride_grouped((arg194_1, arg195_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_63], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf345, arg194_1, buf346, arg195_1, 1, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg194_1
        del arg195_1
        buf348 = buf313; del buf313  # reuse
        assert_size_stride_grouped((arg197_1, arg198_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_64], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf345, arg197_1, buf348, arg198_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg197_1
        del arg198_1
        buf350 = reinterpret_tensor(buf323, (1, 1, 1024), (1024, 1024, 1), 0); del buf323  # reuse
        assert_size_stride_grouped((arg200_1, arg201_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_65], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf345, arg200_1, buf350, arg201_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg200_1
        del arg201_1
        buf352 = reinterpret_tensor(buf329, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf329  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_129, pow_38, variance_37], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf346, buf352, 16, 128, stream=raw_stream0)
        assert_size_stride(arg196_1, (128, ), (1, ), 'input')
        buf355 = reinterpret_tensor(buf345, (1, 16, 1, 128), (2048, 128, 128, 1), 0); del buf345  # reuse
        buf353 = reinterpret_tensor(buf355, (1, 16, 1, 64), (2048, 128, 128, 1), 0)  # alias
        buf354 = reinterpret_tensor(buf355, (1, 16, 1, 64), (2048, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_129, pow_38, variance_37, add_84, rsqrt_37, hidden_states_130, to_79, mul_123, query_states_9, x2_18, neg_18, x1_18, cat_20], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg196_1, buf346, buf352, buf353, buf354, 1024, stream=raw_stream0)
        buf356 = buf320; del buf320  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_131, pow_39, variance_38], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf348, buf356, 8, 128, stream=raw_stream0)
        del buf353
        del buf354
        assert_size_stride(arg199_1, (128, ), (1, ), 'input')
        buf359 = reinterpret_tensor(buf310, (1, 8, 1, 128), (1024, 128, 128, 1), 0); del buf310  # reuse
        buf357 = reinterpret_tensor(buf359, (1, 8, 1, 64), (1024, 128, 128, 1), 0)  # alias
        buf358 = reinterpret_tensor(buf359, (1, 8, 1, 64), (1024, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_131, pow_39, variance_38, add_85, rsqrt_38, hidden_states_132, to_81, mul_125, key_states_9, x2_19, neg_19, x1_19, cat_21], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg199_1, buf348, buf356, buf357, buf358, 512, stream=raw_stream0)
        assert_size_stride_grouped((arg202_1, arg203_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_13, sin_13, arange_13, cache_position_9, hidden_states_131, pow_39, variance_38, add_85, rsqrt_38, hidden_states_132, to_81, mul_125, key_states_9, mul_128, mul_129, k_embed_9, index_copy__18], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg202_1, arg199_1, buf348, buf356, buf1, buf359, buf0, arg203_1, 1024, stream=raw_stream0)
        del arg199_1
        del buf357
        del buf358
        buf361 = reinterpret_tensor(buf328, (16, 1, 256), (256, 256, 1), 0); del buf328  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_129, pow_38, variance_37, add_84, rsqrt_37, hidden_states_130, to_79, mul_123, query_states_9, cos_13, mul_126, sin_13, mul_127, q_embed_9, attn_output_27, key_9], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg196_1, buf346, buf352, buf1, buf355, buf0, arg203_1, buf361, 4096, 128, stream=raw_stream0)
        del arg196_1
        del arg203_1
        buf362 = buf326; del buf326  # reuse
        buf364 = reinterpret_tensor(buf325, (1, 16, 1, 256), (4096, 256, 4096, 1), 0); del buf325  # reuse
        buf365 = reinterpret_tensor(buf352, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf352  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_27], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8.run(buf361, arg3_1, buf362, buf364, buf365, 16, 256, stream=raw_stream0)
        assert_size_stride(arg204_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_13, cache_position_9, index_copy__19], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_9.run(arg202_1, buf350, arg204_1, 1024, stream=raw_stream0)
        buf369 = reinterpret_tensor(buf355, (1, 1, 2048), (2048, 128, 1), 0); del buf355  # reuse
        # Topologically Sorted Source Nodes: [attn_output_27, value_9, transpose_39, reshape_29, output_66], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf362, buf364, buf365, arg204_1, buf369, 2048, 256, stream=raw_stream0)
        del arg204_1
        buf368 = buf346; del buf346  # reuse
        assert_size_stride_grouped((arg205_1, arg206_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_27, transpose_39, reshape_29, output_66], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf369, arg205_1, buf368, arg206_1, 1, 2048, 2048, 128, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg205_1
        del arg206_1
        assert_size_stride(arg207_1, (2048, ), (1, ), 'input')
        buf371 = buf295; del buf295  # reuse
        buf374 = reinterpret_tensor(buf369, (1, 1, 2048), (2048, 2048, 1), 0); del buf369  # reuse
        buf377 = buf227; del buf227  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_111, hidden_states_121, hidden_states_125, hidden_states_135, hidden_states_136, pow_40, variance_39, add_90, rsqrt_39, hidden_states_137, to_83, hidden_states_138, output_67, output_68], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_18.run(buf371, buf303, buf332, buf341, buf368, arg207_1, buf374, buf377, 1, 2048, stream=raw_stream0)
        del arg207_1
        buf373 = buf342; del buf342  # reuse
        assert_size_stride_grouped((arg208_1, arg209_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_136, pow_40, variance_39, add_90, rsqrt_39, hidden_states_137, to_83, hidden_states_138, output_67], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf374, arg208_1, buf373, arg209_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg208_1
        del arg209_1
        buf376 = buf339; del buf339  # reuse
        assert_size_stride_grouped((arg210_1, arg211_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_136, pow_40, variance_39, add_90, rsqrt_39, hidden_states_137, to_83, hidden_states_138, output_68], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf377, arg210_1, buf376, arg211_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg210_1
        del arg211_1
        buf379 = buf377; del buf377  # reuse
        buf380 = buf337; del buf337  # reuse
        # Topologically Sorted Source Nodes: [silu_9, mul_132, output_69], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_12.run(buf373, buf376, buf380, 6144, stream=raw_stream0)
        assert_size_stride_grouped((arg212_1, arg213_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_9, mul_132, output_69], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf380, arg212_1, buf379, arg213_1, 1, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg212_1
        del arg213_1
        assert_size_stride(arg214_1, (2048, ), (1, ), 'input')
        buf384 = buf374; del buf374  # reuse
        buf387 = buf368; del buf368  # reuse
        buf390 = buf341; del buf341  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_139, hidden_states_140, pow_41, variance_40, add_92, rsqrt_40, hidden_states_141, to_85, hidden_states_142, output_70, output_71, output_72], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_15.run(buf371, buf379, arg214_1, buf384, buf387, buf390, 1, 2048, stream=raw_stream0)
        del arg214_1
        buf383 = buf332; del buf332  # reuse
        assert_size_stride_grouped((arg215_1, arg216_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_139, hidden_states_140, pow_41, variance_40, add_92, rsqrt_40, hidden_states_141, to_85, hidden_states_142, output_70], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf384, arg215_1, buf383, arg216_1, 1, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg215_1
        del arg216_1
        buf386 = buf350; del buf350  # reuse
        assert_size_stride_grouped((arg218_1, arg219_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_139, hidden_states_140, pow_41, variance_40, add_92, rsqrt_40, hidden_states_141, to_85, hidden_states_142, output_71], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf387, arg218_1, buf386, arg219_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg218_1
        del arg219_1
        buf389 = reinterpret_tensor(buf359, (1, 1, 1024), (1024, 1024, 1), 0); del buf359  # reuse
        assert_size_stride_grouped((arg221_1, arg222_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_139, hidden_states_140, pow_41, variance_40, add_92, rsqrt_40, hidden_states_141, to_85, hidden_states_142, output_72], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf390, arg221_1, buf389, arg222_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg221_1
        del arg222_1
        buf392 = reinterpret_tensor(buf365, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf365  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_143, pow_42, variance_41], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf383, buf392, 16, 128, stream=raw_stream0)
        assert_size_stride(arg217_1, (128, ), (1, ), 'input')
        buf395 = reinterpret_tensor(buf390, (1, 16, 1, 128), (2048, 128, 128, 1), 0); del buf390  # reuse
        buf393 = reinterpret_tensor(buf395, (1, 16, 1, 64), (2048, 128, 128, 1), 0)  # alias
        buf394 = reinterpret_tensor(buf395, (1, 16, 1, 64), (2048, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_143, pow_42, variance_41, add_93, rsqrt_41, hidden_states_144, to_87, mul_136, query_states_10, x2_20, neg_20, x1_20, cat_22], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg217_1, buf383, buf392, buf393, buf394, 1024, stream=raw_stream0)
        buf396 = buf356; del buf356  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_145, pow_43, variance_42], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf386, buf396, 8, 128, stream=raw_stream0)
        del buf393
        del buf394
        assert_size_stride(arg220_1, (128, ), (1, ), 'input')
        buf399 = reinterpret_tensor(buf348, (1, 8, 1, 128), (1024, 128, 128, 1), 0); del buf348  # reuse
        buf397 = reinterpret_tensor(buf399, (1, 8, 1, 64), (1024, 128, 128, 1), 0)  # alias
        buf398 = reinterpret_tensor(buf399, (1, 8, 1, 64), (1024, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_145, pow_43, variance_42, add_94, rsqrt_42, hidden_states_146, to_89, mul_138, key_states_10, x2_21, neg_21, x1_21, cat_23], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg220_1, buf386, buf396, buf397, buf398, 512, stream=raw_stream0)
        assert_size_stride_grouped((arg223_1, arg224_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_14, sin_14, arange_14, cache_position_10, hidden_states_145, pow_43, variance_42, add_94, rsqrt_42, hidden_states_146, to_89, mul_138, key_states_10, mul_141, mul_142, k_embed_10, index_copy__20], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg223_1, arg220_1, buf386, buf396, buf1, buf399, buf0, arg224_1, 1024, stream=raw_stream0)
        del arg220_1
        del buf397
        del buf398
        buf401 = reinterpret_tensor(buf364, (16, 1, 256), (256, 256, 1), 0); del buf364  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_143, pow_42, variance_41, add_93, rsqrt_41, hidden_states_144, to_87, mul_136, query_states_10, cos_14, mul_139, sin_14, mul_140, q_embed_10, attn_output_30, key_10], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg217_1, buf383, buf392, buf1, buf395, buf0, arg224_1, buf401, 4096, 128, stream=raw_stream0)
        del arg217_1
        del arg224_1
        buf402 = buf362; del buf362  # reuse
        buf404 = reinterpret_tensor(buf361, (1, 16, 1, 256), (4096, 256, 4096, 1), 0); del buf361  # reuse
        buf405 = reinterpret_tensor(buf392, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf392  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_30], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8.run(buf401, arg3_1, buf402, buf404, buf405, 16, 256, stream=raw_stream0)
        assert_size_stride(arg225_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_14, cache_position_10, index_copy__21], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_9.run(arg223_1, buf389, arg225_1, 1024, stream=raw_stream0)
        buf409 = reinterpret_tensor(buf395, (1, 1, 2048), (2048, 128, 1), 0); del buf395  # reuse
        # Topologically Sorted Source Nodes: [attn_output_30, value_10, transpose_43, reshape_32, output_73], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf402, buf404, buf405, arg225_1, buf409, 2048, 256, stream=raw_stream0)
        del arg225_1
        buf408 = buf383; del buf383  # reuse
        assert_size_stride_grouped((arg226_1, arg227_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_30, transpose_43, reshape_32, output_73], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf409, arg226_1, buf408, arg227_1, 1, 2048, 2048, 128, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg226_1
        del arg227_1
        assert_size_stride(arg228_1, (2048, ), (1, ), 'input')
        buf412 = reinterpret_tensor(buf409, (1, 1, 2048), (2048, 2048, 1), 0); del buf409  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_139, hidden_states_149, hidden_states_150, pow_44, variance_43, add_99, rsqrt_43, hidden_states_151, to_91, hidden_states_152], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_16.run(buf371, buf379, buf408, arg228_1, buf412, 1, 2048, stream=raw_stream0)
        del arg228_1
        buf413 = buf380; del buf380  # reuse
        assert_size_stride_grouped((arg229_1, arg230_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_74], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf412, arg229_1, buf413, arg230_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg229_1
        del arg230_1
        buf415 = buf376; del buf376  # reuse
        assert_size_stride_grouped((arg231_1, arg232_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_75], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf412, arg231_1, buf415, arg232_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg231_1
        del arg232_1
        buf417 = buf412; del buf412  # reuse
        buf418 = buf373; del buf373  # reuse
        # Topologically Sorted Source Nodes: [silu_10, mul_145, output_76], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_12.run(buf413, buf415, buf418, 6144, stream=raw_stream0)
        assert_size_stride_grouped((arg233_1, arg234_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_10, mul_145, output_76], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf418, arg233_1, buf417, arg234_1, 1, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg233_1
        del arg234_1
        assert_size_stride(arg235_1, (2048, ), (1, ), 'input')
        buf421 = buf387; del buf387  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_139, hidden_states_149, hidden_states_153, hidden_states_154, pow_45, variance_44, add_101, rsqrt_44, hidden_states_155, to_93, hidden_states_156], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_17.run(buf371, buf379, buf408, buf417, arg235_1, buf421, 1, 2048, stream=raw_stream0)
        del arg235_1
        buf422 = buf384; del buf384  # reuse
        assert_size_stride_grouped((arg236_1, arg237_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_77], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf421, arg236_1, buf422, arg237_1, 1, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg236_1
        del arg237_1
        buf424 = buf389; del buf389  # reuse
        assert_size_stride_grouped((arg239_1, arg240_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_78], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf421, arg239_1, buf424, arg240_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg239_1
        del arg240_1
        buf426 = reinterpret_tensor(buf399, (1, 1, 1024), (1024, 1024, 1), 0); del buf399  # reuse
        assert_size_stride_grouped((arg242_1, arg243_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_79], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf421, arg242_1, buf426, arg243_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg242_1
        del arg243_1
        buf428 = reinterpret_tensor(buf405, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf405  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_157, pow_46, variance_45], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf422, buf428, 16, 128, stream=raw_stream0)
        assert_size_stride(arg238_1, (128, ), (1, ), 'input')
        buf431 = reinterpret_tensor(buf421, (1, 16, 1, 128), (2048, 128, 128, 1), 0); del buf421  # reuse
        buf429 = reinterpret_tensor(buf431, (1, 16, 1, 64), (2048, 128, 128, 1), 0)  # alias
        buf430 = reinterpret_tensor(buf431, (1, 16, 1, 64), (2048, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_157, pow_46, variance_45, add_102, rsqrt_45, hidden_states_158, to_95, mul_149, query_states_11, x2_22, neg_22, x1_22, cat_24], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg238_1, buf422, buf428, buf429, buf430, 1024, stream=raw_stream0)
        buf432 = buf396; del buf396  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_159, pow_47, variance_46], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf424, buf432, 8, 128, stream=raw_stream0)
        del buf429
        del buf430
        assert_size_stride(arg241_1, (128, ), (1, ), 'input')
        buf435 = reinterpret_tensor(buf386, (1, 8, 1, 128), (1024, 128, 128, 1), 0); del buf386  # reuse
        buf433 = reinterpret_tensor(buf435, (1, 8, 1, 64), (1024, 128, 128, 1), 0)  # alias
        buf434 = reinterpret_tensor(buf435, (1, 8, 1, 64), (1024, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_159, pow_47, variance_46, add_103, rsqrt_46, hidden_states_160, to_97, mul_151, key_states_11, x2_23, neg_23, x1_23, cat_25], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg241_1, buf424, buf432, buf433, buf434, 512, stream=raw_stream0)
        assert_size_stride_grouped((arg244_1, arg245_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_15, sin_15, arange_15, cache_position_11, hidden_states_159, pow_47, variance_46, add_103, rsqrt_46, hidden_states_160, to_97, mul_151, key_states_11, mul_154, mul_155, k_embed_11, index_copy__22], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg244_1, arg241_1, buf424, buf432, buf1, buf435, buf0, arg245_1, 1024, stream=raw_stream0)
        del arg241_1
        del buf433
        del buf434
        buf437 = reinterpret_tensor(buf404, (16, 1, 256), (256, 256, 1), 0); del buf404  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_157, pow_46, variance_45, add_102, rsqrt_45, hidden_states_158, to_95, mul_149, query_states_11, cos_15, mul_152, sin_15, mul_153, q_embed_11, attn_output_33, key_11], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg238_1, buf422, buf428, buf1, buf431, buf0, arg245_1, buf437, 4096, 128, stream=raw_stream0)
        del arg238_1
        del arg245_1
        buf438 = buf402; del buf402  # reuse
        buf440 = reinterpret_tensor(buf401, (1, 16, 1, 256), (4096, 256, 4096, 1), 0); del buf401  # reuse
        buf441 = reinterpret_tensor(buf428, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf428  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_33], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8.run(buf437, arg3_1, buf438, buf440, buf441, 16, 256, stream=raw_stream0)
        assert_size_stride(arg246_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_15, cache_position_11, index_copy__23], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_9.run(arg244_1, buf426, arg246_1, 1024, stream=raw_stream0)
        buf445 = reinterpret_tensor(buf431, (1, 1, 2048), (2048, 128, 1), 0); del buf431  # reuse
        # Topologically Sorted Source Nodes: [attn_output_33, value_11, transpose_47, reshape_35, output_80], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf438, buf440, buf441, arg246_1, buf445, 2048, 256, stream=raw_stream0)
        del arg246_1
        buf444 = buf422; del buf422  # reuse
        assert_size_stride_grouped((arg247_1, arg248_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_33, transpose_47, reshape_35, output_80], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf445, arg247_1, buf444, arg248_1, 1, 2048, 2048, 128, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg247_1
        del arg248_1
        assert_size_stride(arg249_1, (2048, ), (1, ), 'input')
        buf447 = buf371; del buf371  # reuse
        buf450 = reinterpret_tensor(buf445, (1, 1, 2048), (2048, 2048, 1), 0); del buf445  # reuse
        buf453 = buf303; del buf303  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_139, hidden_states_149, hidden_states_153, hidden_states_163, hidden_states_164, pow_48, variance_47, add_108, rsqrt_47, hidden_states_165, to_99, hidden_states_166, output_81, output_82], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_18.run(buf447, buf379, buf408, buf417, buf444, arg249_1, buf450, buf453, 1, 2048, stream=raw_stream0)
        del arg249_1
        buf449 = buf418; del buf418  # reuse
        assert_size_stride_grouped((arg250_1, arg251_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_164, pow_48, variance_47, add_108, rsqrt_47, hidden_states_165, to_99, hidden_states_166, output_81], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf450, arg250_1, buf449, arg251_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg250_1
        del arg251_1
        buf452 = buf415; del buf415  # reuse
        assert_size_stride_grouped((arg252_1, arg253_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_164, pow_48, variance_47, add_108, rsqrt_47, hidden_states_165, to_99, hidden_states_166, output_82], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf453, arg252_1, buf452, arg253_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg252_1
        del arg253_1
        buf455 = buf453; del buf453  # reuse
        buf456 = buf413; del buf413  # reuse
        # Topologically Sorted Source Nodes: [silu_11, mul_158, output_83], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_12.run(buf449, buf452, buf456, 6144, stream=raw_stream0)
        assert_size_stride_grouped((arg254_1, arg255_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_11, mul_158, output_83], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf456, arg254_1, buf455, arg255_1, 1, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg254_1
        del arg255_1
        assert_size_stride(arg256_1, (2048, ), (1, ), 'input')
        buf460 = buf450; del buf450  # reuse
        buf463 = buf444; del buf444  # reuse
        buf466 = buf417; del buf417  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_167, hidden_states_168, pow_49, variance_48, add_110, rsqrt_48, hidden_states_169, to_101, hidden_states_170, output_84, output_85, output_86], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_15.run(buf447, buf455, arg256_1, buf460, buf463, buf466, 1, 2048, stream=raw_stream0)
        del arg256_1
        buf459 = buf408; del buf408  # reuse
        assert_size_stride_grouped((arg257_1, arg258_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_167, hidden_states_168, pow_49, variance_48, add_110, rsqrt_48, hidden_states_169, to_101, hidden_states_170, output_84], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf460, arg257_1, buf459, arg258_1, 1, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg257_1
        del arg258_1
        buf462 = buf426; del buf426  # reuse
        assert_size_stride_grouped((arg260_1, arg261_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_167, hidden_states_168, pow_49, variance_48, add_110, rsqrt_48, hidden_states_169, to_101, hidden_states_170, output_85], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf463, arg260_1, buf462, arg261_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg260_1
        del arg261_1
        buf465 = reinterpret_tensor(buf435, (1, 1, 1024), (1024, 1024, 1), 0); del buf435  # reuse
        assert_size_stride_grouped((arg263_1, arg264_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_167, hidden_states_168, pow_49, variance_48, add_110, rsqrt_48, hidden_states_169, to_101, hidden_states_170, output_86], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf466, arg263_1, buf465, arg264_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg263_1
        del arg264_1
        buf468 = reinterpret_tensor(buf441, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf441  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_171, pow_50, variance_49], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf459, buf468, 16, 128, stream=raw_stream0)
        assert_size_stride(arg259_1, (128, ), (1, ), 'input')
        buf471 = reinterpret_tensor(buf466, (1, 16, 1, 128), (2048, 128, 128, 1), 0); del buf466  # reuse
        buf469 = reinterpret_tensor(buf471, (1, 16, 1, 64), (2048, 128, 128, 1), 0)  # alias
        buf470 = reinterpret_tensor(buf471, (1, 16, 1, 64), (2048, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_171, pow_50, variance_49, add_111, rsqrt_49, hidden_states_172, to_103, mul_162, query_states_12, x2_24, neg_24, x1_24, cat_26], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg259_1, buf459, buf468, buf469, buf470, 1024, stream=raw_stream0)
        buf472 = buf432; del buf432  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_173, pow_51, variance_50], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf462, buf472, 8, 128, stream=raw_stream0)
        del buf469
        del buf470
        assert_size_stride(arg262_1, (128, ), (1, ), 'input')
        buf475 = reinterpret_tensor(buf424, (1, 8, 1, 128), (1024, 128, 128, 1), 0); del buf424  # reuse
        buf473 = reinterpret_tensor(buf475, (1, 8, 1, 64), (1024, 128, 128, 1), 0)  # alias
        buf474 = reinterpret_tensor(buf475, (1, 8, 1, 64), (1024, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_173, pow_51, variance_50, add_112, rsqrt_50, hidden_states_174, to_105, mul_164, key_states_12, x2_25, neg_25, x1_25, cat_27], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg262_1, buf462, buf472, buf473, buf474, 512, stream=raw_stream0)
        assert_size_stride_grouped((arg265_1, arg266_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_16, sin_16, arange_16, cache_position_12, hidden_states_173, pow_51, variance_50, add_112, rsqrt_50, hidden_states_174, to_105, mul_164, key_states_12, mul_167, mul_168, k_embed_12, index_copy__24], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg265_1, arg262_1, buf462, buf472, buf1, buf475, buf0, arg266_1, 1024, stream=raw_stream0)
        del arg262_1
        del buf473
        del buf474
        buf477 = reinterpret_tensor(buf440, (16, 1, 256), (256, 256, 1), 0); del buf440  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_171, pow_50, variance_49, add_111, rsqrt_49, hidden_states_172, to_103, mul_162, query_states_12, cos_16, mul_165, sin_16, mul_166, q_embed_12, attn_output_36, key_12], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg259_1, buf459, buf468, buf1, buf471, buf0, arg266_1, buf477, 4096, 128, stream=raw_stream0)
        del arg259_1
        del arg266_1
        buf478 = buf438; del buf438  # reuse
        buf480 = reinterpret_tensor(buf437, (1, 16, 1, 256), (4096, 256, 4096, 1), 0); del buf437  # reuse
        buf481 = reinterpret_tensor(buf468, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf468  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_36], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8.run(buf477, arg3_1, buf478, buf480, buf481, 16, 256, stream=raw_stream0)
        assert_size_stride(arg267_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_16, cache_position_12, index_copy__25], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_9.run(arg265_1, buf465, arg267_1, 1024, stream=raw_stream0)
        buf485 = reinterpret_tensor(buf471, (1, 1, 2048), (2048, 128, 1), 0); del buf471  # reuse
        # Topologically Sorted Source Nodes: [attn_output_36, value_12, transpose_51, reshape_38, output_87], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf478, buf480, buf481, arg267_1, buf485, 2048, 256, stream=raw_stream0)
        del arg267_1
        buf484 = buf459; del buf459  # reuse
        assert_size_stride_grouped((arg268_1, arg269_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_36, transpose_51, reshape_38, output_87], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf485, arg268_1, buf484, arg269_1, 1, 2048, 2048, 128, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg268_1
        del arg269_1
        assert_size_stride(arg270_1, (2048, ), (1, ), 'input')
        buf488 = reinterpret_tensor(buf485, (1, 1, 2048), (2048, 2048, 1), 0); del buf485  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_167, hidden_states_177, hidden_states_178, pow_52, variance_51, add_117, rsqrt_51, hidden_states_179, to_107, hidden_states_180], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_16.run(buf447, buf455, buf484, arg270_1, buf488, 1, 2048, stream=raw_stream0)
        del arg270_1
        buf489 = buf456; del buf456  # reuse
        assert_size_stride_grouped((arg271_1, arg272_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_88], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf488, arg271_1, buf489, arg272_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg271_1
        del arg272_1
        buf491 = buf452; del buf452  # reuse
        assert_size_stride_grouped((arg273_1, arg274_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_89], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf488, arg273_1, buf491, arg274_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg273_1
        del arg274_1
        buf493 = buf488; del buf488  # reuse
        buf494 = buf449; del buf449  # reuse
        # Topologically Sorted Source Nodes: [silu_12, mul_171, output_90], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_12.run(buf489, buf491, buf494, 6144, stream=raw_stream0)
        assert_size_stride_grouped((arg275_1, arg276_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_12, mul_171, output_90], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf494, arg275_1, buf493, arg276_1, 1, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg275_1
        del arg276_1
        assert_size_stride(arg277_1, (2048, ), (1, ), 'input')
        buf497 = buf463; del buf463  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_167, hidden_states_177, hidden_states_181, hidden_states_182, pow_53, variance_52, add_119, rsqrt_52, hidden_states_183, to_109, hidden_states_184], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_17.run(buf447, buf455, buf484, buf493, arg277_1, buf497, 1, 2048, stream=raw_stream0)
        del arg277_1
        buf498 = buf460; del buf460  # reuse
        assert_size_stride_grouped((arg278_1, arg279_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_91], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf497, arg278_1, buf498, arg279_1, 1, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg278_1
        del arg279_1
        buf500 = buf465; del buf465  # reuse
        assert_size_stride_grouped((arg281_1, arg282_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_92], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf497, arg281_1, buf500, arg282_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg281_1
        del arg282_1
        buf502 = reinterpret_tensor(buf475, (1, 1, 1024), (1024, 1024, 1), 0); del buf475  # reuse
        assert_size_stride_grouped((arg284_1, arg285_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_93], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf497, arg284_1, buf502, arg285_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg284_1
        del arg285_1
        buf504 = reinterpret_tensor(buf481, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf481  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_185, pow_54, variance_53], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf498, buf504, 16, 128, stream=raw_stream0)
        assert_size_stride(arg280_1, (128, ), (1, ), 'input')
        buf507 = reinterpret_tensor(buf497, (1, 16, 1, 128), (2048, 128, 128, 1), 0); del buf497  # reuse
        buf505 = reinterpret_tensor(buf507, (1, 16, 1, 64), (2048, 128, 128, 1), 0)  # alias
        buf506 = reinterpret_tensor(buf507, (1, 16, 1, 64), (2048, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_185, pow_54, variance_53, add_120, rsqrt_53, hidden_states_186, to_111, mul_175, query_states_13, x2_26, neg_26, x1_26, cat_28], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg280_1, buf498, buf504, buf505, buf506, 1024, stream=raw_stream0)
        buf508 = buf472; del buf472  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_187, pow_55, variance_54], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf500, buf508, 8, 128, stream=raw_stream0)
        del buf505
        del buf506
        assert_size_stride(arg283_1, (128, ), (1, ), 'input')
        buf511 = reinterpret_tensor(buf462, (1, 8, 1, 128), (1024, 128, 128, 1), 0); del buf462  # reuse
        buf509 = reinterpret_tensor(buf511, (1, 8, 1, 64), (1024, 128, 128, 1), 0)  # alias
        buf510 = reinterpret_tensor(buf511, (1, 8, 1, 64), (1024, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_187, pow_55, variance_54, add_121, rsqrt_54, hidden_states_188, to_113, mul_177, key_states_13, x2_27, neg_27, x1_27, cat_29], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg283_1, buf500, buf508, buf509, buf510, 512, stream=raw_stream0)
        assert_size_stride_grouped((arg286_1, arg287_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_17, sin_17, arange_17, cache_position_13, hidden_states_187, pow_55, variance_54, add_121, rsqrt_54, hidden_states_188, to_113, mul_177, key_states_13, mul_180, mul_181, k_embed_13, index_copy__26], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg286_1, arg283_1, buf500, buf508, buf1, buf511, buf0, arg287_1, 1024, stream=raw_stream0)
        del arg283_1
        del buf509
        del buf510
        buf513 = reinterpret_tensor(buf480, (16, 1, 256), (256, 256, 1), 0); del buf480  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_185, pow_54, variance_53, add_120, rsqrt_53, hidden_states_186, to_111, mul_175, query_states_13, cos_17, mul_178, sin_17, mul_179, q_embed_13, attn_output_39, key_13], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg280_1, buf498, buf504, buf1, buf507, buf0, arg287_1, buf513, 4096, 128, stream=raw_stream0)
        del arg280_1
        del arg287_1
        buf514 = buf478; del buf478  # reuse
        buf516 = reinterpret_tensor(buf477, (1, 16, 1, 256), (4096, 256, 4096, 1), 0); del buf477  # reuse
        buf517 = reinterpret_tensor(buf504, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf504  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_39], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8.run(buf513, arg3_1, buf514, buf516, buf517, 16, 256, stream=raw_stream0)
        assert_size_stride(arg288_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_17, cache_position_13, index_copy__27], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_9.run(arg286_1, buf502, arg288_1, 1024, stream=raw_stream0)
        buf521 = reinterpret_tensor(buf507, (1, 1, 2048), (2048, 128, 1), 0); del buf507  # reuse
        # Topologically Sorted Source Nodes: [attn_output_39, value_13, transpose_55, reshape_41, output_94], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf514, buf516, buf517, arg288_1, buf521, 2048, 256, stream=raw_stream0)
        del arg288_1
        buf520 = buf498; del buf498  # reuse
        assert_size_stride_grouped((arg289_1, arg290_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_39, transpose_55, reshape_41, output_94], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf521, arg289_1, buf520, arg290_1, 1, 2048, 2048, 128, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg289_1
        del arg290_1
        assert_size_stride(arg291_1, (2048, ), (1, ), 'input')
        buf523 = buf447; del buf447  # reuse
        buf526 = reinterpret_tensor(buf521, (1, 1, 2048), (2048, 2048, 1), 0); del buf521  # reuse
        buf529 = buf379; del buf379  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_167, hidden_states_177, hidden_states_181, hidden_states_191, hidden_states_192, pow_56, variance_55, add_126, rsqrt_55, hidden_states_193, to_115, hidden_states_194, output_95, output_96], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_18.run(buf523, buf455, buf484, buf493, buf520, arg291_1, buf526, buf529, 1, 2048, stream=raw_stream0)
        del arg291_1
        buf525 = buf494; del buf494  # reuse
        assert_size_stride_grouped((arg292_1, arg293_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_192, pow_56, variance_55, add_126, rsqrt_55, hidden_states_193, to_115, hidden_states_194, output_95], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf526, arg292_1, buf525, arg293_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg292_1
        del arg293_1
        buf528 = buf491; del buf491  # reuse
        assert_size_stride_grouped((arg294_1, arg295_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_192, pow_56, variance_55, add_126, rsqrt_55, hidden_states_193, to_115, hidden_states_194, output_96], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf529, arg294_1, buf528, arg295_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg294_1
        del arg295_1
        buf531 = buf529; del buf529  # reuse
        buf532 = buf489; del buf489  # reuse
        # Topologically Sorted Source Nodes: [silu_13, mul_184, output_97], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_12.run(buf525, buf528, buf532, 6144, stream=raw_stream0)
        assert_size_stride_grouped((arg296_1, arg297_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_13, mul_184, output_97], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf532, arg296_1, buf531, arg297_1, 1, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg296_1
        del arg297_1
        assert_size_stride(arg298_1, (2048, ), (1, ), 'input')
        buf536 = buf526; del buf526  # reuse
        buf539 = buf520; del buf520  # reuse
        buf542 = buf493; del buf493  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_195, hidden_states_196, pow_57, variance_56, add_128, rsqrt_56, hidden_states_197, to_117, hidden_states_198, output_98, output_99, output_100], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_15.run(buf523, buf531, arg298_1, buf536, buf539, buf542, 1, 2048, stream=raw_stream0)
        del arg298_1
        buf535 = buf484; del buf484  # reuse
        assert_size_stride_grouped((arg299_1, arg300_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_195, hidden_states_196, pow_57, variance_56, add_128, rsqrt_56, hidden_states_197, to_117, hidden_states_198, output_98], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf536, arg299_1, buf535, arg300_1, 1, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg299_1
        del arg300_1
        buf538 = buf502; del buf502  # reuse
        assert_size_stride_grouped((arg302_1, arg303_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_195, hidden_states_196, pow_57, variance_56, add_128, rsqrt_56, hidden_states_197, to_117, hidden_states_198, output_99], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf539, arg302_1, buf538, arg303_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg302_1
        del arg303_1
        buf541 = reinterpret_tensor(buf511, (1, 1, 1024), (1024, 1024, 1), 0); del buf511  # reuse
        assert_size_stride_grouped((arg305_1, arg306_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_195, hidden_states_196, pow_57, variance_56, add_128, rsqrt_56, hidden_states_197, to_117, hidden_states_198, output_100], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf542, arg305_1, buf541, arg306_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg305_1
        del arg306_1
        buf544 = reinterpret_tensor(buf517, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf517  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_199, pow_58, variance_57], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf535, buf544, 16, 128, stream=raw_stream0)
        assert_size_stride(arg301_1, (128, ), (1, ), 'input')
        buf547 = reinterpret_tensor(buf542, (1, 16, 1, 128), (2048, 128, 128, 1), 0); del buf542  # reuse
        buf545 = reinterpret_tensor(buf547, (1, 16, 1, 64), (2048, 128, 128, 1), 0)  # alias
        buf546 = reinterpret_tensor(buf547, (1, 16, 1, 64), (2048, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_199, pow_58, variance_57, add_129, rsqrt_57, hidden_states_200, to_119, mul_188, query_states_14, x2_28, neg_28, x1_28, cat_30], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg301_1, buf535, buf544, buf545, buf546, 1024, stream=raw_stream0)
        buf548 = buf508; del buf508  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_201, pow_59, variance_58], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf538, buf548, 8, 128, stream=raw_stream0)
        del buf545
        del buf546
        assert_size_stride(arg304_1, (128, ), (1, ), 'input')
        buf551 = reinterpret_tensor(buf500, (1, 8, 1, 128), (1024, 128, 128, 1), 0); del buf500  # reuse
        buf549 = reinterpret_tensor(buf551, (1, 8, 1, 64), (1024, 128, 128, 1), 0)  # alias
        buf550 = reinterpret_tensor(buf551, (1, 8, 1, 64), (1024, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_201, pow_59, variance_58, add_130, rsqrt_58, hidden_states_202, to_121, mul_190, key_states_14, x2_29, neg_29, x1_29, cat_31], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg304_1, buf538, buf548, buf549, buf550, 512, stream=raw_stream0)
        assert_size_stride_grouped((arg307_1, arg308_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_18, sin_18, arange_18, cache_position_14, hidden_states_201, pow_59, variance_58, add_130, rsqrt_58, hidden_states_202, to_121, mul_190, key_states_14, mul_193, mul_194, k_embed_14, index_copy__28], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg307_1, arg304_1, buf538, buf548, buf1, buf551, buf0, arg308_1, 1024, stream=raw_stream0)
        del arg304_1
        del buf549
        del buf550
        buf553 = reinterpret_tensor(buf516, (16, 1, 256), (256, 256, 1), 0); del buf516  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_199, pow_58, variance_57, add_129, rsqrt_57, hidden_states_200, to_119, mul_188, query_states_14, cos_18, mul_191, sin_18, mul_192, q_embed_14, attn_output_42, key_14], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg301_1, buf535, buf544, buf1, buf547, buf0, arg308_1, buf553, 4096, 128, stream=raw_stream0)
        del arg301_1
        del arg308_1
        buf554 = buf514; del buf514  # reuse
        buf556 = reinterpret_tensor(buf513, (1, 16, 1, 256), (4096, 256, 4096, 1), 0); del buf513  # reuse
        buf557 = reinterpret_tensor(buf544, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf544  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_42], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8.run(buf553, arg3_1, buf554, buf556, buf557, 16, 256, stream=raw_stream0)
        assert_size_stride(arg309_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_18, cache_position_14, index_copy__29], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_9.run(arg307_1, buf541, arg309_1, 1024, stream=raw_stream0)
        buf561 = reinterpret_tensor(buf547, (1, 1, 2048), (2048, 128, 1), 0); del buf547  # reuse
        # Topologically Sorted Source Nodes: [attn_output_42, value_14, transpose_59, reshape_44, output_101], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf554, buf556, buf557, arg309_1, buf561, 2048, 256, stream=raw_stream0)
        del arg309_1
        buf560 = buf535; del buf535  # reuse
        assert_size_stride_grouped((arg310_1, arg311_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_42, transpose_59, reshape_44, output_101], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf561, arg310_1, buf560, arg311_1, 1, 2048, 2048, 128, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg310_1
        del arg311_1
        assert_size_stride(arg312_1, (2048, ), (1, ), 'input')
        buf564 = reinterpret_tensor(buf561, (1, 1, 2048), (2048, 2048, 1), 0); del buf561  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_195, hidden_states_205, hidden_states_206, pow_60, variance_59, add_135, rsqrt_59, hidden_states_207, to_123, hidden_states_208], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_16.run(buf523, buf531, buf560, arg312_1, buf564, 1, 2048, stream=raw_stream0)
        del arg312_1
        buf565 = buf532; del buf532  # reuse
        assert_size_stride_grouped((arg313_1, arg314_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_102], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf564, arg313_1, buf565, arg314_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg313_1
        del arg314_1
        buf567 = buf528; del buf528  # reuse
        assert_size_stride_grouped((arg315_1, arg316_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_103], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf564, arg315_1, buf567, arg316_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg315_1
        del arg316_1
        buf569 = buf564; del buf564  # reuse
        buf570 = buf525; del buf525  # reuse
        # Topologically Sorted Source Nodes: [silu_14, mul_197, output_104], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_12.run(buf565, buf567, buf570, 6144, stream=raw_stream0)
        assert_size_stride_grouped((arg317_1, arg318_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_14, mul_197, output_104], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf570, arg317_1, buf569, arg318_1, 1, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg317_1
        del arg318_1
        assert_size_stride(arg319_1, (2048, ), (1, ), 'input')
        buf573 = buf539; del buf539  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_195, hidden_states_205, hidden_states_209, hidden_states_210, pow_61, variance_60, add_137, rsqrt_60, hidden_states_211, to_125, hidden_states_212], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_17.run(buf523, buf531, buf560, buf569, arg319_1, buf573, 1, 2048, stream=raw_stream0)
        del arg319_1
        buf574 = buf536; del buf536  # reuse
        assert_size_stride_grouped((arg320_1, arg321_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_105], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf573, arg320_1, buf574, arg321_1, 1, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg320_1
        del arg321_1
        buf576 = buf541; del buf541  # reuse
        assert_size_stride_grouped((arg323_1, arg324_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_106], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf573, arg323_1, buf576, arg324_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg323_1
        del arg324_1
        buf578 = reinterpret_tensor(buf551, (1, 1, 1024), (1024, 1024, 1), 0); del buf551  # reuse
        assert_size_stride_grouped((arg326_1, arg327_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_107], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf573, arg326_1, buf578, arg327_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg326_1
        del arg327_1
        buf580 = reinterpret_tensor(buf557, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf557  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_213, pow_62, variance_61], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf574, buf580, 16, 128, stream=raw_stream0)
        assert_size_stride(arg322_1, (128, ), (1, ), 'input')
        buf583 = reinterpret_tensor(buf573, (1, 16, 1, 128), (2048, 128, 128, 1), 0); del buf573  # reuse
        buf581 = reinterpret_tensor(buf583, (1, 16, 1, 64), (2048, 128, 128, 1), 0)  # alias
        buf582 = reinterpret_tensor(buf583, (1, 16, 1, 64), (2048, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_213, pow_62, variance_61, add_138, rsqrt_61, hidden_states_214, to_127, mul_201, query_states_15, x2_30, neg_30, x1_30, cat_32], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg322_1, buf574, buf580, buf581, buf582, 1024, stream=raw_stream0)
        buf584 = buf548; del buf548  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_215, pow_63, variance_62], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf576, buf584, 8, 128, stream=raw_stream0)
        del buf581
        del buf582
        assert_size_stride(arg325_1, (128, ), (1, ), 'input')
        buf587 = reinterpret_tensor(buf538, (1, 8, 1, 128), (1024, 128, 128, 1), 0); del buf538  # reuse
        buf585 = reinterpret_tensor(buf587, (1, 8, 1, 64), (1024, 128, 128, 1), 0)  # alias
        buf586 = reinterpret_tensor(buf587, (1, 8, 1, 64), (1024, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_215, pow_63, variance_62, add_139, rsqrt_62, hidden_states_216, to_129, mul_203, key_states_15, x2_31, neg_31, x1_31, cat_33], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg325_1, buf576, buf584, buf585, buf586, 512, stream=raw_stream0)
        assert_size_stride_grouped((arg328_1, arg329_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_19, sin_19, arange_19, cache_position_15, hidden_states_215, pow_63, variance_62, add_139, rsqrt_62, hidden_states_216, to_129, mul_203, key_states_15, mul_206, mul_207, k_embed_15, index_copy__30], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg328_1, arg325_1, buf576, buf584, buf1, buf587, buf0, arg329_1, 1024, stream=raw_stream0)
        del arg325_1
        del buf585
        del buf586
        buf589 = reinterpret_tensor(buf556, (16, 1, 256), (256, 256, 1), 0); del buf556  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_213, pow_62, variance_61, add_138, rsqrt_61, hidden_states_214, to_127, mul_201, query_states_15, cos_19, mul_204, sin_19, mul_205, q_embed_15, attn_output_45, key_15], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg322_1, buf574, buf580, buf1, buf583, buf0, arg329_1, buf589, 4096, 128, stream=raw_stream0)
        del arg322_1
        del arg329_1
        buf590 = buf554; del buf554  # reuse
        buf592 = reinterpret_tensor(buf553, (1, 16, 1, 256), (4096, 256, 4096, 1), 0); del buf553  # reuse
        buf593 = reinterpret_tensor(buf580, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf580  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_45], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8.run(buf589, arg3_1, buf590, buf592, buf593, 16, 256, stream=raw_stream0)
        assert_size_stride(arg330_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_19, cache_position_15, index_copy__31], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_9.run(arg328_1, buf578, arg330_1, 1024, stream=raw_stream0)
        buf597 = reinterpret_tensor(buf583, (1, 1, 2048), (2048, 128, 1), 0); del buf583  # reuse
        # Topologically Sorted Source Nodes: [attn_output_45, value_15, transpose_63, reshape_47, output_108], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf590, buf592, buf593, arg330_1, buf597, 2048, 256, stream=raw_stream0)
        del arg330_1
        buf596 = buf574; del buf574  # reuse
        assert_size_stride_grouped((arg331_1, arg332_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_45, transpose_63, reshape_47, output_108], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf597, arg331_1, buf596, arg332_1, 1, 2048, 2048, 128, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg331_1
        del arg332_1
        assert_size_stride(arg333_1, (2048, ), (1, ), 'input')
        buf599 = buf523; del buf523  # reuse
        buf602 = reinterpret_tensor(buf597, (1, 1, 2048), (2048, 2048, 1), 0); del buf597  # reuse
        buf605 = buf455; del buf455  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_195, hidden_states_205, hidden_states_209, hidden_states_219, hidden_states_220, pow_64, variance_63, add_144, rsqrt_63, hidden_states_221, to_131, hidden_states_222, output_109, output_110], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_18.run(buf599, buf531, buf560, buf569, buf596, arg333_1, buf602, buf605, 1, 2048, stream=raw_stream0)
        del arg333_1
        buf601 = buf570; del buf570  # reuse
        assert_size_stride_grouped((arg334_1, arg335_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_220, pow_64, variance_63, add_144, rsqrt_63, hidden_states_221, to_131, hidden_states_222, output_109], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf602, arg334_1, buf601, arg335_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg334_1
        del arg335_1
        buf604 = buf567; del buf567  # reuse
        assert_size_stride_grouped((arg336_1, arg337_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_220, pow_64, variance_63, add_144, rsqrt_63, hidden_states_221, to_131, hidden_states_222, output_110], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf605, arg336_1, buf604, arg337_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg336_1
        del arg337_1
        buf607 = buf605; del buf605  # reuse
        buf608 = buf565; del buf565  # reuse
        # Topologically Sorted Source Nodes: [silu_15, mul_210, output_111], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_12.run(buf601, buf604, buf608, 6144, stream=raw_stream0)
        assert_size_stride_grouped((arg338_1, arg339_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_15, mul_210, output_111], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf608, arg338_1, buf607, arg339_1, 1, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg338_1
        del arg339_1
        assert_size_stride(arg340_1, (2048, ), (1, ), 'input')
        buf612 = buf602; del buf602  # reuse
        buf615 = buf596; del buf596  # reuse
        buf618 = buf569; del buf569  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_223, hidden_states_224, pow_65, variance_64, add_146, rsqrt_64, hidden_states_225, to_133, hidden_states_226, output_112, output_113, output_114], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_15.run(buf599, buf607, arg340_1, buf612, buf615, buf618, 1, 2048, stream=raw_stream0)
        del arg340_1
        buf611 = buf560; del buf560  # reuse
        assert_size_stride_grouped((arg341_1, arg342_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_223, hidden_states_224, pow_65, variance_64, add_146, rsqrt_64, hidden_states_225, to_133, hidden_states_226, output_112], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf612, arg341_1, buf611, arg342_1, 1, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg341_1
        del arg342_1
        buf614 = buf578; del buf578  # reuse
        assert_size_stride_grouped((arg344_1, arg345_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_223, hidden_states_224, pow_65, variance_64, add_146, rsqrt_64, hidden_states_225, to_133, hidden_states_226, output_113], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf615, arg344_1, buf614, arg345_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg344_1
        del arg345_1
        buf617 = reinterpret_tensor(buf587, (1, 1, 1024), (1024, 1024, 1), 0); del buf587  # reuse
        assert_size_stride_grouped((arg347_1, arg348_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_223, hidden_states_224, pow_65, variance_64, add_146, rsqrt_64, hidden_states_225, to_133, hidden_states_226, output_114], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf618, arg347_1, buf617, arg348_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg347_1
        del arg348_1
        buf620 = reinterpret_tensor(buf593, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf593  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_227, pow_66, variance_65], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf611, buf620, 16, 128, stream=raw_stream0)
        assert_size_stride(arg343_1, (128, ), (1, ), 'input')
        buf623 = reinterpret_tensor(buf618, (1, 16, 1, 128), (2048, 128, 128, 1), 0); del buf618  # reuse
        buf621 = reinterpret_tensor(buf623, (1, 16, 1, 64), (2048, 128, 128, 1), 0)  # alias
        buf622 = reinterpret_tensor(buf623, (1, 16, 1, 64), (2048, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_227, pow_66, variance_65, add_147, rsqrt_65, hidden_states_228, to_135, mul_214, query_states_16, x2_32, neg_32, x1_32, cat_34], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg343_1, buf611, buf620, buf621, buf622, 1024, stream=raw_stream0)
        buf624 = buf584; del buf584  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_229, pow_67, variance_66], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf614, buf624, 8, 128, stream=raw_stream0)
        del buf621
        del buf622
        assert_size_stride(arg346_1, (128, ), (1, ), 'input')
        buf627 = reinterpret_tensor(buf576, (1, 8, 1, 128), (1024, 128, 128, 1), 0); del buf576  # reuse
        buf625 = reinterpret_tensor(buf627, (1, 8, 1, 64), (1024, 128, 128, 1), 0)  # alias
        buf626 = reinterpret_tensor(buf627, (1, 8, 1, 64), (1024, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_229, pow_67, variance_66, add_148, rsqrt_66, hidden_states_230, to_137, mul_216, key_states_16, x2_33, neg_33, x1_33, cat_35], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg346_1, buf614, buf624, buf625, buf626, 512, stream=raw_stream0)
        assert_size_stride_grouped((arg349_1, arg350_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_20, sin_20, arange_20, cache_position_16, hidden_states_229, pow_67, variance_66, add_148, rsqrt_66, hidden_states_230, to_137, mul_216, key_states_16, mul_219, mul_220, k_embed_16, index_copy__32], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg349_1, arg346_1, buf614, buf624, buf1, buf627, buf0, arg350_1, 1024, stream=raw_stream0)
        del arg346_1
        del buf625
        del buf626
        buf629 = reinterpret_tensor(buf592, (16, 1, 256), (256, 256, 1), 0); del buf592  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_227, pow_66, variance_65, add_147, rsqrt_65, hidden_states_228, to_135, mul_214, query_states_16, cos_20, mul_217, sin_20, mul_218, q_embed_16, attn_output_48, key_16], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg343_1, buf611, buf620, buf1, buf623, buf0, arg350_1, buf629, 4096, 128, stream=raw_stream0)
        del arg343_1
        del arg350_1
        buf630 = buf590; del buf590  # reuse
        buf632 = reinterpret_tensor(buf589, (1, 16, 1, 256), (4096, 256, 4096, 1), 0); del buf589  # reuse
        buf633 = reinterpret_tensor(buf620, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf620  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_48], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8.run(buf629, arg3_1, buf630, buf632, buf633, 16, 256, stream=raw_stream0)
        assert_size_stride(arg351_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_20, cache_position_16, index_copy__33], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_9.run(arg349_1, buf617, arg351_1, 1024, stream=raw_stream0)
        buf637 = reinterpret_tensor(buf623, (1, 1, 2048), (2048, 128, 1), 0); del buf623  # reuse
        # Topologically Sorted Source Nodes: [attn_output_48, value_16, transpose_67, reshape_50, output_115], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf630, buf632, buf633, arg351_1, buf637, 2048, 256, stream=raw_stream0)
        del arg351_1
        buf636 = buf611; del buf611  # reuse
        assert_size_stride_grouped((arg352_1, arg353_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_48, transpose_67, reshape_50, output_115], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf637, arg352_1, buf636, arg353_1, 1, 2048, 2048, 128, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg352_1
        del arg353_1
        assert_size_stride(arg354_1, (2048, ), (1, ), 'input')
        buf640 = reinterpret_tensor(buf637, (1, 1, 2048), (2048, 2048, 1), 0); del buf637  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_223, hidden_states_233, hidden_states_234, pow_68, variance_67, add_153, rsqrt_67, hidden_states_235, to_139, hidden_states_236], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_16.run(buf599, buf607, buf636, arg354_1, buf640, 1, 2048, stream=raw_stream0)
        del arg354_1
        buf641 = buf608; del buf608  # reuse
        assert_size_stride_grouped((arg355_1, arg356_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_116], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf640, arg355_1, buf641, arg356_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg355_1
        del arg356_1
        buf643 = buf604; del buf604  # reuse
        assert_size_stride_grouped((arg357_1, arg358_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_117], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf640, arg357_1, buf643, arg358_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg357_1
        del arg358_1
        buf645 = buf640; del buf640  # reuse
        buf646 = buf601; del buf601  # reuse
        # Topologically Sorted Source Nodes: [silu_16, mul_223, output_118], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_12.run(buf641, buf643, buf646, 6144, stream=raw_stream0)
        assert_size_stride_grouped((arg359_1, arg360_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_16, mul_223, output_118], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf646, arg359_1, buf645, arg360_1, 1, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg359_1
        del arg360_1
        assert_size_stride(arg361_1, (2048, ), (1, ), 'input')
        buf649 = buf615; del buf615  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_223, hidden_states_233, hidden_states_237, hidden_states_238, pow_69, variance_68, add_155, rsqrt_68, hidden_states_239, to_141, hidden_states_240], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_17.run(buf599, buf607, buf636, buf645, arg361_1, buf649, 1, 2048, stream=raw_stream0)
        del arg361_1
        buf650 = buf612; del buf612  # reuse
        assert_size_stride_grouped((arg362_1, arg363_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_119], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf649, arg362_1, buf650, arg363_1, 1, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg362_1
        del arg363_1
        buf652 = buf617; del buf617  # reuse
        assert_size_stride_grouped((arg365_1, arg366_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_120], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf649, arg365_1, buf652, arg366_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg365_1
        del arg366_1
        buf654 = reinterpret_tensor(buf627, (1, 1, 1024), (1024, 1024, 1), 0); del buf627  # reuse
        assert_size_stride_grouped((arg368_1, arg369_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_121], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf649, arg368_1, buf654, arg369_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg368_1
        del arg369_1
        buf656 = reinterpret_tensor(buf633, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf633  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_241, pow_70, variance_69], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf650, buf656, 16, 128, stream=raw_stream0)
        assert_size_stride(arg364_1, (128, ), (1, ), 'input')
        buf659 = reinterpret_tensor(buf649, (1, 16, 1, 128), (2048, 128, 128, 1), 0); del buf649  # reuse
        buf657 = reinterpret_tensor(buf659, (1, 16, 1, 64), (2048, 128, 128, 1), 0)  # alias
        buf658 = reinterpret_tensor(buf659, (1, 16, 1, 64), (2048, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_241, pow_70, variance_69, add_156, rsqrt_69, hidden_states_242, to_143, mul_227, query_states_17, x2_34, neg_34, x1_34, cat_36], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg364_1, buf650, buf656, buf657, buf658, 1024, stream=raw_stream0)
        buf660 = buf624; del buf624  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_243, pow_71, variance_70], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf652, buf660, 8, 128, stream=raw_stream0)
        del buf657
        del buf658
        assert_size_stride(arg367_1, (128, ), (1, ), 'input')
        buf663 = reinterpret_tensor(buf614, (1, 8, 1, 128), (1024, 128, 128, 1), 0); del buf614  # reuse
        buf661 = reinterpret_tensor(buf663, (1, 8, 1, 64), (1024, 128, 128, 1), 0)  # alias
        buf662 = reinterpret_tensor(buf663, (1, 8, 1, 64), (1024, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_243, pow_71, variance_70, add_157, rsqrt_70, hidden_states_244, to_145, mul_229, key_states_17, x2_35, neg_35, x1_35, cat_37], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg367_1, buf652, buf660, buf661, buf662, 512, stream=raw_stream0)
        assert_size_stride_grouped((arg370_1, arg371_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_21, sin_21, arange_21, cache_position_17, hidden_states_243, pow_71, variance_70, add_157, rsqrt_70, hidden_states_244, to_145, mul_229, key_states_17, mul_232, mul_233, k_embed_17, index_copy__34], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg370_1, arg367_1, buf652, buf660, buf1, buf663, buf0, arg371_1, 1024, stream=raw_stream0)
        del arg367_1
        del buf661
        del buf662
        buf665 = reinterpret_tensor(buf632, (16, 1, 256), (256, 256, 1), 0); del buf632  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_241, pow_70, variance_69, add_156, rsqrt_69, hidden_states_242, to_143, mul_227, query_states_17, cos_21, mul_230, sin_21, mul_231, q_embed_17, attn_output_51, key_17], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg364_1, buf650, buf656, buf1, buf659, buf0, arg371_1, buf665, 4096, 128, stream=raw_stream0)
        del arg364_1
        del arg371_1
        buf666 = buf630; del buf630  # reuse
        buf668 = reinterpret_tensor(buf629, (1, 16, 1, 256), (4096, 256, 4096, 1), 0); del buf629  # reuse
        buf669 = reinterpret_tensor(buf656, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf656  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_51], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8.run(buf665, arg3_1, buf666, buf668, buf669, 16, 256, stream=raw_stream0)
        assert_size_stride(arg372_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_21, cache_position_17, index_copy__35], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_9.run(arg370_1, buf654, arg372_1, 1024, stream=raw_stream0)
        buf673 = reinterpret_tensor(buf659, (1, 1, 2048), (2048, 128, 1), 0); del buf659  # reuse
        # Topologically Sorted Source Nodes: [attn_output_51, value_17, transpose_71, reshape_53, output_122], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf666, buf668, buf669, arg372_1, buf673, 2048, 256, stream=raw_stream0)
        del arg372_1
        buf672 = buf650; del buf650  # reuse
        assert_size_stride_grouped((arg373_1, arg374_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_51, transpose_71, reshape_53, output_122], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf673, arg373_1, buf672, arg374_1, 1, 2048, 2048, 128, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg373_1
        del arg374_1
        assert_size_stride(arg375_1, (2048, ), (1, ), 'input')
        buf675 = buf599; del buf599  # reuse
        buf678 = reinterpret_tensor(buf673, (1, 1, 2048), (2048, 2048, 1), 0); del buf673  # reuse
        buf681 = buf531; del buf531  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_223, hidden_states_233, hidden_states_237, hidden_states_247, hidden_states_248, pow_72, variance_71, add_162, rsqrt_71, hidden_states_249, to_147, hidden_states_250, output_123, output_124], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_18.run(buf675, buf607, buf636, buf645, buf672, arg375_1, buf678, buf681, 1, 2048, stream=raw_stream0)
        del arg375_1
        buf677 = buf646; del buf646  # reuse
        assert_size_stride_grouped((arg376_1, arg377_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_248, pow_72, variance_71, add_162, rsqrt_71, hidden_states_249, to_147, hidden_states_250, output_123], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf678, arg376_1, buf677, arg377_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg376_1
        del arg377_1
        buf680 = buf643; del buf643  # reuse
        assert_size_stride_grouped((arg378_1, arg379_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_248, pow_72, variance_71, add_162, rsqrt_71, hidden_states_249, to_147, hidden_states_250, output_124], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf681, arg378_1, buf680, arg379_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg378_1
        del arg379_1
        buf683 = buf681; del buf681  # reuse
        buf684 = buf641; del buf641  # reuse
        # Topologically Sorted Source Nodes: [silu_17, mul_236, output_125], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_12.run(buf677, buf680, buf684, 6144, stream=raw_stream0)
        assert_size_stride_grouped((arg380_1, arg381_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_17, mul_236, output_125], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf684, arg380_1, buf683, arg381_1, 1, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg380_1
        del arg381_1
        assert_size_stride(arg382_1, (2048, ), (1, ), 'input')
        buf688 = buf678; del buf678  # reuse
        buf691 = buf672; del buf672  # reuse
        buf694 = buf645; del buf645  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_251, hidden_states_252, pow_73, variance_72, add_164, rsqrt_72, hidden_states_253, to_149, hidden_states_254, output_126, output_127, output_128], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_15.run(buf675, buf683, arg382_1, buf688, buf691, buf694, 1, 2048, stream=raw_stream0)
        del arg382_1
        buf687 = buf636; del buf636  # reuse
        assert_size_stride_grouped((arg383_1, arg384_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_251, hidden_states_252, pow_73, variance_72, add_164, rsqrt_72, hidden_states_253, to_149, hidden_states_254, output_126], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf688, arg383_1, buf687, arg384_1, 1, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg383_1
        del arg384_1
        buf690 = buf654; del buf654  # reuse
        assert_size_stride_grouped((arg386_1, arg387_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_251, hidden_states_252, pow_73, variance_72, add_164, rsqrt_72, hidden_states_253, to_149, hidden_states_254, output_127], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf691, arg386_1, buf690, arg387_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg386_1
        del arg387_1
        buf693 = reinterpret_tensor(buf663, (1, 1, 1024), (1024, 1024, 1), 0); del buf663  # reuse
        assert_size_stride_grouped((arg389_1, arg390_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_251, hidden_states_252, pow_73, variance_72, add_164, rsqrt_72, hidden_states_253, to_149, hidden_states_254, output_128], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf694, arg389_1, buf693, arg390_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg389_1
        del arg390_1
        buf696 = reinterpret_tensor(buf669, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf669  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_255, pow_74, variance_73], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf687, buf696, 16, 128, stream=raw_stream0)
        assert_size_stride(arg385_1, (128, ), (1, ), 'input')
        buf699 = reinterpret_tensor(buf694, (1, 16, 1, 128), (2048, 128, 128, 1), 0); del buf694  # reuse
        buf697 = reinterpret_tensor(buf699, (1, 16, 1, 64), (2048, 128, 128, 1), 0)  # alias
        buf698 = reinterpret_tensor(buf699, (1, 16, 1, 64), (2048, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_255, pow_74, variance_73, add_165, rsqrt_73, hidden_states_256, to_151, mul_240, query_states_18, x2_36, neg_36, x1_36, cat_38], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg385_1, buf687, buf696, buf697, buf698, 1024, stream=raw_stream0)
        buf700 = buf660; del buf660  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_257, pow_75, variance_74], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf690, buf700, 8, 128, stream=raw_stream0)
        del buf697
        del buf698
        assert_size_stride(arg388_1, (128, ), (1, ), 'input')
        buf703 = reinterpret_tensor(buf652, (1, 8, 1, 128), (1024, 128, 128, 1), 0); del buf652  # reuse
        buf701 = reinterpret_tensor(buf703, (1, 8, 1, 64), (1024, 128, 128, 1), 0)  # alias
        buf702 = reinterpret_tensor(buf703, (1, 8, 1, 64), (1024, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_257, pow_75, variance_74, add_166, rsqrt_74, hidden_states_258, to_153, mul_242, key_states_18, x2_37, neg_37, x1_37, cat_39], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg388_1, buf690, buf700, buf701, buf702, 512, stream=raw_stream0)
        assert_size_stride_grouped((arg391_1, arg392_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_22, sin_22, arange_22, cache_position_18, hidden_states_257, pow_75, variance_74, add_166, rsqrt_74, hidden_states_258, to_153, mul_242, key_states_18, mul_245, mul_246, k_embed_18, index_copy__36], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg391_1, arg388_1, buf690, buf700, buf1, buf703, buf0, arg392_1, 1024, stream=raw_stream0)
        del arg388_1
        del buf701
        del buf702
        buf705 = reinterpret_tensor(buf668, (16, 1, 256), (256, 256, 1), 0); del buf668  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_255, pow_74, variance_73, add_165, rsqrt_73, hidden_states_256, to_151, mul_240, query_states_18, cos_22, mul_243, sin_22, mul_244, q_embed_18, attn_output_54, key_18], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg385_1, buf687, buf696, buf1, buf699, buf0, arg392_1, buf705, 4096, 128, stream=raw_stream0)
        del arg385_1
        del arg392_1
        buf706 = buf666; del buf666  # reuse
        buf708 = reinterpret_tensor(buf665, (1, 16, 1, 256), (4096, 256, 4096, 1), 0); del buf665  # reuse
        buf709 = reinterpret_tensor(buf696, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf696  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_54], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8.run(buf705, arg3_1, buf706, buf708, buf709, 16, 256, stream=raw_stream0)
        assert_size_stride(arg393_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_22, cache_position_18, index_copy__37], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_9.run(arg391_1, buf693, arg393_1, 1024, stream=raw_stream0)
        buf713 = reinterpret_tensor(buf699, (1, 1, 2048), (2048, 128, 1), 0); del buf699  # reuse
        # Topologically Sorted Source Nodes: [attn_output_54, value_18, transpose_75, reshape_56, output_129], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf706, buf708, buf709, arg393_1, buf713, 2048, 256, stream=raw_stream0)
        del arg393_1
        buf712 = buf687; del buf687  # reuse
        assert_size_stride_grouped((arg394_1, arg395_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_54, transpose_75, reshape_56, output_129], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf713, arg394_1, buf712, arg395_1, 1, 2048, 2048, 128, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg394_1
        del arg395_1
        assert_size_stride(arg396_1, (2048, ), (1, ), 'input')
        buf716 = reinterpret_tensor(buf713, (1, 1, 2048), (2048, 2048, 1), 0); del buf713  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_251, hidden_states_261, hidden_states_262, pow_76, variance_75, add_171, rsqrt_75, hidden_states_263, to_155, hidden_states_264], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_16.run(buf675, buf683, buf712, arg396_1, buf716, 1, 2048, stream=raw_stream0)
        del arg396_1
        buf717 = buf684; del buf684  # reuse
        assert_size_stride_grouped((arg397_1, arg398_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_130], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf716, arg397_1, buf717, arg398_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg397_1
        del arg398_1
        buf719 = buf680; del buf680  # reuse
        assert_size_stride_grouped((arg399_1, arg400_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_131], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf716, arg399_1, buf719, arg400_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg399_1
        del arg400_1
        buf721 = buf716; del buf716  # reuse
        buf722 = buf677; del buf677  # reuse
        # Topologically Sorted Source Nodes: [silu_18, mul_249, output_132], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_12.run(buf717, buf719, buf722, 6144, stream=raw_stream0)
        assert_size_stride_grouped((arg401_1, arg402_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_18, mul_249, output_132], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf722, arg401_1, buf721, arg402_1, 1, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg401_1
        del arg402_1
        assert_size_stride(arg403_1, (2048, ), (1, ), 'input')
        buf725 = buf691; del buf691  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_251, hidden_states_261, hidden_states_265, hidden_states_266, pow_77, variance_76, add_173, rsqrt_76, hidden_states_267, to_157, hidden_states_268], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_17.run(buf675, buf683, buf712, buf721, arg403_1, buf725, 1, 2048, stream=raw_stream0)
        del arg403_1
        buf726 = buf688; del buf688  # reuse
        assert_size_stride_grouped((arg404_1, arg405_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_133], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf725, arg404_1, buf726, arg405_1, 1, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg404_1
        del arg405_1
        buf728 = buf693; del buf693  # reuse
        assert_size_stride_grouped((arg407_1, arg408_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_134], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf725, arg407_1, buf728, arg408_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg407_1
        del arg408_1
        buf730 = reinterpret_tensor(buf703, (1, 1, 1024), (1024, 1024, 1), 0); del buf703  # reuse
        assert_size_stride_grouped((arg410_1, arg411_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_135], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf725, arg410_1, buf730, arg411_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg410_1
        del arg411_1
        buf732 = reinterpret_tensor(buf709, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf709  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_269, pow_78, variance_77], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf726, buf732, 16, 128, stream=raw_stream0)
        assert_size_stride(arg406_1, (128, ), (1, ), 'input')
        buf735 = reinterpret_tensor(buf725, (1, 16, 1, 128), (2048, 128, 128, 1), 0); del buf725  # reuse
        buf733 = reinterpret_tensor(buf735, (1, 16, 1, 64), (2048, 128, 128, 1), 0)  # alias
        buf734 = reinterpret_tensor(buf735, (1, 16, 1, 64), (2048, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_269, pow_78, variance_77, add_174, rsqrt_77, hidden_states_270, to_159, mul_253, query_states_19, x2_38, neg_38, x1_38, cat_40], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg406_1, buf726, buf732, buf733, buf734, 1024, stream=raw_stream0)
        buf736 = buf700; del buf700  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_271, pow_79, variance_78], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf728, buf736, 8, 128, stream=raw_stream0)
        del buf733
        del buf734
        assert_size_stride(arg409_1, (128, ), (1, ), 'input')
        buf739 = reinterpret_tensor(buf690, (1, 8, 1, 128), (1024, 128, 128, 1), 0); del buf690  # reuse
        buf737 = reinterpret_tensor(buf739, (1, 8, 1, 64), (1024, 128, 128, 1), 0)  # alias
        buf738 = reinterpret_tensor(buf739, (1, 8, 1, 64), (1024, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_271, pow_79, variance_78, add_175, rsqrt_78, hidden_states_272, to_161, mul_255, key_states_19, x2_39, neg_39, x1_39, cat_41], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg409_1, buf728, buf736, buf737, buf738, 512, stream=raw_stream0)
        assert_size_stride_grouped((arg412_1, arg413_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_23, sin_23, arange_23, cache_position_19, hidden_states_271, pow_79, variance_78, add_175, rsqrt_78, hidden_states_272, to_161, mul_255, key_states_19, mul_258, mul_259, k_embed_19, index_copy__38], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg412_1, arg409_1, buf728, buf736, buf1, buf739, buf0, arg413_1, 1024, stream=raw_stream0)
        del arg409_1
        del buf737
        del buf738
        buf741 = reinterpret_tensor(buf708, (16, 1, 256), (256, 256, 1), 0); del buf708  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_269, pow_78, variance_77, add_174, rsqrt_77, hidden_states_270, to_159, mul_253, query_states_19, cos_23, mul_256, sin_23, mul_257, q_embed_19, attn_output_57, key_19], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg406_1, buf726, buf732, buf1, buf735, buf0, arg413_1, buf741, 4096, 128, stream=raw_stream0)
        del arg406_1
        del arg413_1
        buf742 = buf706; del buf706  # reuse
        buf744 = reinterpret_tensor(buf705, (1, 16, 1, 256), (4096, 256, 4096, 1), 0); del buf705  # reuse
        buf745 = reinterpret_tensor(buf732, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf732  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_57], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8.run(buf741, arg3_1, buf742, buf744, buf745, 16, 256, stream=raw_stream0)
        assert_size_stride(arg414_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_23, cache_position_19, index_copy__39], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_9.run(arg412_1, buf730, arg414_1, 1024, stream=raw_stream0)
        buf749 = reinterpret_tensor(buf735, (1, 1, 2048), (2048, 128, 1), 0); del buf735  # reuse
        # Topologically Sorted Source Nodes: [attn_output_57, value_19, transpose_79, reshape_59, output_136], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf742, buf744, buf745, arg414_1, buf749, 2048, 256, stream=raw_stream0)
        del arg414_1
        buf748 = buf726; del buf726  # reuse
        assert_size_stride_grouped((arg415_1, arg416_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_57, transpose_79, reshape_59, output_136], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf749, arg415_1, buf748, arg416_1, 1, 2048, 2048, 128, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg415_1
        del arg416_1
        assert_size_stride(arg417_1, (2048, ), (1, ), 'input')
        buf751 = buf675; del buf675  # reuse
        buf754 = reinterpret_tensor(buf749, (1, 1, 2048), (2048, 2048, 1), 0); del buf749  # reuse
        buf757 = buf607; del buf607  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_251, hidden_states_261, hidden_states_265, hidden_states_275, hidden_states_276, pow_80, variance_79, add_180, rsqrt_79, hidden_states_277, to_163, hidden_states_278, output_137, output_138], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_18.run(buf751, buf683, buf712, buf721, buf748, arg417_1, buf754, buf757, 1, 2048, stream=raw_stream0)
        del arg417_1
        buf753 = buf722; del buf722  # reuse
        assert_size_stride_grouped((arg418_1, arg419_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_276, pow_80, variance_79, add_180, rsqrt_79, hidden_states_277, to_163, hidden_states_278, output_137], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf754, arg418_1, buf753, arg419_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg418_1
        del arg419_1
        buf756 = buf719; del buf719  # reuse
        assert_size_stride_grouped((arg420_1, arg421_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_276, pow_80, variance_79, add_180, rsqrt_79, hidden_states_277, to_163, hidden_states_278, output_138], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf757, arg420_1, buf756, arg421_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg420_1
        del arg421_1
        buf759 = buf757; del buf757  # reuse
        buf760 = buf717; del buf717  # reuse
        # Topologically Sorted Source Nodes: [silu_19, mul_262, output_139], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_12.run(buf753, buf756, buf760, 6144, stream=raw_stream0)
        assert_size_stride_grouped((arg422_1, arg423_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_19, mul_262, output_139], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf760, arg422_1, buf759, arg423_1, 1, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg422_1
        del arg423_1
        assert_size_stride(arg424_1, (2048, ), (1, ), 'input')
        buf764 = buf754; del buf754  # reuse
        buf767 = buf748; del buf748  # reuse
        buf770 = buf721; del buf721  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_279, hidden_states_280, pow_81, variance_80, add_182, rsqrt_80, hidden_states_281, to_165, hidden_states_282, output_140, output_141, output_142], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_15.run(buf751, buf759, arg424_1, buf764, buf767, buf770, 1, 2048, stream=raw_stream0)
        del arg424_1
        buf763 = buf712; del buf712  # reuse
        assert_size_stride_grouped((arg425_1, arg426_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_279, hidden_states_280, pow_81, variance_80, add_182, rsqrt_80, hidden_states_281, to_165, hidden_states_282, output_140], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf764, arg425_1, buf763, arg426_1, 1, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg425_1
        del arg426_1
        buf766 = buf730; del buf730  # reuse
        assert_size_stride_grouped((arg428_1, arg429_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_279, hidden_states_280, pow_81, variance_80, add_182, rsqrt_80, hidden_states_281, to_165, hidden_states_282, output_141], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf767, arg428_1, buf766, arg429_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg428_1
        del arg429_1
        buf769 = reinterpret_tensor(buf739, (1, 1, 1024), (1024, 1024, 1), 0); del buf739  # reuse
        assert_size_stride_grouped((arg431_1, arg432_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_279, hidden_states_280, pow_81, variance_80, add_182, rsqrt_80, hidden_states_281, to_165, hidden_states_282, output_142], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf770, arg431_1, buf769, arg432_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg431_1
        del arg432_1
        buf772 = reinterpret_tensor(buf745, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf745  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_283, pow_82, variance_81], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf763, buf772, 16, 128, stream=raw_stream0)
        assert_size_stride(arg427_1, (128, ), (1, ), 'input')
        buf775 = reinterpret_tensor(buf770, (1, 16, 1, 128), (2048, 128, 128, 1), 0); del buf770  # reuse
        buf773 = reinterpret_tensor(buf775, (1, 16, 1, 64), (2048, 128, 128, 1), 0)  # alias
        buf774 = reinterpret_tensor(buf775, (1, 16, 1, 64), (2048, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_283, pow_82, variance_81, add_183, rsqrt_81, hidden_states_284, to_167, mul_266, query_states_20, x2_40, neg_40, x1_40, cat_42], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg427_1, buf763, buf772, buf773, buf774, 1024, stream=raw_stream0)
        buf776 = buf736; del buf736  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_285, pow_83, variance_82], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf766, buf776, 8, 128, stream=raw_stream0)
        del buf773
        del buf774
        assert_size_stride(arg430_1, (128, ), (1, ), 'input')
        buf779 = reinterpret_tensor(buf728, (1, 8, 1, 128), (1024, 128, 128, 1), 0); del buf728  # reuse
        buf777 = reinterpret_tensor(buf779, (1, 8, 1, 64), (1024, 128, 128, 1), 0)  # alias
        buf778 = reinterpret_tensor(buf779, (1, 8, 1, 64), (1024, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_285, pow_83, variance_82, add_184, rsqrt_82, hidden_states_286, to_169, mul_268, key_states_20, x2_41, neg_41, x1_41, cat_43], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg430_1, buf766, buf776, buf777, buf778, 512, stream=raw_stream0)
        assert_size_stride_grouped((arg433_1, arg434_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_24, sin_24, arange_24, cache_position_20, hidden_states_285, pow_83, variance_82, add_184, rsqrt_82, hidden_states_286, to_169, mul_268, key_states_20, mul_271, mul_272, k_embed_20, index_copy__40], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg433_1, arg430_1, buf766, buf776, buf1, buf779, buf0, arg434_1, 1024, stream=raw_stream0)
        del arg430_1
        del buf777
        del buf778
        buf781 = reinterpret_tensor(buf744, (16, 1, 256), (256, 256, 1), 0); del buf744  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_283, pow_82, variance_81, add_183, rsqrt_81, hidden_states_284, to_167, mul_266, query_states_20, cos_24, mul_269, sin_24, mul_270, q_embed_20, attn_output_60, key_20], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg427_1, buf763, buf772, buf1, buf775, buf0, arg434_1, buf781, 4096, 128, stream=raw_stream0)
        del arg427_1
        del arg434_1
        buf782 = buf742; del buf742  # reuse
        buf784 = reinterpret_tensor(buf741, (1, 16, 1, 256), (4096, 256, 4096, 1), 0); del buf741  # reuse
        buf785 = reinterpret_tensor(buf772, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf772  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_60], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8.run(buf781, arg3_1, buf782, buf784, buf785, 16, 256, stream=raw_stream0)
        assert_size_stride(arg435_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_24, cache_position_20, index_copy__41], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_9.run(arg433_1, buf769, arg435_1, 1024, stream=raw_stream0)
        buf789 = reinterpret_tensor(buf775, (1, 1, 2048), (2048, 128, 1), 0); del buf775  # reuse
        # Topologically Sorted Source Nodes: [attn_output_60, value_20, transpose_83, reshape_62, output_143], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf782, buf784, buf785, arg435_1, buf789, 2048, 256, stream=raw_stream0)
        del arg435_1
        buf788 = buf763; del buf763  # reuse
        assert_size_stride_grouped((arg436_1, arg437_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_60, transpose_83, reshape_62, output_143], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf789, arg436_1, buf788, arg437_1, 1, 2048, 2048, 128, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg436_1
        del arg437_1
        assert_size_stride(arg438_1, (2048, ), (1, ), 'input')
        buf792 = reinterpret_tensor(buf789, (1, 1, 2048), (2048, 2048, 1), 0); del buf789  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_279, hidden_states_289, hidden_states_290, pow_84, variance_83, add_189, rsqrt_83, hidden_states_291, to_171, hidden_states_292], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_16.run(buf751, buf759, buf788, arg438_1, buf792, 1, 2048, stream=raw_stream0)
        del arg438_1
        buf793 = buf760; del buf760  # reuse
        assert_size_stride_grouped((arg439_1, arg440_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_144], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf792, arg439_1, buf793, arg440_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg439_1
        del arg440_1
        buf795 = buf756; del buf756  # reuse
        assert_size_stride_grouped((arg441_1, arg442_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_145], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf792, arg441_1, buf795, arg442_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg441_1
        del arg442_1
        buf797 = buf792; del buf792  # reuse
        buf798 = buf753; del buf753  # reuse
        # Topologically Sorted Source Nodes: [silu_20, mul_275, output_146], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_12.run(buf793, buf795, buf798, 6144, stream=raw_stream0)
        assert_size_stride_grouped((arg443_1, arg444_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_20, mul_275, output_146], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf798, arg443_1, buf797, arg444_1, 1, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg443_1
        del arg444_1
        assert_size_stride(arg445_1, (2048, ), (1, ), 'input')
        buf801 = buf767; del buf767  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_279, hidden_states_289, hidden_states_293, hidden_states_294, pow_85, variance_84, add_191, rsqrt_84, hidden_states_295, to_173, hidden_states_296], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_17.run(buf751, buf759, buf788, buf797, arg445_1, buf801, 1, 2048, stream=raw_stream0)
        del arg445_1
        buf802 = buf764; del buf764  # reuse
        assert_size_stride_grouped((arg446_1, arg447_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_147], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf801, arg446_1, buf802, arg447_1, 1, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg446_1
        del arg447_1
        buf804 = buf769; del buf769  # reuse
        assert_size_stride_grouped((arg449_1, arg450_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_148], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf801, arg449_1, buf804, arg450_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg449_1
        del arg450_1
        buf806 = reinterpret_tensor(buf779, (1, 1, 1024), (1024, 1024, 1), 0); del buf779  # reuse
        assert_size_stride_grouped((arg452_1, arg453_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_149], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf801, arg452_1, buf806, arg453_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg452_1
        del arg453_1
        buf808 = reinterpret_tensor(buf785, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf785  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_297, pow_86, variance_85], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf802, buf808, 16, 128, stream=raw_stream0)
        assert_size_stride(arg448_1, (128, ), (1, ), 'input')
        buf811 = reinterpret_tensor(buf801, (1, 16, 1, 128), (2048, 128, 128, 1), 0); del buf801  # reuse
        buf809 = reinterpret_tensor(buf811, (1, 16, 1, 64), (2048, 128, 128, 1), 0)  # alias
        buf810 = reinterpret_tensor(buf811, (1, 16, 1, 64), (2048, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_297, pow_86, variance_85, add_192, rsqrt_85, hidden_states_298, to_175, mul_279, query_states_21, x2_42, neg_42, x1_42, cat_44], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg448_1, buf802, buf808, buf809, buf810, 1024, stream=raw_stream0)
        buf812 = buf776; del buf776  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_299, pow_87, variance_86], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf804, buf812, 8, 128, stream=raw_stream0)
        del buf809
        del buf810
        assert_size_stride(arg451_1, (128, ), (1, ), 'input')
        buf815 = reinterpret_tensor(buf766, (1, 8, 1, 128), (1024, 128, 128, 1), 0); del buf766  # reuse
        buf813 = reinterpret_tensor(buf815, (1, 8, 1, 64), (1024, 128, 128, 1), 0)  # alias
        buf814 = reinterpret_tensor(buf815, (1, 8, 1, 64), (1024, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_299, pow_87, variance_86, add_193, rsqrt_86, hidden_states_300, to_177, mul_281, key_states_21, x2_43, neg_43, x1_43, cat_45], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg451_1, buf804, buf812, buf813, buf814, 512, stream=raw_stream0)
        assert_size_stride_grouped((arg454_1, arg455_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_25, sin_25, arange_25, cache_position_21, hidden_states_299, pow_87, variance_86, add_193, rsqrt_86, hidden_states_300, to_177, mul_281, key_states_21, mul_284, mul_285, k_embed_21, index_copy__42], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg454_1, arg451_1, buf804, buf812, buf1, buf815, buf0, arg455_1, 1024, stream=raw_stream0)
        del arg451_1
        del buf813
        del buf814
        buf817 = reinterpret_tensor(buf784, (16, 1, 256), (256, 256, 1), 0); del buf784  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_297, pow_86, variance_85, add_192, rsqrt_85, hidden_states_298, to_175, mul_279, query_states_21, cos_25, mul_282, sin_25, mul_283, q_embed_21, attn_output_63, key_21], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg448_1, buf802, buf808, buf1, buf811, buf0, arg455_1, buf817, 4096, 128, stream=raw_stream0)
        del arg448_1
        del arg455_1
        buf818 = buf782; del buf782  # reuse
        buf820 = reinterpret_tensor(buf781, (1, 16, 1, 256), (4096, 256, 4096, 1), 0); del buf781  # reuse
        buf821 = reinterpret_tensor(buf808, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf808  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_63], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8.run(buf817, arg3_1, buf818, buf820, buf821, 16, 256, stream=raw_stream0)
        assert_size_stride(arg456_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_25, cache_position_21, index_copy__43], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_9.run(arg454_1, buf806, arg456_1, 1024, stream=raw_stream0)
        buf825 = reinterpret_tensor(buf811, (1, 1, 2048), (2048, 128, 1), 0); del buf811  # reuse
        # Topologically Sorted Source Nodes: [attn_output_63, value_21, transpose_87, reshape_65, output_150], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf818, buf820, buf821, arg456_1, buf825, 2048, 256, stream=raw_stream0)
        del arg456_1
        buf824 = buf802; del buf802  # reuse
        assert_size_stride_grouped((arg457_1, arg458_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_63, transpose_87, reshape_65, output_150], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf825, arg457_1, buf824, arg458_1, 1, 2048, 2048, 128, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg457_1
        del arg458_1
        assert_size_stride(arg459_1, (2048, ), (1, ), 'input')
        buf827 = buf751; del buf751  # reuse
        buf830 = reinterpret_tensor(buf825, (1, 1, 2048), (2048, 2048, 1), 0); del buf825  # reuse
        buf833 = buf683; del buf683  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_279, hidden_states_289, hidden_states_293, hidden_states_303, hidden_states_304, pow_88, variance_87, add_198, rsqrt_87, hidden_states_305, to_179, hidden_states_306, output_151, output_152], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_18.run(buf827, buf759, buf788, buf797, buf824, arg459_1, buf830, buf833, 1, 2048, stream=raw_stream0)
        del arg459_1
        buf829 = buf798; del buf798  # reuse
        assert_size_stride_grouped((arg460_1, arg461_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_304, pow_88, variance_87, add_198, rsqrt_87, hidden_states_305, to_179, hidden_states_306, output_151], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf830, arg460_1, buf829, arg461_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg460_1
        del arg461_1
        buf832 = buf795; del buf795  # reuse
        assert_size_stride_grouped((arg462_1, arg463_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_304, pow_88, variance_87, add_198, rsqrt_87, hidden_states_305, to_179, hidden_states_306, output_152], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf833, arg462_1, buf832, arg463_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg462_1
        del arg463_1
        buf835 = buf833; del buf833  # reuse
        buf836 = buf793; del buf793  # reuse
        # Topologically Sorted Source Nodes: [silu_21, mul_288, output_153], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_12.run(buf829, buf832, buf836, 6144, stream=raw_stream0)
        assert_size_stride_grouped((arg464_1, arg465_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_21, mul_288, output_153], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf836, arg464_1, buf835, arg465_1, 1, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg464_1
        del arg465_1
        assert_size_stride(arg466_1, (2048, ), (1, ), 'input')
        buf840 = buf830; del buf830  # reuse
        buf843 = buf824; del buf824  # reuse
        buf846 = buf797; del buf797  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_307, hidden_states_308, pow_89, variance_88, add_200, rsqrt_88, hidden_states_309, to_181, hidden_states_310, output_154, output_155, output_156], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_15.run(buf827, buf835, arg466_1, buf840, buf843, buf846, 1, 2048, stream=raw_stream0)
        del arg466_1
        buf839 = buf788; del buf788  # reuse
        assert_size_stride_grouped((arg467_1, arg468_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_307, hidden_states_308, pow_89, variance_88, add_200, rsqrt_88, hidden_states_309, to_181, hidden_states_310, output_154], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf840, arg467_1, buf839, arg468_1, 1, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg467_1
        del arg468_1
        buf842 = buf806; del buf806  # reuse
        assert_size_stride_grouped((arg470_1, arg471_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_307, hidden_states_308, pow_89, variance_88, add_200, rsqrt_88, hidden_states_309, to_181, hidden_states_310, output_155], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf843, arg470_1, buf842, arg471_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg470_1
        del arg471_1
        buf845 = reinterpret_tensor(buf815, (1, 1, 1024), (1024, 1024, 1), 0); del buf815  # reuse
        assert_size_stride_grouped((arg473_1, arg474_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_307, hidden_states_308, pow_89, variance_88, add_200, rsqrt_88, hidden_states_309, to_181, hidden_states_310, output_156], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf846, arg473_1, buf845, arg474_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg473_1
        del arg474_1
        buf848 = reinterpret_tensor(buf821, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf821  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_311, pow_90, variance_89], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf839, buf848, 16, 128, stream=raw_stream0)
        assert_size_stride(arg469_1, (128, ), (1, ), 'input')
        buf851 = reinterpret_tensor(buf846, (1, 16, 1, 128), (2048, 128, 128, 1), 0); del buf846  # reuse
        buf849 = reinterpret_tensor(buf851, (1, 16, 1, 64), (2048, 128, 128, 1), 0)  # alias
        buf850 = reinterpret_tensor(buf851, (1, 16, 1, 64), (2048, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_311, pow_90, variance_89, add_201, rsqrt_89, hidden_states_312, to_183, mul_292, query_states_22, x2_44, neg_44, x1_44, cat_46], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg469_1, buf839, buf848, buf849, buf850, 1024, stream=raw_stream0)
        buf852 = buf812; del buf812  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_313, pow_91, variance_90], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf842, buf852, 8, 128, stream=raw_stream0)
        del buf849
        del buf850
        assert_size_stride(arg472_1, (128, ), (1, ), 'input')
        buf855 = reinterpret_tensor(buf804, (1, 8, 1, 128), (1024, 128, 128, 1), 0); del buf804  # reuse
        buf853 = reinterpret_tensor(buf855, (1, 8, 1, 64), (1024, 128, 128, 1), 0)  # alias
        buf854 = reinterpret_tensor(buf855, (1, 8, 1, 64), (1024, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_313, pow_91, variance_90, add_202, rsqrt_90, hidden_states_314, to_185, mul_294, key_states_22, x2_45, neg_45, x1_45, cat_47], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg472_1, buf842, buf852, buf853, buf854, 512, stream=raw_stream0)
        assert_size_stride_grouped((arg475_1, arg476_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_26, sin_26, arange_26, cache_position_22, hidden_states_313, pow_91, variance_90, add_202, rsqrt_90, hidden_states_314, to_185, mul_294, key_states_22, mul_297, mul_298, k_embed_22, index_copy__44], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg475_1, arg472_1, buf842, buf852, buf1, buf855, buf0, arg476_1, 1024, stream=raw_stream0)
        del arg472_1
        del buf853
        del buf854
        buf857 = reinterpret_tensor(buf820, (16, 1, 256), (256, 256, 1), 0); del buf820  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_311, pow_90, variance_89, add_201, rsqrt_89, hidden_states_312, to_183, mul_292, query_states_22, cos_26, mul_295, sin_26, mul_296, q_embed_22, attn_output_66, key_22], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg469_1, buf839, buf848, buf1, buf851, buf0, arg476_1, buf857, 4096, 128, stream=raw_stream0)
        del arg469_1
        del arg476_1
        buf858 = buf818; del buf818  # reuse
        buf860 = reinterpret_tensor(buf817, (1, 16, 1, 256), (4096, 256, 4096, 1), 0); del buf817  # reuse
        buf861 = reinterpret_tensor(buf848, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf848  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_66], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8.run(buf857, arg3_1, buf858, buf860, buf861, 16, 256, stream=raw_stream0)
        assert_size_stride(arg477_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_26, cache_position_22, index_copy__45], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_9.run(arg475_1, buf845, arg477_1, 1024, stream=raw_stream0)
        buf865 = reinterpret_tensor(buf851, (1, 1, 2048), (2048, 128, 1), 0); del buf851  # reuse
        # Topologically Sorted Source Nodes: [attn_output_66, value_22, transpose_91, reshape_68, output_157], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf858, buf860, buf861, arg477_1, buf865, 2048, 256, stream=raw_stream0)
        del arg477_1
        buf864 = buf839; del buf839  # reuse
        assert_size_stride_grouped((arg478_1, arg479_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_66, transpose_91, reshape_68, output_157], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf865, arg478_1, buf864, arg479_1, 1, 2048, 2048, 128, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg478_1
        del arg479_1
        assert_size_stride(arg480_1, (2048, ), (1, ), 'input')
        buf868 = reinterpret_tensor(buf865, (1, 1, 2048), (2048, 2048, 1), 0); del buf865  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_307, hidden_states_317, hidden_states_318, pow_92, variance_91, add_207, rsqrt_91, hidden_states_319, to_187, hidden_states_320], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_16.run(buf827, buf835, buf864, arg480_1, buf868, 1, 2048, stream=raw_stream0)
        del arg480_1
        buf869 = buf836; del buf836  # reuse
        assert_size_stride_grouped((arg481_1, arg482_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_158], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf868, arg481_1, buf869, arg482_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg481_1
        del arg482_1
        buf871 = buf832; del buf832  # reuse
        assert_size_stride_grouped((arg483_1, arg484_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_159], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf868, arg483_1, buf871, arg484_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg483_1
        del arg484_1
        buf873 = buf868; del buf868  # reuse
        buf874 = buf829; del buf829  # reuse
        # Topologically Sorted Source Nodes: [silu_22, mul_301, output_160], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_12.run(buf869, buf871, buf874, 6144, stream=raw_stream0)
        assert_size_stride_grouped((arg485_1, arg486_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_22, mul_301, output_160], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf874, arg485_1, buf873, arg486_1, 1, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg485_1
        del arg486_1
        assert_size_stride(arg487_1, (2048, ), (1, ), 'input')
        buf877 = buf843; del buf843  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_307, hidden_states_317, hidden_states_321, hidden_states_322, pow_93, variance_92, add_209, rsqrt_92, hidden_states_323, to_189, hidden_states_324], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_17.run(buf827, buf835, buf864, buf873, arg487_1, buf877, 1, 2048, stream=raw_stream0)
        del arg487_1
        buf878 = buf840; del buf840  # reuse
        assert_size_stride_grouped((arg488_1, arg489_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_161], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf877, arg488_1, buf878, arg489_1, 1, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg488_1
        del arg489_1
        buf880 = buf845; del buf845  # reuse
        assert_size_stride_grouped((arg491_1, arg492_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_162], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf877, arg491_1, buf880, arg492_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg491_1
        del arg492_1
        buf882 = reinterpret_tensor(buf855, (1, 1, 1024), (1024, 1024, 1), 0); del buf855  # reuse
        assert_size_stride_grouped((arg494_1, arg495_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_163], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf877, arg494_1, buf882, arg495_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg494_1
        del arg495_1
        buf884 = reinterpret_tensor(buf861, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf861  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_325, pow_94, variance_93], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf878, buf884, 16, 128, stream=raw_stream0)
        assert_size_stride(arg490_1, (128, ), (1, ), 'input')
        buf887 = reinterpret_tensor(buf877, (1, 16, 1, 128), (2048, 128, 128, 1), 0); del buf877  # reuse
        buf885 = reinterpret_tensor(buf887, (1, 16, 1, 64), (2048, 128, 128, 1), 0)  # alias
        buf886 = reinterpret_tensor(buf887, (1, 16, 1, 64), (2048, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_325, pow_94, variance_93, add_210, rsqrt_93, hidden_states_326, to_191, mul_305, query_states_23, x2_46, neg_46, x1_46, cat_48], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg490_1, buf878, buf884, buf885, buf886, 1024, stream=raw_stream0)
        buf888 = buf852; del buf852  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_327, pow_95, variance_94], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf880, buf888, 8, 128, stream=raw_stream0)
        del buf885
        del buf886
        assert_size_stride(arg493_1, (128, ), (1, ), 'input')
        buf891 = reinterpret_tensor(buf842, (1, 8, 1, 128), (1024, 128, 128, 1), 0); del buf842  # reuse
        buf889 = reinterpret_tensor(buf891, (1, 8, 1, 64), (1024, 128, 128, 1), 0)  # alias
        buf890 = reinterpret_tensor(buf891, (1, 8, 1, 64), (1024, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_327, pow_95, variance_94, add_211, rsqrt_94, hidden_states_328, to_193, mul_307, key_states_23, x2_47, neg_47, x1_47, cat_49], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg493_1, buf880, buf888, buf889, buf890, 512, stream=raw_stream0)
        assert_size_stride_grouped((arg496_1, arg497_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_27, sin_27, arange_27, cache_position_23, hidden_states_327, pow_95, variance_94, add_211, rsqrt_94, hidden_states_328, to_193, mul_307, key_states_23, mul_310, mul_311, k_embed_23, index_copy__46], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg496_1, arg493_1, buf880, buf888, buf1, buf891, buf0, arg497_1, 1024, stream=raw_stream0)
        del arg493_1
        del buf889
        del buf890
        buf893 = reinterpret_tensor(buf860, (16, 1, 256), (256, 256, 1), 0); del buf860  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_325, pow_94, variance_93, add_210, rsqrt_93, hidden_states_326, to_191, mul_305, query_states_23, cos_27, mul_308, sin_27, mul_309, q_embed_23, attn_output_69, key_23], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg490_1, buf878, buf884, buf1, buf887, buf0, arg497_1, buf893, 4096, 128, stream=raw_stream0)
        del arg490_1
        del arg497_1
        buf894 = buf858; del buf858  # reuse
        buf896 = reinterpret_tensor(buf857, (1, 16, 1, 256), (4096, 256, 4096, 1), 0); del buf857  # reuse
        buf897 = reinterpret_tensor(buf884, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf884  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_69], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8.run(buf893, arg3_1, buf894, buf896, buf897, 16, 256, stream=raw_stream0)
        assert_size_stride(arg498_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_27, cache_position_23, index_copy__47], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_9.run(arg496_1, buf882, arg498_1, 1024, stream=raw_stream0)
        buf901 = reinterpret_tensor(buf887, (1, 1, 2048), (2048, 128, 1), 0); del buf887  # reuse
        # Topologically Sorted Source Nodes: [attn_output_69, value_23, transpose_95, reshape_71, output_164], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf894, buf896, buf897, arg498_1, buf901, 2048, 256, stream=raw_stream0)
        del arg498_1
        buf900 = buf878; del buf878  # reuse
        assert_size_stride_grouped((arg499_1, arg500_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_69, transpose_95, reshape_71, output_164], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf901, arg499_1, buf900, arg500_1, 1, 2048, 2048, 128, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg499_1
        del arg500_1
        assert_size_stride(arg501_1, (2048, ), (1, ), 'input')
        buf903 = buf827; del buf827  # reuse
        buf906 = reinterpret_tensor(buf901, (1, 1, 2048), (2048, 2048, 1), 0); del buf901  # reuse
        buf909 = buf759; del buf759  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_307, hidden_states_317, hidden_states_321, hidden_states_331, hidden_states_332, pow_96, variance_95, add_216, rsqrt_95, hidden_states_333, to_195, hidden_states_334, output_165, output_166], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_18.run(buf903, buf835, buf864, buf873, buf900, arg501_1, buf906, buf909, 1, 2048, stream=raw_stream0)
        del arg501_1
        buf905 = buf874; del buf874  # reuse
        assert_size_stride_grouped((arg502_1, arg503_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_332, pow_96, variance_95, add_216, rsqrt_95, hidden_states_333, to_195, hidden_states_334, output_165], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf906, arg502_1, buf905, arg503_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg502_1
        del arg503_1
        buf908 = buf871; del buf871  # reuse
        assert_size_stride_grouped((arg504_1, arg505_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_332, pow_96, variance_95, add_216, rsqrt_95, hidden_states_333, to_195, hidden_states_334, output_166], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf909, arg504_1, buf908, arg505_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg504_1
        del arg505_1
        buf911 = buf909; del buf909  # reuse
        buf912 = buf869; del buf869  # reuse
        # Topologically Sorted Source Nodes: [silu_23, mul_314, output_167], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_12.run(buf905, buf908, buf912, 6144, stream=raw_stream0)
        assert_size_stride_grouped((arg506_1, arg507_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_23, mul_314, output_167], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf912, arg506_1, buf911, arg507_1, 1, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg506_1
        del arg507_1
        assert_size_stride(arg508_1, (2048, ), (1, ), 'input')
        buf916 = buf906; del buf906  # reuse
        buf919 = buf900; del buf900  # reuse
        buf922 = buf873; del buf873  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_335, hidden_states_336, pow_97, variance_96, add_218, rsqrt_96, hidden_states_337, to_197, hidden_states_338, output_168, output_169, output_170], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_15.run(buf903, buf911, arg508_1, buf916, buf919, buf922, 1, 2048, stream=raw_stream0)
        del arg508_1
        buf915 = buf864; del buf864  # reuse
        assert_size_stride_grouped((arg509_1, arg510_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_335, hidden_states_336, pow_97, variance_96, add_218, rsqrt_96, hidden_states_337, to_197, hidden_states_338, output_168], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf916, arg509_1, buf915, arg510_1, 1, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg509_1
        del arg510_1
        buf918 = buf882; del buf882  # reuse
        assert_size_stride_grouped((arg512_1, arg513_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_335, hidden_states_336, pow_97, variance_96, add_218, rsqrt_96, hidden_states_337, to_197, hidden_states_338, output_169], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf919, arg512_1, buf918, arg513_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg512_1
        del arg513_1
        buf921 = reinterpret_tensor(buf891, (1, 1, 1024), (1024, 1024, 1), 0); del buf891  # reuse
        assert_size_stride_grouped((arg515_1, arg516_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_335, hidden_states_336, pow_97, variance_96, add_218, rsqrt_96, hidden_states_337, to_197, hidden_states_338, output_170], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf922, arg515_1, buf921, arg516_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg515_1
        del arg516_1
        buf924 = reinterpret_tensor(buf897, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf897  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_339, pow_98, variance_97], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf915, buf924, 16, 128, stream=raw_stream0)
        assert_size_stride(arg511_1, (128, ), (1, ), 'input')
        buf927 = reinterpret_tensor(buf922, (1, 16, 1, 128), (2048, 128, 128, 1), 0); del buf922  # reuse
        buf925 = reinterpret_tensor(buf927, (1, 16, 1, 64), (2048, 128, 128, 1), 0)  # alias
        buf926 = reinterpret_tensor(buf927, (1, 16, 1, 64), (2048, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_339, pow_98, variance_97, add_219, rsqrt_97, hidden_states_340, to_199, mul_318, query_states_24, x2_48, neg_48, x1_48, cat_50], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg511_1, buf915, buf924, buf925, buf926, 1024, stream=raw_stream0)
        buf928 = buf888; del buf888  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_341, pow_99, variance_98], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf918, buf928, 8, 128, stream=raw_stream0)
        del buf925
        del buf926
        assert_size_stride(arg514_1, (128, ), (1, ), 'input')
        buf931 = reinterpret_tensor(buf880, (1, 8, 1, 128), (1024, 128, 128, 1), 0); del buf880  # reuse
        buf929 = reinterpret_tensor(buf931, (1, 8, 1, 64), (1024, 128, 128, 1), 0)  # alias
        buf930 = reinterpret_tensor(buf931, (1, 8, 1, 64), (1024, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_341, pow_99, variance_98, add_220, rsqrt_98, hidden_states_342, to_201, mul_320, key_states_24, x2_49, neg_49, x1_49, cat_51], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg514_1, buf918, buf928, buf929, buf930, 512, stream=raw_stream0)
        assert_size_stride_grouped((arg517_1, arg518_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_28, sin_28, arange_28, cache_position_24, hidden_states_341, pow_99, variance_98, add_220, rsqrt_98, hidden_states_342, to_201, mul_320, key_states_24, mul_323, mul_324, k_embed_24, index_copy__48], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg517_1, arg514_1, buf918, buf928, buf1, buf931, buf0, arg518_1, 1024, stream=raw_stream0)
        del arg514_1
        del buf929
        del buf930
        buf933 = reinterpret_tensor(buf896, (16, 1, 256), (256, 256, 1), 0); del buf896  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_339, pow_98, variance_97, add_219, rsqrt_97, hidden_states_340, to_199, mul_318, query_states_24, cos_28, mul_321, sin_28, mul_322, q_embed_24, attn_output_72, key_24], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg511_1, buf915, buf924, buf1, buf927, buf0, arg518_1, buf933, 4096, 128, stream=raw_stream0)
        del arg511_1
        del arg518_1
        buf934 = buf894; del buf894  # reuse
        buf936 = reinterpret_tensor(buf893, (1, 16, 1, 256), (4096, 256, 4096, 1), 0); del buf893  # reuse
        buf937 = reinterpret_tensor(buf924, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf924  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_72], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8.run(buf933, arg3_1, buf934, buf936, buf937, 16, 256, stream=raw_stream0)
        assert_size_stride(arg519_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_28, cache_position_24, index_copy__49], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_9.run(arg517_1, buf921, arg519_1, 1024, stream=raw_stream0)
        buf941 = reinterpret_tensor(buf927, (1, 1, 2048), (2048, 128, 1), 0); del buf927  # reuse
        # Topologically Sorted Source Nodes: [attn_output_72, value_24, transpose_99, reshape_74, output_171], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf934, buf936, buf937, arg519_1, buf941, 2048, 256, stream=raw_stream0)
        del arg519_1
        buf940 = buf915; del buf915  # reuse
        assert_size_stride_grouped((arg520_1, arg521_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_72, transpose_99, reshape_74, output_171], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf941, arg520_1, buf940, arg521_1, 1, 2048, 2048, 128, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg520_1
        del arg521_1
        assert_size_stride(arg522_1, (2048, ), (1, ), 'input')
        buf944 = reinterpret_tensor(buf941, (1, 1, 2048), (2048, 2048, 1), 0); del buf941  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_335, hidden_states_345, hidden_states_346, pow_100, variance_99, add_225, rsqrt_99, hidden_states_347, to_203, hidden_states_348], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_16.run(buf903, buf911, buf940, arg522_1, buf944, 1, 2048, stream=raw_stream0)
        del arg522_1
        buf945 = buf912; del buf912  # reuse
        assert_size_stride_grouped((arg523_1, arg524_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_172], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf944, arg523_1, buf945, arg524_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg523_1
        del arg524_1
        buf947 = buf908; del buf908  # reuse
        assert_size_stride_grouped((arg525_1, arg526_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_173], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf944, arg525_1, buf947, arg526_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg525_1
        del arg526_1
        buf949 = buf944; del buf944  # reuse
        buf950 = buf905; del buf905  # reuse
        # Topologically Sorted Source Nodes: [silu_24, mul_327, output_174], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_12.run(buf945, buf947, buf950, 6144, stream=raw_stream0)
        assert_size_stride_grouped((arg527_1, arg528_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_24, mul_327, output_174], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf950, arg527_1, buf949, arg528_1, 1, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg527_1
        del arg528_1
        assert_size_stride(arg529_1, (2048, ), (1, ), 'input')
        buf953 = buf919; del buf919  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_335, hidden_states_345, hidden_states_349, hidden_states_350, pow_101, variance_100, add_227, rsqrt_100, hidden_states_351, to_205, hidden_states_352], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_17.run(buf903, buf911, buf940, buf949, arg529_1, buf953, 1, 2048, stream=raw_stream0)
        del arg529_1
        buf954 = buf916; del buf916  # reuse
        assert_size_stride_grouped((arg530_1, arg531_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_175], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf953, arg530_1, buf954, arg531_1, 1, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg530_1
        del arg531_1
        buf956 = buf921; del buf921  # reuse
        assert_size_stride_grouped((arg533_1, arg534_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_176], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf953, arg533_1, buf956, arg534_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg533_1
        del arg534_1
        buf958 = reinterpret_tensor(buf931, (1, 1, 1024), (1024, 1024, 1), 0); del buf931  # reuse
        assert_size_stride_grouped((arg536_1, arg537_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_177], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf953, arg536_1, buf958, arg537_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg536_1
        del arg537_1
        buf960 = reinterpret_tensor(buf937, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf937  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_353, pow_102, variance_101], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf954, buf960, 16, 128, stream=raw_stream0)
        assert_size_stride(arg532_1, (128, ), (1, ), 'input')
        buf963 = reinterpret_tensor(buf953, (1, 16, 1, 128), (2048, 128, 128, 1), 0); del buf953  # reuse
        buf961 = reinterpret_tensor(buf963, (1, 16, 1, 64), (2048, 128, 128, 1), 0)  # alias
        buf962 = reinterpret_tensor(buf963, (1, 16, 1, 64), (2048, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_353, pow_102, variance_101, add_228, rsqrt_101, hidden_states_354, to_207, mul_331, query_states_25, x2_50, neg_50, x1_50, cat_52], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg532_1, buf954, buf960, buf961, buf962, 1024, stream=raw_stream0)
        buf964 = buf928; del buf928  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_355, pow_103, variance_102], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf956, buf964, 8, 128, stream=raw_stream0)
        del buf961
        del buf962
        assert_size_stride(arg535_1, (128, ), (1, ), 'input')
        buf967 = reinterpret_tensor(buf918, (1, 8, 1, 128), (1024, 128, 128, 1), 0); del buf918  # reuse
        buf965 = reinterpret_tensor(buf967, (1, 8, 1, 64), (1024, 128, 128, 1), 0)  # alias
        buf966 = reinterpret_tensor(buf967, (1, 8, 1, 64), (1024, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_355, pow_103, variance_102, add_229, rsqrt_102, hidden_states_356, to_209, mul_333, key_states_25, x2_51, neg_51, x1_51, cat_53], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg535_1, buf956, buf964, buf965, buf966, 512, stream=raw_stream0)
        assert_size_stride_grouped((arg538_1, arg539_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_29, sin_29, arange_29, cache_position_25, hidden_states_355, pow_103, variance_102, add_229, rsqrt_102, hidden_states_356, to_209, mul_333, key_states_25, mul_336, mul_337, k_embed_25, index_copy__50], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg538_1, arg535_1, buf956, buf964, buf1, buf967, buf0, arg539_1, 1024, stream=raw_stream0)
        del arg535_1
        del buf965
        del buf966
        buf969 = reinterpret_tensor(buf936, (16, 1, 256), (256, 256, 1), 0); del buf936  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_353, pow_102, variance_101, add_228, rsqrt_101, hidden_states_354, to_207, mul_331, query_states_25, cos_29, mul_334, sin_29, mul_335, q_embed_25, attn_output_75, key_25], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg532_1, buf954, buf960, buf1, buf963, buf0, arg539_1, buf969, 4096, 128, stream=raw_stream0)
        del arg532_1
        del arg539_1
        buf970 = buf934; del buf934  # reuse
        buf972 = reinterpret_tensor(buf933, (1, 16, 1, 256), (4096, 256, 4096, 1), 0); del buf933  # reuse
        buf973 = reinterpret_tensor(buf960, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf960  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_75], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8.run(buf969, arg3_1, buf970, buf972, buf973, 16, 256, stream=raw_stream0)
        assert_size_stride(arg540_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_29, cache_position_25, index_copy__51], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_9.run(arg538_1, buf958, arg540_1, 1024, stream=raw_stream0)
        buf977 = reinterpret_tensor(buf963, (1, 1, 2048), (2048, 128, 1), 0); del buf963  # reuse
        # Topologically Sorted Source Nodes: [attn_output_75, value_25, transpose_103, reshape_77, output_178], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf970, buf972, buf973, arg540_1, buf977, 2048, 256, stream=raw_stream0)
        del arg540_1
        buf976 = buf954; del buf954  # reuse
        assert_size_stride_grouped((arg541_1, arg542_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_75, transpose_103, reshape_77, output_178], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf977, arg541_1, buf976, arg542_1, 1, 2048, 2048, 128, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg541_1
        del arg542_1
        assert_size_stride(arg543_1, (2048, ), (1, ), 'input')
        buf979 = buf903; del buf903  # reuse
        buf982 = reinterpret_tensor(buf977, (1, 1, 2048), (2048, 2048, 1), 0); del buf977  # reuse
        buf985 = buf835; del buf835  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_335, hidden_states_345, hidden_states_349, hidden_states_359, hidden_states_360, pow_104, variance_103, add_234, rsqrt_103, hidden_states_361, to_211, hidden_states_362, output_179, output_180], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_18.run(buf979, buf911, buf940, buf949, buf976, arg543_1, buf982, buf985, 1, 2048, stream=raw_stream0)
        del arg543_1
        buf981 = buf950; del buf950  # reuse
        assert_size_stride_grouped((arg544_1, arg545_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_360, pow_104, variance_103, add_234, rsqrt_103, hidden_states_361, to_211, hidden_states_362, output_179], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf982, arg544_1, buf981, arg545_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg544_1
        del arg545_1
        buf984 = buf947; del buf947  # reuse
        assert_size_stride_grouped((arg546_1, arg547_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_360, pow_104, variance_103, add_234, rsqrt_103, hidden_states_361, to_211, hidden_states_362, output_180], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf985, arg546_1, buf984, arg547_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg546_1
        del arg547_1
        buf987 = buf985; del buf985  # reuse
        buf988 = buf945; del buf945  # reuse
        # Topologically Sorted Source Nodes: [silu_25, mul_340, output_181], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_12.run(buf981, buf984, buf988, 6144, stream=raw_stream0)
        assert_size_stride_grouped((arg548_1, arg549_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_25, mul_340, output_181], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf988, arg548_1, buf987, arg549_1, 1, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg548_1
        del arg549_1
        assert_size_stride(arg550_1, (2048, ), (1, ), 'input')
        buf992 = buf982; del buf982  # reuse
        buf995 = buf976; del buf976  # reuse
        buf998 = buf949; del buf949  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_363, hidden_states_364, pow_105, variance_104, add_236, rsqrt_104, hidden_states_365, to_213, hidden_states_366, output_182, output_183, output_184], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_15.run(buf979, buf987, arg550_1, buf992, buf995, buf998, 1, 2048, stream=raw_stream0)
        del arg550_1
        buf991 = buf940; del buf940  # reuse
        assert_size_stride_grouped((arg551_1, arg552_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_363, hidden_states_364, pow_105, variance_104, add_236, rsqrt_104, hidden_states_365, to_213, hidden_states_366, output_182], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf992, arg551_1, buf991, arg552_1, 1, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg551_1
        del arg552_1
        buf994 = buf958; del buf958  # reuse
        assert_size_stride_grouped((arg554_1, arg555_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_363, hidden_states_364, pow_105, variance_104, add_236, rsqrt_104, hidden_states_365, to_213, hidden_states_366, output_183], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf995, arg554_1, buf994, arg555_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg554_1
        del arg555_1
        buf997 = reinterpret_tensor(buf967, (1, 1, 1024), (1024, 1024, 1), 0); del buf967  # reuse
        assert_size_stride_grouped((arg557_1, arg558_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_363, hidden_states_364, pow_105, variance_104, add_236, rsqrt_104, hidden_states_365, to_213, hidden_states_366, output_184], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf998, arg557_1, buf997, arg558_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg557_1
        del arg558_1
        buf1000 = reinterpret_tensor(buf973, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf973  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_367, pow_106, variance_105], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf991, buf1000, 16, 128, stream=raw_stream0)
        assert_size_stride(arg553_1, (128, ), (1, ), 'input')
        buf1003 = reinterpret_tensor(buf998, (1, 16, 1, 128), (2048, 128, 128, 1), 0); del buf998  # reuse
        buf1001 = reinterpret_tensor(buf1003, (1, 16, 1, 64), (2048, 128, 128, 1), 0)  # alias
        buf1002 = reinterpret_tensor(buf1003, (1, 16, 1, 64), (2048, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_367, pow_106, variance_105, add_237, rsqrt_105, hidden_states_368, to_215, mul_344, query_states_26, x2_52, neg_52, x1_52, cat_54], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg553_1, buf991, buf1000, buf1001, buf1002, 1024, stream=raw_stream0)
        buf1004 = buf964; del buf964  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_369, pow_107, variance_106], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf994, buf1004, 8, 128, stream=raw_stream0)
        del buf1001
        del buf1002
        assert_size_stride(arg556_1, (128, ), (1, ), 'input')
        buf1007 = reinterpret_tensor(buf956, (1, 8, 1, 128), (1024, 128, 128, 1), 0); del buf956  # reuse
        buf1005 = reinterpret_tensor(buf1007, (1, 8, 1, 64), (1024, 128, 128, 1), 0)  # alias
        buf1006 = reinterpret_tensor(buf1007, (1, 8, 1, 64), (1024, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_369, pow_107, variance_106, add_238, rsqrt_106, hidden_states_370, to_217, mul_346, key_states_26, x2_53, neg_53, x1_53, cat_55], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg556_1, buf994, buf1004, buf1005, buf1006, 512, stream=raw_stream0)
        assert_size_stride_grouped((arg559_1, arg560_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_30, sin_30, arange_30, cache_position_26, hidden_states_369, pow_107, variance_106, add_238, rsqrt_106, hidden_states_370, to_217, mul_346, key_states_26, mul_349, mul_350, k_embed_26, index_copy__52], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg559_1, arg556_1, buf994, buf1004, buf1, buf1007, buf0, arg560_1, 1024, stream=raw_stream0)
        del arg556_1
        del buf1005
        del buf1006
        buf1009 = reinterpret_tensor(buf972, (16, 1, 256), (256, 256, 1), 0); del buf972  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_367, pow_106, variance_105, add_237, rsqrt_105, hidden_states_368, to_215, mul_344, query_states_26, cos_30, mul_347, sin_30, mul_348, q_embed_26, attn_output_78, key_26], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg553_1, buf991, buf1000, buf1, buf1003, buf0, arg560_1, buf1009, 4096, 128, stream=raw_stream0)
        del arg553_1
        del arg560_1
        buf1010 = buf970; del buf970  # reuse
        buf1012 = reinterpret_tensor(buf969, (1, 16, 1, 256), (4096, 256, 4096, 1), 0); del buf969  # reuse
        buf1013 = reinterpret_tensor(buf1000, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf1000  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_78], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8.run(buf1009, arg3_1, buf1010, buf1012, buf1013, 16, 256, stream=raw_stream0)
        assert_size_stride(arg561_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_30, cache_position_26, index_copy__53], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_9.run(arg559_1, buf997, arg561_1, 1024, stream=raw_stream0)
        buf1017 = reinterpret_tensor(buf991, (1, 1, 2048), (2048, 128, 1), 0); del buf991  # reuse
        # Topologically Sorted Source Nodes: [attn_output_78, value_26, transpose_107, reshape_80, output_185], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf1010, buf1012, buf1013, arg561_1, buf1017, 2048, 256, stream=raw_stream0)
        del arg561_1
        buf1016 = reinterpret_tensor(buf1003, (1, 1, 2048), (2048, 2048, 1), 0); del buf1003  # reuse
        assert_size_stride_grouped((arg562_1, arg563_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_78, transpose_107, reshape_80, output_185], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf1017, arg562_1, buf1016, arg563_1, 1, 2048, 2048, 128, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg562_1
        del arg563_1
        assert_size_stride(arg564_1, (2048, ), (1, ), 'input')
        buf1020 = reinterpret_tensor(buf1017, (1, 1, 2048), (2048, 2048, 1), 0); del buf1017  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_363, hidden_states_373, hidden_states_374, pow_108, variance_107, add_243, rsqrt_107, hidden_states_375, to_219, hidden_states_376], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_16.run(buf979, buf987, buf1016, arg564_1, buf1020, 1, 2048, stream=raw_stream0)
        del arg564_1
        buf1021 = buf988; del buf988  # reuse
        assert_size_stride_grouped((arg565_1, arg566_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_186], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf1020, arg565_1, buf1021, arg566_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg565_1
        del arg566_1
        buf1023 = buf984; del buf984  # reuse
        assert_size_stride_grouped((arg567_1, arg568_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_187], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf1020, arg567_1, buf1023, arg568_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg567_1
        del arg568_1
        buf1025 = buf1020; del buf1020  # reuse
        buf1026 = buf981; del buf981  # reuse
        # Topologically Sorted Source Nodes: [silu_26, mul_353, output_188], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_12.run(buf1021, buf1023, buf1026, 6144, stream=raw_stream0)
        assert_size_stride_grouped((arg569_1, arg570_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_26, mul_353, output_188], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf1026, arg569_1, buf1025, arg570_1, 1, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg569_1
        del arg570_1
        assert_size_stride(arg571_1, (2048, ), (1, ), 'input')
        buf1029 = buf995; del buf995  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_363, hidden_states_373, hidden_states_377, hidden_states_378, pow_109, variance_108, add_245, rsqrt_108, hidden_states_379, to_221, hidden_states_380], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_17.run(buf979, buf987, buf1016, buf1025, arg571_1, buf1029, 1, 2048, stream=raw_stream0)
        del arg571_1
        buf1030 = buf992; del buf992  # reuse
        assert_size_stride_grouped((arg572_1, arg573_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_189], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf1029, arg572_1, buf1030, arg573_1, 1, 2048, 2048, 2048, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg572_1
        del arg573_1
        buf1032 = buf997; del buf997  # reuse
        assert_size_stride_grouped((arg575_1, arg576_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_190], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf1029, arg575_1, buf1032, arg576_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg575_1
        del arg576_1
        buf1034 = buf994; del buf994  # reuse
        assert_size_stride_grouped((arg578_1, arg579_1), ((1024, 2048), (8, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_191], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf1029, arg578_1, buf1034, arg579_1, 1, 1024, 2048, 2048, 1, 1, 2048, 1024, 1, 1, 16, stream=raw_stream0)
        del arg578_1
        del arg579_1
        buf1036 = reinterpret_tensor(buf1013, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf1013  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_381, pow_110, variance_109], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_2.run(buf1030, buf1036, 16, 128, stream=raw_stream0)
        assert_size_stride(arg574_1, (128, ), (1, ), 'input')
        buf1039 = reinterpret_tensor(buf1029, (1, 16, 1, 128), (2048, 128, 128, 1), 0); del buf1029  # reuse
        buf1037 = reinterpret_tensor(buf1039, (1, 16, 1, 64), (2048, 128, 128, 1), 0)  # alias
        buf1038 = reinterpret_tensor(buf1039, (1, 16, 1, 64), (2048, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_381, pow_110, variance_109, add_246, rsqrt_109, hidden_states_382, to_223, mul_357, query_states_27, x2_54, neg_54, x1_54, cat_56], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_3.run(arg574_1, buf1030, buf1036, buf1037, buf1038, 1024, stream=raw_stream0)
        buf1040 = buf1004; del buf1004  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_383, pow_111, variance_110], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_4.run(buf1032, buf1040, 8, 128, stream=raw_stream0)
        del buf1037
        del buf1038
        assert_size_stride(arg577_1, (128, ), (1, ), 'input')
        buf1043 = buf1007; del buf1007  # reuse
        buf1041 = reinterpret_tensor(buf1043, (1, 8, 1, 64), (1024, 128, 128, 1), 0)  # alias
        buf1042 = reinterpret_tensor(buf1043, (1, 8, 1, 64), (1024, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [hidden_states_383, pow_111, variance_110, add_247, rsqrt_110, hidden_states_384, to_225, mul_359, key_states_27, x2_55, neg_55, x1_55, cat_57], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_5.run(arg577_1, buf1032, buf1040, buf1041, buf1042, 512, stream=raw_stream0)
        assert_size_stride_grouped((arg580_1, arg581_1), ((), (1, 8, 256, 128)), ((), (262144, 32768, 128, 1)), 'input')
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_31, sin_31, arange_31, cache_position_27, hidden_states_383, pow_111, variance_110, add_247, rsqrt_110, hidden_states_384, to_225, mul_359, key_states_27, mul_362, mul_363, k_embed_27, index_copy__54], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.arange, aten.add, aten.view, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6.run(arg580_1, arg577_1, buf1032, buf1040, buf1, buf1043, buf0, arg581_1, 1024, stream=raw_stream0)
        del arg577_1
        del buf1032
        del buf1040
        del buf1041
        del buf1042
        del buf1043
        buf1045 = reinterpret_tensor(buf1012, (16, 1, 256), (256, 256, 1), 0); del buf1012  # reuse
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, hidden_states_381, pow_110, variance_109, add_246, rsqrt_109, hidden_states_382, to_223, mul_357, query_states_27, cos_31, mul_360, sin_31, mul_361, q_embed_27, attn_output_81, key_27], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze, aten._scaled_dot_product_flash_attention_for_cpu, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__to_copy__unsafe_view_add_cat_clone_expand_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7.run(arg574_1, buf1030, buf1036, buf1, buf1039, buf0, arg581_1, buf1045, 4096, 128, stream=raw_stream0)
        del arg574_1
        del arg581_1
        del buf0
        del buf1
        buf1046 = buf1010; del buf1010  # reuse
        buf1048 = reinterpret_tensor(buf1009, (1, 16, 1, 256), (4096, 256, 4096, 1), 0); del buf1009  # reuse
        buf1049 = reinterpret_tensor(buf1036, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf1036  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_81], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_8.run(buf1045, arg3_1, buf1046, buf1048, buf1049, 16, 256, stream=raw_stream0)
        del buf1045
        assert_size_stride(arg582_1, (1, 8, 256, 128), (262144, 32768, 128, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_31, cache_position_27, index_copy__55], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_9.run(arg580_1, buf1034, arg582_1, 1024, stream=raw_stream0)
        del buf1034
        buf1053 = reinterpret_tensor(buf1039, (1, 1, 2048), (2048, 128, 1), 0); del buf1039  # reuse
        # Topologically Sorted Source Nodes: [attn_output_81, value_27, transpose_111, reshape_83, output_192], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf1046, buf1048, buf1049, arg582_1, buf1053, 2048, 256, stream=raw_stream0)
        del arg582_1
        del buf1046
        del buf1048
        del buf1049
        buf1052 = buf1030; del buf1030  # reuse
        assert_size_stride_grouped((arg583_1, arg584_1), ((2048, 2048), (16, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [attn_output_81, transpose_111, reshape_83, output_192], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf1053, arg583_1, buf1052, arg584_1, 1, 2048, 2048, 128, 1, 1, 2048, 2048, 1, 1, 16, stream=raw_stream0)
        del arg583_1
        del arg584_1
        assert_size_stride(arg585_1, (2048, ), (1, ), 'input')
        buf1055 = buf979; del buf979  # reuse
        buf1058 = reinterpret_tensor(buf1053, (1, 1, 2048), (2048, 2048, 1), 0); del buf1053  # reuse
        buf1061 = buf911; del buf911  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_363, hidden_states_373, hidden_states_377, hidden_states_387, hidden_states_388, pow_112, variance_111, add_252, rsqrt_111, hidden_states_389, to_227, hidden_states_390, output_193, output_194], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_18.run(buf1055, buf987, buf1016, buf1025, buf1052, arg585_1, buf1058, buf1061, 1, 2048, stream=raw_stream0)
        del arg585_1
        del buf1016
        del buf1025
        del buf1052
        del buf987
        buf1057 = buf1026; del buf1026  # reuse
        assert_size_stride_grouped((arg586_1, arg587_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_388, pow_112, variance_111, add_252, rsqrt_111, hidden_states_389, to_227, hidden_states_390, output_193], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf1058, arg586_1, buf1057, arg587_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg586_1
        del arg587_1
        del buf1058
        buf1060 = buf1023; del buf1023  # reuse
        assert_size_stride_grouped((arg588_1, arg589_1), ((6144, 2048), (48, 16)), ((2048, 1), (16, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_388, pow_112, variance_111, add_252, rsqrt_111, hidden_states_389, to_227, hidden_states_390, output_194], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf1061, arg588_1, buf1060, arg589_1, 1, 6144, 2048, 2048, 1, 1, 2048, 6144, 1, 1, 16, stream=raw_stream0)
        del arg588_1
        del arg589_1
        buf1063 = buf1061; del buf1061  # reuse
        buf1064 = buf1021; del buf1021  # reuse
        # Topologically Sorted Source Nodes: [silu_27, mul_366, output_195], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_12.run(buf1057, buf1060, buf1064, 6144, stream=raw_stream0)
        del buf1057
        del buf1060
        assert_size_stride_grouped((arg590_1, arg591_1), ((2048, 6144), (16, 48)), ((6144, 1), (48, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_27, mul_366, output_195], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf1064, arg590_1, buf1063, arg591_1, 1, 2048, 6144, 6144, 1, 1, 6144, 2048, 1, 1, 48, stream=raw_stream0)
        del arg590_1
        del arg591_1
        del buf1064
        assert_size_stride(arg592_1, (2048, ), (1, ), 'input')
        buf1067 = buf1055; del buf1055  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_391, hidden_states_392, pow_113, variance_112, add_254, rsqrt_112, hidden_states_393, to_229, hidden_states_394], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19.run(buf1067, buf1063, arg592_1, 1, 2048, stream=raw_stream0)
        del arg592_1
        del buf1063
        assert_size_stride(arg593_1, (151936, 2048), (2048, 1), 'input')
        buf1068 = empty_strided((1, 151936), (151936, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_391, hidden_states_392, pow_113, variance_112, add_254, rsqrt_112, hidden_states_393, to_229, hidden_states_394, getitem_181, logits], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.slice, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_slice_t_view_20.run(buf1067, arg593_1, buf1068, 9496, 1, 1, stream=raw_stream0)
        del arg593_1
        del buf1067
        # Topologically Sorted Source Nodes: [add_], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__21.run(arg3_1, arg3_1, 1, stream=raw_stream0)
        del arg3_1
        # Topologically Sorted Source Nodes: [add__1], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__21.run(arg34_1, arg34_1, 1, stream=raw_stream0)
        del arg34_1
        # Topologically Sorted Source Nodes: [add__2], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__21.run(arg55_1, arg55_1, 1, stream=raw_stream0)
        del arg55_1
        # Topologically Sorted Source Nodes: [add__3], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__21.run(arg76_1, arg76_1, 1, stream=raw_stream0)
        del arg76_1
        # Topologically Sorted Source Nodes: [add__4], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__21.run(arg97_1, arg97_1, 1, stream=raw_stream0)
        del arg97_1
        # Topologically Sorted Source Nodes: [add__5], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__21.run(arg118_1, arg118_1, 1, stream=raw_stream0)
        del arg118_1
        # Topologically Sorted Source Nodes: [add__6], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__21.run(arg139_1, arg139_1, 1, stream=raw_stream0)
        del arg139_1
        # Topologically Sorted Source Nodes: [add__7], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__21.run(arg160_1, arg160_1, 1, stream=raw_stream0)
        del arg160_1
        # Topologically Sorted Source Nodes: [add__8], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__21.run(arg181_1, arg181_1, 1, stream=raw_stream0)
        del arg181_1
        # Topologically Sorted Source Nodes: [add__9], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__21.run(arg202_1, arg202_1, 1, stream=raw_stream0)
        del arg202_1
        # Topologically Sorted Source Nodes: [add__10], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__21.run(arg223_1, arg223_1, 1, stream=raw_stream0)
        del arg223_1
        # Topologically Sorted Source Nodes: [add__11], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__21.run(arg244_1, arg244_1, 1, stream=raw_stream0)
        del arg244_1
        # Topologically Sorted Source Nodes: [add__12], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__21.run(arg265_1, arg265_1, 1, stream=raw_stream0)
        del arg265_1
        # Topologically Sorted Source Nodes: [add__13], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__21.run(arg286_1, arg286_1, 1, stream=raw_stream0)
        del arg286_1
        # Topologically Sorted Source Nodes: [add__14], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__21.run(arg307_1, arg307_1, 1, stream=raw_stream0)
        del arg307_1
        # Topologically Sorted Source Nodes: [add__15], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__21.run(arg328_1, arg328_1, 1, stream=raw_stream0)
        del arg328_1
        # Topologically Sorted Source Nodes: [add__16], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__21.run(arg349_1, arg349_1, 1, stream=raw_stream0)
        del arg349_1
        # Topologically Sorted Source Nodes: [add__17], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__21.run(arg370_1, arg370_1, 1, stream=raw_stream0)
        del arg370_1
        # Topologically Sorted Source Nodes: [add__18], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__21.run(arg391_1, arg391_1, 1, stream=raw_stream0)
        del arg391_1
        # Topologically Sorted Source Nodes: [add__19], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__21.run(arg412_1, arg412_1, 1, stream=raw_stream0)
        del arg412_1
        # Topologically Sorted Source Nodes: [add__20], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__21.run(arg433_1, arg433_1, 1, stream=raw_stream0)
        del arg433_1
        # Topologically Sorted Source Nodes: [add__21], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__21.run(arg454_1, arg454_1, 1, stream=raw_stream0)
        del arg454_1
        # Topologically Sorted Source Nodes: [add__22], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__21.run(arg475_1, arg475_1, 1, stream=raw_stream0)
        del arg475_1
        # Topologically Sorted Source Nodes: [add__23], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__21.run(arg496_1, arg496_1, 1, stream=raw_stream0)
        del arg496_1
        # Topologically Sorted Source Nodes: [add__24], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__21.run(arg517_1, arg517_1, 1, stream=raw_stream0)
        del arg517_1
        # Topologically Sorted Source Nodes: [add__25], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__21.run(arg538_1, arg538_1, 1, stream=raw_stream0)
        del arg538_1
        # Topologically Sorted Source Nodes: [add__26], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__21.run(arg559_1, arg559_1, 1, stream=raw_stream0)
        del arg559_1
        # Topologically Sorted Source Nodes: [add__27], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__21.run(arg580_1, arg580_1, 1, stream=raw_stream0)
        del arg580_1
        return (buf1068, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((1, 1), (1, 1), device='tnca:0', dtype=torch.int64)
    arg1_1 = rand_strided((151936, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg2_1 = rand_strided((4, 1, 1), (1, 1, 1), device='tnca:0', dtype=torch.int64)
    arg3_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg4_1 = rand_strided((64, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg5_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg6_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg7_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg8_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg9_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg10_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg11_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg12_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg13_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg14_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg15_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg16_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg17_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg18_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg19_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg20_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg21_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg22_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg23_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg24_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg25_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg26_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg27_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg28_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg29_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg30_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg31_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg32_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg33_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg34_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg35_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg36_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg37_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg38_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg39_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg40_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg41_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg42_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg43_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg44_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg45_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg46_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg47_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg48_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg49_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg50_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg51_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg52_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg53_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg54_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg55_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg56_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg57_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg58_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg59_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg60_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg61_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg62_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg63_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg64_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg65_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg66_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg67_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg68_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg69_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg70_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg71_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg72_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg73_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg74_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg75_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg76_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg77_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg78_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg79_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg80_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg81_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg82_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg83_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg84_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg85_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg86_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg87_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg88_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg89_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg90_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg91_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg92_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg93_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg94_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg95_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg96_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg97_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg98_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg99_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg100_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg101_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg102_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg103_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg104_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg105_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg106_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg107_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg108_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg109_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg110_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg111_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg112_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg113_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg114_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg115_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg116_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg117_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg118_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg119_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg120_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg121_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg122_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg123_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg124_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg125_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg126_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg127_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg128_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg129_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg130_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg131_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg132_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg133_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg134_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg135_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg136_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg137_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg138_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg139_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg140_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg141_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg142_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg143_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg144_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg145_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg146_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg147_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg148_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg149_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg150_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg151_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg152_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg153_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg154_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg155_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg156_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg157_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg158_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg159_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg160_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg161_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg162_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg163_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg164_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg165_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg166_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg167_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg168_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg169_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg170_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg171_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg172_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg173_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg174_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg175_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg176_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg177_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg178_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg179_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg180_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg181_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg182_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg183_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg184_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg185_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg186_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg187_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg188_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg189_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg190_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg191_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg192_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg193_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg194_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg195_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg196_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg197_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg198_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg199_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg200_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg201_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg202_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg203_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg204_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg205_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg206_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg207_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg208_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg209_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg210_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg211_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg212_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg213_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg214_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg215_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg216_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg217_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg218_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg219_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg220_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg221_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg222_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg223_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg224_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg225_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg226_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg227_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg228_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg229_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg230_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg231_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg232_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg233_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg234_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg235_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg236_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg237_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg238_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg239_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg240_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg241_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg242_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg243_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg244_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg245_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg246_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg247_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg248_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg249_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg250_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg251_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg252_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg253_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg254_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg255_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg256_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg257_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg258_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg259_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg260_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg261_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg262_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg263_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg264_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg265_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg266_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg267_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg268_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg269_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg270_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg271_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg272_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg273_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg274_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg275_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg276_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg277_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg278_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg279_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg280_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg281_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg282_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg283_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg284_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg285_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg286_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg287_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg288_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg289_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg290_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg291_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg292_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg293_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg294_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg295_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg296_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg297_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg298_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg299_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg300_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg301_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg302_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg303_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg304_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg305_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg306_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg307_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg308_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg309_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg310_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg311_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg312_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg313_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg314_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg315_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg316_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg317_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg318_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg319_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg320_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg321_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg322_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg323_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg324_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg325_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg326_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg327_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg328_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg329_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg330_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg331_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg332_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg333_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg334_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg335_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg336_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg337_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg338_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg339_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg340_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg341_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg342_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg343_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg344_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg345_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg346_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg347_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg348_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg349_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg350_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg351_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg352_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg353_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg354_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg355_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg356_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg357_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg358_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg359_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg360_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg361_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg362_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg363_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg364_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg365_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg366_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg367_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg368_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg369_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg370_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg371_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg372_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg373_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg374_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg375_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg376_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg377_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg378_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg379_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg380_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg381_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg382_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg383_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg384_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg385_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg386_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg387_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg388_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg389_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg390_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg391_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg392_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg393_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg394_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg395_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg396_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg397_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg398_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg399_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg400_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg401_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg402_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg403_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg404_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg405_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg406_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg407_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg408_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg409_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg410_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg411_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg412_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg413_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg414_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg415_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg416_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg417_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg418_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg419_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg420_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg421_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg422_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg423_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg424_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg425_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg426_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg427_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg428_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg429_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg430_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg431_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg432_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg433_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg434_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg435_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg436_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg437_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg438_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg439_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg440_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg441_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg442_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg443_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg444_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg445_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg446_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg447_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg448_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg449_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg450_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg451_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg452_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg453_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg454_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg455_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg456_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg457_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg458_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg459_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg460_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg461_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg462_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg463_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg464_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg465_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg466_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg467_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg468_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg469_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg470_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg471_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg472_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg473_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg474_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg475_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg476_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg477_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg478_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg479_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg480_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg481_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg482_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg483_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg484_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg485_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg486_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg487_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg488_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg489_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg490_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg491_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg492_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg493_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg494_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg495_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg496_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg497_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg498_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg499_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg500_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg501_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg502_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg503_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg504_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg505_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg506_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg507_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg508_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg509_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg510_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg511_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg512_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg513_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg514_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg515_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg516_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg517_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg518_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg519_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg520_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg521_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg522_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg523_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg524_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg525_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg526_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg527_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg528_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg529_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg530_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg531_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg532_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg533_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg534_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg535_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg536_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg537_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg538_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg539_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg540_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg541_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg542_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg543_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg544_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg545_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg546_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg547_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg548_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg549_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg550_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg551_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg552_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg553_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg554_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg555_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg556_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg557_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg558_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg559_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg560_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg561_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg562_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg563_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg564_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg565_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg566_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg567_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg568_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg569_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg570_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg571_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg572_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg573_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg574_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg575_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg576_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg577_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg578_1 = rand_strided((1024, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg579_1 = rand_strided((8, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg580_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg581_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg582_1 = rand_strided((1, 8, 256, 128), (262144, 32768, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg583_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg584_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg585_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg586_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg587_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg588_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg589_1 = rand_strided((48, 16), (16, 1), device='tnca:0', dtype=torch.float32)
    arg590_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg591_1 = rand_strided((16, 48), (48, 1), device='tnca:0', dtype=torch.float32)
    arg592_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg593_1 = rand_strided((151936, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1, arg123_1, arg124_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg132_1, arg133_1, arg134_1, arg135_1, arg136_1, arg137_1, arg138_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg146_1, arg147_1, arg148_1, arg149_1, arg150_1, arg151_1, arg152_1, arg153_1, arg154_1, arg155_1, arg156_1, arg157_1, arg158_1, arg159_1, arg160_1, arg161_1, arg162_1, arg163_1, arg164_1, arg165_1, arg166_1, arg167_1, arg168_1, arg169_1, arg170_1, arg171_1, arg172_1, arg173_1, arg174_1, arg175_1, arg176_1, arg177_1, arg178_1, arg179_1, arg180_1, arg181_1, arg182_1, arg183_1, arg184_1, arg185_1, arg186_1, arg187_1, arg188_1, arg189_1, arg190_1, arg191_1, arg192_1, arg193_1, arg194_1, arg195_1, arg196_1, arg197_1, arg198_1, arg199_1, arg200_1, arg201_1, arg202_1, arg203_1, arg204_1, arg205_1, arg206_1, arg207_1, arg208_1, arg209_1, arg210_1, arg211_1, arg212_1, arg213_1, arg214_1, arg215_1, arg216_1, arg217_1, arg218_1, arg219_1, arg220_1, arg221_1, arg222_1, arg223_1, arg224_1, arg225_1, arg226_1, arg227_1, arg228_1, arg229_1, arg230_1, arg231_1, arg232_1, arg233_1, arg234_1, arg235_1, arg236_1, arg237_1, arg238_1, arg239_1, arg240_1, arg241_1, arg242_1, arg243_1, arg244_1, arg245_1, arg246_1, arg247_1, arg248_1, arg249_1, arg250_1, arg251_1, arg252_1, arg253_1, arg254_1, arg255_1, arg256_1, arg257_1, arg258_1, arg259_1, arg260_1, arg261_1, arg262_1, arg263_1, arg264_1, arg265_1, arg266_1, arg267_1, arg268_1, arg269_1, arg270_1, arg271_1, arg272_1, arg273_1, arg274_1, arg275_1, arg276_1, arg277_1, arg278_1, arg279_1, arg280_1, arg281_1, arg282_1, arg283_1, arg284_1, arg285_1, arg286_1, arg287_1, arg288_1, arg289_1, arg290_1, arg291_1, arg292_1, arg293_1, arg294_1, arg295_1, arg296_1, arg297_1, arg298_1, arg299_1, arg300_1, arg301_1, arg302_1, arg303_1, arg304_1, arg305_1, arg306_1, arg307_1, arg308_1, arg309_1, arg310_1, arg311_1, arg312_1, arg313_1, arg314_1, arg315_1, arg316_1, arg317_1, arg318_1, arg319_1, arg320_1, arg321_1, arg322_1, arg323_1, arg324_1, arg325_1, arg326_1, arg327_1, arg328_1, arg329_1, arg330_1, arg331_1, arg332_1, arg333_1, arg334_1, arg335_1, arg336_1, arg337_1, arg338_1, arg339_1, arg340_1, arg341_1, arg342_1, arg343_1, arg344_1, arg345_1, arg346_1, arg347_1, arg348_1, arg349_1, arg350_1, arg351_1, arg352_1, arg353_1, arg354_1, arg355_1, arg356_1, arg357_1, arg358_1, arg359_1, arg360_1, arg361_1, arg362_1, arg363_1, arg364_1, arg365_1, arg366_1, arg367_1, arg368_1, arg369_1, arg370_1, arg371_1, arg372_1, arg373_1, arg374_1, arg375_1, arg376_1, arg377_1, arg378_1, arg379_1, arg380_1, arg381_1, arg382_1, arg383_1, arg384_1, arg385_1, arg386_1, arg387_1, arg388_1, arg389_1, arg390_1, arg391_1, arg392_1, arg393_1, arg394_1, arg395_1, arg396_1, arg397_1, arg398_1, arg399_1, arg400_1, arg401_1, arg402_1, arg403_1, arg404_1, arg405_1, arg406_1, arg407_1, arg408_1, arg409_1, arg410_1, arg411_1, arg412_1, arg413_1, arg414_1, arg415_1, arg416_1, arg417_1, arg418_1, arg419_1, arg420_1, arg421_1, arg422_1, arg423_1, arg424_1, arg425_1, arg426_1, arg427_1, arg428_1, arg429_1, arg430_1, arg431_1, arg432_1, arg433_1, arg434_1, arg435_1, arg436_1, arg437_1, arg438_1, arg439_1, arg440_1, arg441_1, arg442_1, arg443_1, arg444_1, arg445_1, arg446_1, arg447_1, arg448_1, arg449_1, arg450_1, arg451_1, arg452_1, arg453_1, arg454_1, arg455_1, arg456_1, arg457_1, arg458_1, arg459_1, arg460_1, arg461_1, arg462_1, arg463_1, arg464_1, arg465_1, arg466_1, arg467_1, arg468_1, arg469_1, arg470_1, arg471_1, arg472_1, arg473_1, arg474_1, arg475_1, arg476_1, arg477_1, arg478_1, arg479_1, arg480_1, arg481_1, arg482_1, arg483_1, arg484_1, arg485_1, arg486_1, arg487_1, arg488_1, arg489_1, arg490_1, arg491_1, arg492_1, arg493_1, arg494_1, arg495_1, arg496_1, arg497_1, arg498_1, arg499_1, arg500_1, arg501_1, arg502_1, arg503_1, arg504_1, arg505_1, arg506_1, arg507_1, arg508_1, arg509_1, arg510_1, arg511_1, arg512_1, arg513_1, arg514_1, arg515_1, arg516_1, arg517_1, arg518_1, arg519_1, arg520_1, arg521_1, arg522_1, arg523_1, arg524_1, arg525_1, arg526_1, arg527_1, arg528_1, arg529_1, arg530_1, arg531_1, arg532_1, arg533_1, arg534_1, arg535_1, arg536_1, arg537_1, arg538_1, arg539_1, arg540_1, arg541_1, arg542_1, arg543_1, arg544_1, arg545_1, arg546_1, arg547_1, arg548_1, arg549_1, arg550_1, arg551_1, arg552_1, arg553_1, arg554_1, arg555_1, arg556_1, arg557_1, arg558_1, arg559_1, arg560_1, arg561_1, arg562_1, arg563_1, arg564_1, arg565_1, arg566_1, arg567_1, arg568_1, arg569_1, arg570_1, arg571_1, arg572_1, arg573_1, arg574_1, arg575_1, arg576_1, arg577_1, arg578_1, arg579_1, arg580_1, arg581_1, arg582_1, arg583_1, arg584_1, arg585_1, arg586_1, arg587_1, arg588_1, arg589_1, arg590_1, arg591_1, arg592_1, arg593_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
