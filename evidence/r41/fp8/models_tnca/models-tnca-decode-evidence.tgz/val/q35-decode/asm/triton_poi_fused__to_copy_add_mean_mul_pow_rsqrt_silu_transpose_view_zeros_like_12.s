    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.shli       s2, s4, #4                      // x16 as a shift
    s.ld.d       s3, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.shli       s4, s2, #1                      // element offset -> bytes (x2)
    .li       s5, #1124073472
    v.splat      v0, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s5, s3, s4                      // &in_ptr3[...]
    v.rcp.approx v1, v0                          // ISA 8.8: <= 2**-22 relative
    v.ld.h       v2, [s5, #0]
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v4, s2
    v.movi       v5, #0
    v.add        v6, v4, v3
    v.movi       v3, #7
    vf.cvt.bf16.f32 v4, v2
    v.sub        v2, v5, v6
    v.cmp.lt     p1, v6, v5
    @p1 v.sel        v7, v2, v6
    .li       s3, #1065353216
    v.splat      v2, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.lshr       v8, v7, v3
    s.ld.d       s3, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.sub        v3, v5, v8
    v.movi       v7, #0
    @p1 v.sel        v9, v3, v8
    v.sub        v3, v7, v6
    v.ld.gather.w v8, [s3, v9]                   // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v7
    @p1 v.sel        v9, v3, v6
    v.movi       v3, #127
    s.shli       s3, s2, #2                      // element offset -> bytes (x4)
    v.and        v6, v9, v3
    v.movi       v3, #128
    v.sub        v9, v7, v6
    v.sub        v10, v7, v3
    vf.fms       v11, v0, v1, v2
    s.ld.d       s2, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    @p1 v.sel        v12, v9, v6
    v.sub        v6, v5, v3
    vf.fms       v9, v1, v11, v1
    s.add        s5, s2, s3                      // &in_ptr1[...]
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.cmp.lt     p1, v3, v7
    vf.neg       v7, v9                          // Newton step: r0*(2 - x*r0)
    v.ld.w       v9, [s5, #0]
    v.cmp.lt     p2, v3, v5
    @p1 v.sel        v5, v10, v3
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v5, v7, v1
    @p2 v.sel        v1, v6, v3
    vf.mul       v1, v8, v5                      // a/y: faithful quotient
    vf.fms       v3, v1, v0, v8
    v.ld.gather.h v0, [s2, v12]                  // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v6, v0
    s.ld.d       s2, [s1, #32]                   // out_ptr0: device_ptr64 at arg_base+32
    vf.neg       v0, v4
    .li       s1, #1069066811
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1060205080
    v.splat      v8, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v10, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v11, v0, v7
    vf.fms       v12, v3, v5, v1
    .li       s1, #897988541
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s1, s2, s4                      // &out_ptr0[...]
    vf.fms       v5, v0, v7, v11                 // the exact rounding error of x*log2(e)
    v.exp2.approx v0, v11                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v7, v12                         // a/y: one correction to the IEEE quotient
    .li       s2, #1077936128
    v.splat      v11, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v12, v5, v8
    .li       s2, #3204448256
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v8, v7, v1
    vf.add       v1, v8, v3
    v.rsqrt.approx v3, v1                        // ISA 8.8: <= 2**-22 relative
    vf.fma       v7, v0, v12, v0                 // 2**t * 2**d
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v8, v7, v0
    vf.add       v0, v8, v10
    v.rcp.approx v7, v0                          // ISA 8.8: <= 2**-22 relative
    vf.mul       v8, v3, v3
    vf.mul       v10, v3, v5
    vf.fms       v5, v1, v8, v11
    vf.mul       v1, v10, v5                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v5, v1, v3
    vf.mul       v1, v9, v5
    vf.mul       v3, v6, v1
    vf.fms       v1, v0, v7, v2
    vf.fms       v2, v7, v1, v7
    vf.neg       v1, v2                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v2, v1, v7
    vf.mul       v1, v4, v2                      // a/y: faithful quotient
    vf.fms       v5, v1, v0, v4
    vf.fms       v0, v5, v2, v1
    vf.neg       v2, v0                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v0, v2, v1
    vf.mul       v1, v3, v0
    vf.cvt.f32.bf16 v0, v1
    v.st.h       [s1, #0], v0
__rctx_next:
    exit
