#!/bin/sh
# Batch C on GB10: system and multicore regressions for the final-image candidate.
# Three lanes in parallel (<= 3 cores), each logging separately.
. ~/tc_env/env.sh
cd ~/tc_hw_final
L=~/tc_hw_logs
lane() { name=$1; shift; ( "$@" ; echo "EXIT=$?" ) > $L/C_$name.log 2>&1; }
(
lane nuca_top_mesh sh -c 'nice -n 10 make top && nice -n 10 make nuca && nice -n 10 make mesh && nice -n 10 make nuca-dco && nice -n 10 make nuca-dco IVFLAGS="-g2012 -I rtl/common -Ptb_nuca_slice.DCO_REGISTERED_RANGES=1" && nice -n 10 make nuca-dco DCO_POLICIES="2 74" DCO_SEEDS="1 7" IVFLAGS="-g2012 -I rtl/common -Ptb_nuca_slice.DCO_REGISTERED_RANGES=1 -Ptb_nuca_slice.REGISTER_VICTIM_OWNER=1 -Ptb_nuca_slice.EPOCH_CHURN=1" && for ports in 3 8; do iverilog -g2012 -I rtl/common -s tb_tmu_registered_ranges -Ptb_tmu_registered_ranges.PORTS=$ports -o /tmp/hw-tmu-$ports.vvp tb/nuca/tb_tmu_registered_ranges.v rtl/nuca/tnca_tmu.v && vvp /tmp/hw-tmu-$ports.vvp || exit 1; done'
) &
(
lane r40_rtl sh -c 'nice -n 10 make r40-grid-dispatch r40-multicore-shell r40-grid-deadline r40-core-parameters && nice -n 10 make r40-memory-ports r40-line-axi r40-cache-maintenance r40-multicore-dma TRITON_PYTHON=$TRITON_PYTHON TORCH_PYTHON=$TRITON_PYTHON'
) &
(
lane mmio sh -c 'nice -n 10 $TRITON_PYTHON tools/r40/multicore_mmio_tests.py --cores 1 --ports 1 && nice -n 10 $TRITON_PYTHON tools/r40/multicore_mmio_tests.py --cores 3 --ports 3 && nice -n 10 $TRITON_PYTHON tools/r40/multicore_mmio_tests.py --cores 3 --ports 3 --pipeline 2 --board-top'
) &
wait
echo BATCH_C_DONE > $L/C_done.log
