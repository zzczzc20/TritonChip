source ~/tc_env/env.sh
cd /tmp/r40_p0b_source
python3 targeted2.py > /tmp/r40_p0_targeted2.log 2>&1
echo $? > /tmp/r40_p0_targeted2.exit
