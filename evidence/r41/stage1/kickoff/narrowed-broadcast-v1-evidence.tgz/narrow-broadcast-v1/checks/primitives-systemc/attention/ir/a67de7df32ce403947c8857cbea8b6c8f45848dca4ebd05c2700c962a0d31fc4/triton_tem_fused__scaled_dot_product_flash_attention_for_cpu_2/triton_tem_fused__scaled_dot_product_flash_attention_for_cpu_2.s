    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #1
    s.movz       s2, #0
    s.sub        s3, s1, s4
    s.movz       s5, #0
    s.min.s      s6, s3, s1
    s.movz       s1, #0
    s.cmp.lt     s3, s6, s2
    s.movz       s2, #0
    s.cmp.lt     s7, s4, s5
    s.sub        s5, s1, s3
    s.sub        s1, s2, s7
    s.xor        s2, s6, s5
    s.movz       s3, #0
    s.movz       s7, #1
    s.xor        s8, s4, s1
    s.sub        s9, s2, s5
    s.rdspecial  s2, arg_base
    s.movz       s5, #0
    s.sub        s10, s8, s1
    s.addi       s8, s3, #0
    s.cmp.eq     s3, s9, s7
    s.ld.d       s7, [s2, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.addi       s11, s5, #0
    s.ld.d       s5, [s2, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s12, [s2, #16]                  // out_ptr0: device_ptr64 at arg_base+16
    s.mov        s8, s10
    br.nz        s3, sdiv_done_1
    s.movz       s2, #0
    s.movz       s3, #31
    s.mov        s8, s2
    s.addi       s2, s3, #0
sdiv_2:
    s.lshr       s3, s10, s2
    s.shli       s13, s11, #1
    s.andi       s14, s3, #1
    s.movz       s3, #0
    s.or         s15, s13, s14
    s.movz       s13, #1
    s.cmp.geu    s14, s15, s9
    s.shl        s16, s13, s2
    s.sub        s13, s3, s14
    s.subi       s3, s2, #1
    s.and        s14, s9, s13
    s.and        s17, s16, s13
    s.sub        s13, s15, s14
    s.or         s14, s8, s17
    s.mov        s11, s13
    s.mov        s8, s14
    s.mov        s2, s3
    s.movz       s3, #0
    s.cmp.ge     s13, s2, s3
    br.nz        s13, sdiv_2
sdiv_done_1:
    s.movz       s2, #0
    s.movz       s3, #0
    s.movz       s8, #0
    s.movz       s9, #0
    s.cmp.lt     s10, s6, s2
    s.movz       s2, #0
    s.cmp.lt     s13, s3, s8
    s.sub        s8, s9, s10
    s.sub        s9, s2, s13
    s.xor        s2, s6, s8
    s.xor        s6, s11, s1
    s.xor        s10, s3, s9
    s.sub        s11, s2, s8
    s.movz       s2, #0
    s.movz       s13, #1
    s.sub        s14, s6, s1
    s.sub        s1, s10, s9
    s.movz       s6, #0
    s.addi       s10, s2, #0
    s.cmp.eq     s2, s11, s13
    s.add        s13, s4, s14
    s.addi       s4, s6, #0
    s.mov        s10, s1
    br.nz        s2, sdiv_done_3
    s.movz       s2, #0
    s.movz       s6, #31
    s.mov        s10, s2
    s.addi       s2, s6, #0
sdiv_4:
    s.lshr       s6, s1, s2
    s.shli       s14, s4, #1
    s.andi       s15, s6, #1
    s.movz       s6, #0
    s.or         s16, s14, s15
    s.movz       s14, #1
    s.cmp.geu    s15, s16, s11
    s.shl        s17, s14, s2
    s.sub        s14, s6, s15
    s.subi       s6, s2, #1
    s.and        s15, s11, s14
    s.and        s18, s17, s14
    s.sub        s14, s16, s15
    s.or         s15, s10, s18
    s.mov        s4, s14
    s.mov        s10, s15
    s.mov        s2, s6
    s.movz       s6, #0
    s.cmp.ge     s14, s2, s6
    br.nz        s14, sdiv_4
sdiv_done_3:
    s.movz       s1, #16
    s.xor        s2, s9, s8
    s.mul        s4, s13, s1
    s.xor        s6, s10, s2
    v.iota       v0                              // arange(0, VLEN)
    s.sub        s8, s6, s2
    v.movi       v1, #5
    v.splat      v2, s4
    s.mul        s2, s8, s1
    v.movi       v3, #0
    v.add        v4, v2, v0
    v.splat      v2, s13
    v.splat      v5, s3
    v.splat      v6, s8
    v.splat      v7, s3
    v.splat      v8, s2
    v.sub        v9, v3, v4
    v.sub        v10, v3, v1
    v.cmp.lt     p1, v4, v3
    v.cmp.lt     p2, v1, v3
    v.cmp.ge     p3, v2, v5
    v.cmp.ge     p3, v6, v7
    v.add        v2, v8, v0
    v.movi       v0, #1
    @p1 v.sel        v5, v9, v4
    @p2 v.sel        v4, v10, v1
    v.movi       v6, #0
    v.movi       v7, #0
    s.movz       s6, #31
idiv_5:
    v.splat      v8, s6
    v.shl        v9, v7, v0
    v.cmp.lt     p2, v7, v3
    v.lshr       v10, v5, v8
    v.shl        v11, v0, v8
    s.subi       s8, s6, #1
    v.and        v8, v10, v0
    s.movz       s9, #0
    v.or         v10, v9, v8
    v.cmp.geu    p3, v10, v4
    p.or         p4, p2, p3
    v.sub        v8, v10, v4
    @p4 v.sel        v9, v11, v3
    @p4 v.sel        v11, v8, v10
    v.or         v8, v6, v9
    v.mov        v7, v11
    v.mov        v6, v8
    s.mov        s6, s8
    s.cmp.ge     s8, s6, s9
    br.nz        s8, idiv_5
    v.movi       v0, #0
    v.sub        v4, v3, v7
    v.movi       v3, #1
    v.sub        v5, v0, v2
    v.sub        v6, v0, v1
    v.cmp.lt     p2, v2, v0
    v.cmp.lt     p3, v1, v0
    @p1 v.sel        v8, v4, v7
    @p2 v.sel        v4, v5, v2
    @p3 v.sel        v2, v6, v1
    v.movi       v1, #0
    v.movi       v5, #0
    s.movz       s6, #31
idiv_6:
    v.splat      v6, s6
    v.shl        v7, v5, v3
    v.cmp.lt     p1, v5, v0
    v.lshr       v9, v4, v6
    v.shl        v10, v3, v6
    s.subi       s8, s6, #1
    v.and        v6, v9, v3
    s.movz       s9, #0
    v.or         v9, v7, v6
    v.cmp.geu    p3, v9, v2
    p.or         p4, p1, p3
    v.sub        v6, v9, v2
    @p4 v.sel        v7, v10, v0
    @p4 v.sel        v10, v6, v9
    v.or         v6, v1, v7
    v.mov        v5, v10
    v.mov        v1, v6
    s.mov        s6, s8
    s.cmp.ge     s8, s6, s9
    br.nz        s8, idiv_6
    s.rdspecial  s6, pid.z
    s.rdspecial  s8, npid.y
    s.rdspecial  s9, pid.y
    s.mul        s10, s6, s8
    s.movz       s6, #7
    s.rdspecial  s8, arg_base
    s.movz       s11, #1280
    s.ld.d       s13, [s8, #24]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.add        s8, s9, s10
    v.extract    s9, v8, #0
    s.min.s      s10, s8, s6
    s.movz       s6, #256
    v.extract    s14, v8, #1
    v.extract    s15, v8, #2
    s.mul        s16, s10, s11
    v.sub        v1, v0, v5
    v.splat      v0, s9
    v.splat      v2, s6
    v.splat      v3, s14
    v.splat      v4, s15
    s.rdspecial  s9, role_id
    s.movz       s10, #8192
    s.movz       s11, #0
    @p2 v.sel        v6, v1, v5
    v.extract    s14, v8, #3
    v.extract    s15, v8, #4
    v.splat      v1, s14
    v.splat      v5, s15
    v.mul        v7, v0, v2
    v.iota       v0                              // arange(0, VLEN)
    v.mul        v9, v3, v2
    v.mul        v3, v4, v2
    v.mul        v4, v1, v2
    v.mul        v1, v5, v2
    s.mul        s14, s9, s10
    s.add        s9, s11, s16                    // the tile origin
    v.add        v5, v7, v0
    v.splat      v7, s9
    v.add        v10, v9, v0
    v.add        v9, v3, v0
    v.add        v3, v4, v0
    v.add        v4, v1, v0
    s.add        s9, s13, s14                    // this context's own scratch
    v.splat      v1, s3
    v.add        v11, v5, v7
    v.add        v5, v10, v7
    v.add        v10, v9, v7
    v.add        v9, v3, v7
    v.add        v3, v4, v7
    s.addi       s10, s9, #0
    v.extract    s11, v8, #5
    v.extract    s13, v8, #6
    v.add        v4, v1, v11
    v.add        v11, v1, v5
    v.add        v5, v1, v10
    v.add        v10, v1, v9
    v.add        v9, v1, v3
    s.addi       s14, s10, #64
    s.addi       s15, s10, #128
    s.addi       s16, s10, #192
    s.addi       s17, s10, #256
    s.addi       s18, s10, #320
    s.addi       s19, s10, #384
    v.st.w       [s10, #0], v4
    v.splat      v3, s11
    v.extract    s11, v8, #7
    v.mul        v4, v3, v2
    v.add        v3, v4, v0
    v.add        v4, v3, v7
    v.add        v3, v1, v4
    v.st.w       [s14, #0], v11
    v.extract    s14, v8, #8
    v.splat      v4, s13
    s.addi       s13, s10, #448
    v.mul        v11, v4, v2
    v.add        v4, v11, v0
    v.add        v11, v4, v7
    v.add        v4, v1, v11
    v.st.w       [s15, #0], v5
    v.extract    s15, v8, #9
    v.splat      v5, s11
    s.addi       s11, s10, #512
    v.mul        v11, v5, v2
    v.add        v5, v11, v0
    v.add        v11, v5, v7
    v.add        v5, v1, v11
    v.st.w       [s16, #0], v10
    v.extract    s16, v8, #10
    v.splat      v10, s14
    s.addi       s14, s10, #576
    v.mul        v11, v10, v2
    v.add        v10, v11, v0
    v.add        v11, v10, v7
    v.add        v10, v1, v11
    v.st.w       [s17, #0], v9
    v.extract    s17, v8, #11
    v.splat      v9, s15
    s.addi       s15, s10, #640
    v.mul        v11, v9, v2
    v.add        v9, v11, v0
    v.add        v11, v9, v7
    v.add        v9, v1, v11
    v.st.w       [s18, #0], v3
    v.extract    s18, v8, #12
    v.splat      v3, s16
    s.addi       s16, s10, #704
    v.mul        v11, v3, v2
    v.add        v3, v11, v0
    v.add        v11, v3, v7
    v.add        v3, v1, v11
    v.st.w       [s19, #0], v4
    v.extract    s19, v8, #13
    v.splat      v4, s17
    s.addi       s17, s10, #768
    v.mul        v11, v4, v2
    v.add        v4, v11, v0
    v.add        v11, v4, v7
    v.add        v4, v1, v11
    v.st.w       [s13, #0], v5
    v.extract    s13, v8, #14
    v.splat      v5, s18
    s.addi       s18, s10, #832
    v.mul        v11, v5, v2
    v.add        v5, v11, v0
    v.add        v11, v5, v7
    v.add        v5, v1, v11
    v.st.w       [s11, #0], v10
    v.extract    s11, v8, #15
    v.splat      v8, s19
    v.splat      v10, s13
    s.addi       s13, s10, #896
    v.mul        v11, v8, v2
    v.mul        v8, v10, v2
    s.addi       s19, s10, #960
    v.add        v10, v11, v0
    v.add        v11, v8, v0
    v.add        v8, v10, v7
    v.add        v10, v11, v7
    v.add        v11, v1, v8
    v.add        v8, v1, v10
    v.st.w       [s14, #0], v9
    v.splat      v9, s11
    s.addi       s10, s9, #1024
    v.mul        v10, v9, v2
    v.splat      v2, s3
    v.add        v9, v10, v0
    v.add        v10, v2, v6
    v.add        v2, v9, v7
    v.add        v9, v10, v7
    v.add        v10, v1, v2
    v.splat      v1, s3
    v.add        v2, v1, v9
    v.st.w       [s15, #0], v3
    s.movz       s11, #5
    s.addi       s14, s10, #64
    v.splat      v3, s11
    v.add        v9, v3, v6
    v.add        v3, v9, v7
    v.add        v9, v1, v3
    v.st.w       [s16, #0], v4
    s.movz       s15, #10
    s.addi       s16, s10, #128
    v.splat      v3, s15
    s.addi       s15, s10, #192
    v.add        v4, v3, v6
    v.add        v3, v4, v7
    v.add        v4, v1, v3
    v.st.w       [s17, #0], v5
    s.movz       s17, #15
    v.splat      v3, s17
    s.movz       s17, #20
    v.add        v5, v3, v6
    v.add        v3, v5, v7
    v.add        v5, v1, v3
    v.st.w       [s18, #0], v11
    s.movz       s18, #25
    v.splat      v3, s17
    s.addi       s17, s10, #256
    v.add        v11, v3, v6
    v.add        v3, v11, v7
    v.add        v11, v1, v3
    v.st.w       [s13, #0], v8
    s.movz       s13, #30
    v.splat      v3, s18
    v.add        v8, v3, v6
    v.add        v3, v8, v7
    v.add        v8, v1, v3
    v.st.w       [s19, #0], v10
    v.splat      v3, s13
    s.addi       s13, s10, #320
    s.addi       s19, s10, #384
    v.add        v10, v3, v6
    fence.acq_rel.device
    v.add        v3, v10, v7
    v.add        v10, v1, v3
    v.st.w       [s10, #0], v2
    v.st.w       [s14, #0], v9
    s.movz       s14, #35
    v.splat      v2, s14
    s.movz       s14, #40
    v.splat      v3, s14
    s.movz       s14, #45
    v.add        v9, v2, v6
    v.add        v2, v3, v6
    v.add        v3, v9, v7
    v.add        v9, v2, v7
    v.add        v2, v1, v3
    v.add        v3, v1, v9
    v.st.w       [s16, #0], v4
    s.movz       s16, #50
    v.splat      v4, s14
    s.addi       s14, s10, #448
    v.add        v9, v4, v6
    v.add        v4, v9, v7
    v.add        v9, v1, v4
    v.st.w       [s15, #0], v5
    s.movz       s15, #55
    v.splat      v4, s16
    s.addi       s16, s10, #512
    v.add        v5, v4, v6
    v.add        v4, v5, v7
    v.add        v5, v1, v4
    v.st.w       [s17, #0], v11
    s.movz       s17, #60
    v.splat      v4, s15
    s.addi       s15, s10, #576
    v.add        v11, v4, v6
    v.add        v4, v11, v7
    v.add        v11, v1, v4
    v.st.w       [s13, #0], v8
    s.movz       s13, #65
    v.splat      v4, s17
    s.addi       s17, s10, #640
    v.add        v8, v4, v6
    v.add        v4, v8, v7
    v.add        v8, v1, v4
    v.st.w       [s19, #0], v10
    s.movz       s19, #70
    v.splat      v4, s13
    s.addi       s13, s10, #704
    v.add        v10, v4, v6
    v.add        v4, v10, v7
    v.add        v10, v1, v4
    v.st.w       [s14, #0], v2
    s.movz       s14, #75
    v.splat      v2, s19
    s.addi       s19, s10, #768
    v.add        v4, v2, v6
    v.add        v2, v4, v7
    v.add        v4, v1, v2
    v.st.w       [s16, #0], v3
    v.splat      v2, s14
    s.addi       s14, s10, #832
    s.addi       s16, s10, #896
    v.add        v3, v2, v6
    s.addi       s20, s10, #960
    s.addi       s10, s3, #0
    v.add        v2, v3, v7
    v.add        v3, v1, v2
    v.st.w       [s15, #0], v9
    s.addi       s3, s9, #0
    v.st.w       [s17, #0], v5
    s.addi       s15, s9, #2048
    v.st.w       [s13, #0], v11
    s.addi       s13, s9, #64
    v.st.w       [s19, #0], v8
    s.addi       s17, s15, #64
    v.st.w       [s14, #0], v10
    s.addi       s14, s9, #128
    v.st.w       [s16, #0], v4
    s.addi       s16, s15, #128
    v.st.w       [s20, #0], v3
    fence.acq_rel.device
    s.addi       s19, s9, #192
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s15, #192
    v.st.w       [s15, #0], v1
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s9, #256
    v.st.w       [s17, #0], v1
    s.addi       s17, s15, #256
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s9, #320
    v.st.w       [s16, #0], v1
    s.addi       s16, s15, #320
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s9, #384
    v.st.w       [s3, #0], v1
    s.addi       s3, s15, #384
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s9, #448
    v.st.w       [s17, #0], v1
    s.addi       s17, s15, #448
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s9, #512
    v.st.w       [s16, #0], v1
    s.addi       s16, s15, #512
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s9, #576
    v.st.w       [s3, #0], v1
    s.addi       s3, s15, #576
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s9, #640
    v.st.w       [s17, #0], v1
    s.addi       s17, s15, #640
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s9, #704
    v.st.w       [s16, #0], v1
    s.addi       s16, s15, #704
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s9, #768
    v.st.w       [s3, #0], v1
    s.addi       s3, s15, #768
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s9, #832
    v.st.w       [s17, #0], v1
    s.addi       s17, s15, #832
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s9, #896
    v.st.w       [s16, #0], v1
    s.addi       s16, s15, #896
    s.addi       s20, s15, #960
    v.ld.w       v1, [s19, #0]
    s.addi       s15, s9, #960
    v.st.w       [s3, #0], v1
    s.addi       s3, s9, #1024
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s9, #3072
    v.st.w       [s17, #0], v1
    s.addi       s17, s9, #1088
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s13, #64
    v.st.w       [s16, #0], v1
    s.addi       s16, s9, #1152
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s13, #128
    v.st.w       [s20, #0], v1
    fence.acq_rel.device
    s.addi       s19, s9, #1216
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s13, #192
    v.st.w       [s13, #0], v1
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s9, #1280
    v.st.w       [s14, #0], v1
    s.addi       s14, s13, #256
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s9, #1344
    v.st.w       [s15, #0], v1
    s.addi       s15, s13, #320
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s9, #1408
    v.st.w       [s3, #0], v1
    s.addi       s3, s13, #384
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s9, #1472
    v.st.w       [s14, #0], v1
    s.addi       s14, s13, #448
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s9, #1536
    v.st.w       [s15, #0], v1
    s.addi       s15, s13, #512
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s9, #1600
    v.st.w       [s3, #0], v1
    s.addi       s3, s13, #576
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s9, #1664
    v.st.w       [s14, #0], v1
    s.addi       s14, s13, #640
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s9, #1728
    v.st.w       [s15, #0], v1
    s.addi       s15, s13, #704
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s9, #1792
    v.st.w       [s3, #0], v1
    s.addi       s3, s13, #768
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s9, #1856
    v.st.w       [s14, #0], v1
    s.addi       s14, s13, #832
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s9, #1920
    v.st.w       [s15, #0], v1
    s.addi       s15, s13, #896
    s.addi       s20, s13, #960
    v.ld.w       v1, [s19, #0]
    s.addi       s13, s9, #1984
    v.st.w       [s3, #0], v1
    v.ld.w       v1, [s17, #0]
    v.st.w       [s14, #0], v1
    v.ld.w       v1, [s16, #0]
    v.st.w       [s15, #0], v1
    v.ld.w       v1, [s13, #0]
    v.st.w       [s20, #0], v1
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_7:
    s.cmp.ge     s3, s10, s6
    br.nz        s3, endfor_8
    s.addi       s3, s9, #2048
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s13, #0
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s9, #2112
    s.movz       s14, #1
    s.addi       s15, s9, #2176
    s.movz       s16, #2
    s.addi       s17, s9, #2240
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s13, v2
    v.ld.w       v1, [s3, #0]
    s.movz       s3, #3
    s.addi       s13, s9, #2304
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s14, v2
    v.ld.w       v1, [s15, #0]
    s.movz       s14, #4
    s.addi       s15, s9, #2368
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s16, v2
    v.ld.w       v1, [s17, #0]
    s.movz       s16, #5
    s.addi       s17, s9, #2432
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s3, v2
    v.ld.w       v1, [s13, #0]
    s.movz       s3, #6
    s.addi       s13, s9, #2496
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s14, v2
    v.ld.w       v1, [s15, #0]
    s.movz       s14, #7
    s.addi       s15, s9, #2560
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s16, v2
    v.ld.w       v1, [s17, #0]
    s.movz       s16, #8
    s.addi       s17, s9, #2624
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s3, v2
    v.ld.w       v1, [s13, #0]
    s.movz       s3, #9
    s.addi       s13, s9, #2688
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s14, v2
    v.ld.w       v1, [s15, #0]
    s.movz       s14, #10
    s.addi       s15, s9, #2752
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s16, v2
    v.ld.w       v1, [s17, #0]
    s.movz       s16, #11
    s.addi       s17, s9, #2816
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s3, v2
    v.ld.w       v1, [s13, #0]
    s.movz       s3, #12
    s.addi       s13, s9, #2880
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s14, v2
    v.ld.w       v1, [s15, #0]
    s.movz       s14, #13
    s.addi       s15, s9, #2944
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s16, v2
    v.ld.w       v1, [s17, #0]
    s.movz       s16, #14
    s.addi       s17, s9, #3008
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s3, v2
    v.ld.w       v1, [s13, #0]
    s.movz       s3, #15
    s.addi       s13, s9, #3072
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s14, v2
    v.ld.w       v1, [s15, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s14, #0
    s.addi       s15, s9, #3136
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s16, v2
    v.ld.w       v1, [s17, #0]
    s.movz       s16, #1
    s.addi       s17, s9, #3200
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    s.movz       s19, #2
    a.vwrite     a1, s3, v2
    v.ld.w       v1, [s13, #0]
    s.addi       s3, s9, #3264
    s.movz       s13, #3
    v.ld.gather.w v2, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s14, v2
    v.ld.w       v1, [s15, #0]
    s.addi       s14, s9, #3328
    s.movz       s15, #4
    v.ld.gather.w v2, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s16, v2
    v.ld.w       v1, [s17, #0]
    s.addi       s16, s9, #3392
    s.movz       s17, #5
    v.ld.gather.w v2, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s19, v2
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s9, #3456
    s.movz       s19, #6
    v.ld.gather.w v2, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s13, v2
    v.ld.w       v1, [s14, #0]
    s.addi       s13, s9, #3520
    s.movz       s14, #7
    v.ld.gather.w v2, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v2
    v.ld.w       v1, [s16, #0]
    s.addi       s15, s9, #3584
    s.movz       s16, #8
    v.ld.gather.w v2, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s17, v2
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s9, #3648
    s.movz       s17, #9
    v.movi       v2, #0
    v.ld.gather.w v3, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s19, v3
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s9, #3712
    s.movz       s19, #10
    v.ld.gather.w v3, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s14, v3
    v.ld.w       v1, [s15, #0]
    s.addi       s14, s9, #3776
    s.movz       s15, #11
    v.ld.gather.w v3, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s16, v3
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s9, #3840
    s.movz       s16, #12
    v.ld.gather.w v3, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s17, v3
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s9, #3904
    s.movz       s17, #13
    v.ld.gather.w v3, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s19, v3
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s9, #3968
    s.movz       s19, #14
    v.ld.gather.w v3, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v3
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s9, #4032
    s.movz       s15, #15
    v.ld.gather.w v3, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s16, v3
    v.ld.w       v1, [s13, #0]
    s.movz       s13, #0
    s.movz       s16, #0
    v.ld.gather.w v3, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s17, v3
    v.ld.w       v1, [s14, #0]
    s.movz       s14, #1
    s.movz       s17, #2
    v.ld.gather.w v3, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s19, v3
    v.ld.w       v1, [s3, #0]
    s.movz       s3, #3
    s.movz       s19, #4
    v.ld.gather.w v3, [s5, v1]                   // index is in elements (ISA sec 9.1)
    s.movz       s20, #5
    a.vwrite     a2, s15, v3
    a.vread      v1, a1, s13
    a.vread      v3, a2, s16
    a.vread      v4, a2, s14
    v.extract    s13, v1, #0
    v.extract    s14, v1, #1
    v.splat      v5, s13
    v.splat      v6, s14
    v.extract    s13, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s13
    a.vread      v5, a2, s17
    v.extract    s13, v1, #3
    a.vread      v8, a2, s3
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s13
    v.extract    s3, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s3
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v1, #5
    a.vread      v3, a2, s20
    v.splat      v5, s3
    v.extract    s3, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s13, #6
    v.splat      v4, s3
    a.vread      v8, a2, s13
    v.extract    s3, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s13, #7
    v.splat      v6, s3
    a.vread      v7, a2, s13
    v.extract    s3, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s13, #8
    v.splat      v3, s3
    a.vread      v5, a2, s13
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s3, #0
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #9
    s.movz       s14, #9
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v9, v6, v7, v10
    v.extract    s13, v1, #10
    s.movz       s14, #10
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v10, v3, v5, v9
    v.extract    s13, v1, #11
    s.movz       s14, #11
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v9, v4, v8, v10
    v.extract    s13, v1, #12
    s.movz       s14, #12
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v10, v6, v7, v9
    v.extract    s13, v1, #13
    s.movz       s14, #13
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v9, v3, v5, v10
    v.extract    s13, v1, #14
    s.movz       s14, #14
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #15
    s.movz       s14, #15
    v.splat      v1, s13
    a.vread      v4, a2, s14
    vf.fma       v8, v6, v7, v10
    s.movz       s13, #1
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s19, #4
    s.movz       s20, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s3, v3
    a.vread      v1, a1, s13
    a.vread      v3, a2, s14
    a.vread      v4, a2, s15
    v.extract    s3, v1, #0
    v.extract    s13, v1, #1
    v.splat      v5, s3
    v.splat      v6, s13
    v.extract    s3, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s3
    a.vread      v5, a2, s16
    v.extract    s3, v1, #3
    a.vread      v8, a2, s17
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s3
    v.extract    s3, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s3
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v1, #5
    a.vread      v3, a2, s20
    v.splat      v5, s3
    v.extract    s3, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s13, #6
    v.splat      v4, s3
    a.vread      v8, a2, s13
    v.extract    s3, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s13, #7
    v.splat      v6, s3
    a.vread      v7, a2, s13
    v.extract    s3, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s13, #8
    v.splat      v3, s3
    a.vread      v5, a2, s13
    s.movz       s3, #1
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #9
    s.movz       s14, #9
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v9, v6, v7, v10
    v.extract    s13, v1, #10
    s.movz       s14, #10
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v10, v3, v5, v9
    v.extract    s13, v1, #11
    s.movz       s14, #11
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v9, v4, v8, v10
    v.extract    s13, v1, #12
    s.movz       s14, #12
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v10, v6, v7, v9
    v.extract    s13, v1, #13
    s.movz       s14, #13
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v9, v3, v5, v10
    v.extract    s13, v1, #14
    s.movz       s14, #14
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #15
    s.movz       s14, #15
    v.splat      v1, s13
    a.vread      v4, a2, s14
    vf.fma       v8, v6, v7, v10
    s.movz       s13, #2
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s19, #4
    s.movz       s20, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s3, v3
    a.vread      v1, a1, s13
    a.vread      v3, a2, s14
    a.vread      v4, a2, s15
    v.extract    s3, v1, #0
    v.extract    s13, v1, #1
    v.splat      v5, s3
    v.splat      v6, s13
    v.extract    s3, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s3
    a.vread      v5, a2, s16
    v.extract    s3, v1, #3
    a.vread      v8, a2, s17
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s3
    v.extract    s3, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s3
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v1, #5
    a.vread      v3, a2, s20
    v.splat      v5, s3
    v.extract    s3, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s13, #6
    v.splat      v4, s3
    a.vread      v8, a2, s13
    v.extract    s3, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s13, #7
    v.splat      v6, s3
    a.vread      v7, a2, s13
    v.extract    s3, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s13, #8
    v.splat      v3, s3
    a.vread      v5, a2, s13
    s.movz       s3, #2
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #9
    s.movz       s14, #9
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v9, v6, v7, v10
    v.extract    s13, v1, #10
    s.movz       s14, #10
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v10, v3, v5, v9
    v.extract    s13, v1, #11
    s.movz       s14, #11
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v9, v4, v8, v10
    v.extract    s13, v1, #12
    s.movz       s14, #12
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v10, v6, v7, v9
    v.extract    s13, v1, #13
    s.movz       s14, #13
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v9, v3, v5, v10
    v.extract    s13, v1, #14
    s.movz       s14, #14
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #15
    s.movz       s14, #15
    v.splat      v1, s13
    a.vread      v4, a2, s14
    vf.fma       v8, v6, v7, v10
    s.movz       s13, #3
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s19, #4
    s.movz       s20, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s3, v3
    a.vread      v1, a1, s13
    a.vread      v3, a2, s14
    a.vread      v4, a2, s15
    v.extract    s3, v1, #0
    v.extract    s13, v1, #1
    v.splat      v5, s3
    v.splat      v6, s13
    v.extract    s3, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s3
    a.vread      v5, a2, s16
    v.extract    s3, v1, #3
    a.vread      v8, a2, s17
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s3
    v.extract    s3, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s3
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v1, #5
    a.vread      v3, a2, s20
    v.splat      v5, s3
    v.extract    s3, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s13, #6
    v.splat      v4, s3
    a.vread      v8, a2, s13
    v.extract    s3, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s13, #7
    v.splat      v6, s3
    a.vread      v7, a2, s13
    v.extract    s3, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s13, #8
    v.splat      v3, s3
    a.vread      v5, a2, s13
    s.movz       s3, #3
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #9
    s.movz       s14, #9
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v9, v6, v7, v10
    v.extract    s13, v1, #10
    s.movz       s14, #10
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v10, v3, v5, v9
    v.extract    s13, v1, #11
    s.movz       s14, #11
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v9, v4, v8, v10
    v.extract    s13, v1, #12
    s.movz       s14, #12
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v10, v6, v7, v9
    v.extract    s13, v1, #13
    s.movz       s14, #13
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v9, v3, v5, v10
    v.extract    s13, v1, #14
    s.movz       s14, #14
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #15
    s.movz       s14, #15
    v.splat      v1, s13
    a.vread      v4, a2, s14
    vf.fma       v8, v6, v7, v10
    s.movz       s13, #4
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s19, #4
    s.movz       s20, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s3, v3
    a.vread      v1, a1, s13
    a.vread      v3, a2, s14
    a.vread      v4, a2, s15
    v.extract    s3, v1, #0
    v.extract    s13, v1, #1
    v.splat      v5, s3
    v.splat      v6, s13
    v.extract    s3, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s3
    a.vread      v5, a2, s16
    v.extract    s3, v1, #3
    a.vread      v8, a2, s17
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s3
    v.extract    s3, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s3
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v1, #5
    a.vread      v3, a2, s20
    v.splat      v5, s3
    v.extract    s3, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s13, #6
    v.splat      v4, s3
    a.vread      v8, a2, s13
    v.extract    s3, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s13, #7
    v.splat      v6, s3
    a.vread      v7, a2, s13
    v.extract    s3, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s13, #8
    v.splat      v3, s3
    a.vread      v5, a2, s13
    s.movz       s3, #4
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #9
    s.movz       s14, #9
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v9, v6, v7, v10
    v.extract    s13, v1, #10
    s.movz       s14, #10
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v10, v3, v5, v9
    v.extract    s13, v1, #11
    s.movz       s14, #11
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v9, v4, v8, v10
    v.extract    s13, v1, #12
    s.movz       s14, #12
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v10, v6, v7, v9
    v.extract    s13, v1, #13
    s.movz       s14, #13
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v9, v3, v5, v10
    v.extract    s13, v1, #14
    s.movz       s14, #14
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #15
    s.movz       s14, #15
    v.splat      v1, s13
    a.vread      v4, a2, s14
    vf.fma       v8, v6, v7, v10
    s.movz       s13, #5
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s19, #4
    s.movz       s20, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s3, v3
    a.vread      v1, a1, s13
    a.vread      v3, a2, s14
    a.vread      v4, a2, s15
    v.extract    s3, v1, #0
    v.extract    s13, v1, #1
    v.splat      v5, s3
    v.splat      v6, s13
    v.extract    s3, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s3
    a.vread      v5, a2, s16
    v.extract    s3, v1, #3
    a.vread      v8, a2, s17
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s3
    v.extract    s3, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s3
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v1, #5
    a.vread      v3, a2, s20
    v.splat      v5, s3
    v.extract    s3, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s13, #6
    v.splat      v4, s3
    a.vread      v8, a2, s13
    v.extract    s3, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s13, #7
    v.splat      v6, s3
    a.vread      v7, a2, s13
    v.extract    s3, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s13, #8
    v.splat      v3, s3
    a.vread      v5, a2, s13
    s.movz       s3, #5
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #9
    s.movz       s14, #9
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v9, v6, v7, v10
    v.extract    s13, v1, #10
    s.movz       s14, #10
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v10, v3, v5, v9
    v.extract    s13, v1, #11
    s.movz       s14, #11
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v9, v4, v8, v10
    v.extract    s13, v1, #12
    s.movz       s14, #12
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v10, v6, v7, v9
    v.extract    s13, v1, #13
    s.movz       s14, #13
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v9, v3, v5, v10
    v.extract    s13, v1, #14
    s.movz       s14, #14
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #15
    s.movz       s14, #15
    v.splat      v1, s13
    a.vread      v4, a2, s14
    vf.fma       v8, v6, v7, v10
    s.movz       s13, #6
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s19, #4
    s.movz       s20, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s3, v3
    a.vread      v1, a1, s13
    a.vread      v3, a2, s14
    a.vread      v4, a2, s15
    v.extract    s3, v1, #0
    v.extract    s13, v1, #1
    v.splat      v5, s3
    v.splat      v6, s13
    v.extract    s3, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s3
    a.vread      v5, a2, s16
    v.extract    s3, v1, #3
    a.vread      v8, a2, s17
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s3
    v.extract    s3, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s3
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v1, #5
    a.vread      v3, a2, s20
    v.splat      v5, s3
    v.extract    s3, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s13, #6
    v.splat      v4, s3
    a.vread      v8, a2, s13
    v.extract    s3, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s13, #7
    v.splat      v6, s3
    a.vread      v7, a2, s13
    v.extract    s3, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s13, #8
    v.splat      v3, s3
    a.vread      v5, a2, s13
    s.movz       s3, #6
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #9
    s.movz       s14, #9
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v9, v6, v7, v10
    v.extract    s13, v1, #10
    s.movz       s14, #10
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v10, v3, v5, v9
    v.extract    s13, v1, #11
    s.movz       s14, #11
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v9, v4, v8, v10
    v.extract    s13, v1, #12
    s.movz       s14, #12
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v10, v6, v7, v9
    v.extract    s13, v1, #13
    s.movz       s14, #13
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v9, v3, v5, v10
    v.extract    s13, v1, #14
    s.movz       s14, #14
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #15
    s.movz       s14, #15
    v.splat      v1, s13
    a.vread      v4, a2, s14
    vf.fma       v8, v6, v7, v10
    s.movz       s13, #7
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s19, #4
    s.movz       s20, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s3, v3
    a.vread      v1, a1, s13
    a.vread      v3, a2, s14
    a.vread      v4, a2, s15
    v.extract    s3, v1, #0
    v.extract    s13, v1, #1
    v.splat      v5, s3
    v.splat      v6, s13
    v.extract    s3, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s3
    a.vread      v5, a2, s16
    v.extract    s3, v1, #3
    a.vread      v8, a2, s17
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s3
    v.extract    s3, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s3
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v1, #5
    a.vread      v3, a2, s20
    v.splat      v5, s3
    v.extract    s3, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s13, #6
    v.splat      v4, s3
    a.vread      v8, a2, s13
    v.extract    s3, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s13, #7
    v.splat      v6, s3
    a.vread      v7, a2, s13
    v.extract    s3, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s13, #8
    v.splat      v3, s3
    a.vread      v5, a2, s13
    s.movz       s3, #7
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #9
    s.movz       s14, #9
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v9, v6, v7, v10
    v.extract    s13, v1, #10
    s.movz       s14, #10
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v10, v3, v5, v9
    v.extract    s13, v1, #11
    s.movz       s14, #11
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v9, v4, v8, v10
    v.extract    s13, v1, #12
    s.movz       s14, #12
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v10, v6, v7, v9
    v.extract    s13, v1, #13
    s.movz       s14, #13
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v9, v3, v5, v10
    v.extract    s13, v1, #14
    s.movz       s14, #14
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #15
    s.movz       s14, #15
    v.splat      v1, s13
    a.vread      v4, a2, s14
    vf.fma       v8, v6, v7, v10
    s.movz       s13, #8
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s19, #4
    s.movz       s20, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s3, v3
    a.vread      v1, a1, s13
    a.vread      v3, a2, s14
    a.vread      v4, a2, s15
    v.extract    s3, v1, #0
    v.extract    s13, v1, #1
    v.splat      v5, s3
    v.splat      v6, s13
    v.extract    s3, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s3
    a.vread      v5, a2, s16
    v.extract    s3, v1, #3
    a.vread      v8, a2, s17
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s3
    v.extract    s3, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s3
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v1, #5
    a.vread      v3, a2, s20
    v.splat      v5, s3
    v.extract    s3, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s13, #6
    v.splat      v4, s3
    a.vread      v8, a2, s13
    v.extract    s3, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s13, #7
    v.splat      v6, s3
    a.vread      v7, a2, s13
    v.extract    s3, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s13, #8
    v.splat      v3, s3
    a.vread      v5, a2, s13
    s.movz       s3, #8
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #9
    s.movz       s14, #9
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v9, v6, v7, v10
    v.extract    s13, v1, #10
    s.movz       s14, #10
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v10, v3, v5, v9
    v.extract    s13, v1, #11
    s.movz       s14, #11
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v9, v4, v8, v10
    v.extract    s13, v1, #12
    s.movz       s14, #12
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v10, v6, v7, v9
    v.extract    s13, v1, #13
    s.movz       s14, #13
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v9, v3, v5, v10
    v.extract    s13, v1, #14
    s.movz       s14, #14
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #15
    s.movz       s14, #15
    v.splat      v1, s13
    a.vread      v4, a2, s14
    vf.fma       v8, v6, v7, v10
    s.movz       s13, #9
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s19, #4
    s.movz       s20, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s3, v3
    a.vread      v1, a1, s13
    a.vread      v3, a2, s14
    a.vread      v4, a2, s15
    v.extract    s3, v1, #0
    v.extract    s13, v1, #1
    v.splat      v5, s3
    v.splat      v6, s13
    v.extract    s3, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s3
    a.vread      v5, a2, s16
    v.extract    s3, v1, #3
    a.vread      v8, a2, s17
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s3
    v.extract    s3, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s3
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v1, #5
    a.vread      v3, a2, s20
    v.splat      v5, s3
    v.extract    s3, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s13, #6
    v.splat      v4, s3
    a.vread      v8, a2, s13
    v.extract    s3, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s13, #7
    v.splat      v6, s3
    a.vread      v7, a2, s13
    v.extract    s3, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s13, #8
    v.splat      v3, s3
    a.vread      v5, a2, s13
    s.movz       s3, #9
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #9
    s.movz       s14, #9
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v9, v6, v7, v10
    v.extract    s13, v1, #10
    s.movz       s14, #10
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v10, v3, v5, v9
    v.extract    s13, v1, #11
    s.movz       s14, #11
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v9, v4, v8, v10
    v.extract    s13, v1, #12
    s.movz       s14, #12
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v10, v6, v7, v9
    v.extract    s13, v1, #13
    s.movz       s14, #13
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v9, v3, v5, v10
    v.extract    s13, v1, #14
    s.movz       s14, #14
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #15
    s.movz       s14, #15
    v.splat      v1, s13
    a.vread      v4, a2, s14
    vf.fma       v8, v6, v7, v10
    s.movz       s13, #10
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s19, #4
    s.movz       s20, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s3, v3
    a.vread      v1, a1, s13
    a.vread      v3, a2, s14
    a.vread      v4, a2, s15
    v.extract    s3, v1, #0
    v.extract    s13, v1, #1
    v.splat      v5, s3
    v.splat      v6, s13
    v.extract    s3, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s3
    a.vread      v5, a2, s16
    v.extract    s3, v1, #3
    a.vread      v8, a2, s17
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s3
    v.extract    s3, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s3
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v1, #5
    a.vread      v3, a2, s20
    v.splat      v5, s3
    v.extract    s3, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s13, #6
    v.splat      v4, s3
    a.vread      v8, a2, s13
    v.extract    s3, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s13, #7
    v.splat      v6, s3
    a.vread      v7, a2, s13
    v.extract    s3, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s13, #8
    v.splat      v3, s3
    a.vread      v5, a2, s13
    s.movz       s3, #10
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #9
    s.movz       s14, #9
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v9, v6, v7, v10
    v.extract    s13, v1, #10
    s.movz       s14, #10
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v10, v3, v5, v9
    v.extract    s13, v1, #11
    s.movz       s14, #11
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v9, v4, v8, v10
    v.extract    s13, v1, #12
    s.movz       s14, #12
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v10, v6, v7, v9
    v.extract    s13, v1, #13
    s.movz       s14, #13
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v9, v3, v5, v10
    v.extract    s13, v1, #14
    s.movz       s14, #14
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #15
    s.movz       s14, #15
    v.splat      v1, s13
    a.vread      v4, a2, s14
    vf.fma       v8, v6, v7, v10
    s.movz       s13, #11
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s19, #4
    s.movz       s20, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s3, v3
    a.vread      v1, a1, s13
    a.vread      v3, a2, s14
    a.vread      v4, a2, s15
    v.extract    s3, v1, #0
    v.extract    s13, v1, #1
    v.splat      v5, s3
    v.splat      v6, s13
    v.extract    s3, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s3
    a.vread      v5, a2, s16
    v.extract    s3, v1, #3
    a.vread      v8, a2, s17
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s3
    v.extract    s3, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s3
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v1, #5
    a.vread      v3, a2, s20
    v.splat      v5, s3
    v.extract    s3, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s13, #6
    v.splat      v4, s3
    a.vread      v8, a2, s13
    v.extract    s3, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s13, #7
    v.splat      v6, s3
    a.vread      v7, a2, s13
    v.extract    s3, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s13, #8
    v.splat      v3, s3
    a.vread      v5, a2, s13
    s.movz       s3, #11
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #9
    s.movz       s14, #9
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v9, v6, v7, v10
    v.extract    s13, v1, #10
    s.movz       s14, #10
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v10, v3, v5, v9
    v.extract    s13, v1, #11
    s.movz       s14, #11
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v9, v4, v8, v10
    v.extract    s13, v1, #12
    s.movz       s14, #12
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v10, v6, v7, v9
    v.extract    s13, v1, #13
    s.movz       s14, #13
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v9, v3, v5, v10
    v.extract    s13, v1, #14
    s.movz       s14, #14
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #15
    s.movz       s14, #15
    v.splat      v1, s13
    a.vread      v4, a2, s14
    vf.fma       v8, v6, v7, v10
    s.movz       s13, #12
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s19, #4
    s.movz       s20, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s3, v3
    a.vread      v1, a1, s13
    a.vread      v3, a2, s14
    a.vread      v4, a2, s15
    v.extract    s3, v1, #0
    v.extract    s13, v1, #1
    v.splat      v5, s3
    v.splat      v6, s13
    v.extract    s3, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s3
    a.vread      v5, a2, s16
    v.extract    s3, v1, #3
    a.vread      v8, a2, s17
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s3
    v.extract    s3, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s3
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v1, #5
    a.vread      v3, a2, s20
    v.splat      v5, s3
    v.extract    s3, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s13, #6
    v.splat      v4, s3
    a.vread      v8, a2, s13
    v.extract    s3, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s13, #7
    v.splat      v6, s3
    a.vread      v7, a2, s13
    v.extract    s3, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s13, #8
    v.splat      v3, s3
    a.vread      v5, a2, s13
    s.movz       s3, #12
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #9
    s.movz       s14, #9
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v9, v6, v7, v10
    v.extract    s13, v1, #10
    s.movz       s14, #10
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v10, v3, v5, v9
    v.extract    s13, v1, #11
    s.movz       s14, #11
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v9, v4, v8, v10
    v.extract    s13, v1, #12
    s.movz       s14, #12
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v10, v6, v7, v9
    v.extract    s13, v1, #13
    s.movz       s14, #13
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v9, v3, v5, v10
    v.extract    s13, v1, #14
    s.movz       s14, #14
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #15
    s.movz       s14, #15
    v.splat      v1, s13
    a.vread      v4, a2, s14
    vf.fma       v8, v6, v7, v10
    s.movz       s13, #13
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s19, #4
    s.movz       s20, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s3, v3
    a.vread      v1, a1, s13
    a.vread      v3, a2, s14
    a.vread      v4, a2, s15
    v.extract    s3, v1, #0
    v.extract    s13, v1, #1
    v.splat      v5, s3
    v.splat      v6, s13
    v.extract    s3, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s3
    a.vread      v5, a2, s16
    v.extract    s3, v1, #3
    a.vread      v8, a2, s17
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s3
    v.extract    s3, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s3
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v1, #5
    a.vread      v3, a2, s20
    v.splat      v5, s3
    v.extract    s3, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s13, #6
    v.splat      v4, s3
    a.vread      v8, a2, s13
    v.extract    s3, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s13, #7
    v.splat      v6, s3
    a.vread      v7, a2, s13
    v.extract    s3, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s13, #8
    v.splat      v3, s3
    a.vread      v5, a2, s13
    s.movz       s3, #13
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #9
    s.movz       s14, #9
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v9, v6, v7, v10
    v.extract    s13, v1, #10
    s.movz       s14, #10
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v10, v3, v5, v9
    v.extract    s13, v1, #11
    s.movz       s14, #11
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v9, v4, v8, v10
    v.extract    s13, v1, #12
    s.movz       s14, #12
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v10, v6, v7, v9
    v.extract    s13, v1, #13
    s.movz       s14, #13
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v9, v3, v5, v10
    v.extract    s13, v1, #14
    s.movz       s14, #14
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #15
    s.movz       s14, #15
    v.splat      v1, s13
    a.vread      v4, a2, s14
    vf.fma       v8, v6, v7, v10
    s.movz       s13, #14
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s19, #4
    s.movz       s20, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s3, v3
    a.vread      v1, a1, s13
    a.vread      v3, a2, s14
    a.vread      v4, a2, s15
    v.extract    s3, v1, #0
    v.extract    s13, v1, #1
    v.splat      v5, s3
    v.splat      v6, s13
    v.extract    s3, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s3
    a.vread      v5, a2, s16
    v.extract    s3, v1, #3
    a.vread      v8, a2, s17
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s3
    v.extract    s3, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s3
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v1, #5
    a.vread      v3, a2, s20
    v.splat      v5, s3
    v.extract    s3, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s13, #6
    v.splat      v4, s3
    a.vread      v8, a2, s13
    v.extract    s3, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s13, #7
    v.splat      v6, s3
    a.vread      v7, a2, s13
    v.extract    s3, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s13, #8
    v.splat      v3, s3
    a.vread      v5, a2, s13
    s.movz       s3, #14
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #9
    s.movz       s14, #9
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v9, v6, v7, v10
    v.extract    s13, v1, #10
    s.movz       s14, #10
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v10, v3, v5, v9
    v.extract    s13, v1, #11
    s.movz       s14, #11
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v9, v4, v8, v10
    v.extract    s13, v1, #12
    s.movz       s14, #12
    v.splat      v4, s13
    a.vread      v8, a2, s14
    vf.fma       v10, v6, v7, v9
    v.extract    s13, v1, #13
    s.movz       s14, #13
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v9, v3, v5, v10
    v.extract    s13, v1, #14
    s.movz       s14, #14
    v.splat      v3, s13
    a.vread      v5, a2, s14
    vf.fma       v10, v4, v8, v9
    v.extract    s13, v1, #15
    s.movz       s14, #15
    v.splat      v1, s13
    a.vread      v4, a2, s14
    vf.fma       v8, v6, v7, v10
    s.movz       s13, #15
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s19, #4
    s.movz       s20, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s3, v3
    a.vread      v1, a1, s13
    a.vread      v3, a2, s14
    a.vread      v4, a2, s15
    v.extract    s3, v1, #0
    v.extract    s13, v1, #1
    v.splat      v5, s3
    v.splat      v6, s13
    v.extract    s3, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v2, s3
    a.vread      v3, a2, s16
    v.extract    s3, v1, #3
    a.vread      v5, a2, s17
    vf.fma       v8, v6, v4, v7
    v.splat      v4, s3
    v.extract    s3, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s3
    vf.fma       v9, v2, v3, v8
    v.extract    s3, v1, #5
    a.vread      v2, a2, s20
    v.splat      v3, s3
    v.extract    s3, v1, #6
    vf.fma       v8, v4, v5, v9
    s.movz       s13, #6
    v.splat      v4, s3
    a.vread      v5, a2, s13
    v.extract    s3, v1, #7
    vf.fma       v9, v7, v6, v8
    s.movz       s13, #7
    v.splat      v6, s3
    a.vread      v7, a2, s13
    v.extract    s3, v1, #8
    vf.fma       v8, v3, v2, v9
    s.movz       s13, #8
    v.splat      v2, s3
    a.vread      v3, a2, s13
    s.movz       s3, #15
    vf.fma       v9, v4, v5, v8
    v.extract    s13, v1, #9
    s.movz       s14, #9
    v.splat      v4, s13
    a.vread      v5, a2, s14
    vf.fma       v8, v6, v7, v9
    v.extract    s13, v1, #10
    s.movz       s14, #10
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v9, v2, v3, v8
    v.extract    s13, v1, #11
    s.movz       s14, #11
    v.splat      v2, s13
    a.vread      v3, a2, s14
    vf.fma       v8, v4, v5, v9
    v.extract    s13, v1, #12
    s.movz       s14, #12
    v.splat      v4, s13
    a.vread      v5, a2, s14
    vf.fma       v9, v6, v7, v8
    v.extract    s13, v1, #13
    s.movz       s14, #13
    v.splat      v6, s13
    a.vread      v7, a2, s14
    vf.fma       v8, v2, v3, v9
    v.extract    s13, v1, #14
    s.movz       s14, #14
    v.splat      v2, s13
    a.vread      v3, a2, s14
    vf.fma       v9, v4, v5, v8
    v.extract    s13, v1, #15
    s.movz       s14, #15
    v.splat      v1, s13
    a.vread      v4, a2, s14
    vf.fma       v5, v6, v7, v9
    s.addi       s13, s9, #2048
    v.splat      v6, s1
    s.addi       s14, s9, #4096
    s.addi       s15, s9, #2112
    vf.fma       v7, v2, v3, v5
    s.addi       s16, s14, #64
    s.addi       s17, s9, #2176
    s.addi       s19, s14, #128
    s.addi       s20, s9, #2240
    vf.fma       v2, v1, v4, v7
    a.vwrite     a3, s3, v2
    v.ld.w       v1, [s13, #0]
    s.addi       s3, s14, #192
    s.addi       s13, s9, #2304
    v.add        v2, v1, v6
    v.st.w       [s14, #0], v2
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s14, #256
    v.add        v2, v1, v6
    v.st.w       [s16, #0], v2
    s.addi       s16, s9, #2368
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s14, #320
    v.add        v2, v1, v6
    v.st.w       [s19, #0], v2
    s.addi       s19, s9, #2432
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s14, #384
    v.add        v2, v1, v6
    v.st.w       [s3, #0], v2
    s.addi       s3, s9, #2496
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s14, #448
    v.add        v2, v1, v6
    v.st.w       [s15, #0], v2
    s.addi       s15, s9, #2560
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s14, #512
    v.add        v2, v1, v6
    v.st.w       [s17, #0], v2
    s.addi       s17, s9, #2624
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s14, #576
    v.add        v2, v1, v6
    v.st.w       [s20, #0], v2
    s.addi       s20, s9, #2688
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s14, #640
    v.add        v2, v1, v6
    v.st.w       [s13, #0], v2
    s.addi       s13, s9, #2752
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s14, #704
    v.add        v2, v1, v6
    v.st.w       [s16, #0], v2
    s.addi       s16, s9, #2816
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s14, #768
    v.add        v2, v1, v6
    v.st.w       [s19, #0], v2
    s.addi       s19, s9, #2880
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s14, #832
    v.add        v2, v1, v6
    v.st.w       [s3, #0], v2
    s.addi       s3, s9, #2944
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s14, #896
    s.addi       s21, s14, #960
    v.add        v2, v1, v6
    v.st.w       [s15, #0], v2
    s.addi       s14, s9, #3008
    v.ld.w       v1, [s16, #0]
    s.addi       s15, s9, #3072
    v.add        v2, v1, v6
    v.st.w       [s17, #0], v2
    s.movz       s16, #80
    v.splat      v1, s16
    s.addi       s16, s9, #5120
    v.ld.w       v2, [s19, #0]
    s.addi       s17, s9, #3136
    v.add        v3, v2, v6
    v.st.w       [s20, #0], v3
    s.addi       s19, s16, #64
    v.ld.w       v2, [s3, #0]
    s.addi       s3, s9, #3200
    v.add        v3, v2, v6
    v.st.w       [s13, #0], v3
    s.addi       s13, s16, #128
    v.ld.w       v2, [s14, #0]
    s.addi       s14, s9, #3264
    v.add        v3, v2, v6
    v.st.w       [s21, #0], v3
    fence.acq_rel.device
    s.addi       s20, s16, #192
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s9, #3328
    v.add        v3, v2, v1
    v.st.w       [s16, #0], v3
    v.ld.w       v2, [s17, #0]
    s.addi       s17, s16, #256
    v.add        v3, v2, v1
    v.st.w       [s19, #0], v3
    s.addi       s19, s9, #3392
    v.ld.w       v2, [s3, #0]
    s.addi       s3, s16, #320
    v.add        v3, v2, v1
    v.st.w       [s13, #0], v3
    s.addi       s13, s9, #3456
    v.ld.w       v2, [s14, #0]
    s.addi       s14, s16, #384
    v.add        v3, v2, v1
    v.st.w       [s20, #0], v3
    s.addi       s20, s9, #3520
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s16, #448
    v.add        v3, v2, v1
    v.st.w       [s17, #0], v3
    s.addi       s17, s9, #3584
    v.ld.w       v2, [s19, #0]
    s.addi       s19, s16, #512
    v.add        v3, v2, v1
    v.st.w       [s3, #0], v3
    s.addi       s3, s9, #3648
    v.ld.w       v2, [s13, #0]
    s.addi       s13, s16, #576
    v.add        v3, v2, v1
    v.st.w       [s14, #0], v3
    s.addi       s14, s9, #3712
    v.ld.w       v2, [s20, #0]
    s.addi       s20, s16, #640
    v.add        v3, v2, v1
    v.st.w       [s15, #0], v3
    s.addi       s15, s9, #3776
    v.ld.w       v2, [s17, #0]
    s.addi       s17, s16, #704
    v.add        v3, v2, v1
    v.st.w       [s19, #0], v3
    s.addi       s19, s9, #3840
    v.ld.w       v2, [s3, #0]
    s.addi       s3, s16, #768
    v.add        v3, v2, v1
    v.st.w       [s13, #0], v3
    s.addi       s13, s9, #3904
    v.ld.w       v2, [s14, #0]
    s.addi       s14, s16, #832
    v.add        v3, v2, v1
    v.st.w       [s20, #0], v3
    s.addi       s20, s9, #3968
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s16, #896
    s.addi       s21, s16, #960
    v.add        v3, v2, v1
    v.st.w       [s17, #0], v3
    s.addi       s16, s9, #4032
    v.ld.w       v2, [s19, #0]
    s.addi       s17, s9, #4096
    v.add        v3, v2, v1
    v.st.w       [s3, #0], v3
    s.addi       s3, s9, #6144
    v.ld.w       v2, [s13, #0]
    s.addi       s13, s9, #4160
    v.add        v3, v2, v1
    v.st.w       [s14, #0], v3
    s.addi       s14, s3, #64
    v.ld.w       v2, [s20, #0]
    s.addi       s19, s9, #4224
    v.add        v3, v2, v1
    v.st.w       [s15, #0], v3
    s.addi       s15, s3, #128
    v.ld.w       v2, [s16, #0]
    s.addi       s16, s9, #4288
    v.add        v3, v2, v1
    v.st.w       [s21, #0], v3
    fence.acq_rel.device
    s.addi       s20, s3, #192
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s9, #4352
    v.st.w       [s3, #0], v1
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s3, #256
    v.st.w       [s14, #0], v1
    s.addi       s14, s9, #4416
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s3, #320
    v.st.w       [s15, #0], v1
    s.addi       s15, s9, #4480
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s3, #384
    v.st.w       [s20, #0], v1
    s.addi       s20, s9, #4544
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s3, #448
    v.st.w       [s13, #0], v1
    s.addi       s13, s9, #4608
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s3, #512
    v.st.w       [s19, #0], v1
    s.addi       s19, s9, #4672
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s3, #576
    v.st.w       [s16, #0], v1
    s.addi       s16, s9, #4736
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s3, #640
    v.st.w       [s17, #0], v1
    s.addi       s17, s9, #4800
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s3, #704
    v.st.w       [s14, #0], v1
    s.addi       s14, s9, #4864
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s3, #768
    v.st.w       [s15, #0], v1
    s.addi       s15, s9, #4928
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s3, #832
    v.st.w       [s20, #0], v1
    s.addi       s20, s9, #4992
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s3, #896
    s.addi       s21, s3, #960
    v.st.w       [s13, #0], v1
    s.addi       s3, s9, #5056
    v.ld.w       v1, [s14, #0]
    s.addi       s13, s9, #5120
    v.st.w       [s19, #0], v1
    s.addi       s14, s9, #7168
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s9, #5184
    v.st.w       [s16, #0], v1
    s.addi       s16, s14, #64
    v.ld.w       v1, [s20, #0]
    s.addi       s19, s9, #5248
    v.st.w       [s17, #0], v1
    s.addi       s17, s14, #128
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s9, #5312
    v.st.w       [s21, #0], v1
    fence.acq_rel.device
    s.addi       s20, s14, #192
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s9, #5376
    v.st.w       [s14, #0], v1
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s14, #256
    v.st.w       [s16, #0], v1
    s.addi       s16, s9, #5440
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s14, #320
    v.st.w       [s17, #0], v1
    s.addi       s17, s9, #5504
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s14, #384
    v.st.w       [s20, #0], v1
    s.addi       s20, s9, #5568
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s14, #448
    v.st.w       [s15, #0], v1
    s.addi       s15, s9, #5632
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s14, #512
    v.st.w       [s19, #0], v1
    s.addi       s19, s9, #5696
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s14, #576
    v.st.w       [s3, #0], v1
    s.addi       s3, s9, #5760
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s14, #640
    v.st.w       [s13, #0], v1
    s.addi       s13, s9, #5824
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s14, #704
    v.st.w       [s16, #0], v1
    s.addi       s16, s9, #5888
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s14, #768
    v.st.w       [s17, #0], v1
    s.addi       s17, s9, #5952
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s14, #832
    v.st.w       [s20, #0], v1
    s.addi       s20, s9, #6016
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s14, #896
    s.addi       s21, s14, #960
    v.st.w       [s15, #0], v1
    s.addi       s14, s9, #6080
    v.ld.w       v1, [s16, #0]
    s.movz       s15, #0
    v.st.w       [s19, #0], v1
    s.movz       s16, #0
    v.ld.w       v1, [s17, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s17, #0
    v.st.w       [s3, #0], v1
    s.movz       s3, #1
    v.ld.w       v1, [s20, #0]
    s.movz       s19, #1
    v.st.w       [s13, #0], v1
    s.movz       s13, #1
    v.ld.w       v1, [s14, #0]
    s.movz       s14, #2
    v.st.w       [s21, #0], v1
    fence.acq_rel.device
    a.vread      v1, a0, s15
    a.vread      v2, a3, s16
    s.movz       s15, #2
    s.movz       s16, #2
    vf.add       v3, v1, v2
    s.movz       s20, #3
    a.vwrite     a4, s17, v3
    a.vread      v1, a0, s3
    a.vread      v2, a3, s19
    s.movz       s3, #3
    s.movz       s17, #3
    vf.add       v3, v1, v2
    s.movz       s19, #4
    a.vwrite     a4, s13, v3
    a.vread      v1, a0, s14
    a.vread      v2, a3, s15
    s.movz       s13, #4
    s.movz       s14, #4
    vf.add       v3, v1, v2
    s.movz       s15, #5
    a.vwrite     a4, s16, v3
    a.vread      v1, a0, s20
    a.vread      v2, a3, s3
    s.movz       s3, #5
    s.movz       s16, #5
    vf.add       v3, v1, v2
    s.movz       s20, #6
    a.vwrite     a4, s17, v3
    a.vread      v1, a0, s19
    a.vread      v2, a3, s13
    s.movz       s13, #6
    s.movz       s17, #6
    vf.add       v3, v1, v2
    s.movz       s19, #7
    a.vwrite     a4, s14, v3
    a.vread      v1, a0, s15
    a.vread      v2, a3, s3
    s.movz       s3, #7
    s.movz       s14, #7
    vf.add       v3, v1, v2
    s.movz       s15, #8
    a.vwrite     a4, s16, v3
    a.vread      v1, a0, s20
    a.vread      v2, a3, s13
    s.movz       s13, #8
    s.movz       s16, #8
    vf.add       v3, v1, v2
    s.movz       s20, #9
    a.vwrite     a4, s17, v3
    a.vread      v1, a0, s19
    a.vread      v2, a3, s3
    s.movz       s3, #9
    s.movz       s17, #9
    vf.add       v3, v1, v2
    s.movz       s19, #10
    a.vwrite     a4, s14, v3
    a.vread      v1, a0, s15
    a.vread      v2, a3, s13
    s.movz       s13, #10
    s.movz       s14, #10
    vf.add       v3, v1, v2
    s.movz       s15, #11
    a.vwrite     a4, s16, v3
    a.vread      v1, a0, s20
    a.vread      v2, a3, s3
    s.movz       s3, #11
    s.movz       s16, #11
    vf.add       v3, v1, v2
    s.movz       s20, #12
    a.vwrite     a4, s17, v3
    a.vread      v1, a0, s19
    a.vread      v2, a3, s13
    s.movz       s13, #12
    s.movz       s17, #12
    vf.add       v3, v1, v2
    s.movz       s19, #13
    a.vwrite     a4, s14, v3
    a.vread      v1, a0, s15
    a.vread      v2, a3, s3
    s.movz       s3, #13
    s.movz       s14, #13
    vf.add       v3, v1, v2
    s.movz       s15, #14
    a.vwrite     a4, s16, v3
    a.vread      v1, a0, s20
    a.vread      v2, a3, s13
    s.movz       s13, #14
    s.movz       s16, #14
    vf.add       v3, v1, v2
    s.movz       s20, #15
    a.vwrite     a4, s17, v3
    a.vread      v1, a0, s19
    a.vread      v2, a3, s3
    s.movz       s3, #15
    s.movz       s17, #15
    vf.add       v3, v1, v2
    s.addi       s19, s9, #6144
    a.vwrite     a4, s14, v3
    a.vread      v1, a0, s15
    a.vread      v2, a3, s13
    s.addi       s13, s9, #2048
    s.addi       s14, s9, #6208
    vf.add       v3, v1, v2
    s.addi       s15, s9, #2112
    a.vwrite     a4, s16, v3
    a.vread      v1, a0, s20
    a.vread      v2, a3, s3
    s.addi       s3, s9, #6272
    s.addi       s16, s9, #2176
    vf.add       v3, v1, v2
    s.addi       s20, s9, #6336
    a.vwrite     a4, s17, v3
    v.ld.w       v1, [s19, #0]
    s.addi       s17, s9, #2240
    s.addi       s19, s9, #6400
    v.st.w       [s13, #0], v1
    s.addi       s13, s9, #2304
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s9, #6464
    v.st.w       [s15, #0], v1
    s.addi       s15, s9, #2368
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s9, #6528
    v.st.w       [s16, #0], v1
    s.addi       s16, s9, #2432
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s9, #6592
    v.st.w       [s17, #0], v1
    s.addi       s17, s9, #2496
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s9, #6656
    v.st.w       [s13, #0], v1
    s.addi       s13, s9, #2560
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s9, #6720
    v.st.w       [s15, #0], v1
    s.addi       s15, s9, #2624
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s9, #6784
    v.st.w       [s16, #0], v1
    s.addi       s16, s9, #2688
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s9, #6848
    v.st.w       [s17, #0], v1
    s.addi       s17, s9, #2752
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s9, #6912
    v.st.w       [s13, #0], v1
    s.addi       s13, s9, #2816
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s9, #6976
    v.st.w       [s15, #0], v1
    s.addi       s15, s9, #2880
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s9, #7040
    v.st.w       [s16, #0], v1
    s.addi       s16, s9, #2944
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s9, #7104
    v.st.w       [s17, #0], v1
    s.addi       s17, s9, #3008
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s9, #7168
    v.st.w       [s13, #0], v1
    s.addi       s13, s9, #3072
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s9, #7232
    v.st.w       [s15, #0], v1
    s.addi       s15, s9, #3136
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s9, #7296
    v.st.w       [s16, #0], v1
    s.addi       s16, s9, #3200
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s9, #7360
    v.st.w       [s17, #0], v1
    fence.acq_rel.device
    s.addi       s17, s9, #3264
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s9, #7424
    v.st.w       [s13, #0], v1
    s.addi       s13, s9, #3328
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s9, #7488
    v.st.w       [s15, #0], v1
    s.addi       s15, s9, #3392
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s9, #7552
    v.st.w       [s16, #0], v1
    s.addi       s16, s9, #3456
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s9, #7616
    v.st.w       [s17, #0], v1
    s.addi       s17, s9, #3520
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s9, #7680
    v.st.w       [s13, #0], v1
    s.addi       s13, s9, #3584
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s9, #7744
    v.st.w       [s15, #0], v1
    s.addi       s15, s9, #3648
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s9, #7808
    v.st.w       [s16, #0], v1
    s.addi       s16, s9, #3712
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s9, #7872
    v.st.w       [s17, #0], v1
    s.addi       s17, s9, #3776
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s9, #7936
    v.st.w       [s13, #0], v1
    s.addi       s13, s9, #3840
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s9, #8000
    v.st.w       [s15, #0], v1
    s.addi       s15, s9, #3904
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s9, #8064
    v.st.w       [s16, #0], v1
    s.addi       s16, s9, #3968
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s9, #8128
    s.addi       s21, s9, #4032
    v.st.w       [s17, #0], v1
    s.movz       s17, #0
    v.ld.w       v1, [s19, #0]
    s.movz       s19, #0
    v.st.w       [s13, #0], v1
    s.movz       s13, #1
    v.ld.w       v1, [s14, #0]
    s.movz       s14, #1
    v.st.w       [s15, #0], v1
    s.movz       s15, #2
    v.ld.w       v1, [s3, #0]
    s.movz       s3, #2
    v.st.w       [s16, #0], v1
    s.movz       s16, #3
    v.ld.w       v1, [s20, #0]
    s.movz       s20, #3
    v.st.w       [s21, #0], v1
    fence.acq_rel.device
    a.vread      v1, a4, s17
    s.movz       s17, #4
    s.movz       s21, #4
    a.vwrite     a0, s19, v1
    a.vread      v1, a4, s13
    s.movz       s13, #5
    s.movz       s19, #5
    a.vwrite     a0, s14, v1
    a.vread      v1, a4, s15
    s.movz       s14, #6
    s.movz       s15, #6
    a.vwrite     a0, s3, v1
    a.vread      v1, a4, s16
    s.movz       s3, #7
    s.movz       s16, #7
    a.vwrite     a0, s20, v1
    a.vread      v1, a4, s17
    s.movz       s17, #8
    s.movz       s20, #8
    a.vwrite     a0, s21, v1
    a.vread      v1, a4, s13
    s.movz       s13, #9
    s.movz       s21, #9
    a.vwrite     a0, s19, v1
    a.vread      v1, a4, s14
    s.movz       s14, #10
    s.movz       s19, #10
    a.vwrite     a0, s15, v1
    a.vread      v1, a4, s3
    s.movz       s3, #11
    s.movz       s15, #11
    a.vwrite     a0, s16, v1
    a.vread      v1, a4, s17
    s.movz       s16, #12
    s.movz       s17, #12
    a.vwrite     a0, s20, v1
    a.vread      v1, a4, s13
    s.movz       s13, #13
    s.movz       s20, #13
    a.vwrite     a0, s21, v1
    a.vread      v1, a4, s14
    s.movz       s14, #14
    s.movz       s21, #14
    a.vwrite     a0, s19, v1
    a.vread      v1, a4, s3
    s.movz       s3, #15
    s.movz       s19, #15
    a.vwrite     a0, s15, v1
    a.vread      v1, a4, s16
    s.add        s15, s10, s1
    s.movz       s16, #1
    a.vwrite     a0, s17, v1
    a.vread      v1, a4, s13
    a.vwrite     a0, s20, v1
    a.vread      v1, a4, s14
    a.vwrite     a0, s21, v1
    a.vread      v1, a4, s3
    a.vwrite     a0, s19, v1
    s.mov        s10, s15
    br.nz        s16, for_7
endfor_8:
    s.movz       s1, #0
    s.mul        s3, s8, s18
    s.add        s5, s1, s2                      // the tile origin
    s.movz       s1, #0
    s.muli       s6, s2, #4                      // a runtime tile origin, x4
    v.splat      v1, s5
    s.add        s2, s1, s4                      // the tile origin
    s.muli       s1, s4, #20                     // a runtime tile origin, x20
    s.movz       s4, #8
    v.splat      v2, s2
    v.splat      v3, s11
    v.add        v4, v0, v1
    v.splat      v0, s11
    s.muli       s5, s3, #4                      // a runtime tile origin, x4
    s.addi       s3, s2, #1
    v.splat      v1, s8
    v.splat      v5, s4
    s.add        s4, s12, s6                     // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s6, #0
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v4, v0
    v.splat      v0, s3
    s.add        s3, s4, s1                      // the tile origin
    p.and        p3, p1, p2
    s.addi       s1, s2, #2
    v.cmp.lt     p1, v1, v5
    a.vread      v1, a0, s6
    s.add        s4, s3, s5                      // the tile origin
    p.and        p4, p3, p1
    s.movz       s3, #1
    v.cmp.lt     p3, v0, v3
    v.splat      v0, s1
    p.and        p5, p3, p2
    s.addi       s1, s2, #3
    @p4 v.st.w       [s4, #0], v1
    a.vread      v1, a0, s3
    s.addi       s3, s4, #20                     // row 1
    p.and        p3, p5, p1
    s.movz       s5, #2
    v.cmp.lt     p4, v0, v3
    v.splat      v0, s1
    p.and        p5, p4, p2
    s.addi       s1, s2, #4
    s.addi       s6, s4, #40                     // row 2
    p.and        p4, p5, p1
    s.movz       s7, #3
    v.splat      v2, s1
    s.addi       s1, s2, #5
    s.addi       s8, s4, #60                     // row 3
    s.movz       s9, #4
    v.splat      v4, s1
    s.addi       s1, s2, #6
    @p3 v.st.w       [s3, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p3, v0, v3
    p.and        p5, p3, p2
    s.addi       s3, s4, #80                     // row 4
    p.and        p3, p5, p1
    s.movz       s5, #5
    v.splat      v0, s1
    s.addi       s1, s2, #7
    s.addi       s10, s4, #100                   // row 5
    s.movz       s11, #6
    v.splat      v5, s1
    s.addi       s1, s4, #120                    // row 6
    @p4 v.st.w       [s6, #0], v1
    a.vread      v1, a0, s7
    v.cmp.lt     p4, v2, v3
    p.and        p5, p4, p2
    s.addi       s6, s2, #8
    p.and        p4, p5, p1
    s.movz       s7, #7
    v.splat      v2, s6
    s.addi       s6, s4, #140                    // row 7
    @p3 v.st.w       [s8, #0], v1
    a.vread      v1, a0, s9
    v.cmp.lt     p3, v4, v3
    p.and        p5, p3, p2
    s.addi       s8, s2, #9
    p.and        p3, p5, p1
    s.movz       s9, #8
    v.splat      v4, s8
    s.addi       s8, s4, #160                    // row 8
    @p4 v.st.w       [s3, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p4, v0, v3
    p.and        p5, p4, p2
    s.addi       s3, s2, #10
    p.and        p4, p5, p1
    s.movz       s5, #9
    v.splat      v0, s3
    s.addi       s3, s4, #180                    // row 9
    @p3 v.st.w       [s10, #0], v1
    a.vread      v1, a0, s11
    v.cmp.lt     p3, v5, v3
    p.and        p5, p3, p2
    s.addi       s10, s2, #11
    p.and        p3, p5, p1
    s.movz       s11, #10
    v.splat      v5, s10
    s.addi       s10, s4, #200                   // row 10
    @p4 v.st.w       [s1, #0], v1
    a.vread      v1, a0, s7
    v.cmp.lt     p4, v2, v3
    p.and        p5, p4, p2
    s.addi       s1, s2, #12
    p.and        p4, p5, p1
    s.movz       s7, #11
    v.splat      v2, s1
    s.addi       s1, s4, #220                    // row 11
    @p3 v.st.w       [s6, #0], v1
    a.vread      v1, a0, s9
    v.cmp.lt     p3, v4, v3
    p.and        p5, p3, p2
    s.addi       s6, s2, #13
    p.and        p3, p5, p1
    s.movz       s9, #12
    v.splat      v4, s6
    s.addi       s6, s4, #240                    // row 12
    @p4 v.st.w       [s8, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p4, v0, v3
    p.and        p5, p4, p2
    s.addi       s5, s2, #14
    p.and        p4, p5, p1
    s.movz       s8, #13
    v.splat      v0, s5
    s.addi       s5, s4, #260                    // row 13
    @p3 v.st.w       [s3, #0], v1
    a.vread      v1, a0, s11
    v.cmp.lt     p3, v5, v3
    p.and        p5, p3, p2
    s.addi       s3, s2, #15
    p.and        p3, p5, p1
    s.movz       s2, #14
    v.splat      v5, s3
    s.addi       s3, s4, #280                    // row 14
    s.movz       s11, #15
    s.addi       s12, s4, #300                   // row 15
    @p4 v.st.w       [s10, #0], v1
    a.vread      v1, a0, s7
    v.cmp.lt     p4, v2, v3
    p.and        p5, p4, p2
    p.and        p4, p5, p1
    @p3 v.st.w       [s1, #0], v1
    a.vread      v1, a0, s9
    v.cmp.lt     p3, v4, v3
    p.and        p5, p3, p2
    p.and        p3, p5, p1
    @p4 v.st.w       [s6, #0], v1
    a.vread      v1, a0, s8
    v.cmp.lt     p4, v0, v3
    p.and        p5, p4, p2
    p.and        p4, p5, p1
    @p3 v.st.w       [s5, #0], v1
    a.vread      v0, a0, s2
    v.cmp.lt     p3, v5, v3
    p.and        p5, p3, p2
    p.and        p2, p5, p1
    @p4 v.st.w       [s3, #0], v0
    a.vread      v0, a0, s11
    @p2 v.st.w       [s12, #0], v0
__rctx_next:
    exit
