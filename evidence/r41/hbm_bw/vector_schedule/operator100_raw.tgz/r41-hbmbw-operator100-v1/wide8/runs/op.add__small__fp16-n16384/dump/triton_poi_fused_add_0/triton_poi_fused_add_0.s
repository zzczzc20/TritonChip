    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.movz       s2, #16
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s5, #32
    s.movz       s6, #48
    s.movz       s7, #64
    s.movz       s8, #80
    s.movz       s9, #96
    s.movz       s10, #112
    s.shli       s11, s4, #7                     // x128 as a shift
    v.iota       v0                              // arange(0, VLEN)
    s.add        s4, s2, s11
    s.add        s2, s5, s11
    s.ld.d       s5, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.add        s12, s6, s11
    s.add        s6, s7, s11
    v.movi       v1, #16
    v.iota       v2                              // arange(0, VLEN)
    v.movi       v3, #32
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v5, #48
    v.iota       v6                              // arange(0, VLEN)
    v.movi       v7, #64
    v.iota       v8                              // arange(0, VLEN)
    s.ld.d       s7, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.add        s1, s8, s11
    s.add        s8, s9, s11
    s.add        s9, s10, s11
    s.shli       s10, s11, #1                    // element offset -> bytes (x2)
    v.movi       v9, #80
    s.add        s13, s3, s10                    // &in_ptr0[...]
    v.iota       v10                             // arange(0, VLEN)
    v.movi       v11, #96
    v.iota       v12                             // arange(0, VLEN)
    v.movi       v13, #112
    v.ld.h       v14, [s13, #0]
    v.iota       v15                             // arange(0, VLEN)
    s.shli       s13, s4, #1                     // element offset -> bytes (x2)
    v.add        v16, v0, v1
    s.shli       s4, s2, #1                      // element offset -> bytes (x2)
    s.add        s2, s3, s13                     // &in_ptr0[...]
    s.add        s14, s3, s4                     // &in_ptr0[...]
    v.add        v0, v2, v3
    s.shli       s15, s12, #1                    // element offset -> bytes (x2)
    v.add        v1, v4, v5
    s.shli       s12, s6, #1                     // element offset -> bytes (x2)
    s.add        s6, s3, s15                     // &in_ptr0[...]
    s.add        s16, s3, s12                    // &in_ptr0[...]
    v.add        v2, v6, v7
    s.shli       s17, s1, #1                     // element offset -> bytes (x2)
    v.ld.h       v3, [s2, #0]
    s.add        s1, s3, s17                     // &in_ptr0[...]
    v.add        v4, v8, v9
    s.shli       s2, s8, #1                      // element offset -> bytes (x2)
    v.add        v5, v10, v11
    s.shli       s8, s9, #1                      // element offset -> bytes (x2)
    v.add        v6, v12, v13
    vf.cvt.f16.f32 v7, v14
    v.splat      v8, s11
    v.splat      v9, s11
    v.splat      v10, s11
    v.splat      v11, s11
    v.splat      v12, s11
    v.splat      v13, s11
    v.ld.h       v14, [s14, #0]
    s.add        s9, s3, s2                      // &in_ptr0[...]
    s.add        s14, s3, s8                     // &in_ptr0[...]
    vf.cvt.f16.f32 v17, v3
    v.splat      v3, s11
    v.splat      v18, s11
    s.add        s3, s5, s10                     // &in_ptr1[...]
    v.add        v19, v8, v15
    v.add        v8, v9, v16
    v.add        v8, v10, v0
    v.add        v0, v11, v1
    v.add        v0, v12, v2
    v.add        v0, v13, v4
    v.add        v0, v3, v5
    v.ld.h       v0, [s6, #0]
    s.add        s6, s5, s13                     // &in_ptr1[...]
    vf.cvt.f16.f32 v1, v14
    v.add        v2, v18, v6
    v.ld.h       v2, [s16, #0]
    s.add        s11, s5, s4                     // &in_ptr1[...]
    vf.cvt.f16.f32 v3, v0
    v.ld.h       v0, [s1, #0]
    s.add        s1, s5, s15                     // &in_ptr1[...]
    vf.cvt.f16.f32 v4, v2
    v.ld.h       v2, [s9, #0]
    s.add        s9, s5, s12                     // &in_ptr1[...]
    vf.cvt.f16.f32 v5, v0
    v.ld.h       v0, [s14, #0]
    s.add        s14, s5, s17                    // &in_ptr1[...]
    vf.cvt.f16.f32 v6, v2
    s.add        s16, s7, s10                    // &out_ptr0[...]
    s.add        s10, s7, s13                    // &out_ptr0[...]
    s.add        s13, s7, s4                     // &out_ptr0[...]
    s.add        s4, s7, s15                     // &out_ptr0[...]
    v.ld.h       v2, [s3, #0]
    s.add        s3, s5, s2                      // &in_ptr1[...]
    s.add        s15, s5, s8                     // &in_ptr1[...]
    vf.cvt.f16.f32 v8, v0
    s.add        s5, s7, s12                     // &out_ptr0[...]
    s.add        s12, s7, s17                    // &out_ptr0[...]
    v.ld.h       v0, [s6, #0]
    vf.cvt.f16.f32 v9, v2
    s.add        s6, s7, s2                      // &out_ptr0[...]
    vf.add       v2, v7, v9
    vf.cvt.f32.f16 v7, v2
    v.ld.h       v2, [s11, #0]
    vf.cvt.f16.f32 v9, v0
    s.add        s2, s7, s8                      // &out_ptr0[...]
    vf.add       v0, v17, v9
    vf.cvt.f32.f16 v9, v0
    v.ld.h       v0, [s1, #0]
    vf.cvt.f16.f32 v10, v2
    vf.add       v2, v1, v10
    vf.cvt.f32.f16 v1, v2
    v.ld.h       v2, [s9, #0]
    vf.cvt.f16.f32 v10, v0
    vf.add       v0, v3, v10
    vf.cvt.f32.f16 v3, v0
    v.ld.h       v0, [s14, #0]
    vf.cvt.f16.f32 v10, v2
    vf.add       v2, v4, v10
    vf.cvt.f32.f16 v4, v2
    v.ld.h       v2, [s3, #0]
    vf.cvt.f16.f32 v10, v0
    vf.add       v0, v5, v10
    vf.cvt.f32.f16 v5, v0
    v.ld.h       v0, [s15, #0]
    vf.cvt.f16.f32 v10, v2
    vf.add       v2, v6, v10
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v0
    v.st.h       [s16, #0], v7
    vf.add       v0, v8, v2
    vf.cvt.f32.f16 v2, v0
    v.st.h       [s10, #0], v9
    v.st.h       [s13, #0], v1
    v.st.h       [s4, #0], v3
    v.st.h       [s5, #0], v4
    v.st.h       [s12, #0], v5
    v.st.h       [s6, #0], v6
    v.st.h       [s2, #0], v2
__rctx_next:
    exit
