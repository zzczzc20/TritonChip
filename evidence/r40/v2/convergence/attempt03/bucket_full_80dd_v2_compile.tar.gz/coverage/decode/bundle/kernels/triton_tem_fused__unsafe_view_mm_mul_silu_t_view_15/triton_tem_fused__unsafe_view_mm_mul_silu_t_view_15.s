    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s5, [s1, #24]                   // out_ptr1: device_ptr64 at arg_base+24
    s.rdspecial  s1, arg_base
    s.ld.d       s6, [s1, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s7, #1024
    s.mul        s8, s1, s7
    s.add        s1, s6, s8                      // this context's own scratch
    s.addi       s6, s1, #0                      // TensorMap 0: a tile contiguous down its columns (built once, at entry)
    s.movz       s1, #0
    s.st.d       [s6, #0], s3
    .li       s1, #2147483647
    s.st.d       [s6, #8], s1
    .li       s1, #2147483647
    s.st.d       [s6, #16], s1
    s.movz       s1, #2048
    s.st.d       [s6, #48], s1
    s.movz       s1, #2
    s.st.d       [s6, #56], s1
    .li       s1, #68719476752
    s.st.d       [s6, #88], s1
    .li       s1, #8589934592
    s.st.d       [s6, #104], s1
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #176
    s.movz       s3, #0
    s.movz       s6, #0
    s.movz       s7, #0
    s.movz       s8, #0
    s.cmp.lt     s9, s1, s8
    s.sub        s8, s7, s9
    s.xor        s7, s1, s8
    s.sub        s9, s7, s8
    .li       s7, #1952257862
    s.movz       s9, #1
    s.movz       s10, #0
    s.movz       s11, #0
    s.movz       s12, #0
    s.movz       s13, #0
    s.movz       s14, #0
    s.movz       s15, #0
    s.movz       s16, #1
    s.rdspecial  s17, role_id
    s.rdspecial  s18, npid.x
__rctx_program:
    s.cmp.lt     s19, s17, s6
    s.cmp.lt     s20, s17, s11
    s.sub        s21, s3, s19
    s.sub        s19, s10, s20
    s.xor        s20, s17, s21
    s.xor        s22, s21, s8
    s.sub        s23, s20, s21
    s.xor        s20, s17, s19
    s.mul        s21, s23, s7
    s.sub        s24, s20, s19
    s.addi       s20, s14, #0
    s.addi       s25, s15, #0
    s.mov        s20, s24
    s.lshri      s26, s21, #32
    s.sub        s21, s23, s26
    s.lshri      s27, s21, #1
    s.add        s21, s26, s27
    s.lshri      s26, s21, #7
    s.xor        s21, s26, s22
    s.muli       s27, s26, #176
    s.sub        s26, s21, s22
    s.sub        s21, s9, s26
    s.min.s      s22, s21, s9
    s.sub        s21, s23, s27
    s.cmp.lt     s21, s22, s13
    s.sub        s23, s12, s21
    s.xor        s21, s22, s23
    s.sub        s27, s21, s23
    s.cmp.eq     s21, s27, s16
    br.nz        s21, sdiv_done_1
    s.movz       s21, #0
    s.movz       s23, #31
    s.mov        s20, s21
    s.addi       s21, s23, #0
sdiv_2:
    s.lshr       s23, s24, s21
    s.shli       s28, s25, #1
    s.andi       s29, s23, #1
    s.movz       s23, #0
    s.or         s30, s28, s29
    s.movz       s28, #1
    s.cmp.geu    s29, s30, s27
    s.shl        s31, s28, s21
    s.sub        s28, s23, s29
    s.subi       s23, s21, #1
    s.and        s29, s27, s28
    s.and        s32, s31, s28
    s.sub        s28, s30, s29
    s.or         s29, s20, s32
    s.mov        s25, s28
    s.mov        s20, s29
    s.mov        s21, s23
    s.movz       s23, #0
    s.cmp.ge     s28, s21, s23
    br.nz        s28, sdiv_2
sdiv_done_1:
    s.movz       s20, #0
    s.movz       s21, #0
    s.cmp.lt     s23, s17, s20
    .li       s20, #1952257862
    s.sub        s24, s21, s23
    s.movz       s21, #0
    s.xor        s23, s17, s24
    s.movz       s27, #0
    s.sub        s28, s23, s24
    s.movz       s23, #0
    s.mul        s29, s28, s20
    s.cmp.lt     s20, s22, s21
    s.movz       s21, #0
    s.movz       s30, #0
    s.sub        s31, s23, s20
    s.lshri      s20, s29, #32
    s.movz       s23, #0
    s.cmp.lt     s29, s1, s21
    s.xor        s21, s22, s31
    s.xor        s22, s25, s19
    s.sub        s25, s23, s29
    s.sub        s23, s28, s20
    s.sub        s29, s21, s31
    s.lshri      s21, s23, #1
    s.sub        s23, s22, s19
    s.add        s19, s20, s21
    s.movz       s20, #0
    s.lshri      s21, s19, #7
    s.movz       s19, #1
    s.muli       s22, s21, #176
    s.addi       s21, s20, #0
    s.cmp.eq     s20, s29, s19
    s.add        s19, s26, s23
    s.xor        s23, s1, s25
    s.sub        s26, s28, s22
    s.movz       s22, #0
    s.xor        s28, s26, s24
    s.sub        s26, s23, s25
    s.sub        s23, s28, s24
    s.addi       s24, s22, #0
    s.cmp.lt     s22, s23, s27
    s.sub        s25, s30, s22
    s.xor        s22, s23, s25
    s.sub        s23, s22, s25
    s.mov        s21, s23
    br.nz        s20, sdiv_done_3
    s.movz       s20, #0
    s.movz       s22, #31
    s.mov        s21, s20
    s.addi       s20, s22, #0
sdiv_4:
    s.lshr       s22, s23, s20
    s.shli       s26, s24, #1
    s.andi       s27, s22, #1
    s.movz       s22, #0
    s.or         s28, s26, s27
    s.movz       s26, #1
    s.cmp.geu    s27, s28, s29
    s.shl        s30, s26, s20
    s.sub        s26, s22, s27
    s.subi       s22, s20, #1
    s.and        s27, s29, s26
    s.and        s32, s30, s26
    s.sub        s26, s28, s27
    s.or         s27, s21, s32
    s.mov        s24, s26
    s.mov        s21, s27
    s.mov        s20, s22
    s.movz       s22, #0
    s.cmp.ge     s26, s20, s22
    br.nz        s26, sdiv_4
sdiv_done_3:
    s.xor        s20, s25, s31
    s.movz       s22, #16
    s.xor        s23, s21, s20
    .li       s21, #1952257862
    s.sub        s24, s23, s20
    s.movz       s20, #0
    s.mul        s23, s24, s22
    v.splat      v0, s19
    v.splat      v1, s20
    v.splat      v2, s24
    v.splat      v3, s20
    s.mul        s24, s23, s21
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s23
    v.iota       v6                              // arange(0, VLEN)
    v.cmp.ge     p1, v0, v1
    s.lshri      s21, s24, #32
    v.cmp.ge     p1, v2, v3
    s.sub        s24, s23, s21
    v.add        v0, v5, v4
    s.lshri      s25, s24, #1
    s.movz       s24, #64
    s.add        s26, s21, s25
    s.addi       s21, s20, #0
    s.lshri      s20, s26, #11
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    s.muli       s25, s20, #2816
    s.sub        s20, s23, s25
    v.splat      v0, s20
    v.add        v1, v0, v6
for_5:
    s.cmp.ge     s25, s21, s24
    br.nz        s25, endfor_6
    s.mul        s25, s21, s22
    s.muli       s26, s25, #2                    // a runtime tile origin, x2
    s.add        s27, s2, s26                    // the tile origin
    v.ld.h       v0, [s27, #0]
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s26, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s27, s20                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s28, s25                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w0, d0, s27, s26
    mb.wait      s26
    s.rdspecial  s25, arg_base
    s.ld.d       s27, [s25, #32]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s25, role_id
    s.movz       s28, #1024
    s.mul        s29, s25, s28
    s.add        s25, s27, s29                   // this context's own scratch
    s.addi       s27, s25, #256                  // 512 bytes of repack scratch
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    v.st.h       [s27, #0], v0
    s.addi       s28, s27, #32                   // row 1
    v.st.h       [s28, #0], v0
    s.addi       s28, s27, #64                   // row 2
    v.st.h       [s28, #0], v0
    s.addi       s28, s27, #96                   // row 3
    v.st.h       [s28, #0], v0
    s.addi       s28, s27, #128                  // row 4
    v.st.h       [s28, #0], v0
    s.addi       s28, s27, #160                  // row 5
    v.st.h       [s28, #0], v0
    s.addi       s28, s27, #192                  // row 6
    v.st.h       [s28, #0], v0
    s.addi       s28, s27, #224                  // row 7
    v.st.h       [s28, #0], v0
    s.addi       s28, s27, #256                  // row 8
    v.st.h       [s28, #0], v0
    s.addi       s28, s27, #288                  // row 9
    v.st.h       [s28, #0], v0
    s.addi       s28, s27, #320                  // row 10
    v.st.h       [s28, #0], v0
    s.addi       s28, s27, #352                  // row 11
    v.st.h       [s28, #0], v0
    s.addi       s28, s27, #384                  // row 12
    v.st.h       [s28, #0], v0
    s.addi       s28, s27, #416                  // row 13
    v.st.h       [s28, #0], v0
    s.addi       s28, s27, #448                  // row 14
    v.st.h       [s28, #0], v0
    s.addi       s28, s27, #480                  // row 15
    v.st.h       [s28, #0], v0
    s.addi       s28, s25, #768                  // TensorMap 1: a repacked tile
    s.movz       s25, #0
    s.st.d       [s28, #0], s27
    s.movz       s25, #16
    s.st.d       [s28, #8], s25
    s.movz       s25, #16
    s.st.d       [s28, #16], s25
    s.movz       s25, #32
    s.st.d       [s28, #48], s25
    s.movz       s25, #2
    s.st.d       [s28, #56], s25
    .li       s25, #68719476752
    s.st.d       [s28, #88], s25
    .li       s25, #8589934592
    s.st.d       [s28, #104], s25
    fence.release.device
    td.load      d1, [s28]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s25, #0
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s27, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s28, s25                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s29, s25                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s28, s27
    mb.wait      s27
    mb.arm       s25, b2, #0, #1                 // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.f16 a0, v48, v56, s25
    mb.wait      s25
    s.add        s28, s21, s9
    s.mov        s21, s28
    s.movz       s28, #1
    br.nz        s28, for_5
endfor_6:
    s.mul        s20, s19, s22
    v.splat      v0, s20
    v.add        v1, v0, v4
    s.muli       s19, s23, #2                    // a runtime tile origin, x2
    s.add        s21, s4, s19                    // the tile origin
    s.muli       s19, s20, #5632                 // a runtime tile origin, x5632
    s.add        s22, s21, s19                   // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s19, #0
    s.movz       s21, #0
    s.add        s24, s21, s20                   // the tile origin
    v.splat      v0, s24
    v.splat      v1, s9
    v.cmp.lt     p1, v0, v1
    s.movz       s21, #0
    s.add        s28, s21, s23                   // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v2, s28
    v.add        v3, v0, v2
    s.movz       s21, #2816
    v.splat      v0, s21
    v.cmp.lt     p2, v3, v0
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s22, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s19, v2
    s.movz       s19, #1
    s.addi       s21, s22, #5632                 // row 1
    s.addi       s28, s24, #1
    v.splat      v0, s28
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s21, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s19, v2
    s.movz       s19, #2
    s.addi       s21, s22, #11264                // row 2
    s.addi       s28, s24, #2
    v.splat      v0, s28
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s21, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s19, v2
    s.movz       s19, #3
    s.addi       s21, s22, #16896                // row 3
    s.addi       s28, s24, #3
    v.splat      v0, s28
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s21, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s19, v2
    s.movz       s19, #4
    s.addi       s21, s22, #22528                // row 4
    s.addi       s28, s24, #4
    v.splat      v0, s28
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s21, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s19, v2
    s.movz       s19, #5
    s.addi       s21, s22, #28160                // row 5
    s.addi       s28, s24, #5
    v.splat      v0, s28
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s21, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s19, v2
    s.movz       s19, #6
    s.movz       s21, #33792
    s.add        s28, s22, s21                   // row 6
    s.addi       s21, s24, #6
    v.splat      v0, s21
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s28, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s19, v2
    s.movz       s19, #7
    s.movz       s21, #39424
    s.add        s28, s22, s21                   // row 7
    s.addi       s21, s24, #7
    v.splat      v0, s21
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s28, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s19, v2
    s.movz       s19, #8
    s.movz       s21, #45056
    s.add        s28, s22, s21                   // row 8
    s.addi       s21, s24, #8
    v.splat      v0, s21
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s28, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s19, v2
    s.movz       s19, #9
    s.movz       s21, #50688
    s.add        s28, s22, s21                   // row 9
    s.addi       s21, s24, #9
    v.splat      v0, s21
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s28, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s19, v2
    s.movz       s19, #10
    s.movz       s21, #56320
    s.add        s28, s22, s21                   // row 10
    s.addi       s21, s24, #10
    v.splat      v0, s21
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s28, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s19, v2
    s.movz       s19, #11
    s.movz       s21, #61952
    s.add        s28, s22, s21                   // row 11
    s.addi       s21, s24, #11
    v.splat      v0, s21
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s28, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s19, v2
    s.movz       s19, #12
    .li       s21, #67584
    s.add        s28, s22, s21                   // row 12
    s.addi       s21, s24, #12
    v.splat      v0, s21
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s28, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s19, v2
    s.movz       s19, #13
    .li       s21, #73216
    s.add        s28, s22, s21                   // row 13
    s.addi       s21, s24, #13
    v.splat      v0, s21
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s28, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s19, v2
    s.movz       s19, #14
    .li       s21, #78848
    s.add        s28, s22, s21                   // row 14
    s.addi       s21, s24, #14
    v.splat      v0, s21
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s28, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s19, v2
    s.movz       s19, #15
    .li       s21, #84480
    s.add        s28, s22, s21                   // row 15
    s.addi       s21, s24, #15
    v.splat      v0, s21
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s28, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s19, v2
    .li       s19, #1065353216
    v.splat      v0, s19                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.muli       s19, s23, #2                    // a runtime tile origin, x2
    s.add        s21, s5, s19                    // the tile origin
    s.muli       s19, s20, #5632                 // a runtime tile origin, x5632
    s.add        s20, s21, s19                   // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s19, #0
    a.vread      v2, a1, s19
    s.movz       s19, #0
    a.vread      v3, a1, s19
    vf.neg       v4, v3
    .li       s19, #1069066811
    v.splat      v3, s19                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v5, v4, v3
    vf.fms       v6, v4, v3, v5                  // the exact rounding error of x*log2(e)
    v.exp2.approx v4, v5                         // ISA 8.8: <= 2**-22 relative
    .li       s19, #1060205080
    v.splat      v5, s19                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v7, v6, v5
    vf.fma       v6, v4, v7, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v7, v6, v4
    vf.add       v4, v7, v0
    v.rcp.approx v6, v4                          // ISA 8.8: <= 2**-22 relative
    .li       s19, #1065353216
    v.splat      v7, s19                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v8, v4, v6, v7
    vf.fms       v4, v6, v8, v6
    vf.neg       v8, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.mul       v6, v2, v4                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s19, #0
    a.vread      v2, a0, s19
    vf.cvt.f32.f16 v4, v2
    vf.cvt.f16.f32 v2, v4
    vf.mul       v4, v6, v2
    vf.cvt.f32.f16 v2, v4
    v.splat      v4, s24
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s20, #0], v2
    s.movz       s19, #1
    a.vread      v2, a1, s19
    s.movz       s19, #1
    a.vread      v4, a1, s19
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s19, #1
    a.vread      v2, a0, s19
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s19, s20, #5632                 // row 1
    s.addi       s21, s24, #1
    v.splat      v4, s21
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s19, #0], v2
    s.movz       s19, #2
    a.vread      v2, a1, s19
    s.movz       s19, #2
    a.vread      v4, a1, s19
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s19, #2
    a.vread      v2, a0, s19
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s19, s20, #11264                // row 2
    s.addi       s21, s24, #2
    v.splat      v4, s21
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s19, #0], v2
    s.movz       s19, #3
    a.vread      v2, a1, s19
    s.movz       s19, #3
    a.vread      v4, a1, s19
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s19, #3
    a.vread      v2, a0, s19
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s19, s20, #16896                // row 3
    s.addi       s21, s24, #3
    v.splat      v4, s21
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s19, #0], v2
    s.movz       s19, #4
    a.vread      v2, a1, s19
    s.movz       s19, #4
    a.vread      v4, a1, s19
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s19, #4
    a.vread      v2, a0, s19
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s19, s20, #22528                // row 4
    s.addi       s21, s24, #4
    v.splat      v4, s21
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s19, #0], v2
    s.movz       s19, #5
    a.vread      v2, a1, s19
    s.movz       s19, #5
    a.vread      v4, a1, s19
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s19, #5
    a.vread      v2, a0, s19
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s19, s20, #28160                // row 5
    s.addi       s21, s24, #5
    v.splat      v4, s21
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s19, #0], v2
    s.movz       s19, #6
    a.vread      v2, a1, s19
    s.movz       s19, #6
    a.vread      v4, a1, s19
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s19, #6
    a.vread      v2, a0, s19
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.movz       s19, #33792
    s.add        s21, s20, s19                   // row 6
    s.addi       s19, s24, #6
    v.splat      v4, s19
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s21, #0], v2
    s.movz       s19, #7
    a.vread      v2, a1, s19
    s.movz       s19, #7
    a.vread      v4, a1, s19
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s19, #7
    a.vread      v2, a0, s19
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.movz       s19, #39424
    s.add        s21, s20, s19                   // row 7
    s.addi       s19, s24, #7
    v.splat      v4, s19
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s21, #0], v2
    s.movz       s19, #8
    a.vread      v2, a1, s19
    s.movz       s19, #8
    a.vread      v4, a1, s19
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s19, #8
    a.vread      v2, a0, s19
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.movz       s19, #45056
    s.add        s21, s20, s19                   // row 8
    s.addi       s19, s24, #8
    v.splat      v4, s19
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s21, #0], v2
    s.movz       s19, #9
    a.vread      v2, a1, s19
    s.movz       s19, #9
    a.vread      v4, a1, s19
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s19, #9
    a.vread      v2, a0, s19
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.movz       s19, #50688
    s.add        s21, s20, s19                   // row 9
    s.addi       s19, s24, #9
    v.splat      v4, s19
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s21, #0], v2
    s.movz       s19, #10
    a.vread      v2, a1, s19
    s.movz       s19, #10
    a.vread      v4, a1, s19
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s19, #10
    a.vread      v2, a0, s19
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.movz       s19, #56320
    s.add        s21, s20, s19                   // row 10
    s.addi       s19, s24, #10
    v.splat      v4, s19
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s21, #0], v2
    s.movz       s19, #11
    a.vread      v2, a1, s19
    s.movz       s19, #11
    a.vread      v4, a1, s19
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s19, #11
    a.vread      v2, a0, s19
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.movz       s19, #61952
    s.add        s21, s20, s19                   // row 11
    s.addi       s19, s24, #11
    v.splat      v4, s19
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s21, #0], v2
    s.movz       s19, #12
    a.vread      v2, a1, s19
    s.movz       s19, #12
    a.vread      v4, a1, s19
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s19, #12
    a.vread      v2, a0, s19
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    .li       s19, #67584
    s.add        s21, s20, s19                   // row 12
    s.addi       s19, s24, #12
    v.splat      v4, s19
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s21, #0], v2
    s.movz       s19, #13
    a.vread      v2, a1, s19
    s.movz       s19, #13
    a.vread      v4, a1, s19
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s19, #13
    a.vread      v2, a0, s19
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    .li       s19, #73216
    s.add        s21, s20, s19                   // row 13
    s.addi       s19, s24, #13
    v.splat      v4, s19
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s21, #0], v2
    s.movz       s19, #14
    a.vread      v2, a1, s19
    s.movz       s19, #14
    a.vread      v4, a1, s19
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s19, #14
    a.vread      v2, a0, s19
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    .li       s19, #78848
    s.add        s21, s20, s19                   // row 14
    s.addi       s19, s24, #14
    v.splat      v4, s19
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s21, #0], v2
    s.movz       s19, #15
    a.vread      v2, a1, s19
    s.movz       s19, #15
    a.vread      v4, a1, s19
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v3, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v5, v3, v4, v3                  // 2**t * 2**d
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v4, v5, v3
    vf.add       v3, v4, v0
    v.rcp.approx v0, v3                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v4, v3, v0, v7
    vf.fms       v3, v0, v4, v0
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v0
    vf.mul       v0, v2, v3                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s19, #15
    a.vread      v2, a0, s19
    vf.cvt.f32.f16 v3, v2
    vf.cvt.f16.f32 v2, v3
    vf.mul       v3, v0, v2
    vf.cvt.f32.f16 v0, v3
    .li       s19, #84480
    s.add        s21, s20, s19                   // row 15
    s.addi       s19, s24, #15
    v.splat      v2, s19
    v.cmp.lt     p1, v2, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s21, #0], v0
__rctx_next:
    s.addi       s19, s17, #2                    // the next program of this context: + 2
    s.cmp.lt     s20, s19, s18
    s.mov        s17, s19
    br.nz        s20, __rctx_program
    exit
