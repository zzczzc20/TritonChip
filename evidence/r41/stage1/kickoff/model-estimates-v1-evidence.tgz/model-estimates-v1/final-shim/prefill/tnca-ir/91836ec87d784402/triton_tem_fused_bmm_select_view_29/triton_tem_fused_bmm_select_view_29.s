    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s3, s4, s1
    s.movz       s1, #8
    s.movz       s5, #0
    s.sub        s6, s2, s3
    s.movz       s2, #0
    s.cmp.lt     s3, s1, s5
    s.xor        s5, s4, s6
    s.sub        s7, s2, s3
    s.sub        s2, s5, s6
    s.xor        s3, s6, s7
    s.lshri      s5, s2, #3
    s.movz       s6, #4
    s.xor        s8, s5, s3
    s.movz       s9, #1
    s.sub        s10, s8, s3
    s.movz       s3, #0
    s.sub        s8, s6, s10
    s.movz       s6, #0
    s.min.s      s11, s8, s9
    s.movz       s8, #0
    s.cmp.lt     s9, s11, s3
    s.movz       s3, #0
    s.cmp.lt     s12, s4, s6
    s.sub        s6, s8, s9
    s.sub        s8, s3, s12
    s.xor        s3, s11, s6
    s.muli       s9, s5, #8
    s.movz       s5, #0
    s.movz       s12, #1
    s.xor        s13, s4, s8
    s.sub        s14, s3, s6
    s.rdspecial  s3, arg_base
    s.xor        s6, s1, s7
    s.movz       s15, #0
    s.sub        s16, s13, s8
    s.addi       s13, s5, #0
    s.cmp.eq     s5, s14, s12
    s.ld.d       s12, [s3, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.sub        s17, s6, s7
    s.sub        s6, s2, s9
    s.addi       s2, s15, #0
    s.ld.d       s6, [s3, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s7, [s3, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.mov        s13, s16
    br.nz        s5, sdiv_done_1
    s.movz       s3, #0
    s.movz       s5, #31
    s.mov        s13, s3
    s.addi       s3, s5, #0
sdiv_2:
    s.lshr       s5, s16, s3
    s.shli       s9, s2, #1
    s.andi       s15, s5, #1
    s.movz       s5, #0
    s.or         s17, s9, s15
    s.movz       s9, #1
    s.cmp.geu    s15, s17, s14
    s.shl        s18, s9, s3
    s.sub        s9, s5, s15
    s.subi       s5, s3, #1
    s.and        s15, s14, s9
    s.and        s19, s18, s9
    s.sub        s9, s17, s15
    s.or         s15, s13, s19
    s.mov        s2, s9
    s.mov        s13, s15
    s.mov        s3, s5
    s.movz       s5, #0
    s.cmp.ge     s9, s3, s5
    br.nz        s9, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s5, #0
    s.cmp.lt     s9, s4, s3
    s.movz       s3, #0
    s.sub        s13, s5, s9
    s.movz       s5, #0
    s.xor        s9, s4, s13
    s.movz       s4, #0
    s.sub        s14, s9, s13
    s.cmp.lt     s9, s11, s3
    s.lshri      s3, s14, #3
    s.movz       s15, #0
    s.muli       s16, s3, #8
    s.sub        s3, s4, s9
    s.movz       s4, #0
    s.cmp.lt     s9, s1, s15
    s.xor        s15, s11, s3
    s.sub        s11, s14, s16
    s.movz       s14, #0
    s.xor        s16, s11, s13
    s.xor        s11, s2, s8
    s.sub        s2, s16, s13
    s.sub        s13, s14, s9
    s.cmp.lt     s9, s2, s5
    s.sub        s5, s15, s3
    s.sub        s14, s4, s9
    s.movz       s4, #0
    s.xor        s9, s2, s14
    s.movz       s2, #1
    s.sub        s15, s11, s8
    s.xor        s8, s1, s13
    s.sub        s1, s9, s14
    s.movz       s9, #0
    s.addi       s11, s4, #0
    s.cmp.eq     s4, s5, s2
    s.add        s2, s10, s15
    s.sub        s10, s8, s13
    s.addi       s8, s9, #0
    s.mov        s11, s1
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.movz       s9, #31
    s.mov        s11, s4
    s.addi       s4, s9, #0
sdiv_4:
    s.lshr       s9, s1, s4
    s.shli       s10, s8, #1
    s.andi       s13, s9, #1
    s.movz       s9, #0
    s.or         s15, s10, s13
    s.movz       s10, #1
    s.cmp.geu    s13, s15, s5
    s.shl        s16, s10, s4
    s.sub        s10, s9, s13
    s.subi       s9, s4, #1
    s.and        s13, s5, s10
    s.and        s17, s16, s10
    s.sub        s10, s15, s13
    s.or         s13, s11, s17
    s.mov        s8, s10
    s.mov        s11, s13
    s.mov        s4, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s4, s9
    br.nz        s10, sdiv_4
sdiv_done_3:
    s.movz       s1, #16
    s.rdspecial  s4, pid.z
    s.rdspecial  s5, npid.y
    s.xor        s8, s14, s3
    s.mul        s3, s2, s1
    s.mul        s9, s4, s5
    s.xor        s4, s11, s8
    s.rdspecial  s5, pid.y
    s.sub        s10, s4, s8
    s.andi       s4, s3, #63
    s.mul        s8, s10, s1
    s.add        s11, s5, s9
    s.movz       s5, #15
    s.rdspecial  s9, arg_base
    s.min.s      s13, s11, s5
    s.movz       s5, #8192
    s.ld.d       s14, [s9, #24]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.muli       s9, s4, #64                     // a runtime tile origin, x64
    s.mul        s15, s13, s5
    s.andi       s13, s8, #127
    s.movz       s16, #0
    s.rdspecial  s17, role_id
    s.movz       s18, #6144
    s.add        s19, s16, s9                    // the tile origin
    s.mul        s9, s17, s18
    s.add        s16, s19, s15                   // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s16
    s.movz       s17, #0
    s.add        s18, s14, s9                    // this context's own scratch
    v.splat      v2, s2
    s.addi       s2, s18, #0
    v.splat      v3, s17
    v.splat      v4, s10
    v.splat      v5, s17
    v.add        v6, v0, v1
    s.addi       s9, s2, #64
    v.cmp.ge     p1, v2, v3
    s.addi       s10, s16, #64
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v2, s10
    v.cmp.ge     p1, v4, v5
    s.addi       s10, s16, #128
    v.splat      v3, s3
    v.splat      v4, s10
    v.add        v5, v0, v2
    s.addi       s10, s2, #128
    v.add        v2, v0, v4
    v.add        v4, v3, v1
    v.splat      v3, s8
    s.addi       s14, s16, #192
    s.addi       s19, s2, #192
    v.add        v4, v3, v1
    v.splat      v1, s14
    v.splat      v3, s4
    s.addi       s4, s12, #16384                 // &arg_A[4096] (a constant offset, x4)
    v.add        v4, v0, v1
    s.movz       s12, #64
    s.addi       s14, s17, #0
    v.st.w       [s2, #0], v6
    v.iota       v1                              // arange(0, VLEN)
    s.addi       s17, s2, #256
    v.add        v6, v3, v1
    s.addi       s20, s16, #256
    v.splat      v1, s13
    v.splat      v3, s20
    v.add        v6, v0, v3
    v.st.w       [s9, #0], v5
    v.iota       v3                              // arange(0, VLEN)
    v.add        v5, v1, v3
    s.addi       s9, s16, #320
    s.addi       s20, s16, #384
    s.addi       s21, s16, #448
    v.splat      v1, s9
    s.addi       s9, s16, #512
    v.splat      v3, s20
    s.addi       s20, s16, #576
    v.add        v5, v0, v1
    v.add        v1, v0, v3
    v.st.w       [s10, #0], v2
    s.addi       s10, s16, #640
    v.splat      v2, s21
    s.addi       s21, s16, #704
    v.add        v3, v0, v2
    v.st.w       [s19, #0], v4
    s.addi       s19, s16, #768
    v.splat      v2, s9
    s.addi       s9, s16, #832
    v.add        v4, v0, v2
    v.st.w       [s17, #0], v6
    s.addi       s17, s16, #896
    v.splat      v2, s20
    s.addi       s20, s2, #320
    s.addi       s22, s16, #960
    v.add        v6, v0, v2
    v.st.w       [s20, #0], v5
    v.splat      v2, s10
    s.addi       s10, s2, #384
    s.addi       s16, s18, #1024
    v.add        v5, v0, v2
    v.st.w       [s10, #0], v1
    s.movz       s10, #0
    v.splat      v1, s21
    s.addi       s20, s2, #448
    s.add        s21, s10, s13                   // the tile origin
    v.add        v2, v0, v1
    s.add        s10, s21, s15                   // the tile origin
    s.addi       s13, s2, #512
    s.addi       s15, s2, #576
    v.st.w       [s20, #0], v3
    s.addi       s20, s10, #128
    v.splat      v1, s19
    s.addi       s19, s2, #640
    v.add        v3, v0, v1
    v.st.w       [s13, #0], v4
    s.addi       s13, s10, #256
    v.splat      v1, s9
    s.addi       s9, s2, #704
    v.add        v4, v0, v1
    v.st.w       [s15, #0], v6
    s.addi       s15, s10, #384
    v.splat      v1, s17
    s.addi       s17, s2, #768
    v.add        v6, v0, v1
    v.st.w       [s19, #0], v5
    s.addi       s19, s10, #512
    v.splat      v1, s22
    s.addi       s21, s2, #832
    v.add        v5, v0, v1
    v.st.w       [s9, #0], v2
    s.addi       s9, s10, #640
    v.splat      v1, s10
    v.add        v2, v0, v1
    v.st.w       [s17, #0], v3
    s.addi       s17, s10, #768
    v.splat      v1, s20
    s.addi       s20, s2, #896
    s.addi       s22, s2, #960
    v.add        v3, v0, v1
    v.st.w       [s21, #0], v4
    s.addi       s2, s10, #896
    v.splat      v1, s13
    s.addi       s13, s16, #64
    v.add        v4, v0, v1
    v.st.w       [s20, #0], v6
    s.addi       s20, s10, #1024
    v.splat      v1, s15
    s.addi       s15, s16, #128
    v.add        v6, v0, v1
    v.st.w       [s22, #0], v5
    v.splat      v1, s19
    s.addi       s19, s16, #192
    s.addi       s21, s16, #256
    v.add        v5, v0, v1
    fence.acq_rel.device
    v.st.w       [s16, #0], v2
    v.splat      v1, s9
    s.addi       s9, s10, #1152
    v.add        v2, v0, v1
    v.st.w       [s13, #0], v3
    s.addi       s13, s10, #1280
    v.splat      v1, s17
    s.addi       s17, s10, #1408
    v.add        v3, v0, v1
    v.st.w       [s15, #0], v4
    s.addi       s15, s10, #1536
    v.splat      v1, s2
    s.addi       s2, s10, #1664
    v.add        v4, v0, v1
    v.st.w       [s19, #0], v6
    s.addi       s19, s10, #1792
    v.splat      v1, s20
    s.addi       s20, s16, #320
    v.add        v6, v0, v1
    v.st.w       [s21, #0], v5
    s.addi       s21, s10, #1920
    v.splat      v1, s9
    s.addi       s9, s16, #384
    s.addi       s10, s16, #448
    v.add        v5, v0, v1
    v.st.w       [s20, #0], v2
    v.splat      v1, s13
    s.addi       s13, s16, #512
    s.addi       s20, s16, #576
    v.add        v2, v0, v1
    v.st.w       [s9, #0], v3
    v.splat      v1, s17
    s.addi       s9, s16, #640
    s.addi       s17, s16, #704
    v.add        v3, v0, v1
    v.st.w       [s10, #0], v4
    v.splat      v1, s15
    s.addi       s10, s16, #768
    s.addi       s15, s16, #832
    v.add        v4, v0, v1
    v.st.w       [s13, #0], v6
    v.splat      v1, s2
    s.addi       s2, s16, #896
    s.addi       s13, s16, #960
    v.add        v6, v0, v1
    v.st.w       [s20, #0], v5
    v.splat      v1, s19
    v.add        v5, v0, v1
    v.st.w       [s9, #0], v2
    v.splat      v1, s21
    v.add        v2, v0, v1
    v.st.w       [s17, #0], v3
    v.st.w       [s10, #0], v4
    v.st.w       [s15, #0], v6
    v.st.w       [s2, #0], v5
    v.st.w       [s13, #0], v2
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_6:
    s.cmp.ge     s2, s14, s12
    br.nz        s2, endfor_7
    s.addi       s2, s18, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s9, #0
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #64
    s.movz       s10, #1
    s.addi       s13, s18, #128
    s.movz       s15, #2
    s.addi       s16, s18, #192
    v.ld.gather.w v2, [s4, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s9, v2
    v.ld.w       v1, [s2, #0]
    s.movz       s2, #3
    s.addi       s9, s18, #256
    v.ld.gather.w v2, [s4, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s10, v2
    v.ld.w       v1, [s13, #0]
    s.movz       s10, #4
    s.addi       s13, s18, #320
    v.ld.gather.w v2, [s4, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s15, v2
    v.ld.w       v1, [s16, #0]
    s.movz       s15, #5
    s.addi       s16, s18, #384
    v.ld.gather.w v2, [s4, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s2, v2
    v.ld.w       v1, [s9, #0]
    s.movz       s2, #6
    s.addi       s9, s18, #448
    v.ld.gather.w v2, [s4, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s10, v2
    v.ld.w       v1, [s13, #0]
    s.movz       s10, #7
    s.addi       s13, s18, #512
    v.ld.gather.w v2, [s4, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s15, v2
    v.ld.w       v1, [s16, #0]
    s.movz       s15, #8
    s.addi       s16, s18, #576
    v.ld.gather.w v2, [s4, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s2, v2
    v.ld.w       v1, [s9, #0]
    s.movz       s2, #9
    s.addi       s9, s18, #640
    v.ld.gather.w v2, [s4, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s10, v2
    v.ld.w       v1, [s13, #0]
    s.movz       s10, #10
    s.addi       s13, s18, #704
    v.ld.gather.w v2, [s4, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s15, v2
    v.ld.w       v1, [s16, #0]
    s.movz       s15, #11
    s.addi       s16, s18, #768
    v.ld.gather.w v2, [s4, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s2, v2
    v.ld.w       v1, [s9, #0]
    s.movz       s2, #12
    s.addi       s9, s18, #832
    v.ld.gather.w v2, [s4, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s10, v2
    v.ld.w       v1, [s13, #0]
    s.movz       s10, #13
    s.addi       s13, s18, #896
    v.ld.gather.w v2, [s4, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s15, v2
    v.ld.w       v1, [s16, #0]
    s.movz       s15, #14
    s.addi       s16, s18, #960
    v.ld.gather.w v2, [s4, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s2, v2
    v.ld.w       v1, [s9, #0]
    s.movz       s2, #15
    s.addi       s9, s18, #1024
    v.ld.gather.w v2, [s4, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s10, v2
    v.ld.w       v1, [s13, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s10, #0
    s.addi       s13, s18, #1088
    v.ld.gather.w v2, [s4, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s15, v2
    v.ld.w       v1, [s16, #0]
    s.movz       s15, #1
    s.addi       s16, s18, #1152
    v.ld.gather.w v2, [s4, v1]                   // index is in elements (ISA sec 9.1)
    s.movz       s17, #2
    a.vwrite     a1, s2, v2
    v.ld.w       v1, [s9, #0]
    s.addi       s2, s18, #1216
    s.movz       s9, #3
    v.ld.gather.w v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s10, v2
    v.ld.w       v1, [s13, #0]
    s.addi       s10, s18, #1280
    s.movz       s13, #4
    v.ld.gather.w v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v2
    v.ld.w       v1, [s16, #0]
    s.addi       s15, s18, #1344
    s.movz       s16, #5
    v.ld.gather.w v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s17, v2
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #1408
    s.movz       s17, #6
    v.ld.gather.w v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s9, v2
    v.ld.w       v1, [s10, #0]
    s.addi       s9, s18, #1472
    s.movz       s10, #7
    v.ld.gather.w v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s13, v2
    v.ld.w       v1, [s15, #0]
    s.addi       s13, s18, #1536
    s.movz       s15, #8
    v.ld.gather.w v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s16, v2
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #1600
    s.movz       s16, #9
    v.movi       v2, #0
    v.ld.gather.w v3, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s17, v3
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s18, #1664
    s.movz       s17, #10
    v.ld.gather.w v3, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s10, v3
    v.ld.w       v1, [s13, #0]
    s.addi       s10, s18, #1728
    s.movz       s13, #11
    v.ld.gather.w v3, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v3
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #1792
    s.movz       s15, #12
    v.ld.gather.w v3, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s16, v3
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s18, #1856
    s.movz       s16, #13
    v.ld.gather.w v3, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s17, v3
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s18, #1920
    s.movz       s17, #14
    v.ld.gather.w v3, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s13, v3
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #1984
    s.movz       s13, #15
    v.ld.gather.w v3, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v3
    v.ld.w       v1, [s9, #0]
    s.movz       s9, #0
    s.movz       s15, #0
    v.ld.gather.w v3, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s16, v3
    v.ld.w       v1, [s10, #0]
    s.movz       s10, #1
    s.movz       s16, #2
    v.ld.gather.w v3, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s17, v3
    v.ld.w       v1, [s2, #0]
    s.movz       s2, #3
    s.movz       s17, #4
    v.ld.gather.w v3, [s6, v1]                   // index is in elements (ISA sec 9.1)
    s.movz       s19, #5
    a.vwrite     a2, s13, v3
    a.vread      v1, a1, s9
    a.vread      v3, a2, s15
    a.vread      v4, a2, s10
    v.extract    s9, v1, #0
    v.extract    s10, v1, #1
    v.splat      v5, s9
    v.splat      v6, s10
    v.extract    s9, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s9
    a.vread      v5, a2, s16
    v.extract    s9, v1, #3
    a.vread      v8, a2, s2
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s9
    v.extract    s2, v1, #4
    a.vread      v6, a2, s17
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s9, #6
    v.splat      v4, s2
    a.vread      v8, a2, s9
    v.extract    s2, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s9, #7
    v.splat      v6, s2
    a.vread      v7, a2, s9
    v.extract    s2, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s9, #8
    v.splat      v3, s2
    a.vread      v5, a2, s9
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s2, #0
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #9
    s.movz       s10, #9
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v9, v6, v7, v10
    v.extract    s9, v1, #10
    s.movz       s10, #10
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v10, v3, v5, v9
    v.extract    s9, v1, #11
    s.movz       s10, #11
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v9, v4, v8, v10
    v.extract    s9, v1, #12
    s.movz       s10, #12
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v10, v6, v7, v9
    v.extract    s9, v1, #13
    s.movz       s10, #13
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v9, v3, v5, v10
    v.extract    s9, v1, #14
    s.movz       s10, #14
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #15
    s.movz       s10, #15
    v.splat      v1, s9
    a.vread      v4, a2, s10
    vf.fma       v8, v6, v7, v10
    s.movz       s9, #1
    s.movz       s10, #0
    s.movz       s13, #1
    s.movz       s15, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s16, #3
    s.movz       s17, #4
    s.movz       s19, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v1, a1, s9
    a.vread      v3, a2, s10
    a.vread      v4, a2, s13
    v.extract    s2, v1, #0
    v.extract    s9, v1, #1
    v.splat      v5, s2
    v.splat      v6, s9
    v.extract    s2, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s2
    a.vread      v5, a2, s15
    v.extract    s2, v1, #3
    a.vread      v8, a2, s16
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v1, #4
    a.vread      v6, a2, s17
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s9, #6
    v.splat      v4, s2
    a.vread      v8, a2, s9
    v.extract    s2, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s9, #7
    v.splat      v6, s2
    a.vread      v7, a2, s9
    v.extract    s2, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s9, #8
    v.splat      v3, s2
    a.vread      v5, a2, s9
    s.movz       s2, #1
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #9
    s.movz       s10, #9
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v9, v6, v7, v10
    v.extract    s9, v1, #10
    s.movz       s10, #10
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v10, v3, v5, v9
    v.extract    s9, v1, #11
    s.movz       s10, #11
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v9, v4, v8, v10
    v.extract    s9, v1, #12
    s.movz       s10, #12
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v10, v6, v7, v9
    v.extract    s9, v1, #13
    s.movz       s10, #13
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v9, v3, v5, v10
    v.extract    s9, v1, #14
    s.movz       s10, #14
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #15
    s.movz       s10, #15
    v.splat      v1, s9
    a.vread      v4, a2, s10
    vf.fma       v8, v6, v7, v10
    s.movz       s9, #2
    s.movz       s10, #0
    s.movz       s13, #1
    s.movz       s15, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s16, #3
    s.movz       s17, #4
    s.movz       s19, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v1, a1, s9
    a.vread      v3, a2, s10
    a.vread      v4, a2, s13
    v.extract    s2, v1, #0
    v.extract    s9, v1, #1
    v.splat      v5, s2
    v.splat      v6, s9
    v.extract    s2, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s2
    a.vread      v5, a2, s15
    v.extract    s2, v1, #3
    a.vread      v8, a2, s16
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v1, #4
    a.vread      v6, a2, s17
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s9, #6
    v.splat      v4, s2
    a.vread      v8, a2, s9
    v.extract    s2, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s9, #7
    v.splat      v6, s2
    a.vread      v7, a2, s9
    v.extract    s2, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s9, #8
    v.splat      v3, s2
    a.vread      v5, a2, s9
    s.movz       s2, #2
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #9
    s.movz       s10, #9
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v9, v6, v7, v10
    v.extract    s9, v1, #10
    s.movz       s10, #10
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v10, v3, v5, v9
    v.extract    s9, v1, #11
    s.movz       s10, #11
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v9, v4, v8, v10
    v.extract    s9, v1, #12
    s.movz       s10, #12
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v10, v6, v7, v9
    v.extract    s9, v1, #13
    s.movz       s10, #13
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v9, v3, v5, v10
    v.extract    s9, v1, #14
    s.movz       s10, #14
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #15
    s.movz       s10, #15
    v.splat      v1, s9
    a.vread      v4, a2, s10
    vf.fma       v8, v6, v7, v10
    s.movz       s9, #3
    s.movz       s10, #0
    s.movz       s13, #1
    s.movz       s15, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s16, #3
    s.movz       s17, #4
    s.movz       s19, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v1, a1, s9
    a.vread      v3, a2, s10
    a.vread      v4, a2, s13
    v.extract    s2, v1, #0
    v.extract    s9, v1, #1
    v.splat      v5, s2
    v.splat      v6, s9
    v.extract    s2, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s2
    a.vread      v5, a2, s15
    v.extract    s2, v1, #3
    a.vread      v8, a2, s16
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v1, #4
    a.vread      v6, a2, s17
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s9, #6
    v.splat      v4, s2
    a.vread      v8, a2, s9
    v.extract    s2, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s9, #7
    v.splat      v6, s2
    a.vread      v7, a2, s9
    v.extract    s2, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s9, #8
    v.splat      v3, s2
    a.vread      v5, a2, s9
    s.movz       s2, #3
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #9
    s.movz       s10, #9
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v9, v6, v7, v10
    v.extract    s9, v1, #10
    s.movz       s10, #10
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v10, v3, v5, v9
    v.extract    s9, v1, #11
    s.movz       s10, #11
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v9, v4, v8, v10
    v.extract    s9, v1, #12
    s.movz       s10, #12
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v10, v6, v7, v9
    v.extract    s9, v1, #13
    s.movz       s10, #13
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v9, v3, v5, v10
    v.extract    s9, v1, #14
    s.movz       s10, #14
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #15
    s.movz       s10, #15
    v.splat      v1, s9
    a.vread      v4, a2, s10
    vf.fma       v8, v6, v7, v10
    s.movz       s9, #4
    s.movz       s10, #0
    s.movz       s13, #1
    s.movz       s15, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s16, #3
    s.movz       s17, #4
    s.movz       s19, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v1, a1, s9
    a.vread      v3, a2, s10
    a.vread      v4, a2, s13
    v.extract    s2, v1, #0
    v.extract    s9, v1, #1
    v.splat      v5, s2
    v.splat      v6, s9
    v.extract    s2, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s2
    a.vread      v5, a2, s15
    v.extract    s2, v1, #3
    a.vread      v8, a2, s16
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v1, #4
    a.vread      v6, a2, s17
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s9, #6
    v.splat      v4, s2
    a.vread      v8, a2, s9
    v.extract    s2, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s9, #7
    v.splat      v6, s2
    a.vread      v7, a2, s9
    v.extract    s2, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s9, #8
    v.splat      v3, s2
    a.vread      v5, a2, s9
    s.movz       s2, #4
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #9
    s.movz       s10, #9
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v9, v6, v7, v10
    v.extract    s9, v1, #10
    s.movz       s10, #10
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v10, v3, v5, v9
    v.extract    s9, v1, #11
    s.movz       s10, #11
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v9, v4, v8, v10
    v.extract    s9, v1, #12
    s.movz       s10, #12
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v10, v6, v7, v9
    v.extract    s9, v1, #13
    s.movz       s10, #13
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v9, v3, v5, v10
    v.extract    s9, v1, #14
    s.movz       s10, #14
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #15
    s.movz       s10, #15
    v.splat      v1, s9
    a.vread      v4, a2, s10
    vf.fma       v8, v6, v7, v10
    s.movz       s9, #5
    s.movz       s10, #0
    s.movz       s13, #1
    s.movz       s15, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s16, #3
    s.movz       s17, #4
    s.movz       s19, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v1, a1, s9
    a.vread      v3, a2, s10
    a.vread      v4, a2, s13
    v.extract    s2, v1, #0
    v.extract    s9, v1, #1
    v.splat      v5, s2
    v.splat      v6, s9
    v.extract    s2, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s2
    a.vread      v5, a2, s15
    v.extract    s2, v1, #3
    a.vread      v8, a2, s16
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v1, #4
    a.vread      v6, a2, s17
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s9, #6
    v.splat      v4, s2
    a.vread      v8, a2, s9
    v.extract    s2, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s9, #7
    v.splat      v6, s2
    a.vread      v7, a2, s9
    v.extract    s2, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s9, #8
    v.splat      v3, s2
    a.vread      v5, a2, s9
    s.movz       s2, #5
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #9
    s.movz       s10, #9
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v9, v6, v7, v10
    v.extract    s9, v1, #10
    s.movz       s10, #10
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v10, v3, v5, v9
    v.extract    s9, v1, #11
    s.movz       s10, #11
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v9, v4, v8, v10
    v.extract    s9, v1, #12
    s.movz       s10, #12
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v10, v6, v7, v9
    v.extract    s9, v1, #13
    s.movz       s10, #13
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v9, v3, v5, v10
    v.extract    s9, v1, #14
    s.movz       s10, #14
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #15
    s.movz       s10, #15
    v.splat      v1, s9
    a.vread      v4, a2, s10
    vf.fma       v8, v6, v7, v10
    s.movz       s9, #6
    s.movz       s10, #0
    s.movz       s13, #1
    s.movz       s15, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s16, #3
    s.movz       s17, #4
    s.movz       s19, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v1, a1, s9
    a.vread      v3, a2, s10
    a.vread      v4, a2, s13
    v.extract    s2, v1, #0
    v.extract    s9, v1, #1
    v.splat      v5, s2
    v.splat      v6, s9
    v.extract    s2, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s2
    a.vread      v5, a2, s15
    v.extract    s2, v1, #3
    a.vread      v8, a2, s16
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v1, #4
    a.vread      v6, a2, s17
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s9, #6
    v.splat      v4, s2
    a.vread      v8, a2, s9
    v.extract    s2, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s9, #7
    v.splat      v6, s2
    a.vread      v7, a2, s9
    v.extract    s2, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s9, #8
    v.splat      v3, s2
    a.vread      v5, a2, s9
    s.movz       s2, #6
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #9
    s.movz       s10, #9
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v9, v6, v7, v10
    v.extract    s9, v1, #10
    s.movz       s10, #10
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v10, v3, v5, v9
    v.extract    s9, v1, #11
    s.movz       s10, #11
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v9, v4, v8, v10
    v.extract    s9, v1, #12
    s.movz       s10, #12
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v10, v6, v7, v9
    v.extract    s9, v1, #13
    s.movz       s10, #13
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v9, v3, v5, v10
    v.extract    s9, v1, #14
    s.movz       s10, #14
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #15
    s.movz       s10, #15
    v.splat      v1, s9
    a.vread      v4, a2, s10
    vf.fma       v8, v6, v7, v10
    s.movz       s9, #7
    s.movz       s10, #0
    s.movz       s13, #1
    s.movz       s15, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s16, #3
    s.movz       s17, #4
    s.movz       s19, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v1, a1, s9
    a.vread      v3, a2, s10
    a.vread      v4, a2, s13
    v.extract    s2, v1, #0
    v.extract    s9, v1, #1
    v.splat      v5, s2
    v.splat      v6, s9
    v.extract    s2, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s2
    a.vread      v5, a2, s15
    v.extract    s2, v1, #3
    a.vread      v8, a2, s16
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v1, #4
    a.vread      v6, a2, s17
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s9, #6
    v.splat      v4, s2
    a.vread      v8, a2, s9
    v.extract    s2, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s9, #7
    v.splat      v6, s2
    a.vread      v7, a2, s9
    v.extract    s2, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s9, #8
    v.splat      v3, s2
    a.vread      v5, a2, s9
    s.movz       s2, #7
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #9
    s.movz       s10, #9
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v9, v6, v7, v10
    v.extract    s9, v1, #10
    s.movz       s10, #10
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v10, v3, v5, v9
    v.extract    s9, v1, #11
    s.movz       s10, #11
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v9, v4, v8, v10
    v.extract    s9, v1, #12
    s.movz       s10, #12
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v10, v6, v7, v9
    v.extract    s9, v1, #13
    s.movz       s10, #13
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v9, v3, v5, v10
    v.extract    s9, v1, #14
    s.movz       s10, #14
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #15
    s.movz       s10, #15
    v.splat      v1, s9
    a.vread      v4, a2, s10
    vf.fma       v8, v6, v7, v10
    s.movz       s9, #8
    s.movz       s10, #0
    s.movz       s13, #1
    s.movz       s15, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s16, #3
    s.movz       s17, #4
    s.movz       s19, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v1, a1, s9
    a.vread      v3, a2, s10
    a.vread      v4, a2, s13
    v.extract    s2, v1, #0
    v.extract    s9, v1, #1
    v.splat      v5, s2
    v.splat      v6, s9
    v.extract    s2, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s2
    a.vread      v5, a2, s15
    v.extract    s2, v1, #3
    a.vread      v8, a2, s16
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v1, #4
    a.vread      v6, a2, s17
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s9, #6
    v.splat      v4, s2
    a.vread      v8, a2, s9
    v.extract    s2, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s9, #7
    v.splat      v6, s2
    a.vread      v7, a2, s9
    v.extract    s2, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s9, #8
    v.splat      v3, s2
    a.vread      v5, a2, s9
    s.movz       s2, #8
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #9
    s.movz       s10, #9
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v9, v6, v7, v10
    v.extract    s9, v1, #10
    s.movz       s10, #10
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v10, v3, v5, v9
    v.extract    s9, v1, #11
    s.movz       s10, #11
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v9, v4, v8, v10
    v.extract    s9, v1, #12
    s.movz       s10, #12
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v10, v6, v7, v9
    v.extract    s9, v1, #13
    s.movz       s10, #13
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v9, v3, v5, v10
    v.extract    s9, v1, #14
    s.movz       s10, #14
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #15
    s.movz       s10, #15
    v.splat      v1, s9
    a.vread      v4, a2, s10
    vf.fma       v8, v6, v7, v10
    s.movz       s9, #9
    s.movz       s10, #0
    s.movz       s13, #1
    s.movz       s15, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s16, #3
    s.movz       s17, #4
    s.movz       s19, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v1, a1, s9
    a.vread      v3, a2, s10
    a.vread      v4, a2, s13
    v.extract    s2, v1, #0
    v.extract    s9, v1, #1
    v.splat      v5, s2
    v.splat      v6, s9
    v.extract    s2, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s2
    a.vread      v5, a2, s15
    v.extract    s2, v1, #3
    a.vread      v8, a2, s16
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v1, #4
    a.vread      v6, a2, s17
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s9, #6
    v.splat      v4, s2
    a.vread      v8, a2, s9
    v.extract    s2, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s9, #7
    v.splat      v6, s2
    a.vread      v7, a2, s9
    v.extract    s2, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s9, #8
    v.splat      v3, s2
    a.vread      v5, a2, s9
    s.movz       s2, #9
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #9
    s.movz       s10, #9
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v9, v6, v7, v10
    v.extract    s9, v1, #10
    s.movz       s10, #10
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v10, v3, v5, v9
    v.extract    s9, v1, #11
    s.movz       s10, #11
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v9, v4, v8, v10
    v.extract    s9, v1, #12
    s.movz       s10, #12
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v10, v6, v7, v9
    v.extract    s9, v1, #13
    s.movz       s10, #13
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v9, v3, v5, v10
    v.extract    s9, v1, #14
    s.movz       s10, #14
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #15
    s.movz       s10, #15
    v.splat      v1, s9
    a.vread      v4, a2, s10
    vf.fma       v8, v6, v7, v10
    s.movz       s9, #10
    s.movz       s10, #0
    s.movz       s13, #1
    s.movz       s15, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s16, #3
    s.movz       s17, #4
    s.movz       s19, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v1, a1, s9
    a.vread      v3, a2, s10
    a.vread      v4, a2, s13
    v.extract    s2, v1, #0
    v.extract    s9, v1, #1
    v.splat      v5, s2
    v.splat      v6, s9
    v.extract    s2, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s2
    a.vread      v5, a2, s15
    v.extract    s2, v1, #3
    a.vread      v8, a2, s16
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v1, #4
    a.vread      v6, a2, s17
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s9, #6
    v.splat      v4, s2
    a.vread      v8, a2, s9
    v.extract    s2, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s9, #7
    v.splat      v6, s2
    a.vread      v7, a2, s9
    v.extract    s2, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s9, #8
    v.splat      v3, s2
    a.vread      v5, a2, s9
    s.movz       s2, #10
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #9
    s.movz       s10, #9
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v9, v6, v7, v10
    v.extract    s9, v1, #10
    s.movz       s10, #10
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v10, v3, v5, v9
    v.extract    s9, v1, #11
    s.movz       s10, #11
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v9, v4, v8, v10
    v.extract    s9, v1, #12
    s.movz       s10, #12
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v10, v6, v7, v9
    v.extract    s9, v1, #13
    s.movz       s10, #13
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v9, v3, v5, v10
    v.extract    s9, v1, #14
    s.movz       s10, #14
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #15
    s.movz       s10, #15
    v.splat      v1, s9
    a.vread      v4, a2, s10
    vf.fma       v8, v6, v7, v10
    s.movz       s9, #11
    s.movz       s10, #0
    s.movz       s13, #1
    s.movz       s15, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s16, #3
    s.movz       s17, #4
    s.movz       s19, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v1, a1, s9
    a.vread      v3, a2, s10
    a.vread      v4, a2, s13
    v.extract    s2, v1, #0
    v.extract    s9, v1, #1
    v.splat      v5, s2
    v.splat      v6, s9
    v.extract    s2, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s2
    a.vread      v5, a2, s15
    v.extract    s2, v1, #3
    a.vread      v8, a2, s16
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v1, #4
    a.vread      v6, a2, s17
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s9, #6
    v.splat      v4, s2
    a.vread      v8, a2, s9
    v.extract    s2, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s9, #7
    v.splat      v6, s2
    a.vread      v7, a2, s9
    v.extract    s2, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s9, #8
    v.splat      v3, s2
    a.vread      v5, a2, s9
    s.movz       s2, #11
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #9
    s.movz       s10, #9
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v9, v6, v7, v10
    v.extract    s9, v1, #10
    s.movz       s10, #10
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v10, v3, v5, v9
    v.extract    s9, v1, #11
    s.movz       s10, #11
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v9, v4, v8, v10
    v.extract    s9, v1, #12
    s.movz       s10, #12
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v10, v6, v7, v9
    v.extract    s9, v1, #13
    s.movz       s10, #13
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v9, v3, v5, v10
    v.extract    s9, v1, #14
    s.movz       s10, #14
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #15
    s.movz       s10, #15
    v.splat      v1, s9
    a.vread      v4, a2, s10
    vf.fma       v8, v6, v7, v10
    s.movz       s9, #12
    s.movz       s10, #0
    s.movz       s13, #1
    s.movz       s15, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s16, #3
    s.movz       s17, #4
    s.movz       s19, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v1, a1, s9
    a.vread      v3, a2, s10
    a.vread      v4, a2, s13
    v.extract    s2, v1, #0
    v.extract    s9, v1, #1
    v.splat      v5, s2
    v.splat      v6, s9
    v.extract    s2, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s2
    a.vread      v5, a2, s15
    v.extract    s2, v1, #3
    a.vread      v8, a2, s16
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v1, #4
    a.vread      v6, a2, s17
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s9, #6
    v.splat      v4, s2
    a.vread      v8, a2, s9
    v.extract    s2, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s9, #7
    v.splat      v6, s2
    a.vread      v7, a2, s9
    v.extract    s2, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s9, #8
    v.splat      v3, s2
    a.vread      v5, a2, s9
    s.movz       s2, #12
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #9
    s.movz       s10, #9
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v9, v6, v7, v10
    v.extract    s9, v1, #10
    s.movz       s10, #10
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v10, v3, v5, v9
    v.extract    s9, v1, #11
    s.movz       s10, #11
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v9, v4, v8, v10
    v.extract    s9, v1, #12
    s.movz       s10, #12
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v10, v6, v7, v9
    v.extract    s9, v1, #13
    s.movz       s10, #13
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v9, v3, v5, v10
    v.extract    s9, v1, #14
    s.movz       s10, #14
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #15
    s.movz       s10, #15
    v.splat      v1, s9
    a.vread      v4, a2, s10
    vf.fma       v8, v6, v7, v10
    s.movz       s9, #13
    s.movz       s10, #0
    s.movz       s13, #1
    s.movz       s15, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s16, #3
    s.movz       s17, #4
    s.movz       s19, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v1, a1, s9
    a.vread      v3, a2, s10
    a.vread      v4, a2, s13
    v.extract    s2, v1, #0
    v.extract    s9, v1, #1
    v.splat      v5, s2
    v.splat      v6, s9
    v.extract    s2, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s2
    a.vread      v5, a2, s15
    v.extract    s2, v1, #3
    a.vread      v8, a2, s16
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v1, #4
    a.vread      v6, a2, s17
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s9, #6
    v.splat      v4, s2
    a.vread      v8, a2, s9
    v.extract    s2, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s9, #7
    v.splat      v6, s2
    a.vread      v7, a2, s9
    v.extract    s2, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s9, #8
    v.splat      v3, s2
    a.vread      v5, a2, s9
    s.movz       s2, #13
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #9
    s.movz       s10, #9
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v9, v6, v7, v10
    v.extract    s9, v1, #10
    s.movz       s10, #10
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v10, v3, v5, v9
    v.extract    s9, v1, #11
    s.movz       s10, #11
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v9, v4, v8, v10
    v.extract    s9, v1, #12
    s.movz       s10, #12
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v10, v6, v7, v9
    v.extract    s9, v1, #13
    s.movz       s10, #13
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v9, v3, v5, v10
    v.extract    s9, v1, #14
    s.movz       s10, #14
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #15
    s.movz       s10, #15
    v.splat      v1, s9
    a.vread      v4, a2, s10
    vf.fma       v8, v6, v7, v10
    s.movz       s9, #14
    s.movz       s10, #0
    s.movz       s13, #1
    s.movz       s15, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s16, #3
    s.movz       s17, #4
    s.movz       s19, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v1, a1, s9
    a.vread      v3, a2, s10
    a.vread      v4, a2, s13
    v.extract    s2, v1, #0
    v.extract    s9, v1, #1
    v.splat      v5, s2
    v.splat      v6, s9
    v.extract    s2, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s2
    a.vread      v5, a2, s15
    v.extract    s2, v1, #3
    a.vread      v8, a2, s16
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v1, #4
    a.vread      v6, a2, s17
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s9, #6
    v.splat      v4, s2
    a.vread      v8, a2, s9
    v.extract    s2, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s9, #7
    v.splat      v6, s2
    a.vread      v7, a2, s9
    v.extract    s2, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s9, #8
    v.splat      v3, s2
    a.vread      v5, a2, s9
    s.movz       s2, #14
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #9
    s.movz       s10, #9
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v9, v6, v7, v10
    v.extract    s9, v1, #10
    s.movz       s10, #10
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v10, v3, v5, v9
    v.extract    s9, v1, #11
    s.movz       s10, #11
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v9, v4, v8, v10
    v.extract    s9, v1, #12
    s.movz       s10, #12
    v.splat      v4, s9
    a.vread      v8, a2, s10
    vf.fma       v10, v6, v7, v9
    v.extract    s9, v1, #13
    s.movz       s10, #13
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v9, v3, v5, v10
    v.extract    s9, v1, #14
    s.movz       s10, #14
    v.splat      v3, s9
    a.vread      v5, a2, s10
    vf.fma       v10, v4, v8, v9
    v.extract    s9, v1, #15
    s.movz       s10, #15
    v.splat      v1, s9
    a.vread      v4, a2, s10
    vf.fma       v8, v6, v7, v10
    s.movz       s9, #15
    s.movz       s10, #0
    s.movz       s13, #1
    s.movz       s15, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s16, #3
    s.movz       s17, #4
    s.movz       s19, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v1, a1, s9
    a.vread      v3, a2, s10
    a.vread      v4, a2, s13
    v.extract    s2, v1, #0
    v.extract    s9, v1, #1
    v.splat      v5, s2
    v.splat      v6, s9
    v.extract    s2, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v2, s2
    a.vread      v3, a2, s15
    v.extract    s2, v1, #3
    a.vread      v5, a2, s16
    vf.fma       v8, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v1, #4
    a.vread      v6, a2, s17
    v.splat      v7, s2
    vf.fma       v9, v2, v3, v8
    v.extract    s2, v1, #5
    a.vread      v2, a2, s19
    v.splat      v3, s2
    v.extract    s2, v1, #6
    vf.fma       v8, v4, v5, v9
    s.movz       s9, #6
    v.splat      v4, s2
    a.vread      v5, a2, s9
    v.extract    s2, v1, #7
    vf.fma       v9, v7, v6, v8
    s.movz       s9, #7
    v.splat      v6, s2
    a.vread      v7, a2, s9
    v.extract    s2, v1, #8
    vf.fma       v8, v3, v2, v9
    s.movz       s9, #8
    v.splat      v2, s2
    a.vread      v3, a2, s9
    s.movz       s2, #15
    vf.fma       v9, v4, v5, v8
    v.extract    s9, v1, #9
    s.movz       s10, #9
    v.splat      v4, s9
    a.vread      v5, a2, s10
    vf.fma       v8, v6, v7, v9
    v.extract    s9, v1, #10
    s.movz       s10, #10
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v9, v2, v3, v8
    v.extract    s9, v1, #11
    s.movz       s10, #11
    v.splat      v2, s9
    a.vread      v3, a2, s10
    vf.fma       v8, v4, v5, v9
    v.extract    s9, v1, #12
    s.movz       s10, #12
    v.splat      v4, s9
    a.vread      v5, a2, s10
    vf.fma       v9, v6, v7, v8
    v.extract    s9, v1, #13
    s.movz       s10, #13
    v.splat      v6, s9
    a.vread      v7, a2, s10
    vf.fma       v8, v2, v3, v9
    v.extract    s9, v1, #14
    s.movz       s10, #14
    v.splat      v2, s9
    a.vread      v3, a2, s10
    vf.fma       v9, v4, v5, v8
    v.extract    s9, v1, #15
    s.movz       s10, #15
    v.splat      v1, s9
    a.vread      v4, a2, s10
    vf.fma       v5, v6, v7, v9
    s.addi       s9, s18, #0
    v.splat      v6, s1
    s.addi       s10, s18, #2048
    s.addi       s13, s18, #64
    vf.fma       v7, v2, v3, v5
    s.addi       s15, s10, #64
    s.addi       s16, s18, #128
    s.addi       s17, s10, #128
    s.addi       s19, s18, #192
    vf.fma       v2, v1, v4, v7
    a.vwrite     a3, s2, v2
    v.ld.w       v1, [s9, #0]
    s.addi       s2, s10, #192
    s.addi       s9, s18, #256
    v.add        v2, v1, v6
    v.st.w       [s10, #0], v2
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #256
    v.add        v2, v1, v6
    v.st.w       [s15, #0], v2
    s.addi       s15, s18, #320
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s10, #320
    v.add        v2, v1, v6
    v.st.w       [s17, #0], v2
    s.addi       s17, s18, #384
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s10, #384
    v.add        v2, v1, v6
    v.st.w       [s2, #0], v2
    s.addi       s2, s18, #448
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s10, #448
    v.add        v2, v1, v6
    v.st.w       [s13, #0], v2
    s.addi       s13, s18, #512
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s10, #512
    v.add        v2, v1, v6
    v.st.w       [s16, #0], v2
    s.addi       s16, s18, #576
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s10, #576
    v.add        v2, v1, v6
    v.st.w       [s19, #0], v2
    s.addi       s19, s18, #640
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s10, #640
    v.add        v2, v1, v6
    v.st.w       [s9, #0], v2
    s.addi       s9, s18, #704
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #704
    v.add        v2, v1, v6
    v.st.w       [s15, #0], v2
    s.addi       s15, s18, #768
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s10, #768
    v.add        v2, v1, v6
    v.st.w       [s17, #0], v2
    s.addi       s17, s18, #832
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s10, #832
    v.add        v2, v1, v6
    v.st.w       [s2, #0], v2
    s.addi       s2, s18, #896
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s10, #896
    s.addi       s20, s10, #960
    v.add        v2, v1, v6
    v.st.w       [s13, #0], v2
    s.addi       s10, s18, #960
    v.ld.w       v1, [s15, #0]
    s.addi       s13, s18, #1024
    v.add        v2, v1, v6
    v.st.w       [s16, #0], v2
    s.movz       s15, #2048
    v.splat      v1, s15
    s.addi       s15, s18, #3072
    v.ld.w       v2, [s17, #0]
    s.addi       s16, s18, #1088
    v.add        v3, v2, v6
    v.st.w       [s19, #0], v3
    s.addi       s17, s15, #64
    v.ld.w       v2, [s2, #0]
    s.addi       s2, s18, #1152
    v.add        v3, v2, v6
    v.st.w       [s9, #0], v3
    s.addi       s9, s15, #128
    v.ld.w       v2, [s10, #0]
    s.addi       s10, s18, #1216
    v.add        v3, v2, v6
    v.st.w       [s20, #0], v3
    fence.acq_rel.device
    s.addi       s19, s15, #192
    v.ld.w       v2, [s13, #0]
    s.addi       s13, s18, #1280
    v.add        v3, v2, v1
    v.st.w       [s15, #0], v3
    v.ld.w       v2, [s16, #0]
    s.addi       s16, s15, #256
    v.add        v3, v2, v1
    v.st.w       [s17, #0], v3
    s.addi       s17, s18, #1344
    v.ld.w       v2, [s2, #0]
    s.addi       s2, s15, #320
    v.add        v3, v2, v1
    v.st.w       [s9, #0], v3
    s.addi       s9, s18, #1408
    v.ld.w       v2, [s10, #0]
    s.addi       s10, s15, #384
    v.add        v3, v2, v1
    v.st.w       [s19, #0], v3
    s.addi       s19, s18, #1472
    v.ld.w       v2, [s13, #0]
    s.addi       s13, s15, #448
    v.add        v3, v2, v1
    v.st.w       [s16, #0], v3
    s.addi       s16, s18, #1536
    v.ld.w       v2, [s17, #0]
    s.addi       s17, s15, #512
    v.add        v3, v2, v1
    v.st.w       [s2, #0], v3
    s.addi       s2, s18, #1600
    v.ld.w       v2, [s9, #0]
    s.addi       s9, s15, #576
    v.add        v3, v2, v1
    v.st.w       [s10, #0], v3
    s.addi       s10, s18, #1664
    v.ld.w       v2, [s19, #0]
    s.addi       s19, s15, #640
    v.add        v3, v2, v1
    v.st.w       [s13, #0], v3
    s.addi       s13, s18, #1728
    v.ld.w       v2, [s16, #0]
    s.addi       s16, s15, #704
    v.add        v3, v2, v1
    v.st.w       [s17, #0], v3
    s.addi       s17, s18, #1792
    v.ld.w       v2, [s2, #0]
    s.addi       s2, s15, #768
    v.add        v3, v2, v1
    v.st.w       [s9, #0], v3
    s.addi       s9, s18, #1856
    v.ld.w       v2, [s10, #0]
    s.addi       s10, s15, #832
    v.add        v3, v2, v1
    v.st.w       [s19, #0], v3
    s.addi       s19, s18, #1920
    v.ld.w       v2, [s13, #0]
    s.addi       s13, s15, #896
    s.addi       s20, s15, #960
    v.add        v3, v2, v1
    v.st.w       [s16, #0], v3
    s.addi       s15, s18, #1984
    v.ld.w       v2, [s17, #0]
    s.addi       s16, s18, #2048
    v.add        v3, v2, v1
    v.st.w       [s2, #0], v3
    s.addi       s2, s18, #4096
    v.ld.w       v2, [s9, #0]
    s.addi       s9, s18, #2112
    v.add        v3, v2, v1
    v.st.w       [s10, #0], v3
    s.addi       s10, s2, #64
    v.ld.w       v2, [s19, #0]
    s.addi       s17, s18, #2176
    v.add        v3, v2, v1
    v.st.w       [s13, #0], v3
    s.addi       s13, s2, #128
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s18, #2240
    v.add        v3, v2, v1
    v.st.w       [s20, #0], v3
    fence.acq_rel.device
    s.addi       s19, s2, #192
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s18, #2304
    v.st.w       [s2, #0], v1
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s2, #256
    v.st.w       [s10, #0], v1
    s.addi       s10, s18, #2368
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s2, #320
    v.st.w       [s13, #0], v1
    s.addi       s13, s18, #2432
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s2, #384
    v.st.w       [s19, #0], v1
    s.addi       s19, s18, #2496
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s2, #448
    v.st.w       [s9, #0], v1
    s.addi       s9, s18, #2560
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s2, #512
    v.st.w       [s17, #0], v1
    s.addi       s17, s18, #2624
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s2, #576
    v.st.w       [s15, #0], v1
    s.addi       s15, s18, #2688
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s2, #640
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #2752
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s2, #704
    v.st.w       [s10, #0], v1
    s.addi       s10, s18, #2816
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s2, #768
    v.st.w       [s13, #0], v1
    s.addi       s13, s18, #2880
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s2, #832
    v.st.w       [s19, #0], v1
    s.addi       s19, s18, #2944
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s2, #896
    s.addi       s20, s2, #960
    v.st.w       [s9, #0], v1
    s.addi       s2, s18, #3008
    v.ld.w       v1, [s10, #0]
    s.addi       s9, s18, #3072
    v.st.w       [s17, #0], v1
    s.addi       s10, s18, #5120
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s18, #3136
    v.st.w       [s15, #0], v1
    s.addi       s15, s10, #64
    v.ld.w       v1, [s19, #0]
    s.addi       s17, s18, #3200
    v.st.w       [s16, #0], v1
    s.addi       s16, s10, #128
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #3264
    v.st.w       [s20, #0], v1
    fence.acq_rel.device
    s.addi       s19, s10, #192
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s18, #3328
    v.st.w       [s10, #0], v1
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #256
    v.st.w       [s15, #0], v1
    s.addi       s15, s18, #3392
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s10, #320
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #3456
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s10, #384
    v.st.w       [s19, #0], v1
    s.addi       s19, s18, #3520
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s10, #448
    v.st.w       [s13, #0], v1
    s.addi       s13, s18, #3584
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s10, #512
    v.st.w       [s17, #0], v1
    s.addi       s17, s18, #3648
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s10, #576
    v.st.w       [s2, #0], v1
    s.addi       s2, s18, #3712
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s10, #640
    v.st.w       [s9, #0], v1
    s.addi       s9, s18, #3776
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #704
    v.st.w       [s15, #0], v1
    s.addi       s15, s18, #3840
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s10, #768
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #3904
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s10, #832
    v.st.w       [s19, #0], v1
    s.addi       s19, s18, #3968
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s10, #896
    s.addi       s20, s10, #960
    v.st.w       [s13, #0], v1
    s.addi       s10, s18, #4032
    v.ld.w       v1, [s15, #0]
    s.movz       s13, #0
    v.st.w       [s17, #0], v1
    s.movz       s15, #0
    v.ld.w       v1, [s16, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s16, #0
    v.st.w       [s2, #0], v1
    s.movz       s2, #1
    v.ld.w       v1, [s19, #0]
    s.movz       s17, #1
    v.st.w       [s9, #0], v1
    s.movz       s9, #1
    v.ld.w       v1, [s10, #0]
    s.movz       s10, #2
    v.st.w       [s20, #0], v1
    fence.acq_rel.device
    a.vread      v1, a0, s13
    a.vread      v2, a3, s15
    s.movz       s13, #2
    s.movz       s15, #2
    vf.add       v3, v1, v2
    s.movz       s19, #3
    a.vwrite     a4, s16, v3
    a.vread      v1, a0, s2
    a.vread      v2, a3, s17
    s.movz       s2, #3
    s.movz       s16, #3
    vf.add       v3, v1, v2
    s.movz       s17, #4
    a.vwrite     a4, s9, v3
    a.vread      v1, a0, s10
    a.vread      v2, a3, s13
    s.movz       s9, #4
    s.movz       s10, #4
    vf.add       v3, v1, v2
    s.movz       s13, #5
    a.vwrite     a4, s15, v3
    a.vread      v1, a0, s19
    a.vread      v2, a3, s2
    s.movz       s2, #5
    s.movz       s15, #5
    vf.add       v3, v1, v2
    s.movz       s19, #6
    a.vwrite     a4, s16, v3
    a.vread      v1, a0, s17
    a.vread      v2, a3, s9
    s.movz       s9, #6
    s.movz       s16, #6
    vf.add       v3, v1, v2
    s.movz       s17, #7
    a.vwrite     a4, s10, v3
    a.vread      v1, a0, s13
    a.vread      v2, a3, s2
    s.movz       s2, #7
    s.movz       s10, #7
    vf.add       v3, v1, v2
    s.movz       s13, #8
    a.vwrite     a4, s15, v3
    a.vread      v1, a0, s19
    a.vread      v2, a3, s9
    s.movz       s9, #8
    s.movz       s15, #8
    vf.add       v3, v1, v2
    s.movz       s19, #9
    a.vwrite     a4, s16, v3
    a.vread      v1, a0, s17
    a.vread      v2, a3, s2
    s.movz       s2, #9
    s.movz       s16, #9
    vf.add       v3, v1, v2
    s.movz       s17, #10
    a.vwrite     a4, s10, v3
    a.vread      v1, a0, s13
    a.vread      v2, a3, s9
    s.movz       s9, #10
    s.movz       s10, #10
    vf.add       v3, v1, v2
    s.movz       s13, #11
    a.vwrite     a4, s15, v3
    a.vread      v1, a0, s19
    a.vread      v2, a3, s2
    s.movz       s2, #11
    s.movz       s15, #11
    vf.add       v3, v1, v2
    s.movz       s19, #12
    a.vwrite     a4, s16, v3
    a.vread      v1, a0, s17
    a.vread      v2, a3, s9
    s.movz       s9, #12
    s.movz       s16, #12
    vf.add       v3, v1, v2
    s.movz       s17, #13
    a.vwrite     a4, s10, v3
    a.vread      v1, a0, s13
    a.vread      v2, a3, s2
    s.movz       s2, #13
    s.movz       s10, #13
    vf.add       v3, v1, v2
    s.movz       s13, #14
    a.vwrite     a4, s15, v3
    a.vread      v1, a0, s19
    a.vread      v2, a3, s9
    s.movz       s9, #14
    s.movz       s15, #14
    vf.add       v3, v1, v2
    s.movz       s19, #15
    a.vwrite     a4, s16, v3
    a.vread      v1, a0, s17
    a.vread      v2, a3, s2
    s.movz       s2, #15
    s.movz       s16, #15
    vf.add       v3, v1, v2
    s.addi       s17, s18, #4096
    a.vwrite     a4, s10, v3
    a.vread      v1, a0, s13
    a.vread      v2, a3, s9
    s.addi       s9, s18, #0
    s.addi       s10, s18, #4160
    vf.add       v3, v1, v2
    s.addi       s13, s18, #64
    a.vwrite     a4, s15, v3
    a.vread      v1, a0, s19
    a.vread      v2, a3, s2
    s.addi       s2, s18, #4224
    s.addi       s15, s18, #128
    vf.add       v3, v1, v2
    s.addi       s19, s18, #4288
    a.vwrite     a4, s16, v3
    v.ld.w       v1, [s17, #0]
    s.addi       s16, s18, #192
    s.addi       s17, s18, #4352
    v.st.w       [s9, #0], v1
    s.addi       s9, s18, #256
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s18, #4416
    v.st.w       [s13, #0], v1
    s.addi       s13, s18, #320
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #4480
    v.st.w       [s15, #0], v1
    s.addi       s15, s18, #384
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s18, #4544
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #448
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s18, #4608
    v.st.w       [s9, #0], v1
    s.addi       s9, s18, #512
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s18, #4672
    v.st.w       [s13, #0], v1
    s.addi       s13, s18, #576
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #4736
    v.st.w       [s15, #0], v1
    s.addi       s15, s18, #640
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s18, #4800
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #704
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s18, #4864
    v.st.w       [s9, #0], v1
    s.addi       s9, s18, #768
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s18, #4928
    v.st.w       [s13, #0], v1
    s.addi       s13, s18, #832
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #4992
    v.st.w       [s15, #0], v1
    s.addi       s15, s18, #896
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s18, #5056
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #960
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s18, #5120
    v.st.w       [s9, #0], v1
    s.addi       s9, s18, #1024
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s18, #5184
    v.st.w       [s13, #0], v1
    s.addi       s13, s18, #1088
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #5248
    v.st.w       [s15, #0], v1
    s.addi       s15, s18, #1152
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s18, #5312
    v.st.w       [s16, #0], v1
    fence.acq_rel.device
    s.addi       s16, s18, #1216
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s18, #5376
    v.st.w       [s9, #0], v1
    s.addi       s9, s18, #1280
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s18, #5440
    v.st.w       [s13, #0], v1
    s.addi       s13, s18, #1344
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #5504
    v.st.w       [s15, #0], v1
    s.addi       s15, s18, #1408
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s18, #5568
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #1472
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s18, #5632
    v.st.w       [s9, #0], v1
    s.addi       s9, s18, #1536
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s18, #5696
    v.st.w       [s13, #0], v1
    s.addi       s13, s18, #1600
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #5760
    v.st.w       [s15, #0], v1
    s.addi       s15, s18, #1664
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s18, #5824
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #1728
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s18, #5888
    v.st.w       [s9, #0], v1
    s.addi       s9, s18, #1792
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s18, #5952
    v.st.w       [s13, #0], v1
    s.addi       s13, s18, #1856
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #6016
    v.st.w       [s15, #0], v1
    s.addi       s15, s18, #1920
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s18, #6080
    s.addi       s20, s18, #1984
    v.st.w       [s16, #0], v1
    s.movz       s16, #0
    v.ld.w       v1, [s17, #0]
    s.movz       s17, #0
    v.st.w       [s9, #0], v1
    s.movz       s9, #1
    v.ld.w       v1, [s10, #0]
    s.movz       s10, #1
    v.st.w       [s13, #0], v1
    s.movz       s13, #2
    v.ld.w       v1, [s2, #0]
    s.movz       s2, #2
    v.st.w       [s15, #0], v1
    s.movz       s15, #3
    v.ld.w       v1, [s19, #0]
    s.movz       s19, #3
    v.st.w       [s20, #0], v1
    fence.acq_rel.device
    a.vread      v1, a4, s16
    s.movz       s16, #4
    s.movz       s20, #4
    a.vwrite     a0, s17, v1
    a.vread      v1, a4, s9
    s.movz       s9, #5
    s.movz       s17, #5
    a.vwrite     a0, s10, v1
    a.vread      v1, a4, s13
    s.movz       s10, #6
    s.movz       s13, #6
    a.vwrite     a0, s2, v1
    a.vread      v1, a4, s15
    s.movz       s2, #7
    s.movz       s15, #7
    a.vwrite     a0, s19, v1
    a.vread      v1, a4, s16
    s.movz       s16, #8
    s.movz       s19, #8
    a.vwrite     a0, s20, v1
    a.vread      v1, a4, s9
    s.movz       s9, #9
    s.movz       s20, #9
    a.vwrite     a0, s17, v1
    a.vread      v1, a4, s10
    s.movz       s10, #10
    s.movz       s17, #10
    a.vwrite     a0, s13, v1
    a.vread      v1, a4, s2
    s.movz       s2, #11
    s.movz       s13, #11
    a.vwrite     a0, s15, v1
    a.vread      v1, a4, s16
    s.movz       s15, #12
    s.movz       s16, #12
    a.vwrite     a0, s19, v1
    a.vread      v1, a4, s9
    s.movz       s9, #13
    s.movz       s19, #13
    a.vwrite     a0, s20, v1
    a.vread      v1, a4, s10
    s.movz       s10, #14
    s.movz       s20, #14
    a.vwrite     a0, s17, v1
    a.vread      v1, a4, s2
    s.movz       s2, #15
    s.movz       s17, #15
    a.vwrite     a0, s13, v1
    a.vread      v1, a4, s15
    s.add        s13, s14, s1
    s.movz       s15, #1
    a.vwrite     a0, s16, v1
    a.vread      v1, a4, s9
    a.vwrite     a0, s19, v1
    a.vread      v1, a4, s10
    a.vwrite     a0, s20, v1
    a.vread      v1, a4, s2
    a.vwrite     a0, s17, v1
    s.mov        s14, s13
    br.nz        s15, for_6
endfor_7:
    s.movz       s2, #0
    v.splat      v1, s12
    s.add        s4, s2, s3                      // the tile origin
    v.movi       v2, #1
    v.splat      v3, s4
    v.movi       v4, #0
    s.addi       s2, s4, #1
    s.movz       s6, #0
    v.cmp.lt     p1, v3, v1
    v.splat      v3, s2
    @p1 v.sel        v5, v2, v4
    s.add        s2, s6, s8                      // the tile origin
    v.movi       v2, #1
    v.movi       v4, #0
    s.mul        s6, s11, s5
    s.muli       s5, s8, #4                      // a runtime tile origin, x4
    v.splat      v6, s2
    v.cmp.lt     p1, v3, v1
    v.extract    s2, v5, #0
    s.movz       s8, #128
    @p1 v.sel        v3, v2, v4
    s.muli       s9, s3, #512                    // a runtime tile origin, x512
    v.splat      v2, s2
    v.movi       v4, #0
    v.add        v5, v0, v6
    v.splat      v0, s8
    s.muli       s2, s6, #4                      // a runtime tile origin, x4
    v.extract    s3, v3, #0
    v.splat      v3, s11
    v.splat      v6, s1
    s.add        s1, s7, s5                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s5, #0
    v.cmp.ne     p1, v2, v4
    v.cmp.lt     p2, v5, v0
    v.splat      v0, s3
    v.movi       v2, #0
    s.add        s3, s1, s9                      // the tile origin
    p.and        p3, p1, p2
    v.cmp.lt     p1, v3, v6
    s.addi       s1, s4, #2
    v.movi       v3, #1
    v.splat      v4, s1
    a.vread      v5, a0, s5
    s.add        s1, s3, s2                      // the tile origin
    v.movi       v6, #0
    s.addi       s2, s4, #3
    v.cmp.lt     p4, v4, v1
    v.splat      v4, s2
    @p4 v.sel        v7, v3, v6
    v.movi       v3, #1
    v.movi       v6, #0
    v.cmp.lt     p4, v4, v1
    v.extract    s2, v7, #0
    @p4 v.sel        v4, v3, v6
    p.and        p4, p3, p1
    s.movz       s3, #1
    v.cmp.ne     p3, v0, v2
    v.splat      v0, s2
    v.movi       v2, #0
    p.and        p5, p3, p2
    v.extract    s2, v4, #0
    @p4 v.st.w       [s1, #0], v5
    a.vread      v3, a0, s3
    s.addi       s3, s1, #512                    // row 1
    s.addi       s5, s4, #4
    v.movi       v4, #1
    v.splat      v5, s5
    v.movi       v6, #0
    p.and        p3, p5, p1
    v.cmp.lt     p4, v5, v1
    @p4 v.sel        v5, v4, v6
    s.movz       s5, #2
    v.cmp.ne     p4, v0, v2
    v.splat      v0, s2
    v.movi       v2, #0
    p.and        p5, p4, p2
    v.extract    s2, v5, #0
    s.addi       s6, s1, #1024                   // row 2
    p.and        p4, p5, p1
    @p3 v.st.w       [s3, #0], v3
    a.vread      v3, a0, s5
    s.addi       s3, s4, #5
    v.movi       v4, #1
    v.splat      v5, s3
    v.movi       v6, #0
    s.movz       s3, #3
    v.cmp.lt     p3, v5, v1
    @p3 v.sel        v5, v4, v6
    v.cmp.ne     p3, v0, v2
    v.splat      v0, s2
    v.movi       v2, #0
    p.and        p5, p3, p2
    v.extract    s2, v5, #0
    s.addi       s5, s1, #1536                   // row 3
    p.and        p3, p5, p1
    s.movz       s7, #4
    v.splat      v4, s2
    @p4 v.st.w       [s6, #0], v3
    a.vread      v3, a0, s3
    s.addi       s2, s4, #6
    v.movi       v5, #1
    v.splat      v6, s2
    v.movi       v7, #0
    v.cmp.ne     p4, v0, v2
    v.movi       v0, #0
    p.and        p5, p4, p2
    s.addi       s2, s1, #2048                   // row 4
    p.and        p4, p5, p1
    s.movz       s3, #5
    v.movi       v2, #0
    s.addi       s6, s1, #2560                   // row 5
    s.movz       s8, #6
    s.addi       s9, s1, #3072                   // row 6
    @p3 v.st.w       [s5, #0], v3
    v.cmp.lt     p3, v6, v1
    @p3 v.sel        v3, v5, v7
    a.vread      v5, a0, s7
    s.addi       s5, s4, #7
    v.movi       v6, #1
    v.splat      v7, s5
    v.movi       v8, #0
    v.extract    s5, v3, #0
    v.cmp.lt     p3, v7, v1
    @p3 v.sel        v3, v6, v8
    v.cmp.ne     p3, v4, v0
    v.splat      v0, s5
    p.and        p5, p3, p2
    v.extract    s5, v3, #0
    p.and        p3, p5, p1
    v.splat      v3, s5
    v.movi       v4, #0
    @p4 v.st.w       [s2, #0], v5
    a.vread      v5, a0, s3
    s.addi       s2, s4, #8
    v.movi       v6, #1
    v.splat      v7, s2
    v.movi       v8, #0
    v.cmp.ne     p4, v0, v2
    p.and        p5, p4, p2
    s.movz       s2, #7
    p.and        p4, p5, p1
    v.movi       v0, #0
    s.addi       s3, s1, #3584                   // row 7
    s.movz       s5, #8
    s.addi       s7, s1, #4096                   // row 8
    @p3 v.st.w       [s6, #0], v5
    v.cmp.lt     p3, v7, v1
    @p3 v.sel        v2, v6, v8
    a.vread      v5, a0, s8
    s.addi       s6, s4, #9
    v.movi       v6, #1
    v.splat      v7, s6
    v.movi       v8, #0
    v.extract    s6, v2, #0
    v.cmp.lt     p3, v7, v1
    @p3 v.sel        v2, v6, v8
    v.cmp.ne     p3, v3, v4
    v.splat      v3, s6
    p.and        p5, p3, p2
    v.extract    s6, v2, #0
    p.and        p3, p5, p1
    v.splat      v2, s6
    v.movi       v4, #0
    @p4 v.st.w       [s9, #0], v5
    a.vread      v5, a0, s2
    s.addi       s2, s4, #10
    v.movi       v6, #1
    v.splat      v7, s2
    v.movi       v8, #0
    v.cmp.ne     p4, v3, v0
    p.and        p5, p4, p2
    s.movz       s2, #9
    p.and        p4, p5, p1
    v.movi       v0, #0
    s.addi       s6, s1, #4608                   // row 9
    s.movz       s8, #10
    s.addi       s9, s1, #5120                   // row 10
    @p3 v.st.w       [s3, #0], v5
    v.cmp.lt     p3, v7, v1
    @p3 v.sel        v3, v6, v8
    a.vread      v5, a0, s5
    s.addi       s3, s4, #11
    v.movi       v6, #1
    v.splat      v7, s3
    v.movi       v8, #0
    v.extract    s3, v3, #0
    v.cmp.lt     p3, v7, v1
    @p3 v.sel        v3, v6, v8
    v.cmp.ne     p3, v2, v4
    v.splat      v2, s3
    p.and        p5, p3, p2
    v.extract    s3, v3, #0
    p.and        p3, p5, p1
    v.splat      v3, s3
    v.movi       v4, #0
    @p4 v.st.w       [s7, #0], v5
    a.vread      v5, a0, s2
    s.addi       s2, s4, #12
    v.movi       v6, #1
    v.splat      v7, s2
    v.movi       v8, #0
    v.cmp.ne     p4, v2, v0
    p.and        p5, p4, p2
    s.movz       s2, #11
    p.and        p4, p5, p1
    v.movi       v0, #0
    s.addi       s3, s1, #5632                   // row 11
    s.movz       s5, #12
    s.addi       s7, s1, #6144                   // row 12
    @p3 v.st.w       [s6, #0], v5
    v.cmp.lt     p3, v7, v1
    @p3 v.sel        v2, v6, v8
    a.vread      v5, a0, s8
    s.addi       s6, s4, #13
    v.movi       v6, #1
    v.splat      v7, s6
    v.movi       v8, #0
    v.extract    s6, v2, #0
    v.cmp.lt     p3, v7, v1
    @p3 v.sel        v2, v6, v8
    v.cmp.ne     p3, v3, v4
    v.splat      v3, s6
    p.and        p5, p3, p2
    v.extract    s6, v2, #0
    p.and        p3, p5, p1
    v.splat      v2, s6
    v.movi       v4, #0
    @p4 v.st.w       [s9, #0], v5
    a.vread      v5, a0, s2
    s.addi       s2, s4, #14
    v.movi       v6, #1
    v.splat      v7, s2
    v.movi       v8, #0
    v.cmp.ne     p4, v3, v0
    p.and        p5, p4, p2
    s.movz       s2, #13
    p.and        p4, p5, p1
    v.movi       v0, #0
    s.addi       s6, s1, #6656                   // row 13
    s.movz       s8, #14
    s.addi       s9, s1, #7168                   // row 14
    @p3 v.st.w       [s3, #0], v5
    v.cmp.lt     p3, v7, v1
    @p3 v.sel        v3, v6, v8
    a.vread      v5, a0, s5
    s.addi       s3, s4, #15
    v.movi       v6, #1
    v.splat      v7, s3
    v.movi       v8, #0
    v.extract    s3, v3, #0
    v.cmp.lt     p3, v7, v1
    @p3 v.sel        v1, v6, v8
    v.cmp.ne     p3, v2, v4
    v.splat      v2, s3
    p.and        p5, p3, p2
    v.extract    s3, v1, #0
    p.and        p3, p5, p1
    v.splat      v1, s3
    v.movi       v3, #0
    @p4 v.st.w       [s7, #0], v5
    a.vread      v4, a0, s2
    v.cmp.ne     p4, v2, v0
    p.and        p5, p4, p2
    s.movz       s2, #15
    p.and        p4, p5, p1
    s.addi       s3, s1, #7680                   // row 15
    @p3 v.st.w       [s6, #0], v4
    a.vread      v0, a0, s8
    v.cmp.ne     p3, v1, v3
    p.and        p5, p3, p2
    p.and        p2, p5, p1
    @p4 v.st.w       [s9, #0], v0
    a.vread      v0, a0, s2
    @p2 v.st.w       [s3, #0], v0
__rctx_next:
    exit
