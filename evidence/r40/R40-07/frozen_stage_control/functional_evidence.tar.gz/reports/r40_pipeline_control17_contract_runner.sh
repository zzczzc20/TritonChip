#!/bin/bash
source ~/tc_env/env.sh
cd /tmp/r40_pipeline_control17 || exit 2
export PYTHONPATH="$PWD/python:$PWD/compiler/python:$PWD/tools/asm"
CUDA_VISIBLE_DEVICES='' "$HOME/tc_env/torchenv/bin/python" tools/r40/contract_tests.py --reference /tmp/r40_pipeline_control17_contract_reference.json > /tmp/r40_pipeline_control17_contract.log 2>&1
rc=$?
printf '%s
' "$rc" > /tmp/r40_pipeline_control17_contract.exit
exit "$rc"
