#!/bin/bash
export GATE_DIR=~/r41g4_gate2
bash ~/r41g4_gate2/gate_g4.sh base > ~/r41g4_gate2/gate-base.out 2>&1
bash ~/r41g4_gate2/gate_g4.sh head > ~/r41g4_gate2/gate-head.out 2>&1
echo done > ~/r41g4_gate2/CHAIN_DONE
