    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s3, s4, s1
    .li       s1, #2576980378
    s.sub        s5, s2, s3
    s.movz       s2, #5
    s.xor        s3, s4, s5
    s.movz       s6, #0
    s.sub        s7, s3, s5
    s.movz       s3, #0
    s.mul        s8, s7, s1
    s.cmp.lt     s1, s2, s6
    s.movz       s6, #2
    s.sub        s9, s3, s1
    s.movz       s1, #1
    s.lshri      s3, s8, #32
    s.xor        s8, s5, s9
    s.sub        s5, s7, s3
    s.movz       s10, #0
    s.lshri      s11, s5, #1
    s.movz       s5, #0
    s.add        s12, s3, s11
    s.movz       s3, #0
    s.lshri      s11, s12, #2
    s.movz       s12, #0
    s.xor        s13, s11, s8
    s.cmp.lt     s14, s4, s5
    s.sub        s5, s13, s8
    s.sub        s8, s12, s14
    s.sub        s12, s6, s5
    s.muli       s6, s11, #5
    s.min.s      s11, s12, s1
    s.movz       s12, #0
    s.cmp.lt     s13, s11, s10
    s.movz       s10, #1
    s.sub        s14, s3, s13
    s.xor        s3, s4, s8
    s.rdspecial  s13, arg_base
    s.xor        s15, s2, s9
    s.movz       s16, #0
    s.sub        s17, s3, s8
    s.ld.d       s3, [s13, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.xor        s18, s11, s14
    s.sub        s19, s15, s9
    s.sub        s9, s7, s6
    s.ld.d       s6, [s13, #8]                   // arg_B: device_ptr64 at arg_base+8
    s.sub        s7, s18, s14
    s.ld.d       s9, [s13, #16]                  // in_ptr2: device_ptr64 at arg_base+16
    s.addi       s14, s12, #0
    s.ld.d       s12, [s13, #24]                 // in_ptr3: device_ptr64 at arg_base+24
    s.addi       s15, s16, #0
    s.ld.d       s16, [s13, #32]                 // in_ptr4: device_ptr64 at arg_base+32
    s.cmp.eq     s18, s7, s10
    s.ld.d       s10, [s13, #40]                 // out_ptr0: device_ptr64 at arg_base+40
    s.mov        s14, s17
    br.nz        s18, sdiv_done_1
    s.movz       s13, #0
    s.movz       s18, #31
    s.mov        s14, s13
    s.addi       s13, s18, #0
sdiv_2:
    s.lshr       s18, s17, s13
    s.shli       s19, s15, #1
    s.andi       s20, s18, #1
    s.movz       s18, #0
    s.or         s21, s19, s20
    s.movz       s19, #1
    s.cmp.geu    s20, s21, s7
    s.shl        s22, s19, s13
    s.sub        s19, s18, s20
    s.subi       s18, s13, #1
    s.and        s20, s7, s19
    s.and        s23, s22, s19
    s.sub        s19, s21, s20
    s.or         s20, s14, s23
    s.mov        s15, s19
    s.mov        s14, s20
    s.mov        s13, s18
    s.movz       s18, #0
    s.cmp.ge     s19, s13, s18
    br.nz        s19, sdiv_2
sdiv_done_1:
    s.movz       s7, #0
    s.movz       s13, #0
    s.cmp.lt     s14, s4, s7
    .li       s7, #2576980378
    s.sub        s17, s13, s14
    s.movz       s13, #0
    s.xor        s14, s4, s17
    s.movz       s4, #0
    s.sub        s18, s14, s17
    s.movz       s14, #0
    s.mul        s19, s18, s7
    s.cmp.lt     s7, s11, s13
    s.movz       s13, #0
    s.sub        s20, s14, s7
    s.movz       s7, #0
    s.lshri      s14, s19, #32
    s.cmp.lt     s19, s2, s13
    s.xor        s13, s11, s20
    s.xor        s11, s15, s8
    s.sub        s15, s13, s20
    s.sub        s13, s11, s8
    s.sub        s8, s18, s14
    s.add        s11, s5, s13
    s.lshri      s5, s8, #1
    s.movz       s8, #0
    s.add        s13, s14, s5
    s.sub        s5, s8, s19
    s.lshri      s8, s13, #2
    s.movz       s13, #0
    s.muli       s14, s8, #5
    s.movz       s8, #1
    s.xor        s19, s2, s5
    s.addi       s2, s13, #0
    s.cmp.eq     s13, s15, s8
    s.sub        s8, s18, s14
    s.movz       s14, #0
    s.xor        s18, s8, s17
    s.sub        s8, s19, s5
    s.sub        s5, s18, s17
    s.addi       s8, s14, #0
    s.cmp.lt     s14, s5, s4
    s.sub        s4, s7, s14
    s.xor        s7, s5, s4
    s.sub        s5, s7, s4
    s.mov        s2, s5
    br.nz        s13, sdiv_done_3
    s.movz       s7, #0
    s.movz       s13, #31
    s.mov        s2, s7
    s.addi       s7, s13, #0
sdiv_4:
    s.lshr       s13, s5, s7
    s.shli       s14, s8, #1
    s.andi       s17, s13, #1
    s.movz       s13, #0
    s.or         s18, s14, s17
    s.movz       s14, #1
    s.cmp.geu    s17, s18, s15
    s.shl        s19, s14, s7
    s.sub        s14, s13, s17
    s.subi       s13, s7, #1
    s.and        s17, s15, s14
    s.and        s21, s19, s14
    s.sub        s14, s18, s17
    s.or         s17, s2, s21
    s.mov        s8, s14
    s.mov        s2, s17
    s.mov        s7, s13
    s.movz       s13, #0
    s.cmp.ge     s14, s7, s13
    br.nz        s14, sdiv_4
sdiv_done_3:
    s.movz       s5, #16
    s.xor        s7, s4, s20
    s.mul        s4, s11, s5
    s.xor        s8, s2, s7
    v.iota       v0                              // arange(0, VLEN)
    s.sub        s2, s8, s7
    v.movi       v1, #26
    v.splat      v2, s4
    s.mul        s7, s2, s5
    v.movi       v3, #0
    v.add        v4, v2, v0
    s.movz       s8, #0
    v.splat      v2, s11
    v.splat      v5, s8
    v.splat      v6, s2
    v.splat      v7, s8
    v.splat      v8, s7
    v.sub        v9, v3, v4
    v.cmp.lt     p1, v4, v3
    v.cmp.lt     p2, v1, v3
    v.cmp.ge     p3, v2, v5
    v.sub        v2, v3, v1
    v.cmp.ge     p3, v6, v7
    v.add        v5, v8, v0
    v.movi       v0, #1
    @p1 v.sel        v5, v9, v4
    @p2 v.sel        v4, v2, v1
    v.movi       v1, #0
    v.movi       v2, #0
    s.movz       s2, #31
idiv_5:
    v.splat      v6, s2
    v.shl        v7, v2, v0
    v.cmp.lt     p2, v2, v3
    v.lshr       v8, v5, v6
    v.shl        v9, v0, v6
    s.subi       s11, s2, #1
    v.and        v6, v8, v0
    s.movz       s13, #0
    v.or         v8, v7, v6
    v.cmp.geu    p3, v8, v4
    p.or         p4, p2, p3
    v.sub        v6, v8, v4
    @p4 v.sel        v7, v9, v3
    @p4 v.sel        v9, v6, v8
    v.or         v6, v1, v7
    v.mov        v2, v9
    v.mov        v1, v6
    s.mov        s2, s11
    s.cmp.ge     s11, s2, s13
    br.nz        s11, idiv_5
    .li       s2, #2576980378
    v.sub        v0, v3, v2
    s.mul        s11, s7, s2
    v.iota       v1                              // arange(0, VLEN)
    @p1 v.sel        v3, v0, v2
    s.movz       s2, #6
    s.addi       s13, s8, #0
    s.lshri      s14, s11, #32
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    s.sub        s11, s7, s14
    s.lshri      s15, s11, #1
    s.add        s11, s14, s15
    s.lshri      s14, s11, #6
    s.muli       s11, s14, #80
    s.sub        s14, s7, s11
    v.splat      v0, s14
    v.add        v2, v0, v1
for_6:
    s.cmp.ge     s11, s13, s2
    br.nz        s11, endfor_7
    s.mul        s11, s13, s5
    s.rdspecial  s15, arg_base
    s.ld.d       s17, [s15, #48]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s15, role_id
    s.movz       s18, #1536
    s.mul        s19, s15, s18
    s.add        s15, s17, s19                   // this context's own scratch
    s.addi       s17, s15, #0
    v.splat      v0, s8
    s.movz       s18, #0
    s.add        s19, s18, s11                   // the tile origin
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v2, s19
    v.add        v4, v1, v2
    v.extract    s18, v3, #0
    v.splat      v1, s18
    s.movz       s18, #96
    v.splat      v2, s18
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s17, #0], v5
    s.addi       s18, s17, #64
    v.extract    s19, v3, #1
    v.splat      v1, s19
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s18, #0], v5
    s.addi       s18, s17, #128
    v.extract    s19, v3, #2
    v.splat      v1, s19
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s18, #0], v5
    s.addi       s18, s17, #192
    v.extract    s19, v3, #3
    v.splat      v1, s19
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s18, #0], v5
    s.addi       s18, s17, #256
    v.extract    s19, v3, #4
    v.splat      v1, s19
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s18, #0], v5
    s.addi       s18, s17, #320
    v.extract    s19, v3, #5
    v.splat      v1, s19
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s18, #0], v5
    s.addi       s18, s17, #384
    v.extract    s19, v3, #6
    v.splat      v1, s19
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s18, #0], v5
    s.addi       s18, s17, #448
    v.extract    s19, v3, #7
    v.splat      v1, s19
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s18, #0], v5
    s.addi       s18, s17, #512
    v.extract    s19, v3, #8
    v.splat      v1, s19
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s18, #0], v5
    s.addi       s18, s17, #576
    v.extract    s19, v3, #9
    v.splat      v1, s19
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s18, #0], v5
    s.addi       s18, s17, #640
    v.extract    s19, v3, #10
    v.splat      v1, s19
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s18, #0], v5
    s.addi       s18, s17, #704
    v.extract    s19, v3, #11
    v.splat      v1, s19
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s18, #0], v5
    s.addi       s18, s17, #768
    v.extract    s19, v3, #12
    v.splat      v1, s19
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s18, #0], v5
    s.addi       s18, s17, #832
    v.extract    s19, v3, #13
    v.splat      v1, s19
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s18, #0], v5
    s.addi       s18, s17, #896
    v.extract    s19, v3, #14
    v.splat      v1, s19
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s18, #0], v5
    s.addi       s18, s17, #960
    v.extract    s17, v3, #15
    v.splat      v1, s17
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v2, v0, v1
    v.st.w       [s18, #0], v2
    fence.acq_rel.device
    s.addi       s17, s15, #1024                 // 256 bytes of repack scratch
    // repack 16x16 f8E4M3FN through memory: there is no v.pack (ISA sec 8.4)
    s.addi       s18, s15, #0
    v.ld.w       v0, [s18, #0]
    v.ld.gather.b v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s17, #0], v1
    s.addi       s18, s15, #64
    v.ld.w       v0, [s18, #0]
    v.ld.gather.b v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s18, s17, #16                   // row 1
    v.st.b       [s18, #0], v1
    s.addi       s18, s15, #128
    v.ld.w       v0, [s18, #0]
    v.ld.gather.b v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s18, s17, #32                   // row 2
    v.st.b       [s18, #0], v1
    s.addi       s18, s15, #192
    v.ld.w       v0, [s18, #0]
    v.ld.gather.b v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s18, s17, #48                   // row 3
    v.st.b       [s18, #0], v1
    s.addi       s18, s15, #256
    v.ld.w       v0, [s18, #0]
    v.ld.gather.b v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s18, s17, #64                   // row 4
    v.st.b       [s18, #0], v1
    s.addi       s18, s15, #320
    v.ld.w       v0, [s18, #0]
    v.ld.gather.b v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s18, s17, #80                   // row 5
    v.st.b       [s18, #0], v1
    s.addi       s18, s15, #384
    v.ld.w       v0, [s18, #0]
    v.ld.gather.b v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s18, s17, #96                   // row 6
    v.st.b       [s18, #0], v1
    s.addi       s18, s15, #448
    v.ld.w       v0, [s18, #0]
    v.ld.gather.b v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s18, s17, #112                  // row 7
    v.st.b       [s18, #0], v1
    s.addi       s18, s15, #512
    v.ld.w       v0, [s18, #0]
    v.ld.gather.b v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s18, s17, #128                  // row 8
    v.st.b       [s18, #0], v1
    s.addi       s18, s15, #576
    v.ld.w       v0, [s18, #0]
    v.ld.gather.b v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s18, s17, #144                  // row 9
    v.st.b       [s18, #0], v1
    s.addi       s18, s15, #640
    v.ld.w       v0, [s18, #0]
    v.ld.gather.b v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s18, s17, #160                  // row 10
    v.st.b       [s18, #0], v1
    s.addi       s18, s15, #704
    v.ld.w       v0, [s18, #0]
    v.ld.gather.b v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s18, s17, #176                  // row 11
    v.st.b       [s18, #0], v1
    s.addi       s18, s15, #768
    v.ld.w       v0, [s18, #0]
    v.ld.gather.b v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s18, s17, #192                  // row 12
    v.st.b       [s18, #0], v1
    s.addi       s18, s15, #832
    v.ld.w       v0, [s18, #0]
    v.ld.gather.b v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s18, s17, #208                  // row 13
    v.st.b       [s18, #0], v1
    s.addi       s18, s15, #896
    v.ld.w       v0, [s18, #0]
    v.ld.gather.b v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s18, s17, #224                  // row 14
    v.st.b       [s18, #0], v1
    s.addi       s18, s15, #960
    v.ld.w       v0, [s18, #0]
    v.ld.gather.b v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s18, s17, #240                  // row 15
    v.st.b       [s18, #0], v1
    w.def        w0, #60, #4                     // v60..v63
    fence.acq_rel.device
    v.ld.w       v0, [s17, #0]
    v.mov        v60, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s18, s17, #64
    v.ld.w       v0, [s18, #0]
    v.mov        v61, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s18, s17, #128
    v.ld.w       v0, [s18, #0]
    v.mov        v62, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s18, s17, #192
    v.ld.w       v0, [s18, #0]
    v.mov        v63, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s17, s15, #1280                 // 256 bytes of repack scratch
    // repack 16x16 f8E4M3FN through memory: there is no v.pack (ISA sec 8.4)
    s.movz       s15, #0
    s.add        s18, s15, s11                   // the tile origin
    s.muli       s11, s14, #96                   // a runtime tile origin, x96
    s.add        s15, s18, s11                   // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    s.movz       s11, #96
    v.splat      v1, s11
    v.mul        v2, v0, v1
    v.splat      v0, s15
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s17, #0], v0
    s.addi       s11, s15, #1
    v.splat      v0, s11
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s6, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s11, s17, #16                   // row 1
    v.st.b       [s11, #0], v0
    s.addi       s11, s15, #2
    v.splat      v0, s11
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s6, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s11, s17, #32                   // row 2
    v.st.b       [s11, #0], v0
    s.addi       s11, s15, #3
    v.splat      v0, s11
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s6, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s11, s17, #48                   // row 3
    v.st.b       [s11, #0], v0
    s.addi       s11, s15, #4
    v.splat      v0, s11
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s6, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s11, s17, #64                   // row 4
    v.st.b       [s11, #0], v0
    s.addi       s11, s15, #5
    v.splat      v0, s11
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s6, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s11, s17, #80                   // row 5
    v.st.b       [s11, #0], v0
    s.addi       s11, s15, #6
    v.splat      v0, s11
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s6, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s11, s17, #96                   // row 6
    v.st.b       [s11, #0], v0
    s.addi       s11, s15, #7
    v.splat      v0, s11
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s6, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s11, s17, #112                  // row 7
    v.st.b       [s11, #0], v0
    s.addi       s11, s15, #8
    v.splat      v0, s11
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s6, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s11, s17, #128                  // row 8
    v.st.b       [s11, #0], v0
    s.addi       s11, s15, #9
    v.splat      v0, s11
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s6, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s11, s17, #144                  // row 9
    v.st.b       [s11, #0], v0
    s.addi       s11, s15, #10
    v.splat      v0, s11
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s6, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s11, s17, #160                  // row 10
    v.st.b       [s11, #0], v0
    s.addi       s11, s15, #11
    v.splat      v0, s11
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s6, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s11, s17, #176                  // row 11
    v.st.b       [s11, #0], v0
    s.addi       s11, s15, #12
    v.splat      v0, s11
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s6, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s11, s17, #192                  // row 12
    v.st.b       [s11, #0], v0
    s.addi       s11, s15, #13
    v.splat      v0, s11
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s6, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s11, s17, #208                  // row 13
    v.st.b       [s11, #0], v0
    s.addi       s11, s15, #14
    v.splat      v0, s11
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s6, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s11, s17, #224                  // row 14
    v.st.b       [s11, #0], v0
    s.addi       s11, s15, #15
    v.splat      v0, s11
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s6, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s11, s17, #240                  // row 15
    v.st.b       [s11, #0], v0
    w.def        w1, #56, #4                     // v56..v59
    fence.acq_rel.device
    v.ld.w       v0, [s17, #0]
    v.mov        v56, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s11, s17, #64
    v.ld.w       v0, [s11, #0]
    v.mov        v57, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s11, s17, #128
    v.ld.w       v0, [s11, #0]
    v.mov        v58, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s11, s17, #192
    v.ld.w       v0, [s11, #0]
    v.mov        v59, v0                         // hand off through the shared window (sec 7.3)
    mb.arm       s11, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.e4m3 a0, v60, v56, s11
    mb.wait      s11
    s.add        s15, s13, s1
    s.mov        s13, s15
    s.movz       s15, #1
    br.nz        s15, for_6
endfor_7:
    s.ld.w       s1, [s9, #0]                    // one element, not a vector
    v.splat      v0, s1
    s.ld.w       s1, [s12, #0]                   // one element, not a vector
    v.splat      v1, s1
    s.muli       s1, s7, #2                      // a runtime tile origin, x2
    s.add        s2, s16, s1                     // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s1, s7, #2                      // a runtime tile origin, x2
    s.add        s3, s10, s1                     // the tile origin
    s.muli       s1, s4, #160                    // a runtime tile origin, x160
    s.add        s5, s3, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    a.vread      v2, a0, s1
    vf.mul       v3, v0, v1
    vf.mul       v4, v2, v3
    s.movz       s1, #0
    s.add        s3, s1, s4                      // the tile origin
    v.splat      v2, s3
    s.movz       s1, #26
    v.splat      v3, s1
    v.cmp.lt     p1, v2, v3
    s.movz       s1, #0
    s.add        s4, s1, s7                      // the tile origin
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v5, s4
    v.add        v6, v2, v5
    s.movz       s1, #80
    v.splat      v2, s1
    v.cmp.lt     p2, v6, v2
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v5, v2
    vf.add       v2, v4, v5
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s3
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s5, #0], v4
    s.movz       s1, #1
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s3, #1
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #160                    // row 1
    s.addi       s4, s3, #1
    v.splat      v2, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #2
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s3, #2
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #320                    // row 2
    s.addi       s4, s3, #2
    v.splat      v2, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #3
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s3, #3
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #480                    // row 3
    s.addi       s4, s3, #3
    v.splat      v2, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #4
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s3, #4
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #640                    // row 4
    s.addi       s4, s3, #4
    v.splat      v2, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #5
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s3, #5
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #800                    // row 5
    s.addi       s4, s3, #5
    v.splat      v2, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #6
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s3, #6
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #960                    // row 6
    s.addi       s4, s3, #6
    v.splat      v2, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #7
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s3, #7
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #1120                   // row 7
    s.addi       s4, s3, #7
    v.splat      v2, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #8
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s3, #8
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #1280                   // row 8
    s.addi       s4, s3, #8
    v.splat      v2, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #9
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s3, #9
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #1440                   // row 9
    s.addi       s4, s3, #9
    v.splat      v2, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #10
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s3, #10
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #1600                   // row 10
    s.addi       s4, s3, #10
    v.splat      v2, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #11
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s3, #11
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #1760                   // row 11
    s.addi       s4, s3, #11
    v.splat      v2, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #12
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s3, #12
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #1920                   // row 12
    s.addi       s4, s3, #12
    v.splat      v2, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #13
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s3, #13
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #2080                   // row 13
    s.addi       s4, s3, #13
    v.splat      v2, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #14
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s3, #14
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #2240                   // row 14
    s.addi       s4, s3, #14
    v.splat      v2, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #15
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v0, v2, v4
    s.addi       s1, s3, #15
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s2, #0]
    vf.cvt.bf16.f32 v2, v1
    vf.add       v1, v0, v2
    vf.cvt.f32.bf16 v0, v1
    s.addi       s1, s5, #2400                   // row 15
    s.addi       s2, s3, #15
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
__rctx_next:
    exit
