    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.shli       s2, s4, #4                      // x16 as a shift
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s2
    v.movi       v2, #0
    v.movi       v3, #0
    v.add        v4, v1, v0
    v.movi       v0, #256
    v.movi       v1, #6
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    v.sub        v6, v3, v4
    @p1 v.sel        v7, v5, v4
    s.shli       s4, s2, #1                      // element offset -> bytes (x2)
    v.cmp.lt     p2, v4, v3
    s.add        s2, s3, s4                      // &in_ptr0[...]
    v.cmp.lt     p3, v4, v0
    @p2 v.sel        v0, v6, v4
    v.movi       v4, #63
    v.lshr       v5, v7, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s2, #0]
    v.and        v6, v0, v4
    v.sub        v0, v2, v5
    s.movz       s2, #32832
    v.splat      v4, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.sub        v7, v3, v6
    @p1 v.sel        v8, v0, v5
    v.movi       v0, #64
    @p2 v.sel        v5, v7, v6
    v.mul        v6, v8, v4
    v.sub        v4, v3, v0
    v.sub        v7, v2, v0
    v.add        v8, v5, v6
    v.cmp.lt     p1, v0, v3
    v.cmp.lt     p2, v0, v2
    s.ld.d       s2, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    @p1 v.sel        v2, v4, v0
    @p2 v.sel        v2, v7, v0
    @p3 v.st.scatter.h [s2, v8], v1
__rctx_next:
    exit
