

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 2, 'num_stages': 2}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 2, 'num_stages': 3}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 2, 'num_stages': 4}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 4, 'num_stages': 2}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 4, 'num_stages': 3}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 4, 'num_stages': 4}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 8, 'num_stages': 2}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 8, 'num_stages': 3}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 8, 'num_stages': 4}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 16, 'num_stages': 2}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 16, 'num_stages': 3}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 16, 'num_stages': 4}, {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 2, 'num_stages': 2}, {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 2, 'num_stages': 3}, {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 2, 'num_stages': 4}, {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 4, 'num_stages': 2}, {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 4, 'num_stages': 3}, {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 4, 'num_stages': 4}, {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 8, 'num_stages': 2}, {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 8, 'num_stages': 3}, {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 8, 'num_stages': 4}, {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 16, 'num_stages': 2}, {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 16, 'num_stages': 3}, {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 16, 'num_stages': 4}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 2, 'num_stages': 2}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 2, 'num_stages': 3}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 2, 'num_stages': 4}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 4, 'num_stages': 2}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 4, 'num_stages': 3}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 4, 'num_stages': 4}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 8, 'num_stages': 2}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 8, 'num_stages': 3}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 8, 'num_stages': 4}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 16, 'num_stages': 2}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 16, 'num_stages': 3}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 16, 'num_stages': 4}, {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 2, 'num_stages': 2}, {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 2, 'num_stages': 3}, {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 2, 'num_stages': 4}, {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 4, 'num_stages': 2}, {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 4, 'num_stages': 3}, {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 4, 'num_stages': 4}, {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 8, 'num_stages': 2}, {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 8, 'num_stages': 3}, {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 8, 'num_stages': 4}, {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 16, 'num_stages': 2}, {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 16, 'num_stages': 3}, {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 16, 'num_stages': 4}],
    inductor_meta={'grid_type': 'PrecomputedGrid', 'precomputed_grids': [{'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 2, 'num_stages': 2}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 2, 'num_stages': 3}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 2, 'num_stages': 4}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 4, 'num_stages': 2}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 4, 'num_stages': 3}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 4, 'num_stages': 4}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 8, 'num_stages': 2}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 8, 'num_stages': 3}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 8, 'num_stages': 4}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 16, 'num_stages': 2}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 16, 'num_stages': 3}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 16, 'num_stages': 4}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 2, 'num_stages': 2}, 'python': ['1', '1', '1'], 'cpp': ['1L', '1L', '1L'], 'python_slow': ['1', '1', '1']}, {'config': {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 2, 'num_stages': 3}, 'python': ['1', '1', '1'], 'cpp': ['1L', '1L', '1L'], 'python_slow': ['1', '1', '1']}, {'config': {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 2, 'num_stages': 4}, 'python': ['1', '1', '1'], 'cpp': ['1L', '1L', '1L'], 'python_slow': ['1', '1', '1']}, {'config': {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 4, 'num_stages': 2}, 'python': ['1', '1', '1'], 'cpp': ['1L', '1L', '1L'], 'python_slow': ['1', '1', '1']}, {'config': {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 4, 'num_stages': 3}, 'python': ['1', '1', '1'], 'cpp': ['1L', '1L', '1L'], 'python_slow': ['1', '1', '1']}, {'config': {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 4, 'num_stages': 4}, 'python': ['1', '1', '1'], 'cpp': ['1L', '1L', '1L'], 'python_slow': ['1', '1', '1']}, {'config': {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 8, 'num_stages': 2}, 'python': ['1', '1', '1'], 'cpp': ['1L', '1L', '1L'], 'python_slow': ['1', '1', '1']}, {'config': {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 8, 'num_stages': 3}, 'python': ['1', '1', '1'], 'cpp': ['1L', '1L', '1L'], 'python_slow': ['1', '1', '1']}, {'config': {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 8, 'num_stages': 4}, 'python': ['1', '1', '1'], 'cpp': ['1L', '1L', '1L'], 'python_slow': ['1', '1', '1']}, {'config': {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 16, 'num_stages': 2}, 'python': ['1', '1', '1'], 'cpp': ['1L', '1L', '1L'], 'python_slow': ['1', '1', '1']}, {'config': {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 16, 'num_stages': 3}, 'python': ['1', '1', '1'], 'cpp': ['1L', '1L', '1L'], 'python_slow': ['1', '1', '1']}, {'config': {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 16, 'num_stages': 4}, 'python': ['1', '1', '1'], 'cpp': ['1L', '1L', '1L'], 'python_slow': ['1', '1', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 2, 'num_stages': 2}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 2, 'num_stages': 3}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 2, 'num_stages': 4}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 4, 'num_stages': 2}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 4, 'num_stages': 3}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 4, 'num_stages': 4}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 8, 'num_stages': 2}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 8, 'num_stages': 3}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 8, 'num_stages': 4}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 16, 'num_stages': 2}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 16, 'num_stages': 3}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 16, 'num_stages': 4}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 2, 'num_stages': 2}, 'python': ['1', '4', '1'], 'cpp': ['1L', '4L', '1L'], 'python_slow': ['1', '4', '1']}, {'config': {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 2, 'num_stages': 3}, 'python': ['1', '4', '1'], 'cpp': ['1L', '4L', '1L'], 'python_slow': ['1', '4', '1']}, {'config': {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 2, 'num_stages': 4}, 'python': ['1', '4', '1'], 'cpp': ['1L', '4L', '1L'], 'python_slow': ['1', '4', '1']}, {'config': {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 4, 'num_stages': 2}, 'python': ['1', '4', '1'], 'cpp': ['1L', '4L', '1L'], 'python_slow': ['1', '4', '1']}, {'config': {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 4, 'num_stages': 3}, 'python': ['1', '4', '1'], 'cpp': ['1L', '4L', '1L'], 'python_slow': ['1', '4', '1']}, {'config': {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 4, 'num_stages': 4}, 'python': ['1', '4', '1'], 'cpp': ['1L', '4L', '1L'], 'python_slow': ['1', '4', '1']}, {'config': {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 8, 'num_stages': 2}, 'python': ['1', '4', '1'], 'cpp': ['1L', '4L', '1L'], 'python_slow': ['1', '4', '1']}, {'config': {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 8, 'num_stages': 3}, 'python': ['1', '4', '1'], 'cpp': ['1L', '4L', '1L'], 'python_slow': ['1', '4', '1']}, {'config': {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 8, 'num_stages': 4}, 'python': ['1', '4', '1'], 'cpp': ['1L', '4L', '1L'], 'python_slow': ['1', '4', '1']}, {'config': {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 16, 'num_stages': 2}, 'python': ['1', '4', '1'], 'cpp': ['1L', '4L', '1L'], 'python_slow': ['1', '4', '1']}, {'config': {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 16, 'num_stages': 3}, 'python': ['1', '4', '1'], 'cpp': ['1L', '4L', '1L'], 'python_slow': ['1', '4', '1']}, {'config': {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 16, 'num_stages': 4}, 'python': ['1', '4', '1'], 'cpp': ['1L', '4L', '1L'], 'python_slow': ['1', '4', '1']}], 'extra_launcher_args': [], 'declared_constexpr_names': ['BLOCK_SIZE_M', 'BLOCK_SIZE_N', 'BLOCK_SIZE_K', 'GROUP_SIZE_M'], 'kernel_name': 'w8a8_tensor_dynamic_fp8_matmul_kernel_1', 'backend_hash': 'A4E79D10F359390E2037525D201E9899BAFFEBA619AB1AC552E7E01BB639922A', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    triton_meta={'signature': {'A': '*fp8e4nv', 'B': '*fp8e4nv', 'C': '*bf16', 'As': '*fp32', 'Bs': '*fp32', 'M': 'i32', 'N': 'i32', 'K': 'i32', 'stride_am': 'i32', 'stride_ak': 'constexpr', 'stride_bk': 'constexpr', 'stride_bn': 'i32', 'stride_cm': 'i32', 'stride_cn': 'constexpr', 'stride_as_m': 'constexpr', 'BLOCK_SIZE_M': 'constexpr', 'BLOCK_SIZE_N': 'constexpr', 'BLOCK_SIZE_K': 'constexpr', 'GROUP_SIZE_M': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'stride_ak': 1, 'stride_bk': 1, 'stride_cn': 1, 'stride_as_m': 1, 'BLOCK_SIZE_M': 16, 'GROUP_SIZE_M': 8}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]], (11,): [['tt.divisibility', 16]], (12,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def w8a8_tensor_dynamic_fp8_matmul_kernel(
    A,  # (M, K) pre-quantized FP8 activations
    B,  # (N, K) FP8 weights
    C,  # (M, N) output
    As,  # (M,) per-token activation scales
    Bs,  # scalar/(1,) per-tensor weight scale
    # Shape
    M,
    N,
    K,
    # Strides
    stride_am,
    stride_ak,
    stride_bk,
    stride_bn,
    stride_cm,
    stride_cn,
    stride_as_m,
    # Meta-parameters
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """Tensor-scale FP8 GEMM kernel.

    Computes ``C = A @ B.T`` with one activation scale per row and one
    weight scale for the full matrix.
    Uses a 2D grid with swizzle for L2 cache locality on B tiles.
    """
    pid_m, pid_n, offs_am, offs_bn, offs_k = _swizzle_offsets(
        M, N, BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M
    )
    a_ptrs = A + offs_am[:, None] * stride_am + offs_k[None, :] * stride_ak
    b_ptrs = B + offs_k[:, None] * stride_bk + offs_bn[None, :] * stride_bn

    a_s = tl.load(As + offs_am * stride_as_m)
    b_s = tl.load(Bs)

    # Accumulate raw dot products, apply scales once after the loop.
    accumulator = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    for k in range(0, tl.cdiv(K, BLOCK_SIZE_K)):
        k_remaining = K - k * BLOCK_SIZE_K
        a = tl.load(a_ptrs, mask=offs_k[None, :] < k_remaining, other=0.0)
        b = tl.load(b_ptrs, mask=offs_k[:, None] < k_remaining, other=0.0)
        accumulator += tl.dot(a, b)
        a_ptrs += BLOCK_SIZE_K * stride_ak
        b_ptrs += BLOCK_SIZE_K * stride_bk

    accumulator = accumulator * a_s[:, None] * b_s

    _store_masked(
        C,
        accumulator,
        pid_m,
        pid_n,
        M,
        N,
        stride_cm,
        stride_cn,
        BLOCK_SIZE_M,
        BLOCK_SIZE_N,
    )

@triton.jit
def _swizzle_offsets(
    M,
    N,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """2D-grid tile scheduling shared by the kernels below: swizzle the
    ``(pid_m, pid_n)`` program ids for L2 locality on B, then build the operand
    offset vectors. Returns ``(pid_m, pid_n, offs_am, offs_bn, offs_k)`` — the
    swizzled ids (reused by the output store) and the ``%``-wrapped row/col offsets
    plus the K range."""
    pid_m = tl.program_id(axis=0)
    pid_n = tl.program_id(axis=1)
    num_pid_m = tl.cdiv(M, BLOCK_SIZE_M)
    num_pid_n = tl.cdiv(N, BLOCK_SIZE_N)
    pid_m, pid_n = tl.swizzle2d(pid_m, pid_n, num_pid_m, num_pid_n, GROUP_SIZE_M)
    offs_am = (pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)) % M
    offs_bn = (pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)) % N
    offs_k = tl.arange(0, BLOCK_SIZE_K)
    return pid_m, pid_n, offs_am, offs_bn, offs_k

@triton.jit
def _store_masked(
    C,
    accumulator,
    pid_m,
    pid_n,
    M,
    N,
    stride_cm,
    stride_cn,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
):
    """Shared output epilogue of the kernels below: cast the fp32 accumulator to
    ``C``'s dtype and store the ``(BLOCK_SIZE_M, BLOCK_SIZE_N)`` tile at the swizzled
    ``(pid_m, pid_n)``, masked to the ``(M, N)`` bounds."""
    c = accumulator.to(C.dtype.element_ty)
    offs_cm = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_cn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    c_ptrs = C + stride_cm * offs_cm[:, None] + stride_cn * offs_cn[None, :]
    c_mask = (offs_cm[:, None] < M) & (offs_cn[None, :] < N)
    tl.store(c_ptrs, c, mask=c_mask)
