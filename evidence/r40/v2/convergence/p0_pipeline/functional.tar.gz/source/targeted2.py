import subprocess,pathlib,json
root=pathlib.Path.cwd();out=pathlib.Path('/tmp/r40_p0_targeted2');out.mkdir(exist_ok=False);results=[]
def execute(name,command,expected=0):
 p=subprocess.run(command,capture_output=True,text=True,timeout=180);(out/(name+'.log')).write_text(p.stdout+p.stderr)
 if p.returncode!=expected:raise RuntimeError(name+' '+p.stdout+p.stderr)
 return p.stdout+p.stderr
for ranges in (0,1):
 args=['iverilog','-g2012','-I','rtl/common','-s','tb_nuca_slice','-Ptb_nuca_slice.SYNC_TAG_BANK=1','-Ptb_nuca_slice.REGISTER_VICTIM_OWNER=1','-Ptb_nuca_slice.EPOCH_CHURN=1',f'-Ptb_nuca_slice.DCO_REGISTERED_RANGES={ranges}','-Ptb_nuca_slice.POLICY=74','-o',str(out/'test.vvp'),'rtl/nuca/tnca_nuca_slice.v','tb/common/tnca_dram_model.v','tb/nuca/tb_nuca_slice.v']
 execute('build_'+str(ranges),args);text=execute('run_'+str(ranges),['vvp',str(out/'test.vvp'),'+nreq=2000','+seed=7','+min_wb=1']);assert 'PASS' in text.splitlines(),text
 results.append(dict(ranges=ranges,output=text));print(text,flush=True)
mut=root/'rtl/nuca/tnca_nuca_slice.v';s=mut.read_text();needle='if (REGISTER_VICTIM_OWNER && owner_epoch_q != dco_owner_epoch)';assert s.count(needle)==1
(out/'mutant.v').write_text(s.replace(needle,"if (1'b0)"))
args[-3]=str(out/'mutant.v');execute('mutation_build',args);text=execute('mutation_run',['vvp',str(out/'test.vvp'),'+nreq=2000','+seed=7'],1);assert 'stale owner classification consumed instead of retried' in text,text
for ports in (3,8):
 execute('tmu_build'+str(ports),['iverilog','-g2012','-I','rtl/common','-s','tb_tmu_registered_ranges',f'-Ptb_tmu_registered_ranges.PORTS={ports}','-o',str(out/'test.vvp'),'rtl/nuca/tnca_tmu.v','tb/nuca/tb_tmu_registered_ranges.v'])
 text=execute('tmu_run'+str(ports),['vvp',str(out/'test.vvp')]);assert 'TMU REGISTERED RANGES PASS' in text,text
 print(text,flush=True)
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
