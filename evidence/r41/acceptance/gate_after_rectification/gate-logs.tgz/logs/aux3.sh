#!/bin/bash
# Third pass on the final rectification tree (product code identical to the gate
# head tree 116f747): the unit tests whose files changed after it, and the FMA miter
# with Verilator on PATH (the aux2 miter failed on a missing PATH entry).
set -u
source ~/tc_env/env.sh
export PATH=$HOME/tc_env/root/usr/bin:$PATH
G=~/r41fix_gate; P=~/tc_env/torchenv/bin/python; T=final; L=$G/logs/aux3-final
mkdir -p $L; : > $L/exit_codes.txt
stamp() { date -u +%FT%TZ; }
lane() { local n=$1 d=$2; shift 2
  echo "# $(stamp) start $n in $d: $*" > $L/$n.log
  ( cd $d && export PYTHONPATH=$d/python:$d/compiler/python:$d && echo "# PYTHONPATH=$PYTHONPATH" && nice -n 10 "$@" ) >> $L/$n.log 2>&1; local rc=$?
  echo "# $(stamp) end $n exit $rc" >> $L/$n.log; echo "$n $rc" >> $L/exit_codes.txt; }
echo "aux3 $T $(cat $G/$T/.gate_commit) started $(stamp)" > $L/run.txt
for t in tools/r40/large_grid_tests.py tools/performance_harness/test_hbm8.py \
         tools/performance_harness/test_stage2_acceptance.py; do
  lane unit-$(echo $t | tr / _ | sed 's/\.py$//') $G/$T $P $t
done
lane fma-miter $G/$T bash $G/miter/run_miter.sh $G/fma_ref $G/$T/rtl 1000000 1
echo "finished $(stamp)" >> $L/run.txt
