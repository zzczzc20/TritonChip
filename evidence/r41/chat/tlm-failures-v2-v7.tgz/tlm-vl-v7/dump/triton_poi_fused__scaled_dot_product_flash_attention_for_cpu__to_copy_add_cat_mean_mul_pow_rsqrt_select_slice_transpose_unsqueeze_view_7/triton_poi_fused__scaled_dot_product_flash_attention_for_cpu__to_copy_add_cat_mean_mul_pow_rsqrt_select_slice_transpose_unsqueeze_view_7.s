    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    v.movi       v1, #0
    v.movi       v2, #0
    v.movi       v3, #7
    v.movi       v4, #127
    v.splat      v5, s2
    v.movi       v6, #128
    v.movi       v7, #18
    v.add        v8, v5, v0
    v.movi       v0, #0
    v.sub        v5, v2, v6
    v.sub        v9, v1, v8
    v.cmp.lt     p1, v8, v1
    v.sub        v10, v2, v8
    @p1 v.sel        v11, v9, v8
    v.cmp.lt     p2, v8, v2
    @p2 v.sel        v9, v10, v8
    v.lshr       v10, v11, v3
    v.sub        v3, v1, v6
    v.and        v11, v9, v4
    v.sub        v4, v1, v10
    v.sub        v9, v0, v7
    v.sub        v12, v2, v11
    @p1 v.sel        v13, v4, v10
    s.rdspecial  s1, arg_base
    v.cmp.lt     p1, v6, v2
    v.sub        v2, v0, v13
    v.cmp.lt     p3, v6, v1
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v1, #1
    @p1 v.sel        v1, v5, v6
    v.cmp.lt     p1, v13, v0
    @p2 v.sel        v1, v12, v11
    v.cmp.lt     p2, v7, v0
    v.movi       v4, #1
    @p3 v.sel        v4, v3, v6
    v.movi       v3, #1
    @p1 v.sel        v4, v2, v13
    @p2 v.sel        v2, v9, v7
    s.ld.d       s4, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.movi       v5, #0
    v.movi       v7, #0
    s.movz       s5, #31
    s.ld.d       s6, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s7, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s8, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s9, [s1, #40]                   // in_ptr5: device_ptr64 at arg_base+40
    s.ld.d       s10, [s1, #48]                  // out_ptr0: device_ptr64 at arg_base+48
idiv_1:
    v.splat      v9, s5
    v.shl        v10, v7, v3
    v.cmp.lt     p2, v7, v0
    v.lshr       v11, v4, v9
    v.shl        v12, v3, v9
    s.subi       s1, s5, #1
    v.and        v9, v11, v3
    s.movz       s11, #0
    v.or         v11, v10, v9
    v.cmp.geu    p3, v11, v2
    p.or         p4, p2, p3
    v.sub        v9, v11, v2
    @p4 v.sel        v10, v12, v0
    @p4 v.sel        v12, v9, v11
    v.or         v9, v5, v10
    v.mov        v7, v12
    v.mov        v5, v9
    s.mov        s5, s1
    s.cmp.ge     s1, s5, s11
    br.nz        s1, idiv_1
    v.movi       v2, #2304
    v.movi       v3, #0
    v.sub        v4, v0, v7
    v.movi       v0, #1
    v.sub        v5, v3, v8
    v.sub        v9, v3, v2
    v.cmp.lt     p2, v8, v3
    v.cmp.lt     p3, v2, v3
    @p1 v.sel        v10, v4, v7
    @p2 v.sel        v4, v5, v8
    @p3 v.sel        v5, v9, v2
    v.movi       v2, #0
    v.movi       v7, #0
    s.movz       s1, #31
idiv_2:
    v.splat      v9, s1
    v.shl        v11, v7, v0
    v.cmp.lt     p1, v7, v3
    v.lshr       v12, v4, v9
    v.shl        v13, v0, v9
    s.subi       s5, s1, #1
    v.and        v9, v12, v0
    s.movz       s11, #0
    v.or         v12, v11, v9
    v.cmp.geu    p4, v12, v5
    p.or         p5, p1, p4
    v.sub        v9, v12, v5
    @p5 v.sel        v11, v13, v3
    @p5 v.sel        v13, v9, v12
    v.or         v9, v2, v11
    v.mov        v7, v13
    v.mov        v2, v9
    s.mov        s1, s5
    s.cmp.ge     s5, s1, s11
    br.nz        s5, idiv_2
    p.xor        p1, p2, p3
    v.sub        v0, v3, v2
    @p1 v.sel        v3, v0, v2
    v.ld.gather.h v0, [s3, v1]                   // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v2, v0
    s.movz       s1, #128
    v.mul        v0, v3, v6
    v.add        v4, v1, v0
    s.movz       s1, #2048
    v.movi       v0, #2048
    v.mul        v5, v10, v0
    v.add        v0, v4, v5
    v.ld.gather.h v4, [s4, v0]                   // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v0, v4
    v.movi       v4, #16
    v.mul        v5, v10, v4
    v.add        v4, v3, v5
    v.ld.gather.w v3, [s6, v4]                   // index is in elements (ISA sec 9.1)
    s.movz       s1, #64
    v.movi       v4, #64
    v.mul        v5, v10, v4
    v.movi       v6, #0
    v.movi       v7, #1
    v.cmp.lt     p1, v1, v6
    v.cmp.lt     p2, v4, v6
    v.sub        v7, v6, v1
    @p1 v.sel        v9, v7, v1
    v.sub        v1, v6, v4
    @p2 v.sel        v7, v1, v4
    v.movi       v1, #63
    v.and        v7, v9, v1
    v.sub        v1, v6, v7
    @p1 v.sel        v6, v1, v7
    v.add        v1, v5, v6
    v.ld.gather.w v7, [s7, v1]                   // index is in elements (ISA sec 9.1)
    s.shli       s1, s2, #1                      // element offset -> bytes (x2)
    s.add        s3, s8, s1                      // &in_ptr4[...]
    v.ld.h       v9, [s3, #0]
    vf.cvt.bf16.f32 v10, v9
    v.ld.gather.w v9, [s9, v1]                   // index is in elements (ISA sec 9.1)
    .li       s1, #1124073472
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v11, v1                         // ISA 8.8: <= 2**-22 relative
    .li       s1, #1065353216
    v.splat      v12, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v13, v1, v11, v12
    vf.fms       v12, v11, v13, v11
    vf.neg       v13, v12                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v13, v13
    @p1 v.sel        v12, v13, v11
    vf.mul       v11, v3, v12                    // a/y: faithful quotient
    vf.fms       v13, v11, v1, v3
    vf.fms       v1, v13, v12, v11
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v11
    .li       s1, #897988541
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v11, v1, v3
    v.rsqrt.approx v1, v11                       // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v1, v1
    .li       s1, #1077936128
    v.splat      v12, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v13, v11, v3, v12
    .li       s1, #3204448256
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v11, v1, v3
    vf.mul       v3, v11, v13                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v11, v3, v1
    vf.mul       v1, v0, v11
    vf.mul       v0, v2, v1
    v.movi       v1, #0
    v.movi       v2, #1
    v.cmp.lt     p1, v8, v1
    v.cmp.lt     p2, v4, v1
    v.sub        v2, v1, v8
    @p1 v.sel        v3, v2, v8
    v.sub        v2, v1, v4
    @p2 v.sel        v8, v2, v4
    v.movi       v2, #63
    v.and        v4, v3, v2
    v.sub        v2, v1, v4
    @p1 v.sel        v1, v2, v4
    v.movi       v2, #0
    v.movi       v3, #0
    v.extract    s1, v1, #0
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v2, s1, #0
    s.lshri      s3, s1, #32
    v.insert     v3, s3, #0
    v.extract    s1, v1, #1
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v2, s1, #1
    s.lshri      s3, s1, #32
    v.insert     v3, s3, #1
    v.extract    s1, v1, #2
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v2, s1, #2
    s.lshri      s3, s1, #32
    v.insert     v3, s3, #2
    v.extract    s1, v1, #3
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v2, s1, #3
    s.lshri      s3, s1, #32
    v.insert     v3, s3, #3
    v.extract    s1, v1, #4
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v2, s1, #4
    s.lshri      s3, s1, #32
    v.insert     v3, s3, #4
    v.extract    s1, v1, #5
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v2, s1, #5
    s.lshri      s3, s1, #32
    v.insert     v3, s3, #5
    v.extract    s1, v1, #6
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v2, s1, #6
    s.lshri      s3, s1, #32
    v.insert     v3, s3, #6
    v.extract    s1, v1, #7
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v2, s1, #7
    s.lshri      s3, s1, #32
    v.insert     v3, s3, #7
    v.extract    s1, v1, #8
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v2, s1, #8
    s.lshri      s3, s1, #32
    v.insert     v3, s3, #8
    v.extract    s1, v1, #9
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v2, s1, #9
    s.lshri      s3, s1, #32
    v.insert     v3, s3, #9
    v.extract    s1, v1, #10
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v2, s1, #10
    s.lshri      s3, s1, #32
    v.insert     v3, s3, #10
    v.extract    s1, v1, #11
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v2, s1, #11
    s.lshri      s3, s1, #32
    v.insert     v3, s3, #11
    v.extract    s1, v1, #12
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v2, s1, #12
    s.lshri      s3, s1, #32
    v.insert     v3, s3, #12
    v.extract    s1, v1, #13
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v2, s1, #13
    s.lshri      s3, s1, #32
    v.insert     v3, s3, #13
    v.extract    s1, v1, #14
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v2, s1, #14
    s.lshri      s3, s1, #32
    v.insert     v3, s3, #14
    v.extract    s1, v1, #15
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v2, s1, #15
    s.lshri      s3, s1, #32
    v.insert     v3, s3, #15
    v.movi       v1, #0
    v.extract    s1, v2, #0
    v.extract    s3, v3, #0
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #2
    s.cmp.ge     s4, s3, s1
    v.insert     v1, s4, #0
    v.extract    s1, v2, #1
    v.extract    s3, v3, #1
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #2
    s.cmp.ge     s4, s3, s1
    v.insert     v1, s4, #1
    v.extract    s1, v2, #2
    v.extract    s3, v3, #2
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #2
    s.cmp.ge     s4, s3, s1
    v.insert     v1, s4, #2
    v.extract    s1, v2, #3
    v.extract    s3, v3, #3
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #2
    s.cmp.ge     s4, s3, s1
    v.insert     v1, s4, #3
    v.extract    s1, v2, #4
    v.extract    s3, v3, #4
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #2
    s.cmp.ge     s4, s3, s1
    v.insert     v1, s4, #4
    v.extract    s1, v2, #5
    v.extract    s3, v3, #5
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #2
    s.cmp.ge     s4, s3, s1
    v.insert     v1, s4, #5
    v.extract    s1, v2, #6
    v.extract    s3, v3, #6
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #2
    s.cmp.ge     s4, s3, s1
    v.insert     v1, s4, #6
    v.extract    s1, v2, #7
    v.extract    s3, v3, #7
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #2
    s.cmp.ge     s4, s3, s1
    v.insert     v1, s4, #7
    v.extract    s1, v2, #8
    v.extract    s3, v3, #8
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #2
    s.cmp.ge     s4, s3, s1
    v.insert     v1, s4, #8
    v.extract    s1, v2, #9
    v.extract    s3, v3, #9
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #2
    s.cmp.ge     s4, s3, s1
    v.insert     v1, s4, #9
    v.extract    s1, v2, #10
    v.extract    s3, v3, #10
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #2
    s.cmp.ge     s4, s3, s1
    v.insert     v1, s4, #10
    v.extract    s1, v2, #11
    v.extract    s3, v3, #11
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #2
    s.cmp.ge     s4, s3, s1
    v.insert     v1, s4, #11
    v.extract    s1, v2, #12
    v.extract    s3, v3, #12
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #2
    s.cmp.ge     s4, s3, s1
    v.insert     v1, s4, #12
    v.extract    s1, v2, #13
    v.extract    s3, v3, #13
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #2
    s.cmp.ge     s4, s3, s1
    v.insert     v1, s4, #13
    v.extract    s1, v2, #14
    v.extract    s3, v3, #14
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #2
    s.cmp.ge     s4, s3, s1
    v.insert     v1, s4, #14
    v.extract    s1, v2, #15
    v.extract    s3, v3, #15
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #2
    s.cmp.ge     s4, s3, s1
    v.insert     v1, s4, #15
    v.movi       v4, #0
    v.cmp.ne     p1, v1, v4
    v.movi       v1, #0
    v.extract    s1, v2, #0
    v.extract    s3, v3, #0
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #60
    s.cmp.lt     s4, s3, s1
    v.insert     v1, s4, #0
    v.extract    s1, v2, #1
    v.extract    s3, v3, #1
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #60
    s.cmp.lt     s4, s3, s1
    v.insert     v1, s4, #1
    v.extract    s1, v2, #2
    v.extract    s3, v3, #2
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #60
    s.cmp.lt     s4, s3, s1
    v.insert     v1, s4, #2
    v.extract    s1, v2, #3
    v.extract    s3, v3, #3
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #60
    s.cmp.lt     s4, s3, s1
    v.insert     v1, s4, #3
    v.extract    s1, v2, #4
    v.extract    s3, v3, #4
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #60
    s.cmp.lt     s4, s3, s1
    v.insert     v1, s4, #4
    v.extract    s1, v2, #5
    v.extract    s3, v3, #5
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #60
    s.cmp.lt     s4, s3, s1
    v.insert     v1, s4, #5
    v.extract    s1, v2, #6
    v.extract    s3, v3, #6
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #60
    s.cmp.lt     s4, s3, s1
    v.insert     v1, s4, #6
    v.extract    s1, v2, #7
    v.extract    s3, v3, #7
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #60
    s.cmp.lt     s4, s3, s1
    v.insert     v1, s4, #7
    v.extract    s1, v2, #8
    v.extract    s3, v3, #8
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #60
    s.cmp.lt     s4, s3, s1
    v.insert     v1, s4, #8
    v.extract    s1, v2, #9
    v.extract    s3, v3, #9
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #60
    s.cmp.lt     s4, s3, s1
    v.insert     v1, s4, #9
    v.extract    s1, v2, #10
    v.extract    s3, v3, #10
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #60
    s.cmp.lt     s4, s3, s1
    v.insert     v1, s4, #10
    v.extract    s1, v2, #11
    v.extract    s3, v3, #11
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #60
    s.cmp.lt     s4, s3, s1
    v.insert     v1, s4, #11
    v.extract    s1, v2, #12
    v.extract    s3, v3, #12
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #60
    s.cmp.lt     s4, s3, s1
    v.insert     v1, s4, #12
    v.extract    s1, v2, #13
    v.extract    s3, v3, #13
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #60
    s.cmp.lt     s4, s3, s1
    v.insert     v1, s4, #13
    v.extract    s1, v2, #14
    v.extract    s3, v3, #14
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #60
    s.cmp.lt     s4, s3, s1
    v.insert     v1, s4, #14
    v.extract    s1, v2, #15
    v.extract    s3, v3, #15
    s.shli       s4, s3, #32
    s.or         s3, s1, s4
    s.movz       s1, #60
    s.cmp.lt     s4, s3, s1
    v.insert     v1, s4, #15
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    .li       s1, #-2
    v.movi       v1, #-2
    v.add        v2, v6, v1
    v.movi       v1, #3
    v.movi       v3, #0
    v.movi       v4, #1
    v.cmp.lt     p3, v2, v3
    v.cmp.lt     p4, v1, v3
    v.sub        v6, v3, v2
    @p3 v.sel        v8, v6, v2
    v.sub        v6, v3, v1
    @p4 v.sel        v11, v6, v1
    v.movi       v6, #0
    v.movi       v12, #0
    s.movz       s1, #31
idiv_3:
    v.splat      v13, s1
    v.shl        v14, v12, v4
    v.cmp.lt     p4, v12, v3
    v.lshr       v15, v8, v13
    v.shl        v16, v4, v13
    s.subi       s3, s1, #1
    v.and        v13, v15, v4
    s.movz       s4, #0
    v.or         v15, v14, v13
    v.cmp.geu    p5, v15, v11
    p.or         p6, p4, p5
    v.sub        v13, v15, v11
    @p6 v.sel        v14, v16, v3
    @p6 v.sel        v16, v13, v15
    v.or         v13, v6, v14
    v.mov        v12, v16
    v.mov        v6, v13
    s.mov        s1, s3
    s.cmp.ge     s3, s1, s4
    br.nz        s3, idiv_3
    v.sub        v4, v3, v12
    v.movi       v3, #0
    v.movi       v6, #0
    @p3 v.sel        v8, v4, v12
    v.extract    s1, v8, #0
    v.extract    s3, v8, #1
    s.shli       s4, s1, #32
    s.shli       s1, s3, #32
    s.ashri      s3, s4, #32
    v.extract    s4, v8, #2
    s.lshri      s5, s3, #32
    s.ashri      s6, s1, #32
    v.insert     v3, s3, #0
    v.insert     v6, s5, #0
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v8, #3
    s.ashri      s5, s1, #32
    v.insert     v3, s6, #1
    v.insert     v6, s3, #1
    s.shli       s1, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v8, #4
    s.ashri      s6, s1, #32
    v.insert     v3, s5, #2
    v.insert     v6, s3, #2
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v8, #5
    s.ashri      s5, s1, #32
    v.insert     v3, s6, #3
    v.insert     v6, s3, #3
    s.shli       s1, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v8, #6
    s.ashri      s6, s1, #32
    v.insert     v3, s5, #4
    v.insert     v6, s3, #4
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v8, #7
    s.ashri      s5, s1, #32
    v.insert     v3, s6, #5
    v.insert     v6, s3, #5
    s.shli       s1, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v8, #8
    s.ashri      s6, s1, #32
    v.insert     v3, s5, #6
    v.insert     v6, s3, #6
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v8, #9
    s.ashri      s5, s1, #32
    v.insert     v3, s6, #7
    v.insert     v6, s3, #7
    s.shli       s1, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v8, #10
    s.ashri      s6, s1, #32
    v.insert     v3, s5, #8
    v.insert     v6, s3, #8
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v8, #11
    s.ashri      s5, s1, #32
    v.insert     v3, s6, #9
    v.insert     v6, s3, #9
    s.shli       s1, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v8, #12
    s.ashri      s6, s1, #32
    v.insert     v3, s5, #10
    v.insert     v6, s3, #10
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v8, #13
    s.ashri      s5, s1, #32
    v.insert     v3, s6, #11
    v.insert     v6, s3, #11
    s.shli       s1, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v8, #14
    s.ashri      s6, s1, #32
    v.insert     v3, s5, #12
    v.insert     v6, s3, #12
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v8, #15
    s.ashri      s5, s1, #32
    v.insert     v3, s6, #13
    v.insert     v6, s3, #13
    s.shli       s1, s4, #32
    s.lshri      s3, s5, #32
    s.ashri      s4, s1, #32
    v.insert     v3, s5, #14
    v.insert     v6, s3, #14
    s.lshri      s1, s4, #32
    v.insert     v3, s4, #15
    v.insert     v6, s1, #15
    s.movz       s1, #0
    v.extract    s3, v3, #0
    v.extract    s4, v6, #0
    v.extract    s5, v6, #1
    s.shli       s6, s4, #32
    v.movi       v4, #0
    s.or         s4, s3, s6
    v.extract    s3, v3, #1
    s.shli       s6, s5, #32
    s.cmp.eq     s5, s4, s1
    v.extract    s1, v6, #2
    s.or         s4, s3, s6
    s.movz       s3, #0
    v.insert     v4, s5, #0
    v.extract    s5, v3, #2
    s.shli       s6, s1, #32
    s.cmp.eq     s1, s4, s3
    v.extract    s3, v6, #3
    s.or         s4, s5, s6
    s.movz       s5, #0
    v.insert     v4, s1, #1
    v.extract    s1, v3, #3
    s.shli       s6, s3, #32
    s.cmp.eq     s3, s4, s5
    v.extract    s4, v6, #4
    s.or         s5, s1, s6
    s.movz       s1, #0
    v.insert     v4, s3, #2
    v.extract    s3, v3, #4
    s.shli       s6, s4, #32
    s.cmp.eq     s4, s5, s1
    v.extract    s1, v6, #5
    s.or         s5, s3, s6
    s.movz       s3, #0
    v.insert     v4, s4, #3
    v.extract    s4, v3, #5
    s.shli       s6, s1, #32
    s.cmp.eq     s1, s5, s3
    v.extract    s3, v6, #6
    s.or         s5, s4, s6
    s.movz       s4, #0
    v.insert     v4, s1, #4
    v.extract    s1, v3, #6
    s.shli       s6, s3, #32
    s.cmp.eq     s3, s5, s4
    v.extract    s4, v6, #7
    s.or         s5, s1, s6
    s.movz       s1, #0
    v.insert     v4, s3, #5
    v.extract    s3, v3, #7
    s.shli       s6, s4, #32
    s.cmp.eq     s4, s5, s1
    v.extract    s1, v6, #8
    s.or         s5, s3, s6
    s.movz       s3, #0
    v.insert     v4, s4, #6
    v.extract    s4, v3, #8
    s.shli       s6, s1, #32
    s.cmp.eq     s1, s5, s3
    v.extract    s3, v6, #9
    s.or         s5, s4, s6
    s.movz       s4, #0
    v.insert     v4, s1, #7
    v.extract    s1, v3, #9
    s.shli       s6, s3, #32
    s.cmp.eq     s3, s5, s4
    v.extract    s4, v6, #10
    s.or         s5, s1, s6
    s.movz       s1, #0
    v.insert     v4, s3, #8
    v.extract    s3, v3, #10
    s.shli       s6, s4, #32
    s.cmp.eq     s4, s5, s1
    v.extract    s1, v6, #11
    s.or         s5, s3, s6
    s.movz       s3, #0
    v.insert     v4, s4, #9
    v.extract    s4, v3, #11
    s.shli       s6, s1, #32
    s.cmp.eq     s1, s5, s3
    v.extract    s3, v6, #12
    s.or         s5, s4, s6
    s.movz       s4, #0
    v.insert     v4, s1, #10
    v.extract    s1, v3, #12
    s.shli       s6, s3, #32
    s.cmp.eq     s3, s5, s4
    v.extract    s4, v6, #13
    s.or         s5, s1, s6
    s.movz       s1, #0
    v.insert     v4, s3, #11
    v.extract    s3, v3, #13
    s.shli       s6, s4, #32
    s.cmp.eq     s4, s5, s1
    v.extract    s1, v6, #14
    s.or         s5, s3, s6
    s.movz       s3, #0
    v.insert     v4, s4, #12
    v.extract    s4, v3, #14
    s.shli       s6, s1, #32
    s.cmp.eq     s1, s5, s3
    v.extract    s3, v6, #15
    s.or         s5, s4, s6
    s.movz       s4, #0
    v.insert     v4, s1, #13
    v.extract    s1, v3, #15
    s.shli       s6, s3, #32
    s.cmp.eq     s3, s5, s4
    s.or         s4, s1, s6
    s.movz       s1, #0
    v.insert     v4, s3, #14
    s.cmp.eq     s3, s4, s1
    v.movi       v3, #0
    v.insert     v4, s3, #15
    v.movi       v6, #0
    v.sub        v11, v3, v2
    v.sub        v12, v3, v1
    p.and        p3, p1, p2
    v.cmp.ne     p1, v4, v6
    v.cmp.lt     p2, v2, v3
    v.cmp.lt     p4, v1, v3
    p.and        p5, p3, p1
    v.movi       v4, #1
    @p2 v.sel        v6, v11, v2
    @p4 v.sel        v11, v12, v1
    v.movi       v12, #0
    v.movi       v13, #0
    s.movz       s1, #31
idiv_4:
    v.splat      v14, s1
    v.shl        v15, v13, v4
    v.cmp.lt     p1, v13, v3
    v.lshr       v16, v6, v14
    v.shl        v17, v4, v14
    s.subi       s3, s1, #1
    v.and        v14, v16, v4
    s.movz       s4, #0
    v.or         v16, v15, v14
    v.cmp.geu    p3, v16, v11
    p.or         p6, p1, p3
    v.sub        v14, v16, v11
    @p6 v.sel        v15, v17, v3
    @p6 v.sel        v17, v14, v16
    v.or         v14, v12, v15
    v.mov        v13, v17
    v.mov        v12, v14
    s.mov        s1, s3
    s.cmp.ge     s3, s1, s4
    br.nz        s3, idiv_4
    v.sub        v4, v3, v12
    p.xor        p1, p2, p4
    v.movi       v3, #1
    @p1 v.sel        v6, v4, v12
    v.movi       v4, #0
    v.movi       v11, #2306
    v.sub        v12, v6, v3
    v.cmp.ne     p1, v8, v4
    v.cmp.lt     p2, v2, v4
    @p1 v.sel        v2, v12, v6
    .li       s1, #1050163184
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s1, s2, #2                      // element offset -> bytes (x4)
    @p2 v.sel        v4, v2, v6
    s.add        s2, s10, s1                     // &out_ptr0[...]
    s.movz       s1, #1
    v.mul        v2, v4, v1
    s.movz       s1, #3
    s.movz       s1, #2306
    v.add        v1, v2, v11
    v.add        v2, v1, v5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v1, [s7, v2]               // index is in elements (ISA sec 9.1)
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v4, [s9, v2]               // index is in elements (ISA sec 9.1)
    @p5 v.sel        v2, v1, v7
    vf.mul       v1, v0, v2
    @p5 v.sel        v0, v4, v9
    vf.mul       v2, v10, v0
    vf.add       v0, v1, v2
    vf.mul       v1, v0, v3
    v.st.w       [s2, #0], v1
__rctx_next:
    exit
