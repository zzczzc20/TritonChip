#!/bin/bash
source ~/tc_env/env.sh
cd /tmp/r40_pipeline_control13 || exit 2
export PYTHONPATH="$PWD/python:$PWD/compiler/python:$PWD/tools/asm"
"$HOME/tc_env/torchenv/bin/python" -c "from tnca import device; device.prepare('core-vrf-sync-v5')" > /tmp/r40_pipeline_control15_prepare.log 2>&1
rc=$?
printf '%s
' "$rc" > /tmp/r40_pipeline_control15_prepare.exit
if [ "$rc" != 0 ]; then exit "$rc"; fi
CUDA_VISIBLE_DEVICES='' TNCA_PIPELINE=1 "$HOME/tc_env/torchenv/bin/python" tools/r39/rctx_roles_tests.py --only gemm_one_step gemm_odd_steps gemm_grid_3x2 gemm_carried_pointers --json /tmp/r40_pipeline_control15_native.json > /tmp/r40_pipeline_control15_native.log 2>&1
rc=$?
printf '%s
' "$rc" > /tmp/r40_pipeline_control15_native.exit
CUDA_VISIBLE_DEVICES='' TNCA_PIPELINE=1 "$HOME/tc_env/torchenv/bin/python" tools/r40/native_pipeline_tests.py --stages 1 > /tmp/r40_pipeline_control15_torch.log 2>&1
rc=$?
printf '%s
' "$rc" > /tmp/r40_pipeline_control15_torch.exit
exit "$rc"
