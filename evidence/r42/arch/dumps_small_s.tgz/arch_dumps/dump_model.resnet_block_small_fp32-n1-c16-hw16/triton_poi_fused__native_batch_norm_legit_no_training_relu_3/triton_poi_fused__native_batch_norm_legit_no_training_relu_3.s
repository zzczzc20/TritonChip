    s.rdspecial  s1, arg_base
    s.movz       s2, #256
    s.ld.d       s3, [s1, #0]                    // in_out_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #0
    s.rdspecial  s5, role_id
    s.rdspecial  s6, npid.x
    s.ld.d       s7, [s1, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    s.ld.d       s8, [s1, #16]                   // in_ptr1: device_ptr64 at arg_base+16
    s.ld.d       s9, [s1, #24]                   // in_ptr2: device_ptr64 at arg_base+24
    s.ld.d       s10, [s1, #32]                  // in_ptr3: device_ptr64 at arg_base+32
__rctx_program:
    // tiled element-wise program: 256 lanes as 2 tiles of 128 (2 tensor-engine transfers, one load buffer(s))
    s.mul        s1, s5, s2
    s.addi       s11, s4, #0
tiles_1:
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #16
    v.movi       v2, #32
    v.movi       v3, #48
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v5, #64
    v.movi       v6, #80
    v.movi       v7, #96
    v.iota       v8                              // arange(0, VLEN)
    v.movi       v9, #112
    // tile 0 of the iteration: lanes t0 + 0
    s.add        s12, s1, s11
    v.add        v10, v0, v1
    v.splat      v1, s12
    v.add        v11, v0, v2
    v.add        v2, v0, v3
    v.add        v3, v4, v5
    v.add        v5, v4, v6
    v.add        v6, v4, v7
    v.add        v4, v8, v9
    v.add        v7, v1, v0
    v.add        v0, v1, v10
    v.add        v9, v1, v11
    v.add        v10, v1, v2
    v.add        v2, v1, v3
    v.add        v3, v1, v5
    v.add        v5, v1, v6
    v.add        v6, v1, v4
    v.movi       v1, #0
    v.movi       v4, #0
    v.movi       v11, #15
    v.sub        v12, v1, v7
    v.sub        v13, v4, v0
    v.cmp.lt     p1, v7, v1
    v.cmp.lt     p2, v0, v4
    @p1 v.sel        v14, v12, v7
    @p2 v.sel        v7, v13, v0
    v.movi       v0, #15
    v.and        v12, v14, v11
    // tile 1 of the iteration: lanes t0 + 128
    s.addi       s13, s11, #128
    v.and        v11, v7, v0
    v.sub        v0, v1, v12
    v.movi       v7, #16
    v.iota       v13                             // arange(0, VLEN)
    @p1 v.sel        v14, v0, v12
    v.movi       v0, #32
    v.movi       v12, #48
    v.movi       v15, #64
    v.iota       v16                             // arange(0, VLEN)
    v.movi       v17, #80
    v.movi       v18, #96
    v.movi       v19, #112
    s.add        s14, s1, s13
    v.sub        v20, v4, v11
    v.splat      v21, s14
    v.add        v22, v8, v7
    v.movi       v7, #0
    @p2 v.sel        v23, v20, v11
    v.add        v11, v13, v0
    v.sub        v0, v7, v9
    v.cmp.lt     p1, v9, v7
    v.add        v20, v13, v12
    @p1 v.sel        v12, v0, v9
    v.add        v0, v13, v15
    v.movi       v9, #15
    v.add        v13, v16, v17
    v.add        v15, v16, v18
    v.movi       v17, #0
    v.and        v18, v12, v9
    v.add        v9, v16, v19
    v.sub        v12, v17, v10
    v.cmp.lt     p2, v10, v17
    v.movi       v16, #15
    @p2 v.sel        v19, v12, v10
    v.sub        v10, v7, v18
    v.movi       v12, #16
    v.movi       v24, #0
    v.and        v25, v19, v16
    @p1 v.sel        v16, v10, v18
    v.cmp.lt     p1, v2, v24
    v.sub        v10, v17, v25
    v.movi       v18, #16
    v.movi       v19, #16
    @p2 v.sel        v26, v10, v25
    v.movi       v10, #16
    v.movi       v25, #16
    v.sub        v27, v1, v12
    v.sub        v28, v4, v18
    v.sub        v29, v7, v19
    v.sub        v30, v17, v10
    v.cmp.lt     p2, v12, v1
    v.sub        v1, v24, v2
    v.sub        v31, v24, v25
    v.cmp.lt     p3, v18, v4
    @p1 v.sel        v4, v1, v2
    @p2 v.sel        v1, v27, v12
    v.movi       v1, #0
    v.movi       v2, #15
    v.movi       v12, #16
    v.sub        v27, v1, v3
    v.cmp.lt     p2, v3, v1
    v.and        v32, v4, v2
    @p2 v.sel        v2, v27, v3
    v.sub        v3, v1, v12
    v.sub        v4, v24, v32
    @p3 v.sel        v27, v28, v18
    v.movi       v18, #0
    v.movi       v27, #15
    @p1 v.sel        v28, v4, v32
    v.cmp.lt     p1, v5, v18
    v.and        v4, v2, v27
    v.movi       v2, #16
    v.cmp.lt     p3, v19, v7
    v.sub        v7, v18, v5
    v.sub        v27, v1, v4
    v.sub        v32, v18, v2
    @p1 v.sel        v33, v7, v5
    @p2 v.sel        v5, v27, v4
    v.cmp.lt     p2, v10, v17
    @p3 v.sel        v4, v29, v19
    v.movi       v4, #0
    v.movi       v7, #15
    v.movi       v17, #16
    v.sub        v19, v4, v6
    v.cmp.lt     p3, v6, v4
    v.and        v27, v33, v7
    @p3 v.sel        v7, v19, v6
    v.sub        v6, v4, v17
    v.sub        v19, v18, v27
    @p2 v.sel        v29, v30, v10
    v.movi       v10, #15
    @p1 v.sel        v29, v19, v27
    s.shli       s13, s12, #2
    v.and        v19, v7, v10
    s.add        s12, s3, s13
    v.cmp.lt     p1, v25, v24
    v.sub        v7, v4, v19
    v.ld.w       v10, [s12, #0]
    v.cmp.lt     p2, v12, v1
    @p3 v.sel        v1, v7, v19
    v.cmp.lt     p3, v2, v18
    @p1 v.sel        v7, v31, v25
    v.add        v7, v21, v8
    v.add        v8, v21, v22
    v.add        v18, v21, v11
    v.add        v11, v21, v20
    v.add        v19, v21, v0
    v.add        v0, v21, v13
    v.add        v13, v21, v15
    v.add        v15, v21, v9
    v.movi       v9, #16
    v.cmp.lt     p1, v17, v4
    @p2 v.sel        v4, v3, v12
    v.movi       v3, #0
    v.movi       v4, #15
    v.ld.w       v12, [s12, #64]
    v.sub        v20, v3, v7
    v.cmp.lt     p2, v7, v3
    v.movi       v21, #16
    @p2 v.sel        v22, v20, v7
    v.sub        v7, v3, v9
    @p3 v.sel        v20, v32, v2
    v.movi       v2, #0
    v.movi       v20, #15
    v.and        v24, v22, v4
    v.sub        v4, v2, v8
    v.cmp.lt     p3, v8, v2
    v.sub        v22, v3, v24
    @p3 v.sel        v25, v4, v8
    v.movi       v4, #16
    @p2 v.sel        v8, v22, v24
    v.and        v22, v25, v20
    v.sub        v20, v2, v21
    v.ld.w       v24, [s12, #128]
    v.sub        v25, v2, v22
    v.cmp.lt     p2, v9, v3
    @p1 v.sel        v3, v6, v17
    v.movi       v3, #0
    v.movi       v6, #15
    @p3 v.sel        v17, v25, v22
    v.sub        v22, v3, v18
    v.cmp.lt     p1, v18, v3
    v.sub        v25, v3, v4
    @p1 v.sel        v27, v22, v18
    v.cmp.lt     p3, v21, v2
    @p2 v.sel        v2, v7, v9
    v.and        v2, v27, v6
    v.cmp.lt     p2, v4, v3
    @p3 v.sel        v6, v20, v21
    v.sub        v6, v3, v2
    @p2 v.sel        v3, v25, v4
    v.ld.w       v3, [s12, #192]
    @p1 v.sel        v4, v6, v2
    v.ld.w       v2, [s12, #256]
    v.movi       v6, #16
    v.ld.w       v7, [s12, #320]
    v.movi       v9, #0
    v.ld.w       v18, [s12, #384]
    v.cmp.lt     p1, v11, v9
    v.ld.w       v20, [s12, #448]
    v.movi       v21, #0
    v.movi       v22, #0
    v.movi       v25, #0
    v.movi       v27, #0
    v.sub        v30, v9, v11
    v.sub        v31, v21, v19
    v.sub        v32, v22, v0
    v.sub        v33, v25, v13
    v.cmp.lt     p2, v19, v21
    v.cmp.lt     p3, v0, v22
    @p1 v.sel        v34, v30, v11
    v.movi       v11, #15
    @p2 v.sel        v30, v31, v19
    v.movi       v19, #15
    @p3 v.sel        v31, v32, v0
    v.movi       v0, #15
    v.movi       v32, #15
    v.and        v35, v34, v11
    v.and        v11, v30, v19
    v.and        v19, v31, v0
    v.sub        v0, v9, v35
    v.sub        v30, v21, v11
    v.sub        v31, v22, v19
    @p1 v.sel        v34, v0, v35
    v.cmp.lt     p1, v13, v25
    @p1 v.sel        v0, v33, v13
    @p2 v.sel        v13, v30, v11
    v.cmp.lt     p2, v15, v27
    v.and        v11, v0, v32
    @p3 v.sel        v0, v31, v19
    v.movi       v19, #16
    v.sub        v30, v25, v11
    v.movi       v31, #16
    v.movi       v32, #16
    @p1 v.sel        v33, v30, v11
    v.movi       v11, #16
    v.sub        v30, v9, v6
    v.sub        v35, v21, v19
    v.sub        v36, v22, v31
    v.sub        v37, v25, v32
    v.cmp.lt     p1, v6, v9
    v.sub        v9, v27, v15
    v.sub        v38, v27, v11
    v.cmp.lt     p3, v19, v21
    @p2 v.sel        v21, v9, v15
    @p1 v.sel        v9, v30, v6
    v.movi       v6, #15
    s.shli       s13, s14, #2
    v.cmp.lt     p1, v31, v22
    v.and        v9, v21, v6
    s.add        s14, s3, s13
    @p3 v.sel        v6, v35, v19
    v.ld.gather.w v6, [s8, v14]                  // index is in elements (ISA sec 9.1)
    v.sub        v15, v27, v9
    v.cmp.lt     p3, v32, v25
    @p1 v.sel        v19, v36, v31
    @p2 v.sel        v19, v15, v9
    v.cmp.lt     p1, v11, v27
    @p3 v.sel        v9, v37, v32
    @p1 v.sel        v9, v38, v11
    v.ld.gather.w v9, [s8, v23]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.w v11, [s8, v16]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v15, [s8, v26]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v21, [s8, v28]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v22, [s8, v5]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.w v25, [s8, v29]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v27, [s8, v1]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.w v30, [s7, v14]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v31, [s7, v23]                 // index is in elements (ISA sec 9.1)
    vf.sub       v32, v10, v30
    v.ld.gather.w v10, [s7, v16]                 // index is in elements (ISA sec 9.1)
    vf.sub       v30, v12, v31
    v.ld.gather.w v12, [s7, v26]                 // index is in elements (ISA sec 9.1)
    vf.sub       v31, v24, v10
    v.ld.gather.w v10, [s7, v28]                 // index is in elements (ISA sec 9.1)
    vf.sub       v24, v3, v12
    v.ld.gather.w v3, [s7, v5]                   // index is in elements (ISA sec 9.1)
    vf.sub       v12, v2, v10
    v.ld.gather.w v2, [s7, v29]                  // index is in elements (ISA sec 9.1)
    vf.sub       v10, v7, v3
    v.ld.gather.w v3, [s7, v1]                   // index is in elements (ISA sec 9.1)
    vf.sub       v7, v18, v2
    v.ld.gather.w v2, [s9, v14]                  // index is in elements (ISA sec 9.1)
    vf.sub       v18, v20, v3
    v.ld.gather.w v3, [s9, v23]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.w v20, [s9, v16]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v35, [s9, v26]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v36, [s9, v28]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v37, [s9, v5]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.w v38, [s9, v29]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v39, [s9, v1]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.w v40, [s10, v14]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v14, [s10, v23]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v23, [s10, v16]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v16, [s10, v26]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v26, [s10, v28]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v28, [s10, v5]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v5, [s10, v29]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v29, [s10, v1]                 // index is in elements (ISA sec 9.1)
    v.ld.w       v1, [s14, #0]
    .li       s13, #925353388
    v.splat      v41, s13                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.ld.w       v42, [s14, #64]
    vf.add       v43, v6, v41
    v.ld.w       v6, [s14, #128]
    vf.add       v44, v9, v41
    v.ld.w       v9, [s14, #192]
    vf.add       v45, v11, v41
    v.ld.w       v11, [s14, #256]
    vf.add       v46, v15, v41
    v.ld.w       v15, [s14, #320]
    vf.add       v47, v21, v41
    v.ld.w       v21, [s14, #384]
    .li       s13, #925353388
    v.splat      v41, s13                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.ld.w       v48, [s14, #448]
    vf.add       v49, v22, v41
    vf.add       v22, v25, v41
    vf.add       v25, v27, v41
    v.rsqrt.approx v27, v43                      // ISA 8.8: <= 2**-22 relative
    v.rsqrt.approx v41, v44                      // ISA 8.8: <= 2**-22 relative
    v.rsqrt.approx v50, v45                      // ISA 8.8: <= 2**-22 relative
    v.rsqrt.approx v51, v46                      // ISA 8.8: <= 2**-22 relative
    v.rsqrt.approx v52, v47                      // ISA 8.8: <= 2**-22 relative
    v.rsqrt.approx v53, v49                      // ISA 8.8: <= 2**-22 relative
    v.rsqrt.approx v54, v22                      // ISA 8.8: <= 2**-22 relative
    .li       s13, #1077936128
    v.splat      v55, s13                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s13, #3204448256
    v.splat      v56, s13                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v57, v27, v27
    vf.mul       v58, v41, v41
    vf.mul       v59, v50, v50
    vf.fms       v60, v43, v57, v55
    v.rsqrt.approx v43, v25                      // ISA 8.8: <= 2**-22 relative
    vf.fms       v57, v44, v58, v55
    vf.mul       v44, v51, v51
    vf.fms       v58, v45, v59, v55
    vf.mul       v45, v52, v52
    vf.fms       v59, v46, v44, v55
    vf.mul       v44, v53, v53
    vf.fms       v46, v47, v45, v55
    vf.mul       v45, v54, v54
    vf.fms       v47, v49, v44, v55
    vf.mul       v44, v27, v56
    vf.fms       v49, v22, v45, v55
    vf.mul       v22, v41, v56
    vf.mul       v45, v44, v60                   // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.mul       v44, v50, v56
    vf.mul       v60, v22, v57                   // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.mul       v22, v51, v56
    vf.cmp.o     p1, v45, v45
    vf.mul       v57, v44, v58                   // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.mul       v44, v52, v56
    vf.mul       v58, v22, v59                   // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.mul       v22, v43, v43
    vf.cmp.o     p2, v60, v60
    vf.cmp.o     p3, v57, v57
    vf.mul       v59, v44, v46                   // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.mul       v44, v53, v56
    vf.fms       v46, v25, v22, v55
    vf.mul       v22, v54, v56
    @p1 v.sel        v25, v45, v27
    vf.mul       v27, v43, v56
    vf.mul       v45, v44, v47                   // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v58, v58
    vf.mul       v44, v22, v49                   // Newton step: 0.5*r0*(3 - x*r0^2)
    @p2 v.sel        v22, v60, v41
    vf.mul       v41, v27, v46                   // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v59, v59
    @p3 v.sel        v27, v57, v50
    vf.cmp.o     p3, v45, v45
    @p1 v.sel        v46, v58, v51
    vf.cmp.o     p1, v44, v44
    @p2 v.sel        v47, v59, v52
    vf.cmp.o     p2, v41, v41
    @p3 v.sel        v49, v45, v53
    @p1 v.sel        v45, v44, v54
    @p2 v.sel        v44, v41, v43
    vf.mul       v41, v32, v25
    vf.mul       v25, v30, v22
    vf.mul       v22, v31, v27
    vf.mul       v27, v24, v46
    vf.mul       v24, v12, v47
    vf.mul       v12, v10, v49
    vf.mul       v10, v7, v45
    vf.mul       v7, v18, v44
    vf.mul       v18, v41, v2
    vf.mul       v2, v25, v3
    vf.mul       v3, v22, v20
    vf.mul       v20, v27, v35
    vf.mul       v22, v24, v36
    vf.mul       v24, v12, v37
    vf.mul       v12, v10, v38
    vf.mul       v10, v7, v39
    vf.add       v7, v18, v40
    vf.add       v18, v2, v14
    vf.add       v2, v3, v23
    vf.add       v3, v20, v16
    vf.add       v14, v22, v26
    vf.add       v16, v24, v28
    vf.add       v20, v12, v5
    vf.add       v5, v10, v29
    v.movi       v10, #0
    v.movi       v12, #0
    vf.max.prop  v22, v7, v10
    vf.max.prop  v7, v18, v10
    vf.max.prop  v18, v2, v10
    vf.max.prop  v2, v3, v10
    vf.max.prop  v3, v14, v10
    vf.max.prop  v10, v16, v12
    vf.max.prop  v14, v20, v12
    vf.max.prop  v16, v5, v12
    v.st.w       [s12, #0], v22
    .li       s13, #925353388
    v.splat      v5, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.st.w       [s12, #64], v7
    v.st.w       [s12, #128], v18
    v.st.w       [s12, #192], v2
    v.st.w       [s12, #256], v3
    v.st.w       [s12, #320], v10
    v.st.w       [s12, #384], v14
    .li       s13, #925353388
    v.splat      v2, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.st.w       [s12, #448], v16
    v.ld.gather.w v3, [s8, v8]                   // index is in elements (ISA sec 9.1)
    v.ld.gather.w v7, [s8, v17]                  // index is in elements (ISA sec 9.1)
    vf.add       v10, v3, v5
    v.ld.gather.w v3, [s8, v4]                   // index is in elements (ISA sec 9.1)
    vf.add       v12, v7, v5
    v.ld.gather.w v7, [s8, v34]                  // index is in elements (ISA sec 9.1)
    vf.add       v14, v3, v5
    v.ld.gather.w v3, [s8, v13]                  // index is in elements (ISA sec 9.1)
    vf.add       v16, v7, v5
    v.ld.gather.w v7, [s8, v0]                   // index is in elements (ISA sec 9.1)
    vf.add       v18, v3, v5
    v.ld.gather.w v3, [s8, v33]                  // index is in elements (ISA sec 9.1)
    vf.add       v5, v7, v2
    v.ld.gather.w v7, [s8, v19]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.w v20, [s7, v8]                  // index is in elements (ISA sec 9.1)
    vf.add       v22, v3, v2
    v.ld.gather.w v3, [s7, v17]                  // index is in elements (ISA sec 9.1)
    vf.add       v23, v7, v2
    vf.sub       v2, v1, v20
    v.ld.gather.w v1, [s7, v4]                   // index is in elements (ISA sec 9.1)
    v.rsqrt.approx v7, v10                       // ISA 8.8: <= 2**-22 relative
    vf.sub       v20, v42, v3
    v.ld.gather.w v3, [s7, v34]                  // index is in elements (ISA sec 9.1)
    vf.sub       v24, v6, v1
    vf.mul       v1, v7, v7
    v.ld.gather.w v6, [s7, v13]                  // index is in elements (ISA sec 9.1)
    vf.fms       v25, v10, v1, v55
    vf.sub       v1, v9, v3
    v.ld.gather.w v3, [s7, v0]                   // index is in elements (ISA sec 9.1)
    vf.mul       v9, v7, v56
    vf.sub       v10, v11, v6
    v.ld.gather.w v6, [s7, v33]                  // index is in elements (ISA sec 9.1)
    vf.mul       v11, v9, v25                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.sub       v9, v15, v3
    v.ld.gather.w v3, [s7, v19]                  // index is in elements (ISA sec 9.1)
    v.rsqrt.approx v15, v12                      // ISA 8.8: <= 2**-22 relative
    vf.sub       v25, v21, v6
    vf.cmp.o     p1, v11, v11
    @p1 v.sel        v6, v11, v7
    v.ld.gather.w v7, [s9, v8]                   // index is in elements (ISA sec 9.1)
    v.rsqrt.approx v11, v14                      // ISA 8.8: <= 2**-22 relative
    vf.sub       v21, v48, v3
    vf.mul       v3, v15, v15
    vf.mul       v26, v15, v56
    vf.fms       v27, v12, v3, v55
    v.ld.gather.w v3, [s9, v17]                  // index is in elements (ISA sec 9.1)
    vf.mul       v12, v26, v27                   // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v12, v12
    @p1 v.sel        v26, v12, v15
    vf.mul       v12, v11, v11
    v.ld.gather.w v15, [s9, v4]                  // index is in elements (ISA sec 9.1)
    vf.fms       v27, v14, v12, v55
    v.ld.gather.w v12, [s9, v34]                 // index is in elements (ISA sec 9.1)
    vf.mul       v14, v11, v56
    v.ld.gather.w v28, [s9, v13]                 // index is in elements (ISA sec 9.1)
    vf.mul       v29, v14, v27                   // Newton step: 0.5*r0*(3 - x*r0^2)
    v.ld.gather.w v14, [s9, v0]                  // index is in elements (ISA sec 9.1)
    vf.cmp.o     p1, v29, v29
    v.ld.gather.w v27, [s9, v33]                 // index is in elements (ISA sec 9.1)
    @p1 v.sel        v30, v29, v11
    v.ld.gather.w v11, [s9, v19]                 // index is in elements (ISA sec 9.1)
    v.rsqrt.approx v29, v16                      // ISA 8.8: <= 2**-22 relative
    v.ld.gather.w v31, [s10, v8]                 // index is in elements (ISA sec 9.1)
    vf.mul       v8, v29, v29
    v.ld.gather.w v32, [s10, v17]                // index is in elements (ISA sec 9.1)
    vf.fms       v17, v16, v8, v55
    v.ld.gather.w v8, [s10, v4]                  // index is in elements (ISA sec 9.1)
    vf.mul       v4, v29, v56
    v.ld.gather.w v16, [s10, v34]                // index is in elements (ISA sec 9.1)
    vf.mul       v34, v4, v17                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.ld.gather.w v4, [s10, v13]                 // index is in elements (ISA sec 9.1)
    vf.cmp.o     p1, v34, v34
    v.ld.gather.w v13, [s10, v0]                 // index is in elements (ISA sec 9.1)
    @p1 v.sel        v0, v34, v29
    v.ld.gather.w v17, [s10, v33]                // index is in elements (ISA sec 9.1)
    v.rsqrt.approx v29, v18                      // ISA 8.8: <= 2**-22 relative
    v.ld.gather.w v33, [s10, v19]                // index is in elements (ISA sec 9.1)
    v.rsqrt.approx v19, v5                       // ISA 8.8: <= 2**-22 relative
    v.rsqrt.approx v34, v22                      // ISA 8.8: <= 2**-22 relative
    v.rsqrt.approx v35, v23                      // ISA 8.8: <= 2**-22 relative
    vf.mul       v36, v2, v6
    vf.mul       v2, v20, v26
    vf.mul       v6, v24, v30
    vf.mul       v20, v1, v0
    vf.mul       v0, v36, v7
    vf.mul       v1, v2, v3
    vf.mul       v2, v29, v29
    vf.mul       v3, v29, v56
    vf.mul       v7, v6, v15
    vf.mul       v6, v20, v12
    vf.add       v12, v0, v31
    vf.fms       v0, v18, v2, v55
    vf.add       v2, v1, v32
    vf.add       v1, v7, v8
    vf.add       v7, v6, v16
    vf.mul       v6, v3, v0                      // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v0, #0
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v3, v6, v29
    vf.max.prop  v6, v12, v0
    vf.mul       v8, v19, v19
    vf.mul       v12, v34, v34
    vf.mul       v15, v35, v35
    vf.mul       v16, v19, v56
    vf.mul       v18, v34, v56
    vf.fms       v20, v5, v8, v55
    vf.fms       v5, v22, v12, v55
    vf.fms       v8, v23, v15, v55
    vf.mul       v12, v35, v56
    vf.mul       v15, v10, v3
    vf.mul       v3, v16, v20                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.mul       v10, v18, v5                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v5, #0
    vf.mul       v16, v12, v8                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.mul       v8, v15, v28
    vf.cmp.o     p1, v3, v3
    vf.cmp.o     p2, v10, v10
    @p1 v.sel        v12, v3, v19
    vf.cmp.o     p1, v16, v16
    @p2 v.sel        v3, v10, v34
    @p1 v.sel        v10, v16, v35
    vf.mul       v15, v9, v12
    vf.mul       v9, v25, v3
    vf.mul       v3, v21, v10
    vf.add       v10, v8, v4
    vf.max.prop  v4, v2, v0
    vf.mul       v2, v15, v14
    vf.mul       v8, v9, v27
    vf.mul       v9, v3, v11
    vf.max.prop  v3, v1, v0
    vf.max.prop  v1, v7, v0
    vf.add       v7, v2, v13
    vf.add       v2, v8, v17
    vf.add       v8, v9, v33
    vf.max.prop  v9, v10, v0
    s.addi       s12, s11, #256
    vf.max.prop  v0, v7, v5
    vf.max.prop  v7, v2, v5
    vf.max.prop  v2, v8, v5
    v.st.w       [s14, #0], v6
    s.movz       s13, #256
    v.st.w       [s14, #64], v4
    v.st.w       [s14, #128], v3
    v.st.w       [s14, #192], v1
    v.st.w       [s14, #256], v9
    v.st.w       [s14, #320], v0
    v.st.w       [s14, #384], v7
    v.st.w       [s14, #448], v2
    s.mov        s11, s12
    s.cmp.lt     s12, s11, s13
    br.nz        s12, tiles_1
endtiles_2:
__rctx_next:
    s.addi       s1, s5, #4                      // the next program of this context: + 4
    s.cmp.lt     s11, s1, s6
    s.mov        s5, s1
    br.nz        s11, __rctx_program
    exit
