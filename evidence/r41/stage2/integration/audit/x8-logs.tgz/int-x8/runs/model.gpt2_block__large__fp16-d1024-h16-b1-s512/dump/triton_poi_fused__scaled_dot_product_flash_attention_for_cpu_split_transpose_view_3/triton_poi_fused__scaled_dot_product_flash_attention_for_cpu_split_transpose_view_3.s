    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, pid.y
    s.rdspecial  s2, arg_base
    s.shli       s3, s1, #4                      // x16 as a shift
    s.shli       s1, s4, #4                      // x16 as a shift
    s.rdspecial  s4, role_id
    s.movz       s5, #2560
    s.ld.d       s6, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.rdspecial  s7, arg_base
    s.mul        s8, s4, s5
    s.muli       s4, s1, #6144
    v.splat      v0, s3
    v.iota       v1                              // arange(0, VLEN)
    s.ld.d       s5, [s7, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.muli       s7, s3, #2
    v.add        v2, v0, v1
    v.movi       v0, #0
    v.splat      v1, s1
    v.movi       v3, #0
    s.addi       s9, s6, #2048
    v.cmp.ge     p1, v2, v0
    v.cmpi.lt    p2, v2, #1024
    v.cmp.ge     p3, v1, v3
    v.cmpi.lt    p4, v1, #512
    s.add        s6, s5, s8                      // this context's own scratch
    s.add        s5, s9, s4
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.addi       s4, s6, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s8, #512
    s.movz       s10, #1024
    s.movz       s11, #6144
    s.movz       s12, #2
    s.add        s13, s5, s7
    .li       s5, #68719476752
    p.and        p2, p5, p1
    s.ld.d       s7, [s2, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.movi       v0, #0
    s.st.d       [s4, #0], s9
    s.addi       s2, s1, #1
    v.splat      v1, s2
    s.movz       s2, #1
    s.st.d       [s4, #8], s8
    .li       s8, #8589934592
    s.muli       s9, s2, #6144
    s.st.d       [s4, #16], s10
    v.cmp.ge     p1, v1, v0
    v.cmpi.lt    p3, v1, #512
    s.st.d       [s4, #48], s11
    p.and        p4, p1, p3
    s.addi       s2, s1, #2
    s.st.d       [s4, #56], s12
    s.movz       s10, #2
    s.addi       s11, s6, #256
    s.st.d       [s4, #88], s5
    p.and        p1, p5, p4
    s.add        s5, s13, s9
    s.st.d       [s4, #104], s8
    fence.release.device
    td.load      d0, [s4]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v0, [s13, #0]
    v.splat      v1, s2
    v.movi       v2, #0
    s.muli       s2, s10, #6144
    v.cmp.ge     p2, v1, v2
    v.cmpi.lt    p3, v1, #512
    v.st.w       [s11, #0], v0
    p.and        p4, p2, p3
    s.addi       s4, s1, #3
    s.movz       s8, #3
    s.addi       s9, s11, #64
    p.and        p2, p5, p4
    s.add        s10, s13, s2
    v.splat      v0, s4
    v.movi       v1, #0
    s.muli       s2, s8, #6144
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v2, [s5, #0]
    v.cmp.ge     p1, v0, v1
    v.cmpi.lt    p3, v0, #512
    p.and        p4, p1, p3
    s.addi       s4, s1, #4
    s.movz       s5, #4
    v.st.w       [s9, #0], v2
    s.addi       s8, s11, #128
    p.and        p1, p5, p4
    s.add        s9, s13, s2
    v.splat      v0, s4
    v.movi       v1, #0
    s.muli       s2, s5, #6144
    v.cmp.ge     p3, v0, v1
    s.addi       s4, s1, #5
    s.movz       s5, #5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s10, #0]
    v.cmpi.lt    p2, v0, #512
    p.and        p4, p3, p2
    s.addi       s10, s11, #192
    p.and        p2, p5, p4
    s.add        s12, s13, s2
    v.st.w       [s8, #0], v1
    v.splat      v0, s4
    v.movi       v1, #0
    s.muli       s2, s5, #6144
    v.cmp.ge     p3, v0, v1
    s.addi       s4, s1, #6
    s.movz       s5, #6
    v.splat      v1, s4
    s.addi       s4, s11, #256
    s.add        s8, s13, s2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v2, [s9, #0]
    v.cmpi.lt    p1, v0, #512
    p.and        p4, p3, p1
    v.movi       v0, #0
    p.and        p1, p5, p4
    s.muli       s2, s5, #6144
    v.st.w       [s10, #0], v2
    v.cmp.ge     p3, v1, v0
    s.addi       s5, s1, #7
    s.movz       s9, #7
    s.add        s10, s13, s2
    v.splat      v0, s5
    s.addi       s2, s11, #320
    v.movi       v2, #0
    s.muli       s5, s9, #6144
    v.movi       v3, #0
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s12, #0]
    v.cmpi.lt    p2, v1, #512
    p.and        p4, p3, p2
    v.cmp.ge     p2, v0, v2
    p.and        p3, p5, p4
    s.addi       s9, s1, #8
    v.st.w       [s4, #0], v4
    s.movz       s4, #8
    s.add        s12, s13, s5
    v.splat      v1, s9
    s.addi       s5, s11, #384
    s.muli       s9, s4, #6144
    v.movi       v2, #0
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s8, #0]
    v.cmpi.lt    p1, v0, #512
    p.and        p4, p2, p1
    v.cmp.ge     p1, v1, v3
    p.and        p2, p5, p4
    s.addi       s4, s1, #9
    v.st.w       [s2, #0], v4
    s.movz       s2, #9
    s.add        s8, s13, s9
    v.splat      v0, s4
    s.addi       s4, s11, #448
    s.muli       s9, s2, #6144
    v.movi       v3, #0
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s10, #0]
    v.cmpi.lt    p3, v1, #512
    p.and        p4, p1, p3
    v.cmp.ge     p1, v0, v2
    p.and        p3, p5, p4
    s.addi       s2, s1, #10
    v.st.w       [s5, #0], v4
    s.movz       s5, #10
    s.add        s10, s13, s9
    v.splat      v1, s2
    s.addi       s2, s11, #512
    s.muli       s9, s5, #6144
    v.movi       v2, #0
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s12, #0]
    v.cmpi.lt    p2, v0, #512
    p.and        p4, p1, p2
    v.cmp.ge     p1, v1, v3
    p.and        p2, p5, p4
    s.addi       s5, s1, #11
    v.st.w       [s4, #0], v4
    s.movz       s4, #11
    s.add        s12, s13, s9
    v.splat      v0, s5
    s.addi       s5, s11, #576
    s.muli       s9, s4, #6144
    v.movi       v3, #0
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s8, #0]
    v.cmpi.lt    p3, v1, #512
    p.and        p4, p1, p3
    v.cmp.ge     p1, v0, v2
    p.and        p3, p5, p4
    s.addi       s4, s1, #12
    v.st.w       [s2, #0], v4
    s.movz       s2, #12
    s.add        s8, s13, s9
    v.splat      v1, s4
    s.addi       s4, s11, #640
    s.muli       s9, s2, #6144
    v.movi       v2, #0
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s10, #0]
    v.cmpi.lt    p2, v0, #512
    p.and        p4, p1, p2
    v.cmp.ge     p1, v1, v3
    p.and        p2, p5, p4
    s.addi       s2, s1, #13
    v.st.w       [s5, #0], v4
    s.movz       s5, #13
    s.add        s10, s13, s9
    v.splat      v0, s2
    s.addi       s2, s11, #704
    s.muli       s9, s5, #6144
    v.movi       v3, #0
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s12, #0]
    v.cmpi.lt    p3, v1, #512
    p.and        p4, p1, p3
    v.cmp.ge     p1, v0, v2
    p.and        p3, p5, p4
    s.addi       s5, s1, #14
    v.st.w       [s4, #0], v4
    s.movz       s4, #14
    s.add        s12, s13, s9
    v.splat      v1, s5
    s.addi       s5, s11, #768
    s.muli       s9, s4, #6144
    v.movi       v2, #0
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s8, #0]
    v.cmpi.lt    p2, v0, #512
    p.and        p4, p1, p2
    v.cmp.ge     p1, v1, v3
    p.and        p2, p5, p4
    s.addi       s4, s1, #15
    v.st.w       [s2, #0], v4
    s.movz       s2, #15
    s.add        s8, s13, s9
    v.splat      v0, s4
    s.addi       s4, s11, #832
    s.muli       s9, s2, #6144
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s10, #0]
    v.cmpi.lt    p3, v1, #512
    p.and        p4, p1, p3
    v.cmp.ge     p1, v0, v2
    p.and        p3, p5, p4
    s.addi       s2, s11, #896
    v.st.w       [s5, #0], v3
    s.add        s5, s13, s9
    s.addi       s9, s11, #960
    // tile epilogue: 16 rows through the vector unit, as f16 (ISA sec 9B)
    s.addi       s10, s6, #256
    s.addi       s11, s6, #1280                  // 512 bytes of repack scratch
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s12, #0]
    v.cmpi.lt    p2, v0, #512
    p.and        p4, p1, p2
    s.addi       s12, s6, #320
    p.and        p1, p5, p4
    v.st.w       [s4, #0], v1
    s.movz       s4, #1
    s.muli       s13, s4, #32
    s.add        s4, s11, s13
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s8, #0]
    s.addi       s8, s6, #384
    v.st.w       [s2, #0], v0
    s.movz       s2, #2
    s.muli       s13, s2, #32
    s.add        s2, s11, s13
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s5, #0]
    s.addi       s5, s6, #448
    v.st.w       [s9, #0], v0
    fence.acq_rel.device
    s.movz       s9, #3
    s.muli       s13, s9, #32
    s.add        s9, s11, s13
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s6, #512
    v.st.h       [s11, #0], v0
    v.ld.w       v0, [s12, #0]
    s.movz       s12, #4
    s.muli       s13, s12, #32
    s.add        s12, s11, s13
    v.st.h       [s4, #0], v0
    s.addi       s4, s6, #576
    v.ld.w       v0, [s8, #0]
    s.movz       s8, #5
    s.muli       s13, s8, #32
    s.add        s8, s11, s13
    v.st.h       [s2, #0], v0
    s.addi       s2, s6, #640
    v.ld.w       v0, [s5, #0]
    s.movz       s5, #6
    s.muli       s13, s5, #32
    s.add        s5, s11, s13
    v.st.h       [s9, #0], v0
    s.addi       s9, s6, #704
    v.ld.w       v0, [s10, #0]
    s.movz       s10, #7
    s.muli       s13, s10, #32
    s.add        s10, s11, s13
    v.st.h       [s12, #0], v0
    s.addi       s12, s6, #768
    v.ld.w       v0, [s4, #0]
    s.movz       s4, #8
    s.muli       s13, s4, #32
    s.add        s4, s11, s13
    v.st.h       [s8, #0], v0
    s.addi       s8, s6, #832
    v.ld.w       v0, [s2, #0]
    s.movz       s2, #9
    s.muli       s13, s2, #32
    s.add        s2, s11, s13
    v.st.h       [s5, #0], v0
    s.addi       s5, s6, #896
    v.ld.w       v0, [s9, #0]
    s.movz       s9, #10
    s.muli       s13, s9, #32
    s.add        s9, s11, s13
    v.st.h       [s10, #0], v0
    s.addi       s10, s6, #960
    v.ld.w       v0, [s12, #0]
    s.movz       s12, #11
    s.muli       s13, s12, #32
    s.add        s12, s11, s13
    v.st.h       [s4, #0], v0
    s.addi       s4, s6, #1024
    v.ld.w       v0, [s8, #0]
    s.movz       s8, #12
    // tl.trans: 16 columns, gathered %c336:scalar elements apart (ISA sec 9.1)
    v.iota       v1                              // arange(0, VLEN)
    s.muli       s13, s8, #32
    s.add        s8, s11, s13
    v.st.h       [s2, #0], v0
    s.addi       s2, s6, #1088
    v.ld.w       v0, [s5, #0]
    s.movz       s5, #13
    s.muli       s13, s5, #32
    s.add        s5, s11, s13
    v.st.h       [s9, #0], v0
    s.addi       s9, s6, #1152
    v.ld.w       v0, [s10, #0]
    s.movz       s10, #14
    s.muli       s13, s10, #32
    s.add        s10, s11, s13
    v.st.h       [s12, #0], v0
    s.movz       s12, #0
    s.muli       s13, s12, #32
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s6, #1216
    s.add        s12, s11, s13
    v.st.h       [s8, #0], v0
    s.movz       s8, #0
    s.muli       s13, s8, #2
    v.ld.w       v0, [s2, #0]
    s.movz       s2, #15
    s.add        s8, s12, s13
    s.muli       s12, s2, #32
    s.movz       s2, #16
    v.splat      v2, s2
    s.addi       s2, s8, #2                      // column 1
    s.add        s13, s11, s12
    v.mul        v3, v1, v2                      // one element per source row
    v.st.h       [s5, #0], v0
    s.addi       s5, s8, #4                      // column 2
    s.addi       s11, s8, #6                     // column 3
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s8, #8                      // column 4
    v.st.h       [s10, #0], v0
    s.addi       s10, s8, #10                    // column 5
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s8, #12                     // column 6
    v.st.h       [s13, #0], v0
    s.addi       s12, s8, #14                    // column 7
    fence.acq_rel.device
    v.ld.gather.h v0, [s8, v3]                   // index is in elements (ISA sec 9.1)
    v.ld.gather.h v1, [s2, v3]                   // index is in elements (ISA sec 9.1)
    s.addi       s2, s8, #16                     // column 8
    v.ld.gather.h v2, [s5, v3]                   // index is in elements (ISA sec 9.1)
    s.addi       s5, s8, #18                     // column 9
    v.ld.gather.h v4, [s11, v3]                  // index is in elements (ISA sec 9.1)
    s.addi       s11, s8, #20                    // column 10
    v.ld.gather.h v5, [s9, v3]                   // index is in elements (ISA sec 9.1)
    s.addi       s9, s8, #22                     // column 11
    v.ld.gather.h v6, [s10, v3]                  // index is in elements (ISA sec 9.1)
    s.addi       s10, s8, #24                    // column 12
    v.ld.gather.h v7, [s4, v3]                   // index is in elements (ISA sec 9.1)
    s.addi       s4, s8, #26                     // column 13
    v.ld.gather.h v8, [s12, v3]                  // index is in elements (ISA sec 9.1)
    s.addi       s12, s8, #28                    // column 14
    s.addi       s13, s8, #30                    // column 15
    v.ld.gather.h v9, [s2, v3]                   // index is in elements (ISA sec 9.1)
    s.addi       s2, s6, #1792                   // 512 bytes of repack scratch
    s.addi       s8, s6, #2304                   // TensorMap 1: a repacked tile
    v.ld.gather.h v10, [s5, v3]                  // index is in elements (ISA sec 9.1)
    s.addi       s5, s2, #32                     // row 1
    v.ld.gather.h v11, [s11, v3]                 // index is in elements (ISA sec 9.1)
    s.addi       s6, s2, #64                     // row 2
    v.ld.gather.h v12, [s9, v3]                  // index is in elements (ISA sec 9.1)
    s.addi       s9, s2, #96                     // row 3
    v.ld.gather.h v13, [s10, v3]                 // index is in elements (ISA sec 9.1)
    s.addi       s10, s2, #128                   // row 4
    v.ld.gather.h v14, [s4, v3]                  // index is in elements (ISA sec 9.1)
    s.addi       s4, s2, #160                    // row 5
    v.ld.gather.h v15, [s12, v3]                 // index is in elements (ISA sec 9.1)
    s.addi       s11, s2, #192                   // row 6
    v.ld.gather.h v16, [s13, v3]                 // index is in elements (ISA sec 9.1)
    s.movz       s12, #0
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    v.st.h       [s2, #0], v0
    v.st.h       [s5, #0], v1
    s.addi       s5, s2, #224                    // row 7
    v.st.h       [s6, #0], v2
    s.muli       s6, s12, #32
    s.add        s13, s2, s6
    v.st.h       [s9, #0], v4
    s.muli       s6, s12, #2
    s.add        s9, s13, s6
    s.addi       s6, s2, #256                    // row 8
    v.st.h       [s10, #0], v5
    s.addi       s10, s2, #288                   // row 9
    .li       s13, #1052050675
    v.splat      v0, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.st.h       [s4, #0], v6
    s.addi       s4, s2, #320                    // row 10
    s.muli       s13, s3, #2048                  // a runtime tile origin, x2048
    v.st.h       [s11, #0], v7
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s3, #0
    v.st.h       [s5, #0], v8
    s.muli       s5, s3, #32
    s.addi       s3, s2, #352                    // row 11
    v.st.h       [s6, #0], v9
    s.addi       s6, s2, #384                    // row 12
    s.add        s11, s9, s5
    v.st.h       [s10, #0], v10
    s.addi       s5, s2, #416                    // row 13
    v.st.h       [s4, #0], v11
    s.addi       s4, s2, #448                    // row 14
    v.iota       v1                              // arange(0, VLEN)
    v.st.h       [s3, #0], v12
    s.addi       s3, s2, #480                    // row 15
    v.st.h       [s6, #0], v13
    s.movz       s6, #16
    v.st.h       [s5, #0], v14
    s.movz       s5, #16
    v.st.h       [s4, #0], v15
    s.movz       s4, #32
    v.st.h       [s3, #0], v16
    s.movz       s3, #2
    s.st.d       [s8, #0], s2
    .li       s2, #68719476752
    s.st.d       [s8, #8], s6
    .li       s6, #8589934592
    s.st.d       [s8, #16], s5
    s.muli       s5, s1, #4                      // a runtime tile origin, x4
    s.st.d       [s8, #48], s4
    s.movz       s4, #0
    s.st.d       [s8, #56], s3
    s.movz       s3, #1
    s.add        s10, s4, s1                     // the tile origin
    s.st.d       [s8, #88], s2
    s.muli       s1, s3, #32
    v.splat      v2, s10
    s.st.d       [s8, #104], s6
    fence.release.device
    td.load      d1, [s8]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s2, b0, #0, #1                  // 0 arrival(s), 1 operation(s)
    s.add        s3, s7, s5                      // the tile origin
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s4, s12                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s5, s12                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d1, s4, s2
    mb.wait      s2
    v.ld.h       v3, [s11, #0]
    v.add        v4, v1, v2
    s.add        s4, s3, s13                     // the tile origin
    s.add        s3, s9, s1
    v.cmpi.lt    p1, v4, #512
    s.movz       s1, #2
    vf.cvt.f16.f32 v1, v3
    s.muli       s5, s1, #32
    s.addi       s1, s4, #2048                   // row 1
    s.movz       s6, #3
    vf.mul       v2, v1, v0
    s.muli       s7, s6, #32
    s.add        s6, s9, s5
    s.addi       s5, s4, #4096                   // row 2
    @p1 v.st.w       [s4, #0], v2
    s.movz       s8, #4
    s.add        s10, s9, s7
    s.muli       s7, s8, #32
    s.addi       s8, s4, #6144                   // row 3
    s.movz       s11, #5
    s.addi       s12, s4, #8192                  // row 4
    s.muli       s13, s11, #32
    s.add        s11, s9, s7
    s.movz       s7, #6
    v.ld.h       v1, [s3, #0]
    s.muli       s3, s7, #32
    s.add        s7, s9, s13
    s.addi       s13, s4, #10240                 // row 5
    vf.cvt.f16.f32 v2, v1
    s.add        s14, s9, s3
    vf.mul       v1, v2, v0
    @p1 v.st.w       [s1, #0], v1
    s.movz       s1, #7
    s.muli       s3, s1, #32
    s.add        s1, s9, s3
    v.ld.h       v1, [s6, #0]
    s.addi       s3, s4, #12288                  // row 6
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    @p1 v.st.w       [s5, #0], v1
    s.movz       s5, #8
    s.muli       s6, s5, #32
    s.add        s5, s9, s6
    v.ld.h       v1, [s10, #0]
    s.addi       s6, s4, #14336                  // row 7
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    @p1 v.st.w       [s8, #0], v1
    s.movz       s8, #9
    s.muli       s10, s8, #32
    s.add        s8, s9, s10
    v.ld.h       v1, [s11, #0]
    s.addi       s10, s4, #16384                 // row 8
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    @p1 v.st.w       [s12, #0], v1
    s.movz       s11, #10
    s.muli       s12, s11, #32
    s.add        s11, s9, s12
    v.ld.h       v1, [s7, #0]
    s.addi       s7, s4, #18432                  // row 9
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    @p1 v.st.w       [s13, #0], v1
    s.movz       s12, #11
    s.muli       s13, s12, #32
    s.add        s12, s9, s13
    v.ld.h       v1, [s14, #0]
    s.addi       s13, s4, #20480                 // row 10
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    @p1 v.st.w       [s3, #0], v1
    s.movz       s3, #12
    s.muli       s14, s3, #32
    s.add        s3, s9, s14
    v.ld.h       v1, [s1, #0]
    s.addi       s1, s4, #22528                  // row 11
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    @p1 v.st.w       [s6, #0], v1
    s.movz       s6, #13
    s.muli       s14, s6, #32
    s.add        s6, s9, s14
    v.ld.h       v1, [s5, #0]
    s.addi       s5, s4, #24576                  // row 12
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    @p1 v.st.w       [s10, #0], v1
    s.movz       s10, #14
    s.muli       s14, s10, #32
    s.add        s10, s9, s14
    v.ld.h       v1, [s8, #0]
    s.addi       s8, s4, #26624                  // row 13
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    @p1 v.st.w       [s7, #0], v1
    s.movz       s7, #15
    s.muli       s14, s7, #32
    s.add        s7, s9, s14
    s.addi       s9, s4, #28672                  // row 14
    v.ld.h       v1, [s11, #0]
    s.addi       s11, s4, #30720                 // row 15
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    @p1 v.st.w       [s13, #0], v1
    v.ld.h       v1, [s12, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    @p1 v.st.w       [s1, #0], v1
    v.ld.h       v1, [s3, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    @p1 v.st.w       [s5, #0], v1
    v.ld.h       v1, [s6, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    @p1 v.st.w       [s8, #0], v1
    v.ld.h       v1, [s10, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    @p1 v.st.w       [s9, #0], v1
    v.ld.h       v1, [s7, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    @p1 v.st.w       [s11, #0], v1
__rctx_next:
    exit
