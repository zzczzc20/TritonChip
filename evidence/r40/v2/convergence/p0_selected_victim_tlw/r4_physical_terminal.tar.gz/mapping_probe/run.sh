source /tools/Xilinx/Vivado/2023.2/settings64.sh >/dev/null 2>&1
cd /home/zzhouch/tnca_build/r40_r4_mapping_probe_20261017
timeout 600 nice -n 19 vivado -mode batch -source probe.tcl -tclargs /home/zzhouch/tnca_build/r40_r4_module_20261017/reports/routed.dcp /home/zzhouch/tnca_build/r40_r4_mapping_probe_20261017/reports > stdout.log 2>&1
echo $? > runner.exit
