.li s5, #0x10000
mb.wait s5
exit
