    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.rdspecial  s2, arg_base
    s.ld.d       s3, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s5, #512
    .li       s6, #2147483647
    s.mul        s7, s1, s5
    .li       s1, #2147483647
    s.movz       s5, #768
    s.movz       s8, #4
    .li       s9, #68719476752
    .li       s10, #2207613190144
    s.rdspecial  s11, arg_base
    s.ld.d       s12, [s2, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.add        s13, s3, s7                     // this context's own scratch
    s.rdspecial  s3, role_id
    s.addi       s7, s13, #0                     // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.movz       s13, #512
    .li       s14, #2147483647
    s.mul        s15, s3, s13
    .li       s3, #2147483647
    s.movz       s13, #512
    s.movz       s16, #4
    .li       s17, #68719476752
    s.ld.d       s18, [s2, #8]                   // arg_B: device_ptr64 at arg_base+8
    s.movz       s19, #8
    .li       s20, #2207613190144
    s.movz       s21, #0
    s.movz       s21, #0
    s.ld.d       s21, [s2, #16]                  // out_ptr0: device_ptr64 at arg_base+16
    s.st.d       [s7, #0], s12
    s.movz       s2, #0
    s.st.d       [s7, #8], s6
    s.movz       s6, #0
    s.st.d       [s7, #16], s1
    s.movz       s1, #0
    s.cmp.lt     s12, s19, s1
    s.st.d       [s7, #48], s5
    s.cmp.lt     s1, s4, s2
    s.movz       s2, #0
    s.sub        s5, s2, s12
    s.movz       s2, #1
    s.st.d       [s7, #56], s8
    s.sub        s8, s6, s1
    s.movz       s1, #0
    s.xor        s6, s4, s8
    s.st.d       [s7, #88], s9
    s.sub        s9, s6, s8
    s.movz       s6, #0
    s.st.d       [s7, #104], s10
    s.lshri      s10, s9, #3
    fence.release.device
    td.load      d0, [s7]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.xor        s7, s8, s5
    s.movz       s8, #0
    s.ld.d       s12, [s11, #24]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.cmp.lt     s11, s4, s6
    s.add        s6, s12, s15                    // this context's own scratch
    s.xor        s12, s10, s7
    s.muli       s15, s10, #8
    s.sub        s10, s12, s7
    s.movz       s7, #0
    s.addi       s12, s6, #256                   // TensorMap 1: a 2-D tt.load (built once, at entry)
    s.sub        s6, s7, s11
    s.sub        s7, s19, s10
    s.st.d       [s12, #0], s18
    s.min.s      s11, s7, s2
    s.movz       s7, #0
    s.cmp.lt     s18, s11, s1
    s.sub        s1, s9, s15
    s.sub        s1, s8, s18
    s.movz       s8, #1
    s.xor        s9, s4, s6
    s.xor        s15, s19, s5
    s.sub        s18, s9, s6
    s.sub        s9, s15, s5
    s.movz       s5, #0
    s.st.d       [s12, #8], s14
    s.xor        s9, s11, s1
    s.sub        s14, s9, s1
    s.st.d       [s12, #16], s3
    s.addi       s1, s7, #0
    s.addi       s3, s5, #0
    s.st.d       [s12, #48], s13
    s.cmp.eq     s5, s14, s8
    s.st.d       [s12, #56], s16
    s.st.d       [s12, #88], s17
    s.st.d       [s12, #104], s20
    fence.release.device
    td.load      d1, [s12]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.mov        s1, s18
    br.nz        s5, sdiv_done_1
    s.movz       s5, #0
    s.movz       s7, #31
    s.mov        s1, s5
    s.addi       s5, s7, #0
sdiv_2:
    s.lshr       s7, s18, s5
    s.shli       s8, s3, #1
    s.andi       s9, s7, #1
    s.movz       s7, #0
    s.or         s12, s8, s9
    s.movz       s8, #1
    s.cmp.geu    s9, s12, s14
    s.shl        s13, s8, s5
    s.sub        s8, s7, s9
    s.subi       s7, s5, #1
    s.and        s9, s14, s8
    s.and        s15, s13, s8
    s.sub        s8, s12, s9
    s.or         s9, s1, s15
    s.mov        s3, s8
    s.mov        s1, s9
    s.mov        s5, s7
    s.movz       s7, #0
    s.cmp.ge     s8, s5, s7
    br.nz        s8, sdiv_2
sdiv_done_1:
    s.movz       s1, #0
    s.movz       s5, #0
    s.cmp.lt     s7, s4, s1
    s.movz       s1, #0
    s.sub        s8, s5, s7
    s.movz       s5, #0
    s.xor        s7, s4, s8
    s.movz       s4, #0
    s.sub        s9, s7, s8
    s.cmp.lt     s7, s11, s1
    s.lshri      s1, s9, #3
    s.movz       s12, #0
    s.muli       s13, s1, #8
    s.sub        s1, s4, s7
    s.movz       s4, #0
    s.cmp.lt     s7, s19, s12
    s.xor        s12, s11, s1
    s.sub        s11, s9, s13
    s.movz       s9, #0
    s.xor        s13, s11, s8
    s.xor        s11, s3, s6
    s.sub        s3, s13, s8
    s.sub        s8, s9, s7
    s.cmp.lt     s7, s3, s5
    s.sub        s5, s12, s1
    s.sub        s9, s4, s7
    s.movz       s4, #0
    s.xor        s7, s3, s9
    s.movz       s3, #1
    s.sub        s12, s11, s6
    s.xor        s6, s19, s8
    s.sub        s11, s7, s9
    s.movz       s7, #0
    s.addi       s13, s4, #0
    s.cmp.eq     s4, s5, s3
    s.add        s3, s10, s12
    s.sub        s10, s6, s8
    s.addi       s6, s7, #0
    s.mov        s13, s11
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.movz       s7, #31
    s.mov        s13, s4
    s.addi       s4, s7, #0
sdiv_4:
    s.lshr       s7, s11, s4
    s.shli       s8, s6, #1
    s.andi       s10, s7, #1
    s.movz       s7, #0
    s.or         s12, s8, s10
    s.movz       s8, #1
    s.cmp.geu    s10, s12, s5
    s.shl        s14, s8, s4
    s.sub        s8, s7, s10
    s.subi       s7, s4, #1
    s.and        s10, s5, s8
    s.and        s15, s14, s8
    s.sub        s8, s12, s10
    s.or         s10, s13, s15
    s.mov        s6, s8
    s.mov        s13, s10
    s.mov        s4, s7
    s.movz       s7, #0
    s.cmp.ge     s8, s4, s7
    br.nz        s8, sdiv_4
sdiv_done_3:
    s.xor        s4, s9, s1
    s.movz       s1, #16
    s.xor        s5, s13, s4
    s.mul        s6, s3, s1
    s.sub        s7, s5, s4
    s.movz       s4, #0
    s.mul        s5, s7, s1
    v.splat      v0, s3
    s.andi       s3, s6, #127
    v.splat      v1, s4
    v.splat      v2, s7
    s.andi       s7, s5, #127
    v.splat      v3, s4
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s6
    v.cmp.ge     p1, v0, v1
    v.splat      v0, s5
    v.splat      v1, s3
    v.cmp.ge     p1, v2, v3
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s7
    v.add        v6, v5, v4
    v.iota       v5                              // arange(0, VLEN)
    v.add        v6, v0, v4
    v.add        v0, v1, v2
    v.add        v0, v3, v5
    s.movz       s8, #12
    s.addi       s9, s4, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s4, s9, s8
    br.nz        s4, endfor_6
    s.mul        s4, s9, s1
    w.def        w0, #48, #16                    // v48..v63
    mb.arm       s10, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.movi       v0, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s11, #0
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s12, s3                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s13, s4                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.w w0, d0, s12, s10
    mb.wait      s10
    w.def        w1, #32, #16                    // v32..v47
    mb.arm       s12, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s13, s4                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s14, s7                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.w w1, d1, s13, s12
    mb.wait      s12
    v.extract    s4, v48, #0
    v.extract    s13, v48, #1
    v.splat      v1, s4
    v.splat      v2, s13
    v.extract    s4, v48, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s4
    v.extract    s4, v48, #3
    v.extract    s13, v48, #4
    v.splat      v4, s4
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s13
    v.extract    s4, v48, #5
    v.extract    s13, v48, #6
    v.splat      v3, s4
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s13
    v.extract    s4, v48, #7
    v.extract    s13, v48, #8
    v.splat      v5, s4
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s13
    v.extract    s4, v48, #9
    v.extract    s13, v48, #10
    v.extract    s14, v48, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s4
    v.extract    s4, v48, #12
    v.extract    s15, v48, #13
    v.extract    s16, v48, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s13
    v.extract    s13, v48, #15
    v.splat      v6, s14
    s.movz       s14, #1
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s4
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s15
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s16
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s13
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s11, v1
    v.extract    s4, v49, #0
    v.extract    s11, v49, #1
    v.splat      v1, s4
    v.splat      v2, s11
    v.extract    s4, v49, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s4
    v.extract    s4, v49, #3
    v.extract    s11, v49, #4
    v.splat      v4, s4
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s11
    v.extract    s4, v49, #5
    v.extract    s11, v49, #6
    v.splat      v3, s4
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s11
    v.extract    s4, v49, #7
    v.extract    s11, v49, #8
    v.splat      v5, s4
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s11
    v.extract    s4, v49, #9
    v.extract    s11, v49, #10
    v.extract    s13, v49, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s4
    v.extract    s4, v49, #12
    v.extract    s15, v49, #13
    v.extract    s16, v49, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s11
    v.extract    s11, v49, #15
    v.splat      v6, s13
    s.movz       s13, #2
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s4
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s15
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s16
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s11
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s14, v1
    v.extract    s4, v50, #0
    v.extract    s11, v50, #1
    v.splat      v1, s4
    v.splat      v2, s11
    v.extract    s4, v50, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s4
    v.extract    s4, v50, #3
    v.extract    s11, v50, #4
    v.splat      v4, s4
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s11
    v.extract    s4, v50, #5
    v.extract    s11, v50, #6
    v.splat      v3, s4
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s11
    v.extract    s4, v50, #7
    v.extract    s11, v50, #8
    v.splat      v5, s4
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s11
    v.extract    s4, v50, #9
    v.extract    s11, v50, #10
    v.extract    s14, v50, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s4
    v.extract    s4, v50, #12
    v.extract    s15, v50, #13
    v.extract    s16, v50, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s11
    v.extract    s11, v50, #15
    v.splat      v6, s14
    s.movz       s14, #3
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s4
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s15
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s16
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s11
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s13, v1
    v.extract    s4, v51, #0
    v.extract    s11, v51, #1
    v.splat      v1, s4
    v.splat      v2, s11
    v.extract    s4, v51, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s4
    v.extract    s4, v51, #3
    v.extract    s11, v51, #4
    v.splat      v4, s4
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s11
    v.extract    s4, v51, #5
    v.extract    s11, v51, #6
    v.splat      v3, s4
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s11
    v.extract    s4, v51, #7
    v.extract    s11, v51, #8
    v.splat      v5, s4
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s11
    v.extract    s4, v51, #9
    v.extract    s11, v51, #10
    v.extract    s13, v51, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s4
    v.extract    s4, v51, #12
    v.extract    s15, v51, #13
    v.extract    s16, v51, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s11
    v.extract    s11, v51, #15
    v.splat      v6, s13
    s.movz       s13, #4
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s4
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s15
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s16
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s11
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s14, v1
    v.extract    s4, v52, #0
    v.extract    s11, v52, #1
    v.splat      v1, s4
    v.splat      v2, s11
    v.extract    s4, v52, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s4
    v.extract    s4, v52, #3
    v.extract    s11, v52, #4
    v.splat      v4, s4
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s11
    v.extract    s4, v52, #5
    v.extract    s11, v52, #6
    v.splat      v3, s4
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s11
    v.extract    s4, v52, #7
    v.extract    s11, v52, #8
    v.splat      v5, s4
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s11
    v.extract    s4, v52, #9
    v.extract    s11, v52, #10
    v.extract    s14, v52, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s4
    v.extract    s4, v52, #12
    v.extract    s15, v52, #13
    v.extract    s16, v52, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s11
    v.extract    s11, v52, #15
    v.splat      v6, s14
    s.movz       s14, #5
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s4
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s15
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s16
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s11
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s13, v1
    v.extract    s4, v53, #0
    v.extract    s11, v53, #1
    v.splat      v1, s4
    v.splat      v2, s11
    v.extract    s4, v53, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s4
    v.extract    s4, v53, #3
    v.extract    s11, v53, #4
    v.splat      v4, s4
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s11
    v.extract    s4, v53, #5
    v.extract    s11, v53, #6
    v.splat      v3, s4
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s11
    v.extract    s4, v53, #7
    v.extract    s11, v53, #8
    v.splat      v5, s4
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s11
    v.extract    s4, v53, #9
    v.extract    s11, v53, #10
    v.extract    s13, v53, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s4
    v.extract    s4, v53, #12
    v.extract    s15, v53, #13
    v.extract    s16, v53, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s11
    v.extract    s11, v53, #15
    v.splat      v6, s13
    s.movz       s13, #6
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s4
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s15
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s16
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s11
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s14, v1
    v.extract    s4, v54, #0
    v.extract    s11, v54, #1
    v.splat      v1, s4
    v.splat      v2, s11
    v.extract    s4, v54, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s4
    v.extract    s4, v54, #3
    v.extract    s11, v54, #4
    v.splat      v4, s4
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s11
    v.extract    s4, v54, #5
    v.extract    s11, v54, #6
    v.splat      v3, s4
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s11
    v.extract    s4, v54, #7
    v.extract    s11, v54, #8
    v.splat      v5, s4
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s11
    v.extract    s4, v54, #9
    v.extract    s11, v54, #10
    v.extract    s14, v54, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s4
    v.extract    s4, v54, #12
    v.extract    s15, v54, #13
    v.extract    s16, v54, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s11
    v.extract    s11, v54, #15
    v.splat      v6, s14
    s.movz       s14, #7
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s4
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s15
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s16
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s11
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s13, v1
    v.extract    s4, v55, #0
    v.extract    s11, v55, #1
    v.splat      v1, s4
    v.splat      v2, s11
    v.extract    s4, v55, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s4
    v.extract    s4, v55, #3
    v.extract    s11, v55, #4
    v.splat      v4, s4
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s11
    v.extract    s4, v55, #5
    v.extract    s11, v55, #6
    v.splat      v3, s4
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s11
    v.extract    s4, v55, #7
    v.extract    s11, v55, #8
    v.splat      v5, s4
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s11
    v.extract    s4, v55, #9
    v.extract    s11, v55, #10
    v.extract    s13, v55, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s4
    v.extract    s4, v55, #12
    v.extract    s15, v55, #13
    v.extract    s16, v55, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s11
    v.extract    s11, v55, #15
    v.splat      v6, s13
    s.movz       s13, #8
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s4
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s15
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s16
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s11
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s14, v1
    v.extract    s4, v56, #0
    v.extract    s11, v56, #1
    v.splat      v1, s4
    v.splat      v2, s11
    v.extract    s4, v56, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s4
    v.extract    s4, v56, #3
    v.extract    s11, v56, #4
    v.splat      v4, s4
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s11
    v.extract    s4, v56, #5
    v.extract    s11, v56, #6
    v.splat      v3, s4
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s11
    v.extract    s4, v56, #7
    v.extract    s11, v56, #8
    v.splat      v5, s4
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s11
    v.extract    s4, v56, #9
    v.extract    s11, v56, #10
    v.extract    s14, v56, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s4
    v.extract    s4, v56, #12
    v.extract    s15, v56, #13
    v.extract    s16, v56, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s11
    v.extract    s11, v56, #15
    v.splat      v6, s14
    s.movz       s14, #9
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s4
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s15
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s16
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s11
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s13, v1
    v.extract    s4, v57, #0
    v.extract    s11, v57, #1
    v.splat      v1, s4
    v.splat      v2, s11
    v.extract    s4, v57, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s4
    v.extract    s4, v57, #3
    v.extract    s11, v57, #4
    v.splat      v4, s4
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s11
    v.extract    s4, v57, #5
    v.extract    s11, v57, #6
    v.splat      v3, s4
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s11
    v.extract    s4, v57, #7
    v.extract    s11, v57, #8
    v.splat      v5, s4
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s11
    v.extract    s4, v57, #9
    v.extract    s11, v57, #10
    v.extract    s13, v57, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s4
    v.extract    s4, v57, #12
    v.extract    s15, v57, #13
    v.extract    s16, v57, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s11
    v.extract    s11, v57, #15
    v.splat      v6, s13
    s.movz       s13, #10
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s4
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s15
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s16
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s11
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s14, v1
    v.extract    s4, v58, #0
    v.extract    s11, v58, #1
    v.splat      v1, s4
    v.splat      v2, s11
    v.extract    s4, v58, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s4
    v.extract    s4, v58, #3
    v.extract    s11, v58, #4
    v.splat      v4, s4
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s11
    v.extract    s4, v58, #5
    v.extract    s11, v58, #6
    v.splat      v3, s4
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s11
    v.extract    s4, v58, #7
    v.extract    s11, v58, #8
    v.splat      v5, s4
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s11
    v.extract    s4, v58, #9
    v.extract    s11, v58, #10
    v.extract    s14, v58, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s4
    v.extract    s4, v58, #12
    v.extract    s15, v58, #13
    v.extract    s16, v58, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s11
    v.extract    s11, v58, #15
    v.splat      v6, s14
    s.movz       s14, #11
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s4
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s15
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s16
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s11
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s13, v1
    v.extract    s4, v59, #0
    v.extract    s11, v59, #1
    v.splat      v1, s4
    v.splat      v2, s11
    v.extract    s4, v59, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s4
    v.extract    s4, v59, #3
    v.extract    s11, v59, #4
    v.splat      v4, s4
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s11
    v.extract    s4, v59, #5
    v.extract    s11, v59, #6
    v.splat      v3, s4
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s11
    v.extract    s4, v59, #7
    v.extract    s11, v59, #8
    v.splat      v5, s4
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s11
    v.extract    s4, v59, #9
    v.extract    s11, v59, #10
    v.extract    s13, v59, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s4
    v.extract    s4, v59, #12
    v.extract    s15, v59, #13
    v.extract    s16, v59, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s11
    v.extract    s11, v59, #15
    v.splat      v6, s13
    s.movz       s13, #12
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s4
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s15
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s16
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s11
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s14, v1
    v.extract    s4, v60, #0
    v.extract    s11, v60, #1
    v.splat      v1, s4
    v.splat      v2, s11
    v.extract    s4, v60, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s4
    v.extract    s4, v60, #3
    v.extract    s11, v60, #4
    v.splat      v4, s4
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s11
    v.extract    s4, v60, #5
    v.extract    s11, v60, #6
    v.splat      v3, s4
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s11
    v.extract    s4, v60, #7
    v.extract    s11, v60, #8
    v.splat      v5, s4
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s11
    v.extract    s4, v60, #9
    v.extract    s11, v60, #10
    v.extract    s14, v60, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s4
    v.extract    s4, v60, #12
    v.extract    s15, v60, #13
    v.extract    s16, v60, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s11
    v.extract    s11, v60, #15
    v.splat      v6, s14
    s.movz       s14, #13
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s4
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s15
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s16
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s11
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s13, v1
    v.extract    s4, v61, #0
    v.extract    s11, v61, #1
    v.splat      v1, s4
    v.splat      v2, s11
    v.extract    s4, v61, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s4
    v.extract    s4, v61, #3
    v.extract    s11, v61, #4
    v.splat      v4, s4
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s11
    v.extract    s4, v61, #5
    v.extract    s11, v61, #6
    v.splat      v3, s4
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s11
    v.extract    s4, v61, #7
    v.extract    s11, v61, #8
    v.splat      v5, s4
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s11
    v.extract    s4, v61, #9
    v.extract    s11, v61, #10
    v.extract    s13, v61, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s4
    v.extract    s4, v61, #12
    v.extract    s15, v61, #13
    v.extract    s16, v61, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s11
    v.extract    s11, v61, #15
    v.splat      v6, s13
    s.movz       s13, #14
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s4
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s15
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s16
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s11
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s14, v1
    v.extract    s4, v62, #0
    v.extract    s11, v62, #1
    v.splat      v1, s4
    v.splat      v2, s11
    v.extract    s4, v62, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s4
    v.extract    s4, v62, #3
    v.extract    s11, v62, #4
    v.splat      v4, s4
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s11
    v.extract    s4, v62, #5
    v.extract    s11, v62, #6
    v.splat      v3, s4
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s11
    v.extract    s4, v62, #7
    v.extract    s11, v62, #8
    v.splat      v5, s4
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s11
    v.extract    s4, v62, #9
    v.extract    s11, v62, #10
    v.extract    s14, v62, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s4
    v.extract    s4, v62, #12
    v.extract    s15, v62, #13
    v.extract    s16, v62, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s11
    v.extract    s11, v62, #15
    v.splat      v6, s14
    s.movz       s14, #15
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s4
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s15
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s16
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s11
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s13, v1
    v.extract    s4, v63, #0
    v.extract    s11, v63, #1
    v.splat      v1, s4
    v.splat      v2, s11
    v.extract    s4, v63, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v0, s4
    v.extract    s4, v63, #3
    v.extract    s11, v63, #4
    v.splat      v1, s4
    vf.fma       v4, v2, v33, v3
    v.splat      v2, s11
    v.extract    s4, v63, #5
    v.extract    s11, v63, #6
    v.splat      v3, s4
    vf.fma       v5, v0, v34, v4
    v.splat      v0, s11
    v.extract    s4, v63, #7
    v.extract    s11, v63, #8
    v.splat      v4, s4
    vf.fma       v6, v1, v35, v5
    v.splat      v1, s11
    v.extract    s4, v63, #9
    v.extract    s11, v63, #10
    v.splat      v5, s4
    vf.fma       v7, v2, v36, v6
    v.splat      v2, s11
    v.extract    s4, v63, #11
    v.extract    s11, v63, #12
    v.extract    s13, v63, #13
    vf.fma       v6, v3, v37, v7
    v.splat      v3, s4
    v.extract    s4, v63, #14
    v.extract    s15, v63, #15
    v.splat      v7, s11
    vf.fma       v8, v0, v38, v6
    v.splat      v0, s13
    s.movz       s11, #0
    s.movz       s13, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s16, #0
    vf.fma       v6, v4, v39, v8
    v.splat      v4, s4
    s.movz       s4, #1
    s.movz       s17, #1
    vf.fma       v8, v1, v40, v6
    v.splat      v1, s15
    s.movz       s15, #1
    vf.fma       v6, v5, v41, v8
    vf.fma       v5, v2, v42, v6
    vf.fma       v2, v3, v43, v5
    vf.fma       v3, v7, v44, v2
    vf.fma       v2, v0, v45, v3
    vf.fma       v0, v4, v46, v2
    vf.fma       v2, v1, v47, v0
    a.vwrite     a1, s14, v2
    a.vread      v0, a0, s11
    a.vread      v1, a1, s13
    s.movz       s11, #2
    s.movz       s13, #2
    vf.add       v2, v0, v1
    s.movz       s14, #2
    a.vwrite     a2, s16, v2
    a.vread      v0, a0, s4
    a.vread      v1, a1, s17
    s.movz       s4, #3
    s.movz       s16, #3
    vf.add       v2, v0, v1
    s.movz       s17, #3
    a.vwrite     a2, s15, v2
    a.vread      v0, a0, s11
    a.vread      v1, a1, s13
    s.movz       s11, #4
    s.movz       s13, #4
    vf.add       v2, v0, v1
    s.movz       s15, #4
    a.vwrite     a2, s14, v2
    a.vread      v0, a0, s4
    a.vread      v1, a1, s16
    s.movz       s4, #5
    s.movz       s14, #5
    vf.add       v2, v0, v1
    s.movz       s16, #5
    a.vwrite     a2, s17, v2
    a.vread      v0, a0, s11
    a.vread      v1, a1, s13
    s.movz       s11, #6
    s.movz       s13, #6
    vf.add       v2, v0, v1
    s.movz       s17, #6
    a.vwrite     a2, s15, v2
    a.vread      v0, a0, s4
    a.vread      v1, a1, s14
    s.movz       s4, #7
    s.movz       s14, #7
    vf.add       v2, v0, v1
    s.movz       s15, #7
    a.vwrite     a2, s16, v2
    a.vread      v0, a0, s11
    a.vread      v1, a1, s13
    s.movz       s11, #8
    s.movz       s13, #8
    vf.add       v2, v0, v1
    s.movz       s16, #8
    a.vwrite     a2, s17, v2
    a.vread      v0, a0, s4
    a.vread      v1, a1, s14
    s.movz       s4, #9
    s.movz       s14, #9
    vf.add       v2, v0, v1
    s.movz       s17, #9
    a.vwrite     a2, s15, v2
    a.vread      v0, a0, s11
    a.vread      v1, a1, s13
    s.movz       s11, #10
    s.movz       s13, #10
    vf.add       v2, v0, v1
    s.movz       s15, #10
    a.vwrite     a2, s16, v2
    a.vread      v0, a0, s4
    a.vread      v1, a1, s14
    s.movz       s4, #11
    s.movz       s14, #11
    vf.add       v2, v0, v1
    s.movz       s16, #11
    a.vwrite     a2, s17, v2
    a.vread      v0, a0, s11
    a.vread      v1, a1, s13
    s.movz       s11, #12
    s.movz       s13, #12
    vf.add       v2, v0, v1
    s.movz       s17, #12
    a.vwrite     a2, s15, v2
    a.vread      v0, a0, s4
    a.vread      v1, a1, s14
    s.movz       s4, #13
    s.movz       s14, #13
    vf.add       v2, v0, v1
    s.movz       s15, #13
    a.vwrite     a2, s16, v2
    a.vread      v0, a0, s11
    a.vread      v1, a1, s13
    s.movz       s11, #14
    s.movz       s13, #14
    vf.add       v2, v0, v1
    s.movz       s16, #14
    a.vwrite     a2, s17, v2
    a.vread      v0, a0, s4
    a.vread      v1, a1, s14
    s.movz       s4, #15
    s.movz       s14, #15
    vf.add       v2, v0, v1
    s.movz       s17, #15
    a.vwrite     a2, s15, v2
    a.vread      v0, a0, s11
    a.vread      v1, a1, s13
    s.movz       s11, #0
    s.movz       s13, #0
    vf.add       v2, v0, v1
    s.movz       s15, #1
    a.vwrite     a2, s16, v2
    a.vread      v0, a0, s4
    a.vread      v1, a1, s14
    s.movz       s4, #1
    s.movz       s14, #2
    vf.add       v2, v0, v1
    s.movz       s16, #2
    a.vwrite     a2, s17, v2
    a.vread      v0, a2, s11
    s.movz       s11, #3
    s.movz       s17, #3
    a.vwrite     a0, s13, v0
    a.vread      v0, a2, s15
    s.movz       s13, #4
    s.movz       s15, #4
    a.vwrite     a0, s4, v0
    a.vread      v0, a2, s14
    s.movz       s4, #5
    s.movz       s14, #5
    a.vwrite     a0, s16, v0
    a.vread      v0, a2, s11
    s.movz       s11, #6
    s.movz       s16, #6
    a.vwrite     a0, s17, v0
    a.vread      v0, a2, s13
    s.movz       s13, #7
    s.movz       s17, #7
    a.vwrite     a0, s15, v0
    a.vread      v0, a2, s4
    s.movz       s4, #8
    s.movz       s15, #8
    a.vwrite     a0, s14, v0
    a.vread      v0, a2, s11
    s.movz       s11, #9
    s.movz       s14, #9
    a.vwrite     a0, s16, v0
    a.vread      v0, a2, s13
    s.movz       s13, #10
    s.movz       s16, #10
    a.vwrite     a0, s17, v0
    a.vread      v0, a2, s4
    s.movz       s4, #11
    s.movz       s17, #11
    a.vwrite     a0, s15, v0
    a.vread      v0, a2, s11
    s.movz       s11, #12
    s.movz       s15, #12
    a.vwrite     a0, s14, v0
    a.vread      v0, a2, s13
    s.movz       s13, #13
    s.movz       s14, #13
    a.vwrite     a0, s16, v0
    a.vread      v0, a2, s4
    s.movz       s4, #14
    s.movz       s16, #14
    a.vwrite     a0, s17, v0
    a.vread      v0, a2, s11
    s.movz       s11, #15
    s.movz       s17, #15
    a.vwrite     a0, s15, v0
    a.vread      v0, a2, s13
    s.add        s13, s9, s2
    s.movz       s15, #1
    a.vwrite     a0, s14, v0
    a.vread      v0, a2, s4
    a.vwrite     a0, s16, v0
    a.vread      v0, a2, s11
    a.vwrite     a0, s17, v0
    s.mov        s9, s13
    br.nz        s15, for_5
endfor_6:
    s.movz       s1, #0
    s.movz       s2, #0
    s.add        s3, s1, s5                      // the tile origin
    s.muli       s1, s5, #4                      // a runtime tile origin, x4
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s3
    s.add        s3, s2, s6                      // the tile origin
    s.movz       s2, #128
    s.muli       s4, s6, #512                    // a runtime tile origin, x512
    v.splat      v2, s3
    v.splat      v3, s2
    v.add        v4, v0, v1
    v.splat      v0, s2
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s2, #0
    s.addi       s5, s3, #1
    s.add        s6, s21, s1                     // the tile origin
    a.vread      v1, a0, s2
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v4, v0
    v.splat      v0, s5
    s.add        s1, s6, s4                      // the tile origin
    p.and        p3, p1, p2
    s.movz       s2, #1
    s.addi       s4, s3, #2
    @p3 v.st.w       [s1, #0], v1
    a.vread      v1, a0, s2
    v.cmp.lt     p1, v0, v3
    v.splat      v0, s4
    s.addi       s2, s1, #512                    // row 1
    p.and        p3, p1, p2
    s.movz       s4, #2
    s.addi       s5, s3, #3
    v.cmp.lt     p1, v0, v3
    v.splat      v0, s5
    s.addi       s5, s1, #1024                   // row 2
    p.and        p4, p1, p2
    s.movz       s6, #3
    s.addi       s7, s3, #4
    s.addi       s8, s1, #1536                   // row 3
    v.splat      v2, s7
    s.movz       s7, #4
    s.addi       s9, s3, #5
    @p3 v.st.w       [s2, #0], v1
    a.vread      v1, a0, s4
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    v.splat      v0, s9
    s.addi       s2, s1, #2048                   // row 4
    s.movz       s4, #5
    s.addi       s9, s3, #6
    v.splat      v4, s9
    s.addi       s9, s1, #2560                   // row 5
    @p4 v.st.w       [s5, #0], v1
    a.vread      v1, a0, s6
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.movz       s5, #6
    s.addi       s6, s3, #7
    v.splat      v2, s6
    s.addi       s6, s1, #3072                   // row 6
    @p3 v.st.w       [s8, #0], v1
    a.vread      v1, a0, s7
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.movz       s7, #7
    s.addi       s8, s3, #8
    v.splat      v0, s8
    s.addi       s8, s1, #3584                   // row 7
    @p4 v.st.w       [s2, #0], v1
    a.vread      v1, a0, s4
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    s.movz       s2, #8
    s.addi       s4, s3, #9
    v.splat      v4, s4
    s.addi       s4, s1, #4096                   // row 8
    @p3 v.st.w       [s9, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    s.movz       s5, #9
    s.addi       s9, s3, #10
    v.splat      v2, s9
    s.addi       s9, s1, #4608                   // row 9
    @p4 v.st.w       [s6, #0], v1
    a.vread      v1, a0, s7
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.movz       s6, #10
    s.addi       s7, s3, #11
    v.splat      v0, s7
    s.addi       s7, s1, #5120                   // row 10
    @p3 v.st.w       [s8, #0], v1
    a.vread      v1, a0, s2
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    s.movz       s2, #11
    s.addi       s8, s3, #12
    v.splat      v4, s8
    s.addi       s8, s1, #5632                   // row 11
    @p4 v.st.w       [s4, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.movz       s4, #12
    s.addi       s5, s3, #13
    v.splat      v2, s5
    s.addi       s5, s1, #6144                   // row 12
    @p3 v.st.w       [s9, #0], v1
    a.vread      v1, a0, s6
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.movz       s6, #13
    s.addi       s9, s3, #14
    s.addi       s11, s3, #15
    v.splat      v0, s9
    s.addi       s3, s1, #6656                   // row 13
    v.splat      v5, s11
    s.movz       s9, #14
    @p4 v.st.w       [s7, #0], v1
    a.vread      v1, a0, s2
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    s.addi       s2, s1, #7168                   // row 14
    s.movz       s7, #15
    s.addi       s11, s1, #7680                  // row 15
    @p3 v.st.w       [s8, #0], v1
    a.vread      v1, a0, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p4 v.st.w       [s5, #0], v1
    a.vread      v1, a0, s6
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    @p3 v.st.w       [s3, #0], v1
    a.vread      v0, a0, s9
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    @p4 v.st.w       [s2, #0], v0
    a.vread      v0, a0, s7
    @p3 v.st.w       [s11, #0], v0
__rctx_next:
    exit
