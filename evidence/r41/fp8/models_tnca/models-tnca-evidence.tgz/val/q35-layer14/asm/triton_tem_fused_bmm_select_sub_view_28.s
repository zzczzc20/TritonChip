    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s3, s4, s1
    s.movz       s1, #8
    s.movz       s5, #0
    s.sub        s6, s2, s3
    s.movz       s2, #0
    s.cmp.lt     s3, s1, s5
    s.xor        s5, s4, s6
    s.sub        s7, s2, s3
    s.sub        s2, s5, s6
    s.xor        s3, s6, s7
    s.lshri      s5, s2, #3
    s.movz       s6, #4
    s.xor        s8, s5, s3
    s.movz       s9, #1
    s.sub        s10, s8, s3
    s.movz       s3, #0
    s.sub        s8, s6, s10
    s.movz       s6, #0
    s.min.s      s11, s8, s9
    s.movz       s8, #0
    s.cmp.lt     s9, s11, s3
    s.movz       s3, #0
    s.cmp.lt     s12, s4, s6
    s.sub        s6, s8, s9
    s.sub        s8, s3, s12
    s.xor        s3, s11, s6
    s.muli       s9, s5, #8
    s.movz       s5, #0
    s.movz       s12, #1
    s.xor        s13, s4, s8
    s.sub        s14, s3, s6
    s.rdspecial  s3, arg_base
    s.xor        s6, s1, s7
    s.movz       s15, #0
    s.sub        s16, s13, s8
    s.addi       s13, s5, #0
    s.cmp.eq     s5, s14, s12
    s.ld.d       s12, [s3, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.sub        s17, s6, s7
    s.sub        s6, s2, s9
    s.ld.d       s2, [s3, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.addi       s6, s15, #0
    s.ld.d       s7, [s3, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s9, [s3, #24]                   // out_ptr1: device_ptr64 at arg_base+24
    s.mov        s13, s16
    br.nz        s5, sdiv_done_1
    s.movz       s3, #0
    s.movz       s5, #31
    s.mov        s13, s3
    s.addi       s3, s5, #0
sdiv_2:
    s.lshr       s5, s16, s3
    s.shli       s15, s6, #1
    s.andi       s17, s5, #1
    s.movz       s5, #0
    s.or         s18, s15, s17
    s.movz       s15, #1
    s.cmp.geu    s17, s18, s14
    s.shl        s19, s15, s3
    s.sub        s15, s5, s17
    s.subi       s5, s3, #1
    s.and        s17, s14, s15
    s.and        s20, s19, s15
    s.sub        s15, s18, s17
    s.or         s17, s13, s20
    s.mov        s6, s15
    s.mov        s13, s17
    s.mov        s3, s5
    s.movz       s5, #0
    s.cmp.ge     s15, s3, s5
    br.nz        s15, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s5, #0
    s.cmp.lt     s13, s4, s3
    s.movz       s3, #0
    s.sub        s14, s5, s13
    s.movz       s5, #0
    s.xor        s13, s4, s14
    s.movz       s4, #0
    s.sub        s15, s13, s14
    s.cmp.lt     s13, s11, s3
    s.lshri      s3, s15, #3
    s.movz       s16, #0
    s.muli       s17, s3, #8
    s.sub        s3, s4, s13
    s.movz       s4, #0
    s.cmp.lt     s13, s1, s16
    s.xor        s16, s11, s3
    s.sub        s11, s15, s17
    s.movz       s15, #0
    s.xor        s17, s11, s14
    s.xor        s11, s6, s8
    s.sub        s6, s17, s14
    s.sub        s14, s15, s13
    s.cmp.lt     s13, s6, s5
    s.sub        s5, s16, s3
    s.sub        s15, s4, s13
    s.movz       s4, #0
    s.xor        s13, s6, s15
    s.movz       s6, #1
    s.sub        s16, s11, s8
    s.xor        s8, s1, s14
    s.sub        s1, s13, s15
    s.movz       s11, #0
    s.addi       s13, s4, #0
    s.cmp.eq     s4, s5, s6
    s.add        s6, s10, s16
    s.sub        s10, s8, s14
    s.addi       s8, s11, #0
    s.mov        s13, s1
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.movz       s10, #31
    s.mov        s13, s4
    s.addi       s4, s10, #0
sdiv_4:
    s.lshr       s10, s1, s4
    s.shli       s11, s8, #1
    s.andi       s14, s10, #1
    s.movz       s10, #0
    s.or         s16, s11, s14
    s.movz       s11, #1
    s.cmp.geu    s14, s16, s5
    s.shl        s17, s11, s4
    s.sub        s11, s10, s14
    s.subi       s10, s4, #1
    s.and        s14, s5, s11
    s.and        s18, s17, s11
    s.sub        s11, s16, s14
    s.or         s14, s13, s18
    s.mov        s8, s11
    s.mov        s13, s14
    s.mov        s4, s10
    s.movz       s10, #0
    s.cmp.ge     s11, s4, s10
    br.nz        s11, sdiv_4
sdiv_done_3:
    s.movz       s1, #16
    s.rdspecial  s4, pid.z
    s.rdspecial  s5, npid.y
    s.xor        s8, s15, s3
    s.mul        s3, s6, s1
    s.mul        s10, s4, s5
    s.xor        s4, s13, s8
    s.rdspecial  s5, pid.y
    s.sub        s11, s4, s8
    s.andi       s4, s3, #63
    s.mul        s8, s11, s1
    s.add        s13, s5, s10
    s.movz       s5, #31
    s.movz       s10, #16384
    s.min.s      s14, s13, s5
    s.muli       s5, s4, #128                    // a runtime tile origin, x128
    s.mul        s15, s14, s10
    s.rdspecial  s14, role_id
    s.movz       s16, #7168
    s.andi       s17, s8, #127
    s.movz       s18, #0
    s.rdspecial  s19, arg_base
    s.mul        s20, s14, s16
    s.add        s14, s18, s5                    // the tile origin
    s.ld.d       s5, [s19, #32]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.add        s16, s14, s15                   // the tile origin
    s.movz       s14, #0
    s.add        s18, s5, s20                    // this context's own scratch
    v.iota       v0                              // arange(0, VLEN)
    s.addi       s5, s18, #0
    v.splat      v1, s16
    v.splat      v2, s6
    v.splat      v3, s14
    s.addi       s6, s16, #128
    v.splat      v4, s11
    v.splat      v5, s14
    v.add        v6, v0, v1
    s.addi       s11, s5, #64
    v.cmp.ge     p1, v2, v3
    v.splat      v1, s6
    v.iota       v2                              // arange(0, VLEN)
    v.add        v3, v0, v1
    v.cmp.ge     p1, v4, v5
    s.addi       s6, s16, #256
    v.splat      v1, s3
    v.splat      v4, s6
    s.addi       s6, s5, #128
    v.add        v5, v0, v4
    v.add        v4, v1, v2
    s.addi       s19, s16, #384
    v.splat      v1, s8
    s.addi       s20, s5, #192
    v.add        v4, v1, v2
    v.splat      v1, s19
    v.splat      v2, s4
    v.add        v4, v0, v1
    s.addi       s4, s5, #256
    s.movz       s19, #128
    s.addi       s21, s14, #0
    v.st.w       [s5, #0], v6
    v.iota       v1                              // arange(0, VLEN)
    s.addi       s22, s16, #512
    v.add        v6, v2, v1
    v.splat      v1, s22
    v.splat      v2, s17
    v.add        v6, v0, v1
    v.st.w       [s11, #0], v3
    v.iota       v1                              // arange(0, VLEN)
    s.addi       s11, s5, #320
    v.add        v3, v2, v1
    s.addi       s22, s16, #640
    s.addi       s23, s16, #768
    v.splat      v1, s22
    s.addi       s22, s16, #896
    v.splat      v2, s23
    s.addi       s23, s16, #1024
    v.add        v3, v0, v1
    v.add        v1, v0, v2
    v.st.w       [s6, #0], v5
    s.addi       s6, s16, #1152
    v.splat      v2, s22
    s.addi       s22, s16, #1280
    v.add        v5, v0, v2
    v.st.w       [s20, #0], v4
    s.addi       s20, s16, #1408
    v.splat      v2, s23
    s.addi       s23, s16, #1536
    v.add        v4, v0, v2
    v.st.w       [s4, #0], v6
    s.addi       s4, s16, #1664
    v.splat      v2, s6
    s.addi       s6, s16, #1792
    s.addi       s24, s16, #1920
    v.add        v6, v0, v2
    v.st.w       [s11, #0], v3
    v.splat      v2, s22
    s.addi       s11, s5, #384
    s.addi       s16, s18, #1024
    v.add        v3, v0, v2
    v.st.w       [s11, #0], v1
    s.movz       s11, #0
    v.splat      v1, s20
    s.addi       s20, s5, #448
    s.add        s22, s11, s17                   // the tile origin
    s.addi       s11, s5, #512
    s.add        s17, s22, s15                   // the tile origin
    s.addi       s15, s5, #576
    v.add        v2, v0, v1
    v.st.w       [s20, #0], v5
    s.addi       s20, s17, #128
    v.splat      v1, s23
    s.addi       s22, s5, #640
    v.add        v5, v0, v1
    v.st.w       [s11, #0], v4
    s.addi       s11, s17, #256
    v.splat      v1, s4
    s.addi       s4, s5, #704
    v.add        v4, v0, v1
    v.st.w       [s15, #0], v6
    s.addi       s15, s17, #384
    v.splat      v1, s6
    s.addi       s6, s5, #768
    v.add        v6, v0, v1
    v.st.w       [s22, #0], v3
    s.addi       s22, s17, #512
    v.splat      v1, s24
    s.addi       s23, s5, #832
    v.add        v3, v0, v1
    v.st.w       [s4, #0], v2
    s.addi       s4, s17, #640
    v.splat      v1, s17
    v.add        v2, v0, v1
    v.st.w       [s6, #0], v5
    s.addi       s6, s17, #768
    v.splat      v1, s20
    s.addi       s20, s5, #896
    s.addi       s24, s5, #960
    v.add        v5, v0, v1
    v.st.w       [s23, #0], v4
    s.addi       s5, s17, #896
    v.splat      v1, s11
    s.addi       s11, s16, #64
    v.add        v4, v0, v1
    v.st.w       [s20, #0], v6
    s.addi       s20, s17, #1024
    v.splat      v1, s15
    s.addi       s15, s16, #128
    v.add        v6, v0, v1
    v.st.w       [s24, #0], v3
    v.splat      v1, s22
    s.addi       s22, s16, #192
    s.addi       s23, s16, #256
    v.add        v3, v0, v1
    fence.acq_rel.device
    v.st.w       [s16, #0], v2
    v.splat      v1, s4
    s.addi       s4, s17, #1152
    v.add        v2, v0, v1
    v.st.w       [s11, #0], v5
    s.addi       s11, s17, #1280
    v.splat      v1, s6
    s.addi       s6, s17, #1408
    v.add        v5, v0, v1
    v.st.w       [s15, #0], v4
    s.addi       s15, s17, #1536
    v.splat      v1, s5
    s.addi       s5, s17, #1664
    v.add        v4, v0, v1
    v.st.w       [s22, #0], v6
    s.addi       s22, s17, #1792
    v.splat      v1, s20
    s.addi       s20, s16, #320
    v.add        v6, v0, v1
    v.st.w       [s23, #0], v3
    s.addi       s23, s17, #1920
    v.splat      v1, s4
    s.addi       s4, s16, #384
    s.addi       s17, s16, #448
    v.add        v3, v0, v1
    v.st.w       [s20, #0], v2
    v.splat      v1, s11
    s.addi       s11, s16, #512
    s.addi       s20, s16, #576
    v.add        v2, v0, v1
    v.st.w       [s4, #0], v5
    v.splat      v1, s6
    s.addi       s4, s16, #640
    s.addi       s6, s16, #704
    v.add        v5, v0, v1
    v.st.w       [s17, #0], v4
    v.splat      v1, s15
    s.addi       s15, s16, #768
    v.add        v4, v0, v1
    s.addi       s17, s16, #832
    v.st.w       [s11, #0], v6
    v.splat      v1, s5
    s.addi       s5, s16, #896
    v.add        v6, v0, v1
    s.addi       s11, s16, #960
    v.st.w       [s20, #0], v3
    v.splat      v1, s22
    v.add        v3, v0, v1
    v.st.w       [s4, #0], v2
    v.splat      v1, s23
    v.add        v2, v0, v1
    v.st.w       [s6, #0], v5
    v.st.w       [s15, #0], v4
    v.st.w       [s17, #0], v6
    v.st.w       [s5, #0], v3
    v.st.w       [s11, #0], v2
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s4, s21, s19
    br.nz        s4, endfor_6
    s.addi       s4, s18, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s5, #0
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #64
    s.movz       s6, #1
    s.addi       s11, s18, #128
    s.movz       s15, #2
    s.addi       s16, s18, #192
    v.ld.gather.w v2, [s12, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s5, v2
    v.ld.w       v1, [s4, #0]
    s.movz       s4, #3
    s.addi       s5, s18, #256
    v.ld.gather.w v2, [s12, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s6, v2
    v.ld.w       v1, [s11, #0]
    s.movz       s6, #4
    s.addi       s11, s18, #320
    v.ld.gather.w v2, [s12, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s15, v2
    v.ld.w       v1, [s16, #0]
    s.movz       s15, #5
    s.addi       s16, s18, #384
    v.ld.gather.w v2, [s12, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s4, v2
    v.ld.w       v1, [s5, #0]
    s.movz       s4, #6
    s.addi       s5, s18, #448
    v.ld.gather.w v2, [s12, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s6, v2
    v.ld.w       v1, [s11, #0]
    s.movz       s6, #7
    s.addi       s11, s18, #512
    v.ld.gather.w v2, [s12, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s15, v2
    v.ld.w       v1, [s16, #0]
    s.movz       s15, #8
    s.addi       s16, s18, #576
    v.ld.gather.w v2, [s12, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s4, v2
    v.ld.w       v1, [s5, #0]
    s.movz       s4, #9
    s.addi       s5, s18, #640
    v.ld.gather.w v2, [s12, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s6, v2
    v.ld.w       v1, [s11, #0]
    s.movz       s6, #10
    s.addi       s11, s18, #704
    v.ld.gather.w v2, [s12, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s15, v2
    v.ld.w       v1, [s16, #0]
    s.movz       s15, #11
    s.addi       s16, s18, #768
    v.ld.gather.w v2, [s12, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s4, v2
    v.ld.w       v1, [s5, #0]
    s.movz       s4, #12
    s.addi       s5, s18, #832
    v.ld.gather.w v2, [s12, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s6, v2
    v.ld.w       v1, [s11, #0]
    s.movz       s6, #13
    s.addi       s11, s18, #896
    v.ld.gather.w v2, [s12, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s15, v2
    v.ld.w       v1, [s16, #0]
    s.movz       s15, #14
    s.addi       s16, s18, #960
    v.ld.gather.w v2, [s12, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s4, v2
    v.ld.w       v1, [s5, #0]
    s.movz       s4, #15
    s.addi       s5, s18, #1024
    v.ld.gather.w v2, [s12, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s6, v2
    v.ld.w       v1, [s11, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s6, #0
    s.addi       s11, s18, #1088
    v.ld.gather.w v2, [s12, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s15, v2
    v.ld.w       v1, [s16, #0]
    s.movz       s15, #1
    s.addi       s16, s18, #1152
    v.ld.gather.w v2, [s12, v1]                  // index is in elements (ISA sec 9.1)
    s.movz       s17, #2
    a.vwrite     a1, s4, v2
    v.ld.w       v1, [s5, #0]
    s.addi       s4, s18, #1216
    s.movz       s5, #3
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s6, v2
    v.ld.w       v1, [s11, #0]
    s.addi       s6, s18, #1280
    s.movz       s11, #4
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v2
    v.ld.w       v1, [s16, #0]
    s.addi       s15, s18, #1344
    s.movz       s16, #5
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s17, v2
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #1408
    s.movz       s17, #6
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s5, v2
    v.ld.w       v1, [s6, #0]
    s.addi       s5, s18, #1472
    s.movz       s6, #7
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s11, v2
    v.ld.w       v1, [s15, #0]
    s.addi       s11, s18, #1536
    s.movz       s15, #8
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s16, v2
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #1600
    s.movz       s16, #9
    v.movi       v2, #0
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s17, v3
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s18, #1664
    s.movz       s17, #10
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s6, v3
    v.ld.w       v1, [s11, #0]
    s.addi       s6, s18, #1728
    s.movz       s11, #11
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v3
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #1792
    s.movz       s15, #12
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s16, v3
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s18, #1856
    s.movz       s16, #13
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s17, v3
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s18, #1920
    s.movz       s17, #14
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s11, v3
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #1984
    s.movz       s11, #15
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v3
    v.ld.w       v1, [s5, #0]
    s.movz       s5, #0
    s.movz       s15, #0
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s16, v3
    v.ld.w       v1, [s6, #0]
    s.movz       s6, #1
    s.movz       s16, #2
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s17, v3
    v.ld.w       v1, [s4, #0]
    s.movz       s4, #3
    s.movz       s17, #4
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    s.movz       s20, #5
    a.vwrite     a2, s11, v3
    a.vread      v1, a1, s5
    a.vread      v3, a2, s15
    v.extract    s5, v1, #0
    v.splat      v4, s5
    v.extract    s5, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s5
    a.vread      v4, a2, s6
    v.extract    s5, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s5
    a.vread      v4, a2, s16
    v.extract    s5, v1, #3
    vf.fma       v5, v3, v4, v6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    v.extract    s4, v1, #4
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s17
    v.extract    s4, v1, #5
    vf.fma       v5, v3, v4, v6
    v.splat      v3, s4
    a.vread      v4, a2, s20
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s4, #0
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #1
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s11, #1
    s.movz       s15, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s4
    a.vread      v4, a2, s11
    v.extract    s4, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s15
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #1
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #2
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s11, #1
    s.movz       s15, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s4
    a.vread      v4, a2, s11
    v.extract    s4, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s15
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #2
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #3
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s11, #1
    s.movz       s15, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s4
    a.vread      v4, a2, s11
    v.extract    s4, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s15
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #4
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s11, #1
    s.movz       s15, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s4
    a.vread      v4, a2, s11
    v.extract    s4, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s15
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #5
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s11, #1
    s.movz       s15, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s4
    a.vread      v4, a2, s11
    v.extract    s4, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s15
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #6
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s11, #1
    s.movz       s15, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s4
    a.vread      v4, a2, s11
    v.extract    s4, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s15
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #7
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s11, #1
    s.movz       s15, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s4
    a.vread      v4, a2, s11
    v.extract    s4, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s15
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #8
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s11, #1
    s.movz       s15, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s4
    a.vread      v4, a2, s11
    v.extract    s4, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s15
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #9
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s11, #1
    s.movz       s15, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s4
    a.vread      v4, a2, s11
    v.extract    s4, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s15
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #9
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #10
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s11, #1
    s.movz       s15, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s4
    a.vread      v4, a2, s11
    v.extract    s4, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s15
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #10
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #11
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s11, #1
    s.movz       s15, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s4
    a.vread      v4, a2, s11
    v.extract    s4, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s15
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #11
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #12
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s11, #1
    s.movz       s15, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s4
    a.vread      v4, a2, s11
    v.extract    s4, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s15
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #12
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #13
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s11, #1
    s.movz       s15, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s4
    a.vread      v4, a2, s11
    v.extract    s4, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s15
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #13
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #14
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s11, #1
    s.movz       s15, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s4
    a.vread      v4, a2, s11
    v.extract    s4, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s4
    a.vread      v4, a2, s15
    s.movz       s4, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s4
    s.movz       s4, #14
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #15
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s11, #1
    s.movz       s15, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v2, s4
    a.vread      v3, a2, s11
    v.extract    s4, v1, #2
    vf.fma       v4, v2, v3, v5
    v.splat      v2, s4
    a.vread      v3, a2, s15
    s.movz       s4, #3
    vf.fma       v5, v2, v3, v4
    v.extract    s5, v1, #3
    v.splat      v2, s5
    a.vread      v3, a2, s4
    s.movz       s4, #4
    vf.fma       v4, v2, v3, v5
    v.extract    s5, v1, #4
    v.splat      v2, s5
    a.vread      v3, a2, s4
    s.movz       s4, #5
    vf.fma       v5, v2, v3, v4
    v.extract    s5, v1, #5
    v.splat      v2, s5
    a.vread      v3, a2, s4
    s.movz       s4, #6
    vf.fma       v4, v2, v3, v5
    v.extract    s5, v1, #6
    v.splat      v2, s5
    a.vread      v3, a2, s4
    s.movz       s4, #7
    vf.fma       v5, v2, v3, v4
    v.extract    s5, v1, #7
    v.splat      v2, s5
    a.vread      v3, a2, s4
    s.movz       s4, #8
    vf.fma       v4, v2, v3, v5
    v.extract    s5, v1, #8
    v.splat      v2, s5
    a.vread      v3, a2, s4
    s.movz       s4, #15
    vf.fma       v5, v2, v3, v4
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v2, s6
    a.vread      v3, a2, s5
    s.movz       s5, #10
    vf.fma       v4, v2, v3, v5
    v.extract    s6, v1, #10
    v.splat      v2, s6
    a.vread      v3, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v2, v3, v4
    v.extract    s6, v1, #11
    v.splat      v2, s6
    a.vread      v3, a2, s5
    s.movz       s5, #12
    vf.fma       v4, v2, v3, v5
    v.extract    s6, v1, #12
    v.splat      v2, s6
    a.vread      v3, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v2, v3, v4
    v.extract    s6, v1, #13
    v.splat      v2, s6
    a.vread      v3, a2, s5
    s.movz       s5, #14
    vf.fma       v4, v2, v3, v5
    v.extract    s6, v1, #14
    v.splat      v2, s6
    a.vread      v3, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v2, v3, v4
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v2, a2, s5
    s.addi       s5, s18, #0
    vf.fma       v3, v1, v2, v5
    v.splat      v1, s1
    s.addi       s6, s18, #2048
    s.addi       s11, s18, #64
    a.vwrite     a3, s4, v3
    v.ld.w       v2, [s5, #0]
    s.addi       s4, s6, #64
    s.addi       s5, s18, #128
    s.addi       s15, s6, #128
    s.addi       s16, s18, #192
    s.addi       s17, s6, #192
    s.addi       s20, s18, #256
    v.add        v3, v2, v1
    v.st.w       [s6, #0], v3
    v.ld.w       v2, [s11, #0]
    s.addi       s11, s6, #256
    v.add        v3, v2, v1
    v.st.w       [s4, #0], v3
    s.addi       s4, s18, #320
    v.ld.w       v2, [s5, #0]
    s.addi       s5, s6, #320
    v.add        v3, v2, v1
    v.st.w       [s15, #0], v3
    s.addi       s15, s18, #384
    v.ld.w       v2, [s16, #0]
    s.addi       s16, s6, #384
    v.add        v3, v2, v1
    v.st.w       [s17, #0], v3
    s.addi       s17, s18, #448
    v.ld.w       v2, [s20, #0]
    s.addi       s20, s6, #448
    v.add        v3, v2, v1
    v.st.w       [s11, #0], v3
    s.addi       s11, s18, #512
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s6, #512
    v.add        v3, v2, v1
    v.st.w       [s5, #0], v3
    s.addi       s5, s18, #576
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s6, #576
    v.add        v3, v2, v1
    v.st.w       [s16, #0], v3
    s.addi       s16, s18, #640
    v.ld.w       v2, [s17, #0]
    s.addi       s17, s6, #640
    v.add        v3, v2, v1
    v.st.w       [s20, #0], v3
    s.addi       s20, s18, #704
    v.ld.w       v2, [s11, #0]
    s.addi       s11, s6, #704
    v.add        v3, v2, v1
    v.st.w       [s4, #0], v3
    s.addi       s4, s18, #768
    v.ld.w       v2, [s5, #0]
    s.addi       s5, s6, #768
    v.add        v3, v2, v1
    v.st.w       [s15, #0], v3
    s.addi       s15, s18, #832
    v.ld.w       v2, [s16, #0]
    s.addi       s16, s6, #832
    v.add        v3, v2, v1
    v.st.w       [s17, #0], v3
    s.addi       s17, s18, #896
    v.ld.w       v2, [s20, #0]
    s.addi       s20, s6, #896
    s.addi       s22, s6, #960
    v.add        v3, v2, v1
    v.st.w       [s11, #0], v3
    s.addi       s6, s18, #960
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s18, #1024
    v.add        v3, v2, v1
    v.st.w       [s5, #0], v3
    s.movz       s5, #2048
    v.splat      v2, s5
    s.addi       s5, s18, #3072
    v.ld.w       v3, [s15, #0]
    s.addi       s11, s18, #1088
    v.add        v4, v3, v1
    v.st.w       [s16, #0], v4
    s.addi       s15, s5, #64
    v.ld.w       v3, [s17, #0]
    s.addi       s16, s18, #1152
    v.add        v4, v3, v1
    v.st.w       [s20, #0], v4
    s.addi       s17, s5, #128
    v.ld.w       v3, [s6, #0]
    s.addi       s6, s18, #1216
    v.add        v4, v3, v1
    v.st.w       [s22, #0], v4
    fence.acq_rel.device
    s.addi       s20, s5, #192
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #1280
    v.add        v3, v1, v2
    v.st.w       [s5, #0], v3
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s5, #256
    v.add        v3, v1, v2
    v.st.w       [s15, #0], v3
    s.addi       s15, s18, #1344
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s5, #320
    v.add        v3, v1, v2
    v.st.w       [s17, #0], v3
    s.addi       s17, s18, #1408
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s5, #384
    v.add        v3, v1, v2
    v.st.w       [s20, #0], v3
    s.addi       s20, s18, #1472
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s5, #448
    v.add        v3, v1, v2
    v.st.w       [s11, #0], v3
    s.addi       s11, s18, #1536
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s5, #512
    v.add        v3, v1, v2
    v.st.w       [s16, #0], v3
    s.addi       s16, s18, #1600
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s5, #576
    v.add        v3, v1, v2
    v.st.w       [s6, #0], v3
    s.addi       s6, s18, #1664
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s5, #640
    v.add        v3, v1, v2
    v.st.w       [s4, #0], v3
    s.addi       s4, s18, #1728
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s5, #704
    v.add        v3, v1, v2
    v.st.w       [s15, #0], v3
    s.addi       s15, s18, #1792
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s5, #768
    v.add        v3, v1, v2
    v.st.w       [s17, #0], v3
    s.addi       s17, s18, #1856
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s5, #832
    v.add        v3, v1, v2
    v.st.w       [s20, #0], v3
    s.addi       s20, s18, #1920
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s5, #896
    s.addi       s22, s5, #960
    v.add        v3, v1, v2
    v.st.w       [s11, #0], v3
    s.addi       s5, s18, #1984
    v.ld.w       v1, [s15, #0]
    s.addi       s11, s18, #2048
    v.add        v3, v1, v2
    v.st.w       [s16, #0], v3
    s.addi       s15, s18, #4096
    v.ld.w       v1, [s17, #0]
    s.addi       s16, s18, #2112
    v.add        v3, v1, v2
    v.st.w       [s6, #0], v3
    s.addi       s6, s15, #64
    v.ld.w       v1, [s20, #0]
    s.addi       s17, s18, #2176
    v.add        v3, v1, v2
    v.st.w       [s4, #0], v3
    s.addi       s4, s15, #128
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s18, #2240
    v.add        v3, v1, v2
    v.st.w       [s22, #0], v3
    fence.acq_rel.device
    s.addi       s20, s15, #192
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s18, #2304
    v.st.w       [s15, #0], v1
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s15, #256
    v.st.w       [s6, #0], v1
    s.addi       s6, s18, #2368
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s15, #320
    v.st.w       [s4, #0], v1
    s.addi       s4, s18, #2432
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s15, #384
    v.st.w       [s20, #0], v1
    s.addi       s20, s18, #2496
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s15, #448
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #2560
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s15, #512
    v.st.w       [s17, #0], v1
    s.addi       s17, s18, #2624
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s15, #576
    v.st.w       [s5, #0], v1
    s.addi       s5, s18, #2688
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s15, #640
    v.st.w       [s11, #0], v1
    s.addi       s11, s18, #2752
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s15, #704
    v.st.w       [s6, #0], v1
    s.addi       s6, s18, #2816
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s15, #768
    v.st.w       [s4, #0], v1
    s.addi       s4, s18, #2880
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s15, #832
    v.st.w       [s20, #0], v1
    s.addi       s20, s18, #2944
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s15, #896
    s.addi       s22, s15, #960
    v.st.w       [s16, #0], v1
    s.addi       s15, s18, #3008
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s18, #3072
    v.st.w       [s17, #0], v1
    s.addi       s16, s18, #5120
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #3136
    v.st.w       [s5, #0], v1
    s.addi       s5, s16, #64
    v.ld.w       v1, [s20, #0]
    s.addi       s17, s18, #3200
    v.st.w       [s11, #0], v1
    s.addi       s11, s16, #128
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s18, #3264
    v.st.w       [s22, #0], v1
    fence.acq_rel.device
    s.addi       s20, s16, #192
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s18, #3328
    v.st.w       [s16, #0], v1
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s16, #256
    v.st.w       [s5, #0], v1
    s.addi       s5, s18, #3392
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s16, #320
    v.st.w       [s11, #0], v1
    s.addi       s11, s18, #3456
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s16, #384
    v.st.w       [s20, #0], v1
    s.addi       s20, s18, #3520
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s16, #448
    v.st.w       [s4, #0], v1
    s.addi       s4, s18, #3584
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s16, #512
    v.st.w       [s17, #0], v1
    s.addi       s17, s18, #3648
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s16, #576
    v.st.w       [s15, #0], v1
    s.addi       s15, s18, #3712
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s16, #640
    v.st.w       [s6, #0], v1
    s.addi       s6, s18, #3776
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s16, #704
    v.st.w       [s5, #0], v1
    s.addi       s5, s18, #3840
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s16, #768
    v.st.w       [s11, #0], v1
    s.addi       s11, s18, #3904
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s16, #832
    v.st.w       [s20, #0], v1
    s.addi       s20, s18, #3968
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s16, #896
    s.addi       s22, s16, #960
    v.st.w       [s4, #0], v1
    s.addi       s4, s18, #4032
    v.ld.w       v1, [s5, #0]
    s.movz       s5, #0
    v.st.w       [s17, #0], v1
    s.movz       s16, #0
    v.ld.w       v1, [s11, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s11, #0
    v.st.w       [s15, #0], v1
    s.movz       s15, #1
    v.ld.w       v1, [s20, #0]
    s.movz       s17, #1
    v.st.w       [s6, #0], v1
    s.movz       s6, #1
    v.ld.w       v1, [s4, #0]
    s.movz       s4, #2
    v.st.w       [s22, #0], v1
    fence.acq_rel.device
    a.vread      v1, a0, s5
    a.vread      v2, a3, s16
    s.movz       s5, #2
    vf.add       v3, v1, v2
    s.movz       s16, #2
    s.movz       s20, #3
    a.vwrite     a4, s11, v3
    a.vread      v1, a0, s15
    a.vread      v2, a3, s17
    s.movz       s11, #3
    vf.add       v3, v1, v2
    s.movz       s15, #3
    s.movz       s17, #4
    a.vwrite     a4, s6, v3
    a.vread      v1, a0, s4
    a.vread      v2, a3, s5
    s.movz       s4, #4
    vf.add       v3, v1, v2
    s.movz       s5, #4
    s.movz       s6, #5
    a.vwrite     a4, s16, v3
    a.vread      v1, a0, s20
    a.vread      v2, a3, s11
    s.movz       s11, #5
    vf.add       v3, v1, v2
    s.movz       s16, #5
    s.movz       s20, #6
    a.vwrite     a4, s15, v3
    a.vread      v1, a0, s17
    a.vread      v2, a3, s4
    s.movz       s4, #6
    vf.add       v3, v1, v2
    s.movz       s15, #6
    s.movz       s17, #7
    a.vwrite     a4, s5, v3
    a.vread      v1, a0, s6
    a.vread      v2, a3, s11
    s.movz       s5, #7
    vf.add       v3, v1, v2
    s.movz       s6, #7
    s.movz       s11, #8
    a.vwrite     a4, s16, v3
    a.vread      v1, a0, s20
    a.vread      v2, a3, s4
    s.movz       s4, #8
    vf.add       v3, v1, v2
    s.movz       s16, #8
    s.movz       s20, #9
    a.vwrite     a4, s15, v3
    a.vread      v1, a0, s17
    a.vread      v2, a3, s5
    s.movz       s5, #9
    vf.add       v3, v1, v2
    s.movz       s15, #9
    s.movz       s17, #10
    a.vwrite     a4, s6, v3
    a.vread      v1, a0, s11
    a.vread      v2, a3, s4
    s.movz       s4, #10
    vf.add       v3, v1, v2
    s.movz       s6, #10
    s.movz       s11, #11
    a.vwrite     a4, s16, v3
    a.vread      v1, a0, s20
    a.vread      v2, a3, s5
    s.movz       s5, #11
    vf.add       v3, v1, v2
    s.movz       s16, #11
    s.movz       s20, #12
    a.vwrite     a4, s15, v3
    a.vread      v1, a0, s17
    a.vread      v2, a3, s4
    s.movz       s4, #12
    vf.add       v3, v1, v2
    s.movz       s15, #12
    s.movz       s17, #13
    a.vwrite     a4, s6, v3
    a.vread      v1, a0, s11
    a.vread      v2, a3, s5
    s.movz       s5, #13
    vf.add       v3, v1, v2
    s.movz       s6, #13
    s.movz       s11, #14
    a.vwrite     a4, s16, v3
    a.vread      v1, a0, s20
    a.vread      v2, a3, s4
    s.movz       s4, #14
    vf.add       v3, v1, v2
    s.movz       s16, #14
    s.movz       s20, #15
    a.vwrite     a4, s15, v3
    a.vread      v1, a0, s17
    a.vread      v2, a3, s5
    s.movz       s5, #15
    vf.add       v3, v1, v2
    s.movz       s15, #15
    s.addi       s17, s18, #4096
    a.vwrite     a4, s6, v3
    a.vread      v1, a0, s11
    a.vread      v2, a3, s4
    s.addi       s4, s18, #0
    vf.add       v3, v1, v2
    s.addi       s6, s18, #4160
    s.addi       s11, s18, #64
    a.vwrite     a4, s16, v3
    a.vread      v1, a0, s20
    a.vread      v2, a3, s5
    s.addi       s5, s18, #4224
    vf.add       v3, v1, v2
    s.addi       s16, s18, #128
    s.addi       s20, s18, #4288
    a.vwrite     a4, s15, v3
    v.ld.w       v1, [s17, #0]
    s.addi       s15, s18, #192
    s.addi       s17, s18, #4352
    v.st.w       [s4, #0], v1
    s.addi       s4, s18, #256
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s18, #4416
    v.st.w       [s11, #0], v1
    s.addi       s11, s18, #320
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s18, #4480
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #384
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s18, #4544
    v.st.w       [s15, #0], v1
    s.addi       s15, s18, #448
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s18, #4608
    v.st.w       [s4, #0], v1
    s.addi       s4, s18, #512
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s18, #4672
    v.st.w       [s11, #0], v1
    s.addi       s11, s18, #576
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s18, #4736
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #640
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s18, #4800
    v.st.w       [s15, #0], v1
    s.addi       s15, s18, #704
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s18, #4864
    v.st.w       [s4, #0], v1
    s.addi       s4, s18, #768
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s18, #4928
    v.st.w       [s11, #0], v1
    s.addi       s11, s18, #832
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s18, #4992
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #896
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s18, #5056
    v.st.w       [s15, #0], v1
    s.addi       s15, s18, #960
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s18, #5120
    v.st.w       [s4, #0], v1
    s.addi       s4, s18, #1024
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s18, #5184
    v.st.w       [s11, #0], v1
    s.addi       s11, s18, #1088
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s18, #5248
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #1152
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s18, #5312
    v.st.w       [s15, #0], v1
    fence.acq_rel.device
    s.addi       s15, s18, #1216
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s18, #5376
    v.st.w       [s4, #0], v1
    s.addi       s4, s18, #1280
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s18, #5440
    v.st.w       [s11, #0], v1
    s.addi       s11, s18, #1344
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s18, #5504
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #1408
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s18, #5568
    v.st.w       [s15, #0], v1
    s.addi       s15, s18, #1472
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s18, #5632
    v.st.w       [s4, #0], v1
    s.addi       s4, s18, #1536
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s18, #5696
    v.st.w       [s11, #0], v1
    s.addi       s11, s18, #1600
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s18, #5760
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #1664
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s18, #5824
    v.st.w       [s15, #0], v1
    s.addi       s15, s18, #1728
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s18, #5888
    v.st.w       [s4, #0], v1
    s.addi       s4, s18, #1792
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s18, #5952
    v.st.w       [s11, #0], v1
    s.addi       s11, s18, #1856
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s18, #6016
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #1920
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s18, #6080
    v.st.w       [s15, #0], v1
    s.addi       s15, s18, #1984
    v.ld.w       v1, [s17, #0]
    s.movz       s17, #0
    v.st.w       [s4, #0], v1
    s.movz       s4, #0
    v.ld.w       v1, [s6, #0]
    s.movz       s6, #1
    v.st.w       [s11, #0], v1
    s.movz       s11, #1
    v.ld.w       v1, [s5, #0]
    s.movz       s5, #2
    v.st.w       [s16, #0], v1
    s.movz       s16, #2
    v.ld.w       v1, [s20, #0]
    s.movz       s20, #3
    v.st.w       [s15, #0], v1
    fence.acq_rel.device
    a.vread      v1, a4, s17
    s.movz       s15, #3
    a.vwrite     a0, s4, v1
    a.vread      v1, a4, s6
    s.movz       s4, #4
    a.vwrite     a0, s11, v1
    a.vread      v1, a4, s5
    s.movz       s5, #4
    a.vwrite     a0, s16, v1
    a.vread      v1, a4, s20
    s.movz       s6, #5
    a.vwrite     a0, s15, v1
    a.vread      v1, a4, s4
    s.movz       s4, #5
    a.vwrite     a0, s5, v1
    a.vread      v1, a4, s6
    s.movz       s5, #6
    a.vwrite     a0, s4, v1
    s.movz       s4, #6
    a.vread      v1, a4, s5
    s.movz       s5, #7
    a.vwrite     a0, s4, v1
    s.movz       s4, #7
    a.vread      v1, a4, s5
    s.movz       s5, #8
    a.vwrite     a0, s4, v1
    s.movz       s4, #8
    a.vread      v1, a4, s5
    s.movz       s5, #9
    a.vwrite     a0, s4, v1
    s.movz       s4, #9
    a.vread      v1, a4, s5
    s.movz       s5, #10
    a.vwrite     a0, s4, v1
    s.movz       s4, #10
    a.vread      v1, a4, s5
    s.movz       s5, #11
    a.vwrite     a0, s4, v1
    s.movz       s4, #11
    a.vread      v1, a4, s5
    s.movz       s5, #12
    a.vwrite     a0, s4, v1
    s.movz       s4, #12
    a.vread      v1, a4, s5
    s.movz       s5, #13
    a.vwrite     a0, s4, v1
    s.movz       s4, #13
    a.vread      v1, a4, s5
    s.movz       s5, #14
    a.vwrite     a0, s4, v1
    s.movz       s4, #14
    a.vread      v1, a4, s5
    s.movz       s5, #15
    a.vwrite     a0, s4, v1
    s.movz       s4, #15
    a.vread      v1, a4, s5
    s.add        s5, s21, s1
    s.movz       s6, #1
    a.vwrite     a0, s4, v1
    s.mov        s21, s5
    br.nz        s6, for_5
endfor_6:
    s.movz       s1, #8192
    s.muli       s2, s3, #128                    // a runtime tile origin, x128
    s.movz       s4, #0
    s.mul        s5, s13, s1
    s.add        s6, s4, s8                      // the tile origin
    v.movi       v1, #0
    s.add        s4, s6, s2                      // the tile origin
    v.movi       v2, #0
    s.add        s2, s4, s5                      // the tile origin
    s.mul        s4, s13, s10
    s.addi       s6, s2, #128
    v.splat      v3, s2
    v.splat      v4, s6
    v.add        v5, v0, v3
    v.add        v3, v0, v4
    v.sub        v4, v1, v5
    v.sub        v6, v2, v3
    v.cmp.lt     p1, v5, v1
    v.cmp.lt     p2, v3, v2
    @p1 v.sel        v7, v4, v5
    v.movi       v4, #8191
    @p2 v.sel        v5, v6, v3
    v.movi       v3, #8191
    v.and        v6, v7, v4
    s.movz       s6, #0
    v.sub        v4, v1, v6
    s.add        s10, s6, s4                     // the tile origin
    @p1 v.sel        v7, v4, v6
    v.splat      v4, s10
    s.addi       s4, s18, #6144
    v.splat      v6, s14
    v.add        v8, v7, v4
    s.addi       s6, s4, #64
    v.add        v7, v6, v8
    s.movz       s10, #32
    v.st.w       [s4, #0], v7
    v.splat      v7, s13
    v.and        v8, v5, v3
    v.splat      v3, s10
    v.sub        v5, v2, v8
    v.cmp.lt     p1, v7, v3
    s.addi       s10, s2, #256
    v.movi       v3, #0
    v.splat      v7, s10
    @p2 v.sel        v9, v5, v8
    v.add        v5, v0, v7
    v.add        v7, v9, v4
    v.sub        v8, v3, v5
    v.cmp.lt     p2, v5, v3
    @p2 v.sel        v9, v8, v5
    v.add        v5, v6, v7
    s.addi       s10, s4, #128
    v.st.w       [s6, #0], v5
    v.splat      v5, s1
    v.movi       v7, #1
    v.movi       v7, #8191
    v.sub        v8, v1, v5
    v.and        v10, v9, v7
    v.sub        v7, v2, v5
    v.sub        v9, v3, v5
    v.cmp.lt     p3, v5, v1
    v.sub        v1, v3, v10
    v.cmp.lt     p4, v5, v2
    @p2 v.sel        v2, v1, v10
    v.cmp.lt     p2, v5, v3
    v.add        v1, v2, v4
    @p3 v.sel        v2, v8, v5
    s.addi       s1, s2, #384
    v.movi       v2, #0
    v.splat      v3, s1
    v.movi       v8, #8191
    v.add        v10, v0, v3
    v.add        v3, v6, v1
    v.sub        v1, v2, v10
    v.cmp.lt     p3, v10, v2
    @p3 v.sel        v11, v1, v10
    s.addi       s1, s4, #192
    v.and        v1, v11, v8
    v.st.w       [s10, #0], v3
    v.sub        v3, v2, v1
    v.sub        v8, v2, v5
    v.movi       v10, #1
    s.addi       s6, s2, #512
    @p3 v.sel        v10, v3, v1
    s.addi       s10, s4, #256
    v.add        v1, v10, v4
    v.cmp.lt     p3, v5, v2
    v.add        v2, v6, v1
    @p4 v.sel        v1, v7, v5
    v.splat      v1, s6
    v.movi       v3, #0
    v.add        v7, v0, v1
    v.movi       v1, #8191
    v.sub        v10, v3, v7
    v.cmp.lt     p4, v7, v3
    @p4 v.sel        v11, v10, v7
    v.st.w       [s1, #0], v2
    v.and        v2, v11, v1
    v.sub        v1, v3, v5
    v.sub        v7, v3, v2
    v.movi       v10, #1
    s.addi       s1, s2, #640
    @p4 v.sel        v10, v7, v2
    s.addi       s6, s4, #320
    v.add        v2, v10, v4
    v.cmp.lt     p4, v5, v3
    v.add        v3, v6, v2
    @p2 v.sel        v2, v9, v5
    v.splat      v2, s1
    v.movi       v7, #0
    v.add        v9, v0, v2
    v.movi       v2, #8191
    v.sub        v10, v7, v9
    v.cmp.lt     p2, v9, v7
    @p2 v.sel        v11, v10, v9
    v.st.w       [s10, #0], v3
    v.and        v3, v11, v2
    v.sub        v2, v7, v5
    v.sub        v9, v7, v3
    v.movi       v10, #1
    s.addi       s1, s2, #768
    @p2 v.sel        v10, v9, v3
    s.addi       s10, s4, #384
    v.add        v3, v10, v4
    v.cmp.lt     p2, v5, v7
    v.add        v7, v6, v3
    @p3 v.sel        v3, v8, v5
    v.splat      v3, s1
    v.movi       v8, #0
    v.add        v9, v0, v3
    v.movi       v3, #8191
    v.sub        v10, v8, v9
    v.cmp.lt     p3, v9, v8
    @p3 v.sel        v11, v10, v9
    v.st.w       [s6, #0], v7
    v.and        v7, v11, v3
    v.sub        v3, v8, v5
    v.sub        v9, v8, v7
    v.movi       v10, #1
    s.addi       s1, s2, #896
    @p3 v.sel        v10, v9, v7
    s.addi       s6, s4, #448
    v.add        v7, v10, v4
    v.cmp.lt     p3, v5, v8
    v.add        v8, v6, v7
    @p4 v.sel        v7, v1, v5
    v.splat      v1, s1
    v.movi       v7, #0
    v.add        v9, v0, v1
    v.movi       v1, #8191
    v.sub        v10, v7, v9
    v.cmp.lt     p4, v9, v7
    @p4 v.sel        v11, v10, v9
    v.st.w       [s10, #0], v8
    v.and        v8, v11, v1
    v.sub        v1, v7, v5
    v.sub        v9, v7, v8
    v.movi       v10, #1
    s.addi       s1, s2, #1024
    @p4 v.sel        v10, v9, v8
    s.addi       s10, s4, #512
    v.add        v8, v10, v4
    v.cmp.lt     p4, v5, v7
    v.add        v7, v6, v8
    @p2 v.sel        v8, v2, v5
    v.splat      v2, s1
    v.movi       v8, #0
    v.add        v9, v0, v2
    v.movi       v2, #8191
    v.sub        v10, v8, v9
    v.cmp.lt     p2, v9, v8
    @p2 v.sel        v11, v10, v9
    v.st.w       [s6, #0], v7
    v.and        v7, v11, v2
    v.sub        v2, v8, v5
    v.sub        v9, v8, v7
    v.movi       v10, #1
    s.addi       s1, s2, #1152
    @p2 v.sel        v10, v9, v7
    s.addi       s6, s4, #576
    v.add        v7, v10, v4
    v.cmp.lt     p2, v5, v8
    v.add        v8, v6, v7
    @p3 v.sel        v7, v3, v5
    v.splat      v3, s1
    v.movi       v7, #0
    v.add        v9, v0, v3
    v.movi       v3, #8191
    v.sub        v10, v7, v9
    v.cmp.lt     p3, v9, v7
    @p3 v.sel        v11, v10, v9
    v.st.w       [s10, #0], v8
    v.and        v8, v11, v3
    v.sub        v3, v7, v5
    v.sub        v9, v7, v8
    v.movi       v10, #1
    s.addi       s1, s2, #1280
    @p3 v.sel        v10, v9, v8
    s.addi       s10, s4, #640
    v.add        v8, v10, v4
    v.cmp.lt     p3, v5, v7
    v.add        v7, v6, v8
    @p4 v.sel        v8, v1, v5
    v.splat      v1, s1
    v.movi       v8, #0
    v.add        v9, v0, v1
    v.movi       v1, #8191
    v.sub        v10, v8, v9
    v.cmp.lt     p4, v9, v8
    @p4 v.sel        v11, v10, v9
    v.st.w       [s6, #0], v7
    v.and        v7, v11, v1
    v.sub        v1, v8, v5
    v.sub        v9, v8, v7
    v.movi       v10, #1
    s.addi       s1, s2, #1408
    @p4 v.sel        v10, v9, v7
    s.addi       s6, s4, #704
    v.add        v7, v10, v4
    v.cmp.lt     p4, v5, v8
    v.add        v8, v6, v7
    @p2 v.sel        v7, v2, v5
    v.splat      v2, s1
    v.movi       v7, #0
    v.add        v9, v0, v2
    v.movi       v2, #8191
    v.sub        v10, v7, v9
    v.cmp.lt     p2, v9, v7
    @p2 v.sel        v11, v10, v9
    v.st.w       [s10, #0], v8
    v.and        v8, v11, v2
    v.sub        v2, v7, v5
    v.sub        v9, v7, v8
    v.movi       v10, #1
    s.addi       s1, s2, #1536
    @p2 v.sel        v10, v9, v8
    s.addi       s10, s4, #768
    v.add        v8, v10, v4
    v.cmp.lt     p2, v5, v7
    v.add        v7, v6, v8
    @p3 v.sel        v8, v3, v5
    v.splat      v3, s1
    v.movi       v8, #0
    v.add        v9, v0, v3
    v.movi       v3, #8191
    v.sub        v10, v8, v9
    v.cmp.lt     p3, v9, v8
    @p3 v.sel        v11, v10, v9
    v.st.w       [s6, #0], v7
    v.and        v7, v11, v3
    v.sub        v3, v8, v5
    v.sub        v9, v8, v7
    v.movi       v10, #1
    s.addi       s1, s2, #1664
    @p3 v.sel        v10, v9, v7
    s.addi       s6, s4, #832
    v.add        v7, v10, v4
    v.cmp.lt     p3, v5, v8
    v.add        v8, v6, v7
    @p4 v.sel        v7, v1, v5
    v.splat      v1, s1
    v.movi       v7, #0
    v.add        v9, v0, v1
    v.movi       v1, #8191
    v.sub        v10, v7, v9
    v.cmp.lt     p4, v9, v7
    @p4 v.sel        v11, v10, v9
    v.st.w       [s10, #0], v8
    v.and        v8, v11, v1
    v.sub        v1, v7, v5
    v.sub        v9, v7, v8
    v.movi       v10, #1
    s.addi       s1, s2, #1792
    @p4 v.sel        v10, v9, v8
    s.addi       s10, s4, #896
    v.add        v8, v10, v4
    v.cmp.lt     p4, v5, v7
    v.add        v7, v6, v8
    @p2 v.sel        v8, v2, v5
    v.splat      v2, s1
    v.movi       v8, #0
    v.add        v9, v0, v2
    v.movi       v2, #8191
    v.sub        v10, v8, v9
    v.cmp.lt     p2, v9, v8
    @p2 v.sel        v11, v10, v9
    v.st.w       [s6, #0], v7
    v.and        v7, v11, v2
    v.sub        v2, v8, v5
    v.sub        v9, v8, v7
    v.movi       v10, #1
    s.addi       s1, s2, #1920
    @p2 v.sel        v10, v9, v7
    s.addi       s2, s4, #960
    v.add        v7, v10, v4
    v.cmp.lt     p2, v5, v8
    v.add        v8, v6, v7
    @p3 v.sel        v7, v3, v5
    v.splat      v3, s1
    v.movi       v7, #0
    v.add        v9, v0, v3
    v.movi       v3, #8191
    v.sub        v10, v7, v9
    v.cmp.lt     p3, v9, v7
    @p3 v.sel        v11, v10, v9
    v.st.w       [s10, #0], v8
    v.and        v8, v11, v3
    v.sub        v3, v7, v5
    v.sub        v9, v7, v8
    v.movi       v10, #1
    @p3 v.sel        v10, v9, v8
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s1, #0
    v.add        v8, v10, v4
    v.cmp.lt     p3, v5, v7
    v.add        v4, v6, v8
    @p4 v.sel        v6, v1, v5
    s.movz       s4, #0
    s.addi       s6, s18, #6144
    s.movz       s10, #0
    s.add        s11, s4, s8                     // the tile origin
    v.st.w       [s2, #0], v4
    fence.acq_rel.device
    s.add        s2, s10, s3                     // the tile origin
    s.movz       s4, #64
    v.splat      v1, s11
    v.splat      v4, s2
    v.splat      v6, s4
    v.add        v7, v0, v1
    v.splat      v0, s19
    v.cmp.lt     p4, v4, v6
    v.ld.w       v1, [s6, #0]
    v.movi       v4, #1
    s.movz       s4, #1
    @p2 v.sel        v4, v2, v5
    v.cmp.lt     p2, v7, v0
    p.and        p5, p4, p2
    s.addi       s6, s18, #6208
    p.and        p4, p5, p1
    s.addi       s10, s2, #1
    s.addi       s11, s18, #6272
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s7, v1]               // index is in elements (ISA sec 9.1)
    v.splat      v1, s10
    s.addi       s10, s2, #2
    v.cmp.lt     p4, v1, v6
    p.and        p5, p4, p2
    s.movz       s12, #2
    p.and        p4, p5, p1
    v.movi       v1, #1
    v.splat      v1, s10
    @p3 v.sel        v2, v3, v5
    a.vwrite     a5, s1, v0
    v.ld.w       v0, [s6, #0]
    v.cmp.lt     p3, v1, v6
    p.and        p5, p3, p2
    s.addi       s1, s18, #6336
    p.and        p3, p5, p1
    s.addi       s6, s2, #3
    s.movz       s10, #3
    v.splat      v1, s6
    s.addi       s6, s18, #6400
    s.addi       s13, s2, #4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v2, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p4, v1, v6
    p.and        p5, p4, p2
    v.splat      v0, s13
    p.and        p4, p5, p1
    s.movz       s13, #4
    s.addi       s14, s18, #6464
    s.addi       s15, s2, #5
    v.splat      v1, s15
    a.vwrite     a5, s4, v2
    v.ld.w       v2, [s11, #0]
    s.movz       s4, #5
    s.addi       s11, s18, #6528
    s.addi       s15, s2, #6
    v.splat      v3, s15
    s.movz       s15, #6
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v4, [s7, v2]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v0, v6
    p.and        p5, p3, p2
    p.and        p3, p5, p1
    a.vwrite     a5, s12, v4
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s18, #6592
    s.addi       s12, s2, #7
    v.splat      v2, s12
    s.movz       s12, #7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p4, v1, v6
    p.and        p5, p4, p2
    p.and        p4, p5, p1
    a.vwrite     a5, s10, v4
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s18, #6656
    s.addi       s10, s2, #8
    v.splat      v1, s10
    s.movz       s10, #8
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v4, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v3, v6
    p.and        p5, p3, p2
    p.and        p3, p5, p1
    a.vwrite     a5, s13, v4
    v.ld.w       v0, [s14, #0]
    s.addi       s13, s18, #6720
    s.addi       s14, s2, #9
    v.splat      v3, s14
    s.movz       s14, #9
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p4, v2, v6
    p.and        p5, p4, p2
    p.and        p4, p5, p1
    a.vwrite     a5, s4, v4
    v.ld.w       v0, [s11, #0]
    s.addi       s4, s18, #6784
    s.addi       s11, s2, #10
    v.splat      v2, s11
    s.movz       s11, #10
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v4, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v1, v6
    p.and        p5, p3, p2
    p.and        p3, p5, p1
    a.vwrite     a5, s15, v4
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s18, #6848
    s.addi       s15, s2, #11
    v.splat      v1, s15
    s.movz       s15, #11
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p4, v3, v6
    p.and        p5, p4, p2
    p.and        p4, p5, p1
    a.vwrite     a5, s12, v4
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s18, #6912
    s.addi       s12, s2, #12
    v.splat      v3, s12
    s.movz       s12, #12
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v4, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v2, v6
    p.and        p5, p3, p2
    p.and        p3, p5, p1
    a.vwrite     a5, s10, v4
    v.ld.w       v0, [s13, #0]
    s.addi       s10, s18, #6976
    s.addi       s13, s2, #13
    v.splat      v2, s13
    s.movz       s13, #13
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p4, v1, v6
    p.and        p5, p4, p2
    p.and        p4, p5, p1
    a.vwrite     a5, s14, v4
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s18, #7040
    s.addi       s14, s2, #14
    s.addi       s16, s18, #7104
    v.splat      v1, s14
    s.movz       s14, #14
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v4, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v3, v6
    p.and        p5, p3, p2
    p.and        p3, p5, p1
    a.vwrite     a5, s11, v4
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s2, #15
    s.muli       s11, s8, #4                     // a runtime tile origin, x4
    v.splat      v3, s1
    s.muli       s1, s3, #512                    // a runtime tile origin, x512
    s.movz       s3, #15
    s.muli       s8, s5, #4                      // a runtime tile origin, x4
    s.add        s5, s9, s11                     // the tile origin
    s.add        s9, s5, s1                      // the tile origin
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p4, v2, v6
    p.and        p5, p4, p2
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    p.and        p4, p5, p1
    s.add        s5, s9, s8                      // the tile origin
    a.vwrite     a5, s15, v4
    v.ld.w       v0, [s6, #0]
    s.movz       s6, #0
    v.splat      v2, s2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v4, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v1, v6
    p.and        p5, p3, p2
    s.movz       s8, #1
    p.and        p3, p5, p1
    a.vwrite     a5, s12, v4
    v.ld.w       v0, [s10, #0]
    s.addi       s9, s2, #1
    s.movz       s10, #1
    v.splat      v1, s9
    s.addi       s9, s5, #512                    // row 1
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p4, v3, v6
    p.and        p5, p4, p2
    p.and        p4, p5, p1
    a.vwrite     a5, s13, v4
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s2, #2
    s.movz       s11, #2
    s.movz       s12, #2
    v.splat      v3, s4
    s.addi       s4, s5, #1024                   // row 2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v4, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v2, v6
    p.and        p5, p3, p2
    p.and        p3, p5, p1
    a.vwrite     a5, s14, v4
    v.ld.w       v0, [s16, #0]
    s.movz       s13, #3
    s.movz       s14, #3
    s.addi       s15, s5, #1536                  // row 3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v2, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p4, v1, v6
    p.and        p5, p4, p2
    s.addi       s7, s2, #3
    p.and        p4, p5, p1
    a.vwrite     a5, s3, v2
    a.vread      v0, a5, s1
    a.vread      v1, a0, s6
    v.splat      v2, s7
    vf.sub       v4, v0, v1
    s.addi       s1, s2, #4
    s.movz       s3, #4
    s.movz       s6, #4
    @p3 v.st.w       [s5, #0], v4
    a.vread      v0, a5, s8
    a.vread      v1, a0, s10
    v.cmp.lt     p3, v3, v6
    vf.sub       v3, v0, v1
    p.and        p5, p3, p2
    v.splat      v0, s1
    p.and        p3, p5, p1
    s.addi       s1, s2, #5
    s.addi       s7, s5, #2048                   // row 4
    @p4 v.st.w       [s9, #0], v3
    a.vread      v1, a5, s11
    a.vread      v3, a0, s12
    v.cmp.lt     p4, v2, v6
    vf.sub       v2, v1, v3
    p.and        p5, p4, p2
    s.movz       s8, #5
    p.and        p4, p5, p1
    s.movz       s9, #5
    v.splat      v1, s1
    @p3 v.st.w       [s4, #0], v2
    a.vread      v2, a5, s13
    a.vread      v3, a0, s14
    v.cmp.lt     p3, v0, v6
    vf.sub       v0, v2, v3
    p.and        p5, p3, p2
    s.addi       s1, s2, #6
    p.and        p3, p5, p1
    s.addi       s4, s5, #2560                   // row 5
    s.movz       s10, #6
    @p4 v.st.w       [s15, #0], v0
    a.vread      v0, a5, s3
    a.vread      v2, a0, s6
    v.cmp.lt     p4, v1, v6
    vf.sub       v1, v0, v2
    p.and        p5, p4, p2
    s.movz       s3, #6
    p.and        p4, p5, p1
    v.splat      v0, s1
    s.addi       s1, s2, #7
    @p3 v.st.w       [s7, #0], v1
    a.vread      v1, a5, s8
    a.vread      v2, a0, s9
    v.cmp.lt     p3, v0, v6
    vf.sub       v0, v1, v2
    p.and        p5, p3, p2
    s.addi       s6, s5, #3072                   // row 6
    p.and        p3, p5, p1
    s.movz       s7, #7
    s.movz       s8, #7
    @p4 v.st.w       [s4, #0], v0
    a.vread      v0, a5, s10
    a.vread      v1, a0, s3
    v.splat      v2, s1
    vf.sub       v3, v0, v1
    v.cmp.lt     p4, v2, v6
    p.and        p5, p4, p2
    s.addi       s1, s2, #8
    s.addi       s3, s5, #3584                   // row 7
    p.and        p4, p5, p1
    @p3 v.st.w       [s6, #0], v3
    a.vread      v0, a5, s7
    a.vread      v1, a0, s8
    s.movz       s4, #8
    vf.sub       v2, v0, v1
    s.movz       s6, #8
    v.splat      v0, s1
    s.addi       s1, s2, #9
    v.cmp.lt     p3, v0, v6
    p.and        p5, p3, p2
    @p4 v.st.w       [s3, #0], v2
    a.vread      v0, a5, s4
    a.vread      v1, a0, s6
    s.addi       s3, s5, #4096                   // row 8
    vf.sub       v2, v0, v1
    p.and        p3, p5, p1
    s.movz       s4, #9
    s.movz       s6, #9
    v.splat      v0, s1
    s.addi       s1, s2, #10
    @p3 v.st.w       [s3, #0], v2
    a.vread      v1, a5, s4
    a.vread      v2, a0, s6
    v.cmp.lt     p3, v0, v6
    vf.sub       v0, v1, v2
    p.and        p4, p3, p2
    s.addi       s3, s5, #4608                   // row 9
    p.and        p3, p4, p1
    s.movz       s4, #10
    s.movz       s6, #10
    v.splat      v1, s1
    @p3 v.st.w       [s3, #0], v0
    a.vread      v0, a5, s4
    a.vread      v2, a0, s6
    v.cmp.lt     p3, v1, v6
    vf.sub       v1, v0, v2
    p.and        p4, p3, p2
    s.addi       s1, s2, #11
    s.addi       s3, s5, #5120                   // row 10
    p.and        p3, p4, p1
    s.movz       s4, #11
    s.movz       s6, #11
    v.splat      v0, s1
    @p3 v.st.w       [s3, #0], v1
    a.vread      v1, a5, s4
    a.vread      v2, a0, s6
    v.cmp.lt     p3, v0, v6
    vf.sub       v0, v1, v2
    p.and        p4, p3, p2
    s.addi       s1, s2, #12
    s.addi       s3, s5, #5632                   // row 11
    p.and        p3, p4, p1
    s.movz       s4, #12
    s.movz       s6, #12
    v.splat      v1, s1
    @p3 v.st.w       [s3, #0], v0
    a.vread      v0, a5, s4
    a.vread      v2, a0, s6
    v.cmp.lt     p3, v1, v6
    vf.sub       v1, v0, v2
    p.and        p4, p3, p2
    s.addi       s1, s2, #13
    s.addi       s3, s5, #6144                   // row 12
    p.and        p3, p4, p1
    s.movz       s4, #13
    s.movz       s6, #13
    v.splat      v0, s1
    @p3 v.st.w       [s3, #0], v1
    a.vread      v1, a5, s4
    a.vread      v2, a0, s6
    v.cmp.lt     p3, v0, v6
    vf.sub       v0, v1, v2
    p.and        p4, p3, p2
    s.addi       s1, s2, #14
    s.addi       s3, s5, #6656                   // row 13
    p.and        p3, p4, p1
    s.movz       s4, #14
    s.movz       s6, #14
    v.splat      v1, s1
    @p3 v.st.w       [s3, #0], v0
    a.vread      v0, a5, s4
    a.vread      v2, a0, s6
    v.cmp.lt     p3, v1, v6
    vf.sub       v1, v0, v2
    p.and        p4, p3, p2
    s.addi       s1, s2, #15
    s.addi       s2, s5, #7168                   // row 14
    p.and        p3, p4, p1
    s.movz       s3, #15
    s.movz       s4, #15
    v.splat      v0, s1
    @p3 v.st.w       [s2, #0], v1
    a.vread      v1, a5, s3
    a.vread      v2, a0, s4
    v.cmp.lt     p3, v0, v6
    vf.sub       v0, v1, v2
    p.and        p4, p3, p2
    s.addi       s1, s5, #7680                   // row 15
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v0
__rctx_next:
    exit
