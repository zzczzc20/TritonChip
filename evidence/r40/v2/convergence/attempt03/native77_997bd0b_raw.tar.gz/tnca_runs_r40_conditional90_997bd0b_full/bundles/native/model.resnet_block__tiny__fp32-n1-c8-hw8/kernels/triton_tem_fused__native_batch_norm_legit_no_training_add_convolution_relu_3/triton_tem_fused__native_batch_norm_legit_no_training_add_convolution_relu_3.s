    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    s.rdspecial  s3, pid.y
    s.rdspecial  s4, arg_base
    s.mul        s5, s3, s1
    s.ld.d       s1, [s4, #64]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.splat      v1, s2
    v.movi       v2, #0
    s.rdspecial  s2, role_id
    v.add        v3, v1, v0
    s.movz       s3, #6208
    s.movz       s4, #0
    s.mul        s6, s2, s3
    v.cmp.lt     p1, v3, v2
    v.movi       v1, #8
    s.rdspecial  s2, arg_base
    s.movz       s3, #512
    s.add        s7, s1, s6                      // this context's own scratch
    v.cmp.lt     p2, v1, v2
    s.addi       s1, s7, #0
    s.addi       s6, s7, #1024
    s.addi       s8, s1, #64
    s.addi       s9, s1, #128
    s.addi       s10, s1, #192
    s.addi       s11, s1, #256
    s.addi       s12, s1, #320
    s.addi       s13, s1, #384
    s.addi       s14, s1, #448
    s.addi       s15, s1, #512
    s.addi       s16, s1, #576
    s.addi       s17, s1, #640
    s.addi       s18, s1, #704
    s.addi       s19, s1, #768
    s.addi       s20, s1, #832
    s.addi       s21, s1, #896
    s.addi       s22, s1, #960
    s.ld.d       s23, [s2, #0]                   // arg_X: device_ptr64 at arg_base+0
    v.sub        v4, v2, v3
    s.movz       s24, #72
    s.movz       s24, #9
    s.movz       s25, #1
    v.movi       v5, #1
    s.ld.d       s26, [s2, #8]                   // arg_W: device_ptr64 at arg_base+8
    @p1 v.sel        v5, v4, v3
    s.ld.d       s27, [s2, #16]                  // in_ptr2: device_ptr64 at arg_base+16
    v.sub        v4, v2, v1
    s.ld.d       s28, [s2, #24]                  // in_ptr3: device_ptr64 at arg_base+24
    @p2 v.sel        v6, v4, v1
    s.ld.d       s29, [s2, #32]                  // in_ptr4: device_ptr64 at arg_base+32
    v.movi       v4, #7
    s.ld.d       s30, [s2, #40]                  // in_ptr5: device_ptr64 at arg_base+40
    v.and        v6, v5, v4
    s.ld.d       s31, [s2, #48]                  // in_ptr6: device_ptr64 at arg_base+48
    v.sub        v4, v2, v6
    s.ld.d       s32, [s2, #56]                  // out_ptr1: device_ptr64 at arg_base+56
    v.movi       v2, #0
    v.movi       v5, #3
    v.movi       v7, #0
    v.sub        v8, v2, v3
    v.cmp.lt     p2, v3, v2
    v.movi       v9, #3
    @p2 v.sel        v10, v8, v3
    v.movi       v3, #0
    v.movi       v8, #512
    v.lshr       v11, v10, v5
    v.splat      v5, s5
    v.movi       v10, #7
    v.sub        v12, v2, v11
    v.add        v13, v5, v0
    v.cmp.lt     p3, v1, v2
    @p2 v.sel        v5, v12, v11
    v.splat      v11, s4
    v.sub        v12, v2, v1
    v.cmp.lt     p2, v5, v7
    @p1 v.sel        v2, v4, v6
    v.sub        v4, v7, v5
    v.cmp.lt     p1, v5, v3
    v.movi       v6, #1
    @p2 v.sel        v6, v4, v5
    @p3 v.sel        v4, v12, v1
    v.sub        v4, v3, v5
    v.lshr       v12, v6, v9
    v.sub        v6, v3, v1
    @p1 v.sel        v9, v4, v5
    v.sub        v4, v7, v12
    v.cmp.lt     p3, v1, v3
    v.and        v5, v9, v10
    @p2 v.sel        v9, v4, v12
    v.sub        v4, v7, v1
    v.sub        v10, v3, v5
    v.mul        v3, v9, v8
    v.cmp.lt     p2, v1, v7
    v.movi       v7, #1
    v.extract    s2, v3, #0
    v.extract    s33, v3, #1
    v.extract    s34, v3, #2
    v.extract    s35, v3, #3
    v.extract    s36, v3, #4
    v.extract    s37, v3, #5
    v.splat      v7, s2
    v.extract    s2, v3, #6
    v.splat      v8, s33
    v.add        v12, v11, v7
    @p3 v.sel        v7, v6, v1
    v.extract    s33, v3, #7
    v.splat      v6, s34
    v.add        v7, v11, v8
    @p1 v.sel        v8, v10, v5
    v.splat      v5, s35
    v.add        v10, v11, v6
    v.movi       v6, #1
    v.extract    s34, v3, #8
    v.extract    s35, v3, #9
    v.add        v6, v11, v5
    @p2 v.sel        v5, v4, v1
    v.splat      v4, s36
    v.extract    s36, v3, #10
    v.st.w       [s1, #0], v12
    v.extract    s1, v3, #11
    v.splat      v5, s37
    v.extract    s37, v3, #12
    v.add        v12, v11, v4
    v.add        v4, v11, v5
    v.st.w       [s8, #0], v7
    v.extract    s8, v3, #13
    v.splat      v5, s2
    v.extract    s2, v3, #14
    v.add        v7, v11, v5
    v.st.w       [s9, #0], v10
    v.extract    s9, v3, #15
    v.splat      v3, s33
    v.splat      v5, s34
    v.add        v10, v11, v3
    v.add        v3, v11, v5
    v.st.w       [s10, #0], v6
    v.movi       v5, #72
    v.mul        v6, v13, v5
    v.st.w       [s11, #0], v12
    v.splat      v5, s35
    v.add        v12, v11, v5
    v.st.w       [s12, #0], v4
    v.splat      v4, s36
    s.addi       s10, s4, #0
    v.add        v5, v11, v4
    v.st.w       [s13, #0], v7
    v.splat      v4, s1
    v.add        v7, v11, v4
    v.st.w       [s14, #0], v10
    v.splat      v4, s37
    v.add        v10, v11, v4
    v.st.w       [s15, #0], v3
    v.splat      v3, s8
    v.add        v4, v11, v3
    v.st.w       [s16, #0], v12
    v.splat      v3, s2
    v.add        v12, v11, v3
    v.st.w       [s17, #0], v5
    v.splat      v3, s9
    v.add        v5, v11, v3
    v.splat      v3, s4
    v.add        v11, v3, v6
    v.st.w       [s18, #0], v7
    v.st.w       [s19, #0], v10
    v.st.w       [s20, #0], v4
    v.st.w       [s21, #0], v12
    v.st.w       [s22, #0], v5
    fence.acq_rel.device
    v.st.w       [s6, #0], v11
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_1:
    s.cmp.ge     s1, s10, s24
    br.nz        s1, endfor_2
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s6, s10, s1
    s.movz       s1, #0
    s.sub        s8, s2, s6
    .li       s2, #1431655766
    s.xor        s6, s10, s8
    s.movz       s9, #0
    s.sub        s11, s6, s8
    s.cmp.lt     s6, s10, s1
    s.mul        s1, s11, s2
    s.sub        s2, s9, s6
    .li       s6, #1431655766
    s.xor        s9, s10, s2
    s.movz       s12, #3
    s.sub        s13, s9, s2
    s.lshri      s9, s1, #32
    s.mul        s1, s13, s6
    s.sub        s6, s11, s9
    s.movz       s14, #0
    s.lshri      s15, s6, #1
    s.movz       s6, #0
    s.add        s16, s9, s15
    s.lshri      s9, s1, #32
    s.lshri      s1, s16, #1
    s.sub        s15, s13, s9
    s.muli       s16, s1, #3
    s.cmp.lt     s1, s12, s14
    s.lshri      s14, s15, #1
    s.sub        s15, s6, s1
    s.add        s1, s9, s14
    s.xor        s6, s2, s15
    s.lshri      s2, s1, #1
    s.sub        s1, s11, s16
    s.xor        s9, s2, s6
    s.xor        s11, s1, s8
    s.sub        s1, s9, s6
    s.sub        s6, s11, s8
    s.sub        s8, s1, s25
    s.sub        s9, s6, s25
    v.splat      v3, s8
    v.splat      v4, s9
    v.movi       v5, #64
    v.add        v6, v3, v8
    v.add        v3, v4, v2
    s.movz       s8, #8
    v.mul        v4, v6, v5
    v.mul        v5, v3, v1
    s.movz       s9, #0
    s.movz       s11, #0
    s.cmp.lt     s14, s12, s9
    s.muli       s9, s2, #3
    s.sub        s2, s11, s14
    s.xor        s11, s12, s15
    s.addi       s14, s7, #1088
    s.xor        s16, s12, s2
    s.sub        s17, s11, s15
    s.addi       s11, s7, #0
    v.extract    s15, v4, #0
    v.ld.w       v7, [s11, #0]
    v.extract    s11, v5, #0
    v.splat      v10, s15
    v.splat      v11, s11
    v.iota       v12                             // arange(0, VLEN)
    s.sub        s11, s13, s9
    v.add        v14, v10, v11
    s.addi       s9, s7, #64
    v.extract    s11, v4, #1
    v.add        v10, v14, v12
    v.extract    s13, v5, #1
    v.splat      v11, s11
    v.splat      v14, s13
    s.addi       s11, s14, #64
    s.addi       s13, s7, #128
    v.add        v15, v11, v14
    s.addi       s15, s14, #128
    s.sub        s17, s16, s2
    v.add        v11, v7, v10
    v.add        v7, v15, v12
    v.extract    s2, v4, #2
    v.st.w       [s14, #0], v11
    v.extract    s16, v5, #2
    v.splat      v10, s2
    v.splat      v11, s16
    s.addi       s2, s7, #192
    v.extract    s16, v4, #3
    v.add        v14, v10, v11
    v.splat      v10, s16
    v.extract    s16, v5, #3
    v.add        v11, v14, v12
    v.splat      v14, s16
    s.addi       s16, s14, #192
    s.movz       s17, #64
    v.add        v15, v10, v14
    v.add        v10, v15, v12
    v.ld.w       v14, [s9, #0]
    s.addi       s9, s7, #256
    v.add        v15, v14, v7
    v.st.w       [s11, #0], v15
    v.extract    s11, v4, #4
    v.splat      v7, s11
    v.extract    s11, v5, #4
    v.splat      v14, s11
    s.addi       s11, s14, #256
    v.add        v15, v7, v14
    v.add        v7, v15, v12
    v.ld.w       v14, [s13, #0]
    s.addi       s13, s7, #320
    v.add        v15, v14, v11
    v.st.w       [s15, #0], v15
    v.extract    s15, v4, #5
    v.splat      v11, s15
    v.extract    s15, v5, #5
    v.splat      v14, s15
    s.addi       s15, s14, #320
    v.add        v15, v11, v14
    v.add        v11, v15, v12
    v.ld.w       v14, [s2, #0]
    s.addi       s2, s7, #384
    v.add        v15, v14, v10
    v.st.w       [s16, #0], v15
    v.extract    s16, v4, #6
    v.splat      v10, s16
    v.extract    s16, v5, #6
    v.splat      v14, s16
    s.addi       s16, s14, #384
    v.add        v15, v10, v14
    v.add        v10, v15, v12
    v.ld.w       v14, [s9, #0]
    s.addi       s9, s7, #448
    v.add        v15, v14, v7
    v.st.w       [s11, #0], v15
    v.extract    s11, v4, #7
    v.splat      v7, s11
    v.extract    s11, v5, #7
    v.splat      v14, s11
    s.addi       s11, s14, #448
    v.add        v15, v7, v14
    v.add        v7, v15, v12
    v.ld.w       v14, [s13, #0]
    s.addi       s13, s7, #512
    v.add        v15, v14, v11
    v.st.w       [s15, #0], v15
    v.extract    s15, v4, #8
    v.splat      v11, s15
    v.extract    s15, v5, #8
    v.splat      v14, s15
    s.addi       s15, s14, #512
    v.add        v15, v11, v14
    v.add        v11, v15, v12
    v.ld.w       v14, [s2, #0]
    s.addi       s2, s7, #576
    v.add        v15, v14, v10
    v.st.w       [s16, #0], v15
    v.extract    s16, v4, #9
    v.splat      v10, s16
    v.extract    s16, v5, #9
    v.splat      v14, s16
    s.addi       s16, s14, #576
    v.add        v15, v10, v14
    v.add        v10, v15, v12
    v.ld.w       v14, [s9, #0]
    s.addi       s9, s7, #640
    v.add        v15, v14, v7
    v.st.w       [s11, #0], v15
    v.extract    s11, v4, #10
    v.splat      v7, s11
    v.extract    s11, v5, #10
    v.splat      v14, s11
    s.addi       s11, s14, #640
    v.add        v15, v7, v14
    v.add        v7, v15, v12
    v.ld.w       v14, [s13, #0]
    s.addi       s13, s7, #704
    v.add        v15, v14, v11
    v.st.w       [s15, #0], v15
    v.extract    s15, v4, #11
    v.splat      v11, s15
    v.extract    s15, v5, #11
    v.splat      v14, s15
    s.addi       s15, s14, #704
    v.add        v15, v11, v14
    v.add        v11, v15, v12
    v.ld.w       v14, [s2, #0]
    s.addi       s2, s7, #768
    v.add        v15, v14, v10
    v.st.w       [s16, #0], v15
    v.extract    s16, v4, #12
    v.splat      v10, s16
    v.extract    s16, v5, #12
    v.splat      v14, s16
    s.addi       s16, s14, #768
    v.add        v15, v10, v14
    v.add        v10, v15, v12
    v.ld.w       v14, [s9, #0]
    s.addi       s9, s7, #832
    v.add        v15, v14, v7
    v.st.w       [s11, #0], v15
    v.extract    s11, v4, #13
    v.splat      v7, s11
    v.extract    s11, v5, #13
    v.splat      v14, s11
    s.addi       s11, s14, #832
    v.add        v15, v7, v14
    v.add        v7, v15, v12
    v.ld.w       v14, [s13, #0]
    s.addi       s13, s7, #896
    v.movi       v15, #1
    v.add        v16, v14, v11
    v.cmp.lt     p1, v9, v15
    v.st.w       [s15, #0], v16
    v.extract    s15, v4, #14
    v.movi       v11, #1
    v.splat      v14, s15
    v.extract    s15, v5, #14
    v.movi       v15, #0
    v.splat      v16, s15
    s.addi       s15, s14, #896
    s.addi       s17, s14, #960
    v.add        v17, v14, v16
    @p1 v.sel        v14, v11, v15
    v.add        v11, v17, v12
    v.ld.w       v15, [s2, #0]
    s.addi       s2, s7, #960
    v.movi       v16, #0
    v.movi       v17, #1
    v.cmp.lt     p1, v6, v1
    v.cmp.ge     p2, v6, v16
    v.movi       v6, #0
    @p2 v.sel        v18, v17, v6
    v.movi       v6, #1
    v.add        v17, v15, v10
    v.movi       v10, #0
    v.st.w       [s16, #0], v17
    v.extract    s14, v4, #15
    v.movi       v4, #1
    v.splat      v15, s14
    v.extract    s14, v5, #15
    @p1 v.sel        v5, v6, v10
    v.splat      v6, s14
    v.cmp.ge     p1, v3, v16
    v.add        v10, v15, v6
    v.add        v6, v10, v12
    v.ld.w       v10, [s9, #0]
    v.movi       v15, #0
    v.movi       v16, #1
    v.cmp.lt     p2, v3, v1
    v.movi       v3, #0
    @p1 v.sel        v17, v4, v15
    v.cmp.lt     p1, v0, v1
    @p2 v.sel        v4, v16, v3
    v.add        v3, v10, v7
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s9, #0
    v.st.w       [s11, #0], v3
    s.addi       s11, s7, #1088
    v.extract    s14, v14, #0
    v.ld.w       v3, [s13, #0]
    v.extract    s13, v18, #0
    v.splat      v7, s14
    v.movi       v10, #0
    v.splat      v15, s13
    v.movi       v16, #0
    v.cmp.ne     p2, v7, v10
    v.cmp.ne     p3, v15, v16
    v.add        v7, v3, v11
    p.and        p4, p2, p3
    v.st.w       [s15, #0], v7
    v.extract    s13, v5, #0
    v.movi       v3, #0
    v.splat      v7, s13
    v.ld.w       v10, [s2, #0]
    v.extract    s2, v17, #0
    v.movi       v11, #0
    v.splat      v15, s2
    v.cmp.ne     p2, v7, v3
    p.and        p3, p4, p2
    v.cmp.ne     p2, v15, v11
    p.and        p4, p3, p2
    v.add        v3, v10, v6
    v.extract    s2, v4, #0
    v.st.w       [s17, #0], v3
    fence.acq_rel.device
    v.splat      v3, s2
    v.movi       v6, #0
    s.addi       s2, s7, #1152
    v.extract    s13, v14, #1
    v.cmp.ne     p2, v3, v6
    p.and        p3, p4, p2
    v.extract    s14, v18, #1
    p.and        p2, p3, p1
    v.splat      v3, s13
    v.movi       v6, #0
    v.splat      v7, s14
    v.movi       v10, #0
    v.extract    s13, v5, #1
    v.movi       v11, #0
    v.splat      v15, s13
    v.extract    s13, v17, #1
    v.ld.w       v16, [s11, #0]
    v.cmp.ne     p3, v3, v6
    v.cmp.ne     p4, v7, v10
    p.and        p5, p3, p4
    v.splat      v3, s13
    v.movi       v6, #0
    v.extract    s11, v4, #1
    v.cmp.ne     p3, v15, v11
    p.and        p4, p5, p3
    v.splat      v7, s11
    v.movi       v10, #0
    v.cmp.ne     p3, v3, v6
    p.and        p5, p4, p3
    v.cmp.ne     p3, v7, v10
    p.and        p4, p5, p3
    s.movz       s11, #1
    p.and        p3, p4, p1
    s.addi       s13, s7, #1216
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v3, [s23, v16]             // index is in elements (ISA sec 9.1)
    v.extract    s14, v14, #2
    v.extract    s15, v18, #2
    v.splat      v6, s14
    v.movi       v7, #0
    v.splat      v10, s15
    v.movi       v11, #0
    v.extract    s14, v5, #2
    v.movi       v15, #0
    v.splat      v16, s14
    v.cmp.ne     p2, v6, v7
    v.cmp.ne     p4, v10, v11
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v15
    p.and        p4, p5, p2
    s.movz       s14, #2
    a.vwrite     a1, s9, v3
    v.ld.w       v3, [s2, #0]
    v.extract    s2, v17, #2
    v.movi       v6, #0
    v.splat      v7, s2
    v.extract    s2, v4, #2
    v.movi       v10, #0
    v.splat      v11, s2
    v.cmp.ne     p2, v7, v6
    p.and        p5, p4, p2
    v.cmp.ne     p2, v11, v10
    p.and        p4, p5, p2
    s.addi       s2, s7, #1280
    p.and        p2, p4, p1
    v.extract    s9, v14, #3
    v.extract    s15, v18, #3
    v.splat      v6, s9
    v.movi       v7, #0
    v.splat      v10, s15
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s23, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s9, v5, #3
    v.movi       v15, #0
    v.splat      v16, s9
    v.cmp.ne     p3, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v15
    p.and        p4, p5, p3
    s.movz       s9, #3
    a.vwrite     a1, s11, v11
    v.ld.w       v3, [s13, #0]
    v.extract    s11, v17, #3
    v.movi       v6, #0
    v.splat      v7, s11
    v.extract    s11, v4, #3
    v.movi       v10, #0
    v.splat      v11, s11
    v.cmp.ne     p3, v7, v6
    p.and        p5, p4, p3
    v.cmp.ne     p3, v11, v10
    p.and        p4, p5, p3
    s.addi       s11, s7, #1344
    p.and        p3, p4, p1
    v.extract    s13, v14, #4
    v.extract    s15, v18, #4
    v.splat      v6, s13
    v.movi       v7, #0
    v.splat      v10, s15
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v11, [s23, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s13, v5, #4
    v.movi       v15, #0
    v.splat      v16, s13
    v.cmp.ne     p2, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v15
    p.and        p4, p5, p2
    s.movz       s13, #4
    a.vwrite     a1, s14, v11
    v.ld.w       v3, [s2, #0]
    v.extract    s2, v17, #4
    v.movi       v6, #0
    v.splat      v7, s2
    v.extract    s2, v4, #4
    v.movi       v10, #0
    v.splat      v11, s2
    v.cmp.ne     p2, v7, v6
    p.and        p5, p4, p2
    v.cmp.ne     p2, v11, v10
    p.and        p4, p5, p2
    s.addi       s2, s7, #1408
    p.and        p2, p4, p1
    v.extract    s14, v14, #5
    v.extract    s15, v18, #5
    v.splat      v6, s14
    v.movi       v7, #0
    v.splat      v10, s15
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s23, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s14, v5, #5
    v.movi       v15, #0
    v.splat      v16, s14
    v.cmp.ne     p3, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v15
    p.and        p4, p5, p3
    s.movz       s14, #5
    a.vwrite     a1, s9, v11
    v.ld.w       v3, [s11, #0]
    v.extract    s9, v17, #5
    v.movi       v6, #0
    v.splat      v7, s9
    v.extract    s9, v4, #5
    v.movi       v10, #0
    v.splat      v11, s9
    v.cmp.ne     p3, v7, v6
    p.and        p5, p4, p3
    v.cmp.ne     p3, v11, v10
    p.and        p4, p5, p3
    s.addi       s9, s7, #1472
    p.and        p3, p4, p1
    v.extract    s11, v14, #6
    v.extract    s15, v18, #6
    v.splat      v6, s11
    v.movi       v7, #0
    v.splat      v10, s15
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v11, [s23, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s11, v5, #6
    v.movi       v15, #0
    v.splat      v16, s11
    v.cmp.ne     p2, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v15
    p.and        p4, p5, p2
    s.movz       s11, #6
    a.vwrite     a1, s13, v11
    v.ld.w       v3, [s2, #0]
    v.extract    s2, v17, #6
    v.movi       v6, #0
    v.splat      v7, s2
    v.extract    s2, v4, #6
    v.movi       v10, #0
    v.splat      v11, s2
    v.cmp.ne     p2, v7, v6
    p.and        p5, p4, p2
    v.cmp.ne     p2, v11, v10
    p.and        p4, p5, p2
    s.addi       s2, s7, #1536
    p.and        p2, p4, p1
    v.extract    s13, v14, #7
    v.extract    s15, v18, #7
    v.splat      v6, s13
    v.movi       v7, #0
    v.splat      v10, s15
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s23, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s13, v5, #7
    v.movi       v15, #0
    v.splat      v16, s13
    v.cmp.ne     p3, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v15
    p.and        p4, p5, p3
    s.movz       s13, #7
    a.vwrite     a1, s14, v11
    v.ld.w       v3, [s9, #0]
    v.extract    s9, v17, #7
    v.movi       v6, #0
    v.splat      v7, s9
    v.extract    s9, v4, #7
    v.movi       v10, #0
    v.splat      v11, s9
    v.cmp.ne     p3, v7, v6
    p.and        p5, p4, p3
    v.cmp.ne     p3, v11, v10
    p.and        p4, p5, p3
    s.addi       s9, s7, #1600
    p.and        p3, p4, p1
    v.extract    s14, v14, #8
    v.extract    s15, v18, #8
    v.splat      v6, s14
    v.movi       v7, #0
    v.splat      v10, s15
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v11, [s23, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s14, v5, #8
    v.movi       v15, #0
    v.splat      v16, s14
    v.cmp.ne     p2, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v15
    p.and        p4, p5, p2
    s.movz       s14, #8
    a.vwrite     a1, s11, v11
    v.ld.w       v3, [s2, #0]
    v.extract    s2, v17, #8
    v.movi       v6, #0
    v.splat      v7, s2
    v.extract    s2, v4, #8
    v.movi       v10, #0
    v.splat      v11, s2
    v.cmp.ne     p2, v7, v6
    p.and        p5, p4, p2
    v.cmp.ne     p2, v11, v10
    p.and        p4, p5, p2
    s.addi       s2, s7, #1664
    p.and        p2, p4, p1
    v.extract    s11, v14, #9
    v.extract    s15, v18, #9
    v.splat      v6, s11
    v.movi       v7, #0
    v.splat      v10, s15
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s23, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s11, v5, #9
    v.movi       v15, #0
    v.splat      v16, s11
    v.cmp.ne     p3, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v15
    p.and        p4, p5, p3
    s.movz       s11, #9
    a.vwrite     a1, s13, v11
    v.ld.w       v3, [s9, #0]
    v.extract    s9, v17, #9
    v.movi       v6, #0
    v.splat      v7, s9
    v.extract    s9, v4, #9
    v.movi       v10, #0
    v.splat      v11, s9
    v.cmp.ne     p3, v7, v6
    p.and        p5, p4, p3
    v.cmp.ne     p3, v11, v10
    p.and        p4, p5, p3
    s.addi       s9, s7, #1728
    p.and        p3, p4, p1
    v.extract    s13, v14, #10
    v.extract    s15, v18, #10
    v.splat      v6, s13
    v.movi       v7, #0
    v.splat      v10, s15
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v11, [s23, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s13, v5, #10
    v.movi       v15, #0
    v.splat      v16, s13
    v.cmp.ne     p2, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v15
    p.and        p4, p5, p2
    s.movz       s13, #10
    a.vwrite     a1, s14, v11
    v.ld.w       v3, [s2, #0]
    v.extract    s2, v17, #10
    v.movi       v6, #0
    v.splat      v7, s2
    v.extract    s2, v4, #10
    v.movi       v10, #0
    v.splat      v11, s2
    v.cmp.ne     p2, v7, v6
    p.and        p5, p4, p2
    v.cmp.ne     p2, v11, v10
    p.and        p4, p5, p2
    s.addi       s2, s7, #1792
    p.and        p2, p4, p1
    v.extract    s14, v14, #11
    v.extract    s15, v18, #11
    v.splat      v6, s14
    v.movi       v7, #0
    v.splat      v10, s15
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s23, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s14, v5, #11
    v.movi       v15, #0
    v.splat      v16, s14
    v.cmp.ne     p3, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v15
    p.and        p4, p5, p3
    s.movz       s14, #11
    a.vwrite     a1, s11, v11
    v.ld.w       v3, [s9, #0]
    v.extract    s9, v17, #11
    v.movi       v6, #0
    v.splat      v7, s9
    v.extract    s9, v4, #11
    v.movi       v10, #0
    v.splat      v11, s9
    v.cmp.ne     p3, v7, v6
    p.and        p5, p4, p3
    v.cmp.ne     p3, v11, v10
    p.and        p4, p5, p3
    s.addi       s9, s7, #1856
    p.and        p3, p4, p1
    v.extract    s11, v14, #12
    v.extract    s15, v18, #12
    v.splat      v6, s11
    v.movi       v7, #0
    v.splat      v10, s15
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v11, [s23, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s11, v5, #12
    v.movi       v15, #0
    v.splat      v16, s11
    v.cmp.ne     p2, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v15
    p.and        p4, p5, p2
    s.movz       s11, #12
    a.vwrite     a1, s13, v11
    v.ld.w       v3, [s2, #0]
    v.extract    s2, v17, #12
    v.movi       v6, #0
    v.splat      v7, s2
    v.extract    s2, v4, #12
    v.movi       v10, #0
    v.splat      v11, s2
    v.cmp.ne     p2, v7, v6
    p.and        p5, p4, p2
    v.cmp.ne     p2, v11, v10
    p.and        p4, p5, p2
    s.addi       s2, s7, #1920
    p.and        p2, p4, p1
    v.extract    s13, v14, #13
    v.extract    s15, v18, #13
    v.splat      v6, s13
    v.movi       v7, #0
    v.splat      v10, s15
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s23, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s13, v5, #13
    v.movi       v15, #0
    v.splat      v16, s13
    v.cmp.ne     p3, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v15
    p.and        p4, p5, p3
    s.movz       s13, #13
    a.vwrite     a1, s14, v11
    v.ld.w       v3, [s9, #0]
    v.extract    s9, v17, #13
    v.movi       v6, #0
    v.splat      v7, s9
    v.extract    s9, v4, #13
    v.movi       v10, #0
    v.splat      v11, s9
    v.cmp.ne     p3, v7, v6
    p.and        p5, p4, p3
    v.cmp.ne     p3, v11, v10
    p.and        p4, p5, p3
    s.addi       s9, s7, #1984
    p.and        p3, p4, p1
    v.extract    s14, v14, #14
    v.extract    s15, v18, #14
    v.splat      v6, s14
    v.movi       v7, #0
    v.splat      v10, s15
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v11, [s23, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s14, v5, #14
    v.movi       v15, #0
    v.splat      v16, s14
    v.cmp.ne     p2, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v15
    p.and        p4, p5, p2
    s.movz       s14, #14
    a.vwrite     a1, s11, v11
    v.ld.w       v3, [s2, #0]
    v.extract    s2, v17, #14
    v.movi       v6, #0
    v.splat      v7, s2
    v.extract    s2, v4, #14
    v.movi       v10, #0
    v.splat      v11, s2
    v.cmp.ne     p2, v7, v6
    p.and        p5, p4, p2
    v.cmp.ne     p2, v11, v10
    p.and        p4, p5, p2
    s.addi       s2, s7, #2048
    p.and        p2, p4, p1
    v.extract    s11, v14, #15
    v.extract    s15, v18, #15
    v.splat      v6, s11
    v.movi       v7, #0
    v.splat      v10, s15
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s23, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s11, v5, #15
    v.movi       v5, #0
    v.splat      v14, s11
    v.cmp.ne     p3, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v14, v5
    p.and        p4, p5, p3
    s.movz       s11, #15
    a.vwrite     a1, s13, v11
    v.ld.w       v3, [s9, #0]
    v.extract    s9, v17, #15
    v.movi       v5, #0
    v.splat      v6, s9
    v.extract    s9, v4, #15
    v.movi       v4, #0
    v.splat      v7, s9
    v.cmp.ne     p3, v6, v5
    p.and        p5, p4, p3
    v.cmp.ne     p3, v7, v4
    p.and        p4, p5, p3
    s.addi       s9, s7, #1024
    p.and        p3, p4, p1
    s.movz       s13, #24
    s.mul        s15, s6, s8
    s.mul        s6, s1, s13
    s.movz       s1, #0
    s.addi       s13, s7, #2112
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s23, v3]              // index is in elements (ISA sec 9.1)
    s.addi       s16, s7, #1024
    s.add        s17, s1, s6                     // the tile origin
    s.addi       s1, s13, #64
    s.add        s6, s17, s15                    // the tile origin
    v.splat      v3, s6
    s.addi       s15, s6, #1
    v.splat      v5, s15
    a.vwrite     a1, s14, v4
    v.ld.w       v4, [s2, #0]
    s.addi       s2, s7, #1024
    s.addi       s14, s6, #2
    s.addi       s15, s13, #128
    v.splat      v6, s14
    s.addi       s14, s7, #1024
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v7, [s23, v4]              // index is in elements (ISA sec 9.1)
    s.addi       s17, s6, #3
    v.splat      v4, s17
    s.addi       s17, s13, #192
    a.vwrite     a1, s11, v7
    v.ld.w       v7, [s9, #0]
    s.addi       s9, s7, #1024
    s.addi       s11, s6, #4
    v.splat      v10, s11
    s.addi       s11, s13, #256
    v.add        v11, v7, v3
    v.st.w       [s13, #0], v11
    v.ld.w       v3, [s16, #0]
    s.addi       s16, s7, #1024
    v.add        v7, v3, v5
    v.st.w       [s1, #0], v7
    s.addi       s1, s6, #5
    v.splat      v3, s1
    s.addi       s1, s13, #320
    v.ld.w       v5, [s2, #0]
    s.addi       s2, s7, #1024
    v.add        v7, v5, v6
    v.st.w       [s15, #0], v7
    s.addi       s15, s6, #6
    v.splat      v5, s15
    s.addi       s15, s13, #384
    v.ld.w       v6, [s14, #0]
    s.addi       s14, s7, #1024
    v.add        v7, v6, v4
    v.st.w       [s17, #0], v7
    s.addi       s17, s6, #7
    v.splat      v4, s17
    s.addi       s17, s13, #448
    v.ld.w       v6, [s9, #0]
    s.addi       s9, s7, #1024
    v.add        v7, v6, v10
    v.st.w       [s11, #0], v7
    s.addi       s11, s6, #8
    v.splat      v6, s11
    s.addi       s11, s13, #512
    v.ld.w       v7, [s16, #0]
    s.addi       s16, s7, #1024
    v.add        v10, v7, v3
    v.st.w       [s1, #0], v10
    s.addi       s1, s6, #9
    v.splat      v3, s1
    s.addi       s1, s13, #576
    v.ld.w       v7, [s2, #0]
    s.addi       s2, s7, #1024
    v.add        v10, v7, v5
    v.st.w       [s15, #0], v10
    s.addi       s15, s6, #10
    v.splat      v5, s15
    s.addi       s15, s13, #640
    v.ld.w       v7, [s14, #0]
    s.addi       s14, s7, #1024
    v.add        v10, v7, v4
    v.st.w       [s17, #0], v10
    s.addi       s17, s6, #11
    v.splat      v4, s17
    s.addi       s17, s13, #704
    v.ld.w       v7, [s9, #0]
    s.addi       s9, s7, #1024
    v.add        v10, v7, v6
    v.st.w       [s11, #0], v10
    s.addi       s11, s6, #12
    v.splat      v6, s11
    s.addi       s11, s13, #768
    v.ld.w       v7, [s16, #0]
    s.addi       s16, s7, #1024
    v.add        v10, v7, v3
    v.splat      v3, s4
    v.st.w       [s1, #0], v10
    s.addi       s1, s6, #13
    v.splat      v7, s8
    v.splat      v10, s1
    s.addi       s1, s13, #832
    v.cmp.lt     p1, v3, v7
    v.ld.w       v3, [s2, #0]
    s.addi       s2, s7, #1024
    v.add        v11, v3, v5
    v.splat      v3, s8
    v.st.w       [s15, #0], v11
    s.addi       s15, s6, #14
    s.addi       s18, s6, #15
    v.splat      v5, s15
    s.addi       s6, s13, #896
    v.splat      v11, s18
    s.addi       s15, s7, #1024
    s.addi       s18, s13, #960
    v.ld.w       v14, [s14, #0]
    s.addi       s13, s7, #2112
    v.add        v15, v14, v4
    v.st.w       [s17, #0], v15
    s.movz       s14, #0
    v.splat      v4, s25
    s.add        s17, s14, s5                    // the tile origin
    v.splat      v14, s17
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s14, #0
    v.cmp.lt     p2, v4, v7
    v.add        v4, v12, v14
    v.cmp.lt     p3, v4, v3
    p.and        p4, p1, p3
    p.and        p1, p2, p3
    v.ld.w       v3, [s9, #0]
    s.addi       s9, s7, #2176
    v.add        v4, v3, v6
    v.st.w       [s11, #0], v4
    s.movz       s11, #1
    v.ld.w       v3, [s16, #0]
    s.addi       s16, s7, #2240
    v.add        v4, v3, v10
    v.st.w       [s1, #0], v4
    s.movz       s1, #2
    v.splat      v3, s1
    s.movz       s1, #2
    v.cmp.lt     p2, v3, v7
    p.and        p5, p2, p3
    v.ld.w       v3, [s2, #0]
    s.addi       s2, s7, #2304
    v.splat      v4, s12
    s.movz       s12, #3
    v.add        v6, v3, v5
    v.st.w       [s6, #0], v6
    s.addi       s6, s7, #2368
    v.ld.w       v3, [s15, #0]
    s.movz       s15, #4
    v.splat      v5, s15
    s.movz       s15, #4
    v.add        v6, v3, v11
    v.st.w       [s18, #0], v6
    fence.acq_rel.device
    s.movz       s17, #5
    v.ld.w       v3, [s13, #0]
    s.addi       s13, s7, #2432
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v6, [s26, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v7
    p.and        p4, p2, p3
    a.vwrite     a2, s14, v6
    v.ld.w       v3, [s9, #0]
    s.movz       s9, #5
    s.addi       s14, s7, #2496
    v.splat      v4, s9
    s.movz       s9, #6
    v.splat      v6, s9
    s.movz       s9, #6
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.w v10, [s26, v3]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v7
    p.and        p2, p1, p3
    a.vwrite     a2, s11, v10
    v.ld.w       v3, [s16, #0]
    s.addi       s11, s7, #2560
    s.movz       s16, #7
    v.splat      v5, s16
    s.movz       s16, #7
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v10, [s26, v3]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v7
    p.and        p5, p1, p3
    a.vwrite     a2, s1, v10
    v.ld.w       v3, [s2, #0]
    s.addi       s1, s7, #2624
    v.splat      v4, s8
    s.movz       s2, #8
    s.addi       s8, s7, #2688
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v10, [s26, v3]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v7
    p.and        p4, p1, p3
    a.vwrite     a2, s12, v10
    v.ld.w       v3, [s6, #0]
    v.splat      v6, s24
    s.movz       s6, #9
    s.addi       s12, s7, #2752
    s.movz       s18, #10
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v10, [s26, v3]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v7
    p.and        p2, p1, p3
    a.vwrite     a2, s15, v10
    v.ld.w       v3, [s13, #0]
    s.movz       s13, #10
    s.addi       s15, s7, #2816
    v.splat      v5, s13
    s.movz       s13, #11
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v10, [s26, v3]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v7
    p.and        p5, p1, p3
    a.vwrite     a2, s17, v10
    v.ld.w       v3, [s14, #0]
    s.movz       s14, #11
    s.addi       s17, s7, #2880
    v.splat      v4, s14
    s.movz       s14, #12
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v10, [s26, v3]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v7
    p.and        p4, p1, p3
    a.vwrite     a2, s9, v10
    v.ld.w       v3, [s11, #0]
    s.movz       s9, #12
    s.addi       s11, s7, #2944
    v.splat      v6, s9
    s.movz       s9, #13
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v10, [s26, v3]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v7
    p.and        p2, p1, p3
    a.vwrite     a2, s16, v10
    v.ld.w       v3, [s1, #0]
    s.movz       s1, #13
    s.addi       s16, s7, #3008
    v.splat      v5, s1
    s.movz       s1, #14
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v10, [s26, v3]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v7
    p.and        p5, p1, p3
    a.vwrite     a2, s2, v10
    v.ld.w       v3, [s8, #0]
    s.movz       s2, #14
    s.movz       s8, #15
    v.splat      v4, s2
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v10, [s26, v3]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v7
    p.and        p4, p1, p3
    s.addi       s2, s7, #3072
    a.vwrite     a2, s6, v10
    v.ld.w       v3, [s12, #0]
    s.movz       s6, #15
    v.movi       v6, #0
    v.splat      v10, s6
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v11, [s26, v3]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v7
    p.and        p2, p1, p3
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s6, #0
    a.vwrite     a2, s18, v11
    v.ld.w       v3, [s15, #0]
    s.movz       s12, #0
    s.movz       s15, #0
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v5, [s26, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v7
    p.and        p5, p1, p3
    a.vwrite     a2, s13, v5
    v.ld.w       v3, [s17, #0]
    s.movz       s13, #1
    s.movz       s17, #2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s26, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v10, v7
    p.and        p4, p1, p3
    a.vwrite     a2, s14, v4
    v.ld.w       v3, [s11, #0]
    s.movz       s11, #3
    s.movz       s14, #4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s26, v3]              // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s9, v4
    v.ld.w       v3, [s16, #0]
    s.movz       s9, #5
    s.movz       s16, #6
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v4, [s26, v3]              // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s1, v4
    v.ld.w       v3, [s2, #0]
    s.movz       s1, #7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s26, v3]              // index is in elements (ISA sec 9.1)
    s.movz       s2, #8
    a.vwrite     a2, s8, v4
    a.vread      v3, a1, s12
    a.vread      v4, a2, s15
    a.vread      v5, a2, s13
    v.extract    s8, v3, #0
    v.extract    s12, v3, #1
    v.splat      v7, s8
    v.splat      v10, s12
    v.extract    s8, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s8
    a.vread      v7, a2, s17
    v.extract    s8, v3, #3
    a.vread      v12, a2, s11
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s8
    v.extract    s8, v3, #4
    a.vread      v10, a2, s14
    v.splat      v11, s8
    vf.fma       v15, v4, v7, v14
    v.extract    s8, v3, #5
    a.vread      v4, a2, s9
    v.splat      v7, s8
    v.extract    s8, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s8
    a.vread      v12, a2, s16
    v.extract    s8, v3, #7
    a.vread      v15, a2, s1
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s8
    v.extract    s1, v3, #8
    a.vread      v11, a2, s2
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #1
    s.movz       s2, #0
    s.movz       s8, #1
    s.movz       s9, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s11, #3
    s.movz       s12, #4
    s.movz       s13, #5
    s.movz       s14, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s15, #7
    s.movz       s16, #8
    s.movz       s17, #1
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s6, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s8
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v7, a2, s9
    v.extract    s1, v3, #3
    a.vread      v12, a2, s11
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s12
    v.splat      v11, s1
    vf.fma       v15, v4, v7, v14
    v.extract    s1, v3, #5
    a.vread      v4, a2, s13
    v.splat      v7, s1
    v.extract    s1, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s1
    a.vread      v12, a2, s14
    v.extract    s1, v3, #7
    a.vread      v15, a2, s15
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s16
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #2
    s.movz       s2, #0
    s.movz       s6, #1
    s.movz       s8, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s9, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s16, #2
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s17, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s6
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v7, a2, s8
    v.extract    s1, v3, #3
    a.vread      v12, a2, s9
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s1
    vf.fma       v15, v4, v7, v14
    v.extract    s1, v3, #5
    a.vread      v4, a2, s12
    v.splat      v7, s1
    v.extract    s1, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s1
    a.vread      v12, a2, s13
    v.extract    s1, v3, #7
    a.vread      v15, a2, s14
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s15
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #3
    s.movz       s2, #0
    s.movz       s6, #1
    s.movz       s8, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s9, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s17, #3
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s16, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s6
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v7, a2, s8
    v.extract    s1, v3, #3
    a.vread      v12, a2, s9
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s1
    vf.fma       v15, v4, v7, v14
    v.extract    s1, v3, #5
    a.vread      v4, a2, s12
    v.splat      v7, s1
    v.extract    s1, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s1
    a.vread      v12, a2, s13
    v.extract    s1, v3, #7
    a.vread      v15, a2, s14
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s15
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #4
    s.movz       s2, #0
    s.movz       s6, #1
    s.movz       s8, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s9, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s16, #4
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s17, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s6
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v7, a2, s8
    v.extract    s1, v3, #3
    a.vread      v12, a2, s9
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s1
    vf.fma       v15, v4, v7, v14
    v.extract    s1, v3, #5
    a.vread      v4, a2, s12
    v.splat      v7, s1
    v.extract    s1, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s1
    a.vread      v12, a2, s13
    v.extract    s1, v3, #7
    a.vread      v15, a2, s14
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s15
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #5
    s.movz       s2, #0
    s.movz       s6, #1
    s.movz       s8, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s9, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s17, #5
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s16, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s6
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v7, a2, s8
    v.extract    s1, v3, #3
    a.vread      v12, a2, s9
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s1
    vf.fma       v15, v4, v7, v14
    v.extract    s1, v3, #5
    a.vread      v4, a2, s12
    v.splat      v7, s1
    v.extract    s1, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s1
    a.vread      v12, a2, s13
    v.extract    s1, v3, #7
    a.vread      v15, a2, s14
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s15
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #6
    s.movz       s2, #0
    s.movz       s6, #1
    s.movz       s8, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s9, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s16, #6
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s17, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s6
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v7, a2, s8
    v.extract    s1, v3, #3
    a.vread      v12, a2, s9
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s1
    vf.fma       v15, v4, v7, v14
    v.extract    s1, v3, #5
    a.vread      v4, a2, s12
    v.splat      v7, s1
    v.extract    s1, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s1
    a.vread      v12, a2, s13
    v.extract    s1, v3, #7
    a.vread      v15, a2, s14
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s15
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #7
    s.movz       s2, #0
    s.movz       s6, #1
    s.movz       s8, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s9, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s17, #7
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s16, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s6
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v7, a2, s8
    v.extract    s1, v3, #3
    a.vread      v12, a2, s9
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s1
    vf.fma       v15, v4, v7, v14
    v.extract    s1, v3, #5
    a.vread      v4, a2, s12
    v.splat      v7, s1
    v.extract    s1, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s1
    a.vread      v12, a2, s13
    v.extract    s1, v3, #7
    a.vread      v15, a2, s14
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s15
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #8
    s.movz       s2, #0
    s.movz       s6, #1
    s.movz       s8, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s9, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s16, #8
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s17, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s6
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v7, a2, s8
    v.extract    s1, v3, #3
    a.vread      v12, a2, s9
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s1
    vf.fma       v15, v4, v7, v14
    v.extract    s1, v3, #5
    a.vread      v4, a2, s12
    v.splat      v7, s1
    v.extract    s1, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s1
    a.vread      v12, a2, s13
    v.extract    s1, v3, #7
    a.vread      v15, a2, s14
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s15
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #9
    s.movz       s2, #0
    s.movz       s6, #1
    s.movz       s8, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s9, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s17, #9
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s16, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s6
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v7, a2, s8
    v.extract    s1, v3, #3
    a.vread      v12, a2, s9
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s1
    vf.fma       v15, v4, v7, v14
    v.extract    s1, v3, #5
    a.vread      v4, a2, s12
    v.splat      v7, s1
    v.extract    s1, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s1
    a.vread      v12, a2, s13
    v.extract    s1, v3, #7
    a.vread      v15, a2, s14
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s15
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #10
    s.movz       s2, #0
    s.movz       s6, #1
    s.movz       s8, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s9, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s16, #10
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s17, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s6
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v7, a2, s8
    v.extract    s1, v3, #3
    a.vread      v12, a2, s9
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s1
    vf.fma       v15, v4, v7, v14
    v.extract    s1, v3, #5
    a.vread      v4, a2, s12
    v.splat      v7, s1
    v.extract    s1, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s1
    a.vread      v12, a2, s13
    v.extract    s1, v3, #7
    a.vread      v15, a2, s14
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s15
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #11
    s.movz       s2, #0
    s.movz       s6, #1
    s.movz       s8, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s9, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s17, #11
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s16, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s6
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v7, a2, s8
    v.extract    s1, v3, #3
    a.vread      v12, a2, s9
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s1
    vf.fma       v15, v4, v7, v14
    v.extract    s1, v3, #5
    a.vread      v4, a2, s12
    v.splat      v7, s1
    v.extract    s1, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s1
    a.vread      v12, a2, s13
    v.extract    s1, v3, #7
    a.vread      v15, a2, s14
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s15
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #12
    s.movz       s2, #0
    s.movz       s6, #1
    s.movz       s8, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s9, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s16, #12
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s17, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s6
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v7, a2, s8
    v.extract    s1, v3, #3
    a.vread      v12, a2, s9
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s1
    vf.fma       v15, v4, v7, v14
    v.extract    s1, v3, #5
    a.vread      v4, a2, s12
    v.splat      v7, s1
    v.extract    s1, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s1
    a.vread      v12, a2, s13
    v.extract    s1, v3, #7
    a.vread      v15, a2, s14
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s15
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #13
    s.movz       s2, #0
    s.movz       s6, #1
    s.movz       s8, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s9, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s17, #13
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s16, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s6
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v7, a2, s8
    v.extract    s1, v3, #3
    a.vread      v12, a2, s9
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s1
    vf.fma       v15, v4, v7, v14
    v.extract    s1, v3, #5
    a.vread      v4, a2, s12
    v.splat      v7, s1
    v.extract    s1, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s1
    a.vread      v12, a2, s13
    v.extract    s1, v3, #7
    a.vread      v15, a2, s14
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s15
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #14
    s.movz       s2, #0
    s.movz       s6, #1
    s.movz       s8, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s9, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s16, #14
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s17, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s6
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v7, a2, s8
    v.extract    s1, v3, #3
    a.vread      v12, a2, s9
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s1
    vf.fma       v15, v4, v7, v14
    v.extract    s1, v3, #5
    a.vread      v4, a2, s12
    v.splat      v7, s1
    v.extract    s1, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s1
    a.vread      v12, a2, s13
    v.extract    s1, v3, #7
    a.vread      v15, a2, s14
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s15
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #15
    s.movz       s2, #0
    s.movz       s6, #1
    s.movz       s8, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s9, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s17, #15
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s16, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s6
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v6, a2, s8
    v.extract    s1, v3, #3
    a.vread      v7, a2, s9
    vf.fma       v12, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s1
    vf.fma       v14, v4, v6, v12
    v.extract    s1, v3, #5
    a.vread      v4, a2, s12
    v.splat      v6, s1
    v.extract    s1, v3, #6
    vf.fma       v12, v5, v7, v14
    v.splat      v5, s1
    a.vread      v7, a2, s13
    v.extract    s1, v3, #7
    a.vread      v14, a2, s14
    vf.fma       v15, v11, v10, v12
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s15
    v.splat      v12, s1
    vf.fma       v16, v6, v4, v15
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v6, a2, s2
    vf.fma       v15, v5, v7, v16
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v10, v14, v15
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v14, a2, s2
    vf.fma       v15, v12, v11, v16
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v12, a2, s2
    vf.fma       v16, v4, v6, v15
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v6, a2, s2
    vf.fma       v15, v5, v7, v16
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v10, v14, v15
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v14, v11, v12, v16
    s.movz       s1, #0
    s.movz       s2, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s6, #0
    s.movz       s8, #1
    vf.fma       v11, v4, v6, v14
    s.movz       s9, #1
    s.movz       s11, #1
    s.movz       s12, #2
    s.movz       s13, #2
    vf.fma       v4, v5, v7, v11
    s.movz       s14, #2
    s.movz       s15, #3
    s.movz       s16, #3
    s.movz       s18, #3
    vf.fma       v5, v3, v10, v4
    s.movz       s19, #4
    a.vwrite     a3, s17, v5
    a.vread      v3, a0, s1
    a.vread      v4, a3, s2
    s.movz       s1, #4
    s.movz       s2, #4
    vf.add       v5, v3, v4
    s.movz       s17, #5
    a.vwrite     a4, s6, v5
    a.vread      v3, a0, s8
    a.vread      v4, a3, s9
    s.movz       s6, #5
    s.movz       s8, #5
    vf.add       v5, v3, v4
    s.movz       s9, #6
    a.vwrite     a4, s11, v5
    a.vread      v3, a0, s12
    a.vread      v4, a3, s13
    s.movz       s11, #6
    s.movz       s12, #6
    vf.add       v5, v3, v4
    s.movz       s13, #7
    a.vwrite     a4, s14, v5
    a.vread      v3, a0, s15
    a.vread      v4, a3, s16
    s.movz       s14, #7
    s.movz       s15, #7
    vf.add       v5, v3, v4
    s.movz       s16, #8
    a.vwrite     a4, s18, v5
    a.vread      v3, a0, s19
    a.vread      v4, a3, s1
    s.movz       s1, #8
    s.movz       s18, #8
    vf.add       v5, v3, v4
    s.movz       s19, #9
    a.vwrite     a4, s2, v5
    a.vread      v3, a0, s17
    a.vread      v4, a3, s6
    s.movz       s2, #9
    s.movz       s6, #9
    vf.add       v5, v3, v4
    s.movz       s17, #10
    a.vwrite     a4, s8, v5
    a.vread      v3, a0, s9
    a.vread      v4, a3, s11
    s.movz       s8, #10
    s.movz       s9, #10
    vf.add       v5, v3, v4
    s.movz       s11, #11
    a.vwrite     a4, s12, v5
    a.vread      v3, a0, s13
    a.vread      v4, a3, s14
    s.movz       s12, #11
    s.movz       s13, #11
    vf.add       v5, v3, v4
    s.movz       s14, #12
    a.vwrite     a4, s15, v5
    a.vread      v3, a0, s16
    a.vread      v4, a3, s1
    s.movz       s1, #12
    s.movz       s15, #12
    vf.add       v5, v3, v4
    s.movz       s16, #13
    a.vwrite     a4, s18, v5
    a.vread      v3, a0, s19
    a.vread      v4, a3, s2
    s.movz       s2, #13
    s.movz       s18, #13
    vf.add       v5, v3, v4
    s.movz       s19, #14
    a.vwrite     a4, s6, v5
    a.vread      v3, a0, s17
    a.vread      v4, a3, s8
    s.movz       s6, #14
    s.movz       s8, #14
    vf.add       v5, v3, v4
    s.movz       s17, #15
    a.vwrite     a4, s9, v5
    a.vread      v3, a0, s11
    a.vread      v4, a3, s12
    s.movz       s9, #15
    s.movz       s11, #15
    vf.add       v5, v3, v4
    s.movz       s12, #0
    a.vwrite     a4, s13, v5
    a.vread      v3, a0, s14
    a.vread      v4, a3, s1
    s.movz       s1, #0
    s.movz       s13, #1
    vf.add       v5, v3, v4
    s.movz       s14, #1
    a.vwrite     a4, s15, v5
    a.vread      v3, a0, s16
    a.vread      v4, a3, s2
    s.movz       s2, #2
    s.movz       s15, #2
    vf.add       v5, v3, v4
    s.movz       s16, #3
    a.vwrite     a4, s18, v5
    a.vread      v3, a0, s19
    a.vread      v4, a3, s6
    s.movz       s6, #3
    s.movz       s18, #4
    vf.add       v5, v3, v4
    s.movz       s19, #4
    a.vwrite     a4, s8, v5
    a.vread      v3, a0, s17
    a.vread      v4, a3, s9
    s.movz       s8, #5
    s.movz       s9, #5
    vf.add       v5, v3, v4
    s.movz       s17, #6
    a.vwrite     a4, s11, v5
    a.vread      v3, a4, s12
    s.movz       s11, #6
    s.movz       s12, #7
    a.vwrite     a0, s1, v3
    a.vread      v3, a4, s13
    s.movz       s1, #7
    s.movz       s13, #8
    a.vwrite     a0, s14, v3
    a.vread      v3, a4, s2
    s.movz       s2, #8
    s.movz       s14, #9
    a.vwrite     a0, s15, v3
    a.vread      v3, a4, s16
    s.movz       s15, #9
    s.movz       s16, #10
    a.vwrite     a0, s6, v3
    a.vread      v3, a4, s18
    s.movz       s6, #10
    s.movz       s18, #11
    a.vwrite     a0, s19, v3
    a.vread      v3, a4, s8
    s.movz       s8, #11
    s.movz       s19, #12
    a.vwrite     a0, s9, v3
    a.vread      v3, a4, s17
    s.movz       s9, #12
    s.movz       s17, #13
    a.vwrite     a0, s11, v3
    a.vread      v3, a4, s12
    s.movz       s11, #13
    s.movz       s12, #14
    a.vwrite     a0, s1, v3
    a.vread      v3, a4, s13
    s.movz       s1, #14
    s.movz       s13, #15
    a.vwrite     a0, s2, v3
    a.vread      v3, a4, s14
    s.movz       s2, #15
    s.add        s14, s10, s25
    a.vwrite     a0, s15, v3
    a.vread      v3, a4, s16
    s.movz       s15, #1
    a.vwrite     a0, s6, v3
    a.vread      v3, a4, s18
    a.vwrite     a0, s8, v3
    a.vread      v3, a4, s19
    a.vwrite     a0, s9, v3
    a.vread      v3, a4, s17
    a.vwrite     a0, s11, v3
    a.vread      v3, a4, s12
    a.vwrite     a0, s1, v3
    a.vread      v3, a4, s13
    a.vwrite     a0, s2, v3
    s.mov        s10, s14
    br.nz        s15, for_1
endfor_2:
    s.muli       s1, s5, #64                     // a runtime tile origin, x64
    v.extract    s2, v8, #0
    s.movz       s6, #8
    s.movz       s8, #64
    v.extract    s9, v8, #1
    s.movz       s10, #0
    v.splat      v0, s2
    v.splat      v3, s6
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s8
    v.splat      v6, s9
    v.extract    s2, v2, #0
    s.add        s6, s10, s1                     // the tile origin
    v.extract    s1, v2, #1
    v.splat      v7, s2
    v.mul        v10, v0, v3
    v.mul        v0, v4, v5
    v.splat      v4, s6
    v.splat      v5, s1
    v.mul        v11, v6, v3
    v.extract    s1, v9, #0
    v.extract    s2, v9, #1
    v.add        v6, v7, v10
    v.add        v7, v0, v4
    v.splat      v0, s1
    v.splat      v4, s3
    v.add        v10, v5, v11
    v.add        v5, v6, v7
    v.mul        v6, v0, v4
    v.add        v0, v10, v7
    s.addi       s1, s7, #3136
    v.add        v10, v5, v6
    s.addi       s3, s1, #64
    v.movi       v5, #1
    v.splat      v6, s2
    v.st.w       [s1, #0], v10
    v.movi       v10, #1
    v.movi       v11, #0
    v.movi       v12, #1
    v.movi       v14, #0
    v.cmp.lt     p1, v9, v5
    v.mul        v5, v6, v4
    v.cmp.lt     p2, v8, v1
    v.movi       v6, #1
    v.add        v15, v0, v5
    v.movi       v0, #0
    @p1 v.sel        v5, v10, v11
    v.extract    s2, v8, #2
    v.extract    s6, v2, #2
    s.addi       s8, s1, #128
    v.splat      v10, s6
    @p2 v.sel        v11, v12, v14
    v.splat      v12, s2
    v.st.w       [s3, #0], v15
    v.cmp.lt     p1, v2, v1
    v.mul        v14, v12, v3
    @p1 v.sel        v12, v6, v0
    v.extract    s2, v9, #2
    v.add        v0, v10, v14
    v.cmp.lt     p1, v13, v1
    v.extract    s3, v8, #3
    v.extract    s6, v8, #4
    v.extract    s9, v8, #5
    v.splat      v1, s3
    v.splat      v6, s6
    v.splat      v10, s9
    v.extract    s3, v2, #3
    v.extract    s6, v2, #4
    v.extract    s9, v2, #5
    v.extract    s10, v2, #6
    v.splat      v13, s3
    v.mul        v14, v1, v3
    v.splat      v1, s6
    v.mul        v15, v6, v3
    v.mul        v6, v10, v3
    v.extract    s3, v9, #3
    v.extract    s6, v9, #4
    v.extract    s11, v9, #5
    v.add        v10, v13, v14
    v.splat      v13, s9
    v.add        v14, v1, v15
    v.splat      v1, s10
    v.add        v15, v13, v6
    v.splat      v6, s2
    v.add        v13, v0, v7
    v.extract    s2, v8, #6
    v.mul        v0, v6, v4
    v.add        v6, v10, v7
    v.add        v10, v14, v7
    v.add        v14, v15, v7
    v.add        v15, v13, v0
    v.splat      v0, s2
    s.addi       s2, s1, #192
    s.addi       s9, s1, #256
    v.mul        v13, v0, v3
    s.addi       s10, s1, #320
    v.st.w       [s8, #0], v15
    v.extract    s8, v8, #7
    v.splat      v0, s3
    v.extract    s3, v2, #7
    v.add        v15, v1, v13
    v.splat      v1, s8
    v.extract    s8, v9, #6
    v.mul        v13, v0, v4
    v.mul        v0, v1, v3
    v.add        v1, v15, v7
    v.add        v15, v6, v13
    v.splat      v6, s3
    s.addi       s3, s1, #384
    v.add        v13, v6, v0
    v.splat      v0, s6
    s.addi       s6, s1, #448
    v.add        v6, v13, v7
    v.mul        v13, v0, v4
    v.st.w       [s2, #0], v15
    v.extract    s2, v8, #8
    v.splat      v0, s11
    v.extract    s11, v2, #8
    v.add        v15, v10, v13
    v.splat      v10, s2
    v.extract    s2, v9, #7
    v.mul        v13, v0, v4
    v.mul        v0, v10, v3
    v.add        v10, v14, v13
    v.splat      v13, s11
    s.addi       s11, s1, #512
    v.add        v14, v13, v0
    v.splat      v0, s8
    v.add        v13, v14, v7
    v.mul        v14, v0, v4
    v.st.w       [s9, #0], v15
    v.extract    s8, v8, #9
    v.extract    s9, v2, #9
    v.splat      v0, s8
    v.extract    s8, v9, #8
    v.add        v15, v1, v14
    v.splat      v1, s9
    v.mul        v14, v0, v3
    s.addi       s9, s1, #576
    v.add        v0, v1, v14
    v.splat      v1, s2
    v.add        v14, v0, v7
    v.mul        v0, v1, v4
    v.add        v1, v6, v0
    v.splat      v0, s8
    v.st.w       [s10, #0], v10
    v.extract    s2, v8, #10
    v.extract    s8, v2, #10
    v.splat      v6, s2
    v.extract    s2, v9, #9
    v.mul        v10, v0, v4
    v.mul        v0, v6, v3
    s.addi       s10, s1, #640
    v.add        v6, v13, v10
    v.splat      v10, s8
    v.add        v13, v10, v0
    v.splat      v0, s2
    v.add        v10, v13, v7
    v.mul        v13, v0, v4
    v.st.w       [s3, #0], v15
    v.extract    s2, v8, #11
    v.extract    s3, v2, #11
    v.splat      v0, s2
    v.extract    s2, v9, #10
    v.add        v15, v14, v13
    v.splat      v13, s3
    v.mul        v14, v0, v3
    s.addi       s3, s1, #704
    v.add        v0, v13, v14
    v.splat      v13, s2
    v.add        v14, v0, v7
    v.mul        v0, v13, v4
    v.add        v13, v10, v0
    v.st.w       [s6, #0], v1
    v.extract    s2, v8, #12
    v.extract    s6, v2, #12
    v.splat      v0, s2
    v.splat      v1, s6
    v.extract    s2, v9, #11
    v.mul        v10, v0, v3
    s.addi       s6, s1, #768
    v.add        v0, v1, v10
    v.splat      v1, s2
    v.add        v10, v0, v7
    v.mul        v0, v1, v4
    v.add        v1, v14, v0
    v.st.w       [s11, #0], v6
    v.extract    s2, v8, #13
    v.extract    s8, v2, #13
    v.splat      v0, s2
    v.splat      v6, s8
    v.extract    s2, v9, #12
    v.mul        v14, v0, v3
    s.addi       s8, s1, #832
    v.add        v0, v6, v14
    v.splat      v6, s2
    v.add        v14, v0, v7
    v.mul        v0, v6, v4
    v.add        v6, v10, v0
    v.st.w       [s9, #0], v15
    v.extract    s2, v8, #14
    v.extract    s9, v2, #14
    v.splat      v0, s2
    v.splat      v10, s9
    v.extract    s2, v9, #13
    v.mul        v15, v0, v3
    s.addi       s9, s1, #896
    v.add        v0, v10, v15
    v.splat      v10, s2
    v.add        v15, v0, v7
    v.mul        v0, v10, v4
    v.add        v10, v14, v0
    v.st.w       [s10, #0], v13
    v.extract    s2, v8, #15
    v.extract    s10, v2, #15
    v.splat      v0, s2
    v.splat      v2, s10
    v.extract    s2, v9, #14
    v.mul        v8, v0, v3
    v.splat      v0, s2
    s.addi       s2, s1, #960
    v.add        v3, v2, v8
    v.mul        v2, v0, v4
    v.add        v0, v3, v7
    v.add        v3, v15, v2
    v.st.w       [s3, #0], v1
    v.extract    s1, v9, #15
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s3, s5, #4                      // a runtime tile origin, x4
    v.splat      v1, s1
    s.muli       s1, s5, #4                      // a runtime tile origin, x4
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s10, s5, #4                     // a runtime tile origin, x4
    v.mul        v2, v1, v4
    s.add        s11, s28, s3                    // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s3, s5, #4                      // a runtime tile origin, x4
    v.add        v1, v0, v2
    s.add        s5, s27, s1                     // the tile origin
    s.add        s1, s29, s10                    // the tile origin
    v.st.w       [s6, #0], v6
    s.addi       s6, s7, #3136
    v.splat      v0, s4
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.addi       s10, s7, #4160
    s.addi       s12, s7, #3200
    s.addi       s13, s10, #64
    s.addi       s14, s10, #128
    s.add        s15, s30, s3                    // the tile origin
    v.st.w       [s8, #0], v10
    s.addi       s3, s7, #3264
    s.addi       s8, s7, #3328
    v.st.w       [s9, #0], v3
    s.addi       s9, s10, #192
    v.st.w       [s2, #0], v1
    fence.acq_rel.device
    s.addi       s2, s7, #3392
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s10, #256
    v.add        v2, v0, v1
    v.st.w       [s10, #0], v2
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s7, #3456
    v.add        v2, v0, v1
    v.st.w       [s13, #0], v2
    s.addi       s13, s10, #320
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s7, #3520
    v.add        v2, v0, v1
    v.st.w       [s14, #0], v2
    s.addi       s14, s10, #384
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s7, #3584
    v.add        v2, v0, v1
    v.st.w       [s9, #0], v2
    s.addi       s9, s10, #448
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s7, #3648
    v.add        v2, v0, v1
    v.st.w       [s6, #0], v2
    s.addi       s6, s10, #512
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s7, #3712
    v.add        v2, v0, v1
    v.st.w       [s13, #0], v2
    s.addi       s13, s10, #576
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s7, #3776
    v.add        v2, v0, v1
    v.st.w       [s14, #0], v2
    s.addi       s14, s10, #640
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s7, #3840
    v.add        v2, v0, v1
    v.movi       v1, #0
    v.st.w       [s9, #0], v2
    s.addi       s9, s10, #704
    v.ld.w       v2, [s2, #0]
    s.addi       s2, s7, #3904
    v.movi       v3, #0
    v.add        v4, v0, v2
    v.st.w       [s6, #0], v4
    s.addi       s6, s10, #768
    v.ld.w       v2, [s12, #0]
    s.addi       s12, s7, #3968
    v.movi       v4, #0
    v.add        v6, v0, v2
    v.st.w       [s13, #0], v6
    s.addi       s13, s10, #832
    v.ld.w       v2, [s3, #0]
    s.addi       s3, s7, #4032
    v.add        v6, v0, v2
    v.st.w       [s14, #0], v6
    s.addi       s14, s10, #896
    s.addi       s16, s10, #960
    v.ld.w       v2, [s8, #0]
    s.addi       s8, s7, #4096
    v.add        v6, v0, v2
    v.movi       v2, #0
    v.st.w       [s9, #0], v6
    s.addi       s9, s7, #4160
    v.ld.w       v6, [s2, #0]
    v.extract    s2, v5, #0
    v.movi       v7, #0
    v.splat      v8, s2
    v.extract    s2, v11, #0
    v.splat      v9, s2
    v.extract    s2, v12, #0
    v.cmp.ne     p2, v8, v1
    v.splat      v1, s2
    v.cmp.ne     p3, v9, v3
    p.and        p4, p2, p3
    v.cmp.ne     p2, v1, v4
    p.and        p3, p4, p2
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s2, #0
    p.and        p2, p3, p1
    v.add        v1, v0, v6
    v.st.w       [s6, #0], v1
    s.addi       s6, s7, #4224
    v.ld.w       v1, [s12, #0]
    v.extract    s10, v5, #1
    v.movi       v3, #0
    v.splat      v4, s10
    v.extract    s10, v11, #1
    v.splat      v6, s10
    v.extract    s10, v12, #1
    v.cmp.ne     p3, v4, v2
    v.splat      v2, s10
    v.cmp.ne     p4, v6, v7
    p.and        p5, p3, p4
    s.movz       s10, #1
    v.add        v4, v0, v1
    v.cmp.ne     p3, v2, v3
    v.st.w       [s13, #0], v4
    p.and        p4, p5, p3
    p.and        p3, p4, p1
    v.ld.w       v1, [s3, #0]
    v.add        v2, v0, v1
    s.movz       s3, #2
    v.st.w       [s14, #0], v2
    s.addi       s12, s7, #4288
    v.extract    s13, v5, #2
    v.ld.w       v1, [s8, #0]
    v.splat      v2, s13
    v.add        v3, v0, v1
    v.movi       v0, #0
    v.st.w       [s16, #0], v3
    fence.acq_rel.device
    v.extract    s8, v11, #2
    v.movi       v1, #0
    v.splat      v3, s8
    v.cmp.ne     p4, v2, v0
    v.ld.w       v0, [s9, #0]
    v.extract    s8, v12, #2
    v.movi       v2, #0
    v.splat      v4, s8
    s.addi       s8, s7, #4352
    v.extract    s9, v5, #3
    v.movi       v6, #0
    v.splat      v7, s9
    s.movz       s9, #3
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v8, [s31, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v3, v1
    p.and        p5, p4, p2
    v.cmp.ne     p2, v4, v2
    p.and        p4, p5, p2
    v.cmp.ne     p2, v7, v6
    p.and        p5, p4, p1
    a.vwrite     a5, s2, v8
    v.ld.w       v0, [s6, #0]
    v.extract    s2, v11, #3
    v.movi       v1, #0
    v.splat      v2, s2
    v.extract    s2, v12, #3
    v.movi       v3, #0
    v.splat      v4, s2
    s.addi       s2, s7, #4416
    v.extract    s6, v5, #4
    v.movi       v6, #0
    v.splat      v7, s6
    s.movz       s6, #4
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v8, [s31, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v2, v1
    p.and        p4, p2, p3
    v.cmp.ne     p2, v4, v3
    p.and        p3, p4, p2
    v.cmp.ne     p2, v7, v6
    p.and        p4, p3, p1
    a.vwrite     a5, s10, v8
    v.ld.w       v0, [s12, #0]
    v.extract    s10, v11, #4
    v.movi       v1, #0
    v.splat      v2, s10
    v.extract    s10, v12, #4
    v.movi       v3, #0
    v.splat      v4, s10
    s.addi       s10, s7, #4480
    v.extract    s12, v5, #5
    v.movi       v6, #0
    v.splat      v7, s12
    s.movz       s12, #5
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v8, [s31, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v2, v1
    p.and        p5, p2, p3
    v.cmp.ne     p2, v4, v3
    p.and        p3, p5, p2
    v.cmp.ne     p2, v7, v6
    p.and        p5, p3, p1
    a.vwrite     a5, s3, v8
    v.ld.w       v0, [s8, #0]
    v.extract    s3, v11, #5
    v.movi       v1, #0
    v.splat      v2, s3
    v.extract    s3, v12, #5
    v.movi       v3, #0
    v.splat      v4, s3
    s.addi       s3, s7, #4544
    v.extract    s8, v5, #6
    v.movi       v6, #0
    v.splat      v7, s8
    s.movz       s8, #6
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v8, [s31, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v2, v1
    p.and        p4, p2, p3
    v.cmp.ne     p2, v4, v3
    p.and        p3, p4, p2
    v.cmp.ne     p2, v7, v6
    p.and        p4, p3, p1
    a.vwrite     a5, s9, v8
    v.ld.w       v0, [s2, #0]
    v.extract    s2, v11, #6
    v.movi       v1, #0
    v.splat      v2, s2
    v.extract    s2, v12, #6
    v.movi       v3, #0
    v.splat      v4, s2
    s.addi       s2, s7, #4608
    v.extract    s9, v5, #7
    v.movi       v6, #0
    v.splat      v7, s9
    s.movz       s9, #7
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v8, [s31, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v2, v1
    p.and        p5, p2, p3
    v.cmp.ne     p2, v4, v3
    p.and        p3, p5, p2
    v.cmp.ne     p2, v7, v6
    p.and        p5, p3, p1
    a.vwrite     a5, s6, v8
    v.ld.w       v0, [s10, #0]
    v.extract    s6, v11, #7
    v.movi       v1, #0
    v.splat      v2, s6
    v.extract    s6, v12, #7
    v.movi       v3, #0
    v.splat      v4, s6
    s.addi       s6, s7, #4672
    v.extract    s10, v5, #8
    v.movi       v6, #0
    v.splat      v7, s10
    s.movz       s10, #8
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v8, [s31, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v2, v1
    p.and        p4, p2, p3
    v.cmp.ne     p2, v4, v3
    p.and        p3, p4, p2
    v.cmp.ne     p2, v7, v6
    p.and        p4, p3, p1
    a.vwrite     a5, s12, v8
    v.ld.w       v0, [s3, #0]
    v.extract    s3, v11, #8
    v.movi       v1, #0
    v.splat      v2, s3
    v.extract    s3, v12, #8
    v.movi       v3, #0
    v.splat      v4, s3
    s.addi       s3, s7, #4736
    v.extract    s12, v5, #9
    v.movi       v6, #0
    v.splat      v7, s12
    s.movz       s12, #9
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v8, [s31, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v2, v1
    p.and        p5, p2, p3
    v.cmp.ne     p2, v4, v3
    p.and        p3, p5, p2
    v.cmp.ne     p2, v7, v6
    p.and        p5, p3, p1
    a.vwrite     a5, s8, v8
    v.ld.w       v0, [s2, #0]
    v.extract    s2, v11, #9
    v.movi       v1, #0
    v.splat      v2, s2
    v.extract    s2, v12, #9
    v.movi       v3, #0
    v.splat      v4, s2
    s.addi       s2, s7, #4800
    v.extract    s8, v5, #10
    v.movi       v6, #0
    v.splat      v7, s8
    s.movz       s8, #10
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v8, [s31, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v2, v1
    p.and        p4, p2, p3
    v.cmp.ne     p2, v4, v3
    p.and        p3, p4, p2
    v.cmp.ne     p2, v7, v6
    p.and        p4, p3, p1
    a.vwrite     a5, s9, v8
    v.ld.w       v0, [s6, #0]
    v.extract    s6, v11, #10
    v.movi       v1, #0
    v.splat      v2, s6
    v.extract    s6, v12, #10
    v.movi       v3, #0
    v.splat      v4, s6
    s.addi       s6, s7, #4864
    v.extract    s9, v5, #11
    v.movi       v6, #0
    v.splat      v7, s9
    s.movz       s9, #11
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v8, [s31, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v2, v1
    p.and        p5, p2, p3
    v.cmp.ne     p2, v4, v3
    p.and        p3, p5, p2
    v.cmp.ne     p2, v7, v6
    p.and        p5, p3, p1
    a.vwrite     a5, s10, v8
    v.ld.w       v0, [s3, #0]
    v.extract    s3, v11, #11
    v.movi       v1, #0
    v.splat      v2, s3
    v.extract    s3, v12, #11
    v.movi       v3, #0
    v.splat      v4, s3
    s.addi       s3, s7, #4928
    v.extract    s10, v5, #12
    v.movi       v6, #0
    v.splat      v7, s10
    s.movz       s10, #12
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v8, [s31, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v2, v1
    p.and        p4, p2, p3
    v.cmp.ne     p2, v4, v3
    p.and        p3, p4, p2
    v.cmp.ne     p2, v7, v6
    p.and        p4, p3, p1
    a.vwrite     a5, s12, v8
    v.ld.w       v0, [s2, #0]
    v.extract    s2, v11, #12
    v.movi       v1, #0
    v.splat      v2, s2
    v.extract    s2, v12, #12
    v.movi       v3, #0
    v.splat      v4, s2
    s.addi       s2, s7, #4992
    v.extract    s12, v5, #13
    v.movi       v6, #0
    v.splat      v7, s12
    s.movz       s12, #13
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v8, [s31, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v2, v1
    p.and        p5, p2, p3
    v.cmp.ne     p2, v4, v3
    p.and        p3, p5, p2
    v.cmp.ne     p2, v7, v6
    p.and        p5, p3, p1
    a.vwrite     a5, s8, v8
    v.ld.w       v0, [s6, #0]
    v.extract    s6, v11, #13
    v.movi       v1, #0
    v.splat      v2, s6
    v.extract    s6, v12, #13
    v.movi       v3, #0
    v.splat      v4, s6
    s.addi       s6, s7, #5056
    v.extract    s8, v5, #14
    v.movi       v6, #0
    v.splat      v7, s8
    s.movz       s8, #14
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v8, [s31, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v2, v1
    p.and        p4, p2, p3
    v.cmp.ne     p2, v4, v3
    p.and        p3, p4, p2
    v.cmp.ne     p2, v7, v6
    p.and        p4, p3, p1
    a.vwrite     a5, s9, v8
    v.ld.w       v0, [s3, #0]
    v.extract    s3, v11, #14
    v.movi       v1, #0
    v.splat      v2, s3
    v.extract    s3, v12, #14
    v.movi       v3, #0
    v.splat      v4, s3
    s.addi       s3, s7, #5120
    v.extract    s9, v5, #15
    v.movi       v6, #0
    v.splat      v7, s9
    s.movz       s9, #15
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v8, [s31, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v2, v1
    p.and        p5, p2, p3
    v.cmp.ne     p2, v4, v3
    p.and        p3, p5, p2
    v.cmp.ne     p2, v7, v6
    p.and        p5, p3, p1
    a.vwrite     a5, s10, v8
    v.ld.w       v0, [s2, #0]
    v.extract    s2, v11, #15
    v.movi       v1, #0
    v.splat      v2, s2
    v.extract    s2, v12, #15
    v.movi       v3, #0
    v.splat      v4, s2
    s.addi       s2, s7, #3136
    v.splat      v6, s4
    s.addi       s4, s7, #5184
    .li       s10, #925353388
    v.splat      v7, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v8, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v9, [s31, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v2, v1
    p.and        p4, p2, p3
    v.cmp.ne     p2, v4, v3
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    a.vwrite     a5, s12, v9
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s7, #3200
    s.addi       s10, s4, #64
    s.addi       s12, s7, #3264
    s.addi       s13, s4, #128
    s.addi       s14, s7, #3328
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v1, [s31, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s8, v1
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s4, #192
    s.addi       s8, s7, #3392
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s31, v0]              // index is in elements (ISA sec 9.1)
    s.addi       s16, s4, #256
    a.vwrite     a5, s9, v1
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s7, #3456
    s.addi       s9, s4, #320
    v.add        v1, v6, v0
    v.st.w       [s4, #0], v1
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s7, #3520
    v.add        v1, v6, v0
    v.st.w       [s10, #0], v1
    s.addi       s10, s4, #384
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s7, #3584
    v.add        v1, v6, v0
    v.st.w       [s13, #0], v1
    s.addi       s13, s4, #448
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s7, #3648
    v.add        v1, v6, v0
    v.st.w       [s3, #0], v1
    s.addi       s3, s4, #512
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s7, #3712
    v.add        v1, v6, v0
    v.st.w       [s16, #0], v1
    s.addi       s16, s4, #576
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s7, #3776
    v.add        v1, v6, v0
    v.st.w       [s9, #0], v1
    s.addi       s9, s4, #640
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s7, #3840
    v.add        v1, v6, v0
    v.st.w       [s10, #0], v1
    s.addi       s10, s4, #704
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s7, #3904
    v.movi       v1, #0
    v.add        v2, v6, v0
    v.st.w       [s13, #0], v2
    s.addi       s13, s4, #768
    v.movi       v0, #0
    v.ld.w       v2, [s14, #0]
    s.addi       s14, s7, #3968
    v.add        v3, v6, v2
    v.st.w       [s3, #0], v3
    s.addi       s3, s4, #832
    v.movi       v2, #0
    v.ld.w       v3, [s8, #0]
    s.addi       s8, s7, #4032
    v.add        v4, v6, v3
    v.st.w       [s16, #0], v4
    s.addi       s16, s4, #896
    s.addi       s17, s4, #960
    v.ld.w       v3, [s2, #0]
    s.addi       s2, s7, #4096
    v.add        v4, v6, v3
    v.st.w       [s9, #0], v4
    v.extract    s4, v5, #0
    v.movi       v3, #0
    v.splat      v4, s4
    v.extract    s4, v11, #0
    v.cmp.ne     p2, v4, v3
    v.ld.w       v3, [s6, #0]
    v.splat      v4, s4
    s.movz       s4, #0
    v.extract    s6, v5, #0
    v.splat      v9, s6
    v.extract    s6, v11, #0
    v.splat      v10, s6
    v.extract    s6, v12, #0
    v.cmp.ne     p3, v9, v1
    v.splat      v1, s6
    v.cmp.ne     p4, v10, v0
    p.and        p5, p3, p4
    v.cmp.ne     p3, v1, v2
    p.and        p4, p5, p3
    p.and        p3, p4, p1
    v.add        v0, v6, v3
    v.movi       v1, #0
    v.st.w       [s10, #0], v0
    v.extract    s6, v12, #0
    v.cmp.ne     p4, v4, v1
    p.and        p5, p2, p4
    v.ld.w       v0, [s12, #0]
    v.splat      v1, s6
    v.add        v2, v6, v0
    v.movi       v0, #0
    v.st.w       [s13, #0], v2
    v.cmp.ne     p2, v1, v0
    p.and        p4, p5, p2
    p.and        p2, p4, p1
    v.ld.w       v0, [s14, #0]
    v.add        v1, v6, v0
    v.st.w       [s3, #0], v1
    .li       s3, #1077936128
    v.splat      v0, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.ld.w       v1, [s8, #0]
    v.add        v2, v6, v1
    .li       s3, #3204448256
    v.splat      v1, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.st.w       [s16, #0], v2
    v.ld.w       v2, [s2, #0]
    v.add        v3, v6, v2
    v.st.w       [s17, #0], v3
    fence.acq_rel.device
    a.vread      v2, a0, s4
    v.extract    s2, v5, #0
    v.extract    s3, v11, #0
    v.splat      v3, s2
    v.movi       v4, #0
    v.splat      v6, s3
    v.movi       v9, #0
    v.extract    s2, v12, #0
    v.movi       v10, #0
    v.splat      v13, s2
    v.cmp.ne     p4, v3, v4
    v.extract    s2, v5, #0
    v.splat      v3, s2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v4, [s11, #0]
    v.cmp.ne     p2, v6, v9
    p.and        p5, p4, p2
    v.cmp.ne     p2, v13, v10
    p.and        p4, p5, p2
    p.and        p2, p4, p1
    vf.add       v6, v4, v7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s5, #0]
    v.movi       v9, #0
    v.rsqrt.approx v10, v6                       // ISA 8.8: <= 2**-22 relative
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v13, [s1, #0]
    vf.sub       v14, v2, v4
    v.extract    s2, v11, #0
    v.movi       v2, #0
    v.splat      v4, s2
    v.extract    s2, v12, #0
    v.cmp.ne     p2, v3, v9
    v.splat      v3, s2
    v.movi       v9, #0
    v.cmp.ne     p3, v4, v2
    p.and        p4, p2, p3
    v.cmp.ne     p2, v3, v9
    p.and        p3, p4, p2
    s.movz       s2, #0
    vf.mul       v2, v10, v10
    vf.mul       v3, v10, v1
    p.and        p2, p3, p1
    s.addi       s3, s7, #5184
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v4, [s15, #0]
    vf.fms       v9, v6, v2, v0
    a.vread      v2, a5, s2
    v.extract    s2, v5, #0
    v.movi       v6, #0
    vf.mul       v15, v3, v9                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s4, v11, #0
    v.splat      v3, s2
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v9, v15, v10
    v.splat      v10, s4
    v.cmp.ne     p2, v3, v6
    vf.mul       v3, v14, v9
    v.movi       v6, #0
    v.extract    s2, v12, #0
    v.ld.w       v9, [s3, #0]
    v.splat      v14, s2
    vf.mul       v15, v3, v13
    v.extract    s2, v5, #1
    v.extract    s3, v11, #1
    v.splat      v3, s2
    v.cmp.ne     p3, v10, v6
    vf.add       v6, v15, v4
    v.movi       v4, #0
    v.splat      v10, s3
    v.movi       v13, #0
    v.cmp.ne     p4, v3, v4
    vf.add       v3, v6, v2
    v.extract    s2, v12, #1
    v.movi       v2, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v10, v13
    p.and        p3, p4, p2
    vf.max.prop  v4, v3, v8
    v.splat      v3, s2
    v.movi       v6, #0
    v.cmp.ne     p2, v14, v2
    p.and        p4, p5, p2
    v.cmp.ne     p2, v3, v6
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s2, #1
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v9], v4
    a.vread      v2, a0, s2
    v.extract    s2, v5, #1
    v.extract    s3, v11, #1
    v.splat      v3, s2
    v.movi       v4, #0
    v.splat      v6, s3
    v.movi       v9, #0
    v.extract    s2, v12, #1
    v.movi       v10, #0
    v.splat      v13, s2
    v.cmp.ne     p2, v3, v4
    v.cmp.ne     p4, v6, v9
    p.and        p5, p2, p4
    v.cmp.ne     p2, v13, v10
    p.and        p4, p5, p2
    v.extract    s2, v5, #1
    p.and        p2, p4, p1
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s11, #0]
    v.extract    s3, v11, #1
    v.splat      v4, s2
    v.movi       v6, #0
    v.splat      v9, s3
    v.movi       v10, #0
    v.extract    s2, v12, #1
    v.movi       v13, #0
    v.splat      v14, s2
    v.cmp.ne     p3, v4, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s2, v5, #1
    p.and        p5, p3, p4
    v.cmp.ne     p3, v14, v13
    v.splat      v4, s2
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v3, v7
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v3, [s5, #0]
    v.extract    s2, v11, #1
    p.and        p2, p4, p1
    v.cmp.ne     p3, v4, v6
    v.rsqrt.approx v4, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s1, #0]
    vf.sub       v10, v2, v3
    v.splat      v2, s2
    v.movi       v3, #0
    v.extract    s2, v12, #1
    v.movi       v13, #0
    v.splat      v14, s2
    v.cmp.ne     p2, v2, v3
    p.and        p4, p3, p2
    v.cmp.ne     p2, v14, v13
    p.and        p3, p4, p2
    s.movz       s2, #1
    p.and        p2, p3, p1
    s.addi       s3, s7, #5248
    vf.mul       v2, v4, v4
    vf.mul       v3, v4, v1
    v.extract    s4, v5, #1
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v13, [s15, #0]
    vf.fms       v14, v9, v2, v0
    a.vread      v2, a5, s2
    v.splat      v9, s4
    vf.mul       v15, v3, v14                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s2, v11, #1
    v.movi       v3, #0
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v14, v15, v4
    v.splat      v4, s2
    v.cmp.ne     p2, v9, v3
    vf.mul       v3, v10, v14
    v.movi       v9, #0
    v.extract    s2, v12, #1
    v.ld.w       v10, [s3, #0]
    v.splat      v14, s2
    vf.mul       v15, v3, v6
    v.extract    s2, v5, #2
    v.extract    s3, v11, #2
    v.splat      v3, s2
    v.cmp.ne     p3, v4, v9
    vf.add       v4, v15, v13
    v.movi       v6, #0
    v.splat      v9, s3
    v.movi       v13, #0
    v.cmp.ne     p4, v3, v6
    vf.add       v3, v4, v2
    v.extract    s2, v12, #2
    v.movi       v2, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v9, v13
    p.and        p3, p4, p2
    vf.max.prop  v4, v3, v8
    v.splat      v3, s2
    v.movi       v6, #0
    v.cmp.ne     p2, v14, v2
    p.and        p4, p5, p2
    v.cmp.ne     p2, v3, v6
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s2, #2
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v10], v4
    a.vread      v2, a0, s2
    v.extract    s2, v5, #2
    v.extract    s3, v11, #2
    v.splat      v3, s2
    v.movi       v4, #0
    v.splat      v6, s3
    v.movi       v9, #0
    v.extract    s2, v12, #2
    v.movi       v10, #0
    v.splat      v13, s2
    v.cmp.ne     p2, v3, v4
    v.cmp.ne     p4, v6, v9
    p.and        p5, p2, p4
    v.cmp.ne     p2, v13, v10
    p.and        p4, p5, p2
    v.extract    s2, v5, #2
    p.and        p2, p4, p1
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s11, #0]
    v.extract    s3, v11, #2
    v.splat      v4, s2
    v.movi       v6, #0
    v.splat      v9, s3
    v.movi       v10, #0
    v.extract    s2, v12, #2
    v.movi       v13, #0
    v.splat      v14, s2
    v.cmp.ne     p3, v4, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s2, v5, #2
    p.and        p5, p3, p4
    v.cmp.ne     p3, v14, v13
    v.splat      v4, s2
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v3, v7
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v3, [s5, #0]
    v.extract    s2, v11, #2
    p.and        p2, p4, p1
    v.cmp.ne     p3, v4, v6
    v.rsqrt.approx v4, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s1, #0]
    vf.sub       v10, v2, v3
    v.splat      v2, s2
    v.movi       v3, #0
    v.extract    s2, v12, #2
    v.movi       v13, #0
    v.splat      v14, s2
    v.cmp.ne     p2, v2, v3
    p.and        p4, p3, p2
    v.cmp.ne     p2, v14, v13
    p.and        p3, p4, p2
    s.movz       s2, #2
    p.and        p2, p3, p1
    s.addi       s3, s7, #5312
    vf.mul       v2, v4, v4
    vf.mul       v3, v4, v1
    v.extract    s4, v5, #2
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v13, [s15, #0]
    vf.fms       v14, v9, v2, v0
    a.vread      v2, a5, s2
    v.splat      v9, s4
    vf.mul       v15, v3, v14                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s2, v11, #2
    v.movi       v3, #0
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v14, v15, v4
    v.splat      v4, s2
    v.cmp.ne     p2, v9, v3
    vf.mul       v3, v10, v14
    v.movi       v9, #0
    v.extract    s2, v12, #2
    v.ld.w       v10, [s3, #0]
    v.splat      v14, s2
    vf.mul       v15, v3, v6
    v.extract    s2, v5, #3
    v.extract    s3, v11, #3
    v.splat      v3, s2
    v.cmp.ne     p3, v4, v9
    vf.add       v4, v15, v13
    v.movi       v6, #0
    v.splat      v9, s3
    v.movi       v13, #0
    v.cmp.ne     p4, v3, v6
    vf.add       v3, v4, v2
    v.extract    s2, v12, #3
    v.movi       v2, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v9, v13
    p.and        p3, p4, p2
    vf.max.prop  v4, v3, v8
    v.splat      v3, s2
    v.movi       v6, #0
    v.cmp.ne     p2, v14, v2
    p.and        p4, p5, p2
    v.cmp.ne     p2, v3, v6
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s2, #3
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v10], v4
    a.vread      v2, a0, s2
    v.extract    s2, v5, #3
    v.extract    s3, v11, #3
    v.splat      v3, s2
    v.movi       v4, #0
    v.splat      v6, s3
    v.movi       v9, #0
    v.extract    s2, v12, #3
    v.movi       v10, #0
    v.splat      v13, s2
    v.cmp.ne     p2, v3, v4
    v.cmp.ne     p4, v6, v9
    p.and        p5, p2, p4
    v.cmp.ne     p2, v13, v10
    p.and        p4, p5, p2
    v.extract    s2, v5, #3
    p.and        p2, p4, p1
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s11, #0]
    v.extract    s3, v11, #3
    v.splat      v4, s2
    v.movi       v6, #0
    v.splat      v9, s3
    v.movi       v10, #0
    v.extract    s2, v12, #3
    v.movi       v13, #0
    v.splat      v14, s2
    v.cmp.ne     p3, v4, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s2, v5, #3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v14, v13
    v.splat      v4, s2
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v3, v7
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v3, [s5, #0]
    v.extract    s2, v11, #3
    p.and        p2, p4, p1
    v.cmp.ne     p3, v4, v6
    v.rsqrt.approx v4, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s1, #0]
    vf.sub       v10, v2, v3
    v.splat      v2, s2
    v.movi       v3, #0
    v.extract    s2, v12, #3
    v.movi       v13, #0
    v.splat      v14, s2
    v.cmp.ne     p2, v2, v3
    p.and        p4, p3, p2
    v.cmp.ne     p2, v14, v13
    p.and        p3, p4, p2
    s.movz       s2, #3
    p.and        p2, p3, p1
    s.addi       s3, s7, #5376
    vf.mul       v2, v4, v4
    vf.mul       v3, v4, v1
    v.extract    s4, v5, #3
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v13, [s15, #0]
    vf.fms       v14, v9, v2, v0
    a.vread      v2, a5, s2
    v.splat      v9, s4
    vf.mul       v15, v3, v14                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s2, v11, #3
    v.movi       v3, #0
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v14, v15, v4
    v.splat      v4, s2
    v.cmp.ne     p2, v9, v3
    vf.mul       v3, v10, v14
    v.movi       v9, #0
    v.extract    s2, v12, #3
    v.ld.w       v10, [s3, #0]
    v.splat      v14, s2
    vf.mul       v15, v3, v6
    v.extract    s2, v5, #4
    v.extract    s3, v11, #4
    v.splat      v3, s2
    v.cmp.ne     p3, v4, v9
    vf.add       v4, v15, v13
    v.movi       v6, #0
    v.splat      v9, s3
    v.movi       v13, #0
    v.cmp.ne     p4, v3, v6
    vf.add       v3, v4, v2
    v.extract    s2, v12, #4
    v.movi       v2, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v9, v13
    p.and        p3, p4, p2
    vf.max.prop  v4, v3, v8
    v.splat      v3, s2
    v.movi       v6, #0
    v.cmp.ne     p2, v14, v2
    p.and        p4, p5, p2
    v.cmp.ne     p2, v3, v6
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s2, #4
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v10], v4
    a.vread      v2, a0, s2
    v.extract    s2, v5, #4
    v.extract    s3, v11, #4
    v.splat      v3, s2
    v.movi       v4, #0
    v.splat      v6, s3
    v.movi       v9, #0
    v.extract    s2, v12, #4
    v.movi       v10, #0
    v.splat      v13, s2
    v.cmp.ne     p2, v3, v4
    v.cmp.ne     p4, v6, v9
    p.and        p5, p2, p4
    v.cmp.ne     p2, v13, v10
    p.and        p4, p5, p2
    v.extract    s2, v5, #4
    p.and        p2, p4, p1
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s11, #0]
    v.extract    s3, v11, #4
    v.splat      v4, s2
    v.movi       v6, #0
    v.splat      v9, s3
    v.movi       v10, #0
    v.extract    s2, v12, #4
    v.movi       v13, #0
    v.splat      v14, s2
    v.cmp.ne     p3, v4, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s2, v5, #4
    p.and        p5, p3, p4
    v.cmp.ne     p3, v14, v13
    v.splat      v4, s2
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v3, v7
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v3, [s5, #0]
    v.extract    s2, v11, #4
    p.and        p2, p4, p1
    v.cmp.ne     p3, v4, v6
    v.rsqrt.approx v4, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s1, #0]
    vf.sub       v10, v2, v3
    v.splat      v2, s2
    v.movi       v3, #0
    v.extract    s2, v12, #4
    v.movi       v13, #0
    v.splat      v14, s2
    v.cmp.ne     p2, v2, v3
    p.and        p4, p3, p2
    v.cmp.ne     p2, v14, v13
    p.and        p3, p4, p2
    s.movz       s2, #4
    p.and        p2, p3, p1
    s.addi       s3, s7, #5440
    vf.mul       v2, v4, v4
    vf.mul       v3, v4, v1
    v.extract    s4, v5, #4
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v13, [s15, #0]
    vf.fms       v14, v9, v2, v0
    a.vread      v2, a5, s2
    v.splat      v9, s4
    vf.mul       v15, v3, v14                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s2, v11, #4
    v.movi       v3, #0
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v14, v15, v4
    v.splat      v4, s2
    v.cmp.ne     p2, v9, v3
    vf.mul       v3, v10, v14
    v.movi       v9, #0
    v.extract    s2, v12, #4
    v.ld.w       v10, [s3, #0]
    v.splat      v14, s2
    vf.mul       v15, v3, v6
    v.extract    s2, v5, #5
    v.extract    s3, v11, #5
    v.splat      v3, s2
    v.cmp.ne     p3, v4, v9
    vf.add       v4, v15, v13
    v.movi       v6, #0
    v.splat      v9, s3
    v.movi       v13, #0
    v.cmp.ne     p4, v3, v6
    vf.add       v3, v4, v2
    v.extract    s2, v12, #5
    v.movi       v2, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v9, v13
    p.and        p3, p4, p2
    vf.max.prop  v4, v3, v8
    v.splat      v3, s2
    v.movi       v6, #0
    v.cmp.ne     p2, v14, v2
    p.and        p4, p5, p2
    v.cmp.ne     p2, v3, v6
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s2, #5
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v10], v4
    a.vread      v2, a0, s2
    v.extract    s2, v5, #5
    v.extract    s3, v11, #5
    v.splat      v3, s2
    v.movi       v4, #0
    v.splat      v6, s3
    v.movi       v9, #0
    v.extract    s2, v12, #5
    v.movi       v10, #0
    v.splat      v13, s2
    v.cmp.ne     p2, v3, v4
    v.cmp.ne     p4, v6, v9
    p.and        p5, p2, p4
    v.cmp.ne     p2, v13, v10
    p.and        p4, p5, p2
    v.extract    s2, v5, #5
    p.and        p2, p4, p1
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s11, #0]
    v.extract    s3, v11, #5
    v.splat      v4, s2
    v.movi       v6, #0
    v.splat      v9, s3
    v.movi       v10, #0
    v.extract    s2, v12, #5
    v.movi       v13, #0
    v.splat      v14, s2
    v.cmp.ne     p3, v4, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s2, v5, #5
    p.and        p5, p3, p4
    v.cmp.ne     p3, v14, v13
    v.splat      v4, s2
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v3, v7
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v3, [s5, #0]
    v.extract    s2, v11, #5
    p.and        p2, p4, p1
    v.cmp.ne     p3, v4, v6
    v.rsqrt.approx v4, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s1, #0]
    vf.sub       v10, v2, v3
    v.splat      v2, s2
    v.movi       v3, #0
    v.extract    s2, v12, #5
    v.movi       v13, #0
    v.splat      v14, s2
    v.cmp.ne     p2, v2, v3
    p.and        p4, p3, p2
    v.cmp.ne     p2, v14, v13
    p.and        p3, p4, p2
    s.movz       s2, #5
    p.and        p2, p3, p1
    s.addi       s3, s7, #5504
    vf.mul       v2, v4, v4
    vf.mul       v3, v4, v1
    v.extract    s4, v5, #5
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v13, [s15, #0]
    vf.fms       v14, v9, v2, v0
    a.vread      v2, a5, s2
    v.splat      v9, s4
    vf.mul       v15, v3, v14                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s2, v11, #5
    v.movi       v3, #0
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v14, v15, v4
    v.splat      v4, s2
    v.cmp.ne     p2, v9, v3
    vf.mul       v3, v10, v14
    v.movi       v9, #0
    v.extract    s2, v12, #5
    v.ld.w       v10, [s3, #0]
    v.splat      v14, s2
    vf.mul       v15, v3, v6
    v.extract    s2, v5, #6
    v.extract    s3, v11, #6
    v.splat      v3, s2
    v.cmp.ne     p3, v4, v9
    vf.add       v4, v15, v13
    v.movi       v6, #0
    v.splat      v9, s3
    v.movi       v13, #0
    v.cmp.ne     p4, v3, v6
    vf.add       v3, v4, v2
    v.extract    s2, v12, #6
    v.movi       v2, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v9, v13
    p.and        p3, p4, p2
    vf.max.prop  v4, v3, v8
    v.splat      v3, s2
    v.movi       v6, #0
    v.cmp.ne     p2, v14, v2
    p.and        p4, p5, p2
    v.cmp.ne     p2, v3, v6
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s2, #6
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v10], v4
    a.vread      v2, a0, s2
    v.extract    s2, v5, #6
    v.extract    s3, v11, #6
    v.splat      v3, s2
    v.movi       v4, #0
    v.splat      v6, s3
    v.movi       v9, #0
    v.extract    s2, v12, #6
    v.movi       v10, #0
    v.splat      v13, s2
    v.cmp.ne     p2, v3, v4
    v.cmp.ne     p4, v6, v9
    p.and        p5, p2, p4
    v.cmp.ne     p2, v13, v10
    p.and        p4, p5, p2
    v.extract    s2, v5, #6
    p.and        p2, p4, p1
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s11, #0]
    v.extract    s3, v11, #6
    v.splat      v4, s2
    v.movi       v6, #0
    v.splat      v9, s3
    v.movi       v10, #0
    v.extract    s2, v12, #6
    v.movi       v13, #0
    v.splat      v14, s2
    v.cmp.ne     p3, v4, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s2, v5, #6
    p.and        p5, p3, p4
    v.cmp.ne     p3, v14, v13
    v.splat      v4, s2
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v3, v7
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v3, [s5, #0]
    v.extract    s2, v11, #6
    p.and        p2, p4, p1
    v.cmp.ne     p3, v4, v6
    v.rsqrt.approx v4, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s1, #0]
    vf.sub       v10, v2, v3
    v.splat      v2, s2
    v.movi       v3, #0
    v.extract    s2, v12, #6
    v.movi       v13, #0
    v.splat      v14, s2
    v.cmp.ne     p2, v2, v3
    p.and        p4, p3, p2
    v.cmp.ne     p2, v14, v13
    p.and        p3, p4, p2
    s.movz       s2, #6
    p.and        p2, p3, p1
    s.addi       s3, s7, #5568
    vf.mul       v2, v4, v4
    vf.mul       v3, v4, v1
    v.extract    s4, v5, #6
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v13, [s15, #0]
    vf.fms       v14, v9, v2, v0
    a.vread      v2, a5, s2
    v.splat      v9, s4
    vf.mul       v15, v3, v14                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s2, v11, #6
    v.movi       v3, #0
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v14, v15, v4
    v.splat      v4, s2
    v.cmp.ne     p2, v9, v3
    vf.mul       v3, v10, v14
    v.movi       v9, #0
    v.extract    s2, v12, #6
    v.ld.w       v10, [s3, #0]
    v.splat      v14, s2
    vf.mul       v15, v3, v6
    v.extract    s2, v5, #7
    v.extract    s3, v11, #7
    v.splat      v3, s2
    v.cmp.ne     p3, v4, v9
    vf.add       v4, v15, v13
    v.movi       v6, #0
    v.splat      v9, s3
    v.movi       v13, #0
    v.cmp.ne     p4, v3, v6
    vf.add       v3, v4, v2
    v.extract    s2, v12, #7
    v.movi       v2, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v9, v13
    p.and        p3, p4, p2
    vf.max.prop  v4, v3, v8
    v.splat      v3, s2
    v.movi       v6, #0
    v.cmp.ne     p2, v14, v2
    p.and        p4, p5, p2
    v.cmp.ne     p2, v3, v6
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s2, #7
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v10], v4
    a.vread      v2, a0, s2
    v.extract    s2, v5, #7
    v.extract    s3, v11, #7
    v.splat      v3, s2
    v.movi       v4, #0
    v.splat      v6, s3
    v.movi       v9, #0
    v.extract    s2, v12, #7
    v.movi       v10, #0
    v.splat      v13, s2
    v.cmp.ne     p2, v3, v4
    v.cmp.ne     p4, v6, v9
    p.and        p5, p2, p4
    v.cmp.ne     p2, v13, v10
    p.and        p4, p5, p2
    v.extract    s2, v5, #7
    p.and        p2, p4, p1
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s11, #0]
    v.extract    s3, v11, #7
    v.splat      v4, s2
    v.movi       v6, #0
    v.splat      v9, s3
    v.movi       v10, #0
    v.extract    s2, v12, #7
    v.movi       v13, #0
    v.splat      v14, s2
    v.cmp.ne     p3, v4, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s2, v5, #7
    p.and        p5, p3, p4
    v.cmp.ne     p3, v14, v13
    v.splat      v4, s2
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v3, v7
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v3, [s5, #0]
    v.extract    s2, v11, #7
    p.and        p2, p4, p1
    v.cmp.ne     p3, v4, v6
    v.rsqrt.approx v4, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s1, #0]
    vf.sub       v10, v2, v3
    v.splat      v2, s2
    v.movi       v3, #0
    v.extract    s2, v12, #7
    v.movi       v13, #0
    v.splat      v14, s2
    v.cmp.ne     p2, v2, v3
    p.and        p4, p3, p2
    v.cmp.ne     p2, v14, v13
    p.and        p3, p4, p2
    s.movz       s2, #7
    p.and        p2, p3, p1
    s.addi       s3, s7, #5632
    vf.mul       v2, v4, v4
    vf.mul       v3, v4, v1
    v.extract    s4, v5, #7
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v13, [s15, #0]
    vf.fms       v14, v9, v2, v0
    a.vread      v2, a5, s2
    v.splat      v9, s4
    vf.mul       v15, v3, v14                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s2, v11, #7
    v.movi       v3, #0
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v14, v15, v4
    v.splat      v4, s2
    v.cmp.ne     p2, v9, v3
    vf.mul       v3, v10, v14
    v.movi       v9, #0
    v.extract    s2, v12, #7
    v.ld.w       v10, [s3, #0]
    v.splat      v14, s2
    vf.mul       v15, v3, v6
    v.extract    s2, v5, #8
    v.extract    s3, v11, #8
    v.splat      v3, s2
    v.cmp.ne     p3, v4, v9
    vf.add       v4, v15, v13
    v.movi       v6, #0
    v.splat      v9, s3
    v.movi       v13, #0
    v.cmp.ne     p4, v3, v6
    vf.add       v3, v4, v2
    v.extract    s2, v12, #8
    v.movi       v2, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v9, v13
    p.and        p3, p4, p2
    vf.max.prop  v4, v3, v8
    v.splat      v3, s2
    v.movi       v6, #0
    v.cmp.ne     p2, v14, v2
    p.and        p4, p5, p2
    v.cmp.ne     p2, v3, v6
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s2, #8
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v10], v4
    a.vread      v2, a0, s2
    v.extract    s2, v5, #8
    v.extract    s3, v11, #8
    v.splat      v3, s2
    v.movi       v4, #0
    v.splat      v6, s3
    v.movi       v9, #0
    v.extract    s2, v12, #8
    v.movi       v10, #0
    v.splat      v13, s2
    v.cmp.ne     p2, v3, v4
    v.cmp.ne     p4, v6, v9
    p.and        p5, p2, p4
    v.cmp.ne     p2, v13, v10
    p.and        p4, p5, p2
    v.extract    s2, v5, #8
    p.and        p2, p4, p1
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s11, #0]
    v.extract    s3, v11, #8
    v.splat      v4, s2
    v.movi       v6, #0
    v.splat      v9, s3
    v.movi       v10, #0
    v.extract    s2, v12, #8
    v.movi       v13, #0
    v.splat      v14, s2
    v.cmp.ne     p3, v4, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s2, v5, #8
    p.and        p5, p3, p4
    v.cmp.ne     p3, v14, v13
    v.splat      v4, s2
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v3, v7
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v3, [s5, #0]
    v.extract    s2, v11, #8
    p.and        p2, p4, p1
    v.cmp.ne     p3, v4, v6
    v.rsqrt.approx v4, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s1, #0]
    vf.sub       v10, v2, v3
    v.splat      v2, s2
    v.movi       v3, #0
    v.extract    s2, v12, #8
    v.movi       v13, #0
    v.splat      v14, s2
    v.cmp.ne     p2, v2, v3
    p.and        p4, p3, p2
    v.cmp.ne     p2, v14, v13
    p.and        p3, p4, p2
    s.movz       s2, #8
    p.and        p2, p3, p1
    s.addi       s3, s7, #5696
    vf.mul       v2, v4, v4
    vf.mul       v3, v4, v1
    v.extract    s4, v5, #8
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v13, [s15, #0]
    vf.fms       v14, v9, v2, v0
    a.vread      v2, a5, s2
    v.splat      v9, s4
    vf.mul       v15, v3, v14                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s2, v11, #8
    v.movi       v3, #0
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v14, v15, v4
    v.splat      v4, s2
    v.cmp.ne     p2, v9, v3
    vf.mul       v3, v10, v14
    v.movi       v9, #0
    v.extract    s2, v12, #8
    v.ld.w       v10, [s3, #0]
    v.splat      v14, s2
    vf.mul       v15, v3, v6
    v.extract    s2, v5, #9
    v.extract    s3, v11, #9
    v.splat      v3, s2
    v.cmp.ne     p3, v4, v9
    vf.add       v4, v15, v13
    v.movi       v6, #0
    v.splat      v9, s3
    v.movi       v13, #0
    v.cmp.ne     p4, v3, v6
    vf.add       v3, v4, v2
    v.extract    s2, v12, #9
    v.movi       v2, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v9, v13
    p.and        p3, p4, p2
    vf.max.prop  v4, v3, v8
    v.splat      v3, s2
    v.movi       v6, #0
    v.cmp.ne     p2, v14, v2
    p.and        p4, p5, p2
    v.cmp.ne     p2, v3, v6
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s2, #9
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v10], v4
    a.vread      v2, a0, s2
    v.extract    s2, v5, #9
    v.extract    s3, v11, #9
    v.splat      v3, s2
    v.movi       v4, #0
    v.splat      v6, s3
    v.movi       v9, #0
    v.extract    s2, v12, #9
    v.movi       v10, #0
    v.splat      v13, s2
    v.cmp.ne     p2, v3, v4
    v.cmp.ne     p4, v6, v9
    p.and        p5, p2, p4
    v.cmp.ne     p2, v13, v10
    p.and        p4, p5, p2
    v.extract    s2, v5, #9
    p.and        p2, p4, p1
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s11, #0]
    v.extract    s3, v11, #9
    v.splat      v4, s2
    v.movi       v6, #0
    v.splat      v9, s3
    v.movi       v10, #0
    v.extract    s2, v12, #9
    v.movi       v13, #0
    v.splat      v14, s2
    v.cmp.ne     p3, v4, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s2, v5, #9
    p.and        p5, p3, p4
    v.cmp.ne     p3, v14, v13
    v.splat      v4, s2
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v3, v7
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v3, [s5, #0]
    v.extract    s2, v11, #9
    p.and        p2, p4, p1
    v.cmp.ne     p3, v4, v6
    v.rsqrt.approx v4, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s1, #0]
    vf.sub       v10, v2, v3
    v.splat      v2, s2
    v.movi       v3, #0
    v.extract    s2, v12, #9
    v.movi       v13, #0
    v.splat      v14, s2
    v.cmp.ne     p2, v2, v3
    p.and        p4, p3, p2
    v.cmp.ne     p2, v14, v13
    p.and        p3, p4, p2
    s.movz       s2, #9
    p.and        p2, p3, p1
    s.addi       s3, s7, #5760
    vf.mul       v2, v4, v4
    vf.mul       v3, v4, v1
    v.extract    s4, v5, #9
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v13, [s15, #0]
    vf.fms       v14, v9, v2, v0
    a.vread      v2, a5, s2
    v.splat      v9, s4
    vf.mul       v15, v3, v14                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s2, v11, #9
    v.movi       v3, #0
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v14, v15, v4
    v.splat      v4, s2
    v.cmp.ne     p2, v9, v3
    vf.mul       v3, v10, v14
    v.movi       v9, #0
    v.extract    s2, v12, #9
    v.ld.w       v10, [s3, #0]
    v.splat      v14, s2
    vf.mul       v15, v3, v6
    v.extract    s2, v5, #10
    v.extract    s3, v11, #10
    v.splat      v3, s2
    v.cmp.ne     p3, v4, v9
    vf.add       v4, v15, v13
    v.movi       v6, #0
    v.splat      v9, s3
    v.movi       v13, #0
    v.cmp.ne     p4, v3, v6
    vf.add       v3, v4, v2
    v.extract    s2, v12, #10
    v.movi       v2, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v9, v13
    p.and        p3, p4, p2
    vf.max.prop  v4, v3, v8
    v.splat      v3, s2
    v.movi       v6, #0
    v.cmp.ne     p2, v14, v2
    p.and        p4, p5, p2
    v.cmp.ne     p2, v3, v6
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s2, #10
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v10], v4
    a.vread      v2, a0, s2
    v.extract    s2, v5, #10
    v.extract    s3, v11, #10
    v.splat      v3, s2
    v.movi       v4, #0
    v.splat      v6, s3
    v.movi       v9, #0
    v.extract    s2, v12, #10
    v.movi       v10, #0
    v.splat      v13, s2
    v.cmp.ne     p2, v3, v4
    v.cmp.ne     p4, v6, v9
    p.and        p5, p2, p4
    v.cmp.ne     p2, v13, v10
    p.and        p4, p5, p2
    v.extract    s2, v5, #10
    p.and        p2, p4, p1
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s11, #0]
    v.extract    s3, v11, #10
    v.splat      v4, s2
    v.movi       v6, #0
    v.splat      v9, s3
    v.movi       v10, #0
    v.extract    s2, v12, #10
    v.movi       v13, #0
    v.splat      v14, s2
    v.cmp.ne     p3, v4, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s2, v5, #10
    p.and        p5, p3, p4
    v.cmp.ne     p3, v14, v13
    v.splat      v4, s2
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v3, v7
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v3, [s5, #0]
    v.extract    s2, v11, #10
    p.and        p2, p4, p1
    v.cmp.ne     p3, v4, v6
    v.rsqrt.approx v4, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s1, #0]
    vf.sub       v10, v2, v3
    v.splat      v2, s2
    v.movi       v3, #0
    v.extract    s2, v12, #10
    v.movi       v13, #0
    v.splat      v14, s2
    v.cmp.ne     p2, v2, v3
    p.and        p4, p3, p2
    v.cmp.ne     p2, v14, v13
    p.and        p3, p4, p2
    s.movz       s2, #10
    p.and        p2, p3, p1
    s.addi       s3, s7, #5824
    vf.mul       v2, v4, v4
    vf.mul       v3, v4, v1
    v.extract    s4, v5, #10
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v13, [s15, #0]
    vf.fms       v14, v9, v2, v0
    a.vread      v2, a5, s2
    v.splat      v9, s4
    vf.mul       v15, v3, v14                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s2, v11, #10
    v.movi       v3, #0
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v14, v15, v4
    v.splat      v4, s2
    v.cmp.ne     p2, v9, v3
    vf.mul       v3, v10, v14
    v.movi       v9, #0
    v.extract    s2, v12, #10
    v.ld.w       v10, [s3, #0]
    v.splat      v14, s2
    vf.mul       v15, v3, v6
    v.extract    s2, v5, #11
    v.extract    s3, v11, #11
    v.splat      v3, s2
    v.cmp.ne     p3, v4, v9
    vf.add       v4, v15, v13
    v.movi       v6, #0
    v.splat      v9, s3
    v.movi       v13, #0
    v.cmp.ne     p4, v3, v6
    vf.add       v3, v4, v2
    v.extract    s2, v12, #11
    v.movi       v2, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v9, v13
    p.and        p3, p4, p2
    vf.max.prop  v4, v3, v8
    v.splat      v3, s2
    v.movi       v6, #0
    v.cmp.ne     p2, v14, v2
    p.and        p4, p5, p2
    v.cmp.ne     p2, v3, v6
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s2, #11
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v10], v4
    a.vread      v2, a0, s2
    v.extract    s2, v5, #11
    v.extract    s3, v11, #11
    v.splat      v3, s2
    v.movi       v4, #0
    v.splat      v6, s3
    v.movi       v9, #0
    v.extract    s2, v12, #11
    v.movi       v10, #0
    v.splat      v13, s2
    v.cmp.ne     p2, v3, v4
    v.cmp.ne     p4, v6, v9
    p.and        p5, p2, p4
    v.cmp.ne     p2, v13, v10
    p.and        p4, p5, p2
    v.extract    s2, v5, #11
    p.and        p2, p4, p1
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s11, #0]
    v.extract    s3, v11, #11
    v.splat      v4, s2
    v.movi       v6, #0
    v.splat      v9, s3
    v.movi       v10, #0
    v.extract    s2, v12, #11
    v.movi       v13, #0
    v.splat      v14, s2
    v.cmp.ne     p3, v4, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s2, v5, #11
    p.and        p5, p3, p4
    v.cmp.ne     p3, v14, v13
    v.splat      v4, s2
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v3, v7
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v3, [s5, #0]
    v.extract    s2, v11, #11
    p.and        p2, p4, p1
    v.cmp.ne     p3, v4, v6
    v.rsqrt.approx v4, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s1, #0]
    vf.sub       v10, v2, v3
    v.splat      v2, s2
    v.movi       v3, #0
    v.extract    s2, v12, #11
    v.movi       v13, #0
    v.splat      v14, s2
    v.cmp.ne     p2, v2, v3
    p.and        p4, p3, p2
    v.cmp.ne     p2, v14, v13
    p.and        p3, p4, p2
    s.movz       s2, #11
    p.and        p2, p3, p1
    s.addi       s3, s7, #5888
    vf.mul       v2, v4, v4
    vf.mul       v3, v4, v1
    v.extract    s4, v5, #11
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v13, [s15, #0]
    vf.fms       v14, v9, v2, v0
    a.vread      v2, a5, s2
    v.splat      v9, s4
    vf.mul       v15, v3, v14                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s2, v11, #11
    v.movi       v3, #0
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v14, v15, v4
    v.splat      v4, s2
    v.cmp.ne     p2, v9, v3
    vf.mul       v3, v10, v14
    v.movi       v9, #0
    v.extract    s2, v12, #11
    v.ld.w       v10, [s3, #0]
    v.splat      v14, s2
    vf.mul       v15, v3, v6
    v.extract    s2, v5, #12
    v.extract    s3, v11, #12
    v.splat      v3, s2
    v.cmp.ne     p3, v4, v9
    vf.add       v4, v15, v13
    v.movi       v6, #0
    v.splat      v9, s3
    v.movi       v13, #0
    v.cmp.ne     p4, v3, v6
    vf.add       v3, v4, v2
    v.extract    s2, v12, #12
    v.movi       v2, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v9, v13
    p.and        p3, p4, p2
    vf.max.prop  v4, v3, v8
    v.splat      v3, s2
    v.movi       v6, #0
    v.cmp.ne     p2, v14, v2
    p.and        p4, p5, p2
    v.cmp.ne     p2, v3, v6
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s2, #12
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v10], v4
    a.vread      v2, a0, s2
    v.extract    s2, v5, #12
    v.extract    s3, v11, #12
    v.splat      v3, s2
    v.movi       v4, #0
    v.splat      v6, s3
    v.movi       v9, #0
    v.extract    s2, v12, #12
    v.movi       v10, #0
    v.splat      v13, s2
    v.cmp.ne     p2, v3, v4
    v.cmp.ne     p4, v6, v9
    p.and        p5, p2, p4
    v.cmp.ne     p2, v13, v10
    p.and        p4, p5, p2
    v.extract    s2, v5, #12
    p.and        p2, p4, p1
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s11, #0]
    v.extract    s3, v11, #12
    v.splat      v4, s2
    v.movi       v6, #0
    v.splat      v9, s3
    v.movi       v10, #0
    v.extract    s2, v12, #12
    v.movi       v13, #0
    v.splat      v14, s2
    v.cmp.ne     p3, v4, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s2, v5, #12
    p.and        p5, p3, p4
    v.cmp.ne     p3, v14, v13
    v.splat      v4, s2
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v3, v7
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v3, [s5, #0]
    v.extract    s2, v11, #12
    p.and        p2, p4, p1
    v.cmp.ne     p3, v4, v6
    v.rsqrt.approx v4, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s1, #0]
    vf.sub       v10, v2, v3
    v.splat      v2, s2
    v.movi       v3, #0
    v.extract    s2, v12, #12
    v.movi       v13, #0
    v.splat      v14, s2
    v.cmp.ne     p2, v2, v3
    p.and        p4, p3, p2
    v.cmp.ne     p2, v14, v13
    p.and        p3, p4, p2
    s.movz       s2, #12
    p.and        p2, p3, p1
    s.addi       s3, s7, #5952
    vf.mul       v2, v4, v4
    vf.mul       v3, v4, v1
    v.extract    s4, v5, #12
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v13, [s15, #0]
    vf.fms       v14, v9, v2, v0
    a.vread      v2, a5, s2
    v.splat      v9, s4
    vf.mul       v15, v3, v14                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s2, v11, #12
    v.movi       v3, #0
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v14, v15, v4
    v.splat      v4, s2
    v.cmp.ne     p2, v9, v3
    vf.mul       v3, v10, v14
    v.movi       v9, #0
    v.extract    s2, v12, #12
    v.ld.w       v10, [s3, #0]
    v.splat      v14, s2
    vf.mul       v15, v3, v6
    v.extract    s2, v5, #13
    v.extract    s3, v11, #13
    v.splat      v3, s2
    v.cmp.ne     p3, v4, v9
    vf.add       v4, v15, v13
    v.movi       v6, #0
    v.splat      v9, s3
    v.movi       v13, #0
    v.cmp.ne     p4, v3, v6
    vf.add       v3, v4, v2
    v.extract    s2, v12, #13
    v.movi       v2, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v9, v13
    p.and        p3, p4, p2
    vf.max.prop  v4, v3, v8
    v.splat      v3, s2
    v.movi       v6, #0
    v.cmp.ne     p2, v14, v2
    p.and        p4, p5, p2
    v.cmp.ne     p2, v3, v6
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s2, #13
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v10], v4
    a.vread      v2, a0, s2
    v.extract    s2, v5, #13
    v.extract    s3, v11, #13
    v.splat      v3, s2
    v.movi       v4, #0
    v.splat      v6, s3
    v.movi       v9, #0
    v.extract    s2, v12, #13
    v.movi       v10, #0
    v.splat      v13, s2
    v.cmp.ne     p2, v3, v4
    v.cmp.ne     p4, v6, v9
    p.and        p5, p2, p4
    v.cmp.ne     p2, v13, v10
    p.and        p4, p5, p2
    v.extract    s2, v5, #13
    p.and        p2, p4, p1
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s11, #0]
    v.extract    s3, v11, #13
    v.splat      v4, s2
    v.movi       v6, #0
    v.splat      v9, s3
    v.movi       v10, #0
    v.extract    s2, v12, #13
    v.movi       v13, #0
    v.splat      v14, s2
    v.cmp.ne     p3, v4, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s2, v5, #13
    p.and        p5, p3, p4
    v.cmp.ne     p3, v14, v13
    v.splat      v4, s2
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v3, v7
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v3, [s5, #0]
    v.extract    s2, v11, #13
    p.and        p2, p4, p1
    v.cmp.ne     p3, v4, v6
    v.rsqrt.approx v4, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s1, #0]
    vf.sub       v10, v2, v3
    v.splat      v2, s2
    v.movi       v3, #0
    v.extract    s2, v12, #13
    v.movi       v13, #0
    v.splat      v14, s2
    v.cmp.ne     p2, v2, v3
    p.and        p4, p3, p2
    v.cmp.ne     p2, v14, v13
    p.and        p3, p4, p2
    s.movz       s2, #13
    p.and        p2, p3, p1
    s.addi       s3, s7, #6016
    vf.mul       v2, v4, v4
    vf.mul       v3, v4, v1
    v.extract    s4, v5, #13
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v13, [s15, #0]
    vf.fms       v14, v9, v2, v0
    a.vread      v2, a5, s2
    v.splat      v9, s4
    vf.mul       v15, v3, v14                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s2, v11, #13
    v.movi       v3, #0
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v14, v15, v4
    v.splat      v4, s2
    v.cmp.ne     p2, v9, v3
    vf.mul       v3, v10, v14
    v.movi       v9, #0
    v.extract    s2, v12, #13
    v.ld.w       v10, [s3, #0]
    v.splat      v14, s2
    vf.mul       v15, v3, v6
    v.extract    s2, v5, #14
    v.extract    s3, v11, #14
    v.splat      v3, s2
    v.cmp.ne     p3, v4, v9
    vf.add       v4, v15, v13
    v.movi       v6, #0
    v.splat      v9, s3
    v.movi       v13, #0
    v.cmp.ne     p4, v3, v6
    vf.add       v3, v4, v2
    v.extract    s2, v12, #14
    v.movi       v2, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v9, v13
    p.and        p3, p4, p2
    vf.max.prop  v4, v3, v8
    v.splat      v3, s2
    v.movi       v6, #0
    v.cmp.ne     p2, v14, v2
    p.and        p4, p5, p2
    v.cmp.ne     p2, v3, v6
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s2, #14
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v10], v4
    a.vread      v2, a0, s2
    v.extract    s2, v5, #14
    v.extract    s3, v11, #14
    v.splat      v3, s2
    v.movi       v4, #0
    v.splat      v6, s3
    v.movi       v9, #0
    v.extract    s2, v12, #14
    v.movi       v10, #0
    v.splat      v13, s2
    v.cmp.ne     p2, v3, v4
    v.cmp.ne     p4, v6, v9
    p.and        p5, p2, p4
    v.cmp.ne     p2, v13, v10
    p.and        p4, p5, p2
    v.extract    s2, v5, #14
    p.and        p2, p4, p1
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s11, #0]
    v.extract    s3, v11, #14
    v.splat      v4, s2
    v.movi       v6, #0
    v.splat      v9, s3
    v.movi       v10, #0
    v.extract    s2, v12, #14
    v.movi       v13, #0
    v.splat      v14, s2
    v.cmp.ne     p3, v4, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s2, v5, #14
    p.and        p5, p3, p4
    v.cmp.ne     p3, v14, v13
    v.splat      v4, s2
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v3, v7
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v3, [s5, #0]
    v.extract    s2, v11, #14
    p.and        p2, p4, p1
    v.cmp.ne     p3, v4, v6
    v.rsqrt.approx v4, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s1, #0]
    vf.sub       v10, v2, v3
    v.splat      v2, s2
    v.movi       v3, #0
    v.extract    s2, v12, #14
    v.movi       v13, #0
    v.splat      v14, s2
    v.cmp.ne     p2, v2, v3
    p.and        p4, p3, p2
    v.cmp.ne     p2, v14, v13
    p.and        p3, p4, p2
    s.movz       s2, #14
    p.and        p2, p3, p1
    s.addi       s3, s7, #6080
    vf.mul       v2, v4, v4
    vf.mul       v3, v4, v1
    v.extract    s4, v5, #14
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v13, [s15, #0]
    vf.fms       v14, v9, v2, v0
    a.vread      v2, a5, s2
    v.splat      v9, s4
    vf.mul       v15, v3, v14                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s2, v11, #14
    v.movi       v3, #0
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v14, v15, v4
    v.splat      v4, s2
    v.cmp.ne     p2, v9, v3
    vf.mul       v3, v10, v14
    v.movi       v9, #0
    v.extract    s2, v12, #14
    v.ld.w       v10, [s3, #0]
    v.splat      v14, s2
    vf.mul       v15, v3, v6
    v.extract    s2, v5, #15
    v.extract    s3, v11, #15
    v.splat      v3, s2
    v.cmp.ne     p3, v4, v9
    vf.add       v4, v15, v13
    v.movi       v6, #0
    v.splat      v9, s3
    v.movi       v13, #0
    v.cmp.ne     p4, v3, v6
    vf.add       v3, v4, v2
    v.extract    s2, v12, #15
    v.movi       v2, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v9, v13
    p.and        p3, p4, p2
    vf.max.prop  v4, v3, v8
    v.splat      v3, s2
    v.movi       v6, #0
    v.cmp.ne     p2, v14, v2
    p.and        p4, p5, p2
    v.cmp.ne     p2, v3, v6
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s2, #15
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v10], v4
    a.vread      v2, a0, s2
    v.extract    s2, v5, #15
    v.extract    s3, v11, #15
    v.splat      v3, s2
    v.movi       v4, #0
    v.splat      v6, s3
    v.movi       v9, #0
    v.extract    s2, v12, #15
    v.movi       v10, #0
    v.splat      v13, s2
    v.cmp.ne     p2, v3, v4
    v.cmp.ne     p4, v6, v9
    p.and        p5, p2, p4
    v.cmp.ne     p2, v13, v10
    p.and        p4, p5, p2
    v.extract    s2, v5, #15
    p.and        p2, p4, p1
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s11, #0]
    v.extract    s3, v11, #15
    v.splat      v4, s2
    v.movi       v6, #0
    v.splat      v9, s3
    v.movi       v10, #0
    v.extract    s2, v12, #15
    v.movi       v13, #0
    v.splat      v14, s2
    v.cmp.ne     p3, v4, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s2, v5, #15
    p.and        p5, p3, p4
    v.cmp.ne     p3, v14, v13
    v.splat      v4, s2
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v3, v7
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v3, [s5, #0]
    v.extract    s2, v11, #15
    p.and        p2, p4, p1
    v.cmp.ne     p3, v4, v6
    v.rsqrt.approx v4, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s1, #0]
    vf.sub       v7, v2, v3
    v.splat      v2, s2
    v.movi       v3, #0
    v.extract    s1, v12, #15
    v.movi       v10, #0
    v.splat      v13, s1
    v.cmp.ne     p2, v2, v3
    p.and        p4, p3, p2
    v.cmp.ne     p2, v13, v10
    p.and        p3, p4, p2
    s.movz       s1, #15
    p.and        p2, p3, p1
    s.addi       s2, s7, #6144
    vf.mul       v2, v4, v4
    vf.mul       v3, v4, v1
    v.extract    s3, v5, #15
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s15, #0]
    vf.fms       v5, v9, v2, v0
    a.vread      v0, a5, s1
    v.splat      v2, s3
    v.movi       v9, #0
    vf.mul       v10, v3, v5                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s1, v11, #15
    v.cmp.ne     p2, v2, v9
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v2, v10, v4
    v.splat      v3, s1
    v.movi       v4, #0
    vf.mul       v5, v7, v2
    v.extract    s1, v12, #15
    v.movi       v2, #0
    v.ld.w       v7, [s2, #0]
    v.splat      v9, s1
    vf.mul       v10, v5, v6
    v.cmp.ne     p3, v3, v4
    p.and        p4, p2, p3
    v.cmp.ne     p2, v9, v2
    p.and        p3, p4, p2
    vf.add       v2, v10, v1
    p.and        p2, p3, p1
    vf.add       v1, v2, v0
    vf.max.prop  v0, v1, v8
    @p2 v.st.scatter.w [s32, v7], v0
__rctx_next:
    exit
