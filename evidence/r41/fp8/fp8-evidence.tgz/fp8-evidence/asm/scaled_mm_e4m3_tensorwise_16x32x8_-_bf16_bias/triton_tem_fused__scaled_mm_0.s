    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s3, s4, s1
    s.movz       s1, #2
    s.movz       s5, #0
    s.sub        s6, s2, s3
    s.movz       s2, #0
    s.cmp.lt     s3, s1, s5
    s.xor        s5, s4, s6
    s.sub        s7, s2, s3
    s.sub        s2, s5, s6
    s.xor        s3, s6, s7
    s.lshri      s5, s2, #1
    s.movz       s6, #1
    s.xor        s8, s5, s3
    s.movz       s9, #0
    s.sub        s10, s8, s3
    s.movz       s3, #0
    s.sub        s8, s6, s10
    s.movz       s11, #0
    s.min.s      s12, s8, s6
    s.movz       s8, #0
    s.cmp.lt     s13, s12, s9
    s.cmp.lt     s9, s4, s3
    s.sub        s3, s11, s13
    s.sub        s11, s8, s9
    s.xor        s8, s12, s3
    s.muli       s9, s5, #2
    s.movz       s5, #0
    s.movz       s13, #1
    s.xor        s14, s4, s11
    s.sub        s15, s8, s3
    s.rdspecial  s3, arg_base
    s.xor        s8, s1, s7
    s.movz       s16, #0
    s.sub        s17, s14, s11
    s.addi       s14, s5, #0
    s.cmp.eq     s5, s15, s13
    s.ld.d       s13, [s3, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.sub        s18, s8, s7
    s.sub        s7, s2, s9
    s.addi       s2, s16, #0
    s.ld.d       s7, [s3, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s8, [s3, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s9, [s3, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s16, [s3, #32]                  // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s18, [s3, #40]                  // out_ptr0: device_ptr64 at arg_base+40
    s.mov        s14, s17
    br.nz        s5, sdiv_done_1
    s.movz       s3, #0
    s.movz       s5, #31
    s.mov        s14, s3
    s.addi       s3, s5, #0
sdiv_2:
    s.lshr       s5, s17, s3
    s.shli       s19, s2, #1
    s.andi       s20, s5, #1
    s.movz       s5, #0
    s.or         s21, s19, s20
    s.movz       s19, #1
    s.cmp.geu    s20, s21, s15
    s.shl        s22, s19, s3
    s.sub        s19, s5, s20
    s.subi       s5, s3, #1
    s.and        s20, s15, s19
    s.and        s23, s22, s19
    s.sub        s19, s21, s20
    s.or         s20, s14, s23
    s.mov        s2, s19
    s.mov        s14, s20
    s.mov        s3, s5
    s.movz       s5, #0
    s.cmp.ge     s19, s3, s5
    br.nz        s19, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s5, #0
    s.cmp.lt     s14, s4, s3
    s.movz       s3, #0
    s.sub        s15, s5, s14
    s.movz       s5, #0
    s.xor        s14, s4, s15
    s.movz       s4, #0
    s.sub        s17, s14, s15
    s.cmp.lt     s14, s12, s3
    s.lshri      s3, s17, #1
    s.movz       s19, #0
    s.muli       s20, s3, #2
    s.movz       s3, #0
    s.sub        s21, s4, s14
    s.movz       s4, #0
    s.cmp.lt     s14, s1, s19
    s.sub        s19, s17, s20
    s.xor        s17, s12, s21
    s.xor        s12, s19, s15
    s.xor        s19, s2, s11
    s.sub        s2, s12, s15
    s.sub        s12, s4, s14
    s.cmp.lt     s4, s2, s5
    s.sub        s5, s17, s21
    s.sub        s14, s3, s4
    s.movz       s3, #0
    s.xor        s4, s2, s14
    s.movz       s2, #1
    s.sub        s15, s19, s11
    s.xor        s11, s1, s12
    s.sub        s17, s4, s14
    s.movz       s4, #0
    s.addi       s19, s3, #0
    s.cmp.eq     s3, s5, s2
    s.add        s2, s10, s15
    s.sub        s10, s11, s12
    s.addi       s10, s4, #0
    s.mov        s19, s17
    br.nz        s3, sdiv_done_3
    s.movz       s3, #0
    s.movz       s4, #31
    s.mov        s19, s3
    s.addi       s3, s4, #0
sdiv_4:
    s.lshr       s4, s17, s3
    s.shli       s11, s10, #1
    s.andi       s12, s4, #1
    s.movz       s4, #0
    s.or         s15, s11, s12
    s.movz       s11, #1
    s.cmp.geu    s12, s15, s5
    s.shl        s20, s11, s3
    s.sub        s11, s4, s12
    s.subi       s4, s3, #1
    s.and        s12, s5, s11
    s.and        s22, s20, s11
    s.sub        s11, s15, s12
    s.or         s12, s19, s22
    s.mov        s10, s11
    s.mov        s19, s12
    s.mov        s3, s4
    s.movz       s4, #0
    s.cmp.ge     s11, s3, s4
    br.nz        s11, sdiv_4
sdiv_done_3:
    s.xor        s3, s14, s21
    s.xor        s4, s19, s3
    s.sub        s5, s4, s3
    v.splat      v0, s2
    s.movz       s3, #0
    v.splat      v1, s3
    v.cmp.ge     p1, v0, v1
    v.splat      v0, s5
    v.splat      v1, s3
    v.cmp.ge     p1, v0, v1
    s.movz       s4, #16
    s.mul        s10, s2, s4
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s10
    v.add        v2, v1, v0
    s.mul        s2, s5, s4
    v.splat      v1, s2
    v.add        v2, v1, v0
    s.andi       s5, s10, #15
    v.splat      v0, s5
    v.iota       v1                              // arange(0, VLEN)
    v.add        v2, v0, v1
    s.andi       s11, s2, #31
    v.splat      v0, s11
    v.iota       v1                              // arange(0, VLEN)
    v.add        v2, v0, v1
    s.muli       s12, s5, #8                     // a runtime tile origin, x8
    s.add        s5, s13, s12                    // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.rdspecial  s12, arg_base
    s.ld.d       s13, [s12, #48]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s12, role_id
    s.movz       s14, #512
    s.mul        s15, s12, s14
    s.add        s12, s13, s15                   // this context's own scratch
    s.addi       s13, s12, #0                    // 256 bytes of repack scratch
    // repack 16x16 f8E4M3FN through memory: there is no v.pack (ISA sec 8.4)
    v.iota       v0                              // arange(0, VLEN)
    s.movz       s14, #8
    v.splat      v1, s14
    v.cmp.lt     p1, v0, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s5, #0]
    v.st.b       [s13, #0], v1
    s.addi       s15, s5, #8                     // row 1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s15, #0]
    s.addi       s15, s13, #16                   // row 1
    v.st.b       [s15, #0], v1
    s.addi       s15, s5, #16                    // row 2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s15, #0]
    s.addi       s15, s13, #32                   // row 2
    v.st.b       [s15, #0], v1
    s.addi       s15, s5, #24                    // row 3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s15, #0]
    s.addi       s15, s13, #48                   // row 3
    v.st.b       [s15, #0], v1
    s.addi       s15, s5, #32                    // row 4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s15, #0]
    s.addi       s15, s13, #64                   // row 4
    v.st.b       [s15, #0], v1
    s.addi       s15, s5, #40                    // row 5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s15, #0]
    s.addi       s15, s13, #80                   // row 5
    v.st.b       [s15, #0], v1
    s.addi       s15, s5, #48                    // row 6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s15, #0]
    s.addi       s15, s13, #96                   // row 6
    v.st.b       [s15, #0], v1
    s.addi       s15, s5, #56                    // row 7
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s15, #0]
    s.addi       s15, s13, #112                  // row 7
    v.st.b       [s15, #0], v1
    s.addi       s15, s5, #64                    // row 8
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s15, #0]
    s.addi       s15, s13, #128                  // row 8
    v.st.b       [s15, #0], v1
    s.addi       s15, s5, #72                    // row 9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s15, #0]
    s.addi       s15, s13, #144                  // row 9
    v.st.b       [s15, #0], v1
    s.addi       s15, s5, #80                    // row 10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s15, #0]
    s.addi       s15, s13, #160                  // row 10
    v.st.b       [s15, #0], v1
    s.addi       s15, s5, #88                    // row 11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s15, #0]
    s.addi       s15, s13, #176                  // row 11
    v.st.b       [s15, #0], v1
    s.addi       s15, s5, #96                    // row 12
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s15, #0]
    s.addi       s15, s13, #192                  // row 12
    v.st.b       [s15, #0], v1
    s.addi       s15, s5, #104                   // row 13
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s15, #0]
    s.addi       s15, s13, #208                  // row 13
    v.st.b       [s15, #0], v1
    s.addi       s15, s5, #112                   // row 14
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s15, #0]
    s.addi       s15, s13, #224                  // row 14
    v.st.b       [s15, #0], v1
    s.addi       s15, s5, #120                   // row 15
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s15, #0]
    s.addi       s5, s13, #240                   // row 15
    v.st.b       [s5, #0], v1
    w.def        w0, #60, #4                     // v60..v63
    fence.acq_rel.device
    v.ld.w       v1, [s13, #0]
    v.mov        v60, v1                         // hand off through the shared window (sec 7.3)
    s.addi       s5, s13, #64
    v.ld.w       v1, [s5, #0]
    v.mov        v61, v1                         // hand off through the shared window (sec 7.3)
    s.addi       s5, s13, #128
    v.ld.w       v1, [s5, #0]
    v.mov        v62, v1                         // hand off through the shared window (sec 7.3)
    s.addi       s5, s13, #192
    v.ld.w       v1, [s5, #0]
    v.mov        v63, v1                         // hand off through the shared window (sec 7.3)
    s.addi       s5, s12, #256                   // 256 bytes of repack scratch
    // repack 16x16 f8E4M3FN through memory: there is no v.pack (ISA sec 8.4)
    s.movz       s12, #0
    s.muli       s13, s11, #8                    // a runtime tile origin, x8
    s.add        s11, s12, s13                   // the tile origin
    v.iota       v1                              // arange(0, VLEN)
    s.movz       s12, #8
    v.splat      v2, s12
    v.mul        v3, v1, v2
    v.splat      v1, s11
    v.add        v2, v3, v1
    v.splat      v1, s3
    v.splat      v4, s14
    v.cmp.lt     p1, v1, v4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v1, [s7, v2]               // index is in elements (ISA sec 9.1)
    v.st.b       [s5, #0], v1
    s.addi       s3, s11, #1
    v.splat      v1, s3
    v.add        v2, v3, v1
    v.splat      v1, s6
    v.cmp.lt     p1, v1, v4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v1, [s7, v2]               // index is in elements (ISA sec 9.1)
    s.addi       s3, s5, #16                     // row 1
    v.st.b       [s3, #0], v1
    s.addi       s3, s11, #2
    v.splat      v1, s3
    v.add        v2, v3, v1
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v1, [s7, v2]               // index is in elements (ISA sec 9.1)
    s.addi       s1, s5, #32                     // row 2
    v.st.b       [s1, #0], v1
    s.addi       s1, s11, #3
    v.splat      v1, s1
    v.add        v2, v3, v1
    s.movz       s1, #3
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v1, [s7, v2]               // index is in elements (ISA sec 9.1)
    s.addi       s1, s5, #48                     // row 3
    v.st.b       [s1, #0], v1
    s.addi       s1, s11, #4
    v.splat      v1, s1
    v.add        v2, v3, v1
    s.movz       s1, #4
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v1, [s7, v2]               // index is in elements (ISA sec 9.1)
    s.addi       s1, s5, #64                     // row 4
    v.st.b       [s1, #0], v1
    s.addi       s1, s11, #5
    v.splat      v1, s1
    v.add        v2, v3, v1
    s.movz       s1, #5
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v1, [s7, v2]               // index is in elements (ISA sec 9.1)
    s.addi       s1, s5, #80                     // row 5
    v.st.b       [s1, #0], v1
    s.addi       s1, s11, #6
    v.splat      v1, s1
    v.add        v2, v3, v1
    s.movz       s1, #6
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v1, [s7, v2]               // index is in elements (ISA sec 9.1)
    s.addi       s1, s5, #96                     // row 6
    v.st.b       [s1, #0], v1
    s.addi       s1, s11, #7
    v.splat      v1, s1
    v.add        v2, v3, v1
    s.movz       s1, #7
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v1, [s7, v2]               // index is in elements (ISA sec 9.1)
    s.addi       s1, s5, #112                    // row 7
    v.st.b       [s1, #0], v1
    s.addi       s1, s11, #8
    v.splat      v1, s1
    v.add        v2, v3, v1
    v.splat      v1, s14
    v.cmp.lt     p1, v1, v4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v1, [s7, v2]               // index is in elements (ISA sec 9.1)
    s.addi       s1, s5, #128                    // row 8
    v.st.b       [s1, #0], v1
    s.addi       s1, s11, #9
    v.splat      v1, s1
    v.add        v2, v3, v1
    s.movz       s1, #9
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v1, [s7, v2]               // index is in elements (ISA sec 9.1)
    s.addi       s1, s5, #144                    // row 9
    v.st.b       [s1, #0], v1
    s.addi       s1, s11, #10
    v.splat      v1, s1
    v.add        v2, v3, v1
    s.movz       s1, #10
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v1, [s7, v2]               // index is in elements (ISA sec 9.1)
    s.addi       s1, s5, #160                    // row 10
    v.st.b       [s1, #0], v1
    s.addi       s1, s11, #11
    v.splat      v1, s1
    v.add        v2, v3, v1
    s.movz       s1, #11
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v1, [s7, v2]               // index is in elements (ISA sec 9.1)
    s.addi       s1, s5, #176                    // row 11
    v.st.b       [s1, #0], v1
    s.addi       s1, s11, #12
    v.splat      v1, s1
    v.add        v2, v3, v1
    s.movz       s1, #12
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v1, [s7, v2]               // index is in elements (ISA sec 9.1)
    s.addi       s1, s5, #192                    // row 12
    v.st.b       [s1, #0], v1
    s.addi       s1, s11, #13
    v.splat      v1, s1
    v.add        v2, v3, v1
    s.movz       s1, #13
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v1, [s7, v2]               // index is in elements (ISA sec 9.1)
    s.addi       s1, s5, #208                    // row 13
    v.st.b       [s1, #0], v1
    s.addi       s1, s11, #14
    v.splat      v1, s1
    v.add        v2, v3, v1
    s.movz       s1, #14
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v1, [s7, v2]               // index is in elements (ISA sec 9.1)
    s.addi       s1, s5, #224                    // row 14
    v.st.b       [s1, #0], v1
    s.addi       s1, s11, #15
    v.splat      v1, s1
    v.add        v2, v3, v1
    s.movz       s1, #15
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v1, [s7, v2]               // index is in elements (ISA sec 9.1)
    s.addi       s1, s5, #240                    // row 15
    v.st.b       [s1, #0], v1
    w.def        w1, #56, #4                     // v56..v59
    fence.acq_rel.device
    v.ld.w       v1, [s5, #0]
    v.mov        v56, v1                         // hand off through the shared window (sec 7.3)
    s.addi       s1, s5, #64
    v.ld.w       v1, [s1, #0]
    v.mov        v57, v1                         // hand off through the shared window (sec 7.3)
    s.addi       s1, s5, #128
    v.ld.w       v1, [s1, #0]
    v.mov        v58, v1                         // hand off through the shared window (sec 7.3)
    s.addi       s1, s5, #192
    v.ld.w       v1, [s1, #0]
    v.mov        v59, v1                         // hand off through the shared window (sec 7.3)
    m.zero       a0
    mb.arm       s1, b0, #0, #1                  // 0 arrival(s), 1 operation(s)
    m.mma.async.k16.e4m3 a0, v60, v56, s1
    mb.wait      s1
    v.movi       v1, #0
    s.ld.w       s3, [s8, #0]                    // one element, not a vector
    v.splat      v2, s3
    s.ld.w       s3, [s9, #0]                    // one element, not a vector
    v.splat      v3, s3
    s.muli       s3, s2, #2                      // a runtime tile origin, x2
    s.add        s5, s16, s3                     // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s3, s2, #2                      // a runtime tile origin, x2
    s.add        s6, s18, s3                     // the tile origin
    s.muli       s3, s10, #64                    // a runtime tile origin, x64
    s.add        s7, s6, s3                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s3, #0
    a.vread      v4, a0, s3
    vf.add       v5, v4, v1
    vf.mul       v4, v2, v3
    vf.mul       v6, v5, v4
    s.movz       s3, #0
    s.add        s6, s3, s10                     // the tile origin
    v.splat      v4, s6
    v.splat      v5, s4
    v.cmp.lt     p1, v4, v5
    s.movz       s3, #0
    s.add        s4, s3, s2                      // the tile origin
    v.splat      v4, s4
    v.add        v7, v0, v4
    s.movz       s2, #32
    v.splat      v0, s2
    v.cmp.lt     p2, v7, v0
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.bf16.f32 v4, v0
    vf.add       v0, v6, v4
    vf.cvt.f32.bf16 v4, v0
    v.splat      v0, s6
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s7, #0], v4
    s.movz       s2, #1
    a.vread      v0, a0, s2
    vf.add       v4, v0, v1
    vf.mul       v0, v2, v3
    vf.mul       v6, v4, v0
    s.addi       s2, s6, #1
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.bf16.f32 v4, v0
    vf.add       v0, v6, v4
    vf.cvt.f32.bf16 v4, v0
    s.addi       s2, s7, #64                     // row 1
    s.addi       s3, s6, #1
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s2, #0], v4
    s.movz       s2, #2
    a.vread      v0, a0, s2
    vf.add       v4, v0, v1
    vf.mul       v0, v2, v3
    vf.mul       v6, v4, v0
    s.addi       s2, s6, #2
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.bf16.f32 v4, v0
    vf.add       v0, v6, v4
    vf.cvt.f32.bf16 v4, v0
    s.addi       s2, s7, #128                    // row 2
    s.addi       s3, s6, #2
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s2, #0], v4
    s.movz       s2, #3
    a.vread      v0, a0, s2
    vf.add       v4, v0, v1
    vf.mul       v0, v2, v3
    vf.mul       v6, v4, v0
    s.addi       s2, s6, #3
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.bf16.f32 v4, v0
    vf.add       v0, v6, v4
    vf.cvt.f32.bf16 v4, v0
    s.addi       s2, s7, #192                    // row 3
    s.addi       s3, s6, #3
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s2, #0], v4
    s.movz       s2, #4
    a.vread      v0, a0, s2
    vf.add       v4, v0, v1
    vf.mul       v0, v2, v3
    vf.mul       v6, v4, v0
    s.addi       s2, s6, #4
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.bf16.f32 v4, v0
    vf.add       v0, v6, v4
    vf.cvt.f32.bf16 v4, v0
    s.addi       s2, s7, #256                    // row 4
    s.addi       s3, s6, #4
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s2, #0], v4
    s.movz       s2, #5
    a.vread      v0, a0, s2
    vf.add       v4, v0, v1
    vf.mul       v0, v2, v3
    vf.mul       v6, v4, v0
    s.addi       s2, s6, #5
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.bf16.f32 v4, v0
    vf.add       v0, v6, v4
    vf.cvt.f32.bf16 v4, v0
    s.addi       s2, s7, #320                    // row 5
    s.addi       s3, s6, #5
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s2, #0], v4
    s.movz       s2, #6
    a.vread      v0, a0, s2
    vf.add       v4, v0, v1
    vf.mul       v0, v2, v3
    vf.mul       v6, v4, v0
    s.addi       s2, s6, #6
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.bf16.f32 v4, v0
    vf.add       v0, v6, v4
    vf.cvt.f32.bf16 v4, v0
    s.addi       s2, s7, #384                    // row 6
    s.addi       s3, s6, #6
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s2, #0], v4
    s.movz       s2, #7
    a.vread      v0, a0, s2
    vf.add       v4, v0, v1
    vf.mul       v0, v2, v3
    vf.mul       v6, v4, v0
    s.addi       s2, s6, #7
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.bf16.f32 v4, v0
    vf.add       v0, v6, v4
    vf.cvt.f32.bf16 v4, v0
    s.addi       s2, s7, #448                    // row 7
    s.addi       s3, s6, #7
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s2, #0], v4
    s.movz       s2, #8
    a.vread      v0, a0, s2
    vf.add       v4, v0, v1
    vf.mul       v0, v2, v3
    vf.mul       v6, v4, v0
    s.addi       s2, s6, #8
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.bf16.f32 v4, v0
    vf.add       v0, v6, v4
    vf.cvt.f32.bf16 v4, v0
    s.addi       s2, s7, #512                    // row 8
    s.addi       s3, s6, #8
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s2, #0], v4
    s.movz       s2, #9
    a.vread      v0, a0, s2
    vf.add       v4, v0, v1
    vf.mul       v0, v2, v3
    vf.mul       v6, v4, v0
    s.addi       s2, s6, #9
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.bf16.f32 v4, v0
    vf.add       v0, v6, v4
    vf.cvt.f32.bf16 v4, v0
    s.addi       s2, s7, #576                    // row 9
    s.addi       s3, s6, #9
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s2, #0], v4
    s.movz       s2, #10
    a.vread      v0, a0, s2
    vf.add       v4, v0, v1
    vf.mul       v0, v2, v3
    vf.mul       v6, v4, v0
    s.addi       s2, s6, #10
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.bf16.f32 v4, v0
    vf.add       v0, v6, v4
    vf.cvt.f32.bf16 v4, v0
    s.addi       s2, s7, #640                    // row 10
    s.addi       s3, s6, #10
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s2, #0], v4
    s.movz       s2, #11
    a.vread      v0, a0, s2
    vf.add       v4, v0, v1
    vf.mul       v0, v2, v3
    vf.mul       v6, v4, v0
    s.addi       s2, s6, #11
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.bf16.f32 v4, v0
    vf.add       v0, v6, v4
    vf.cvt.f32.bf16 v4, v0
    s.addi       s2, s7, #704                    // row 11
    s.addi       s3, s6, #11
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s2, #0], v4
    s.movz       s2, #12
    a.vread      v0, a0, s2
    vf.add       v4, v0, v1
    vf.mul       v0, v2, v3
    vf.mul       v6, v4, v0
    s.addi       s2, s6, #12
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.bf16.f32 v4, v0
    vf.add       v0, v6, v4
    vf.cvt.f32.bf16 v4, v0
    s.addi       s2, s7, #768                    // row 12
    s.addi       s3, s6, #12
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s2, #0], v4
    s.movz       s2, #13
    a.vread      v0, a0, s2
    vf.add       v4, v0, v1
    vf.mul       v0, v2, v3
    vf.mul       v6, v4, v0
    s.addi       s2, s6, #13
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.bf16.f32 v4, v0
    vf.add       v0, v6, v4
    vf.cvt.f32.bf16 v4, v0
    s.addi       s2, s7, #832                    // row 13
    s.addi       s3, s6, #13
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s2, #0], v4
    s.movz       s2, #14
    a.vread      v0, a0, s2
    vf.add       v4, v0, v1
    vf.mul       v0, v2, v3
    vf.mul       v6, v4, v0
    s.addi       s2, s6, #14
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.bf16.f32 v4, v0
    vf.add       v0, v6, v4
    vf.cvt.f32.bf16 v4, v0
    s.addi       s2, s7, #896                    // row 14
    s.addi       s3, s6, #14
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s2, #0], v4
    s.movz       s2, #15
    a.vread      v0, a0, s2
    vf.add       v4, v0, v1
    vf.mul       v0, v2, v3
    vf.mul       v1, v4, v0
    s.addi       s2, s6, #15
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.bf16.f32 v2, v0
    vf.add       v0, v1, v2
    vf.cvt.f32.bf16 v1, v0
    s.addi       s2, s7, #960                    // row 15
    s.addi       s3, s6, #15
    v.splat      v0, s3
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s2, #0], v1
__rctx_next:
    exit
