    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s3, s4, s1
    s.movz       s1, #16
    s.movz       s5, #0
    s.sub        s6, s2, s3
    s.movz       s2, #0
    s.cmp.lt     s3, s1, s5
    s.xor        s5, s4, s6
    s.sub        s7, s2, s3
    s.sub        s2, s5, s6
    s.xor        s3, s6, s7
    s.lshri      s5, s2, #4
    s.movz       s6, #1
    s.xor        s8, s5, s3
    s.movz       s9, #0
    s.sub        s10, s8, s3
    s.movz       s3, #0
    s.sub        s8, s6, s10
    s.movz       s11, #0
    s.min.s      s12, s8, s6
    s.movz       s6, #0
    s.cmp.lt     s8, s12, s9
    s.cmp.lt     s9, s4, s3
    s.sub        s3, s11, s8
    s.sub        s8, s6, s9
    s.xor        s6, s12, s3
    s.muli       s9, s5, #16
    s.movz       s5, #0
    s.movz       s11, #1
    s.xor        s13, s4, s8
    s.sub        s14, s6, s3
    s.rdspecial  s3, arg_base
    s.xor        s6, s1, s7
    s.movz       s15, #0
    s.sub        s16, s13, s8
    s.addi       s13, s5, #0
    s.cmp.eq     s5, s14, s11
    s.ld.d       s11, [s3, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.sub        s17, s6, s7
    s.sub        s6, s2, s9
    s.addi       s2, s15, #0
    s.ld.d       s6, [s3, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s7, [s3, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.mov        s13, s16
    br.nz        s5, sdiv_done_1
    s.movz       s3, #0
    s.movz       s5, #31
    s.mov        s13, s3
    s.addi       s3, s5, #0
sdiv_2:
    s.lshr       s5, s16, s3
    s.shli       s9, s2, #1
    s.andi       s15, s5, #1
    s.movz       s5, #0
    s.or         s17, s9, s15
    s.movz       s9, #1
    s.cmp.geu    s15, s17, s14
    s.shl        s18, s9, s3
    s.sub        s9, s5, s15
    s.subi       s5, s3, #1
    s.and        s15, s14, s9
    s.and        s19, s18, s9
    s.sub        s9, s17, s15
    s.or         s15, s13, s19
    s.mov        s2, s9
    s.mov        s13, s15
    s.mov        s3, s5
    s.movz       s5, #0
    s.cmp.ge     s9, s3, s5
    br.nz        s9, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s5, #0
    s.cmp.lt     s9, s4, s3
    s.movz       s3, #0
    s.sub        s13, s5, s9
    s.movz       s5, #0
    s.xor        s9, s4, s13
    s.movz       s4, #0
    s.sub        s14, s9, s13
    s.cmp.lt     s9, s12, s3
    s.lshri      s3, s14, #4
    s.movz       s15, #0
    s.muli       s16, s3, #16
    s.movz       s3, #0
    s.sub        s17, s4, s9
    s.movz       s4, #0
    s.cmp.lt     s9, s1, s15
    s.sub        s15, s14, s16
    s.xor        s14, s12, s17
    s.xor        s12, s15, s13
    s.xor        s15, s2, s8
    s.sub        s2, s12, s13
    s.sub        s12, s4, s9
    s.cmp.lt     s4, s2, s5
    s.sub        s5, s14, s17
    s.sub        s9, s3, s4
    s.movz       s3, #0
    s.xor        s4, s2, s9
    s.movz       s2, #1
    s.sub        s13, s15, s8
    s.xor        s8, s1, s12
    s.sub        s14, s4, s9
    s.movz       s4, #0
    s.addi       s15, s3, #0
    s.cmp.eq     s3, s5, s2
    s.add        s2, s10, s13
    s.sub        s10, s8, s12
    s.addi       s8, s4, #0
    s.mov        s15, s14
    br.nz        s3, sdiv_done_3
    s.movz       s3, #0
    s.movz       s4, #31
    s.mov        s15, s3
    s.addi       s3, s4, #0
sdiv_4:
    s.lshr       s4, s14, s3
    s.shli       s10, s8, #1
    s.andi       s12, s4, #1
    s.movz       s4, #0
    s.or         s13, s10, s12
    s.movz       s10, #1
    s.cmp.geu    s12, s13, s5
    s.shl        s16, s10, s3
    s.sub        s10, s4, s12
    s.subi       s4, s3, #1
    s.and        s12, s5, s10
    s.and        s18, s16, s10
    s.sub        s10, s13, s12
    s.or         s12, s15, s18
    s.mov        s8, s10
    s.mov        s15, s12
    s.mov        s3, s4
    s.movz       s4, #0
    s.cmp.ge     s10, s3, s4
    br.nz        s10, sdiv_4
sdiv_done_3:
    s.xor        s3, s9, s17
    s.mul        s4, s2, s1
    s.xor        s5, s15, s3
    v.iota       v0                              // arange(0, VLEN)
    s.sub        s8, s5, s3
    v.movi       v1, #15
    v.splat      v2, s4
    s.mul        s3, s8, s1
    v.movi       v3, #0
    v.add        v4, v2, v0
    s.movz       s5, #0
    v.splat      v2, s2
    v.splat      v5, s5
    v.splat      v6, s8
    v.splat      v7, s5
    v.splat      v8, s3
    v.sub        v9, v3, v4
    v.cmp.lt     p1, v4, v3
    v.cmp.lt     p2, v1, v3
    v.cmp.ge     p3, v2, v5
    v.sub        v2, v3, v1
    v.cmp.ge     p3, v6, v7
    v.add        v5, v8, v0
    v.movi       v0, #1
    @p1 v.sel        v5, v9, v4
    @p2 v.sel        v4, v2, v1
    v.movi       v1, #0
    v.movi       v2, #0
    s.movz       s2, #31
idiv_5:
    v.splat      v6, s2
    v.shl        v7, v2, v0
    v.cmp.lt     p2, v2, v3
    v.lshr       v8, v5, v6
    v.shl        v9, v0, v6
    s.subi       s8, s2, #1
    v.and        v6, v8, v0
    s.movz       s9, #0
    v.or         v8, v7, v6
    v.cmp.geu    p3, v8, v4
    p.or         p4, p2, p3
    v.sub        v6, v8, v4
    @p4 v.sel        v7, v9, v3
    @p4 v.sel        v9, v6, v8
    v.or         v6, v1, v7
    v.mov        v2, v9
    v.mov        v1, v6
    s.mov        s2, s8
    s.cmp.ge     s8, s2, s9
    br.nz        s8, idiv_5
    v.sub        v0, v3, v2
    @p1 v.sel        v1, v0, v2
    s.andi       s2, s3, #255
    v.splat      v0, s2
    v.iota       v2                              // arange(0, VLEN)
    v.add        v3, v0, v2
    s.rdspecial  s8, pid.y
    s.rdspecial  s9, pid.z
    s.rdspecial  s10, npid.y
    s.mul        s12, s9, s10
    s.add        s9, s8, s12
    s.movz       s8, #15
    s.min.s      s10, s9, s8
    s.movz       s12, #960
    s.mul        s13, s10, s12
    s.rdspecial  s12, arg_base
    s.ld.d       s14, [s12, #24]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s12, role_id
    s.movz       s15, #7168
    s.mul        s16, s12, s15
    s.add        s12, s14, s16                   // this context's own scratch
    s.addi       s14, s12, #0
    v.splat      v0, s5
    v.extract    s15, v1, #0
    v.splat      v2, s15
    s.movz       s15, #64
    v.splat      v3, s15
    v.mul        v4, v2, v3
    v.iota       v2                              // arange(0, VLEN)
    v.add        v5, v4, v2
    s.movz       s16, #0
    s.add        s17, s16, s13                   // the tile origin
    v.splat      v4, s17
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s14, #0], v5
    s.addi       s13, s14, #64
    v.extract    s16, v1, #1
    v.splat      v5, s16
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s13, #0], v5
    s.addi       s13, s14, #128
    v.extract    s16, v1, #2
    v.splat      v5, s16
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s13, #0], v5
    s.addi       s13, s14, #192
    v.extract    s16, v1, #3
    v.splat      v5, s16
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s13, #0], v5
    s.addi       s13, s14, #256
    v.extract    s16, v1, #4
    v.splat      v5, s16
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s13, #0], v5
    s.addi       s13, s14, #320
    v.extract    s16, v1, #5
    v.splat      v5, s16
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s13, #0], v5
    s.addi       s13, s14, #384
    v.extract    s16, v1, #6
    v.splat      v5, s16
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s13, #0], v5
    s.addi       s13, s14, #448
    v.extract    s16, v1, #7
    v.splat      v5, s16
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s13, #0], v5
    s.addi       s13, s14, #512
    v.extract    s16, v1, #8
    v.splat      v5, s16
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s13, #0], v5
    s.addi       s13, s14, #576
    v.extract    s16, v1, #9
    v.splat      v5, s16
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s13, #0], v5
    s.addi       s13, s14, #640
    v.extract    s16, v1, #10
    v.splat      v5, s16
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s13, #0], v5
    s.addi       s13, s14, #704
    v.extract    s16, v1, #11
    v.splat      v5, s16
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s13, #0], v5
    s.addi       s13, s14, #768
    v.extract    s16, v1, #12
    v.splat      v5, s16
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s13, #0], v5
    s.addi       s13, s14, #832
    v.extract    s16, v1, #13
    v.splat      v5, s16
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s13, #0], v5
    s.addi       s13, s14, #896
    v.extract    s16, v1, #14
    v.splat      v5, s16
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s13, #0], v5
    s.addi       s13, s14, #960
    v.extract    s14, v1, #15
    v.splat      v1, s14
    v.mul        v5, v1, v3
    v.add        v1, v5, v2
    v.add        v3, v1, v4
    v.add        v1, v0, v3
    v.st.w       [s13, #0], v1
    fence.acq_rel.device
    s.movz       s13, #16384
    s.mul        s14, s10, s13
    s.addi       s10, s5, #0
    s.addi       s5, s12, #1024
    s.addi       s13, s12, #0
    v.ld.w       v0, [s13, #0]
    v.st.w       [s5, #0], v0
    s.addi       s13, s5, #64
    s.addi       s16, s12, #64
    v.ld.w       v0, [s16, #0]
    v.st.w       [s13, #0], v0
    s.addi       s13, s5, #128
    s.addi       s16, s12, #128
    v.ld.w       v0, [s16, #0]
    v.st.w       [s13, #0], v0
    s.addi       s13, s5, #192
    s.addi       s16, s12, #192
    v.ld.w       v0, [s16, #0]
    v.st.w       [s13, #0], v0
    s.addi       s13, s5, #256
    s.addi       s16, s12, #256
    v.ld.w       v0, [s16, #0]
    v.st.w       [s13, #0], v0
    s.addi       s13, s5, #320
    s.addi       s16, s12, #320
    v.ld.w       v0, [s16, #0]
    v.st.w       [s13, #0], v0
    s.addi       s13, s5, #384
    s.addi       s16, s12, #384
    v.ld.w       v0, [s16, #0]
    v.st.w       [s13, #0], v0
    s.addi       s13, s5, #448
    s.addi       s16, s12, #448
    v.ld.w       v0, [s16, #0]
    v.st.w       [s13, #0], v0
    s.addi       s13, s5, #512
    s.addi       s16, s12, #512
    v.ld.w       v0, [s16, #0]
    v.st.w       [s13, #0], v0
    s.addi       s13, s5, #576
    s.addi       s16, s12, #576
    v.ld.w       v0, [s16, #0]
    v.st.w       [s13, #0], v0
    s.addi       s13, s5, #640
    s.addi       s16, s12, #640
    v.ld.w       v0, [s16, #0]
    v.st.w       [s13, #0], v0
    s.addi       s13, s5, #704
    s.addi       s16, s12, #704
    v.ld.w       v0, [s16, #0]
    v.st.w       [s13, #0], v0
    s.addi       s13, s5, #768
    s.addi       s16, s12, #768
    v.ld.w       v0, [s16, #0]
    v.st.w       [s13, #0], v0
    s.addi       s13, s5, #832
    s.addi       s16, s12, #832
    v.ld.w       v0, [s16, #0]
    v.st.w       [s13, #0], v0
    s.addi       s13, s5, #896
    s.addi       s16, s12, #896
    v.ld.w       v0, [s16, #0]
    v.st.w       [s13, #0], v0
    s.addi       s13, s5, #960
    s.addi       s5, s12, #960
    v.ld.w       v0, [s5, #0]
    v.st.w       [s13, #0], v0
    fence.acq_rel.device
    s.addi       s5, s12, #2048
    s.movz       s13, #0
    s.add        s16, s13, s2                    // the tile origin
    s.add        s2, s16, s14                    // the tile origin
    v.splat      v0, s2
    v.add        v1, v2, v0
    v.st.w       [s5, #0], v1
    s.addi       s13, s5, #64
    s.addi       s14, s2, #256
    v.splat      v0, s14
    v.add        v1, v2, v0
    v.st.w       [s13, #0], v1
    s.addi       s13, s5, #128
    s.addi       s14, s2, #512
    v.splat      v0, s14
    v.add        v1, v2, v0
    v.st.w       [s13, #0], v1
    s.addi       s13, s5, #192
    s.addi       s14, s2, #768
    v.splat      v0, s14
    v.add        v1, v2, v0
    v.st.w       [s13, #0], v1
    s.addi       s13, s5, #256
    s.addi       s14, s2, #1024
    v.splat      v0, s14
    v.add        v1, v2, v0
    v.st.w       [s13, #0], v1
    s.addi       s13, s5, #320
    s.addi       s14, s2, #1280
    v.splat      v0, s14
    v.add        v1, v2, v0
    v.st.w       [s13, #0], v1
    s.addi       s13, s5, #384
    s.addi       s14, s2, #1536
    v.splat      v0, s14
    v.add        v1, v2, v0
    v.st.w       [s13, #0], v1
    s.addi       s13, s5, #448
    s.addi       s14, s2, #1792
    v.splat      v0, s14
    v.add        v1, v2, v0
    v.st.w       [s13, #0], v1
    s.addi       s13, s5, #512
    s.addi       s14, s2, #2048
    v.splat      v0, s14
    v.add        v1, v2, v0
    v.st.w       [s13, #0], v1
    s.addi       s13, s5, #576
    s.addi       s14, s2, #2304
    v.splat      v0, s14
    v.add        v1, v2, v0
    v.st.w       [s13, #0], v1
    s.addi       s13, s5, #640
    s.addi       s14, s2, #2560
    v.splat      v0, s14
    v.add        v1, v2, v0
    v.st.w       [s13, #0], v1
    s.addi       s13, s5, #704
    s.addi       s14, s2, #2816
    v.splat      v0, s14
    v.add        v1, v2, v0
    v.st.w       [s13, #0], v1
    s.addi       s13, s5, #768
    s.addi       s14, s2, #3072
    v.splat      v0, s14
    v.add        v1, v2, v0
    v.st.w       [s13, #0], v1
    s.addi       s13, s5, #832
    s.addi       s14, s2, #3328
    v.splat      v0, s14
    v.add        v1, v2, v0
    v.st.w       [s13, #0], v1
    s.addi       s13, s5, #896
    s.addi       s14, s2, #3584
    v.splat      v0, s14
    v.add        v1, v2, v0
    v.st.w       [s13, #0], v1
    s.addi       s13, s5, #960
    s.addi       s5, s2, #3840
    v.splat      v0, s5
    v.add        v1, v2, v0
    v.st.w       [s13, #0], v1
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_6:
    s.cmp.ge     s2, s10, s15
    br.nz        s2, endfor_7
    s.addi       s2, s12, #1024
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s5, #0
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s12, #1088
    s.movz       s13, #1
    s.addi       s14, s12, #1152
    s.movz       s16, #2
    s.addi       s17, s12, #1216
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s5, v1
    v.ld.w       v0, [s2, #0]
    s.movz       s2, #3
    s.addi       s5, s12, #1280
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s13, v1
    v.ld.w       v0, [s14, #0]
    s.movz       s13, #4
    s.addi       s14, s12, #1344
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s16, v1
    v.ld.w       v0, [s17, #0]
    s.movz       s16, #5
    s.addi       s17, s12, #1408
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s2, v1
    v.ld.w       v0, [s5, #0]
    s.movz       s2, #6
    s.addi       s5, s12, #1472
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s13, v1
    v.ld.w       v0, [s14, #0]
    s.movz       s13, #7
    s.addi       s14, s12, #1536
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s16, v1
    v.ld.w       v0, [s17, #0]
    s.movz       s16, #8
    s.addi       s17, s12, #1600
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s2, v1
    v.ld.w       v0, [s5, #0]
    s.movz       s2, #9
    s.addi       s5, s12, #1664
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s13, v1
    v.ld.w       v0, [s14, #0]
    s.movz       s13, #10
    s.addi       s14, s12, #1728
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s16, v1
    v.ld.w       v0, [s17, #0]
    s.movz       s16, #11
    s.addi       s17, s12, #1792
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s2, v1
    v.ld.w       v0, [s5, #0]
    s.movz       s2, #12
    s.addi       s5, s12, #1856
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s13, v1
    v.ld.w       v0, [s14, #0]
    s.movz       s13, #13
    s.addi       s14, s12, #1920
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s16, v1
    v.ld.w       v0, [s17, #0]
    s.movz       s16, #14
    s.addi       s17, s12, #1984
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s2, v1
    v.ld.w       v0, [s5, #0]
    s.movz       s2, #15
    s.addi       s5, s12, #2048
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s13, v1
    v.ld.w       v0, [s14, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s13, #0
    s.addi       s14, s12, #2112
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s16, v1
    v.ld.w       v0, [s17, #0]
    s.movz       s16, #1
    s.addi       s17, s12, #2176
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    s.movz       s18, #2
    a.vwrite     a1, s2, v1
    v.ld.w       v0, [s5, #0]
    s.addi       s2, s12, #2240
    s.movz       s5, #3
    v.ld.gather.w v1, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s13, v1
    v.ld.w       v0, [s14, #0]
    s.addi       s13, s12, #2304
    s.movz       s14, #4
    v.ld.gather.w v1, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s16, v1
    v.ld.w       v0, [s17, #0]
    s.addi       s16, s12, #2368
    s.movz       s17, #5
    v.ld.gather.w v1, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s18, v1
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s12, #2432
    s.movz       s18, #6
    v.ld.gather.w v1, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s5, v1
    v.ld.w       v0, [s13, #0]
    s.addi       s5, s12, #2496
    s.movz       s13, #7
    v.ld.gather.w v1, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s14, v1
    v.ld.w       v0, [s16, #0]
    s.addi       s14, s12, #2560
    s.movz       s16, #8
    v.ld.gather.w v1, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s17, v1
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s12, #2624
    s.movz       s17, #9
    v.movi       v1, #0
    v.ld.gather.w v3, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s18, v3
    v.ld.w       v0, [s5, #0]
    s.addi       s5, s12, #2688
    s.movz       s18, #10
    v.ld.gather.w v3, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s13, v3
    v.ld.w       v0, [s14, #0]
    s.addi       s13, s12, #2752
    s.movz       s14, #11
    v.ld.gather.w v3, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s16, v3
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s12, #2816
    s.movz       s16, #12
    v.ld.gather.w v3, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s17, v3
    v.ld.w       v0, [s5, #0]
    s.addi       s5, s12, #2880
    s.movz       s17, #13
    v.ld.gather.w v3, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s18, v3
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s12, #2944
    s.movz       s18, #14
    v.ld.gather.w v3, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s14, v3
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s12, #3008
    s.movz       s14, #15
    v.ld.gather.w v3, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s16, v3
    v.ld.w       v0, [s5, #0]
    s.movz       s5, #0
    s.movz       s16, #0
    v.ld.gather.w v3, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s17, v3
    v.ld.w       v0, [s13, #0]
    s.movz       s13, #1
    s.movz       s17, #2
    v.ld.gather.w v3, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s18, v3
    v.ld.w       v0, [s2, #0]
    s.movz       s2, #3
    s.movz       s18, #4
    v.ld.gather.w v3, [s6, v0]                   // index is in elements (ISA sec 9.1)
    s.movz       s19, #5
    a.vwrite     a2, s14, v3
    a.vread      v0, a1, s5
    a.vread      v3, a2, s16
    a.vread      v4, a2, s13
    v.extract    s5, v0, #0
    v.extract    s13, v0, #1
    v.splat      v5, s5
    v.splat      v6, s13
    v.extract    s5, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s5
    a.vread      v5, a2, s17
    v.extract    s5, v0, #3
    a.vread      v8, a2, s2
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s5
    v.extract    s2, v0, #4
    a.vread      v6, a2, s18
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s5, #6
    v.splat      v4, s2
    a.vread      v8, a2, s5
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s5, #7
    v.splat      v6, s2
    a.vread      v7, a2, s5
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s5, #8
    v.splat      v3, s2
    a.vread      v5, a2, s5
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s2, #0
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #9
    s.movz       s13, #9
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v9, v6, v7, v10
    v.extract    s5, v0, #10
    s.movz       s13, #10
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v10, v3, v5, v9
    v.extract    s5, v0, #11
    s.movz       s13, #11
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v9, v4, v8, v10
    v.extract    s5, v0, #12
    s.movz       s13, #12
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v10, v6, v7, v9
    v.extract    s5, v0, #13
    s.movz       s13, #13
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v9, v3, v5, v10
    v.extract    s5, v0, #14
    s.movz       s13, #14
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #15
    s.movz       s13, #15
    v.splat      v0, s5
    a.vread      v4, a2, s13
    vf.fma       v8, v6, v7, v10
    s.movz       s5, #1
    s.movz       s13, #0
    s.movz       s14, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s18, #4
    s.movz       s19, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s5
    a.vread      v3, a2, s13
    a.vread      v4, a2, s14
    v.extract    s2, v0, #0
    v.extract    s5, v0, #1
    v.splat      v5, s2
    v.splat      v6, s5
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s2
    a.vread      v5, a2, s16
    v.extract    s2, v0, #3
    a.vread      v8, a2, s17
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s18
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s5, #6
    v.splat      v4, s2
    a.vread      v8, a2, s5
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s5, #7
    v.splat      v6, s2
    a.vread      v7, a2, s5
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s5, #8
    v.splat      v3, s2
    a.vread      v5, a2, s5
    s.movz       s2, #1
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #9
    s.movz       s13, #9
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v9, v6, v7, v10
    v.extract    s5, v0, #10
    s.movz       s13, #10
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v10, v3, v5, v9
    v.extract    s5, v0, #11
    s.movz       s13, #11
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v9, v4, v8, v10
    v.extract    s5, v0, #12
    s.movz       s13, #12
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v10, v6, v7, v9
    v.extract    s5, v0, #13
    s.movz       s13, #13
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v9, v3, v5, v10
    v.extract    s5, v0, #14
    s.movz       s13, #14
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #15
    s.movz       s13, #15
    v.splat      v0, s5
    a.vread      v4, a2, s13
    vf.fma       v8, v6, v7, v10
    s.movz       s5, #2
    s.movz       s13, #0
    s.movz       s14, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s18, #4
    s.movz       s19, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s5
    a.vread      v3, a2, s13
    a.vread      v4, a2, s14
    v.extract    s2, v0, #0
    v.extract    s5, v0, #1
    v.splat      v5, s2
    v.splat      v6, s5
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s2
    a.vread      v5, a2, s16
    v.extract    s2, v0, #3
    a.vread      v8, a2, s17
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s18
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s5, #6
    v.splat      v4, s2
    a.vread      v8, a2, s5
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s5, #7
    v.splat      v6, s2
    a.vread      v7, a2, s5
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s5, #8
    v.splat      v3, s2
    a.vread      v5, a2, s5
    s.movz       s2, #2
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #9
    s.movz       s13, #9
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v9, v6, v7, v10
    v.extract    s5, v0, #10
    s.movz       s13, #10
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v10, v3, v5, v9
    v.extract    s5, v0, #11
    s.movz       s13, #11
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v9, v4, v8, v10
    v.extract    s5, v0, #12
    s.movz       s13, #12
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v10, v6, v7, v9
    v.extract    s5, v0, #13
    s.movz       s13, #13
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v9, v3, v5, v10
    v.extract    s5, v0, #14
    s.movz       s13, #14
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #15
    s.movz       s13, #15
    v.splat      v0, s5
    a.vread      v4, a2, s13
    vf.fma       v8, v6, v7, v10
    s.movz       s5, #3
    s.movz       s13, #0
    s.movz       s14, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s18, #4
    s.movz       s19, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s5
    a.vread      v3, a2, s13
    a.vread      v4, a2, s14
    v.extract    s2, v0, #0
    v.extract    s5, v0, #1
    v.splat      v5, s2
    v.splat      v6, s5
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s2
    a.vread      v5, a2, s16
    v.extract    s2, v0, #3
    a.vread      v8, a2, s17
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s18
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s5, #6
    v.splat      v4, s2
    a.vread      v8, a2, s5
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s5, #7
    v.splat      v6, s2
    a.vread      v7, a2, s5
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s5, #8
    v.splat      v3, s2
    a.vread      v5, a2, s5
    s.movz       s2, #3
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #9
    s.movz       s13, #9
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v9, v6, v7, v10
    v.extract    s5, v0, #10
    s.movz       s13, #10
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v10, v3, v5, v9
    v.extract    s5, v0, #11
    s.movz       s13, #11
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v9, v4, v8, v10
    v.extract    s5, v0, #12
    s.movz       s13, #12
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v10, v6, v7, v9
    v.extract    s5, v0, #13
    s.movz       s13, #13
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v9, v3, v5, v10
    v.extract    s5, v0, #14
    s.movz       s13, #14
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #15
    s.movz       s13, #15
    v.splat      v0, s5
    a.vread      v4, a2, s13
    vf.fma       v8, v6, v7, v10
    s.movz       s5, #4
    s.movz       s13, #0
    s.movz       s14, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s18, #4
    s.movz       s19, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s5
    a.vread      v3, a2, s13
    a.vread      v4, a2, s14
    v.extract    s2, v0, #0
    v.extract    s5, v0, #1
    v.splat      v5, s2
    v.splat      v6, s5
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s2
    a.vread      v5, a2, s16
    v.extract    s2, v0, #3
    a.vread      v8, a2, s17
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s18
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s5, #6
    v.splat      v4, s2
    a.vread      v8, a2, s5
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s5, #7
    v.splat      v6, s2
    a.vread      v7, a2, s5
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s5, #8
    v.splat      v3, s2
    a.vread      v5, a2, s5
    s.movz       s2, #4
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #9
    s.movz       s13, #9
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v9, v6, v7, v10
    v.extract    s5, v0, #10
    s.movz       s13, #10
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v10, v3, v5, v9
    v.extract    s5, v0, #11
    s.movz       s13, #11
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v9, v4, v8, v10
    v.extract    s5, v0, #12
    s.movz       s13, #12
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v10, v6, v7, v9
    v.extract    s5, v0, #13
    s.movz       s13, #13
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v9, v3, v5, v10
    v.extract    s5, v0, #14
    s.movz       s13, #14
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #15
    s.movz       s13, #15
    v.splat      v0, s5
    a.vread      v4, a2, s13
    vf.fma       v8, v6, v7, v10
    s.movz       s5, #5
    s.movz       s13, #0
    s.movz       s14, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s18, #4
    s.movz       s19, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s5
    a.vread      v3, a2, s13
    a.vread      v4, a2, s14
    v.extract    s2, v0, #0
    v.extract    s5, v0, #1
    v.splat      v5, s2
    v.splat      v6, s5
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s2
    a.vread      v5, a2, s16
    v.extract    s2, v0, #3
    a.vread      v8, a2, s17
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s18
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s5, #6
    v.splat      v4, s2
    a.vread      v8, a2, s5
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s5, #7
    v.splat      v6, s2
    a.vread      v7, a2, s5
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s5, #8
    v.splat      v3, s2
    a.vread      v5, a2, s5
    s.movz       s2, #5
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #9
    s.movz       s13, #9
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v9, v6, v7, v10
    v.extract    s5, v0, #10
    s.movz       s13, #10
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v10, v3, v5, v9
    v.extract    s5, v0, #11
    s.movz       s13, #11
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v9, v4, v8, v10
    v.extract    s5, v0, #12
    s.movz       s13, #12
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v10, v6, v7, v9
    v.extract    s5, v0, #13
    s.movz       s13, #13
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v9, v3, v5, v10
    v.extract    s5, v0, #14
    s.movz       s13, #14
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #15
    s.movz       s13, #15
    v.splat      v0, s5
    a.vread      v4, a2, s13
    vf.fma       v8, v6, v7, v10
    s.movz       s5, #6
    s.movz       s13, #0
    s.movz       s14, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s18, #4
    s.movz       s19, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s5
    a.vread      v3, a2, s13
    a.vread      v4, a2, s14
    v.extract    s2, v0, #0
    v.extract    s5, v0, #1
    v.splat      v5, s2
    v.splat      v6, s5
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s2
    a.vread      v5, a2, s16
    v.extract    s2, v0, #3
    a.vread      v8, a2, s17
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s18
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s5, #6
    v.splat      v4, s2
    a.vread      v8, a2, s5
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s5, #7
    v.splat      v6, s2
    a.vread      v7, a2, s5
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s5, #8
    v.splat      v3, s2
    a.vread      v5, a2, s5
    s.movz       s2, #6
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #9
    s.movz       s13, #9
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v9, v6, v7, v10
    v.extract    s5, v0, #10
    s.movz       s13, #10
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v10, v3, v5, v9
    v.extract    s5, v0, #11
    s.movz       s13, #11
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v9, v4, v8, v10
    v.extract    s5, v0, #12
    s.movz       s13, #12
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v10, v6, v7, v9
    v.extract    s5, v0, #13
    s.movz       s13, #13
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v9, v3, v5, v10
    v.extract    s5, v0, #14
    s.movz       s13, #14
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #15
    s.movz       s13, #15
    v.splat      v0, s5
    a.vread      v4, a2, s13
    vf.fma       v8, v6, v7, v10
    s.movz       s5, #7
    s.movz       s13, #0
    s.movz       s14, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s18, #4
    s.movz       s19, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s5
    a.vread      v3, a2, s13
    a.vread      v4, a2, s14
    v.extract    s2, v0, #0
    v.extract    s5, v0, #1
    v.splat      v5, s2
    v.splat      v6, s5
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s2
    a.vread      v5, a2, s16
    v.extract    s2, v0, #3
    a.vread      v8, a2, s17
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s18
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s5, #6
    v.splat      v4, s2
    a.vread      v8, a2, s5
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s5, #7
    v.splat      v6, s2
    a.vread      v7, a2, s5
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s5, #8
    v.splat      v3, s2
    a.vread      v5, a2, s5
    s.movz       s2, #7
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #9
    s.movz       s13, #9
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v9, v6, v7, v10
    v.extract    s5, v0, #10
    s.movz       s13, #10
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v10, v3, v5, v9
    v.extract    s5, v0, #11
    s.movz       s13, #11
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v9, v4, v8, v10
    v.extract    s5, v0, #12
    s.movz       s13, #12
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v10, v6, v7, v9
    v.extract    s5, v0, #13
    s.movz       s13, #13
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v9, v3, v5, v10
    v.extract    s5, v0, #14
    s.movz       s13, #14
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #15
    s.movz       s13, #15
    v.splat      v0, s5
    a.vread      v4, a2, s13
    vf.fma       v8, v6, v7, v10
    s.movz       s5, #8
    s.movz       s13, #0
    s.movz       s14, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s18, #4
    s.movz       s19, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s5
    a.vread      v3, a2, s13
    a.vread      v4, a2, s14
    v.extract    s2, v0, #0
    v.extract    s5, v0, #1
    v.splat      v5, s2
    v.splat      v6, s5
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s2
    a.vread      v5, a2, s16
    v.extract    s2, v0, #3
    a.vread      v8, a2, s17
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s18
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s5, #6
    v.splat      v4, s2
    a.vread      v8, a2, s5
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s5, #7
    v.splat      v6, s2
    a.vread      v7, a2, s5
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s5, #8
    v.splat      v3, s2
    a.vread      v5, a2, s5
    s.movz       s2, #8
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #9
    s.movz       s13, #9
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v9, v6, v7, v10
    v.extract    s5, v0, #10
    s.movz       s13, #10
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v10, v3, v5, v9
    v.extract    s5, v0, #11
    s.movz       s13, #11
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v9, v4, v8, v10
    v.extract    s5, v0, #12
    s.movz       s13, #12
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v10, v6, v7, v9
    v.extract    s5, v0, #13
    s.movz       s13, #13
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v9, v3, v5, v10
    v.extract    s5, v0, #14
    s.movz       s13, #14
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #15
    s.movz       s13, #15
    v.splat      v0, s5
    a.vread      v4, a2, s13
    vf.fma       v8, v6, v7, v10
    s.movz       s5, #9
    s.movz       s13, #0
    s.movz       s14, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s18, #4
    s.movz       s19, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s5
    a.vread      v3, a2, s13
    a.vread      v4, a2, s14
    v.extract    s2, v0, #0
    v.extract    s5, v0, #1
    v.splat      v5, s2
    v.splat      v6, s5
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s2
    a.vread      v5, a2, s16
    v.extract    s2, v0, #3
    a.vread      v8, a2, s17
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s18
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s5, #6
    v.splat      v4, s2
    a.vread      v8, a2, s5
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s5, #7
    v.splat      v6, s2
    a.vread      v7, a2, s5
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s5, #8
    v.splat      v3, s2
    a.vread      v5, a2, s5
    s.movz       s2, #9
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #9
    s.movz       s13, #9
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v9, v6, v7, v10
    v.extract    s5, v0, #10
    s.movz       s13, #10
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v10, v3, v5, v9
    v.extract    s5, v0, #11
    s.movz       s13, #11
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v9, v4, v8, v10
    v.extract    s5, v0, #12
    s.movz       s13, #12
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v10, v6, v7, v9
    v.extract    s5, v0, #13
    s.movz       s13, #13
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v9, v3, v5, v10
    v.extract    s5, v0, #14
    s.movz       s13, #14
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #15
    s.movz       s13, #15
    v.splat      v0, s5
    a.vread      v4, a2, s13
    vf.fma       v8, v6, v7, v10
    s.movz       s5, #10
    s.movz       s13, #0
    s.movz       s14, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s18, #4
    s.movz       s19, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s5
    a.vread      v3, a2, s13
    a.vread      v4, a2, s14
    v.extract    s2, v0, #0
    v.extract    s5, v0, #1
    v.splat      v5, s2
    v.splat      v6, s5
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s2
    a.vread      v5, a2, s16
    v.extract    s2, v0, #3
    a.vread      v8, a2, s17
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s18
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s5, #6
    v.splat      v4, s2
    a.vread      v8, a2, s5
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s5, #7
    v.splat      v6, s2
    a.vread      v7, a2, s5
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s5, #8
    v.splat      v3, s2
    a.vread      v5, a2, s5
    s.movz       s2, #10
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #9
    s.movz       s13, #9
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v9, v6, v7, v10
    v.extract    s5, v0, #10
    s.movz       s13, #10
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v10, v3, v5, v9
    v.extract    s5, v0, #11
    s.movz       s13, #11
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v9, v4, v8, v10
    v.extract    s5, v0, #12
    s.movz       s13, #12
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v10, v6, v7, v9
    v.extract    s5, v0, #13
    s.movz       s13, #13
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v9, v3, v5, v10
    v.extract    s5, v0, #14
    s.movz       s13, #14
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #15
    s.movz       s13, #15
    v.splat      v0, s5
    a.vread      v4, a2, s13
    vf.fma       v8, v6, v7, v10
    s.movz       s5, #11
    s.movz       s13, #0
    s.movz       s14, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s18, #4
    s.movz       s19, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s5
    a.vread      v3, a2, s13
    a.vread      v4, a2, s14
    v.extract    s2, v0, #0
    v.extract    s5, v0, #1
    v.splat      v5, s2
    v.splat      v6, s5
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s2
    a.vread      v5, a2, s16
    v.extract    s2, v0, #3
    a.vread      v8, a2, s17
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s18
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s5, #6
    v.splat      v4, s2
    a.vread      v8, a2, s5
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s5, #7
    v.splat      v6, s2
    a.vread      v7, a2, s5
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s5, #8
    v.splat      v3, s2
    a.vread      v5, a2, s5
    s.movz       s2, #11
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #9
    s.movz       s13, #9
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v9, v6, v7, v10
    v.extract    s5, v0, #10
    s.movz       s13, #10
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v10, v3, v5, v9
    v.extract    s5, v0, #11
    s.movz       s13, #11
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v9, v4, v8, v10
    v.extract    s5, v0, #12
    s.movz       s13, #12
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v10, v6, v7, v9
    v.extract    s5, v0, #13
    s.movz       s13, #13
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v9, v3, v5, v10
    v.extract    s5, v0, #14
    s.movz       s13, #14
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #15
    s.movz       s13, #15
    v.splat      v0, s5
    a.vread      v4, a2, s13
    vf.fma       v8, v6, v7, v10
    s.movz       s5, #12
    s.movz       s13, #0
    s.movz       s14, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s18, #4
    s.movz       s19, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s5
    a.vread      v3, a2, s13
    a.vread      v4, a2, s14
    v.extract    s2, v0, #0
    v.extract    s5, v0, #1
    v.splat      v5, s2
    v.splat      v6, s5
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s2
    a.vread      v5, a2, s16
    v.extract    s2, v0, #3
    a.vread      v8, a2, s17
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s18
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s5, #6
    v.splat      v4, s2
    a.vread      v8, a2, s5
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s5, #7
    v.splat      v6, s2
    a.vread      v7, a2, s5
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s5, #8
    v.splat      v3, s2
    a.vread      v5, a2, s5
    s.movz       s2, #12
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #9
    s.movz       s13, #9
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v9, v6, v7, v10
    v.extract    s5, v0, #10
    s.movz       s13, #10
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v10, v3, v5, v9
    v.extract    s5, v0, #11
    s.movz       s13, #11
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v9, v4, v8, v10
    v.extract    s5, v0, #12
    s.movz       s13, #12
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v10, v6, v7, v9
    v.extract    s5, v0, #13
    s.movz       s13, #13
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v9, v3, v5, v10
    v.extract    s5, v0, #14
    s.movz       s13, #14
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #15
    s.movz       s13, #15
    v.splat      v0, s5
    a.vread      v4, a2, s13
    vf.fma       v8, v6, v7, v10
    s.movz       s5, #13
    s.movz       s13, #0
    s.movz       s14, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s18, #4
    s.movz       s19, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s5
    a.vread      v3, a2, s13
    a.vread      v4, a2, s14
    v.extract    s2, v0, #0
    v.extract    s5, v0, #1
    v.splat      v5, s2
    v.splat      v6, s5
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s2
    a.vread      v5, a2, s16
    v.extract    s2, v0, #3
    a.vread      v8, a2, s17
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s18
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s5, #6
    v.splat      v4, s2
    a.vread      v8, a2, s5
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s5, #7
    v.splat      v6, s2
    a.vread      v7, a2, s5
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s5, #8
    v.splat      v3, s2
    a.vread      v5, a2, s5
    s.movz       s2, #13
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #9
    s.movz       s13, #9
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v9, v6, v7, v10
    v.extract    s5, v0, #10
    s.movz       s13, #10
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v10, v3, v5, v9
    v.extract    s5, v0, #11
    s.movz       s13, #11
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v9, v4, v8, v10
    v.extract    s5, v0, #12
    s.movz       s13, #12
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v10, v6, v7, v9
    v.extract    s5, v0, #13
    s.movz       s13, #13
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v9, v3, v5, v10
    v.extract    s5, v0, #14
    s.movz       s13, #14
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #15
    s.movz       s13, #15
    v.splat      v0, s5
    a.vread      v4, a2, s13
    vf.fma       v8, v6, v7, v10
    s.movz       s5, #14
    s.movz       s13, #0
    s.movz       s14, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s18, #4
    s.movz       s19, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s5
    a.vread      v3, a2, s13
    a.vread      v4, a2, s14
    v.extract    s2, v0, #0
    v.extract    s5, v0, #1
    v.splat      v5, s2
    v.splat      v6, s5
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s2
    a.vread      v5, a2, s16
    v.extract    s2, v0, #3
    a.vread      v8, a2, s17
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s18
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s19
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s5, #6
    v.splat      v4, s2
    a.vread      v8, a2, s5
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s5, #7
    v.splat      v6, s2
    a.vread      v7, a2, s5
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s5, #8
    v.splat      v3, s2
    a.vread      v5, a2, s5
    s.movz       s2, #14
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #9
    s.movz       s13, #9
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v9, v6, v7, v10
    v.extract    s5, v0, #10
    s.movz       s13, #10
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v10, v3, v5, v9
    v.extract    s5, v0, #11
    s.movz       s13, #11
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v9, v4, v8, v10
    v.extract    s5, v0, #12
    s.movz       s13, #12
    v.splat      v4, s5
    a.vread      v8, a2, s13
    vf.fma       v10, v6, v7, v9
    v.extract    s5, v0, #13
    s.movz       s13, #13
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v9, v3, v5, v10
    v.extract    s5, v0, #14
    s.movz       s13, #14
    v.splat      v3, s5
    a.vread      v5, a2, s13
    vf.fma       v10, v4, v8, v9
    v.extract    s5, v0, #15
    s.movz       s13, #15
    v.splat      v0, s5
    a.vread      v4, a2, s13
    vf.fma       v8, v6, v7, v10
    s.movz       s5, #15
    s.movz       s13, #0
    s.movz       s14, #1
    s.movz       s16, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s17, #3
    s.movz       s18, #4
    s.movz       s19, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s5
    a.vread      v3, a2, s13
    a.vread      v4, a2, s14
    v.extract    s2, v0, #0
    v.extract    s5, v0, #1
    v.splat      v5, s2
    v.splat      v6, s5
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v1, s2
    a.vread      v3, a2, s16
    v.extract    s2, v0, #3
    a.vread      v5, a2, s17
    vf.fma       v8, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s18
    v.splat      v7, s2
    vf.fma       v9, v1, v3, v8
    v.extract    s2, v0, #5
    a.vread      v1, a2, s19
    v.splat      v3, s2
    v.extract    s2, v0, #6
    vf.fma       v8, v4, v5, v9
    s.movz       s5, #6
    v.splat      v4, s2
    a.vread      v5, a2, s5
    v.extract    s2, v0, #7
    vf.fma       v9, v7, v6, v8
    s.movz       s5, #7
    v.splat      v6, s2
    a.vread      v7, a2, s5
    v.extract    s2, v0, #8
    vf.fma       v8, v3, v1, v9
    s.movz       s5, #8
    v.splat      v1, s2
    a.vread      v3, a2, s5
    s.movz       s2, #15
    vf.fma       v9, v4, v5, v8
    v.extract    s5, v0, #9
    s.movz       s13, #9
    v.splat      v4, s5
    a.vread      v5, a2, s13
    vf.fma       v8, v6, v7, v9
    v.extract    s5, v0, #10
    s.movz       s13, #10
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v9, v1, v3, v8
    v.extract    s5, v0, #11
    s.movz       s13, #11
    v.splat      v1, s5
    a.vread      v3, a2, s13
    vf.fma       v8, v4, v5, v9
    v.extract    s5, v0, #12
    s.movz       s13, #12
    v.splat      v4, s5
    a.vread      v5, a2, s13
    vf.fma       v9, v6, v7, v8
    v.extract    s5, v0, #13
    s.movz       s13, #13
    v.splat      v6, s5
    a.vread      v7, a2, s13
    vf.fma       v8, v1, v3, v9
    v.extract    s5, v0, #14
    s.movz       s13, #14
    v.splat      v1, s5
    a.vread      v3, a2, s13
    vf.fma       v9, v4, v5, v8
    v.extract    s5, v0, #15
    s.movz       s13, #15
    v.splat      v0, s5
    a.vread      v4, a2, s13
    vf.fma       v5, v6, v7, v9
    s.addi       s5, s12, #1024
    v.splat      v6, s1
    s.addi       s13, s12, #3072
    s.addi       s14, s12, #1088
    vf.fma       v7, v1, v3, v5
    s.addi       s16, s13, #64
    s.addi       s17, s12, #1152
    s.addi       s18, s13, #128
    s.addi       s19, s12, #1216
    vf.fma       v1, v0, v4, v7
    a.vwrite     a3, s2, v1
    v.ld.w       v0, [s5, #0]
    s.addi       s2, s13, #192
    s.addi       s5, s12, #1280
    v.add        v1, v0, v6
    v.st.w       [s13, #0], v1
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s13, #256
    v.add        v1, v0, v6
    v.st.w       [s16, #0], v1
    s.addi       s16, s12, #1344
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s13, #320
    v.add        v1, v0, v6
    v.st.w       [s18, #0], v1
    s.addi       s18, s12, #1408
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s13, #384
    v.add        v1, v0, v6
    v.st.w       [s2, #0], v1
    s.addi       s2, s12, #1472
    v.ld.w       v0, [s5, #0]
    s.addi       s5, s13, #448
    v.add        v1, v0, v6
    v.st.w       [s14, #0], v1
    s.addi       s14, s12, #1536
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s13, #512
    v.add        v1, v0, v6
    v.st.w       [s17, #0], v1
    s.addi       s17, s12, #1600
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s13, #576
    v.add        v1, v0, v6
    v.st.w       [s19, #0], v1
    s.addi       s19, s12, #1664
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s13, #640
    v.add        v1, v0, v6
    v.st.w       [s5, #0], v1
    s.addi       s5, s12, #1728
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s13, #704
    v.add        v1, v0, v6
    v.st.w       [s16, #0], v1
    s.addi       s16, s12, #1792
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s13, #768
    v.add        v1, v0, v6
    v.st.w       [s18, #0], v1
    s.addi       s18, s12, #1856
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s13, #832
    v.add        v1, v0, v6
    v.st.w       [s2, #0], v1
    s.addi       s2, s12, #1920
    v.ld.w       v0, [s5, #0]
    s.addi       s5, s13, #896
    s.addi       s20, s13, #960
    v.add        v1, v0, v6
    v.st.w       [s14, #0], v1
    s.addi       s13, s12, #1984
    v.ld.w       v0, [s16, #0]
    s.addi       s14, s12, #2048
    v.add        v1, v0, v6
    v.st.w       [s17, #0], v1
    s.movz       s16, #4096
    v.splat      v0, s16
    s.addi       s16, s12, #4096
    v.ld.w       v1, [s18, #0]
    s.addi       s17, s12, #2112
    v.add        v3, v1, v6
    v.st.w       [s19, #0], v3
    s.addi       s18, s16, #64
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s12, #2176
    v.add        v3, v1, v6
    v.st.w       [s5, #0], v3
    s.addi       s5, s16, #128
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s12, #2240
    v.add        v3, v1, v6
    v.st.w       [s20, #0], v3
    fence.acq_rel.device
    s.addi       s19, s16, #192
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s12, #2304
    v.add        v3, v1, v0
    v.st.w       [s16, #0], v3
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s16, #256
    v.add        v3, v1, v0
    v.st.w       [s18, #0], v3
    s.addi       s18, s12, #2368
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s16, #320
    v.add        v3, v1, v0
    v.st.w       [s5, #0], v3
    s.addi       s5, s12, #2432
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s16, #384
    v.add        v3, v1, v0
    v.st.w       [s19, #0], v3
    s.addi       s19, s12, #2496
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s16, #448
    v.add        v3, v1, v0
    v.st.w       [s17, #0], v3
    s.addi       s17, s12, #2560
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s16, #512
    v.add        v3, v1, v0
    v.st.w       [s2, #0], v3
    s.addi       s2, s12, #2624
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s16, #576
    v.add        v3, v1, v0
    v.st.w       [s13, #0], v3
    s.addi       s13, s12, #2688
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s16, #640
    v.add        v3, v1, v0
    v.st.w       [s14, #0], v3
    s.addi       s14, s12, #2752
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s16, #704
    v.add        v3, v1, v0
    v.st.w       [s18, #0], v3
    s.addi       s18, s12, #2816
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s16, #768
    v.add        v3, v1, v0
    v.st.w       [s5, #0], v3
    s.addi       s5, s12, #2880
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s16, #832
    v.add        v3, v1, v0
    v.st.w       [s19, #0], v3
    s.addi       s19, s12, #2944
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s16, #896
    s.addi       s20, s16, #960
    v.add        v3, v1, v0
    v.st.w       [s17, #0], v3
    s.addi       s16, s12, #3008
    v.ld.w       v1, [s18, #0]
    s.addi       s17, s12, #3072
    v.add        v3, v1, v0
    v.st.w       [s2, #0], v3
    s.addi       s2, s12, #5120
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s12, #3136
    v.add        v3, v1, v0
    v.st.w       [s13, #0], v3
    s.addi       s13, s2, #64
    v.ld.w       v1, [s19, #0]
    s.addi       s18, s12, #3200
    v.add        v3, v1, v0
    v.st.w       [s14, #0], v3
    s.addi       s14, s2, #128
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s12, #3264
    v.add        v3, v1, v0
    v.st.w       [s20, #0], v3
    fence.acq_rel.device
    s.addi       s19, s2, #192
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s12, #3328
    v.st.w       [s2, #0], v0
    v.ld.w       v0, [s5, #0]
    s.addi       s5, s2, #256
    v.st.w       [s13, #0], v0
    s.addi       s13, s12, #3392
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s2, #320
    v.st.w       [s14, #0], v0
    s.addi       s14, s12, #3456
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s2, #384
    v.st.w       [s19, #0], v0
    s.addi       s19, s12, #3520
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s2, #448
    v.st.w       [s5, #0], v0
    s.addi       s5, s12, #3584
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s2, #512
    v.st.w       [s18, #0], v0
    s.addi       s18, s12, #3648
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s2, #576
    v.st.w       [s16, #0], v0
    s.addi       s16, s12, #3712
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s2, #640
    v.st.w       [s17, #0], v0
    s.addi       s17, s12, #3776
    v.ld.w       v0, [s5, #0]
    s.addi       s5, s2, #704
    v.st.w       [s13, #0], v0
    s.addi       s13, s12, #3840
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s2, #768
    v.st.w       [s14, #0], v0
    s.addi       s14, s12, #3904
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s2, #832
    v.st.w       [s19, #0], v0
    s.addi       s19, s12, #3968
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s2, #896
    s.addi       s20, s2, #960
    v.st.w       [s5, #0], v0
    s.addi       s2, s12, #4032
    v.ld.w       v0, [s13, #0]
    s.addi       s5, s12, #4096
    v.st.w       [s18, #0], v0
    s.addi       s13, s12, #6144
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s12, #4160
    v.st.w       [s16, #0], v0
    s.addi       s16, s13, #64
    v.ld.w       v0, [s19, #0]
    s.addi       s18, s12, #4224
    v.st.w       [s17, #0], v0
    s.addi       s17, s13, #128
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s12, #4288
    v.st.w       [s20, #0], v0
    fence.acq_rel.device
    s.addi       s19, s13, #192
    v.ld.w       v0, [s5, #0]
    s.addi       s5, s12, #4352
    v.st.w       [s13, #0], v0
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s13, #256
    v.st.w       [s16, #0], v0
    s.addi       s16, s12, #4416
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s13, #320
    v.st.w       [s17, #0], v0
    s.addi       s17, s12, #4480
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s13, #384
    v.st.w       [s19, #0], v0
    s.addi       s19, s12, #4544
    v.ld.w       v0, [s5, #0]
    s.addi       s5, s13, #448
    v.st.w       [s14, #0], v0
    s.addi       s14, s12, #4608
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s13, #512
    v.st.w       [s18, #0], v0
    s.addi       s18, s12, #4672
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s13, #576
    v.st.w       [s2, #0], v0
    s.addi       s2, s12, #4736
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s13, #640
    v.st.w       [s5, #0], v0
    s.addi       s5, s12, #4800
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s13, #704
    v.st.w       [s16, #0], v0
    s.addi       s16, s12, #4864
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s13, #768
    v.st.w       [s17, #0], v0
    s.addi       s17, s12, #4928
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s13, #832
    v.st.w       [s19, #0], v0
    s.addi       s19, s12, #4992
    v.ld.w       v0, [s5, #0]
    s.addi       s5, s13, #896
    s.addi       s20, s13, #960
    v.st.w       [s14, #0], v0
    s.addi       s13, s12, #5056
    v.ld.w       v0, [s16, #0]
    s.movz       s14, #0
    v.st.w       [s18, #0], v0
    s.movz       s16, #0
    v.ld.w       v0, [s17, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s17, #0
    v.st.w       [s2, #0], v0
    s.movz       s2, #1
    v.ld.w       v0, [s19, #0]
    s.movz       s18, #1
    v.st.w       [s5, #0], v0
    s.movz       s5, #1
    v.ld.w       v0, [s13, #0]
    s.movz       s13, #2
    v.st.w       [s20, #0], v0
    fence.acq_rel.device
    a.vread      v0, a0, s14
    a.vread      v1, a3, s16
    s.movz       s14, #2
    s.movz       s16, #2
    vf.add       v3, v0, v1
    s.movz       s19, #3
    a.vwrite     a4, s17, v3
    a.vread      v0, a0, s2
    a.vread      v1, a3, s18
    s.movz       s2, #3
    s.movz       s17, #3
    vf.add       v3, v0, v1
    s.movz       s18, #4
    a.vwrite     a4, s5, v3
    a.vread      v0, a0, s13
    a.vread      v1, a3, s14
    s.movz       s5, #4
    s.movz       s13, #4
    vf.add       v3, v0, v1
    s.movz       s14, #5
    a.vwrite     a4, s16, v3
    a.vread      v0, a0, s19
    a.vread      v1, a3, s2
    s.movz       s2, #5
    s.movz       s16, #5
    vf.add       v3, v0, v1
    s.movz       s19, #6
    a.vwrite     a4, s17, v3
    a.vread      v0, a0, s18
    a.vread      v1, a3, s5
    s.movz       s5, #6
    s.movz       s17, #6
    vf.add       v3, v0, v1
    s.movz       s18, #7
    a.vwrite     a4, s13, v3
    a.vread      v0, a0, s14
    a.vread      v1, a3, s2
    s.movz       s2, #7
    s.movz       s13, #7
    vf.add       v3, v0, v1
    s.movz       s14, #8
    a.vwrite     a4, s16, v3
    a.vread      v0, a0, s19
    a.vread      v1, a3, s5
    s.movz       s5, #8
    s.movz       s16, #8
    vf.add       v3, v0, v1
    s.movz       s19, #9
    a.vwrite     a4, s17, v3
    a.vread      v0, a0, s18
    a.vread      v1, a3, s2
    s.movz       s2, #9
    s.movz       s17, #9
    vf.add       v3, v0, v1
    s.movz       s18, #10
    a.vwrite     a4, s13, v3
    a.vread      v0, a0, s14
    a.vread      v1, a3, s5
    s.movz       s5, #10
    s.movz       s13, #10
    vf.add       v3, v0, v1
    s.movz       s14, #11
    a.vwrite     a4, s16, v3
    a.vread      v0, a0, s19
    a.vread      v1, a3, s2
    s.movz       s2, #11
    s.movz       s16, #11
    vf.add       v3, v0, v1
    s.movz       s19, #12
    a.vwrite     a4, s17, v3
    a.vread      v0, a0, s18
    a.vread      v1, a3, s5
    s.movz       s5, #12
    s.movz       s17, #12
    vf.add       v3, v0, v1
    s.movz       s18, #13
    a.vwrite     a4, s13, v3
    a.vread      v0, a0, s14
    a.vread      v1, a3, s2
    s.movz       s2, #13
    s.movz       s13, #13
    vf.add       v3, v0, v1
    s.movz       s14, #14
    a.vwrite     a4, s16, v3
    a.vread      v0, a0, s19
    a.vread      v1, a3, s5
    s.movz       s5, #14
    s.movz       s16, #14
    vf.add       v3, v0, v1
    s.movz       s19, #15
    a.vwrite     a4, s17, v3
    a.vread      v0, a0, s18
    a.vread      v1, a3, s2
    s.movz       s2, #15
    s.movz       s17, #15
    vf.add       v3, v0, v1
    s.addi       s18, s12, #5120
    a.vwrite     a4, s13, v3
    a.vread      v0, a0, s14
    a.vread      v1, a3, s5
    s.addi       s5, s12, #1024
    s.addi       s13, s12, #5184
    vf.add       v3, v0, v1
    s.addi       s14, s12, #1088
    a.vwrite     a4, s16, v3
    a.vread      v0, a0, s19
    a.vread      v1, a3, s2
    s.addi       s2, s12, #5248
    s.addi       s16, s12, #1152
    vf.add       v3, v0, v1
    s.addi       s19, s12, #5312
    a.vwrite     a4, s17, v3
    v.ld.w       v0, [s18, #0]
    s.addi       s17, s12, #1216
    s.addi       s18, s12, #5376
    v.st.w       [s5, #0], v0
    s.addi       s5, s12, #1280
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s12, #5440
    v.st.w       [s14, #0], v0
    s.addi       s14, s12, #1344
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s12, #5504
    v.st.w       [s16, #0], v0
    s.addi       s16, s12, #1408
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #5568
    v.st.w       [s17, #0], v0
    s.addi       s17, s12, #1472
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s12, #5632
    v.st.w       [s5, #0], v0
    s.addi       s5, s12, #1536
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s12, #5696
    v.st.w       [s14, #0], v0
    s.addi       s14, s12, #1600
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s12, #5760
    v.st.w       [s16, #0], v0
    s.addi       s16, s12, #1664
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #5824
    v.st.w       [s17, #0], v0
    s.addi       s17, s12, #1728
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s12, #5888
    v.st.w       [s5, #0], v0
    s.addi       s5, s12, #1792
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s12, #5952
    v.st.w       [s14, #0], v0
    s.addi       s14, s12, #1856
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s12, #6016
    v.st.w       [s16, #0], v0
    s.addi       s16, s12, #1920
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #6080
    v.st.w       [s17, #0], v0
    s.addi       s17, s12, #1984
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s12, #6144
    v.st.w       [s5, #0], v0
    s.addi       s5, s12, #2048
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s12, #6208
    v.st.w       [s14, #0], v0
    s.addi       s14, s12, #2112
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s12, #6272
    v.st.w       [s16, #0], v0
    s.addi       s16, s12, #2176
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #6336
    v.st.w       [s17, #0], v0
    fence.acq_rel.device
    s.addi       s17, s12, #2240
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s12, #6400
    v.st.w       [s5, #0], v0
    s.addi       s5, s12, #2304
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s12, #6464
    v.st.w       [s14, #0], v0
    s.addi       s14, s12, #2368
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s12, #6528
    v.st.w       [s16, #0], v0
    s.addi       s16, s12, #2432
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #6592
    v.st.w       [s17, #0], v0
    s.addi       s17, s12, #2496
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s12, #6656
    v.st.w       [s5, #0], v0
    s.addi       s5, s12, #2560
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s12, #6720
    v.st.w       [s14, #0], v0
    s.addi       s14, s12, #2624
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s12, #6784
    v.st.w       [s16, #0], v0
    s.addi       s16, s12, #2688
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #6848
    v.st.w       [s17, #0], v0
    s.addi       s17, s12, #2752
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s12, #6912
    v.st.w       [s5, #0], v0
    s.addi       s5, s12, #2816
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s12, #6976
    v.st.w       [s14, #0], v0
    s.addi       s14, s12, #2880
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s12, #7040
    v.st.w       [s16, #0], v0
    s.addi       s16, s12, #2944
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #7104
    s.addi       s20, s12, #3008
    v.st.w       [s17, #0], v0
    s.movz       s17, #0
    v.ld.w       v0, [s18, #0]
    s.movz       s18, #0
    v.st.w       [s5, #0], v0
    s.movz       s5, #1
    v.ld.w       v0, [s13, #0]
    s.movz       s13, #1
    v.st.w       [s14, #0], v0
    s.movz       s14, #2
    v.ld.w       v0, [s2, #0]
    s.movz       s2, #2
    v.st.w       [s16, #0], v0
    s.movz       s16, #3
    v.ld.w       v0, [s19, #0]
    s.movz       s19, #3
    v.st.w       [s20, #0], v0
    fence.acq_rel.device
    a.vread      v0, a4, s17
    s.movz       s17, #4
    s.movz       s20, #4
    a.vwrite     a0, s18, v0
    a.vread      v0, a4, s5
    s.movz       s5, #5
    s.movz       s18, #5
    a.vwrite     a0, s13, v0
    a.vread      v0, a4, s14
    s.movz       s13, #6
    s.movz       s14, #6
    a.vwrite     a0, s2, v0
    a.vread      v0, a4, s16
    s.movz       s2, #7
    s.movz       s16, #7
    a.vwrite     a0, s19, v0
    a.vread      v0, a4, s17
    s.movz       s17, #8
    s.movz       s19, #8
    a.vwrite     a0, s20, v0
    a.vread      v0, a4, s5
    s.movz       s5, #9
    s.movz       s20, #9
    a.vwrite     a0, s18, v0
    a.vread      v0, a4, s13
    s.movz       s13, #10
    s.movz       s18, #10
    a.vwrite     a0, s14, v0
    a.vread      v0, a4, s2
    s.movz       s2, #11
    s.movz       s14, #11
    a.vwrite     a0, s16, v0
    a.vread      v0, a4, s17
    s.movz       s16, #12
    s.movz       s17, #12
    a.vwrite     a0, s19, v0
    a.vread      v0, a4, s5
    s.movz       s5, #13
    s.movz       s19, #13
    a.vwrite     a0, s20, v0
    a.vread      v0, a4, s13
    s.movz       s13, #14
    s.movz       s20, #14
    a.vwrite     a0, s18, v0
    a.vread      v0, a4, s2
    s.movz       s2, #15
    s.movz       s18, #15
    a.vwrite     a0, s14, v0
    a.vread      v0, a4, s16
    s.add        s14, s10, s1
    s.movz       s16, #1
    a.vwrite     a0, s17, v0
    a.vread      v0, a4, s5
    a.vwrite     a0, s19, v0
    a.vread      v0, a4, s13
    a.vwrite     a0, s20, v0
    a.vread      v0, a4, s2
    a.vwrite     a0, s18, v0
    s.mov        s10, s14
    br.nz        s16, for_6
endfor_7:
    s.movz       s2, #0
    s.movz       s5, #3840
    s.add        s6, s2, s3                      // the tile origin
    s.mul        s2, s9, s5
    s.movz       s5, #0
    s.muli       s10, s3, #4                     // a runtime tile origin, x4
    v.splat      v0, s6
    s.add        s3, s5, s4                      // the tile origin
    s.movz       s5, #256
    s.muli       s6, s4, #1024                   // a runtime tile origin, x1024
    v.splat      v1, s3
    v.splat      v3, s8
    v.add        v4, v2, v0
    v.splat      v0, s5
    s.muli       s4, s2, #4                      // a runtime tile origin, x4
    s.addi       s2, s3, #1
    v.splat      v2, s9
    v.splat      v5, s1
    s.add        s1, s7, s10                     // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s5, #0
    v.cmp.lt     p1, v1, v3
    v.cmp.lt     p2, v4, v0
    v.splat      v0, s2
    s.add        s2, s1, s6                      // the tile origin
    p.and        p3, p1, p2
    s.addi       s1, s3, #2
    v.cmp.lt     p1, v2, v5
    a.vread      v1, a0, s5
    s.add        s5, s2, s4                      // the tile origin
    p.and        p4, p3, p1
    s.movz       s2, #1
    v.cmp.lt     p3, v0, v3
    v.splat      v0, s1
    p.and        p5, p3, p2
    s.addi       s1, s3, #3
    @p4 v.st.w       [s5, #0], v1
    a.vread      v1, a0, s2
    s.addi       s2, s5, #1024                   // row 1
    p.and        p3, p5, p1
    s.movz       s4, #2
    v.cmp.lt     p4, v0, v3
    v.splat      v0, s1
    p.and        p5, p4, p2
    s.addi       s1, s3, #4
    s.addi       s6, s5, #2048                   // row 2
    p.and        p4, p5, p1
    s.movz       s7, #3
    v.splat      v2, s1
    s.addi       s1, s3, #5
    s.addi       s8, s5, #3072                   // row 3
    s.movz       s9, #4
    v.splat      v4, s1
    s.addi       s1, s3, #6
    @p3 v.st.w       [s2, #0], v1
    a.vread      v1, a0, s4
    v.cmp.lt     p3, v0, v3
    p.and        p5, p3, p2
    s.addi       s2, s5, #4096                   // row 4
    p.and        p3, p5, p1
    s.movz       s4, #5
    v.splat      v0, s1
    s.addi       s1, s3, #7
    s.addi       s10, s5, #5120                  // row 5
    v.splat      v5, s1
    s.movz       s1, #6
    @p4 v.st.w       [s6, #0], v1
    a.vread      v1, a0, s7
    v.cmp.lt     p4, v2, v3
    p.and        p5, p4, p2
    s.addi       s6, s3, #8
    p.and        p4, p5, p1
    s.addi       s7, s5, #6144                   // row 6
    v.splat      v2, s6
    s.movz       s6, #7
    @p3 v.st.w       [s8, #0], v1
    a.vread      v1, a0, s9
    v.cmp.lt     p3, v4, v3
    p.and        p5, p3, p2
    s.addi       s8, s3, #9
    p.and        p3, p5, p1
    s.addi       s9, s5, #7168                   // row 7
    v.splat      v4, s8
    s.movz       s8, #8
    @p4 v.st.w       [s2, #0], v1
    a.vread      v1, a0, s4
    v.cmp.lt     p4, v0, v3
    p.and        p5, p4, p2
    s.addi       s2, s3, #10
    p.and        p4, p5, p1
    s.addi       s4, s5, #8192                   // row 8
    v.splat      v0, s2
    s.movz       s2, #9
    @p3 v.st.w       [s10, #0], v1
    a.vread      v1, a0, s1
    v.cmp.lt     p3, v5, v3
    p.and        p5, p3, p2
    s.addi       s1, s3, #11
    p.and        p3, p5, p1
    s.addi       s10, s5, #9216                  // row 9
    v.splat      v5, s1
    s.movz       s1, #10
    @p4 v.st.w       [s7, #0], v1
    a.vread      v1, a0, s6
    v.cmp.lt     p4, v2, v3
    p.and        p5, p4, p2
    s.addi       s6, s3, #12
    p.and        p4, p5, p1
    s.addi       s7, s5, #10240                  // row 10
    v.splat      v2, s6
    s.movz       s6, #11
    @p3 v.st.w       [s9, #0], v1
    a.vread      v1, a0, s8
    v.cmp.lt     p3, v4, v3
    p.and        p5, p3, p2
    s.addi       s8, s3, #13
    p.and        p3, p5, p1
    s.addi       s9, s5, #11264                  // row 11
    v.splat      v4, s8
    s.movz       s8, #12
    @p4 v.st.w       [s4, #0], v1
    a.vread      v1, a0, s2
    v.cmp.lt     p4, v0, v3
    p.and        p5, p4, p2
    s.addi       s2, s3, #14
    p.and        p4, p5, p1
    s.addi       s4, s5, #12288                  // row 12
    v.splat      v0, s2
    s.movz       s2, #13
    @p3 v.st.w       [s10, #0], v1
    a.vread      v1, a0, s1
    v.cmp.lt     p3, v5, v3
    p.and        p5, p3, p2
    s.addi       s1, s3, #15
    p.and        p3, p5, p1
    s.addi       s3, s5, #13312                  // row 13
    s.movz       s10, #14
    v.splat      v5, s1
    s.addi       s1, s5, #14336                  // row 14
    s.addi       s11, s5, #15360                 // row 15
    @p4 v.st.w       [s7, #0], v1
    a.vread      v1, a0, s6
    v.cmp.lt     p4, v2, v3
    p.and        p5, p4, p2
    s.movz       s5, #15
    p.and        p4, p5, p1
    @p3 v.st.w       [s9, #0], v1
    a.vread      v1, a0, s8
    v.cmp.lt     p3, v4, v3
    p.and        p5, p3, p2
    p.and        p3, p5, p1
    @p4 v.st.w       [s4, #0], v1
    a.vread      v1, a0, s2
    v.cmp.lt     p4, v0, v3
    p.and        p5, p4, p2
    p.and        p4, p5, p1
    @p3 v.st.w       [s3, #0], v1
    a.vread      v0, a0, s10
    v.cmp.lt     p3, v5, v3
    p.and        p5, p3, p2
    p.and        p2, p5, p1
    @p4 v.st.w       [s1, #0], v0
    a.vread      v0, a0, s5
    @p2 v.st.w       [s11, #0], v0
__rctx_next:
    exit
