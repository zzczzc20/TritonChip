    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s8, [s1, #40]                   // in_ptr5: device_ptr64 at arg_base+40
    s.ld.d       s9, [s1, #48]                   // in_ptr6: device_ptr64 at arg_base+48
    s.ld.d       s10, [s1, #56]                  // out_ptr0: device_ptr64 at arg_base+56
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.add        v2, v1, v0
    v.movi       v0, #4096
    v.movi       v1, #0
    v.cmp.lt     p1, v2, v1
    v.cmp.lt     p2, v0, v1
    v.sub        v3, v1, v2
    @p1 v.sel        v4, v3, v2
    v.sub        v3, v1, v0
    @p2 v.sel        v5, v3, v0
    v.movi       v3, #12
    v.lshr       v5, v4, v3
    v.sub        v3, v1, v5
    @p1 v.sel        v1, v3, v5
    v.movi       v3, #0
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v0, v3
    v.sub        v4, v3, v2
    @p1 v.sel        v5, v4, v2
    v.sub        v4, v3, v0
    @p2 v.sel        v6, v4, v0
    v.movi       v0, #4095
    v.and        v4, v5, v0
    v.sub        v0, v3, v4
    @p1 v.sel        v3, v0, v4
    v.movi       v0, #128
    v.movi       v4, #0
    v.cmp.lt     p1, v2, v4
    v.cmp.lt     p2, v0, v4
    v.sub        v5, v4, v2
    @p1 v.sel        v6, v5, v2
    v.sub        v5, v4, v0
    @p2 v.sel        v7, v5, v0
    v.movi       v5, #127
    v.and        v7, v6, v5
    v.sub        v5, v4, v7
    @p1 v.sel        v4, v5, v7
    v.ld.gather.h v5, [s2, v4]                   // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v4, v5
    v.movi       v5, #64
    v.movi       v6, #0
    v.cmp.lt     p1, v1, v6
    v.cmp.lt     p2, v5, v6
    v.sub        v7, v6, v1
    @p1 v.sel        v8, v7, v1
    v.sub        v7, v6, v5
    @p2 v.sel        v9, v7, v5
    v.movi       v7, #63
    v.and        v9, v8, v7
    v.sub        v7, v6, v9
    @p1 v.sel        v6, v7, v9
    v.mul        v7, v6, v0
    v.movi       v6, #0
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v0, v6
    v.sub        v8, v6, v3
    @p1 v.sel        v9, v8, v3
    v.sub        v8, v6, v0
    @p2 v.sel        v10, v8, v0
    v.movi       v8, #7
    v.lshr       v10, v9, v8
    v.sub        v8, v6, v10
    @p1 v.sel        v6, v8, v10
    v.movi       v8, #8192
    v.mul        v9, v6, v8
    v.add        v6, v7, v9
    v.movi       v7, #0
    v.cmp.lt     p1, v3, v7
    v.cmp.lt     p2, v0, v7
    v.sub        v8, v7, v3
    @p1 v.sel        v9, v8, v3
    v.sub        v3, v7, v0
    @p2 v.sel        v8, v3, v0
    v.movi       v3, #127
    v.and        v8, v9, v3
    v.sub        v3, v7, v8
    @p1 v.sel        v7, v3, v8
    v.add        v3, v6, v7
    v.ld.gather.w v6, [s3, v3]                   // index is in elements (ISA sec 9.1)
    v.ld.gather.w v7, [s5, v3]                   // index is in elements (ISA sec 9.1)
    v.ld.gather.w v8, [s6, v3]                   // index is in elements (ISA sec 9.1)
    v.ld.gather.w v9, [s7, v3]                   // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v0, v3
    v.sub        v10, v3, v2
    @p1 v.sel        v11, v10, v2
    v.sub        v2, v3, v0
    @p2 v.sel        v10, v2, v0
    v.movi       v0, #7
    v.lshr       v2, v11, v0
    v.sub        v0, v3, v2
    @p1 v.sel        v3, v0, v2
    v.ld.gather.w v0, [s8, v3]                   // index is in elements (ISA sec 9.1)
    s.shli       s2, s1, #1                      // element offset -> bytes (x2)
    s.add        s1, s9, s2                      // &in_ptr6[...]
    v.ld.h       v2, [s1, #0]
    vf.cvt.bf16.f32 v3, v2
    v.movi       v2, #0
    v.cmp.lt     p1, v1, v2
    v.cmp.lt     p2, v5, v2
    v.sub        v10, v2, v1
    @p1 v.sel        v11, v10, v1
    v.sub        v1, v2, v5
    @p2 v.sel        v10, v1, v5
    v.movi       v1, #6
    v.lshr       v5, v11, v1
    v.sub        v1, v2, v5
    @p1 v.sel        v2, v1, v5
    v.movi       v1, #1
    v.cmp.eq     p1, v2, v1
    vf.add       v1, v6, v7
    v.movi       v5, #0
    v.cmp.eq     p2, v2, v5
    vf.add       v2, v8, v9
    v.movi       v5, #0
    @p2 v.sel        v6, v2, v5
    @p1 v.sel        v2, v1, v6
    .li       s1, #1124073472
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v5, v1                          // ISA 8.8: <= 2**-22 relative
    .li       s1, #1065353216
    v.splat      v6, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v7, v1, v5, v6
    vf.fms       v8, v5, v7, v5
    vf.neg       v7, v8                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v8, v7, v5
    vf.mul       v5, v0, v8                      // a/y: faithful quotient
    vf.fms       v7, v5, v1, v0
    vf.fms       v0, v7, v8, v5
    vf.neg       v1, v0                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v0, v1, v5
    .li       s1, #897988541
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v5, v0, v1
    v.rsqrt.approx v0, v5                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v1, v0, v0
    .li       s1, #1077936128
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v8, v5, v1, v7
    .li       s1, #3204448256
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v5, v0, v1
    vf.mul       v1, v5, v8                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v5, v1, v0
    vf.mul       v0, v2, v5
    vf.mul       v1, v4, v0
    vf.neg       v0, v3
    .li       s1, #1069066811
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v4, v0, v2
    vf.fms       v5, v0, v2, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v0, v4                         // ISA 8.8: <= 2**-22 relative
    .li       s1, #1060205080
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v4, v5, v2
    vf.fma       v2, v0, v4, v0                  // 2**t * 2**d
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v4, v2, v0
    .li       s1, #1065353216
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v2, v4, v0
    v.rcp.approx v0, v2                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v4, v2, v0, v6
    vf.fms       v5, v0, v4, v0
    vf.neg       v4, v5                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v5, v4, v0
    vf.mul       v0, v3, v5                      // a/y: faithful quotient
    vf.fms       v4, v0, v2, v3
    vf.fms       v2, v4, v5, v0
    vf.neg       v3, v2                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v2, v3, v0
    vf.mul       v0, v1, v2
    vf.cvt.f32.bf16 v1, v0
    s.add        s1, s10, s2                     // &out_ptr0[...]
    v.st.h       [s1, #0], v1
__rctx_next:
    exit
