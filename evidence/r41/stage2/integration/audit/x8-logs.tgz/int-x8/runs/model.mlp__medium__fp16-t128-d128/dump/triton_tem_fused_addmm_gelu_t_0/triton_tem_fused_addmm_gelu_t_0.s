    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, role_id
    s.movz       s2, #512
    s.rdspecial  s3, arg_base
    s.mul        s5, s1, s2
    s.ld.d       s1, [s3, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s2, arg_base
    s.rdspecial  s3, role_id
    s.movz       s6, #512
    s.add        s7, s1, s5                      // this context's own scratch
    s.ld.d       s1, [s2, #8]                    // arg_A: device_ptr64 at arg_base+8
    s.addi       s5, s7, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    .li       s7, #2147483647
    .li       s8, #2147483647
    s.movz       s9, #256
    s.movz       s10, #2
    .li       s11, #68719476752
    .li       s12, #8589934592
    s.rdspecial  s13, arg_base
    s.mul        s14, s3, s6
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    .li       s6, #2147483647
    .li       s15, #2147483647
    s.ld.d       s16, [s2, #16]                  // arg_B: device_ptr64 at arg_base+16
    s.movz       s17, #32
    s.movz       s18, #256
    s.ld.d       s19, [s2, #24]                  // out_ptr1: device_ptr64 at arg_base+24
    s.movz       s2, #0
    s.movz       s20, #0
    s.movz       s21, #0
    s.movz       s22, #0
    s.cmp.lt     s23, s17, s21
    s.st.d       [s5, #0], s1
    s.sub        s1, s22, s23
    s.movz       s21, #2
    s.st.d       [s5, #8], s7
    .li       s7, #68719476752
    .li       s22, #8589934592
    s.st.d       [s5, #16], s8
    s.xor        s8, s17, s1
    s.movz       s23, #0
    s.st.d       [s5, #48], s9
    s.movz       s9, #8
    s.movz       s23, #0
    s.st.d       [s5, #56], s10
    s.cmp.lt     s10, s4, s2
    s.movz       s2, #1
    s.sub        s23, s20, s10
    s.movz       s10, #0
    s.st.d       [s5, #88], s11
    s.xor        s11, s4, s23
    s.sub        s20, s8, s1
    s.sub        s8, s11, s23
    s.movz       s11, #0
    s.st.d       [s5, #104], s12
    s.lshri      s12, s8, #5
    fence.release.device
    td.load      d0, [s5]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.xor        s5, s23, s1
    s.movz       s1, #0
    s.movz       s20, #0
    s.ld.d       s23, [s13, #32]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.add        s13, s23, s14                   // this context's own scratch
    s.xor        s14, s12, s5
    s.cmp.lt     s23, s4, s11
    s.sub        s11, s14, s5
    s.muli       s5, s12, #32
    s.sub        s12, s9, s11
    s.addi       s14, s13, #256                  // TensorMap 1: a tile contiguous down its columns (built once, at entry)
    s.min.s      s13, s12, s2
    s.sub        s12, s20, s23
    s.cmp.lt     s20, s13, s10
    s.movz       s10, #0
    s.st.d       [s14, #0], s16
    s.sub        s16, s1, s20
    s.movz       s1, #1
    s.xor        s20, s4, s12
    s.st.d       [s14, #8], s6
    s.xor        s6, s13, s16
    s.sub        s23, s20, s12
    s.st.d       [s14, #16], s15
    s.sub        s15, s6, s16
    s.movz       s6, #0
    s.addi       s16, s10, #0
    s.st.d       [s14, #48], s18
    s.cmp.eq     s10, s15, s1
    s.sub        s1, s8, s5
    s.st.d       [s14, #56], s21
    s.addi       s1, s6, #0
    s.st.d       [s14, #88], s7
    s.st.d       [s14, #104], s22
    fence.release.device
    td.load      d1, [s14]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.mov        s16, s23
    br.nz        s10, sdiv_done_1
    s.movz       s5, #0
    s.movz       s6, #31
    s.mov        s16, s5
    s.addi       s5, s6, #0
sdiv_2:
    s.lshr       s6, s23, s5
    s.shli       s7, s1, #1
    s.andi       s8, s6, #1
    s.movz       s6, #0
    s.or         s10, s7, s8
    s.movz       s7, #1
    s.cmp.geu    s8, s10, s15
    s.shl        s14, s7, s5
    s.sub        s7, s6, s8
    s.subi       s6, s5, #1
    s.and        s8, s15, s7
    s.and        s18, s14, s7
    s.sub        s7, s10, s8
    s.or         s8, s16, s18
    s.mov        s1, s7
    s.mov        s16, s8
    s.mov        s5, s6
    s.movz       s6, #0
    s.cmp.ge     s7, s5, s6
    br.nz        s7, sdiv_2
sdiv_done_1:
    s.movz       s5, #0
    s.movz       s6, #0
    s.cmp.lt     s7, s4, s5
    s.movz       s5, #0
    s.sub        s8, s6, s7
    s.movz       s6, #0
    s.xor        s7, s4, s8
    s.movz       s4, #0
    s.sub        s10, s7, s8
    s.cmp.lt     s7, s13, s5
    s.lshri      s5, s10, #5
    s.movz       s14, #0
    s.muli       s15, s5, #32
    s.sub        s5, s4, s7
    s.movz       s4, #0
    s.cmp.lt     s7, s17, s14
    s.xor        s14, s13, s5
    s.sub        s13, s10, s15
    s.movz       s10, #0
    s.xor        s15, s13, s8
    s.xor        s13, s1, s12
    s.sub        s1, s15, s8
    s.sub        s8, s10, s7
    s.cmp.lt     s7, s1, s6
    s.sub        s6, s14, s5
    s.sub        s10, s4, s7
    s.movz       s4, #0
    s.xor        s7, s1, s10
    s.movz       s1, #1
    s.sub        s14, s13, s12
    s.xor        s12, s17, s8
    s.sub        s13, s7, s10
    s.movz       s7, #0
    s.addi       s15, s4, #0
    s.cmp.eq     s4, s6, s1
    s.add        s1, s11, s14
    s.sub        s11, s12, s8
    s.addi       s8, s7, #0
    s.mov        s15, s13
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.movz       s7, #31
    s.mov        s15, s4
    s.addi       s4, s7, #0
sdiv_4:
    s.lshr       s7, s13, s4
    s.shli       s11, s8, #1
    s.andi       s12, s7, #1
    s.movz       s7, #0
    s.or         s14, s11, s12
    s.movz       s11, #1
    s.cmp.geu    s12, s14, s6
    s.shl        s16, s11, s4
    s.sub        s11, s7, s12
    s.subi       s7, s4, #1
    s.and        s12, s6, s11
    s.and        s17, s16, s11
    s.sub        s11, s14, s12
    s.or         s12, s15, s17
    s.mov        s8, s11
    s.mov        s15, s12
    s.mov        s4, s7
    s.movz       s7, #0
    s.cmp.ge     s11, s4, s7
    br.nz        s11, sdiv_4
sdiv_done_3:
    s.xor        s4, s10, s5
    s.movz       s5, #16
    s.xor        s6, s15, s4
    s.mul        s7, s1, s5
    s.sub        s8, s6, s4
    s.movz       s4, #0
    s.mul        s6, s8, s5
    v.splat      v0, s1
    s.andi       s1, s7, #127
    v.splat      v1, s4
    v.splat      v2, s8
    s.andi       s8, s6, #511
    v.splat      v3, s4
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s7
    v.cmp.ge     p1, v0, v1
    v.splat      v0, s6
    v.splat      v1, s1
    v.cmp.ge     p1, v2, v3
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s8
    v.add        v6, v5, v4
    v.iota       v5                              // arange(0, VLEN)
    v.add        v6, v0, v4
    v.add        v0, v1, v2
    v.add        v0, v3, v5
    s.addi       s10, s4, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s4, s10, s9
    br.nz        s4, endfor_6
    s.mul        s4, s10, s5
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s11, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s12, s10, s2
    s.movz       s13, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s14, s1                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s4                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s14, s11
    mb.wait      s11
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s14, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s15, s8                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s16, s4                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s15, s14
    mb.wait      s14
    mb.arm       s4, b2, #0, #1                  // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.f16 a0, v56, v48, s4
    mb.wait      s4
    s.mov        s10, s12
    br.nz        s13, for_5
endfor_6:
    s.movz       s1, #0
    s.movz       s2, #0
    s.add        s5, s1, s6                      // the tile origin
    s.muli       s1, s6, #2                      // a runtime tile origin, x2
    s.add        s8, s2, s7                      // the tile origin
    s.movz       s2, #128
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s5
    s.movz       s5, #512
    v.splat      v2, s8
    v.splat      v3, s2
    v.add        v4, v0, v1
    v.splat      v0, s5
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v4, v0
    s.add        s2, s3, s1                      // the tile origin
    s.movz       s1, #0
    p.and        p3, p1, p2
    a.vread      v0, a0, s1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s2, #0]
    s.addi       s1, s8, #1
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s3, #0
    v.splat      v2, s1
    s.movz       s1, #1
    v.cmp.lt     p1, v2, v3
    vf.cvt.f16.f32 v2, v1
    p.and        p3, p1, p2
    s.addi       s5, s8, #2
    s.movz       s9, #1
    vf.add       v1, v0, v2
    v.splat      v0, s5
    s.movz       s5, #2
    v.cmp.lt     p1, v0, v3
    vf.cvt.f32.f16 v0, v1
    p.and        p4, p1, p2
    s.addi       s10, s8, #3
    s.movz       s12, #2
    vf.cvt.f16.f32 v1, v0
    v.splat      v0, s10
    s.movz       s10, #3
    a.vwrite     a1, s3, v1
    a.vread      v1, a0, s1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s1, s8, #4
    s.movz       s3, #3
    v.splat      v0, s1
    vf.cvt.f16.f32 v4, v2
    s.movz       s1, #4
    vf.add       v2, v1, v4
    vf.cvt.f32.f16 v1, v2
    vf.cvt.f16.f32 v2, v1
    a.vwrite     a1, s9, v2
    a.vread      v1, a0, s5
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s2, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s5, s8, #5
    s.movz       s9, #4
    v.splat      v0, s5
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #5
    vf.add       v2, v1, v4
    vf.cvt.f32.f16 v1, v2
    vf.cvt.f16.f32 v2, v1
    a.vwrite     a1, s12, v2
    a.vread      v1, a0, s10
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s10, s8, #6
    s.movz       s12, #5
    v.splat      v0, s10
    vf.cvt.f16.f32 v4, v2
    s.movz       s10, #6
    vf.add       v2, v1, v4
    vf.cvt.f32.f16 v1, v2
    vf.cvt.f16.f32 v2, v1
    a.vwrite     a1, s3, v2
    a.vread      v1, a0, s1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s2, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s1, s8, #7
    s.movz       s3, #6
    v.splat      v0, s1
    vf.cvt.f16.f32 v4, v2
    s.movz       s1, #7
    vf.add       v2, v1, v4
    vf.cvt.f32.f16 v1, v2
    vf.cvt.f16.f32 v2, v1
    a.vwrite     a1, s9, v2
    a.vread      v1, a0, s5
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s5, s8, #8
    s.movz       s9, #7
    v.splat      v0, s5
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #8
    vf.add       v2, v1, v4
    vf.cvt.f32.f16 v1, v2
    vf.cvt.f16.f32 v2, v1
    a.vwrite     a1, s12, v2
    a.vread      v1, a0, s10
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s2, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s10, s8, #9
    s.movz       s12, #8
    v.splat      v0, s10
    vf.cvt.f16.f32 v4, v2
    s.movz       s10, #9
    vf.add       v2, v1, v4
    vf.cvt.f32.f16 v1, v2
    vf.cvt.f16.f32 v2, v1
    a.vwrite     a1, s3, v2
    a.vread      v1, a0, s1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s1, s8, #10
    s.movz       s3, #9
    v.splat      v0, s1
    vf.cvt.f16.f32 v4, v2
    s.movz       s1, #10
    vf.add       v2, v1, v4
    vf.cvt.f32.f16 v1, v2
    vf.cvt.f16.f32 v2, v1
    a.vwrite     a1, s9, v2
    a.vread      v1, a0, s5
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s2, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s5, s8, #11
    s.movz       s9, #10
    v.splat      v0, s5
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #11
    vf.add       v2, v1, v4
    vf.cvt.f32.f16 v1, v2
    vf.cvt.f16.f32 v2, v1
    a.vwrite     a1, s12, v2
    a.vread      v1, a0, s10
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s10, s8, #12
    s.movz       s12, #11
    v.splat      v0, s10
    vf.cvt.f16.f32 v4, v2
    s.movz       s10, #12
    vf.add       v2, v1, v4
    vf.cvt.f32.f16 v1, v2
    vf.cvt.f16.f32 v2, v1
    a.vwrite     a1, s3, v2
    a.vread      v1, a0, s1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s2, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s1, s8, #13
    s.movz       s3, #12
    v.splat      v0, s1
    vf.cvt.f16.f32 v4, v2
    s.movz       s1, #13
    vf.add       v2, v1, v4
    vf.cvt.f32.f16 v1, v2
    vf.cvt.f16.f32 v2, v1
    a.vwrite     a1, s9, v2
    a.vread      v1, a0, s5
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s5, s8, #14
    s.movz       s9, #13
    v.splat      v0, s5
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #14
    vf.add       v2, v1, v4
    vf.cvt.f32.f16 v1, v2
    vf.cvt.f16.f32 v2, v1
    a.vwrite     a1, s12, v2
    a.vread      v1, a0, s10
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s2, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s10, s8, #15
    s.movz       s12, #14
    v.splat      v0, s10
    vf.cvt.f16.f32 v4, v2
    s.movz       s10, #15
    .li       s13, #1027024659
    v.splat      v2, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s13, #1061962282
    v.splat      v5, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v6, v1, v4
    .li       s13, #1056964608
    v.splat      v1, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cvt.f32.f16 v4, v6
    vf.cvt.f16.f32 v6, v4
    a.vwrite     a1, s3, v6
    a.vread      v4, a0, s1
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v6, [s2, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.movz       s1, #15
    s.movz       s3, #0
    vf.cvt.f16.f32 v0, v6
    vf.add       v6, v4, v0
    vf.cvt.f32.f16 v0, v6
    vf.cvt.f16.f32 v4, v0
    a.vwrite     a1, s9, v4
    a.vread      v0, a0, s5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s2, #0]
    s.movz       s5, #0
    s.movz       s9, #0
    vf.cvt.f16.f32 v6, v4
    vf.add       v4, v0, v6
    vf.cvt.f32.f16 v0, v4
    vf.cvt.f16.f32 v4, v0
    a.vwrite     a1, s12, v4
    a.vread      v0, a0, s10
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s2, #0]
    s.movz       s2, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s10, #0
    s.movz       s12, #1
    vf.cvt.f16.f32 v6, v4
    vf.add       v4, v0, v6
    vf.cvt.f32.f16 v0, v4
    vf.cvt.f16.f32 v4, v0
    a.vwrite     a1, s1, v4
    a.vread      v0, a1, s3
    a.vread      v4, a1, s5
    a.vread      v6, a1, s9
    a.vread      v7, a1, s2
    vf.mul       v8, v4, v6
    s.movz       s1, #1
    s.movz       s2, #1
    s.movz       s3, #1
    vf.mul       v4, v8, v7
    s.movz       s5, #1
    s.movz       s9, #2
    vf.mul       v6, v4, v2
    vf.add       v4, v0, v6
    vf.mul       v0, v4, v5
    a.vwrite     a2, s10, v0
    a.vread      v0, a1, s12
    a.vread      v4, a1, s1
    a.vread      v6, a1, s2
    a.vread      v7, a1, s3
    vf.mul       v8, v4, v6
    s.movz       s1, #2
    s.movz       s2, #2
    s.movz       s3, #2
    vf.mul       v4, v8, v7
    s.movz       s10, #2
    s.movz       s12, #3
    vf.mul       v6, v4, v2
    vf.add       v4, v0, v6
    vf.mul       v0, v4, v5
    a.vwrite     a2, s5, v0
    a.vread      v0, a1, s9
    a.vread      v4, a1, s1
    a.vread      v6, a1, s2
    a.vread      v7, a1, s3
    vf.mul       v8, v4, v6
    s.movz       s1, #3
    s.movz       s2, #3
    s.movz       s3, #3
    vf.mul       v4, v8, v7
    s.movz       s5, #3
    s.movz       s9, #4
    vf.mul       v6, v4, v2
    vf.add       v4, v0, v6
    vf.mul       v0, v4, v5
    a.vwrite     a2, s10, v0
    a.vread      v0, a1, s12
    a.vread      v4, a1, s1
    a.vread      v6, a1, s2
    a.vread      v7, a1, s3
    vf.mul       v8, v4, v6
    s.movz       s1, #4
    s.movz       s2, #4
    s.movz       s3, #4
    vf.mul       v4, v8, v7
    s.movz       s10, #4
    s.movz       s12, #5
    vf.mul       v6, v4, v2
    vf.add       v4, v0, v6
    vf.mul       v0, v4, v5
    a.vwrite     a2, s5, v0
    a.vread      v0, a1, s9
    a.vread      v4, a1, s1
    a.vread      v6, a1, s2
    a.vread      v7, a1, s3
    vf.mul       v8, v4, v6
    s.movz       s1, #5
    s.movz       s2, #5
    s.movz       s3, #5
    vf.mul       v4, v8, v7
    s.movz       s5, #5
    s.movz       s9, #6
    vf.mul       v6, v4, v2
    vf.add       v4, v0, v6
    vf.mul       v0, v4, v5
    a.vwrite     a2, s10, v0
    a.vread      v0, a1, s12
    a.vread      v4, a1, s1
    a.vread      v6, a1, s2
    a.vread      v7, a1, s3
    vf.mul       v8, v4, v6
    s.movz       s1, #6
    s.movz       s2, #6
    s.movz       s3, #6
    vf.mul       v4, v8, v7
    s.movz       s10, #6
    s.movz       s12, #7
    vf.mul       v6, v4, v2
    vf.add       v4, v0, v6
    vf.mul       v0, v4, v5
    a.vwrite     a2, s5, v0
    a.vread      v0, a1, s9
    a.vread      v4, a1, s1
    a.vread      v6, a1, s2
    a.vread      v7, a1, s3
    vf.mul       v8, v4, v6
    s.movz       s1, #7
    s.movz       s2, #7
    s.movz       s3, #7
    vf.mul       v4, v8, v7
    s.movz       s5, #7
    s.movz       s9, #8
    vf.mul       v6, v4, v2
    vf.add       v4, v0, v6
    vf.mul       v0, v4, v5
    a.vwrite     a2, s10, v0
    a.vread      v0, a1, s12
    a.vread      v4, a1, s1
    a.vread      v6, a1, s2
    a.vread      v7, a1, s3
    vf.mul       v8, v4, v6
    s.movz       s1, #8
    s.movz       s2, #8
    s.movz       s3, #8
    vf.mul       v4, v8, v7
    s.movz       s10, #8
    s.movz       s12, #9
    vf.mul       v6, v4, v2
    vf.add       v4, v0, v6
    vf.mul       v0, v4, v5
    a.vwrite     a2, s5, v0
    a.vread      v0, a1, s9
    a.vread      v4, a1, s1
    a.vread      v6, a1, s2
    a.vread      v7, a1, s3
    vf.mul       v8, v4, v6
    s.movz       s1, #9
    s.movz       s2, #9
    s.movz       s3, #9
    vf.mul       v4, v8, v7
    s.movz       s5, #9
    s.movz       s9, #10
    vf.mul       v6, v4, v2
    vf.add       v4, v0, v6
    vf.mul       v0, v4, v5
    a.vwrite     a2, s10, v0
    a.vread      v0, a1, s12
    a.vread      v4, a1, s1
    a.vread      v6, a1, s2
    a.vread      v7, a1, s3
    vf.mul       v8, v4, v6
    s.movz       s1, #10
    s.movz       s2, #10
    s.movz       s3, #10
    vf.mul       v4, v8, v7
    s.movz       s10, #10
    s.movz       s12, #11
    vf.mul       v6, v4, v2
    vf.add       v4, v0, v6
    vf.mul       v0, v4, v5
    a.vwrite     a2, s5, v0
    a.vread      v0, a1, s9
    a.vread      v4, a1, s1
    a.vread      v6, a1, s2
    a.vread      v7, a1, s3
    vf.mul       v8, v4, v6
    s.movz       s1, #11
    s.movz       s2, #11
    s.movz       s3, #11
    vf.mul       v4, v8, v7
    s.movz       s5, #11
    s.movz       s9, #12
    vf.mul       v6, v4, v2
    vf.add       v4, v0, v6
    vf.mul       v0, v4, v5
    a.vwrite     a2, s10, v0
    a.vread      v0, a1, s12
    a.vread      v4, a1, s1
    a.vread      v6, a1, s2
    a.vread      v7, a1, s3
    vf.mul       v8, v4, v6
    s.movz       s1, #12
    s.movz       s2, #12
    s.movz       s3, #12
    vf.mul       v4, v8, v7
    s.movz       s10, #12
    s.movz       s12, #13
    vf.mul       v6, v4, v2
    vf.add       v4, v0, v6
    vf.mul       v0, v4, v5
    a.vwrite     a2, s5, v0
    a.vread      v0, a1, s9
    a.vread      v4, a1, s1
    a.vread      v6, a1, s2
    a.vread      v7, a1, s3
    vf.mul       v8, v4, v6
    s.movz       s1, #13
    s.movz       s2, #13
    s.movz       s3, #13
    vf.mul       v4, v8, v7
    s.movz       s5, #13
    s.movz       s9, #14
    vf.mul       v6, v4, v2
    vf.add       v4, v0, v6
    .li       s13, #3221225472
    v.splat      v0, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v6, v4, v5
    a.vwrite     a2, s10, v6
    a.vread      v4, a1, s12
    a.vread      v6, a1, s1
    a.vread      v7, a1, s2
    a.vread      v8, a1, s3
    vf.mul       v9, v6, v7
    s.movz       s1, #14
    s.movz       s2, #14
    s.movz       s3, #14
    vf.mul       v6, v9, v8
    s.movz       s10, #14
    s.movz       s12, #15
    .li       s13, #1069066811
    v.splat      v7, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v8, v6, v2
    .li       s13, #1060205080
    v.splat      v6, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v9, v4, v8
    vf.mul       v4, v9, v5
    a.vwrite     a2, s5, v4
    a.vread      v4, a1, s9
    a.vread      v8, a1, s1
    a.vread      v9, a1, s2
    a.vread      v10, a1, s3
    vf.mul       v11, v8, v9
    s.movz       s1, #15
    s.movz       s2, #15
    s.movz       s3, #15
    vf.mul       v8, v11, v10
    s.movz       s5, #15
    s.movz       s9, #0
    vf.mul       v9, v8, v2
    vf.add       v8, v4, v9
    vf.mul       v4, v8, v5
    a.vwrite     a2, s10, v4
    a.vread      v4, a1, s12
    a.vread      v8, a1, s1
    a.vread      v9, a1, s2
    a.vread      v10, a1, s3
    vf.mul       v11, v8, v9
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s1, #0
    s.movz       s2, #1
    s.movz       s3, #1
    vf.mul       v8, v11, v10
    s.movz       s10, #2
    s.movz       s12, #2
    vf.mul       v9, v8, v2
    vf.add       v2, v4, v9
    vf.mul       v4, v2, v5
    a.vwrite     a2, s5, v4
    a.vread      v2, a2, s9
    s.movz       s5, #3
    vf.abs       v4, v2
    s.movz       s9, #3
    vf.mul       v2, v4, v0
    vf.mul       v4, v2, v7
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v2, v7, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v8, v6
    vf.fma       v4, v5, v2, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v2, v4, v5
    a.vwrite     a3, s1, v2
    a.vread      v2, a2, s2
    s.movz       s1, #4
    vf.abs       v4, v2
    s.movz       s2, #4
    vf.mul       v2, v4, v0
    vf.mul       v4, v2, v7
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v2, v7, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v8, v6
    vf.fma       v4, v5, v2, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v2, v4, v5
    a.vwrite     a3, s3, v2
    a.vread      v2, a2, s10
    s.movz       s3, #5
    vf.abs       v4, v2
    s.movz       s10, #5
    vf.mul       v2, v4, v0
    vf.mul       v4, v2, v7
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v2, v7, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v8, v6
    vf.fma       v4, v5, v2, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v2, v4, v5
    a.vwrite     a3, s12, v2
    a.vread      v2, a2, s5
    s.movz       s5, #6
    vf.abs       v4, v2
    s.movz       s12, #6
    vf.mul       v2, v4, v0
    vf.mul       v4, v2, v7
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v2, v7, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v8, v6
    vf.fma       v4, v5, v2, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v2, v4, v5
    a.vwrite     a3, s9, v2
    a.vread      v2, a2, s1
    s.movz       s1, #7
    vf.abs       v4, v2
    s.movz       s9, #7
    vf.mul       v2, v4, v0
    vf.mul       v4, v2, v7
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v2, v7, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v8, v6
    vf.fma       v4, v5, v2, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v2, v4, v5
    a.vwrite     a3, s2, v2
    a.vread      v2, a2, s3
    s.movz       s2, #8
    vf.abs       v4, v2
    s.movz       s3, #8
    vf.mul       v2, v4, v0
    vf.mul       v4, v2, v7
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v2, v7, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v8, v6
    vf.fma       v4, v5, v2, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v2, v4, v5
    a.vwrite     a3, s10, v2
    a.vread      v2, a2, s5
    s.movz       s5, #9
    vf.abs       v4, v2
    s.movz       s10, #9
    vf.mul       v2, v4, v0
    vf.mul       v4, v2, v7
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v2, v7, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v8, v6
    vf.fma       v4, v5, v2, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v2, v4, v5
    a.vwrite     a3, s12, v2
    a.vread      v2, a2, s1
    s.movz       s1, #10
    vf.abs       v4, v2
    s.movz       s12, #10
    vf.mul       v2, v4, v0
    vf.mul       v4, v2, v7
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v2, v7, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v8, v6
    vf.fma       v4, v5, v2, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v2, v4, v5
    a.vwrite     a3, s9, v2
    a.vread      v2, a2, s2
    s.movz       s2, #11
    vf.abs       v4, v2
    s.movz       s9, #11
    vf.mul       v2, v4, v0
    vf.mul       v4, v2, v7
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v2, v7, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v8, v6
    vf.fma       v4, v5, v2, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v2, v4, v5
    a.vwrite     a3, s3, v2
    a.vread      v2, a2, s5
    s.movz       s3, #12
    vf.abs       v4, v2
    s.movz       s5, #12
    vf.mul       v2, v4, v0
    vf.mul       v4, v2, v7
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v2, v7, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v8, v6
    vf.fma       v4, v5, v2, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v2, v4, v5
    a.vwrite     a3, s10, v2
    a.vread      v2, a2, s1
    s.movz       s1, #13
    vf.abs       v4, v2
    s.movz       s10, #13
    vf.mul       v2, v4, v0
    vf.mul       v4, v2, v7
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v2, v7, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v8, v6
    vf.fma       v4, v5, v2, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v2, v4, v5
    a.vwrite     a3, s12, v2
    a.vread      v2, a2, s2
    s.movz       s2, #14
    vf.abs       v4, v2
    s.movz       s12, #14
    vf.mul       v2, v4, v0
    vf.mul       v4, v2, v7
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v2, v7, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v8, v6
    vf.fma       v4, v5, v2, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v2, v4, v5
    a.vwrite     a3, s9, v2
    a.vread      v2, a2, s3
    s.movz       s3, #15
    vf.abs       v4, v2
    s.movz       s9, #15
    vf.mul       v2, v4, v0
    .li       s13, #1065353216
    v.splat      v4, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v5, v2, v7
    .li       s13, #1065353216
    v.splat      v8, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.exp2.approx v9, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v2, v7, v5                 // the exact rounding error of x*log2(e)
    vf.mul       v2, v10, v6
    vf.fma       v5, v9, v2, v9                  // 2**t * 2**d
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v2, v5, v9
    a.vwrite     a3, s5, v2
    a.vread      v2, a2, s1
    s.movz       s1, #0
    vf.abs       v5, v2
    s.movz       s5, #0
    .li       s13, #1065353216
    v.splat      v2, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v9, v5, v0
    vf.mul       v5, v9, v7
    v.exp2.approx v10, v5                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v11, v9, v7, v5                 // the exact rounding error of x*log2(e)
    vf.mul       v5, v11, v6
    vf.fma       v9, v10, v5, v10                // 2**t * 2**d
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v5, v9, v10
    a.vwrite     a3, s10, v5
    a.vread      v5, a2, s2
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s2, #0
    vf.abs       v9, v5
    s.movz       s10, #1
    vf.mul       v5, v9, v0
    vf.mul       v9, v5, v7
    v.exp2.approx v10, v9                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v11, v5, v7, v9                 // the exact rounding error of x*log2(e)
    vf.mul       v5, v11, v6
    vf.fma       v9, v10, v5, v10                // 2**t * 2**d
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v5, v9, v10
    a.vwrite     a3, s12, v5
    a.vread      v5, a2, s3
    s.movz       s3, #1
    vf.abs       v9, v5
    s.movz       s12, #1
    vf.mul       v5, v9, v0
    vf.mul       v0, v5, v7
    v.exp2.approx v9, v0                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v5, v7, v0                 // the exact rounding error of x*log2(e)
    vf.mul       v0, v10, v6
    vf.fma       v5, v9, v0, v9                  // 2**t * 2**d
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v0, v5, v9
    a.vwrite     a3, s9, v0
    a.vread      v0, a3, s1
    a.vread      v5, a3, s5
    vf.sub       v6, v4, v0
    vf.add       v0, v5, v8
    s.movz       s1, #2
    s.movz       s5, #2
    s.movz       s9, #2
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v0, v5, v2
    vf.fms       v0, v5, v7, v5
    vf.neg       v7, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v0, v7, v5
    vf.mul       v5, v6, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s2, v5
    a.vread      v0, a3, s10
    a.vread      v5, a3, s3
    vf.sub       v6, v4, v0
    vf.add       v0, v5, v8
    s.movz       s2, #3
    s.movz       s3, #3
    s.movz       s10, #3
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v0, v5, v2
    vf.fms       v0, v5, v7, v5
    vf.neg       v7, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v0, v7, v5
    vf.mul       v5, v6, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s12, v5
    a.vread      v0, a3, s1
    a.vread      v5, a3, s5
    vf.sub       v6, v4, v0
    vf.add       v0, v5, v8
    s.movz       s1, #4
    s.movz       s5, #4
    s.movz       s12, #4
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v0, v5, v2
    vf.fms       v0, v5, v7, v5
    vf.neg       v7, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v0, v7, v5
    vf.mul       v5, v6, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s9, v5
    a.vread      v0, a3, s2
    a.vread      v5, a3, s3
    vf.sub       v6, v4, v0
    vf.add       v0, v5, v8
    s.movz       s2, #5
    s.movz       s3, #5
    s.movz       s9, #5
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v0, v5, v2
    vf.fms       v0, v5, v7, v5
    vf.neg       v7, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v0, v7, v5
    vf.mul       v5, v6, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s10, v5
    a.vread      v0, a3, s1
    a.vread      v5, a3, s5
    vf.sub       v6, v4, v0
    vf.add       v0, v5, v8
    s.movz       s1, #6
    s.movz       s5, #6
    s.movz       s10, #6
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v0, v5, v2
    vf.fms       v0, v5, v7, v5
    vf.neg       v7, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v0, v7, v5
    vf.mul       v5, v6, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s12, v5
    a.vread      v0, a3, s2
    a.vread      v5, a3, s3
    vf.sub       v6, v4, v0
    vf.add       v0, v5, v8
    s.movz       s2, #7
    s.movz       s3, #7
    s.movz       s12, #7
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v0, v5, v2
    vf.fms       v0, v5, v7, v5
    vf.neg       v7, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v0, v7, v5
    vf.mul       v5, v6, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s9, v5
    a.vread      v0, a3, s1
    a.vread      v5, a3, s5
    vf.sub       v6, v4, v0
    vf.add       v0, v5, v8
    s.movz       s1, #8
    s.movz       s5, #8
    s.movz       s9, #8
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v0, v5, v2
    vf.fms       v0, v5, v7, v5
    vf.neg       v7, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v0, v7, v5
    vf.mul       v5, v6, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s10, v5
    a.vread      v0, a3, s2
    a.vread      v5, a3, s3
    vf.sub       v6, v4, v0
    vf.add       v0, v5, v8
    s.movz       s2, #9
    s.movz       s3, #9
    s.movz       s10, #9
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v0, v5, v2
    vf.fms       v0, v5, v7, v5
    vf.neg       v7, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v0, v7, v5
    vf.mul       v5, v6, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s12, v5
    a.vread      v0, a3, s1
    a.vread      v5, a3, s5
    vf.sub       v6, v4, v0
    vf.add       v0, v5, v8
    s.movz       s1, #10
    s.movz       s5, #10
    s.movz       s12, #10
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v0, v5, v2
    vf.fms       v0, v5, v7, v5
    vf.neg       v7, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v0, v7, v5
    vf.mul       v5, v6, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s9, v5
    a.vread      v0, a3, s2
    a.vread      v5, a3, s3
    vf.sub       v6, v4, v0
    vf.add       v0, v5, v8
    s.movz       s2, #11
    s.movz       s3, #11
    s.movz       s9, #11
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v0, v5, v2
    vf.fms       v0, v5, v7, v5
    vf.neg       v7, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v0, v7, v5
    vf.mul       v5, v6, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s10, v5
    a.vread      v0, a3, s1
    a.vread      v5, a3, s5
    vf.sub       v6, v4, v0
    vf.add       v0, v5, v8
    s.movz       s1, #12
    s.movz       s5, #12
    s.movz       s10, #12
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v0, v5, v2
    vf.fms       v0, v5, v7, v5
    vf.neg       v7, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v0, v7, v5
    vf.mul       v5, v6, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s12, v5
    a.vread      v0, a3, s2
    a.vread      v5, a3, s3
    vf.sub       v6, v4, v0
    vf.add       v0, v5, v8
    s.movz       s2, #13
    s.movz       s3, #13
    s.movz       s12, #13
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v0, v5, v2
    vf.fms       v0, v5, v7, v5
    vf.neg       v7, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v0, v7, v5
    vf.mul       v5, v6, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s9, v5
    a.vread      v0, a3, s1
    a.vread      v5, a3, s5
    vf.sub       v6, v4, v0
    vf.add       v0, v5, v8
    s.movz       s1, #14
    s.movz       s5, #14
    s.movz       s9, #14
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v0, v5, v2
    vf.fms       v0, v5, v7, v5
    vf.neg       v7, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v0, v7, v5
    v.movi       v5, #0
    vf.mul       v7, v6, v0                      // a/y as a refined reciprocal (ISA has no divide)
    .li       s13, #1065353216
    v.splat      v0, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    a.vwrite     a4, s10, v7
    a.vread      v6, a3, s2
    a.vread      v7, a3, s3
    vf.sub       v9, v4, v6
    vf.add       v6, v7, v8
    s.movz       s2, #15
    s.movz       s3, #15
    s.movz       s10, #15
    v.rcp.approx v7, v6                          // ISA 8.8: <= 2**-22 relative
    s.muli       s13, s6, #2                     // a runtime tile origin, x2
    s.muli       s6, s7, #1024                   // a runtime tile origin, x1024
    s.add        s7, s19, s13                    // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s13, #0
    s.add        s15, s7, s6                     // the tile origin
    s.movz       s6, #0
    vf.fms       v10, v6, v7, v2
    vf.fms       v6, v7, v10, v7
    vf.neg       v10, v6                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v10, v10
    @p1 v.sel        v6, v10, v7
    vf.mul       v7, v9, v6                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s12, v7
    a.vread      v6, a3, s1
    a.vread      v7, a3, s5
    vf.sub       v9, v4, v6
    vf.add       v6, v7, v8
    s.movz       s1, #0
    s.movz       s5, #0
    v.splat      v7, s8
    v.rcp.approx v10, v6                         // ISA 8.8: <= 2**-22 relative
    v.cmp.lt     p1, v7, v3
    p.and        p3, p1, p2
    s.movz       s7, #1
    vf.fms       v7, v6, v10, v2
    vf.fms       v6, v10, v7, v10
    vf.neg       v7, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v6, v7, v10
    vf.mul       v7, v9, v6                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s9, v7
    a.vread      v6, a3, s2
    a.vread      v7, a3, s3
    vf.sub       v9, v4, v6
    vf.add       v4, v7, v8
    s.movz       s2, #1
    s.movz       s3, #1
    s.movz       s9, #1
    v.rcp.approx v6, v4                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v4, v6, v2
    vf.fms       v2, v6, v7, v6
    vf.neg       v4, v2                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v2, v4, v6
    vf.mul       v4, v9, v2                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s10, v4
    a.vread      v2, a1, s13
    a.vread      v4, a2, s6
    a.vread      v6, a4, s1
    a.vread      v7, a4, s5
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.addi       s1, s8, #1
    @p1 v.sel        v2, v8, v7
    v.splat      v6, s1
    vf.add       v7, v2, v0
    v.cmp.lt     p1, v6, v3
    s.addi       s1, s15, #1024                  // row 1
    p.and        p4, p1, p2
    vf.mul       v2, v4, v7
    s.movz       s5, #2
    s.movz       s6, #2
    s.movz       s10, #2
    vf.cvt.f32.f16 v4, v2
    s.movz       s12, #2
    @p3 v.st.h       [s15, #0], v4
    a.vread      v2, a1, s7
    a.vread      v4, a2, s2
    a.vread      v6, a4, s3
    a.vread      v7, a4, s9
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.addi       s2, s8, #2
    @p1 v.sel        v2, v8, v7
    v.splat      v6, s2
    vf.add       v7, v2, v0
    v.cmp.lt     p1, v6, v3
    s.addi       s2, s15, #2048                  // row 2
    p.and        p3, p1, p2
    vf.mul       v2, v4, v7
    s.movz       s3, #3
    s.movz       s7, #3
    s.movz       s9, #3
    vf.cvt.f32.f16 v4, v2
    @p4 v.st.h       [s1, #0], v4
    a.vread      v2, a1, s5
    a.vread      v4, a2, s6
    a.vread      v6, a4, s10
    a.vread      v7, a4, s12
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.movz       s1, #3
    @p1 v.sel        v2, v8, v7
    s.addi       s5, s8, #3
    vf.add       v6, v2, v0
    v.splat      v2, s5
    s.addi       s5, s15, #3072                  // row 3
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v4, v6
    p.and        p4, p1, p2
    s.movz       s6, #4
    s.movz       s10, #4
    vf.cvt.f32.f16 v4, v2
    s.movz       s12, #4
    @p3 v.st.h       [s2, #0], v4
    a.vread      v2, a1, s3
    a.vread      v4, a2, s7
    a.vread      v6, a4, s9
    a.vread      v7, a4, s1
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.movz       s1, #4
    @p1 v.sel        v2, v8, v7
    s.addi       s2, s8, #4
    vf.add       v6, v2, v0
    v.splat      v2, s2
    s.addi       s2, s15, #4096                  // row 4
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v4, v6
    p.and        p3, p1, p2
    s.movz       s3, #5
    s.movz       s7, #5
    vf.cvt.f32.f16 v4, v2
    s.movz       s9, #5
    @p4 v.st.h       [s5, #0], v4
    a.vread      v2, a1, s6
    a.vread      v4, a2, s10
    a.vread      v6, a4, s12
    a.vread      v7, a4, s1
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.movz       s1, #5
    @p1 v.sel        v2, v8, v7
    s.addi       s5, s8, #5
    vf.add       v6, v2, v0
    v.splat      v2, s5
    s.addi       s5, s15, #5120                  // row 5
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v4, v6
    p.and        p4, p1, p2
    s.movz       s6, #6
    s.movz       s10, #6
    vf.cvt.f32.f16 v4, v2
    s.movz       s12, #6
    @p3 v.st.h       [s2, #0], v4
    a.vread      v2, a1, s3
    a.vread      v4, a2, s7
    a.vread      v6, a4, s9
    a.vread      v7, a4, s1
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.movz       s1, #6
    @p1 v.sel        v2, v8, v7
    s.addi       s2, s8, #6
    vf.add       v6, v2, v0
    v.splat      v2, s2
    s.addi       s2, s15, #6144                  // row 6
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v4, v6
    p.and        p3, p1, p2
    s.movz       s3, #7
    s.movz       s7, #7
    vf.cvt.f32.f16 v4, v2
    s.movz       s9, #7
    @p4 v.st.h       [s5, #0], v4
    a.vread      v2, a1, s6
    a.vread      v4, a2, s10
    a.vread      v6, a4, s12
    a.vread      v7, a4, s1
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.movz       s1, #7
    @p1 v.sel        v2, v8, v7
    s.addi       s5, s8, #7
    vf.add       v6, v2, v0
    v.splat      v2, s5
    s.addi       s5, s15, #7168                  // row 7
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v4, v6
    p.and        p4, p1, p2
    s.movz       s6, #8
    s.movz       s10, #8
    vf.cvt.f32.f16 v4, v2
    s.movz       s12, #8
    @p3 v.st.h       [s2, #0], v4
    a.vread      v2, a1, s3
    a.vread      v4, a2, s7
    a.vread      v6, a4, s9
    a.vread      v7, a4, s1
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.movz       s1, #8
    @p1 v.sel        v2, v8, v7
    s.addi       s2, s8, #8
    vf.add       v6, v2, v0
    v.splat      v2, s2
    s.addi       s2, s15, #8192                  // row 8
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v4, v6
    p.and        p3, p1, p2
    s.movz       s3, #9
    s.movz       s7, #9
    vf.cvt.f32.f16 v4, v2
    s.movz       s9, #9
    @p4 v.st.h       [s5, #0], v4
    a.vread      v2, a1, s6
    a.vread      v4, a2, s10
    a.vread      v6, a4, s12
    a.vread      v7, a4, s1
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.movz       s1, #9
    @p1 v.sel        v2, v8, v7
    s.addi       s5, s8, #9
    vf.add       v6, v2, v0
    v.splat      v2, s5
    s.addi       s5, s15, #9216                  // row 9
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v4, v6
    p.and        p4, p1, p2
    s.movz       s6, #10
    s.movz       s10, #10
    vf.cvt.f32.f16 v4, v2
    s.movz       s12, #10
    @p3 v.st.h       [s2, #0], v4
    a.vread      v2, a1, s3
    a.vread      v4, a2, s7
    a.vread      v6, a4, s9
    a.vread      v7, a4, s1
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.movz       s1, #10
    @p1 v.sel        v2, v8, v7
    s.addi       s2, s8, #10
    vf.add       v6, v2, v0
    v.splat      v2, s2
    s.addi       s2, s15, #10240                 // row 10
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v4, v6
    p.and        p3, p1, p2
    s.movz       s3, #11
    s.movz       s7, #11
    vf.cvt.f32.f16 v4, v2
    s.movz       s9, #11
    @p4 v.st.h       [s5, #0], v4
    a.vread      v2, a1, s6
    a.vread      v4, a2, s10
    a.vread      v6, a4, s12
    a.vread      v7, a4, s1
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.movz       s1, #11
    @p1 v.sel        v2, v8, v7
    s.addi       s5, s8, #11
    vf.add       v6, v2, v0
    v.splat      v2, s5
    s.addi       s5, s15, #11264                 // row 11
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v4, v6
    p.and        p4, p1, p2
    s.movz       s6, #12
    s.movz       s10, #12
    vf.cvt.f32.f16 v4, v2
    s.movz       s12, #12
    @p3 v.st.h       [s2, #0], v4
    a.vread      v2, a1, s3
    a.vread      v4, a2, s7
    a.vread      v6, a4, s9
    a.vread      v7, a4, s1
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.movz       s1, #12
    @p1 v.sel        v2, v8, v7
    s.addi       s2, s8, #12
    vf.add       v6, v2, v0
    v.splat      v2, s2
    s.addi       s2, s15, #12288                 // row 12
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v4, v6
    p.and        p3, p1, p2
    s.movz       s3, #13
    s.movz       s7, #13
    vf.cvt.f32.f16 v4, v2
    s.movz       s9, #13
    @p4 v.st.h       [s5, #0], v4
    a.vread      v2, a1, s6
    a.vread      v4, a2, s10
    a.vread      v6, a4, s12
    a.vread      v7, a4, s1
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.movz       s1, #13
    @p1 v.sel        v2, v8, v7
    s.addi       s5, s8, #13
    vf.add       v6, v2, v0
    v.splat      v2, s5
    s.addi       s5, s15, #13312                 // row 13
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v4, v6
    p.and        p4, p1, p2
    s.movz       s6, #14
    s.movz       s10, #14
    vf.cvt.f32.f16 v4, v2
    s.movz       s12, #14
    @p3 v.st.h       [s2, #0], v4
    a.vread      v2, a1, s3
    a.vread      v4, a2, s7
    a.vread      v6, a4, s9
    a.vread      v7, a4, s1
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.movz       s1, #14
    @p1 v.sel        v2, v8, v7
    s.addi       s2, s8, #14
    vf.add       v6, v2, v0
    v.splat      v2, s2
    s.addi       s2, s15, #14336                 // row 14
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v4, v6
    p.and        p3, p1, p2
    s.movz       s3, #15
    s.movz       s7, #15
    vf.cvt.f32.f16 v4, v2
    s.movz       s9, #15
    s.addi       s13, s8, #15
    s.addi       s8, s15, #15360                 // row 15
    @p4 v.st.h       [s5, #0], v4
    a.vread      v2, a1, s6
    a.vread      v4, a2, s10
    a.vread      v6, a4, s12
    a.vread      v7, a4, s1
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.movz       s1, #15
    @p1 v.sel        v2, v8, v7
    v.splat      v6, s13
    vf.add       v7, v2, v0
    v.cmp.lt     p1, v6, v3
    p.and        p4, p1, p2
    vf.mul       v2, v4, v7
    vf.cvt.f32.f16 v3, v2
    @p3 v.st.h       [s2, #0], v3
    a.vread      v2, a1, s3
    a.vread      v3, a2, s7
    a.vread      v4, a4, s9
    a.vread      v6, a4, s1
    vf.neg       v7, v4
    vf.cmp.lt    p1, v3, v5
    vf.mul       v3, v2, v1
    @p1 v.sel        v1, v7, v6
    vf.add       v2, v1, v0
    vf.mul       v0, v3, v2
    vf.cvt.f32.f16 v1, v0
    @p4 v.st.h       [s8, #0], v1
__rctx_next:
    exit
