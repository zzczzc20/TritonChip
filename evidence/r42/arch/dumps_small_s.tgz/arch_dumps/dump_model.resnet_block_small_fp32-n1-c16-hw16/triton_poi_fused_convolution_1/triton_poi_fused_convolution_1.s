    s.rdspecial  s1, role_id
    s.rdspecial  s2, npid.x
__rctx_program:
    s.rdspecial  s3, arg_base
    s.ld.d       s4, [s3, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s5, [s3, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.rdspecial  s3, pid.y
    s.movz       s6, #16
    s.shli       s7, s3, #4                      // x16 as a shift
    s.shli       s3, s1, #4                      // x16 as a shift
    s.muli       s8, s3, #4                      // a runtime tile origin, x4
    s.add        s9, s4, s8                      // the tile origin
    s.muli       s4, s7, #36                     // a runtime tile origin, x36
    s.add        s8, s9, s4                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.rdspecial  s4, arg_base
    s.ld.d       s9, [s4, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s4, role_id
    s.movz       s10, #1024
    s.mul        s11, s4, s10
    s.add        s4, s9, s11                     // this context's own scratch
    s.addi       s9, s4, #0
    s.movz       s10, #0
    v.splat      v0, s10
    s.add        s11, s10, s7                    // the tile origin
    v.splat      v1, s11
    v.splat      v2, s6
    v.movi       v3, #0
    v.cmp.lt     p1, v1, v3
    v.cmp.lt     p2, v2, v3
    v.sub        v4, v3, v1
    @p1 v.sel        v5, v4, v1
    v.sub        v1, v3, v2
    @p2 v.sel        v4, v1, v2
    v.movi       v1, #15
    v.and        v4, v5, v1
    v.sub        v1, v3, v4
    @p1 v.sel        v3, v1, v4
    s.muli       s7, s3, #16                     // a runtime tile origin, x16
    s.add        s12, s10, s7                    // the tile origin
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v4, s6
    v.mul        v5, v1, v4
    v.splat      v1, s12
    v.add        v4, v5, v1
    v.add        v1, v3, v4
    v.splat      v3, s11
    v.movi       v5, #0
    v.cmp.lt     p1, v3, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v3
    @p1 v.sel        v7, v6, v3
    v.sub        v3, v5, v2
    @p2 v.sel        v6, v3, v2
    v.movi       v3, #4
    v.lshr       v6, v7, v3
    v.sub        v3, v5, v6
    @p1 v.sel        v5, v3, v6
    s.movz       s6, #144
    v.splat      v3, s6
    v.mul        v6, v5, v3
    v.add        v5, v1, v6
    v.add        v1, v0, v5
    v.st.w       [s9, #0], v1
    s.addi       s6, s9, #64
    s.addi       s7, s11, #1
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    v.splat      v5, s7
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #4
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s6, #0], v1
    s.addi       s6, s9, #128
    s.addi       s7, s11, #2
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    v.splat      v5, s7
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #4
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s6, #0], v1
    s.addi       s6, s9, #192
    s.addi       s7, s11, #3
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    v.splat      v5, s7
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #4
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s6, #0], v1
    s.addi       s6, s9, #256
    s.addi       s7, s11, #4
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    v.splat      v5, s7
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #4
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s6, #0], v1
    s.addi       s6, s9, #320
    s.addi       s7, s11, #5
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    v.splat      v5, s7
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #4
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s6, #0], v1
    s.addi       s6, s9, #384
    s.addi       s7, s11, #6
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    v.splat      v5, s7
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #4
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s6, #0], v1
    s.addi       s6, s9, #448
    s.addi       s7, s11, #7
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    v.splat      v5, s7
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #4
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s6, #0], v1
    s.addi       s6, s9, #512
    s.addi       s7, s11, #8
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    v.splat      v5, s7
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #4
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s6, #0], v1
    s.addi       s6, s9, #576
    s.addi       s7, s11, #9
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    v.splat      v5, s7
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #4
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s6, #0], v1
    s.addi       s6, s9, #640
    s.addi       s7, s11, #10
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    v.splat      v5, s7
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #4
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s6, #0], v1
    s.addi       s6, s9, #704
    s.addi       s7, s11, #11
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    v.splat      v5, s7
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #4
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s6, #0], v1
    s.addi       s6, s9, #768
    s.addi       s7, s11, #12
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    v.splat      v5, s7
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #4
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s6, #0], v1
    s.addi       s6, s9, #832
    s.addi       s7, s11, #13
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    v.splat      v5, s7
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #4
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s6, #0], v1
    s.addi       s6, s9, #896
    s.addi       s7, s11, #14
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    v.splat      v5, s7
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #4
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s6, #0], v1
    s.addi       s6, s9, #960
    s.addi       s7, s11, #15
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    v.splat      v4, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v4, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v4
    @p1 v.sel        v7, v6, v4
    v.sub        v4, v5, v2
    @p2 v.sel        v6, v4, v2
    v.movi       v2, #4
    v.lshr       v4, v7, v2
    v.sub        v2, v5, v4
    @p1 v.sel        v5, v2, v4
    v.mul        v2, v5, v3
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s6, #0], v1
    fence.acq_rel.device
    s.movz       s6, #0
    s.add        s7, s6, s3                      // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s7
    v.add        v2, v0, v1
    v.cmpi.lt    p1, v2, #9
    v.splat      v0, s11
    v.cmpi.lt    p2, v0, #256
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s8, #0]
    s.addi       s3, s4, #0
    v.ld.w       v1, [s3, #0]
    @p3 v.st.scatter.w [s5, v1], v0
    s.addi       s3, s8, #36                     // row 1
    s.addi       s6, s11, #1
    v.splat      v0, s6
    v.cmpi.lt    p2, v0, #256
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s3, #0]
    s.addi       s3, s4, #64
    v.ld.w       v1, [s3, #0]
    @p3 v.st.scatter.w [s5, v1], v0
    s.addi       s3, s8, #72                     // row 2
    s.addi       s6, s11, #2
    v.splat      v0, s6
    v.cmpi.lt    p2, v0, #256
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s3, #0]
    s.addi       s3, s4, #128
    v.ld.w       v1, [s3, #0]
    @p3 v.st.scatter.w [s5, v1], v0
    s.addi       s3, s8, #108                    // row 3
    s.addi       s6, s11, #3
    v.splat      v0, s6
    v.cmpi.lt    p2, v0, #256
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s3, #0]
    s.addi       s3, s4, #192
    v.ld.w       v1, [s3, #0]
    @p3 v.st.scatter.w [s5, v1], v0
    s.addi       s3, s8, #144                    // row 4
    s.addi       s6, s11, #4
    v.splat      v0, s6
    v.cmpi.lt    p2, v0, #256
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s3, #0]
    s.addi       s3, s4, #256
    v.ld.w       v1, [s3, #0]
    @p3 v.st.scatter.w [s5, v1], v0
    s.addi       s3, s8, #180                    // row 5
    s.addi       s6, s11, #5
    v.splat      v0, s6
    v.cmpi.lt    p2, v0, #256
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s3, #0]
    s.addi       s3, s4, #320
    v.ld.w       v1, [s3, #0]
    @p3 v.st.scatter.w [s5, v1], v0
    s.addi       s3, s8, #216                    // row 6
    s.addi       s6, s11, #6
    v.splat      v0, s6
    v.cmpi.lt    p2, v0, #256
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s3, #0]
    s.addi       s3, s4, #384
    v.ld.w       v1, [s3, #0]
    @p3 v.st.scatter.w [s5, v1], v0
    s.addi       s3, s8, #252                    // row 7
    s.addi       s6, s11, #7
    v.splat      v0, s6
    v.cmpi.lt    p2, v0, #256
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s3, #0]
    s.addi       s3, s4, #448
    v.ld.w       v1, [s3, #0]
    @p3 v.st.scatter.w [s5, v1], v0
    s.addi       s3, s8, #288                    // row 8
    s.addi       s6, s11, #8
    v.splat      v0, s6
    v.cmpi.lt    p2, v0, #256
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s3, #0]
    s.addi       s3, s4, #512
    v.ld.w       v1, [s3, #0]
    @p3 v.st.scatter.w [s5, v1], v0
    s.addi       s3, s8, #324                    // row 9
    s.addi       s6, s11, #9
    v.splat      v0, s6
    v.cmpi.lt    p2, v0, #256
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s3, #0]
    s.addi       s3, s4, #576
    v.ld.w       v1, [s3, #0]
    @p3 v.st.scatter.w [s5, v1], v0
    s.addi       s3, s8, #360                    // row 10
    s.addi       s6, s11, #10
    v.splat      v0, s6
    v.cmpi.lt    p2, v0, #256
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s3, #0]
    s.addi       s3, s4, #640
    v.ld.w       v1, [s3, #0]
    @p3 v.st.scatter.w [s5, v1], v0
    s.addi       s3, s8, #396                    // row 11
    s.addi       s6, s11, #11
    v.splat      v0, s6
    v.cmpi.lt    p2, v0, #256
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s3, #0]
    s.addi       s3, s4, #704
    v.ld.w       v1, [s3, #0]
    @p3 v.st.scatter.w [s5, v1], v0
    s.addi       s3, s8, #432                    // row 12
    s.addi       s6, s11, #12
    v.splat      v0, s6
    v.cmpi.lt    p2, v0, #256
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s3, #0]
    s.addi       s3, s4, #768
    v.ld.w       v1, [s3, #0]
    @p3 v.st.scatter.w [s5, v1], v0
    s.addi       s3, s8, #468                    // row 13
    s.addi       s6, s11, #13
    v.splat      v0, s6
    v.cmpi.lt    p2, v0, #256
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s3, #0]
    s.addi       s3, s4, #832
    v.ld.w       v1, [s3, #0]
    @p3 v.st.scatter.w [s5, v1], v0
    s.addi       s3, s8, #504                    // row 14
    s.addi       s6, s11, #14
    v.splat      v0, s6
    v.cmpi.lt    p2, v0, #256
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s3, #0]
    s.addi       s3, s4, #896
    v.ld.w       v1, [s3, #0]
    @p3 v.st.scatter.w [s5, v1], v0
    s.addi       s3, s8, #540                    // row 15
    s.addi       s6, s11, #15
    v.splat      v0, s6
    v.cmpi.lt    p2, v0, #256
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s3, #0]
    s.addi       s3, s4, #960
    v.ld.w       v1, [s3, #0]
    @p3 v.st.scatter.w [s5, v1], v0
__rctx_next:
    s.addi       s3, s1, #2                      // the next program of this context: + 2
    s.cmp.lt     s4, s3, s2
    s.mov        s1, s3
    br.nz        s4, __rctx_program
    exit
