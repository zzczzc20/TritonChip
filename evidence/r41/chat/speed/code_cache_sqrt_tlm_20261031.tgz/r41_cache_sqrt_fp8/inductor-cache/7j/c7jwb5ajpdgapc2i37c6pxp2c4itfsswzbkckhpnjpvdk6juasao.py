# AOT ID: ['2_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# Original path: /home/zhongchun/r41-fp8-kern-hf/hub/kernels--kernels-community--finegrained-fp8/snapshots/0e5764aa5c27d0f005117a92645156481540950a/build/torch-cuda/utils.py:917
_fp8_act_quant_kernel_0 = async_compile.triton('_fp8_act_quant_kernel', '''

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[],
    inductor_meta={'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'declared_constexpr_names': ['BLOCK_SIZE', 'PADDED_BLOCK'], 'kernel_name': '_fp8_act_quant_kernel_0', 'backend_hash': 'A4E79D10F359390E2037525D201E9899BAFFEBA619AB1AC552E7E01BB639922A', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    triton_meta={'signature': {'x_ptr': '*bf16', 'y_ptr': '*fp8e4nv', 's_ptr': '*fp32', 'BLOCK_SIZE': 'constexpr', 'PADDED_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'BLOCK_SIZE': 256, 'PADDED_BLOCK': 256}, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def _fp8_act_quant_kernel(
    x_ptr, y_ptr, s_ptr, BLOCK_SIZE: tl.constexpr, PADDED_BLOCK: tl.constexpr
):
    # ``tl.arange`` needs a power-of-2 length, so iterate over PADDED_BLOCK (the next
    # power of 2) and mask the tail — lets block_size be non-power-of-2 (e.g. a full
    # row K=14336 in tensor-mode). Masked lanes load 0, which can't affect ``amax``.
    pid = tl.program_id(axis=0)
    cols = tl.arange(0, PADDED_BLOCK)
    mask = cols < BLOCK_SIZE
    offs = pid * BLOCK_SIZE + cols
    x = tl.load(x_ptr + offs, mask=mask, other=0.0).to(tl.float32)
    s = tl.max(tl.abs(x)) / 448.0  # float8_e4m3fn max
    y = (x / tl.maximum(s, 1e-12)).to(y_ptr.dtype.element_ty)
    tl.store(y_ptr + offs, y, mask=mask)
    tl.store(s_ptr + pid, s)
''', device_str='tnca')


# Original path: /home/zhongchun/r41-fp8-kern-hf/hub/kernels--kernels-community--finegrained-fp8/snapshots/0e5764aa5c27d0f005117a92645156481540950a/build/torch-cuda/matmul.py:168
w8a8_tensor_dynamic_fp8_matmul_kernel_1 = async_compile.triton('w8a8_tensor_dynamic_fp8_matmul_kernel', '''

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 2, 'num_stages': 2}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 2, 'num_stages': 3}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 2, 'num_stages': 4}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 4, 'num_stages': 2}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 4, 'num_stages': 3}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 4, 'num_stages': 4}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 8, 'num_stages': 2}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 8, 'num_stages': 3}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 8, 'num_stages': 4}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 16, 'num_stages': 2}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 16, 'num_stages': 3}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 16, 'num_stages': 4}, {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 2, 'num_stages': 2}, {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 2, 'num_stages': 3}, {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 2, 'num_stages': 4}, {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 4, 'num_stages': 2}, {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 4, 'num_stages': 3}, {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 4, 'num_stages': 4}, {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 8, 'num_stages': 2}, {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 8, 'num_stages': 3}, {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 8, 'num_stages': 4}, {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 16, 'num_stages': 2}, {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 16, 'num_stages': 3}, {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 16, 'num_stages': 4}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 2, 'num_stages': 2}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 2, 'num_stages': 3}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 2, 'num_stages': 4}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 4, 'num_stages': 2}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 4, 'num_stages': 3}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 4, 'num_stages': 4}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 8, 'num_stages': 2}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 8, 'num_stages': 3}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 8, 'num_stages': 4}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 16, 'num_stages': 2}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 16, 'num_stages': 3}, {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 16, 'num_stages': 4}, {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 2, 'num_stages': 2}, {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 2, 'num_stages': 3}, {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 2, 'num_stages': 4}, {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 4, 'num_stages': 2}, {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 4, 'num_stages': 3}, {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 4, 'num_stages': 4}, {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 8, 'num_stages': 2}, {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 8, 'num_stages': 3}, {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 8, 'num_stages': 4}, {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 16, 'num_stages': 2}, {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 16, 'num_stages': 3}, {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 16, 'num_stages': 4}],
    inductor_meta={'grid_type': 'PrecomputedGrid', 'precomputed_grids': [{'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 2, 'num_stages': 2}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 2, 'num_stages': 3}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 2, 'num_stages': 4}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 4, 'num_stages': 2}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 4, 'num_stages': 3}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 4, 'num_stages': 4}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 8, 'num_stages': 2}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 8, 'num_stages': 3}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 8, 'num_stages': 4}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 16, 'num_stages': 2}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 16, 'num_stages': 3}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'num_warps': 16, 'num_stages': 4}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 2, 'num_stages': 2}, 'python': ['1', '1', '1'], 'cpp': ['1L', '1L', '1L'], 'python_slow': ['1', '1', '1']}, {'config': {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 2, 'num_stages': 3}, 'python': ['1', '1', '1'], 'cpp': ['1L', '1L', '1L'], 'python_slow': ['1', '1', '1']}, {'config': {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 2, 'num_stages': 4}, 'python': ['1', '1', '1'], 'cpp': ['1L', '1L', '1L'], 'python_slow': ['1', '1', '1']}, {'config': {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 4, 'num_stages': 2}, 'python': ['1', '1', '1'], 'cpp': ['1L', '1L', '1L'], 'python_slow': ['1', '1', '1']}, {'config': {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 4, 'num_stages': 3}, 'python': ['1', '1', '1'], 'cpp': ['1L', '1L', '1L'], 'python_slow': ['1', '1', '1']}, {'config': {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 4, 'num_stages': 4}, 'python': ['1', '1', '1'], 'cpp': ['1L', '1L', '1L'], 'python_slow': ['1', '1', '1']}, {'config': {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 8, 'num_stages': 2}, 'python': ['1', '1', '1'], 'cpp': ['1L', '1L', '1L'], 'python_slow': ['1', '1', '1']}, {'config': {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 8, 'num_stages': 3}, 'python': ['1', '1', '1'], 'cpp': ['1L', '1L', '1L'], 'python_slow': ['1', '1', '1']}, {'config': {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 8, 'num_stages': 4}, 'python': ['1', '1', '1'], 'cpp': ['1L', '1L', '1L'], 'python_slow': ['1', '1', '1']}, {'config': {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 16, 'num_stages': 2}, 'python': ['1', '1', '1'], 'cpp': ['1L', '1L', '1L'], 'python_slow': ['1', '1', '1']}, {'config': {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 16, 'num_stages': 3}, 'python': ['1', '1', '1'], 'cpp': ['1L', '1L', '1L'], 'python_slow': ['1', '1', '1']}, {'config': {'BLOCK_SIZE_N': 256, 'BLOCK_SIZE_K': 128, 'num_warps': 16, 'num_stages': 4}, 'python': ['1', '1', '1'], 'cpp': ['1L', '1L', '1L'], 'python_slow': ['1', '1', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 2, 'num_stages': 2}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 2, 'num_stages': 3}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 2, 'num_stages': 4}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 4, 'num_stages': 2}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 4, 'num_stages': 3}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 4, 'num_stages': 4}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 8, 'num_stages': 2}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 8, 'num_stages': 3}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 8, 'num_stages': 4}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 16, 'num_stages': 2}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 16, 'num_stages': 3}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 64, 'num_warps': 16, 'num_stages': 4}, 'python': ['1', '2', '1'], 'cpp': ['1L', '2L', '1L'], 'python_slow': ['1', '2', '1']}, {'config': {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 2, 'num_stages': 2}, 'python': ['1', '4', '1'], 'cpp': ['1L', '4L', '1L'], 'python_slow': ['1', '4', '1']}, {'config': {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 2, 'num_stages': 3}, 'python': ['1', '4', '1'], 'cpp': ['1L', '4L', '1L'], 'python_slow': ['1', '4', '1']}, {'config': {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 2, 'num_stages': 4}, 'python': ['1', '4', '1'], 'cpp': ['1L', '4L', '1L'], 'python_slow': ['1', '4', '1']}, {'config': {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 4, 'num_stages': 2}, 'python': ['1', '4', '1'], 'cpp': ['1L', '4L', '1L'], 'python_slow': ['1', '4', '1']}, {'config': {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 4, 'num_stages': 3}, 'python': ['1', '4', '1'], 'cpp': ['1L', '4L', '1L'], 'python_slow': ['1', '4', '1']}, {'config': {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 4, 'num_stages': 4}, 'python': ['1', '4', '1'], 'cpp': ['1L', '4L', '1L'], 'python_slow': ['1', '4', '1']}, {'config': {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 8, 'num_stages': 2}, 'python': ['1', '4', '1'], 'cpp': ['1L', '4L', '1L'], 'python_slow': ['1', '4', '1']}, {'config': {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 8, 'num_stages': 3}, 'python': ['1', '4', '1'], 'cpp': ['1L', '4L', '1L'], 'python_slow': ['1', '4', '1']}, {'config': {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 8, 'num_stages': 4}, 'python': ['1', '4', '1'], 'cpp': ['1L', '4L', '1L'], 'python_slow': ['1', '4', '1']}, {'config': {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 16, 'num_stages': 2}, 'python': ['1', '4', '1'], 'cpp': ['1L', '4L', '1L'], 'python_slow': ['1', '4', '1']}, {'config': {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 16, 'num_stages': 3}, 'python': ['1', '4', '1'], 'cpp': ['1L', '4L', '1L'], 'python_slow': ['1', '4', '1']}, {'config': {'BLOCK_SIZE_N': 64, 'BLOCK_SIZE_K': 256, 'num_warps': 16, 'num_stages': 4}, 'python': ['1', '4', '1'], 'cpp': ['1L', '4L', '1L'], 'python_slow': ['1', '4', '1']}], 'extra_launcher_args': [], 'declared_constexpr_names': ['BLOCK_SIZE_M', 'BLOCK_SIZE_N', 'BLOCK_SIZE_K', 'GROUP_SIZE_M'], 'kernel_name': 'w8a8_tensor_dynamic_fp8_matmul_kernel_1', 'backend_hash': 'A4E79D10F359390E2037525D201E9899BAFFEBA619AB1AC552E7E01BB639922A', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    triton_meta={'signature': {'A': '*fp8e4nv', 'B': '*fp8e4nv', 'C': '*bf16', 'As': '*fp32', 'Bs': '*fp32', 'M': 'i32', 'N': 'i32', 'K': 'i32', 'stride_am': 'i32', 'stride_ak': 'constexpr', 'stride_bk': 'constexpr', 'stride_bn': 'i32', 'stride_cm': 'i32', 'stride_cn': 'constexpr', 'stride_as_m': 'constexpr', 'BLOCK_SIZE_M': 'constexpr', 'BLOCK_SIZE_N': 'constexpr', 'BLOCK_SIZE_K': 'constexpr', 'GROUP_SIZE_M': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'stride_ak': 1, 'stride_bk': 1, 'stride_cn': 1, 'stride_as_m': 1, 'BLOCK_SIZE_M': 16, 'GROUP_SIZE_M': 8}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]], (11,): [['tt.divisibility', 16]], (12,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def w8a8_tensor_dynamic_fp8_matmul_kernel(
    A,  # (M, K) pre-quantized FP8 activations
    B,  # (N, K) FP8 weights
    C,  # (M, N) output
    As,  # (M,) per-token activation scales
    Bs,  # scalar/(1,) per-tensor weight scale
    # Shape
    M,
    N,
    K,
    # Strides
    stride_am,
    stride_ak,
    stride_bk,
    stride_bn,
    stride_cm,
    stride_cn,
    stride_as_m,
    # Meta-parameters
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """Tensor-scale FP8 GEMM kernel.

    Computes ``C = A @ B.T`` with one activation scale per row and one
    weight scale for the full matrix.
    Uses a 2D grid with swizzle for L2 cache locality on B tiles.
    """
    pid_m, pid_n, offs_am, offs_bn, offs_k = _swizzle_offsets(
        M, N, BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M
    )
    a_ptrs = A + offs_am[:, None] * stride_am + offs_k[None, :] * stride_ak
    b_ptrs = B + offs_k[:, None] * stride_bk + offs_bn[None, :] * stride_bn

    a_s = tl.load(As + offs_am * stride_as_m)
    b_s = tl.load(Bs)

    # Accumulate raw dot products, apply scales once after the loop.
    accumulator = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    for k in range(0, tl.cdiv(K, BLOCK_SIZE_K)):
        k_remaining = K - k * BLOCK_SIZE_K
        a = tl.load(a_ptrs, mask=offs_k[None, :] < k_remaining, other=0.0)
        b = tl.load(b_ptrs, mask=offs_k[:, None] < k_remaining, other=0.0)
        accumulator += tl.dot(a, b)
        a_ptrs += BLOCK_SIZE_K * stride_ak
        b_ptrs += BLOCK_SIZE_K * stride_bk

    accumulator = accumulator * a_s[:, None] * b_s

    _store_masked(
        C,
        accumulator,
        pid_m,
        pid_n,
        M,
        N,
        stride_cm,
        stride_cn,
        BLOCK_SIZE_M,
        BLOCK_SIZE_N,
    )

@triton.jit
def _swizzle_offsets(
    M,
    N,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """2D-grid tile scheduling shared by the kernels below: swizzle the
    ``(pid_m, pid_n)`` program ids for L2 locality on B, then build the operand
    offset vectors. Returns ``(pid_m, pid_n, offs_am, offs_bn, offs_k)`` — the
    swizzled ids (reused by the output store) and the ``%``-wrapped row/col offsets
    plus the K range."""
    pid_m = tl.program_id(axis=0)
    pid_n = tl.program_id(axis=1)
    num_pid_m = tl.cdiv(M, BLOCK_SIZE_M)
    num_pid_n = tl.cdiv(N, BLOCK_SIZE_N)
    pid_m, pid_n = tl.swizzle2d(pid_m, pid_n, num_pid_m, num_pid_n, GROUP_SIZE_M)
    offs_am = (pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)) % M
    offs_bn = (pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)) % N
    offs_k = tl.arange(0, BLOCK_SIZE_K)
    return pid_m, pid_n, offs_am, offs_bn, offs_k

@triton.jit
def _store_masked(
    C,
    accumulator,
    pid_m,
    pid_n,
    M,
    N,
    stride_cm,
    stride_cn,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
):
    """Shared output epilogue of the kernels below: cast the fp32 accumulator to
    ``C``'s dtype and store the ``(BLOCK_SIZE_M, BLOCK_SIZE_N)`` tile at the swizzled
    ``(pid_m, pid_n)``, masked to the ``(M, N)`` bounds."""
    c = accumulator.to(C.dtype.element_ty)
    offs_cm = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_cn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    c_ptrs = C + stride_cm * offs_cm[:, None] + stride_cn * offs_cn[None, :]
    c_mask = (offs_cm[:, None] < M) & (offs_cn[None, :] < N)
    tl.store(c_ptrs, c, mask=c_mask)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1 = args
        args.clear()
        buf0 = empty_strided((7, 256), (256, 1), device='tnca', dtype=torch.float8_e4m3fn)
        buf1 = empty_strided((7, 1), (1, 1), device='tnca', dtype=torch.float32)
        assert_size_stride(arg2_1, (7, 256), (256, 1), 'input')
        # Topologically Sorted Source Nodes: [w8a8_tensor_dynamic_fp8_matmul], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        _fp8_act_quant_kernel_0.run(arg2_1, buf0, buf1, 7, 1, 1, stream=raw_stream0)
        del arg2_1
        buf4 = empty_strided((7, 256), (256, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg0_1, arg1_1), ((256, 256), ()), ((256, 1), ()), 'input')
        # Topologically Sorted Source Nodes: [w8a8_tensor_dynamic_fp8_matmul], Original ATen: [aten.view]
        raw_stream0 = get_raw_stream(0)
        w8a8_tensor_dynamic_fp8_matmul_kernel_1.run(buf0, arg0_1, buf4, reinterpret_tensor(buf1, (7, ), (1, ), 0), reinterpret_tensor(arg1_1, (1, ), (1, ), 0), 7, 256, 256, 256, 1, 1, 256, 256, 1, 1, stream=raw_stream0)
        del arg0_1
        del arg1_1
        return (buf4, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((256, 256), (256, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg1_1 = rand_strided((), (), device='tnca:0', dtype=torch.float32)
    arg2_1 = rand_strided((7, 256), (256, 1), device='tnca:0', dtype=torch.bfloat16)
    return [arg0_1, arg1_1, arg2_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
