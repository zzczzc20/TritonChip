# AOT ID: ['10_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /home/zhongchun/r41-sw-work/bw/final/inductor-cache/ze/czerjgcdhbmq6qkzzleurkjoonqhl4axidyzhlei5pk3kxun4ett.py
# Topologically Sorted Source Nodes: [_scaled_mm], Original ATen: [aten._scaled_mm]
# Source node to ATen node mapping:
#   _scaled_mm => _scaled_mm
# Graph fragment:
#   %arg0_1 : Tensor "f8e4m3fn[129, 256][256, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %arg1_1 : Tensor "f8e4m3fn[256, 136][1, 256]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f32[129, 2][1, 129]tnca:0" = PlaceHolder[target=arg2_1]
#   %arg3_1 : Tensor "f32[2, 136][136, 1]tnca:0" = PlaceHolder[target=arg3_1]
#   %_scaled_mm : Tensor "f32[129, 136][136, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten._scaled_mm.default](args = (%arg0_1, %arg1_1, %arg2_1, %arg3_1, None, None, torch.float32), kwargs = {})
#   return %_scaled_mm
triton_tem_fused__scaled_mm_0 = async_compile.triton('triton_tem_fused__scaled_mm_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp8e4nv', 'arg_B': '*fp8e4nv', 'arg_SA': '*fp32', 'arg_SB': '*fp32', 'out_ptr0': '*fp32'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(4,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__scaled_mm_0', 'backend_hash': 'A9461DFAA2FADAE371D121176B1AD060ABCA2D8BBDA6C581BA1BD955606F8F3E', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'BLOCK_M': 16, 'BLOCK_N': 128, 'BLOCK_K': 128, 'TILE_A': 1, 'TILE_B': 1, 'KSUB': 128, 'SA_KB_FIRST': False, 'SB_KB_FIRST': True}},

)
@triton.jit
def triton_tem_fused__scaled_mm_0(arg_A, arg_B, arg_SA, arg_SB, out_ptr0):
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 128
    BLOCK_K : tl.constexpr = 128
    TILE_A : tl.constexpr = 1
    TILE_B : tl.constexpr = 1
    KSUB : tl.constexpr = 128
    SA_KB_FIRST : tl.constexpr = False
    SB_KB_FIRST : tl.constexpr = True
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B
    SA = arg_SA
    SB = arg_SB

    M = 129
    N = 136
    K = 256
    if M * N == 0:
        return
    stride_am = 256
    stride_ak = 1
    stride_bk = 1
    stride_bn = 256
    sa_r = 1
    sa_k = 129
    sb_k = 136
    sb_c = 1

    pid = tl.program_id(0)
    grid_n = (N + BLOCK_N - 1) // BLOCK_N
    pid_m = pid // grid_n
    pid_n = pid % grid_n
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    offs_m = rm % M
    offs_n = rn % N
    offs_k = tl.arange(0, KSUB)
    a_ptrs = A + (offs_m[:, None] * stride_am + offs_k[None, :] * stride_ak)
    b_ptrs = B + (offs_k[:, None] * stride_bk + offs_n[None, :] * stride_bn)
    sa_ptrs = SA + (offs_m // TILE_A) * sa_r
    sb_ptrs = SB + (offs_n // TILE_B) * sb_c

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
    for kb in range(0, tl.cdiv(K, BLOCK_K)):
        k_remaining = K - kb * BLOCK_K
        a_s = tl.load(sa_ptrs + kb * sa_k)
        b_s = tl.load(sb_ptrs + kb * sb_k)
        a = tl.load(a_ptrs, mask=offs_k[None, :] < k_remaining, other=0.0)
        b = tl.load(b_ptrs, mask=offs_k[:, None] < k_remaining, other=0.0)
        acc += tl.dot(a, b) * a_s[:, None] * b_s[None, :]
        a_ptrs += BLOCK_K * stride_ak
        b_ptrs += BLOCK_K * stride_bk

    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 136*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1 = args
        args.clear()
        assert_size_stride_grouped((arg0_1, arg1_1, arg2_1, arg3_1), ((129, 256), (256, 136), (129, 2), (2, 136)), ((256, 1), (1, 256), (1, 129), (136, 1)), 'input')
        buf0 = empty_strided((129, 136), (136, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [_scaled_mm], Original ATen: [aten._scaled_mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_mm_0.run(arg0_1, arg1_1, arg2_1, arg3_1, buf0, 18, 1, 1, stream=raw_stream0)
        del arg0_1
        del arg1_1
        del arg2_1
        del arg3_1
        return (buf0, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((129, 256), (256, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg1_1 = rand_strided((256, 136), (1, 256), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg2_1 = rand_strided((129, 2), (1, 129), device='tnca:0', dtype=torch.float32)
    arg3_1 = rand_strided((2, 136), (136, 1), device='tnca:0', dtype=torch.float32)
    return [arg0_1, arg1_1, arg2_1, arg3_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
