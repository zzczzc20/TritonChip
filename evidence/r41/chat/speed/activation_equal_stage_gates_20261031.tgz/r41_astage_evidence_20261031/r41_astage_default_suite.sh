#!/usr/bin/env bash
set -eu
export OMP_NUM_THREADS=1 MAX_JOBS=1 CUDA_VISIBLE_DEVICES= HF_HUB_OFFLINE=1
export HF_HOME="$HOME/r41-fp8-kern-hf" TNCA_PROFILE=core-vrf-sync-v5-x8-g2c4-dp TNCA_BACKEND=systemc-tlm-grid
export TNCA_TLM_BINARY="$HOME/r41_vl_reason_dp/build/tnca-chip" TNCA_TLM_CONFIG="$HOME/r41_vl_reason_dp/src/tools/performance_harness/systemc/configs/r41-mma-dp.cfg"
export TNCA_TLM_OUT="$HOME/r41_astage_default_suite_tlm" TNCA_HOST_TIMEOUT=180
unset TNCA_X8_EQUAL_A_STAGE TNCA_EQUAL_ROWS TNCA_X8_SPILL_LANES TNCA_X8_PIPELINE
cd "$HOME/r41_chat_astage_default_20261031"
"$HOME/flux-venv/bin/python" -u "$HOME/r41_cache_pinned_fp8_20261031.py" --group v4 --group compile --quick --out "$HOME/r41_astage_default_suite"
export TNCA_TLM_OUT="$HOME/r41_astage_default_m1_tlm"
"$HOME/flux-venv/bin/python" -u tools/r41/chat_speed/bench_hoisted_fp8.py --route fused --default-div --m 1 --n 256 --k 256 --v1 "$HOME/r41-fp8-kern-hf/hub/kernels--kernels-community--finegrained-fp8/snapshots/48f42b23bb4e0122d4775c6d16753dd2efc7f580" --out "$HOME/r41_astage_default_m1"
