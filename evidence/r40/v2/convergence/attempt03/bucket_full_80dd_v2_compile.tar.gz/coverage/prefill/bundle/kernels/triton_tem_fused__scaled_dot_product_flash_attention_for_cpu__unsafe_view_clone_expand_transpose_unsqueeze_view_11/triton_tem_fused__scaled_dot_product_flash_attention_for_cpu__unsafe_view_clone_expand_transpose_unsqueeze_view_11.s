    s.movz       s1, #4
    s.movz       s2, #0
    s.movz       s3, #0
    s.cmp.lt     s4, s1, s2
    s.rdspecial  s2, arg_base
    s.sub        s5, s3, s4
    s.ld.d       s3, [s2, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.xor        s4, s1, s5
    s.movz       s6, #0
    s.movz       s7, #0
    s.sub        s8, s4, s5
    s.movz       s4, #32
    s.movz       s8, #1
    s.movz       s9, #0
    s.movz       s10, #0
    s.movz       s11, #0
    s.movz       s12, #0
    s.ld.d       s13, [s2, #8]                   // arg_B: device_ptr64 at arg_base+8
    s.movz       s14, #0
    s.movz       s15, #0
    s.movz       s16, #1
    s.rdspecial  s17, role_id
    s.rdspecial  s18, npid.x
    s.ld.d       s19, [s2, #16]                  // out_ptr0: device_ptr64 at arg_base+16
__rctx_program:
    s.cmp.lt     s2, s17, s7
    s.cmp.lt     s20, s17, s10
    s.sub        s21, s6, s2
    s.sub        s2, s9, s20
    s.xor        s20, s17, s21
    s.xor        s22, s21, s5
    s.sub        s23, s20, s21
    s.xor        s20, s17, s2
    s.lshri      s21, s23, #2
    s.sub        s24, s20, s2
    s.xor        s20, s21, s22
    s.muli       s25, s21, #4
    s.sub        s21, s20, s22
    s.addi       s20, s14, #0
    s.sub        s22, s4, s21
    s.addi       s26, s15, #0
    s.min.s      s27, s22, s8
    s.sub        s22, s23, s25
    s.cmp.lt     s22, s27, s12
    s.mov        s20, s24
    s.sub        s23, s11, s22
    s.xor        s22, s27, s23
    s.sub        s25, s22, s23
    s.cmp.eq     s22, s25, s16
    br.nz        s22, sdiv_done_1
    s.movz       s22, #0
    s.movz       s23, #31
    s.mov        s20, s22
    s.addi       s22, s23, #0
sdiv_2:
    s.lshr       s23, s24, s22
    s.shli       s28, s26, #1
    s.andi       s29, s23, #1
    s.movz       s23, #0
    s.or         s30, s28, s29
    s.movz       s28, #1
    s.cmp.geu    s29, s30, s25
    s.shl        s31, s28, s22
    s.sub        s28, s23, s29
    s.subi       s23, s22, #1
    s.and        s29, s25, s28
    s.and        s32, s31, s28
    s.sub        s28, s30, s29
    s.or         s29, s20, s32
    s.mov        s26, s28
    s.mov        s20, s29
    s.mov        s22, s23
    s.movz       s23, #0
    s.cmp.ge     s28, s22, s23
    br.nz        s28, sdiv_2
sdiv_done_1:
    s.movz       s20, #0
    s.movz       s22, #0
    s.cmp.lt     s23, s17, s20
    s.movz       s20, #0
    s.sub        s24, s22, s23
    s.movz       s22, #0
    s.xor        s23, s17, s24
    s.movz       s25, #0
    s.sub        s28, s23, s24
    s.cmp.lt     s23, s27, s20
    s.lshri      s20, s28, #2
    s.movz       s29, #0
    s.muli       s30, s20, #4
    s.movz       s20, #0
    s.sub        s31, s25, s23
    s.movz       s23, #0
    s.cmp.lt     s25, s1, s29
    s.sub        s29, s28, s30
    s.xor        s28, s27, s31
    s.xor        s27, s29, s24
    s.xor        s29, s26, s2
    s.sub        s26, s27, s24
    s.sub        s24, s23, s25
    s.cmp.lt     s23, s26, s22
    s.sub        s22, s28, s31
    s.sub        s25, s20, s23
    s.movz       s20, #0
    s.xor        s23, s26, s25
    s.movz       s26, #1
    s.sub        s27, s29, s2
    s.xor        s2, s1, s24
    s.sub        s28, s23, s25
    s.movz       s23, #0
    s.addi       s29, s20, #0
    s.cmp.eq     s20, s22, s26
    s.add        s26, s21, s27
    s.sub        s21, s2, s24
    s.addi       s2, s23, #0
    s.mov        s29, s28
    br.nz        s20, sdiv_done_3
    s.movz       s20, #0
    s.movz       s21, #31
    s.mov        s29, s20
    s.addi       s20, s21, #0
sdiv_4:
    s.lshr       s21, s28, s20
    s.shli       s23, s2, #1
    s.andi       s24, s21, #1
    s.movz       s21, #0
    s.or         s27, s23, s24
    s.movz       s23, #1
    s.cmp.geu    s24, s27, s22
    s.shl        s30, s23, s20
    s.sub        s23, s21, s24
    s.subi       s21, s20, #1
    s.and        s24, s22, s23
    s.and        s32, s30, s23
    s.sub        s23, s27, s24
    s.or         s24, s29, s32
    s.mov        s2, s23
    s.mov        s29, s24
    s.mov        s20, s21
    s.movz       s21, #0
    s.cmp.ge     s23, s20, s21
    br.nz        s23, sdiv_4
sdiv_done_3:
    s.movz       s2, #16
    s.rdspecial  s20, pid.z
    s.rdspecial  s21, npid.y
    s.xor        s22, s25, s31
    s.mul        s23, s26, s2
    s.mul        s24, s20, s21
    s.xor        s20, s29, s22
    s.rdspecial  s21, pid.y
    s.sub        s25, s20, s22
    s.andi       s20, s23, #511
    s.mul        s22, s25, s2
    s.add        s27, s21, s24
    s.movz       s21, #15
    s.rdspecial  s24, arg_base
    s.min.s      s28, s27, s21
    .li       s21, #262144
    s.movz       s29, #32768
    s.ld.d       s30, [s24, #24]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.muli       s24, s20, #512                  // a runtime tile origin, x512
    s.mul        s31, s28, s21
    s.mul        s21, s28, s29
    s.andi       s28, s22, #63
    s.movz       s32, #0
    s.rdspecial  s33, role_id
    s.movz       s34, #6144
    s.add        s35, s32, s24                   // the tile origin
    s.mul        s24, s33, s34
    s.add        s32, s35, s31                   // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    s.movz       s31, #0
    v.splat      v1, s26
    s.add        s26, s30, s24                   // this context's own scratch
    v.splat      v2, s32
    s.addi       s24, s26, #0
    v.splat      v3, s31
    v.splat      v4, s25
    v.splat      v5, s31
    v.add        v6, v0, v2
    v.cmp.ge     p1, v1, v3
    s.addi       s25, s32, #512
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v2, s25
    s.addi       s25, s24, #64
    v.cmp.ge     p1, v4, v5
    s.addi       s30, s32, #1024
    v.splat      v3, s23
    v.splat      v4, s30
    v.add        v5, v0, v2
    s.addi       s30, s24, #128
    v.add        v2, v3, v1
    v.splat      v2, s22
    v.add        v3, v0, v4
    s.addi       s33, s24, #192
    v.add        v4, v2, v1
    s.addi       s34, s32, #1536
    v.splat      v1, s20
    v.splat      v2, s34
    s.movz       s20, #512
    s.addi       s34, s31, #0
    v.add        v4, v0, v2
    v.st.w       [s24, #0], v6
    v.iota       v2                              // arange(0, VLEN)
    v.add        v6, v1, v2
    s.addi       s31, s32, #2048
    v.splat      v1, s28
    v.splat      v2, s31
    s.addi       s31, s24, #256
    v.st.w       [s25, #0], v5
    v.iota       v5                              // arange(0, VLEN)
    v.add        v6, v0, v2
    v.add        v2, v1, v5
    s.addi       s25, s32, #2560
    s.addi       s35, s32, #3072
    s.addi       s36, s32, #3584
    v.splat      v1, s25
    s.addi       s25, s32, #4096
    v.splat      v2, s35
    s.addi       s35, s32, #4608
    v.add        v5, v0, v1
    v.add        v1, v0, v2
    v.st.w       [s30, #0], v3
    s.addi       s30, s32, #5120
    v.splat      v2, s36
    s.addi       s36, s32, #5632
    v.add        v3, v0, v2
    v.st.w       [s33, #0], v4
    s.addi       s33, s32, #6144
    v.splat      v2, s25
    s.addi       s25, s32, #6656
    v.add        v4, v0, v2
    v.st.w       [s31, #0], v6
    s.addi       s31, s32, #7168
    v.splat      v2, s35
    s.addi       s35, s24, #320
    s.addi       s37, s32, #7680
    v.add        v6, v0, v2
    v.st.w       [s35, #0], v5
    v.splat      v2, s30
    s.addi       s30, s24, #384
    s.addi       s32, s26, #1024
    v.add        v5, v0, v2
    v.st.w       [s30, #0], v1
    s.movz       s30, #0
    v.splat      v1, s36
    s.addi       s35, s24, #448
    s.add        s36, s30, s28                   // the tile origin
    v.add        v2, v0, v1
    s.add        s28, s36, s21                   // the tile origin
    s.addi       s21, s24, #512
    s.addi       s30, s24, #576
    v.st.w       [s35, #0], v3
    s.addi       s35, s28, #64
    v.splat      v1, s33
    s.addi       s33, s24, #640
    v.add        v3, v0, v1
    v.st.w       [s21, #0], v4
    s.addi       s21, s28, #128
    v.splat      v1, s25
    s.addi       s25, s24, #704
    v.add        v4, v0, v1
    v.st.w       [s30, #0], v6
    s.addi       s30, s28, #192
    v.splat      v1, s31
    s.addi       s31, s24, #768
    v.add        v6, v0, v1
    v.st.w       [s33, #0], v5
    s.addi       s33, s28, #256
    v.splat      v1, s37
    s.addi       s36, s24, #832
    v.add        v5, v0, v1
    v.st.w       [s25, #0], v2
    s.addi       s25, s28, #320
    v.splat      v1, s28
    v.add        v2, v0, v1
    v.st.w       [s31, #0], v3
    s.addi       s31, s28, #384
    v.splat      v1, s35
    s.addi       s35, s24, #896
    s.addi       s37, s24, #960
    v.add        v3, v0, v1
    v.st.w       [s36, #0], v4
    s.addi       s24, s28, #448
    v.splat      v1, s21
    s.addi       s21, s32, #64
    v.add        v4, v0, v1
    v.st.w       [s35, #0], v6
    s.addi       s35, s28, #512
    v.splat      v1, s30
    s.addi       s30, s32, #128
    v.add        v6, v0, v1
    v.st.w       [s37, #0], v5
    v.splat      v1, s33
    s.addi       s33, s32, #192
    s.addi       s36, s32, #256
    v.add        v5, v0, v1
    fence.acq_rel.device
    v.st.w       [s32, #0], v2
    v.splat      v1, s25
    s.addi       s25, s28, #576
    v.add        v2, v0, v1
    v.st.w       [s21, #0], v3
    s.addi       s21, s28, #640
    v.splat      v1, s31
    s.addi       s31, s28, #704
    v.add        v3, v0, v1
    v.st.w       [s30, #0], v4
    s.addi       s30, s28, #768
    v.splat      v1, s24
    s.addi       s24, s28, #832
    v.add        v4, v0, v1
    v.st.w       [s33, #0], v6
    s.addi       s33, s28, #896
    v.splat      v1, s35
    s.addi       s35, s32, #320
    v.add        v6, v0, v1
    v.st.w       [s36, #0], v5
    s.addi       s36, s28, #960
    v.splat      v1, s25
    s.addi       s25, s32, #384
    s.addi       s28, s32, #448
    v.add        v5, v0, v1
    v.st.w       [s35, #0], v2
    v.splat      v1, s21
    s.addi       s21, s32, #512
    s.addi       s35, s32, #576
    v.add        v2, v0, v1
    v.st.w       [s25, #0], v3
    v.splat      v1, s31
    s.addi       s25, s32, #640
    s.addi       s31, s32, #704
    v.add        v3, v0, v1
    v.st.w       [s28, #0], v4
    v.splat      v1, s30
    s.addi       s28, s32, #768
    s.addi       s30, s32, #832
    v.add        v4, v0, v1
    v.st.w       [s21, #0], v6
    v.splat      v1, s24
    s.addi       s21, s32, #896
    s.addi       s24, s32, #960
    v.add        v6, v0, v1
    v.st.w       [s35, #0], v5
    v.splat      v1, s33
    v.add        v5, v0, v1
    v.st.w       [s25, #0], v2
    v.splat      v1, s36
    v.add        v2, v0, v1
    v.st.w       [s31, #0], v3
    v.st.w       [s28, #0], v4
    v.st.w       [s30, #0], v6
    v.st.w       [s21, #0], v5
    v.st.w       [s24, #0], v2
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s21, s34, s20
    br.nz        s21, endfor_6
    s.addi       s21, s26, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s24, #0
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s26, #64
    s.movz       s25, #1
    s.addi       s28, s26, #128
    s.movz       s30, #2
    s.addi       s31, s26, #192
    s.movz       s32, #3
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s24, v2
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s26, #256
    s.movz       s24, #4
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s25, v2
    v.ld.w       v1, [s28, #0]
    s.addi       s25, s26, #320
    s.movz       s28, #5
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s30, v2
    v.ld.w       v1, [s31, #0]
    s.addi       s30, s26, #384
    s.movz       s31, #6
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s32, v2
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s26, #448
    s.movz       s32, #7
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s24, v2
    v.ld.w       v1, [s25, #0]
    s.addi       s24, s26, #512
    s.movz       s25, #8
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s28, v2
    v.ld.w       v1, [s30, #0]
    s.addi       s28, s26, #576
    s.movz       s30, #9
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s31, v2
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s26, #640
    s.movz       s31, #10
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s32, v2
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s26, #704
    s.movz       s32, #11
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s25, v2
    v.ld.w       v1, [s28, #0]
    s.addi       s25, s26, #768
    s.movz       s28, #12
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s30, v2
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s26, #832
    s.movz       s30, #13
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s31, v2
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s26, #896
    s.movz       s31, #14
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s32, v2
    v.ld.w       v1, [s25, #0]
    s.addi       s25, s26, #960
    s.movz       s32, #15
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s28, v2
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s26, #1024
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s28, #0
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s30, v2
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s26, #1088
    s.movz       s30, #1
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s31, v2
    v.ld.w       v1, [s25, #0]
    s.addi       s25, s26, #1152
    s.movz       s31, #2
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s32, v2
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s26, #1216
    s.movz       s32, #3
    v.ld.gather.w v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s28, v2
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s26, #1280
    s.movz       s28, #4
    v.ld.gather.w v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s30, v2
    v.ld.w       v1, [s25, #0]
    s.addi       s25, s26, #1344
    s.movz       s30, #5
    v.ld.gather.w v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s31, v2
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s26, #1408
    s.movz       s31, #6
    v.ld.gather.w v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s32, v2
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s26, #1472
    s.movz       s32, #7
    v.ld.gather.w v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s28, v2
    v.ld.w       v1, [s25, #0]
    s.addi       s25, s26, #1536
    s.movz       s28, #8
    v.ld.gather.w v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s30, v2
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s26, #1600
    s.movz       s30, #9
    v.movi       v2, #0
    v.ld.gather.w v3, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s31, v3
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s26, #1664
    s.movz       s31, #10
    v.ld.gather.w v3, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s32, v3
    v.ld.w       v1, [s25, #0]
    s.addi       s25, s26, #1728
    s.movz       s32, #11
    v.ld.gather.w v3, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s28, v3
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s26, #1792
    s.movz       s28, #12
    v.ld.gather.w v3, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s30, v3
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s26, #1856
    s.movz       s30, #13
    v.ld.gather.w v3, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s31, v3
    v.ld.w       v1, [s25, #0]
    s.addi       s25, s26, #1920
    s.movz       s31, #14
    v.ld.gather.w v3, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s32, v3
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s26, #1984
    s.movz       s32, #15
    v.ld.gather.w v3, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s28, v3
    v.ld.w       v1, [s24, #0]
    s.movz       s24, #0
    s.movz       s28, #0
    v.ld.gather.w v3, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s30, v3
    v.ld.w       v1, [s25, #0]
    s.movz       s25, #1
    s.movz       s30, #2
    v.ld.gather.w v3, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s31, v3
    v.ld.w       v1, [s21, #0]
    s.movz       s21, #3
    s.movz       s31, #4
    v.ld.gather.w v3, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s32, v3
    a.vread      v1, a1, s24
    a.vread      v3, a2, s28
    a.vread      v4, a2, s25
    v.extract    s24, v1, #0
    v.extract    s25, v1, #1
    v.splat      v5, s24
    v.splat      v6, s25
    v.extract    s24, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s24
    a.vread      v5, a2, s30
    v.extract    s24, v1, #3
    a.vread      v8, a2, s21
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s24
    v.extract    s21, v1, #4
    a.vread      v6, a2, s31
    v.splat      v7, s21
    vf.fma       v10, v3, v5, v9
    v.extract    s21, v1, #5
    s.movz       s24, #5
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v9, v4, v8, v10
    v.extract    s21, v1, #6
    s.movz       s24, #6
    v.splat      v4, s21
    a.vread      v8, a2, s24
    vf.fma       v10, v7, v6, v9
    v.extract    s21, v1, #7
    s.movz       s24, #7
    v.splat      v6, s21
    a.vread      v7, a2, s24
    vf.fma       v9, v3, v5, v10
    v.extract    s21, v1, #8
    s.movz       s24, #8
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v10, v4, v8, v9
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s21, #0
    v.extract    s24, v1, #9
    s.movz       s25, #9
    v.splat      v4, s24
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s25
    v.extract    s24, v1, #10
    s.movz       s25, #10
    v.splat      v7, s24
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #11
    s.movz       s25, #11
    v.splat      v5, s24
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #12
    s.movz       s25, #12
    v.splat      v6, s24
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #13
    s.movz       s25, #13
    v.splat      v7, s24
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #14
    s.movz       s25, #14
    v.splat      v5, s24
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #15
    s.movz       s25, #15
    v.splat      v1, s24
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s25
    s.movz       s24, #1
    s.movz       s25, #0
    s.movz       s28, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s30, #2
    s.movz       s31, #3
    s.movz       s32, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s21, v3
    a.vread      v1, a1, s24
    a.vread      v3, a2, s25
    a.vread      v4, a2, s28
    v.extract    s21, v1, #0
    v.extract    s24, v1, #1
    v.splat      v5, s21
    v.splat      v6, s24
    v.extract    s21, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s21
    a.vread      v5, a2, s30
    v.extract    s21, v1, #3
    a.vread      v8, a2, s31
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s21
    v.extract    s21, v1, #4
    a.vread      v6, a2, s32
    v.splat      v7, s21
    vf.fma       v10, v3, v5, v9
    v.extract    s21, v1, #5
    s.movz       s24, #5
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v9, v4, v8, v10
    v.extract    s21, v1, #6
    s.movz       s24, #6
    v.splat      v4, s21
    a.vread      v8, a2, s24
    vf.fma       v10, v7, v6, v9
    v.extract    s21, v1, #7
    s.movz       s24, #7
    v.splat      v6, s21
    a.vread      v7, a2, s24
    vf.fma       v9, v3, v5, v10
    v.extract    s21, v1, #8
    s.movz       s24, #8
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v10, v4, v8, v9
    s.movz       s21, #1
    v.extract    s24, v1, #9
    s.movz       s25, #9
    v.splat      v4, s24
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s25
    v.extract    s24, v1, #10
    s.movz       s25, #10
    v.splat      v7, s24
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #11
    s.movz       s25, #11
    v.splat      v5, s24
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #12
    s.movz       s25, #12
    v.splat      v6, s24
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #13
    s.movz       s25, #13
    v.splat      v7, s24
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #14
    s.movz       s25, #14
    v.splat      v5, s24
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #15
    s.movz       s25, #15
    v.splat      v1, s24
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s25
    s.movz       s24, #2
    s.movz       s25, #0
    s.movz       s28, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s30, #2
    s.movz       s31, #3
    s.movz       s32, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s21, v3
    a.vread      v1, a1, s24
    a.vread      v3, a2, s25
    a.vread      v4, a2, s28
    v.extract    s21, v1, #0
    v.extract    s24, v1, #1
    v.splat      v5, s21
    v.splat      v6, s24
    v.extract    s21, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s21
    a.vread      v5, a2, s30
    v.extract    s21, v1, #3
    a.vread      v8, a2, s31
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s21
    v.extract    s21, v1, #4
    a.vread      v6, a2, s32
    v.splat      v7, s21
    vf.fma       v10, v3, v5, v9
    v.extract    s21, v1, #5
    s.movz       s24, #5
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v9, v4, v8, v10
    v.extract    s21, v1, #6
    s.movz       s24, #6
    v.splat      v4, s21
    a.vread      v8, a2, s24
    vf.fma       v10, v7, v6, v9
    v.extract    s21, v1, #7
    s.movz       s24, #7
    v.splat      v6, s21
    a.vread      v7, a2, s24
    vf.fma       v9, v3, v5, v10
    v.extract    s21, v1, #8
    s.movz       s24, #8
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v10, v4, v8, v9
    s.movz       s21, #2
    v.extract    s24, v1, #9
    s.movz       s25, #9
    v.splat      v4, s24
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s25
    v.extract    s24, v1, #10
    s.movz       s25, #10
    v.splat      v7, s24
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #11
    s.movz       s25, #11
    v.splat      v5, s24
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #12
    s.movz       s25, #12
    v.splat      v6, s24
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #13
    s.movz       s25, #13
    v.splat      v7, s24
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #14
    s.movz       s25, #14
    v.splat      v5, s24
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #15
    s.movz       s25, #15
    v.splat      v1, s24
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s25
    s.movz       s24, #3
    s.movz       s25, #0
    s.movz       s28, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s30, #2
    s.movz       s31, #3
    s.movz       s32, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s21, v3
    a.vread      v1, a1, s24
    a.vread      v3, a2, s25
    a.vread      v4, a2, s28
    v.extract    s21, v1, #0
    v.extract    s24, v1, #1
    v.splat      v5, s21
    v.splat      v6, s24
    v.extract    s21, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s21
    a.vread      v5, a2, s30
    v.extract    s21, v1, #3
    a.vread      v8, a2, s31
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s21
    v.extract    s21, v1, #4
    a.vread      v6, a2, s32
    v.splat      v7, s21
    vf.fma       v10, v3, v5, v9
    v.extract    s21, v1, #5
    s.movz       s24, #5
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v9, v4, v8, v10
    v.extract    s21, v1, #6
    s.movz       s24, #6
    v.splat      v4, s21
    a.vread      v8, a2, s24
    vf.fma       v10, v7, v6, v9
    v.extract    s21, v1, #7
    s.movz       s24, #7
    v.splat      v6, s21
    a.vread      v7, a2, s24
    vf.fma       v9, v3, v5, v10
    v.extract    s21, v1, #8
    s.movz       s24, #8
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v10, v4, v8, v9
    s.movz       s21, #3
    v.extract    s24, v1, #9
    s.movz       s25, #9
    v.splat      v4, s24
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s25
    v.extract    s24, v1, #10
    s.movz       s25, #10
    v.splat      v7, s24
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #11
    s.movz       s25, #11
    v.splat      v5, s24
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #12
    s.movz       s25, #12
    v.splat      v6, s24
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #13
    s.movz       s25, #13
    v.splat      v7, s24
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #14
    s.movz       s25, #14
    v.splat      v5, s24
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #15
    s.movz       s25, #15
    v.splat      v1, s24
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s25
    s.movz       s24, #4
    s.movz       s25, #0
    s.movz       s28, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s30, #2
    s.movz       s31, #3
    s.movz       s32, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s21, v3
    a.vread      v1, a1, s24
    a.vread      v3, a2, s25
    a.vread      v4, a2, s28
    v.extract    s21, v1, #0
    v.extract    s24, v1, #1
    v.splat      v5, s21
    v.splat      v6, s24
    v.extract    s21, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s21
    a.vread      v5, a2, s30
    v.extract    s21, v1, #3
    a.vread      v8, a2, s31
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s21
    v.extract    s21, v1, #4
    a.vread      v6, a2, s32
    v.splat      v7, s21
    vf.fma       v10, v3, v5, v9
    v.extract    s21, v1, #5
    s.movz       s24, #5
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v9, v4, v8, v10
    v.extract    s21, v1, #6
    s.movz       s24, #6
    v.splat      v4, s21
    a.vread      v8, a2, s24
    vf.fma       v10, v7, v6, v9
    v.extract    s21, v1, #7
    s.movz       s24, #7
    v.splat      v6, s21
    a.vread      v7, a2, s24
    vf.fma       v9, v3, v5, v10
    v.extract    s21, v1, #8
    s.movz       s24, #8
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v10, v4, v8, v9
    s.movz       s21, #4
    v.extract    s24, v1, #9
    s.movz       s25, #9
    v.splat      v4, s24
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s25
    v.extract    s24, v1, #10
    s.movz       s25, #10
    v.splat      v7, s24
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #11
    s.movz       s25, #11
    v.splat      v5, s24
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #12
    s.movz       s25, #12
    v.splat      v6, s24
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #13
    s.movz       s25, #13
    v.splat      v7, s24
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #14
    s.movz       s25, #14
    v.splat      v5, s24
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #15
    s.movz       s25, #15
    v.splat      v1, s24
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s25
    s.movz       s24, #5
    s.movz       s25, #0
    s.movz       s28, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s30, #2
    s.movz       s31, #3
    s.movz       s32, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s21, v3
    a.vread      v1, a1, s24
    a.vread      v3, a2, s25
    a.vread      v4, a2, s28
    v.extract    s21, v1, #0
    v.extract    s24, v1, #1
    v.splat      v5, s21
    v.splat      v6, s24
    v.extract    s21, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s21
    a.vread      v5, a2, s30
    v.extract    s21, v1, #3
    a.vread      v8, a2, s31
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s21
    v.extract    s21, v1, #4
    a.vread      v6, a2, s32
    v.splat      v7, s21
    vf.fma       v10, v3, v5, v9
    v.extract    s21, v1, #5
    s.movz       s24, #5
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v9, v4, v8, v10
    v.extract    s21, v1, #6
    s.movz       s24, #6
    v.splat      v4, s21
    a.vread      v8, a2, s24
    vf.fma       v10, v7, v6, v9
    v.extract    s21, v1, #7
    s.movz       s24, #7
    v.splat      v6, s21
    a.vread      v7, a2, s24
    vf.fma       v9, v3, v5, v10
    v.extract    s21, v1, #8
    s.movz       s24, #8
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v10, v4, v8, v9
    s.movz       s21, #5
    v.extract    s24, v1, #9
    s.movz       s25, #9
    v.splat      v4, s24
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s25
    v.extract    s24, v1, #10
    s.movz       s25, #10
    v.splat      v7, s24
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #11
    s.movz       s25, #11
    v.splat      v5, s24
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #12
    s.movz       s25, #12
    v.splat      v6, s24
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #13
    s.movz       s25, #13
    v.splat      v7, s24
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #14
    s.movz       s25, #14
    v.splat      v5, s24
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #15
    s.movz       s25, #15
    v.splat      v1, s24
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s25
    s.movz       s24, #6
    s.movz       s25, #0
    s.movz       s28, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s30, #2
    s.movz       s31, #3
    s.movz       s32, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s21, v3
    a.vread      v1, a1, s24
    a.vread      v3, a2, s25
    a.vread      v4, a2, s28
    v.extract    s21, v1, #0
    v.extract    s24, v1, #1
    v.splat      v5, s21
    v.splat      v6, s24
    v.extract    s21, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s21
    a.vread      v5, a2, s30
    v.extract    s21, v1, #3
    a.vread      v8, a2, s31
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s21
    v.extract    s21, v1, #4
    a.vread      v6, a2, s32
    v.splat      v7, s21
    vf.fma       v10, v3, v5, v9
    v.extract    s21, v1, #5
    s.movz       s24, #5
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v9, v4, v8, v10
    v.extract    s21, v1, #6
    s.movz       s24, #6
    v.splat      v4, s21
    a.vread      v8, a2, s24
    vf.fma       v10, v7, v6, v9
    v.extract    s21, v1, #7
    s.movz       s24, #7
    v.splat      v6, s21
    a.vread      v7, a2, s24
    vf.fma       v9, v3, v5, v10
    v.extract    s21, v1, #8
    s.movz       s24, #8
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v10, v4, v8, v9
    s.movz       s21, #6
    v.extract    s24, v1, #9
    s.movz       s25, #9
    v.splat      v4, s24
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s25
    v.extract    s24, v1, #10
    s.movz       s25, #10
    v.splat      v7, s24
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #11
    s.movz       s25, #11
    v.splat      v5, s24
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #12
    s.movz       s25, #12
    v.splat      v6, s24
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #13
    s.movz       s25, #13
    v.splat      v7, s24
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #14
    s.movz       s25, #14
    v.splat      v5, s24
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #15
    s.movz       s25, #15
    v.splat      v1, s24
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s25
    s.movz       s24, #7
    s.movz       s25, #0
    s.movz       s28, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s30, #2
    s.movz       s31, #3
    s.movz       s32, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s21, v3
    a.vread      v1, a1, s24
    a.vread      v3, a2, s25
    a.vread      v4, a2, s28
    v.extract    s21, v1, #0
    v.extract    s24, v1, #1
    v.splat      v5, s21
    v.splat      v6, s24
    v.extract    s21, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s21
    a.vread      v5, a2, s30
    v.extract    s21, v1, #3
    a.vread      v8, a2, s31
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s21
    v.extract    s21, v1, #4
    a.vread      v6, a2, s32
    v.splat      v7, s21
    vf.fma       v10, v3, v5, v9
    v.extract    s21, v1, #5
    s.movz       s24, #5
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v9, v4, v8, v10
    v.extract    s21, v1, #6
    s.movz       s24, #6
    v.splat      v4, s21
    a.vread      v8, a2, s24
    vf.fma       v10, v7, v6, v9
    v.extract    s21, v1, #7
    s.movz       s24, #7
    v.splat      v6, s21
    a.vread      v7, a2, s24
    vf.fma       v9, v3, v5, v10
    v.extract    s21, v1, #8
    s.movz       s24, #8
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v10, v4, v8, v9
    s.movz       s21, #7
    v.extract    s24, v1, #9
    s.movz       s25, #9
    v.splat      v4, s24
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s25
    v.extract    s24, v1, #10
    s.movz       s25, #10
    v.splat      v7, s24
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #11
    s.movz       s25, #11
    v.splat      v5, s24
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #12
    s.movz       s25, #12
    v.splat      v6, s24
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #13
    s.movz       s25, #13
    v.splat      v7, s24
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #14
    s.movz       s25, #14
    v.splat      v5, s24
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #15
    s.movz       s25, #15
    v.splat      v1, s24
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s25
    s.movz       s24, #8
    s.movz       s25, #0
    s.movz       s28, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s30, #2
    s.movz       s31, #3
    s.movz       s32, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s21, v3
    a.vread      v1, a1, s24
    a.vread      v3, a2, s25
    a.vread      v4, a2, s28
    v.extract    s21, v1, #0
    v.extract    s24, v1, #1
    v.splat      v5, s21
    v.splat      v6, s24
    v.extract    s21, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s21
    a.vread      v5, a2, s30
    v.extract    s21, v1, #3
    a.vread      v8, a2, s31
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s21
    v.extract    s21, v1, #4
    a.vread      v6, a2, s32
    v.splat      v7, s21
    vf.fma       v10, v3, v5, v9
    v.extract    s21, v1, #5
    s.movz       s24, #5
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v9, v4, v8, v10
    v.extract    s21, v1, #6
    s.movz       s24, #6
    v.splat      v4, s21
    a.vread      v8, a2, s24
    vf.fma       v10, v7, v6, v9
    v.extract    s21, v1, #7
    s.movz       s24, #7
    v.splat      v6, s21
    a.vread      v7, a2, s24
    vf.fma       v9, v3, v5, v10
    v.extract    s21, v1, #8
    s.movz       s24, #8
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v10, v4, v8, v9
    s.movz       s21, #8
    v.extract    s24, v1, #9
    s.movz       s25, #9
    v.splat      v4, s24
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s25
    v.extract    s24, v1, #10
    s.movz       s25, #10
    v.splat      v7, s24
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #11
    s.movz       s25, #11
    v.splat      v5, s24
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #12
    s.movz       s25, #12
    v.splat      v6, s24
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #13
    s.movz       s25, #13
    v.splat      v7, s24
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #14
    s.movz       s25, #14
    v.splat      v5, s24
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #15
    s.movz       s25, #15
    v.splat      v1, s24
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s25
    s.movz       s24, #9
    s.movz       s25, #0
    s.movz       s28, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s30, #2
    s.movz       s31, #3
    s.movz       s32, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s21, v3
    a.vread      v1, a1, s24
    a.vread      v3, a2, s25
    a.vread      v4, a2, s28
    v.extract    s21, v1, #0
    v.extract    s24, v1, #1
    v.splat      v5, s21
    v.splat      v6, s24
    v.extract    s21, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s21
    a.vread      v5, a2, s30
    v.extract    s21, v1, #3
    a.vread      v8, a2, s31
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s21
    v.extract    s21, v1, #4
    a.vread      v6, a2, s32
    v.splat      v7, s21
    vf.fma       v10, v3, v5, v9
    v.extract    s21, v1, #5
    s.movz       s24, #5
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v9, v4, v8, v10
    v.extract    s21, v1, #6
    s.movz       s24, #6
    v.splat      v4, s21
    a.vread      v8, a2, s24
    vf.fma       v10, v7, v6, v9
    v.extract    s21, v1, #7
    s.movz       s24, #7
    v.splat      v6, s21
    a.vread      v7, a2, s24
    vf.fma       v9, v3, v5, v10
    v.extract    s21, v1, #8
    s.movz       s24, #8
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v10, v4, v8, v9
    s.movz       s21, #9
    v.extract    s24, v1, #9
    s.movz       s25, #9
    v.splat      v4, s24
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s25
    v.extract    s24, v1, #10
    s.movz       s25, #10
    v.splat      v7, s24
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #11
    s.movz       s25, #11
    v.splat      v5, s24
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #12
    s.movz       s25, #12
    v.splat      v6, s24
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #13
    s.movz       s25, #13
    v.splat      v7, s24
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #14
    s.movz       s25, #14
    v.splat      v5, s24
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #15
    s.movz       s25, #15
    v.splat      v1, s24
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s25
    s.movz       s24, #10
    s.movz       s25, #0
    s.movz       s28, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s30, #2
    s.movz       s31, #3
    s.movz       s32, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s21, v3
    a.vread      v1, a1, s24
    a.vread      v3, a2, s25
    a.vread      v4, a2, s28
    v.extract    s21, v1, #0
    v.extract    s24, v1, #1
    v.splat      v5, s21
    v.splat      v6, s24
    v.extract    s21, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s21
    a.vread      v5, a2, s30
    v.extract    s21, v1, #3
    a.vread      v8, a2, s31
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s21
    v.extract    s21, v1, #4
    a.vread      v6, a2, s32
    v.splat      v7, s21
    vf.fma       v10, v3, v5, v9
    v.extract    s21, v1, #5
    s.movz       s24, #5
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v9, v4, v8, v10
    v.extract    s21, v1, #6
    s.movz       s24, #6
    v.splat      v4, s21
    a.vread      v8, a2, s24
    vf.fma       v10, v7, v6, v9
    v.extract    s21, v1, #7
    s.movz       s24, #7
    v.splat      v6, s21
    a.vread      v7, a2, s24
    vf.fma       v9, v3, v5, v10
    v.extract    s21, v1, #8
    s.movz       s24, #8
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v10, v4, v8, v9
    s.movz       s21, #10
    v.extract    s24, v1, #9
    s.movz       s25, #9
    v.splat      v4, s24
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s25
    v.extract    s24, v1, #10
    s.movz       s25, #10
    v.splat      v7, s24
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #11
    s.movz       s25, #11
    v.splat      v5, s24
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #12
    s.movz       s25, #12
    v.splat      v6, s24
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #13
    s.movz       s25, #13
    v.splat      v7, s24
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #14
    s.movz       s25, #14
    v.splat      v5, s24
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #15
    s.movz       s25, #15
    v.splat      v1, s24
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s25
    s.movz       s24, #11
    s.movz       s25, #0
    s.movz       s28, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s30, #2
    s.movz       s31, #3
    s.movz       s32, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s21, v3
    a.vread      v1, a1, s24
    a.vread      v3, a2, s25
    a.vread      v4, a2, s28
    v.extract    s21, v1, #0
    v.extract    s24, v1, #1
    v.splat      v5, s21
    v.splat      v6, s24
    v.extract    s21, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s21
    a.vread      v5, a2, s30
    v.extract    s21, v1, #3
    a.vread      v8, a2, s31
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s21
    v.extract    s21, v1, #4
    a.vread      v6, a2, s32
    v.splat      v7, s21
    vf.fma       v10, v3, v5, v9
    v.extract    s21, v1, #5
    s.movz       s24, #5
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v9, v4, v8, v10
    v.extract    s21, v1, #6
    s.movz       s24, #6
    v.splat      v4, s21
    a.vread      v8, a2, s24
    vf.fma       v10, v7, v6, v9
    v.extract    s21, v1, #7
    s.movz       s24, #7
    v.splat      v6, s21
    a.vread      v7, a2, s24
    vf.fma       v9, v3, v5, v10
    v.extract    s21, v1, #8
    s.movz       s24, #8
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v10, v4, v8, v9
    s.movz       s21, #11
    v.extract    s24, v1, #9
    s.movz       s25, #9
    v.splat      v4, s24
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s25
    v.extract    s24, v1, #10
    s.movz       s25, #10
    v.splat      v7, s24
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #11
    s.movz       s25, #11
    v.splat      v5, s24
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #12
    s.movz       s25, #12
    v.splat      v6, s24
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #13
    s.movz       s25, #13
    v.splat      v7, s24
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #14
    s.movz       s25, #14
    v.splat      v5, s24
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #15
    s.movz       s25, #15
    v.splat      v1, s24
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s25
    s.movz       s24, #12
    s.movz       s25, #0
    s.movz       s28, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s30, #2
    s.movz       s31, #3
    s.movz       s32, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s21, v3
    a.vread      v1, a1, s24
    a.vread      v3, a2, s25
    a.vread      v4, a2, s28
    v.extract    s21, v1, #0
    v.extract    s24, v1, #1
    v.splat      v5, s21
    v.splat      v6, s24
    v.extract    s21, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s21
    a.vread      v5, a2, s30
    v.extract    s21, v1, #3
    a.vread      v8, a2, s31
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s21
    v.extract    s21, v1, #4
    a.vread      v6, a2, s32
    v.splat      v7, s21
    vf.fma       v10, v3, v5, v9
    v.extract    s21, v1, #5
    s.movz       s24, #5
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v9, v4, v8, v10
    v.extract    s21, v1, #6
    s.movz       s24, #6
    v.splat      v4, s21
    a.vread      v8, a2, s24
    vf.fma       v10, v7, v6, v9
    v.extract    s21, v1, #7
    s.movz       s24, #7
    v.splat      v6, s21
    a.vread      v7, a2, s24
    vf.fma       v9, v3, v5, v10
    v.extract    s21, v1, #8
    s.movz       s24, #8
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v10, v4, v8, v9
    s.movz       s21, #12
    v.extract    s24, v1, #9
    s.movz       s25, #9
    v.splat      v4, s24
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s25
    v.extract    s24, v1, #10
    s.movz       s25, #10
    v.splat      v7, s24
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #11
    s.movz       s25, #11
    v.splat      v5, s24
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #12
    s.movz       s25, #12
    v.splat      v6, s24
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #13
    s.movz       s25, #13
    v.splat      v7, s24
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #14
    s.movz       s25, #14
    v.splat      v5, s24
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #15
    s.movz       s25, #15
    v.splat      v1, s24
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s25
    s.movz       s24, #13
    s.movz       s25, #0
    s.movz       s28, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s30, #2
    s.movz       s31, #3
    s.movz       s32, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s21, v3
    a.vread      v1, a1, s24
    a.vread      v3, a2, s25
    a.vread      v4, a2, s28
    v.extract    s21, v1, #0
    v.extract    s24, v1, #1
    v.splat      v5, s21
    v.splat      v6, s24
    v.extract    s21, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s21
    a.vread      v5, a2, s30
    v.extract    s21, v1, #3
    a.vread      v8, a2, s31
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s21
    v.extract    s21, v1, #4
    a.vread      v6, a2, s32
    v.splat      v7, s21
    vf.fma       v10, v3, v5, v9
    v.extract    s21, v1, #5
    s.movz       s24, #5
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v9, v4, v8, v10
    v.extract    s21, v1, #6
    s.movz       s24, #6
    v.splat      v4, s21
    a.vread      v8, a2, s24
    vf.fma       v10, v7, v6, v9
    v.extract    s21, v1, #7
    s.movz       s24, #7
    v.splat      v6, s21
    a.vread      v7, a2, s24
    vf.fma       v9, v3, v5, v10
    v.extract    s21, v1, #8
    s.movz       s24, #8
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v10, v4, v8, v9
    s.movz       s21, #13
    v.extract    s24, v1, #9
    s.movz       s25, #9
    v.splat      v4, s24
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s25
    v.extract    s24, v1, #10
    s.movz       s25, #10
    v.splat      v7, s24
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #11
    s.movz       s25, #11
    v.splat      v5, s24
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #12
    s.movz       s25, #12
    v.splat      v6, s24
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #13
    s.movz       s25, #13
    v.splat      v7, s24
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #14
    s.movz       s25, #14
    v.splat      v5, s24
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #15
    s.movz       s25, #15
    v.splat      v1, s24
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s25
    s.movz       s24, #14
    s.movz       s25, #0
    s.movz       s28, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s30, #2
    s.movz       s31, #3
    s.movz       s32, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s21, v3
    a.vread      v1, a1, s24
    a.vread      v3, a2, s25
    a.vread      v4, a2, s28
    v.extract    s21, v1, #0
    v.extract    s24, v1, #1
    v.splat      v5, s21
    v.splat      v6, s24
    v.extract    s21, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s21
    a.vread      v5, a2, s30
    v.extract    s21, v1, #3
    a.vread      v8, a2, s31
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s21
    v.extract    s21, v1, #4
    a.vread      v6, a2, s32
    v.splat      v7, s21
    vf.fma       v10, v3, v5, v9
    v.extract    s21, v1, #5
    s.movz       s24, #5
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v9, v4, v8, v10
    v.extract    s21, v1, #6
    s.movz       s24, #6
    v.splat      v4, s21
    a.vread      v8, a2, s24
    vf.fma       v10, v7, v6, v9
    v.extract    s21, v1, #7
    s.movz       s24, #7
    v.splat      v6, s21
    a.vread      v7, a2, s24
    vf.fma       v9, v3, v5, v10
    v.extract    s21, v1, #8
    s.movz       s24, #8
    v.splat      v3, s21
    a.vread      v5, a2, s24
    vf.fma       v10, v4, v8, v9
    s.movz       s21, #14
    v.extract    s24, v1, #9
    s.movz       s25, #9
    v.splat      v4, s24
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s25
    v.extract    s24, v1, #10
    s.movz       s25, #10
    v.splat      v7, s24
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #11
    s.movz       s25, #11
    v.splat      v5, s24
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #12
    s.movz       s25, #12
    v.splat      v6, s24
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #13
    s.movz       s25, #13
    v.splat      v7, s24
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s25
    v.extract    s24, v1, #14
    s.movz       s25, #14
    v.splat      v5, s24
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #15
    s.movz       s25, #15
    v.splat      v1, s24
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s25
    s.movz       s24, #15
    s.movz       s25, #0
    s.movz       s28, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s30, #2
    s.movz       s31, #3
    s.movz       s32, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s21, v3
    a.vread      v1, a1, s24
    a.vread      v3, a2, s25
    a.vread      v4, a2, s28
    v.extract    s21, v1, #0
    v.extract    s24, v1, #1
    v.splat      v5, s21
    v.splat      v6, s24
    v.extract    s21, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v2, s21
    a.vread      v3, a2, s30
    v.extract    s21, v1, #3
    a.vread      v5, a2, s31
    vf.fma       v8, v6, v4, v7
    v.splat      v4, s21
    v.extract    s21, v1, #4
    a.vread      v6, a2, s32
    v.splat      v7, s21
    vf.fma       v9, v2, v3, v8
    v.extract    s21, v1, #5
    s.movz       s24, #5
    v.splat      v2, s21
    a.vread      v3, a2, s24
    vf.fma       v8, v4, v5, v9
    v.extract    s21, v1, #6
    s.movz       s24, #6
    v.splat      v4, s21
    a.vread      v5, a2, s24
    vf.fma       v9, v7, v6, v8
    v.extract    s21, v1, #7
    s.movz       s24, #7
    v.splat      v6, s21
    a.vread      v7, a2, s24
    vf.fma       v8, v2, v3, v9
    v.extract    s21, v1, #8
    s.movz       s24, #8
    v.splat      v2, s21
    a.vread      v3, a2, s24
    vf.fma       v9, v4, v5, v8
    s.movz       s21, #15
    v.extract    s24, v1, #9
    s.movz       s25, #9
    v.splat      v4, s24
    vf.fma       v5, v6, v7, v9
    a.vread      v6, a2, s25
    v.extract    s24, v1, #10
    s.movz       s25, #10
    v.splat      v7, s24
    vf.fma       v8, v2, v3, v5
    a.vread      v2, a2, s25
    v.extract    s24, v1, #11
    s.movz       s25, #11
    v.splat      v3, s24
    vf.fma       v5, v4, v6, v8
    a.vread      v4, a2, s25
    v.extract    s24, v1, #12
    s.movz       s25, #12
    v.splat      v6, s24
    vf.fma       v8, v7, v2, v5
    a.vread      v2, a2, s25
    v.extract    s24, v1, #13
    s.movz       s25, #13
    v.splat      v5, s24
    vf.fma       v7, v3, v4, v8
    a.vread      v3, a2, s25
    v.extract    s24, v1, #14
    s.movz       s25, #14
    v.splat      v4, s24
    vf.fma       v8, v6, v2, v7
    a.vread      v2, a2, s25
    v.extract    s24, v1, #15
    s.movz       s25, #15
    v.splat      v1, s24
    vf.fma       v6, v5, v3, v8
    a.vread      v3, a2, s25
    s.addi       s24, s26, #0
    v.splat      v5, s2
    s.addi       s25, s26, #2048
    vf.fma       v7, v4, v2, v6
    s.addi       s28, s26, #64
    s.addi       s30, s25, #64
    s.addi       s31, s26, #128
    s.addi       s32, s25, #128
    vf.fma       v2, v1, v3, v7
    a.vwrite     a3, s21, v2
    v.ld.w       v1, [s24, #0]
    s.addi       s21, s26, #192
    s.addi       s24, s25, #192
    v.add        v2, v1, v5
    v.st.w       [s25, #0], v2
    v.ld.w       v1, [s28, #0]
    s.addi       s28, s26, #256
    v.add        v2, v1, v5
    v.st.w       [s30, #0], v2
    s.addi       s30, s25, #256
    v.ld.w       v1, [s31, #0]
    s.addi       s31, s26, #320
    v.add        v2, v1, v5
    v.st.w       [s32, #0], v2
    s.addi       s32, s25, #320
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s26, #384
    v.add        v2, v1, v5
    v.st.w       [s24, #0], v2
    s.addi       s24, s25, #384
    v.ld.w       v1, [s28, #0]
    s.addi       s28, s26, #448
    v.add        v2, v1, v5
    v.st.w       [s30, #0], v2
    s.addi       s30, s25, #448
    v.ld.w       v1, [s31, #0]
    s.addi       s31, s26, #512
    v.add        v2, v1, v5
    v.st.w       [s32, #0], v2
    s.addi       s32, s25, #512
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s26, #576
    v.add        v2, v1, v5
    v.st.w       [s24, #0], v2
    s.addi       s24, s25, #576
    v.ld.w       v1, [s28, #0]
    s.addi       s28, s26, #640
    v.add        v2, v1, v5
    v.st.w       [s30, #0], v2
    s.addi       s30, s25, #640
    v.ld.w       v1, [s31, #0]
    s.addi       s31, s26, #704
    v.add        v2, v1, v5
    v.st.w       [s32, #0], v2
    s.addi       s32, s25, #704
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s26, #768
    v.add        v2, v1, v5
    v.st.w       [s24, #0], v2
    s.addi       s24, s25, #768
    v.ld.w       v1, [s28, #0]
    s.addi       s28, s26, #832
    v.add        v2, v1, v5
    v.st.w       [s30, #0], v2
    s.addi       s30, s25, #832
    v.ld.w       v1, [s31, #0]
    s.addi       s31, s26, #896
    v.add        v2, v1, v5
    v.st.w       [s32, #0], v2
    s.addi       s32, s25, #896
    s.addi       s33, s25, #960
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s26, #960
    v.add        v2, v1, v5
    v.st.w       [s24, #0], v2
    s.addi       s24, s26, #1024
    v.ld.w       v1, [s28, #0]
    s.movz       s25, #1024
    v.splat      v2, s25
    s.addi       s25, s26, #3072
    v.add        v3, v1, v5
    v.st.w       [s30, #0], v3
    s.addi       s28, s26, #1088
    v.ld.w       v1, [s31, #0]
    s.addi       s30, s25, #64
    v.add        v3, v1, v5
    v.st.w       [s32, #0], v3
    s.addi       s31, s26, #1152
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s25, #128
    v.add        v3, v1, v5
    v.st.w       [s33, #0], v3
    fence.acq_rel.device
    s.addi       s32, s26, #1216
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s25, #192
    v.add        v3, v1, v2
    v.st.w       [s25, #0], v3
    v.ld.w       v1, [s28, #0]
    s.addi       s28, s26, #1280
    v.add        v3, v1, v2
    v.st.w       [s30, #0], v3
    s.addi       s30, s25, #256
    v.ld.w       v1, [s31, #0]
    s.addi       s31, s26, #1344
    v.add        v3, v1, v2
    v.st.w       [s21, #0], v3
    s.addi       s21, s25, #320
    v.ld.w       v1, [s32, #0]
    s.addi       s32, s26, #1408
    v.add        v3, v1, v2
    v.st.w       [s24, #0], v3
    s.addi       s24, s25, #384
    v.ld.w       v1, [s28, #0]
    s.addi       s28, s26, #1472
    v.add        v3, v1, v2
    v.st.w       [s30, #0], v3
    s.addi       s30, s25, #448
    v.ld.w       v1, [s31, #0]
    s.addi       s31, s26, #1536
    v.add        v3, v1, v2
    v.st.w       [s21, #0], v3
    s.addi       s21, s25, #512
    v.ld.w       v1, [s32, #0]
    s.addi       s32, s26, #1600
    v.add        v3, v1, v2
    v.st.w       [s24, #0], v3
    s.addi       s24, s25, #576
    v.ld.w       v1, [s28, #0]
    s.addi       s28, s26, #1664
    v.add        v3, v1, v2
    v.st.w       [s30, #0], v3
    s.addi       s30, s25, #640
    v.ld.w       v1, [s31, #0]
    s.addi       s31, s26, #1728
    v.add        v3, v1, v2
    v.st.w       [s21, #0], v3
    s.addi       s21, s25, #704
    v.ld.w       v1, [s32, #0]
    s.addi       s32, s26, #1792
    v.add        v3, v1, v2
    v.st.w       [s24, #0], v3
    s.addi       s24, s25, #768
    v.ld.w       v1, [s28, #0]
    s.addi       s28, s26, #1856
    v.add        v3, v1, v2
    v.st.w       [s30, #0], v3
    s.addi       s30, s25, #832
    v.ld.w       v1, [s31, #0]
    s.addi       s31, s26, #1920
    v.add        v3, v1, v2
    v.st.w       [s21, #0], v3
    s.addi       s21, s25, #896
    s.addi       s33, s25, #960
    v.ld.w       v1, [s32, #0]
    s.addi       s25, s26, #1984
    v.add        v3, v1, v2
    v.st.w       [s24, #0], v3
    s.addi       s24, s26, #2048
    v.ld.w       v1, [s28, #0]
    s.addi       s28, s26, #4096
    v.add        v3, v1, v2
    v.st.w       [s30, #0], v3
    s.addi       s30, s26, #2112
    v.ld.w       v1, [s31, #0]
    s.addi       s31, s28, #64
    v.add        v3, v1, v2
    v.st.w       [s21, #0], v3
    s.addi       s21, s26, #2176
    v.ld.w       v1, [s25, #0]
    s.addi       s25, s28, #128
    v.add        v3, v1, v2
    v.st.w       [s33, #0], v3
    fence.acq_rel.device
    s.addi       s32, s26, #2240
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s28, #192
    v.st.w       [s28, #0], v1
    v.ld.w       v1, [s30, #0]
    s.addi       s30, s26, #2304
    v.st.w       [s31, #0], v1
    s.addi       s31, s28, #256
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s26, #2368
    v.st.w       [s25, #0], v1
    s.addi       s25, s28, #320
    v.ld.w       v1, [s32, #0]
    s.addi       s32, s26, #2432
    v.st.w       [s24, #0], v1
    s.addi       s24, s28, #384
    v.ld.w       v1, [s30, #0]
    s.addi       s30, s26, #2496
    v.st.w       [s31, #0], v1
    s.addi       s31, s28, #448
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s26, #2560
    v.st.w       [s25, #0], v1
    s.addi       s25, s28, #512
    v.ld.w       v1, [s32, #0]
    s.addi       s32, s26, #2624
    v.st.w       [s24, #0], v1
    s.addi       s24, s28, #576
    v.ld.w       v1, [s30, #0]
    s.addi       s30, s26, #2688
    v.st.w       [s31, #0], v1
    s.addi       s31, s28, #640
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s26, #2752
    v.st.w       [s25, #0], v1
    s.addi       s25, s28, #704
    v.ld.w       v1, [s32, #0]
    s.addi       s32, s26, #2816
    v.st.w       [s24, #0], v1
    s.addi       s24, s28, #768
    v.ld.w       v1, [s30, #0]
    s.addi       s30, s26, #2880
    v.st.w       [s31, #0], v1
    s.addi       s31, s28, #832
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s26, #2944
    v.st.w       [s25, #0], v1
    s.addi       s25, s28, #896
    s.addi       s33, s28, #960
    v.ld.w       v1, [s32, #0]
    s.addi       s28, s26, #3008
    v.st.w       [s24, #0], v1
    s.addi       s24, s26, #3072
    v.ld.w       v1, [s30, #0]
    s.addi       s30, s26, #5120
    v.st.w       [s31, #0], v1
    s.addi       s31, s26, #3136
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s30, #64
    v.st.w       [s25, #0], v1
    s.addi       s25, s26, #3200
    v.ld.w       v1, [s28, #0]
    s.addi       s28, s30, #128
    v.st.w       [s33, #0], v1
    fence.acq_rel.device
    s.addi       s32, s26, #3264
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s30, #192
    v.st.w       [s30, #0], v1
    v.ld.w       v1, [s31, #0]
    s.addi       s31, s26, #3328
    v.st.w       [s21, #0], v1
    s.addi       s21, s30, #256
    v.ld.w       v1, [s25, #0]
    s.addi       s25, s26, #3392
    v.st.w       [s28, #0], v1
    s.addi       s28, s30, #320
    v.ld.w       v1, [s32, #0]
    s.addi       s32, s26, #3456
    v.st.w       [s24, #0], v1
    s.addi       s24, s30, #384
    v.ld.w       v1, [s31, #0]
    s.addi       s31, s26, #3520
    v.st.w       [s21, #0], v1
    s.addi       s21, s30, #448
    v.ld.w       v1, [s25, #0]
    s.addi       s25, s26, #3584
    v.st.w       [s28, #0], v1
    s.addi       s28, s30, #512
    v.ld.w       v1, [s32, #0]
    s.addi       s32, s26, #3648
    v.st.w       [s24, #0], v1
    s.addi       s24, s30, #576
    v.ld.w       v1, [s31, #0]
    s.addi       s31, s26, #3712
    v.st.w       [s21, #0], v1
    s.addi       s21, s30, #640
    v.ld.w       v1, [s25, #0]
    s.addi       s25, s26, #3776
    v.st.w       [s28, #0], v1
    s.addi       s28, s30, #704
    v.ld.w       v1, [s32, #0]
    s.addi       s32, s26, #3840
    v.st.w       [s24, #0], v1
    s.addi       s24, s30, #768
    v.ld.w       v1, [s31, #0]
    s.addi       s31, s26, #3904
    v.st.w       [s21, #0], v1
    s.addi       s21, s30, #832
    v.ld.w       v1, [s25, #0]
    s.addi       s25, s26, #3968
    v.st.w       [s28, #0], v1
    s.addi       s28, s30, #896
    s.addi       s33, s30, #960
    v.ld.w       v1, [s32, #0]
    s.addi       s30, s26, #4032
    v.st.w       [s24, #0], v1
    s.movz       s24, #0
    v.ld.w       v1, [s31, #0]
    s.movz       s31, #0
    v.st.w       [s21, #0], v1
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s21, #0
    v.ld.w       v1, [s25, #0]
    s.movz       s25, #1
    v.st.w       [s28, #0], v1
    s.movz       s28, #1
    v.ld.w       v1, [s30, #0]
    s.movz       s30, #1
    v.st.w       [s33, #0], v1
    fence.acq_rel.device
    a.vread      v1, a0, s24
    a.vread      v2, a3, s31
    s.movz       s24, #2
    s.movz       s31, #2
    vf.add       v3, v1, v2
    s.movz       s32, #2
    a.vwrite     a4, s21, v3
    a.vread      v1, a0, s25
    a.vread      v2, a3, s28
    s.movz       s21, #3
    s.movz       s25, #3
    vf.add       v3, v1, v2
    s.movz       s28, #3
    a.vwrite     a4, s30, v3
    a.vread      v1, a0, s24
    a.vread      v2, a3, s31
    s.movz       s24, #4
    s.movz       s30, #4
    vf.add       v3, v1, v2
    s.movz       s31, #4
    a.vwrite     a4, s32, v3
    a.vread      v1, a0, s21
    a.vread      v2, a3, s25
    s.movz       s21, #5
    s.movz       s25, #5
    vf.add       v3, v1, v2
    s.movz       s32, #5
    a.vwrite     a4, s28, v3
    a.vread      v1, a0, s24
    a.vread      v2, a3, s30
    s.movz       s24, #6
    s.movz       s28, #6
    vf.add       v3, v1, v2
    s.movz       s30, #6
    a.vwrite     a4, s31, v3
    a.vread      v1, a0, s21
    a.vread      v2, a3, s25
    s.movz       s21, #7
    s.movz       s25, #7
    vf.add       v3, v1, v2
    s.movz       s31, #7
    a.vwrite     a4, s32, v3
    a.vread      v1, a0, s24
    a.vread      v2, a3, s28
    s.movz       s24, #8
    s.movz       s28, #8
    vf.add       v3, v1, v2
    s.movz       s32, #8
    a.vwrite     a4, s30, v3
    a.vread      v1, a0, s21
    a.vread      v2, a3, s25
    s.movz       s21, #9
    s.movz       s25, #9
    vf.add       v3, v1, v2
    s.movz       s30, #9
    a.vwrite     a4, s31, v3
    a.vread      v1, a0, s24
    a.vread      v2, a3, s28
    s.movz       s24, #10
    s.movz       s28, #10
    vf.add       v3, v1, v2
    s.movz       s31, #10
    a.vwrite     a4, s32, v3
    a.vread      v1, a0, s21
    a.vread      v2, a3, s25
    s.movz       s21, #11
    s.movz       s25, #11
    vf.add       v3, v1, v2
    s.movz       s32, #11
    a.vwrite     a4, s30, v3
    a.vread      v1, a0, s24
    a.vread      v2, a3, s28
    s.movz       s24, #12
    s.movz       s28, #12
    vf.add       v3, v1, v2
    s.movz       s30, #12
    a.vwrite     a4, s31, v3
    a.vread      v1, a0, s21
    a.vread      v2, a3, s25
    s.movz       s21, #13
    s.movz       s25, #13
    vf.add       v3, v1, v2
    s.movz       s31, #13
    a.vwrite     a4, s32, v3
    a.vread      v1, a0, s24
    a.vread      v2, a3, s28
    s.movz       s24, #14
    s.movz       s28, #14
    vf.add       v3, v1, v2
    s.movz       s32, #14
    a.vwrite     a4, s30, v3
    a.vread      v1, a0, s21
    a.vread      v2, a3, s25
    s.movz       s21, #15
    s.movz       s25, #15
    vf.add       v3, v1, v2
    s.movz       s30, #15
    a.vwrite     a4, s31, v3
    a.vread      v1, a0, s24
    a.vread      v2, a3, s28
    s.addi       s24, s26, #4096
    s.addi       s28, s26, #0
    vf.add       v3, v1, v2
    s.addi       s31, s26, #4160
    a.vwrite     a4, s32, v3
    a.vread      v1, a0, s21
    a.vread      v2, a3, s25
    s.addi       s21, s26, #64
    s.addi       s25, s26, #4224
    vf.add       v3, v1, v2
    s.addi       s32, s26, #128
    a.vwrite     a4, s30, v3
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s26, #4288
    s.addi       s30, s26, #192
    v.st.w       [s28, #0], v1
    s.addi       s28, s26, #4352
    v.ld.w       v1, [s31, #0]
    s.addi       s31, s26, #256
    v.st.w       [s21, #0], v1
    s.addi       s21, s26, #4416
    v.ld.w       v1, [s25, #0]
    s.addi       s25, s26, #320
    v.st.w       [s32, #0], v1
    s.addi       s32, s26, #4480
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s26, #384
    v.st.w       [s30, #0], v1
    s.addi       s30, s26, #4544
    v.ld.w       v1, [s28, #0]
    s.addi       s28, s26, #448
    v.st.w       [s31, #0], v1
    s.addi       s31, s26, #4608
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s26, #512
    v.st.w       [s25, #0], v1
    s.addi       s25, s26, #4672
    v.ld.w       v1, [s32, #0]
    s.addi       s32, s26, #576
    v.st.w       [s24, #0], v1
    s.addi       s24, s26, #4736
    v.ld.w       v1, [s30, #0]
    s.addi       s30, s26, #640
    v.st.w       [s28, #0], v1
    s.addi       s28, s26, #4800
    v.ld.w       v1, [s31, #0]
    s.addi       s31, s26, #704
    v.st.w       [s21, #0], v1
    s.addi       s21, s26, #4864
    v.ld.w       v1, [s25, #0]
    s.addi       s25, s26, #768
    v.st.w       [s32, #0], v1
    s.addi       s32, s26, #4928
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s26, #832
    v.st.w       [s30, #0], v1
    s.addi       s30, s26, #4992
    v.ld.w       v1, [s28, #0]
    s.addi       s28, s26, #896
    v.st.w       [s31, #0], v1
    s.addi       s31, s26, #5056
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s26, #960
    v.st.w       [s25, #0], v1
    s.addi       s25, s26, #5120
    v.ld.w       v1, [s32, #0]
    s.addi       s32, s26, #1024
    v.st.w       [s24, #0], v1
    s.addi       s24, s26, #5184
    v.ld.w       v1, [s30, #0]
    s.addi       s30, s26, #1088
    v.st.w       [s28, #0], v1
    s.addi       s28, s26, #5248
    v.ld.w       v1, [s31, #0]
    s.addi       s31, s26, #1152
    v.st.w       [s21, #0], v1
    fence.acq_rel.device
    s.addi       s21, s26, #5312
    v.ld.w       v1, [s25, #0]
    s.addi       s25, s26, #1216
    v.st.w       [s32, #0], v1
    s.addi       s32, s26, #5376
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s26, #1280
    v.st.w       [s30, #0], v1
    s.addi       s30, s26, #5440
    v.ld.w       v1, [s28, #0]
    s.addi       s28, s26, #1344
    v.st.w       [s31, #0], v1
    s.addi       s31, s26, #5504
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s26, #1408
    v.st.w       [s25, #0], v1
    s.addi       s25, s26, #5568
    v.ld.w       v1, [s32, #0]
    s.addi       s32, s26, #1472
    v.st.w       [s24, #0], v1
    s.addi       s24, s26, #5632
    v.ld.w       v1, [s30, #0]
    s.addi       s30, s26, #1536
    v.st.w       [s28, #0], v1
    s.addi       s28, s26, #5696
    v.ld.w       v1, [s31, #0]
    s.addi       s31, s26, #1600
    v.st.w       [s21, #0], v1
    s.addi       s21, s26, #5760
    v.ld.w       v1, [s25, #0]
    s.addi       s25, s26, #1664
    v.st.w       [s32, #0], v1
    s.addi       s32, s26, #5824
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s26, #1728
    v.st.w       [s30, #0], v1
    s.addi       s30, s26, #5888
    v.ld.w       v1, [s28, #0]
    s.addi       s28, s26, #1792
    v.st.w       [s31, #0], v1
    s.addi       s31, s26, #5952
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s26, #1856
    v.st.w       [s25, #0], v1
    s.addi       s25, s26, #6016
    v.ld.w       v1, [s32, #0]
    s.addi       s32, s26, #1920
    v.st.w       [s24, #0], v1
    s.addi       s24, s26, #6080
    s.addi       s33, s26, #1984
    v.ld.w       v1, [s30, #0]
    s.movz       s30, #0
    v.st.w       [s28, #0], v1
    s.movz       s28, #0
    v.ld.w       v1, [s31, #0]
    s.movz       s31, #1
    v.st.w       [s21, #0], v1
    s.movz       s21, #1
    v.ld.w       v1, [s25, #0]
    s.movz       s25, #2
    v.st.w       [s32, #0], v1
    s.movz       s32, #2
    v.ld.w       v1, [s24, #0]
    s.movz       s24, #3
    v.st.w       [s33, #0], v1
    fence.acq_rel.device
    a.vread      v1, a4, s30
    s.movz       s30, #3
    s.movz       s33, #4
    a.vwrite     a0, s28, v1
    a.vread      v1, a4, s31
    s.movz       s28, #4
    s.movz       s31, #5
    a.vwrite     a0, s21, v1
    a.vread      v1, a4, s25
    s.movz       s21, #5
    s.movz       s25, #6
    a.vwrite     a0, s32, v1
    a.vread      v1, a4, s24
    s.movz       s24, #6
    s.movz       s32, #7
    a.vwrite     a0, s30, v1
    a.vread      v1, a4, s33
    s.movz       s30, #7
    s.movz       s33, #8
    a.vwrite     a0, s28, v1
    a.vread      v1, a4, s31
    s.movz       s28, #8
    s.movz       s31, #9
    a.vwrite     a0, s21, v1
    a.vread      v1, a4, s25
    s.movz       s21, #9
    s.movz       s25, #10
    a.vwrite     a0, s24, v1
    a.vread      v1, a4, s32
    s.movz       s24, #10
    s.movz       s32, #11
    a.vwrite     a0, s30, v1
    a.vread      v1, a4, s33
    s.movz       s30, #11
    s.movz       s33, #12
    a.vwrite     a0, s28, v1
    a.vread      v1, a4, s31
    s.movz       s28, #12
    s.movz       s31, #13
    a.vwrite     a0, s21, v1
    a.vread      v1, a4, s25
    s.movz       s21, #13
    s.movz       s25, #14
    a.vwrite     a0, s24, v1
    a.vread      v1, a4, s32
    s.movz       s24, #14
    s.movz       s32, #15
    a.vwrite     a0, s30, v1
    a.vread      v1, a4, s33
    s.movz       s30, #15
    s.add        s33, s34, s2
    a.vwrite     a0, s28, v1
    a.vread      v1, a4, s31
    s.movz       s28, #1
    a.vwrite     a0, s21, v1
    a.vread      v1, a4, s25
    a.vwrite     a0, s24, v1
    a.vread      v1, a4, s32
    a.vwrite     a0, s30, v1
    s.mov        s34, s33
    br.nz        s28, for_5
endfor_6:
    s.movz       s21, #0
    s.mul        s24, s27, s29
    s.add        s25, s21, s22                   // the tile origin
    s.movz       s21, #0
    s.muli       s26, s22, #4                    // a runtime tile origin, x4
    v.splat      v1, s25
    s.add        s22, s21, s23                   // the tile origin
    s.movz       s21, #64
    s.muli       s25, s23, #256                  // a runtime tile origin, x256
    v.splat      v2, s22
    v.splat      v3, s20
    v.add        v4, v0, v1
    v.splat      v0, s21
    s.muli       s20, s24, #4                    // a runtime tile origin, x4
    s.addi       s21, s22, #1
    v.splat      v1, s27
    v.splat      v5, s2
    s.add        s2, s19, s26                    // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s23, #0
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v4, v0
    v.splat      v0, s21
    s.add        s21, s2, s25                    // the tile origin
    p.and        p3, p1, p2
    s.addi       s2, s22, #2
    v.cmp.lt     p1, v1, v5
    a.vread      v1, a0, s23
    s.add        s23, s21, s20                   // the tile origin
    p.and        p4, p3, p1
    s.movz       s20, #1
    v.cmp.lt     p3, v0, v3
    v.splat      v0, s2
    p.and        p5, p3, p2
    s.addi       s2, s22, #3
    @p4 v.st.w       [s23, #0], v1
    a.vread      v1, a0, s20
    s.addi       s20, s23, #256                  // row 1
    p.and        p3, p5, p1
    s.movz       s21, #2
    v.cmp.lt     p4, v0, v3
    v.splat      v0, s2
    p.and        p5, p4, p2
    s.addi       s2, s22, #4
    s.addi       s24, s23, #512                  // row 2
    p.and        p4, p5, p1
    s.movz       s25, #3
    v.splat      v2, s2
    s.addi       s2, s22, #5
    s.addi       s26, s23, #768                  // row 3
    s.movz       s27, #4
    v.splat      v4, s2
    s.addi       s2, s22, #6
    @p3 v.st.w       [s20, #0], v1
    a.vread      v1, a0, s21
    v.cmp.lt     p3, v0, v3
    p.and        p5, p3, p2
    s.addi       s20, s23, #1024                 // row 4
    p.and        p3, p5, p1
    s.movz       s21, #5
    v.splat      v0, s2
    s.addi       s2, s22, #7
    s.addi       s28, s23, #1280                 // row 5
    v.splat      v5, s2
    s.movz       s2, #6
    @p4 v.st.w       [s24, #0], v1
    a.vread      v1, a0, s25
    v.cmp.lt     p4, v2, v3
    p.and        p5, p4, p2
    s.addi       s24, s22, #8
    p.and        p4, p5, p1
    s.addi       s25, s23, #1536                 // row 6
    v.splat      v2, s24
    s.movz       s24, #7
    @p3 v.st.w       [s26, #0], v1
    a.vread      v1, a0, s27
    v.cmp.lt     p3, v4, v3
    p.and        p5, p3, p2
    s.addi       s26, s22, #9
    p.and        p3, p5, p1
    s.addi       s27, s23, #1792                 // row 7
    v.splat      v4, s26
    s.movz       s26, #8
    @p4 v.st.w       [s20, #0], v1
    a.vread      v1, a0, s21
    v.cmp.lt     p4, v0, v3
    p.and        p5, p4, p2
    s.addi       s20, s22, #10
    p.and        p4, p5, p1
    s.addi       s21, s23, #2048                 // row 8
    v.splat      v0, s20
    s.movz       s20, #9
    @p3 v.st.w       [s28, #0], v1
    a.vread      v1, a0, s2
    v.cmp.lt     p3, v5, v3
    p.and        p5, p3, p2
    s.addi       s2, s22, #11
    p.and        p3, p5, p1
    s.addi       s28, s23, #2304                 // row 9
    v.splat      v5, s2
    s.movz       s2, #10
    @p4 v.st.w       [s25, #0], v1
    a.vread      v1, a0, s24
    v.cmp.lt     p4, v2, v3
    p.and        p5, p4, p2
    s.addi       s24, s22, #12
    p.and        p4, p5, p1
    s.addi       s25, s23, #2560                 // row 10
    v.splat      v2, s24
    s.movz       s24, #11
    @p3 v.st.w       [s27, #0], v1
    a.vread      v1, a0, s26
    v.cmp.lt     p3, v4, v3
    p.and        p5, p3, p2
    s.addi       s26, s22, #13
    p.and        p3, p5, p1
    s.addi       s27, s23, #2816                 // row 11
    v.splat      v4, s26
    s.movz       s26, #12
    @p4 v.st.w       [s21, #0], v1
    a.vread      v1, a0, s20
    v.cmp.lt     p4, v0, v3
    p.and        p5, p4, p2
    s.addi       s20, s22, #14
    p.and        p4, p5, p1
    s.addi       s21, s23, #3072                 // row 12
    v.splat      v0, s20
    s.movz       s20, #13
    @p3 v.st.w       [s28, #0], v1
    a.vread      v1, a0, s2
    v.cmp.lt     p3, v5, v3
    p.and        p5, p3, p2
    s.addi       s2, s22, #15
    p.and        p3, p5, p1
    s.addi       s22, s23, #3328                 // row 13
    s.movz       s28, #14
    v.splat      v5, s2
    s.addi       s2, s23, #3584                  // row 14
    s.addi       s29, s23, #3840                 // row 15
    @p4 v.st.w       [s25, #0], v1
    a.vread      v1, a0, s24
    v.cmp.lt     p4, v2, v3
    p.and        p5, p4, p2
    s.movz       s23, #15
    p.and        p4, p5, p1
    @p3 v.st.w       [s27, #0], v1
    a.vread      v1, a0, s26
    v.cmp.lt     p3, v4, v3
    p.and        p5, p3, p2
    p.and        p3, p5, p1
    @p4 v.st.w       [s21, #0], v1
    a.vread      v1, a0, s20
    v.cmp.lt     p4, v0, v3
    p.and        p5, p4, p2
    p.and        p4, p5, p1
    @p3 v.st.w       [s22, #0], v1
    a.vread      v0, a0, s28
    v.cmp.lt     p3, v5, v3
    p.and        p5, p3, p2
    p.and        p2, p5, p1
    @p4 v.st.w       [s2, #0], v0
    a.vread      v0, a0, s23
    @p2 v.st.w       [s29, #0], v0
__rctx_next:
    s.addi       s2, s17, #2                     // the next program of this context: + 2
    s.cmp.lt     s20, s2, s18
    s.mov        s17, s2
    br.nz        s20, __rctx_program
    exit
