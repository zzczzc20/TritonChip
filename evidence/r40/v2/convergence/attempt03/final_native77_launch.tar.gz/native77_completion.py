from pathlib import Path
import json
import sys
root = Path(__file__).resolve().parent
sys.path[:0] = [str(root/'python'), str(root/'tools/r40')]
from tnca.device_timing import audit_graph_samples
import ablate
r = root/'native77_results'
identity = json.loads((r/'identity.json').read_text())
rows = [json.loads(v) for v in (r/'raw.jsonl').read_text().splitlines() if v.strip()]
expected = {p['id']:p['sha256'] for p in identity['inventory']}
ids = [v.get('point_id') for v in rows]
complete = len(ids)==77 and len(set(ids))==77 and set(ids)==set(expected)
bad = [{'point':v.get('point_id'),'status':v.get('status'),'problems':v.get('problems')}
       for v in rows if v.get('status')!='pass' or v.get('point_sha256')!=expected.get(v.get('point_id'))]
configs = {ablate.digest(ablate.config_of(v,[])) for v in rows}
endpoint_errors = []
endpoint_points = []
for record in rows:
    try:
        entry = record['timings']['device-graph-makespan']
        assert entry['endpoint_schema']=='tnca-launch-endpoints/1'
        audit_graph_samples(entry['samples'],entry['endpoint_records'],
                            launch_counts=[record['time']['launches']]*len(entry['samples']))
        endpoint_points.append(record['point_id'])
    except (AssertionError,KeyError,ValueError,TypeError) as error:
        endpoint_errors.append({'point':record.get('point_id'),'why':str(error)})
report = {'scope':'Functional RTL inventory only; no board or performance acceptance',
          'inventory_complete':complete,'one_software_configuration':len(configs)==1,
          'functional_all_pass':complete and not bad and len(configs)==1,
          'raw_endpoints_complete':complete and len(endpoint_points)==77 and not endpoint_errors,
          'rows':len(rows),'failures':bad,'raw_endpoint_failures':endpoint_errors,
          'image_sha256':None,'actual_clock_hz':None,'required_gate_promotions':[]}
(r/'completion.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
raise SystemExit(0 if report['functional_all_pass'] and report['raw_endpoints_complete'] else 1)
