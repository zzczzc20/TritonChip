    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #5
    v.add        v4, v1, v0
    v.movi       v0, #0
    v.movi       v1, #0
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    v.sub        v6, v0, v4
    @p1 v.sel        v7, v5, v4
    v.movi       v5, #0
    v.sub        v8, v1, v4
    v.lshr       v9, v7, v3
    v.cmp.lt     p2, v4, v0
    v.cmp.lt     p3, v4, v1
    v.sub        v3, v2, v9
    @p2 v.sel        v7, v6, v4
    v.movi       v6, #31
    @p1 v.sel        v10, v3, v9
    @p3 v.sel        v3, v8, v4
    v.and        v4, v7, v6
    v.sub        v6, v5, v10
    v.cmp.lt     p1, v10, v5
    v.movi       v7, #511
    @p1 v.sel        v8, v6, v10
    v.sub        v6, v0, v4
    s.rdspecial  s1, arg_base
    v.and        v9, v8, v7
    v.movi       v7, #32
    @p2 v.sel        v8, v6, v4
    v.sub        v4, v5, v9
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v6, #512
    @p1 v.sel        v11, v4, v9
    v.movi       v4, #16384
    v.sub        v9, v0, v7
    v.cmp.lt     p1, v7, v0
    v.sub        v0, v2, v7
    v.cmp.lt     p2, v7, v2
    v.sub        v2, v5, v6
    @p1 v.sel        v12, v9, v7
    v.sub        v9, v1, v4
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.cmp.lt     p1, v6, v5
    v.movi       v5, #14
    @p2 v.sel        v12, v0, v7
    v.movi       v0, #64
    v.lshr       v12, v3, v5
    v.add        v3, v8, v7
    v.movi       v5, #2048
    v.mul        v7, v10, v0
    v.cmp.lt     p2, v4, v1
    v.sub        v10, v1, v12
    v.mul        v1, v11, v5
    v.add        v5, v8, v7
    @p3 v.sel        v7, v10, v12
    @p1 v.sel        v8, v2, v6
    @p2 v.sel        v2, v9, v4
    v.mul        v2, v7, v0
    v.add        v0, v3, v2
    v.add        v2, v0, v1
    v.ld.gather.h v0, [s2, v2]                   // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v1, v0
    vf.neg       v0, v1
    vf.cvt.f32.f16 v1, v0
    v.st.scatter.h [s3, v5], v1
__rctx_next:
    exit
