# fam.py TSV [margin] [n]: group near_endpoints TSV (slack levels delay start end) by family
import sys,re,collections
m=float(sys.argv[2]) if len(sys.argv)>2 else 1.5; n=int(sys.argv[3]) if len(sys.argv)>3 else 25
c=collections.Counter(); w={}
def f(p): return re.sub(r'__\d+$','',re.sub(r'_replica(_\d+)?','',re.sub(r'\[\d+\]','[*]',p.rsplit('/',1)[0])))
for i,l in enumerate(open(sys.argv[1])):
  if i==0: continue
  p=l.rstrip().split('\t'); s=float(p[0])
  if s>=m: continue
  k=(f(p[3]),f(p[4])); c[k]+=1
  if s<w.get(k,(99,))[0]: w[k]=(s,p[1])
for k,v in sorted(w.items(), key=lambda kv: kv[1][0])[:n]: print(f"{v[0]:+.3f} n={c[k]:5d} L{v[1]:>2s} {k[0]} -> {k[1]}")
