    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, pid.y
    s.movz       s2, #0
    s.movz       s3, #1
    s.movz       s5, #2
    s.movz       s6, #3
    s.movz       s7, #4
    s.movz       s8, #5
    s.movz       s9, #6
    s.movz       s10, #7
    s.shli       s11, s1, #32
    s.movz       s1, #8
    s.ashri      s12, s11, #32
    s.rdspecial  s11, arg_base
    s.mul        s13, s12, s1
    s.ld.d       s12, [s11, #0]                  // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s14, #48
    s.movz       s15, #48
    s.movz       s16, #48
    s.lshri      s17, s13, #32
    s.lshri      s18, s13, #32
    s.lshri      s19, s13, #32
    s.lshri      s20, s13, #32
    s.lshri      s21, s13, #32
    s.lshri      s22, s13, #32
    s.lshri      s23, s13, #32
    s.lshri      s24, s13, #32
    s.ld.d       s25, [s11, #8]                  // out_ptr0: device_ptr64 at arg_base+8
    v.splat      v0, s2
    v.splat      v1, s3
    v.movi       v2, #0
    v.extract    s2, v0, #0
    v.extract    s3, v1, #0
    s.shli       s11, s2, #32
    s.shli       s2, s3, #32
    s.ashri      s3, s11, #32
    s.ashri      s11, s2, #32
    v.movi       v0, #0
    v.movi       v1, #0
    v.movi       v3, #0
    s.lshri      s2, s3, #32
    v.insert     v2, s3, #0
    v.insert     v0, s2, #0
    v.insert     v1, s11, #0
    s.movz       s2, #48
    s.lshri      s3, s11, #32
    s.movz       s11, #48
    v.insert     v3, s3, #0
    s.movz       s3, #48
    v.splat      v4, s5
    s.movz       s5, #48
    v.movi       v5, #0
    s.movz       s26, #48
    v.movi       v6, #0
    s.movz       s27, #16
    v.extract    s28, v4, #0
    s.movz       s29, #16
    s.shli       s30, s28, #32
    s.movz       s28, #16
    s.ashri      s31, s30, #32
    s.movz       s30, #16
    v.insert     v5, s31, #0
    s.movz       s32, #16
    s.lshri      s33, s31, #32
    s.movz       s31, #16
    v.insert     v6, s33, #0
    s.movz       s33, #2048
    s.movz       s34, #16
    v.splat      v4, s6
    .li       s6, #2415888336
    .li       s35, #2415888336
    .li       s36, #2415888336
    .li       s37, #2415888336
    .li       s38, #2415888336
    .li       s39, #2415888336
    .li       s40, #2415888336
    .li       s41, #2415888336
    s.movz       s42, #2048
    s.movz       s43, #16
    v.splat      v7, s7
    v.extract    s7, v4, #0
    v.movi       v4, #0
    s.shli       s44, s7, #32
    v.movi       v8, #0
    s.ashri      s7, s44, #32
    v.movi       v9, #0
    v.movi       v10, #0
    s.lshri      s44, s7, #32
    v.insert     v4, s7, #0
    v.insert     v8, s44, #0
    s.movz       s7, #2048
    v.extract    s44, v7, #0
    s.movz       s45, #2048
    s.shli       s46, s44, #32
    s.movz       s44, #2048
    s.ashri      s47, s46, #32
    s.movz       s46, #2048
    v.insert     v9, s47, #0
    s.movz       s48, #2048
    s.lshri      s49, s47, #32
    s.movz       s47, #2048
    v.insert     v10, s49, #0
    s.movz       s49, #8
    v.splat      v7, s8
    s.movz       s8, #0
    v.movi       v11, #0
    v.iota       v12                             // arange(0, VLEN)
    v.splat      v12, s9
    v.splat      v13, s10
    v.extract    s9, v7, #0
    v.extract    s10, v12, #0
    v.extract    s50, v13, #0
    s.shli       s51, s9, #32
    s.shli       s9, s10, #32
    s.shli       s10, s50, #32
    s.ashri      s50, s51, #32
    s.ashri      s51, s9, #32
    s.ashri      s9, s10, #32
    v.movi       v7, #0
    v.movi       v12, #0
    v.movi       v13, #0
    v.movi       v14, #0
    v.movi       v15, #0
    v.movi       v16, #0
    v.movi       v17, #0
    v.movi       v18, #0
    v.movi       v19, #0
    v.movi       v20, #0
    v.movi       v21, #0
    v.movi       v22, #0
    v.movi       v23, #0
    v.movi       v24, #0
    v.movi       v25, #0
    v.movi       v26, #0
    v.movi       v27, #0
    v.movi       v28, #0
    v.movi       v29, #0
    s.lshri      s10, s50, #32
    s.lshri      s52, s51, #32
    s.lshri      s53, s9, #32
    v.insert     v11, s50, #0
    v.movi       v30, #0
    v.insert     v7, s10, #0
    v.movi       v31, #0
    v.insert     v12, s51, #0
    v.insert     v13, s52, #0
    v.insert     v14, s9, #0
    v.insert     v15, s53, #0
    v.insert     v16, s13, #0
    v.insert     v17, s17, #0
    v.insert     v18, s13, #0
    v.insert     v19, s18, #0
    v.insert     v20, s13, #0
    v.insert     v21, s19, #0
    v.insert     v22, s13, #0
    v.insert     v23, s20, #0
    v.insert     v24, s13, #0
    v.insert     v25, s21, #0
    v.insert     v26, s13, #0
    v.insert     v27, s22, #0
    v.insert     v28, s13, #0
    v.insert     v29, s23, #0
    v.insert     v30, s13, #0
    v.insert     v31, s24, #0
    v.extract    s9, v17, #0
    v.extract    s10, v0, #0
    v.extract    s13, v19, #0
    v.extract    s17, v3, #0
    v.extract    s18, v21, #0
    v.extract    s19, v6, #0
    v.extract    s20, v23, #0
    v.extract    s21, v16, #0
    s.shli       s22, s9, #32
    v.extract    s9, v2, #0
    s.shli       s23, s10, #32
    v.extract    s10, v18, #0
    s.shli       s24, s13, #32
    v.extract    s13, v1, #0
    s.shli       s50, s17, #32
    v.extract    s17, v20, #0
    s.shli       s51, s18, #32
    v.extract    s18, v5, #0
    s.shli       s52, s19, #32
    v.extract    s19, v22, #0
    s.shli       s53, s20, #32
    s.or         s20, s21, s22
    s.or         s21, s9, s23
    s.or         s9, s10, s24
    s.or         s10, s13, s50
    s.or         s13, s17, s51
    s.or         s17, s18, s52
    s.or         s18, s19, s53
    s.add        s19, s20, s21
    s.add        s20, s9, s10
    s.add        s9, s13, s17
    v.movi       v0, #0
    v.extract    s10, v4, #0
    v.movi       v1, #0
    v.extract    s13, v8, #0
    v.extract    s17, v24, #0
    s.shli       s21, s13, #32
    v.movi       v2, #0
    s.or         s13, s10, s21
    v.movi       v3, #0
    s.add        s10, s18, s13
    v.movi       v4, #0
    v.movi       v5, #0
    v.movi       v6, #0
    v.movi       v8, #0
    v.movi       v16, #0
    v.movi       v17, #0
    s.lshri      s13, s19, #32
    s.lshri      s18, s20, #32
    s.lshri      s21, s9, #32
    s.lshri      s22, s10, #32
    v.insert     v0, s19, #0
    v.extract    s19, v25, #0
    v.insert     v1, s13, #0
    v.extract    s13, v10, #0
    s.shli       s23, s19, #32
    v.extract    s19, v9, #0
    s.shli       s24, s13, #32
    v.extract    s13, v26, #0
    s.or         s50, s17, s23
    s.or         s17, s19, s24
    v.movi       v9, #0
    s.add        s19, s50, s17
    v.movi       v10, #0
    s.lshri      s17, s19, #32
    v.insert     v2, s20, #0
    v.extract    s20, v27, #0
    v.insert     v3, s18, #0
    v.extract    s18, v7, #0
    s.shli       s23, s20, #32
    v.extract    s20, v11, #0
    s.shli       s24, s18, #32
    v.extract    s18, v28, #0
    s.or         s50, s13, s23
    s.or         s13, s20, s24
    v.movi       v7, #0
    s.add        s20, s50, s13
    v.movi       v11, #0
    s.lshri      s13, s20, #32
    v.insert     v4, s9, #0
    v.extract    s9, v29, #0
    v.insert     v5, s21, #0
    v.extract    s21, v13, #0
    s.shli       s23, s9, #32
    v.extract    s9, v12, #0
    s.shli       s24, s21, #32
    v.extract    s21, v30, #0
    s.or         s50, s18, s23
    s.or         s18, s9, s24
    v.movi       v12, #0
    s.add        s9, s50, s18
    v.movi       v13, #0
    s.lshri      s18, s9, #32
    v.insert     v6, s10, #0
    v.extract    s10, v31, #0
    v.insert     v8, s22, #0
    v.extract    s22, v15, #0
    s.shli       s23, s10, #32
    v.extract    s10, v14, #0
    s.shli       s24, s22, #32
    s.or         s22, s21, s23
    s.or         s21, s10, s24
    v.insert     v16, s19, #0
    s.add        s10, s22, s21
    v.insert     v17, s17, #0
    s.lshri      s17, s10, #32
    v.insert     v9, s20, #0
    v.insert     v10, s13, #0
    v.insert     v7, s9, #0
    v.insert     v11, s18, #0
    v.insert     v12, s10, #0
    v.insert     v13, s17, #0
    v.extract    s9, v1, #0
    v.extract    s10, v3, #0
    v.extract    s13, v5, #0
    v.extract    s17, v0, #0
    s.shli       s18, s9, #32
    v.extract    s9, v2, #0
    s.shli       s19, s10, #32
    v.extract    s10, v4, #0
    s.shli       s20, s13, #32
    s.or         s13, s17, s18
    s.or         s17, s9, s19
    s.or         s9, s10, s20
    v.movi       v14, #0
    v.extract    s10, v8, #0
    v.extract    s18, v6, #0
    s.shli       s19, s10, #32
    v.movi       v15, #0
    s.or         s10, s18, s19
    v.movi       v18, #0
    v.movi       v19, #0
    s.cmp.lt     s18, s13, s14
    s.cmp.lt     s13, s17, s15
    s.cmp.lt     s14, s9, s16
    s.cmp.lt     s9, s10, s2
    v.insert     v14, s18, #0
    v.insert     v15, s13, #0
    v.insert     v18, s14, #0
    v.insert     v19, s9, #0
    v.movi       v20, #0
    v.movi       v21, #0
    v.movi       v22, #0
    v.movi       v23, #0
    v.movi       v24, #1
    v.movi       v25, #0
    v.movi       v26, #1
    v.movi       v27, #0
    v.movi       v28, #1
    v.movi       v29, #0
    v.cmp.ne     p1, v14, v20
    v.movi       v14, #1
    v.movi       v20, #0
    v.cmp.ne     p2, v15, v21
    v.cmp.ne     p3, v18, v22
    v.cmp.ne     p4, v19, v23
    @p1 v.sel        v15, v24, v25
    @p2 v.sel        v18, v26, v27
    @p3 v.sel        v19, v28, v29
    @p4 v.sel        v21, v14, v20
    v.extract    s2, v15, #0
    v.extract    s9, v18, #0
    v.extract    s10, v19, #0
    v.extract    s13, v21, #0
    v.splat      v14, s2
    v.movi       v15, #0
    v.splat      v18, s9
    v.movi       v19, #0
    v.splat      v20, s10
    v.movi       v21, #0
    v.splat      v22, s13
    v.movi       v23, #0
    v.cmp.ne     p1, v14, v15
    v.extract    s2, v17, #0
    v.extract    s9, v16, #0
    s.shli       s10, s2, #32
    v.movi       v14, #0
    s.or         s2, s9, s10
    v.movi       v15, #0
    s.cmp.lt     s9, s2, s11
    v.movi       v24, #1
    v.insert     v14, s9, #0
    v.movi       v25, #0
    v.movi       v26, #0
    v.cmp.ne     p2, v14, v15
    @p2 v.sel        v14, v24, v25
    v.cmp.ne     p2, v18, v19
    v.extract    s2, v10, #0
    v.extract    s9, v9, #0
    s.shli       s10, s2, #32
    v.movi       v15, #0
    s.or         s2, s9, s10
    v.movi       v18, #0
    s.cmp.lt     s9, s2, s3
    v.movi       v19, #1
    v.insert     v15, s9, #0
    v.movi       v24, #0
    v.extract    s2, v14, #0
    v.cmp.ne     p3, v15, v18
    @p3 v.sel        v14, v19, v24
    v.splat      v15, s2
    v.movi       v18, #0
    v.extract    s2, v14, #0
    v.cmp.ne     p3, v20, v21
    v.extract    s3, v11, #0
    v.extract    s9, v7, #0
    s.shli       s10, s3, #32
    v.movi       v14, #0
    s.or         s3, s9, s10
    v.movi       v19, #0
    s.cmp.lt     s9, s3, s5
    v.movi       v20, #1
    v.insert     v14, s9, #0
    v.movi       v21, #0
    v.splat      v24, s2
    v.cmp.ne     p4, v14, v19
    @p4 v.sel        v14, v20, v21
    v.movi       v19, #0
    v.cmp.ne     p4, v22, v23
    v.extract    s2, v13, #0
    v.extract    s3, v12, #0
    s.shli       s5, s2, #32
    v.movi       v20, #0
    s.or         s2, s3, s5
    v.movi       v21, #0
    s.cmp.lt     s3, s2, s26
    v.movi       v22, #1
    v.insert     v20, s3, #0
    v.movi       v23, #0
    v.extract    s2, v14, #0
    v.cmp.ne     p5, v20, v21
    @p5 v.sel        v14, v22, v23
    v.splat      v20, s2
    v.movi       v21, #0
    v.extract    s2, v14, #0
    v.cmp.ne     p5, v15, v26
    v.iota       v14                             // arange(0, VLEN)
    v.movi       v15, #0
    v.movi       v22, #0
    v.extract    s3, v14, #0
    v.extract    s5, v14, #1
    s.shli       s9, s3, #32
    s.shli       s3, s5, #32
    s.ashri      s5, s9, #32
    s.ashri      s9, s3, #32
    s.lshri      s3, s5, #32
    v.insert     v15, s5, #0
    v.insert     v22, s3, #0
    s.shli       s3, s4, #32
    v.splat      v23, s2
    s.ashri      s2, s3, #32
    v.cmp.ne     p6, v24, v18
    v.extract    s3, v14, #2
    s.lshri      s4, s9, #32
    s.shli       s5, s3, #32
    v.extract    s3, v14, #3
    s.ashri      s10, s5, #32
    v.insert     v15, s9, #1
    v.insert     v22, s4, #1
    s.shli       s4, s3, #32
    s.lshri      s3, s10, #32
    v.extract    s5, v14, #4
    s.ashri      s9, s4, #32
    v.insert     v15, s10, #2
    v.insert     v22, s3, #2
    s.lshri      s3, s9, #32
    v.insert     v15, s9, #3
    v.insert     v22, s3, #3
    s.mul        s3, s2, s1
    v.cmp.ne     p7, v20, v19
    s.shli       s1, s5, #32
    v.extract    s2, v14, #5
    s.ashri      s4, s1, #32
    s.shli       s1, s2, #32
    s.lshri      s2, s4, #32
    v.extract    s5, v14, #6
    s.ashri      s9, s1, #32
    v.insert     v15, s4, #4
    v.insert     v22, s2, #4
    s.shli       s1, s5, #32
    s.lshri      s2, s9, #32
    s.ashri      s4, s1, #32
    v.insert     v15, s9, #5
    v.insert     v22, s2, #5
    s.lshri      s1, s4, #32
    v.insert     v15, s4, #6
    v.cmp.ne     p8, v23, v21
    v.extract    s2, v14, #7
    v.insert     v22, s1, #6
    s.shli       s1, s2, #32
    v.movi       v14, #0
    s.ashri      s2, s1, #32
    v.movi       v18, #0
    s.lshri      s1, s2, #32
    s.lshri      s4, s3, #32
    v.insert     v15, s2, #7
    v.insert     v22, s1, #7
    v.insert     v14, s3, #0
    v.insert     v18, s4, #0
    s.lshri      s1, s3, #32
    v.insert     v14, s3, #1
    v.insert     v18, s1, #1
    s.lshri      s1, s3, #32
    v.insert     v14, s3, #2
    v.insert     v18, s1, #2
    s.lshri      s1, s3, #32
    v.insert     v14, s3, #3
    v.insert     v18, s1, #3
    s.lshri      s1, s3, #32
    v.insert     v14, s3, #4
    v.insert     v18, s1, #4
    s.lshri      s1, s3, #32
    v.insert     v14, s3, #5
    v.insert     v18, s1, #5
    s.lshri      s1, s3, #32
    v.insert     v14, s3, #6
    v.insert     v18, s1, #6
    s.lshri      s1, s3, #32
    v.insert     v14, s3, #7
    v.insert     v18, s1, #7
    v.extract    s1, v22, #0
    v.extract    s2, v14, #0
    v.extract    s3, v18, #0
    v.extract    s4, v15, #0
    s.shli       s5, s3, #32
    s.shli       s3, s1, #32
    v.extract    s1, v18, #1
    v.extract    s9, v22, #1
    s.or         s10, s2, s5
    s.or         s2, s4, s3
    v.extract    s3, v14, #1
    s.shli       s4, s1, #32
    v.extract    s1, v15, #1
    s.shli       s5, s9, #32
    s.add        s9, s10, s2
    v.extract    s2, v18, #2
    v.extract    s10, v22, #2
    v.movi       v19, #0
    v.movi       v20, #0
    s.or         s11, s3, s4
    s.or         s3, s1, s5
    s.lshri      s1, s9, #32
    v.extract    s4, v14, #2
    s.shli       s5, s2, #32
    v.extract    s2, v15, #2
    s.shli       s13, s10, #32
    s.add        s10, s11, s3
    v.extract    s3, v18, #3
    v.extract    s11, v22, #3
    v.insert     v19, s9, #0
    v.insert     v20, s1, #0
    s.or         s1, s4, s5
    s.or         s4, s2, s13
    s.lshri      s2, s10, #32
    v.extract    s5, v14, #3
    s.shli       s9, s3, #32
    v.extract    s3, v15, #3
    s.shli       s13, s11, #32
    s.add        s11, s1, s4
    v.extract    s1, v18, #4
    v.extract    s4, v22, #4
    v.insert     v19, s10, #1
    v.insert     v20, s2, #1
    s.or         s2, s5, s9
    s.or         s5, s3, s13
    s.lshri      s3, s11, #32
    v.extract    s9, v14, #4
    s.shli       s10, s1, #32
    v.extract    s1, v15, #4
    s.shli       s13, s4, #32
    s.add        s4, s2, s5
    v.extract    s2, v18, #5
    v.extract    s5, v22, #5
    v.insert     v19, s11, #2
    v.insert     v20, s3, #2
    s.or         s3, s9, s10
    s.or         s9, s1, s13
    s.lshri      s1, s4, #32
    v.extract    s10, v14, #5
    s.shli       s11, s2, #32
    v.extract    s2, v15, #5
    s.shli       s13, s5, #32
    s.add        s5, s3, s9
    v.extract    s3, v18, #6
    v.extract    s9, v22, #6
    v.insert     v19, s4, #3
    v.insert     v20, s1, #3
    s.or         s1, s10, s11
    s.or         s4, s2, s13
    s.lshri      s2, s5, #32
    v.extract    s10, v14, #6
    s.shli       s11, s3, #32
    v.extract    s3, v15, #6
    s.shli       s13, s9, #32
    s.add        s9, s1, s4
    v.extract    s1, v18, #7
    v.extract    s4, v22, #7
    v.insert     v19, s5, #4
    v.insert     v20, s2, #4
    s.or         s2, s10, s11
    s.or         s5, s3, s13
    s.lshri      s3, s9, #32
    v.extract    s10, v14, #7
    s.shli       s11, s1, #32
    v.extract    s1, v15, #7
    s.shli       s13, s4, #32
    s.add        s4, s2, s5
    v.insert     v19, s9, #5
    v.insert     v20, s3, #5
    s.or         s2, s10, s11
    s.or         s3, s1, s13
    s.lshri      s1, s4, #32
    s.add        s5, s2, s3
    v.insert     v19, s4, #6
    v.insert     v20, s1, #6
    s.lshri      s1, s5, #32
    v.insert     v19, s5, #7
    v.insert     v20, s1, #7
    v.movi       v14, #0
    v.extract    s1, v19, #0
    v.extract    s2, v20, #0
    v.extract    s3, v20, #1
    s.shli       s4, s2, #32
    v.extract    s2, v19, #1
    s.or         s5, s1, s4
    s.shli       s1, s3, #32
    s.cmp.lt     s3, s5, s27
    v.extract    s4, v20, #2
    s.or         s5, s2, s1
    v.insert     v14, s3, #0
    v.extract    s1, v19, #2
    s.shli       s2, s4, #32
    s.cmp.lt     s3, s5, s29
    v.extract    s4, v20, #3
    s.or         s5, s1, s2
    v.insert     v14, s3, #1
    v.extract    s1, v19, #3
    s.shli       s2, s4, #32
    s.cmp.lt     s3, s5, s28
    v.extract    s4, v20, #4
    s.or         s5, s1, s2
    v.insert     v14, s3, #2
    v.extract    s1, v19, #4
    s.shli       s2, s4, #32
    s.cmp.lt     s3, s5, s30
    v.extract    s4, v20, #5
    s.or         s5, s1, s2
    v.insert     v14, s3, #3
    v.extract    s1, v19, #5
    s.shli       s2, s4, #32
    s.cmp.lt     s3, s5, s32
    v.extract    s4, v20, #6
    s.or         s5, s1, s2
    v.extract    s1, v1, #0
    v.extract    s2, v3, #0
    v.extract    s9, v5, #0
    v.insert     v14, s3, #4
    v.extract    s3, v19, #6
    s.shli       s10, s4, #32
    s.cmp.lt     s4, s5, s31
    v.extract    s5, v20, #7
    v.extract    s11, v0, #0
    s.shli       s13, s1, #32
    v.extract    s1, v2, #0
    s.shli       s14, s2, #32
    v.extract    s2, v4, #0
    s.shli       s15, s9, #32
    v.extract    s9, v6, #0
    s.or         s16, s3, s10
    v.insert     v14, s4, #5
    v.extract    s3, v8, #0
    v.extract    s4, v19, #7
    s.shli       s10, s3, #32
    s.shli       s3, s5, #32
    s.or         s5, s11, s13
    s.or         s11, s1, s14
    s.or         s1, s2, s15
    s.or         s2, s9, s10
    s.cmp.lt     s9, s16, s34
    s.or         s10, s4, s3
    s.add        s3, s5, s6
    s.add        s4, s11, s35
    s.add        s5, s1, s36
    s.add        s1, s2, s37
    v.insert     v14, s9, #6
    v.extract    s2, v17, #0
    v.extract    s6, v16, #0
    v.movi       v15, #0
    v.movi       v18, #0
    v.movi       v21, #0
    v.movi       v22, #0
    v.movi       v23, #0
    v.movi       v24, #0
    v.movi       v25, #0
    v.movi       v26, #0
    v.movi       v27, #0
    v.movi       v28, #0
    s.cmp.lt     s9, s10, s43
    s.shli       s10, s2, #32
    s.lshri      s2, s3, #32
    s.lshri      s11, s4, #32
    s.lshri      s13, s5, #32
    s.lshri      s14, s1, #32
    v.insert     v14, s9, #7
    s.or         s9, s6, s10
    v.insert     v15, s3, #0
    v.insert     v18, s2, #0
    v.insert     v21, s4, #0
    v.insert     v22, s11, #0
    v.insert     v23, s5, #0
    v.insert     v24, s13, #0
    v.insert     v25, s1, #0
    v.insert     v26, s14, #0
    v.movi       v29, #0
    s.add        s1, s9, s38
    v.cmp.ne     p9, v14, v29
    v.extract    s2, v20, #0
    v.extract    s3, v19, #0
    s.shli       s4, s2, #32
    v.extract    s2, v10, #0
    v.extract    s5, v11, #0
    v.extract    s6, v13, #0
    v.extract    s9, v20, #1
    s.or         s10, s3, s4
    v.extract    s3, v9, #0
    s.shli       s4, s2, #32
    v.extract    s2, v7, #0
    s.shli       s11, s5, #32
    v.extract    s5, v12, #0
    s.shli       s13, s6, #32
    v.extract    s6, v19, #1
    s.shli       s14, s9, #32
    s.mul        s9, s10, s33
    s.or         s10, s3, s4
    s.or         s3, s2, s11
    s.or         s2, s5, s13
    s.or         s4, s6, s14
    s.add        s5, s10, s39
    s.add        s6, s3, s40
    s.add        s3, s2, s41
    s.mul        s2, s4, s42
    v.movi       v14, #0
    v.movi       v29, #0
    v.movi       v30, #0
    v.movi       v31, #0
    v.movi       v32, #0
    v.movi       v33, #0
    v.movi       v34, #0
    v.movi       v35, #0
    s.lshri      s4, s1, #32
    s.lshri      s10, s5, #32
    s.lshri      s11, s6, #32
    s.lshri      s13, s3, #32
    s.lshri      s14, s9, #32
    v.insert     v27, s1, #0
    v.insert     v28, s4, #0
    v.extract    s1, v20, #2
    v.extract    s4, v19, #2
    s.shli       s15, s1, #32
    v.insert     v14, s5, #0
    s.or         s1, s4, s15
    v.extract    s4, v19, #3
    s.mul        s5, s1, s7
    v.insert     v29, s10, #0
    v.extract    s1, v20, #3
    v.insert     v30, s6, #0
    s.shli       s6, s1, #32
    v.extract    s1, v20, #4
    v.insert     v31, s11, #0
    v.insert     v32, s3, #0
    v.insert     v33, s13, #0
    v.insert     v34, s9, #0
    v.insert     v35, s14, #0
    s.or         s3, s4, s6
    s.lshri      s4, s2, #32
    v.extract    s6, v19, #4
    s.shli       s7, s1, #32
    s.mul        s1, s3, s45
    v.extract    s3, v20, #5
    v.insert     v34, s2, #1
    v.insert     v35, s4, #1
    s.or         s2, s6, s7
    s.lshri      s4, s5, #32
    v.extract    s6, v19, #5
    s.shli       s7, s3, #32
    s.mul        s3, s2, s44
    v.extract    s2, v20, #6
    v.insert     v34, s5, #2
    v.insert     v35, s4, #2
    s.or         s4, s6, s7
    s.lshri      s5, s1, #32
    v.extract    s6, v19, #6
    s.shli       s7, s2, #32
    s.mul        s2, s4, s46
    v.extract    s4, v20, #7
    v.insert     v34, s1, #3
    v.insert     v35, s5, #3
    s.or         s1, s6, s7
    s.lshri      s5, s3, #32
    v.extract    s6, v19, #7
    s.shli       s7, s4, #32
    s.mul        s4, s1, s48
    v.insert     v34, s3, #4
    v.insert     v35, s5, #4
    s.or         s1, s6, s7
    s.lshri      s3, s2, #32
    v.extract    s5, v18, #0
    s.mul        s6, s1, s47
    v.insert     v34, s2, #5
    v.insert     v35, s3, #5
    v.extract    s1, v15, #0
    s.shli       s2, s5, #32
    s.lshri      s3, s4, #32
    v.extract    s5, v18, #0
    s.or         s7, s1, s2
    v.insert     v34, s4, #6
    v.insert     v35, s3, #6
    v.movi       v36, #0
    v.movi       v37, #0
    v.extract    s1, v15, #0
    s.shli       s2, s5, #32
    s.lshri      s3, s6, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v18, #0
    s.or         s9, s1, s2
    v.insert     v34, s6, #7
    v.insert     v35, s3, #7
    v.insert     v36, s7, #0
    v.insert     v37, s4, #0
    v.extract    s1, v15, #0
    s.shli       s2, s5, #32
    s.lshri      s3, s9, #32
    v.extract    s4, v18, #0
    s.or         s5, s1, s2
    v.insert     v36, s9, #1
    v.insert     v37, s3, #1
    v.extract    s1, v15, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v18, #0
    s.or         s6, s1, s2
    v.insert     v36, s5, #2
    v.insert     v37, s3, #2
    v.extract    s1, v15, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v18, #0
    s.or         s5, s1, s2
    v.insert     v36, s6, #3
    v.insert     v37, s3, #3
    v.extract    s1, v15, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v18, #0
    s.or         s6, s1, s2
    v.insert     v36, s5, #4
    v.insert     v37, s3, #4
    v.extract    s1, v15, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v18, #0
    v.extract    s5, v22, #0
    s.or         s7, s1, s2
    v.insert     v36, s6, #5
    v.insert     v37, s3, #5
    v.extract    s1, v15, #0
    s.shli       s2, s4, #32
    v.extract    s3, v21, #0
    s.shli       s4, s5, #32
    s.lshri      s5, s7, #32
    v.extract    s6, v22, #0
    s.or         s9, s1, s2
    s.or         s1, s3, s4
    v.insert     v36, s7, #6
    v.insert     v37, s5, #6
    v.movi       v15, #0
    v.movi       v18, #0
    v.extract    s2, v21, #0
    s.shli       s3, s6, #32
    s.lshri      s4, s9, #32
    s.lshri      s5, s1, #32
    v.extract    s6, v22, #0
    s.or         s7, s2, s3
    v.insert     v36, s9, #7
    v.insert     v37, s4, #7
    v.insert     v15, s1, #0
    v.insert     v18, s5, #0
    v.extract    s1, v21, #0
    s.shli       s2, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v22, #0
    s.or         s5, s1, s2
    v.insert     v15, s7, #1
    v.insert     v18, s3, #1
    v.extract    s1, v21, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v22, #0
    s.or         s6, s1, s2
    v.insert     v15, s5, #2
    v.insert     v18, s3, #2
    v.extract    s1, v21, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v22, #0
    s.or         s5, s1, s2
    v.insert     v15, s6, #3
    v.insert     v18, s3, #3
    v.extract    s1, v21, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v22, #0
    s.or         s6, s1, s2
    v.insert     v15, s5, #4
    v.insert     v18, s3, #4
    v.extract    s1, v21, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v22, #0
    v.extract    s5, v24, #0
    s.or         s7, s1, s2
    v.insert     v15, s6, #5
    v.insert     v18, s3, #5
    v.extract    s1, v21, #0
    s.shli       s2, s4, #32
    v.extract    s3, v23, #0
    s.shli       s4, s5, #32
    s.lshri      s5, s7, #32
    v.extract    s6, v24, #0
    s.or         s9, s1, s2
    s.or         s1, s3, s4
    v.insert     v15, s7, #6
    v.insert     v18, s5, #6
    v.movi       v21, #0
    v.movi       v22, #0
    v.extract    s2, v23, #0
    s.shli       s3, s6, #32
    s.lshri      s4, s9, #32
    s.lshri      s5, s1, #32
    v.extract    s6, v24, #0
    s.or         s7, s2, s3
    v.insert     v15, s9, #7
    v.insert     v18, s4, #7
    v.insert     v21, s1, #0
    v.insert     v22, s5, #0
    v.extract    s1, v23, #0
    s.shli       s2, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v24, #0
    s.or         s5, s1, s2
    v.insert     v21, s7, #1
    v.insert     v22, s3, #1
    v.extract    s1, v23, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v24, #0
    s.or         s6, s1, s2
    v.insert     v21, s5, #2
    v.insert     v22, s3, #2
    v.extract    s1, v23, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v24, #0
    s.or         s5, s1, s2
    v.insert     v21, s6, #3
    v.insert     v22, s3, #3
    v.extract    s1, v23, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v24, #0
    s.or         s6, s1, s2
    v.insert     v21, s5, #4
    v.insert     v22, s3, #4
    v.extract    s1, v23, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v24, #0
    v.extract    s5, v26, #0
    s.or         s7, s1, s2
    v.insert     v21, s6, #5
    v.insert     v22, s3, #5
    v.extract    s1, v23, #0
    s.shli       s2, s4, #32
    v.extract    s3, v25, #0
    s.shli       s4, s5, #32
    s.lshri      s5, s7, #32
    v.extract    s6, v26, #0
    s.or         s9, s1, s2
    s.or         s1, s3, s4
    v.insert     v21, s7, #6
    v.insert     v22, s5, #6
    v.movi       v23, #0
    v.movi       v24, #0
    v.extract    s2, v25, #0
    s.shli       s3, s6, #32
    s.lshri      s4, s9, #32
    s.lshri      s5, s1, #32
    v.extract    s6, v26, #0
    s.or         s7, s2, s3
    v.insert     v21, s9, #7
    v.insert     v22, s4, #7
    v.insert     v23, s1, #0
    v.insert     v24, s5, #0
    v.extract    s1, v25, #0
    s.shli       s2, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v26, #0
    s.or         s5, s1, s2
    v.insert     v23, s7, #1
    v.insert     v24, s3, #1
    v.extract    s1, v25, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v26, #0
    s.or         s6, s1, s2
    v.insert     v23, s5, #2
    v.insert     v24, s3, #2
    v.extract    s1, v25, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v26, #0
    s.or         s5, s1, s2
    v.insert     v23, s6, #3
    v.insert     v24, s3, #3
    v.extract    s1, v25, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v26, #0
    s.or         s6, s1, s2
    v.insert     v23, s5, #4
    v.insert     v24, s3, #4
    v.extract    s1, v25, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v26, #0
    v.extract    s5, v28, #0
    s.or         s7, s1, s2
    v.insert     v23, s6, #5
    v.insert     v24, s3, #5
    v.extract    s1, v25, #0
    s.shli       s2, s4, #32
    v.extract    s3, v27, #0
    s.shli       s4, s5, #32
    s.lshri      s5, s7, #32
    v.extract    s6, v28, #0
    s.or         s9, s1, s2
    s.or         s1, s3, s4
    v.insert     v23, s7, #6
    v.insert     v24, s5, #6
    v.movi       v25, #0
    v.movi       v26, #0
    v.extract    s2, v27, #0
    s.shli       s3, s6, #32
    s.lshri      s4, s9, #32
    s.lshri      s5, s1, #32
    v.extract    s6, v28, #0
    s.or         s7, s2, s3
    v.insert     v23, s9, #7
    v.insert     v24, s4, #7
    v.insert     v25, s1, #0
    v.insert     v26, s5, #0
    v.extract    s1, v27, #0
    s.shli       s2, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v28, #0
    s.or         s5, s1, s2
    v.insert     v25, s7, #1
    v.insert     v26, s3, #1
    v.extract    s1, v27, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v28, #0
    s.or         s6, s1, s2
    v.insert     v25, s5, #2
    v.insert     v26, s3, #2
    v.extract    s1, v27, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v28, #0
    s.or         s5, s1, s2
    v.insert     v25, s6, #3
    v.insert     v26, s3, #3
    v.extract    s1, v27, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v28, #0
    s.or         s6, s1, s2
    v.insert     v25, s5, #4
    v.insert     v26, s3, #4
    v.extract    s1, v27, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v28, #0
    v.extract    s5, v29, #0
    s.or         s7, s1, s2
    v.insert     v25, s6, #5
    v.insert     v26, s3, #5
    v.extract    s1, v27, #0
    s.shli       s2, s4, #32
    v.extract    s3, v14, #0
    s.shli       s4, s5, #32
    s.lshri      s5, s7, #32
    v.extract    s6, v29, #0
    s.or         s9, s1, s2
    s.or         s1, s3, s4
    v.insert     v25, s7, #6
    v.insert     v26, s5, #6
    v.movi       v27, #0
    v.movi       v28, #0
    v.extract    s2, v14, #0
    s.shli       s3, s6, #32
    s.lshri      s4, s9, #32
    s.lshri      s5, s1, #32
    v.extract    s6, v29, #0
    s.or         s7, s2, s3
    v.insert     v25, s9, #7
    v.insert     v26, s4, #7
    v.insert     v27, s1, #0
    v.insert     v28, s5, #0
    v.extract    s1, v14, #0
    s.shli       s2, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v29, #0
    s.or         s5, s1, s2
    v.insert     v27, s7, #1
    v.insert     v28, s3, #1
    v.extract    s1, v14, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v29, #0
    s.or         s6, s1, s2
    v.insert     v27, s5, #2
    v.insert     v28, s3, #2
    v.extract    s1, v14, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v29, #0
    s.or         s5, s1, s2
    v.insert     v27, s6, #3
    v.insert     v28, s3, #3
    v.extract    s1, v14, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v29, #0
    s.or         s6, s1, s2
    v.insert     v27, s5, #4
    v.insert     v28, s3, #4
    v.extract    s1, v14, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v29, #0
    v.extract    s5, v31, #0
    s.or         s7, s1, s2
    v.insert     v27, s6, #5
    v.insert     v28, s3, #5
    v.extract    s1, v14, #0
    s.shli       s2, s4, #32
    v.extract    s3, v30, #0
    s.shli       s4, s5, #32
    s.lshri      s5, s7, #32
    v.extract    s6, v31, #0
    s.or         s9, s1, s2
    s.or         s1, s3, s4
    v.insert     v27, s7, #6
    v.insert     v28, s5, #6
    v.movi       v14, #0
    v.movi       v29, #0
    v.extract    s2, v30, #0
    s.shli       s3, s6, #32
    s.lshri      s4, s9, #32
    s.lshri      s5, s1, #32
    v.extract    s6, v31, #0
    s.or         s7, s2, s3
    v.insert     v27, s9, #7
    v.insert     v28, s4, #7
    v.insert     v14, s1, #0
    v.insert     v29, s5, #0
    v.extract    s1, v30, #0
    s.shli       s2, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v31, #0
    s.or         s5, s1, s2
    v.insert     v14, s7, #1
    v.insert     v29, s3, #1
    v.extract    s1, v30, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v31, #0
    s.or         s6, s1, s2
    v.insert     v14, s5, #2
    v.insert     v29, s3, #2
    v.extract    s1, v30, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v31, #0
    s.or         s5, s1, s2
    v.insert     v14, s6, #3
    v.insert     v29, s3, #3
    v.extract    s1, v30, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v31, #0
    s.or         s6, s1, s2
    v.insert     v14, s5, #4
    v.insert     v29, s3, #4
    v.extract    s1, v30, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v31, #0
    v.extract    s5, v33, #0
    s.or         s7, s1, s2
    v.insert     v14, s6, #5
    v.insert     v29, s3, #5
    v.extract    s1, v30, #0
    s.shli       s2, s4, #32
    v.extract    s3, v32, #0
    s.shli       s4, s5, #32
    s.lshri      s5, s7, #32
    v.extract    s6, v33, #0
    s.or         s9, s1, s2
    s.or         s1, s3, s4
    v.insert     v14, s7, #6
    v.insert     v29, s5, #6
    v.movi       v30, #0
    v.movi       v31, #0
    v.extract    s2, v32, #0
    s.shli       s3, s6, #32
    s.lshri      s4, s9, #32
    s.lshri      s5, s1, #32
    v.extract    s6, v33, #0
    s.or         s7, s2, s3
    v.insert     v14, s9, #7
    v.insert     v29, s4, #7
    v.insert     v30, s1, #0
    v.insert     v31, s5, #0
    v.extract    s1, v32, #0
    s.shli       s2, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v33, #0
    s.or         s5, s1, s2
    v.insert     v30, s7, #1
    v.insert     v31, s3, #1
    v.extract    s1, v32, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v33, #0
    s.or         s6, s1, s2
    v.insert     v30, s5, #2
    v.insert     v31, s3, #2
    v.extract    s1, v32, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v33, #0
    s.or         s5, s1, s2
    v.insert     v30, s6, #3
    v.insert     v31, s3, #3
    v.extract    s1, v32, #0
    s.shli       s2, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v33, #0
    s.or         s6, s1, s2
    v.extract    s1, v37, #0
    v.extract    s2, v35, #0
    v.insert     v30, s5, #4
    v.insert     v31, s3, #4
    v.extract    s3, v32, #0
    s.shli       s5, s4, #32
    s.lshri      s4, s6, #32
    v.extract    s7, v33, #0
    v.extract    s9, v36, #0
    s.shli       s10, s1, #32
    v.extract    s1, v34, #0
    s.shli       s11, s2, #32
    s.or         s2, s3, s5
    v.extract    s3, v37, #1
    v.extract    s5, v35, #1
    v.insert     v30, s6, #5
    v.insert     v31, s4, #5
    v.extract    s4, v32, #0
    s.shli       s6, s7, #32
    s.or         s7, s9, s10
    s.or         s9, s1, s11
    s.lshri      s1, s2, #32
    v.extract    s10, v36, #1
    s.shli       s11, s3, #32
    v.extract    s3, v34, #1
    s.shli       s13, s5, #32
    s.or         s5, s4, s6
    s.add        s4, s7, s9
    v.extract    s6, v37, #2
    v.extract    s7, v35, #2
    v.insert     v30, s2, #6
    v.insert     v31, s1, #6
    v.movi       v32, #0
    v.movi       v33, #0
    s.or         s1, s10, s11
    s.or         s2, s3, s13
    s.lshri      s3, s5, #32
    s.lshri      s9, s4, #32
    v.extract    s10, v36, #2
    s.shli       s11, s6, #32
    v.extract    s6, v34, #2
    s.shli       s13, s7, #32
    s.add        s7, s1, s2
    v.extract    s1, v37, #3
    v.extract    s2, v35, #3
    v.insert     v30, s5, #7
    v.insert     v31, s3, #7
    v.insert     v32, s4, #0
    v.insert     v33, s9, #0
    s.or         s3, s10, s11
    s.or         s4, s6, s13
    s.lshri      s5, s7, #32
    v.extract    s6, v36, #3
    s.shli       s9, s1, #32
    v.extract    s1, v34, #3
    s.shli       s10, s2, #32
    s.add        s2, s3, s4
    v.extract    s3, v37, #4
    v.extract    s4, v35, #4
    v.insert     v32, s7, #1
    v.insert     v33, s5, #1
    s.or         s5, s6, s9
    s.or         s6, s1, s10
    s.lshri      s1, s2, #32
    v.extract    s7, v36, #4
    s.shli       s9, s3, #32
    v.extract    s3, v34, #4
    s.shli       s10, s4, #32
    s.add        s4, s5, s6
    v.extract    s5, v37, #5
    v.extract    s6, v35, #5
    v.insert     v32, s2, #2
    v.insert     v33, s1, #2
    s.or         s1, s7, s9
    s.or         s2, s3, s10
    s.lshri      s3, s4, #32
    v.extract    s7, v36, #5
    s.shli       s9, s5, #32
    v.extract    s5, v34, #5
    s.shli       s10, s6, #32
    s.add        s6, s1, s2
    v.extract    s1, v37, #6
    v.extract    s2, v35, #6
    v.insert     v32, s4, #3
    v.insert     v33, s3, #3
    s.or         s3, s7, s9
    s.or         s4, s5, s10
    s.lshri      s5, s6, #32
    v.extract    s7, v36, #6
    s.shli       s9, s1, #32
    v.extract    s1, v34, #6
    s.shli       s10, s2, #32
    s.add        s2, s3, s4
    v.extract    s3, v37, #7
    v.extract    s4, v35, #7
    v.extract    s11, v18, #0
    v.extract    s13, v35, #0
    v.insert     v32, s6, #4
    v.insert     v33, s5, #4
    s.or         s5, s7, s9
    s.or         s6, s1, s10
    s.lshri      s1, s2, #32
    v.extract    s7, v36, #7
    s.shli       s9, s3, #32
    v.extract    s3, v34, #7
    s.shli       s10, s4, #32
    v.extract    s4, v15, #0
    s.shli       s14, s11, #32
    v.extract    s11, v34, #0
    s.shli       s15, s13, #32
    s.add        s13, s5, s6
    v.extract    s5, v18, #1
    v.extract    s6, v35, #1
    v.insert     v32, s2, #5
    v.insert     v33, s1, #5
    s.or         s1, s7, s9
    s.or         s2, s3, s10
    s.or         s3, s4, s14
    s.or         s4, s11, s15
    s.lshri      s7, s13, #32
    v.extract    s9, v15, #1
    s.shli       s10, s5, #32
    v.extract    s5, v34, #1
    s.shli       s11, s6, #32
    s.add        s6, s1, s2
    s.add        s1, s3, s4
    v.extract    s2, v18, #2
    v.extract    s3, v35, #2
    v.insert     v32, s13, #6
    v.insert     v33, s7, #6
    v.movi       v36, #0
    v.movi       v37, #0
    s.or         s4, s9, s10
    s.or         s7, s5, s11
    s.lshri      s5, s6, #32
    s.lshri      s9, s1, #32
    v.extract    s10, v15, #2
    s.shli       s11, s2, #32
    v.extract    s2, v34, #2
    s.shli       s13, s3, #32
    s.add        s3, s4, s7
    v.extract    s4, v18, #3
    v.extract    s7, v35, #3
    v.insert     v32, s6, #7
    v.insert     v33, s5, #7
    v.insert     v36, s1, #0
    v.insert     v37, s9, #0
    s.or         s1, s10, s11
    s.or         s5, s2, s13
    s.lshri      s2, s3, #32
    v.extract    s6, v15, #3
    s.shli       s9, s4, #32
    v.extract    s4, v34, #3
    s.shli       s10, s7, #32
    s.add        s7, s1, s5
    v.extract    s1, v18, #4
    v.extract    s5, v35, #4
    v.insert     v36, s3, #1
    v.insert     v37, s2, #1
    s.or         s2, s6, s9
    s.or         s3, s4, s10
    s.lshri      s4, s7, #32
    v.extract    s6, v15, #4
    s.shli       s9, s1, #32
    v.extract    s1, v34, #4
    s.shli       s10, s5, #32
    s.add        s5, s2, s3
    v.extract    s2, v18, #5
    v.extract    s3, v35, #5
    v.insert     v36, s7, #2
    v.insert     v37, s4, #2
    s.or         s4, s6, s9
    s.or         s6, s1, s10
    s.lshri      s1, s5, #32
    v.extract    s7, v15, #5
    s.shli       s9, s2, #32
    v.extract    s2, v34, #5
    s.shli       s10, s3, #32
    s.add        s3, s4, s6
    v.extract    s4, v18, #6
    v.extract    s6, v35, #6
    v.insert     v36, s5, #3
    v.insert     v37, s1, #3
    s.or         s1, s7, s9
    s.or         s5, s2, s10
    s.lshri      s2, s3, #32
    v.extract    s7, v15, #6
    s.shli       s9, s4, #32
    v.extract    s4, v34, #6
    s.shli       s10, s6, #32
    s.add        s6, s1, s5
    v.extract    s1, v18, #7
    v.extract    s5, v35, #7
    v.extract    s11, v22, #0
    v.extract    s13, v35, #0
    v.insert     v36, s3, #4
    v.insert     v37, s2, #4
    s.or         s2, s7, s9
    s.or         s3, s4, s10
    s.lshri      s4, s6, #32
    v.extract    s7, v15, #7
    s.shli       s9, s1, #32
    v.extract    s1, v34, #7
    s.shli       s10, s5, #32
    v.extract    s5, v21, #0
    s.shli       s14, s11, #32
    v.extract    s11, v34, #0
    s.shli       s15, s13, #32
    s.add        s13, s2, s3
    v.extract    s2, v22, #1
    v.extract    s3, v35, #1
    v.insert     v36, s6, #5
    v.insert     v37, s4, #5
    s.or         s4, s7, s9
    s.or         s6, s1, s10
    s.or         s1, s5, s14
    s.or         s5, s11, s15
    s.lshri      s7, s13, #32
    v.extract    s9, v21, #1
    s.shli       s10, s2, #32
    v.extract    s2, v34, #1
    s.shli       s11, s3, #32
    s.add        s3, s4, s6
    s.add        s4, s1, s5
    v.extract    s1, v22, #2
    v.extract    s5, v35, #2
    v.insert     v36, s13, #6
    v.insert     v37, s7, #6
    v.movi       v15, #0
    v.movi       v18, #0
    s.or         s6, s9, s10
    s.or         s7, s2, s11
    s.lshri      s2, s3, #32
    s.lshri      s9, s4, #32
    v.extract    s10, v21, #2
    s.shli       s11, s1, #32
    v.extract    s1, v34, #2
    s.shli       s13, s5, #32
    s.add        s5, s6, s7
    v.extract    s6, v22, #3
    v.extract    s7, v35, #3
    v.insert     v36, s3, #7
    v.insert     v37, s2, #7
    v.insert     v15, s4, #0
    v.insert     v18, s9, #0
    s.or         s2, s10, s11
    s.or         s3, s1, s13
    s.lshri      s1, s5, #32
    v.extract    s4, v21, #3
    s.shli       s9, s6, #32
    v.extract    s6, v34, #3
    s.shli       s10, s7, #32
    s.add        s7, s2, s3
    v.extract    s2, v22, #4
    v.extract    s3, v35, #4
    v.insert     v15, s5, #1
    v.insert     v18, s1, #1
    s.or         s1, s4, s9
    s.or         s4, s6, s10
    s.lshri      s5, s7, #32
    v.extract    s6, v21, #4
    s.shli       s9, s2, #32
    v.extract    s2, v34, #4
    s.shli       s10, s3, #32
    s.add        s3, s1, s4
    v.extract    s1, v22, #5
    v.extract    s4, v35, #5
    v.insert     v15, s7, #2
    v.insert     v18, s5, #2
    s.or         s5, s6, s9
    s.or         s6, s2, s10
    s.lshri      s2, s3, #32
    v.extract    s7, v21, #5
    s.shli       s9, s1, #32
    v.extract    s1, v34, #5
    s.shli       s10, s4, #32
    s.add        s4, s5, s6
    v.extract    s5, v22, #6
    v.extract    s6, v35, #6
    v.insert     v15, s3, #3
    v.insert     v18, s2, #3
    s.or         s2, s7, s9
    s.or         s3, s1, s10
    s.lshri      s1, s4, #32
    v.extract    s7, v21, #6
    s.shli       s9, s5, #32
    v.extract    s5, v34, #6
    s.shli       s10, s6, #32
    s.add        s6, s2, s3
    v.extract    s2, v22, #7
    v.extract    s3, v35, #7
    v.extract    s11, v24, #0
    v.extract    s13, v35, #0
    v.insert     v15, s4, #4
    v.insert     v18, s1, #4
    s.or         s1, s7, s9
    s.or         s4, s5, s10
    s.lshri      s5, s6, #32
    v.extract    s7, v21, #7
    s.shli       s9, s2, #32
    v.extract    s2, v34, #7
    s.shli       s10, s3, #32
    v.extract    s3, v23, #0
    s.shli       s14, s11, #32
    v.extract    s11, v34, #0
    s.shli       s15, s13, #32
    s.add        s13, s1, s4
    v.extract    s1, v24, #1
    v.extract    s4, v35, #1
    v.insert     v15, s6, #5
    v.insert     v18, s5, #5
    s.or         s5, s7, s9
    s.or         s6, s2, s10
    s.or         s2, s3, s14
    s.or         s3, s11, s15
    s.lshri      s7, s13, #32
    v.extract    s9, v23, #1
    s.shli       s10, s1, #32
    v.extract    s1, v34, #1
    s.shli       s11, s4, #32
    s.add        s4, s5, s6
    s.add        s5, s2, s3
    v.extract    s2, v24, #2
    v.extract    s3, v35, #2
    v.insert     v15, s13, #6
    v.insert     v18, s7, #6
    v.movi       v21, #0
    v.movi       v22, #0
    s.or         s6, s9, s10
    s.or         s7, s1, s11
    s.lshri      s1, s4, #32
    s.lshri      s9, s5, #32
    v.extract    s10, v23, #2
    s.shli       s11, s2, #32
    v.extract    s2, v34, #2
    s.shli       s13, s3, #32
    s.add        s3, s6, s7
    v.extract    s6, v24, #3
    v.extract    s7, v35, #3
    v.insert     v15, s4, #7
    v.insert     v18, s1, #7
    v.insert     v21, s5, #0
    v.insert     v22, s9, #0
    s.or         s1, s10, s11
    s.or         s4, s2, s13
    s.lshri      s2, s3, #32
    v.extract    s5, v23, #3
    s.shli       s9, s6, #32
    v.extract    s6, v34, #3
    s.shli       s10, s7, #32
    s.add        s7, s1, s4
    v.extract    s1, v24, #4
    v.extract    s4, v35, #4
    v.insert     v21, s3, #1
    v.insert     v22, s2, #1
    s.or         s2, s5, s9
    s.or         s3, s6, s10
    s.lshri      s5, s7, #32
    v.extract    s6, v23, #4
    s.shli       s9, s1, #32
    v.extract    s1, v34, #4
    s.shli       s10, s4, #32
    s.add        s4, s2, s3
    v.extract    s2, v24, #5
    v.extract    s3, v35, #5
    v.insert     v21, s7, #2
    v.insert     v22, s5, #2
    s.or         s5, s6, s9
    s.or         s6, s1, s10
    s.lshri      s1, s4, #32
    v.extract    s7, v23, #5
    s.shli       s9, s2, #32
    v.extract    s2, v34, #5
    s.shli       s10, s3, #32
    s.add        s3, s5, s6
    v.extract    s5, v24, #6
    v.extract    s6, v35, #6
    v.insert     v21, s4, #3
    v.insert     v22, s1, #3
    s.or         s1, s7, s9
    s.or         s4, s2, s10
    s.lshri      s2, s3, #32
    v.extract    s7, v23, #6
    s.shli       s9, s5, #32
    v.extract    s5, v34, #6
    s.shli       s10, s6, #32
    s.add        s6, s1, s4
    v.extract    s1, v24, #7
    v.extract    s4, v35, #7
    v.extract    s11, v26, #0
    v.extract    s13, v35, #0
    v.insert     v21, s3, #4
    v.insert     v22, s2, #4
    s.or         s2, s7, s9
    s.or         s3, s5, s10
    s.lshri      s5, s6, #32
    v.extract    s7, v23, #7
    s.shli       s9, s1, #32
    v.extract    s1, v34, #7
    s.shli       s10, s4, #32
    v.extract    s4, v25, #0
    s.shli       s14, s11, #32
    v.extract    s11, v34, #0
    s.shli       s15, s13, #32
    s.add        s13, s2, s3
    v.extract    s2, v26, #1
    v.extract    s3, v35, #1
    v.insert     v21, s6, #5
    v.insert     v22, s5, #5
    s.or         s5, s7, s9
    s.or         s6, s1, s10
    s.or         s1, s4, s14
    s.or         s4, s11, s15
    s.lshri      s7, s13, #32
    v.extract    s9, v25, #1
    s.shli       s10, s2, #32
    v.extract    s2, v34, #1
    s.shli       s11, s3, #32
    s.add        s3, s5, s6
    s.add        s5, s1, s4
    v.extract    s1, v26, #2
    v.extract    s4, v35, #2
    v.insert     v21, s13, #6
    v.insert     v22, s7, #6
    v.movi       v23, #0
    v.movi       v24, #0
    s.or         s6, s9, s10
    s.or         s7, s2, s11
    s.lshri      s2, s3, #32
    s.lshri      s9, s5, #32
    v.extract    s10, v25, #2
    s.shli       s11, s1, #32
    v.extract    s1, v34, #2
    s.shli       s13, s4, #32
    s.add        s4, s6, s7
    v.extract    s6, v26, #3
    v.extract    s7, v35, #3
    v.insert     v21, s3, #7
    v.insert     v22, s2, #7
    v.insert     v23, s5, #0
    v.insert     v24, s9, #0
    s.or         s2, s10, s11
    s.or         s3, s1, s13
    s.lshri      s1, s4, #32
    v.extract    s5, v25, #3
    s.shli       s9, s6, #32
    v.extract    s6, v34, #3
    s.shli       s10, s7, #32
    s.add        s7, s2, s3
    v.extract    s2, v26, #4
    v.extract    s3, v35, #4
    v.insert     v23, s4, #1
    v.insert     v24, s1, #1
    s.or         s1, s5, s9
    s.or         s4, s6, s10
    s.lshri      s5, s7, #32
    v.extract    s6, v25, #4
    s.shli       s9, s2, #32
    v.extract    s2, v34, #4
    s.shli       s10, s3, #32
    s.add        s3, s1, s4
    v.extract    s1, v26, #5
    v.extract    s4, v35, #5
    v.insert     v23, s7, #2
    v.insert     v24, s5, #2
    s.or         s5, s6, s9
    s.or         s6, s2, s10
    s.lshri      s2, s3, #32
    v.extract    s7, v25, #5
    s.shli       s9, s1, #32
    v.extract    s1, v34, #5
    s.shli       s10, s4, #32
    s.add        s4, s5, s6
    v.extract    s5, v26, #6
    v.extract    s6, v35, #6
    v.insert     v23, s3, #3
    v.insert     v24, s2, #3
    s.or         s2, s7, s9
    s.or         s3, s1, s10
    s.lshri      s1, s4, #32
    v.extract    s7, v25, #6
    s.shli       s9, s5, #32
    v.extract    s5, v34, #6
    s.shli       s10, s6, #32
    s.add        s6, s2, s3
    v.extract    s2, v26, #7
    v.extract    s3, v35, #7
    v.extract    s11, v28, #0
    v.extract    s13, v35, #0
    v.insert     v23, s4, #4
    v.insert     v24, s1, #4
    s.or         s1, s7, s9
    s.or         s4, s5, s10
    s.lshri      s5, s6, #32
    v.extract    s7, v25, #7
    s.shli       s9, s2, #32
    v.extract    s2, v34, #7
    s.shli       s10, s3, #32
    v.extract    s3, v27, #0
    s.shli       s14, s11, #32
    v.extract    s11, v34, #0
    s.shli       s15, s13, #32
    s.add        s13, s1, s4
    v.extract    s1, v28, #1
    v.extract    s4, v35, #1
    v.insert     v23, s6, #5
    v.insert     v24, s5, #5
    s.or         s5, s7, s9
    s.or         s6, s2, s10
    s.or         s2, s3, s14
    s.or         s3, s11, s15
    s.lshri      s7, s13, #32
    v.extract    s9, v27, #1
    s.shli       s10, s1, #32
    v.extract    s1, v34, #1
    s.shli       s11, s4, #32
    s.add        s4, s5, s6
    s.add        s5, s2, s3
    v.extract    s2, v28, #2
    v.extract    s3, v35, #2
    v.insert     v23, s13, #6
    v.insert     v24, s7, #6
    v.movi       v25, #0
    v.movi       v26, #0
    s.or         s6, s9, s10
    s.or         s7, s1, s11
    s.lshri      s1, s4, #32
    s.lshri      s9, s5, #32
    v.extract    s10, v27, #2
    s.shli       s11, s2, #32
    v.extract    s2, v34, #2
    s.shli       s13, s3, #32
    s.add        s3, s6, s7
    v.extract    s6, v28, #3
    v.extract    s7, v35, #3
    v.insert     v23, s4, #7
    v.insert     v24, s1, #7
    v.insert     v25, s5, #0
    v.insert     v26, s9, #0
    s.or         s1, s10, s11
    s.or         s4, s2, s13
    s.lshri      s2, s3, #32
    v.extract    s5, v27, #3
    s.shli       s9, s6, #32
    v.extract    s6, v34, #3
    s.shli       s10, s7, #32
    s.add        s7, s1, s4
    v.extract    s1, v28, #4
    v.extract    s4, v35, #4
    v.insert     v25, s3, #1
    v.insert     v26, s2, #1
    s.or         s2, s5, s9
    s.or         s3, s6, s10
    s.lshri      s5, s7, #32
    v.extract    s6, v27, #4
    s.shli       s9, s1, #32
    v.extract    s1, v34, #4
    s.shli       s10, s4, #32
    s.add        s4, s2, s3
    v.extract    s2, v28, #5
    v.extract    s3, v35, #5
    v.insert     v25, s7, #2
    v.insert     v26, s5, #2
    s.or         s5, s6, s9
    s.or         s6, s1, s10
    s.lshri      s1, s4, #32
    v.extract    s7, v27, #5
    s.shli       s9, s2, #32
    v.extract    s2, v34, #5
    s.shli       s10, s3, #32
    s.add        s3, s5, s6
    v.extract    s5, v28, #6
    v.extract    s6, v35, #6
    v.insert     v25, s4, #3
    v.insert     v26, s1, #3
    s.or         s1, s7, s9
    s.or         s4, s2, s10
    s.lshri      s2, s3, #32
    v.extract    s7, v27, #6
    s.shli       s9, s5, #32
    v.extract    s5, v34, #6
    s.shli       s10, s6, #32
    s.add        s6, s1, s4
    v.extract    s1, v28, #7
    v.extract    s4, v35, #7
    v.extract    s11, v29, #0
    v.extract    s13, v35, #0
    v.insert     v25, s3, #4
    v.insert     v26, s2, #4
    s.or         s2, s7, s9
    s.or         s3, s5, s10
    s.lshri      s5, s6, #32
    v.extract    s7, v27, #7
    s.shli       s9, s1, #32
    v.extract    s1, v34, #7
    s.shli       s10, s4, #32
    v.extract    s4, v14, #0
    s.shli       s14, s11, #32
    v.extract    s11, v34, #0
    s.shli       s15, s13, #32
    s.add        s13, s2, s3
    v.extract    s2, v29, #1
    v.extract    s3, v35, #1
    v.insert     v25, s6, #5
    v.insert     v26, s5, #5
    s.or         s5, s7, s9
    s.or         s6, s1, s10
    s.or         s1, s4, s14
    s.or         s4, s11, s15
    s.lshri      s7, s13, #32
    v.extract    s9, v14, #1
    s.shli       s10, s2, #32
    v.extract    s2, v34, #1
    s.shli       s11, s3, #32
    s.add        s3, s5, s6
    s.add        s5, s1, s4
    v.extract    s1, v29, #2
    v.extract    s4, v35, #2
    v.insert     v25, s13, #6
    v.insert     v26, s7, #6
    v.movi       v27, #0
    v.movi       v28, #0
    s.or         s6, s9, s10
    s.or         s7, s2, s11
    s.lshri      s2, s3, #32
    s.lshri      s9, s5, #32
    v.extract    s10, v14, #2
    s.shli       s11, s1, #32
    v.extract    s1, v34, #2
    s.shli       s13, s4, #32
    s.add        s4, s6, s7
    v.extract    s6, v29, #3
    v.extract    s7, v35, #3
    v.insert     v25, s3, #7
    v.insert     v26, s2, #7
    v.insert     v27, s5, #0
    v.insert     v28, s9, #0
    s.or         s2, s10, s11
    s.or         s3, s1, s13
    s.lshri      s1, s4, #32
    v.extract    s5, v14, #3
    s.shli       s9, s6, #32
    v.extract    s6, v34, #3
    s.shli       s10, s7, #32
    s.add        s7, s2, s3
    v.extract    s2, v29, #4
    v.extract    s3, v35, #4
    v.insert     v27, s4, #1
    v.insert     v28, s1, #1
    s.or         s1, s5, s9
    s.or         s4, s6, s10
    s.lshri      s5, s7, #32
    v.extract    s6, v14, #4
    s.shli       s9, s2, #32
    v.extract    s2, v34, #4
    s.shli       s10, s3, #32
    s.add        s3, s1, s4
    v.extract    s1, v29, #5
    v.extract    s4, v35, #5
    v.insert     v27, s7, #2
    v.insert     v28, s5, #2
    s.or         s5, s6, s9
    s.or         s6, s2, s10
    s.lshri      s2, s3, #32
    v.extract    s7, v14, #5
    s.shli       s9, s1, #32
    v.extract    s1, v34, #5
    s.shli       s10, s4, #32
    s.add        s4, s5, s6
    v.extract    s5, v29, #6
    v.extract    s6, v35, #6
    v.insert     v27, s3, #3
    v.insert     v28, s2, #3
    s.or         s2, s7, s9
    s.or         s3, s1, s10
    s.lshri      s1, s4, #32
    v.extract    s7, v14, #6
    s.shli       s9, s5, #32
    v.extract    s5, v34, #6
    s.shli       s10, s6, #32
    s.add        s6, s2, s3
    v.extract    s2, v29, #7
    v.extract    s3, v35, #7
    v.extract    s11, v31, #0
    v.extract    s13, v35, #0
    v.insert     v27, s4, #4
    v.insert     v28, s1, #4
    s.or         s1, s7, s9
    s.or         s4, s5, s10
    s.lshri      s5, s6, #32
    v.extract    s7, v14, #7
    s.shli       s9, s2, #32
    v.extract    s2, v34, #7
    s.shli       s10, s3, #32
    v.extract    s3, v30, #0
    s.shli       s14, s11, #32
    v.extract    s11, v34, #0
    s.shli       s15, s13, #32
    s.add        s13, s1, s4
    v.extract    s1, v31, #1
    v.extract    s4, v35, #1
    v.insert     v27, s6, #5
    v.insert     v28, s5, #5
    s.or         s5, s7, s9
    s.or         s6, s2, s10
    s.or         s2, s3, s14
    s.or         s3, s11, s15
    s.lshri      s7, s13, #32
    v.extract    s9, v30, #1
    s.shli       s10, s1, #32
    v.extract    s1, v34, #1
    s.shli       s11, s4, #32
    s.add        s4, s5, s6
    s.add        s5, s2, s3
    v.extract    s2, v31, #2
    v.extract    s3, v35, #2
    v.insert     v27, s13, #6
    v.insert     v28, s7, #6
    v.movi       v14, #0
    v.movi       v29, #0
    s.or         s6, s9, s10
    s.or         s7, s1, s11
    s.lshri      s1, s4, #32
    s.lshri      s9, s5, #32
    v.extract    s10, v30, #2
    s.shli       s11, s2, #32
    v.extract    s2, v34, #2
    s.shli       s13, s3, #32
    s.add        s3, s6, s7
    v.extract    s6, v31, #3
    v.extract    s7, v35, #3
    v.insert     v27, s4, #7
    v.insert     v28, s1, #7
    v.insert     v14, s5, #0
    v.insert     v29, s9, #0
    s.or         s1, s10, s11
    s.or         s4, s2, s13
    s.lshri      s2, s3, #32
    v.extract    s5, v30, #3
    s.shli       s9, s6, #32
    v.extract    s6, v34, #3
    s.shli       s10, s7, #32
    s.add        s7, s1, s4
    v.extract    s1, v31, #4
    v.extract    s4, v35, #4
    v.insert     v14, s3, #1
    v.insert     v29, s2, #1
    s.or         s2, s5, s9
    s.or         s3, s6, s10
    s.lshri      s5, s7, #32
    v.extract    s6, v30, #4
    s.shli       s9, s1, #32
    v.extract    s1, v34, #4
    s.shli       s10, s4, #32
    s.add        s4, s2, s3
    v.extract    s2, v31, #5
    v.extract    s3, v35, #5
    v.insert     v14, s7, #2
    v.insert     v29, s5, #2
    s.or         s5, s6, s9
    s.or         s6, s1, s10
    s.lshri      s1, s4, #32
    v.extract    s7, v30, #5
    s.shli       s9, s2, #32
    v.extract    s2, v34, #5
    s.shli       s10, s3, #32
    s.add        s3, s5, s6
    v.extract    s5, v31, #6
    v.extract    s6, v35, #6
    v.insert     v14, s4, #3
    v.insert     v29, s1, #3
    v.extract    s1, v32, #0
    v.extract    s4, v33, #0
    v.splat      v38, s1
    v.splat      v39, s4
    v.movi       v40, #1
    v.cmp.ltu    p10, v32, v38
    v.sub        v41, v32, v38
    s.or         s11, s7, s9
    s.or         s7, s2, s10
    s.lshri      s2, s3, #32
    v.extract    s9, v30, #6
    s.shli       s10, s5, #32
    v.extract    s5, v34, #6
    s.shli       s13, s6, #32
    s.add        s6, s11, s7
    v.extract    s7, v31, #7
    v.extract    s11, v35, #7
    v.insert     v14, s3, #4
    v.movi       v31, #0
    v.insert     v29, s2, #4
    v.sub        v32, v33, v39
    @p10 v.sel        v33, v40, v31
    v.movi       v31, #31
    v.movi       v35, #1
    v.sub        v40, v32, v33
    v.ashr       v32, v41, v31
    v.movi       v31, #0
    s.or         s2, s9, s10
    s.or         s3, s5, s13
    s.lshri      s5, s6, #32
    v.extract    s9, v30, #7
    s.shli       s10, s7, #32
    v.extract    s7, v34, #7
    s.shli       s13, s11, #32
    v.cmp.ne     p10, v40, v32
    v.iota       v30                             // arange(0, VLEN)
    v.splat      v32, s49
    s.add        s11, s2, s3
    @p10 v.sel        v33, v35, v31
    v.insert     v14, s6, #5
    v.insert     v29, s5, #5
    s.or         s2, s9, s10
    s.or         s3, s7, s13
    s.lshri      s5, s11, #32
    v.cmp.lt     p10, v30, v32
    s.add        s6, s2, s3
    @p10 v.reduce.or  s2, v33
    v.insert     v14, s11, #6
    v.insert     v29, s5, #6
    s.lshri      s3, s6, #32
    s.shli       s5, s4, #32
    s.cmp.eq     s4, s2, s8
    v.insert     v14, s6, #7
    v.insert     v29, s3, #7
    s.or         s2, s1, s5
    br.nz        s4, narrow_ok_1
    trap         #677220
narrow_ok_1:
    v.movi       v30, #1
    v.movi       v31, #0
    v.cmp.ltu    p10, v36, v38
    v.sub        v32, v36, v38
    @p10 v.sel        v33, v30, v31
    v.sub        v30, v37, v39
    v.movi       v31, #31
    v.movi       v34, #1
    v.sub        v35, v30, v33
    v.ashr       v30, v32, v31
    v.movi       v31, #0
    s.movz       s1, #8
    v.cmp.ne     p10, v35, v30
    v.iota       v30                             // arange(0, VLEN)
    v.splat      v33, s1
    @p10 v.sel        v35, v34, v31
    s.movz       s1, #0
    v.cmp.lt     p10, v30, v33
    @p10 v.reduce.or  s3, v35
    s.cmp.eq     s4, s3, s1
    br.nz        s4, narrow_ok_2
    trap         #677220
narrow_ok_2:
    v.movi       v30, #1
    v.movi       v31, #0
    v.cmp.ltu    p10, v15, v38
    v.sub        v33, v15, v38
    @p10 v.sel        v15, v30, v31
    v.sub        v30, v18, v39
    v.movi       v18, #31
    v.movi       v31, #1
    v.sub        v34, v30, v15
    v.ashr       v15, v33, v18
    v.movi       v18, #0
    s.movz       s1, #8
    v.cmp.ne     p10, v34, v15
    v.iota       v15                             // arange(0, VLEN)
    v.splat      v30, s1
    @p10 v.sel        v34, v31, v18
    s.movz       s1, #0
    v.cmp.lt     p10, v15, v30
    @p10 v.reduce.or  s3, v34
    s.cmp.eq     s4, s3, s1
    br.nz        s4, narrow_ok_3
    trap         #677220
narrow_ok_3:
    v.movi       v15, #1
    v.movi       v18, #0
    v.cmp.ltu    p10, v21, v38
    v.sub        v30, v21, v38
    @p10 v.sel        v21, v15, v18
    v.sub        v15, v22, v39
    v.movi       v18, #31
    v.movi       v22, #1
    v.sub        v31, v15, v21
    v.ashr       v15, v30, v18
    v.movi       v18, #0
    s.movz       s1, #8
    v.cmp.ne     p10, v31, v15
    v.iota       v15                             // arange(0, VLEN)
    v.splat      v21, s1
    @p10 v.sel        v31, v22, v18
    s.movz       s1, #0
    v.cmp.lt     p10, v15, v21
    @p10 v.reduce.or  s3, v31
    s.cmp.eq     s4, s3, s1
    br.nz        s4, narrow_ok_4
    trap         #677220
narrow_ok_4:
    v.movi       v15, #1
    v.movi       v18, #0
    v.cmp.ltu    p10, v23, v38
    v.sub        v21, v23, v38
    @p10 v.sel        v22, v15, v18
    v.sub        v15, v24, v39
    v.movi       v18, #31
    v.movi       v23, #1
    v.sub        v24, v15, v22
    v.ashr       v15, v21, v18
    v.movi       v18, #0
    s.movz       s1, #8
    v.cmp.ne     p10, v24, v15
    v.iota       v15                             // arange(0, VLEN)
    v.splat      v22, s1
    @p10 v.sel        v24, v23, v18
    s.movz       s1, #0
    v.cmp.lt     p10, v15, v22
    @p10 v.reduce.or  s3, v24
    s.cmp.eq     s4, s3, s1
    br.nz        s4, narrow_ok_5
    trap         #677220
narrow_ok_5:
    v.movi       v15, #1
    v.movi       v18, #0
    v.cmp.ltu    p10, v25, v38
    v.sub        v22, v25, v38
    @p10 v.sel        v23, v15, v18
    v.sub        v15, v26, v39
    v.movi       v18, #31
    v.movi       v24, #1
    v.sub        v25, v15, v23
    v.ashr       v15, v22, v18
    v.movi       v18, #0
    s.movz       s1, #8
    v.cmp.ne     p10, v25, v15
    v.iota       v15                             // arange(0, VLEN)
    v.splat      v23, s1
    @p10 v.sel        v25, v24, v18
    s.movz       s1, #0
    v.cmp.lt     p10, v15, v23
    @p10 v.reduce.or  s3, v25
    s.cmp.eq     s4, s3, s1
    br.nz        s4, narrow_ok_6
    trap         #677220
narrow_ok_6:
    v.movi       v15, #1
    v.movi       v18, #0
    v.cmp.ltu    p10, v27, v38
    v.sub        v23, v27, v38
    @p10 v.sel        v24, v15, v18
    v.sub        v15, v28, v39
    v.movi       v18, #31
    v.movi       v25, #1
    v.sub        v26, v15, v24
    v.ashr       v15, v23, v18
    v.movi       v18, #0
    s.movz       s1, #8
    v.cmp.ne     p10, v26, v15
    v.iota       v15                             // arange(0, VLEN)
    v.splat      v24, s1
    @p10 v.sel        v26, v25, v18
    s.movz       s1, #0
    v.cmp.lt     p10, v15, v24
    @p10 v.reduce.or  s3, v26
    s.cmp.eq     s4, s3, s1
    br.nz        s4, narrow_ok_7
    trap         #677220
narrow_ok_7:
    v.movi       v15, #1
    v.movi       v18, #0
    v.cmp.ltu    p10, v14, v38
    v.sub        v24, v14, v38
    @p10 v.sel        v14, v15, v18
    v.sub        v15, v29, v39
    v.movi       v18, #31
    v.movi       v25, #1
    v.sub        v26, v15, v14
    v.ashr       v14, v24, v18
    v.movi       v15, #0
    s.movz       s1, #8
    v.cmp.ne     p10, v26, v14
    v.iota       v14                             // arange(0, VLEN)
    v.splat      v18, s1
    @p10 v.sel        v26, v25, v15
    s.movz       s1, #0
    v.cmp.lt     p10, v14, v18
    @p10 v.reduce.or  s3, v26
    s.cmp.eq     s4, s3, s1
    br.nz        s4, narrow_ok_8
    trap         #677220
narrow_ok_8:
    v.movi       v14, #1
    v.movi       v15, #0
    v.movi       v18, #0
    s.movz       s1, #8
    @p1 v.sel        v25, v14, v15
    v.iota       v14                             // arange(0, VLEN)
    v.splat      v15, s1
    v.extract    s1, v25, #0
    s.add        s3, s12, s2                     // a 64-bit tile origin
    v.splat      v25, s1
    v.cmp.lt     p10, v14, v15
    s.rdspecial  s1, arg_base
    v.cmp.ne     p11, v25, v18
    p.and        p12, p9, p11
    v.movi       v14, #1
    p.and        p11, p10, p12
    v.movi       v15, #0
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p11 v.ld.gather.sb v18, [s3, v41]           // index is in elements (ISA sec 9.1)
    s.rdspecial  s2, role_id
    @p2 v.sel        v25, v14, v15
    s.movz       s4, #512
    v.movi       v14, #0
    v.extract    s5, v25, #0
    s.mul        s6, s2, s4
    v.splat      v15, s5
    s.movz       s2, #8
    v.iota       v25                             // arange(0, VLEN)
    v.splat      v26, s2
    v.cmp.ne     p10, v15, v14
    p.and        p11, p9, p10
    v.cmp.lt     p10, v25, v26
    p.and        p12, p10, p11
    v.movi       v14, #1
    v.movi       v15, #0
    v.movi       v25, #0
    s.ld.d       s2, [s1, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    @p3 v.sel        v26, v14, v15
    s.movz       s1, #8
    v.iota       v14                             // arange(0, VLEN)
    v.extract    s4, v26, #0
    v.splat      v15, s1
    v.splat      v26, s4
    v.cmp.lt     p10, v14, v15
    v.cmp.ne     p11, v26, v25
    p.and        p13, p9, p11
    s.add        s1, s2, s6                      // this context's own scratch
    p.and        p11, p10, p13
    s.addi       s2, s1, #0
    v.movi       v14, #1
    v.st.w       [s2, #0], v18
    s.addi       s4, s2, #64
    v.movi       v15, #0
    v.movi       v18, #0
    s.movz       s5, #8
    @p4 v.sel        v25, v14, v15
    v.iota       v14                             // arange(0, VLEN)
    v.splat      v15, s5
    v.extract    s5, v25, #0
    s.addi       s6, s2, #128
    v.splat      v25, s5
    v.cmp.lt     p10, v14, v15
    v.movi       v14, #1
    v.movi       v15, #0
    v.movi       v26, #0
    s.movz       s5, #8
    @p5 v.sel        v27, v14, v15
    v.iota       v14                             // arange(0, VLEN)
    v.movi       v15, #0                         // other=, materialised (sec 12)
    @p12 v.ld.gather.sb v15, [s3, v32]           // index is in elements (ISA sec 9.1)
    v.cmp.ne     p12, v25, v18
    p.and        p13, p9, p12
    v.extract    s7, v27, #0
    p.and        p12, p10, p13
    v.splat      v18, s7
    v.splat      v25, s5
    s.addi       s5, s2, #192
    v.cmp.ne     p10, v18, v26
    p.and        p13, p9, p10
    s.addi       s7, s2, #256
    v.st.w       [s4, #0], v15
    v.movi       v15, #1
    v.movi       v18, #0
    v.movi       v26, #0
    s.movz       s4, #8
    @p6 v.sel        v27, v15, v18
    v.iota       v15                             // arange(0, VLEN)
    v.splat      v18, s4
    v.extract    s4, v27, #0
    s.addi       s8, s2, #320
    v.splat      v27, s4
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p11 v.ld.gather.sb v28, [s3, v33]           // index is in elements (ISA sec 9.1)
    v.cmp.lt     p10, v14, v25
    p.and        p11, p10, p13
    v.cmp.ne     p10, v27, v26
    p.and        p13, p9, p10
    v.st.w       [s6, #0], v28
    v.movi       v14, #1
    v.movi       v25, #0
    v.movi       v26, #0
    s.movz       s4, #8
    @p7 v.sel        v27, v14, v25
    v.iota       v14                             // arange(0, VLEN)
    v.splat      v25, s4
    v.extract    s4, v27, #0
    s.addi       s6, s2, #384
    v.splat      v27, s4
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p12 v.ld.gather.sb v28, [s3, v30]           // index is in elements (ISA sec 9.1)
    v.cmp.lt     p10, v15, v18
    p.and        p12, p10, p13
    v.cmp.ne     p10, v27, v26
    p.and        p13, p9, p10
    v.st.w       [s5, #0], v28
    v.movi       v15, #1
    v.movi       v18, #0
    v.movi       v26, #0
    s.movz       s4, #8
    @p8 v.sel        v27, v15, v18
    v.iota       v15                             // arange(0, VLEN)
    v.splat      v18, s4
    v.extract    s4, v27, #0
    s.addi       s5, s2, #448
    v.splat      v27, s4
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p11 v.ld.gather.sb v28, [s3, v21]           // index is in elements (ISA sec 9.1)
    v.cmp.lt     p10, v14, v25
    p.and        p11, p10, p13
    v.cmp.ne     p10, v27, v26
    p.and        p13, p9, p10
    v.st.w       [s7, #0], v28
    v.extract    s2, v1, #0
    v.extract    s4, v0, #0
    s.shli       s7, s2, #32
    s.movz       s2, #16
    s.or         s9, s4, s7
    v.movi       v0, #0
    s.mul        s4, s9, s2
    v.movi       v1, #0
    v.movi       v14, #0
    v.movi       v21, #0
    s.lshri      s2, s4, #32
    v.movi       v25, #0                         // other=, materialised (sec 12)
    @p12 v.ld.gather.sb v25, [s3, v22]           // index is in elements (ISA sec 9.1)
    v.cmp.lt     p10, v15, v18
    p.and        p12, p10, p13
    v.extract    s7, v2, #0
    v.st.w       [s8, #0], v25
    v.extract    s8, v3, #0
    v.extract    s9, v5, #0
    s.shli       s10, s8, #32
    s.shli       s8, s9, #32
    s.or         s9, s7, s10
    v.extract    s7, v4, #0
    v.movi       v2, #0
    s.or         s10, s7, s8
    s.movz       s7, #16
    v.movi       v3, #0
    s.mul        s8, s9, s7
    s.movz       s7, #16
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p11 v.ld.gather.sb v4, [s3, v23]            // index is in elements (ISA sec 9.1)
    s.mul        s9, s10, s7
    s.lshri      s7, s8, #32
    v.st.w       [s6, #0], v4
    v.extract    s6, v8, #0
    v.movi       v4, #0
    s.shli       s10, s6, #32
    v.movi       v5, #0
    v.movi       v8, #0
    v.movi       v15, #0                         // other=, materialised (sec 12)
    @p12 v.ld.gather.sb v15, [s3, v24]           // index is in elements (ISA sec 9.1)
    v.extract    s3, v6, #0
    v.movi       v6, #0
    s.or         s6, s3, s10
    s.movz       s3, #16
    s.mul        s10, s6, s3
    s.lshri      s3, s9, #32
    v.st.w       [s5, #0], v15
    fence.acq_rel.device
    v.extract    s5, v17, #0
    v.insert     v0, s4, #0
    v.insert     v1, s2, #0
    v.extract    s2, v10, #0
    v.extract    s4, v16, #0
    s.shli       s6, s5, #32
    s.shli       s5, s2, #32
    s.or         s2, s4, s6
    v.extract    s4, v9, #0
    v.movi       v9, #0
    s.or         s6, s4, s5
    s.movz       s4, #16
    v.movi       v10, #0
    s.mul        s5, s2, s4
    s.movz       s2, #16
    v.movi       v15, #0
    s.mul        s4, s6, s2
    s.lshri      s2, s10, #32
    v.insert     v14, s8, #0
    v.extract    s6, v7, #0
    v.movi       v7, #0
    v.insert     v21, s7, #0
    v.extract    s7, v11, #0
    v.movi       v11, #0
    s.shli       s8, s7, #32
    v.insert     v2, s9, #0
    v.extract    s7, v12, #0
    s.or         s9, s6, s8
    s.movz       s6, #16
    v.movi       v12, #0
    s.mul        s8, s9, s6
    s.lshri      s6, s5, #32
    v.insert     v3, s3, #0
    v.extract    s3, v13, #0
    v.movi       v13, #0
    s.shli       s9, s3, #32
    v.insert     v4, s10, #0
    s.or         s3, s7, s9
    s.movz       s7, #16
    v.extract    s9, v0, #0
    s.mul        s10, s3, s7
    v.movi       v16, #0
    s.lshri      s3, s4, #32
    v.insert     v5, s2, #0
    v.extract    s2, v1, #0
    v.insert     v8, s5, #0
    s.shli       s5, s2, #32
    v.extract    s2, v1, #0
    s.or         s7, s9, s5
    v.extract    s5, v0, #0
    s.shli       s9, s2, #32
    v.insert     v6, s6, #0
    s.lshri      s2, s8, #32
    s.or         s6, s5, s9
    s.lshri      s5, s10, #32
    v.insert     v9, s4, #0
    s.lshri      s4, s7, #32
    v.insert     v10, s3, #0
    v.extract    s3, v1, #0
    v.insert     v15, s8, #0
    v.insert     v7, s2, #0
    v.insert     v11, s10, #0
    v.insert     v12, s5, #0
    v.insert     v13, s7, #0
    v.insert     v16, s4, #0
    v.extract    s2, v0, #0
    s.shli       s4, s3, #32
    s.lshri      s3, s6, #32
    v.extract    s5, v1, #0
    s.or         s7, s2, s4
    v.insert     v13, s6, #1
    v.insert     v16, s3, #1
    v.extract    s2, v0, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v1, #0
    s.or         s6, s2, s3
    v.insert     v13, s7, #2
    v.insert     v16, s4, #2
    v.extract    s2, v0, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v1, #0
    s.or         s7, s2, s3
    v.insert     v13, s6, #3
    v.insert     v16, s4, #3
    v.extract    s2, v0, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v1, #0
    s.or         s6, s2, s3
    v.insert     v13, s7, #4
    v.insert     v16, s4, #4
    v.extract    s2, v0, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v1, #0
    v.extract    s7, v21, #0
    s.or         s8, s2, s3
    v.insert     v13, s6, #5
    v.insert     v16, s4, #5
    v.extract    s2, v0, #0
    s.shli       s3, s5, #32
    v.extract    s4, v14, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s8, #32
    v.extract    s7, v21, #0
    s.or         s9, s2, s3
    s.or         s2, s4, s5
    v.insert     v13, s8, #6
    v.insert     v16, s6, #6
    v.movi       v0, #0
    v.movi       v1, #0
    v.extract    s3, v14, #0
    s.shli       s4, s7, #32
    s.lshri      s5, s9, #32
    s.lshri      s6, s2, #32
    v.extract    s7, v21, #0
    s.or         s8, s3, s4
    v.insert     v13, s9, #7
    v.insert     v16, s5, #7
    v.insert     v0, s2, #0
    v.insert     v1, s6, #0
    v.extract    s2, v14, #0
    s.shli       s3, s7, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v21, #0
    s.or         s6, s2, s3
    v.insert     v0, s8, #1
    v.insert     v1, s4, #1
    v.extract    s2, v14, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v21, #0
    s.or         s7, s2, s3
    v.insert     v0, s6, #2
    v.insert     v1, s4, #2
    v.extract    s2, v14, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v21, #0
    s.or         s6, s2, s3
    v.insert     v0, s7, #3
    v.insert     v1, s4, #3
    v.extract    s2, v14, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v21, #0
    s.or         s7, s2, s3
    v.insert     v0, s6, #4
    v.insert     v1, s4, #4
    v.extract    s2, v14, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v21, #0
    v.extract    s6, v3, #0
    s.or         s8, s2, s3
    v.insert     v0, s7, #5
    v.insert     v1, s4, #5
    v.extract    s2, v14, #0
    s.shli       s3, s5, #32
    v.extract    s4, v2, #0
    s.shli       s5, s6, #32
    s.lshri      s6, s8, #32
    v.extract    s7, v3, #0
    s.or         s9, s2, s3
    s.or         s2, s4, s5
    v.insert     v0, s8, #6
    v.insert     v1, s6, #6
    v.movi       v14, #0
    v.movi       v17, #0
    v.extract    s3, v2, #0
    s.shli       s4, s7, #32
    s.lshri      s5, s9, #32
    s.lshri      s6, s2, #32
    v.extract    s7, v3, #0
    s.or         s8, s3, s4
    v.insert     v0, s9, #7
    v.insert     v1, s5, #7
    v.insert     v14, s2, #0
    v.insert     v17, s6, #0
    v.extract    s2, v2, #0
    s.shli       s3, s7, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v3, #0
    s.or         s6, s2, s3
    v.insert     v14, s8, #1
    v.insert     v17, s4, #1
    v.extract    s2, v2, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v3, #0
    s.or         s7, s2, s3
    v.insert     v14, s6, #2
    v.insert     v17, s4, #2
    v.extract    s2, v2, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v3, #0
    s.or         s6, s2, s3
    v.insert     v14, s7, #3
    v.insert     v17, s4, #3
    v.extract    s2, v2, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v3, #0
    s.or         s7, s2, s3
    v.insert     v14, s6, #4
    v.insert     v17, s4, #4
    v.extract    s2, v2, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v3, #0
    v.extract    s6, v5, #0
    s.or         s8, s2, s3
    v.insert     v14, s7, #5
    v.insert     v17, s4, #5
    v.extract    s2, v2, #0
    s.shli       s3, s5, #32
    v.extract    s4, v4, #0
    s.shli       s5, s6, #32
    s.lshri      s6, s8, #32
    v.extract    s7, v5, #0
    s.or         s9, s2, s3
    s.or         s2, s4, s5
    v.insert     v14, s8, #6
    v.insert     v17, s6, #6
    v.movi       v2, #0
    v.movi       v3, #0
    v.extract    s3, v4, #0
    s.shli       s4, s7, #32
    s.lshri      s5, s9, #32
    s.lshri      s6, s2, #32
    v.extract    s7, v5, #0
    s.or         s8, s3, s4
    v.insert     v14, s9, #7
    v.insert     v17, s5, #7
    v.insert     v2, s2, #0
    v.insert     v3, s6, #0
    v.extract    s2, v4, #0
    s.shli       s3, s7, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v5, #0
    s.or         s6, s2, s3
    v.insert     v2, s8, #1
    v.insert     v3, s4, #1
    v.extract    s2, v4, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v5, #0
    s.or         s7, s2, s3
    v.insert     v2, s6, #2
    v.insert     v3, s4, #2
    v.extract    s2, v4, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v5, #0
    s.or         s6, s2, s3
    v.insert     v2, s7, #3
    v.insert     v3, s4, #3
    v.extract    s2, v4, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v5, #0
    s.or         s7, s2, s3
    v.insert     v2, s6, #4
    v.insert     v3, s4, #4
    v.extract    s2, v4, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v5, #0
    v.extract    s6, v6, #0
    s.or         s8, s2, s3
    v.insert     v2, s7, #5
    v.insert     v3, s4, #5
    v.extract    s2, v4, #0
    s.shli       s3, s5, #32
    v.extract    s4, v8, #0
    s.shli       s5, s6, #32
    s.lshri      s6, s8, #32
    v.extract    s7, v6, #0
    s.or         s9, s2, s3
    s.or         s2, s4, s5
    v.insert     v2, s8, #6
    v.insert     v3, s6, #6
    v.movi       v4, #0
    v.movi       v5, #0
    v.extract    s3, v8, #0
    s.shli       s4, s7, #32
    s.lshri      s5, s9, #32
    s.lshri      s6, s2, #32
    v.extract    s7, v6, #0
    s.or         s8, s3, s4
    v.insert     v2, s9, #7
    v.insert     v3, s5, #7
    v.insert     v4, s2, #0
    v.insert     v5, s6, #0
    v.extract    s2, v8, #0
    s.shli       s3, s7, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v6, #0
    s.or         s6, s2, s3
    v.insert     v4, s8, #1
    v.insert     v5, s4, #1
    v.extract    s2, v8, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v6, #0
    s.or         s7, s2, s3
    v.insert     v4, s6, #2
    v.insert     v5, s4, #2
    v.extract    s2, v8, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v6, #0
    s.or         s6, s2, s3
    v.insert     v4, s7, #3
    v.insert     v5, s4, #3
    v.extract    s2, v8, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v6, #0
    s.or         s7, s2, s3
    v.insert     v4, s6, #4
    v.insert     v5, s4, #4
    v.extract    s2, v8, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v6, #0
    v.extract    s6, v10, #0
    s.or         s8, s2, s3
    v.insert     v4, s7, #5
    v.insert     v5, s4, #5
    v.extract    s2, v8, #0
    s.shli       s3, s5, #32
    v.extract    s4, v9, #0
    s.shli       s5, s6, #32
    s.lshri      s6, s8, #32
    v.extract    s7, v10, #0
    s.or         s9, s2, s3
    s.or         s2, s4, s5
    v.insert     v4, s8, #6
    v.insert     v5, s6, #6
    v.movi       v6, #0
    v.movi       v8, #0
    v.extract    s3, v9, #0
    s.shli       s4, s7, #32
    s.lshri      s5, s9, #32
    s.lshri      s6, s2, #32
    v.extract    s7, v10, #0
    s.or         s8, s3, s4
    v.insert     v4, s9, #7
    v.insert     v5, s5, #7
    v.insert     v6, s2, #0
    v.insert     v8, s6, #0
    v.extract    s2, v9, #0
    s.shli       s3, s7, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v10, #0
    s.or         s6, s2, s3
    v.insert     v6, s8, #1
    v.insert     v8, s4, #1
    v.extract    s2, v9, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v10, #0
    s.or         s7, s2, s3
    v.insert     v6, s6, #2
    v.insert     v8, s4, #2
    v.extract    s2, v9, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v10, #0
    s.or         s6, s2, s3
    v.insert     v6, s7, #3
    v.insert     v8, s4, #3
    v.extract    s2, v9, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v10, #0
    s.or         s7, s2, s3
    v.insert     v6, s6, #4
    v.insert     v8, s4, #4
    v.extract    s2, v9, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v10, #0
    v.extract    s6, v7, #0
    s.or         s8, s2, s3
    v.insert     v6, s7, #5
    v.insert     v8, s4, #5
    v.extract    s2, v9, #0
    s.shli       s3, s5, #32
    v.extract    s4, v15, #0
    s.shli       s5, s6, #32
    s.lshri      s6, s8, #32
    v.extract    s7, v7, #0
    s.or         s9, s2, s3
    s.or         s2, s4, s5
    v.insert     v6, s8, #6
    v.insert     v8, s6, #6
    v.movi       v9, #0
    v.movi       v10, #0
    v.extract    s3, v15, #0
    s.shli       s4, s7, #32
    s.lshri      s5, s9, #32
    s.lshri      s6, s2, #32
    v.extract    s7, v7, #0
    s.or         s8, s3, s4
    v.insert     v6, s9, #7
    v.insert     v8, s5, #7
    v.insert     v9, s2, #0
    v.insert     v10, s6, #0
    v.extract    s2, v15, #0
    s.shli       s3, s7, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v7, #0
    s.or         s6, s2, s3
    v.insert     v9, s8, #1
    v.insert     v10, s4, #1
    v.extract    s2, v15, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v7, #0
    s.or         s7, s2, s3
    v.insert     v9, s6, #2
    v.insert     v10, s4, #2
    v.extract    s2, v15, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v7, #0
    s.or         s6, s2, s3
    v.insert     v9, s7, #3
    v.insert     v10, s4, #3
    v.extract    s2, v15, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v7, #0
    s.or         s7, s2, s3
    v.insert     v9, s6, #4
    v.insert     v10, s4, #4
    v.extract    s2, v15, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v7, #0
    v.extract    s6, v12, #0
    s.or         s8, s2, s3
    v.insert     v9, s7, #5
    v.insert     v10, s4, #5
    v.extract    s2, v15, #0
    s.shli       s3, s5, #32
    v.extract    s4, v11, #0
    s.shli       s5, s6, #32
    s.lshri      s6, s8, #32
    v.extract    s7, v12, #0
    s.or         s9, s2, s3
    s.or         s2, s4, s5
    v.insert     v9, s8, #6
    v.insert     v10, s6, #6
    v.movi       v7, #0
    v.movi       v15, #0
    v.extract    s3, v11, #0
    s.shli       s4, s7, #32
    s.lshri      s5, s9, #32
    s.lshri      s6, s2, #32
    v.extract    s7, v12, #0
    s.or         s8, s3, s4
    v.insert     v9, s9, #7
    v.insert     v10, s5, #7
    v.insert     v7, s2, #0
    v.insert     v15, s6, #0
    v.extract    s2, v11, #0
    s.shli       s3, s7, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v12, #0
    s.or         s6, s2, s3
    v.insert     v7, s8, #1
    v.insert     v15, s4, #1
    v.extract    s2, v11, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v12, #0
    s.or         s7, s2, s3
    v.insert     v7, s6, #2
    v.insert     v15, s4, #2
    v.extract    s2, v11, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v12, #0
    s.or         s6, s2, s3
    v.insert     v7, s7, #3
    v.insert     v15, s4, #3
    v.extract    s2, v11, #0
    s.shli       s3, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v12, #0
    s.or         s7, s2, s3
    v.extract    s2, v20, #0
    v.extract    s3, v16, #0
    v.insert     v7, s6, #4
    v.insert     v15, s4, #4
    v.extract    s4, v11, #0
    s.shli       s6, s5, #32
    s.lshri      s5, s7, #32
    v.extract    s8, v12, #0
    v.extract    s9, v19, #0
    s.shli       s10, s2, #32
    s.shli       s2, s3, #32
    s.or         s3, s4, s6
    v.extract    s4, v13, #0
    v.insert     v7, s7, #5
    v.extract    s6, v20, #1
    v.insert     v15, s5, #5
    v.extract    s5, v16, #1
    s.shli       s7, s8, #32
    s.or         s8, s9, s10
    v.extract    s9, v11, #0
    s.or         s10, s4, s2
    s.lshri      s2, s3, #32
    s.shli       s4, s6, #32
    s.shli       s6, s5, #32
    s.or         s5, s9, s7
    v.extract    s7, v19, #1
    s.add        s9, s8, s10
    v.extract    s8, v13, #1
    v.insert     v7, s3, #6
    v.extract    s3, v20, #2
    v.insert     v15, s2, #6
    v.extract    s2, v16, #2
    v.movi       v11, #0
    v.movi       v12, #0
    s.or         s10, s7, s4
    s.or         s4, s8, s6
    s.lshri      s6, s5, #32
    s.lshri      s7, s9, #32
    s.shli       s8, s3, #32
    s.shli       s3, s2, #32
    s.add        s2, s10, s4
    v.extract    s4, v19, #2
    v.insert     v7, s5, #7
    v.extract    s5, v13, #2
    v.insert     v15, s6, #7
    v.extract    s6, v20, #3
    v.insert     v11, s9, #0
    v.extract    s9, v16, #3
    v.insert     v12, s7, #0
    s.or         s7, s4, s8
    s.or         s4, s5, s3
    s.lshri      s3, s2, #32
    v.extract    s5, v19, #3
    s.shli       s8, s6, #32
    v.extract    s6, v13, #3
    s.shli       s10, s9, #32
    s.add        s9, s7, s4
    v.extract    s4, v20, #4
    v.insert     v11, s2, #1
    v.extract    s2, v16, #4
    v.insert     v12, s3, #1
    s.or         s3, s5, s8
    s.or         s5, s6, s10
    s.lshri      s6, s9, #32
    v.extract    s7, v19, #4
    s.shli       s8, s4, #32
    v.extract    s4, v13, #4
    s.shli       s10, s2, #32
    s.add        s2, s3, s5
    v.extract    s3, v20, #5
    v.insert     v11, s9, #2
    v.extract    s5, v16, #5
    v.insert     v12, s6, #2
    s.or         s6, s7, s8
    s.or         s7, s4, s10
    s.lshri      s4, s2, #32
    v.extract    s8, v19, #5
    s.shli       s9, s3, #32
    v.extract    s3, v13, #5
    s.shli       s10, s5, #32
    s.add        s5, s6, s7
    v.extract    s6, v20, #6
    v.insert     v11, s2, #3
    v.extract    s2, v16, #6
    v.insert     v12, s4, #3
    s.or         s4, s8, s9
    s.or         s7, s3, s10
    s.lshri      s3, s5, #32
    v.extract    s8, v19, #6
    s.shli       s9, s6, #32
    v.extract    s6, v13, #6
    s.shli       s10, s2, #32
    s.add        s2, s4, s7
    v.extract    s4, v20, #7
    v.insert     v11, s5, #4
    v.extract    s5, v16, #7
    v.insert     v12, s3, #4
    v.extract    s3, v20, #0
    s.or         s7, s8, s9
    v.extract    s8, v1, #0
    s.or         s9, s6, s10
    s.lshri      s6, s2, #32
    s.shli       s10, s4, #32
    s.shli       s4, s5, #32
    s.shli       s5, s3, #32
    s.shli       s3, s8, #32
    s.add        s8, s7, s9
    v.extract    s7, v19, #7
    v.insert     v11, s2, #5
    v.extract    s2, v13, #7
    v.insert     v12, s6, #5
    v.extract    s6, v19, #0
    s.or         s9, s7, s10
    v.extract    s7, v0, #0
    s.or         s10, s2, s4
    v.extract    s2, v20, #1
    s.or         s4, s6, s5
    v.extract    s5, v1, #1
    s.or         s6, s7, s3
    s.lshri      s3, s8, #32
    s.shli       s7, s2, #32
    s.shli       s2, s5, #32
    s.add        s5, s9, s10
    v.extract    s9, v19, #1
    s.add        s10, s4, s6
    v.extract    s4, v0, #1
    v.insert     v11, s8, #6
    v.extract    s6, v20, #2
    v.insert     v12, s3, #6
    v.extract    s3, v1, #2
    v.movi       v13, #0
    v.movi       v16, #0
    s.or         s8, s9, s7
    s.or         s7, s4, s2
    s.lshri      s2, s5, #32
    s.lshri      s4, s10, #32
    s.shli       s9, s6, #32
    s.shli       s6, s3, #32
    s.add        s3, s8, s7
    v.extract    s7, v19, #2
    v.insert     v11, s5, #7
    v.extract    s5, v0, #2
    v.insert     v12, s2, #7
    v.extract    s2, v20, #3
    v.insert     v13, s10, #0
    v.extract    s8, v1, #3
    v.insert     v16, s4, #0
    s.or         s4, s7, s9
    s.or         s7, s5, s6
    s.lshri      s5, s3, #32
    v.extract    s6, v19, #3
    s.shli       s9, s2, #32
    v.extract    s2, v0, #3
    s.shli       s10, s8, #32
    s.add        s8, s4, s7
    v.extract    s4, v20, #4
    v.insert     v13, s3, #1
    v.extract    s3, v1, #4
    v.insert     v16, s5, #1
    s.or         s5, s6, s9
    s.or         s6, s2, s10
    s.lshri      s2, s8, #32
    v.extract    s7, v19, #4
    s.shli       s9, s4, #32
    v.extract    s4, v0, #4
    s.shli       s10, s3, #32
    s.add        s3, s5, s6
    v.extract    s5, v20, #5
    v.insert     v13, s8, #2
    v.extract    s6, v1, #5
    v.insert     v16, s2, #2
    s.or         s2, s7, s9
    s.or         s7, s4, s10
    s.lshri      s4, s3, #32
    v.extract    s8, v19, #5
    s.shli       s9, s5, #32
    v.extract    s5, v0, #5
    s.shli       s10, s6, #32
    s.add        s6, s2, s7
    v.extract    s2, v20, #6
    v.insert     v13, s3, #3
    v.extract    s3, v1, #6
    v.insert     v16, s4, #3
    s.or         s4, s8, s9
    s.or         s7, s5, s10
    s.lshri      s5, s6, #32
    v.extract    s8, v19, #6
    s.shli       s9, s2, #32
    v.extract    s2, v0, #6
    s.shli       s10, s3, #32
    s.add        s3, s4, s7
    v.extract    s4, v20, #7
    v.insert     v13, s6, #4
    v.extract    s6, v1, #7
    v.insert     v16, s5, #4
    v.extract    s5, v20, #0
    s.or         s7, s8, s9
    v.extract    s8, v17, #0
    s.or         s9, s2, s10
    s.lshri      s2, s3, #32
    s.shli       s10, s4, #32
    s.shli       s4, s6, #32
    s.shli       s6, s5, #32
    s.shli       s5, s8, #32
    s.add        s8, s7, s9
    v.extract    s7, v19, #7
    v.insert     v13, s3, #5
    v.extract    s3, v0, #7
    v.insert     v16, s2, #5
    v.extract    s2, v19, #0
    s.or         s9, s7, s10
    v.extract    s7, v14, #0
    s.or         s10, s3, s4
    v.extract    s3, v20, #1
    s.or         s4, s2, s6
    v.extract    s2, v17, #1
    s.or         s6, s7, s5
    s.lshri      s5, s8, #32
    s.shli       s7, s3, #32
    s.shli       s3, s2, #32
    s.add        s2, s9, s10
    v.extract    s9, v19, #1
    s.add        s10, s4, s6
    v.extract    s4, v14, #1
    v.insert     v13, s8, #6
    v.extract    s6, v20, #2
    v.insert     v16, s5, #6
    v.extract    s5, v17, #2
    v.movi       v0, #0
    v.movi       v1, #0
    s.or         s8, s9, s7
    s.or         s7, s4, s3
    s.lshri      s3, s2, #32
    s.lshri      s4, s10, #32
    s.shli       s9, s6, #32
    s.shli       s6, s5, #32
    s.add        s5, s8, s7
    v.extract    s7, v19, #2
    v.insert     v13, s2, #7
    v.extract    s2, v14, #2
    v.insert     v16, s3, #7
    v.extract    s3, v20, #3
    v.insert     v0, s10, #0
    v.extract    s8, v17, #3
    v.insert     v1, s4, #0
    s.or         s4, s7, s9
    s.or         s7, s2, s6
    s.lshri      s2, s5, #32
    v.extract    s6, v19, #3
    s.shli       s9, s3, #32
    v.extract    s3, v14, #3
    s.shli       s10, s8, #32
    s.add        s8, s4, s7
    v.extract    s4, v20, #4
    v.insert     v0, s5, #1
    v.extract    s5, v17, #4
    v.insert     v1, s2, #1
    s.or         s2, s6, s9
    s.or         s6, s3, s10
    s.lshri      s3, s8, #32
    v.extract    s7, v19, #4
    s.shli       s9, s4, #32
    v.extract    s4, v14, #4
    s.shli       s10, s5, #32
    s.add        s5, s2, s6
    v.extract    s2, v20, #5
    v.insert     v0, s8, #2
    v.extract    s6, v17, #5
    v.insert     v1, s3, #2
    s.or         s3, s7, s9
    s.or         s7, s4, s10
    s.lshri      s4, s5, #32
    v.extract    s8, v19, #5
    s.shli       s9, s2, #32
    v.extract    s2, v14, #5
    s.shli       s10, s6, #32
    s.add        s6, s3, s7
    v.extract    s3, v20, #6
    v.insert     v0, s5, #3
    v.extract    s5, v17, #6
    v.insert     v1, s4, #3
    s.or         s4, s8, s9
    s.or         s7, s2, s10
    s.lshri      s2, s6, #32
    v.extract    s8, v19, #6
    s.shli       s9, s3, #32
    v.extract    s3, v14, #6
    s.shli       s10, s5, #32
    s.add        s5, s4, s7
    v.extract    s4, v20, #7
    v.insert     v0, s6, #4
    v.extract    s6, v17, #7
    v.insert     v1, s2, #4
    v.extract    s2, v20, #0
    s.or         s7, s8, s9
    v.extract    s8, v3, #0
    s.or         s9, s3, s10
    s.lshri      s3, s5, #32
    s.shli       s10, s4, #32
    s.shli       s4, s6, #32
    s.shli       s6, s2, #32
    s.shli       s2, s8, #32
    s.add        s8, s7, s9
    v.extract    s7, v19, #7
    v.insert     v0, s5, #5
    v.extract    s5, v14, #7
    v.insert     v1, s3, #5
    v.extract    s3, v19, #0
    s.or         s9, s7, s10
    v.extract    s7, v2, #0
    s.or         s10, s5, s4
    v.extract    s4, v20, #1
    s.or         s5, s3, s6
    v.extract    s3, v3, #1
    s.or         s6, s7, s2
    s.lshri      s2, s8, #32
    s.shli       s7, s4, #32
    s.shli       s4, s3, #32
    s.add        s3, s9, s10
    v.extract    s9, v19, #1
    s.add        s10, s5, s6
    v.extract    s5, v2, #1
    v.insert     v0, s8, #6
    v.extract    s6, v20, #2
    v.insert     v1, s2, #6
    v.extract    s2, v3, #2
    v.movi       v14, #0
    v.movi       v17, #0
    s.or         s8, s9, s7
    s.or         s7, s5, s4
    s.lshri      s4, s3, #32
    s.lshri      s5, s10, #32
    s.shli       s9, s6, #32
    s.shli       s6, s2, #32
    s.add        s2, s8, s7
    v.extract    s7, v19, #2
    v.insert     v0, s3, #7
    v.extract    s3, v2, #2
    v.insert     v1, s4, #7
    v.extract    s4, v20, #3
    v.insert     v14, s10, #0
    v.extract    s8, v3, #3
    v.insert     v17, s5, #0
    s.or         s5, s7, s9
    s.or         s7, s3, s6
    s.lshri      s3, s2, #32
    v.extract    s6, v19, #3
    s.shli       s9, s4, #32
    v.extract    s4, v2, #3
    s.shli       s10, s8, #32
    s.add        s8, s5, s7
    v.extract    s5, v20, #4
    v.insert     v14, s2, #1
    v.extract    s2, v3, #4
    v.insert     v17, s3, #1
    s.or         s3, s6, s9
    s.or         s6, s4, s10
    s.lshri      s4, s8, #32
    v.extract    s7, v19, #4
    s.shli       s9, s5, #32
    v.extract    s5, v2, #4
    s.shli       s10, s2, #32
    s.add        s2, s3, s6
    v.extract    s3, v20, #5
    v.insert     v14, s8, #2
    v.extract    s6, v3, #5
    v.insert     v17, s4, #2
    s.or         s4, s7, s9
    s.or         s7, s5, s10
    s.lshri      s5, s2, #32
    v.extract    s8, v19, #5
    s.shli       s9, s3, #32
    v.extract    s3, v2, #5
    s.shli       s10, s6, #32
    s.add        s6, s4, s7
    v.extract    s4, v20, #6
    v.insert     v14, s2, #3
    v.extract    s2, v3, #6
    v.insert     v17, s5, #3
    s.or         s5, s8, s9
    s.or         s7, s3, s10
    s.lshri      s3, s6, #32
    v.extract    s8, v19, #6
    s.shli       s9, s4, #32
    v.extract    s4, v2, #6
    s.shli       s10, s2, #32
    s.add        s2, s5, s7
    v.extract    s5, v20, #7
    v.insert     v14, s6, #4
    v.extract    s6, v3, #7
    v.insert     v17, s3, #4
    v.extract    s3, v20, #0
    s.or         s7, s8, s9
    v.extract    s8, v5, #0
    s.or         s9, s4, s10
    s.lshri      s4, s2, #32
    s.shli       s10, s5, #32
    s.shli       s5, s6, #32
    s.shli       s6, s3, #32
    s.shli       s3, s8, #32
    s.add        s8, s7, s9
    v.extract    s7, v19, #7
    v.insert     v14, s2, #5
    v.extract    s2, v2, #7
    v.insert     v17, s4, #5
    v.extract    s4, v19, #0
    s.or         s9, s7, s10
    v.extract    s7, v4, #0
    s.or         s10, s2, s5
    v.extract    s2, v20, #1
    s.or         s5, s4, s6
    v.extract    s4, v5, #1
    s.or         s6, s7, s3
    s.lshri      s3, s8, #32
    s.shli       s7, s2, #32
    s.shli       s2, s4, #32
    s.add        s4, s9, s10
    v.extract    s9, v19, #1
    s.add        s10, s5, s6
    v.extract    s5, v4, #1
    v.insert     v14, s8, #6
    v.extract    s6, v20, #2
    v.insert     v17, s3, #6
    v.extract    s3, v5, #2
    v.movi       v2, #0
    v.movi       v3, #0
    s.or         s8, s9, s7
    s.or         s7, s5, s2
    s.lshri      s2, s4, #32
    s.lshri      s5, s10, #32
    s.shli       s9, s6, #32
    s.shli       s6, s3, #32
    s.add        s3, s8, s7
    v.extract    s7, v19, #2
    v.insert     v14, s4, #7
    v.extract    s4, v4, #2
    v.insert     v17, s2, #7
    v.extract    s2, v20, #3
    v.insert     v2, s10, #0
    v.extract    s8, v5, #3
    v.insert     v3, s5, #0
    s.or         s5, s7, s9
    s.or         s7, s4, s6
    s.lshri      s4, s3, #32
    v.extract    s6, v19, #3
    s.shli       s9, s2, #32
    v.extract    s2, v4, #3
    s.shli       s10, s8, #32
    s.add        s8, s5, s7
    v.extract    s5, v20, #4
    v.insert     v2, s3, #1
    v.extract    s3, v5, #4
    v.insert     v3, s4, #1
    s.or         s4, s6, s9
    s.or         s6, s2, s10
    s.lshri      s2, s8, #32
    v.extract    s7, v19, #4
    s.shli       s9, s5, #32
    v.extract    s5, v4, #4
    s.shli       s10, s3, #32
    s.add        s3, s4, s6
    v.extract    s4, v20, #5
    v.insert     v2, s8, #2
    v.extract    s6, v5, #5
    v.insert     v3, s2, #2
    s.or         s2, s7, s9
    s.or         s7, s5, s10
    s.lshri      s5, s3, #32
    v.extract    s8, v19, #5
    s.shli       s9, s4, #32
    v.extract    s4, v4, #5
    s.shli       s10, s6, #32
    s.add        s6, s2, s7
    v.extract    s2, v20, #6
    v.insert     v2, s3, #3
    v.extract    s3, v5, #6
    v.insert     v3, s5, #3
    s.or         s5, s8, s9
    s.or         s7, s4, s10
    s.lshri      s4, s6, #32
    v.extract    s8, v19, #6
    s.shli       s9, s2, #32
    v.extract    s2, v4, #6
    s.shli       s10, s3, #32
    s.add        s3, s5, s7
    v.extract    s5, v20, #7
    v.insert     v2, s6, #4
    v.extract    s6, v5, #7
    v.insert     v3, s4, #4
    v.extract    s4, v20, #0
    s.or         s7, s8, s9
    v.extract    s8, v8, #0
    s.or         s9, s2, s10
    s.lshri      s2, s3, #32
    s.shli       s10, s5, #32
    s.shli       s5, s6, #32
    s.shli       s6, s4, #32
    s.shli       s4, s8, #32
    s.add        s8, s7, s9
    v.extract    s7, v19, #7
    v.insert     v2, s3, #5
    v.extract    s3, v4, #7
    v.insert     v3, s2, #5
    v.extract    s2, v19, #0
    s.or         s9, s7, s10
    v.extract    s7, v6, #0
    s.or         s10, s3, s5
    v.extract    s3, v20, #1
    s.or         s5, s2, s6
    v.extract    s2, v8, #1
    s.or         s6, s7, s4
    s.lshri      s4, s8, #32
    s.shli       s7, s3, #32
    s.shli       s3, s2, #32
    s.add        s2, s9, s10
    v.extract    s9, v19, #1
    s.add        s10, s5, s6
    v.extract    s5, v6, #1
    v.insert     v2, s8, #6
    v.extract    s6, v20, #2
    v.insert     v3, s4, #6
    v.extract    s4, v8, #2
    v.movi       v4, #0
    v.movi       v5, #0
    s.or         s8, s9, s7
    s.or         s7, s5, s3
    s.lshri      s3, s2, #32
    s.lshri      s5, s10, #32
    s.shli       s9, s6, #32
    s.shli       s6, s4, #32
    s.add        s4, s8, s7
    v.extract    s7, v19, #2
    v.insert     v2, s2, #7
    v.extract    s2, v6, #2
    v.insert     v3, s3, #7
    v.extract    s3, v20, #3
    v.insert     v4, s10, #0
    v.extract    s8, v8, #3
    v.insert     v5, s5, #0
    s.or         s5, s7, s9
    s.or         s7, s2, s6
    s.lshri      s2, s4, #32
    v.extract    s6, v19, #3
    s.shli       s9, s3, #32
    v.extract    s3, v6, #3
    s.shli       s10, s8, #32
    s.add        s8, s5, s7
    v.extract    s5, v20, #4
    v.insert     v4, s4, #1
    v.extract    s4, v8, #4
    v.insert     v5, s2, #1
    s.or         s2, s6, s9
    s.or         s6, s3, s10
    s.lshri      s3, s8, #32
    v.extract    s7, v19, #4
    s.shli       s9, s5, #32
    v.extract    s5, v6, #4
    s.shli       s10, s4, #32
    s.add        s4, s2, s6
    v.extract    s2, v20, #5
    v.insert     v4, s8, #2
    v.extract    s6, v8, #5
    v.insert     v5, s3, #2
    s.or         s3, s7, s9
    s.or         s7, s5, s10
    s.lshri      s5, s4, #32
    v.extract    s8, v19, #5
    s.shli       s9, s2, #32
    v.extract    s2, v6, #5
    s.shli       s10, s6, #32
    s.add        s6, s3, s7
    v.extract    s3, v20, #6
    v.insert     v4, s4, #3
    v.extract    s4, v8, #6
    v.insert     v5, s5, #3
    s.or         s5, s8, s9
    s.or         s7, s2, s10
    s.lshri      s2, s6, #32
    v.extract    s8, v19, #6
    s.shli       s9, s3, #32
    v.extract    s3, v6, #6
    s.shli       s10, s4, #32
    s.add        s4, s5, s7
    v.extract    s5, v20, #7
    v.insert     v4, s6, #4
    v.extract    s6, v8, #7
    v.insert     v5, s2, #4
    v.extract    s2, v20, #0
    s.or         s7, s8, s9
    v.extract    s8, v10, #0
    s.or         s9, s3, s10
    s.lshri      s3, s4, #32
    s.shli       s10, s5, #32
    s.shli       s5, s6, #32
    s.shli       s6, s2, #32
    s.shli       s2, s8, #32
    s.add        s8, s7, s9
    v.extract    s7, v19, #7
    v.insert     v4, s4, #5
    v.extract    s4, v6, #7
    v.insert     v5, s3, #5
    v.extract    s3, v19, #0
    s.or         s9, s7, s10
    v.extract    s7, v9, #0
    s.or         s10, s4, s5
    v.extract    s4, v20, #1
    s.or         s5, s3, s6
    v.extract    s3, v10, #1
    s.or         s6, s7, s2
    s.lshri      s2, s8, #32
    s.shli       s7, s4, #32
    s.shli       s4, s3, #32
    s.add        s3, s9, s10
    v.extract    s9, v19, #1
    s.add        s10, s5, s6
    v.extract    s5, v9, #1
    v.insert     v4, s8, #6
    v.extract    s6, v20, #2
    v.insert     v5, s2, #6
    v.extract    s2, v10, #2
    v.movi       v6, #0
    v.movi       v8, #0
    s.or         s8, s9, s7
    s.or         s7, s5, s4
    s.lshri      s4, s3, #32
    s.lshri      s5, s10, #32
    s.shli       s9, s6, #32
    s.shli       s6, s2, #32
    s.add        s2, s8, s7
    v.extract    s7, v19, #2
    v.insert     v4, s3, #7
    v.extract    s3, v9, #2
    v.insert     v5, s4, #7
    v.extract    s4, v20, #3
    v.insert     v6, s10, #0
    v.extract    s8, v10, #3
    v.insert     v8, s5, #0
    s.or         s5, s7, s9
    s.or         s7, s3, s6
    s.lshri      s3, s2, #32
    v.extract    s6, v19, #3
    s.shli       s9, s4, #32
    v.extract    s4, v9, #3
    s.shli       s10, s8, #32
    s.add        s8, s5, s7
    v.extract    s5, v20, #4
    v.insert     v6, s2, #1
    v.extract    s2, v10, #4
    v.insert     v8, s3, #1
    s.or         s3, s6, s9
    s.or         s6, s4, s10
    s.lshri      s4, s8, #32
    v.extract    s7, v19, #4
    s.shli       s9, s5, #32
    v.extract    s5, v9, #4
    s.shli       s10, s2, #32
    s.add        s2, s3, s6
    v.extract    s3, v20, #5
    v.insert     v6, s8, #2
    v.extract    s6, v10, #5
    v.insert     v8, s4, #2
    s.or         s4, s7, s9
    s.or         s7, s5, s10
    s.lshri      s5, s2, #32
    v.extract    s8, v19, #5
    s.shli       s9, s3, #32
    v.extract    s3, v9, #5
    s.shli       s10, s6, #32
    s.add        s6, s4, s7
    v.extract    s4, v20, #6
    v.insert     v6, s2, #3
    v.extract    s2, v10, #6
    v.insert     v8, s5, #3
    s.or         s5, s8, s9
    s.or         s7, s3, s10
    s.lshri      s3, s6, #32
    v.extract    s8, v19, #6
    s.shli       s9, s4, #32
    v.extract    s4, v9, #6
    s.shli       s10, s2, #32
    s.add        s2, s5, s7
    v.extract    s5, v20, #7
    v.insert     v6, s6, #4
    v.extract    s6, v10, #7
    v.insert     v8, s3, #4
    v.extract    s3, v20, #0
    s.or         s7, s8, s9
    v.extract    s8, v15, #0
    s.or         s9, s4, s10
    s.lshri      s4, s2, #32
    s.shli       s10, s5, #32
    s.shli       s5, s6, #32
    s.shli       s6, s3, #32
    s.shli       s3, s8, #32
    s.add        s8, s7, s9
    v.extract    s7, v19, #7
    v.insert     v6, s2, #5
    v.extract    s2, v9, #7
    v.insert     v8, s4, #5
    v.extract    s4, v19, #0
    s.or         s9, s7, s10
    v.extract    s7, v7, #0
    s.or         s10, s2, s5
    v.extract    s2, v20, #1
    s.or         s5, s4, s6
    v.extract    s4, v15, #1
    s.or         s6, s7, s3
    s.lshri      s3, s8, #32
    s.shli       s7, s2, #32
    s.shli       s2, s4, #32
    s.add        s4, s9, s10
    v.extract    s9, v19, #1
    s.add        s10, s5, s6
    v.extract    s5, v7, #1
    v.insert     v6, s8, #6
    v.extract    s6, v20, #2
    v.insert     v8, s3, #6
    v.extract    s3, v15, #2
    v.movi       v9, #0
    v.movi       v10, #0
    s.or         s8, s9, s7
    s.or         s7, s5, s2
    s.lshri      s2, s4, #32
    s.lshri      s5, s10, #32
    s.shli       s9, s6, #32
    s.shli       s6, s3, #32
    s.add        s3, s8, s7
    v.extract    s7, v19, #2
    v.insert     v6, s4, #7
    v.extract    s4, v7, #2
    v.insert     v8, s2, #7
    v.extract    s2, v20, #3
    v.insert     v9, s10, #0
    v.extract    s8, v15, #3
    v.insert     v10, s5, #0
    s.or         s5, s7, s9
    s.or         s7, s4, s6
    s.lshri      s4, s3, #32
    v.extract    s6, v19, #3
    s.shli       s9, s2, #32
    v.extract    s2, v7, #3
    s.shli       s10, s8, #32
    s.add        s8, s5, s7
    v.extract    s5, v20, #4
    v.insert     v9, s3, #1
    v.extract    s3, v15, #4
    v.insert     v10, s4, #1
    s.or         s4, s6, s9
    s.or         s6, s2, s10
    s.lshri      s2, s8, #32
    v.extract    s7, v19, #4
    s.shli       s9, s5, #32
    v.extract    s5, v7, #4
    s.shli       s10, s3, #32
    s.add        s3, s4, s6
    v.extract    s4, v20, #5
    v.insert     v9, s8, #2
    v.extract    s6, v15, #5
    v.insert     v10, s2, #2
    s.or         s2, s7, s9
    s.or         s7, s5, s10
    s.lshri      s5, s3, #32
    v.extract    s8, v19, #5
    s.shli       s9, s4, #32
    v.extract    s4, v7, #5
    s.shli       s10, s6, #32
    s.add        s6, s2, s7
    v.extract    s2, v20, #6
    v.insert     v9, s3, #3
    v.extract    s3, v15, #6
    v.insert     v10, s5, #3
    v.extract    s5, v11, #0
    v.movi       v18, #1
    v.splat      v21, s5
    s.or         s7, s8, s9
    v.extract    s8, v12, #0
    v.cmp.ltu    p10, v11, v21
    v.splat      v22, s8
    v.sub        v23, v11, v21
    s.or         s9, s4, s10
    s.lshri      s4, s6, #32
    s.shli       s10, s2, #32
    s.shli       s2, s3, #32
    s.add        s3, s7, s9
    v.extract    s7, v19, #6
    v.insert     v9, s6, #4
    v.movi       v11, #0
    v.extract    s6, v7, #6
    v.insert     v10, s4, #4
    @p10 v.sel        v24, v18, v11
    v.sub        v11, v12, v22
    v.movi       v12, #31
    v.extract    s4, v20, #7
    v.sub        v18, v11, v24
    v.ashr       v11, v23, v12
    v.movi       v12, #1
    v.movi       v20, #0
    s.or         s9, s7, s10
    v.extract    s7, v15, #7
    s.or         s10, s6, s2
    s.movz       s2, #8
    s.shli       s6, s4, #32
    s.shli       s4, s7, #32
    v.cmp.ne     p10, v18, v11
    v.iota       v11                             // arange(0, VLEN)
    s.add        s7, s9, s10
    s.lshri      s9, s3, #32
    @p10 v.sel        v15, v12, v20
    v.insert     v9, s3, #5
    v.extract    s3, v19, #7
    v.splat      v12, s2
    v.extract    s2, v7, #7
    v.insert     v10, s9, #5
    s.or         s9, s3, s6
    s.or         s3, s2, s4
    s.lshri      s2, s7, #32
    v.cmp.lt     p10, v11, v12
    s.add        s4, s9, s3
    @p10 v.reduce.or  s3, v15
    s.movz       s6, #0
    v.insert     v9, s7, #6
    v.insert     v10, s2, #6
    s.lshri      s2, s4, #32
    s.shli       s7, s8, #32
    s.cmp.eq     s8, s3, s6
    v.insert     v9, s4, #7
    v.insert     v10, s2, #7
    s.or         s2, s5, s7
    br.nz        s8, narrow_ok_10
    trap         #677220
narrow_ok_10:
    v.movi       v7, #1
    v.movi       v11, #0
    v.cmp.ltu    p10, v13, v21
    v.sub        v12, v13, v21
    @p10 v.sel        v13, v7, v11
    v.sub        v7, v16, v22
    v.movi       v11, #31
    v.movi       v15, #1
    v.sub        v16, v7, v13
    v.ashr       v7, v12, v11
    v.movi       v11, #0
    s.movz       s3, #8
    v.cmp.ne     p10, v16, v7
    v.iota       v7                              // arange(0, VLEN)
    v.splat      v13, s3
    @p10 v.sel        v16, v15, v11
    s.movz       s3, #0
    v.cmp.lt     p10, v7, v13
    @p10 v.reduce.or  s4, v16
    s.cmp.eq     s5, s4, s3
    br.nz        s5, narrow_ok_11
    trap         #677220
narrow_ok_11:
    v.movi       v7, #1
    v.movi       v11, #0
    v.cmp.ltu    p10, v0, v21
    v.sub        v13, v0, v21
    @p10 v.sel        v0, v7, v11
    v.sub        v7, v1, v22
    v.movi       v1, #31
    v.movi       v11, #1
    v.sub        v15, v7, v0
    v.ashr       v0, v13, v1
    v.movi       v1, #0
    s.movz       s3, #8
    v.cmp.ne     p10, v15, v0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v7, s3
    @p10 v.sel        v15, v11, v1
    s.movz       s3, #0
    v.cmp.lt     p10, v0, v7
    @p10 v.reduce.or  s4, v15
    s.cmp.eq     s5, s4, s3
    br.nz        s5, narrow_ok_12
    trap         #677220
narrow_ok_12:
    v.movi       v0, #1
    v.movi       v1, #0
    v.cmp.ltu    p10, v14, v21
    v.sub        v7, v14, v21
    @p10 v.sel        v11, v0, v1
    v.sub        v0, v17, v22
    v.movi       v1, #31
    v.movi       v14, #1
    v.sub        v15, v0, v11
    v.ashr       v0, v7, v1
    v.movi       v1, #0
    s.movz       s3, #8
    v.cmp.ne     p10, v15, v0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v11, s3
    @p10 v.sel        v15, v14, v1
    s.movz       s3, #0
    v.cmp.lt     p10, v0, v11
    @p10 v.reduce.or  s4, v15
    s.cmp.eq     s5, s4, s3
    br.nz        s5, narrow_ok_13
    trap         #677220
narrow_ok_13:
    v.movi       v0, #1
    v.movi       v1, #0
    v.cmp.ltu    p10, v2, v21
    v.sub        v11, v2, v21
    @p10 v.sel        v2, v0, v1
    v.sub        v0, v3, v22
    v.movi       v1, #31
    v.movi       v3, #1
    v.sub        v14, v0, v2
    v.ashr       v0, v11, v1
    v.movi       v1, #0
    s.movz       s3, #8
    v.cmp.ne     p10, v14, v0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v2, s3
    @p10 v.sel        v14, v3, v1
    s.movz       s3, #0
    v.cmp.lt     p10, v0, v2
    @p10 v.reduce.or  s4, v14
    s.cmp.eq     s5, s4, s3
    br.nz        s5, narrow_ok_14
    trap         #677220
narrow_ok_14:
    v.movi       v0, #1
    v.movi       v1, #0
    v.cmp.ltu    p10, v4, v21
    v.sub        v2, v4, v21
    @p10 v.sel        v3, v0, v1
    v.sub        v0, v5, v22
    v.movi       v1, #31
    v.movi       v4, #1
    v.sub        v5, v0, v3
    v.ashr       v0, v2, v1
    v.movi       v1, #0
    s.movz       s3, #8
    v.cmp.ne     p10, v5, v0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v3, s3
    @p10 v.sel        v5, v4, v1
    s.movz       s3, #0
    v.cmp.lt     p10, v0, v3
    @p10 v.reduce.or  s4, v5
    s.cmp.eq     s5, s4, s3
    br.nz        s5, narrow_ok_15
    trap         #677220
narrow_ok_15:
    v.movi       v0, #1
    v.movi       v1, #0
    v.cmp.ltu    p10, v6, v21
    v.sub        v3, v6, v21
    @p10 v.sel        v4, v0, v1
    v.sub        v0, v8, v22
    v.movi       v1, #31
    v.movi       v5, #1
    v.sub        v6, v0, v4
    v.ashr       v0, v3, v1
    v.movi       v1, #0
    s.movz       s3, #8
    v.cmp.ne     p10, v6, v0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v4, s3
    @p10 v.sel        v6, v5, v1
    s.movz       s3, #0
    v.cmp.lt     p10, v0, v4
    @p10 v.reduce.or  s4, v6
    s.cmp.eq     s5, s4, s3
    br.nz        s5, narrow_ok_16
    trap         #677220
narrow_ok_16:
    v.movi       v0, #1
    v.movi       v1, #0
    v.cmp.ltu    p10, v9, v21
    v.sub        v4, v9, v21
    @p10 v.sel        v5, v0, v1
    v.sub        v0, v10, v22
    v.movi       v1, #31
    v.movi       v6, #1
    v.sub        v8, v0, v5
    v.ashr       v0, v4, v1
    v.movi       v1, #0
    s.movz       s3, #8
    v.cmp.ne     p10, v8, v0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v5, s3
    @p10 v.sel        v8, v6, v1
    s.movz       s3, #0
    v.cmp.lt     p10, v0, v5
    @p10 v.reduce.or  s4, v8
    s.cmp.eq     s5, s4, s3
    br.nz        s5, narrow_ok_17
    trap         #677220
narrow_ok_17:
    s.addi       s3, s1, #0
    v.movi       v0, #1
    v.ld.w       v1, [s3, #0]
    v.movi       v5, #0
    v.movi       v6, #0
    s.movz       s3, #8
    @p1 v.sel        v8, v0, v5
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v5, s3
    v.extract    s3, v8, #0
    s.shli       s4, s2, #2
    v.splat      v8, s3
    v.cmp.lt     p1, v0, v5
    s.add        s2, s25, s4                     // a 64-bit tile origin
    v.cmp.ne     p10, v8, v6
    p.and        p11, p9, p10
    s.addi       s3, s1, #64
    p.and        p10, p1, p11
    v.movi       v0, #1
    v.movi       v5, #0
    vf.cvt.s32.f32 v6, v1
    v.movi       v1, #0
    @p2 v.sel        v8, v0, v5
    s.movz       s4, #8
    v.iota       v0                              // arange(0, VLEN)
    @p10 v.st.scatter.w [s2, v23], v6
    v.extract    s5, v8, #0
    v.splat      v5, s4
    v.splat      v6, s5
    s.addi       s4, s1, #128
    v.cmp.lt     p1, v0, v5
    v.cmp.ne     p2, v6, v1
    p.and        p10, p9, p2
    v.movi       v0, #1
    p.and        p2, p1, p10
    v.movi       v1, #0
    v.movi       v5, #0
    s.movz       s5, #8
    @p3 v.sel        v6, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s5
    v.extract    s5, v6, #0
    s.addi       s6, s1, #192
    v.ld.w       v6, [s3, #0]
    v.splat      v8, s5
    v.cmp.lt     p1, v0, v1
    v.movi       v0, #1
    v.cmp.ne     p3, v8, v5
    p.and        p10, p9, p3
    v.movi       v1, #0
    p.and        p3, p1, p10
    v.movi       v5, #0
    @p4 v.sel        v8, v0, v1
    s.movz       s3, #8
    v.iota       v0                              // arange(0, VLEN)
    v.extract    s5, v8, #0
    v.splat      v1, s3
    v.splat      v8, s5
    v.cmp.lt     p1, v0, v1
    v.cmp.ne     p4, v8, v5
    vf.cvt.s32.f32 v0, v6
    p.and        p10, p9, p4
    s.addi       s3, s1, #256
    p.and        p4, p1, p10
    v.movi       v1, #1
    @p2 v.st.scatter.w [s2, v12], v0
    v.movi       v0, #0
    v.movi       v5, #0
    s.movz       s5, #8
    @p5 v.sel        v6, v1, v0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s5
    v.extract    s5, v6, #0
    v.splat      v6, s5
    v.cmp.lt     p1, v0, v1
    v.cmp.ne     p2, v6, v5
    p.and        p5, p9, p2
    v.ld.w       v0, [s4, #0]
    p.and        p2, p1, p5
    vf.cvt.s32.f32 v1, v0
    s.addi       s4, s1, #320
    v.movi       v0, #1
    v.movi       v5, #0
    v.movi       v6, #0
    @p3 v.st.scatter.w [s2, v13], v1
    @p6 v.sel        v1, v0, v5
    s.movz       s5, #8
    v.iota       v0                              // arange(0, VLEN)
    v.extract    s7, v1, #0
    v.splat      v1, s5
    v.splat      v5, s7
    v.cmp.lt     p1, v0, v1
    v.cmp.ne     p3, v5, v6
    p.and        p5, p9, p3
    v.ld.w       v0, [s6, #0]
    p.and        p3, p1, p5
    vf.cvt.s32.f32 v1, v0
    s.addi       s5, s1, #384
    v.movi       v0, #1
    v.movi       v5, #0
    v.movi       v6, #0
    @p4 v.st.scatter.w [s2, v7], v1
    @p7 v.sel        v1, v0, v5
    s.movz       s6, #8
    v.iota       v0                              // arange(0, VLEN)
    v.extract    s7, v1, #0
    v.splat      v1, s6
    v.splat      v5, s7
    v.cmp.lt     p1, v0, v1
    v.cmp.ne     p4, v5, v6
    p.and        p5, p9, p4
    v.ld.w       v0, [s3, #0]
    p.and        p4, p1, p5
    vf.cvt.s32.f32 v1, v0
    s.addi       s3, s1, #448
    v.movi       v0, #1
    v.movi       v5, #0
    v.movi       v6, #0
    @p2 v.st.scatter.w [s2, v11], v1
    @p8 v.sel        v1, v0, v5
    s.movz       s1, #8
    v.iota       v0                              // arange(0, VLEN)
    v.extract    s6, v1, #0
    v.splat      v1, s1
    v.splat      v5, s6
    v.cmp.lt     p1, v0, v1
    v.cmp.ne     p2, v5, v6
    p.and        p5, p9, p2
    v.ld.w       v0, [s4, #0]
    p.and        p2, p1, p5
    vf.cvt.s32.f32 v1, v0
    @p3 v.st.scatter.w [s2, v2], v1
    v.ld.w       v0, [s5, #0]
    vf.cvt.s32.f32 v1, v0
    @p4 v.st.scatter.w [s2, v3], v1
    v.ld.w       v0, [s3, #0]
    vf.cvt.s32.f32 v1, v0
    @p2 v.st.scatter.w [s2, v4], v1
__rctx_next:
    exit
