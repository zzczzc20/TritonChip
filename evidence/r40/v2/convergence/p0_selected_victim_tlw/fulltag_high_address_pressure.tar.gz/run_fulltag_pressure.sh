source ~/tc_env/env.sh
cd /home/zhongchun/r40_hit_owner_v3_20261017
python3 run_fulltag_pressure.py > fulltag_pressure.log 2>&1
echo $? > fulltag_pressure.exit
