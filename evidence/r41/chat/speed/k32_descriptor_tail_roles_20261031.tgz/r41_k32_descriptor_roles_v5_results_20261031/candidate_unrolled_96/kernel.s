    // R39-12: role0 on even contexts, role1 on odd ones (ROLE_ID mod 2)
    s.rdspecial  s61, role_id
    s.andi       s61, s61, #1
    br.nz        s61, __tnca_role1
    w.def        w0, #56, #8                     // v56..v63
    w.def        w1, #48, #8                     // v48..v55
    w.def        w2, #40, #8                     // v40..v47
    w.def        w3, #32, #8                     // v32..v39
    .li       s1, #196608
    td.load      d0, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    .li       s1, #196864
    td.load      d1, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    // role 0: partition P (load/transfer). 3 k step(s) over a 2-slot RF channel.
    // k step 0: slot 0, generation 1
    mb.arm       s1, b0, #0, #2                  // 0 arrival(s), 2 operation(s)
    .li       s2, #0
    .li       s3, #0
    s.mov        s4, s2                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s5, s3                          // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w0, d0, s4, s1
    .li       s2, #0
    .li       s3, #0
    s.mov        s4, s2                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s5, s3                          // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w2, d1, s4, s1
    // k step 1: slot 1, generation 1
    mb.arm       s2, b1, #0, #2                  // 0 arrival(s), 2 operation(s)
    .li       s3, #0
    .li       s4, #32
    s.mov        s5, s3                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s6, s4                          // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w1, d0, s5, s2
    .li       s3, #32
    .li       s4, #0
    s.mov        s5, s3                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s6, s4                          // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w3, d1, s5, s2
    // k step 2: slot 0, generation 2
    .li       s3, #65538          // b2 generation 1 (ISA sec 9A.2)
    mb.wait      s3
    mb.arm       s4, b0, #0, #2                  // 0 arrival(s), 2 operation(s)
    .li       s5, #0
    .li       s6, #64
    s.mov        s7, s5                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s8, s6                          // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w0, d0, s7, s4
    .li       s5, #64
    .li       s6, #0
    s.mov        s7, s5                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s8, s6                          // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w2, d1, s7, s4
    exit
__tnca_role1:
    // role 1: partitions M (matrix, and the epilogue merged in because this target has 4 Role Contexts -- sec 7.6)
    m.zero       a0
    // k step 0: slot 0, generation 1
    .li       s1, #65536          // b0 generation 1 (ISA sec 9A.2)
    mb.wait      s1
    mb.arm       s2, b4, #0, #1                  // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a0, v56, v40, s2
    mb.wait      s2
    mb.arm       s3, b2, #1, #0                  // 1 arrival(s), 0 operation(s)
    mb.arrive    b2
    // k step 1: slot 1, generation 1
    .li       s4, #65537          // b1 generation 1 (ISA sec 9A.2)
    mb.wait      s4
    mb.arm       s5, b4, #0, #1                  // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a0, v48, v32, s5
    mb.wait      s5
    mb.arm       s6, b3, #1, #0                  // 1 arrival(s), 0 operation(s)
    mb.arrive    b3
    // k step 2: slot 0, generation 2
    .li       s7, #131072          // b0 generation 2 (ISA sec 9A.2)
    mb.wait      s7
    mb.arm       s8, b4, #0, #1                  // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a0, v56, v40, s8
    mb.wait      s8
    mb.arm       s9, b2, #1, #0                  // 1 arrival(s), 0 operation(s)
    mb.arrive    b2
    // epilogue: the accumulator leaves a row at a time
    .li       s10, #393216
    .li       s11, #0
    a.vread      v0, a0, s11
    v.st.w       [s10, #0], v0
    .li       s11, #1
    a.vread      v0, a0, s11
    s.addi       s11, s10, #64
    v.st.w       [s11, #0], v0
    .li       s11, #2
    a.vread      v0, a0, s11
    s.addi       s11, s10, #128
    v.st.w       [s11, #0], v0
    .li       s11, #3
    a.vread      v0, a0, s11
    s.addi       s11, s10, #192
    v.st.w       [s11, #0], v0
    .li       s11, #4
    a.vread      v0, a0, s11
    s.addi       s11, s10, #256
    v.st.w       [s11, #0], v0
    .li       s11, #5
    a.vread      v0, a0, s11
    s.addi       s11, s10, #320
    v.st.w       [s11, #0], v0
    .li       s11, #6
    a.vread      v0, a0, s11
    s.addi       s11, s10, #384
    v.st.w       [s11, #0], v0
    .li       s11, #7
    a.vread      v0, a0, s11
    s.addi       s11, s10, #448
    v.st.w       [s11, #0], v0
    .li       s11, #8
    a.vread      v0, a0, s11
    s.addi       s11, s10, #512
    v.st.w       [s11, #0], v0
    .li       s11, #9
    a.vread      v0, a0, s11
    s.addi       s11, s10, #576
    v.st.w       [s11, #0], v0
    .li       s11, #10
    a.vread      v0, a0, s11
    s.addi       s11, s10, #640
    v.st.w       [s11, #0], v0
    .li       s11, #11
    a.vread      v0, a0, s11
    s.addi       s11, s10, #704
    v.st.w       [s11, #0], v0
    .li       s11, #12
    a.vread      v0, a0, s11
    s.addi       s11, s10, #768
    v.st.w       [s11, #0], v0
    .li       s11, #13
    a.vread      v0, a0, s11
    s.addi       s11, s10, #832
    v.st.w       [s11, #0], v0
    .li       s11, #14
    a.vread      v0, a0, s11
    s.addi       s11, s10, #896
    v.st.w       [s11, #0], v0
    .li       s11, #15
    a.vread      v0, a0, s11
    s.addi       s11, s10, #960
    v.st.w       [s11, #0], v0
    exit
