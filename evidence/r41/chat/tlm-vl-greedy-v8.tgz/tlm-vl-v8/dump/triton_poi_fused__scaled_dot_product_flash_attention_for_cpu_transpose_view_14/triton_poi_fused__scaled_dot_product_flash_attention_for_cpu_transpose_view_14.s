    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.add        v2, v1, v0
    v.movi       v0, #22528
    v.cmp.lt     p1, v2, v0
    v.movi       v0, #2048
    v.movi       v1, #0
    v.cmp.lt     p2, v2, v1
    v.cmp.lt     p3, v0, v1
    v.sub        v3, v1, v2
    @p2 v.sel        v4, v3, v2
    v.sub        v3, v1, v0
    @p3 v.sel        v5, v3, v0
    v.movi       v3, #2047
    v.and        v5, v4, v3
    v.sub        v3, v1, v5
    @p2 v.sel        v1, v3, v5
    v.movi       v3, #0
    v.cmp.lt     p2, v2, v3
    v.cmp.lt     p3, v0, v3
    v.sub        v4, v3, v2
    @p2 v.sel        v5, v4, v2
    v.sub        v2, v3, v0
    @p3 v.sel        v4, v2, v0
    v.movi       v0, #11
    v.lshr       v2, v5, v0
    v.sub        v0, v3, v2
    @p2 v.sel        v3, v0, v2
    v.movi       v0, #128
    v.mul        v2, v3, v0
    v.movi       v3, #0
    v.cmp.lt     p2, v1, v3
    v.cmp.lt     p3, v0, v3
    v.sub        v4, v3, v1
    @p2 v.sel        v5, v4, v1
    v.sub        v4, v3, v0
    @p3 v.sel        v6, v4, v0
    v.movi       v4, #7
    v.lshr       v6, v5, v4
    v.sub        v4, v3, v6
    @p2 v.sel        v3, v4, v6
    v.movi       v4, #1408
    v.mul        v5, v3, v4
    v.add        v3, v2, v5
    v.movi       v2, #0
    v.cmp.lt     p2, v1, v2
    v.cmp.lt     p3, v0, v2
    v.sub        v4, v2, v1
    @p2 v.sel        v5, v4, v1
    v.sub        v1, v2, v0
    @p3 v.sel        v4, v1, v0
    v.movi       v0, #127
    v.and        v1, v5, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v2, v0, v1
    v.add        v0, v3, v2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    vf.cvt.f32.bf16 v0, v1
    s.shli       s2, s1, #1                      // element offset -> bytes (x2)
    s.add        s1, s3, s2                      // &out_ptr0[...]
    @p1 v.st.h       [s1, #0], v0
__rctx_next:
    exit
