    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    s.rdspecial  s2, arg_base
    v.add        v3, v1, v0
    v.movi       v0, #6
    s.ld.d       s3, [s2, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    v.movi       v4, #128
    @p1 v.sel        v5, v1, v3
    v.movi       v1, #0
    v.cmp.lt     p2, v3, v4
    v.lshr       v4, v5, v0
    v.sub        v0, v1, v3
    v.cmp.lt     p3, v3, v1
    v.sub        v5, v2, v4
    @p3 v.sel        v6, v0, v3
    v.movi       v0, #63
    @p1 v.sel        v7, v5, v4
    s.ld.d       s4, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.and        v4, v6, v0
    v.movi       v0, #256
    v.movi       v5, #0
    v.sub        v6, v1, v4
    v.mul        v8, v7, v0
    v.sub        v0, v5, v3
    @p3 v.sel        v9, v6, v4
    v.cmp.lt     p1, v3, v5
    @p1 v.sel        v4, v0, v3
    v.add        v0, v9, v8
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v3, [s3, v7]               // index is in elements (ISA sec 9.1)
    v.movi       v6, #64
    v.movi       v7, #32
    v.sub        v8, v1, v6
    v.sub        v10, v2, v6
    v.cmp.lt     p3, v6, v1
    v.cmp.lt     p4, v6, v2
    @p3 v.sel        v1, v8, v6
    v.cmp.lt     p3, v7, v5
    @p4 v.sel        v1, v10, v6
    s.ld.d       s3, [s2, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.sub        v1, v5, v7
    s.ld.d       s5, [s2, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s6, [s2, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    v.movi       v2, #31
    @p3 v.sel        v6, v1, v7
    s.ld.d       s7, [s2, #40]                   // in_ptr5: device_ptr64 at arg_base+40
    v.and        v1, v4, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v2, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v4, [s3, v9]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v6, v2
    vf.cvt.bf16.f32 v2, v4
    s.ld.d       s3, [s2, #48]                   // out_ptr0: device_ptr64 at arg_base+48
    .li       s2, #1132462080
    v.splat      v4, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1065353216
    v.splat      v7, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #897988541
    v.splat      v8, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v9, v4                          // ISA 8.8: <= 2**-22 relative
    .li       s2, #1077936128
    v.splat      v10, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #3204448256
    v.splat      v11, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.sub        v12, v5, v1
    s.shli       s2, s1, #1                      // element offset -> bytes (x2)
    .li       s1, #1065353216
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v13, v12, v1
    s.add        s1, s5, s2                      // &in_ptr4[...]
    vf.add       v1, v2, v5
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s1, #0]
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s6, v13]              // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v12, v2
    vf.fms       v2, v4, v9, v7
    vf.fms       v4, v9, v2, v9
    vf.neg       v2, v4                          // Newton step: r0*(2 - x*r0)
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s7, v13]              // index is in elements (ISA sec 9.1)
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v7, v2, v9
    vf.mul       v2, v3, v7                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v3, v2, v8
    v.rsqrt.approx v2, v3                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v7, v12, v4
    vf.mul       v4, v2, v2
    vf.mul       v8, v2, v11
    vf.fms       v9, v3, v4, v10
    vf.mul       v3, v8, v9                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v4, v3, v2
    vf.mul       v2, v6, v4
    vf.mul       v3, v2, v1
    vf.mul       v1, v3, v5
    vf.add       v2, v1, v7
    vf.cvt.f32.bf16 v1, v2
    @p2 v.st.scatter.h [s3, v0], v1
__rctx_next:
    exit
