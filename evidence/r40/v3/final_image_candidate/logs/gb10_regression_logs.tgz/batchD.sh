#!/bin/sh
# Batch D on GB10: native multicore lanes of the CI MMIO matrix (board top, 3 cores).
. ~/tc_env/env.sh
cd ~/tc_hw_final
L=~/tc_hw_logs
lane() { name=$1; shift; ( "$@" ; echo "EXIT=$?" ) > $L/D_$name.log 2>&1; }
( lane native_ports nice -n 10 $TORCH_PYTHON tools/r40/native_memory_ports_tests.py --backend fpga-multicore-sim --cores 3 --ports 3 --pipeline 2 --board-top ) &
( lane native_features nice -n 10 $TORCH_PYTHON tools/r40/native_multicore_features.py --backend fpga-multicore-sim --cores 3 --pipeline 2 --board-top ) &
( lane native_pair nice -n 10 $TORCH_PYTHON tools/r40/native_multicore_features.py --backend fpga-multicore-sim --cores 3 --pair --pipeline 2 --board-top ) &
wait
echo BATCH_D_DONE > $L/D_done.log
