#!/bin/bash
# slot.sh [--min-gb N] LOG -- CMD... : at most two Vivado jobs at once on this host (flock slots).
set -u
min=8
if [ "${1:-}" = "--min-gb" ]; then min=$2; shift 2; fi
log=${1:?log}; shift; [ "${1:-}" = "--" ] && shift
mkdir -p "$(dirname "$log")"
while true; do
  for s in 0 1; do
    exec {fd}>"$HOME/.r41s2int_slot.$s"
    if flock -n $fd; then
      while [ "$(free -g | awk '/^Mem:/{print $7}')" -lt "$min" ]; do sleep 60; done
      echo "$(date -u +%FT%TZ) slot $s start (avail $(free -g | awk '/^Mem:/{print $7}') GB): $*" >> "$log"
      set +u; source $HOME/Xilinx/Vivado/2023.2/settings64.sh >/dev/null 2>&1; set -u
      nice -n 10 "$@" >> "$log" 2>&1; rc=$?
      echo "$(date -u +%FT%TZ) slot $s end exit $rc" >> "$log"
      exec {fd}>&-; exit $rc
    fi
    exec {fd}>&-
  done
  sleep 30
done
