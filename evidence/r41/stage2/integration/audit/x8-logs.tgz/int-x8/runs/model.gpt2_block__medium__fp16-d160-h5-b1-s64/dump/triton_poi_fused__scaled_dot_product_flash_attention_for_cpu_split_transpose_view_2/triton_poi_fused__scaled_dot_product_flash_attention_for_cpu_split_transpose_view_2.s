    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #5
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    @p1 v.sel        v4, v1, v3
    v.movi       v1, #0
    v.lshr       v5, v4, v0
    v.movi       v0, #0
    v.sub        v4, v2, v5
    v.movi       v6, #0
    @p1 v.sel        v7, v4, v5
    v.cmp.lt     p1, v3, v1
    v.sub        v4, v0, v3
    v.sub        v5, v6, v7
    v.cmp.lt     p2, v3, v0
    v.cmp.lt     p3, v7, v6
    @p2 v.sel        v8, v4, v3
    v.movi       v4, #31
    @p3 v.sel        v9, v5, v7
    v.movi       v5, #63
    v.and        v7, v8, v4
    v.and        v4, v9, v5
    v.movi       v5, #32
    v.sub        v8, v0, v7
    v.sub        v9, v6, v4
    @p2 v.sel        v10, v8, v7
    @p3 v.sel        v7, v9, v4
    s.rdspecial  s2, arg_base
    v.sub        v4, v1, v3
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    @p1 v.sel        v8, v4, v3
    v.movi       v4, #10240
    s.ld.d       s4, [s2, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.movi       v9, #11
    v.cmp.lt     p2, v3, v4
    v.lshr       v3, v8, v9
    v.movi       v4, #480
    v.sub        v8, v1, v3
    v.mul        v9, v7, v4
    @p1 v.sel        v4, v8, v3
    v.movi       v3, #64
    v.mul        v7, v4, v5
    v.movi       v4, #2048
    v.add        v8, v10, v7
    v.sub        v7, v0, v5
    v.sub        v10, v2, v5
    v.cmp.lt     p1, v5, v0
    v.add        v0, v8, v9
    .li       s2, #1054295293
    v.splat      v8, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v9, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.sub        v0, v6, v3
    v.cmp.lt     p3, v5, v2
    v.sub        v2, v1, v4
    v.cmp.lt     p4, v3, v6
    @p1 v.sel        v6, v7, v5
    vf.cvt.f16.f32 v6, v9
    s.shli       s2, s1, #2                      // element offset -> bytes (x4)
    v.cmp.lt     p1, v4, v1
    s.add        s1, s4, s2                      // &out_ptr0[...]
    vf.mul       v1, v6, v8
    @p3 v.sel        v6, v10, v5
    @p4 v.sel        v5, v0, v3
    @p1 v.sel        v0, v2, v4
    @p2 v.st.w       [s1, #0], v1
__rctx_next:
    exit
