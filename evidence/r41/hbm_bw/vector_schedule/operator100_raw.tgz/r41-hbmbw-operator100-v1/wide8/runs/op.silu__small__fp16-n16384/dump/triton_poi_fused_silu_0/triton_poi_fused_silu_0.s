    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.movz       s2, #16
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s5, #32
    s.movz       s6, #48
    s.movz       s7, #64
    s.movz       s8, #80
    s.movz       s9, #96
    s.movz       s10, #112
    s.shli       s11, s4, #7                     // x128 as a shift
    v.iota       v0                              // arange(0, VLEN)
    s.add        s4, s2, s11
    s.add        s2, s5, s11
    s.add        s5, s6, s11
    s.add        s6, s7, s11
    s.ld.d       s7, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.add        s1, s8, s11
    s.add        s8, s9, s11
    s.add        s9, s10, s11
    s.shli       s10, s11, #1                    // element offset -> bytes (x2)
    v.movi       v1, #16
    s.add        s12, s3, s10                    // &in_ptr0[...]
    v.iota       v2                              // arange(0, VLEN)
    v.movi       v3, #32
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v5, #48
    v.ld.h       v6, [s12, #0]
    v.iota       v7                              // arange(0, VLEN)
    v.movi       v8, #64
    v.iota       v9                              // arange(0, VLEN)
    v.movi       v10, #80
    v.iota       v11                             // arange(0, VLEN)
    v.movi       v12, #96
    v.iota       v13                             // arange(0, VLEN)
    v.movi       v14, #112
    v.iota       v15                             // arange(0, VLEN)
    s.shli       s12, s4, #1                     // element offset -> bytes (x2)
    v.add        v16, v0, v1
    s.shli       s4, s2, #1                      // element offset -> bytes (x2)
    s.add        s2, s3, s12                     // &in_ptr0[...]
    s.add        s13, s3, s4                     // &in_ptr0[...]
    v.ld.h       v0, [s2, #0]
    v.add        v1, v2, v3
    s.shli       s2, s5, #1                      // element offset -> bytes (x2)
    v.add        v2, v4, v5
    s.shli       s5, s6, #1                      // element offset -> bytes (x2)
    s.add        s6, s3, s2                      // &in_ptr0[...]
    s.add        s14, s3, s5                     // &in_ptr0[...]
    v.add        v3, v7, v8
    s.shli       s15, s1, #1                     // element offset -> bytes (x2)
    v.add        v4, v9, v10
    s.shli       s1, s8, #1                      // element offset -> bytes (x2)
    s.add        s8, s3, s15                     // &in_ptr0[...]
    v.add        v5, v11, v12
    s.shli       s16, s9, #1                     // element offset -> bytes (x2)
    v.ld.h       v7, [s13, #0]
    s.add        s9, s3, s1                      // &in_ptr0[...]
    s.add        s13, s3, s16                    // &in_ptr0[...]
    v.add        v8, v13, v14
    vf.cvt.f16.f32 v9, v6
    v.splat      v6, s11
    vf.cvt.f16.f32 v10, v0
    v.splat      v0, s11
    v.splat      v11, s11
    v.splat      v12, s11
    v.splat      v13, s11
    v.splat      v14, s11
    v.splat      v17, s11
    v.splat      v18, s11
    v.ld.h       v19, [s6, #0]
    vf.cvt.f16.f32 v20, v7
    vf.neg       v7, v9
    v.add        v21, v6, v15
    vf.neg       v6, v10
    v.add        v15, v0, v16
    vf.neg       v0, v20
    v.add        v15, v11, v1
    v.add        v1, v12, v2
    v.add        v1, v13, v3
    .li       s3, #1069066811
    v.splat      v1, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v2, v14, v4
    v.add        v2, v17, v5
    vf.mul       v2, v7, v1
    v.ld.h       v3, [s14, #0]
    vf.cvt.f16.f32 v4, v19
    .li       s3, #1060205080
    v.splat      v5, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v11, v18, v8
    vf.mul       v8, v6, v1
    vf.mul       v11, v0, v1
    vf.neg       v12, v4
    v.exp2.approx v13, v2                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v14, v7, v1, v2                 // the exact rounding error of x*log2(e)
    v.exp2.approx v2, v8                         // ISA 8.8: <= 2**-22 relative
    v.exp2.approx v7, v11                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v15, v12, v1
    vf.fms       v16, v6, v1, v8                 // the exact rounding error of x*log2(e)
    vf.fms       v6, v0, v1, v11                 // the exact rounding error of x*log2(e)
    v.ld.h       v0, [s8, #0]
    vf.cvt.f16.f32 v8, v3
    v.exp2.approx v3, v15                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v11, v12, v1, v15               // the exact rounding error of x*log2(e)
    vf.mul       v12, v14, v5
    vf.mul       v14, v16, v5
    vf.neg       v15, v8
    vf.mul       v16, v6, v5
    vf.mul       v6, v11, v5
    v.ld.h       v11, [s9, #0]
    vf.cvt.f16.f32 v17, v0
    vf.mul       v0, v15, v1
    vf.neg       v18, v17
    vf.fma       v19, v13, v12, v13              // 2**t * 2**d
    vf.fma       v12, v2, v14, v2                // 2**t * 2**d
    vf.fma       v14, v7, v16, v7                // 2**t * 2**d
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v16, v19, v13
    v.ld.h       v13, [s13, #0]
    vf.cvt.f16.f32 v19, v11
    vf.mul       v11, v18, v1
    v.exp2.approx v21, v0                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v22, v15, v1, v0                // the exact rounding error of x*log2(e)
    vf.fma       v0, v3, v6, v3                  // 2**t * 2**d
    vf.neg       v6, v19
    vf.fms       v15, v18, v1, v11               // the exact rounding error of x*log2(e)
    vf.cmp.o     p1, v12, v12
    vf.mul       v18, v22, v5
    vf.cmp.o     p2, v14, v14
    @p1 v.sel        v22, v12, v2
    vf.cmp.o     p1, v0, v0
    @p2 v.sel        v2, v14, v7
    vf.cvt.f16.f32 v7, v13
    vf.mul       v12, v6, v1
    v.exp2.approx v13, v11                       // ISA 8.8: <= 2**-22 relative
    vf.mul       v11, v15, v5
    @p1 v.sel        v14, v0, v3
    vf.neg       v0, v7
    v.exp2.approx v3, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v6, v1, v12                // the exact rounding error of x*log2(e)
    .li       s3, #1065353216
    v.splat      v6, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s3, #1065353216
    v.splat      v12, s3                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v23, v16, v6
    vf.mul       v6, v0, v1
    vf.mul       v16, v15, v5
    vf.add       v15, v22, v12
    .li       s3, #1065353216
    v.splat      v12, s3                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v22, v0, v1, v6                 // the exact rounding error of x*log2(e)
    v.exp2.approx v0, v6                         // ISA 8.8: <= 2**-22 relative
    vf.fma       v1, v21, v18, v21               // 2**t * 2**d
    .li       s3, #1065353216
    v.splat      v6, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v18, v2, v12
    vf.mul       v2, v22, v5
    .li       s3, #1065353216
    v.splat      v5, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v12, v1, v21
    .li       s3, #1065353216
    v.splat      v1, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s3, #1065353216
    v.splat      v21, s3                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v22, v14, v6
    .li       s3, #1065353216
    v.splat      v6, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v14, v13, v11, v13              // 2**t * 2**d
    vf.add       v11, v12, v5
    v.rcp.approx v5, v23                         // ISA 8.8: <= 2**-22 relative
    vf.fma       v12, v3, v16, v3                // 2**t * 2**d
    vf.cmp.o     p1, v14, v14
    @p1 v.sel        v16, v14, v13
    v.rcp.approx v13, v15                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v12, v12
    @p1 v.sel        v14, v12, v3
    vf.add       v3, v16, v1
    v.rcp.approx v1, v18                         // ISA 8.8: <= 2**-22 relative
    vf.add       v12, v14, v21
    v.rcp.approx v14, v22                        // ISA 8.8: <= 2**-22 relative
    .li       s3, #1065353216
    v.splat      v16, s3                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v21, v0, v2, v0                 // 2**t * 2**d
    vf.cmp.o     p1, v21, v21
    @p1 v.sel        v2, v21, v0
    v.rcp.approx v0, v11                         // ISA 8.8: <= 2**-22 relative
    vf.add       v21, v2, v6
    v.rcp.approx v2, v3                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v23, v5, v16
    vf.fms       v23, v15, v13, v16
    vf.fms       v15, v5, v6, v5
    vf.fms       v6, v18, v1, v16
    vf.fms       v18, v13, v23, v13
    vf.fms       v23, v22, v14, v16
    vf.neg       v22, v15                        // Newton step: r0*(2 - x*r0)
    vf.fms       v15, v1, v6, v1
    vf.neg       v6, v18                         // Newton step: r0*(2 - x*r0)
    vf.fms       v18, v14, v23, v14
    vf.cmp.o     p1, v22, v22
    @p1 v.sel        v23, v22, v5
    v.rcp.approx v5, v12                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v22, v11, v0, v16
    vf.neg       v11, v15                        // Newton step: r0*(2 - x*r0)
    vf.neg       v15, v18                        // Newton step: r0*(2 - x*r0)
    vf.fms       v18, v3, v2, v16
    vf.cmp.o     p1, v6, v6
    vf.fms       v3, v0, v22, v0
    vf.cmp.o     p2, v11, v11
    @p1 v.sel        v22, v6, v13
    v.rcp.approx v6, v21                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v13, v2, v18, v2
    vf.neg       v18, v3                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v15, v15
    @p2 v.sel        v3, v11, v1
    @p1 v.sel        v1, v15, v14
    vf.neg       v11, v13                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v18, v18
    @p1 v.sel        v13, v18, v0
    vf.mul       v0, v9, v23                     // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v9, v10, v22                    // a/y as a refined reciprocal (ISA has no divide)
    vf.cmp.o     p1, v11, v11
    @p1 v.sel        v10, v11, v2
    vf.mul       v2, v20, v3                     // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v3, v4, v1                      // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v1, v8, v13                     // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v4, v17, v10                    // a/y as a refined reciprocal (ISA has no divide)
    vf.cvt.f32.f16 v8, v0
    vf.cvt.f32.f16 v0, v9
    vf.fms       v9, v12, v5, v16
    vf.cvt.f32.f16 v10, v2
    vf.cvt.f32.f16 v2, v3
    vf.cvt.f32.f16 v3, v1
    vf.cvt.f32.f16 v1, v4
    vf.fms       v4, v5, v9, v5
    s.add        s3, s7, s10                     // &out_ptr0[...]
    s.add        s6, s7, s12                     // &out_ptr0[...]
    s.add        s8, s7, s4                      // &out_ptr0[...]
    vf.fms       v9, v21, v6, v16
    vf.neg       v11, v4                         // Newton step: r0*(2 - x*r0)
    s.add        s4, s7, s2                      // &out_ptr0[...]
    s.add        s2, s7, s5                      // &out_ptr0[...]
    s.add        s5, s7, s15                     // &out_ptr0[...]
    vf.fms       v4, v6, v9, v6
    vf.cmp.o     p1, v11, v11
    @p1 v.sel        v9, v11, v5
    s.add        s9, s7, s1                      // &out_ptr0[...]
    s.add        s1, s7, s16                     // &out_ptr0[...]
    vf.neg       v5, v4                          // Newton step: r0*(2 - x*r0)
    vf.mul       v4, v19, v9                     // a/y as a refined reciprocal (ISA has no divide)
    v.st.h       [s3, #0], v8
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v8, v5, v6
    vf.cvt.f32.f16 v5, v4
    vf.mul       v4, v7, v8                      // a/y as a refined reciprocal (ISA has no divide)
    vf.cvt.f32.f16 v6, v4
    v.st.h       [s6, #0], v0
    v.st.h       [s8, #0], v10
    v.st.h       [s4, #0], v2
    v.st.h       [s2, #0], v3
    v.st.h       [s5, #0], v1
    v.st.h       [s9, #0], v5
    v.st.h       [s1, #0], v6
__rctx_next:
    exit
