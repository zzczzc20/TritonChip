    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s8, [s1, #40]                   // in_ptr5: device_ptr64 at arg_base+40
    s.ld.d       s9, [s1, #48]                   // in_ptr6: device_ptr64 at arg_base+48
    s.ld.d       s10, [s1, #56]                  // out_ptr0: device_ptr64 at arg_base+56
    s.rdspecial  s1, arg_base
    s.ld.d       s11, [s1, #80]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s12, #512
    s.mul        s13, s1, s12
    s.add        s1, s11, s13                    // this context's own scratch
    s.addi       s11, s1, #0                     // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s12, #0
    s.st.d       [s11, #0], s3
    s.movz       s12, #16
    s.st.d       [s11, #8], s12
    s.movz       s12, #128
    s.st.d       [s11, #16], s12
    s.movz       s12, #256
    s.st.d       [s11, #48], s12
    s.movz       s12, #2
    s.st.d       [s11, #56], s12
    .li       s12, #68719476737
    s.st.d       [s11, #88], s12
    .li       s12, #1108101562368
    s.st.d       [s11, #104], s12
    fence.release.device
    td.load      d0, [s11]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s11, #1
    s.addi       s12, s1, #256                   // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s12, #0], s7
    s.movz       s1, #16
    s.st.d       [s12, #8], s1
    s.movz       s1, #128
    s.st.d       [s12, #16], s1
    s.movz       s1, #256
    s.st.d       [s12, #48], s1
    s.movz       s1, #2
    s.st.d       [s12, #56], s1
    .li       s1, #68719476737
    s.st.d       [s12, #88], s1
    .li       s1, #1108101562368
    s.st.d       [s12, #104], s1
    fence.release.device
    td.load      d1, [s12]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s12, #128
    s.movz       s13, #16
    v.splat      v0, s4
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v2, #64
    v.movi       v3, #0
    v.movi       v4, #1
    v.cmp.lt     p1, v0, v3
    v.cmp.lt     p2, v2, v3
    v.sub        v4, v3, v0
    @p1 v.sel        v5, v4, v0
    v.sub        v4, v3, v2
    @p2 v.sel        v6, v4, v2
    v.movi       v4, #6
    v.lshr       v6, v5, v4
    v.sub        v4, v3, v6
    @p1 v.sel        v3, v4, v6
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s11
    v.cmp.lt     p1, v4, v5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s5, v3]               // index is in elements (ISA sec 9.1)
    v.movi       v5, #0
    v.movi       v6, #1
    v.cmp.lt     p1, v0, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v0
    @p1 v.sel        v7, v6, v0
    v.sub        v0, v5, v2
    @p2 v.sel        v6, v0, v2
    v.movi       v0, #63
    v.and        v2, v7, v0
    v.sub        v0, v5, v2
    @p1 v.sel        v5, v0, v2
    s.addi       s5, s1, #0
    v.movi       v0, #0
    v.movi       v2, #0
    v.mov        v2, v0
for_1:
    s.cmp.ge     s1, s5, s12
    br.nz        s1, endfor_2
    v.splat      v0, s5
    s.movz       s1, #0
    s.movz       s11, #0
    v.add        v6, v0, v1
    s.cmp.lt     s14, s4, s1
    s.movz       s1, #64
    s.sub        s15, s11, s14
    s.movz       s11, #0
    s.movz       s14, #0
    s.cmp.lt     s16, s1, s11
    s.xor        s11, s4, s15
    s.sub        s17, s14, s16
    s.sub        s14, s11, s15
    s.xor        s11, s15, s17
    s.lshri      s15, s14, #6
    v.splat      v0, s5
    s.xor        s16, s15, s11
    v.iota       v7                              // arange(0, VLEN)
    s.sub        s18, s16, s11
    s.movz       s11, #128
    s.movz       s16, #16
    s.muli       s19, s18, #256
    v.add        v8, v0, v7
    v.movi       v0, #0
    v.splat      v7, s11
    v.splat      v9, s18
    v.movi       v10, #0
    v.splat      v11, s16
    s.muli       s11, s5, #2
    v.cmp.ge     p1, v8, v0
    v.cmp.lt     p2, v8, v7
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v11
    v.movi       v0, #128
    s.shli       s16, s5, #1                     // element offset -> bytes (x2)
    s.add        s20, s3, s19
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s19, s2, s16                    // &in_ptr0[...]
    s.add        s16, s20, s11
    p.and        p2, p5, p1
    v.cmp.lt     p1, v6, v0
    v.movi       v0, #0
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v7, [s19, #0]
    v.movi       v8, #64
    v.cmp.lt     p3, v6, v0
    s.muli       s11, s15, #64
    s.xor        s15, s1, s17
    v.cmp.lt     p4, v8, v0
    s.sub        s1, s15, s17
    v.movi       v9, #1
    s.sub        s1, s14, s11
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v9, [s16, #0]
    vf.cvt.bf16.f32 v10, v7
    v.movi       v7, #0
    v.sub        v11, v0, v6
    v.movi       v12, #63
    v.cmp.lt     p2, v3, v7
    @p3 v.sel        v13, v11, v6
    v.movi       v11, #128
    v.splat      v14, s5
    v.and        v15, v13, v12
    v.mul        v12, v5, v11
    v.iota       v11                             // arange(0, VLEN)
    v.sub        v13, v0, v15
    v.extract    s1, v12, #0
    s.movz       s11, #128
    @p3 v.sel        v12, v13, v15
    s.movz       s14, #16
    s.muli       s15, s18, #256
    v.splat      v13, s1
    v.add        v15, v14, v11
    v.movi       v11, #0
    v.splat      v14, s11
    v.splat      v16, s18
    v.movi       v17, #0
    v.splat      v18, s14
    s.muli       s1, s5, #2
    v.add        v19, v6, v13
    v.cmp.ge     p3, v15, v11
    v.cmp.lt     p5, v15, v14
    v.cmp.ge     p6, v16, v17
    s.add        s11, s7, s15
    p.and        p7, p3, p5
    v.cmp.lt     p3, v16, v18
    p.and        p5, p6, p3
    s.add        s14, s11, s1
    p.and        p3, p7, p5
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v6, [s6, v12]              // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v11, v9
    v.sub        v9, v7, v3
    v.movi       v13, #1
    v.movi       v14, #2
    @p2 v.sel        v15, v9, v3
    v.sub        v9, v0, v8
    v.sub        v0, v7, v14
    v.lshr       v16, v15, v13
    v.cmp.lt     p5, v14, v7
    @p4 v.sel        v13, v9, v8
    v.sub        v8, v7, v16
    v.movi       v7, #8192
    .li       s1, #1124073472
    v.splat      v9, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p2 v.sel        v13, v8, v16
    .li       s1, #1065353216
    v.splat      v8, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v15, v9                         // ISA 8.8: <= 2**-22 relative
    v.mul        v16, v13, v7
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s14, #0]
    .li       s1, #897988541
    v.splat      v13, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.extract    s1, v16, #0
    .li       s11, #1077936128
    v.splat      v16, s11                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v17, s1
    v.movi       v18, #1
    @p5 v.sel        v18, v0, v14
    v.add        v0, v19, v17
    s.movz       s1, #8192
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.w v14, [s8, v12]             // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v17, v7
    v.extract    s1, v12, #0
    v.extract    s11, v12, #1
    s.shli       s14, s1, #32
    v.movi       v7, #0
    s.ashri      s1, s14, #32
    v.movi       v18, #0
    s.shli       s14, s11, #32
    s.lshri      s11, s1, #32
    v.extract    s15, v12, #2
    s.ashri      s16, s14, #32
    s.shli       s14, s15, #32
    s.lshri      s15, s16, #32
    s.ashri      s17, s14, #32
    vf.fms       v19, v9, v15, v8
    .li       s14, #3204448256
    v.splat      v8, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v20, [s9, v0]              // index is in elements (ISA sec 9.1)
    v.insert     v7, s1, #0
    v.insert     v18, s11, #0
    vf.fms       v0, v15, v19, v15
    v.insert     v7, s16, #1
    v.insert     v18, s15, #1
    v.insert     v7, s17, #2
    vf.neg       v19, v0                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v19, v19
    @p2 v.sel        v0, v19, v15
    vf.cvt.bf16.f32 v15, v20
    v.extract    s1, v12, #3
    s.lshri      s11, s17, #32
    s.shli       s14, s1, #32
    v.extract    s1, v12, #4
    s.ashri      s15, s14, #32
    v.insert     v18, s11, #2
    s.lshri      s11, s15, #32
    v.insert     v7, s15, #3
    v.insert     v18, s11, #3
    vf.mul       v19, v4, v0                     // a/y: faithful quotient
    s.shli       s11, s1, #32
    vf.fms       v20, v19, v9, v4
    s.ashri      s1, s11, #32
    vf.fms       v9, v20, v0, v19
    v.insert     v7, s1, #4
    vf.neg       v0, v9                          // a/y: one correction to the IEEE quotient
    s.lshri      s11, s1, #32
    vf.cmp.o     p2, v0, v0
    v.insert     v18, s11, #4
    @p2 v.sel        v9, v0, v19
    v.extract    s1, v12, #5
    s.shli       s11, s1, #32
    vf.add       v0, v9, v13
    s.ashri      s1, s11, #32
    v.rsqrt.approx v9, v0                        // ISA 8.8: <= 2**-22 relative
    v.insert     v7, s1, #5
    vf.mul       v13, v9, v9
    s.lshri      s11, s1, #32
    vf.mul       v19, v9, v8
    v.insert     v18, s11, #5
    vf.fms       v8, v0, v13, v16
    v.extract    s1, v12, #6
    s.shli       s11, s1, #32
    s.ashri      s1, s11, #32
    vf.mul       v0, v19, v8                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.insert     v7, s1, #6
    vf.cmp.o     p2, v0, v0
    s.lshri      s11, s1, #32
    @p2 v.sel        v8, v0, v9
    v.insert     v18, s11, #6
    v.extract    s1, v8, #0
    v.extract    s11, v12, #7
    v.splat      v0, s1
    s.shli       s1, s11, #32
    vf.mul       v8, v11, v0
    s.ashri      s11, s1, #32
    vf.mul       v0, v10, v8
    v.extract    s1, v12, #8
    s.lshri      s14, s11, #32
    s.shli       s15, s1, #32
    v.extract    s1, v12, #9
    s.ashri      s16, s15, #32
    v.insert     v7, s11, #7
    v.insert     v18, s14, #7
    s.shli       s11, s1, #32
    s.lshri      s1, s16, #32
    v.extract    s14, v12, #10
    s.ashri      s15, s11, #32
    v.insert     v7, s16, #8
    v.insert     v18, s1, #8
    s.shli       s1, s14, #32
    s.lshri      s11, s15, #32
    v.extract    s14, v12, #11
    s.ashri      s16, s1, #32
    v.insert     v7, s15, #9
    v.insert     v18, s11, #9
    s.shli       s1, s14, #32
    s.lshri      s11, s16, #32
    v.extract    s14, v12, #12
    s.ashri      s15, s1, #32
    v.insert     v7, s16, #10
    v.insert     v18, s11, #10
    s.shli       s1, s14, #32
    s.lshri      s11, s15, #32
    v.extract    s14, v12, #13
    s.ashri      s16, s1, #32
    v.insert     v7, s15, #11
    v.insert     v18, s11, #11
    s.shli       s1, s14, #32
    s.lshri      s11, s16, #32
    v.extract    s14, v12, #14
    s.ashri      s15, s1, #32
    v.insert     v7, s16, #12
    v.insert     v18, s11, #12
    s.shli       s1, s14, #32
    s.lshri      s11, s15, #32
    v.extract    s14, v12, #15
    s.ashri      s16, s1, #32
    v.insert     v7, s15, #13
    v.insert     v18, s11, #13
    s.shli       s1, s14, #32
    s.lshri      s11, s16, #32
    s.ashri      s14, s1, #32
    v.insert     v7, s16, #14
    v.insert     v18, s11, #14
    s.lshri      s1, s14, #32
    v.insert     v7, s14, #15
    v.insert     v18, s1, #15
    s.movz       s1, #2
    v.extract    s11, v7, #0
    v.extract    s14, v18, #0
    v.extract    s15, v18, #1
    s.shli       s16, s14, #32
    v.movi       v8, #0
    s.or         s14, s11, s16
    v.extract    s11, v7, #1
    s.shli       s16, s15, #32
    s.cmp.ge     s15, s14, s1
    v.extract    s1, v18, #2
    s.or         s14, s11, s16
    s.movz       s11, #2
    v.insert     v8, s15, #0
    v.extract    s15, v7, #2
    s.shli       s16, s1, #32
    s.cmp.ge     s1, s14, s11
    v.extract    s11, v18, #3
    s.or         s14, s15, s16
    s.movz       s15, #2
    v.insert     v8, s1, #1
    v.extract    s1, v7, #3
    s.shli       s16, s11, #32
    s.cmp.ge     s11, s14, s15
    v.extract    s14, v18, #4
    s.or         s15, s1, s16
    s.movz       s1, #2
    v.insert     v8, s11, #2
    v.extract    s11, v7, #4
    s.shli       s16, s14, #32
    s.cmp.ge     s14, s15, s1
    v.extract    s1, v18, #5
    s.or         s15, s11, s16
    s.movz       s11, #2
    v.insert     v8, s14, #3
    v.extract    s14, v7, #5
    s.shli       s16, s1, #32
    s.cmp.ge     s1, s15, s11
    v.extract    s11, v18, #6
    s.or         s15, s14, s16
    s.movz       s14, #2
    v.insert     v8, s1, #4
    v.extract    s1, v7, #6
    s.shli       s16, s11, #32
    s.cmp.ge     s11, s15, s14
    v.extract    s14, v18, #7
    s.or         s15, s1, s16
    s.movz       s1, #2
    v.insert     v8, s11, #5
    v.extract    s11, v7, #7
    s.shli       s16, s14, #32
    s.cmp.ge     s14, s15, s1
    v.extract    s1, v18, #8
    s.or         s15, s11, s16
    s.movz       s11, #2
    v.insert     v8, s14, #6
    v.extract    s14, v7, #8
    s.shli       s16, s1, #32
    s.cmp.ge     s1, s15, s11
    v.extract    s11, v18, #9
    s.or         s15, s14, s16
    s.movz       s14, #2
    v.insert     v8, s1, #7
    v.extract    s1, v7, #9
    s.shli       s16, s11, #32
    s.cmp.ge     s11, s15, s14
    v.extract    s14, v18, #10
    s.or         s15, s1, s16
    s.movz       s1, #2
    v.insert     v8, s11, #8
    v.extract    s11, v7, #10
    s.shli       s16, s14, #32
    s.cmp.ge     s14, s15, s1
    v.extract    s1, v18, #11
    s.or         s15, s11, s16
    s.movz       s11, #2
    v.insert     v8, s14, #9
    v.extract    s14, v7, #11
    s.shli       s16, s1, #32
    s.cmp.ge     s1, s15, s11
    v.extract    s11, v18, #12
    s.or         s15, s14, s16
    s.movz       s14, #2
    v.insert     v8, s1, #10
    v.extract    s1, v7, #12
    s.shli       s16, s11, #32
    s.cmp.ge     s11, s15, s14
    v.extract    s14, v18, #13
    s.or         s15, s1, s16
    s.movz       s1, #2
    v.insert     v8, s11, #11
    v.extract    s11, v7, #13
    s.shli       s16, s14, #32
    s.cmp.ge     s14, s15, s1
    v.extract    s1, v18, #14
    s.or         s15, s11, s16
    s.movz       s11, #2
    v.insert     v8, s14, #12
    v.extract    s14, v7, #14
    s.shli       s16, s1, #32
    s.cmp.ge     s1, s15, s11
    v.extract    s11, v18, #15
    v.extract    s15, v18, #0
    s.or         s17, s14, s16
    s.movz       s14, #2
    v.insert     v8, s1, #13
    v.extract    s1, v7, #15
    s.shli       s16, s11, #32
    v.extract    s11, v7, #0
    s.shli       s18, s15, #32
    s.cmp.ge     s15, s17, s14
    v.extract    s14, v18, #1
    s.or         s17, s1, s16
    s.movz       s1, #2
    s.or         s16, s11, s18
    s.movz       s11, #60
    v.insert     v8, s15, #14
    v.movi       v9, #0
    v.extract    s15, v7, #1
    s.shli       s18, s14, #32
    s.cmp.ge     s14, s17, s1
    s.cmp.lt     s1, s16, s11
    v.extract    s11, v18, #2
    s.or         s16, s15, s18
    s.movz       s15, #60
    v.insert     v8, s14, #15
    v.insert     v9, s1, #0
    v.extract    s1, v7, #2
    s.shli       s14, s11, #32
    s.cmp.lt     s11, s16, s15
    v.extract    s15, v18, #3
    s.or         s16, s1, s14
    s.movz       s1, #60
    v.insert     v9, s11, #1
    v.extract    s11, v7, #3
    s.shli       s14, s15, #32
    s.cmp.lt     s15, s16, s1
    v.extract    s1, v18, #4
    s.or         s16, s11, s14
    s.movz       s11, #60
    v.insert     v9, s15, #2
    v.extract    s14, v7, #4
    s.shli       s15, s1, #32
    s.cmp.lt     s1, s16, s11
    v.extract    s11, v18, #5
    s.or         s16, s14, s15
    s.movz       s14, #60
    v.insert     v9, s1, #3
    v.extract    s1, v7, #5
    s.shli       s15, s11, #32
    s.cmp.lt     s11, s16, s14
    v.extract    s14, v18, #6
    s.or         s16, s1, s15
    s.movz       s1, #60
    v.insert     v9, s11, #4
    v.extract    s11, v7, #6
    s.shli       s15, s14, #32
    s.cmp.lt     s14, s16, s1
    v.movi       v10, #0
    s.or         s1, s11, s15
    v.insert     v9, s14, #5
    v.cmp.ne     p2, v8, v10
    v.extract    s11, v18, #7
    s.movz       s14, #60
    v.extract    s15, v7, #7
    s.shli       s16, s11, #32
    s.cmp.lt     s11, s1, s14
    v.extract    s1, v18, #8
    s.or         s14, s15, s16
    s.movz       s15, #60
    v.insert     v9, s11, #6
    v.extract    s11, v7, #8
    s.shli       s16, s1, #32
    s.cmp.lt     s1, s14, s15
    v.extract    s14, v18, #9
    s.or         s15, s11, s16
    s.movz       s11, #60
    v.insert     v9, s1, #7
    v.extract    s1, v7, #9
    s.shli       s16, s14, #32
    s.cmp.lt     s14, s15, s11
    v.extract    s11, v18, #10
    s.or         s15, s1, s16
    s.movz       s1, #60
    v.insert     v9, s14, #8
    v.extract    s14, v7, #10
    s.shli       s16, s11, #32
    s.cmp.lt     s11, s15, s1
    v.extract    s1, v18, #11
    s.or         s15, s14, s16
    s.movz       s14, #60
    v.insert     v9, s11, #9
    v.extract    s11, v7, #11
    s.shli       s16, s1, #32
    s.cmp.lt     s1, s15, s14
    v.extract    s14, v18, #12
    s.or         s15, s11, s16
    s.movz       s11, #60
    v.insert     v9, s1, #10
    v.extract    s1, v7, #12
    s.shli       s16, s14, #32
    s.cmp.lt     s14, s15, s11
    v.extract    s11, v18, #13
    s.or         s15, s1, s16
    s.movz       s1, #60
    v.insert     v9, s14, #11
    v.extract    s14, v7, #13
    s.shli       s16, s11, #32
    s.cmp.lt     s11, s15, s1
    v.extract    s1, v18, #14
    s.or         s15, s14, s16
    s.movz       s14, #60
    v.insert     v9, s11, #12
    v.extract    s11, v7, #14
    s.shli       s16, s1, #32
    s.cmp.lt     s1, s15, s14
    v.extract    s14, v18, #15
    s.or         s15, s11, s16
    s.movz       s11, #60
    v.insert     v9, s1, #13
    v.extract    s1, v7, #15
    s.shli       s16, s14, #32
    v.movi       v7, #-2
    s.cmp.lt     s14, s15, s11
    s.or         s11, s1, s16
    s.movz       s1, #60
    v.insert     v9, s14, #14
    v.add        v8, v12, v7
    v.movi       v7, #3
    v.movi       v10, #0
    s.cmp.lt     s14, s11, s1
    v.movi       v11, #0
    v.insert     v9, s14, #15
    v.sub        v12, v10, v8
    v.sub        v13, v10, v7
    v.cmp.lt     p3, v8, v10
    v.cmp.lt     p4, v7, v10
    v.cmp.ne     p5, v9, v11
    .li       s1, #-2
    v.movi       v9, #1
    @p3 v.sel        v11, v12, v8
    @p4 v.sel        v12, v13, v7
    v.movi       v13, #0
    v.movi       v16, #0
    s.movz       s1, #31
idiv_3:
    v.splat      v18, s1
    v.shl        v19, v16, v9
    v.cmp.lt     p4, v16, v10
    v.lshr       v20, v11, v18
    v.shl        v21, v9, v18
    s.subi       s11, s1, #1
    v.and        v18, v20, v9
    s.movz       s14, #0
    v.or         v20, v19, v18
    v.cmp.geu    p6, v20, v12
    p.or         p7, p4, p6
    v.sub        v18, v20, v12
    @p7 v.sel        v19, v21, v10
    @p7 v.sel        v21, v18, v20
    v.or         v18, v13, v19
    v.mov        v16, v21
    v.mov        v13, v18
    s.mov        s1, s11
    s.cmp.ge     s11, s1, s14
    br.nz        s11, idiv_3
    v.sub        v9, v10, v16
    v.movi       v10, #0
    v.movi       v11, #0
    @p3 v.sel        v12, v9, v16
    v.extract    s1, v12, #0
    v.extract    s11, v12, #1
    s.shli       s14, s1, #32
    s.shli       s1, s11, #32
    s.ashri      s11, s14, #32
    v.extract    s14, v12, #2
    s.lshri      s15, s11, #32
    s.ashri      s16, s1, #32
    v.insert     v10, s11, #0
    v.insert     v11, s15, #0
    s.shli       s1, s14, #32
    s.lshri      s11, s16, #32
    v.extract    s14, v12, #3
    s.ashri      s15, s1, #32
    v.insert     v10, s16, #1
    v.insert     v11, s11, #1
    s.shli       s1, s14, #32
    s.lshri      s11, s15, #32
    v.extract    s14, v12, #4
    s.ashri      s16, s1, #32
    v.insert     v10, s15, #2
    v.insert     v11, s11, #2
    s.shli       s1, s14, #32
    s.lshri      s11, s16, #32
    v.extract    s14, v12, #5
    s.ashri      s15, s1, #32
    v.insert     v10, s16, #3
    v.insert     v11, s11, #3
    s.shli       s1, s14, #32
    s.lshri      s11, s15, #32
    v.extract    s14, v12, #6
    s.ashri      s16, s1, #32
    v.insert     v10, s15, #4
    v.insert     v11, s11, #4
    s.shli       s1, s14, #32
    s.lshri      s11, s16, #32
    v.extract    s14, v12, #7
    s.ashri      s15, s1, #32
    v.insert     v10, s16, #5
    v.insert     v11, s11, #5
    s.shli       s1, s14, #32
    s.lshri      s11, s15, #32
    v.extract    s14, v12, #8
    s.ashri      s16, s1, #32
    v.insert     v10, s15, #6
    v.insert     v11, s11, #6
    s.shli       s1, s14, #32
    s.lshri      s11, s16, #32
    v.extract    s14, v12, #9
    s.ashri      s15, s1, #32
    v.insert     v10, s16, #7
    v.insert     v11, s11, #7
    s.shli       s1, s14, #32
    s.lshri      s11, s15, #32
    v.extract    s14, v12, #10
    s.ashri      s16, s1, #32
    v.insert     v10, s15, #8
    v.insert     v11, s11, #8
    s.shli       s1, s14, #32
    s.lshri      s11, s16, #32
    v.extract    s14, v12, #11
    s.ashri      s15, s1, #32
    v.insert     v10, s16, #9
    v.insert     v11, s11, #9
    s.shli       s1, s14, #32
    s.lshri      s11, s15, #32
    v.extract    s14, v12, #12
    s.ashri      s16, s1, #32
    v.insert     v10, s15, #10
    v.insert     v11, s11, #10
    s.shli       s1, s14, #32
    s.lshri      s11, s16, #32
    v.extract    s14, v12, #13
    s.ashri      s15, s1, #32
    v.insert     v10, s16, #11
    v.insert     v11, s11, #11
    s.shli       s1, s14, #32
    s.lshri      s11, s15, #32
    v.extract    s14, v12, #14
    s.ashri      s16, s1, #32
    v.insert     v10, s15, #12
    v.insert     v11, s11, #12
    s.shli       s1, s14, #32
    s.lshri      s11, s16, #32
    v.extract    s14, v12, #15
    s.ashri      s15, s1, #32
    v.insert     v10, s16, #13
    v.insert     v11, s11, #13
    s.shli       s1, s14, #32
    s.lshri      s11, s15, #32
    s.ashri      s14, s1, #32
    v.insert     v10, s15, #14
    v.insert     v11, s11, #14
    s.lshri      s1, s14, #32
    v.insert     v10, s14, #15
    v.insert     v11, s1, #15
    s.movz       s1, #0
    v.extract    s11, v10, #0
    v.extract    s14, v11, #0
    v.extract    s15, v11, #1
    s.shli       s16, s14, #32
    v.movi       v9, #0
    s.or         s14, s11, s16
    v.extract    s11, v10, #1
    s.shli       s16, s15, #32
    s.cmp.eq     s15, s14, s1
    v.extract    s1, v11, #2
    s.or         s14, s11, s16
    s.movz       s11, #0
    v.insert     v9, s15, #0
    v.extract    s15, v10, #2
    s.shli       s16, s1, #32
    s.cmp.eq     s1, s14, s11
    v.extract    s11, v11, #3
    s.or         s14, s15, s16
    s.movz       s15, #0
    v.insert     v9, s1, #1
    v.extract    s1, v10, #3
    s.shli       s16, s11, #32
    s.cmp.eq     s11, s14, s15
    v.extract    s14, v11, #4
    s.or         s15, s1, s16
    s.movz       s1, #0
    v.insert     v9, s11, #2
    v.extract    s11, v10, #4
    s.shli       s16, s14, #32
    s.cmp.eq     s14, s15, s1
    v.extract    s1, v11, #5
    s.or         s15, s11, s16
    s.movz       s11, #0
    v.insert     v9, s14, #3
    v.extract    s14, v10, #5
    s.shli       s16, s1, #32
    s.cmp.eq     s1, s15, s11
    v.extract    s11, v11, #6
    s.or         s15, s14, s16
    s.movz       s14, #0
    v.insert     v9, s1, #4
    v.extract    s1, v10, #6
    s.shli       s16, s11, #32
    s.cmp.eq     s11, s15, s14
    v.extract    s14, v11, #7
    s.or         s15, s1, s16
    s.movz       s1, #0
    v.insert     v9, s11, #5
    v.extract    s11, v10, #7
    s.shli       s16, s14, #32
    s.cmp.eq     s14, s15, s1
    v.extract    s1, v11, #8
    s.or         s15, s11, s16
    s.movz       s11, #0
    v.insert     v9, s14, #6
    v.extract    s14, v10, #8
    s.shli       s16, s1, #32
    s.cmp.eq     s1, s15, s11
    v.extract    s11, v11, #9
    s.or         s15, s14, s16
    s.movz       s14, #0
    v.insert     v9, s1, #7
    v.extract    s1, v10, #9
    s.shli       s16, s11, #32
    s.cmp.eq     s11, s15, s14
    v.extract    s14, v11, #10
    s.or         s15, s1, s16
    s.movz       s1, #0
    v.insert     v9, s11, #8
    v.extract    s11, v10, #10
    s.shli       s16, s14, #32
    s.cmp.eq     s14, s15, s1
    v.extract    s1, v11, #11
    s.or         s15, s11, s16
    s.movz       s11, #0
    v.insert     v9, s14, #9
    v.extract    s14, v10, #11
    s.shli       s16, s1, #32
    s.cmp.eq     s1, s15, s11
    v.extract    s11, v11, #12
    s.or         s15, s14, s16
    s.movz       s14, #0
    v.insert     v9, s1, #10
    v.extract    s1, v10, #12
    s.shli       s16, s11, #32
    s.cmp.eq     s11, s15, s14
    v.extract    s14, v11, #13
    s.or         s15, s1, s16
    s.movz       s1, #0
    v.insert     v9, s11, #11
    v.extract    s11, v10, #13
    s.shli       s16, s14, #32
    s.cmp.eq     s14, s15, s1
    v.extract    s1, v11, #14
    s.or         s15, s11, s16
    s.movz       s11, #0
    v.insert     v9, s14, #12
    v.extract    s14, v10, #14
    s.shli       s16, s1, #32
    s.cmp.eq     s1, s15, s11
    v.extract    s11, v11, #15
    s.or         s15, s14, s16
    s.movz       s14, #0
    v.insert     v9, s1, #13
    v.extract    s1, v10, #15
    s.shli       s16, s11, #32
    s.cmp.eq     s11, s15, s14
    s.or         s14, s1, s16
    s.movz       s1, #0
    v.insert     v9, s11, #14
    s.cmp.eq     s11, s14, s1
    v.movi       v10, #0
    v.insert     v9, s11, #15
    v.movi       v11, #0
    v.sub        v13, v10, v8
    v.sub        v16, v10, v7
    p.and        p3, p2, p5
    v.cmp.ne     p2, v9, v11
    v.cmp.lt     p4, v8, v10
    v.cmp.lt     p5, v7, v10
    p.and        p6, p3, p2
    v.movi       v9, #1
    @p4 v.sel        v11, v13, v8
    @p5 v.sel        v13, v16, v7
    v.movi       v16, #0
    v.movi       v18, #0
    s.movz       s1, #31
idiv_4:
    v.splat      v19, s1
    v.shl        v20, v18, v9
    v.cmp.lt     p2, v18, v10
    v.lshr       v21, v11, v19
    v.shl        v22, v9, v19
    s.subi       s11, s1, #1
    v.and        v19, v21, v9
    s.movz       s14, #0
    v.or         v21, v20, v19
    v.cmp.geu    p3, v21, v13
    p.or         p7, p2, p3
    v.sub        v19, v21, v13
    @p7 v.sel        v20, v22, v10
    @p7 v.sel        v22, v19, v21
    v.or         v19, v16, v20
    v.mov        v18, v22
    v.mov        v16, v19
    s.mov        s1, s11
    s.cmp.ge     s11, s1, s14
    br.nz        s11, idiv_4
    v.sub        v9, v10, v16
    p.xor        p2, p4, p5
    v.movi       v10, #1
    @p2 v.sel        v11, v9, v16
    v.movi       v9, #0
    v.movi       v13, #130
    v.sub        v16, v11, v10
    v.cmp.ne     p2, v12, v9
    v.cmp.lt     p3, v8, v9
    @p2 v.sel        v8, v16, v11
    p.and        p2, p1, p6
    .li       s1, #1050163184
    v.splat      v9, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p3 v.sel        v10, v8, v11
    v.movi       v8, #0
    vf.mul       v11, v15, v9
    v.mul        v12, v10, v7
    s.add        s1, s5, s13
    s.movz       s11, #1
    v.add        v7, v12, v13
    s.movz       s14, #1
    s.movz       s14, #3
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v10, [s6, v7]              // index is in elements (ISA sec 9.1)
    s.movz       s14, #130
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v12, [s8, v7]              // index is in elements (ISA sec 9.1)
    @p6 v.sel        v7, v10, v6
    vf.mul       v6, v0, v7
    @p6 v.sel        v0, v12, v14
    vf.mul       v7, v17, v0
    vf.add       v0, v6, v7
    vf.mul       v6, v0, v9
    vf.mul       v0, v6, v11
    vf.add       v6, v2, v0
    @p1 v.sel        v0, v6, v2
    v.mov        v8, v0
    v.mov        v2, v8
    s.mov        s5, s1
    br.nz        s11, for_1
endfor_2:
    vf.reduce.add.b v0, v2
    v.movi       v1, #0
    s.movz       s1, #1
    s.shli       s2, s4, #2                      // element offset -> bytes (x4)
    vf.add       v2, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.add        s1, s10, s2                     // &out_ptr0[...]
    v.cmp.lt     p1, v0, v1
    @p1 v.st.w       [s1, #0], v2
__rctx_next:
    exit
