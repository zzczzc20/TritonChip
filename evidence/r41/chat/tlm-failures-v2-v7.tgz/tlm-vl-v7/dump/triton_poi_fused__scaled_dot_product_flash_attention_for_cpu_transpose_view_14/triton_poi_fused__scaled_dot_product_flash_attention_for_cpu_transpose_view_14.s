    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #2047
    v.add        v4, v1, v0
    v.movi       v0, #0
    v.movi       v1, #0
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    v.sub        v6, v0, v4
    @p1 v.sel        v7, v5, v4
    v.cmp.lt     p2, v4, v0
    @p2 v.sel        v5, v6, v4
    v.and        v4, v7, v3
    v.movi       v3, #11
    v.movi       v6, #7
    v.sub        v7, v2, v4
    v.movi       v8, #0
    v.lshr       v9, v5, v3
    @p1 v.sel        v3, v7, v4
    s.rdspecial  s2, arg_base
    v.sub        v4, v0, v9
    v.sub        v5, v1, v3
    v.cmp.lt     p1, v3, v1
    v.cmp.lt     p3, v3, v8
    @p1 v.sel        v7, v5, v3
    @p2 v.sel        v5, v4, v9
    v.movi       v4, #128
    v.lshr       v9, v7, v6
    v.movi       v6, #2304
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.sub        v7, v8, v3
    v.mul        v10, v5, v4
    v.cmp.lt     p2, v4, v1
    s.ld.d       s4, [s2, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    @p3 v.sel        v5, v7, v3
    v.sub        v3, v1, v9
    v.sub        v7, v1, v4
    @p1 v.sel        v1, v3, v9
    v.movi       v3, #127
    v.cmp.lt     p1, v4, v8
    v.mul        v9, v1, v6
    v.and        v1, v5, v3
    v.movi       v3, #2048
    v.add        v5, v10, v9
    v.sub        v6, v8, v1
    v.sub        v9, v2, v3
    v.sub        v10, v8, v4
    @p3 v.sel        v8, v6, v1
    v.sub        v1, v0, v3
    v.cmp.lt     p3, v3, v2
    v.add        v2, v5, v8
    s.shli       s2, s1, #1                      // element offset -> bytes (x2)
    @p3 v.sel        v5, v9, v3
    v.ld.gather.w v5, [s3, v2]                   // index is in elements (ISA sec 9.1)
    s.add        s1, s4, s2                      // &out_ptr0[...]
    v.cmp.lt     p3, v3, v0
    @p3 v.sel        v0, v1, v3
    @p2 v.sel        v0, v7, v4
    @p1 v.sel        v0, v10, v4
    vf.cvt.f32.bf16 v0, v5
    v.st.h       [s1, #0], v0
__rctx_next:
    exit
