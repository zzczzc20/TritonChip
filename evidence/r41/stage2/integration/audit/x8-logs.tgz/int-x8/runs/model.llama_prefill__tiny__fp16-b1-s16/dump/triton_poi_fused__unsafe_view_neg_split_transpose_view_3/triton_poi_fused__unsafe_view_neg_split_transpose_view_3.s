    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #3
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    @p1 v.sel        v4, v1, v3
    v.movi       v1, #0
    v.lshr       v5, v4, v0
    v.movi       v0, #0
    v.sub        v4, v2, v5
    v.sub        v6, v1, v3
    @p1 v.sel        v7, v4, v5
    v.movi       v4, #0
    v.cmp.lt     p1, v3, v1
    v.cmp.lt     p2, v3, v0
    @p1 v.sel        v5, v6, v3
    v.movi       v6, #7
    v.sub        v8, v4, v7
    v.cmp.lt     p3, v7, v4
    v.and        v9, v5, v6
    @p3 v.sel        v5, v8, v7
    v.movi       v6, #15
    v.sub        v8, v1, v9
    v.and        v10, v5, v6
    v.movi       v5, #8
    @p1 v.sel        v6, v8, v9
    v.movi       v8, #16
    v.sub        v9, v4, v10
    s.rdspecial  s1, arg_base
    v.sub        v11, v0, v3
    @p3 v.sel        v12, v9, v10
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    @p2 v.sel        v9, v11, v3
    v.movi       v10, #512
    v.movi       v11, #128
    v.cmp.lt     p1, v3, v10
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.movi       v3, #7
    v.add        v10, v6, v5
    v.lshr       v13, v9, v3
    v.movi       v3, #64
    v.cmp.lt     p3, v5, v1
    v.mul        v9, v12, v3
    v.sub        v3, v0, v13
    v.sub        v12, v1, v5
    @p2 v.sel        v1, v3, v13
    v.sub        v3, v2, v5
    v.mul        v13, v1, v8
    v.cmp.lt     p2, v5, v2
    v.add        v1, v10, v13
    v.sub        v2, v4, v8
    v.add        v10, v1, v9
    v.sub        v1, v0, v11
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v9, [s2, v10]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p4, v8, v4
    @p3 v.sel        v4, v12, v5
    v.mul        v4, v7, v8
    v.cmp.lt     p3, v11, v0
    v.add        v0, v6, v4
    vf.cvt.f16.f32 v4, v9
    @p2 v.sel        v6, v3, v5
    @p4 v.sel        v3, v2, v8
    @p3 v.sel        v2, v1, v11
    vf.neg       v1, v4
    vf.cvt.f32.f16 v2, v1
    @p1 v.st.scatter.h [s3, v0], v2
__rctx_next:
    exit
