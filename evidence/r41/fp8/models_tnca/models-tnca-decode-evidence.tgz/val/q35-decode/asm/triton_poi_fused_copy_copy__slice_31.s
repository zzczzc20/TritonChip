    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #0
    v.sub        v1, v2, v3
    v.sub        v4, v0, v3
    v.cmp.lt     p1, v3, v2
    v.cmp.lt     p2, v3, v0
    @p1 v.sel        v5, v1, v3
    v.movi       v1, #3
    @p2 v.sel        v6, v4, v3
    v.movi       v3, #2
    v.and        v4, v5, v1
    v.lshr       v1, v6, v3
    v.sub        v3, v2, v4
    v.sub        v5, v0, v1
    @p1 v.sel        v6, v3, v4
    @p2 v.sel        v3, v5, v1
    v.movi       v1, #1
    v.movi       v4, #5
    s.rdspecial  s2, arg_base
    v.add        v5, v6, v1
    v.mul        v1, v3, v4
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.add        v3, v5, v1
    v.movi       v1, #4
    v.ld.gather.h v4, [s3, v3]                   // index is in elements (ISA sec 9.1)
    s.shli       s3, s1, #1                      // element offset -> bytes (x2)
    v.sub        v3, v2, v1
    v.sub        v5, v0, v1
    v.cmp.lt     p1, v1, v2
    v.cmp.lt     p2, v1, v0
    s.ld.d       s1, [s2, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    @p1 v.sel        v0, v3, v1
    @p2 v.sel        v0, v5, v1
    s.add        s2, s1, s3                      // &out_ptr0[...]
    v.st.h       [s2, #0], v4
__rctx_next:
    exit
