

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 2, 'num_stages': 2}, {'num_warps': 2, 'num_stages': 3}, {'num_warps': 2, 'num_stages': 4}, {'num_warps': 4, 'num_stages': 2}, {'num_warps': 4, 'num_stages': 3}, {'num_warps': 4, 'num_stages': 4}, {'num_warps': 8, 'num_stages': 2}, {'num_warps': 8, 'num_stages': 3}, {'num_warps': 8, 'num_stages': 4}, {'num_warps': 16, 'num_stages': 2}, {'num_warps': 16, 'num_stages': 3}, {'num_warps': 16, 'num_stages': 4}],
    inductor_meta={'grid_type': 'PrecomputedGrid', 'precomputed_grids': [{'config': {'num_warps': 2, 'num_stages': 2}, 'python': ['1', '72', '1'], 'cpp': ['1L', '72L', '1L'], 'python_slow': ['1', '72', '1']}, {'config': {'num_warps': 2, 'num_stages': 3}, 'python': ['1', '72', '1'], 'cpp': ['1L', '72L', '1L'], 'python_slow': ['1', '72', '1']}, {'config': {'num_warps': 2, 'num_stages': 4}, 'python': ['1', '72', '1'], 'cpp': ['1L', '72L', '1L'], 'python_slow': ['1', '72', '1']}, {'config': {'num_warps': 4, 'num_stages': 2}, 'python': ['1', '72', '1'], 'cpp': ['1L', '72L', '1L'], 'python_slow': ['1', '72', '1']}, {'config': {'num_warps': 4, 'num_stages': 3}, 'python': ['1', '72', '1'], 'cpp': ['1L', '72L', '1L'], 'python_slow': ['1', '72', '1']}, {'config': {'num_warps': 4, 'num_stages': 4}, 'python': ['1', '72', '1'], 'cpp': ['1L', '72L', '1L'], 'python_slow': ['1', '72', '1']}, {'config': {'num_warps': 8, 'num_stages': 2}, 'python': ['1', '72', '1'], 'cpp': ['1L', '72L', '1L'], 'python_slow': ['1', '72', '1']}, {'config': {'num_warps': 8, 'num_stages': 3}, 'python': ['1', '72', '1'], 'cpp': ['1L', '72L', '1L'], 'python_slow': ['1', '72', '1']}, {'config': {'num_warps': 8, 'num_stages': 4}, 'python': ['1', '72', '1'], 'cpp': ['1L', '72L', '1L'], 'python_slow': ['1', '72', '1']}, {'config': {'num_warps': 16, 'num_stages': 2}, 'python': ['1', '72', '1'], 'cpp': ['1L', '72L', '1L'], 'python_slow': ['1', '72', '1']}, {'config': {'num_warps': 16, 'num_stages': 3}, 'python': ['1', '72', '1'], 'cpp': ['1L', '72L', '1L'], 'python_slow': ['1', '72', '1']}, {'config': {'num_warps': 16, 'num_stages': 4}, 'python': ['1', '72', '1'], 'cpp': ['1L', '72L', '1L'], 'python_slow': ['1', '72', '1']}], 'extra_launcher_args': [], 'declared_constexpr_names': ['BLOCK_SIZE_M', 'BLOCK_SIZE_N', 'BLOCK_SIZE_K', 'GROUP_SIZE_M'], 'kernel_name': 'w8a8_block_dynamic_fp8_matmul_kernel_3', 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    triton_meta={'signature': {'A': '*bf16', 'B': '*fp8e4nv', 'C': '*bf16', 'Bs': '*fp32', 'M': 'constexpr', 'N': 'i32', 'K': 'i32', 'stride_am': 'i32', 'stride_ak': 'constexpr', 'stride_bk': 'constexpr', 'stride_bn': 'i32', 'stride_cm': 'i32', 'stride_cn': 'constexpr', 'stride_bs_k': 'constexpr', 'stride_bs_n': 'i32', 'BLOCK_SIZE_M': 'constexpr', 'BLOCK_SIZE_N': 'constexpr', 'BLOCK_SIZE_K': 'constexpr', 'GROUP_SIZE_M': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'M': 1, 'stride_ak': 1, 'stride_bk': 1, 'stride_cn': 1, 'stride_bs_k': 1, 'BLOCK_SIZE_M': 16, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'GROUP_SIZE_M': 8}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (10,): [['tt.divisibility', 16]], (11,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def w8a8_block_dynamic_fp8_matmul_kernel(
    A,  # (M, K) raw BF16/FP16 activations
    B,  # (N, K) FP8 weights
    C,  # (M, N) output
    Bs,  # (N // BLOCK_SIZE_N, K // BLOCK_SIZE_K) weight scales (fp32 or uint8/UE8M0)
    # Shape
    M,
    N,
    K,
    # Strides
    stride_am,
    stride_ak,
    stride_bk,
    stride_bn,
    stride_cm,
    stride_cn,
    stride_bs_k,
    stride_bs_n,
    # Meta-parameters
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """Block-scale FP8 GEMM kernel with fused activation quantization.

    Computes ``C = A @ B.T`` with bf16/fp16 ``A`` quantized to FP8 per-K-tile
    inline (one scale per M-row per BLOCK_SIZE_K) and pre-quantized FP8 weights
    with per-block scales. 2D grid with swizzle for L2 cache locality on B.
    """
    pid_m, pid_n, offs_am, offs_bn, offs_k = _swizzle_offsets(
        M, N, BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M
    )
    a_ptrs = A + (offs_am[:, None] * stride_am + offs_k[None, :] * stride_ak)
    b_ptrs = B + (offs_k[:, None] * stride_bk + offs_bn[None, :] * stride_bn)

    offs_bsn = offs_bn // BLOCK_SIZE_N
    bs_ptrs = Bs + offs_bsn * stride_bs_n

    accumulator = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    for k in range(0, tl.cdiv(K, BLOCK_SIZE_K)):
        k_remaining = K - k * BLOCK_SIZE_K
        a_raw = tl.load(a_ptrs, mask=offs_k[None, :] < k_remaining, other=0.0).to(
            tl.float32
        )
        a, a_s = fp8_act_quant_inline(a_raw)
        b = tl.load(b_ptrs, mask=offs_k[:, None] < k_remaining, other=0.0)
        b_s = decode_ue8m0_scale(tl.load(bs_ptrs))
        accumulator += tl.dot(a, b) * a_s[:, None] * b_s[None, :]
        a_ptrs += BLOCK_SIZE_K * stride_ak
        b_ptrs += BLOCK_SIZE_K * stride_bk
        bs_ptrs += stride_bs_k

    _store_masked(
        C,
        accumulator,
        pid_m,
        pid_n,
        M,
        N,
        stride_cm,
        stride_cn,
        BLOCK_SIZE_M,
        BLOCK_SIZE_N,
    )

@triton.jit
def _swizzle_offsets(
    M,
    N,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """2D-grid tile scheduling shared by the kernels below: swizzle the
    ``(pid_m, pid_n)`` program ids for L2 locality on B, then build the operand
    offset vectors. Returns ``(pid_m, pid_n, offs_am, offs_bn, offs_k)`` — the
    swizzled ids (reused by the output store) and the ``%``-wrapped row/col offsets
    plus the K range."""
    pid_m = tl.program_id(axis=0)
    pid_n = tl.program_id(axis=1)
    num_pid_m = tl.cdiv(M, BLOCK_SIZE_M)
    num_pid_n = tl.cdiv(N, BLOCK_SIZE_N)
    pid_m, pid_n = tl.swizzle2d(pid_m, pid_n, num_pid_m, num_pid_n, GROUP_SIZE_M)
    offs_am = (pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)) % M
    offs_bn = (pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)) % N
    offs_k = tl.arange(0, BLOCK_SIZE_K)
    return pid_m, pid_n, offs_am, offs_bn, offs_k

@triton.jit
def fp8_act_quant_inline(a_raw):
    """Inline FP8 (E4M3) activation quant for the W8A8 block-scale path.

    Per-row amax → fp32 scale ``amax/448`` (floored at 1e-12 against zero rows)
    → cast values to FP8. Returns ``(a_fp8, a_s)`` with shapes ``(M, K)`` and
    ``(M,)``.
    """
    a_s = tl.max(tl.abs(a_raw), axis=1) / 448.0
    a_fp8 = (a_raw / tl.maximum(a_s[:, None], 1e-12)).to(tl.float8e4nv)
    return a_fp8, a_s

@triton.jit
def decode_ue8m0_scale(scale):
    """Decode a UE8M0 weight scale to fp32: when it was loaded as ``uint8`` exponent
    bits, ``value = 2^(exp - 127)``, built directly as the fp32 bit pattern. fp32
    scales (block-dynamic with float scales) pass through. The dtype branch is a
    compile-time constant, so only the taken path is emitted (single return — Triton
    requires all ``return`` statements to share a type)."""
    if scale.dtype == tl.uint8:
        scale = (scale.to(tl.int32) << 23).to(tl.float32, bitcast=True)
    return scale

@triton.jit
def _store_masked(
    C,
    accumulator,
    pid_m,
    pid_n,
    M,
    N,
    stride_cm,
    stride_cn,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
):
    """Shared output epilogue of the kernels below: cast the fp32 accumulator to
    ``C``'s dtype and store the ``(BLOCK_SIZE_M, BLOCK_SIZE_N)`` tile at the swizzled
    ``(pid_m, pid_n)``, masked to the ``(M, N)`` bounds."""
    c = accumulator.to(C.dtype.element_ty)
    offs_cm = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_cn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    c_ptrs = C + stride_cm * offs_cm[:, None] + stride_cn * offs_cn[None, :]
    c_mask = (offs_cm[:, None] < M) & (offs_cn[None, :] < N)
    tl.store(c_ptrs, c, mask=c_mask)
