    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    s.ld.d       s3, [s1, #0]                    // A: device_ptr64 at arg_base+0
    s.addi       s4, s2, #0
    s.ld.d       s2, [s1, #8]                    // B: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // C: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // As: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // Bs: device_ptr64 at arg_base+32
    s.ld.sw      s8, [s1, #40]                   // M: i32 at arg_base+40
    s.ld.sw      s9, [s1, #48]                   // N: i32 at arg_base+48
    s.ld.sw      s10, [s1, #56]                  // K: i32 at arg_base+56
    s.ld.sw      s11, [s1, #64]                  // stride_am: i32 at arg_base+64
    s.ld.sw      s12, [s1, #72]                  // stride_bn: i32 at arg_base+72
    s.ld.sw      s13, [s1, #80]                  // stride_cm: i32 at arg_base+80
rows_1:
    s.movz       s1, #127
    s.movz       s14, #0
    s.add        s15, s9, s1
    s.movz       s16, #0
    s.cmp.lt     s17, s15, s14
    s.movz       s14, #128
    s.sub        s18, s16, s17
    s.movz       s16, #0
    s.movz       s17, #0
    s.cmp.lt     s19, s14, s16
    s.xor        s16, s15, s18
    s.sub        s15, s17, s19
    s.sub        s17, s16, s18
    s.xor        s16, s18, s15
    s.lshri      s18, s17, #7
    s.rdspecial  s19, pid.x
    s.xor        s20, s18, s16
    s.add        s21, s8, s1
    s.movz       s22, #0
    s.sub        s23, s20, s16
    s.movz       s16, #8
    s.movz       s20, #0
    s.cmp.lt     s24, s21, s22
    s.mul        s22, s19, s23
    s.sub        s19, s20, s24
    s.rdspecial  s20, pid.y
    s.xor        s24, s21, s19
    s.movz       s21, #0
    s.add        s25, s22, s20
    s.sub        s20, s24, s19
    s.movz       s22, #0
    s.cmp.lt     s24, s14, s21
    s.lshri      s21, s20, #7
    s.sub        s26, s22, s24
    s.muli       s22, s21, #128
    s.muli       s24, s18, #128
    s.xor        s18, s19, s26
    // rows [r0, r0 + 16) of a 128-row program (row_split)
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s19, s23, s16
    v.splat      v1, s4
    s.movz       s23, #0
    s.xor        s27, s14, s26
    s.xor        s28, s21, s18
    s.xor        s21, s14, s15
    v.add        v2, v0, v1
    s.movz       s29, #0
    s.sub        s30, s27, s26
    s.movz       s26, #0
    s.movz       s27, #0
    s.cmp.lt     s30, s19, s29
    s.cmp.lt     s29, s25, s26
    s.sub        s26, s27, s30
    s.sub        s27, s23, s29
    s.xor        s23, s19, s26
    s.xor        s29, s25, s27
    s.sub        s30, s23, s26
    s.sub        s23, s29, s27
    s.sub        s29, s20, s22
    s.movz       s20, #0
    s.movz       s22, #1
    s.addi       s29, s20, #0
    s.cmp.eq     s20, s30, s22
    s.sub        s22, s28, s18
    s.movz       s18, #0
    s.sub        s28, s21, s15
    s.sub        s15, s17, s24
    s.addi       s15, s18, #0
    s.mov        s29, s23
    br.nz        s20, sdiv_done_3
    s.movz       s17, #0
    s.movz       s18, #31
    s.mov        s29, s17
    s.addi       s17, s18, #0
sdiv_4:
    s.lshr       s18, s23, s17
    s.shli       s20, s15, #1
    s.andi       s21, s18, #1
    s.movz       s18, #0
    s.or         s24, s20, s21
    s.movz       s20, #1
    s.cmp.geu    s21, s24, s30
    s.shl        s28, s20, s17
    s.sub        s20, s18, s21
    s.subi       s18, s17, #1
    s.and        s21, s30, s20
    s.and        s31, s28, s20
    s.sub        s20, s24, s21
    s.or         s21, s29, s31
    s.mov        s15, s20
    s.mov        s29, s21
    s.mov        s17, s18
    s.movz       s18, #0
    s.cmp.ge     s20, s17, s18
    br.nz        s20, sdiv_4
sdiv_done_3:
    s.xor        s15, s27, s26
    s.movz       s17, #0
    s.xor        s18, s29, s15
    s.movz       s20, #0
    s.movz       s21, #0
    s.cmp.lt     s23, s19, s17
    s.sub        s17, s18, s15
    s.movz       s15, #0
    s.cmp.lt     s18, s25, s20
    s.sub        s20, s21, s23
    s.mul        s21, s17, s16
    s.sub        s17, s15, s18
    s.xor        s15, s19, s20
    s.xor        s18, s25, s17
    s.sub        s19, s15, s20
    s.movz       s15, #0
    s.movz       s20, #1
    s.sub        s23, s22, s21
    s.sub        s22, s18, s17
    s.movz       s18, #0
    s.addi       s24, s15, #0
    s.cmp.eq     s15, s19, s20
    s.min.s      s20, s23, s16
    s.addi       s16, s18, #0
    s.mov        s24, s22
    br.nz        s15, sdiv_done_5
    s.movz       s15, #0
    s.movz       s18, #31
    s.mov        s24, s15
    s.addi       s15, s18, #0
sdiv_6:
    s.lshr       s18, s22, s15
    s.shli       s23, s16, #1
    s.andi       s25, s18, #1
    s.movz       s18, #0
    s.or         s26, s23, s25
    s.movz       s23, #1
    s.cmp.geu    s25, s26, s19
    s.shl        s27, s23, s15
    s.sub        s23, s18, s25
    s.subi       s18, s15, #1
    s.and        s25, s19, s23
    s.and        s28, s27, s23
    s.sub        s23, s26, s25
    s.or         s25, s24, s28
    s.mov        s16, s23
    s.mov        s24, s25
    s.mov        s15, s18
    s.movz       s18, #0
    s.cmp.ge     s23, s15, s18
    br.nz        s23, sdiv_6
sdiv_done_5:
    s.xor        s15, s16, s17
    s.movz       s16, #0
    s.sub        s18, s15, s17
    s.movz       s15, #0
    s.movz       s17, #0
    s.cmp.lt     s19, s20, s16
    s.movz       s16, #0
    s.cmp.lt     s22, s18, s15
    s.sub        s15, s17, s19
    s.sub        s17, s16, s22
    s.xor        s16, s20, s15
    s.xor        s19, s18, s17
    s.sub        s22, s16, s15
    s.movz       s15, #0
    s.movz       s16, #1
    s.sub        s23, s19, s17
    s.movz       s19, #0
    s.addi       s24, s15, #0
    s.cmp.eq     s15, s22, s16
    s.addi       s16, s19, #0
    s.mov        s24, s23
    br.nz        s15, sdiv_done_7
    s.movz       s15, #0
    s.movz       s19, #31
    s.mov        s24, s15
    s.addi       s15, s19, #0
sdiv_8:
    s.lshr       s19, s23, s15
    s.shli       s25, s16, #1
    s.andi       s26, s19, #1
    s.movz       s19, #0
    s.or         s27, s25, s26
    s.movz       s25, #1
    s.cmp.geu    s26, s27, s22
    s.shl        s28, s25, s15
    s.sub        s25, s19, s26
    s.subi       s19, s15, #1
    s.and        s26, s22, s25
    s.and        s29, s28, s25
    s.sub        s25, s27, s26
    s.or         s26, s24, s29
    s.mov        s16, s25
    s.mov        s24, s26
    s.mov        s15, s19
    s.movz       s19, #0
    s.cmp.ge     s25, s15, s19
    br.nz        s25, sdiv_8
sdiv_done_7:
    s.movz       s15, #0
    s.movz       s19, #0
    s.movz       s22, #0
    s.cmp.lt     s23, s20, s15
    s.movz       s15, #0
    s.cmp.lt     s24, s18, s19
    s.sub        s19, s22, s23
    s.sub        s22, s15, s24
    s.xor        s15, s20, s19
    s.xor        s20, s16, s17
    s.xor        s16, s18, s22
    s.sub        s18, s15, s19
    s.movz       s15, #0
    s.movz       s23, #1
    s.sub        s24, s20, s17
    s.sub        s17, s16, s22
    s.movz       s16, #0
    s.addi       s20, s15, #0
    s.cmp.eq     s15, s18, s23
    s.add        s23, s21, s24
    s.addi       s21, s16, #0
    s.mov        s20, s17
    br.nz        s15, sdiv_done_9
    s.movz       s15, #0
    s.movz       s16, #31
    s.mov        s20, s15
    s.addi       s15, s16, #0
sdiv_10:
    s.lshr       s16, s17, s15
    s.shli       s24, s21, #1
    s.andi       s25, s16, #1
    s.movz       s16, #0
    s.or         s26, s24, s25
    s.movz       s24, #1
    s.cmp.geu    s25, s26, s18
    s.shl        s27, s24, s15
    s.sub        s24, s16, s25
    s.subi       s16, s15, #1
    s.and        s25, s18, s24
    s.and        s28, s27, s24
    s.sub        s24, s26, s25
    s.or         s25, s20, s28
    s.mov        s21, s24
    s.mov        s20, s25
    s.mov        s15, s16
    s.movz       s16, #0
    s.cmp.ge     s24, s15, s16
    br.nz        s24, sdiv_10
sdiv_done_9:
    s.mul        s15, s23, s14
    v.splat      v0, s8
    v.movi       v1, #0
    s.xor        s16, s22, s19
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v4, s15
    v.movi       v5, #16
    v.iota       v6                              // arange(0, VLEN)
    v.add        v7, v4, v2
    v.movi       v2, #32
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v8, #48
    v.iota       v9                              // arange(0, VLEN)
    v.movi       v10, #64
    v.iota       v11                             // arange(0, VLEN)
    v.movi       v12, #80
    v.iota       v13                             // arange(0, VLEN)
    v.movi       v14, #96
    v.iota       v15                             // arange(0, VLEN)
    v.movi       v16, #112
    s.xor        s17, s20, s16
    v.cmp.lt     p1, v7, v1
    v.cmp.lt     p2, v0, v1
    s.sub        s18, s17, s16
    v.sub        v17, v1, v7
    v.add        v18, v3, v5
    v.iota       v3                              // arange(0, VLEN)
    v.add        v5, v6, v2
    v.sub        v2, v1, v0
    v.add        v6, v4, v8
    v.add        v4, v9, v10
    v.add        v8, v11, v12
    v.add        v9, v13, v14
    v.add        v10, v15, v16
    v.splat      v11, s15
    v.splat      v11, s15
    v.splat      v11, s15
    v.splat      v11, s15
    v.splat      v11, s15
    v.splat      v11, s15
    v.splat      v11, s15
    v.splat      v11, s15
    s.add        s16, s4, s15
    v.splat      v11, s8
    v.splat      v11, s8
    v.splat      v11, s8
    v.splat      v11, s8
    v.splat      v11, s8
    v.splat      v11, s8
    v.splat      v11, s8
    v.splat      v11, s8
    v.movi       v11, #1
    @p1 v.sel        v12, v17, v7
    @p2 v.sel        v7, v2, v0
    v.movi       v0, #0
    v.movi       v2, #0
    s.movz       s15, #31
idiv_11:
    v.splat      v13, s15
    v.shl        v14, v2, v11
    v.cmp.lt     p2, v2, v1
    v.lshr       v15, v12, v13
    v.shl        v16, v11, v13
    s.subi       s17, s15, #1
    v.and        v13, v15, v11
    s.movz       s19, #0
    v.or         v15, v14, v13
    v.cmp.geu    p3, v15, v7
    p.or         p4, p2, p3
    v.sub        v13, v15, v7
    @p4 v.sel        v14, v16, v1
    @p4 v.sel        v16, v13, v15
    v.or         v13, v0, v14
    v.mov        v2, v16
    v.mov        v0, v13
    s.mov        s15, s17
    s.cmp.ge     s17, s15, s19
    br.nz        s17, idiv_11
    s.mul        s15, s18, s14
    v.splat      v0, s9
    v.movi       v7, #0
    v.sub        v11, v1, v2
    v.splat      v1, s9
    v.splat      v12, s15
    v.splat      v13, s15
    v.splat      v14, s15
    v.add        v15, v12, v3
    v.splat      v3, s15
    v.splat      v12, s15
    v.splat      v16, s15
    v.splat      v17, s15
    v.splat      v19, s15
    v.sub        v20, v7, v15
    v.sub        v21, v7, v0
    v.cmp.lt     p2, v15, v7
    v.cmp.lt     p3, v0, v7
    @p1 v.sel        v22, v11, v2
    v.add        v2, v13, v18
    v.add        v11, v14, v5
    v.add        v5, v3, v6
    v.add        v3, v12, v4
    v.add        v4, v16, v8
    v.add        v6, v17, v9
    v.add        v8, v19, v10
    v.splat      v9, s9
    v.splat      v10, s9
    v.splat      v12, s9
    v.splat      v13, s9
    v.splat      v14, s9
    v.splat      v16, s9
    v.movi       v17, #1
    @p2 v.sel        v18, v20, v15
    @p3 v.sel        v15, v21, v0
    v.movi       v0, #0
    v.movi       v19, #0
    s.movz       s17, #31
idiv_12:
    v.splat      v20, s17
    v.shl        v21, v19, v17
    v.cmp.lt     p1, v19, v7
    v.lshr       v23, v18, v20
    v.shl        v24, v17, v20
    s.subi       s18, s17, #1
    v.and        v20, v23, v17
    s.movz       s19, #0
    v.or         v23, v21, v20
    v.cmp.geu    p3, v23, v15
    p.or         p4, p1, p3
    v.sub        v20, v23, v15
    @p4 v.sel        v21, v24, v7
    @p4 v.sel        v24, v20, v23
    v.or         v20, v0, v21
    v.mov        v19, v24
    v.mov        v0, v20
    s.mov        s17, s18
    s.cmp.ge     s18, s17, s19
    br.nz        s18, idiv_12
    v.movi       v0, #0
    v.sub        v15, v7, v19
    v.movi       v7, #1
    v.sub        v17, v0, v2
    v.sub        v18, v0, v1
    v.cmp.lt     p1, v2, v0
    v.cmp.lt     p3, v1, v0
    @p2 v.sel        v20, v15, v19
    @p1 v.sel        v15, v17, v2
    @p3 v.sel        v2, v18, v1
    v.movi       v1, #0
    v.movi       v17, #0
    s.movz       s17, #31
idiv_13:
    v.splat      v18, s17
    v.shl        v19, v17, v7
    v.cmp.lt     p2, v17, v0
    v.lshr       v21, v15, v18
    v.shl        v23, v7, v18
    s.subi       s18, s17, #1
    v.and        v18, v21, v7
    s.movz       s19, #0
    v.or         v21, v19, v18
    v.cmp.geu    p3, v21, v2
    p.or         p4, p2, p3
    v.sub        v18, v21, v2
    @p4 v.sel        v19, v23, v0
    @p4 v.sel        v23, v18, v21
    v.or         v18, v1, v19
    v.mov        v17, v23
    v.mov        v1, v18
    s.mov        s17, s18
    s.cmp.ge     s18, s17, s19
    br.nz        s18, idiv_13
    v.movi       v1, #0
    v.sub        v2, v0, v17
    v.movi       v0, #1
    v.sub        v7, v1, v11
    v.sub        v15, v1, v9
    v.cmp.lt     p2, v11, v1
    v.cmp.lt     p3, v9, v1
    @p1 v.sel        v18, v2, v17
    @p2 v.sel        v2, v7, v11
    @p3 v.sel        v7, v15, v9
    v.movi       v9, #0
    v.movi       v11, #0
    s.movz       s17, #31
idiv_14:
    v.splat      v15, s17
    v.shl        v17, v11, v0
    v.cmp.lt     p1, v11, v1
    v.lshr       v19, v2, v15
    v.shl        v21, v0, v15
    s.subi       s18, s17, #1
    v.and        v15, v19, v0
    s.movz       s19, #0
    v.or         v19, v17, v15
    v.cmp.geu    p3, v19, v7
    p.or         p4, p1, p3
    v.sub        v15, v19, v7
    @p4 v.sel        v17, v21, v1
    @p4 v.sel        v21, v15, v19
    v.or         v15, v9, v17
    v.mov        v11, v21
    v.mov        v9, v15
    s.mov        s17, s18
    s.cmp.ge     s18, s17, s19
    br.nz        s18, idiv_14
    v.movi       v0, #0
    v.sub        v2, v1, v11
    v.movi       v1, #1
    v.sub        v7, v0, v5
    v.sub        v9, v0, v10
    v.cmp.lt     p1, v5, v0
    v.cmp.lt     p3, v10, v0
    @p2 v.sel        v15, v2, v11
    @p1 v.sel        v2, v7, v5
    @p3 v.sel        v5, v9, v10
    v.movi       v7, #0
    v.movi       v9, #0
    s.movz       s17, #31
idiv_15:
    v.splat      v10, s17
    v.shl        v11, v9, v1
    v.cmp.lt     p2, v9, v0
    v.lshr       v17, v2, v10
    v.shl        v19, v1, v10
    s.subi       s18, s17, #1
    v.and        v10, v17, v1
    s.movz       s19, #0
    v.or         v17, v11, v10
    v.cmp.geu    p3, v17, v5
    p.or         p4, p2, p3
    v.sub        v10, v17, v5
    @p4 v.sel        v11, v19, v0
    @p4 v.sel        v19, v10, v17
    v.or         v10, v7, v11
    v.mov        v9, v19
    v.mov        v7, v10
    s.mov        s17, s18
    s.cmp.ge     s18, s17, s19
    br.nz        s18, idiv_15
    v.movi       v1, #0
    v.sub        v2, v0, v9
    v.movi       v0, #1
    v.sub        v5, v1, v3
    v.sub        v7, v1, v12
    v.cmp.lt     p2, v3, v1
    v.cmp.lt     p3, v12, v1
    @p1 v.sel        v10, v2, v9
    @p2 v.sel        v2, v5, v3
    @p3 v.sel        v3, v7, v12
    v.movi       v5, #0
    v.movi       v7, #0
    s.movz       s17, #31
idiv_16:
    v.splat      v9, s17
    v.shl        v11, v7, v0
    v.cmp.lt     p1, v7, v1
    v.lshr       v12, v2, v9
    v.shl        v17, v0, v9
    s.subi       s18, s17, #1
    v.and        v9, v12, v0
    s.movz       s19, #0
    v.or         v12, v11, v9
    v.cmp.geu    p3, v12, v3
    p.or         p4, p1, p3
    v.sub        v9, v12, v3
    @p4 v.sel        v11, v17, v1
    @p4 v.sel        v17, v9, v12
    v.or         v9, v5, v11
    v.mov        v7, v17
    v.mov        v5, v9
    s.mov        s17, s18
    s.cmp.ge     s18, s17, s19
    br.nz        s18, idiv_16
    v.movi       v0, #0
    v.sub        v2, v1, v7
    v.movi       v1, #1
    v.sub        v3, v0, v4
    v.sub        v5, v0, v13
    v.cmp.lt     p1, v4, v0
    v.cmp.lt     p3, v13, v0
    @p2 v.sel        v9, v2, v7
    @p1 v.sel        v2, v3, v4
    @p3 v.sel        v3, v5, v13
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s17, #31
idiv_17:
    v.splat      v7, s17
    v.shl        v11, v5, v1
    v.cmp.lt     p2, v5, v0
    v.lshr       v12, v2, v7
    v.shl        v13, v1, v7
    s.subi       s18, s17, #1
    v.and        v7, v12, v1
    s.movz       s19, #0
    v.or         v12, v11, v7
    v.cmp.geu    p3, v12, v3
    p.or         p4, p2, p3
    v.sub        v7, v12, v3
    @p4 v.sel        v11, v13, v0
    @p4 v.sel        v13, v7, v12
    v.or         v7, v4, v11
    v.mov        v5, v13
    v.mov        v4, v7
    s.mov        s17, s18
    s.cmp.ge     s18, s17, s19
    br.nz        s18, idiv_17
    v.movi       v1, #0
    v.sub        v2, v0, v5
    v.movi       v0, #1
    v.sub        v3, v1, v6
    v.sub        v4, v1, v14
    v.cmp.lt     p2, v6, v1
    v.cmp.lt     p3, v14, v1
    @p1 v.sel        v7, v2, v5
    @p2 v.sel        v2, v3, v6
    @p3 v.sel        v3, v4, v14
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s17, #31
idiv_18:
    v.splat      v6, s17
    v.shl        v11, v5, v0
    v.cmp.lt     p1, v5, v1
    v.lshr       v12, v2, v6
    v.shl        v13, v0, v6
    s.subi       s18, s17, #1
    v.and        v6, v12, v0
    s.movz       s19, #0
    v.or         v12, v11, v6
    v.cmp.geu    p3, v12, v3
    p.or         p4, p1, p3
    v.sub        v6, v12, v3
    @p4 v.sel        v11, v13, v1
    @p4 v.sel        v13, v6, v12
    v.or         v6, v4, v11
    v.mov        v5, v13
    v.mov        v4, v6
    s.mov        s17, s18
    s.cmp.ge     s18, s17, s19
    br.nz        s18, idiv_18
    v.movi       v0, #0
    v.sub        v2, v1, v5
    v.movi       v1, #1
    v.sub        v3, v0, v8
    v.sub        v4, v0, v16
    v.cmp.lt     p1, v8, v0
    v.cmp.lt     p3, v16, v0
    @p2 v.sel        v6, v2, v5
    @p1 v.sel        v2, v3, v8
    @p3 v.sel        v3, v4, v16
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s17, #31
idiv_19:
    v.splat      v8, s17
    v.shl        v11, v5, v1
    v.cmp.lt     p2, v5, v0
    v.lshr       v12, v2, v8
    v.shl        v13, v1, v8
    s.subi       s18, s17, #1
    v.and        v8, v12, v1
    s.movz       s19, #0
    v.or         v12, v11, v8
    v.cmp.geu    p3, v12, v3
    p.or         p4, p2, p3
    v.sub        v8, v12, v3
    @p4 v.sel        v11, v13, v0
    @p4 v.sel        v13, v8, v12
    v.or         v8, v4, v11
    v.mov        v5, v13
    v.mov        v4, v8
    s.mov        s17, s18
    s.cmp.ge     s18, s17, s19
    br.nz        s18, idiv_19
    s.add        s17, s10, s1
    s.movz       s1, #0
    s.movz       s18, #0
    s.cmp.lt     s19, s17, s1
    s.movz       s1, #0
    s.sub        s20, s18, s19
    s.movz       s18, #0
    s.xor        s19, s17, s20
    s.cmp.lt     s17, s14, s1
    s.sub        s1, s19, s20
    s.sub        s19, s18, s17
    s.lshri      s17, s1, #7
    s.xor        s18, s20, s19
    s.muli       s20, s17, #128
    v.sub        v1, v0, v5
    s.xor        s21, s14, s19
    s.xor        s22, s17, s18
    s.movz       s17, #0
    s.movz       s23, #0
    s.movz       s24, #0
    @p1 v.sel        v0, v1, v5
    s.movz       s25, #16
    s.movz       s26, #32
    s.movz       s27, #48
    s.movz       s28, #64
    s.movz       s29, #80
    s.movz       s30, #96
    s.movz       s31, #112
    v.ld.gather.w v1, [s6, v22]                  // index is in elements (ISA sec 9.1)
    s.sub        s32, s21, s19
    s.sub        s19, s1, s20
    s.sub        s1, s22, s18
    s.movz       s18, #1
    s.addi       s19, s17, #0
    s.addi       s20, s23, #0
    s.addi       s21, s24, #0
    s.ld.w       s22, [s7, #0]                   // one element, not a vector
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_20:
    s.cmp.ge     s23, s19, s1
    br.nz        s23, endfor_21
    s.mul        s23, s19, s14
    s.sub        s24, s10, s23
    v.splat      v2, s12
    v.mul        v3, v20, v2
    v.splat      v2, s12
    v.mul        v4, v18, v2
    v.splat      v2, s12
    v.mul        v5, v15, v2
    v.splat      v2, s12
    v.mul        v8, v10, v2
    v.splat      v2, s12
    v.mul        v11, v9, v2
    v.splat      v2, s12
    v.mul        v12, v7, v2
    v.splat      v2, s12
    v.mul        v13, v6, v2
    v.splat      v2, s12
    v.mul        v14, v0, v2
    s.add        s23, s17, s24
    // tl.dot 16x128 by 128x128 FP8 as (B^T A^T)^T: B^T rows are contiguous loads, A is scattered into the MMA B operand
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s32, #16
    v.splat      v16, s32
    v.mul        v17, v2, v16
    v.iota       v2                              // arange(0, VLEN)
    v.movi       v16, #7
    v.and        v19, v2, v16
    v.movi       v2, #2
    v.shl        v16, v19, v2
    v.iota       v2                              // arange(0, VLEN)
    v.movi       v19, #3
    v.lshr       v21, v2, v19
    v.movi       v2, #0
    v.cmp.eq     p1, v21, v2
    v.iota       v2                              // arange(0, VLEN)
    v.movi       v19, #3
    v.lshr       v21, v2, v19
    v.movi       v2, #1
    v.cmp.eq     p2, v21, v2
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    s.rdspecial  s32, arg_base
    s.ld.d       s33, [s32, #88]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.addi       s32, s33, #0                    // 512 bytes of repack scratch
    v.splat      v2, s11
    v.mul        v19, v22, v2
    v.extract    s34, v19, #0
    s.add        s35, s34, s20
    s.add        s34, s3, s35
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s35, #0
    s.add        s36, s35, s24                   // the tile origin
    v.splat      v21, s36
    v.cmp.lt     p3, v2, v21
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s34, #0]
    s.addi       s34, s32, #0
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #1
    s.add        s35, s34, s20
    s.add        s34, s3, s35
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s34, #0]
    s.addi       s34, s32, #1
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #2
    s.add        s35, s34, s20
    s.add        s34, s3, s35
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s34, #0]
    s.addi       s34, s32, #2
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #3
    s.add        s35, s34, s20
    s.add        s34, s3, s35
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s34, #0]
    s.addi       s34, s32, #3
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #4
    s.add        s35, s34, s20
    s.add        s34, s3, s35
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s34, #0]
    s.addi       s34, s32, #4
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #5
    s.add        s35, s34, s20
    s.add        s34, s3, s35
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s34, #0]
    s.addi       s34, s32, #5
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #6
    s.add        s35, s34, s20
    s.add        s34, s3, s35
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s34, #0]
    s.addi       s34, s32, #6
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #7
    s.add        s35, s34, s20
    s.add        s34, s3, s35
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s34, #0]
    s.addi       s34, s32, #7
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #8
    s.add        s35, s34, s20
    s.add        s34, s3, s35
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s34, #0]
    s.addi       s34, s32, #8
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #9
    s.add        s35, s34, s20
    s.add        s34, s3, s35
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s34, #0]
    s.addi       s34, s32, #9
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #10
    s.add        s35, s34, s20
    s.add        s34, s3, s35
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s34, #0]
    s.addi       s34, s32, #10
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #11
    s.add        s35, s34, s20
    s.add        s34, s3, s35
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s34, #0]
    s.addi       s34, s32, #11
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #12
    s.add        s35, s34, s20
    s.add        s34, s3, s35
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s34, #0]
    s.addi       s34, s32, #12
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #13
    s.add        s35, s34, s20
    s.add        s34, s3, s35
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s34, #0]
    s.addi       s34, s32, #13
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #14
    s.add        s35, s34, s20
    s.add        s34, s3, s35
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s34, #0]
    s.addi       s34, s32, #14
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #15
    s.add        s35, s34, s20
    s.add        s34, s3, s35
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s34, #0]
    s.addi       s34, s32, #15
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #0
    s.add        s35, s34, s20
    s.addi       s34, s35, #16
    s.add        s35, s3, s34
    s.movz       s34, #0
    s.add        s36, s34, s25                   // the tile origin
    v.splat      v21, s36
    v.add        v23, v2, v21
    s.movz       s34, #0
    s.add        s36, s34, s24                   // the tile origin
    v.splat      v21, s36
    v.cmp.lt     p3, v23, v21
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s35, #0]
    s.addi       s34, s32, #256
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #1
    s.add        s35, s34, s20
    s.addi       s34, s35, #16
    s.add        s35, s3, s34
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s35, #0]
    s.addi       s34, s32, #257
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #2
    s.add        s35, s34, s20
    s.addi       s34, s35, #16
    s.add        s35, s3, s34
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s35, #0]
    s.addi       s34, s32, #258
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #3
    s.add        s35, s34, s20
    s.addi       s34, s35, #16
    s.add        s35, s3, s34
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s35, #0]
    s.addi       s34, s32, #259
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #4
    s.add        s35, s34, s20
    s.addi       s34, s35, #16
    s.add        s35, s3, s34
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s35, #0]
    s.addi       s34, s32, #260
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #5
    s.add        s35, s34, s20
    s.addi       s34, s35, #16
    s.add        s35, s3, s34
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s35, #0]
    s.addi       s34, s32, #261
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #6
    s.add        s35, s34, s20
    s.addi       s34, s35, #16
    s.add        s35, s3, s34
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s35, #0]
    s.addi       s34, s32, #262
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #7
    s.add        s35, s34, s20
    s.addi       s34, s35, #16
    s.add        s35, s3, s34
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s35, #0]
    s.addi       s34, s32, #263
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #8
    s.add        s35, s34, s20
    s.addi       s34, s35, #16
    s.add        s35, s3, s34
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s35, #0]
    s.addi       s34, s32, #264
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #9
    s.add        s35, s34, s20
    s.addi       s34, s35, #16
    s.add        s35, s3, s34
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s35, #0]
    s.addi       s34, s32, #265
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #10
    s.add        s35, s34, s20
    s.addi       s34, s35, #16
    s.add        s35, s3, s34
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s35, #0]
    s.addi       s34, s32, #266
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #11
    s.add        s35, s34, s20
    s.addi       s34, s35, #16
    s.add        s35, s3, s34
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s35, #0]
    s.addi       s34, s32, #267
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #12
    s.add        s35, s34, s20
    s.addi       s34, s35, #16
    s.add        s35, s3, s34
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s35, #0]
    s.addi       s34, s32, #268
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #13
    s.add        s35, s34, s20
    s.addi       s34, s35, #16
    s.add        s35, s3, s34
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s35, #0]
    s.addi       s34, s32, #269
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #14
    s.add        s35, s34, s20
    s.addi       s34, s35, #16
    s.add        s35, s3, s34
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s35, #0]
    s.addi       s34, s32, #270
    v.st.scatter.b [s34, v17], v21
    v.extract    s34, v19, #15
    s.add        s35, s34, s20
    s.addi       s34, s35, #16
    s.add        s35, s3, s34
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s35, #0]
    s.addi       s34, s32, #271
    v.st.scatter.b [s34, v17], v21
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    v.ld.w       v21, [s32, #0]
    v.mov        v48, v21                        // hand off through the shared window (sec 7.3)
    s.addi       s34, s32, #64
    v.ld.w       v21, [s34, #0]
    v.mov        v49, v21                        // hand off through the shared window (sec 7.3)
    s.addi       s34, s32, #128
    v.ld.w       v21, [s34, #0]
    v.mov        v50, v21                        // hand off through the shared window (sec 7.3)
    s.addi       s34, s32, #192
    v.ld.w       v21, [s34, #0]
    v.mov        v51, v21                        // hand off through the shared window (sec 7.3)
    s.addi       s34, s32, #256
    v.ld.w       v21, [s34, #0]
    v.mov        v52, v21                        // hand off through the shared window (sec 7.3)
    s.addi       s34, s32, #320
    v.ld.w       v21, [s34, #0]
    v.mov        v53, v21                        // hand off through the shared window (sec 7.3)
    s.addi       s34, s32, #384
    v.ld.w       v21, [s34, #0]
    v.mov        v54, v21                        // hand off through the shared window (sec 7.3)
    s.addi       s34, s32, #448
    v.ld.w       v21, [s34, #0]
    v.mov        v55, v21                        // hand off through the shared window (sec 7.3)
    s.addi       s32, s23, #0
    v.splat      v21, s32
    v.sub        v23, v21, v16
    v.movi       v21, #0
    v.cmp.gt     p3, v23, v21
    v.movi       v21, #0
    v.max.s      v24, v23, v21
    v.movi       v21, #4
    v.min.s      v23, v24, v21
    v.movi       v21, #1
    v.movi       v24, #3
    v.shl        v25, v23, v24
    v.shl        v24, v21, v25
    v.movi       v21, #1
    v.sub        v25, v24, v21
    v.movi       v21, #4
    v.cmp.ge     p4, v23, v21
    v.movi       v21, #-1
    @p4 v.sel        v23, v21, v25
    s.add        s32, s2, s21
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s34, v3, #0
    s.add        s35, s32, s34
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s35, #0]
    v.extract    s34, v3, #1
    s.add        s35, s32, s34
    s.addi       s34, s35, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s34, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v56, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s34, v3, #2
    s.add        s35, s32, s34
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s35, #0]
    v.extract    s34, v3, #3
    s.add        s35, s32, s34
    s.addi       s34, s35, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s34, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v57, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s34, v3, #4
    s.add        s35, s32, s34
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s35, #0]
    v.extract    s34, v3, #5
    s.add        s35, s32, s34
    s.addi       s34, s35, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s34, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v58, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s34, v3, #6
    s.add        s35, s32, s34
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s35, #0]
    v.extract    s34, v3, #7
    s.add        s35, s32, s34
    s.addi       s34, s35, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s34, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v59, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s34, v3, #8
    s.add        s35, s32, s34
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s35, #0]
    v.extract    s34, v3, #9
    s.add        s35, s32, s34
    s.addi       s34, s35, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s34, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v60, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s34, v3, #10
    s.add        s35, s32, s34
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s35, #0]
    v.extract    s34, v3, #11
    s.add        s35, s32, s34
    s.addi       s34, s35, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s34, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v61, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s34, v3, #12
    s.add        s35, s32, s34
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s35, #0]
    v.extract    s34, v3, #13
    s.add        s35, s32, s34
    s.addi       s34, s35, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s34, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v62, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s34, v3, #14
    s.add        s35, s32, s34
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s35, #0]
    v.extract    s34, v3, #15
    s.add        s35, s32, s34
    s.addi       s32, s35, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s32, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v63, v21                        // hand off through the shared window (sec 7.3)
    mb.arm       s32, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a8, v56, v48, s32
    mb.wait      s32
    s.add        s34, s2, s21
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s35, v4, #0
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s36, #0]
    v.extract    s35, v4, #1
    s.add        s36, s34, s35
    s.addi       s35, s36, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s35, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v56, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s35, v4, #2
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s36, #0]
    v.extract    s35, v4, #3
    s.add        s36, s34, s35
    s.addi       s35, s36, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s35, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v57, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s35, v4, #4
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s36, #0]
    v.extract    s35, v4, #5
    s.add        s36, s34, s35
    s.addi       s35, s36, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s35, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v58, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s35, v4, #6
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s36, #0]
    v.extract    s35, v4, #7
    s.add        s36, s34, s35
    s.addi       s35, s36, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s35, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v59, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s35, v4, #8
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s36, #0]
    v.extract    s35, v4, #9
    s.add        s36, s34, s35
    s.addi       s35, s36, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s35, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v60, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s35, v4, #10
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s36, #0]
    v.extract    s35, v4, #11
    s.add        s36, s34, s35
    s.addi       s35, s36, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s35, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v61, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s35, v4, #12
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s36, #0]
    v.extract    s35, v4, #13
    s.add        s36, s34, s35
    s.addi       s35, s36, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s35, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v62, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s35, v4, #14
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s36, #0]
    v.extract    s35, v4, #15
    s.add        s36, s34, s35
    s.addi       s34, s36, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s34, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v63, v21                        // hand off through the shared window (sec 7.3)
    mb.arm       s34, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a9, v56, v48, s34
    mb.wait      s34
    s.add        s35, s2, s21
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s36, v5, #0
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s37, #0]
    v.extract    s36, v5, #1
    s.add        s37, s35, s36
    s.addi       s36, s37, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s36, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v56, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s36, v5, #2
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s37, #0]
    v.extract    s36, v5, #3
    s.add        s37, s35, s36
    s.addi       s36, s37, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s36, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v57, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s36, v5, #4
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s37, #0]
    v.extract    s36, v5, #5
    s.add        s37, s35, s36
    s.addi       s36, s37, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s36, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v58, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s36, v5, #6
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s37, #0]
    v.extract    s36, v5, #7
    s.add        s37, s35, s36
    s.addi       s36, s37, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s36, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v59, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s36, v5, #8
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s37, #0]
    v.extract    s36, v5, #9
    s.add        s37, s35, s36
    s.addi       s36, s37, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s36, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v60, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s36, v5, #10
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s37, #0]
    v.extract    s36, v5, #11
    s.add        s37, s35, s36
    s.addi       s36, s37, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s36, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v61, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s36, v5, #12
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s37, #0]
    v.extract    s36, v5, #13
    s.add        s37, s35, s36
    s.addi       s36, s37, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s36, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v62, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s36, v5, #14
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s37, #0]
    v.extract    s36, v5, #15
    s.add        s37, s35, s36
    s.addi       s35, s37, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s35, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v63, v21                        // hand off through the shared window (sec 7.3)
    mb.arm       s35, b2, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a10, v56, v48, s35
    mb.wait      s35
    s.add        s36, s2, s21
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s37, v8, #0
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s38, #0]
    v.extract    s37, v8, #1
    s.add        s38, s36, s37
    s.addi       s37, s38, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s37, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v56, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v8, #2
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s38, #0]
    v.extract    s37, v8, #3
    s.add        s38, s36, s37
    s.addi       s37, s38, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s37, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v57, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v8, #4
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s38, #0]
    v.extract    s37, v8, #5
    s.add        s38, s36, s37
    s.addi       s37, s38, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s37, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v58, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v8, #6
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s38, #0]
    v.extract    s37, v8, #7
    s.add        s38, s36, s37
    s.addi       s37, s38, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s37, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v59, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v8, #8
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s38, #0]
    v.extract    s37, v8, #9
    s.add        s38, s36, s37
    s.addi       s37, s38, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s37, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v60, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v8, #10
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s38, #0]
    v.extract    s37, v8, #11
    s.add        s38, s36, s37
    s.addi       s37, s38, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s37, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v61, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v8, #12
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s38, #0]
    v.extract    s37, v8, #13
    s.add        s38, s36, s37
    s.addi       s37, s38, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s37, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v62, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v8, #14
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s38, #0]
    v.extract    s37, v8, #15
    s.add        s38, s36, s37
    s.addi       s36, s38, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s36, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v63, v21                        // hand off through the shared window (sec 7.3)
    mb.arm       s36, b3, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a11, v56, v48, s36
    mb.wait      s36
    s.add        s37, s2, s21
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s38, v11, #0
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s39, #0]
    v.extract    s38, v11, #1
    s.add        s39, s37, s38
    s.addi       s38, s39, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s38, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v56, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v11, #2
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s39, #0]
    v.extract    s38, v11, #3
    s.add        s39, s37, s38
    s.addi       s38, s39, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s38, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v57, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v11, #4
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s39, #0]
    v.extract    s38, v11, #5
    s.add        s39, s37, s38
    s.addi       s38, s39, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s38, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v58, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v11, #6
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s39, #0]
    v.extract    s38, v11, #7
    s.add        s39, s37, s38
    s.addi       s38, s39, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s38, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v59, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v11, #8
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s39, #0]
    v.extract    s38, v11, #9
    s.add        s39, s37, s38
    s.addi       s38, s39, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s38, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v60, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v11, #10
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s39, #0]
    v.extract    s38, v11, #11
    s.add        s39, s37, s38
    s.addi       s38, s39, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s38, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v61, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v11, #12
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s39, #0]
    v.extract    s38, v11, #13
    s.add        s39, s37, s38
    s.addi       s38, s39, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s38, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v62, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v11, #14
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s39, #0]
    v.extract    s38, v11, #15
    s.add        s39, s37, s38
    s.addi       s37, s39, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s37, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v63, v21                        // hand off through the shared window (sec 7.3)
    mb.arm       s37, b4, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a12, v56, v48, s37
    mb.wait      s37
    s.add        s38, s2, s21
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s39, v12, #0
    s.add        s40, s38, s39
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s40, #0]
    v.extract    s39, v12, #1
    s.add        s40, s38, s39
    s.addi       s39, s40, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s39, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v56, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v12, #2
    s.add        s40, s38, s39
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s40, #0]
    v.extract    s39, v12, #3
    s.add        s40, s38, s39
    s.addi       s39, s40, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s39, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v57, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v12, #4
    s.add        s40, s38, s39
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s40, #0]
    v.extract    s39, v12, #5
    s.add        s40, s38, s39
    s.addi       s39, s40, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s39, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v58, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v12, #6
    s.add        s40, s38, s39
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s40, #0]
    v.extract    s39, v12, #7
    s.add        s40, s38, s39
    s.addi       s39, s40, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s39, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v59, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v12, #8
    s.add        s40, s38, s39
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s40, #0]
    v.extract    s39, v12, #9
    s.add        s40, s38, s39
    s.addi       s39, s40, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s39, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v60, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v12, #10
    s.add        s40, s38, s39
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s40, #0]
    v.extract    s39, v12, #11
    s.add        s40, s38, s39
    s.addi       s39, s40, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s39, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v61, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v12, #12
    s.add        s40, s38, s39
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s40, #0]
    v.extract    s39, v12, #13
    s.add        s40, s38, s39
    s.addi       s39, s40, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s39, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v62, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v12, #14
    s.add        s40, s38, s39
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s40, #0]
    v.extract    s39, v12, #15
    s.add        s40, s38, s39
    s.addi       s38, s40, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s38, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v63, v21                        // hand off through the shared window (sec 7.3)
    mb.arm       s38, b5, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a13, v56, v48, s38
    mb.wait      s38
    s.add        s39, s2, s21
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s40, v13, #0
    s.add        s41, s39, s40
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s41, #0]
    v.extract    s40, v13, #1
    s.add        s41, s39, s40
    s.addi       s40, s41, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s40, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v56, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v13, #2
    s.add        s41, s39, s40
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s41, #0]
    v.extract    s40, v13, #3
    s.add        s41, s39, s40
    s.addi       s40, s41, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s40, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v57, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v13, #4
    s.add        s41, s39, s40
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s41, #0]
    v.extract    s40, v13, #5
    s.add        s41, s39, s40
    s.addi       s40, s41, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s40, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v58, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v13, #6
    s.add        s41, s39, s40
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s41, #0]
    v.extract    s40, v13, #7
    s.add        s41, s39, s40
    s.addi       s40, s41, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s40, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v59, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v13, #8
    s.add        s41, s39, s40
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s41, #0]
    v.extract    s40, v13, #9
    s.add        s41, s39, s40
    s.addi       s40, s41, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s40, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v60, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v13, #10
    s.add        s41, s39, s40
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s41, #0]
    v.extract    s40, v13, #11
    s.add        s41, s39, s40
    s.addi       s40, s41, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s40, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v61, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v13, #12
    s.add        s41, s39, s40
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s41, #0]
    v.extract    s40, v13, #13
    s.add        s41, s39, s40
    s.addi       s40, s41, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s40, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v62, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v13, #14
    s.add        s41, s39, s40
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s41, #0]
    v.extract    s40, v13, #15
    s.add        s41, s39, s40
    s.addi       s39, s41, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s39, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v63, v21                        // hand off through the shared window (sec 7.3)
    mb.arm       s39, b6, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a14, v56, v48, s39
    mb.wait      s39
    s.add        s40, s2, s21
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s41, v14, #0
    s.add        s42, s40, s41
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s42, #0]
    v.extract    s41, v14, #1
    s.add        s42, s40, s41
    s.addi       s41, s42, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s41, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v56, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v14, #2
    s.add        s42, s40, s41
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s42, #0]
    v.extract    s41, v14, #3
    s.add        s42, s40, s41
    s.addi       s41, s42, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s41, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v57, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v14, #4
    s.add        s42, s40, s41
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s42, #0]
    v.extract    s41, v14, #5
    s.add        s42, s40, s41
    s.addi       s41, s42, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s41, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v58, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v14, #6
    s.add        s42, s40, s41
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s42, #0]
    v.extract    s41, v14, #7
    s.add        s42, s40, s41
    s.addi       s41, s42, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s41, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v59, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v14, #8
    s.add        s42, s40, s41
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s42, #0]
    v.extract    s41, v14, #9
    s.add        s42, s40, s41
    s.addi       s41, s42, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s41, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v60, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v14, #10
    s.add        s42, s40, s41
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s42, #0]
    v.extract    s41, v14, #11
    s.add        s42, s40, s41
    s.addi       s41, s42, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s41, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v61, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v14, #12
    s.add        s42, s40, s41
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s42, #0]
    v.extract    s41, v14, #13
    s.add        s42, s40, s41
    s.addi       s41, s42, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s41, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v62, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v14, #14
    s.add        s42, s40, s41
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s42, #0]
    v.extract    s41, v14, #15
    s.add        s42, s40, s41
    s.addi       s40, s42, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s40, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v63, v21                        // hand off through the shared window (sec 7.3)
    mb.arm       s40, b7, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a15, v56, v48, s40
    mb.wait      s40
    s.addi       s41, s33, #512                  // 512 bytes of repack scratch
    v.extract    s42, v19, #0
    s.add        s43, s42, s20
    s.addi       s42, s43, #32
    s.add        s43, s3, s42
    s.movz       s42, #0
    s.add        s44, s42, s26                   // the tile origin
    v.splat      v21, s44
    v.add        v23, v2, v21
    s.movz       s42, #0
    s.add        s44, s42, s24                   // the tile origin
    v.splat      v21, s44
    v.cmp.lt     p3, v23, v21
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #0
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #1
    s.add        s43, s42, s20
    s.addi       s42, s43, #32
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #1
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #2
    s.add        s43, s42, s20
    s.addi       s42, s43, #32
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #2
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #3
    s.add        s43, s42, s20
    s.addi       s42, s43, #32
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #3
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #4
    s.add        s43, s42, s20
    s.addi       s42, s43, #32
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #4
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #5
    s.add        s43, s42, s20
    s.addi       s42, s43, #32
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #5
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #6
    s.add        s43, s42, s20
    s.addi       s42, s43, #32
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #6
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #7
    s.add        s43, s42, s20
    s.addi       s42, s43, #32
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #7
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #8
    s.add        s43, s42, s20
    s.addi       s42, s43, #32
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #8
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #9
    s.add        s43, s42, s20
    s.addi       s42, s43, #32
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #9
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #10
    s.add        s43, s42, s20
    s.addi       s42, s43, #32
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #10
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #11
    s.add        s43, s42, s20
    s.addi       s42, s43, #32
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #11
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #12
    s.add        s43, s42, s20
    s.addi       s42, s43, #32
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #12
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #13
    s.add        s43, s42, s20
    s.addi       s42, s43, #32
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #13
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #14
    s.add        s43, s42, s20
    s.addi       s42, s43, #32
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #14
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #15
    s.add        s43, s42, s20
    s.addi       s42, s43, #32
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #15
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #0
    s.add        s43, s42, s20
    s.addi       s42, s43, #48
    s.add        s43, s3, s42
    s.movz       s42, #0
    s.add        s44, s42, s27                   // the tile origin
    v.splat      v21, s44
    v.add        v23, v2, v21
    s.movz       s42, #0
    s.add        s44, s42, s24                   // the tile origin
    v.splat      v21, s44
    v.cmp.lt     p3, v23, v21
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #256
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #1
    s.add        s43, s42, s20
    s.addi       s42, s43, #48
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #257
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #2
    s.add        s43, s42, s20
    s.addi       s42, s43, #48
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #258
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #3
    s.add        s43, s42, s20
    s.addi       s42, s43, #48
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #259
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #4
    s.add        s43, s42, s20
    s.addi       s42, s43, #48
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #260
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #5
    s.add        s43, s42, s20
    s.addi       s42, s43, #48
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #261
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #6
    s.add        s43, s42, s20
    s.addi       s42, s43, #48
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #262
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #7
    s.add        s43, s42, s20
    s.addi       s42, s43, #48
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #263
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #8
    s.add        s43, s42, s20
    s.addi       s42, s43, #48
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #264
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #9
    s.add        s43, s42, s20
    s.addi       s42, s43, #48
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #265
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #10
    s.add        s43, s42, s20
    s.addi       s42, s43, #48
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #266
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #11
    s.add        s43, s42, s20
    s.addi       s42, s43, #48
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #267
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #12
    s.add        s43, s42, s20
    s.addi       s42, s43, #48
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #268
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #13
    s.add        s43, s42, s20
    s.addi       s42, s43, #48
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #269
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #14
    s.add        s43, s42, s20
    s.addi       s42, s43, #48
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #270
    v.st.scatter.b [s42, v17], v21
    v.extract    s42, v19, #15
    s.add        s43, s42, s20
    s.addi       s42, s43, #48
    s.add        s43, s3, s42
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s43, #0]
    s.addi       s42, s41, #271
    v.st.scatter.b [s42, v17], v21
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    v.ld.w       v21, [s41, #0]
    v.mov        v48, v21                        // hand off through the shared window (sec 7.3)
    s.addi       s42, s41, #64
    v.ld.w       v21, [s42, #0]
    v.mov        v49, v21                        // hand off through the shared window (sec 7.3)
    s.addi       s42, s41, #128
    v.ld.w       v21, [s42, #0]
    v.mov        v50, v21                        // hand off through the shared window (sec 7.3)
    s.addi       s42, s41, #192
    v.ld.w       v21, [s42, #0]
    v.mov        v51, v21                        // hand off through the shared window (sec 7.3)
    s.addi       s42, s41, #256
    v.ld.w       v21, [s42, #0]
    v.mov        v52, v21                        // hand off through the shared window (sec 7.3)
    s.addi       s42, s41, #320
    v.ld.w       v21, [s42, #0]
    v.mov        v53, v21                        // hand off through the shared window (sec 7.3)
    s.addi       s42, s41, #384
    v.ld.w       v21, [s42, #0]
    v.mov        v54, v21                        // hand off through the shared window (sec 7.3)
    s.addi       s42, s41, #448
    v.ld.w       v21, [s42, #0]
    v.mov        v55, v21                        // hand off through the shared window (sec 7.3)
    s.addi       s41, s23, #-32
    v.splat      v21, s41
    v.sub        v23, v21, v16
    v.movi       v21, #0
    v.cmp.gt     p3, v23, v21
    v.movi       v21, #0
    v.max.s      v24, v23, v21
    v.movi       v21, #4
    v.min.s      v23, v24, v21
    v.movi       v21, #1
    v.movi       v24, #3
    v.shl        v25, v23, v24
    v.shl        v24, v21, v25
    v.movi       v21, #1
    v.sub        v25, v24, v21
    v.movi       v21, #4
    v.cmp.ge     p4, v23, v21
    v.movi       v21, #-1
    @p4 v.sel        v23, v21, v25
    s.addi       s41, s21, #32
    s.add        s42, s2, s41
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s41, v3, #0
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s43, #0]
    v.extract    s41, v3, #1
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s41, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v56, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v3, #2
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s43, #0]
    v.extract    s41, v3, #3
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s41, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v57, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v3, #4
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s43, #0]
    v.extract    s41, v3, #5
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s41, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v58, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v3, #6
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s43, #0]
    v.extract    s41, v3, #7
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s41, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v59, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v3, #8
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s43, #0]
    v.extract    s41, v3, #9
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s41, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v60, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v3, #10
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s43, #0]
    v.extract    s41, v3, #11
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s41, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v61, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v3, #12
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s43, #0]
    v.extract    s41, v3, #13
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s41, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v62, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v3, #14
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s43, #0]
    v.extract    s41, v3, #15
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s41, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v63, v21                        // hand off through the shared window (sec 7.3)
    mb.arm       s41, b8, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a8, v56, v48, s41
    mb.wait      s41
    s.addi       s42, s21, #32
    s.add        s43, s2, s42
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s42, v4, #0
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s44, #0]
    v.extract    s42, v4, #1
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s42, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v56, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s42, v4, #2
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s44, #0]
    v.extract    s42, v4, #3
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s42, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v57, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s42, v4, #4
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s44, #0]
    v.extract    s42, v4, #5
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s42, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v58, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s42, v4, #6
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s44, #0]
    v.extract    s42, v4, #7
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s42, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v59, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s42, v4, #8
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s44, #0]
    v.extract    s42, v4, #9
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s42, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v60, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s42, v4, #10
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s44, #0]
    v.extract    s42, v4, #11
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s42, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v61, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s42, v4, #12
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s44, #0]
    v.extract    s42, v4, #13
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s42, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v62, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s42, v4, #14
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s44, #0]
    v.extract    s42, v4, #15
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s42, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v63, v21                        // hand off through the shared window (sec 7.3)
    mb.arm       s42, b9, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a9, v56, v48, s42
    mb.wait      s42
    s.addi       s43, s21, #32
    s.add        s44, s2, s43
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s43, v5, #0
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s45, #0]
    v.extract    s43, v5, #1
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s43, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v56, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s43, v5, #2
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s45, #0]
    v.extract    s43, v5, #3
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s43, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v57, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s43, v5, #4
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s45, #0]
    v.extract    s43, v5, #5
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s43, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v58, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s43, v5, #6
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s45, #0]
    v.extract    s43, v5, #7
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s43, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v59, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s43, v5, #8
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s45, #0]
    v.extract    s43, v5, #9
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s43, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v60, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s43, v5, #10
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s45, #0]
    v.extract    s43, v5, #11
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s43, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v61, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s43, v5, #12
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s45, #0]
    v.extract    s43, v5, #13
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s43, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v62, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s43, v5, #14
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s45, #0]
    v.extract    s43, v5, #15
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s43, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v63, v21                        // hand off through the shared window (sec 7.3)
    mb.arm       s43, b10, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a10, v56, v48, s43
    mb.wait      s43
    s.addi       s44, s21, #32
    s.add        s45, s2, s44
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s44, v8, #0
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s46, #0]
    v.extract    s44, v8, #1
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s44, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v56, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s44, v8, #2
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s46, #0]
    v.extract    s44, v8, #3
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s44, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v57, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s44, v8, #4
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s46, #0]
    v.extract    s44, v8, #5
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s44, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v58, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s44, v8, #6
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s46, #0]
    v.extract    s44, v8, #7
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s44, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v59, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s44, v8, #8
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s46, #0]
    v.extract    s44, v8, #9
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s44, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v60, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s44, v8, #10
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s46, #0]
    v.extract    s44, v8, #11
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s44, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v61, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s44, v8, #12
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s46, #0]
    v.extract    s44, v8, #13
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s44, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v62, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s44, v8, #14
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s46, #0]
    v.extract    s44, v8, #15
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s44, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v63, v21                        // hand off through the shared window (sec 7.3)
    mb.arm       s44, b11, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a11, v56, v48, s44
    mb.wait      s44
    s.addi       s45, s21, #32
    s.add        s46, s2, s45
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s45, v11, #0
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s47, #0]
    v.extract    s45, v11, #1
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s45, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v56, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s45, v11, #2
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s47, #0]
    v.extract    s45, v11, #3
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s45, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v57, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s45, v11, #4
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s47, #0]
    v.extract    s45, v11, #5
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s45, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v58, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s45, v11, #6
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s47, #0]
    v.extract    s45, v11, #7
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s45, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v59, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s45, v11, #8
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s47, #0]
    v.extract    s45, v11, #9
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s45, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v60, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s45, v11, #10
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s47, #0]
    v.extract    s45, v11, #11
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s45, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v61, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s45, v11, #12
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s47, #0]
    v.extract    s45, v11, #13
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s45, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v62, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s45, v11, #14
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s47, #0]
    v.extract    s45, v11, #15
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s45, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v63, v21                        // hand off through the shared window (sec 7.3)
    mb.arm       s45, b12, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a12, v56, v48, s45
    mb.wait      s45
    s.addi       s46, s21, #32
    s.add        s47, s2, s46
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s46, v12, #0
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s48, #0]
    v.extract    s46, v12, #1
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s46, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v56, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s46, v12, #2
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s48, #0]
    v.extract    s46, v12, #3
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s46, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v57, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s46, v12, #4
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s48, #0]
    v.extract    s46, v12, #5
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s46, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v58, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s46, v12, #6
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s48, #0]
    v.extract    s46, v12, #7
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s46, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v59, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s46, v12, #8
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s48, #0]
    v.extract    s46, v12, #9
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s46, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v60, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s46, v12, #10
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s48, #0]
    v.extract    s46, v12, #11
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s46, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v61, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s46, v12, #12
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s48, #0]
    v.extract    s46, v12, #13
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s46, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v62, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s46, v12, #14
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s48, #0]
    v.extract    s46, v12, #15
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s46, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v63, v21                        // hand off through the shared window (sec 7.3)
    mb.arm       s46, b13, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a13, v56, v48, s46
    mb.wait      s46
    s.addi       s47, s21, #32
    s.add        s48, s2, s47
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s47, v13, #0
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s49, #0]
    v.extract    s47, v13, #1
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s47, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v56, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s47, v13, #2
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s49, #0]
    v.extract    s47, v13, #3
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s47, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v57, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s47, v13, #4
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s49, #0]
    v.extract    s47, v13, #5
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s47, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v58, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s47, v13, #6
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s49, #0]
    v.extract    s47, v13, #7
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s47, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v59, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s47, v13, #8
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s49, #0]
    v.extract    s47, v13, #9
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s47, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v60, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s47, v13, #10
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s49, #0]
    v.extract    s47, v13, #11
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s47, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v61, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s47, v13, #12
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s49, #0]
    v.extract    s47, v13, #13
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s47, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v62, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s47, v13, #14
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s49, #0]
    v.extract    s47, v13, #15
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s47, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v63, v21                        // hand off through the shared window (sec 7.3)
    mb.arm       s47, b14, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a14, v56, v48, s47
    mb.wait      s47
    s.addi       s48, s21, #32
    s.add        s49, s2, s48
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s48, v14, #0
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s50, #0]
    v.extract    s48, v14, #1
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s48, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v56, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s48, v14, #2
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s50, #0]
    v.extract    s48, v14, #3
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s48, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v57, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s48, v14, #4
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s50, #0]
    v.extract    s48, v14, #5
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s48, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v58, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s48, v14, #6
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s50, #0]
    v.extract    s48, v14, #7
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s48, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v59, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s48, v14, #8
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s50, #0]
    v.extract    s48, v14, #9
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s48, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v60, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s48, v14, #10
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s50, #0]
    v.extract    s48, v14, #11
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s48, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v61, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s48, v14, #12
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s50, #0]
    v.extract    s48, v14, #13
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s48, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v62, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s48, v14, #14
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s50, #0]
    v.extract    s48, v14, #15
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s48, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v63, v21                        // hand off through the shared window (sec 7.3)
    mb.arm       s48, b15, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a15, v56, v48, s48
    mb.wait      s48
    s.addi       s49, s33, #1024                 // 512 bytes of repack scratch
    v.extract    s50, v19, #0
    s.add        s51, s50, s20
    s.addi       s50, s51, #64
    s.add        s51, s3, s50
    s.movz       s50, #0
    s.add        s52, s50, s28                   // the tile origin
    v.splat      v21, s52
    v.add        v23, v2, v21
    s.movz       s50, #0
    s.add        s52, s50, s24                   // the tile origin
    v.splat      v21, s52
    v.cmp.lt     p3, v23, v21
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #0
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #1
    s.add        s51, s50, s20
    s.addi       s50, s51, #64
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #1
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #2
    s.add        s51, s50, s20
    s.addi       s50, s51, #64
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #2
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #3
    s.add        s51, s50, s20
    s.addi       s50, s51, #64
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #3
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #4
    s.add        s51, s50, s20
    s.addi       s50, s51, #64
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #4
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #5
    s.add        s51, s50, s20
    s.addi       s50, s51, #64
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #5
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #6
    s.add        s51, s50, s20
    s.addi       s50, s51, #64
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #6
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #7
    s.add        s51, s50, s20
    s.addi       s50, s51, #64
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #7
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #8
    s.add        s51, s50, s20
    s.addi       s50, s51, #64
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #8
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #9
    s.add        s51, s50, s20
    s.addi       s50, s51, #64
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #9
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #10
    s.add        s51, s50, s20
    s.addi       s50, s51, #64
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #10
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #11
    s.add        s51, s50, s20
    s.addi       s50, s51, #64
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #11
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #12
    s.add        s51, s50, s20
    s.addi       s50, s51, #64
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #12
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #13
    s.add        s51, s50, s20
    s.addi       s50, s51, #64
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #13
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #14
    s.add        s51, s50, s20
    s.addi       s50, s51, #64
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #14
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #15
    s.add        s51, s50, s20
    s.addi       s50, s51, #64
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #15
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #0
    s.add        s51, s50, s20
    s.addi       s50, s51, #80
    s.add        s51, s3, s50
    s.movz       s50, #0
    s.add        s52, s50, s29                   // the tile origin
    v.splat      v21, s52
    v.add        v23, v2, v21
    s.movz       s50, #0
    s.add        s52, s50, s24                   // the tile origin
    v.splat      v21, s52
    v.cmp.lt     p3, v23, v21
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #256
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #1
    s.add        s51, s50, s20
    s.addi       s50, s51, #80
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #257
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #2
    s.add        s51, s50, s20
    s.addi       s50, s51, #80
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #258
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #3
    s.add        s51, s50, s20
    s.addi       s50, s51, #80
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #259
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #4
    s.add        s51, s50, s20
    s.addi       s50, s51, #80
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #260
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #5
    s.add        s51, s50, s20
    s.addi       s50, s51, #80
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #261
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #6
    s.add        s51, s50, s20
    s.addi       s50, s51, #80
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #262
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #7
    s.add        s51, s50, s20
    s.addi       s50, s51, #80
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #263
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #8
    s.add        s51, s50, s20
    s.addi       s50, s51, #80
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #264
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #9
    s.add        s51, s50, s20
    s.addi       s50, s51, #80
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #265
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #10
    s.add        s51, s50, s20
    s.addi       s50, s51, #80
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #266
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #11
    s.add        s51, s50, s20
    s.addi       s50, s51, #80
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #267
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #12
    s.add        s51, s50, s20
    s.addi       s50, s51, #80
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #268
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #13
    s.add        s51, s50, s20
    s.addi       s50, s51, #80
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #269
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #14
    s.add        s51, s50, s20
    s.addi       s50, s51, #80
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #270
    v.st.scatter.b [s50, v17], v21
    v.extract    s50, v19, #15
    s.add        s51, s50, s20
    s.addi       s50, s51, #80
    s.add        s51, s3, s50
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s51, #0]
    s.addi       s50, s49, #271
    v.st.scatter.b [s50, v17], v21
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    v.ld.w       v21, [s49, #0]
    v.mov        v48, v21                        // hand off through the shared window (sec 7.3)
    s.addi       s50, s49, #64
    v.ld.w       v21, [s50, #0]
    v.mov        v49, v21                        // hand off through the shared window (sec 7.3)
    s.addi       s50, s49, #128
    v.ld.w       v21, [s50, #0]
    v.mov        v50, v21                        // hand off through the shared window (sec 7.3)
    s.addi       s50, s49, #192
    v.ld.w       v21, [s50, #0]
    v.mov        v51, v21                        // hand off through the shared window (sec 7.3)
    s.addi       s50, s49, #256
    v.ld.w       v21, [s50, #0]
    v.mov        v52, v21                        // hand off through the shared window (sec 7.3)
    s.addi       s50, s49, #320
    v.ld.w       v21, [s50, #0]
    v.mov        v53, v21                        // hand off through the shared window (sec 7.3)
    s.addi       s50, s49, #384
    v.ld.w       v21, [s50, #0]
    v.mov        v54, v21                        // hand off through the shared window (sec 7.3)
    s.addi       s50, s49, #448
    v.ld.w       v21, [s50, #0]
    v.mov        v55, v21                        // hand off through the shared window (sec 7.3)
    s.addi       s49, s23, #-64
    v.splat      v21, s49
    v.sub        v23, v21, v16
    v.movi       v21, #0
    v.cmp.gt     p3, v23, v21
    v.movi       v21, #0
    v.max.s      v24, v23, v21
    v.movi       v21, #4
    v.min.s      v23, v24, v21
    v.movi       v21, #1
    v.movi       v24, #3
    v.shl        v25, v23, v24
    v.shl        v24, v21, v25
    v.movi       v21, #1
    v.sub        v25, v24, v21
    v.movi       v21, #4
    v.cmp.ge     p4, v23, v21
    v.movi       v21, #-1
    @p4 v.sel        v23, v21, v25
    s.addi       s49, s21, #64
    s.add        s50, s2, s49
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s49, v3, #0
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s51, #0]
    v.extract    s49, v3, #1
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s49, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v56, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s49, v3, #2
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s51, #0]
    v.extract    s49, v3, #3
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s49, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v57, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s49, v3, #4
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s51, #0]
    v.extract    s49, v3, #5
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s49, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v58, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s49, v3, #6
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s51, #0]
    v.extract    s49, v3, #7
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s49, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v59, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s49, v3, #8
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s51, #0]
    v.extract    s49, v3, #9
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s49, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v60, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s49, v3, #10
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s51, #0]
    v.extract    s49, v3, #11
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s49, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v61, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s49, v3, #12
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s51, #0]
    v.extract    s49, v3, #13
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s49, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v62, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s49, v3, #14
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s51, #0]
    v.extract    s49, v3, #15
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s49, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v63, v21                        // hand off through the shared window (sec 7.3)
    mb.arm       s49, b16, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a8, v56, v48, s49
    mb.wait      s49
    s.addi       s50, s21, #64
    s.add        s51, s2, s50
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s50, v4, #0
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s52, #0]
    v.extract    s50, v4, #1
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s50, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v56, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s50, v4, #2
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s52, #0]
    v.extract    s50, v4, #3
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s50, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v57, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s50, v4, #4
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s52, #0]
    v.extract    s50, v4, #5
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s50, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v58, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s50, v4, #6
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s52, #0]
    v.extract    s50, v4, #7
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s50, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v59, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s50, v4, #8
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s52, #0]
    v.extract    s50, v4, #9
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s50, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v60, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s50, v4, #10
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s52, #0]
    v.extract    s50, v4, #11
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s50, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v61, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s50, v4, #12
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s52, #0]
    v.extract    s50, v4, #13
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s50, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v62, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s50, v4, #14
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s52, #0]
    v.extract    s50, v4, #15
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s50, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v63, v21                        // hand off through the shared window (sec 7.3)
    mb.arm       s50, b17, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a9, v56, v48, s50
    mb.wait      s50
    s.addi       s51, s21, #64
    s.add        s52, s2, s51
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s51, v5, #0
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s53, #0]
    v.extract    s51, v5, #1
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s51, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v56, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s51, v5, #2
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s53, #0]
    v.extract    s51, v5, #3
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s51, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v57, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s51, v5, #4
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s53, #0]
    v.extract    s51, v5, #5
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s51, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v58, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s51, v5, #6
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s53, #0]
    v.extract    s51, v5, #7
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s51, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v59, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s51, v5, #8
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s53, #0]
    v.extract    s51, v5, #9
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s51, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v60, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s51, v5, #10
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s53, #0]
    v.extract    s51, v5, #11
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s51, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v61, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s51, v5, #12
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s53, #0]
    v.extract    s51, v5, #13
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s51, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v62, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s51, v5, #14
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s53, #0]
    v.extract    s51, v5, #15
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s51, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v63, v21                        // hand off through the shared window (sec 7.3)
    mb.arm       s51, b18, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a10, v56, v48, s51
    mb.wait      s51
    s.addi       s52, s21, #64
    s.add        s53, s2, s52
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s52, v8, #0
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s54, #0]
    v.extract    s52, v8, #1
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s52, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v56, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s52, v8, #2
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s54, #0]
    v.extract    s52, v8, #3
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s52, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v57, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s52, v8, #4
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s54, #0]
    v.extract    s52, v8, #5
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s52, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v58, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s52, v8, #6
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s54, #0]
    v.extract    s52, v8, #7
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s52, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v59, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s52, v8, #8
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s54, #0]
    v.extract    s52, v8, #9
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s52, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v60, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s52, v8, #10
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s54, #0]
    v.extract    s52, v8, #11
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s52, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v61, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s52, v8, #12
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s54, #0]
    v.extract    s52, v8, #13
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s52, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v62, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s52, v8, #14
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s54, #0]
    v.extract    s52, v8, #15
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s52, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v63, v21                        // hand off through the shared window (sec 7.3)
    mb.arm       s52, b19, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a11, v56, v48, s52
    mb.wait      s52
    s.addi       s53, s21, #64
    s.add        s54, s2, s53
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s53, v11, #0
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s55, #0]
    v.extract    s53, v11, #1
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s53, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v56, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s53, v11, #2
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s55, #0]
    v.extract    s53, v11, #3
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s53, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v57, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s53, v11, #4
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s55, #0]
    v.extract    s53, v11, #5
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s53, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v58, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s53, v11, #6
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s55, #0]
    v.extract    s53, v11, #7
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s53, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v59, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s53, v11, #8
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s55, #0]
    v.extract    s53, v11, #9
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s53, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v60, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s53, v11, #10
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s55, #0]
    v.extract    s53, v11, #11
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s53, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v61, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s53, v11, #12
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s55, #0]
    v.extract    s53, v11, #13
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s53, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v62, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s53, v11, #14
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s55, #0]
    v.extract    s53, v11, #15
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s53, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v63, v21                        // hand off through the shared window (sec 7.3)
    mb.arm       s53, b20, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a12, v56, v48, s53
    mb.wait      s53
    s.addi       s54, s21, #64
    s.add        s55, s2, s54
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s54, v12, #0
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s56, #0]
    v.extract    s54, v12, #1
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s54, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v56, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s54, v12, #2
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s56, #0]
    v.extract    s54, v12, #3
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s54, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v57, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s54, v12, #4
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s56, #0]
    v.extract    s54, v12, #5
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s54, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v58, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s54, v12, #6
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s56, #0]
    v.extract    s54, v12, #7
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s54, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v59, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s54, v12, #8
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s56, #0]
    v.extract    s54, v12, #9
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s54, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v60, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s54, v12, #10
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s56, #0]
    v.extract    s54, v12, #11
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s54, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v61, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s54, v12, #12
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s56, #0]
    v.extract    s54, v12, #13
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s54, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v62, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s54, v12, #14
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s56, #0]
    v.extract    s54, v12, #15
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s54, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v63, v21                        // hand off through the shared window (sec 7.3)
    mb.arm       s54, b21, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a13, v56, v48, s54
    mb.wait      s54
    s.addi       s55, s21, #64
    s.add        s56, s2, s55
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s55, v13, #0
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s57, #0]
    v.extract    s55, v13, #1
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s55, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v56, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s55, v13, #2
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s57, #0]
    v.extract    s55, v13, #3
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s55, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v57, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s55, v13, #4
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s57, #0]
    v.extract    s55, v13, #5
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s55, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v58, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s55, v13, #6
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s57, #0]
    v.extract    s55, v13, #7
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s55, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v59, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s55, v13, #8
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s57, #0]
    v.extract    s55, v13, #9
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s55, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v60, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s55, v13, #10
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s57, #0]
    v.extract    s55, v13, #11
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s55, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v61, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s55, v13, #12
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s57, #0]
    v.extract    s55, v13, #13
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s55, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v62, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s55, v13, #14
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s57, #0]
    v.extract    s55, v13, #15
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s55, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v63, v21                        // hand off through the shared window (sec 7.3)
    mb.arm       s55, b22, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a14, v56, v48, s55
    mb.wait      s55
    s.addi       s56, s21, #64
    s.add        s57, s2, s56
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s56, v14, #0
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s58, #0]
    v.extract    s56, v14, #1
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s56, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v56, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s56, v14, #2
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s58, #0]
    v.extract    s56, v14, #3
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s56, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v57, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s56, v14, #4
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s58, #0]
    v.extract    s56, v14, #5
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s56, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v58, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s56, v14, #6
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s58, #0]
    v.extract    s56, v14, #7
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s56, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v59, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s56, v14, #8
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s58, #0]
    v.extract    s56, v14, #9
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s56, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v60, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s56, v14, #10
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s58, #0]
    v.extract    s56, v14, #11
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s56, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v61, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s56, v14, #12
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s58, #0]
    v.extract    s56, v14, #13
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s56, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v62, v21                        // hand off through the shared window (sec 7.3)
    v.extract    s56, v14, #14
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s58, #0]
    v.extract    s56, v14, #15
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s56, #0]
    v.or         v25, v21, v24
    v.and        v21, v25, v23
    v.mov        v63, v21                        // hand off through the shared window (sec 7.3)
    mb.arm       s56, b23, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a15, v56, v48, s56
    mb.wait      s56
    s.addi       s57, s33, #1536                 // 512 bytes of repack scratch
    v.extract    s58, v19, #0
    s.add        s59, s58, s20
    s.addi       s58, s59, #96
    s.add        s59, s3, s58
    s.movz       s58, #0
    s.add        s60, s58, s30                   // the tile origin
    v.splat      v21, s60
    v.add        v23, v2, v21
    s.movz       s58, #0
    s.add        s60, s58, s24                   // the tile origin
    v.splat      v21, s60
    v.cmp.lt     p3, v23, v21
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s59, #0]
    s.addi       s58, s57, #0
    v.st.scatter.b [s58, v17], v21
    v.extract    s58, v19, #1
    s.add        s59, s58, s20
    s.addi       s58, s59, #96
    s.add        s59, s3, s58
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s59, #0]
    s.addi       s58, s57, #1
    v.st.scatter.b [s58, v17], v21
    v.extract    s58, v19, #2
    s.add        s59, s58, s20
    s.addi       s58, s59, #96
    s.add        s59, s3, s58
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s59, #0]
    s.addi       s58, s57, #2
    v.st.scatter.b [s58, v17], v21
    v.extract    s58, v19, #3
    s.add        s59, s58, s20
    s.addi       s58, s59, #96
    s.add        s59, s3, s58
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s59, #0]
    s.addi       s58, s57, #3
    v.st.scatter.b [s58, v17], v21
    v.extract    s58, v19, #4
    s.add        s59, s58, s20
    s.addi       s58, s59, #96
    s.add        s59, s3, s58
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s59, #0]
    s.addi       s58, s57, #4
    v.st.scatter.b [s58, v17], v21
    v.extract    s58, v19, #5
    s.add        s59, s58, s20
    s.addi       s58, s59, #96
    s.add        s59, s3, s58
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s59, #0]
    s.addi       s58, s57, #5
    v.st.scatter.b [s58, v17], v21
    v.extract    s58, v19, #6
    s.add        s59, s58, s20
    s.addi       s58, s59, #96
    s.add        s59, s3, s58
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s59, #0]
    s.addi       s58, s57, #6
    v.st.scatter.b [s58, v17], v21
    v.extract    s58, v19, #7
    s.add        s59, s58, s20
    s.addi       s58, s59, #96
    s.add        s59, s3, s58
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s59, #0]
    s.addi       s58, s57, #7
    v.st.scatter.b [s58, v17], v21
    v.extract    s58, v19, #8
    s.add        s59, s58, s20
    s.addi       s58, s59, #96
    s.add        s59, s3, s58
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s59, #0]
    s.addi       s58, s57, #8
    v.st.scatter.b [s58, v17], v21
    v.extract    s58, v19, #9
    s.add        s59, s58, s20
    s.addi       s58, s59, #96
    s.add        s59, s3, s58
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s59, #0]
    s.addi       s58, s57, #9
    v.st.scatter.b [s58, v17], v21
    v.extract    s58, v19, #10
    s.add        s59, s58, s20
    s.addi       s58, s59, #96
    s.add        s59, s3, s58
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s59, #0]
    s.addi       s58, s57, #10
    v.st.scatter.b [s58, v17], v21
    v.extract    s58, v19, #11
    s.add        s59, s58, s20
    s.addi       s58, s59, #96
    s.add        s59, s3, s58
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s59, #0]
    s.addi       s58, s57, #11
    v.st.scatter.b [s58, v17], v21
    v.extract    s58, v19, #12
    s.add        s59, s58, s20
    s.addi       s58, s59, #96
    s.add        s59, s3, s58
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s59, #0]
    s.addi       s58, s57, #12
    v.st.scatter.b [s58, v17], v21
    v.extract    s58, v19, #13
    s.add        s59, s58, s20
    s.addi       s58, s59, #96
    s.add        s59, s3, s58
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s59, #0]
    s.addi       s58, s57, #13
    v.st.scatter.b [s58, v17], v21
    v.extract    s58, v19, #14
    s.add        s59, s58, s20
    s.addi       s58, s59, #96
    s.add        s59, s3, s58
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s59, #0]
    s.addi       s58, s57, #14
    v.st.scatter.b [s58, v17], v21
    v.extract    s58, v19, #15
    s.add        s59, s58, s20
    s.addi       s58, s59, #96
    s.add        s59, s3, s58
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v21, [s59, #0]
    s.addi       s58, s57, #15
    v.st.scatter.b [s58, v17], v21
    v.extract    s58, v19, #0
    s.add        s59, s58, s20
    s.addi       s58, s59, #112
    s.add        s59, s3, s58
    s.movz       s58, #0
    s.add        s60, s58, s31                   // the tile origin
    v.splat      v21, s60
    v.add        v23, v2, v21
    s.movz       s58, #0
    s.add        s60, s58, s24                   // the tile origin
    v.splat      v2, s60
    v.cmp.lt     p3, v23, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s59, #0]
    s.addi       s24, s57, #256
    v.st.scatter.b [s24, v17], v2
    v.extract    s24, v19, #1
    s.add        s58, s24, s20
    s.addi       s24, s58, #112
    s.add        s58, s3, s24
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s58, #0]
    s.addi       s24, s57, #257
    v.st.scatter.b [s24, v17], v2
    v.extract    s24, v19, #2
    s.add        s58, s24, s20
    s.addi       s24, s58, #112
    s.add        s58, s3, s24
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s58, #0]
    s.addi       s24, s57, #258
    v.st.scatter.b [s24, v17], v2
    v.extract    s24, v19, #3
    s.add        s58, s24, s20
    s.addi       s24, s58, #112
    s.add        s58, s3, s24
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s58, #0]
    s.addi       s24, s57, #259
    v.st.scatter.b [s24, v17], v2
    v.extract    s24, v19, #4
    s.add        s58, s24, s20
    s.addi       s24, s58, #112
    s.add        s58, s3, s24
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s58, #0]
    s.addi       s24, s57, #260
    v.st.scatter.b [s24, v17], v2
    v.extract    s24, v19, #5
    s.add        s58, s24, s20
    s.addi       s24, s58, #112
    s.add        s58, s3, s24
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s58, #0]
    s.addi       s24, s57, #261
    v.st.scatter.b [s24, v17], v2
    v.extract    s24, v19, #6
    s.add        s58, s24, s20
    s.addi       s24, s58, #112
    s.add        s58, s3, s24
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s58, #0]
    s.addi       s24, s57, #262
    v.st.scatter.b [s24, v17], v2
    v.extract    s24, v19, #7
    s.add        s58, s24, s20
    s.addi       s24, s58, #112
    s.add        s58, s3, s24
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s58, #0]
    s.addi       s24, s57, #263
    v.st.scatter.b [s24, v17], v2
    v.extract    s24, v19, #8
    s.add        s58, s24, s20
    s.addi       s24, s58, #112
    s.add        s58, s3, s24
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s58, #0]
    s.addi       s24, s57, #264
    v.st.scatter.b [s24, v17], v2
    v.extract    s24, v19, #9
    s.add        s58, s24, s20
    s.addi       s24, s58, #112
    s.add        s58, s3, s24
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s58, #0]
    s.addi       s24, s57, #265
    v.st.scatter.b [s24, v17], v2
    v.extract    s24, v19, #10
    s.add        s58, s24, s20
    s.addi       s24, s58, #112
    s.add        s58, s3, s24
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s58, #0]
    s.addi       s24, s57, #266
    v.st.scatter.b [s24, v17], v2
    v.extract    s24, v19, #11
    s.add        s58, s24, s20
    s.addi       s24, s58, #112
    s.add        s58, s3, s24
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s58, #0]
    s.addi       s24, s57, #267
    v.st.scatter.b [s24, v17], v2
    v.extract    s24, v19, #12
    s.add        s58, s24, s20
    s.addi       s24, s58, #112
    s.add        s58, s3, s24
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s58, #0]
    s.addi       s24, s57, #268
    v.st.scatter.b [s24, v17], v2
    v.extract    s24, v19, #13
    s.add        s58, s24, s20
    s.addi       s24, s58, #112
    s.add        s58, s3, s24
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s58, #0]
    s.addi       s24, s57, #269
    v.st.scatter.b [s24, v17], v2
    v.extract    s24, v19, #14
    s.add        s58, s24, s20
    s.addi       s24, s58, #112
    s.add        s58, s3, s24
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s58, #0]
    s.addi       s24, s57, #270
    v.st.scatter.b [s24, v17], v2
    v.extract    s24, v19, #15
    s.add        s58, s24, s20
    s.addi       s24, s58, #112
    s.add        s58, s3, s24
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s58, #0]
    s.addi       s24, s57, #271
    v.st.scatter.b [s24, v17], v2
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    v.ld.w       v2, [s57, #0]
    v.mov        v48, v2                         // hand off through the shared window (sec 7.3)
    s.addi       s24, s57, #64
    v.ld.w       v2, [s24, #0]
    v.mov        v49, v2                         // hand off through the shared window (sec 7.3)
    s.addi       s24, s57, #128
    v.ld.w       v2, [s24, #0]
    v.mov        v50, v2                         // hand off through the shared window (sec 7.3)
    s.addi       s24, s57, #192
    v.ld.w       v2, [s24, #0]
    v.mov        v51, v2                         // hand off through the shared window (sec 7.3)
    s.addi       s24, s57, #256
    v.ld.w       v2, [s24, #0]
    v.mov        v52, v2                         // hand off through the shared window (sec 7.3)
    s.addi       s24, s57, #320
    v.ld.w       v2, [s24, #0]
    v.mov        v53, v2                         // hand off through the shared window (sec 7.3)
    s.addi       s24, s57, #384
    v.ld.w       v2, [s24, #0]
    v.mov        v54, v2                         // hand off through the shared window (sec 7.3)
    s.addi       s24, s57, #448
    v.ld.w       v2, [s24, #0]
    v.mov        v55, v2                         // hand off through the shared window (sec 7.3)
    s.addi       s24, s23, #-96
    v.splat      v2, s24
    v.sub        v19, v2, v16
    v.movi       v2, #0
    v.cmp.gt     p3, v19, v2
    v.movi       v2, #0
    v.max.s      v16, v19, v2
    v.movi       v2, #4
    v.min.s      v19, v16, v2
    v.movi       v2, #1
    v.movi       v16, #3
    v.shl        v21, v19, v16
    v.shl        v16, v2, v21
    v.movi       v2, #1
    v.sub        v21, v16, v2
    v.movi       v2, #4
    v.cmp.ge     p4, v19, v2
    v.movi       v2, #-1
    @p4 v.sel        v16, v2, v21
    s.addi       s23, s21, #96
    s.add        s24, s2, s23
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s23, v3, #0
    s.add        s57, s24, s23
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s57, #0]
    v.extract    s23, v3, #1
    s.add        s57, s24, s23
    s.addi       s23, s57, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s23, #0]
    v.or         v21, v2, v19
    v.and        v2, v21, v16
    v.mov        v56, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s23, v3, #2
    s.add        s57, s24, s23
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s57, #0]
    v.extract    s23, v3, #3
    s.add        s57, s24, s23
    s.addi       s23, s57, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s23, #0]
    v.or         v21, v2, v19
    v.and        v2, v21, v16
    v.mov        v57, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s23, v3, #4
    s.add        s57, s24, s23
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s57, #0]
    v.extract    s23, v3, #5
    s.add        s57, s24, s23
    s.addi       s23, s57, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s23, #0]
    v.or         v21, v2, v19
    v.and        v2, v21, v16
    v.mov        v58, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s23, v3, #6
    s.add        s57, s24, s23
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s57, #0]
    v.extract    s23, v3, #7
    s.add        s57, s24, s23
    s.addi       s23, s57, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s23, #0]
    v.or         v21, v2, v19
    v.and        v2, v21, v16
    v.mov        v59, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s23, v3, #8
    s.add        s57, s24, s23
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s57, #0]
    v.extract    s23, v3, #9
    s.add        s57, s24, s23
    s.addi       s23, s57, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s23, #0]
    v.or         v21, v2, v19
    v.and        v2, v21, v16
    v.mov        v60, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s23, v3, #10
    s.add        s57, s24, s23
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s57, #0]
    v.extract    s23, v3, #11
    s.add        s57, s24, s23
    s.addi       s23, s57, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s23, #0]
    v.or         v21, v2, v19
    v.and        v2, v21, v16
    v.mov        v61, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s23, v3, #12
    s.add        s57, s24, s23
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s57, #0]
    v.extract    s23, v3, #13
    s.add        s57, s24, s23
    s.addi       s23, s57, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s23, #0]
    v.or         v21, v2, v19
    v.and        v2, v21, v16
    v.mov        v62, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s23, v3, #14
    s.add        s57, s24, s23
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s57, #0]
    v.extract    s23, v3, #15
    s.add        s57, s24, s23
    s.addi       s23, s57, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s23, #0]
    v.or         v19, v2, v3
    v.and        v2, v19, v16
    v.mov        v63, v2                         // hand off through the shared window (sec 7.3)
    mb.arm       s23, b24, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a8, v56, v48, s23
    mb.wait      s23
    s.addi       s24, s21, #96
    s.add        s57, s2, s24
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s24, v4, #0
    s.add        s58, s57, s24
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s58, #0]
    v.extract    s24, v4, #1
    s.add        s58, s57, s24
    s.addi       s24, s58, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s24, #0]
    v.or         v19, v2, v3
    v.and        v2, v19, v16
    v.mov        v56, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s24, v4, #2
    s.add        s58, s57, s24
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s58, #0]
    v.extract    s24, v4, #3
    s.add        s58, s57, s24
    s.addi       s24, s58, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s24, #0]
    v.or         v19, v2, v3
    v.and        v2, v19, v16
    v.mov        v57, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s24, v4, #4
    s.add        s58, s57, s24
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s58, #0]
    v.extract    s24, v4, #5
    s.add        s58, s57, s24
    s.addi       s24, s58, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s24, #0]
    v.or         v19, v2, v3
    v.and        v2, v19, v16
    v.mov        v58, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s24, v4, #6
    s.add        s58, s57, s24
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s58, #0]
    v.extract    s24, v4, #7
    s.add        s58, s57, s24
    s.addi       s24, s58, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s24, #0]
    v.or         v19, v2, v3
    v.and        v2, v19, v16
    v.mov        v59, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s24, v4, #8
    s.add        s58, s57, s24
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s58, #0]
    v.extract    s24, v4, #9
    s.add        s58, s57, s24
    s.addi       s24, s58, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s24, #0]
    v.or         v19, v2, v3
    v.and        v2, v19, v16
    v.mov        v60, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s24, v4, #10
    s.add        s58, s57, s24
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s58, #0]
    v.extract    s24, v4, #11
    s.add        s58, s57, s24
    s.addi       s24, s58, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s24, #0]
    v.or         v19, v2, v3
    v.and        v2, v19, v16
    v.mov        v61, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s24, v4, #12
    s.add        s58, s57, s24
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s58, #0]
    v.extract    s24, v4, #13
    s.add        s58, s57, s24
    s.addi       s24, s58, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s24, #0]
    v.or         v19, v2, v3
    v.and        v2, v19, v16
    v.mov        v62, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s24, v4, #14
    s.add        s58, s57, s24
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s58, #0]
    v.extract    s24, v4, #15
    s.add        s58, s57, s24
    s.addi       s24, s58, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s24, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v63, v2                         // hand off through the shared window (sec 7.3)
    mb.arm       s24, b25, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a9, v56, v48, s24
    mb.wait      s24
    s.addi       s57, s21, #96
    s.add        s58, s2, s57
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s57, v5, #0
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s59, #0]
    v.extract    s57, v5, #1
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s57, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v56, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s57, v5, #2
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s59, #0]
    v.extract    s57, v5, #3
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s57, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v57, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s57, v5, #4
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s59, #0]
    v.extract    s57, v5, #5
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s57, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v58, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s57, v5, #6
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s59, #0]
    v.extract    s57, v5, #7
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s57, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v59, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s57, v5, #8
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s59, #0]
    v.extract    s57, v5, #9
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s57, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v60, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s57, v5, #10
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s59, #0]
    v.extract    s57, v5, #11
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s57, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v61, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s57, v5, #12
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s59, #0]
    v.extract    s57, v5, #13
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s57, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v62, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s57, v5, #14
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s59, #0]
    v.extract    s57, v5, #15
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s57, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v63, v2                         // hand off through the shared window (sec 7.3)
    mb.arm       s57, b26, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a10, v56, v48, s57
    mb.wait      s57
    s.addi       s58, s21, #96
    s.add        s59, s2, s58
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s58, v8, #0
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s60, #0]
    v.extract    s58, v8, #1
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s58, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v56, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s58, v8, #2
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s60, #0]
    v.extract    s58, v8, #3
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s58, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v57, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s58, v8, #4
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s60, #0]
    v.extract    s58, v8, #5
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s58, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v58, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s58, v8, #6
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s60, #0]
    v.extract    s58, v8, #7
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s58, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v59, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s58, v8, #8
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s60, #0]
    v.extract    s58, v8, #9
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s58, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v60, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s58, v8, #10
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s60, #0]
    v.extract    s58, v8, #11
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s58, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v61, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s58, v8, #12
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s60, #0]
    v.extract    s58, v8, #13
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s58, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v62, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s58, v8, #14
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s60, #0]
    v.extract    s58, v8, #15
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s58, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v63, v2                         // hand off through the shared window (sec 7.3)
    mb.arm       s58, b27, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a11, v56, v48, s58
    mb.wait      s58
    s.addi       s59, s21, #96
    s.add        s60, s2, s59
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s59, v11, #0
    s.add        s23, s60, s59
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s23, #0]
    v.extract    s23, v11, #1
    s.add        s24, s60, s23
    s.addi       s23, s24, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s23, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v56, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s23, v11, #2
    s.add        s24, s60, s23
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s24, #0]
    v.extract    s23, v11, #3
    s.add        s24, s60, s23
    s.addi       s23, s24, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s23, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v57, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s23, v11, #4
    s.add        s24, s60, s23
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s24, #0]
    v.extract    s23, v11, #5
    s.add        s24, s60, s23
    s.addi       s23, s24, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s23, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v58, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s23, v11, #6
    s.add        s24, s60, s23
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s24, #0]
    v.extract    s23, v11, #7
    s.add        s24, s60, s23
    s.addi       s23, s24, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s23, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v59, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s23, v11, #8
    s.add        s24, s60, s23
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s24, #0]
    v.extract    s23, v11, #9
    s.add        s24, s60, s23
    s.addi       s23, s24, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s23, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v60, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s23, v11, #10
    s.add        s24, s60, s23
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s24, #0]
    v.extract    s23, v11, #11
    s.add        s24, s60, s23
    s.addi       s23, s24, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s23, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v61, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s23, v11, #12
    s.add        s24, s60, s23
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s24, #0]
    v.extract    s23, v11, #13
    s.add        s24, s60, s23
    s.addi       s23, s24, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s23, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v62, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s23, v11, #14
    s.add        s24, s60, s23
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s24, #0]
    v.extract    s23, v11, #15
    s.add        s24, s60, s23
    s.addi       s23, s24, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s23, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v63, v2                         // hand off through the shared window (sec 7.3)
    mb.arm       s23, b28, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a12, v56, v48, s23
    mb.wait      s23
    s.addi       s24, s21, #96
    s.add        s32, s2, s24
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s24, v12, #0
    s.add        s34, s32, s24
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s34, #0]
    v.extract    s24, v12, #1
    s.add        s34, s32, s24
    s.addi       s24, s34, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s24, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v56, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s24, v12, #2
    s.add        s34, s32, s24
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s34, #0]
    v.extract    s24, v12, #3
    s.add        s34, s32, s24
    s.addi       s24, s34, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s24, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v57, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s24, v12, #4
    s.add        s34, s32, s24
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s34, #0]
    v.extract    s24, v12, #5
    s.add        s34, s32, s24
    s.addi       s24, s34, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s24, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v58, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s24, v12, #6
    s.add        s34, s32, s24
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s34, #0]
    v.extract    s24, v12, #7
    s.add        s34, s32, s24
    s.addi       s24, s34, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s24, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v59, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s24, v12, #8
    s.add        s34, s32, s24
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s34, #0]
    v.extract    s24, v12, #9
    s.add        s34, s32, s24
    s.addi       s24, s34, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s24, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v60, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s24, v12, #10
    s.add        s34, s32, s24
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s34, #0]
    v.extract    s24, v12, #11
    s.add        s34, s32, s24
    s.addi       s24, s34, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s24, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v61, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s24, v12, #12
    s.add        s34, s32, s24
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s34, #0]
    v.extract    s24, v12, #13
    s.add        s34, s32, s24
    s.addi       s24, s34, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s24, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v62, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s24, v12, #14
    s.add        s34, s32, s24
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s34, #0]
    v.extract    s24, v12, #15
    s.add        s34, s32, s24
    s.addi       s24, s34, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s24, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v63, v2                         // hand off through the shared window (sec 7.3)
    mb.arm       s24, b29, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a13, v56, v48, s24
    mb.wait      s24
    s.addi       s32, s21, #96
    s.add        s34, s2, s32
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s32, v13, #0
    s.add        s35, s34, s32
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s35, #0]
    v.extract    s32, v13, #1
    s.add        s35, s34, s32
    s.addi       s32, s35, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s32, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v56, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s32, v13, #2
    s.add        s35, s34, s32
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s35, #0]
    v.extract    s32, v13, #3
    s.add        s35, s34, s32
    s.addi       s32, s35, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s32, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v57, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s32, v13, #4
    s.add        s35, s34, s32
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s35, #0]
    v.extract    s32, v13, #5
    s.add        s35, s34, s32
    s.addi       s32, s35, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s32, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v58, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s32, v13, #6
    s.add        s35, s34, s32
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s35, #0]
    v.extract    s32, v13, #7
    s.add        s35, s34, s32
    s.addi       s32, s35, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s32, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v59, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s32, v13, #8
    s.add        s35, s34, s32
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s35, #0]
    v.extract    s32, v13, #9
    s.add        s35, s34, s32
    s.addi       s32, s35, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s32, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v60, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s32, v13, #10
    s.add        s35, s34, s32
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s35, #0]
    v.extract    s32, v13, #11
    s.add        s35, s34, s32
    s.addi       s32, s35, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s32, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v61, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s32, v13, #12
    s.add        s35, s34, s32
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s35, #0]
    v.extract    s32, v13, #13
    s.add        s35, s34, s32
    s.addi       s32, s35, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s32, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v62, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s32, v13, #14
    s.add        s35, s34, s32
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s35, #0]
    v.extract    s32, v13, #15
    s.add        s35, s34, s32
    s.addi       s32, s35, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s32, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v63, v2                         // hand off through the shared window (sec 7.3)
    mb.arm       s32, b30, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a14, v56, v48, s32
    mb.wait      s32
    s.addi       s34, s21, #96
    s.add        s35, s2, s34
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s34, v14, #0
    s.add        s36, s35, s34
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s36, #0]
    v.extract    s34, v14, #1
    s.add        s36, s35, s34
    s.addi       s34, s36, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s34, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v56, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s34, v14, #2
    s.add        s36, s35, s34
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s36, #0]
    v.extract    s34, v14, #3
    s.add        s36, s35, s34
    s.addi       s34, s36, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s34, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v57, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s34, v14, #4
    s.add        s36, s35, s34
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s36, #0]
    v.extract    s34, v14, #5
    s.add        s36, s35, s34
    s.addi       s34, s36, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s34, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v58, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s34, v14, #6
    s.add        s36, s35, s34
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s36, #0]
    v.extract    s34, v14, #7
    s.add        s36, s35, s34
    s.addi       s34, s36, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s34, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v59, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s34, v14, #8
    s.add        s36, s35, s34
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s36, #0]
    v.extract    s34, v14, #9
    s.add        s36, s35, s34
    s.addi       s34, s36, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s34, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v60, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s34, v14, #10
    s.add        s36, s35, s34
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s36, #0]
    v.extract    s34, v14, #11
    s.add        s36, s35, s34
    s.addi       s34, s36, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s34, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v61, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s34, v14, #12
    s.add        s36, s35, s34
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s36, #0]
    v.extract    s34, v14, #13
    s.add        s36, s35, s34
    s.addi       s34, s36, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s34, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v62, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s34, v14, #14
    s.add        s36, s35, s34
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s36, #0]
    v.extract    s34, v14, #15
    s.add        s36, s35, s34
    s.addi       s34, s36, #-32
    p.and        p1, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v3, [s34, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v63, v2                         // hand off through the shared window (sec 7.3)
    mb.arm       s34, b31, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a15, v56, v48, s34
    mb.wait      s34
    s.addi       s35, s33, #2048
    s.movz       s36, #0
    a.vread      v2, a8, s36
    v.st.scatter.w [s35, v17], v2
    s.addi       s36, s35, #4
    s.movz       s37, #1
    a.vread      v2, a8, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #8
    s.movz       s37, #2
    a.vread      v2, a8, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #12
    s.movz       s37, #3
    a.vread      v2, a8, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #16
    s.movz       s37, #4
    a.vread      v2, a8, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #20
    s.movz       s37, #5
    a.vread      v2, a8, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #24
    s.movz       s37, #6
    a.vread      v2, a8, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #28
    s.movz       s37, #7
    a.vread      v2, a8, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #32
    s.movz       s37, #8
    a.vread      v2, a8, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #36
    s.movz       s37, #9
    a.vread      v2, a8, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #40
    s.movz       s37, #10
    a.vread      v2, a8, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #44
    s.movz       s37, #11
    a.vread      v2, a8, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #48
    s.movz       s37, #12
    a.vread      v2, a8, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #52
    s.movz       s37, #13
    a.vread      v2, a8, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #56
    s.movz       s37, #14
    a.vread      v2, a8, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #60
    s.movz       s35, #15
    a.vread      v2, a8, s35
    v.st.scatter.w [s36, v17], v2
    fence.acq_rel.device
    s.addi       s35, s33, #3072
    s.movz       s36, #0
    a.vread      v2, a9, s36
    v.st.scatter.w [s35, v17], v2
    s.addi       s36, s35, #4
    s.movz       s37, #1
    a.vread      v2, a9, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #8
    s.movz       s37, #2
    a.vread      v2, a9, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #12
    s.movz       s37, #3
    a.vread      v2, a9, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #16
    s.movz       s37, #4
    a.vread      v2, a9, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #20
    s.movz       s37, #5
    a.vread      v2, a9, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #24
    s.movz       s37, #6
    a.vread      v2, a9, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #28
    s.movz       s37, #7
    a.vread      v2, a9, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #32
    s.movz       s37, #8
    a.vread      v2, a9, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #36
    s.movz       s37, #9
    a.vread      v2, a9, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #40
    s.movz       s37, #10
    a.vread      v2, a9, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #44
    s.movz       s37, #11
    a.vread      v2, a9, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #48
    s.movz       s37, #12
    a.vread      v2, a9, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #52
    s.movz       s37, #13
    a.vread      v2, a9, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #56
    s.movz       s37, #14
    a.vread      v2, a9, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #60
    s.movz       s35, #15
    a.vread      v2, a9, s35
    v.st.scatter.w [s36, v17], v2
    fence.acq_rel.device
    s.addi       s35, s33, #4096
    s.movz       s36, #0
    a.vread      v2, a10, s36
    v.st.scatter.w [s35, v17], v2
    s.addi       s36, s35, #4
    s.movz       s37, #1
    a.vread      v2, a10, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #8
    s.movz       s37, #2
    a.vread      v2, a10, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #12
    s.movz       s37, #3
    a.vread      v2, a10, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #16
    s.movz       s37, #4
    a.vread      v2, a10, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #20
    s.movz       s37, #5
    a.vread      v2, a10, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #24
    s.movz       s37, #6
    a.vread      v2, a10, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #28
    s.movz       s37, #7
    a.vread      v2, a10, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #32
    s.movz       s37, #8
    a.vread      v2, a10, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #36
    s.movz       s37, #9
    a.vread      v2, a10, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #40
    s.movz       s37, #10
    a.vread      v2, a10, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #44
    s.movz       s37, #11
    a.vread      v2, a10, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #48
    s.movz       s37, #12
    a.vread      v2, a10, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #52
    s.movz       s37, #13
    a.vread      v2, a10, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #56
    s.movz       s37, #14
    a.vread      v2, a10, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #60
    s.movz       s35, #15
    a.vread      v2, a10, s35
    v.st.scatter.w [s36, v17], v2
    fence.acq_rel.device
    s.addi       s35, s33, #5120
    s.movz       s36, #0
    a.vread      v2, a11, s36
    v.st.scatter.w [s35, v17], v2
    s.addi       s36, s35, #4
    s.movz       s37, #1
    a.vread      v2, a11, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #8
    s.movz       s37, #2
    a.vread      v2, a11, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #12
    s.movz       s37, #3
    a.vread      v2, a11, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #16
    s.movz       s37, #4
    a.vread      v2, a11, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #20
    s.movz       s37, #5
    a.vread      v2, a11, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #24
    s.movz       s37, #6
    a.vread      v2, a11, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #28
    s.movz       s37, #7
    a.vread      v2, a11, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #32
    s.movz       s37, #8
    a.vread      v2, a11, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #36
    s.movz       s37, #9
    a.vread      v2, a11, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #40
    s.movz       s37, #10
    a.vread      v2, a11, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #44
    s.movz       s37, #11
    a.vread      v2, a11, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #48
    s.movz       s37, #12
    a.vread      v2, a11, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #52
    s.movz       s37, #13
    a.vread      v2, a11, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #56
    s.movz       s37, #14
    a.vread      v2, a11, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #60
    s.movz       s35, #15
    a.vread      v2, a11, s35
    v.st.scatter.w [s36, v17], v2
    fence.acq_rel.device
    s.addi       s35, s33, #6144
    s.movz       s36, #0
    a.vread      v2, a12, s36
    v.st.scatter.w [s35, v17], v2
    s.addi       s36, s35, #4
    s.movz       s37, #1
    a.vread      v2, a12, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #8
    s.movz       s37, #2
    a.vread      v2, a12, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #12
    s.movz       s37, #3
    a.vread      v2, a12, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #16
    s.movz       s37, #4
    a.vread      v2, a12, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #20
    s.movz       s37, #5
    a.vread      v2, a12, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #24
    s.movz       s37, #6
    a.vread      v2, a12, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #28
    s.movz       s37, #7
    a.vread      v2, a12, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #32
    s.movz       s37, #8
    a.vread      v2, a12, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #36
    s.movz       s37, #9
    a.vread      v2, a12, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #40
    s.movz       s37, #10
    a.vread      v2, a12, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #44
    s.movz       s37, #11
    a.vread      v2, a12, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #48
    s.movz       s37, #12
    a.vread      v2, a12, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #52
    s.movz       s37, #13
    a.vread      v2, a12, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #56
    s.movz       s37, #14
    a.vread      v2, a12, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #60
    s.movz       s35, #15
    a.vread      v2, a12, s35
    v.st.scatter.w [s36, v17], v2
    fence.acq_rel.device
    s.addi       s35, s33, #7168
    s.movz       s36, #0
    a.vread      v2, a13, s36
    v.st.scatter.w [s35, v17], v2
    s.addi       s36, s35, #4
    s.movz       s37, #1
    a.vread      v2, a13, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #8
    s.movz       s37, #2
    a.vread      v2, a13, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #12
    s.movz       s37, #3
    a.vread      v2, a13, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #16
    s.movz       s37, #4
    a.vread      v2, a13, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #20
    s.movz       s37, #5
    a.vread      v2, a13, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #24
    s.movz       s37, #6
    a.vread      v2, a13, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #28
    s.movz       s37, #7
    a.vread      v2, a13, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #32
    s.movz       s37, #8
    a.vread      v2, a13, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #36
    s.movz       s37, #9
    a.vread      v2, a13, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #40
    s.movz       s37, #10
    a.vread      v2, a13, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #44
    s.movz       s37, #11
    a.vread      v2, a13, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #48
    s.movz       s37, #12
    a.vread      v2, a13, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #52
    s.movz       s37, #13
    a.vread      v2, a13, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #56
    s.movz       s37, #14
    a.vread      v2, a13, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #60
    s.movz       s35, #15
    a.vread      v2, a13, s35
    v.st.scatter.w [s36, v17], v2
    fence.acq_rel.device
    s.addi       s35, s33, #8192
    s.movz       s36, #0
    a.vread      v2, a14, s36
    v.st.scatter.w [s35, v17], v2
    s.addi       s36, s35, #4
    s.movz       s37, #1
    a.vread      v2, a14, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #8
    s.movz       s37, #2
    a.vread      v2, a14, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #12
    s.movz       s37, #3
    a.vread      v2, a14, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #16
    s.movz       s37, #4
    a.vread      v2, a14, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #20
    s.movz       s37, #5
    a.vread      v2, a14, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #24
    s.movz       s37, #6
    a.vread      v2, a14, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #28
    s.movz       s37, #7
    a.vread      v2, a14, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #32
    s.movz       s37, #8
    a.vread      v2, a14, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #36
    s.movz       s37, #9
    a.vread      v2, a14, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #40
    s.movz       s37, #10
    a.vread      v2, a14, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #44
    s.movz       s37, #11
    a.vread      v2, a14, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #48
    s.movz       s37, #12
    a.vread      v2, a14, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #52
    s.movz       s37, #13
    a.vread      v2, a14, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #56
    s.movz       s37, #14
    a.vread      v2, a14, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #60
    s.movz       s35, #15
    a.vread      v2, a14, s35
    v.st.scatter.w [s36, v17], v2
    fence.acq_rel.device
    s.addi       s35, s33, #9216
    s.movz       s36, #0
    a.vread      v2, a15, s36
    v.st.scatter.w [s35, v17], v2
    s.addi       s36, s35, #4
    s.movz       s37, #1
    a.vread      v2, a15, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #8
    s.movz       s37, #2
    a.vread      v2, a15, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #12
    s.movz       s37, #3
    a.vread      v2, a15, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #16
    s.movz       s37, #4
    a.vread      v2, a15, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #20
    s.movz       s37, #5
    a.vread      v2, a15, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #24
    s.movz       s37, #6
    a.vread      v2, a15, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #28
    s.movz       s37, #7
    a.vread      v2, a15, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #32
    s.movz       s37, #8
    a.vread      v2, a15, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #36
    s.movz       s37, #9
    a.vread      v2, a15, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #40
    s.movz       s37, #10
    a.vread      v2, a15, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #44
    s.movz       s37, #11
    a.vread      v2, a15, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #48
    s.movz       s37, #12
    a.vread      v2, a15, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #52
    s.movz       s37, #13
    a.vread      v2, a15, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #56
    s.movz       s37, #14
    a.vread      v2, a15, s37
    v.st.scatter.w [s36, v17], v2
    s.addi       s36, s35, #60
    s.movz       s35, #15
    a.vread      v2, a15, s35
    v.st.scatter.w [s36, v17], v2
    fence.acq_rel.device
    s.addi       s35, s33, #10240
    s.movz       s36, #0
    a.vread      v2, a0, s36
    s.addi       s36, s33, #2048
    v.ld.w       v3, [s36, #0]
    vf.add       v4, v2, v3
    v.st.w       [s35, #0], v4
    s.addi       s36, s35, #64
    s.movz       s37, #1
    a.vread      v2, a0, s37
    s.addi       s37, s33, #2112
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #128
    s.movz       s37, #2
    a.vread      v2, a0, s37
    s.addi       s37, s33, #2176
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #192
    s.movz       s37, #3
    a.vread      v2, a0, s37
    s.addi       s37, s33, #2240
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #256
    s.movz       s37, #4
    a.vread      v2, a0, s37
    s.addi       s37, s33, #2304
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #320
    s.movz       s37, #5
    a.vread      v2, a0, s37
    s.addi       s37, s33, #2368
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #384
    s.movz       s37, #6
    a.vread      v2, a0, s37
    s.addi       s37, s33, #2432
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #448
    s.movz       s37, #7
    a.vread      v2, a0, s37
    s.addi       s37, s33, #2496
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #512
    s.movz       s37, #8
    a.vread      v2, a0, s37
    s.addi       s37, s33, #2560
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #576
    s.movz       s37, #9
    a.vread      v2, a0, s37
    s.addi       s37, s33, #2624
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #640
    s.movz       s37, #10
    a.vread      v2, a0, s37
    s.addi       s37, s33, #2688
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #704
    s.movz       s37, #11
    a.vread      v2, a0, s37
    s.addi       s37, s33, #2752
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #768
    s.movz       s37, #12
    a.vread      v2, a0, s37
    s.addi       s37, s33, #2816
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #832
    s.movz       s37, #13
    a.vread      v2, a0, s37
    s.addi       s37, s33, #2880
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #896
    s.movz       s37, #14
    a.vread      v2, a0, s37
    s.addi       s37, s33, #2944
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #960
    s.movz       s35, #15
    a.vread      v2, a0, s35
    s.addi       s35, s33, #3008
    v.ld.w       v3, [s35, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    fence.acq_rel.device
    s.addi       s35, s33, #11264
    s.movz       s36, #0
    a.vread      v2, a1, s36
    s.addi       s36, s33, #3072
    v.ld.w       v3, [s36, #0]
    vf.add       v4, v2, v3
    v.st.w       [s35, #0], v4
    s.addi       s36, s35, #64
    s.movz       s37, #1
    a.vread      v2, a1, s37
    s.addi       s37, s33, #3136
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #128
    s.movz       s37, #2
    a.vread      v2, a1, s37
    s.addi       s37, s33, #3200
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #192
    s.movz       s37, #3
    a.vread      v2, a1, s37
    s.addi       s37, s33, #3264
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #256
    s.movz       s37, #4
    a.vread      v2, a1, s37
    s.addi       s37, s33, #3328
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #320
    s.movz       s37, #5
    a.vread      v2, a1, s37
    s.addi       s37, s33, #3392
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #384
    s.movz       s37, #6
    a.vread      v2, a1, s37
    s.addi       s37, s33, #3456
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #448
    s.movz       s37, #7
    a.vread      v2, a1, s37
    s.addi       s37, s33, #3520
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #512
    s.movz       s37, #8
    a.vread      v2, a1, s37
    s.addi       s37, s33, #3584
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #576
    s.movz       s37, #9
    a.vread      v2, a1, s37
    s.addi       s37, s33, #3648
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #640
    s.movz       s37, #10
    a.vread      v2, a1, s37
    s.addi       s37, s33, #3712
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #704
    s.movz       s37, #11
    a.vread      v2, a1, s37
    s.addi       s37, s33, #3776
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #768
    s.movz       s37, #12
    a.vread      v2, a1, s37
    s.addi       s37, s33, #3840
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #832
    s.movz       s37, #13
    a.vread      v2, a1, s37
    s.addi       s37, s33, #3904
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #896
    s.movz       s37, #14
    a.vread      v2, a1, s37
    s.addi       s37, s33, #3968
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #960
    s.movz       s35, #15
    a.vread      v2, a1, s35
    s.addi       s35, s33, #4032
    v.ld.w       v3, [s35, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    fence.acq_rel.device
    s.addi       s35, s33, #12288
    s.movz       s36, #0
    a.vread      v2, a2, s36
    s.addi       s36, s33, #4096
    v.ld.w       v3, [s36, #0]
    vf.add       v4, v2, v3
    v.st.w       [s35, #0], v4
    s.addi       s36, s35, #64
    s.movz       s37, #1
    a.vread      v2, a2, s37
    s.addi       s37, s33, #4160
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #128
    s.movz       s37, #2
    a.vread      v2, a2, s37
    s.addi       s37, s33, #4224
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #192
    s.movz       s37, #3
    a.vread      v2, a2, s37
    s.addi       s37, s33, #4288
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #256
    s.movz       s37, #4
    a.vread      v2, a2, s37
    s.addi       s37, s33, #4352
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #320
    s.movz       s37, #5
    a.vread      v2, a2, s37
    s.addi       s37, s33, #4416
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #384
    s.movz       s37, #6
    a.vread      v2, a2, s37
    s.addi       s37, s33, #4480
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #448
    s.movz       s37, #7
    a.vread      v2, a2, s37
    s.addi       s37, s33, #4544
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #512
    s.movz       s37, #8
    a.vread      v2, a2, s37
    s.addi       s37, s33, #4608
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #576
    s.movz       s37, #9
    a.vread      v2, a2, s37
    s.addi       s37, s33, #4672
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #640
    s.movz       s37, #10
    a.vread      v2, a2, s37
    s.addi       s37, s33, #4736
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #704
    s.movz       s37, #11
    a.vread      v2, a2, s37
    s.addi       s37, s33, #4800
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #768
    s.movz       s37, #12
    a.vread      v2, a2, s37
    s.addi       s37, s33, #4864
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #832
    s.movz       s37, #13
    a.vread      v2, a2, s37
    s.addi       s37, s33, #4928
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #896
    s.movz       s37, #14
    a.vread      v2, a2, s37
    s.addi       s37, s33, #4992
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #960
    s.movz       s35, #15
    a.vread      v2, a2, s35
    s.addi       s35, s33, #5056
    v.ld.w       v3, [s35, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    fence.acq_rel.device
    s.addi       s35, s33, #13312
    s.movz       s36, #0
    a.vread      v2, a3, s36
    s.addi       s36, s33, #5120
    v.ld.w       v3, [s36, #0]
    vf.add       v4, v2, v3
    v.st.w       [s35, #0], v4
    s.addi       s36, s35, #64
    s.movz       s37, #1
    a.vread      v2, a3, s37
    s.addi       s37, s33, #5184
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #128
    s.movz       s37, #2
    a.vread      v2, a3, s37
    s.addi       s37, s33, #5248
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #192
    s.movz       s37, #3
    a.vread      v2, a3, s37
    s.addi       s37, s33, #5312
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #256
    s.movz       s37, #4
    a.vread      v2, a3, s37
    s.addi       s37, s33, #5376
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #320
    s.movz       s37, #5
    a.vread      v2, a3, s37
    s.addi       s37, s33, #5440
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #384
    s.movz       s37, #6
    a.vread      v2, a3, s37
    s.addi       s37, s33, #5504
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #448
    s.movz       s37, #7
    a.vread      v2, a3, s37
    s.addi       s37, s33, #5568
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #512
    s.movz       s37, #8
    a.vread      v2, a3, s37
    s.addi       s37, s33, #5632
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #576
    s.movz       s37, #9
    a.vread      v2, a3, s37
    s.addi       s37, s33, #5696
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #640
    s.movz       s37, #10
    a.vread      v2, a3, s37
    s.addi       s37, s33, #5760
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #704
    s.movz       s37, #11
    a.vread      v2, a3, s37
    s.addi       s37, s33, #5824
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #768
    s.movz       s37, #12
    a.vread      v2, a3, s37
    s.addi       s37, s33, #5888
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #832
    s.movz       s37, #13
    a.vread      v2, a3, s37
    s.addi       s37, s33, #5952
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #896
    s.movz       s37, #14
    a.vread      v2, a3, s37
    s.addi       s37, s33, #6016
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #960
    s.movz       s35, #15
    a.vread      v2, a3, s35
    s.addi       s35, s33, #6080
    v.ld.w       v3, [s35, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    fence.acq_rel.device
    s.addi       s35, s33, #14336
    s.movz       s36, #0
    a.vread      v2, a4, s36
    s.addi       s36, s33, #6144
    v.ld.w       v3, [s36, #0]
    vf.add       v4, v2, v3
    v.st.w       [s35, #0], v4
    s.addi       s36, s35, #64
    s.movz       s37, #1
    a.vread      v2, a4, s37
    s.addi       s37, s33, #6208
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #128
    s.movz       s37, #2
    a.vread      v2, a4, s37
    s.addi       s37, s33, #6272
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #192
    s.movz       s37, #3
    a.vread      v2, a4, s37
    s.addi       s37, s33, #6336
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #256
    s.movz       s37, #4
    a.vread      v2, a4, s37
    s.addi       s37, s33, #6400
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #320
    s.movz       s37, #5
    a.vread      v2, a4, s37
    s.addi       s37, s33, #6464
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #384
    s.movz       s37, #6
    a.vread      v2, a4, s37
    s.addi       s37, s33, #6528
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #448
    s.movz       s37, #7
    a.vread      v2, a4, s37
    s.addi       s37, s33, #6592
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #512
    s.movz       s37, #8
    a.vread      v2, a4, s37
    s.addi       s37, s33, #6656
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #576
    s.movz       s37, #9
    a.vread      v2, a4, s37
    s.addi       s37, s33, #6720
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #640
    s.movz       s37, #10
    a.vread      v2, a4, s37
    s.addi       s37, s33, #6784
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #704
    s.movz       s37, #11
    a.vread      v2, a4, s37
    s.addi       s37, s33, #6848
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #768
    s.movz       s37, #12
    a.vread      v2, a4, s37
    s.addi       s37, s33, #6912
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #832
    s.movz       s37, #13
    a.vread      v2, a4, s37
    s.addi       s37, s33, #6976
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #896
    s.movz       s37, #14
    a.vread      v2, a4, s37
    s.addi       s37, s33, #7040
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #960
    s.movz       s35, #15
    a.vread      v2, a4, s35
    s.addi       s35, s33, #7104
    v.ld.w       v3, [s35, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    fence.acq_rel.device
    s.addi       s35, s33, #15360
    s.movz       s36, #0
    a.vread      v2, a5, s36
    s.addi       s36, s33, #7168
    v.ld.w       v3, [s36, #0]
    vf.add       v4, v2, v3
    v.st.w       [s35, #0], v4
    s.addi       s36, s35, #64
    s.movz       s37, #1
    a.vread      v2, a5, s37
    s.addi       s37, s33, #7232
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #128
    s.movz       s37, #2
    a.vread      v2, a5, s37
    s.addi       s37, s33, #7296
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #192
    s.movz       s37, #3
    a.vread      v2, a5, s37
    s.addi       s37, s33, #7360
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #256
    s.movz       s37, #4
    a.vread      v2, a5, s37
    s.addi       s37, s33, #7424
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #320
    s.movz       s37, #5
    a.vread      v2, a5, s37
    s.addi       s37, s33, #7488
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #384
    s.movz       s37, #6
    a.vread      v2, a5, s37
    s.addi       s37, s33, #7552
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #448
    s.movz       s37, #7
    a.vread      v2, a5, s37
    s.addi       s37, s33, #7616
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #512
    s.movz       s37, #8
    a.vread      v2, a5, s37
    s.addi       s37, s33, #7680
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #576
    s.movz       s37, #9
    a.vread      v2, a5, s37
    s.addi       s37, s33, #7744
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #640
    s.movz       s37, #10
    a.vread      v2, a5, s37
    s.addi       s37, s33, #7808
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #704
    s.movz       s37, #11
    a.vread      v2, a5, s37
    s.addi       s37, s33, #7872
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #768
    s.movz       s37, #12
    a.vread      v2, a5, s37
    s.addi       s37, s33, #7936
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #832
    s.movz       s37, #13
    a.vread      v2, a5, s37
    s.addi       s37, s33, #8000
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #896
    s.movz       s37, #14
    a.vread      v2, a5, s37
    s.addi       s37, s33, #8064
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #960
    s.movz       s35, #15
    a.vread      v2, a5, s35
    s.addi       s35, s33, #8128
    v.ld.w       v3, [s35, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    fence.acq_rel.device
    s.addi       s35, s33, #16384
    s.movz       s36, #0
    a.vread      v2, a6, s36
    s.addi       s36, s33, #8192
    v.ld.w       v3, [s36, #0]
    vf.add       v4, v2, v3
    v.st.w       [s35, #0], v4
    s.addi       s36, s35, #64
    s.movz       s37, #1
    a.vread      v2, a6, s37
    s.addi       s37, s33, #8256
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #128
    s.movz       s37, #2
    a.vread      v2, a6, s37
    s.addi       s37, s33, #8320
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #192
    s.movz       s37, #3
    a.vread      v2, a6, s37
    s.addi       s37, s33, #8384
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #256
    s.movz       s37, #4
    a.vread      v2, a6, s37
    s.addi       s37, s33, #8448
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #320
    s.movz       s37, #5
    a.vread      v2, a6, s37
    s.addi       s37, s33, #8512
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #384
    s.movz       s37, #6
    a.vread      v2, a6, s37
    s.addi       s37, s33, #8576
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #448
    s.movz       s37, #7
    a.vread      v2, a6, s37
    s.addi       s37, s33, #8640
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #512
    s.movz       s37, #8
    a.vread      v2, a6, s37
    s.addi       s37, s33, #8704
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #576
    s.movz       s37, #9
    a.vread      v2, a6, s37
    s.addi       s37, s33, #8768
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #640
    s.movz       s37, #10
    a.vread      v2, a6, s37
    s.addi       s37, s33, #8832
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #704
    s.movz       s37, #11
    a.vread      v2, a6, s37
    s.addi       s37, s33, #8896
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #768
    s.movz       s37, #12
    a.vread      v2, a6, s37
    s.addi       s37, s33, #8960
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #832
    s.movz       s37, #13
    a.vread      v2, a6, s37
    s.addi       s37, s33, #9024
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #896
    s.movz       s37, #14
    a.vread      v2, a6, s37
    s.addi       s37, s33, #9088
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #960
    s.movz       s35, #15
    a.vread      v2, a6, s35
    s.addi       s35, s33, #9152
    v.ld.w       v3, [s35, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    fence.acq_rel.device
    s.addi       s35, s33, #17408
    s.movz       s36, #0
    a.vread      v2, a7, s36
    s.addi       s36, s33, #9216
    v.ld.w       v3, [s36, #0]
    vf.add       v4, v2, v3
    v.st.w       [s35, #0], v4
    s.addi       s36, s35, #64
    s.movz       s37, #1
    a.vread      v2, a7, s37
    s.addi       s37, s33, #9280
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #128
    s.movz       s37, #2
    a.vread      v2, a7, s37
    s.addi       s37, s33, #9344
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #192
    s.movz       s37, #3
    a.vread      v2, a7, s37
    s.addi       s37, s33, #9408
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #256
    s.movz       s37, #4
    a.vread      v2, a7, s37
    s.addi       s37, s33, #9472
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #320
    s.movz       s37, #5
    a.vread      v2, a7, s37
    s.addi       s37, s33, #9536
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #384
    s.movz       s37, #6
    a.vread      v2, a7, s37
    s.addi       s37, s33, #9600
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #448
    s.movz       s37, #7
    a.vread      v2, a7, s37
    s.addi       s37, s33, #9664
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #512
    s.movz       s37, #8
    a.vread      v2, a7, s37
    s.addi       s37, s33, #9728
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #576
    s.movz       s37, #9
    a.vread      v2, a7, s37
    s.addi       s37, s33, #9792
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #640
    s.movz       s37, #10
    a.vread      v2, a7, s37
    s.addi       s37, s33, #9856
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #704
    s.movz       s37, #11
    a.vread      v2, a7, s37
    s.addi       s37, s33, #9920
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #768
    s.movz       s37, #12
    a.vread      v2, a7, s37
    s.addi       s37, s33, #9984
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #832
    s.movz       s37, #13
    a.vread      v2, a7, s37
    s.addi       s37, s33, #10048
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #896
    s.movz       s37, #14
    a.vread      v2, a7, s37
    s.addi       s37, s33, #10112
    v.ld.w       v3, [s37, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    s.addi       s36, s35, #960
    s.movz       s35, #15
    a.vread      v2, a7, s35
    s.addi       s35, s33, #10176
    v.ld.w       v3, [s35, #0]
    vf.add       v4, v2, v3
    v.st.w       [s36, #0], v4
    fence.acq_rel.device
    s.addi       s35, s20, #128
    s.addi       s36, s35, #0
    s.addi       s35, s21, #128
    s.addi       s37, s35, #0
    s.mov        s20, s36
    s.mov        s21, s37
    s.movz       s35, #0
    s.addi       s36, s33, #10240
    v.ld.w       v2, [s36, #0]
    a.vwrite     a0, s35, v2
    s.movz       s35, #1
    s.addi       s36, s33, #10304
    v.ld.w       v2, [s36, #0]
    a.vwrite     a0, s35, v2
    s.movz       s35, #2
    s.addi       s36, s33, #10368
    v.ld.w       v2, [s36, #0]
    a.vwrite     a0, s35, v2
    s.movz       s35, #3
    s.addi       s36, s33, #10432
    v.ld.w       v2, [s36, #0]
    a.vwrite     a0, s35, v2
    s.movz       s35, #4
    s.addi       s36, s33, #10496
    v.ld.w       v2, [s36, #0]
    a.vwrite     a0, s35, v2
    s.movz       s35, #5
    s.addi       s36, s33, #10560
    v.ld.w       v2, [s36, #0]
    a.vwrite     a0, s35, v2
    s.movz       s35, #6
    s.addi       s36, s33, #10624
    v.ld.w       v2, [s36, #0]
    a.vwrite     a0, s35, v2
    s.movz       s35, #7
    s.addi       s36, s33, #10688
    v.ld.w       v2, [s36, #0]
    a.vwrite     a0, s35, v2
    s.movz       s35, #8
    s.addi       s36, s33, #10752
    v.ld.w       v2, [s36, #0]
    a.vwrite     a0, s35, v2
    s.movz       s35, #9
    s.addi       s36, s33, #10816
    v.ld.w       v2, [s36, #0]
    a.vwrite     a0, s35, v2
    s.movz       s35, #10
    s.addi       s36, s33, #10880
    v.ld.w       v2, [s36, #0]
    a.vwrite     a0, s35, v2
    s.movz       s35, #11
    s.addi       s36, s33, #10944
    v.ld.w       v2, [s36, #0]
    a.vwrite     a0, s35, v2
    s.movz       s35, #12
    s.addi       s36, s33, #11008
    v.ld.w       v2, [s36, #0]
    a.vwrite     a0, s35, v2
    s.movz       s35, #13
    s.addi       s36, s33, #11072
    v.ld.w       v2, [s36, #0]
    a.vwrite     a0, s35, v2
    s.movz       s35, #14
    s.addi       s36, s33, #11136
    v.ld.w       v2, [s36, #0]
    a.vwrite     a0, s35, v2
    s.movz       s35, #15
    s.addi       s36, s33, #11200
    v.ld.w       v2, [s36, #0]
    a.vwrite     a0, s35, v2
    s.movz       s35, #0
    s.addi       s36, s33, #11264
    v.ld.w       v2, [s36, #0]
    a.vwrite     a1, s35, v2
    s.movz       s35, #1
    s.addi       s36, s33, #11328
    v.ld.w       v2, [s36, #0]
    a.vwrite     a1, s35, v2
    s.movz       s35, #2
    s.addi       s36, s33, #11392
    v.ld.w       v2, [s36, #0]
    a.vwrite     a1, s35, v2
    s.movz       s35, #3
    s.addi       s36, s33, #11456
    v.ld.w       v2, [s36, #0]
    a.vwrite     a1, s35, v2
    s.movz       s35, #4
    s.addi       s36, s33, #11520
    v.ld.w       v2, [s36, #0]
    a.vwrite     a1, s35, v2
    s.movz       s35, #5
    s.addi       s36, s33, #11584
    v.ld.w       v2, [s36, #0]
    a.vwrite     a1, s35, v2
    s.movz       s35, #6
    s.addi       s36, s33, #11648
    v.ld.w       v2, [s36, #0]
    a.vwrite     a1, s35, v2
    s.movz       s35, #7
    s.addi       s36, s33, #11712
    v.ld.w       v2, [s36, #0]
    a.vwrite     a1, s35, v2
    s.movz       s35, #8
    s.addi       s36, s33, #11776
    v.ld.w       v2, [s36, #0]
    a.vwrite     a1, s35, v2
    s.movz       s35, #9
    s.addi       s36, s33, #11840
    v.ld.w       v2, [s36, #0]
    a.vwrite     a1, s35, v2
    s.movz       s35, #10
    s.addi       s36, s33, #11904
    v.ld.w       v2, [s36, #0]
    a.vwrite     a1, s35, v2
    s.movz       s35, #11
    s.addi       s36, s33, #11968
    v.ld.w       v2, [s36, #0]
    a.vwrite     a1, s35, v2
    s.movz       s35, #12
    s.addi       s36, s33, #12032
    v.ld.w       v2, [s36, #0]
    a.vwrite     a1, s35, v2
    s.movz       s35, #13
    s.addi       s36, s33, #12096
    v.ld.w       v2, [s36, #0]
    a.vwrite     a1, s35, v2
    s.movz       s35, #14
    s.addi       s36, s33, #12160
    v.ld.w       v2, [s36, #0]
    a.vwrite     a1, s35, v2
    s.movz       s35, #15
    s.addi       s36, s33, #12224
    v.ld.w       v2, [s36, #0]
    a.vwrite     a1, s35, v2
    s.movz       s35, #0
    s.addi       s36, s33, #12288
    v.ld.w       v2, [s36, #0]
    a.vwrite     a2, s35, v2
    s.movz       s35, #1
    s.addi       s36, s33, #12352
    v.ld.w       v2, [s36, #0]
    a.vwrite     a2, s35, v2
    s.movz       s35, #2
    s.addi       s36, s33, #12416
    v.ld.w       v2, [s36, #0]
    a.vwrite     a2, s35, v2
    s.movz       s35, #3
    s.addi       s36, s33, #12480
    v.ld.w       v2, [s36, #0]
    a.vwrite     a2, s35, v2
    s.movz       s35, #4
    s.addi       s36, s33, #12544
    v.ld.w       v2, [s36, #0]
    a.vwrite     a2, s35, v2
    s.movz       s35, #5
    s.addi       s36, s33, #12608
    v.ld.w       v2, [s36, #0]
    a.vwrite     a2, s35, v2
    s.movz       s35, #6
    s.addi       s36, s33, #12672
    v.ld.w       v2, [s36, #0]
    a.vwrite     a2, s35, v2
    s.movz       s35, #7
    s.addi       s36, s33, #12736
    v.ld.w       v2, [s36, #0]
    a.vwrite     a2, s35, v2
    s.movz       s35, #8
    s.addi       s36, s33, #12800
    v.ld.w       v2, [s36, #0]
    a.vwrite     a2, s35, v2
    s.movz       s35, #9
    s.addi       s36, s33, #12864
    v.ld.w       v2, [s36, #0]
    a.vwrite     a2, s35, v2
    s.movz       s35, #10
    s.addi       s36, s33, #12928
    v.ld.w       v2, [s36, #0]
    a.vwrite     a2, s35, v2
    s.movz       s35, #11
    s.addi       s36, s33, #12992
    v.ld.w       v2, [s36, #0]
    a.vwrite     a2, s35, v2
    s.movz       s35, #12
    s.addi       s36, s33, #13056
    v.ld.w       v2, [s36, #0]
    a.vwrite     a2, s35, v2
    s.movz       s35, #13
    s.addi       s36, s33, #13120
    v.ld.w       v2, [s36, #0]
    a.vwrite     a2, s35, v2
    s.movz       s35, #14
    s.addi       s36, s33, #13184
    v.ld.w       v2, [s36, #0]
    a.vwrite     a2, s35, v2
    s.movz       s35, #15
    s.addi       s36, s33, #13248
    v.ld.w       v2, [s36, #0]
    a.vwrite     a2, s35, v2
    s.movz       s35, #0
    s.addi       s36, s33, #13312
    v.ld.w       v2, [s36, #0]
    a.vwrite     a3, s35, v2
    s.movz       s35, #1
    s.addi       s36, s33, #13376
    v.ld.w       v2, [s36, #0]
    a.vwrite     a3, s35, v2
    s.movz       s35, #2
    s.addi       s36, s33, #13440
    v.ld.w       v2, [s36, #0]
    a.vwrite     a3, s35, v2
    s.movz       s35, #3
    s.addi       s36, s33, #13504
    v.ld.w       v2, [s36, #0]
    a.vwrite     a3, s35, v2
    s.movz       s35, #4
    s.addi       s36, s33, #13568
    v.ld.w       v2, [s36, #0]
    a.vwrite     a3, s35, v2
    s.movz       s35, #5
    s.addi       s36, s33, #13632
    v.ld.w       v2, [s36, #0]
    a.vwrite     a3, s35, v2
    s.movz       s35, #6
    s.addi       s36, s33, #13696
    v.ld.w       v2, [s36, #0]
    a.vwrite     a3, s35, v2
    s.movz       s35, #7
    s.addi       s36, s33, #13760
    v.ld.w       v2, [s36, #0]
    a.vwrite     a3, s35, v2
    s.movz       s35, #8
    s.addi       s36, s33, #13824
    v.ld.w       v2, [s36, #0]
    a.vwrite     a3, s35, v2
    s.movz       s35, #9
    s.addi       s36, s33, #13888
    v.ld.w       v2, [s36, #0]
    a.vwrite     a3, s35, v2
    s.movz       s35, #10
    s.addi       s36, s33, #13952
    v.ld.w       v2, [s36, #0]
    a.vwrite     a3, s35, v2
    s.movz       s35, #11
    s.addi       s36, s33, #14016
    v.ld.w       v2, [s36, #0]
    a.vwrite     a3, s35, v2
    s.movz       s35, #12
    s.addi       s36, s33, #14080
    v.ld.w       v2, [s36, #0]
    a.vwrite     a3, s35, v2
    s.movz       s35, #13
    s.addi       s36, s33, #14144
    v.ld.w       v2, [s36, #0]
    a.vwrite     a3, s35, v2
    s.movz       s35, #14
    s.addi       s36, s33, #14208
    v.ld.w       v2, [s36, #0]
    a.vwrite     a3, s35, v2
    s.movz       s35, #15
    s.addi       s36, s33, #14272
    v.ld.w       v2, [s36, #0]
    a.vwrite     a3, s35, v2
    s.movz       s35, #0
    s.addi       s36, s33, #14336
    v.ld.w       v2, [s36, #0]
    a.vwrite     a4, s35, v2
    s.movz       s35, #1
    s.addi       s36, s33, #14400
    v.ld.w       v2, [s36, #0]
    a.vwrite     a4, s35, v2
    s.movz       s35, #2
    s.addi       s36, s33, #14464
    v.ld.w       v2, [s36, #0]
    a.vwrite     a4, s35, v2
    s.movz       s35, #3
    s.addi       s36, s33, #14528
    v.ld.w       v2, [s36, #0]
    a.vwrite     a4, s35, v2
    s.movz       s35, #4
    s.addi       s36, s33, #14592
    v.ld.w       v2, [s36, #0]
    a.vwrite     a4, s35, v2
    s.movz       s35, #5
    s.addi       s36, s33, #14656
    v.ld.w       v2, [s36, #0]
    a.vwrite     a4, s35, v2
    s.movz       s35, #6
    s.addi       s36, s33, #14720
    v.ld.w       v2, [s36, #0]
    a.vwrite     a4, s35, v2
    s.movz       s35, #7
    s.addi       s36, s33, #14784
    v.ld.w       v2, [s36, #0]
    a.vwrite     a4, s35, v2
    s.movz       s35, #8
    s.addi       s36, s33, #14848
    v.ld.w       v2, [s36, #0]
    a.vwrite     a4, s35, v2
    s.movz       s35, #9
    s.addi       s36, s33, #14912
    v.ld.w       v2, [s36, #0]
    a.vwrite     a4, s35, v2
    s.movz       s35, #10
    s.addi       s36, s33, #14976
    v.ld.w       v2, [s36, #0]
    a.vwrite     a4, s35, v2
    s.movz       s35, #11
    s.addi       s36, s33, #15040
    v.ld.w       v2, [s36, #0]
    a.vwrite     a4, s35, v2
    s.movz       s35, #12
    s.addi       s36, s33, #15104
    v.ld.w       v2, [s36, #0]
    a.vwrite     a4, s35, v2
    s.movz       s35, #13
    s.addi       s36, s33, #15168
    v.ld.w       v2, [s36, #0]
    a.vwrite     a4, s35, v2
    s.movz       s35, #14
    s.addi       s36, s33, #15232
    v.ld.w       v2, [s36, #0]
    a.vwrite     a4, s35, v2
    s.movz       s35, #15
    s.addi       s36, s33, #15296
    v.ld.w       v2, [s36, #0]
    a.vwrite     a4, s35, v2
    s.movz       s35, #0
    s.addi       s36, s33, #15360
    v.ld.w       v2, [s36, #0]
    a.vwrite     a5, s35, v2
    s.movz       s35, #1
    s.addi       s36, s33, #15424
    v.ld.w       v2, [s36, #0]
    a.vwrite     a5, s35, v2
    s.movz       s35, #2
    s.addi       s36, s33, #15488
    v.ld.w       v2, [s36, #0]
    a.vwrite     a5, s35, v2
    s.movz       s35, #3
    s.addi       s36, s33, #15552
    v.ld.w       v2, [s36, #0]
    a.vwrite     a5, s35, v2
    s.movz       s35, #4
    s.addi       s36, s33, #15616
    v.ld.w       v2, [s36, #0]
    a.vwrite     a5, s35, v2
    s.movz       s35, #5
    s.addi       s36, s33, #15680
    v.ld.w       v2, [s36, #0]
    a.vwrite     a5, s35, v2
    s.movz       s35, #6
    s.addi       s36, s33, #15744
    v.ld.w       v2, [s36, #0]
    a.vwrite     a5, s35, v2
    s.movz       s35, #7
    s.addi       s36, s33, #15808
    v.ld.w       v2, [s36, #0]
    a.vwrite     a5, s35, v2
    s.movz       s35, #8
    s.addi       s36, s33, #15872
    v.ld.w       v2, [s36, #0]
    a.vwrite     a5, s35, v2
    s.movz       s35, #9
    s.addi       s36, s33, #15936
    v.ld.w       v2, [s36, #0]
    a.vwrite     a5, s35, v2
    s.movz       s35, #10
    s.addi       s36, s33, #16000
    v.ld.w       v2, [s36, #0]
    a.vwrite     a5, s35, v2
    s.movz       s35, #11
    s.addi       s36, s33, #16064
    v.ld.w       v2, [s36, #0]
    a.vwrite     a5, s35, v2
    s.movz       s35, #12
    s.addi       s36, s33, #16128
    v.ld.w       v2, [s36, #0]
    a.vwrite     a5, s35, v2
    s.movz       s35, #13
    s.addi       s36, s33, #16192
    v.ld.w       v2, [s36, #0]
    a.vwrite     a5, s35, v2
    s.movz       s35, #14
    s.addi       s36, s33, #16256
    v.ld.w       v2, [s36, #0]
    a.vwrite     a5, s35, v2
    s.movz       s35, #15
    s.addi       s36, s33, #16320
    v.ld.w       v2, [s36, #0]
    a.vwrite     a5, s35, v2
    s.movz       s35, #0
    s.addi       s36, s33, #16384
    v.ld.w       v2, [s36, #0]
    a.vwrite     a6, s35, v2
    s.movz       s35, #1
    s.addi       s36, s33, #16448
    v.ld.w       v2, [s36, #0]
    a.vwrite     a6, s35, v2
    s.movz       s35, #2
    s.addi       s36, s33, #16512
    v.ld.w       v2, [s36, #0]
    a.vwrite     a6, s35, v2
    s.movz       s35, #3
    s.addi       s36, s33, #16576
    v.ld.w       v2, [s36, #0]
    a.vwrite     a6, s35, v2
    s.movz       s35, #4
    s.addi       s36, s33, #16640
    v.ld.w       v2, [s36, #0]
    a.vwrite     a6, s35, v2
    s.movz       s35, #5
    s.addi       s36, s33, #16704
    v.ld.w       v2, [s36, #0]
    a.vwrite     a6, s35, v2
    s.movz       s35, #6
    s.addi       s36, s33, #16768
    v.ld.w       v2, [s36, #0]
    a.vwrite     a6, s35, v2
    s.movz       s35, #7
    s.addi       s36, s33, #16832
    v.ld.w       v2, [s36, #0]
    a.vwrite     a6, s35, v2
    s.movz       s35, #8
    s.addi       s36, s33, #16896
    v.ld.w       v2, [s36, #0]
    a.vwrite     a6, s35, v2
    s.movz       s35, #9
    s.addi       s36, s33, #16960
    v.ld.w       v2, [s36, #0]
    a.vwrite     a6, s35, v2
    s.movz       s35, #10
    s.addi       s36, s33, #17024
    v.ld.w       v2, [s36, #0]
    a.vwrite     a6, s35, v2
    s.movz       s35, #11
    s.addi       s36, s33, #17088
    v.ld.w       v2, [s36, #0]
    a.vwrite     a6, s35, v2
    s.movz       s35, #12
    s.addi       s36, s33, #17152
    v.ld.w       v2, [s36, #0]
    a.vwrite     a6, s35, v2
    s.movz       s35, #13
    s.addi       s36, s33, #17216
    v.ld.w       v2, [s36, #0]
    a.vwrite     a6, s35, v2
    s.movz       s35, #14
    s.addi       s36, s33, #17280
    v.ld.w       v2, [s36, #0]
    a.vwrite     a6, s35, v2
    s.movz       s35, #15
    s.addi       s36, s33, #17344
    v.ld.w       v2, [s36, #0]
    a.vwrite     a6, s35, v2
    s.movz       s35, #0
    s.addi       s36, s33, #17408
    v.ld.w       v2, [s36, #0]
    a.vwrite     a7, s35, v2
    s.movz       s35, #1
    s.addi       s36, s33, #17472
    v.ld.w       v2, [s36, #0]
    a.vwrite     a7, s35, v2
    s.movz       s35, #2
    s.addi       s36, s33, #17536
    v.ld.w       v2, [s36, #0]
    a.vwrite     a7, s35, v2
    s.movz       s35, #3
    s.addi       s36, s33, #17600
    v.ld.w       v2, [s36, #0]
    a.vwrite     a7, s35, v2
    s.movz       s35, #4
    s.addi       s36, s33, #17664
    v.ld.w       v2, [s36, #0]
    a.vwrite     a7, s35, v2
    s.movz       s35, #5
    s.addi       s36, s33, #17728
    v.ld.w       v2, [s36, #0]
    a.vwrite     a7, s35, v2
    s.movz       s35, #6
    s.addi       s36, s33, #17792
    v.ld.w       v2, [s36, #0]
    a.vwrite     a7, s35, v2
    s.movz       s35, #7
    s.addi       s36, s33, #17856
    v.ld.w       v2, [s36, #0]
    a.vwrite     a7, s35, v2
    s.movz       s35, #8
    s.addi       s36, s33, #17920
    v.ld.w       v2, [s36, #0]
    a.vwrite     a7, s35, v2
    s.movz       s35, #9
    s.addi       s36, s33, #17984
    v.ld.w       v2, [s36, #0]
    a.vwrite     a7, s35, v2
    s.movz       s35, #10
    s.addi       s36, s33, #18048
    v.ld.w       v2, [s36, #0]
    a.vwrite     a7, s35, v2
    s.movz       s35, #11
    s.addi       s36, s33, #18112
    v.ld.w       v2, [s36, #0]
    a.vwrite     a7, s35, v2
    s.movz       s35, #12
    s.addi       s36, s33, #18176
    v.ld.w       v2, [s36, #0]
    a.vwrite     a7, s35, v2
    s.movz       s35, #13
    s.addi       s36, s33, #18240
    v.ld.w       v2, [s36, #0]
    a.vwrite     a7, s35, v2
    s.movz       s35, #14
    s.addi       s36, s33, #18304
    v.ld.w       v2, [s36, #0]
    a.vwrite     a7, s35, v2
    s.movz       s35, #15
    s.addi       s36, s33, #18368
    v.ld.w       v2, [s36, #0]
    a.vwrite     a7, s35, v2
    s.add        s33, s19, s18
    s.mov        s19, s33
    s.movz       s33, #1
    br.nz        s33, for_20
endfor_21:
    s.movz       s1, #0
    v.extract    s14, v1, #0
    a.vread      v0, a0, s1
    v.splat      v2, s14
    s.mul        s1, s16, s13
    v.splat      v3, s22
    vf.mul       v4, v0, v2
    s.movz       s14, #0
    s.movz       s17, #0
    s.add        s18, s14, s15                   // the tile origin
    s.movz       s14, #0
    vf.mul       v0, v4, v3
    s.movz       s19, #0
    s.muli       s20, s1, #2
    s.muli       s1, s15, #2
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v4, s18
    s.add        s18, s17, s16                   // the tile origin
    s.add        s16, s14, s8                    // the tile origin
    s.add        s14, s19, s9                    // the tile origin
    v.splat      v5, s18
    v.splat      v6, s16
    v.add        v7, v2, v4
    v.splat      v4, s14
    vf.cvt.f32.bf16 v8, v0
    s.add        s14, s20, s1
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v7, v4
    s.add        s16, s5, s14
    p.and        p3, p1, p2
    s.movz       s14, #1
    v.extract    s17, v1, #1
    @p3 v.st.h       [s16, #0], v8
    a.vread      v0, a0, s14
    v.splat      v4, s17
    s.muli       s14, s13, #2
    s.addi       s16, s15, #16
    vf.mul       v5, v0, v4
    s.addi       s17, s15, #32
    s.addi       s19, s18, #1
    s.muli       s21, s14, #1
    s.addi       s22, s15, #48
    vf.mul       v0, v5, v3
    v.splat      v4, s19
    s.addi       s19, s15, #64
    s.add        s25, s21, s20
    v.cmp.lt     p1, v4, v6
    vf.cvt.f32.bf16 v4, v0
    s.add        s21, s25, s1
    s.addi       s25, s15, #80
    s.add        s26, s5, s21
    p.and        p3, p1, p2
    s.addi       s21, s15, #96
    @p3 v.st.h       [s26, #0], v4
    s.addi       s26, s15, #112
    s.movz       s15, #2
    v.extract    s27, v1, #2
    a.vread      v0, a0, s15
    v.splat      v4, s27
    s.muli       s15, s14, #2
    s.addi       s27, s18, #2
    vf.mul       v5, v0, v4
    v.splat      v0, s27
    s.movz       s27, #3
    s.add        s28, s15, s20
    v.cmp.lt     p1, v0, v6
    vf.mul       v0, v5, v3
    s.add        s15, s28, s1
    p.and        p3, p1, p2
    s.add        s28, s5, s15
    v.extract    s15, v1, #3
    vf.cvt.f32.bf16 v4, v0
    v.splat      v0, s15
    s.muli       s15, s14, #3
    s.addi       s29, s18, #3
    s.movz       s30, #4
    @p3 v.st.h       [s28, #0], v4
    a.vread      v4, a0, s27
    s.add        s27, s15, s20
    v.splat      v5, s29
    vf.mul       v7, v4, v0
    s.add        s15, s27, s1
    v.cmp.lt     p1, v5, v6
    s.add        s27, s5, s15
    p.and        p3, p1, p2
    vf.mul       v0, v7, v3
    v.extract    s15, v1, #4
    s.muli       s28, s14, #4
    v.splat      v4, s15
    s.addi       s15, s18, #4
    vf.cvt.f32.bf16 v5, v0
    v.splat      v0, s15
    s.add        s15, s28, s20
    s.movz       s28, #5
    s.add        s29, s15, s1
    @p3 v.st.h       [s27, #0], v5
    a.vread      v5, a0, s30
    v.cmp.lt     p1, v0, v6
    s.add        s15, s5, s29
    vf.mul       v0, v5, v4
    p.and        p3, p1, p2
    v.extract    s27, v1, #5
    s.muli       s29, s14, #5
    v.splat      v4, s27
    vf.mul       v5, v0, v3
    s.addi       s27, s18, #5
    s.movz       s30, #6
    s.add        s31, s29, s20
    v.splat      v0, s27
    vf.cvt.f32.bf16 v7, v5
    s.add        s27, s31, s1
    v.cmp.lt     p1, v0, v6
    s.add        s29, s5, s27
    p.and        p4, p1, p2
    @p3 v.st.h       [s15, #0], v7
    a.vread      v0, a0, s28
    v.extract    s15, v1, #6
    s.muli       s27, s14, #6
    vf.mul       v5, v0, v4
    v.splat      v0, s15
    s.addi       s15, s18, #6
    s.movz       s28, #7
    s.add        s31, s27, s20
    vf.mul       v4, v5, v3
    v.splat      v5, s15
    s.add        s15, s31, s1
    v.extract    s27, v1, #7
    v.cmp.lt     p1, v5, v6
    vf.cvt.f32.bf16 v5, v4
    s.add        s31, s5, s15
    p.and        p3, p1, p2
    v.splat      v4, s27
    s.muli       s15, s14, #7
    @p4 v.st.h       [s29, #0], v5
    a.vread      v5, a0, s30
    s.addi       s27, s18, #7
    s.movz       s29, #8
    vf.mul       v7, v5, v0
    s.add        s30, s15, s20
    v.splat      v0, s27
    s.add        s15, s30, s1
    v.extract    s27, v1, #8
    vf.mul       v5, v7, v3
    v.cmp.lt     p1, v0, v6
    s.add        s30, s5, s15
    p.and        p4, p1, p2
    v.splat      v0, s27
    vf.cvt.f32.bf16 v7, v5
    s.muli       s15, s14, #8
    s.addi       s27, s18, #8
    s.movz       s33, #9
    v.splat      v5, s27
    @p3 v.st.h       [s31, #0], v7
    a.vread      v7, a0, s28
    s.add        s27, s15, s20
    v.cmp.lt     p1, v5, v6
    vf.mul       v5, v7, v4
    s.add        s15, s27, s1
    p.and        p3, p1, p2
    s.add        s27, s5, s15
    v.extract    s15, v1, #9
    vf.mul       v4, v5, v3
    v.splat      v5, s15
    s.muli       s15, s14, #9
    s.addi       s28, s18, #9
    s.movz       s31, #10
    vf.cvt.f32.bf16 v7, v4
    v.splat      v4, s28
    s.add        s28, s15, s20
    v.extract    s15, v1, #10
    s.add        s35, s28, s1
    @p4 v.st.h       [s30, #0], v7
    a.vread      v7, a0, s29
    v.cmp.lt     p1, v4, v6
    s.add        s28, s5, s35
    vf.mul       v4, v7, v0
    p.and        p4, p1, p2
    v.splat      v0, s15
    s.muli       s15, s14, #10
    s.addi       s29, s18, #10
    vf.mul       v7, v4, v3
    v.splat      v4, s29
    s.movz       s29, #11
    s.add        s30, s15, s20
    v.extract    s15, v1, #11
    vf.cvt.f32.bf16 v8, v7
    s.add        s35, s30, s1
    v.splat      v7, s15
    s.add        s15, s5, s35
    s.muli       s30, s14, #11
    @p3 v.st.h       [s27, #0], v8
    a.vread      v8, a0, s33
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v8, v5
    s.addi       s27, s18, #11
    s.add        s33, s30, s20
    v.splat      v5, s27
    s.add        s27, s33, s1
    vf.mul       v8, v4, v3
    s.add        s30, s5, s27
    s.movz       s27, #12
    v.extract    s33, v1, #12
    vf.cvt.f32.bf16 v4, v8
    v.splat      v8, s33
    s.muli       s33, s14, #12
    s.addi       s35, s18, #12
    @p4 v.st.h       [s28, #0], v4
    a.vread      v4, a0, s31
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v4, v0
    s.add        s28, s33, s20
    v.splat      v0, s35
    s.add        s31, s28, s1
    s.movz       s28, #13
    vf.mul       v4, v5, v3
    s.add        s33, s5, s31
    v.extract    s31, v1, #13
    v.splat      v5, s31
    vf.cvt.f32.bf16 v9, v4
    s.muli       s31, s14, #13
    s.addi       s35, s18, #13
    v.splat      v4, s35
    @p3 v.st.h       [s15, #0], v9
    a.vread      v9, a0, s29
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v7
    s.add        s15, s31, s20
    s.movz       s29, #14
    s.add        s31, s15, s1
    v.extract    s15, v1, #14
    vf.mul       v7, v0, v3
    s.add        s35, s5, s31
    v.splat      v0, s15
    vf.cvt.f32.bf16 v9, v7
    s.muli       s15, s14, #14
    s.addi       s31, s18, #14
    v.splat      v7, s31
    @p4 v.st.h       [s30, #0], v9
    a.vread      v9, a0, s27
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v9, v8
    s.add        s27, s15, s20
    s.movz       s15, #15
    s.add        s30, s27, s1
    v.extract    s27, v1, #15
    vf.mul       v8, v4, v3
    s.add        s31, s5, s30
    v.splat      v4, s27
    vf.cvt.f32.bf16 v9, v8
    s.muli       s27, s14, #15
    s.addi       s30, s18, #15
    v.splat      v8, s30
    @p3 v.st.h       [s33, #0], v9
    a.vread      v9, a0, s28
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v9, v5
    s.add        s28, s27, s20
    s.movz       s27, #0
    s.add        s30, s28, s1
    v.extract    s1, v1, #0
    vf.mul       v5, v7, v3
    s.add        s28, s5, s30
    v.splat      v7, s1
    vf.cvt.f32.bf16 v9, v5
    s.movz       s1, #0
    s.muli       s30, s16, #2
    s.add        s33, s1, s16                    // the tile origin
    v.splat      v5, s18
    @p4 v.st.h       [s35, #0], v9
    a.vread      v9, a0, s29
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v0
    s.movz       s1, #0
    v.splat      v0, s33
    s.add        s16, s1, s9                     // the tile origin
    s.add        s1, s20, s30
    vf.mul       v9, v8, v3
    v.add        v8, v2, v0
    v.splat      v0, s16
    v.cmp.lt     p1, v5, v6
    s.add        s16, s5, s1
    vf.cvt.f32.bf16 v5, v9
    s.movz       s1, #1
    v.extract    s29, v1, #1
    s.muli       s33, s14, #1
    v.splat      v9, s29
    @p3 v.st.h       [s31, #0], v5
    a.vread      v5, a0, s15
    v.cmp.lt     p2, v8, v0
    p.and        p3, p1, p2
    vf.mul       v0, v5, v4
    s.addi       s15, s18, #1
    s.add        s29, s33, s20
    v.splat      v4, s15
    s.add        s15, s29, s30
    vf.mul       v5, v0, v3
    s.add        s29, s5, s15
    vf.cvt.f32.bf16 v0, v5
    s.movz       s15, #2
    v.extract    s31, v1, #2
    s.muli       s33, s14, #2
    v.splat      v5, s31
    @p4 v.st.h       [s28, #0], v0
    a.vread      v0, a1, s27
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v0, v7
    s.addi       s27, s18, #2
    s.add        s28, s33, s20
    v.splat      v0, s27
    s.add        s27, s28, s30
    vf.mul       v7, v4, v3
    s.add        s28, s5, s27
    vf.cvt.f32.bf16 v4, v7
    s.movz       s27, #3
    v.extract    s31, v1, #3
    s.muli       s33, s14, #3
    v.splat      v7, s31
    @p3 v.st.h       [s16, #0], v4
    a.vread      v4, a1, s1
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v4, v9
    s.addi       s1, s18, #3
    s.add        s16, s33, s20
    v.splat      v4, s1
    s.add        s1, s16, s30
    vf.mul       v8, v0, v3
    s.add        s16, s5, s1
    s.movz       s1, #4
    v.extract    s31, v1, #4
    vf.cvt.f32.bf16 v0, v8
    v.splat      v8, s31
    s.muli       s31, s14, #4
    s.addi       s33, s18, #4
    @p4 v.st.h       [s29, #0], v0
    a.vread      v0, a1, s15
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v0, v5
    s.add        s15, s31, s20
    v.splat      v0, s33
    s.add        s29, s15, s30
    s.movz       s15, #5
    vf.mul       v5, v4, v3
    s.add        s31, s5, s29
    v.extract    s29, v1, #5
    v.splat      v4, s29
    vf.cvt.f32.bf16 v9, v5
    s.muli       s29, s14, #5
    s.addi       s33, s18, #5
    v.splat      v5, s33
    @p3 v.st.h       [s28, #0], v9
    a.vread      v9, a1, s27
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v7
    s.add        s27, s29, s20
    s.movz       s28, #6
    s.add        s29, s27, s30
    v.extract    s27, v1, #6
    vf.mul       v7, v0, v3
    s.add        s33, s5, s29
    v.splat      v0, s27
    vf.cvt.f32.bf16 v9, v7
    s.muli       s27, s14, #6
    s.addi       s29, s18, #6
    v.splat      v7, s29
    @p4 v.st.h       [s16, #0], v9
    a.vread      v9, a1, s1
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v8
    s.add        s1, s27, s20
    s.movz       s16, #7
    s.add        s27, s1, s30
    v.extract    s1, v1, #7
    vf.mul       v8, v5, v3
    s.add        s29, s5, s27
    v.splat      v5, s1
    vf.cvt.f32.bf16 v9, v8
    s.muli       s1, s14, #7
    s.addi       s27, s18, #7
    v.splat      v8, s27
    @p3 v.st.h       [s31, #0], v9
    a.vread      v9, a1, s15
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v9, v4
    s.add        s15, s1, s20
    s.movz       s1, #8
    s.add        s27, s15, s30
    v.extract    s15, v1, #8
    vf.mul       v4, v7, v3
    s.add        s31, s5, s27
    v.splat      v7, s15
    vf.cvt.f32.bf16 v9, v4
    s.muli       s15, s14, #8
    s.addi       s27, s18, #8
    v.splat      v4, s27
    @p4 v.st.h       [s33, #0], v9
    a.vread      v9, a1, s28
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v0
    s.add        s27, s15, s20
    s.movz       s15, #9
    s.add        s28, s27, s30
    v.extract    s27, v1, #9
    vf.mul       v0, v8, v3
    s.add        s33, s5, s28
    v.splat      v8, s27
    vf.cvt.f32.bf16 v9, v0
    s.muli       s27, s14, #9
    s.addi       s28, s18, #9
    v.splat      v0, s28
    @p3 v.st.h       [s29, #0], v9
    a.vread      v9, a1, s16
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v5
    s.add        s16, s27, s20
    s.movz       s27, #10
    s.add        s28, s16, s30
    v.extract    s16, v1, #10
    vf.mul       v5, v4, v3
    s.add        s29, s5, s28
    v.splat      v4, s16
    vf.cvt.f32.bf16 v9, v5
    s.muli       s16, s14, #10
    s.addi       s28, s18, #10
    v.splat      v5, s28
    @p4 v.st.h       [s31, #0], v9
    a.vread      v9, a1, s1
    v.cmp.lt     p1, v0, v6
    p.and        p4, p1, p2
    vf.mul       v0, v9, v7
    s.add        s1, s16, s20
    s.movz       s16, #11
    s.add        s28, s1, s30
    v.extract    s1, v1, #11
    vf.mul       v7, v0, v3
    s.add        s31, s5, s28
    v.splat      v0, s1
    vf.cvt.f32.bf16 v9, v7
    s.muli       s1, s14, #11
    s.addi       s28, s18, #11
    v.splat      v7, s28
    @p3 v.st.h       [s33, #0], v9
    a.vread      v9, a1, s15
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v8
    s.add        s15, s1, s20
    s.movz       s1, #12
    s.add        s28, s15, s30
    v.extract    s15, v1, #12
    vf.mul       v8, v5, v3
    s.add        s33, s5, s28
    v.splat      v5, s15
    vf.cvt.f32.bf16 v9, v8
    s.muli       s15, s14, #12
    s.addi       s28, s18, #12
    v.splat      v8, s28
    @p4 v.st.h       [s29, #0], v9
    a.vread      v9, a1, s27
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v4
    s.add        s27, s15, s20
    s.movz       s15, #13
    s.add        s28, s27, s30
    v.extract    s27, v1, #13
    vf.mul       v4, v7, v3
    s.add        s29, s5, s28
    v.splat      v7, s27
    vf.cvt.f32.bf16 v9, v4
    s.muli       s27, s14, #13
    s.addi       s28, s18, #13
    v.splat      v4, s28
    @p3 v.st.h       [s31, #0], v9
    a.vread      v9, a1, s16
    v.cmp.lt     p1, v8, v6
    p.and        p3, p1, p2
    vf.mul       v8, v9, v0
    s.add        s16, s27, s20
    s.movz       s27, #14
    s.add        s28, s16, s30
    v.extract    s16, v1, #14
    vf.mul       v0, v8, v3
    s.add        s31, s5, s28
    v.splat      v8, s16
    vf.cvt.f32.bf16 v9, v0
    s.muli       s16, s14, #14
    s.addi       s28, s18, #14
    v.splat      v0, s28
    @p4 v.st.h       [s33, #0], v9
    a.vread      v9, a1, s1
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v9, v5
    s.add        s1, s16, s20
    s.movz       s16, #15
    s.add        s28, s1, s30
    v.extract    s1, v1, #15
    vf.mul       v5, v4, v3
    s.add        s33, s5, s28
    v.splat      v4, s1
    vf.cvt.f32.bf16 v9, v5
    s.muli       s1, s14, #15
    s.addi       s28, s18, #15
    v.splat      v5, s28
    @p3 v.st.h       [s29, #0], v9
    a.vread      v9, a1, s15
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v7
    s.add        s15, s1, s20
    s.movz       s1, #0
    s.add        s28, s15, s30
    v.extract    s15, v1, #0
    vf.mul       v7, v0, v3
    s.add        s29, s5, s28
    v.splat      v0, s15
    vf.cvt.f32.bf16 v9, v7
    s.movz       s15, #0
    s.muli       s28, s17, #2
    s.add        s30, s15, s17                   // the tile origin
    v.splat      v7, s18
    @p4 v.st.h       [s31, #0], v9
    a.vread      v9, a1, s27
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v8
    s.movz       s15, #0
    v.splat      v8, s30
    s.add        s17, s15, s9                    // the tile origin
    s.add        s15, s20, s28
    vf.mul       v9, v5, v3
    v.add        v5, v2, v8
    v.splat      v8, s17
    v.cmp.lt     p1, v7, v6
    s.add        s17, s5, s15
    vf.cvt.f32.bf16 v7, v9
    s.movz       s15, #1
    v.extract    s27, v1, #1
    s.muli       s30, s14, #1
    v.splat      v9, s27
    @p3 v.st.h       [s33, #0], v7
    a.vread      v7, a1, s16
    v.cmp.lt     p2, v5, v8
    p.and        p3, p1, p2
    vf.mul       v5, v7, v4
    s.addi       s16, s18, #1
    s.add        s27, s30, s20
    v.splat      v4, s16
    s.add        s16, s27, s28
    vf.mul       v7, v5, v3
    s.add        s27, s5, s16
    vf.cvt.f32.bf16 v5, v7
    s.movz       s16, #2
    v.extract    s30, v1, #2
    s.muli       s31, s14, #2
    v.splat      v7, s30
    @p4 v.st.h       [s29, #0], v5
    a.vread      v5, a2, s1
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v5, v0
    s.addi       s1, s18, #2
    s.add        s29, s31, s20
    v.splat      v0, s1
    s.add        s1, s29, s28
    vf.mul       v5, v4, v3
    s.add        s29, s5, s1
    vf.cvt.f32.bf16 v4, v5
    s.movz       s1, #3
    v.extract    s30, v1, #3
    s.muli       s31, s14, #3
    v.splat      v5, s30
    @p3 v.st.h       [s17, #0], v4
    a.vread      v4, a2, s15
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v4, v9
    s.addi       s15, s18, #3
    s.add        s17, s31, s20
    v.splat      v4, s15
    s.add        s15, s17, s28
    vf.mul       v8, v0, v3
    s.add        s17, s5, s15
    s.movz       s15, #4
    v.extract    s30, v1, #4
    vf.cvt.f32.bf16 v0, v8
    v.splat      v8, s30
    s.muli       s30, s14, #4
    s.addi       s31, s18, #4
    @p4 v.st.h       [s27, #0], v0
    a.vread      v0, a2, s16
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v0, v7
    s.add        s16, s30, s20
    v.splat      v0, s31
    s.add        s27, s16, s28
    s.movz       s16, #5
    vf.mul       v7, v4, v3
    s.add        s30, s5, s27
    v.extract    s27, v1, #5
    v.splat      v4, s27
    vf.cvt.f32.bf16 v9, v7
    s.muli       s27, s14, #5
    s.addi       s31, s18, #5
    v.splat      v7, s31
    @p3 v.st.h       [s29, #0], v9
    a.vread      v9, a2, s1
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v5
    s.add        s1, s27, s20
    s.movz       s27, #6
    s.add        s29, s1, s28
    v.extract    s1, v1, #6
    vf.mul       v5, v0, v3
    s.add        s31, s5, s29
    v.splat      v0, s1
    vf.cvt.f32.bf16 v9, v5
    s.muli       s1, s14, #6
    s.addi       s29, s18, #6
    v.splat      v5, s29
    @p4 v.st.h       [s17, #0], v9
    a.vread      v9, a2, s15
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v8
    s.add        s15, s1, s20
    s.movz       s1, #7
    s.add        s17, s15, s28
    v.extract    s15, v1, #7
    vf.mul       v8, v7, v3
    s.add        s29, s5, s17
    v.splat      v7, s15
    vf.cvt.f32.bf16 v9, v8
    s.muli       s15, s14, #7
    s.addi       s17, s18, #7
    v.splat      v8, s17
    @p3 v.st.h       [s30, #0], v9
    a.vread      v9, a2, s16
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v4
    s.add        s16, s15, s20
    s.movz       s15, #8
    s.add        s17, s16, s28
    v.extract    s16, v1, #8
    vf.mul       v4, v5, v3
    s.add        s30, s5, s17
    v.splat      v5, s16
    vf.cvt.f32.bf16 v9, v4
    s.muli       s16, s14, #8
    s.addi       s17, s18, #8
    v.splat      v4, s17
    @p4 v.st.h       [s31, #0], v9
    a.vread      v9, a2, s27
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v0
    s.add        s17, s16, s20
    s.movz       s16, #9
    s.add        s27, s17, s28
    v.extract    s17, v1, #9
    vf.mul       v0, v8, v3
    s.add        s31, s5, s27
    v.splat      v8, s17
    vf.cvt.f32.bf16 v9, v0
    s.muli       s17, s14, #9
    s.addi       s27, s18, #9
    v.splat      v0, s27
    @p3 v.st.h       [s29, #0], v9
    a.vread      v9, a2, s1
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v7
    s.add        s1, s17, s20
    s.movz       s17, #10
    s.add        s27, s1, s28
    v.extract    s1, v1, #10
    vf.mul       v7, v4, v3
    s.add        s29, s5, s27
    v.splat      v4, s1
    vf.cvt.f32.bf16 v9, v7
    s.muli       s1, s14, #10
    s.addi       s27, s18, #10
    v.splat      v7, s27
    @p4 v.st.h       [s30, #0], v9
    a.vread      v9, a2, s15
    v.cmp.lt     p1, v0, v6
    p.and        p4, p1, p2
    vf.mul       v0, v9, v5
    s.add        s15, s1, s20
    s.movz       s1, #11
    s.add        s27, s15, s28
    v.extract    s15, v1, #11
    vf.mul       v5, v0, v3
    s.add        s30, s5, s27
    v.splat      v0, s15
    vf.cvt.f32.bf16 v9, v5
    s.muli       s15, s14, #11
    s.addi       s27, s18, #11
    v.splat      v5, s27
    @p3 v.st.h       [s31, #0], v9
    a.vread      v9, a2, s16
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v9, v8
    s.add        s16, s15, s20
    s.movz       s15, #12
    s.add        s27, s16, s28
    v.extract    s16, v1, #12
    vf.mul       v8, v7, v3
    s.add        s31, s5, s27
    v.splat      v7, s16
    vf.cvt.f32.bf16 v9, v8
    s.muli       s16, s14, #12
    s.addi       s27, s18, #12
    v.splat      v8, s27
    @p4 v.st.h       [s29, #0], v9
    a.vread      v9, a2, s17
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v4
    s.add        s17, s16, s20
    s.movz       s16, #13
    s.add        s27, s17, s28
    v.extract    s17, v1, #13
    vf.mul       v4, v5, v3
    s.add        s29, s5, s27
    v.splat      v5, s17
    vf.cvt.f32.bf16 v9, v4
    s.muli       s17, s14, #13
    s.addi       s27, s18, #13
    v.splat      v4, s27
    @p3 v.st.h       [s30, #0], v9
    a.vread      v9, a2, s1
    v.cmp.lt     p1, v8, v6
    p.and        p3, p1, p2
    vf.mul       v8, v9, v0
    s.add        s1, s17, s20
    s.movz       s17, #14
    s.add        s27, s1, s28
    v.extract    s1, v1, #14
    vf.mul       v0, v8, v3
    s.add        s30, s5, s27
    v.splat      v8, s1
    vf.cvt.f32.bf16 v9, v0
    s.muli       s1, s14, #14
    s.addi       s27, s18, #14
    v.splat      v0, s27
    @p4 v.st.h       [s31, #0], v9
    a.vread      v9, a2, s15
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v9, v7
    s.add        s15, s1, s20
    s.movz       s1, #15
    s.add        s27, s15, s28
    v.extract    s15, v1, #15
    vf.mul       v7, v4, v3
    s.add        s31, s5, s27
    v.splat      v4, s15
    vf.cvt.f32.bf16 v9, v7
    s.muli       s15, s14, #15
    s.addi       s27, s18, #15
    v.splat      v7, s27
    @p3 v.st.h       [s29, #0], v9
    a.vread      v9, a2, s16
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v5
    s.add        s16, s15, s20
    s.movz       s15, #0
    s.add        s27, s16, s28
    v.extract    s16, v1, #0
    vf.mul       v5, v0, v3
    s.add        s28, s5, s27
    v.splat      v0, s16
    vf.cvt.f32.bf16 v9, v5
    s.movz       s16, #0
    s.muli       s27, s22, #2
    s.add        s29, s16, s22                   // the tile origin
    v.splat      v5, s18
    @p4 v.st.h       [s30, #0], v9
    a.vread      v9, a2, s17
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v8
    s.movz       s16, #0
    v.splat      v8, s29
    s.add        s17, s16, s9                    // the tile origin
    s.add        s16, s20, s27
    vf.mul       v9, v7, v3
    v.add        v7, v2, v8
    v.splat      v8, s17
    v.cmp.lt     p1, v5, v6
    s.add        s17, s5, s16
    vf.cvt.f32.bf16 v5, v9
    s.movz       s16, #1
    v.extract    s22, v1, #1
    s.muli       s29, s14, #1
    v.splat      v9, s22
    @p3 v.st.h       [s31, #0], v5
    a.vread      v5, a2, s1
    v.cmp.lt     p2, v7, v8
    p.and        p3, p1, p2
    vf.mul       v7, v5, v4
    s.addi       s1, s18, #1
    s.add        s22, s29, s20
    v.splat      v4, s1
    s.add        s1, s22, s27
    vf.mul       v5, v7, v3
    s.add        s22, s5, s1
    vf.cvt.f32.bf16 v7, v5
    s.movz       s1, #2
    v.extract    s29, v1, #2
    s.muli       s30, s14, #2
    v.splat      v5, s29
    @p4 v.st.h       [s28, #0], v7
    a.vread      v7, a3, s15
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v7, v0
    s.addi       s15, s18, #2
    s.add        s28, s30, s20
    v.splat      v0, s15
    s.add        s15, s28, s27
    vf.mul       v7, v4, v3
    s.add        s28, s5, s15
    vf.cvt.f32.bf16 v4, v7
    s.movz       s15, #3
    v.extract    s29, v1, #3
    s.muli       s30, s14, #3
    v.splat      v7, s29
    @p3 v.st.h       [s17, #0], v4
    a.vread      v4, a3, s16
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v4, v9
    s.addi       s16, s18, #3
    s.add        s17, s30, s20
    v.splat      v4, s16
    s.add        s16, s17, s27
    vf.mul       v8, v0, v3
    s.add        s17, s5, s16
    s.movz       s16, #4
    v.extract    s29, v1, #4
    vf.cvt.f32.bf16 v0, v8
    v.splat      v8, s29
    s.muli       s29, s14, #4
    s.addi       s30, s18, #4
    @p4 v.st.h       [s22, #0], v0
    a.vread      v0, a3, s1
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v0, v5
    s.add        s1, s29, s20
    v.splat      v0, s30
    s.add        s22, s1, s27
    s.movz       s1, #5
    vf.mul       v5, v4, v3
    s.add        s29, s5, s22
    v.extract    s22, v1, #5
    v.splat      v4, s22
    vf.cvt.f32.bf16 v9, v5
    s.muli       s22, s14, #5
    s.addi       s30, s18, #5
    v.splat      v5, s30
    @p3 v.st.h       [s28, #0], v9
    a.vread      v9, a3, s15
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v7
    s.add        s15, s22, s20
    s.movz       s22, #6
    s.add        s28, s15, s27
    v.extract    s15, v1, #6
    vf.mul       v7, v0, v3
    s.add        s30, s5, s28
    v.splat      v0, s15
    vf.cvt.f32.bf16 v9, v7
    s.muli       s15, s14, #6
    s.addi       s28, s18, #6
    v.splat      v7, s28
    @p4 v.st.h       [s17, #0], v9
    a.vread      v9, a3, s16
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v8
    s.add        s16, s15, s20
    s.movz       s15, #7
    s.add        s17, s16, s27
    v.extract    s16, v1, #7
    vf.mul       v8, v5, v3
    s.add        s28, s5, s17
    v.splat      v5, s16
    vf.cvt.f32.bf16 v9, v8
    s.muli       s16, s14, #7
    s.addi       s17, s18, #7
    v.splat      v8, s17
    @p3 v.st.h       [s29, #0], v9
    a.vread      v9, a3, s1
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v9, v4
    s.add        s1, s16, s20
    s.movz       s16, #8
    s.add        s17, s1, s27
    v.extract    s1, v1, #8
    vf.mul       v4, v7, v3
    s.add        s29, s5, s17
    v.splat      v7, s1
    vf.cvt.f32.bf16 v9, v4
    s.muli       s1, s14, #8
    s.addi       s17, s18, #8
    v.splat      v4, s17
    @p4 v.st.h       [s30, #0], v9
    a.vread      v9, a3, s22
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v0
    s.add        s17, s1, s20
    s.movz       s1, #9
    s.add        s22, s17, s27
    v.extract    s17, v1, #9
    vf.mul       v0, v8, v3
    s.add        s30, s5, s22
    v.splat      v8, s17
    vf.cvt.f32.bf16 v9, v0
    s.muli       s17, s14, #9
    s.addi       s22, s18, #9
    v.splat      v0, s22
    @p3 v.st.h       [s28, #0], v9
    a.vread      v9, a3, s15
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v5
    s.add        s15, s17, s20
    s.movz       s17, #10
    s.add        s22, s15, s27
    v.extract    s15, v1, #10
    vf.mul       v5, v4, v3
    s.add        s28, s5, s22
    v.splat      v4, s15
    vf.cvt.f32.bf16 v9, v5
    s.muli       s15, s14, #10
    s.addi       s22, s18, #10
    v.splat      v5, s22
    @p4 v.st.h       [s29, #0], v9
    a.vread      v9, a3, s16
    v.cmp.lt     p1, v0, v6
    p.and        p4, p1, p2
    vf.mul       v0, v9, v7
    s.add        s16, s15, s20
    s.movz       s15, #11
    s.add        s22, s16, s27
    v.extract    s16, v1, #11
    vf.mul       v7, v0, v3
    s.add        s29, s5, s22
    v.splat      v0, s16
    vf.cvt.f32.bf16 v9, v7
    s.muli       s16, s14, #11
    s.addi       s22, s18, #11
    v.splat      v7, s22
    @p3 v.st.h       [s30, #0], v9
    a.vread      v9, a3, s1
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v8
    s.add        s1, s16, s20
    s.movz       s16, #12
    s.add        s22, s1, s27
    v.extract    s1, v1, #12
    vf.mul       v8, v5, v3
    s.add        s30, s5, s22
    v.splat      v5, s1
    vf.cvt.f32.bf16 v9, v8
    s.muli       s1, s14, #12
    s.addi       s22, s18, #12
    v.splat      v8, s22
    @p4 v.st.h       [s28, #0], v9
    a.vread      v9, a3, s17
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v4
    s.add        s17, s1, s20
    s.movz       s1, #13
    s.add        s22, s17, s27
    v.extract    s17, v1, #13
    vf.mul       v4, v7, v3
    s.add        s28, s5, s22
    v.splat      v7, s17
    vf.cvt.f32.bf16 v9, v4
    s.muli       s17, s14, #13
    s.addi       s22, s18, #13
    v.splat      v4, s22
    @p3 v.st.h       [s29, #0], v9
    a.vread      v9, a3, s15
    v.cmp.lt     p1, v8, v6
    p.and        p3, p1, p2
    vf.mul       v8, v9, v0
    s.add        s15, s17, s20
    s.movz       s17, #14
    s.add        s22, s15, s27
    v.extract    s15, v1, #14
    vf.mul       v0, v8, v3
    s.add        s29, s5, s22
    v.splat      v8, s15
    vf.cvt.f32.bf16 v9, v0
    s.muli       s15, s14, #14
    s.addi       s22, s18, #14
    v.splat      v0, s22
    @p4 v.st.h       [s30, #0], v9
    a.vread      v9, a3, s16
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v9, v5
    s.add        s16, s15, s20
    s.movz       s15, #15
    s.add        s22, s16, s27
    v.extract    s16, v1, #15
    vf.mul       v5, v4, v3
    s.add        s30, s5, s22
    v.splat      v4, s16
    vf.cvt.f32.bf16 v9, v5
    s.muli       s16, s14, #15
    s.addi       s22, s18, #15
    v.splat      v5, s22
    @p3 v.st.h       [s28, #0], v9
    a.vread      v9, a3, s1
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v7
    s.add        s1, s16, s20
    s.movz       s16, #0
    s.add        s22, s1, s27
    v.extract    s1, v1, #0
    vf.mul       v7, v0, v3
    s.add        s27, s5, s22
    v.splat      v0, s1
    vf.cvt.f32.bf16 v9, v7
    s.movz       s1, #0
    s.muli       s22, s19, #2
    s.add        s28, s1, s19                    // the tile origin
    v.splat      v7, s18
    @p4 v.st.h       [s29, #0], v9
    a.vread      v9, a3, s17
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v8
    s.movz       s1, #0
    v.splat      v8, s28
    s.add        s17, s1, s9                     // the tile origin
    s.add        s1, s20, s22
    vf.mul       v9, v5, v3
    v.add        v5, v2, v8
    v.splat      v8, s17
    v.cmp.lt     p1, v7, v6
    s.add        s17, s5, s1
    vf.cvt.f32.bf16 v7, v9
    s.movz       s1, #1
    v.extract    s19, v1, #1
    s.muli       s28, s14, #1
    v.splat      v9, s19
    @p3 v.st.h       [s30, #0], v7
    a.vread      v7, a3, s15
    v.cmp.lt     p2, v5, v8
    p.and        p3, p1, p2
    vf.mul       v5, v7, v4
    s.addi       s15, s18, #1
    s.add        s19, s28, s20
    v.splat      v4, s15
    s.add        s15, s19, s22
    vf.mul       v7, v5, v3
    s.add        s19, s5, s15
    vf.cvt.f32.bf16 v5, v7
    s.movz       s15, #2
    v.extract    s28, v1, #2
    s.muli       s29, s14, #2
    v.splat      v7, s28
    @p4 v.st.h       [s27, #0], v5
    a.vread      v5, a4, s16
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v5, v0
    s.addi       s16, s18, #2
    s.add        s27, s29, s20
    v.splat      v0, s16
    s.add        s16, s27, s22
    vf.mul       v5, v4, v3
    s.add        s27, s5, s16
    vf.cvt.f32.bf16 v4, v5
    s.movz       s16, #3
    v.extract    s28, v1, #3
    s.muli       s29, s14, #3
    v.splat      v5, s28
    @p3 v.st.h       [s17, #0], v4
    a.vread      v4, a4, s1
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v4, v9
    s.addi       s1, s18, #3
    s.add        s17, s29, s20
    v.splat      v4, s1
    s.add        s1, s17, s22
    vf.mul       v8, v0, v3
    s.add        s17, s5, s1
    s.movz       s1, #4
    v.extract    s28, v1, #4
    vf.cvt.f32.bf16 v0, v8
    v.splat      v8, s28
    s.muli       s28, s14, #4
    s.addi       s29, s18, #4
    @p4 v.st.h       [s19, #0], v0
    a.vread      v0, a4, s15
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v0, v7
    s.add        s15, s28, s20
    v.splat      v0, s29
    s.add        s19, s15, s22
    s.movz       s15, #5
    vf.mul       v7, v4, v3
    s.add        s28, s5, s19
    v.extract    s19, v1, #5
    v.splat      v4, s19
    vf.cvt.f32.bf16 v9, v7
    s.muli       s19, s14, #5
    s.addi       s29, s18, #5
    v.splat      v7, s29
    @p3 v.st.h       [s27, #0], v9
    a.vread      v9, a4, s16
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v5
    s.add        s16, s19, s20
    s.movz       s19, #6
    s.add        s27, s16, s22
    v.extract    s16, v1, #6
    vf.mul       v5, v0, v3
    s.add        s29, s5, s27
    v.splat      v0, s16
    vf.cvt.f32.bf16 v9, v5
    s.muli       s16, s14, #6
    s.addi       s27, s18, #6
    v.splat      v5, s27
    @p4 v.st.h       [s17, #0], v9
    a.vread      v9, a4, s1
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v8
    s.add        s1, s16, s20
    s.movz       s16, #7
    s.add        s17, s1, s22
    v.extract    s1, v1, #7
    vf.mul       v8, v7, v3
    s.add        s27, s5, s17
    v.splat      v7, s1
    vf.cvt.f32.bf16 v9, v8
    s.muli       s1, s14, #7
    s.addi       s17, s18, #7
    v.splat      v8, s17
    @p3 v.st.h       [s28, #0], v9
    a.vread      v9, a4, s15
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v4
    s.add        s15, s1, s20
    s.movz       s1, #8
    s.add        s17, s15, s22
    v.extract    s15, v1, #8
    vf.mul       v4, v5, v3
    s.add        s28, s5, s17
    v.splat      v5, s15
    vf.cvt.f32.bf16 v9, v4
    s.muli       s15, s14, #8
    s.addi       s17, s18, #8
    v.splat      v4, s17
    @p4 v.st.h       [s29, #0], v9
    a.vread      v9, a4, s19
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v0
    s.add        s17, s15, s20
    s.movz       s15, #9
    s.add        s19, s17, s22
    v.extract    s17, v1, #9
    vf.mul       v0, v8, v3
    s.add        s29, s5, s19
    v.splat      v8, s17
    vf.cvt.f32.bf16 v9, v0
    s.muli       s17, s14, #9
    s.addi       s19, s18, #9
    v.splat      v0, s19
    @p3 v.st.h       [s27, #0], v9
    a.vread      v9, a4, s16
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v7
    s.add        s16, s17, s20
    s.movz       s17, #10
    s.add        s19, s16, s22
    v.extract    s16, v1, #10
    vf.mul       v7, v4, v3
    s.add        s27, s5, s19
    v.splat      v4, s16
    vf.cvt.f32.bf16 v9, v7
    s.muli       s16, s14, #10
    s.addi       s19, s18, #10
    v.splat      v7, s19
    @p4 v.st.h       [s28, #0], v9
    a.vread      v9, a4, s1
    v.cmp.lt     p1, v0, v6
    p.and        p4, p1, p2
    vf.mul       v0, v9, v5
    s.add        s1, s16, s20
    s.movz       s16, #11
    s.add        s19, s1, s22
    v.extract    s1, v1, #11
    vf.mul       v5, v0, v3
    s.add        s28, s5, s19
    v.splat      v0, s1
    vf.cvt.f32.bf16 v9, v5
    s.muli       s1, s14, #11
    s.addi       s19, s18, #11
    v.splat      v5, s19
    @p3 v.st.h       [s29, #0], v9
    a.vread      v9, a4, s15
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v9, v8
    s.add        s15, s1, s20
    s.movz       s1, #12
    s.add        s19, s15, s22
    v.extract    s15, v1, #12
    vf.mul       v8, v7, v3
    s.add        s29, s5, s19
    v.splat      v7, s15
    vf.cvt.f32.bf16 v9, v8
    s.muli       s15, s14, #12
    s.addi       s19, s18, #12
    v.splat      v8, s19
    @p4 v.st.h       [s27, #0], v9
    a.vread      v9, a4, s17
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v4
    s.add        s17, s15, s20
    s.movz       s15, #13
    s.add        s19, s17, s22
    v.extract    s17, v1, #13
    vf.mul       v4, v5, v3
    s.add        s27, s5, s19
    v.splat      v5, s17
    vf.cvt.f32.bf16 v9, v4
    s.muli       s17, s14, #13
    s.addi       s19, s18, #13
    v.splat      v4, s19
    @p3 v.st.h       [s28, #0], v9
    a.vread      v9, a4, s16
    v.cmp.lt     p1, v8, v6
    p.and        p3, p1, p2
    vf.mul       v8, v9, v0
    s.add        s16, s17, s20
    s.movz       s17, #14
    s.add        s19, s16, s22
    v.extract    s16, v1, #14
    vf.mul       v0, v8, v3
    s.add        s28, s5, s19
    v.splat      v8, s16
    vf.cvt.f32.bf16 v9, v0
    s.muli       s16, s14, #14
    s.addi       s19, s18, #14
    v.splat      v0, s19
    @p4 v.st.h       [s29, #0], v9
    a.vread      v9, a4, s1
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v9, v7
    s.add        s1, s16, s20
    s.movz       s16, #15
    s.add        s19, s1, s22
    v.extract    s1, v1, #15
    vf.mul       v7, v4, v3
    s.add        s29, s5, s19
    v.splat      v4, s1
    vf.cvt.f32.bf16 v9, v7
    s.muli       s1, s14, #15
    s.addi       s19, s18, #15
    v.splat      v7, s19
    @p3 v.st.h       [s27, #0], v9
    a.vread      v9, a4, s15
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v5
    s.add        s15, s1, s20
    s.movz       s1, #0
    s.add        s19, s15, s22
    v.extract    s15, v1, #0
    vf.mul       v5, v0, v3
    s.add        s22, s5, s19
    v.splat      v0, s15
    vf.cvt.f32.bf16 v9, v5
    s.movz       s15, #0
    s.muli       s19, s25, #2
    s.add        s27, s15, s25                   // the tile origin
    v.splat      v5, s18
    @p4 v.st.h       [s28, #0], v9
    a.vread      v9, a4, s17
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v8
    s.movz       s15, #0
    v.splat      v8, s27
    s.add        s17, s15, s9                    // the tile origin
    s.add        s15, s20, s19
    vf.mul       v9, v7, v3
    v.add        v7, v2, v8
    v.splat      v8, s17
    v.cmp.lt     p1, v5, v6
    s.add        s17, s5, s15
    vf.cvt.f32.bf16 v5, v9
    s.movz       s15, #1
    v.extract    s25, v1, #1
    s.muli       s27, s14, #1
    v.splat      v9, s25
    @p3 v.st.h       [s29, #0], v5
    a.vread      v5, a4, s16
    v.cmp.lt     p2, v7, v8
    p.and        p3, p1, p2
    vf.mul       v7, v5, v4
    s.addi       s16, s18, #1
    s.add        s25, s27, s20
    v.splat      v4, s16
    s.add        s16, s25, s19
    vf.mul       v5, v7, v3
    s.add        s25, s5, s16
    vf.cvt.f32.bf16 v7, v5
    s.movz       s16, #2
    v.extract    s27, v1, #2
    s.muli       s28, s14, #2
    v.splat      v5, s27
    @p4 v.st.h       [s22, #0], v7
    a.vread      v7, a5, s1
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v7, v0
    s.addi       s1, s18, #2
    s.add        s22, s28, s20
    v.splat      v0, s1
    s.add        s1, s22, s19
    vf.mul       v7, v4, v3
    s.add        s22, s5, s1
    vf.cvt.f32.bf16 v4, v7
    s.movz       s1, #3
    v.extract    s27, v1, #3
    s.muli       s28, s14, #3
    v.splat      v7, s27
    @p3 v.st.h       [s17, #0], v4
    a.vread      v4, a5, s15
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v4, v9
    s.addi       s15, s18, #3
    s.add        s17, s28, s20
    v.splat      v4, s15
    s.add        s15, s17, s19
    vf.mul       v8, v0, v3
    s.add        s17, s5, s15
    s.movz       s15, #4
    v.extract    s27, v1, #4
    vf.cvt.f32.bf16 v0, v8
    v.splat      v8, s27
    s.muli       s27, s14, #4
    s.addi       s28, s18, #4
    @p4 v.st.h       [s25, #0], v0
    a.vread      v0, a5, s16
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v0, v5
    s.add        s16, s27, s20
    v.splat      v0, s28
    s.add        s25, s16, s19
    s.movz       s16, #5
    vf.mul       v5, v4, v3
    s.add        s27, s5, s25
    v.extract    s25, v1, #5
    v.splat      v4, s25
    vf.cvt.f32.bf16 v9, v5
    s.muli       s25, s14, #5
    s.addi       s28, s18, #5
    v.splat      v5, s28
    @p3 v.st.h       [s22, #0], v9
    a.vread      v9, a5, s1
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v7
    s.add        s1, s25, s20
    s.movz       s22, #6
    s.add        s25, s1, s19
    v.extract    s1, v1, #6
    vf.mul       v7, v0, v3
    s.add        s28, s5, s25
    v.splat      v0, s1
    vf.cvt.f32.bf16 v9, v7
    s.muli       s1, s14, #6
    s.addi       s25, s18, #6
    v.splat      v7, s25
    @p4 v.st.h       [s17, #0], v9
    a.vread      v9, a5, s15
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v8
    s.add        s15, s1, s20
    s.movz       s1, #7
    s.add        s17, s15, s19
    v.extract    s15, v1, #7
    vf.mul       v8, v5, v3
    s.add        s25, s5, s17
    v.splat      v5, s15
    vf.cvt.f32.bf16 v9, v8
    s.muli       s15, s14, #7
    s.addi       s17, s18, #7
    v.splat      v8, s17
    @p3 v.st.h       [s27, #0], v9
    a.vread      v9, a5, s16
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v9, v4
    s.add        s16, s15, s20
    s.movz       s15, #8
    s.add        s17, s16, s19
    v.extract    s16, v1, #8
    vf.mul       v4, v7, v3
    s.add        s27, s5, s17
    v.splat      v7, s16
    vf.cvt.f32.bf16 v9, v4
    s.muli       s16, s14, #8
    s.addi       s17, s18, #8
    v.splat      v4, s17
    @p4 v.st.h       [s28, #0], v9
    a.vread      v9, a5, s22
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v0
    s.add        s17, s16, s20
    s.movz       s16, #9
    s.add        s22, s17, s19
    v.extract    s17, v1, #9
    vf.mul       v0, v8, v3
    s.add        s28, s5, s22
    v.splat      v8, s17
    vf.cvt.f32.bf16 v9, v0
    s.muli       s17, s14, #9
    s.addi       s22, s18, #9
    v.splat      v0, s22
    @p3 v.st.h       [s25, #0], v9
    a.vread      v9, a5, s1
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v5
    s.add        s1, s17, s20
    s.movz       s17, #10
    s.add        s22, s1, s19
    v.extract    s1, v1, #10
    vf.mul       v5, v4, v3
    s.add        s25, s5, s22
    v.splat      v4, s1
    vf.cvt.f32.bf16 v9, v5
    s.muli       s1, s14, #10
    s.addi       s22, s18, #10
    v.splat      v5, s22
    @p4 v.st.h       [s27, #0], v9
    a.vread      v9, a5, s15
    v.cmp.lt     p1, v0, v6
    p.and        p4, p1, p2
    vf.mul       v0, v9, v7
    s.add        s15, s1, s20
    s.movz       s1, #11
    s.add        s22, s15, s19
    v.extract    s15, v1, #11
    vf.mul       v7, v0, v3
    s.add        s27, s5, s22
    v.splat      v0, s15
    vf.cvt.f32.bf16 v9, v7
    s.muli       s15, s14, #11
    s.addi       s22, s18, #11
    v.splat      v7, s22
    @p3 v.st.h       [s28, #0], v9
    a.vread      v9, a5, s16
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v8
    s.add        s16, s15, s20
    s.movz       s15, #12
    s.add        s22, s16, s19
    v.extract    s16, v1, #12
    vf.mul       v8, v5, v3
    s.add        s28, s5, s22
    v.splat      v5, s16
    vf.cvt.f32.bf16 v9, v8
    s.muli       s16, s14, #12
    s.addi       s22, s18, #12
    v.splat      v8, s22
    @p4 v.st.h       [s25, #0], v9
    a.vread      v9, a5, s17
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v4
    s.add        s17, s16, s20
    s.movz       s16, #13
    s.add        s22, s17, s19
    v.extract    s17, v1, #13
    vf.mul       v4, v7, v3
    s.add        s25, s5, s22
    v.splat      v7, s17
    vf.cvt.f32.bf16 v9, v4
    s.muli       s17, s14, #13
    s.addi       s22, s18, #13
    v.splat      v4, s22
    @p3 v.st.h       [s27, #0], v9
    a.vread      v9, a5, s1
    v.cmp.lt     p1, v8, v6
    p.and        p3, p1, p2
    vf.mul       v8, v9, v0
    s.add        s1, s17, s20
    s.movz       s17, #14
    s.add        s22, s1, s19
    v.extract    s1, v1, #14
    vf.mul       v0, v8, v3
    s.add        s27, s5, s22
    v.splat      v8, s1
    vf.cvt.f32.bf16 v9, v0
    s.muli       s1, s14, #14
    s.addi       s22, s18, #14
    v.splat      v0, s22
    @p4 v.st.h       [s28, #0], v9
    a.vread      v9, a5, s15
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v9, v5
    s.add        s15, s1, s20
    s.movz       s1, #15
    s.add        s22, s15, s19
    v.extract    s15, v1, #15
    vf.mul       v5, v4, v3
    s.add        s28, s5, s22
    v.splat      v4, s15
    vf.cvt.f32.bf16 v9, v5
    s.muli       s15, s14, #15
    s.addi       s22, s18, #15
    v.splat      v5, s22
    @p3 v.st.h       [s25, #0], v9
    a.vread      v9, a5, s16
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v7
    s.add        s16, s15, s20
    s.movz       s15, #0
    s.add        s22, s16, s19
    v.extract    s16, v1, #0
    vf.mul       v7, v0, v3
    s.add        s19, s5, s22
    v.splat      v0, s16
    vf.cvt.f32.bf16 v9, v7
    s.movz       s16, #0
    s.muli       s22, s21, #2
    s.add        s25, s16, s21                   // the tile origin
    v.splat      v7, s18
    @p4 v.st.h       [s27, #0], v9
    a.vread      v9, a5, s17
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v8
    s.movz       s16, #0
    v.splat      v8, s25
    s.add        s17, s16, s9                    // the tile origin
    s.add        s16, s20, s22
    vf.mul       v9, v5, v3
    v.add        v5, v2, v8
    v.splat      v8, s17
    v.cmp.lt     p1, v7, v6
    s.add        s17, s5, s16
    vf.cvt.f32.bf16 v7, v9
    s.movz       s16, #1
    v.extract    s21, v1, #1
    s.muli       s25, s14, #1
    v.splat      v9, s21
    @p3 v.st.h       [s28, #0], v7
    a.vread      v7, a5, s1
    v.cmp.lt     p2, v5, v8
    p.and        p3, p1, p2
    vf.mul       v5, v7, v4
    s.addi       s1, s18, #1
    s.add        s21, s25, s20
    v.splat      v4, s1
    s.add        s1, s21, s22
    vf.mul       v7, v5, v3
    s.add        s21, s5, s1
    vf.cvt.f32.bf16 v5, v7
    s.movz       s1, #2
    v.extract    s25, v1, #2
    s.muli       s27, s14, #2
    v.splat      v7, s25
    @p4 v.st.h       [s19, #0], v5
    a.vread      v5, a6, s15
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v5, v0
    s.addi       s15, s18, #2
    s.add        s19, s27, s20
    v.splat      v0, s15
    s.add        s15, s19, s22
    vf.mul       v5, v4, v3
    s.add        s19, s5, s15
    vf.cvt.f32.bf16 v4, v5
    s.movz       s15, #3
    v.extract    s25, v1, #3
    s.muli       s27, s14, #3
    v.splat      v5, s25
    @p3 v.st.h       [s17, #0], v4
    a.vread      v4, a6, s16
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v4, v9
    s.addi       s16, s18, #3
    s.add        s17, s27, s20
    v.splat      v4, s16
    s.add        s16, s17, s22
    vf.mul       v8, v0, v3
    s.add        s17, s5, s16
    s.movz       s16, #4
    v.extract    s25, v1, #4
    vf.cvt.f32.bf16 v0, v8
    v.splat      v8, s25
    s.muli       s25, s14, #4
    s.addi       s27, s18, #4
    @p4 v.st.h       [s21, #0], v0
    a.vread      v0, a6, s1
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v0, v7
    s.add        s1, s25, s20
    v.splat      v0, s27
    s.add        s21, s1, s22
    s.movz       s1, #5
    vf.mul       v7, v4, v3
    s.add        s25, s5, s21
    v.extract    s21, v1, #5
    v.splat      v4, s21
    vf.cvt.f32.bf16 v9, v7
    s.muli       s21, s14, #5
    s.addi       s27, s18, #5
    v.splat      v7, s27
    @p3 v.st.h       [s19, #0], v9
    a.vread      v9, a6, s15
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v5
    s.add        s15, s21, s20
    s.movz       s19, #6
    s.add        s21, s15, s22
    v.extract    s15, v1, #6
    vf.mul       v5, v0, v3
    s.add        s27, s5, s21
    v.splat      v0, s15
    vf.cvt.f32.bf16 v9, v5
    s.muli       s15, s14, #6
    s.addi       s21, s18, #6
    v.splat      v5, s21
    @p4 v.st.h       [s17, #0], v9
    a.vread      v9, a6, s16
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v8
    s.add        s16, s15, s20
    s.movz       s15, #7
    s.add        s17, s16, s22
    v.extract    s16, v1, #7
    vf.mul       v8, v7, v3
    s.add        s21, s5, s17
    v.splat      v7, s16
    vf.cvt.f32.bf16 v9, v8
    s.muli       s16, s14, #7
    s.addi       s17, s18, #7
    v.splat      v8, s17
    @p3 v.st.h       [s25, #0], v9
    a.vread      v9, a6, s1
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v4
    s.add        s1, s16, s20
    s.movz       s16, #8
    s.add        s17, s1, s22
    v.extract    s1, v1, #8
    vf.mul       v4, v5, v3
    s.add        s25, s5, s17
    v.splat      v5, s1
    vf.cvt.f32.bf16 v9, v4
    s.muli       s1, s14, #8
    s.addi       s17, s18, #8
    v.splat      v4, s17
    @p4 v.st.h       [s27, #0], v9
    a.vread      v9, a6, s19
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v0
    s.add        s17, s1, s20
    s.movz       s1, #9
    s.add        s19, s17, s22
    v.extract    s17, v1, #9
    vf.mul       v0, v8, v3
    s.add        s27, s5, s19
    v.splat      v8, s17
    vf.cvt.f32.bf16 v9, v0
    s.muli       s17, s14, #9
    s.addi       s19, s18, #9
    v.splat      v0, s19
    @p3 v.st.h       [s21, #0], v9
    a.vread      v9, a6, s15
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v7
    s.add        s15, s17, s20
    s.movz       s17, #10
    s.add        s19, s15, s22
    v.extract    s15, v1, #10
    vf.mul       v7, v4, v3
    s.add        s21, s5, s19
    v.splat      v4, s15
    vf.cvt.f32.bf16 v9, v7
    s.muli       s15, s14, #10
    s.addi       s19, s18, #10
    v.splat      v7, s19
    @p4 v.st.h       [s25, #0], v9
    a.vread      v9, a6, s16
    v.cmp.lt     p1, v0, v6
    p.and        p4, p1, p2
    vf.mul       v0, v9, v5
    s.add        s16, s15, s20
    s.movz       s15, #11
    s.add        s19, s16, s22
    v.extract    s16, v1, #11
    vf.mul       v5, v0, v3
    s.add        s25, s5, s19
    v.splat      v0, s16
    vf.cvt.f32.bf16 v9, v5
    s.muli       s16, s14, #11
    s.addi       s19, s18, #11
    v.splat      v5, s19
    @p3 v.st.h       [s27, #0], v9
    a.vread      v9, a6, s1
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v9, v8
    s.add        s1, s16, s20
    s.movz       s16, #12
    s.add        s19, s1, s22
    v.extract    s1, v1, #12
    vf.mul       v8, v7, v3
    s.add        s27, s5, s19
    v.splat      v7, s1
    vf.cvt.f32.bf16 v9, v8
    s.muli       s1, s14, #12
    s.addi       s19, s18, #12
    v.splat      v8, s19
    @p4 v.st.h       [s21, #0], v9
    a.vread      v9, a6, s17
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v4
    s.add        s17, s1, s20
    s.movz       s1, #13
    s.add        s19, s17, s22
    v.extract    s17, v1, #13
    vf.mul       v4, v5, v3
    s.add        s21, s5, s19
    v.splat      v5, s17
    vf.cvt.f32.bf16 v9, v4
    s.muli       s17, s14, #13
    s.addi       s19, s18, #13
    v.splat      v4, s19
    @p3 v.st.h       [s25, #0], v9
    a.vread      v9, a6, s15
    v.cmp.lt     p1, v8, v6
    p.and        p3, p1, p2
    vf.mul       v8, v9, v0
    s.add        s15, s17, s20
    s.movz       s17, #14
    s.add        s19, s15, s22
    v.extract    s15, v1, #14
    vf.mul       v0, v8, v3
    s.add        s25, s5, s19
    v.splat      v8, s15
    vf.cvt.f32.bf16 v9, v0
    s.muli       s15, s14, #14
    s.addi       s19, s18, #14
    v.splat      v0, s19
    @p4 v.st.h       [s27, #0], v9
    a.vread      v9, a6, s16
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v9, v7
    s.add        s16, s15, s20
    s.movz       s15, #15
    s.add        s19, s16, s22
    v.extract    s16, v1, #15
    vf.mul       v7, v4, v3
    s.add        s27, s5, s19
    v.splat      v4, s16
    vf.cvt.f32.bf16 v9, v7
    s.muli       s16, s14, #15
    s.addi       s19, s18, #15
    v.splat      v7, s19
    @p3 v.st.h       [s21, #0], v9
    a.vread      v9, a6, s1
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v5
    s.add        s1, s16, s20
    s.movz       s16, #0
    s.add        s19, s1, s22
    v.extract    s1, v1, #0
    vf.mul       v5, v0, v3
    s.add        s21, s5, s19
    v.splat      v0, s1
    vf.cvt.f32.bf16 v9, v5
    s.movz       s1, #0
    s.muli       s19, s26, #2
    s.add        s22, s1, s26                    // the tile origin
    v.splat      v5, s18
    @p4 v.st.h       [s25, #0], v9
    a.vread      v9, a6, s17
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v8
    s.movz       s1, #0
    v.splat      v8, s22
    s.add        s17, s1, s9                     // the tile origin
    s.add        s1, s20, s19
    vf.mul       v9, v7, v3
    v.add        v7, v2, v8
    v.splat      v2, s17
    v.cmp.lt     p1, v5, v6
    s.add        s17, s5, s1
    vf.cvt.f32.bf16 v5, v9
    s.movz       s1, #1
    v.extract    s22, v1, #1
    s.muli       s25, s14, #1
    v.splat      v8, s22
    @p3 v.st.h       [s27, #0], v5
    a.vread      v5, a6, s15
    v.cmp.lt     p2, v7, v2
    p.and        p3, p1, p2
    vf.mul       v2, v5, v4
    s.addi       s15, s18, #1
    s.add        s22, s25, s20
    v.splat      v4, s15
    s.add        s15, s22, s19
    vf.mul       v5, v2, v3
    s.add        s22, s5, s15
    vf.cvt.f32.bf16 v2, v5
    s.movz       s15, #2
    v.extract    s25, v1, #2
    s.muli       s26, s14, #2
    v.splat      v5, s25
    @p4 v.st.h       [s21, #0], v2
    a.vread      v2, a7, s16
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v2, v0
    s.addi       s16, s18, #2
    s.add        s21, s26, s20
    v.splat      v0, s16
    s.add        s16, s21, s19
    vf.mul       v2, v4, v3
    s.add        s21, s5, s16
    vf.cvt.f32.bf16 v4, v2
    s.movz       s16, #3
    v.extract    s25, v1, #3
    s.muli       s26, s14, #3
    v.splat      v2, s25
    @p3 v.st.h       [s17, #0], v4
    a.vread      v4, a7, s1
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v4, v8
    s.addi       s1, s18, #3
    s.add        s17, s26, s20
    v.splat      v4, s1
    s.add        s1, s17, s19
    vf.mul       v7, v0, v3
    s.add        s17, s5, s1
    s.movz       s1, #4
    v.extract    s25, v1, #4
    vf.cvt.f32.bf16 v0, v7
    v.splat      v7, s25
    s.muli       s25, s14, #4
    s.addi       s26, s18, #4
    @p4 v.st.h       [s22, #0], v0
    a.vread      v0, a7, s15
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v0, v5
    s.add        s15, s25, s20
    v.splat      v0, s26
    s.add        s22, s15, s19
    s.movz       s15, #5
    vf.mul       v5, v4, v3
    s.add        s25, s5, s22
    v.extract    s22, v1, #5
    v.splat      v4, s22
    vf.cvt.f32.bf16 v8, v5
    s.muli       s22, s14, #5
    s.addi       s26, s18, #5
    v.splat      v5, s26
    @p3 v.st.h       [s21, #0], v8
    a.vread      v8, a7, s16
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v8, v2
    s.add        s16, s22, s20
    s.movz       s21, #6
    s.add        s22, s16, s19
    v.extract    s16, v1, #6
    vf.mul       v2, v0, v3
    s.add        s26, s5, s22
    v.splat      v0, s16
    vf.cvt.f32.bf16 v8, v2
    s.muli       s16, s14, #6
    s.addi       s22, s18, #6
    v.splat      v2, s22
    @p4 v.st.h       [s17, #0], v8
    a.vread      v8, a7, s1
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v8, v7
    s.add        s1, s16, s20
    s.movz       s16, #7
    s.add        s17, s1, s19
    v.extract    s1, v1, #7
    vf.mul       v7, v5, v3
    s.add        s22, s5, s17
    v.splat      v5, s1
    vf.cvt.f32.bf16 v8, v7
    s.muli       s1, s14, #7
    s.addi       s17, s18, #7
    v.splat      v7, s17
    @p3 v.st.h       [s25, #0], v8
    a.vread      v8, a7, s15
    v.cmp.lt     p1, v2, v6
    p.and        p3, p1, p2
    vf.mul       v2, v8, v4
    s.add        s15, s1, s20
    s.movz       s1, #8
    s.add        s17, s15, s19
    v.extract    s15, v1, #8
    vf.mul       v4, v2, v3
    s.add        s25, s5, s17
    v.splat      v2, s15
    vf.cvt.f32.bf16 v8, v4
    s.muli       s15, s14, #8
    s.addi       s17, s18, #8
    v.splat      v4, s17
    @p4 v.st.h       [s26, #0], v8
    a.vread      v8, a7, s21
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v8, v0
    s.add        s17, s15, s20
    s.movz       s15, #9
    s.add        s21, s17, s19
    v.extract    s17, v1, #9
    vf.mul       v0, v7, v3
    s.add        s26, s5, s21
    v.splat      v7, s17
    vf.cvt.f32.bf16 v8, v0
    s.muli       s17, s14, #9
    s.addi       s21, s18, #9
    v.splat      v0, s21
    @p3 v.st.h       [s22, #0], v8
    a.vread      v8, a7, s16
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v8, v5
    s.add        s16, s17, s20
    s.movz       s17, #10
    s.add        s21, s16, s19
    v.extract    s16, v1, #10
    vf.mul       v5, v4, v3
    s.add        s22, s5, s21
    v.splat      v4, s16
    vf.cvt.f32.bf16 v8, v5
    s.muli       s16, s14, #10
    s.addi       s21, s18, #10
    v.splat      v5, s21
    @p4 v.st.h       [s25, #0], v8
    a.vread      v8, a7, s1
    v.cmp.lt     p1, v0, v6
    p.and        p4, p1, p2
    vf.mul       v0, v8, v2
    s.add        s1, s16, s20
    s.movz       s16, #11
    s.add        s21, s1, s19
    v.extract    s1, v1, #11
    vf.mul       v2, v0, v3
    s.add        s25, s5, s21
    v.splat      v0, s1
    vf.cvt.f32.bf16 v8, v2
    s.muli       s1, s14, #11
    s.addi       s21, s18, #11
    v.splat      v2, s21
    @p3 v.st.h       [s26, #0], v8
    a.vread      v8, a7, s15
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v8, v7
    s.add        s15, s1, s20
    s.movz       s1, #12
    s.add        s21, s15, s19
    v.extract    s15, v1, #12
    vf.mul       v7, v5, v3
    s.add        s26, s5, s21
    v.splat      v5, s15
    vf.cvt.f32.bf16 v8, v7
    s.muli       s15, s14, #12
    s.addi       s21, s18, #12
    v.splat      v7, s21
    @p4 v.st.h       [s22, #0], v8
    a.vread      v8, a7, s17
    v.cmp.lt     p1, v2, v6
    p.and        p4, p1, p2
    vf.mul       v2, v8, v4
    s.add        s17, s15, s20
    s.movz       s15, #13
    s.add        s21, s17, s19
    v.extract    s17, v1, #13
    vf.mul       v4, v2, v3
    s.add        s22, s5, s21
    v.splat      v2, s17
    vf.cvt.f32.bf16 v8, v4
    s.muli       s17, s14, #13
    s.addi       s21, s18, #13
    v.splat      v4, s21
    @p3 v.st.h       [s25, #0], v8
    a.vread      v8, a7, s16
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v8, v0
    s.add        s16, s17, s20
    s.movz       s17, #14
    s.add        s21, s16, s19
    v.extract    s16, v1, #14
    vf.mul       v0, v7, v3
    s.add        s25, s5, s21
    v.splat      v7, s16
    vf.cvt.f32.bf16 v8, v0
    s.muli       s16, s14, #14
    s.addi       s21, s18, #14
    v.splat      v0, s21
    @p4 v.st.h       [s26, #0], v8
    a.vread      v8, a7, s1
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v8, v5
    s.add        s1, s16, s20
    s.movz       s16, #15
    s.add        s21, s1, s19
    v.extract    s1, v1, #15
    vf.mul       v1, v4, v3
    s.add        s26, s5, s21
    v.splat      v4, s1
    vf.cvt.f32.bf16 v5, v1
    s.muli       s1, s14, #15
    s.addi       s14, s18, #15
    v.splat      v1, s14
    @p3 v.st.h       [s22, #0], v5
    a.vread      v5, a7, s15
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v5, v2
    s.add        s14, s1, s20
    s.addi       s1, s4, #16
    s.add        s15, s14, s19
    s.movz       s14, #128
    vf.mul       v2, v0, v3
    s.add        s18, s5, s15
    vf.cvt.f32.bf16 v0, v2
    @p4 v.st.h       [s25, #0], v0
    a.vread      v0, a7, s17
    v.cmp.lt     p1, v1, v6
    p.and        p4, p1, p2
    vf.mul       v1, v0, v7
    vf.mul       v0, v1, v3
    vf.cvt.f32.bf16 v1, v0
    @p3 v.st.h       [s26, #0], v1
    a.vread      v0, a7, s16
    vf.mul       v1, v0, v4
    vf.mul       v0, v1, v3
    vf.cvt.f32.bf16 v1, v0
    @p4 v.st.h       [s18, #0], v1
    s.mov        s4, s1
    s.cmp.lt     s1, s4, s14
    br.nz        s1, rows_1
endrows_2:
    exit
    exit
