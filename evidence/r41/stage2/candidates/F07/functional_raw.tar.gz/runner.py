from pathlib import Path
import json,itertools,subprocess
r=Path.cwd();out=r/'results';out.mkdir(exist_ok=False);rows=[]
def step(name,args,expect=0):
 p=subprocess.run(args,text=True,capture_output=True,timeout=900);t=p.stdout+p.stderr;(out/(name+'.log')).write_text(t);assert p.returncode==expect,(name,p.returncode,t[-2500:]);return t
base=['iverilog','-g2012','-Irtl/common','-s','tb_nuca_slice','-Ptb_nuca_slice.SETS=32','-Ptb_nuca_slice.SET_W=5','-Ptb_nuca_slice.WAYS=8','-Ptb_nuca_slice.WAY_W=3','-Ptb_nuca_slice.REGISTER_VICTIM_OWNER=1','-Ptb_nuca_slice.DCO_REGISTERED_RANGES=1','-Ptb_nuca_slice.AMO_TRAFFIC=1','-Ptb_nuca_slice.DRAM_LAT=400']
def build(name,epoch,policy,source):
 b=str(out/(name+'.vvp'));step(name+'_build',base+[f'-Ptb_nuca_slice.EPOCH_CHURN={epoch}',f'-Ptb_nuca_slice.POLICY={policy}','-o',b,source,'rtl/nuca/tnca_nuca_slice_before.v','tb/common/tnca_dram_model.v','tb/nuca/service_snapshot.v']);return b
for epoch,policy in itertools.product([0,3],[46,78]):
 name=f'epoch{epoch}_policy{policy}';b=build(name,epoch,policy,'rtl/nuca/tnca_nuca_slice.v');t=step(name,['vvp',b,'+nreq=12000','+seed=7','+min_wb=1','+min_block=1']);assert 'PASS' in t.splitlines() and 'FAIL' not in t and 'FATAL' not in t,t;rows.append({'name':name,'status':'cycle-and-oracle-pass','log':name+'.log'});(out/'summary.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,flush=True)
s=(r/'rtl/nuca/tnca_nuca_slice.v').read_text();needle='service_set_q <= ms_set[ms_pick_id];';assert s.count(needle)==1;mutant=out/'wrong_service_set.v';mutant.write_text(s.replace(needle,"service_set_q <= ms_set[ms_pick_id] ^ 1'b1;"));b=build('mutation',0,78,str(mutant));t=step('mutation',['vvp',b,'+nreq=12000','+seed=7'],1);assert 'MSHR service descriptor changed after arbitration' in t,t;rows.append({'name':'wrong_service_set','status':'mutation-detected'});(out/'summary.json').write_text(json.dumps(rows,indent=2)+'\n');print('SERVICE_SNAPSHOT_FUNCTIONAL_DONE',flush=True)
