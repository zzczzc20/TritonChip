    // R39-12: role0 on even contexts, role1 on odd ones (ROLE_ID mod 2)
    s.rdspecial  s61, role_id
    s.andi       s61, s61, #1
    br.nz        s61, __tnca_role1
    w.def        w0, #60, #4                     // v60..v63
    w.def        w1, #56, #4                     // v56..v59
    w.def        w2, #52, #4                     // v52..v55
    w.def        w3, #48, #4                     // v48..v51
    .li       s1, #196608
    td.load      d0, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    .li       s1, #196864
    td.load      d1, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    // role 0: partition P, k loop rolled -- 3 trip(s) of 2 step(s). Every W and V number in the body is static.
    .li       s1, #0
    .li       s2, #0
p_loop:
    s.shli       s3, s1, #16                     // epoch into the token (ISA sec 9A.2)
    s.ori        s3, s3, #2                      // barrier b2
    mb.wait      s3
    mb.arm       s4, b0, #0, #2                  // 0 arrival(s), 2 operation(s)
    .li       s5, #0
    s.mov        s6, s5                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s7, s2                          // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w0, d0, s6, s4
    .li       s5, #0
    s.mov        s6, s2                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s7, s5                          // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w2, d1, s6, s4
    s.shli       s5, s1, #16                     // epoch into the token (ISA sec 9A.2)
    s.ori        s5, s5, #3                      // barrier b3
    mb.wait      s5
    mb.arm       s6, b1, #0, #2                  // 0 arrival(s), 2 operation(s)
    s.addi       s7, s2, #16
    .li       s8, #0
    s.mov        s9, s8                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s10, s7                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w1, d0, s9, s6
    .li       s8, #0
    s.mov        s9, s7                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s10, s8                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w3, d1, s9, s6
    s.addi       s7, s2, #32
    s.mov        s2, s7
    s.addi       s7, s1, #1
    s.mov        s1, s7
    .li       s7, #3
    s.cmp.lt     s8, s1, s7
    br.nz        s8, p_loop
    exit
__tnca_role1:
    // role 1: partitions M+E, the same loop cloned. The generation is derived from this role's own trip counter (sec 7.3).
    m.zero       a0
    .li       s1, #0
c_loop:
    s.addi       s2, s1, #1
    s.shli       s3, s2, #16                     // epoch into the token (ISA sec 9A.2)
    s.ori        s3, s3, #0                      // barrier b0
    mb.wait      s3
    mb.arm       s4, b4, #0, #1                  // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k16.e4m3 a0, v60, v52, s4
    mb.wait      s4
    mb.arm       s5, b2, #1, #0                  // 1 arrival(s), 0 operation(s)
    mb.arrive    b2
    s.shli       s6, s2, #16                     // epoch into the token (ISA sec 9A.2)
    s.ori        s6, s6, #1                      // barrier b1
    mb.wait      s6
    mb.arm       s2, b4, #0, #1                  // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k16.e4m3 a0, v56, v48, s2
    mb.wait      s2
    mb.arm       s7, b3, #1, #0                  // 1 arrival(s), 0 operation(s)
    mb.arrive    b3
    s.addi       s8, s1, #1
    s.mov        s1, s8
    .li       s8, #3
    s.cmp.lt     s9, s1, s8
    br.nz        s9, c_loop
    // epilogue
    .li       s1, #393216
    .li       s8, #0
    a.vread      v0, a0, s8
    v.st.w       [s1, #0], v0
    .li       s8, #1
    a.vread      v0, a0, s8
    s.addi       s8, s1, #64
    v.st.w       [s8, #0], v0
    .li       s8, #2
    a.vread      v0, a0, s8
    s.addi       s8, s1, #128
    v.st.w       [s8, #0], v0
    .li       s8, #3
    a.vread      v0, a0, s8
    s.addi       s8, s1, #192
    v.st.w       [s8, #0], v0
    .li       s8, #4
    a.vread      v0, a0, s8
    s.addi       s8, s1, #256
    v.st.w       [s8, #0], v0
    .li       s8, #5
    a.vread      v0, a0, s8
    s.addi       s8, s1, #320
    v.st.w       [s8, #0], v0
    .li       s8, #6
    a.vread      v0, a0, s8
    s.addi       s8, s1, #384
    v.st.w       [s8, #0], v0
    .li       s8, #7
    a.vread      v0, a0, s8
    s.addi       s8, s1, #448
    v.st.w       [s8, #0], v0
    .li       s8, #8
    a.vread      v0, a0, s8
    s.addi       s8, s1, #512
    v.st.w       [s8, #0], v0
    .li       s8, #9
    a.vread      v0, a0, s8
    s.addi       s8, s1, #576
    v.st.w       [s8, #0], v0
    .li       s8, #10
    a.vread      v0, a0, s8
    s.addi       s8, s1, #640
    v.st.w       [s8, #0], v0
    .li       s8, #11
    a.vread      v0, a0, s8
    s.addi       s8, s1, #704
    v.st.w       [s8, #0], v0
    .li       s8, #12
    a.vread      v0, a0, s8
    s.addi       s8, s1, #768
    v.st.w       [s8, #0], v0
    .li       s8, #13
    a.vread      v0, a0, s8
    s.addi       s8, s1, #832
    v.st.w       [s8, #0], v0
    .li       s8, #14
    a.vread      v0, a0, s8
    s.addi       s8, s1, #896
    v.st.w       [s8, #0], v0
    .li       s8, #15
    a.vread      v0, a0, s8
    s.addi       s8, s1, #960
    v.st.w       [s8, #0], v0
    exit
