    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.shli       s2, s4, #4                      // x16 as a shift
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.shli       s4, s2, #1                      // element offset -> bytes (x2)
    .li       s5, #1065353216
    v.splat      v0, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v2, s2
    v.add        v3, v2, v1
    s.add        s2, s3, s4                      // &in_ptr1[...]
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.ld.h       v1, [s2, #0]
    s.add        s2, s3, s4                      // &in_ptr0[...]
    vf.cvt.bf16.f32 v2, v1
    v.ld.h       v1, [s2, #0]
    v.rcp.approx v3, v2                          // ISA 8.8: <= 2**-22 relative
    vf.cvt.bf16.f32 v4, v1
    s.ld.d       s2, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.add        s1, s2, s4                      // &out_ptr0[...]
    vf.fms       v1, v2, v3, v0
    vf.fms       v0, v3, v1, v3
    vf.neg       v1, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v0, v1, v3
    vf.mul       v1, v4, v0                      // a/y as a refined reciprocal (ISA has no divide)
    vf.cvt.f32.bf16 v0, v1
    v.st.h       [s1, #0], v0
__rctx_next:
    exit
