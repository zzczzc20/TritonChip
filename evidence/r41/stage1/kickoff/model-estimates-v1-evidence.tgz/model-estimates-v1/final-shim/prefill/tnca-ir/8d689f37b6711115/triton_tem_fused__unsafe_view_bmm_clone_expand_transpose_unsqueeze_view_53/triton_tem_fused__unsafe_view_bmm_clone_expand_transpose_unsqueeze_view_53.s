    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s3, s4, s1
    .li       s1, #3340530120
    s.sub        s5, s2, s3
    s.movz       s2, #9
    s.xor        s3, s4, s5
    s.movz       s6, #0
    s.sub        s7, s3, s5
    s.movz       s3, #0
    s.mul        s8, s7, s1
    s.cmp.lt     s1, s2, s6
    s.movz       s6, #8
    s.sub        s9, s3, s1
    s.movz       s1, #1
    s.lshri      s3, s8, #32
    s.xor        s8, s5, s9
    s.sub        s5, s7, s3
    s.movz       s10, #0
    s.lshri      s11, s5, #1
    s.movz       s5, #0
    s.add        s12, s3, s11
    s.movz       s3, #0
    s.lshri      s11, s12, #3
    s.movz       s12, #0
    s.xor        s13, s11, s8
    s.cmp.lt     s14, s4, s5
    s.sub        s5, s13, s8
    s.sub        s8, s12, s14
    s.sub        s12, s6, s5
    s.muli       s13, s11, #9
    s.min.s      s11, s12, s1
    s.movz       s1, #0
    s.cmp.lt     s12, s11, s10
    s.movz       s10, #1
    s.sub        s14, s3, s12
    s.xor        s3, s4, s8
    s.xor        s12, s11, s14
    s.rdspecial  s15, arg_base
    s.sub        s16, s12, s14
    s.xor        s12, s2, s9
    s.movz       s14, #0
    s.sub        s17, s3, s8
    s.addi       s3, s1, #0
    s.ld.d       s1, [s15, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.sub        s18, s12, s9
    s.sub        s9, s7, s13
    s.addi       s7, s14, #0
    s.ld.d       s9, [s15, #8]                   // arg_B: device_ptr64 at arg_base+8
    s.cmp.eq     s12, s16, s10
    s.ld.d       s10, [s15, #16]                 // out_ptr0: device_ptr64 at arg_base+16
    s.mov        s3, s17
    br.nz        s12, sdiv_done_1
    s.movz       s12, #0
    s.movz       s13, #31
    s.mov        s3, s12
    s.addi       s12, s13, #0
sdiv_2:
    s.lshr       s13, s17, s12
    s.shli       s14, s7, #1
    s.andi       s15, s13, #1
    s.movz       s13, #0
    s.or         s18, s14, s15
    s.movz       s14, #1
    s.cmp.geu    s15, s18, s16
    s.shl        s19, s14, s12
    s.sub        s14, s13, s15
    s.subi       s13, s12, #1
    s.and        s15, s16, s14
    s.and        s20, s19, s14
    s.sub        s14, s18, s15
    s.or         s15, s3, s20
    s.mov        s7, s14
    s.mov        s3, s15
    s.mov        s12, s13
    s.movz       s13, #0
    s.cmp.ge     s14, s12, s13
    br.nz        s14, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s12, #0
    s.cmp.lt     s13, s4, s3
    .li       s3, #3340530120
    s.sub        s14, s12, s13
    s.movz       s12, #0
    s.xor        s13, s4, s14
    s.movz       s4, #0
    s.sub        s15, s13, s14
    s.movz       s13, #0
    s.mul        s16, s15, s3
    s.cmp.lt     s3, s11, s12
    s.movz       s12, #0
    s.sub        s17, s13, s3
    s.movz       s3, #0
    s.lshri      s13, s16, #32
    s.cmp.lt     s16, s2, s12
    s.xor        s12, s11, s17
    s.xor        s11, s7, s8
    s.sub        s7, s12, s17
    s.sub        s12, s11, s8
    s.sub        s8, s15, s13
    s.add        s11, s5, s12
    s.lshri      s5, s8, #1
    s.movz       s8, #0
    s.add        s12, s13, s5
    s.sub        s5, s8, s16
    s.lshri      s8, s12, #3
    s.movz       s12, #0
    s.muli       s13, s8, #9
    s.movz       s8, #1
    s.xor        s16, s2, s5
    s.addi       s2, s12, #0
    s.cmp.eq     s12, s7, s8
    s.sub        s8, s15, s13
    s.movz       s13, #0
    s.xor        s15, s8, s14
    s.sub        s8, s16, s5
    s.sub        s5, s15, s14
    s.addi       s8, s13, #0
    s.cmp.lt     s13, s5, s4
    s.sub        s4, s3, s13
    s.xor        s3, s5, s4
    s.sub        s5, s3, s4
    s.mov        s2, s5
    br.nz        s12, sdiv_done_3
    s.movz       s3, #0
    s.movz       s12, #31
    s.mov        s2, s3
    s.addi       s3, s12, #0
sdiv_4:
    s.lshr       s12, s5, s3
    s.shli       s13, s8, #1
    s.andi       s14, s12, #1
    s.movz       s12, #0
    s.or         s15, s13, s14
    s.movz       s13, #1
    s.cmp.geu    s14, s15, s7
    s.shl        s16, s13, s3
    s.sub        s13, s12, s14
    s.subi       s12, s3, #1
    s.and        s14, s7, s13
    s.and        s18, s16, s13
    s.sub        s13, s15, s14
    s.or         s14, s2, s18
    s.mov        s8, s13
    s.mov        s2, s14
    s.mov        s3, s12
    s.movz       s12, #0
    s.cmp.ge     s13, s3, s12
    br.nz        s13, sdiv_4
sdiv_done_3:
    s.xor        s3, s4, s17
    s.movz       s4, #16
    s.xor        s5, s2, s3
    .li       s2, #3340530120
    s.sub        s7, s5, s3
    s.rdspecial  s3, pid.z
    s.mul        s5, s7, s4
    s.rdspecial  s8, npid.y
    s.mul        s12, s11, s4
    s.mul        s13, s3, s8
    s.rdspecial  s3, pid.y
    s.mul        s8, s5, s2
    s.movz       s2, #7
    s.andi       s14, s12, #127
    s.add        s15, s3, s13
    s.rdspecial  s3, arg_base
    s.lshri      s13, s8, #32
    s.min.s      s8, s15, s2
    s.sub        s2, s5, s13
    s.movz       s16, #32768
    s.lshri      s17, s2, #1
    s.movz       s2, #36864
    s.add        s18, s13, s17
    s.ld.d       s13, [s3, #24]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.lshri      s3, s18, #7
    s.mul        s17, s8, s16
    s.muli       s16, s3, #144
    s.mul        s3, s8, s2
    s.rdspecial  s2, role_id
    s.movz       s8, #9728
    s.movz       s18, #0
    s.sub        s19, s5, s16
    v.splat      v0, s11
    s.mul        s11, s2, s8
    v.splat      v1, s18
    v.splat      v2, s7
    v.splat      v3, s18
    v.iota       v4                              // arange(0, VLEN)
    s.add        s2, s13, s11                    // this context's own scratch
    v.splat      v5, s12
    s.addi       s7, s2, #0
    v.splat      v6, s5
    v.cmp.ge     p1, v0, v1
    s.muli       s8, s14, #256                   // a runtime tile origin, x256
    s.movz       s11, #0
    v.splat      v0, s14
    v.iota       v1                              // arange(0, VLEN)
    v.cmp.ge     p1, v2, v3
    s.add        s13, s11, s8                    // the tile origin
    v.iota       v2                              // arange(0, VLEN)
    s.add        s8, s13, s17                    // the tile origin
    v.splat      v3, s19
    v.add        v7, v5, v4
    s.addi       s11, s8, #256
    v.splat      v5, s8
    s.addi       s13, s7, #64
    v.add        v7, v6, v4
    s.addi       s14, s8, #512
    v.splat      v4, s11
    v.iota       v6                              // arange(0, VLEN)
    v.add        v7, v2, v5
    v.add        v5, v2, v4
    s.addi       s11, s7, #128
    v.add        v4, v0, v1
    s.addi       s16, s8, #768
    s.addi       s17, s8, #1024
    v.splat      v0, s14
    v.splat      v1, s16
    s.addi       s14, s7, #192
    v.add        v4, v2, v0
    v.add        v0, v2, v1
    s.addi       s16, s7, #256
    v.add        v1, v3, v6
    s.addi       s20, s8, #1280
    s.addi       s21, s8, #1536
    v.splat      v1, s17
    v.splat      v3, s20
    s.addi       s17, s7, #320
    v.add        v6, v2, v1
    v.add        v1, v2, v3
    s.addi       s20, s7, #384
    s.addi       s22, s18, #0
    v.st.w       [s7, #0], v7
    v.splat      v3, s21
    s.addi       s18, s7, #448
    v.add        v7, v2, v3
    v.st.w       [s13, #0], v5
    s.movz       s13, #256
    v.st.w       [s11, #0], v4
    s.addi       s11, s8, #1792
    v.splat      v3, s11
    s.addi       s11, s8, #2048
    v.splat      v4, s11
    s.addi       s11, s8, #2304
    v.add        v5, v2, v3
    v.add        v3, v2, v4
    v.st.w       [s14, #0], v0
    s.addi       s14, s8, #2560
    v.splat      v0, s11
    s.addi       s11, s8, #2816
    v.add        v4, v2, v0
    v.st.w       [s16, #0], v6
    s.addi       s16, s8, #3072
    v.splat      v0, s14
    s.addi       s14, s8, #3328
    v.add        v6, v2, v0
    v.st.w       [s17, #0], v1
    s.addi       s17, s8, #3584
    s.addi       s21, s8, #3840
    v.splat      v0, s11
    s.addi       s8, s2, #1024
    v.add        v1, v2, v0
    v.st.w       [s20, #0], v7
    s.muli       s11, s19, #256                  // a runtime tile origin, x256
    s.movz       s19, #0
    v.iota       v0                              // arange(0, VLEN)
    s.add        s20, s19, s11                   // the tile origin
    s.addi       s11, s7, #512
    s.add        s19, s20, s3                    // the tile origin
    s.addi       s3, s7, #576
    v.st.w       [s18, #0], v5
    s.movz       s18, #256
    v.splat      v5, s16
    s.addi       s16, s7, #640
    v.add        v7, v2, v5
    v.st.w       [s11, #0], v3
    v.splat      v3, s18
    s.addi       s11, s19, #1
    s.addi       s18, s7, #704
    v.mul        v5, v0, v3
    v.splat      v0, s14
    s.addi       s14, s7, #768
    v.add        v3, v2, v0
    v.st.w       [s3, #0], v4
    s.addi       s3, s19, #2
    v.splat      v0, s17
    s.addi       s17, s7, #832
    v.add        v4, v2, v0
    v.st.w       [s16, #0], v6
    s.addi       s16, s19, #3
    v.splat      v0, s21
    s.addi       s20, s7, #896
    s.addi       s21, s7, #960
    v.add        v6, v2, v0
    v.st.w       [s18, #0], v1
    s.addi       s7, s19, #4
    v.splat      v0, s19
    v.add        v1, v5, v0
    v.st.w       [s14, #0], v7
    s.addi       s14, s19, #5
    v.splat      v0, s11
    s.addi       s11, s8, #64
    v.add        v7, v5, v0
    v.st.w       [s17, #0], v3
    s.addi       s17, s19, #6
    v.splat      v0, s3
    s.addi       s3, s8, #128
    v.add        v3, v5, v0
    v.st.w       [s20, #0], v4
    s.addi       s18, s19, #7
    v.splat      v0, s16
    s.addi       s16, s8, #192
    v.add        v4, v5, v0
    v.st.w       [s21, #0], v6
    v.splat      v0, s7
    s.addi       s7, s8, #256
    s.addi       s20, s8, #320
    v.add        v6, v5, v0
    fence.acq_rel.device
    v.st.w       [s8, #0], v1
    v.splat      v0, s14
    s.addi       s14, s19, #8
    v.add        v1, v5, v0
    v.st.w       [s11, #0], v7
    s.addi       s11, s19, #9
    v.splat      v0, s17
    s.addi       s17, s19, #10
    v.add        v7, v5, v0
    v.st.w       [s3, #0], v3
    s.addi       s3, s19, #11
    v.splat      v0, s18
    s.addi       s18, s19, #12
    v.add        v3, v5, v0
    v.st.w       [s16, #0], v4
    s.addi       s16, s19, #13
    v.splat      v0, s14
    s.addi       s14, s19, #14
    v.add        v4, v5, v0
    v.st.w       [s7, #0], v6
    s.addi       s7, s19, #15
    v.splat      v0, s11
    s.addi       s11, s8, #384
    s.addi       s19, s8, #448
    v.add        v6, v5, v0
    v.st.w       [s20, #0], v1
    v.splat      v0, s17
    s.addi       s17, s8, #512
    s.addi       s20, s8, #576
    v.add        v1, v5, v0
    v.st.w       [s11, #0], v7
    v.splat      v0, s3
    s.addi       s3, s8, #640
    s.addi       s11, s8, #704
    v.add        v7, v5, v0
    v.st.w       [s19, #0], v3
    v.splat      v0, s18
    s.addi       s18, s8, #768
    s.addi       s19, s8, #832
    v.add        v3, v5, v0
    v.st.w       [s17, #0], v4
    v.splat      v0, s16
    s.addi       s16, s8, #896
    s.addi       s17, s8, #960
    v.add        v4, v5, v0
    v.st.w       [s20, #0], v6
    v.splat      v0, s14
    v.add        v6, v5, v0
    v.st.w       [s3, #0], v1
    v.splat      v0, s7
    v.add        v1, v5, v0
    v.st.w       [s11, #0], v7
    v.st.w       [s18, #0], v3
    v.st.w       [s19, #0], v4
    v.st.w       [s16, #0], v6
    v.st.w       [s17, #0], v1
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s3, s22, s13
    br.nz        s3, endfor_6
    s.addi       s3, s2, #0
    s.addi       s7, s2, #2048
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s2, #64
    s.addi       s8, s7, #64
    s.addi       s11, s2, #128
    s.addi       s14, s7, #128
    s.addi       s16, s2, #192
    s.addi       s17, s7, #192
    v.ld.gather.h v1, [s1, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s2, #256
    v.ld.gather.h v1, [s1, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s8, #0], v1
    s.addi       s8, s7, #256
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s2, #320
    v.ld.gather.h v1, [s1, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s7, #320
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s2, #384
    v.ld.gather.h v1, [s1, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s17, #0], v1
    s.addi       s17, s7, #384
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s2, #448
    v.ld.gather.h v1, [s1, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s8, #0], v1
    s.addi       s8, s7, #448
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s2, #512
    v.ld.gather.h v1, [s1, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s7, #512
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s2, #576
    v.ld.gather.h v1, [s1, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s17, #0], v1
    s.addi       s17, s7, #576
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s2, #640
    v.ld.gather.h v1, [s1, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s8, #0], v1
    s.addi       s8, s7, #640
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s2, #704
    v.ld.gather.h v1, [s1, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s7, #704
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s2, #768
    v.ld.gather.h v1, [s1, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s17, #0], v1
    s.addi       s17, s7, #768
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s2, #832
    v.ld.gather.h v1, [s1, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s8, #0], v1
    s.addi       s8, s7, #832
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s2, #896
    v.ld.gather.h v1, [s1, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s7, #896
    s.addi       s18, s7, #960
    v.ld.w       v0, [s16, #0]
    s.addi       s7, s2, #960
    v.ld.gather.h v1, [s1, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s17, #0], v1
    s.addi       s16, s2, #1024
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s2, #3072
    v.ld.gather.h v1, [s1, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s8, #0], v1
    s.addi       s8, s2, #1088
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s3, #64
    v.ld.gather.h v1, [s1, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s2, #1152
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s3, #128
    v.ld.gather.h v1, [s1, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s17, s2, #1216
    v.st.w       [s18, #0], v1
    fence.acq_rel.device
    s.addi       s18, s3, #192
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s2, #1280
    v.ld.gather.h v1, [s9, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s3, #256
    v.ld.gather.h v1, [s9, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s11, #0], v1
    s.addi       s11, s2, #1344
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s3, #320
    v.ld.gather.h v1, [s9, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s2, #1408
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s3, #384
    v.ld.gather.h v1, [s9, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s18, #0], v1
    s.addi       s18, s2, #1472
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s3, #448
    v.ld.gather.h v1, [s9, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s8, #0], v1
    s.addi       s8, s2, #1536
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s3, #512
    v.ld.gather.h v1, [s9, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s2, #1600
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s3, #576
    v.ld.gather.h v1, [s9, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s17, #0], v1
    s.addi       s17, s2, #1664
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s3, #640
    v.ld.gather.h v1, [s9, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v1
    s.addi       s16, s2, #1728
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s3, #704
    v.ld.gather.h v1, [s9, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s11, #0], v1
    s.addi       s11, s2, #1792
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s3, #768
    v.ld.gather.h v1, [s9, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s2, #1856
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s3, #832
    v.ld.gather.h v1, [s9, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s18, #0], v1
    s.addi       s18, s2, #1920
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s3, #896
    s.addi       s19, s3, #960
    v.ld.gather.h v1, [s9, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s8, #0], v1
    s.addi       s3, s2, #1984
    v.ld.w       v0, [s11, #0]
    // repack 16x16 bf16 through memory: there is no v.pack (ISA sec 8.4)
    s.addi       s8, s2, #2048
    v.ld.gather.h v1, [s9, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s11, s2, #4096                  // 512 bytes of repack scratch
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s2, #2112
    v.ld.gather.h v1, [s9, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s17, #0], v1
    s.addi       s14, s11, #32                   // row 1
    v.ld.w       v0, [s18, #0]
    s.addi       s17, s2, #2176
    v.ld.gather.h v1, [s9, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v1
    s.addi       s16, s11, #64                   // row 2
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s2, #2240
    v.ld.gather.h v1, [s9, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s18, s11, #96                   // row 3
    v.st.w       [s19, #0], v1
    fence.acq_rel.device
    s.addi       s19, s2, #2304
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s11, #128                   // row 4
    v.st.h       [s11, #0], v0
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s2, #2368
    v.st.h       [s14, #0], v0
    s.addi       s14, s11, #160                  // row 5
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s2, #2432
    v.st.h       [s16, #0], v0
    s.addi       s16, s11, #192                  // row 6
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s2, #2496
    v.st.h       [s18, #0], v0
    s.addi       s18, s11, #224                  // row 7
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s2, #2560
    s.movz       s20, #0
    v.st.h       [s8, #0], v0
    s.addi       s8, s11, #256                   // row 8
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s2, #2624
    v.st.h       [s14, #0], v0
    s.addi       s14, s11, #288                  // row 9
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s2, #2688
    v.st.h       [s16, #0], v0
    s.addi       s16, s11, #320                  // row 10
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s2, #2752
    v.st.h       [s18, #0], v0
    s.addi       s18, s11, #352                  // row 11
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s2, #2816
    v.st.h       [s8, #0], v0
    s.addi       s8, s11, #384                   // row 12
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s2, #2880
    v.st.h       [s14, #0], v0
    s.addi       s14, s11, #416                  // row 13
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s2, #2944
    v.st.h       [s16, #0], v0
    s.addi       s16, s11, #448                  // row 14
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s2, #3008
    v.st.h       [s18, #0], v0
    s.addi       s18, s11, #480                  // row 15
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s2, #4608                  // TensorMap 0: a repacked tile
    v.st.h       [s8, #0], v0
    s.movz       s8, #16
    v.ld.w       v0, [s7, #0]
    s.movz       s7, #16
    v.st.h       [s14, #0], v0
    s.movz       s14, #32
    v.ld.w       v0, [s17, #0]
    s.movz       s17, #2
    v.st.h       [s16, #0], v0
    .li       s16, #68719476752
    v.ld.w       v0, [s3, #0]
    .li       s3, #1108101562368
    v.st.h       [s18, #0], v0
    s.movz       s18, #0
    s.st.d       [s19, #0], s11
    // repack 16x16 bf16 through memory: there is no v.pack (ISA sec 8.4)
    s.addi       s11, s2, #3072
    s.st.d       [s19, #8], s8
    s.addi       s8, s2, #4864                   // 512 bytes of repack scratch
    s.st.d       [s19, #16], s7
    s.addi       s7, s2, #3136
    s.st.d       [s19, #48], s14
    s.addi       s14, s8, #32                    // row 1
    s.st.d       [s19, #56], s17
    s.addi       s17, s2, #3200
    s.st.d       [s19, #88], s16
    s.addi       s16, s8, #64                    // row 2
    s.st.d       [s19, #104], s3
    fence.release.device
    td.load      d0, [s19]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s3, b0, #0, #1                  // 0 arrival(s), 1 operation(s)
    s.addi       s19, s2, #3264
    s.addi       s20, s8, #96                    // row 3
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s23, s18                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s24, s18                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s23, s3
    mb.wait      s3
    s.addi       s18, s2, #3328
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s8, #128                   // row 4
    v.st.h       [s8, #0], v0
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s2, #3392
    v.st.h       [s14, #0], v0
    s.addi       s14, s8, #160                   // row 5
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s2, #3456
    v.st.h       [s16, #0], v0
    s.addi       s16, s8, #192                   // row 6
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s2, #3520
    v.st.h       [s20, #0], v0
    s.addi       s20, s8, #224                   // row 7
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s2, #3584
    s.movz       s21, #0
    v.st.h       [s11, #0], v0
    s.addi       s11, s8, #256                   // row 8
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s2, #3648
    v.st.h       [s14, #0], v0
    s.addi       s14, s8, #288                   // row 9
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s2, #3712
    v.st.h       [s16, #0], v0
    s.addi       s16, s8, #320                   // row 10
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s2, #3776
    v.st.h       [s20, #0], v0
    s.addi       s20, s8, #352                   // row 11
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s2, #3840
    v.st.h       [s11, #0], v0
    s.addi       s11, s8, #384                   // row 12
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s2, #3904
    v.st.h       [s14, #0], v0
    s.addi       s14, s8, #416                   // row 13
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s2, #3968
    v.st.h       [s16, #0], v0
    s.addi       s16, s8, #448                   // row 14
    v.splat      v0, s4
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s2, #4032
    v.st.h       [s20, #0], v1
    s.addi       s20, s8, #480                   // row 15
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s2, #5376                  // TensorMap 1: a repacked tile
    v.st.h       [s11, #0], v1
    s.movz       s11, #16
    v.ld.w       v1, [s7, #0]
    s.movz       s7, #16
    v.st.h       [s14, #0], v1
    s.movz       s14, #32
    v.ld.w       v1, [s17, #0]
    s.movz       s17, #2
    v.st.h       [s16, #0], v1
    .li       s16, #68719476752
    v.ld.w       v1, [s19, #0]
    .li       s19, #1108101562368
    v.st.h       [s20, #0], v1
    s.movz       s20, #0
    s.st.d       [s18, #0], s8
    s.addi       s8, s2, #0
    s.st.d       [s18, #8], s11
    s.addi       s11, s2, #5632
    s.st.d       [s18, #16], s7
    s.addi       s7, s2, #64
    s.st.d       [s18, #48], s14
    s.addi       s14, s11, #64
    s.st.d       [s18, #56], s17
    s.addi       s17, s2, #128
    s.st.d       [s18, #88], s16
    s.addi       s16, s11, #128
    s.st.d       [s18, #104], s19
    fence.release.device
    td.load      d1, [s18]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s18, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s19, s2, #192
    s.addi       s21, s11, #192
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s23, s20                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s24, s20                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s23, s18
    mb.wait      s18
    mb.arm       s20, b2, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s23, s2, #256
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.bf16 a0, v56, v48, s20
    mb.wait      s20
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s11, #256
    v.add        v3, v1, v0
    v.st.w       [s11, #0], v3
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s2, #320
    v.add        v3, v1, v0
    v.st.w       [s14, #0], v3
    s.addi       s14, s11, #320
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s2, #384
    v.add        v3, v1, v0
    v.st.w       [s16, #0], v3
    s.addi       s16, s11, #384
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s2, #448
    v.add        v3, v1, v0
    v.st.w       [s21, #0], v3
    s.addi       s21, s11, #448
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s2, #512
    v.add        v3, v1, v0
    v.st.w       [s8, #0], v3
    s.addi       s8, s11, #512
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s2, #576
    v.add        v3, v1, v0
    v.st.w       [s14, #0], v3
    s.addi       s14, s11, #576
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s2, #640
    v.add        v3, v1, v0
    v.st.w       [s16, #0], v3
    s.addi       s16, s11, #640
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s2, #704
    v.add        v3, v1, v0
    v.st.w       [s21, #0], v3
    s.addi       s21, s11, #704
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s2, #768
    v.add        v3, v1, v0
    v.st.w       [s8, #0], v3
    s.addi       s8, s11, #768
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s2, #832
    v.add        v3, v1, v0
    v.st.w       [s14, #0], v3
    s.addi       s14, s11, #832
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s2, #896
    v.add        v3, v1, v0
    v.st.w       [s16, #0], v3
    s.addi       s16, s11, #896
    s.addi       s24, s11, #960
    v.ld.w       v1, [s19, #0]
    s.addi       s11, s2, #960
    v.add        v3, v1, v0
    v.st.w       [s21, #0], v3
    s.addi       s19, s2, #1024
    v.ld.w       v1, [s23, #0]
    s.addi       s21, s2, #6656
    v.add        v3, v1, v0
    v.st.w       [s8, #0], v3
    s.addi       s8, s2, #1088
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s21, #64
    v.add        v3, v1, v0
    v.st.w       [s14, #0], v3
    s.addi       s14, s2, #1152
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s21, #128
    v.add        v3, v1, v0
    v.st.w       [s16, #0], v3
    s.addi       s16, s2, #1216
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s21, #192
    v.add        v3, v1, v0
    v.st.w       [s24, #0], v3
    fence.acq_rel.device
    s.addi       s23, s2, #1280
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s21, #256
    v.add        v3, v1, v0
    v.st.w       [s21, #0], v3
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s2, #1344
    v.add        v3, v1, v0
    v.st.w       [s7, #0], v3
    s.addi       s7, s21, #320
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s2, #1408
    v.add        v3, v1, v0
    v.st.w       [s17, #0], v3
    s.addi       s17, s21, #384
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s2, #1472
    v.add        v3, v1, v0
    v.st.w       [s11, #0], v3
    s.addi       s11, s21, #448
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s2, #1536
    v.add        v3, v1, v0
    v.st.w       [s19, #0], v3
    s.addi       s19, s21, #512
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s2, #1600
    v.add        v3, v1, v0
    v.st.w       [s7, #0], v3
    s.addi       s7, s21, #576
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s2, #1664
    v.add        v3, v1, v0
    v.st.w       [s17, #0], v3
    s.addi       s17, s21, #640
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s2, #1728
    v.add        v3, v1, v0
    v.st.w       [s11, #0], v3
    s.addi       s11, s21, #704
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s2, #1792
    v.add        v3, v1, v0
    v.st.w       [s19, #0], v3
    s.addi       s19, s21, #768
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s2, #1856
    v.add        v3, v1, v0
    v.st.w       [s7, #0], v3
    s.addi       s7, s21, #832
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s2, #1920
    v.add        v3, v1, v0
    v.st.w       [s17, #0], v3
    s.addi       s17, s21, #896
    s.addi       s24, s21, #960
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s2, #1984
    v.add        v3, v1, v0
    v.st.w       [s11, #0], v3
    s.addi       s11, s2, #5632
    v.ld.w       v1, [s23, #0]
    s.addi       s21, s2, #7680
    v.add        v3, v1, v0
    v.st.w       [s19, #0], v3
    s.addi       s19, s2, #5696
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s21, #64
    v.add        v3, v1, v0
    v.st.w       [s7, #0], v3
    s.addi       s7, s2, #5760
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s21, #128
    v.add        v3, v1, v0
    v.st.w       [s17, #0], v3
    s.addi       s17, s2, #5824
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s21, #192
    v.add        v3, v1, v0
    v.st.w       [s24, #0], v3
    fence.acq_rel.device
    s.addi       s23, s2, #5888
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s21, #256
    v.st.w       [s21, #0], v0
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s2, #5952
    v.st.w       [s8, #0], v0
    s.addi       s8, s21, #320
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s2, #6016
    v.st.w       [s14, #0], v0
    s.addi       s14, s21, #384
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s2, #6080
    v.st.w       [s16, #0], v0
    s.addi       s16, s21, #448
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s2, #6144
    v.st.w       [s11, #0], v0
    s.addi       s11, s21, #512
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s2, #6208
    v.st.w       [s8, #0], v0
    s.addi       s8, s21, #576
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s2, #6272
    v.st.w       [s14, #0], v0
    s.addi       s14, s21, #640
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s2, #6336
    v.st.w       [s16, #0], v0
    s.addi       s16, s21, #704
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s2, #6400
    v.st.w       [s11, #0], v0
    s.addi       s11, s21, #768
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s2, #6464
    v.st.w       [s8, #0], v0
    s.addi       s8, s21, #832
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s2, #6528
    v.st.w       [s14, #0], v0
    s.addi       s14, s21, #896
    s.addi       s24, s21, #960
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s2, #6592
    v.st.w       [s16, #0], v0
    s.addi       s16, s2, #6656
    v.ld.w       v0, [s23, #0]
    s.addi       s21, s2, #8704
    v.st.w       [s11, #0], v0
    s.addi       s11, s2, #6720
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s21, #64
    v.st.w       [s8, #0], v0
    s.addi       s8, s2, #6784
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s21, #128
    v.st.w       [s14, #0], v0
    s.addi       s14, s2, #6848
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s21, #192
    v.st.w       [s24, #0], v0
    fence.acq_rel.device
    s.addi       s23, s2, #6912
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s21, #256
    v.st.w       [s21, #0], v0
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s2, #6976
    v.st.w       [s19, #0], v0
    s.addi       s19, s21, #320
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s2, #7040
    v.st.w       [s7, #0], v0
    s.addi       s7, s21, #384
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s2, #7104
    v.st.w       [s17, #0], v0
    s.addi       s17, s21, #448
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s2, #7168
    v.st.w       [s16, #0], v0
    s.addi       s16, s21, #512
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s2, #7232
    v.st.w       [s19, #0], v0
    s.addi       s19, s21, #576
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s2, #7296
    v.st.w       [s7, #0], v0
    s.addi       s7, s21, #640
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s2, #7360
    v.st.w       [s17, #0], v0
    s.addi       s17, s21, #704
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s2, #7424
    v.st.w       [s16, #0], v0
    s.addi       s16, s21, #768
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s2, #7488
    v.st.w       [s19, #0], v0
    s.addi       s19, s21, #832
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s2, #7552
    v.st.w       [s7, #0], v0
    s.addi       s7, s21, #896
    s.addi       s24, s21, #960
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s2, #7616
    v.st.w       [s17, #0], v0
    s.addi       s17, s2, #7680
    v.ld.w       v0, [s23, #0]
    s.addi       s21, s2, #0
    v.st.w       [s16, #0], v0
    s.addi       s16, s2, #7744
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s2, #64
    v.st.w       [s19, #0], v0
    s.addi       s19, s2, #7808
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s2, #128
    v.st.w       [s7, #0], v0
    s.addi       s7, s2, #7872
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s2, #192
    v.st.w       [s24, #0], v0
    fence.acq_rel.device
    s.addi       s23, s2, #7936
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s2, #256
    v.st.w       [s21, #0], v0
    s.addi       s21, s2, #8000
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s2, #320
    v.st.w       [s11, #0], v0
    s.addi       s11, s2, #8064
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s2, #384
    v.st.w       [s8, #0], v0
    s.addi       s8, s2, #8128
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s2, #448
    v.st.w       [s14, #0], v0
    s.addi       s14, s2, #8192
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s2, #512
    v.st.w       [s17, #0], v0
    s.addi       s17, s2, #8256
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s2, #576
    v.st.w       [s16, #0], v0
    s.addi       s16, s2, #8320
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s2, #640
    v.st.w       [s19, #0], v0
    s.addi       s19, s2, #8384
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s2, #704
    v.st.w       [s7, #0], v0
    s.addi       s7, s2, #8448
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s2, #768
    v.st.w       [s23, #0], v0
    s.addi       s23, s2, #8512
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s2, #832
    v.st.w       [s21, #0], v0
    s.addi       s21, s2, #8576
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s2, #896
    v.st.w       [s11, #0], v0
    s.addi       s11, s2, #8640
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s2, #960
    v.st.w       [s8, #0], v0
    s.addi       s8, s2, #8704
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s2, #1024
    v.st.w       [s14, #0], v0
    s.addi       s14, s2, #8768
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s2, #1088
    v.st.w       [s17, #0], v0
    s.addi       s17, s2, #8832
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s2, #1152
    v.st.w       [s16, #0], v0
    s.addi       s16, s2, #8896
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s2, #1216
    v.st.w       [s19, #0], v0
    fence.acq_rel.device
    s.addi       s19, s2, #8960
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s2, #1280
    v.st.w       [s7, #0], v0
    s.addi       s7, s2, #9024
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s2, #1344
    v.st.w       [s23, #0], v0
    s.addi       s23, s2, #9088
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s2, #1408
    v.st.w       [s21, #0], v0
    s.addi       s21, s2, #9152
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s2, #1472
    v.st.w       [s11, #0], v0
    s.addi       s11, s2, #9216
    s.add        s24, s22, s4
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s2, #1536
    v.st.w       [s8, #0], v0
    s.addi       s8, s2, #9280
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s2, #1600
    v.st.w       [s14, #0], v0
    s.addi       s14, s2, #9344
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s2, #1664
    v.st.w       [s17, #0], v0
    s.addi       s17, s2, #9408
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s2, #1728
    v.st.w       [s16, #0], v0
    s.addi       s16, s2, #9472
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s2, #1792
    v.st.w       [s19, #0], v0
    s.addi       s19, s2, #9536
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s2, #1856
    v.st.w       [s7, #0], v0
    s.addi       s7, s2, #9600
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s2, #1920
    v.st.w       [s23, #0], v0
    s.addi       s23, s2, #9664
    s.addi       s25, s2, #1984
    v.ld.w       v0, [s17, #0]
    s.movz       s17, #1
    v.st.w       [s21, #0], v0
    v.ld.w       v0, [s16, #0]
    v.st.w       [s11, #0], v0
    v.ld.w       v0, [s19, #0]
    v.st.w       [s8, #0], v0
    v.ld.w       v0, [s7, #0]
    v.st.w       [s14, #0], v0
    v.ld.w       v0, [s23, #0]
    v.st.w       [s25, #0], v0
    fence.acq_rel.device
    s.mov        s22, s24
    br.nz        s17, for_5
endfor_6:
    s.movz       s1, #0
    s.movz       s2, #128
    s.add        s4, s1, s12                     // the tile origin
    v.splat      v0, s2
    v.splat      v1, s4
    v.movi       v3, #1
    v.movi       v4, #0
    s.movz       s1, #0
    s.movz       s2, #18432
    v.cmp.lt     p1, v1, v0
    @p1 v.sel        v1, v3, v4
    s.add        s7, s1, s5                      // the tile origin
    s.mul        s1, s15, s2
    s.muli       s2, s5, #2                      // a runtime tile origin, x2
    v.splat      v3, s7
    s.addi       s5, s4, #1
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s7, #0
    s.muli       s8, s12, #288                   // a runtime tile origin, x288
    v.splat      v4, s5
    v.extract    s5, v1, #0
    a.vread      v1, a0, s7
    s.movz       s7, #144
    v.splat      v5, s5
    v.movi       v6, #0
    v.add        v7, v2, v3
    v.splat      v2, s7
    v.movi       v3, #1
    v.movi       v8, #0
    s.muli       s5, s1, #2                      // a runtime tile origin, x2
    s.add        s1, s10, s2                     // the tile origin
    v.cmp.lt     p1, v4, v0
    v.splat      v4, s15
    vf.cvt.f32.bf16 v9, v1
    v.cmp.ne     p2, v5, v6
    v.splat      v1, s6
    v.cmp.lt     p3, v7, v2
    @p1 v.sel        v2, v3, v8
    s.add        s2, s1, s8                      // the tile origin
    p.and        p1, p2, p3
    v.cmp.lt     p2, v4, v1
    s.add        s1, s2, s5                      // the tile origin
    s.addi       s2, s4, #2
    p.and        p4, p1, p2
    s.movz       s5, #1
    v.extract    s6, v2, #0
    v.splat      v1, s2
    @p4 v.st.h       [s1, #0], v9
    a.vread      v2, a0, s5
    v.splat      v3, s6
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p1, v1, v0
    vf.cvt.f32.bf16 v1, v2
    v.cmp.ne     p4, v3, v4
    @p1 v.sel        v2, v5, v6
    p.and        p1, p4, p3
    s.addi       s2, s4, #3
    s.addi       s5, s1, #288                    // row 1
    p.and        p4, p1, p2
    s.movz       s6, #2
    v.extract    s7, v2, #0
    v.splat      v2, s2
    @p4 v.st.h       [s5, #0], v1
    a.vread      v1, a0, s6
    v.splat      v3, s7
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p1, v2, v0
    vf.cvt.f32.bf16 v2, v1
    v.cmp.ne     p4, v3, v4
    @p1 v.sel        v1, v5, v6
    p.and        p1, p4, p3
    s.addi       s2, s4, #4
    s.addi       s5, s1, #576                    // row 2
    p.and        p4, p1, p2
    s.movz       s6, #3
    v.extract    s7, v1, #0
    v.splat      v1, s2
    @p4 v.st.h       [s5, #0], v2
    a.vread      v2, a0, s6
    v.splat      v3, s7
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p1, v1, v0
    vf.cvt.f32.bf16 v1, v2
    v.cmp.ne     p4, v3, v4
    @p1 v.sel        v2, v5, v6
    p.and        p1, p4, p3
    s.addi       s2, s4, #5
    s.addi       s5, s1, #864                    // row 3
    p.and        p4, p1, p2
    s.movz       s6, #4
    v.extract    s7, v2, #0
    v.splat      v2, s2
    @p4 v.st.h       [s5, #0], v1
    a.vread      v1, a0, s6
    v.splat      v3, s7
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p1, v2, v0
    vf.cvt.f32.bf16 v2, v1
    v.cmp.ne     p4, v3, v4
    @p1 v.sel        v1, v5, v6
    p.and        p1, p4, p3
    s.addi       s2, s4, #6
    s.addi       s5, s1, #1152                   // row 4
    p.and        p4, p1, p2
    s.movz       s6, #5
    v.extract    s7, v1, #0
    v.splat      v1, s2
    @p4 v.st.h       [s5, #0], v2
    a.vread      v2, a0, s6
    v.splat      v3, s7
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p1, v1, v0
    vf.cvt.f32.bf16 v1, v2
    v.cmp.ne     p4, v3, v4
    @p1 v.sel        v2, v5, v6
    p.and        p1, p4, p3
    s.addi       s2, s4, #7
    s.addi       s5, s1, #1440                   // row 5
    p.and        p4, p1, p2
    s.movz       s6, #6
    v.extract    s7, v2, #0
    v.splat      v2, s2
    @p4 v.st.h       [s5, #0], v1
    a.vread      v1, a0, s6
    v.splat      v3, s7
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p1, v2, v0
    vf.cvt.f32.bf16 v2, v1
    v.cmp.ne     p4, v3, v4
    @p1 v.sel        v1, v5, v6
    p.and        p1, p4, p3
    s.addi       s2, s4, #8
    s.addi       s5, s1, #1728                   // row 6
    p.and        p4, p1, p2
    s.movz       s6, #7
    v.extract    s7, v1, #0
    v.splat      v1, s2
    @p4 v.st.h       [s5, #0], v2
    a.vread      v2, a0, s6
    v.splat      v3, s7
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p1, v1, v0
    vf.cvt.f32.bf16 v1, v2
    v.cmp.ne     p4, v3, v4
    @p1 v.sel        v2, v5, v6
    p.and        p1, p4, p3
    s.addi       s2, s4, #9
    s.addi       s5, s1, #2016                   // row 7
    p.and        p4, p1, p2
    s.movz       s6, #8
    v.extract    s7, v2, #0
    v.splat      v2, s2
    @p4 v.st.h       [s5, #0], v1
    a.vread      v1, a0, s6
    v.splat      v3, s7
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p1, v2, v0
    vf.cvt.f32.bf16 v2, v1
    v.cmp.ne     p4, v3, v4
    @p1 v.sel        v1, v5, v6
    p.and        p1, p4, p3
    s.addi       s2, s4, #10
    s.addi       s5, s1, #2304                   // row 8
    p.and        p4, p1, p2
    s.movz       s6, #9
    v.extract    s7, v1, #0
    v.splat      v1, s2
    @p4 v.st.h       [s5, #0], v2
    a.vread      v2, a0, s6
    v.splat      v3, s7
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p1, v1, v0
    vf.cvt.f32.bf16 v1, v2
    v.cmp.ne     p4, v3, v4
    @p1 v.sel        v2, v5, v6
    p.and        p1, p4, p3
    s.addi       s2, s4, #11
    s.addi       s5, s1, #2592                   // row 9
    p.and        p4, p1, p2
    s.movz       s6, #10
    v.extract    s7, v2, #0
    v.splat      v2, s2
    @p4 v.st.h       [s5, #0], v1
    a.vread      v1, a0, s6
    v.splat      v3, s7
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p1, v2, v0
    vf.cvt.f32.bf16 v2, v1
    v.cmp.ne     p4, v3, v4
    @p1 v.sel        v1, v5, v6
    p.and        p1, p4, p3
    s.addi       s2, s4, #12
    s.addi       s5, s1, #2880                   // row 10
    p.and        p4, p1, p2
    s.movz       s6, #11
    v.extract    s7, v1, #0
    v.splat      v1, s2
    @p4 v.st.h       [s5, #0], v2
    a.vread      v2, a0, s6
    v.splat      v3, s7
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p1, v1, v0
    vf.cvt.f32.bf16 v1, v2
    v.cmp.ne     p4, v3, v4
    @p1 v.sel        v2, v5, v6
    p.and        p1, p4, p3
    s.addi       s2, s4, #13
    s.addi       s5, s1, #3168                   // row 11
    p.and        p4, p1, p2
    s.movz       s6, #12
    v.extract    s7, v2, #0
    v.splat      v2, s2
    @p4 v.st.h       [s5, #0], v1
    a.vread      v1, a0, s6
    v.splat      v3, s7
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p1, v2, v0
    vf.cvt.f32.bf16 v2, v1
    v.cmp.ne     p4, v3, v4
    @p1 v.sel        v1, v5, v6
    p.and        p1, p4, p3
    s.addi       s2, s4, #14
    s.addi       s5, s1, #3456                   // row 12
    p.and        p4, p1, p2
    s.movz       s6, #13
    v.extract    s7, v1, #0
    v.splat      v1, s2
    @p4 v.st.h       [s5, #0], v2
    a.vread      v2, a0, s6
    v.splat      v3, s7
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p1, v1, v0
    vf.cvt.f32.bf16 v1, v2
    v.cmp.ne     p4, v3, v4
    @p1 v.sel        v2, v5, v6
    p.and        p1, p4, p3
    s.addi       s2, s4, #15
    s.addi       s4, s1, #3744                   // row 13
    p.and        p4, p1, p2
    s.movz       s5, #14
    v.extract    s6, v2, #0
    v.splat      v2, s2
    @p4 v.st.h       [s4, #0], v1
    a.vread      v1, a0, s5
    v.splat      v3, s6
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p1, v2, v0
    vf.cvt.f32.bf16 v0, v1
    v.cmp.ne     p4, v3, v4
    @p1 v.sel        v1, v5, v6
    p.and        p1, p4, p3
    s.addi       s2, s1, #4032                   // row 14
    p.and        p4, p1, p2
    s.movz       s4, #15
    v.extract    s5, v1, #0
    @p4 v.st.h       [s2, #0], v0
    a.vread      v0, a0, s4
    v.splat      v1, s5
    v.movi       v2, #0
    vf.cvt.f32.bf16 v3, v0
    s.addi       s2, s1, #4320                   // row 15
    v.cmp.ne     p1, v1, v2
    p.and        p4, p1, p3
    p.and        p1, p4, p2
    @p1 v.st.h       [s2, #0], v3
__rctx_next:
    exit
