module {
  tt.func public @pure() -> (i64, i64, i64, i64) {
    %v0 = arith.constant 64 : i64
    %v1 = arith.constant 16 : i64
    %v2 = arith.constant 32 : i64
    %v3 = arith.constant 48 : i64
    tt.return %v0, %v1, %v2, %v3 : i64, i64, i64, i64
  }
}
