from pathlib import Path
import subprocess,json
r=Path.cwd();out=r/'mutations';out.mkdir(exist_ok=False);records=[]
def run(name,args,expected=0):
 p=subprocess.run(args,capture_output=True,text=True,timeout=240);s=p.stdout+p.stderr;(out/(name+'.log')).write_text(s);assert p.returncode==expected,(name,p.returncode,s[-2400:]);return s
def record(name,text):
 records.append(dict(name=name,stdout=text));(out/'report.json').write_text(json.dumps(records,indent=2)+'\n');print(name,flush=True)
args=['iverilog','-g2012','-I','rtl/common','-s','tb_nuca_slice','-Ptb_nuca_slice.SETS=32','-Ptb_nuca_slice.SET_W=5','-Ptb_nuca_slice.WAYS=8','-Ptb_nuca_slice.WAY_W=3','-Ptb_nuca_slice.REGISTER_VICTIM_OWNER=1','-Ptb_nuca_slice.DCO_REGISTERED_RANGES=1','-Ptb_nuca_slice.AMO_TRAFFIC=1','-o',str(out/'widths.vvp'),'rtl/nuca/tnca_nuca_slice.v','tb/common/tnca_dram_model.v','tb/nuca/tb_nuca_data_atomic_widths.v']
run('widths_build',args);s=run('widths',['vvp',str(out/'widths.vvp'),'+seed=23','+nreq=4000','+min_wb=1']);assert 'PASS' in s.splitlines() and 'FAIL' not in s,s;record('atomic_widths_pass',s)
source=(r/'rtl/nuca/tnca_nuca_slice.v').read_text()
for name,needle,replacement in [('store_byte_mask',"data_write_mask={{(LINE_BYTES-WORD_BYTES){1'b0}},cur_be} << (cur_wsel*WORD_BYTES);","data_write_mask={LINE_BYTES{1'b1}};"),('hit_word_capture','hit_word_q<=data_mem[cur_set*WAYS+hit_way][cur_wsel*WORD_BITS+:WORD_BITS];','hit_word_q<=0;')]:
 assert source.count(needle)>=1
 p=out/(name+'.v');p.write_text(source.replace(needle,replacement));mutargs=list(args);mutargs[-3]=str(p);run(name+'_build',mutargs);s=run(name,['vvp',str(out/'widths.vvp'),'+seed=23','+nreq=4000','+min_wb=1'],1);assert 'miter mismatch' in s,s;record(name+'_detected',s)
source=(r/'rtl/nuca/tnca_tmu.v').read_text()
for name,needle,replacement,message in [('write_drain',"if (tl_pipeline_busy) mw_go = 1'b0;","if (1'b0) mw_go = 1'b0;",'metadata write overtook accepted notice'),('early_ack','mw_go = REGISTER_WRITES ? mw_pending_q : mw_offer;','mw_go = mw_offer;','write ACK before inbox capture')]:
 assert source.count(needle)==1
 p=out/(name+'.v');p.write_text(source.replace(needle,replacement));binary=str(out/(name+'.vvp'));run(name+'_build',['iverilog','-g2012','-I','rtl/common','-s','tb_tmu_registered_ranges','-o',binary,str(p),'tb/nuca/tb_tmu_pipeline_quiet.v']);s=run(name,['vvp',binary],1);assert message in s,s;record(name+'_detected',s)
print('R4_WIDTHS_MUTATIONS_DONE',flush=True)
