#!/bin/bash
# usage: run.sh NAME CFG MODE POINTS...
n=$1; cfg=$2; m=$3; shift 3; pts=(); for p in "$@"; do pts+=(--point $p); done
cd ~/r41-tte && source ~/tc_env/env.sh >/dev/null 2>&1
env_args=(); [ "$m" != 0 ] && env_args=(--env TNCA_TILED_POINTWISE=$m)
~/tc_env/torchenv/bin/python tools/performance_harness/systemc/run_graphs.py --source-root ~/r41-tte --binary ~/r41-tte-mb/tnca-chip \
  --config ~/r41-tte-runs/$cfg --out ~/r41-tte-runs/$n --active-cores 3 --env TNCA_RTL_MEM_PORTS=3 --env TNCA_RTL_OUTSTANDING=32 \
  --jobs 2 --timeout 3600 "${env_args[@]}" "${pts[@]}" > ~/r41-tte-runs/$n.log 2>&1
echo "rc=$?" >> ~/r41-tte-runs/$n.log
