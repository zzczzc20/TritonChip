module probe(output [7:0] observed, output [7:0] fixed_observed);
parameter [4:0] MAC_CUTS=29;
localparam MAC_LAT=MAC_CUTS[0]+MAC_CUTS[1]+MAC_CUTS[2]+MAC_CUTS[3]+MAC_CUTS[4];
localparam integer FIXED=MAC_CUTS[0]+MAC_CUTS[1]+MAC_CUTS[2]+MAC_CUTS[3]+MAC_CUTS[4];
assign observed=MAC_LAT;assign fixed_observed=FIXED;
endmodule
