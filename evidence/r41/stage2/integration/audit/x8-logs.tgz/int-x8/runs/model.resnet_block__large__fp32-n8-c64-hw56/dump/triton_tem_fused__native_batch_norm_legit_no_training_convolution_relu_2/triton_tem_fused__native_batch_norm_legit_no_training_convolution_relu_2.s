    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    v.movi       v1, #56
    v.movi       v2, #0
    s.rdspecial  s3, arg_base
    v.sub        v3, v2, v1
    v.splat      v4, s2
    v.cmp.lt     p1, v1, v2
    v.add        v5, v4, v0
    s.ld.d       s2, [s3, #0]                    // arg_X: device_ptr64 at arg_base+0
    v.sub        v4, v2, v5
    v.cmp.lt     p2, v5, v2
    s.ld.d       s4, [s3, #8]                    // arg_W: device_ptr64 at arg_base+8
    v.movi       v6, #1
    @p2 v.sel        v7, v4, v5
    s.ld.d       s5, [s3, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    @p1 v.sel        v4, v3, v1
    v.movi       v3, #0
    s.ld.d       s6, [s3, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    v.movi       v8, #0
    s.movz       s7, #31
    s.ld.d       s8, [s3, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s9, [s3, #40]                   // in_ptr5: device_ptr64 at arg_base+40
    s.ld.d       s10, [s3, #48]                  // out_ptr1: device_ptr64 at arg_base+48
idiv_1:
    v.splat      v9, s7
    v.shl        v10, v8, v6
    v.lshr       v11, v7, v9
    v.cmp.lt     p1, v8, v2
    v.and        v12, v11, v6
    v.shl        v11, v6, v9
    v.or         v9, v10, v12
    s.subi       s3, s7, #1
    v.cmp.geu    p3, v9, v4
    p.or         p4, p1, p3
    v.sub        v10, v9, v4
    @p4 v.sel        v12, v11, v2
    @p4 v.sel        v11, v10, v9
    v.or         v9, v3, v12
    v.mov        v8, v11
    v.mov        v3, v9
    s.mov        s7, s3
    s.movz       s3, #0
    s.cmp.ge     s11, s7, s3
    br.nz        s11, idiv_1
    v.movi       v3, #0
    v.sub        v4, v2, v8
    v.sub        v2, v3, v5
    v.sub        v6, v3, v1
    v.cmp.lt     p1, v5, v3
    v.cmp.lt     p3, v1, v3
    @p2 v.sel        v7, v4, v8
    v.movi       v4, #1
    @p1 v.sel        v8, v2, v5
    @p3 v.sel        v2, v6, v1
    v.movi       v5, #0
    v.movi       v6, #0
    s.movz       s3, #31
idiv_2:
    v.splat      v9, s3
    v.shl        v10, v6, v4
    v.lshr       v11, v8, v9
    v.cmp.lt     p2, v6, v3
    v.and        v12, v11, v4
    v.shl        v11, v4, v9
    v.or         v9, v10, v12
    s.subi       s7, s3, #1
    v.cmp.geu    p4, v9, v2
    p.or         p5, p2, p4
    v.sub        v10, v9, v2
    @p5 v.sel        v12, v11, v3
    @p5 v.sel        v11, v10, v9
    v.or         v9, v5, v12
    v.mov        v6, v11
    v.mov        v5, v9
    s.mov        s3, s7
    s.movz       s7, #0
    s.cmp.ge     s11, s3, s7
    br.nz        s11, idiv_2
    p.xor        p2, p1, p3
    v.sub        v2, v3, v5
    v.movi       v3, #0
    @p2 v.sel        v4, v2, v5
    v.sub        v2, v3, v1
    v.sub        v5, v3, v4
    v.cmp.lt     p1, v4, v3
    v.cmp.lt     p2, v1, v3
    v.movi       v6, #1
    @p1 v.sel        v8, v5, v4
    @p2 v.sel        v5, v2, v1
    v.movi       v2, #0
    v.movi       v9, #0
    s.movz       s3, #31
idiv_3:
    v.splat      v10, s3
    v.shl        v11, v9, v6
    v.lshr       v12, v8, v10
    v.cmp.lt     p2, v9, v3
    v.and        v13, v12, v6
    v.shl        v12, v6, v10
    v.or         v10, v11, v13
    s.subi       s7, s3, #1
    v.cmp.geu    p3, v10, v5
    p.or         p4, p2, p3
    v.sub        v11, v10, v5
    @p4 v.sel        v13, v12, v3
    @p4 v.sel        v12, v11, v10
    v.or         v10, v2, v13
    v.mov        v9, v12
    v.mov        v2, v10
    s.mov        s3, s7
    s.movz       s7, #0
    s.cmp.ge     s11, s3, s7
    br.nz        s11, idiv_3
    v.movi       v2, #0
    v.sub        v5, v3, v9
    v.sub        v3, v2, v4
    v.sub        v6, v2, v1
    v.cmp.lt     p2, v4, v2
    v.cmp.lt     p3, v1, v2
    @p1 v.sel        v8, v5, v9
    v.movi       v5, #1
    @p2 v.sel        v9, v3, v4
    @p3 v.sel        v3, v6, v1
    v.movi       v4, #0
    v.movi       v6, #0
    s.movz       s3, #31
idiv_4:
    v.splat      v10, s3
    v.shl        v11, v6, v5
    v.lshr       v12, v9, v10
    v.cmp.lt     p1, v6, v2
    v.and        v13, v12, v5
    v.shl        v12, v5, v10
    v.or         v10, v11, v13
    s.subi       s7, s3, #1
    v.cmp.geu    p4, v10, v3
    p.or         p5, p1, p4
    v.sub        v11, v10, v3
    @p5 v.sel        v13, v12, v2
    @p5 v.sel        v12, v11, v10
    v.or         v10, v4, v13
    v.mov        v6, v12
    v.mov        v4, v10
    s.mov        s3, s7
    s.movz       s7, #0
    s.cmp.ge     s11, s3, s7
    br.nz        s11, idiv_4
    s.rdspecial  s3, pid.y
    s.rdspecial  s7, role_id
    s.mul        s11, s3, s1
    s.movz       s3, #4160
    p.xor        p1, p2, p3
    v.sub        v3, v2, v4
    s.rdspecial  s12, arg_base
    s.mul        s13, s7, s3
    @p1 v.sel        v2, v3, v4
    .li       s3, #200704
    v.splat      v3, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.ld.d       s3, [s12, #56]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.splat      v4, s11
    v.mul        v5, v2, v3
    v.add        v3, v4, v0
    s.add        s7, s3, s13                     // this context's own scratch
    s.movz       s3, #0
    v.extract    s12, v5, #0
    v.extract    s13, v5, #1
    v.extract    s14, v5, #2
    v.extract    s15, v5, #3
    v.extract    s16, v5, #4
    v.extract    s17, v5, #5
    v.extract    s18, v5, #6
    v.extract    s19, v5, #7
    v.splat      v4, s3
    v.splat      v6, s12
    s.addi       s12, s7, #0
    v.splat      v9, s13
    v.splat      v10, s14
    v.splat      v11, s15
    v.splat      v12, s16
    v.add        v13, v4, v6
    s.addi       s13, s12, #64
    v.add        v6, v4, v9
    s.addi       s14, s12, #128
    v.add        v9, v4, v10
    s.addi       s15, s12, #192
    v.add        v10, v4, v11
    s.addi       s16, s12, #256
    v.add        v11, v4, v12
    v.st.w       [s12, #0], v13
    v.splat      v12, s17
    s.addi       s17, s12, #320
    v.add        v13, v4, v12
    v.st.w       [s13, #0], v6
    v.splat      v6, s18
    s.addi       s13, s12, #384
    v.add        v12, v4, v6
    s.addi       s18, s12, #448
    v.st.w       [s14, #0], v9
    .li       s14, #200704
    v.splat      v6, s19
    v.extract    s19, v5, #8
    v.add        v9, v4, v6
    v.st.w       [s15, #0], v10
    v.extract    s15, v5, #9
    v.splat      v6, s19
    v.extract    s19, v5, #10
    v.add        v10, v4, v6
    v.st.w       [s16, #0], v11
    v.extract    s16, v5, #11
    v.splat      v6, s15
    v.extract    s15, v5, #12
    v.add        v11, v4, v6
    v.st.w       [s17, #0], v13
    v.extract    s17, v5, #13
    v.splat      v6, s19
    v.extract    s19, v5, #14
    v.add        v13, v4, v6
    s.movz       s20, #576
    v.st.w       [s13, #0], v12
    v.movi       v6, #576
    v.extract    s13, v5, #15
    v.splat      v5, s16
    v.mul        v12, v3, v6
    s.addi       s16, s12, #512
    v.add        v6, v4, v5
    v.st.w       [s18, #0], v9
    v.splat      v5, s15
    s.addi       s15, s12, #576
    s.addi       s18, s12, #640
    v.add        v9, v4, v5
    v.st.w       [s16, #0], v10
    v.splat      v5, s17
    s.addi       s16, s12, #704
    s.addi       s17, s12, #768
    v.add        v10, v4, v5
    v.st.w       [s15, #0], v11
    v.splat      v5, s19
    s.addi       s15, s12, #832
    s.addi       s19, s12, #896
    v.add        v11, v4, v5
    s.addi       s20, s12, #960
    v.st.w       [s18, #0], v13
    v.splat      v5, s13
    s.addi       s12, s7, #1024
    v.add        v13, v4, v5
    v.splat      v4, s3
    s.movz       s13, #36
    v.add        v5, v4, v12
    v.st.w       [s16, #0], v6
    s.movz       s16, #1
    v.st.w       [s17, #0], v9
    s.addi       s17, s3, #0
    v.st.w       [s15, #0], v10
    v.st.w       [s19, #0], v11
    v.st.w       [s20, #0], v13
    fence.acq_rel.device
    v.st.w       [s12, #0], v5
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s12, s17, s13
    br.nz        s12, endfor_6
    s.movz       s12, #0
    s.movz       s15, #0
    s.cmp.lt     s18, s17, s12
    s.movz       s12, #4
    s.sub        s19, s15, s18
    s.movz       s15, #0
    s.movz       s18, #0
    s.cmp.lt     s20, s12, s15
    s.xor        s15, s17, s19
    s.sub        s21, s18, s20
    s.sub        s18, s15, s19
    s.xor        s15, s19, s21
    s.lshri      s19, s18, #2
    s.movz       s20, #0
    s.xor        s22, s19, s15
    s.movz       s23, #0
    s.sub        s24, s22, s15
    s.movz       s15, #0
    s.cmp.lt     s22, s24, s20
    s.movz       s20, #0
    s.sub        s25, s23, s22
    .li       s22, #1431655766
    s.xor        s23, s24, s25
    s.cmp.lt     s26, s17, s15
    s.sub        s15, s23, s25
    s.sub        s23, s20, s26
    s.mul        s20, s15, s22
    s.xor        s22, s17, s23
    s.movz       s26, #3
    s.sub        s27, s22, s23
    s.muli       s22, s19, #4
    s.lshri      s19, s20, #32
    s.sub        s20, s18, s22
    s.movz       s18, #0
    s.lshri      s20, s27, #2
    s.cmp.lt     s22, s26, s18
    s.muli       s18, s20, #4
    s.sub        s20, s27, s18
    s.movz       s18, #0
    s.xor        s27, s20, s23
    s.sub        s20, s18, s22
    s.sub        s18, s27, s23
    s.movz       s22, #0
    s.mul        s23, s18, s1
    s.movz       s18, #0
    s.sub        s27, s15, s19
    s.cmp.lt     s28, s12, s22
    s.lshri      s22, s27, #1
    s.sub        s27, s18, s28
    s.add        s18, s19, s22
    s.xor        s19, s12, s27
    s.lshri      s22, s18, #1
    s.xor        s18, s25, s20
    s.muli       s25, s22, #3
    s.xor        s28, s12, s21
    s.sub        s12, s19, s27
    s.movz       s12, #0
    s.movz       s19, #0
    s.cmp.lt     s27, s24, s12
    s.xor        s12, s22, s18
    s.sub        s22, s19, s27
    .li       s19, #1431655766
    s.xor        s27, s24, s22
    s.sub        s24, s12, s18
    s.sub        s12, s27, s22
    s.movz       s18, #0
    s.mul        s27, s12, s19
    s.cmp.lt     s19, s26, s18
    s.sub        s18, s28, s21
    s.sub        s18, s24, s16
    v.movi       v4, #3584
    s.lshri      s21, s27, #32
    v.splat      v5, s18
    s.sub        s18, s12, s21
    v.add        v6, v5, v8
    s.lshri      s27, s18, #1
    v.mul        v5, v6, v4
    s.add        s18, s21, s27
    v.splat      v4, s23
    s.lshri      s21, s18, #1
    v.add        v9, v0, v4
    s.muli       s18, s21, #3
    s.movz       s21, #0
    s.xor        s27, s26, s20
    s.sub        s28, s21, s19
    s.movz       s19, #64
    s.sub        s21, s12, s18
    s.xor        s12, s26, s28
    s.xor        s18, s21, s22
    s.sub        s21, s27, s20
    s.sub        s20, s18, s22
    s.addi       s18, s7, #0
    s.sub        s21, s20, s16
    v.movi       v4, #64
    v.splat      v10, s21
    v.ld.w       v11, [s18, #0]
    v.add        v12, v10, v7
    v.extract    s18, v5, #0
    v.mul        v10, v12, v4
    v.splat      v13, s18
    v.extract    s18, v10, #0
    v.splat      v14, s18
    s.addi       s18, s7, #1088
    s.sub        s21, s15, s25
    s.movz       s15, #0
    v.iota       v15                             // arange(0, VLEN)
    s.add        s21, s15, s23                   // the tile origin
    v.add        v16, v13, v14
    v.splat      v13, s21
    s.addi       s15, s7, #64
    v.add        v14, v15, v13
    v.extract    s21, v5, #1
    v.add        v13, v16, v14
    v.extract    s22, v10, #1
    v.add        v16, v11, v13
    v.splat      v11, s21
    v.st.w       [s18, #0], v16
    s.addi       s21, s18, #64
    s.sub        s25, s12, s28
    v.splat      v13, s22
    s.addi       s12, s7, #128
    v.add        v16, v11, v13
    v.extract    s22, v5, #2
    v.add        v11, v16, v14
    v.extract    s25, v10, #2
    v.splat      v13, s22
    v.ld.w       v16, [s15, #0]
    v.splat      v17, s25
    s.addi       s15, s18, #128
    v.add        v18, v13, v17
    s.addi       s22, s7, #192
    v.add        v13, v18, v14
    v.extract    s25, v5, #3
    s.addi       s26, s18, #192
    s.movz       s27, #3584
    v.extract    s27, v10, #3
    v.add        v17, v16, v11
    v.splat      v11, s25
    v.st.w       [s21, #0], v17
    v.splat      v16, s27
    s.addi       s21, s7, #256
    v.add        v17, v11, v16
    v.extract    s25, v5, #4
    v.add        v11, v17, v14
    v.extract    s27, v10, #4
    v.splat      v16, s25
    v.splat      v17, s27
    s.addi       s25, s18, #256
    v.ld.w       v18, [s12, #0]
    v.add        v19, v16, v17
    s.addi       s12, s7, #320
    v.add        v16, v19, v14
    v.extract    s27, v5, #5
    v.splat      v17, s27
    v.extract    s27, v10, #5
    v.splat      v19, s27
    s.addi       s27, s18, #320
    v.add        v20, v17, v19
    v.add        v17, v18, v13
    v.add        v13, v20, v14
    v.st.w       [s15, #0], v17
    s.addi       s15, s7, #384
    v.ld.w       v17, [s22, #0]
    v.extract    s22, v5, #6
    v.splat      v18, s22
    v.extract    s22, v10, #6
    v.splat      v19, s22
    s.addi       s22, s18, #384
    v.add        v20, v18, v19
    v.add        v18, v20, v14
    v.add        v19, v17, v11
    v.st.w       [s26, #0], v19
    s.addi       s26, s7, #448
    v.ld.w       v11, [s21, #0]
    v.extract    s21, v5, #7
    v.splat      v17, s21
    v.extract    s21, v10, #7
    v.splat      v19, s21
    s.addi       s21, s18, #448
    v.add        v20, v17, v19
    v.add        v17, v20, v14
    v.add        v19, v11, v16
    v.st.w       [s25, #0], v19
    s.addi       s25, s7, #512
    v.ld.w       v11, [s12, #0]
    v.extract    s12, v5, #8
    v.splat      v16, s12
    v.extract    s12, v10, #8
    v.splat      v19, s12
    s.addi       s12, s18, #512
    v.add        v20, v16, v19
    v.add        v16, v20, v14
    v.add        v19, v11, v13
    v.st.w       [s27, #0], v19
    s.addi       s27, s7, #576
    v.ld.w       v11, [s15, #0]
    v.extract    s15, v5, #9
    v.splat      v13, s15
    v.extract    s15, v10, #9
    v.splat      v19, s15
    s.addi       s15, s18, #576
    v.add        v20, v13, v19
    v.add        v13, v20, v14
    v.add        v19, v11, v18
    v.st.w       [s22, #0], v19
    s.addi       s22, s7, #640
    v.ld.w       v11, [s26, #0]
    v.extract    s26, v5, #10
    v.splat      v18, s26
    v.extract    s26, v10, #10
    v.splat      v19, s26
    s.addi       s26, s18, #640
    v.add        v20, v18, v19
    v.add        v18, v20, v14
    v.add        v19, v11, v17
    v.st.w       [s21, #0], v19
    s.addi       s21, s7, #704
    v.ld.w       v11, [s25, #0]
    v.extract    s25, v5, #11
    v.splat      v17, s25
    v.extract    s25, v10, #11
    v.splat      v19, s25
    s.addi       s25, s18, #704
    v.add        v20, v17, v19
    v.add        v17, v20, v14
    v.add        v19, v11, v16
    v.st.w       [s12, #0], v19
    s.addi       s12, s7, #768
    v.ld.w       v11, [s27, #0]
    v.extract    s27, v5, #12
    v.splat      v16, s27
    v.extract    s27, v10, #12
    v.splat      v19, s27
    s.addi       s27, s18, #768
    v.add        v20, v16, v19
    v.add        v16, v20, v14
    v.add        v19, v11, v13
    v.st.w       [s15, #0], v19
    s.addi       s15, s7, #832
    v.ld.w       v11, [s22, #0]
    v.extract    s22, v5, #13
    v.splat      v13, s22
    v.extract    s22, v10, #13
    v.splat      v19, s22
    s.addi       s22, s18, #832
    v.add        v20, v13, v19
    v.add        v13, v20, v14
    v.add        v19, v11, v18
    v.st.w       [s26, #0], v19
    s.addi       s26, s7, #896
    v.ld.w       v11, [s21, #0]
    v.extract    s21, v5, #14
    v.splat      v18, s21
    v.extract    s21, v10, #14
    v.splat      v19, s21
    s.addi       s21, s18, #896
    v.add        v20, v18, v19
    v.movi       v18, #8
    v.add        v19, v20, v14
    s.addi       s28, s18, #960
    v.add        v20, v11, v17
    v.cmp.lt     p1, v2, v18
    v.st.w       [s25, #0], v20
    s.addi       s18, s7, #960
    v.movi       v11, #1
    v.movi       v17, #0
    @p1 v.sel        v18, v11, v17
    v.ld.w       v11, [s12, #0]
    v.extract    s12, v5, #15
    v.movi       v5, #0
    v.splat      v17, s12
    v.extract    s12, v10, #15
    v.splat      v10, s12
    v.movi       v20, #1
    v.cmp.ge     p1, v6, v5
    v.add        v21, v17, v10
    v.movi       v10, #0
    v.add        v17, v11, v16
    @p1 v.sel        v11, v20, v10
    v.st.w       [s27, #0], v17
    v.movi       v10, #1
    v.movi       v16, #0
    v.cmp.lt     p1, v6, v1
    v.add        v6, v21, v14
    @p1 v.sel        v14, v10, v16
    v.movi       v10, #1
    v.cmp.ge     p1, v12, v5
    v.ld.w       v5, [s15, #0]
    v.movi       v16, #0
    v.movi       v17, #1
    @p1 v.sel        v20, v10, v16
    v.movi       v10, #0
    v.cmp.lt     p1, v12, v1
    @p1 v.sel        v12, v17, v10
    v.cmp.lt     p1, v9, v4
    v.add        v4, v5, v13
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s12, #0
    v.st.w       [s22, #0], v4
    v.extract    s15, v18, #0
    s.addi       s22, s7, #1088
    v.ld.w       v4, [s26, #0]
    v.extract    s25, v11, #0
    v.splat      v5, s15
    v.movi       v9, #0
    v.splat      v10, s25
    v.movi       v13, #0
    v.cmp.ne     p2, v5, v9
    v.cmp.ne     p3, v10, v13
    v.add        v5, v4, v19
    p.and        p4, p2, p3
    v.st.w       [s21, #0], v5
    v.extract    s15, v14, #0
    v.splat      v4, s15
    v.movi       v5, #0
    v.ld.w       v9, [s18, #0]
    v.extract    s15, v20, #0
    v.cmp.ne     p2, v4, v5
    v.splat      v4, s15
    v.movi       v5, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v4, v5
    p.and        p4, p3, p2
    v.add        v4, v9, v6
    v.extract    s15, v12, #0
    v.st.w       [s28, #0], v4
    fence.acq_rel.device
    v.splat      v4, s15
    v.movi       v5, #0
    v.extract    s15, v18, #1
    v.cmp.ne     p2, v4, v5
    p.and        p3, p4, p2
    v.extract    s18, v11, #1
    p.and        p2, p3, p1
    v.splat      v4, s15
    v.ld.w       v5, [s22, #0]
    v.movi       v6, #0
    v.splat      v9, s18
    v.movi       v10, #0
    s.addi       s15, s7, #1152
    v.extract    s18, v14, #1
    v.cmp.ne     p3, v4, v6
    v.cmp.ne     p4, v9, v10
    v.splat      v4, s18
    v.movi       v6, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v9, [s2, v5]               // index is in elements (ISA sec 9.1)
    p.and        p2, p3, p4
    v.extract    s18, v20, #1
    v.cmp.ne     p3, v4, v6
    v.splat      v4, s18
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.extract    s18, v12, #1
    v.cmp.ne     p2, v4, v5
    v.splat      v4, s18
    a.vwrite     a1, s12, v9
    v.ld.w       v5, [s15, #0]
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v4, v6
    p.and        p4, p3, p2
    v.extract    s12, v18, #2
    p.and        p2, p4, p1
    v.extract    s15, v11, #2
    v.splat      v4, s12
    v.movi       v6, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v9, [s2, v5]               // index is in elements (ISA sec 9.1)
    v.splat      v5, s15
    v.movi       v10, #0
    s.movz       s12, #1
    s.addi       s15, s7, #1216
    v.extract    s18, v14, #2
    v.cmp.ne     p2, v4, v6
    v.cmp.ne     p3, v5, v10
    v.splat      v4, s18
    v.movi       v5, #0
    a.vwrite     a1, s12, v9
    v.ld.w       v6, [s15, #0]
    p.and        p4, p2, p3
    v.extract    s12, v20, #2
    v.cmp.ne     p2, v4, v5
    v.splat      v4, s12
    v.movi       v5, #0
    p.and        p3, p4, p2
    v.extract    s12, v12, #2
    v.cmp.ne     p2, v4, v5
    v.splat      v4, s12
    v.movi       v5, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v4, v5
    p.and        p3, p4, p2
    v.extract    s12, v18, #3
    p.and        p2, p3, p1
    v.extract    s15, v11, #3
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s2, v6]               // index is in elements (ISA sec 9.1)
    v.splat      v5, s12
    v.movi       v6, #0
    v.splat      v9, s15
    v.movi       v10, #0
    s.movz       s12, #2
    s.addi       s15, s7, #1280
    v.extract    s18, v14, #3
    v.cmp.ne     p2, v5, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v5, s18
    v.movi       v6, #0
    a.vwrite     a1, s12, v4
    v.ld.w       v4, [s15, #0]
    p.and        p4, p2, p3
    v.extract    s12, v20, #3
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s12
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s12, v12, #3
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s12
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v5, v6
    p.and        p3, p4, p2
    v.extract    s12, v18, #4
    p.and        p2, p3, p1
    v.extract    s15, v11, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s2, v4]               // index is in elements (ISA sec 9.1)
    v.splat      v4, s12
    v.movi       v6, #0
    v.splat      v9, s15
    v.movi       v10, #0
    s.movz       s12, #3
    s.addi       s15, s7, #1344
    v.extract    s18, v14, #4
    v.cmp.ne     p2, v4, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v4, s18
    v.movi       v6, #0
    a.vwrite     a1, s12, v5
    v.ld.w       v5, [s15, #0]
    p.and        p4, p2, p3
    v.extract    s12, v20, #4
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s12
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s12, v12, #4
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s12
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v4, v6
    p.and        p3, p4, p2
    v.extract    s12, v18, #5
    p.and        p2, p3, p1
    v.extract    s15, v11, #5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s2, v5]               // index is in elements (ISA sec 9.1)
    v.splat      v5, s12
    v.movi       v6, #0
    v.splat      v9, s15
    v.movi       v10, #0
    s.movz       s12, #4
    s.addi       s15, s7, #1408
    v.extract    s18, v14, #5
    v.cmp.ne     p2, v5, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v5, s18
    v.movi       v6, #0
    a.vwrite     a1, s12, v4
    v.ld.w       v4, [s15, #0]
    p.and        p4, p2, p3
    v.extract    s12, v20, #5
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s12
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s12, v12, #5
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s12
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v5, v6
    p.and        p3, p4, p2
    v.extract    s12, v18, #6
    p.and        p2, p3, p1
    v.extract    s15, v11, #6
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s2, v4]               // index is in elements (ISA sec 9.1)
    v.splat      v4, s12
    v.movi       v6, #0
    v.splat      v9, s15
    v.movi       v10, #0
    s.movz       s12, #5
    s.addi       s15, s7, #1472
    v.extract    s18, v14, #6
    v.cmp.ne     p2, v4, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v4, s18
    v.movi       v6, #0
    a.vwrite     a1, s12, v5
    v.ld.w       v5, [s15, #0]
    p.and        p4, p2, p3
    v.extract    s12, v20, #6
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s12
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s12, v12, #6
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s12
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v4, v6
    p.and        p3, p4, p2
    v.extract    s12, v18, #7
    p.and        p2, p3, p1
    v.extract    s15, v11, #7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s2, v5]               // index is in elements (ISA sec 9.1)
    v.splat      v5, s12
    v.movi       v6, #0
    v.splat      v9, s15
    v.movi       v10, #0
    s.movz       s12, #6
    s.addi       s15, s7, #1536
    v.extract    s18, v14, #7
    v.cmp.ne     p2, v5, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v5, s18
    v.movi       v6, #0
    a.vwrite     a1, s12, v4
    v.ld.w       v4, [s15, #0]
    p.and        p4, p2, p3
    v.extract    s12, v20, #7
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s12
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s12, v12, #7
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s12
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v5, v6
    p.and        p3, p4, p2
    v.extract    s12, v18, #8
    p.and        p2, p3, p1
    v.extract    s15, v11, #8
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s2, v4]               // index is in elements (ISA sec 9.1)
    v.splat      v4, s12
    v.movi       v6, #0
    v.splat      v9, s15
    v.movi       v10, #0
    s.movz       s12, #7
    s.addi       s15, s7, #1600
    v.extract    s18, v14, #8
    v.cmp.ne     p2, v4, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v4, s18
    v.movi       v6, #0
    a.vwrite     a1, s12, v5
    v.ld.w       v5, [s15, #0]
    p.and        p4, p2, p3
    v.extract    s12, v20, #8
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s12
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s12, v12, #8
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s12
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v4, v6
    p.and        p3, p4, p2
    v.extract    s12, v18, #9
    p.and        p2, p3, p1
    v.extract    s15, v11, #9
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s2, v5]               // index is in elements (ISA sec 9.1)
    v.splat      v5, s12
    v.movi       v6, #0
    v.splat      v9, s15
    v.movi       v10, #0
    s.movz       s12, #8
    s.addi       s15, s7, #1664
    v.extract    s18, v14, #9
    v.cmp.ne     p2, v5, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v5, s18
    v.movi       v6, #0
    a.vwrite     a1, s12, v4
    v.ld.w       v4, [s15, #0]
    p.and        p4, p2, p3
    v.extract    s12, v20, #9
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s12
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s12, v12, #9
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s12
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v5, v6
    p.and        p3, p4, p2
    v.extract    s12, v18, #10
    p.and        p2, p3, p1
    v.extract    s15, v11, #10
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s2, v4]               // index is in elements (ISA sec 9.1)
    v.splat      v4, s12
    v.movi       v6, #0
    v.splat      v9, s15
    v.movi       v10, #0
    s.movz       s12, #9
    s.addi       s15, s7, #1728
    v.extract    s18, v14, #10
    v.cmp.ne     p2, v4, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v4, s18
    v.movi       v6, #0
    a.vwrite     a1, s12, v5
    v.ld.w       v5, [s15, #0]
    p.and        p4, p2, p3
    v.extract    s12, v20, #10
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s12
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s12, v12, #10
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s12
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v4, v6
    p.and        p3, p4, p2
    v.extract    s12, v18, #11
    p.and        p2, p3, p1
    v.extract    s15, v11, #11
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s2, v5]               // index is in elements (ISA sec 9.1)
    v.splat      v5, s12
    v.movi       v6, #0
    v.splat      v9, s15
    v.movi       v10, #0
    s.movz       s12, #10
    s.addi       s15, s7, #1792
    v.extract    s18, v14, #11
    v.cmp.ne     p2, v5, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v5, s18
    v.movi       v6, #0
    a.vwrite     a1, s12, v4
    v.ld.w       v4, [s15, #0]
    p.and        p4, p2, p3
    v.extract    s12, v20, #11
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s12
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s12, v12, #11
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s12
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v5, v6
    p.and        p3, p4, p2
    v.extract    s12, v18, #12
    p.and        p2, p3, p1
    v.extract    s15, v11, #12
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s2, v4]               // index is in elements (ISA sec 9.1)
    v.splat      v4, s12
    v.movi       v6, #0
    v.splat      v9, s15
    v.movi       v10, #0
    s.movz       s12, #11
    s.addi       s15, s7, #1856
    v.extract    s18, v14, #12
    v.cmp.ne     p2, v4, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v4, s18
    v.movi       v6, #0
    a.vwrite     a1, s12, v5
    v.ld.w       v5, [s15, #0]
    p.and        p4, p2, p3
    v.extract    s12, v20, #12
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s12
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s12, v12, #12
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s12
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v4, v6
    p.and        p3, p4, p2
    v.extract    s12, v18, #13
    p.and        p2, p3, p1
    v.extract    s15, v11, #13
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s2, v5]               // index is in elements (ISA sec 9.1)
    v.splat      v5, s12
    v.movi       v6, #0
    v.splat      v9, s15
    v.movi       v10, #0
    s.movz       s12, #12
    s.addi       s15, s7, #1920
    v.extract    s18, v14, #13
    v.cmp.ne     p2, v5, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v5, s18
    v.movi       v6, #0
    a.vwrite     a1, s12, v4
    v.ld.w       v4, [s15, #0]
    p.and        p4, p2, p3
    v.extract    s12, v20, #13
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s12
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s12, v12, #13
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s12
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v5, v6
    p.and        p3, p4, p2
    v.extract    s12, v18, #14
    p.and        p2, p3, p1
    v.extract    s15, v11, #14
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s2, v4]               // index is in elements (ISA sec 9.1)
    v.splat      v4, s12
    v.movi       v6, #0
    v.splat      v9, s15
    v.movi       v10, #0
    s.movz       s12, #13
    s.addi       s15, s7, #1984
    v.extract    s18, v14, #14
    v.cmp.ne     p2, v4, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v4, s18
    v.movi       v6, #0
    a.vwrite     a1, s12, v5
    v.ld.w       v5, [s15, #0]
    p.and        p4, p2, p3
    v.extract    s12, v20, #14
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s12
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s12, v12, #14
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s12
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v4, v6
    p.and        p3, p4, p2
    v.extract    s12, v18, #15
    p.and        p2, p3, p1
    v.extract    s15, v11, #15
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s2, v5]               // index is in elements (ISA sec 9.1)
    v.splat      v5, s12
    v.movi       v6, #0
    v.splat      v9, s15
    v.movi       v10, #0
    s.movz       s12, #14
    s.addi       s15, s7, #2048
    v.extract    s18, v14, #15
    v.cmp.ne     p2, v5, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v5, s18
    v.movi       v6, #0
    a.vwrite     a1, s12, v4
    v.ld.w       v4, [s15, #0]
    p.and        p4, p2, p3
    v.extract    s12, v20, #15
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s12
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s12, v12, #15
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s12
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v5, v6
    p.and        p3, p4, p2
    s.movz       s12, #192
    p.and        p2, p3, p1
    s.movz       s15, #15
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s2, v4]               // index is in elements (ISA sec 9.1)
    s.addi       s18, s7, #1024
    s.mul        s21, s24, s12
    s.movz       s12, #0
    s.mul        s22, s20, s19
    s.add        s20, s12, s23                   // the tile origin
    s.addi       s12, s7, #2112
    s.add        s24, s20, s21                   // the tile origin
    s.addi       s20, s7, #1024
    s.add        s21, s24, s22                   // the tile origin
    a.vwrite     a1, s15, v5
    v.ld.w       v4, [s18, #0]
    v.splat      v5, s21
    s.addi       s15, s21, #1
    s.addi       s18, s12, #64
    v.splat      v6, s15
    s.addi       s15, s7, #1024
    s.addi       s22, s21, #2
    s.addi       s24, s12, #128
    v.splat      v9, s22
    s.addi       s22, s7, #1024
    v.add        v10, v4, v5
    s.addi       s25, s21, #3
    v.st.w       [s12, #0], v10
    v.splat      v4, s25
    s.addi       s25, s12, #192
    s.addi       s26, s7, #1024
    s.addi       s27, s21, #4
    s.addi       s28, s12, #256
    v.splat      v5, s27
    s.addi       s27, s7, #1024
    v.ld.w       v10, [s20, #0]
    s.addi       s20, s21, #5
    v.splat      v11, s20
    s.addi       s20, s12, #320
    v.add        v12, v10, v6
    v.st.w       [s18, #0], v12
    s.addi       s18, s7, #1024
    v.ld.w       v6, [s15, #0]
    s.addi       s15, s21, #6
    v.splat      v10, s15
    s.addi       s15, s12, #384
    v.add        v12, v6, v9
    v.st.w       [s24, #0], v12
    s.addi       s24, s7, #1024
    v.ld.w       v6, [s22, #0]
    s.addi       s22, s21, #7
    v.splat      v9, s22
    s.addi       s22, s12, #448
    v.add        v12, v6, v4
    v.st.w       [s25, #0], v12
    s.addi       s25, s7, #1024
    v.ld.w       v4, [s26, #0]
    s.addi       s26, s21, #8
    v.splat      v6, s26
    s.addi       s26, s12, #512
    v.add        v12, v4, v5
    v.st.w       [s28, #0], v12
    s.addi       s28, s7, #1024
    v.ld.w       v4, [s27, #0]
    s.addi       s27, s21, #9
    v.splat      v5, s27
    s.addi       s27, s12, #576
    v.add        v12, v4, v11
    v.st.w       [s20, #0], v12
    s.addi       s20, s7, #1024
    v.ld.w       v4, [s18, #0]
    s.addi       s18, s21, #10
    v.splat      v11, s18
    s.addi       s18, s12, #640
    v.add        v12, v4, v10
    v.st.w       [s15, #0], v12
    s.addi       s15, s7, #1024
    v.ld.w       v4, [s24, #0]
    s.addi       s24, s21, #11
    v.splat      v10, s24
    s.addi       s24, s12, #704
    v.add        v12, v4, v9
    v.st.w       [s22, #0], v12
    s.addi       s22, s7, #1024
    v.ld.w       v4, [s25, #0]
    s.addi       s25, s21, #12
    v.splat      v9, s25
    s.addi       s25, s12, #768
    v.add        v12, v4, v6
    v.st.w       [s26, #0], v12
    s.addi       s26, s7, #1024
    v.ld.w       v4, [s28, #0]
    s.addi       s28, s21, #13
    v.splat      v6, s28
    s.addi       s28, s12, #832
    v.add        v12, v4, v5
    v.st.w       [s27, #0], v12
    s.addi       s27, s7, #1024
    v.splat      v4, s19
    v.ld.w       v5, [s20, #0]
    s.addi       s20, s21, #14
    s.addi       s29, s21, #15
    v.splat      v12, s20
    s.addi       s20, s12, #896
    v.splat      v13, s29
    s.addi       s21, s7, #1024
    s.addi       s29, s12, #960
    v.add        v14, v5, v11
    v.st.w       [s18, #0], v14
    s.addi       s12, s7, #2112
    v.splat      v5, s19
    s.movz       s18, #0
    s.add        s19, s18, s11                   // the tile origin
    v.splat      v11, s19
    s.movz       s18, #0
    v.add        v14, v15, v11
    v.ld.w       v11, [s15, #0]
    s.add        s15, s18, s23                   // the tile origin
    v.cmp.lt     p1, v14, v5
    v.splat      v5, s15
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s18, #0
    v.cmp.lt     p2, v5, v4
    p.and        p3, p2, p1
    v.add        v5, v11, v10
    s.movz       s19, #1
    v.st.w       [s24, #0], v5
    s.addi       s23, s7, #2176
    v.ld.w       v5, [s22, #0]
    s.addi       s22, s15, #1
    v.splat      v10, s22
    v.cmp.lt     p2, v10, v4
    p.and        p4, p2, p1
    v.add        v10, v5, v9
    v.st.w       [s25, #0], v10
    s.addi       s22, s7, #2240
    s.movz       s24, #2
    v.ld.w       v5, [s26, #0]
    s.addi       s25, s15, #2
    v.splat      v9, s25
    v.add        v10, v5, v6
    v.cmp.lt     p2, v9, v4
    v.st.w       [s28, #0], v10
    p.and        p5, p2, p1
    v.ld.w       v5, [s27, #0]
    s.addi       s25, s7, #2304
    s.movz       s26, #3
    v.add        v6, v5, v12
    s.addi       s27, s15, #3
    v.st.w       [s20, #0], v6
    v.splat      v5, s27
    v.ld.w       v6, [s21, #0]
    s.movz       s20, #4
    v.add        v9, v6, v13
    s.addi       s21, s7, #2368
    v.st.w       [s29, #0], v9
    fence.acq_rel.device
    s.addi       s27, s15, #4
    v.splat      v6, s27
    v.ld.w       v9, [s12, #0]
    s.addi       s12, s7, #2432
    s.addi       s27, s15, #5
    s.movz       s28, #5
    v.splat      v10, s27
    s.movz       s27, #6
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s4, v9]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v4
    p.and        p3, p2, p1
    a.vwrite     a2, s18, v11
    v.ld.w       v5, [s23, #0]
    s.addi       s18, s7, #2496
    s.addi       s23, s15, #6
    v.splat      v9, s23
    s.movz       s23, #7
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v11, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v4
    p.and        p4, p2, p1
    a.vwrite     a2, s19, v11
    v.ld.w       v5, [s22, #0]
    s.addi       s19, s7, #2560
    s.addi       s22, s15, #7
    v.splat      v6, s22
    s.movz       s22, #8
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v11, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v10, v4
    p.and        p5, p2, p1
    a.vwrite     a2, s24, v11
    v.ld.w       v5, [s25, #0]
    s.addi       s24, s7, #2624
    s.addi       s25, s15, #8
    v.splat      v10, s25
    s.movz       s25, #9
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v9, v4
    p.and        p3, p2, p1
    a.vwrite     a2, s26, v11
    v.ld.w       v5, [s21, #0]
    s.addi       s21, s7, #2688
    s.addi       s26, s15, #9
    v.splat      v9, s26
    s.movz       s26, #10
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v11, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v4
    p.and        p4, p2, p1
    a.vwrite     a2, s20, v11
    v.ld.w       v5, [s12, #0]
    s.addi       s12, s7, #2752
    s.addi       s20, s15, #10
    v.splat      v6, s20
    s.movz       s20, #11
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v11, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v10, v4
    p.and        p5, p2, p1
    a.vwrite     a2, s28, v11
    v.ld.w       v5, [s18, #0]
    s.addi       s18, s7, #2816
    s.addi       s28, s15, #11
    v.splat      v10, s28
    s.movz       s28, #12
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v9, v4
    p.and        p3, p2, p1
    a.vwrite     a2, s27, v11
    v.ld.w       v5, [s19, #0]
    s.addi       s19, s7, #2880
    s.addi       s27, s15, #12
    v.splat      v9, s27
    s.movz       s27, #13
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v11, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v4
    p.and        p4, p2, p1
    a.vwrite     a2, s23, v11
    v.ld.w       v5, [s24, #0]
    s.addi       s23, s7, #2944
    s.addi       s24, s15, #13
    v.splat      v6, s24
    s.movz       s24, #14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v11, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v10, v4
    p.and        p5, p2, p1
    a.vwrite     a2, s22, v11
    v.ld.w       v5, [s21, #0]
    s.addi       s21, s7, #3008
    s.addi       s22, s15, #14
    v.splat      v10, s22
    s.movz       s22, #15
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v9, v4
    p.and        p3, p2, p1
    a.vwrite     a2, s25, v11
    v.ld.w       v5, [s12, #0]
    s.addi       s12, s7, #3072
    s.addi       s25, s15, #15
    v.movi       v9, #0
    v.splat      v11, s25
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v12, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v4
    p.and        p4, p2, p1
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s15, #0
    a.vwrite     a2, s26, v12
    v.ld.w       v5, [s18, #0]
    s.movz       s18, #0
    s.movz       s25, #0
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v6, [s4, v5]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v10, v4
    p.and        p5, p2, p1
    a.vwrite     a2, s20, v6
    v.ld.w       v5, [s19, #0]
    s.movz       s19, #1
    s.movz       s20, #2
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v6, [s4, v5]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v11, v4
    p.and        p3, p2, p1
    a.vwrite     a2, s28, v6
    v.ld.w       v4, [s23, #0]
    s.movz       s23, #3
    s.movz       s26, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v5, [s4, v4]               // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s27, v5
    v.ld.w       v4, [s21, #0]
    s.movz       s21, #5
    s.movz       s27, #6
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v5, [s4, v4]               // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s24, v5
    v.ld.w       v4, [s12, #0]
    s.movz       s12, #7
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v5, [s4, v4]               // index is in elements (ISA sec 9.1)
    s.movz       s24, #8
    a.vwrite     a2, s22, v5
    a.vread      v4, a1, s18
    a.vread      v5, a2, s25
    v.extract    s18, v4, #0
    v.splat      v6, s18
    v.extract    s18, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s18
    a.vread      v6, a2, s19
    v.extract    s18, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s18
    a.vread      v6, a2, s20
    v.extract    s18, v4, #3
    vf.fma       v10, v5, v6, v11
    v.splat      v5, s18
    a.vread      v6, a2, s23
    v.extract    s18, v4, #4
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s18
    a.vread      v6, a2, s26
    v.extract    s18, v4, #5
    vf.fma       v10, v5, v6, v11
    v.splat      v5, s18
    a.vread      v6, a2, s21
    v.extract    s18, v4, #6
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s18
    a.vread      v6, a2, s27
    v.extract    s18, v4, #7
    vf.fma       v10, v5, v6, v11
    v.splat      v5, s18
    a.vread      v6, a2, s12
    v.extract    s12, v4, #8
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s12
    a.vread      v6, a2, s24
    s.movz       s12, #9
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #9
    v.splat      v5, s18
    a.vread      v6, a2, s12
    s.movz       s12, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #10
    v.splat      v5, s18
    a.vread      v6, a2, s12
    s.movz       s12, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #11
    v.splat      v5, s18
    a.vread      v6, a2, s12
    s.movz       s12, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #12
    v.splat      v5, s18
    a.vread      v6, a2, s12
    s.movz       s12, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #13
    v.splat      v5, s18
    a.vread      v6, a2, s12
    s.movz       s12, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #14
    v.splat      v5, s18
    a.vread      v6, a2, s12
    s.movz       s12, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #15
    v.splat      v4, s18
    a.vread      v5, a2, s12
    s.movz       s12, #1
    vf.fma       v6, v4, v5, v10
    s.movz       s18, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s15, v6
    a.vread      v4, a1, s12
    a.vread      v5, a2, s18
    v.extract    s12, v4, #0
    v.splat      v6, s12
    v.extract    s12, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s12
    a.vread      v6, a2, s19
    v.extract    s12, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s12
    a.vread      v6, a2, s20
    s.movz       s12, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #3
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #4
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #5
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #6
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #7
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #8
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #1
    vf.fma       v10, v5, v6, v11
    s.movz       s15, #9
    v.extract    s18, v4, #9
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #10
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #11
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #12
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #13
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #14
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #15
    v.splat      v4, s18
    a.vread      v5, a2, s15
    s.movz       s15, #2
    vf.fma       v6, v4, v5, v10
    s.movz       s18, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s12, v6
    a.vread      v4, a1, s15
    a.vread      v5, a2, s18
    v.extract    s12, v4, #0
    v.splat      v6, s12
    v.extract    s12, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s12
    a.vread      v6, a2, s19
    v.extract    s12, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s12
    a.vread      v6, a2, s20
    s.movz       s12, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #3
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #4
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #5
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #6
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #7
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #8
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #2
    vf.fma       v10, v5, v6, v11
    s.movz       s15, #9
    v.extract    s18, v4, #9
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #10
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #11
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #12
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #13
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #14
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #15
    v.splat      v4, s18
    a.vread      v5, a2, s15
    s.movz       s15, #3
    vf.fma       v6, v4, v5, v10
    s.movz       s18, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s12, v6
    a.vread      v4, a1, s15
    a.vread      v5, a2, s18
    v.extract    s12, v4, #0
    v.splat      v6, s12
    v.extract    s12, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s12
    a.vread      v6, a2, s19
    v.extract    s12, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s12
    a.vread      v6, a2, s20
    s.movz       s12, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #3
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #4
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #5
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #6
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #7
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #8
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #3
    vf.fma       v10, v5, v6, v11
    s.movz       s15, #9
    v.extract    s18, v4, #9
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #10
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #11
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #12
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #13
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #14
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #15
    v.splat      v4, s18
    a.vread      v5, a2, s15
    s.movz       s15, #4
    vf.fma       v6, v4, v5, v10
    s.movz       s18, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s12, v6
    a.vread      v4, a1, s15
    a.vread      v5, a2, s18
    v.extract    s12, v4, #0
    v.splat      v6, s12
    v.extract    s12, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s12
    a.vread      v6, a2, s19
    v.extract    s12, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s12
    a.vread      v6, a2, s20
    s.movz       s12, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #3
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #4
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #5
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #6
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #7
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #8
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #4
    vf.fma       v10, v5, v6, v11
    s.movz       s15, #9
    v.extract    s18, v4, #9
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #10
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #11
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #12
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #13
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #14
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #15
    v.splat      v4, s18
    a.vread      v5, a2, s15
    s.movz       s15, #5
    vf.fma       v6, v4, v5, v10
    s.movz       s18, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s12, v6
    a.vread      v4, a1, s15
    a.vread      v5, a2, s18
    v.extract    s12, v4, #0
    v.splat      v6, s12
    v.extract    s12, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s12
    a.vread      v6, a2, s19
    v.extract    s12, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s12
    a.vread      v6, a2, s20
    s.movz       s12, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #3
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #4
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #5
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #6
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #7
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #8
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #5
    vf.fma       v10, v5, v6, v11
    s.movz       s15, #9
    v.extract    s18, v4, #9
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #10
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #11
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #12
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #13
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #14
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #15
    v.splat      v4, s18
    a.vread      v5, a2, s15
    s.movz       s15, #6
    vf.fma       v6, v4, v5, v10
    s.movz       s18, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s12, v6
    a.vread      v4, a1, s15
    a.vread      v5, a2, s18
    v.extract    s12, v4, #0
    v.splat      v6, s12
    v.extract    s12, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s12
    a.vread      v6, a2, s19
    v.extract    s12, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s12
    a.vread      v6, a2, s20
    s.movz       s12, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #3
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #4
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #5
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #6
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #7
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #8
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #6
    vf.fma       v10, v5, v6, v11
    s.movz       s15, #9
    v.extract    s18, v4, #9
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #10
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #11
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #12
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #13
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #14
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #15
    v.splat      v4, s18
    a.vread      v5, a2, s15
    s.movz       s15, #7
    vf.fma       v6, v4, v5, v10
    s.movz       s18, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s12, v6
    a.vread      v4, a1, s15
    a.vread      v5, a2, s18
    v.extract    s12, v4, #0
    v.splat      v6, s12
    v.extract    s12, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s12
    a.vread      v6, a2, s19
    v.extract    s12, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s12
    a.vread      v6, a2, s20
    s.movz       s12, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #3
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #4
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #5
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #6
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #7
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #8
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #7
    vf.fma       v10, v5, v6, v11
    s.movz       s15, #9
    v.extract    s18, v4, #9
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #10
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #11
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #12
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #13
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #14
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #15
    v.splat      v4, s18
    a.vread      v5, a2, s15
    s.movz       s15, #8
    vf.fma       v6, v4, v5, v10
    s.movz       s18, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s12, v6
    a.vread      v4, a1, s15
    a.vread      v5, a2, s18
    v.extract    s12, v4, #0
    v.splat      v6, s12
    v.extract    s12, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s12
    a.vread      v6, a2, s19
    v.extract    s12, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s12
    a.vread      v6, a2, s20
    s.movz       s12, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #3
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #4
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #5
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #6
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #7
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #8
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #8
    vf.fma       v10, v5, v6, v11
    s.movz       s15, #9
    v.extract    s18, v4, #9
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #10
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #11
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #12
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #13
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #14
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #15
    v.splat      v4, s18
    a.vread      v5, a2, s15
    s.movz       s15, #9
    vf.fma       v6, v4, v5, v10
    s.movz       s18, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s12, v6
    a.vread      v4, a1, s15
    a.vread      v5, a2, s18
    v.extract    s12, v4, #0
    v.splat      v6, s12
    v.extract    s12, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s12
    a.vread      v6, a2, s19
    v.extract    s12, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s12
    a.vread      v6, a2, s20
    s.movz       s12, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #3
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #4
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #5
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #6
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #7
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #8
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #9
    vf.fma       v10, v5, v6, v11
    s.movz       s15, #9
    v.extract    s18, v4, #9
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #10
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #11
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #12
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #13
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #14
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #15
    v.splat      v4, s18
    a.vread      v5, a2, s15
    s.movz       s15, #10
    vf.fma       v6, v4, v5, v10
    s.movz       s18, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s12, v6
    a.vread      v4, a1, s15
    a.vread      v5, a2, s18
    v.extract    s12, v4, #0
    v.splat      v6, s12
    v.extract    s12, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s12
    a.vread      v6, a2, s19
    v.extract    s12, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s12
    a.vread      v6, a2, s20
    s.movz       s12, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #3
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #4
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #5
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #6
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #7
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #8
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #10
    vf.fma       v10, v5, v6, v11
    s.movz       s15, #9
    v.extract    s18, v4, #9
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #10
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #11
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #12
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #13
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #14
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #15
    v.splat      v4, s18
    a.vread      v5, a2, s15
    s.movz       s15, #11
    vf.fma       v6, v4, v5, v10
    s.movz       s18, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s12, v6
    a.vread      v4, a1, s15
    a.vread      v5, a2, s18
    v.extract    s12, v4, #0
    v.splat      v6, s12
    v.extract    s12, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s12
    a.vread      v6, a2, s19
    v.extract    s12, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s12
    a.vread      v6, a2, s20
    s.movz       s12, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #3
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #4
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #5
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #6
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #7
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #8
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #11
    vf.fma       v10, v5, v6, v11
    s.movz       s15, #9
    v.extract    s18, v4, #9
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #10
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #11
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #12
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #13
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #14
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #15
    v.splat      v4, s18
    a.vread      v5, a2, s15
    s.movz       s15, #12
    vf.fma       v6, v4, v5, v10
    s.movz       s18, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s12, v6
    a.vread      v4, a1, s15
    a.vread      v5, a2, s18
    v.extract    s12, v4, #0
    v.splat      v6, s12
    v.extract    s12, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s12
    a.vread      v6, a2, s19
    v.extract    s12, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s12
    a.vread      v6, a2, s20
    s.movz       s12, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #3
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #4
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #5
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #6
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #7
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #8
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #12
    vf.fma       v10, v5, v6, v11
    s.movz       s15, #9
    v.extract    s18, v4, #9
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #10
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #11
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #12
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #13
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #14
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #15
    v.splat      v4, s18
    a.vread      v5, a2, s15
    s.movz       s15, #13
    vf.fma       v6, v4, v5, v10
    s.movz       s18, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s12, v6
    a.vread      v4, a1, s15
    a.vread      v5, a2, s18
    v.extract    s12, v4, #0
    v.splat      v6, s12
    v.extract    s12, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s12
    a.vread      v6, a2, s19
    v.extract    s12, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s12
    a.vread      v6, a2, s20
    s.movz       s12, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #3
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #4
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #5
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #6
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #7
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #8
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #13
    vf.fma       v10, v5, v6, v11
    s.movz       s15, #9
    v.extract    s18, v4, #9
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #10
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #11
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #12
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #13
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #14
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #15
    v.splat      v4, s18
    a.vread      v5, a2, s15
    s.movz       s15, #14
    vf.fma       v6, v4, v5, v10
    s.movz       s18, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s12, v6
    a.vread      v4, a1, s15
    a.vread      v5, a2, s18
    v.extract    s12, v4, #0
    v.splat      v6, s12
    v.extract    s12, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s12
    a.vread      v6, a2, s19
    v.extract    s12, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s12
    a.vread      v6, a2, s20
    s.movz       s12, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #3
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #4
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #5
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #6
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s15, v4, #7
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s15, v4, #8
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #14
    vf.fma       v10, v5, v6, v11
    s.movz       s15, #9
    v.extract    s18, v4, #9
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #10
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #11
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #12
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #13
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s18, v4, #14
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s18, v4, #15
    v.splat      v4, s18
    a.vread      v5, a2, s15
    s.movz       s15, #15
    vf.fma       v6, v4, v5, v10
    s.movz       s18, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s12, v6
    a.vread      v4, a1, s15
    a.vread      v5, a2, s18
    v.extract    s12, v4, #0
    v.splat      v6, s12
    v.extract    s12, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s12
    a.vread      v6, a2, s19
    v.extract    s12, v4, #2
    vf.fma       v9, v5, v6, v10
    v.splat      v5, s12
    a.vread      v6, a2, s20
    s.movz       s12, #3
    vf.fma       v10, v5, v6, v9
    v.extract    s15, v4, #3
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #4
    vf.fma       v9, v5, v6, v10
    v.extract    s15, v4, #4
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #5
    vf.fma       v10, v5, v6, v9
    v.extract    s15, v4, #5
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #6
    vf.fma       v9, v5, v6, v10
    v.extract    s15, v4, #6
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #7
    vf.fma       v10, v5, v6, v9
    v.extract    s15, v4, #7
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #8
    vf.fma       v9, v5, v6, v10
    v.extract    s15, v4, #8
    v.splat      v5, s15
    a.vread      v6, a2, s12
    s.movz       s12, #15
    vf.fma       v10, v5, v6, v9
    s.movz       s15, #9
    v.extract    s18, v4, #9
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #10
    vf.fma       v9, v5, v6, v10
    v.extract    s18, v4, #10
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #11
    vf.fma       v10, v5, v6, v9
    v.extract    s18, v4, #11
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #12
    vf.fma       v9, v5, v6, v10
    v.extract    s18, v4, #12
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #13
    vf.fma       v10, v5, v6, v9
    v.extract    s18, v4, #13
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #14
    vf.fma       v9, v5, v6, v10
    v.extract    s18, v4, #14
    v.splat      v5, s18
    a.vread      v6, a2, s15
    s.movz       s15, #15
    vf.fma       v10, v5, v6, v9
    v.extract    s18, v4, #15
    v.splat      v4, s18
    a.vread      v5, a2, s15
    s.movz       s15, #0
    vf.fma       v6, v4, v5, v10
    s.movz       s18, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s19, #0
    s.movz       s20, #1
    a.vwrite     a3, s12, v6
    a.vread      v4, a0, s15
    a.vread      v5, a3, s18
    s.movz       s12, #1
    vf.add       v6, v4, v5
    s.movz       s15, #1
    s.movz       s18, #2
    s.movz       s21, #2
    a.vwrite     a4, s19, v6
    a.vread      v4, a0, s20
    a.vread      v5, a3, s12
    s.movz       s12, #2
    vf.add       v6, v4, v5
    s.movz       s19, #3
    s.movz       s20, #3
    s.movz       s22, #3
    a.vwrite     a4, s15, v6
    a.vread      v4, a0, s18
    a.vread      v5, a3, s21
    s.movz       s15, #4
    vf.add       v6, v4, v5
    s.movz       s18, #4
    s.movz       s21, #4
    s.movz       s23, #5
    a.vwrite     a4, s12, v6
    a.vread      v4, a0, s19
    a.vread      v5, a3, s20
    s.movz       s12, #5
    vf.add       v6, v4, v5
    s.movz       s19, #5
    s.movz       s20, #6
    s.movz       s24, #6
    a.vwrite     a4, s22, v6
    a.vread      v4, a0, s15
    a.vread      v5, a3, s18
    s.movz       s15, #6
    vf.add       v6, v4, v5
    s.movz       s18, #7
    s.movz       s22, #7
    s.movz       s25, #7
    a.vwrite     a4, s21, v6
    a.vread      v4, a0, s23
    a.vread      v5, a3, s12
    s.movz       s12, #8
    vf.add       v6, v4, v5
    s.movz       s21, #8
    s.movz       s23, #8
    s.movz       s26, #9
    a.vwrite     a4, s19, v6
    a.vread      v4, a0, s20
    a.vread      v5, a3, s24
    s.movz       s19, #9
    vf.add       v6, v4, v5
    s.movz       s20, #9
    s.movz       s24, #10
    s.movz       s27, #10
    a.vwrite     a4, s15, v6
    a.vread      v4, a0, s18
    a.vread      v5, a3, s22
    s.movz       s15, #10
    vf.add       v6, v4, v5
    s.movz       s18, #11
    s.movz       s22, #11
    s.movz       s28, #11
    a.vwrite     a4, s25, v6
    a.vread      v4, a0, s12
    a.vread      v5, a3, s21
    s.movz       s12, #12
    vf.add       v6, v4, v5
    s.movz       s21, #12
    s.movz       s25, #12
    s.movz       s29, #13
    a.vwrite     a4, s23, v6
    a.vread      v4, a0, s26
    a.vread      v5, a3, s19
    s.movz       s19, #13
    vf.add       v6, v4, v5
    s.movz       s23, #13
    s.movz       s26, #14
    a.vwrite     a4, s20, v6
    a.vread      v4, a0, s24
    a.vread      v5, a3, s27
    s.movz       s20, #14
    vf.add       v6, v4, v5
    s.movz       s24, #14
    s.movz       s27, #15
    a.vwrite     a4, s15, v6
    a.vread      v4, a0, s18
    a.vread      v5, a3, s22
    s.movz       s15, #15
    vf.add       v6, v4, v5
    s.movz       s18, #15
    s.movz       s22, #0
    a.vwrite     a4, s28, v6
    a.vread      v4, a0, s12
    a.vread      v5, a3, s21
    s.movz       s12, #0
    vf.add       v6, v4, v5
    s.movz       s21, #1
    s.movz       s28, #1
    a.vwrite     a4, s25, v6
    a.vread      v4, a0, s29
    a.vread      v5, a3, s19
    s.movz       s19, #2
    vf.add       v6, v4, v5
    s.movz       s25, #2
    s.movz       s29, #3
    a.vwrite     a4, s23, v6
    a.vread      v4, a0, s26
    a.vread      v5, a3, s20
    s.movz       s20, #3
    vf.add       v6, v4, v5
    s.movz       s23, #4
    s.movz       s26, #4
    a.vwrite     a4, s24, v6
    a.vread      v4, a0, s27
    a.vread      v5, a3, s15
    s.movz       s15, #5
    vf.add       v6, v4, v5
    s.movz       s24, #5
    s.movz       s27, #6
    a.vwrite     a4, s18, v6
    a.vread      v4, a4, s22
    s.movz       s18, #6
    a.vwrite     a0, s12, v4
    a.vread      v4, a4, s21
    s.movz       s12, #7
    a.vwrite     a0, s28, v4
    a.vread      v4, a4, s19
    s.movz       s19, #7
    a.vwrite     a0, s25, v4
    a.vread      v4, a4, s29
    s.movz       s21, #8
    a.vwrite     a0, s20, v4
    a.vread      v4, a4, s23
    s.movz       s20, #8
    a.vwrite     a0, s26, v4
    a.vread      v4, a4, s15
    s.movz       s15, #9
    a.vwrite     a0, s24, v4
    a.vread      v4, a4, s27
    s.movz       s22, #9
    a.vwrite     a0, s18, v4
    a.vread      v4, a4, s12
    s.movz       s12, #10
    a.vwrite     a0, s19, v4
    a.vread      v4, a4, s21
    s.movz       s18, #10
    a.vwrite     a0, s20, v4
    a.vread      v4, a4, s15
    s.movz       s15, #11
    a.vwrite     a0, s22, v4
    a.vread      v4, a4, s12
    s.movz       s12, #11
    a.vwrite     a0, s18, v4
    a.vread      v4, a4, s15
    s.movz       s15, #12
    a.vwrite     a0, s12, v4
    s.movz       s12, #12
    a.vread      v4, a4, s15
    s.movz       s15, #13
    a.vwrite     a0, s12, v4
    s.movz       s12, #13
    a.vread      v4, a4, s15
    s.movz       s15, #14
    a.vwrite     a0, s12, v4
    s.movz       s12, #14
    a.vread      v4, a4, s15
    s.movz       s15, #15
    a.vwrite     a0, s12, v4
    s.movz       s12, #15
    a.vread      v4, a4, s15
    s.add        s15, s17, s16
    s.movz       s18, #1
    a.vwrite     a0, s12, v4
    s.mov        s17, s15
    br.nz        s18, for_5
endfor_6:
    s.muli       s1, s11, #3136                  // a runtime tile origin, x3136
    s.movz       s2, #56
    s.movz       s4, #0
    s.movz       s12, #3136
    v.extract    s13, v8, #0
    v.splat      v0, s13
    v.splat      v4, s2
    s.add        s2, s4, s1                      // the tile origin
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s12
    v.extract    s1, v7, #0
    v.splat      v9, s1
    v.mul        v10, v0, v4
    v.mul        v0, v5, v6
    v.splat      v5, s2
    v.add        v6, v9, v10
    s.movz       s1, #0
    s.muli       s2, s11, #4                     // a runtime tile origin, x4
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s4, s11, #4                     // a runtime tile origin, x4
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s12, s11, #4                    // a runtime tile origin, x4
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s13, s11, #4                    // a runtime tile origin, x4
    s.add        s15, s1, s11                    // the tile origin
    v.movi       v9, #8
    v.add        v10, v0, v5
    v.movi       v0, #1
    v.movi       v5, #0
    v.movi       v11, #1
    v.movi       v12, #0
    v.movi       v13, #1
    v.movi       v14, #0
    v.movi       v15, #64
    v.iota       v16                             // arange(0, VLEN)
    v.splat      v17, s15
    v.cmp.lt     p1, v2, v9
    v.extract    s1, v2, #0
    v.splat      v9, s1
    v.add        v18, v6, v10
    v.cmp.lt     p2, v8, v1
    v.cmp.lt     p3, v7, v1
    @p1 v.sel        v1, v0, v5
    v.splat      v0, s14
    s.movz       s1, #3136
    v.mul        v5, v9, v0
    @p2 v.sel        v6, v11, v12
    v.add        v9, v18, v5
    v.splat      v5, s1
    v.movi       v11, #0
    @p3 v.sel        v12, v13, v14
    v.sub        v13, v11, v9
    v.cmp.lt     p1, v9, v11
    v.cmp.lt     p2, v5, v11
    v.cmp.lt     p3, v3, v15
    v.sub        v3, v11, v5
    s.add        s1, s5, s2                      // the tile origin
    s.add        s2, s6, s4                      // the tile origin
    s.add        s4, s8, s12                     // the tile origin
    s.add        s5, s9, s13                     // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    .li       s6, #925353388
    v.splat      v14, s6                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v15, #0
    s.addi       s6, s7, #3136
    v.splat      v18, s3
    v.add        v19, v16, v17
    v.movi       v16, #1
    @p1 v.sel        v17, v13, v9
    @p2 v.sel        v9, v3, v5
    v.movi       v3, #0
    v.movi       v13, #0
    s.movz       s3, #31
idiv_7:
    v.splat      v20, s3
    v.shl        v21, v13, v16
    v.lshr       v22, v17, v20
    v.cmp.lt     p2, v13, v11
    v.and        v23, v22, v16
    v.shl        v22, v16, v20
    v.or         v20, v21, v23
    s.subi       s8, s3, #1
    v.cmp.geu    p4, v20, v9
    p.or         p5, p2, p4
    v.sub        v21, v20, v9
    @p5 v.sel        v23, v22, v11
    @p5 v.sel        v22, v21, v20
    v.or         v20, v3, v23
    v.mov        v13, v22
    v.mov        v3, v20
    s.mov        s3, s8
    s.movz       s8, #0
    s.cmp.ge     s9, s3, s8
    br.nz        s9, idiv_7
    v.extract    s3, v8, #1
    v.sub        v3, v11, v13
    s.movz       s8, #64
    v.splat      v9, s3
    v.extract    s3, v7, #1
    @p1 v.sel        v11, v3, v13
    v.splat      v3, s8
    v.splat      v13, s3
    v.mul        v16, v9, v4
    v.extract    s3, v2, #0
    v.extract    s8, v2, #1
    v.mul        v9, v11, v3
    v.splat      v11, s3
    v.add        v17, v13, v16
    v.splat      v13, s8
    v.add        v16, v19, v9
    v.mul        v9, v11, v0
    v.add        v11, v17, v10
    v.mul        v17, v13, v0
    v.add        v13, v16, v9
    v.add        v9, v11, v17
    v.movi       v11, #0
    v.add        v16, v18, v13
    v.sub        v13, v11, v9
    v.sub        v17, v11, v5
    v.cmp.lt     p1, v9, v11
    v.cmp.lt     p2, v5, v11
    v.st.w       [s6, #0], v16
    s.addi       s3, s6, #64
    v.movi       v16, #1
    @p1 v.sel        v20, v13, v9
    @p2 v.sel        v9, v17, v5
    v.movi       v13, #0
    v.movi       v17, #0
    s.movz       s8, #31
idiv_8:
    v.splat      v21, s8
    v.shl        v22, v17, v16
    v.lshr       v23, v20, v21
    v.cmp.lt     p2, v17, v11
    v.and        v24, v23, v16
    v.shl        v23, v16, v21
    v.or         v21, v22, v24
    s.subi       s9, s8, #1
    v.cmp.geu    p4, v21, v9
    p.or         p5, p2, p4
    v.sub        v22, v21, v9
    @p5 v.sel        v24, v23, v11
    @p5 v.sel        v23, v22, v21
    v.or         v21, v13, v24
    v.mov        v17, v23
    v.mov        v13, v21
    s.mov        s8, s9
    s.movz       s9, #0
    s.cmp.ge     s11, s8, s9
    br.nz        s11, idiv_8
    v.extract    s8, v8, #2
    v.sub        v9, v11, v17
    v.splat      v11, s8
    v.extract    s8, v7, #2
    @p1 v.sel        v13, v9, v17
    v.splat      v9, s8
    v.mul        v16, v11, v4
    v.extract    s8, v2, #1
    v.extract    s9, v2, #2
    v.mul        v11, v13, v3
    v.splat      v13, s8
    v.add        v17, v9, v16
    v.splat      v9, s9
    v.add        v16, v19, v11
    v.mul        v11, v13, v0
    v.add        v13, v17, v10
    v.mul        v17, v9, v0
    v.add        v9, v16, v11
    v.add        v11, v13, v17
    v.movi       v13, #0
    v.add        v16, v18, v9
    v.sub        v9, v13, v11
    v.sub        v17, v13, v5
    v.cmp.lt     p1, v11, v13
    v.cmp.lt     p2, v5, v13
    v.st.w       [s3, #0], v16
    s.addi       s3, s6, #128
    v.movi       v16, #1
    @p1 v.sel        v20, v9, v11
    @p2 v.sel        v9, v17, v5
    v.movi       v11, #0
    v.movi       v17, #0
    s.movz       s8, #31
idiv_9:
    v.splat      v21, s8
    v.shl        v22, v17, v16
    v.lshr       v23, v20, v21
    v.cmp.lt     p2, v17, v13
    v.and        v24, v23, v16
    v.shl        v23, v16, v21
    v.or         v21, v22, v24
    s.subi       s9, s8, #1
    v.cmp.geu    p4, v21, v9
    p.or         p5, p2, p4
    v.sub        v22, v21, v9
    @p5 v.sel        v24, v23, v13
    @p5 v.sel        v23, v22, v21
    v.or         v21, v11, v24
    v.mov        v17, v23
    v.mov        v11, v21
    s.mov        s8, s9
    s.movz       s9, #0
    s.cmp.ge     s11, s8, s9
    br.nz        s11, idiv_9
    v.extract    s8, v8, #3
    v.sub        v9, v13, v17
    v.splat      v11, s8
    v.extract    s8, v7, #3
    @p1 v.sel        v13, v9, v17
    v.splat      v9, s8
    v.mul        v16, v11, v4
    v.extract    s8, v2, #2
    v.extract    s9, v2, #3
    v.mul        v11, v13, v3
    v.splat      v13, s8
    v.add        v17, v9, v16
    v.splat      v9, s9
    v.add        v16, v19, v11
    v.mul        v11, v13, v0
    v.add        v13, v17, v10
    v.mul        v17, v9, v0
    v.add        v9, v16, v11
    v.add        v11, v13, v17
    v.movi       v13, #0
    v.add        v16, v18, v9
    v.sub        v9, v13, v11
    v.sub        v17, v13, v5
    v.cmp.lt     p1, v11, v13
    v.cmp.lt     p2, v5, v13
    v.st.w       [s3, #0], v16
    s.addi       s3, s6, #192
    v.movi       v16, #1
    @p1 v.sel        v20, v9, v11
    @p2 v.sel        v9, v17, v5
    v.movi       v11, #0
    v.movi       v17, #0
    s.movz       s8, #31
idiv_10:
    v.splat      v21, s8
    v.shl        v22, v17, v16
    v.lshr       v23, v20, v21
    v.cmp.lt     p2, v17, v13
    v.and        v24, v23, v16
    v.shl        v23, v16, v21
    v.or         v21, v22, v24
    s.subi       s9, s8, #1
    v.cmp.geu    p4, v21, v9
    p.or         p5, p2, p4
    v.sub        v22, v21, v9
    @p5 v.sel        v24, v23, v13
    @p5 v.sel        v23, v22, v21
    v.or         v21, v11, v24
    v.mov        v17, v23
    v.mov        v11, v21
    s.mov        s8, s9
    s.movz       s9, #0
    s.cmp.ge     s11, s8, s9
    br.nz        s11, idiv_10
    v.extract    s8, v8, #4
    v.sub        v9, v13, v17
    v.splat      v11, s8
    v.extract    s8, v7, #4
    @p1 v.sel        v13, v9, v17
    v.splat      v9, s8
    v.mul        v16, v11, v4
    v.extract    s8, v2, #3
    v.extract    s9, v2, #4
    v.mul        v11, v13, v3
    v.splat      v13, s8
    v.add        v17, v9, v16
    v.splat      v9, s9
    v.add        v16, v19, v11
    v.mul        v11, v13, v0
    v.add        v13, v17, v10
    v.mul        v17, v9, v0
    v.add        v9, v16, v11
    v.add        v11, v13, v17
    v.movi       v13, #0
    v.add        v16, v18, v9
    v.sub        v9, v13, v11
    v.sub        v17, v13, v5
    v.cmp.lt     p1, v11, v13
    v.cmp.lt     p2, v5, v13
    v.st.w       [s3, #0], v16
    s.addi       s3, s6, #256
    v.movi       v16, #1
    @p1 v.sel        v20, v9, v11
    @p2 v.sel        v9, v17, v5
    v.movi       v11, #0
    v.movi       v17, #0
    s.movz       s8, #31
idiv_11:
    v.splat      v21, s8
    v.shl        v22, v17, v16
    v.lshr       v23, v20, v21
    v.cmp.lt     p2, v17, v13
    v.and        v24, v23, v16
    v.shl        v23, v16, v21
    v.or         v21, v22, v24
    s.subi       s9, s8, #1
    v.cmp.geu    p4, v21, v9
    p.or         p5, p2, p4
    v.sub        v22, v21, v9
    @p5 v.sel        v24, v23, v13
    @p5 v.sel        v23, v22, v21
    v.or         v21, v11, v24
    v.mov        v17, v23
    v.mov        v11, v21
    s.mov        s8, s9
    s.movz       s9, #0
    s.cmp.ge     s11, s8, s9
    br.nz        s11, idiv_11
    v.extract    s8, v8, #5
    v.sub        v9, v13, v17
    v.splat      v11, s8
    v.extract    s8, v7, #5
    @p1 v.sel        v13, v9, v17
    v.splat      v9, s8
    v.mul        v16, v11, v4
    v.extract    s8, v2, #4
    v.extract    s9, v2, #5
    v.mul        v11, v13, v3
    v.splat      v13, s8
    v.add        v17, v9, v16
    v.splat      v9, s9
    v.add        v16, v19, v11
    v.mul        v11, v13, v0
    v.add        v13, v17, v10
    v.mul        v17, v9, v0
    v.add        v9, v16, v11
    v.add        v11, v13, v17
    v.movi       v13, #0
    v.add        v16, v18, v9
    v.sub        v9, v13, v11
    v.sub        v17, v13, v5
    v.cmp.lt     p1, v11, v13
    v.cmp.lt     p2, v5, v13
    v.st.w       [s3, #0], v16
    s.addi       s3, s6, #320
    v.movi       v16, #1
    @p1 v.sel        v20, v9, v11
    @p2 v.sel        v9, v17, v5
    v.movi       v11, #0
    v.movi       v17, #0
    s.movz       s8, #31
idiv_12:
    v.splat      v21, s8
    v.shl        v22, v17, v16
    v.lshr       v23, v20, v21
    v.cmp.lt     p2, v17, v13
    v.and        v24, v23, v16
    v.shl        v23, v16, v21
    v.or         v21, v22, v24
    s.subi       s9, s8, #1
    v.cmp.geu    p4, v21, v9
    p.or         p5, p2, p4
    v.sub        v22, v21, v9
    @p5 v.sel        v24, v23, v13
    @p5 v.sel        v23, v22, v21
    v.or         v21, v11, v24
    v.mov        v17, v23
    v.mov        v11, v21
    s.mov        s8, s9
    s.movz       s9, #0
    s.cmp.ge     s11, s8, s9
    br.nz        s11, idiv_12
    v.extract    s8, v8, #6
    v.sub        v9, v13, v17
    v.splat      v11, s8
    v.extract    s8, v7, #6
    @p1 v.sel        v13, v9, v17
    v.splat      v9, s8
    v.mul        v16, v11, v4
    v.extract    s8, v2, #5
    v.extract    s9, v2, #6
    v.mul        v11, v13, v3
    v.splat      v13, s8
    v.add        v17, v9, v16
    v.splat      v9, s9
    v.add        v16, v19, v11
    v.mul        v11, v13, v0
    v.add        v13, v17, v10
    v.mul        v17, v9, v0
    v.add        v9, v16, v11
    v.add        v11, v13, v17
    v.movi       v13, #0
    v.add        v16, v18, v9
    v.sub        v9, v13, v11
    v.sub        v17, v13, v5
    v.cmp.lt     p1, v11, v13
    v.cmp.lt     p2, v5, v13
    v.st.w       [s3, #0], v16
    s.addi       s3, s6, #384
    v.movi       v16, #1
    @p1 v.sel        v20, v9, v11
    @p2 v.sel        v9, v17, v5
    v.movi       v11, #0
    v.movi       v17, #0
    s.movz       s8, #31
idiv_13:
    v.splat      v21, s8
    v.shl        v22, v17, v16
    v.lshr       v23, v20, v21
    v.cmp.lt     p2, v17, v13
    v.and        v24, v23, v16
    v.shl        v23, v16, v21
    v.or         v21, v22, v24
    s.subi       s9, s8, #1
    v.cmp.geu    p4, v21, v9
    p.or         p5, p2, p4
    v.sub        v22, v21, v9
    @p5 v.sel        v24, v23, v13
    @p5 v.sel        v23, v22, v21
    v.or         v21, v11, v24
    v.mov        v17, v23
    v.mov        v11, v21
    s.mov        s8, s9
    s.movz       s9, #0
    s.cmp.ge     s11, s8, s9
    br.nz        s11, idiv_13
    v.extract    s8, v8, #7
    v.sub        v9, v13, v17
    v.splat      v11, s8
    v.extract    s8, v7, #7
    @p1 v.sel        v13, v9, v17
    v.splat      v9, s8
    v.mul        v16, v11, v4
    v.extract    s8, v2, #6
    v.extract    s9, v2, #7
    v.mul        v11, v13, v3
    v.splat      v13, s8
    v.add        v17, v9, v16
    v.splat      v9, s9
    v.add        v16, v19, v11
    v.mul        v11, v13, v0
    v.add        v13, v17, v10
    v.mul        v17, v9, v0
    v.add        v9, v16, v11
    v.add        v11, v13, v17
    v.movi       v13, #0
    v.add        v16, v18, v9
    v.sub        v9, v13, v11
    v.sub        v17, v13, v5
    v.cmp.lt     p1, v11, v13
    v.cmp.lt     p2, v5, v13
    v.st.w       [s3, #0], v16
    s.addi       s3, s6, #448
    v.movi       v16, #1
    @p1 v.sel        v20, v9, v11
    @p2 v.sel        v9, v17, v5
    v.movi       v11, #0
    v.movi       v17, #0
    s.movz       s8, #31
idiv_14:
    v.splat      v21, s8
    v.shl        v22, v17, v16
    v.lshr       v23, v20, v21
    v.cmp.lt     p2, v17, v13
    v.and        v24, v23, v16
    v.shl        v23, v16, v21
    v.or         v21, v22, v24
    s.subi       s9, s8, #1
    v.cmp.geu    p4, v21, v9
    p.or         p5, p2, p4
    v.sub        v22, v21, v9
    @p5 v.sel        v24, v23, v13
    @p5 v.sel        v23, v22, v21
    v.or         v21, v11, v24
    v.mov        v17, v23
    v.mov        v11, v21
    s.mov        s8, s9
    s.movz       s9, #0
    s.cmp.ge     s11, s8, s9
    br.nz        s11, idiv_14
    v.extract    s8, v8, #8
    v.sub        v9, v13, v17
    v.splat      v11, s8
    v.extract    s8, v7, #8
    @p1 v.sel        v13, v9, v17
    v.splat      v9, s8
    v.mul        v16, v11, v4
    v.extract    s8, v2, #7
    v.extract    s9, v2, #8
    v.mul        v11, v13, v3
    v.splat      v13, s8
    v.add        v17, v9, v16
    v.splat      v9, s9
    v.add        v16, v19, v11
    v.mul        v11, v13, v0
    v.add        v13, v17, v10
    v.mul        v17, v9, v0
    v.add        v9, v16, v11
    v.add        v11, v13, v17
    v.movi       v13, #0
    v.add        v16, v18, v9
    v.sub        v9, v13, v11
    v.sub        v17, v13, v5
    v.cmp.lt     p1, v11, v13
    v.cmp.lt     p2, v5, v13
    v.st.w       [s3, #0], v16
    s.addi       s3, s6, #512
    v.movi       v16, #1
    @p1 v.sel        v20, v9, v11
    @p2 v.sel        v9, v17, v5
    v.movi       v11, #0
    v.movi       v17, #0
    s.movz       s8, #31
idiv_15:
    v.splat      v21, s8
    v.shl        v22, v17, v16
    v.lshr       v23, v20, v21
    v.cmp.lt     p2, v17, v13
    v.and        v24, v23, v16
    v.shl        v23, v16, v21
    v.or         v21, v22, v24
    s.subi       s9, s8, #1
    v.cmp.geu    p4, v21, v9
    p.or         p5, p2, p4
    v.sub        v22, v21, v9
    @p5 v.sel        v24, v23, v13
    @p5 v.sel        v23, v22, v21
    v.or         v21, v11, v24
    v.mov        v17, v23
    v.mov        v11, v21
    s.mov        s8, s9
    s.movz       s9, #0
    s.cmp.ge     s11, s8, s9
    br.nz        s11, idiv_15
    v.extract    s8, v8, #9
    v.sub        v9, v13, v17
    v.splat      v11, s8
    v.extract    s8, v7, #9
    @p1 v.sel        v13, v9, v17
    v.splat      v9, s8
    v.mul        v16, v11, v4
    v.extract    s8, v2, #8
    v.extract    s9, v2, #9
    v.mul        v11, v13, v3
    v.splat      v13, s8
    v.add        v17, v9, v16
    v.splat      v9, s9
    v.add        v16, v19, v11
    v.mul        v11, v13, v0
    v.add        v13, v17, v10
    v.mul        v17, v9, v0
    v.add        v9, v16, v11
    v.add        v11, v13, v17
    v.movi       v13, #0
    v.add        v16, v18, v9
    v.sub        v9, v13, v11
    v.sub        v17, v13, v5
    v.cmp.lt     p1, v11, v13
    v.cmp.lt     p2, v5, v13
    v.st.w       [s3, #0], v16
    s.addi       s3, s6, #576
    v.movi       v16, #1
    @p1 v.sel        v20, v9, v11
    @p2 v.sel        v9, v17, v5
    v.movi       v11, #0
    v.movi       v17, #0
    s.movz       s8, #31
idiv_16:
    v.splat      v21, s8
    v.shl        v22, v17, v16
    v.lshr       v23, v20, v21
    v.cmp.lt     p2, v17, v13
    v.and        v24, v23, v16
    v.shl        v23, v16, v21
    v.or         v21, v22, v24
    s.subi       s9, s8, #1
    v.cmp.geu    p4, v21, v9
    p.or         p5, p2, p4
    v.sub        v22, v21, v9
    @p5 v.sel        v24, v23, v13
    @p5 v.sel        v23, v22, v21
    v.or         v21, v11, v24
    v.mov        v17, v23
    v.mov        v11, v21
    s.mov        s8, s9
    s.movz       s9, #0
    s.cmp.ge     s11, s8, s9
    br.nz        s11, idiv_16
    v.extract    s8, v8, #10
    v.sub        v9, v13, v17
    v.splat      v11, s8
    v.extract    s8, v7, #10
    @p1 v.sel        v13, v9, v17
    v.splat      v9, s8
    v.mul        v16, v11, v4
    v.extract    s8, v2, #9
    v.extract    s9, v2, #10
    v.mul        v11, v13, v3
    v.splat      v13, s8
    v.add        v17, v9, v16
    v.splat      v9, s9
    v.add        v16, v19, v11
    v.mul        v11, v13, v0
    v.add        v13, v17, v10
    v.mul        v17, v9, v0
    v.add        v9, v16, v11
    v.add        v11, v13, v17
    v.movi       v13, #0
    v.add        v16, v18, v9
    v.sub        v9, v13, v11
    v.sub        v17, v13, v5
    v.cmp.lt     p1, v11, v13
    v.cmp.lt     p2, v5, v13
    v.st.w       [s3, #0], v16
    s.addi       s3, s6, #640
    v.movi       v16, #1
    @p1 v.sel        v20, v9, v11
    @p2 v.sel        v9, v17, v5
    v.movi       v11, #0
    v.movi       v17, #0
    s.movz       s8, #31
idiv_17:
    v.splat      v21, s8
    v.shl        v22, v17, v16
    v.lshr       v23, v20, v21
    v.cmp.lt     p2, v17, v13
    v.and        v24, v23, v16
    v.shl        v23, v16, v21
    v.or         v21, v22, v24
    s.subi       s9, s8, #1
    v.cmp.geu    p4, v21, v9
    p.or         p5, p2, p4
    v.sub        v22, v21, v9
    @p5 v.sel        v24, v23, v13
    @p5 v.sel        v23, v22, v21
    v.or         v21, v11, v24
    v.mov        v17, v23
    v.mov        v11, v21
    s.mov        s8, s9
    s.movz       s9, #0
    s.cmp.ge     s11, s8, s9
    br.nz        s11, idiv_17
    v.extract    s8, v8, #11
    v.sub        v9, v13, v17
    v.splat      v11, s8
    v.extract    s8, v7, #11
    @p1 v.sel        v13, v9, v17
    v.splat      v9, s8
    v.mul        v16, v11, v4
    v.extract    s8, v2, #10
    v.extract    s9, v2, #11
    v.mul        v11, v13, v3
    v.splat      v13, s8
    v.add        v17, v9, v16
    v.splat      v9, s9
    v.add        v16, v19, v11
    v.mul        v11, v13, v0
    v.add        v13, v17, v10
    v.mul        v17, v9, v0
    v.add        v9, v16, v11
    v.add        v11, v13, v17
    v.movi       v13, #0
    v.add        v16, v18, v9
    v.sub        v9, v13, v11
    v.sub        v17, v13, v5
    v.cmp.lt     p1, v11, v13
    v.cmp.lt     p2, v5, v13
    v.st.w       [s3, #0], v16
    s.addi       s3, s6, #704
    v.movi       v16, #1
    @p1 v.sel        v20, v9, v11
    @p2 v.sel        v9, v17, v5
    v.movi       v11, #0
    v.movi       v17, #0
    s.movz       s8, #31
idiv_18:
    v.splat      v21, s8
    v.shl        v22, v17, v16
    v.lshr       v23, v20, v21
    v.cmp.lt     p2, v17, v13
    v.and        v24, v23, v16
    v.shl        v23, v16, v21
    v.or         v21, v22, v24
    s.subi       s9, s8, #1
    v.cmp.geu    p4, v21, v9
    p.or         p5, p2, p4
    v.sub        v22, v21, v9
    @p5 v.sel        v24, v23, v13
    @p5 v.sel        v23, v22, v21
    v.or         v21, v11, v24
    v.mov        v17, v23
    v.mov        v11, v21
    s.mov        s8, s9
    s.movz       s9, #0
    s.cmp.ge     s11, s8, s9
    br.nz        s11, idiv_18
    v.extract    s8, v8, #12
    v.sub        v9, v13, v17
    v.splat      v11, s8
    v.extract    s8, v7, #12
    @p1 v.sel        v13, v9, v17
    v.splat      v9, s8
    v.mul        v16, v11, v4
    v.extract    s8, v2, #11
    v.extract    s9, v2, #12
    v.mul        v11, v13, v3
    v.splat      v13, s8
    v.add        v17, v9, v16
    v.splat      v9, s9
    v.add        v16, v19, v11
    v.mul        v11, v13, v0
    v.add        v13, v17, v10
    v.mul        v17, v9, v0
    v.add        v9, v16, v11
    v.add        v11, v13, v17
    v.movi       v13, #0
    v.add        v16, v18, v9
    v.sub        v9, v13, v11
    v.sub        v17, v13, v5
    v.cmp.lt     p1, v11, v13
    v.cmp.lt     p2, v5, v13
    v.st.w       [s3, #0], v16
    s.addi       s3, s6, #768
    v.movi       v16, #1
    @p1 v.sel        v20, v9, v11
    @p2 v.sel        v9, v17, v5
    v.movi       v11, #0
    v.movi       v17, #0
    s.movz       s8, #31
idiv_19:
    v.splat      v21, s8
    v.shl        v22, v17, v16
    v.lshr       v23, v20, v21
    v.cmp.lt     p2, v17, v13
    v.and        v24, v23, v16
    v.shl        v23, v16, v21
    v.or         v21, v22, v24
    s.subi       s9, s8, #1
    v.cmp.geu    p4, v21, v9
    p.or         p5, p2, p4
    v.sub        v22, v21, v9
    @p5 v.sel        v24, v23, v13
    @p5 v.sel        v23, v22, v21
    v.or         v21, v11, v24
    v.mov        v17, v23
    v.mov        v11, v21
    s.mov        s8, s9
    s.movz       s9, #0
    s.cmp.ge     s11, s8, s9
    br.nz        s11, idiv_19
    v.extract    s8, v8, #13
    v.sub        v9, v13, v17
    v.splat      v11, s8
    v.extract    s8, v7, #13
    @p1 v.sel        v13, v9, v17
    v.splat      v9, s8
    v.mul        v16, v11, v4
    v.extract    s8, v2, #12
    v.extract    s9, v2, #13
    v.mul        v11, v13, v3
    v.splat      v13, s8
    v.add        v17, v9, v16
    v.splat      v9, s9
    v.add        v16, v19, v11
    v.mul        v11, v13, v0
    v.add        v13, v17, v10
    v.mul        v17, v9, v0
    v.add        v9, v16, v11
    v.add        v11, v13, v17
    v.movi       v13, #0
    v.add        v16, v18, v9
    v.sub        v9, v13, v11
    v.sub        v17, v13, v5
    v.cmp.lt     p1, v11, v13
    v.cmp.lt     p2, v5, v13
    v.st.w       [s3, #0], v16
    s.addi       s3, s6, #832
    v.movi       v16, #1
    @p1 v.sel        v20, v9, v11
    @p2 v.sel        v9, v17, v5
    v.movi       v11, #0
    v.movi       v17, #0
    s.movz       s8, #31
idiv_20:
    v.splat      v21, s8
    v.shl        v22, v17, v16
    v.lshr       v23, v20, v21
    v.cmp.lt     p2, v17, v13
    v.and        v24, v23, v16
    v.shl        v23, v16, v21
    v.or         v21, v22, v24
    s.subi       s9, s8, #1
    v.cmp.geu    p4, v21, v9
    p.or         p5, p2, p4
    v.sub        v22, v21, v9
    @p5 v.sel        v24, v23, v13
    @p5 v.sel        v23, v22, v21
    v.or         v21, v11, v24
    v.mov        v17, v23
    v.mov        v11, v21
    s.mov        s8, s9
    s.movz       s9, #0
    s.cmp.ge     s11, s8, s9
    br.nz        s11, idiv_20
    v.extract    s8, v8, #14
    v.sub        v9, v13, v17
    v.splat      v11, s8
    v.extract    s8, v7, #14
    @p1 v.sel        v13, v9, v17
    v.splat      v9, s8
    v.mul        v16, v11, v4
    v.extract    s8, v2, #13
    v.extract    s9, v2, #14
    v.mul        v11, v13, v3
    v.splat      v13, s8
    v.add        v17, v9, v16
    v.splat      v9, s9
    v.add        v16, v19, v11
    v.mul        v11, v13, v0
    v.add        v13, v17, v10
    v.mul        v17, v9, v0
    v.add        v9, v16, v11
    v.add        v11, v13, v17
    v.movi       v13, #0
    v.add        v16, v18, v9
    v.sub        v9, v13, v11
    v.sub        v17, v13, v5
    v.cmp.lt     p1, v11, v13
    v.cmp.lt     p2, v5, v13
    v.st.w       [s3, #0], v16
    s.addi       s3, s6, #896
    v.movi       v16, #1
    @p1 v.sel        v20, v9, v11
    @p2 v.sel        v9, v17, v5
    v.movi       v11, #0
    v.movi       v17, #0
    s.movz       s8, #31
idiv_21:
    v.splat      v21, s8
    v.shl        v22, v17, v16
    v.lshr       v23, v20, v21
    v.cmp.lt     p2, v17, v13
    v.and        v24, v23, v16
    v.shl        v23, v16, v21
    v.or         v21, v22, v24
    s.subi       s9, s8, #1
    v.cmp.geu    p4, v21, v9
    p.or         p5, p2, p4
    v.sub        v22, v21, v9
    @p5 v.sel        v24, v23, v13
    @p5 v.sel        v23, v22, v21
    v.or         v21, v11, v24
    v.mov        v17, v23
    v.mov        v11, v21
    s.mov        s8, s9
    s.movz       s9, #0
    s.cmp.ge     s11, s8, s9
    br.nz        s11, idiv_21
    v.extract    s8, v8, #15
    v.sub        v8, v13, v17
    v.splat      v9, s8
    v.extract    s8, v7, #15
    @p1 v.sel        v7, v8, v17
    v.splat      v8, s8
    v.mul        v11, v9, v4
    v.extract    s8, v2, #14
    v.extract    s9, v2, #15
    v.mul        v4, v7, v3
    v.splat      v7, s8
    v.add        v9, v8, v11
    v.splat      v8, s9
    v.add        v11, v19, v4
    v.mul        v4, v7, v0
    v.add        v7, v9, v10
    v.mul        v9, v8, v0
    v.add        v8, v11, v4
    v.add        v4, v7, v9
    v.movi       v7, #0
    v.add        v9, v18, v8
    v.sub        v8, v7, v4
    v.sub        v10, v7, v5
    v.cmp.lt     p1, v4, v7
    v.cmp.lt     p2, v5, v7
    v.st.w       [s3, #0], v9
    s.addi       s3, s6, #960
    v.movi       v9, #1
    @p1 v.sel        v11, v8, v4
    @p2 v.sel        v4, v10, v5
    v.movi       v5, #0
    v.movi       v8, #0
    s.movz       s6, #31
idiv_22:
    v.splat      v10, s6
    v.shl        v13, v8, v9
    v.lshr       v16, v11, v10
    v.cmp.lt     p2, v8, v7
    v.and        v17, v16, v9
    v.shl        v16, v9, v10
    v.or         v10, v13, v17
    s.subi       s8, s6, #1
    v.cmp.geu    p4, v10, v4
    p.or         p5, p2, p4
    v.sub        v13, v10, v4
    @p5 v.sel        v17, v16, v7
    @p5 v.sel        v16, v13, v10
    v.or         v10, v5, v17
    v.mov        v8, v16
    v.mov        v5, v10
    s.mov        s6, s8
    s.movz       s8, #0
    s.cmp.ge     s9, s6, s8
    br.nz        s9, idiv_22
    v.sub        v4, v7, v8
    v.extract    s6, v1, #0
    @p1 v.sel        v5, v4, v8
    v.extract    s8, v6, #0
    v.extract    s9, v2, #15
    v.splat      v2, s6
    v.movi       v4, #0
    v.splat      v7, s8
    v.movi       v8, #0
    v.mul        v9, v5, v3
    v.splat      v3, s9
    v.extract    s6, v12, #0
    v.cmp.ne     p1, v2, v4
    v.cmp.ne     p2, v7, v8
    v.splat      v2, s6
    v.movi       v4, #0
    v.add        v5, v19, v9
    v.mul        v7, v3, v0
    p.and        p4, p1, p2
    v.cmp.ne     p1, v2, v4
    v.add        v0, v5, v7
    p.and        p2, p4, p1
    v.add        v2, v18, v0
    s.movz       s6, #0
    p.and        p1, p2, p3
    v.st.w       [s3, #0], v2
    fence.acq_rel.device
    a.vread      v0, a0, s6
    v.extract    s3, v1, #0
    v.extract    s6, v6, #0
    v.splat      v2, s3
    v.movi       v3, #0
    v.splat      v4, s6
    v.movi       v5, #0
    v.extract    s3, v12, #0
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v7, [s2, #0]
    v.cmp.ne     p1, v2, v3
    v.cmp.ne     p2, v4, v5
    v.splat      v2, s3
    v.movi       v3, #0
    p.and        p4, p1, p2
    v.cmp.ne     p1, v2, v3
    p.and        p2, p4, p1
    v.extract    s3, v1, #0
    p.and        p1, p2, p3
    vf.add       v2, v7, v14
    v.extract    s6, v6, #0
    v.splat      v3, s3
    v.movi       v4, #0
    v.rsqrt.approx v5, v2                        // ISA 8.8: <= 2**-22 relative
    v.splat      v7, s6
    v.movi       v8, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v9, [s1, #0]
    v.extract    s3, v12, #0
    .li       s6, #1077936128
    v.splat      v10, s6                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s6, #3204448256
    v.splat      v11, s6                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.ne     p1, v3, v4
    v.cmp.ne     p2, v7, v8
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.extract    s3, v1, #0
    v.cmp.ne     p1, v3, v4
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p2, p4, p1
    vf.sub       v7, v0, v9
    v.extract    s3, v6, #0
    v.splat      v0, s3
    v.movi       v8, #0
    v.extract    s3, v12, #0
    v.cmp.ne     p1, v3, v4
    v.cmp.ne     p4, v0, v8
    v.splat      v0, s3
    v.movi       v3, #0
    p.and        p5, p2, p3
    vf.mul       v4, v5, v5
    vf.mul       v8, v5, v11
    p.and        p2, p1, p4
    v.cmp.ne     p1, v0, v3
    vf.fms       v0, v2, v4, v10
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p5 v.ld.w       v2, [s4, #0]
    p.and        p4, p2, p1
    s.addi       s3, s7, #3136
    vf.mul       v3, v8, v0                      // Newton step: 0.5*r0*(3 - x*r0^2)
    p.and        p1, p4, p3
    v.extract    s6, v1, #0
    v.extract    s8, v6, #0
    vf.cmp.o     p2, v3, v3
    @p2 v.sel        v0, v3, v5
    v.splat      v3, s6
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s5, #0]
    vf.mul       v5, v7, v0
    v.movi       v0, #0
    v.splat      v7, s8
    v.movi       v8, #0
    vf.mul       v9, v5, v2
    v.extract    s6, v1, #1
    v.extract    s8, v6, #1
    v.splat      v2, s6
    v.movi       v5, #0
    v.ld.w       v13, [s3, #0]
    vf.add       v16, v9, v4
    v.splat      v4, s8
    v.extract    s3, v12, #0
    v.extract    s6, v12, #1
    v.cmp.ne     p1, v3, v0
    v.movi       v0, #0
    v.cmp.ne     p2, v7, v8
    v.splat      v3, s3
    v.movi       v7, #0
    v.cmp.ne     p4, v2, v5
    p.and        p5, p1, p2
    v.cmp.ne     p1, v4, v0
    p.and        p2, p4, p1
    v.cmp.ne     p1, v3, v7
    vf.max.prop  v0, v16, v15
    v.splat      v2, s6
    v.movi       v3, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v2, v3
    p.and        p5, p2, p1
    p.and        p1, p4, p3
    s.movz       s3, #1
    p.and        p2, p5, p3
    @p1 v.st.scatter.w [s10, v13], v0
    a.vread      v0, a0, s3
    v.extract    s3, v1, #1
    v.extract    s6, v6, #1
    v.splat      v2, s3
    v.movi       v3, #0
    v.splat      v4, s6
    v.movi       v5, #0
    v.extract    s3, v12, #1
    v.cmp.ne     p1, v2, v3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p2, v4, v5
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.cmp.ne     p1, v3, v4
    p.and        p2, p4, p1
    v.extract    s3, v1, #1
    p.and        p1, p2, p3
    v.extract    s6, v6, #1
    vf.add       v3, v2, v14
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s6
    v.rsqrt.approx v7, v3                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v9, [s1, #0]
    v.extract    s3, v12, #1
    v.cmp.ne     p1, v2, v4
    v.cmp.ne     p2, v5, v8
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.extract    s3, v1, #1
    v.extract    s6, v6, #1
    v.cmp.ne     p1, v2, v4
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p2, p4, p1
    v.cmp.ne     p1, v2, v4
    p.and        p4, p2, p3
    vf.sub       v2, v0, v9
    v.splat      v0, s6
    v.movi       v4, #0
    v.extract    s3, v12, #1
    v.cmp.ne     p2, v0, v4
    v.splat      v0, s3
    v.movi       v4, #0
    p.and        p5, p1, p2
    v.cmp.ne     p1, v0, v4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s4, #0]
    vf.mul       v4, v7, v7
    vf.mul       v5, v7, v11
    p.and        p2, p5, p1
    s.addi       s3, s7, #3200
    vf.fms       v8, v3, v4, v10
    p.and        p1, p2, p3
    v.extract    s6, v1, #1
    v.extract    s8, v6, #1
    vf.mul       v3, v5, v8                      // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s5, #0]
    v.splat      v5, s6
    v.movi       v8, #0
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v9, v3, v7
    v.splat      v3, s8
    vf.mul       v7, v2, v9
    v.movi       v2, #0
    v.extract    s6, v12, #1
    v.cmp.ne     p1, v5, v8
    vf.mul       v5, v7, v0
    v.ld.w       v0, [s3, #0]
    v.extract    s3, v1, #2
    v.extract    s8, v6, #2
    v.splat      v7, s3
    v.movi       v8, #0
    v.splat      v9, s8
    v.movi       v13, #0
    vf.add       v16, v5, v4
    v.extract    s3, v12, #2
    v.cmp.ne     p2, v3, v2
    v.splat      v2, s6
    v.movi       v3, #0
    v.cmp.ne     p4, v7, v8
    p.and        p5, p1, p2
    v.cmp.ne     p1, v9, v13
    p.and        p2, p4, p1
    v.cmp.ne     p1, v2, v3
    vf.max.prop  v2, v16, v15
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v3, v4
    p.and        p5, p2, p1
    p.and        p1, p4, p3
    s.movz       s3, #2
    p.and        p2, p5, p3
    @p1 v.st.scatter.w [s10, v0], v2
    a.vread      v0, a0, s3
    v.extract    s3, v1, #2
    v.extract    s6, v6, #2
    v.splat      v2, s3
    v.movi       v3, #0
    v.splat      v4, s6
    v.movi       v5, #0
    v.extract    s3, v12, #2
    v.cmp.ne     p1, v2, v3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p2, v4, v5
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.cmp.ne     p1, v3, v4
    p.and        p2, p4, p1
    v.extract    s3, v1, #2
    p.and        p1, p2, p3
    v.extract    s6, v6, #2
    vf.add       v3, v2, v14
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s6
    v.rsqrt.approx v7, v3                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v9, [s1, #0]
    v.extract    s3, v12, #2
    v.cmp.ne     p1, v2, v4
    v.cmp.ne     p2, v5, v8
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.extract    s3, v1, #2
    v.extract    s6, v6, #2
    v.cmp.ne     p1, v2, v4
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p2, p4, p1
    v.cmp.ne     p1, v2, v4
    p.and        p4, p2, p3
    vf.sub       v2, v0, v9
    v.splat      v0, s6
    v.movi       v4, #0
    v.extract    s3, v12, #2
    v.cmp.ne     p2, v0, v4
    v.splat      v0, s3
    v.movi       v4, #0
    p.and        p5, p1, p2
    v.cmp.ne     p1, v0, v4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s4, #0]
    vf.mul       v4, v7, v7
    vf.mul       v5, v7, v11
    p.and        p2, p5, p1
    s.addi       s3, s7, #3264
    vf.fms       v8, v3, v4, v10
    p.and        p1, p2, p3
    v.extract    s6, v1, #2
    v.extract    s8, v6, #2
    vf.mul       v3, v5, v8                      // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s5, #0]
    v.splat      v5, s6
    v.movi       v8, #0
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v9, v3, v7
    v.splat      v3, s8
    vf.mul       v7, v2, v9
    v.movi       v2, #0
    v.extract    s6, v12, #2
    v.cmp.ne     p1, v5, v8
    vf.mul       v5, v7, v0
    v.ld.w       v0, [s3, #0]
    v.extract    s3, v1, #3
    v.extract    s8, v6, #3
    v.splat      v7, s3
    v.movi       v8, #0
    v.splat      v9, s8
    v.movi       v13, #0
    vf.add       v16, v5, v4
    v.extract    s3, v12, #3
    v.cmp.ne     p2, v3, v2
    v.splat      v2, s6
    v.movi       v3, #0
    v.cmp.ne     p4, v7, v8
    p.and        p5, p1, p2
    v.cmp.ne     p1, v9, v13
    p.and        p2, p4, p1
    v.cmp.ne     p1, v2, v3
    vf.max.prop  v2, v16, v15
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v3, v4
    p.and        p5, p2, p1
    p.and        p1, p4, p3
    s.movz       s3, #3
    p.and        p2, p5, p3
    @p1 v.st.scatter.w [s10, v0], v2
    a.vread      v0, a0, s3
    v.extract    s3, v1, #3
    v.extract    s6, v6, #3
    v.splat      v2, s3
    v.movi       v3, #0
    v.splat      v4, s6
    v.movi       v5, #0
    v.extract    s3, v12, #3
    v.cmp.ne     p1, v2, v3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p2, v4, v5
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.cmp.ne     p1, v3, v4
    p.and        p2, p4, p1
    v.extract    s3, v1, #3
    p.and        p1, p2, p3
    v.extract    s6, v6, #3
    vf.add       v3, v2, v14
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s6
    v.rsqrt.approx v7, v3                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v9, [s1, #0]
    v.extract    s3, v12, #3
    v.cmp.ne     p1, v2, v4
    v.cmp.ne     p2, v5, v8
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.extract    s3, v1, #3
    v.extract    s6, v6, #3
    v.cmp.ne     p1, v2, v4
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p2, p4, p1
    v.cmp.ne     p1, v2, v4
    p.and        p4, p2, p3
    vf.sub       v2, v0, v9
    v.splat      v0, s6
    v.movi       v4, #0
    v.extract    s3, v12, #3
    v.cmp.ne     p2, v0, v4
    v.splat      v0, s3
    v.movi       v4, #0
    p.and        p5, p1, p2
    v.cmp.ne     p1, v0, v4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s4, #0]
    vf.mul       v4, v7, v7
    vf.mul       v5, v7, v11
    p.and        p2, p5, p1
    s.addi       s3, s7, #3328
    vf.fms       v8, v3, v4, v10
    p.and        p1, p2, p3
    v.extract    s6, v1, #3
    v.extract    s8, v6, #3
    vf.mul       v3, v5, v8                      // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s5, #0]
    v.splat      v5, s6
    v.movi       v8, #0
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v9, v3, v7
    v.splat      v3, s8
    vf.mul       v7, v2, v9
    v.movi       v2, #0
    v.extract    s6, v12, #3
    v.cmp.ne     p1, v5, v8
    vf.mul       v5, v7, v0
    v.ld.w       v0, [s3, #0]
    v.extract    s3, v1, #4
    v.extract    s8, v6, #4
    v.splat      v7, s3
    v.movi       v8, #0
    v.splat      v9, s8
    v.movi       v13, #0
    vf.add       v16, v5, v4
    v.extract    s3, v12, #4
    v.cmp.ne     p2, v3, v2
    v.splat      v2, s6
    v.movi       v3, #0
    v.cmp.ne     p4, v7, v8
    p.and        p5, p1, p2
    v.cmp.ne     p1, v9, v13
    p.and        p2, p4, p1
    v.cmp.ne     p1, v2, v3
    vf.max.prop  v2, v16, v15
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v3, v4
    p.and        p5, p2, p1
    p.and        p1, p4, p3
    s.movz       s3, #4
    p.and        p2, p5, p3
    @p1 v.st.scatter.w [s10, v0], v2
    a.vread      v0, a0, s3
    v.extract    s3, v1, #4
    v.extract    s6, v6, #4
    v.splat      v2, s3
    v.movi       v3, #0
    v.splat      v4, s6
    v.movi       v5, #0
    v.extract    s3, v12, #4
    v.cmp.ne     p1, v2, v3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p2, v4, v5
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.cmp.ne     p1, v3, v4
    p.and        p2, p4, p1
    v.extract    s3, v1, #4
    p.and        p1, p2, p3
    v.extract    s6, v6, #4
    vf.add       v3, v2, v14
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s6
    v.rsqrt.approx v7, v3                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v9, [s1, #0]
    v.extract    s3, v12, #4
    v.cmp.ne     p1, v2, v4
    v.cmp.ne     p2, v5, v8
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.extract    s3, v1, #4
    v.extract    s6, v6, #4
    v.cmp.ne     p1, v2, v4
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p2, p4, p1
    v.cmp.ne     p1, v2, v4
    p.and        p4, p2, p3
    vf.sub       v2, v0, v9
    v.splat      v0, s6
    v.movi       v4, #0
    v.extract    s3, v12, #4
    v.cmp.ne     p2, v0, v4
    v.splat      v0, s3
    v.movi       v4, #0
    p.and        p5, p1, p2
    v.cmp.ne     p1, v0, v4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s4, #0]
    vf.mul       v4, v7, v7
    vf.mul       v5, v7, v11
    p.and        p2, p5, p1
    s.addi       s3, s7, #3392
    vf.fms       v8, v3, v4, v10
    p.and        p1, p2, p3
    v.extract    s6, v1, #4
    v.extract    s8, v6, #4
    vf.mul       v3, v5, v8                      // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s5, #0]
    v.splat      v5, s6
    v.movi       v8, #0
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v9, v3, v7
    v.splat      v3, s8
    vf.mul       v7, v2, v9
    v.movi       v2, #0
    v.extract    s6, v12, #4
    v.cmp.ne     p1, v5, v8
    vf.mul       v5, v7, v0
    v.ld.w       v0, [s3, #0]
    v.extract    s3, v1, #5
    v.extract    s8, v6, #5
    v.splat      v7, s3
    v.movi       v8, #0
    v.splat      v9, s8
    v.movi       v13, #0
    vf.add       v16, v5, v4
    v.extract    s3, v12, #5
    v.cmp.ne     p2, v3, v2
    v.splat      v2, s6
    v.movi       v3, #0
    v.cmp.ne     p4, v7, v8
    p.and        p5, p1, p2
    v.cmp.ne     p1, v9, v13
    p.and        p2, p4, p1
    v.cmp.ne     p1, v2, v3
    vf.max.prop  v2, v16, v15
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v3, v4
    p.and        p5, p2, p1
    p.and        p1, p4, p3
    s.movz       s3, #5
    p.and        p2, p5, p3
    @p1 v.st.scatter.w [s10, v0], v2
    a.vread      v0, a0, s3
    v.extract    s3, v1, #5
    v.extract    s6, v6, #5
    v.splat      v2, s3
    v.movi       v3, #0
    v.splat      v4, s6
    v.movi       v5, #0
    v.extract    s3, v12, #5
    v.cmp.ne     p1, v2, v3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p2, v4, v5
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.cmp.ne     p1, v3, v4
    p.and        p2, p4, p1
    v.extract    s3, v1, #5
    p.and        p1, p2, p3
    v.extract    s6, v6, #5
    vf.add       v3, v2, v14
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s6
    v.rsqrt.approx v7, v3                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v9, [s1, #0]
    v.extract    s3, v12, #5
    v.cmp.ne     p1, v2, v4
    v.cmp.ne     p2, v5, v8
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.extract    s3, v1, #5
    v.extract    s6, v6, #5
    v.cmp.ne     p1, v2, v4
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p2, p4, p1
    v.cmp.ne     p1, v2, v4
    p.and        p4, p2, p3
    vf.sub       v2, v0, v9
    v.splat      v0, s6
    v.movi       v4, #0
    v.extract    s3, v12, #5
    v.cmp.ne     p2, v0, v4
    v.splat      v0, s3
    v.movi       v4, #0
    p.and        p5, p1, p2
    v.cmp.ne     p1, v0, v4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s4, #0]
    vf.mul       v4, v7, v7
    vf.mul       v5, v7, v11
    p.and        p2, p5, p1
    s.addi       s3, s7, #3456
    vf.fms       v8, v3, v4, v10
    p.and        p1, p2, p3
    v.extract    s6, v1, #5
    v.extract    s8, v6, #5
    vf.mul       v3, v5, v8                      // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s5, #0]
    v.splat      v5, s6
    v.movi       v8, #0
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v9, v3, v7
    v.splat      v3, s8
    vf.mul       v7, v2, v9
    v.movi       v2, #0
    v.extract    s6, v12, #5
    v.cmp.ne     p1, v5, v8
    vf.mul       v5, v7, v0
    v.ld.w       v0, [s3, #0]
    v.extract    s3, v1, #6
    v.extract    s8, v6, #6
    v.splat      v7, s3
    v.movi       v8, #0
    v.splat      v9, s8
    v.movi       v13, #0
    vf.add       v16, v5, v4
    v.extract    s3, v12, #6
    v.cmp.ne     p2, v3, v2
    v.splat      v2, s6
    v.movi       v3, #0
    v.cmp.ne     p4, v7, v8
    p.and        p5, p1, p2
    v.cmp.ne     p1, v9, v13
    p.and        p2, p4, p1
    v.cmp.ne     p1, v2, v3
    vf.max.prop  v2, v16, v15
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v3, v4
    p.and        p5, p2, p1
    p.and        p1, p4, p3
    s.movz       s3, #6
    p.and        p2, p5, p3
    @p1 v.st.scatter.w [s10, v0], v2
    a.vread      v0, a0, s3
    v.extract    s3, v1, #6
    v.extract    s6, v6, #6
    v.splat      v2, s3
    v.movi       v3, #0
    v.splat      v4, s6
    v.movi       v5, #0
    v.extract    s3, v12, #6
    v.cmp.ne     p1, v2, v3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p2, v4, v5
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.cmp.ne     p1, v3, v4
    p.and        p2, p4, p1
    v.extract    s3, v1, #6
    p.and        p1, p2, p3
    v.extract    s6, v6, #6
    vf.add       v3, v2, v14
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s6
    v.rsqrt.approx v7, v3                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v9, [s1, #0]
    v.extract    s3, v12, #6
    v.cmp.ne     p1, v2, v4
    v.cmp.ne     p2, v5, v8
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.extract    s3, v1, #6
    v.extract    s6, v6, #6
    v.cmp.ne     p1, v2, v4
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p2, p4, p1
    v.cmp.ne     p1, v2, v4
    p.and        p4, p2, p3
    vf.sub       v2, v0, v9
    v.splat      v0, s6
    v.movi       v4, #0
    v.extract    s3, v12, #6
    v.cmp.ne     p2, v0, v4
    v.splat      v0, s3
    v.movi       v4, #0
    p.and        p5, p1, p2
    v.cmp.ne     p1, v0, v4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s4, #0]
    vf.mul       v4, v7, v7
    vf.mul       v5, v7, v11
    p.and        p2, p5, p1
    s.addi       s3, s7, #3520
    vf.fms       v8, v3, v4, v10
    p.and        p1, p2, p3
    v.extract    s6, v1, #6
    v.extract    s8, v6, #6
    vf.mul       v3, v5, v8                      // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s5, #0]
    v.splat      v5, s6
    v.movi       v8, #0
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v9, v3, v7
    v.splat      v3, s8
    vf.mul       v7, v2, v9
    v.movi       v2, #0
    v.extract    s6, v12, #6
    v.cmp.ne     p1, v5, v8
    vf.mul       v5, v7, v0
    v.ld.w       v0, [s3, #0]
    v.extract    s3, v1, #7
    v.extract    s8, v6, #7
    v.splat      v7, s3
    v.movi       v8, #0
    v.splat      v9, s8
    v.movi       v13, #0
    vf.add       v16, v5, v4
    v.extract    s3, v12, #7
    v.cmp.ne     p2, v3, v2
    v.splat      v2, s6
    v.movi       v3, #0
    v.cmp.ne     p4, v7, v8
    p.and        p5, p1, p2
    v.cmp.ne     p1, v9, v13
    p.and        p2, p4, p1
    v.cmp.ne     p1, v2, v3
    vf.max.prop  v2, v16, v15
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v3, v4
    p.and        p5, p2, p1
    p.and        p1, p4, p3
    s.movz       s3, #7
    p.and        p2, p5, p3
    @p1 v.st.scatter.w [s10, v0], v2
    a.vread      v0, a0, s3
    v.extract    s3, v1, #7
    v.extract    s6, v6, #7
    v.splat      v2, s3
    v.movi       v3, #0
    v.splat      v4, s6
    v.movi       v5, #0
    v.extract    s3, v12, #7
    v.cmp.ne     p1, v2, v3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p2, v4, v5
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.cmp.ne     p1, v3, v4
    p.and        p2, p4, p1
    v.extract    s3, v1, #7
    p.and        p1, p2, p3
    v.extract    s6, v6, #7
    vf.add       v3, v2, v14
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s6
    v.rsqrt.approx v7, v3                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v9, [s1, #0]
    v.extract    s3, v12, #7
    v.cmp.ne     p1, v2, v4
    v.cmp.ne     p2, v5, v8
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.extract    s3, v1, #7
    v.extract    s6, v6, #7
    v.cmp.ne     p1, v2, v4
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p2, p4, p1
    v.cmp.ne     p1, v2, v4
    p.and        p4, p2, p3
    vf.sub       v2, v0, v9
    v.splat      v0, s6
    v.movi       v4, #0
    v.extract    s3, v12, #7
    v.cmp.ne     p2, v0, v4
    v.splat      v0, s3
    v.movi       v4, #0
    p.and        p5, p1, p2
    v.cmp.ne     p1, v0, v4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s4, #0]
    vf.mul       v4, v7, v7
    vf.mul       v5, v7, v11
    p.and        p2, p5, p1
    s.addi       s3, s7, #3584
    vf.fms       v8, v3, v4, v10
    p.and        p1, p2, p3
    v.extract    s6, v1, #7
    v.extract    s8, v6, #7
    vf.mul       v3, v5, v8                      // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s5, #0]
    v.splat      v5, s6
    v.movi       v8, #0
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v9, v3, v7
    v.splat      v3, s8
    vf.mul       v7, v2, v9
    v.movi       v2, #0
    v.extract    s6, v12, #7
    v.cmp.ne     p1, v5, v8
    vf.mul       v5, v7, v0
    v.ld.w       v0, [s3, #0]
    v.extract    s3, v1, #8
    v.extract    s8, v6, #8
    v.splat      v7, s3
    v.movi       v8, #0
    v.splat      v9, s8
    v.movi       v13, #0
    vf.add       v16, v5, v4
    v.extract    s3, v12, #8
    v.cmp.ne     p2, v3, v2
    v.splat      v2, s6
    v.movi       v3, #0
    v.cmp.ne     p4, v7, v8
    p.and        p5, p1, p2
    v.cmp.ne     p1, v9, v13
    p.and        p2, p4, p1
    v.cmp.ne     p1, v2, v3
    vf.max.prop  v2, v16, v15
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v3, v4
    p.and        p5, p2, p1
    p.and        p1, p4, p3
    s.movz       s3, #8
    p.and        p2, p5, p3
    @p1 v.st.scatter.w [s10, v0], v2
    a.vread      v0, a0, s3
    v.extract    s3, v1, #8
    v.extract    s6, v6, #8
    v.splat      v2, s3
    v.movi       v3, #0
    v.splat      v4, s6
    v.movi       v5, #0
    v.extract    s3, v12, #8
    v.cmp.ne     p1, v2, v3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p2, v4, v5
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.cmp.ne     p1, v3, v4
    p.and        p2, p4, p1
    v.extract    s3, v1, #8
    p.and        p1, p2, p3
    v.extract    s6, v6, #8
    vf.add       v3, v2, v14
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s6
    v.rsqrt.approx v7, v3                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v9, [s1, #0]
    v.extract    s3, v12, #8
    v.cmp.ne     p1, v2, v4
    v.cmp.ne     p2, v5, v8
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.extract    s3, v1, #8
    v.extract    s6, v6, #8
    v.cmp.ne     p1, v2, v4
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p2, p4, p1
    v.cmp.ne     p1, v2, v4
    p.and        p4, p2, p3
    vf.sub       v2, v0, v9
    v.splat      v0, s6
    v.movi       v4, #0
    v.extract    s3, v12, #8
    v.cmp.ne     p2, v0, v4
    v.splat      v0, s3
    v.movi       v4, #0
    p.and        p5, p1, p2
    v.cmp.ne     p1, v0, v4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s4, #0]
    vf.mul       v4, v7, v7
    vf.mul       v5, v7, v11
    p.and        p2, p5, p1
    s.addi       s3, s7, #3648
    vf.fms       v8, v3, v4, v10
    p.and        p1, p2, p3
    v.extract    s6, v1, #8
    v.extract    s8, v6, #8
    vf.mul       v3, v5, v8                      // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s5, #0]
    v.splat      v5, s6
    v.movi       v8, #0
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v9, v3, v7
    v.splat      v3, s8
    vf.mul       v7, v2, v9
    v.movi       v2, #0
    v.extract    s6, v12, #8
    v.cmp.ne     p1, v5, v8
    vf.mul       v5, v7, v0
    v.ld.w       v0, [s3, #0]
    v.extract    s3, v1, #9
    v.extract    s8, v6, #9
    v.splat      v7, s3
    v.movi       v8, #0
    v.splat      v9, s8
    v.movi       v13, #0
    vf.add       v16, v5, v4
    v.extract    s3, v12, #9
    v.cmp.ne     p2, v3, v2
    v.splat      v2, s6
    v.movi       v3, #0
    v.cmp.ne     p4, v7, v8
    p.and        p5, p1, p2
    v.cmp.ne     p1, v9, v13
    p.and        p2, p4, p1
    v.cmp.ne     p1, v2, v3
    vf.max.prop  v2, v16, v15
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v3, v4
    p.and        p5, p2, p1
    p.and        p1, p4, p3
    s.movz       s3, #9
    p.and        p2, p5, p3
    @p1 v.st.scatter.w [s10, v0], v2
    a.vread      v0, a0, s3
    v.extract    s3, v1, #9
    v.extract    s6, v6, #9
    v.splat      v2, s3
    v.movi       v3, #0
    v.splat      v4, s6
    v.movi       v5, #0
    v.extract    s3, v12, #9
    v.cmp.ne     p1, v2, v3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p2, v4, v5
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.cmp.ne     p1, v3, v4
    p.and        p2, p4, p1
    v.extract    s3, v1, #9
    p.and        p1, p2, p3
    v.extract    s6, v6, #9
    vf.add       v3, v2, v14
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s6
    v.rsqrt.approx v7, v3                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v9, [s1, #0]
    v.extract    s3, v12, #9
    v.cmp.ne     p1, v2, v4
    v.cmp.ne     p2, v5, v8
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.extract    s3, v1, #9
    v.extract    s6, v6, #9
    v.cmp.ne     p1, v2, v4
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p2, p4, p1
    v.cmp.ne     p1, v2, v4
    p.and        p4, p2, p3
    vf.sub       v2, v0, v9
    v.splat      v0, s6
    v.movi       v4, #0
    v.extract    s3, v12, #9
    v.cmp.ne     p2, v0, v4
    v.splat      v0, s3
    v.movi       v4, #0
    p.and        p5, p1, p2
    v.cmp.ne     p1, v0, v4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s4, #0]
    vf.mul       v4, v7, v7
    vf.mul       v5, v7, v11
    p.and        p2, p5, p1
    s.addi       s3, s7, #3712
    vf.fms       v8, v3, v4, v10
    p.and        p1, p2, p3
    v.extract    s6, v1, #9
    v.extract    s8, v6, #9
    vf.mul       v3, v5, v8                      // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s5, #0]
    v.splat      v5, s6
    v.movi       v8, #0
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v9, v3, v7
    v.splat      v3, s8
    vf.mul       v7, v2, v9
    v.movi       v2, #0
    v.extract    s6, v12, #9
    v.cmp.ne     p1, v5, v8
    vf.mul       v5, v7, v0
    v.ld.w       v0, [s3, #0]
    v.extract    s3, v1, #10
    v.extract    s8, v6, #10
    v.splat      v7, s3
    v.movi       v8, #0
    v.splat      v9, s8
    v.movi       v13, #0
    vf.add       v16, v5, v4
    v.extract    s3, v12, #10
    v.cmp.ne     p2, v3, v2
    v.splat      v2, s6
    v.movi       v3, #0
    v.cmp.ne     p4, v7, v8
    p.and        p5, p1, p2
    v.cmp.ne     p1, v9, v13
    p.and        p2, p4, p1
    v.cmp.ne     p1, v2, v3
    vf.max.prop  v2, v16, v15
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v3, v4
    p.and        p5, p2, p1
    p.and        p1, p4, p3
    s.movz       s3, #10
    p.and        p2, p5, p3
    @p1 v.st.scatter.w [s10, v0], v2
    a.vread      v0, a0, s3
    v.extract    s3, v1, #10
    v.extract    s6, v6, #10
    v.splat      v2, s3
    v.movi       v3, #0
    v.splat      v4, s6
    v.movi       v5, #0
    v.extract    s3, v12, #10
    v.cmp.ne     p1, v2, v3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p2, v4, v5
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.cmp.ne     p1, v3, v4
    p.and        p2, p4, p1
    v.extract    s3, v1, #10
    p.and        p1, p2, p3
    v.extract    s6, v6, #10
    vf.add       v3, v2, v14
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s6
    v.rsqrt.approx v7, v3                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v9, [s1, #0]
    v.extract    s3, v12, #10
    v.cmp.ne     p1, v2, v4
    v.cmp.ne     p2, v5, v8
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.extract    s3, v1, #10
    v.extract    s6, v6, #10
    v.cmp.ne     p1, v2, v4
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p2, p4, p1
    v.cmp.ne     p1, v2, v4
    p.and        p4, p2, p3
    vf.sub       v2, v0, v9
    v.splat      v0, s6
    v.movi       v4, #0
    v.extract    s3, v12, #10
    v.cmp.ne     p2, v0, v4
    v.splat      v0, s3
    v.movi       v4, #0
    p.and        p5, p1, p2
    v.cmp.ne     p1, v0, v4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s4, #0]
    vf.mul       v4, v7, v7
    vf.mul       v5, v7, v11
    p.and        p2, p5, p1
    s.addi       s3, s7, #3776
    vf.fms       v8, v3, v4, v10
    p.and        p1, p2, p3
    v.extract    s6, v1, #10
    v.extract    s8, v6, #10
    vf.mul       v3, v5, v8                      // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s5, #0]
    v.splat      v5, s6
    v.movi       v8, #0
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v9, v3, v7
    v.splat      v3, s8
    vf.mul       v7, v2, v9
    v.movi       v2, #0
    v.extract    s6, v12, #10
    v.cmp.ne     p1, v5, v8
    vf.mul       v5, v7, v0
    v.ld.w       v0, [s3, #0]
    v.extract    s3, v1, #11
    v.extract    s8, v6, #11
    v.splat      v7, s3
    v.movi       v8, #0
    v.splat      v9, s8
    v.movi       v13, #0
    vf.add       v16, v5, v4
    v.extract    s3, v12, #11
    v.cmp.ne     p2, v3, v2
    v.splat      v2, s6
    v.movi       v3, #0
    v.cmp.ne     p4, v7, v8
    p.and        p5, p1, p2
    v.cmp.ne     p1, v9, v13
    p.and        p2, p4, p1
    v.cmp.ne     p1, v2, v3
    vf.max.prop  v2, v16, v15
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v3, v4
    p.and        p5, p2, p1
    p.and        p1, p4, p3
    s.movz       s3, #11
    p.and        p2, p5, p3
    @p1 v.st.scatter.w [s10, v0], v2
    a.vread      v0, a0, s3
    v.extract    s3, v1, #11
    v.extract    s6, v6, #11
    v.splat      v2, s3
    v.movi       v3, #0
    v.splat      v4, s6
    v.movi       v5, #0
    v.extract    s3, v12, #11
    v.cmp.ne     p1, v2, v3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p2, v4, v5
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.cmp.ne     p1, v3, v4
    p.and        p2, p4, p1
    v.extract    s3, v1, #11
    p.and        p1, p2, p3
    v.extract    s6, v6, #11
    vf.add       v3, v2, v14
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s6
    v.rsqrt.approx v7, v3                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v9, [s1, #0]
    v.extract    s3, v12, #11
    v.cmp.ne     p1, v2, v4
    v.cmp.ne     p2, v5, v8
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.extract    s3, v1, #11
    v.extract    s6, v6, #11
    v.cmp.ne     p1, v2, v4
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p2, p4, p1
    v.cmp.ne     p1, v2, v4
    p.and        p4, p2, p3
    vf.sub       v2, v0, v9
    v.splat      v0, s6
    v.movi       v4, #0
    v.extract    s3, v12, #11
    v.cmp.ne     p2, v0, v4
    v.splat      v0, s3
    v.movi       v4, #0
    p.and        p5, p1, p2
    v.cmp.ne     p1, v0, v4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s4, #0]
    vf.mul       v4, v7, v7
    vf.mul       v5, v7, v11
    p.and        p2, p5, p1
    s.addi       s3, s7, #3840
    vf.fms       v8, v3, v4, v10
    p.and        p1, p2, p3
    v.extract    s6, v1, #11
    v.extract    s8, v6, #11
    vf.mul       v3, v5, v8                      // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s5, #0]
    v.splat      v5, s6
    v.movi       v8, #0
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v9, v3, v7
    v.splat      v3, s8
    vf.mul       v7, v2, v9
    v.movi       v2, #0
    v.extract    s6, v12, #11
    v.cmp.ne     p1, v5, v8
    vf.mul       v5, v7, v0
    v.ld.w       v0, [s3, #0]
    v.extract    s3, v1, #12
    v.extract    s8, v6, #12
    v.splat      v7, s3
    v.movi       v8, #0
    v.splat      v9, s8
    v.movi       v13, #0
    vf.add       v16, v5, v4
    v.extract    s3, v12, #12
    v.cmp.ne     p2, v3, v2
    v.splat      v2, s6
    v.movi       v3, #0
    v.cmp.ne     p4, v7, v8
    p.and        p5, p1, p2
    v.cmp.ne     p1, v9, v13
    p.and        p2, p4, p1
    v.cmp.ne     p1, v2, v3
    vf.max.prop  v2, v16, v15
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v3, v4
    p.and        p5, p2, p1
    p.and        p1, p4, p3
    s.movz       s3, #12
    p.and        p2, p5, p3
    @p1 v.st.scatter.w [s10, v0], v2
    a.vread      v0, a0, s3
    v.extract    s3, v1, #12
    v.extract    s6, v6, #12
    v.splat      v2, s3
    v.movi       v3, #0
    v.splat      v4, s6
    v.movi       v5, #0
    v.extract    s3, v12, #12
    v.cmp.ne     p1, v2, v3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p2, v4, v5
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.cmp.ne     p1, v3, v4
    p.and        p2, p4, p1
    v.extract    s3, v1, #12
    p.and        p1, p2, p3
    v.extract    s6, v6, #12
    vf.add       v3, v2, v14
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s6
    v.rsqrt.approx v7, v3                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v9, [s1, #0]
    v.extract    s3, v12, #12
    v.cmp.ne     p1, v2, v4
    v.cmp.ne     p2, v5, v8
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.extract    s3, v1, #12
    v.extract    s6, v6, #12
    v.cmp.ne     p1, v2, v4
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p2, p4, p1
    v.cmp.ne     p1, v2, v4
    p.and        p4, p2, p3
    vf.sub       v2, v0, v9
    v.splat      v0, s6
    v.movi       v4, #0
    v.extract    s3, v12, #12
    v.cmp.ne     p2, v0, v4
    v.splat      v0, s3
    v.movi       v4, #0
    p.and        p5, p1, p2
    v.cmp.ne     p1, v0, v4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s4, #0]
    vf.mul       v4, v7, v7
    vf.mul       v5, v7, v11
    p.and        p2, p5, p1
    s.addi       s3, s7, #3904
    vf.fms       v8, v3, v4, v10
    p.and        p1, p2, p3
    v.extract    s6, v1, #12
    v.extract    s8, v6, #12
    vf.mul       v3, v5, v8                      // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s5, #0]
    v.splat      v5, s6
    v.movi       v8, #0
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v9, v3, v7
    v.splat      v3, s8
    vf.mul       v7, v2, v9
    v.movi       v2, #0
    v.extract    s6, v12, #12
    v.cmp.ne     p1, v5, v8
    vf.mul       v5, v7, v0
    v.ld.w       v0, [s3, #0]
    v.extract    s3, v1, #13
    v.extract    s8, v6, #13
    v.splat      v7, s3
    v.movi       v8, #0
    v.splat      v9, s8
    v.movi       v13, #0
    vf.add       v16, v5, v4
    v.extract    s3, v12, #13
    v.cmp.ne     p2, v3, v2
    v.splat      v2, s6
    v.movi       v3, #0
    v.cmp.ne     p4, v7, v8
    p.and        p5, p1, p2
    v.cmp.ne     p1, v9, v13
    p.and        p2, p4, p1
    v.cmp.ne     p1, v2, v3
    vf.max.prop  v2, v16, v15
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v3, v4
    p.and        p5, p2, p1
    p.and        p1, p4, p3
    s.movz       s3, #13
    p.and        p2, p5, p3
    @p1 v.st.scatter.w [s10, v0], v2
    a.vread      v0, a0, s3
    v.extract    s3, v1, #13
    v.extract    s6, v6, #13
    v.splat      v2, s3
    v.movi       v3, #0
    v.splat      v4, s6
    v.movi       v5, #0
    v.extract    s3, v12, #13
    v.cmp.ne     p1, v2, v3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p2, v4, v5
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.cmp.ne     p1, v3, v4
    p.and        p2, p4, p1
    v.extract    s3, v1, #13
    p.and        p1, p2, p3
    v.extract    s6, v6, #13
    vf.add       v3, v2, v14
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s6
    v.rsqrt.approx v7, v3                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v9, [s1, #0]
    v.extract    s3, v12, #13
    v.cmp.ne     p1, v2, v4
    v.cmp.ne     p2, v5, v8
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.extract    s3, v1, #13
    v.extract    s6, v6, #13
    v.cmp.ne     p1, v2, v4
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p2, p4, p1
    v.cmp.ne     p1, v2, v4
    p.and        p4, p2, p3
    vf.sub       v2, v0, v9
    v.splat      v0, s6
    v.movi       v4, #0
    v.extract    s3, v12, #13
    v.cmp.ne     p2, v0, v4
    v.splat      v0, s3
    v.movi       v4, #0
    p.and        p5, p1, p2
    v.cmp.ne     p1, v0, v4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s4, #0]
    vf.mul       v4, v7, v7
    vf.mul       v5, v7, v11
    p.and        p2, p5, p1
    s.addi       s3, s7, #3968
    vf.fms       v8, v3, v4, v10
    p.and        p1, p2, p3
    v.extract    s6, v1, #13
    v.extract    s8, v6, #13
    vf.mul       v3, v5, v8                      // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s5, #0]
    v.splat      v5, s6
    v.movi       v8, #0
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v9, v3, v7
    v.splat      v3, s8
    vf.mul       v7, v2, v9
    v.movi       v2, #0
    v.extract    s6, v12, #13
    v.cmp.ne     p1, v5, v8
    vf.mul       v5, v7, v0
    v.ld.w       v0, [s3, #0]
    v.extract    s3, v1, #14
    v.extract    s8, v6, #14
    v.splat      v7, s3
    v.movi       v8, #0
    v.splat      v9, s8
    v.movi       v13, #0
    vf.add       v16, v5, v4
    v.extract    s3, v12, #14
    v.cmp.ne     p2, v3, v2
    v.splat      v2, s6
    v.movi       v3, #0
    v.cmp.ne     p4, v7, v8
    p.and        p5, p1, p2
    v.cmp.ne     p1, v9, v13
    p.and        p2, p4, p1
    v.cmp.ne     p1, v2, v3
    vf.max.prop  v2, v16, v15
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v3, v4
    p.and        p5, p2, p1
    p.and        p1, p4, p3
    s.movz       s3, #14
    p.and        p2, p5, p3
    @p1 v.st.scatter.w [s10, v0], v2
    a.vread      v0, a0, s3
    v.extract    s3, v1, #14
    v.extract    s6, v6, #14
    v.splat      v2, s3
    v.movi       v3, #0
    v.splat      v4, s6
    v.movi       v5, #0
    v.extract    s3, v12, #14
    v.cmp.ne     p1, v2, v3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p2, v4, v5
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.cmp.ne     p1, v3, v4
    p.and        p2, p4, p1
    v.extract    s3, v1, #14
    p.and        p1, p2, p3
    v.extract    s6, v6, #14
    vf.add       v3, v2, v14
    v.splat      v2, s3
    v.movi       v4, #0
    v.splat      v5, s6
    v.rsqrt.approx v7, v3                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v9, [s1, #0]
    v.extract    s3, v12, #14
    v.cmp.ne     p1, v2, v4
    v.cmp.ne     p2, v5, v8
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.extract    s3, v1, #14
    v.extract    s6, v6, #14
    v.cmp.ne     p1, v2, v4
    v.splat      v2, s3
    v.movi       v4, #0
    p.and        p2, p4, p1
    v.cmp.ne     p1, v2, v4
    p.and        p4, p2, p3
    vf.sub       v2, v0, v9
    v.splat      v0, s6
    v.movi       v4, #0
    v.extract    s3, v12, #14
    v.cmp.ne     p2, v0, v4
    v.splat      v0, s3
    v.movi       v4, #0
    p.and        p5, p1, p2
    v.cmp.ne     p1, v0, v4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s4, #0]
    vf.mul       v4, v7, v7
    vf.mul       v5, v7, v11
    p.and        p2, p5, p1
    s.addi       s3, s7, #4032
    vf.fms       v8, v3, v4, v10
    p.and        p1, p2, p3
    v.extract    s6, v1, #14
    v.extract    s8, v6, #14
    vf.mul       v3, v5, v8                      // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s5, #0]
    v.splat      v5, s6
    v.movi       v8, #0
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v9, v3, v7
    v.splat      v3, s8
    vf.mul       v7, v2, v9
    v.movi       v2, #0
    v.extract    s6, v12, #14
    v.cmp.ne     p1, v5, v8
    vf.mul       v5, v7, v0
    v.ld.w       v0, [s3, #0]
    v.extract    s3, v1, #15
    v.extract    s8, v6, #15
    v.splat      v7, s3
    v.movi       v8, #0
    v.splat      v9, s8
    v.movi       v13, #0
    vf.add       v16, v5, v4
    v.extract    s3, v12, #15
    v.cmp.ne     p2, v3, v2
    v.splat      v2, s6
    v.movi       v3, #0
    v.cmp.ne     p4, v7, v8
    p.and        p5, p1, p2
    v.cmp.ne     p1, v9, v13
    p.and        p2, p4, p1
    v.cmp.ne     p1, v2, v3
    vf.max.prop  v2, v16, v15
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p5, p1
    v.cmp.ne     p1, v3, v4
    p.and        p5, p2, p1
    p.and        p1, p4, p3
    s.movz       s3, #15
    p.and        p2, p5, p3
    @p1 v.st.scatter.w [s10, v0], v2
    a.vread      v0, a0, s3
    v.extract    s3, v1, #15
    v.extract    s6, v6, #15
    v.splat      v2, s3
    v.movi       v3, #0
    v.splat      v4, s6
    v.movi       v5, #0
    v.extract    s3, v12, #15
    v.cmp.ne     p1, v2, v3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.cmp.ne     p2, v4, v5
    v.splat      v3, s3
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.cmp.ne     p1, v3, v4
    p.and        p2, p4, p1
    v.extract    s2, v1, #15
    p.and        p1, p2, p3
    v.extract    s3, v6, #15
    vf.add       v3, v2, v14
    v.splat      v2, s2
    v.movi       v4, #0
    v.splat      v5, s3
    v.rsqrt.approx v7, v3                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v9, [s1, #0]
    v.extract    s1, v12, #15
    v.cmp.ne     p1, v2, v4
    v.cmp.ne     p2, v5, v8
    v.splat      v2, s1
    v.movi       v4, #0
    p.and        p4, p1, p2
    v.extract    s1, v1, #15
    v.extract    s2, v6, #15
    v.cmp.ne     p1, v2, v4
    v.splat      v2, s1
    v.movi       v4, #0
    p.and        p2, p4, p1
    v.cmp.ne     p1, v2, v4
    p.and        p4, p2, p3
    vf.sub       v2, v0, v9
    v.splat      v0, s2
    v.movi       v4, #0
    v.extract    s1, v12, #15
    v.cmp.ne     p2, v0, v4
    v.splat      v0, s1
    v.movi       v4, #0
    p.and        p5, p1, p2
    v.cmp.ne     p1, v0, v4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s4, #0]
    vf.mul       v4, v7, v7
    vf.mul       v5, v7, v11
    p.and        p2, p5, p1
    s.addi       s1, s7, #4096
    vf.fms       v8, v3, v4, v10
    p.and        p1, p2, p3
    v.extract    s2, v1, #15
    v.extract    s3, v6, #15
    vf.mul       v1, v5, v8                      // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v3, [s5, #0]
    v.splat      v4, s2
    v.movi       v5, #0
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v6, v1, v7
    v.splat      v1, s3
    vf.mul       v7, v2, v6
    v.movi       v2, #0
    v.extract    s2, v12, #15
    v.cmp.ne     p1, v4, v5
    vf.mul       v4, v7, v0
    v.ld.w       v0, [s1, #0]
    v.cmp.ne     p2, v1, v2
    v.splat      v1, s2
    vf.add       v2, v4, v3
    v.movi       v3, #0
    p.and        p4, p1, p2
    v.cmp.ne     p1, v1, v3
    vf.max.prop  v1, v2, v15
    p.and        p2, p4, p1
    p.and        p1, p2, p3
    @p1 v.st.scatter.w [s10, v0], v1
__rctx_next:
    exit
