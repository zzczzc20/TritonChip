    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.rdspecial  s2, arg_base
    s.ld.d       s3, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s5, #512
    .li       s6, #2147483647
    s.mul        s7, s1, s5
    .li       s1, #2147483647
    s.movz       s5, #64
    s.movz       s8, #4
    .li       s9, #68719476752
    .li       s10, #2207613190144
    s.rdspecial  s11, arg_base
    s.ld.d       s12, [s2, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.add        s13, s3, s7                     // this context's own scratch
    s.rdspecial  s3, role_id
    s.addi       s7, s13, #0                     // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.movz       s13, #512
    .li       s14, #2147483647
    s.mul        s15, s3, s13
    .li       s3, #2147483647
    s.movz       s13, #512
    s.movz       s16, #4
    .li       s17, #68719476752
    s.addi       s18, s12, #2048                 // the pointer's constant offset (2048 bytes)
    s.ld.d       s19, [s2, #8]                   // arg_B: device_ptr64 at arg_base+8
    .li       s20, #2207613190144
    s.movz       s21, #0
    s.movz       s21, #0
    s.ld.d       s21, [s2, #16]                  // out_ptr0: device_ptr64 at arg_base+16
    s.movz       s2, #0
    s.st.d       [s7, #0], s18
    s.movz       s18, #0
    s.st.d       [s7, #8], s6
    s.movz       s6, #8
    s.st.d       [s7, #16], s1
    s.movz       s1, #0
    s.cmp.lt     s22, s6, s1
    s.st.d       [s7, #48], s5
    s.cmp.lt     s1, s4, s2
    s.movz       s2, #0
    s.sub        s5, s2, s22
    s.movz       s2, #1
    s.st.d       [s7, #56], s8
    s.sub        s8, s18, s1
    s.movz       s1, #0
    s.xor        s18, s4, s8
    s.st.d       [s7, #88], s9
    s.sub        s9, s18, s8
    s.movz       s18, #0
    s.st.d       [s7, #104], s10
    s.lshri      s10, s9, #3
    fence.release.device
    td.load      d0, [s7]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.xor        s7, s8, s5
    s.movz       s8, #0
    s.ld.d       s22, [s11, #24]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.cmp.lt     s11, s4, s18
    s.add        s18, s22, s15                   // this context's own scratch
    s.xor        s15, s10, s7
    s.muli       s22, s10, #8
    s.sub        s10, s15, s7
    s.movz       s7, #0
    s.addi       s15, s18, #256                  // TensorMap 1: a 2-D tt.load (built once, at entry)
    s.sub        s18, s7, s11
    s.sub        s7, s2, s10
    s.st.d       [s15, #0], s19
    s.min.s      s11, s7, s2
    s.movz       s2, #0
    s.cmp.lt     s7, s11, s1
    s.movz       s1, #1
    s.sub        s19, s8, s7
    s.xor        s7, s4, s18
    s.sub        s8, s9, s22
    s.xor        s8, s6, s5
    s.movz       s9, #0
    s.sub        s22, s7, s18
    s.st.d       [s15, #8], s14
    s.xor        s7, s11, s19
    s.sub        s14, s8, s5
    s.sub        s5, s7, s19
    s.st.d       [s15, #16], s3
    s.addi       s3, s2, #0
    s.addi       s2, s9, #0
    s.st.d       [s15, #48], s13
    s.cmp.eq     s7, s5, s1
    s.st.d       [s15, #56], s16
    s.st.d       [s15, #88], s17
    s.st.d       [s15, #104], s20
    fence.release.device
    td.load      d1, [s15]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.mov        s3, s22
    br.nz        s7, sdiv_done_1
    s.movz       s1, #0
    s.movz       s7, #31
    s.mov        s3, s1
    s.addi       s1, s7, #0
sdiv_2:
    s.lshr       s7, s22, s1
    s.shli       s8, s2, #1
    s.andi       s9, s7, #1
    s.movz       s7, #0
    s.or         s13, s8, s9
    s.movz       s8, #1
    s.cmp.geu    s9, s13, s5
    s.shl        s14, s8, s1
    s.sub        s8, s7, s9
    s.subi       s7, s1, #1
    s.and        s9, s5, s8
    s.and        s15, s14, s8
    s.sub        s8, s13, s9
    s.or         s9, s3, s15
    s.mov        s2, s8
    s.mov        s3, s9
    s.mov        s1, s7
    s.movz       s7, #0
    s.cmp.ge     s8, s1, s7
    br.nz        s8, sdiv_2
sdiv_done_1:
    s.movz       s1, #0
    s.movz       s3, #0
    s.cmp.lt     s5, s4, s1
    s.movz       s1, #0
    s.sub        s7, s3, s5
    s.movz       s3, #0
    s.xor        s5, s4, s7
    s.movz       s4, #0
    s.sub        s8, s5, s7
    s.cmp.lt     s5, s11, s1
    s.lshri      s1, s8, #3
    s.movz       s9, #0
    s.muli       s13, s1, #8
    s.sub        s1, s4, s5
    s.movz       s4, #0
    s.cmp.lt     s5, s6, s9
    s.xor        s9, s11, s1
    s.sub        s11, s8, s13
    s.movz       s8, #0
    s.xor        s13, s11, s7
    s.xor        s11, s2, s18
    s.sub        s2, s13, s7
    s.sub        s7, s8, s5
    s.cmp.lt     s5, s2, s3
    s.sub        s3, s9, s1
    s.sub        s8, s4, s5
    s.movz       s4, #0
    s.xor        s5, s2, s8
    s.movz       s2, #1
    s.sub        s9, s11, s18
    s.xor        s11, s6, s7
    s.sub        s6, s5, s8
    s.movz       s5, #0
    s.addi       s13, s4, #0
    s.cmp.eq     s4, s3, s2
    s.add        s2, s10, s9
    s.sub        s9, s11, s7
    s.addi       s7, s5, #0
    s.mov        s13, s6
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.movz       s5, #31
    s.mov        s13, s4
    s.addi       s4, s5, #0
sdiv_4:
    s.lshr       s5, s6, s4
    s.shli       s9, s7, #1
    s.andi       s10, s5, #1
    s.movz       s5, #0
    s.or         s11, s9, s10
    s.movz       s9, #1
    s.cmp.geu    s10, s11, s3
    s.shl        s14, s9, s4
    s.sub        s9, s5, s10
    s.subi       s5, s4, #1
    s.and        s10, s3, s9
    s.and        s15, s14, s9
    s.sub        s9, s11, s10
    s.or         s10, s13, s15
    s.mov        s7, s9
    s.mov        s13, s10
    s.mov        s4, s5
    s.movz       s5, #0
    s.cmp.ge     s9, s4, s5
    br.nz        s9, sdiv_4
sdiv_done_3:
    s.rdspecial  s3, pid.z
    s.rdspecial  s4, npid.y
    s.xor        s5, s8, s1
    s.mul        s1, s3, s4
    s.rdspecial  s3, pid.y
    s.xor        s4, s13, s5
    s.movz       s6, #16
    s.movz       s7, #31
    s.add        s8, s3, s1
    s.sub        s1, s4, s5
    s.mul        s3, s2, s6
    s.min.s      s4, s8, s7
    s.movz       s5, #1024
    s.mul        s7, s1, s6
    s.movz       s9, #4096
    s.mul        s10, s4, s5
    s.mul        s5, s4, s9
    w.def        w0, #48, #16                    // v48..v63
    mb.arm       s4, b0, #0, #1                  // 0 arrival(s), 1 operation(s)
    s.andi       s9, s3, #15
    s.andi       s11, s7, #127
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s13, s9                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s14, s10                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.w w0, d0, s13, s4
    mb.wait      s4
    w.def        w1, #32, #16                    // v32..v47
    mb.arm       s10, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s13, #0
    s.add        s14, s11, s5
    v.movi       v0, #0
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s15, s13                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s16, s14                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.w w1, d1, s15, s10
    mb.wait      s10
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s5, #0
    s.movz       s13, #0
    v.splat      v1, s2
    v.extract    s2, v48, #0
    v.splat      v2, s13
    v.splat      v3, s2
    v.splat      v4, s1
    v.splat      v5, s13
    v.iota       v6                              // arange(0, VLEN)
    v.cmp.ge     p1, v1, v2
    vf.fma       v1, v3, v32, v0
    v.extract    s1, v48, #1
    v.splat      v2, s3
    v.splat      v3, s1
    v.splat      v7, s7
    v.cmp.ge     p1, v4, v5
    vf.fma       v4, v3, v33, v1
    v.extract    s1, v48, #2
    v.splat      v1, s9
    v.splat      v3, s1
    v.add        v5, v2, v6
    v.extract    s1, v48, #3
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s1
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s11
    v.add        v8, v7, v6
    vf.fma       v6, v3, v35, v2
    v.extract    s1, v48, #4
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s1
    v.add        v7, v1, v4
    v.extract    s1, v48, #5
    vf.fma       v1, v3, v36, v6
    v.splat      v3, s1
    v.add        v4, v5, v2
    v.extract    s1, v48, #6
    v.extract    s2, v48, #7
    vf.fma       v2, v3, v37, v1
    v.splat      v1, s1
    v.splat      v3, s2
    s.addi       s1, s12, #2048                  // &arg_A[512] (a constant offset, x4)
    v.extract    s1, v48, #8
    vf.fma       v4, v1, v38, v2
    v.splat      v1, s1
    v.extract    s1, v48, #9
    v.extract    s2, v48, #10
    v.splat      v2, s1
    vf.fma       v5, v3, v39, v4
    v.splat      v3, s2
    v.extract    s1, v48, #11
    v.extract    s2, v48, #12
    v.splat      v4, s1
    vf.fma       v6, v1, v40, v5
    v.splat      v1, s2
    v.extract    s1, v48, #13
    v.extract    s2, v48, #14
    v.splat      v5, s1
    vf.fma       v7, v2, v41, v6
    v.splat      v2, s2
    v.extract    s1, v48, #15
    s.movz       s2, #1
    v.splat      v6, s1
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v4, v43, v8
    vf.fma       v4, v1, v44, v3
    vf.fma       v1, v5, v45, v4
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v6, v47, v3
    a.vwrite     a0, s5, v1
    v.extract    s1, v49, #0
    v.extract    s5, v49, #1
    v.splat      v1, s1
    v.splat      v2, s5
    v.extract    s1, v49, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v49, #3
    v.extract    s5, v49, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s5
    v.extract    s1, v49, #5
    v.extract    s5, v49, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s5
    v.extract    s1, v49, #7
    v.extract    s5, v49, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s5
    v.extract    s1, v49, #9
    v.extract    s5, v49, #10
    v.extract    s9, v49, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v49, #12
    v.extract    s11, v49, #13
    v.extract    s12, v49, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s5
    v.extract    s5, v49, #15
    v.splat      v6, s9
    s.movz       s9, #2
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s11
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s12
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s5
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s2, v1
    v.extract    s1, v50, #0
    v.extract    s2, v50, #1
    v.splat      v1, s1
    v.splat      v2, s2
    v.extract    s1, v50, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v50, #3
    v.extract    s2, v50, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s2
    v.extract    s1, v50, #5
    v.extract    s2, v50, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s2
    v.extract    s1, v50, #7
    v.extract    s2, v50, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s2
    v.extract    s1, v50, #9
    v.extract    s2, v50, #10
    v.extract    s5, v50, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v50, #12
    v.extract    s11, v50, #13
    v.extract    s12, v50, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s2
    v.extract    s2, v50, #15
    v.splat      v6, s5
    s.movz       s5, #3
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s11
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s12
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s2
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s9, v1
    v.extract    s1, v51, #0
    v.extract    s2, v51, #1
    v.splat      v1, s1
    v.splat      v2, s2
    v.extract    s1, v51, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v51, #3
    v.extract    s2, v51, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s2
    v.extract    s1, v51, #5
    v.extract    s2, v51, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s2
    v.extract    s1, v51, #7
    v.extract    s2, v51, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s2
    v.extract    s1, v51, #9
    v.extract    s2, v51, #10
    v.extract    s9, v51, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v51, #12
    v.extract    s11, v51, #13
    v.extract    s12, v51, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s2
    v.extract    s2, v51, #15
    v.splat      v6, s9
    s.movz       s9, #4
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s11
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s12
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s2
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s5, v1
    v.extract    s1, v52, #0
    v.extract    s2, v52, #1
    v.splat      v1, s1
    v.splat      v2, s2
    v.extract    s1, v52, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v52, #3
    v.extract    s2, v52, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s2
    v.extract    s1, v52, #5
    v.extract    s2, v52, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s2
    v.extract    s1, v52, #7
    v.extract    s2, v52, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s2
    v.extract    s1, v52, #9
    v.extract    s2, v52, #10
    v.extract    s5, v52, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v52, #12
    v.extract    s11, v52, #13
    v.extract    s12, v52, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s2
    v.extract    s2, v52, #15
    v.splat      v6, s5
    s.movz       s5, #5
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s11
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s12
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s2
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s9, v1
    v.extract    s1, v53, #0
    v.extract    s2, v53, #1
    v.splat      v1, s1
    v.splat      v2, s2
    v.extract    s1, v53, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v53, #3
    v.extract    s2, v53, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s2
    v.extract    s1, v53, #5
    v.extract    s2, v53, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s2
    v.extract    s1, v53, #7
    v.extract    s2, v53, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s2
    v.extract    s1, v53, #9
    v.extract    s2, v53, #10
    v.extract    s9, v53, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v53, #12
    v.extract    s11, v53, #13
    v.extract    s12, v53, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s2
    v.extract    s2, v53, #15
    v.splat      v6, s9
    s.movz       s9, #6
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s11
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s12
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s2
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s5, v1
    v.extract    s1, v54, #0
    v.extract    s2, v54, #1
    v.splat      v1, s1
    v.splat      v2, s2
    v.extract    s1, v54, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v54, #3
    v.extract    s2, v54, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s2
    v.extract    s1, v54, #5
    v.extract    s2, v54, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s2
    v.extract    s1, v54, #7
    v.extract    s2, v54, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s2
    v.extract    s1, v54, #9
    v.extract    s2, v54, #10
    v.extract    s5, v54, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v54, #12
    v.extract    s11, v54, #13
    v.extract    s12, v54, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s2
    v.extract    s2, v54, #15
    v.splat      v6, s5
    s.movz       s5, #7
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s11
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s12
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s2
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s9, v1
    v.extract    s1, v55, #0
    v.extract    s2, v55, #1
    v.splat      v1, s1
    v.splat      v2, s2
    v.extract    s1, v55, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v55, #3
    v.extract    s2, v55, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s2
    v.extract    s1, v55, #5
    v.extract    s2, v55, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s2
    v.extract    s1, v55, #7
    v.extract    s2, v55, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s2
    v.extract    s1, v55, #9
    v.extract    s2, v55, #10
    v.extract    s9, v55, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v55, #12
    v.extract    s11, v55, #13
    v.extract    s12, v55, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s2
    v.extract    s2, v55, #15
    v.splat      v6, s9
    s.movz       s9, #8
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s11
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s12
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s2
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s5, v1
    v.extract    s1, v56, #0
    v.extract    s2, v56, #1
    v.splat      v1, s1
    v.splat      v2, s2
    v.extract    s1, v56, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v56, #3
    v.extract    s2, v56, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s2
    v.extract    s1, v56, #5
    v.extract    s2, v56, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s2
    v.extract    s1, v56, #7
    v.extract    s2, v56, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s2
    v.extract    s1, v56, #9
    v.extract    s2, v56, #10
    v.extract    s5, v56, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v56, #12
    v.extract    s11, v56, #13
    v.extract    s12, v56, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s2
    v.extract    s2, v56, #15
    v.splat      v6, s5
    s.movz       s5, #9
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s11
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s12
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s2
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s9, v1
    v.extract    s1, v57, #0
    v.extract    s2, v57, #1
    v.splat      v1, s1
    v.splat      v2, s2
    v.extract    s1, v57, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v57, #3
    v.extract    s2, v57, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s2
    v.extract    s1, v57, #5
    v.extract    s2, v57, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s2
    v.extract    s1, v57, #7
    v.extract    s2, v57, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s2
    v.extract    s1, v57, #9
    v.extract    s2, v57, #10
    v.extract    s9, v57, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v57, #12
    v.extract    s11, v57, #13
    v.extract    s12, v57, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s2
    v.extract    s2, v57, #15
    v.splat      v6, s9
    s.movz       s9, #10
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s11
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s12
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s2
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s5, v1
    v.extract    s1, v58, #0
    v.extract    s2, v58, #1
    v.splat      v1, s1
    v.splat      v2, s2
    v.extract    s1, v58, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v58, #3
    v.extract    s2, v58, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s2
    v.extract    s1, v58, #5
    v.extract    s2, v58, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s2
    v.extract    s1, v58, #7
    v.extract    s2, v58, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s2
    v.extract    s1, v58, #9
    v.extract    s2, v58, #10
    v.extract    s5, v58, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v58, #12
    v.extract    s11, v58, #13
    v.extract    s12, v58, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s2
    v.extract    s2, v58, #15
    v.splat      v6, s5
    s.movz       s5, #11
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s11
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s12
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s2
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s9, v1
    v.extract    s1, v59, #0
    v.extract    s2, v59, #1
    v.splat      v1, s1
    v.splat      v2, s2
    v.extract    s1, v59, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v59, #3
    v.extract    s2, v59, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s2
    v.extract    s1, v59, #5
    v.extract    s2, v59, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s2
    v.extract    s1, v59, #7
    v.extract    s2, v59, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s2
    v.extract    s1, v59, #9
    v.extract    s2, v59, #10
    v.extract    s9, v59, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v59, #12
    v.extract    s11, v59, #13
    v.extract    s12, v59, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s2
    v.extract    s2, v59, #15
    v.splat      v6, s9
    s.movz       s9, #12
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s11
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s12
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s2
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s5, v1
    v.extract    s1, v60, #0
    v.extract    s2, v60, #1
    v.splat      v1, s1
    v.splat      v2, s2
    v.extract    s1, v60, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v60, #3
    v.extract    s2, v60, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s2
    v.extract    s1, v60, #5
    v.extract    s2, v60, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s2
    v.extract    s1, v60, #7
    v.extract    s2, v60, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s2
    v.extract    s1, v60, #9
    v.extract    s2, v60, #10
    v.extract    s5, v60, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v60, #12
    v.extract    s11, v60, #13
    v.extract    s12, v60, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s2
    v.extract    s2, v60, #15
    v.splat      v6, s5
    s.movz       s5, #13
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s11
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s12
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s2
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s9, v1
    v.extract    s1, v61, #0
    v.extract    s2, v61, #1
    v.splat      v1, s1
    v.splat      v2, s2
    v.extract    s1, v61, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v61, #3
    v.extract    s2, v61, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s2
    v.extract    s1, v61, #5
    v.extract    s2, v61, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s2
    v.extract    s1, v61, #7
    v.extract    s2, v61, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s2
    v.extract    s1, v61, #9
    v.extract    s2, v61, #10
    v.extract    s9, v61, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v61, #12
    v.extract    s11, v61, #13
    v.extract    s12, v61, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s2
    v.extract    s2, v61, #15
    v.splat      v6, s9
    s.movz       s9, #14
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s11
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s12
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s2
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s5, v1
    v.extract    s1, v62, #0
    v.extract    s2, v62, #1
    v.splat      v1, s1
    v.splat      v2, s2
    v.extract    s1, v62, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v62, #3
    v.extract    s2, v62, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s2
    v.extract    s1, v62, #5
    v.extract    s2, v62, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s2
    v.extract    s1, v62, #7
    v.extract    s2, v62, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s2
    v.extract    s1, v62, #9
    v.extract    s2, v62, #10
    v.extract    s5, v62, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v62, #12
    v.extract    s11, v62, #13
    v.extract    s12, v62, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s2
    v.extract    s2, v62, #15
    v.splat      v6, s5
    s.movz       s5, #15
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s11
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s12
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s2
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s9, v1
    v.extract    s1, v63, #0
    v.extract    s2, v63, #1
    v.splat      v1, s1
    v.splat      v2, s2
    v.extract    s1, v63, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v0, s1
    v.extract    s1, v63, #3
    v.extract    s2, v63, #4
    v.splat      v1, s1
    vf.fma       v4, v2, v33, v3
    v.splat      v2, s2
    v.extract    s1, v63, #5
    v.extract    s2, v63, #6
    v.splat      v3, s1
    vf.fma       v5, v0, v34, v4
    v.splat      v0, s2
    v.extract    s1, v63, #7
    v.extract    s2, v63, #8
    v.splat      v4, s1
    vf.fma       v6, v1, v35, v5
    v.splat      v1, s2
    v.extract    s1, v63, #9
    v.extract    s2, v63, #10
    v.splat      v5, s1
    vf.fma       v7, v2, v36, v6
    v.splat      v2, s2
    v.extract    s1, v63, #11
    v.extract    s2, v63, #12
    v.extract    s9, v63, #13
    vf.fma       v6, v3, v37, v7
    v.splat      v3, s1
    v.extract    s1, v63, #14
    v.extract    s11, v63, #15
    v.splat      v7, s2
    vf.fma       v8, v0, v38, v6
    v.splat      v0, s9
    s.movz       s2, #2048
    s.muli       s9, s7, #4                      // a runtime tile origin, x4
    s.mul        s12, s8, s2
    vf.fma       v6, v4, v39, v8
    v.splat      v4, s1
    s.movz       s1, #0
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s2, #0
    s.add        s13, s1, s3                     // the tile origin
    vf.fma       v8, v1, v40, v6
    v.splat      v1, s11
    s.movz       s1, #0
    s.muli       s11, s3, #512                   // a runtime tile origin, x512
    s.movz       s3, #32
    vf.fma       v6, v5, v41, v8
    s.add        s14, s1, s7                     // the tile origin
    v.iota       v5                              // arange(0, VLEN)
    s.muli       s1, s12, #4                     // a runtime tile origin, x4
    s.add        s7, s21, s9                     // the tile origin
    vf.fma       v8, v2, v42, v6
    v.splat      v2, s14
    s.movz       s9, #128
    s.add        s12, s7, s11                    // the tile origin
    v.add        v6, v5, v2
    vf.fma       v2, v3, v43, v8
    v.movi       v3, #0
    v.splat      v5, s13
    s.add        s7, s12, s1                     // the tile origin
    s.movz       s1, #1
    vf.fma       v8, v7, v44, v2
    v.splat      v2, s6
    s.addi       s6, s13, #1
    s.addi       s11, s7, #512                   // row 1
    v.cmp.lt     p1, v5, v2
    vf.fma       v5, v0, v45, v8
    v.splat      v0, s9
    v.splat      v7, s8
    v.cmp.lt     p2, v6, v0
    vf.fma       v0, v4, v46, v5
    v.splat      v4, s3
    p.and        p3, p1, p2
    v.splat      v5, s6
    v.cmp.lt     p1, v7, v4
    vf.fma       v4, v1, v47, v0
    p.and        p4, p3, p1
    v.cmp.lt     p3, v5, v2
    p.and        p5, p3, p2
    s.movz       s3, #2
    a.vwrite     a0, s5, v4
    a.vread      v0, a0, s2
    p.and        p3, p5, p1
    s.addi       s2, s13, #2
    vf.add       v1, v0, v3
    v.splat      v0, s2
    s.addi       s2, s7, #1024                   // row 2
    s.movz       s5, #3
    s.addi       s6, s13, #3
    @p4 v.st.w       [s7, #0], v1
    a.vread      v1, a0, s1
    v.cmp.lt     p4, v0, v2
    p.and        p5, p4, p2
    vf.add       v0, v1, v3
    p.and        p4, p5, p1
    v.splat      v1, s6
    s.addi       s1, s7, #1536                   // row 3
    s.movz       s6, #4
    s.addi       s8, s13, #4
    s.addi       s9, s7, #2048                   // row 4
    v.splat      v4, s8
    s.movz       s8, #5
    s.addi       s12, s13, #5
    s.addi       s14, s7, #2560                  // row 5
    v.splat      v5, s12
    s.movz       s12, #6
    s.addi       s15, s13, #6
    @p3 v.st.w       [s11, #0], v0
    a.vread      v0, a0, s3
    v.cmp.lt     p3, v1, v2
    p.and        p5, p3, p2
    vf.add       v1, v0, v3
    p.and        p3, p5, p1
    v.splat      v0, s15
    s.addi       s3, s7, #3072                   // row 6
    s.movz       s11, #7
    s.addi       s15, s13, #7
    s.addi       s16, s7, #3584                  // row 7
    v.splat      v6, s15
    @p4 v.st.w       [s2, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p4, v4, v2
    p.and        p5, p4, p2
    vf.add       v4, v1, v3
    p.and        p4, p5, p1
    s.movz       s2, #8
    s.addi       s5, s13, #8
    s.addi       s15, s7, #4096                  // row 8
    v.splat      v1, s5
    @p3 v.st.w       [s1, #0], v4
    a.vread      v4, a0, s6
    v.cmp.lt     p3, v5, v2
    p.and        p5, p3, p2
    vf.add       v5, v4, v3
    p.and        p3, p5, p1
    s.movz       s1, #9
    s.addi       s5, s13, #9
    s.addi       s6, s7, #4608                   // row 9
    v.splat      v4, s5
    @p4 v.st.w       [s9, #0], v5
    a.vread      v5, a0, s8
    v.cmp.lt     p4, v0, v2
    p.and        p5, p4, p2
    vf.add       v0, v5, v3
    p.and        p4, p5, p1
    s.movz       s5, #10
    s.addi       s8, s13, #10
    s.addi       s9, s7, #5120                   // row 10
    v.splat      v5, s8
    @p3 v.st.w       [s14, #0], v0
    a.vread      v0, a0, s12
    v.cmp.lt     p3, v6, v2
    p.and        p5, p3, p2
    vf.add       v6, v0, v3
    p.and        p3, p5, p1
    s.movz       s8, #11
    s.addi       s12, s13, #11
    s.addi       s14, s7, #5632                  // row 11
    v.splat      v0, s12
    @p4 v.st.w       [s3, #0], v6
    a.vread      v6, a0, s11
    v.cmp.lt     p4, v1, v2
    p.and        p5, p4, p2
    vf.add       v1, v6, v3
    p.and        p4, p5, p1
    s.movz       s3, #12
    s.addi       s11, s13, #12
    s.addi       s12, s7, #6144                  // row 12
    v.splat      v6, s11
    @p3 v.st.w       [s16, #0], v1
    a.vread      v1, a0, s2
    v.cmp.lt     p3, v4, v2
    p.and        p5, p3, p2
    vf.add       v4, v1, v3
    p.and        p3, p5, p1
    s.movz       s2, #13
    s.addi       s11, s13, #13
    s.addi       s16, s7, #6656                  // row 13
    v.splat      v1, s11
    @p4 v.st.w       [s15, #0], v4
    a.vread      v4, a0, s1
    v.cmp.lt     p4, v5, v2
    p.and        p5, p4, p2
    vf.add       v5, v4, v3
    p.and        p4, p5, p1
    s.movz       s1, #14
    s.addi       s11, s13, #14
    s.addi       s15, s7, #7168                  // row 14
    v.splat      v4, s11
    @p3 v.st.w       [s6, #0], v5
    a.vread      v5, a0, s5
    v.cmp.lt     p3, v0, v2
    p.and        p5, p3, p2
    vf.add       v0, v5, v3
    p.and        p3, p5, p1
    s.movz       s5, #15
    s.addi       s6, s13, #15
    s.addi       s11, s7, #7680                  // row 15
    v.splat      v5, s6
    @p4 v.st.w       [s9, #0], v0
    a.vread      v0, a0, s8
    v.cmp.lt     p4, v6, v2
    p.and        p5, p4, p2
    vf.add       v6, v0, v3
    p.and        p4, p5, p1
    @p3 v.st.w       [s14, #0], v6
    a.vread      v0, a0, s3
    v.cmp.lt     p3, v1, v2
    p.and        p5, p3, p2
    vf.add       v1, v0, v3
    p.and        p3, p5, p1
    @p4 v.st.w       [s12, #0], v1
    a.vread      v0, a0, s2
    v.cmp.lt     p4, v4, v2
    p.and        p5, p4, p2
    vf.add       v1, v0, v3
    p.and        p4, p5, p1
    @p3 v.st.w       [s16, #0], v1
    a.vread      v0, a0, s1
    v.cmp.lt     p3, v5, v2
    p.and        p5, p3, p2
    vf.add       v1, v0, v3
    p.and        p2, p5, p1
    @p4 v.st.w       [s15, #0], v1
    a.vread      v0, a0, s5
    vf.add       v1, v0, v3
    @p2 v.st.w       [s11, #0], v1
__rctx_next:
    exit
