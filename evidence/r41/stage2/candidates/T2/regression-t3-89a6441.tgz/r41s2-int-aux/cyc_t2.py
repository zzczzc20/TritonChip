import sys,re
def load(f):
    d={}
    for l in open(f,errors='replace'):
        m=re.match(r'^\s+(.+?)\s+(PASS|FAIL)\s+cycles=(\d+)',l)
        if m: d.setdefault(m[1],[]).append((m[2],int(m[3])))
    return d
b,n=load(sys.argv[1]),load(sys.argv[2])
tb=tn=0; diffs=[]; npass=sum(1 for v in n.values() for x in v if x[0]=='PASS'); nfail=sum(1 for v in n.values() for x in v if x[0]!='PASS')
for k in n:
    if k in b and len(b[k])==len(n[k]):
        for (sb,cb),(sn,cn) in zip(b[k],n[k]):
            tb+=cb; tn+=cn
            if cb!=cn: diffs.append((k,cb,cn))
print(f"{sys.argv[2].split('/')[-1]}: PASS {npass} FAIL {nfail}; common total {tb} -> {tn} ({(tn-tb)/max(tb,1)*100:+.3f}%); {len(diffs)} differ", ' '.join(f"{k}:{cb}->{cn}" for k,cb,cn in diffs[:8]))
