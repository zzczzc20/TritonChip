    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, role_id
    s.movz       s2, #512
    s.rdspecial  s3, arg_base
    s.mul        s5, s1, s2
    s.ld.d       s1, [s3, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s2, arg_base
    s.rdspecial  s3, role_id
    s.movz       s6, #512
    s.add        s7, s1, s5                      // this context's own scratch
    s.ld.d       s1, [s2, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.addi       s5, s7, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    .li       s7, #2147483647
    .li       s8, #2147483647
    s.movz       s9, #2048
    s.movz       s10, #2
    .li       s11, #68719476752
    .li       s12, #8589934592
    s.rdspecial  s13, arg_base
    s.mul        s14, s3, s6
    s.ld.d       s3, [s2, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.movz       s6, #16
    .li       s15, #2147483647
    s.ld.d       s16, [s2, #16]                  // out_ptr0: device_ptr64 at arg_base+16
    s.movz       s2, #0
    s.movz       s17, #0
    s.movz       s18, #0
    s.movz       s19, #0
    s.cmp.lt     s20, s6, s18
    s.st.d       [s5, #0], s1
    s.sub        s1, s19, s20
    .li       s18, #2147483647
    s.st.d       [s5, #8], s7
    s.movz       s7, #2048
    s.movz       s19, #2
    s.st.d       [s5, #16], s8
    .li       s8, #68719476752
    .li       s20, #8589934592
    s.st.d       [s5, #48], s9
    s.xor        s9, s6, s1
    s.movz       s21, #0
    s.movz       s21, #32
    s.st.d       [s5, #56], s10
    s.cmp.lt     s10, s4, s2
    s.movz       s2, #1
    s.sub        s22, s17, s10
    s.movz       s10, #0
    s.st.d       [s5, #88], s11
    s.xor        s11, s4, s22
    s.movz       s17, #0
    s.sub        s17, s11, s22
    s.st.d       [s5, #104], s12
    s.lshri      s11, s17, #4
    fence.release.device
    td.load      d0, [s5]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.xor        s5, s22, s1
    s.movz       s12, #0
    s.ld.d       s22, [s13, #24]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.sub        s13, s9, s1
    s.xor        s1, s11, s5
    s.movz       s9, #0
    s.sub        s13, s1, s5
    s.movz       s1, #0
    s.sub        s5, s21, s13
    s.muli       s21, s11, #16
    s.min.s      s11, s5, s2
    s.add        s5, s22, s14                    // this context's own scratch
    s.cmp.lt     s14, s4, s12
    s.movz       s12, #0
    s.addi       s22, s5, #256                   // TensorMap 1: a tile contiguous down its columns (built once, at entry)
    s.cmp.lt     s5, s11, s10
    s.sub        s10, s1, s14
    s.movz       s1, #1
    s.st.d       [s22, #0], s3
    s.sub        s3, s9, s5
    s.xor        s5, s4, s10
    s.movz       s9, #0
    s.st.d       [s22, #8], s15
    s.xor        s14, s11, s3
    s.sub        s15, s5, s10
    s.st.d       [s22, #16], s18
    s.sub        s5, s14, s3
    s.addi       s3, s12, #0
    s.st.d       [s22, #48], s7
    s.cmp.eq     s7, s5, s1
    s.sub        s1, s17, s21
    s.st.d       [s22, #56], s19
    s.addi       s1, s9, #0
    s.st.d       [s22, #88], s8
    s.st.d       [s22, #104], s20
    fence.release.device
    td.load      d1, [s22]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.mov        s3, s15
    br.nz        s7, sdiv_done_1
    s.movz       s7, #0
    s.movz       s8, #31
    s.mov        s3, s7
    s.addi       s7, s8, #0
sdiv_2:
    s.lshr       s8, s15, s7
    s.shli       s9, s1, #1
    s.andi       s12, s8, #1
    s.movz       s8, #0
    s.or         s14, s9, s12
    s.movz       s9, #1
    s.cmp.geu    s12, s14, s5
    s.shl        s17, s9, s7
    s.sub        s9, s8, s12
    s.subi       s8, s7, #1
    s.and        s12, s5, s9
    s.and        s18, s17, s9
    s.sub        s9, s14, s12
    s.or         s12, s3, s18
    s.mov        s1, s9
    s.mov        s3, s12
    s.mov        s7, s8
    s.movz       s8, #0
    s.cmp.ge     s9, s7, s8
    br.nz        s9, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s5, #0
    s.cmp.lt     s7, s4, s3
    s.movz       s3, #0
    s.sub        s8, s5, s7
    s.movz       s5, #0
    s.xor        s7, s4, s8
    s.movz       s4, #0
    s.sub        s9, s7, s8
    s.cmp.lt     s7, s11, s3
    s.lshri      s3, s9, #4
    s.movz       s12, #0
    s.muli       s14, s3, #16
    s.movz       s3, #0
    s.sub        s15, s4, s7
    s.movz       s4, #0
    s.cmp.lt     s7, s6, s12
    s.sub        s12, s9, s14
    s.xor        s9, s11, s15
    s.xor        s11, s12, s8
    s.xor        s12, s1, s10
    s.sub        s1, s11, s8
    s.sub        s8, s4, s7
    s.cmp.lt     s4, s1, s5
    s.sub        s5, s9, s15
    s.sub        s7, s3, s4
    s.movz       s3, #0
    s.xor        s4, s1, s7
    s.movz       s1, #1
    s.sub        s9, s12, s10
    s.xor        s10, s6, s8
    s.sub        s11, s4, s7
    s.movz       s4, #0
    s.addi       s12, s3, #0
    s.cmp.eq     s3, s5, s1
    s.add        s1, s13, s9
    s.sub        s9, s10, s8
    s.addi       s8, s4, #0
    s.mov        s12, s11
    br.nz        s3, sdiv_done_3
    s.movz       s3, #0
    s.movz       s4, #31
    s.mov        s12, s3
    s.addi       s3, s4, #0
sdiv_4:
    s.lshr       s4, s11, s3
    s.shli       s9, s8, #1
    s.andi       s10, s4, #1
    s.movz       s4, #0
    s.or         s13, s9, s10
    s.movz       s9, #1
    s.cmp.geu    s10, s13, s5
    s.shl        s14, s9, s3
    s.sub        s9, s4, s10
    s.subi       s4, s3, #1
    s.and        s10, s5, s9
    s.and        s17, s14, s9
    s.sub        s9, s13, s10
    s.or         s10, s12, s17
    s.mov        s8, s9
    s.mov        s12, s10
    s.mov        s3, s4
    s.movz       s4, #0
    s.cmp.ge     s9, s3, s4
    br.nz        s9, sdiv_4
sdiv_done_3:
    s.xor        s3, s7, s15
    s.mul        s4, s1, s6
    s.xor        s5, s12, s3
    s.movz       s7, #0
    s.sub        s8, s5, s3
    v.splat      v0, s1
    s.mul        s1, s8, s6
    s.andi       s3, s4, #511
    v.splat      v1, s7
    v.splat      v2, s8
    v.splat      v3, s7
    s.andi       s5, s1, #255
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s4
    v.cmp.ge     p1, v0, v1
    v.splat      v0, s1
    v.splat      v1, s3
    v.cmp.ge     p1, v2, v3
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s5
    v.add        v6, v5, v4
    v.iota       v5                              // arange(0, VLEN)
    v.add        v6, v0, v4
    v.add        v0, v1, v2
    v.add        v0, v3, v5
    s.movz       s8, #64
    s.addi       s9, s7, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s7, s9, s8
    br.nz        s7, endfor_6
    s.mul        s7, s9, s6
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s10, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s11, s9, s2
    s.movz       s12, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s13, s3                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s14, s7                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s13, s10
    mb.wait      s10
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s13, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s14, s5                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s7                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s14, s13
    mb.wait      s13
    mb.arm       s7, b2, #0, #1                  // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.f16 a0, v56, v48, s7
    mb.wait      s7
    s.mov        s9, s11
    br.nz        s12, for_5
endfor_6:
    s.movz       s2, #0
    s.muli       s3, s1, #2                      // a runtime tile origin, x2
    s.movz       s5, #0
    s.add        s6, s2, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    s.muli       s2, s4, #512                    // a runtime tile origin, x512
    s.add        s8, s5, s4                      // the tile origin
    s.movz       s4, #512
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s6
    s.movz       s5, #256
    a.vread      v2, a0, s1
    v.splat      v3, s8
    v.splat      v4, s4
    v.add        v5, v0, v1
    v.splat      v0, s5
    s.add        s1, s16, s3                     // the tile origin
    vf.cvt.f32.f16 v1, v2
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v0
    s.add        s3, s1, s2                      // the tile origin
    p.and        p3, p1, p2
    s.movz       s1, #1
    s.addi       s2, s8, #1
    @p3 v.st.h       [s3, #0], v1
    a.vread      v0, a0, s1
    v.splat      v1, s2
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #512                    // row 1
    p.and        p3, p1, p2
    s.movz       s2, #2
    s.addi       s4, s8, #2
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a0, s2
    v.splat      v1, s4
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #1024                   // row 2
    p.and        p3, p1, p2
    s.movz       s2, #3
    s.addi       s4, s8, #3
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a0, s2
    v.splat      v1, s4
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #1536                   // row 3
    p.and        p3, p1, p2
    s.movz       s2, #4
    s.addi       s4, s8, #4
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a0, s2
    v.splat      v1, s4
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #2048                   // row 4
    p.and        p3, p1, p2
    s.movz       s2, #5
    s.addi       s4, s8, #5
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a0, s2
    v.splat      v1, s4
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #2560                   // row 5
    p.and        p3, p1, p2
    s.movz       s2, #6
    s.addi       s4, s8, #6
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a0, s2
    v.splat      v1, s4
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #3072                   // row 6
    p.and        p3, p1, p2
    s.movz       s2, #7
    s.addi       s4, s8, #7
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a0, s2
    v.splat      v1, s4
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #3584                   // row 7
    p.and        p3, p1, p2
    s.movz       s2, #8
    s.addi       s4, s8, #8
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a0, s2
    v.splat      v1, s4
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #4096                   // row 8
    p.and        p3, p1, p2
    s.movz       s2, #9
    s.addi       s4, s8, #9
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a0, s2
    v.splat      v1, s4
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #4608                   // row 9
    p.and        p3, p1, p2
    s.movz       s2, #10
    s.addi       s4, s8, #10
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a0, s2
    v.splat      v1, s4
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #5120                   // row 10
    p.and        p3, p1, p2
    s.movz       s2, #11
    s.addi       s4, s8, #11
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a0, s2
    v.splat      v1, s4
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #5632                   // row 11
    p.and        p3, p1, p2
    s.movz       s2, #12
    s.addi       s4, s8, #12
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a0, s2
    v.splat      v1, s4
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #6144                   // row 12
    p.and        p3, p1, p2
    s.movz       s2, #13
    s.addi       s4, s8, #13
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a0, s2
    v.splat      v1, s4
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #6656                   // row 13
    p.and        p3, p1, p2
    s.movz       s2, #14
    s.addi       s4, s8, #14
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a0, s2
    v.splat      v1, s4
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #7168                   // row 14
    p.and        p3, p1, p2
    s.movz       s2, #15
    s.addi       s4, s8, #15
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a0, s2
    v.splat      v1, s4
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #7680                   // row 15
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
__rctx_next:
    exit
