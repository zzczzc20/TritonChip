# AOT ID: ['0_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /home/zhongchun/r41-stage1/runs/primitive-ir-v2/recurrence/inductor-cache/cz/cczuejtlikhyndli27ddflq6rbswscc36f7oimwdd7sucts532s5.py
# Topologically Sorted Source Nodes: [exp], Original ATen: [aten.exp]
# Source node to ATen node mapping:
#   exp => exp
# Graph fragment:
#   %arg0_1 : Tensor "f32[1, 1][1, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %exp : Tensor "f32[1, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%arg0_1,), kwargs = {})
#   return %exp
triton_poi_fused_exp_0 = async_compile.triton('triton_poi_fused_exp_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'constexpr', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_exp_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_exp_0(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK])
    tmp2 = libdevice.exp(tmp1)
    tl.store(out_ptr0 + (tl.full([XBLOCK], 0, tl.int32).broadcast_to(XBLOCK)), tmp2, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-stage1/runs/primitive-ir-v2/recurrence/inductor-cache/te/cte3irzvddehxbmsjnkohtrtboffrwmnqtzmsxobadnmihbbtgi2.py
# Topologically Sorted Source Nodes: [unsqueeze, matmul, exp, getitem, decayed], Original ATen: [aten.unsqueeze, aten.view, aten.exp, aten.mul, aten.bmm]
# Source node to ATen node mapping:
#   decayed => mul
#   exp => exp
#   getitem => unsqueeze, unsqueeze_1
#   matmul => bmm, view, view_1
#   unsqueeze => unsqueeze_2
# Graph fragment:
#   %arg2_1 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %arg1_1 : Tensor "f32[1, 1, 128, 128][16384, 16384, 128, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %exp : Tensor "f32[1, 1][1, 1]tnca:0" = PlaceHolder[target=exp]
#   %unsqueeze_2 : Tensor "f32[1, 1, 1, 128][128, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg2_1, -2), kwargs = {})
#   %view : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand, [1, 1, 128]), kwargs = {})
#   %exp : Tensor "f32[1, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%arg0_1,), kwargs = {})
#   %unsqueeze : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%exp, 2), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[1, 1, 1, 1][1, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze, 3), kwargs = {})
#   %mul : Tensor "f32[1, 1, 128, 128][16384, 16384, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg1_1, %unsqueeze_1), kwargs = {})
#   %view_1 : Tensor "f32[1, 128, 128][16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_1, [1, 128, 128]), kwargs = {})
#   %bmm : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view, %view_1), kwargs = {})
#   return %bmm
triton_red_fused_bmm_exp_mul_unsqueeze_view_1 = async_compile.triton('triton_red_fused_bmm_exp_mul_unsqueeze_view_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 128, 'r0_': 128},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_bmm_exp_mul_unsqueeze_view_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 66560, 'r0_': 512}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_bmm_exp_mul_unsqueeze_view_1(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 128
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tmp2 = tl.load(in_ptr2 + (0))
    tmp3 = tl.broadcast_to(tmp2, [R0_BLOCK])
    _tmp7 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (x0 + 128*r0_1), r0_mask, eviction_policy='evict_first', other=0.0)
        tmp4 = tmp1 * tmp3
        tmp5 = tmp0 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask, tmp8, _tmp7)
    tmp7 = triton_helpers.promote_to_tensor(tl.sum(_tmp7, 0))
    tl.store(out_ptr0 + (x0), tmp7, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-stage1/runs/primitive-ir-v2/recurrence/inductor-cache/gp/cgp4p2thly7herol6owqryvduovttq2wakqiczeym5q3ntvibc4s.py
# Topologically Sorted Source Nodes: [getitem_2, exp, getitem, decayed, matmul, predicted, sub, getitem_1, delta, getitem_3, mul_2, updated], Original ATen: [aten.unsqueeze, aten.exp, aten.mul, aten.view, aten.squeeze, aten.sub, aten.add]
# Source node to ATen node mapping:
#   decayed => mul
#   delta => mul_1
#   exp => exp
#   getitem => unsqueeze, unsqueeze_1
#   getitem_1 => unsqueeze_3
#   getitem_2 => unsqueeze_4
#   getitem_3 => unsqueeze_5
#   matmul => view_2
#   mul_2 => mul_2
#   predicted => squeeze
#   sub => sub
#   updated => add
# Graph fragment:
#   %arg1_1 : Tensor "f32[1, 1, 128, 128][16384, 16384, 128, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %exp : Tensor "f32[1, 1][1, 1]tnca:0" = PlaceHolder[target=exp]
#   %arg2_1 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %arg3_1 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0" = PlaceHolder[target=arg3_1]
#   %bmm : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0" = PlaceHolder[target=bmm]
#   %arg4_1 : Tensor "f32[1, 1][1, 1]tnca:0" = PlaceHolder[target=arg4_1]
#   %unsqueeze_4 : Tensor "f32[1, 1, 128, 1][128, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg2_1, 3), kwargs = {})
#   %exp : Tensor "f32[1, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%arg0_1,), kwargs = {})
#   %unsqueeze : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%exp, 2), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[1, 1, 1, 1][1, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze, 3), kwargs = {})
#   %mul : Tensor "f32[1, 1, 128, 128][16384, 16384, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg1_1, %unsqueeze_1), kwargs = {})
#   %view_2 : Tensor "f32[1, 1, 1, 128][128, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm, [1, 1, 1, 128]), kwargs = {})
#   %squeeze : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.squeeze.dim](args = (%view_2, -2), kwargs = {})
#   %sub : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%arg3_1, %squeeze), kwargs = {})
#   %unsqueeze_3 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg4_1, 2), kwargs = {})
#   %mul_1 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sub, %unsqueeze_3), kwargs = {})
#   %unsqueeze_5 : Tensor "f32[1, 1, 1, 128][128, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_1, 2), kwargs = {})
#   %mul_2 : Tensor "f32[1, 1, 128, 128][16384, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%unsqueeze_4, %unsqueeze_5), kwargs = {})
#   %add : Tensor "f32[1, 1, 128, 128][16384, 16384, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul, %mul_2), kwargs = {})
#   return %expand_3
triton_poi_fused_add_exp_mul_squeeze_sub_unsqueeze_view_2 = async_compile.triton('triton_poi_fused_add_exp_mul_squeeze_sub_unsqueeze_view_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 16384}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_add_exp_mul_squeeze_sub_unsqueeze_view_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 198144}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_exp_mul_squeeze_sub_unsqueeze_view_2(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 16384
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x2 = xindex
    x1 = xindex // 128
    x0 = (xindex % 128)
    tmp0 = tl.load(in_ptr0 + (x2), None)
    tmp1 = tl.load(in_ptr1 + (0))
    tmp2 = tl.broadcast_to(tmp1, [XBLOCK])
    tmp4 = tl.load(in_ptr2 + (x1), None, eviction_policy='evict_last')
    tmp5 = tl.load(in_ptr3 + (x0), None, eviction_policy='evict_last')
    tmp6 = tl.load(in_ptr4 + (x0), None, eviction_policy='evict_last')
    tmp8 = tl.load(in_ptr5 + (0))
    tmp9 = tl.broadcast_to(tmp8, [XBLOCK])
    tmp3 = tmp0 * tmp2
    tmp7 = tmp5 - tmp6
    tmp10 = tmp7 * tmp9
    tmp11 = tmp4 * tmp10
    tmp12 = tmp3 + tmp11
    tl.store(out_ptr0 + (x2), tmp12, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-stage1/runs/primitive-ir-v2/recurrence/inductor-cache/f2/cf2ihyiz5i226lzjjm2azjhdof2fnrfmhhotp7urzrggmu2ek2wu.py
# Topologically Sorted Source Nodes: [unsqueeze_1, matmul_1], Original ATen: [aten.unsqueeze, aten.view, aten.bmm]
# Source node to ATen node mapping:
#   matmul_1 => bmm_1, view_3, view_4
#   unsqueeze_1 => unsqueeze_6
# Graph fragment:
#   %arg5_1 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0" = PlaceHolder[target=arg5_1]
#   %expand_3 : Tensor "f32[1, 1, 128, 128][16384, 16384, 128, 1]tnca:0" = PlaceHolder[target=expand_3]
#   %unsqueeze_6 : Tensor "f32[1, 1, 1, 128][128, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg5_1, -2), kwargs = {})
#   %view_3 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_2, [1, 1, 128]), kwargs = {})
#   %view_4 : Tensor "f32[1, 128, 128][16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_3, [1, 128, 128]), kwargs = {})
#   %bmm_1 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_3, %view_4), kwargs = {})
#   return %bmm_1
triton_red_fused_bmm_unsqueeze_view_3 = async_compile.triton('triton_red_fused_bmm_unsqueeze_view_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 128, 'r0_': 128},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_bmm_unsqueeze_view_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 66560, 'r0_': 512}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_bmm_unsqueeze_view_3(in_ptr0, in_ptr1, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 128
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    _tmp4 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (x0 + 128*r0_1), r0_mask, eviction_policy='evict_first', other=0.0)
        tmp2 = tmp0 * tmp1
        tmp3 = tl.broadcast_to(tmp2, [R0_BLOCK])
        tmp5 = _tmp4 + tmp3
        _tmp4 = tl.where(r0_mask, tmp5, _tmp4)
    tmp4 = triton_helpers.promote_to_tensor(tl.sum(_tmp4, 0))
    tl.store(out_ptr0 + (x0), tmp4, None)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1 = args
        args.clear()
        assert_size_stride(arg0_1, (1, 1), (1, 1), 'input')
        buf0 = empty_strided((1, 1), (1, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [exp], Original ATen: [aten.exp]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_0.run(arg0_1, buf0, 1, stream=raw_stream0)
        del arg0_1
        assert_size_stride_grouped((arg2_1, arg1_1), ((1, 1, 128), (1, 1, 128, 128)), ((128, 128, 1), (16384, 16384, 128, 1)), 'input')
        buf1 = empty_strided((1, 1, 128), (128, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [unsqueeze, matmul, exp, getitem, decayed], Original ATen: [aten.unsqueeze, aten.view, aten.exp, aten.mul, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_bmm_exp_mul_unsqueeze_view_1.run(arg2_1, arg1_1, buf0, buf1, 128, 128, stream=raw_stream0)
        assert_size_stride_grouped((arg3_1, arg4_1), ((1, 1, 128), (1, 1)), ((128, 128, 1), (1, 1)), 'input')
        buf2 = empty_strided((1, 1, 128, 128), (16384, 16384, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [getitem_2, exp, getitem, decayed, matmul, predicted, sub, getitem_1, delta, getitem_3, mul_2, updated], Original ATen: [aten.unsqueeze, aten.exp, aten.mul, aten.view, aten.squeeze, aten.sub, aten.add]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_exp_mul_squeeze_sub_unsqueeze_view_2.run(arg1_1, buf0, arg2_1, arg3_1, buf1, arg4_1, buf2, 16384, stream=raw_stream0)
        del arg1_1
        del arg2_1
        del arg3_1
        del arg4_1
        del buf0
        assert_size_stride(arg5_1, (1, 1, 128), (128, 128, 1), 'input')
        buf3 = buf1; del buf1  # reuse
        # Topologically Sorted Source Nodes: [unsqueeze_1, matmul_1], Original ATen: [aten.unsqueeze, aten.view, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_bmm_unsqueeze_view_3.run(arg5_1, buf2, buf3, 128, 128, stream=raw_stream0)
        del arg5_1
        return (buf2, buf3, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((1, 1), (1, 1), device='tnca:0', dtype=torch.float32)
    arg1_1 = rand_strided((1, 1, 128, 128), (16384, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg2_1 = rand_strided((1, 1, 128), (128, 128, 1), device='tnca:0', dtype=torch.float32)
    arg3_1 = rand_strided((1, 1, 128), (128, 128, 1), device='tnca:0', dtype=torch.float32)
    arg4_1 = rand_strided((1, 1), (1, 1), device='tnca:0', dtype=torch.float32)
    arg5_1 = rand_strided((1, 1, 128), (128, 128, 1), device='tnca:0', dtype=torch.float32)
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('recurrence', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
