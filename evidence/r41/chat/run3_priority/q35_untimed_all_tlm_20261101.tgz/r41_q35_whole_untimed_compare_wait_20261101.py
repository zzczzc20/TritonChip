import json,subprocess,time
from pathlib import Path
import torch
from safetensors.torch import load_file
h=Path.home(); modes=('base','precise','ieee')
units=[f'r41-q35-whole-untimed-{m}-20261101' for m in modes]
while True:
 states=[subprocess.run(['systemctl','--user','show',u,'-p','ActiveState','--value'],text=True,capture_output=True).stdout.strip() for u in units]
 if all(s not in ('active','activating','reloading') for s in states):break
 time.sleep(60)
roots={m:h/f'r41_q35_whole_untimed_{m}_20261101_diag' for m in modes}
for m,p in roots.items():
 if not (p/'result.json').is_file() or not (p/'logits.safetensors').is_file():raise RuntimeError(f'{m} did not produce complete output')
cpu=load_file(str(h/'r41_q35_multiturn_cpu_diag/logits.safetensors'))['whole']
timed=load_file(str(h/'r41_q35_multiturn_tlm_whole_20261031_diag/logits.safetensors'))['whole']
tensors={m:load_file(str(p/'logits.safetensors'))['whole'] for m,p in roots.items()}
def cmp(a,b):
 af,bf=a.float(),b.float();d=af-bf
 return dict(elements=a.numel(),bit_mismatches=int((a.view(torch.int16)!=b.view(torch.int16)).sum()),relative_l2=float(d.norm()/bf.norm()),max_abs=float(d.abs().max()))
out={'scope':'full-checkpoint untimed functional DP TLM; numerical diagnostic only, no cycle or board claim','baseline_untimed_vs_timed':cmp(tensors['base'],timed),'results':{}}
for m,t in tensors.items():
 r=json.loads((roots[m]/'result.json').read_text())
 out['results'][m]={'top5':r['paths']['whole']['logits'],'vs_cpu':cmp(t,cpu),'vs_timed_baseline':cmp(t,timed)}
(h/'r41_q35_whole_untimed_compare_20261101.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
