source ~/tc_env/env.sh
cd /tmp/r40_p0b_source
~/tc_env/torchenv/bin/python -m pip install --no-deps --target /tmp/r40_p0_solver z3-solver==4.13.0.0 > /tmp/r40_p0_solver_install.log 2>&1
result=$?
echo "$result" > /tmp/r40_p0_solver_install.exit
if [ "$result" -eq 0 ]; then
 python3 tools/r40/dco_registered_ranges.py --z3 /tmp/r40_p0_solver/bin/z3 --out /tmp/r40_p0_registered_proof2 > /tmp/r40_p0_registered_proof2.log 2>&1
 echo $? > /tmp/r40_p0_registered_proof2.exit
fi
