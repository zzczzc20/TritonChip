
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 32, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 256, 'r0_': 16384}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 4}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12(in_ptr0, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 32
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[32, 128], strides=[128, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp9 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp2 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp0 = tl.full([1], 0, tl.int32)
        tmp1 = tmp0 == tmp0
        tmp3 = tl.full([1], 0.0, tl.float32)
        tmp4 = tl.where(tmp1, tmp2, tmp3)
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tmp5.to(tl.float32)
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask, tmp10, _tmp9)
    tmp9 = triton_helpers.promote_to_tensor(tl.sum(_tmp9, 0))
    tl.store(out_ptr0 + (x0), tmp9, None)
