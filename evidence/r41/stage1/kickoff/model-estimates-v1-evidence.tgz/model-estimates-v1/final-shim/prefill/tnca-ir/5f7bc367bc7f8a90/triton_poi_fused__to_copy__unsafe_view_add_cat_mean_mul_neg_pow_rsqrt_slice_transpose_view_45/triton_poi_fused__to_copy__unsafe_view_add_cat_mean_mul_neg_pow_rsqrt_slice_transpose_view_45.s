    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    s.rdspecial  s1, arg_base
    v.add        v3, v1, v0
    v.movi       v0, #5
    s.ld.d       s2, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    v.movi       v4, #0
    @p1 v.sel        v5, v1, v3
    v.movi       v1, #31
    v.sub        v6, v4, v3
    v.lshr       v7, v5, v0
    v.cmp.lt     p2, v3, v4
    @p2 v.sel        v0, v6, v3
    v.sub        v5, v2, v7
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.and        v6, v0, v1
    @p1 v.sel        v0, v5, v7
    v.movi       v1, #32
    v.sub        v5, v4, v6
    v.movi       v7, #0
    v.movi       v8, #0
    @p2 v.sel        v9, v5, v6
    v.sub        v5, v7, v3
    v.cmp.lt     p1, v3, v7
    v.sub        v6, v8, v0
    s.ld.d       s4, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    @p1 v.sel        v10, v5, v3
    v.cmp.lt     p2, v0, v8
    @p2 v.sel        v3, v6, v0
    v.movi       v5, #1
    v.movi       v6, #64
    v.movi       v11, #2
    v.and        v12, v3, v5
    v.sub        v3, v4, v1
    v.sub        v5, v2, v1
    v.sub        v13, v8, v12
    s.ld.d       s5, [s1, #24]                   // out_ptr0: device_ptr64 at arg_base+24
    v.sub        v14, v8, v11
    @p2 v.sel        v15, v13, v12
    v.sub        v12, v7, v6
    v.cmp.lt     p2, v1, v4
    v.cmp.lt     p3, v1, v2
    @p2 v.sel        v2, v3, v1
    v.cmp.lt     p2, v11, v8
    @p3 v.sel        v2, v5, v1
    v.cmp.lt     p3, v6, v7
    @p2 v.sel        v2, v14, v11
    s.ld.d       s6, [s1, #32]                   // out_ptr1: device_ptr64 at arg_base+32
    .li       s1, #1132462080
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #897988541
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v5, v2                          // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #256
    v.add        v11, v9, v1
    .li       s1, #1077936128
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.mul        v13, v0, v8
    .li       s1, #3204448256
    v.splat      v8, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v14, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.ld.gather.w v16, [s2, v0]                  // index is in elements (ISA sec 9.1)
    @p3 v.sel        v0, v12, v6
    v.add        v0, v11, v13
    v.add        v12, v9, v13
    v.ld.gather.h v13, [s3, v0]                  // index is in elements (ISA sec 9.1)
    vf.fms       v0, v2, v5, v3
    v.movi       v2, #6
    v.lshr       v3, v10, v2
    vf.fms       v2, v5, v0, v5
    v.movi       v0, #8192
    v.sub        v10, v7, v3
    v.mul        v7, v15, v0
    vf.neg       v0, v2                          // Newton step: r0*(2 - x*r0)
    v.ld.gather.h v2, [s4, v11]                  // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v11, v13
    @p1 v.sel        v13, v10, v3
    vf.cmp.o     p1, v0, v0
    @p1 v.sel        v3, v0, v5
    v.mul        v0, v13, v6
    vf.mul       v5, v16, v3                     // a/y as a refined reciprocal (ISA has no divide)
    v.add        v3, v9, v0
    v.add        v0, v3, v7
    vf.add       v3, v5, v4
    v.ld.gather.h v4, [s3, v12]                  // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v5, v2
    v.rsqrt.approx v2, v3                        // ISA 8.8: <= 2**-22 relative
    vf.add       v6, v5, v14
    v.ld.gather.h v5, [s4, v9]                   // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v7, v4
    vf.cvt.bf16.f32 v4, v5
    vf.mul       v5, v2, v2
    vf.mul       v9, v2, v8
    vf.add       v8, v4, v14
    vf.fms       v4, v3, v5, v1
    vf.mul       v1, v9, v4                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v3, v1, v2
    vf.mul       v1, v11, v3
    vf.mul       v2, v7, v3
    vf.mul       v3, v1, v6
    vf.mul       v1, v2, v8
    vf.neg       v2, v3
    vf.cvt.f32.bf16 v3, v1
    vf.cvt.f32.bf16 v1, v2
    v.st.scatter.h [s5, v0], v1
    v.st.scatter.h [s6, v0], v3
__rctx_next:
    exit
