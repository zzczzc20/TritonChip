    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    s.rdspecial  s2, arg_base
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v2, #64
    v.add        v3, v1, v0
    v.movi       v0, #63
    v.movi       v1, #32
    v.mul        v4, v3, v2
    .li       s4, #1069066811
    v.splat      v2, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.lt     p1, v3, v1
    v.add        v1, v4, v0
    .li       s4, #1060205080
    v.splat      v0, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s4, s1, #2                      // element offset -> bytes (x4)
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v3, [s3, v1]               // index is in elements (ISA sec 9.1)
    vf.mul       v1, v3, v2
    s.ld.d       s1, [s2, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.exp2.approx v4, v1                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v3, v2, v1                  // the exact rounding error of x*log2(e)
    vf.mul       v1, v5, v0
    s.add        s2, s1, s4                      // &out_ptr0[...]
    vf.fma       v0, v4, v1, v4                  // 2**t * 2**d
    vf.cmp.o     p2, v0, v0
    @p2 v.sel        v1, v0, v4
    @p1 v.st.w       [s2, #0], v1
__rctx_next:
    exit
