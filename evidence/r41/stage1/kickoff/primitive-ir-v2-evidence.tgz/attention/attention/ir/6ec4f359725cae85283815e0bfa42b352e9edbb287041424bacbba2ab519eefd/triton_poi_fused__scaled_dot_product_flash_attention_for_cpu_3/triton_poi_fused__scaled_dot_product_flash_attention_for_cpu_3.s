    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    v.movi       v1, #5
    v.movi       v2, #0
    v.movi       v3, #40
    s.rdspecial  s1, arg_base
    v.splat      v4, s2
    v.sub        v5, v2, v1
    v.cmp.lt     p1, v1, v2
    v.add        v6, v4, v0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v0, #1
    v.sub        v4, v2, v6
    v.cmp.lt     p2, v6, v2
    v.cmp.lt     p3, v6, v3
    @p2 v.sel        v3, v4, v6
    @p1 v.sel        v4, v5, v1
    v.movi       v5, #0
    v.movi       v7, #0
    s.movz       s4, #31
    s.ld.d       s5, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
idiv_1:
    v.splat      v8, s4
    v.shl        v9, v7, v0
    v.cmp.lt     p1, v7, v2
    v.lshr       v10, v3, v8
    v.shl        v11, v0, v8
    s.subi       s1, s4, #1
    v.and        v8, v10, v0
    s.movz       s6, #0
    v.or         v10, v9, v8
    v.cmp.geu    p4, v10, v4
    p.or         p5, p1, p4
    v.sub        v8, v10, v4
    @p5 v.sel        v9, v11, v2
    @p5 v.sel        v11, v8, v10
    v.or         v8, v5, v9
    v.mov        v7, v11
    v.mov        v5, v8
    s.mov        s4, s1
    s.cmp.ge     s1, s4, s6
    br.nz        s1, idiv_1
    v.sub        v0, v2, v7
    v.movi       v2, #-1
    v.mul        v3, v6, v1
    @p2 v.sel        v1, v0, v7
    v.movi       v0, #1
    v.movi       v4, #2
    v.mul        v5, v1, v2
    v.movi       v2, #3
    v.movi       v6, #4
    v.extract    s1, v5, #0
    v.extract    s4, v5, #1
    s.shli       s6, s1, #32
    v.add        v7, v3, v0
    s.ashri      s1, s6, #32
    v.add        v8, v3, v4
    v.add        v9, v3, v2
    v.add        v10, v3, v6
    v.movi       v11, #0
    v.movi       v12, #0
    s.shli       s6, s4, #32
    s.lshri      s4, s1, #32
    v.extract    s7, v5, #2
    s.ashri      s8, s6, #32
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v13, [s3, v3]              // index is in elements (ISA sec 9.1)
    s.shli       s6, s7, #32
    s.lshri      s7, s8, #32
    s.ashri      s9, s6, #32
    s.movz       s6, #5
    s.movz       s6, #1
    s.movz       s6, #2
    s.movz       s6, #3
    s.movz       s6, #4
    .li       s6, #-1
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v3, [s3, v7]               // index is in elements (ISA sec 9.1)
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v7, [s3, v8]               // index is in elements (ISA sec 9.1)
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v8, [s3, v9]               // index is in elements (ISA sec 9.1)
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v9, [s3, v10]              // index is in elements (ISA sec 9.1)
    v.insert     v11, s1, #0
    v.insert     v12, s4, #0
    v.extract    s1, v5, #3
    v.insert     v11, s8, #1
    v.insert     v12, s7, #1
    s.shli       s3, s1, #32
    s.lshri      s1, s9, #32
    v.extract    s4, v5, #4
    s.ashri      s6, s3, #32
    v.insert     v11, s9, #2
    v.insert     v12, s1, #2
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v5, #5
    s.ashri      s7, s1, #32
    v.insert     v11, s6, #3
    v.insert     v12, s3, #3
    s.shli       s1, s4, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v5, #6
    s.ashri      s6, s1, #32
    v.insert     v11, s7, #4
    v.insert     v12, s3, #4
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v5, #7
    s.ashri      s7, s1, #32
    v.insert     v11, s6, #5
    v.insert     v12, s3, #5
    s.shli       s1, s4, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v5, #8
    s.ashri      s6, s1, #32
    v.insert     v11, s7, #6
    v.insert     v12, s3, #6
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v5, #9
    s.ashri      s7, s1, #32
    v.insert     v11, s6, #7
    v.insert     v12, s3, #7
    s.shli       s1, s4, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v5, #10
    s.ashri      s6, s1, #32
    v.insert     v11, s7, #8
    v.insert     v12, s3, #8
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v5, #11
    s.ashri      s7, s1, #32
    v.insert     v11, s6, #9
    v.insert     v12, s3, #9
    s.shli       s1, s4, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v5, #12
    s.ashri      s6, s1, #32
    v.insert     v11, s7, #10
    v.insert     v12, s3, #10
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v5, #13
    s.ashri      s7, s1, #32
    v.insert     v11, s6, #11
    v.insert     v12, s3, #11
    s.shli       s1, s4, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v5, #14
    s.ashri      s6, s1, #32
    v.insert     v11, s7, #12
    v.insert     v12, s3, #12
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v5, #15
    s.ashri      s7, s1, #32
    v.insert     v11, s6, #13
    v.insert     v12, s3, #13
    s.shli       s1, s4, #32
    s.lshri      s3, s7, #32
    s.ashri      s4, s1, #32
    v.insert     v11, s7, #14
    v.insert     v12, s3, #14
    s.lshri      s1, s4, #32
    v.insert     v11, s4, #15
    v.insert     v12, s1, #15
    s.movz       s1, #0
    v.extract    s3, v11, #0
    v.extract    s4, v12, #0
    v.extract    s6, v12, #1
    s.shli       s7, s4, #32
    v.movi       v5, #0
    s.or         s4, s3, s7
    v.extract    s3, v11, #1
    s.shli       s7, s6, #32
    s.cmp.le     s6, s4, s1
    v.extract    s1, v12, #2
    s.or         s4, s3, s7
    s.movz       s3, #0
    v.insert     v5, s6, #0
    v.extract    s6, v11, #2
    s.shli       s7, s1, #32
    s.cmp.le     s1, s4, s3
    v.extract    s3, v12, #3
    s.or         s4, s6, s7
    s.movz       s6, #0
    v.insert     v5, s1, #1
    v.extract    s1, v11, #3
    s.shli       s7, s3, #32
    s.cmp.le     s3, s4, s6
    v.extract    s4, v12, #4
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v5, s3, #2
    v.extract    s3, v11, #4
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s1
    v.extract    s1, v12, #5
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v5, s4, #3
    v.extract    s4, v11, #5
    s.shli       s7, s1, #32
    s.cmp.le     s1, s6, s3
    v.extract    s3, v12, #6
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v5, s1, #4
    v.extract    s1, v11, #6
    s.shli       s7, s3, #32
    s.cmp.le     s3, s6, s4
    v.extract    s4, v12, #7
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v5, s3, #5
    v.extract    s3, v11, #7
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s1
    v.extract    s1, v12, #8
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v5, s4, #6
    v.extract    s4, v11, #8
    s.shli       s7, s1, #32
    s.cmp.le     s1, s6, s3
    v.extract    s3, v12, #9
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v5, s1, #7
    v.extract    s1, v11, #9
    s.shli       s7, s3, #32
    s.cmp.le     s3, s6, s4
    v.extract    s4, v12, #10
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v5, s3, #8
    v.extract    s3, v11, #10
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s1
    v.extract    s1, v12, #11
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v5, s4, #9
    v.extract    s4, v11, #11
    s.shli       s7, s1, #32
    s.cmp.le     s1, s6, s3
    v.extract    s3, v12, #12
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v5, s1, #10
    v.extract    s1, v11, #12
    s.shli       s7, s3, #32
    s.cmp.le     s3, s6, s4
    v.extract    s4, v12, #13
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v5, s3, #11
    v.extract    s3, v11, #13
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s1
    v.extract    s1, v12, #14
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v5, s4, #12
    v.extract    s4, v11, #14
    s.shli       s7, s1, #32
    s.cmp.le     s1, s6, s3
    v.extract    s3, v12, #15
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v5, s1, #13
    v.extract    s1, v11, #15
    s.shli       s7, s3, #32
    s.cmp.le     s3, s6, s4
    s.or         s4, s1, s7
    s.movz       s1, #0
    v.insert     v5, s3, #14
    s.cmp.le     s3, s4, s1
    v.movi       v10, #0
    v.insert     v5, s3, #15
    v.movi       v11, #0
    .li       s1, #4286578688
    v.splat      v12, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.ne     p1, v5, v10
    v.movi       v5, #1
    @p1 v.sel        v10, v11, v12
    v.movi       v14, #0
    v.movi       v15, #0
    vf.add       v16, v13, v10
    v.movi       v10, #1
    v.movi       v13, #0
    v.movi       v17, #1
    v.movi       v18, #0
    vf.cmp.eq    p1, v16, v12
    @p1 v.sel        v16, v5, v14
    v.movi       v5, #1
    v.movi       v14, #0
    v.cmp.eq     p1, v16, v15
    @p1 v.sel        v16, v10, v13
    @p1 v.sel        v10, v17, v18
    v.movi       v13, #0
    v.extract    s1, v16, #0
    v.movi       v16, #0
    s.lshri      s3, s1, #32
    v.extract    s4, v10, #1
    @p1 v.sel        v10, v5, v14
    v.movi       v5, #1
    v.movi       v14, #0
    v.insert     v13, s1, #0
    v.insert     v16, s3, #0
    s.lshri      s1, s4, #32
    v.extract    s3, v10, #2
    @p1 v.sel        v10, v5, v14
    v.movi       v5, #1
    v.movi       v14, #0
    v.insert     v13, s4, #1
    v.insert     v16, s1, #1
    s.lshri      s1, s3, #32
    v.extract    s4, v10, #3
    @p1 v.sel        v10, v5, v14
    v.movi       v5, #1
    v.movi       v14, #0
    v.insert     v13, s3, #2
    v.insert     v16, s1, #2
    s.lshri      s1, s4, #32
    v.extract    s3, v10, #4
    @p1 v.sel        v10, v5, v14
    v.movi       v5, #1
    v.movi       v14, #0
    v.insert     v13, s4, #3
    v.insert     v16, s1, #3
    s.lshri      s1, s3, #32
    v.extract    s4, v10, #5
    @p1 v.sel        v10, v5, v14
    v.movi       v5, #1
    v.movi       v14, #0
    v.insert     v13, s3, #4
    v.insert     v16, s1, #4
    s.lshri      s1, s4, #32
    v.extract    s3, v10, #6
    @p1 v.sel        v10, v5, v14
    v.movi       v5, #1
    v.movi       v14, #0
    v.insert     v13, s4, #5
    v.insert     v16, s1, #5
    s.lshri      s1, s3, #32
    v.extract    s4, v10, #7
    @p1 v.sel        v10, v5, v14
    v.movi       v5, #1
    v.movi       v14, #0
    v.insert     v13, s3, #6
    v.insert     v16, s1, #6
    s.lshri      s1, s4, #32
    v.extract    s3, v10, #8
    @p1 v.sel        v10, v5, v14
    v.movi       v5, #1
    v.movi       v14, #0
    v.insert     v13, s4, #7
    v.insert     v16, s1, #7
    s.lshri      s1, s3, #32
    v.extract    s4, v10, #9
    @p1 v.sel        v10, v5, v14
    v.movi       v5, #1
    v.movi       v14, #0
    v.insert     v13, s3, #8
    v.insert     v16, s1, #8
    s.lshri      s1, s4, #32
    v.extract    s3, v10, #10
    @p1 v.sel        v10, v5, v14
    v.movi       v5, #1
    v.movi       v14, #0
    v.insert     v13, s4, #9
    v.insert     v16, s1, #9
    s.lshri      s1, s3, #32
    v.extract    s4, v10, #11
    @p1 v.sel        v10, v5, v14
    v.movi       v5, #1
    v.movi       v14, #0
    v.insert     v13, s3, #10
    v.insert     v16, s1, #10
    s.lshri      s1, s4, #32
    v.extract    s3, v10, #12
    @p1 v.sel        v10, v5, v14
    v.movi       v5, #1
    v.movi       v14, #0
    v.insert     v13, s4, #11
    v.insert     v16, s1, #11
    s.lshri      s1, s3, #32
    v.extract    s4, v10, #13
    @p1 v.sel        v10, v5, v14
    v.movi       v5, #1
    v.movi       v14, #0
    v.insert     v13, s3, #12
    v.insert     v16, s1, #12
    s.lshri      s1, s4, #32
    v.extract    s3, v10, #14
    @p1 v.sel        v10, v5, v14
    v.insert     v13, s4, #13
    v.insert     v16, s1, #13
    s.lshri      s1, s3, #32
    v.extract    s4, v10, #15
    v.insert     v13, s3, #14
    v.insert     v16, s1, #14
    s.lshri      s1, s4, #32
    v.insert     v13, s4, #15
    v.insert     v16, s1, #15
    s.movz       s1, #0
    v.extract    s3, v13, #0
    v.extract    s4, v16, #0
    v.extract    s6, v16, #1
    s.shli       s7, s4, #32
    v.movi       v5, #0
    s.or         s4, s3, s7
    v.extract    s3, v13, #1
    s.shli       s7, s6, #32
    s.cmp.ne     s6, s4, s1
    v.extract    s1, v16, #2
    s.or         s4, s3, s7
    s.movz       s3, #0
    v.insert     v5, s6, #0
    v.extract    s6, v13, #2
    s.shli       s7, s1, #32
    s.cmp.ne     s1, s4, s3
    v.extract    s3, v16, #3
    s.or         s4, s6, s7
    s.movz       s6, #0
    v.insert     v5, s1, #1
    v.extract    s1, v13, #3
    s.shli       s7, s3, #32
    s.cmp.ne     s3, s4, s6
    v.extract    s4, v16, #4
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v5, s3, #2
    v.extract    s3, v13, #4
    s.shli       s7, s4, #32
    s.cmp.ne     s4, s6, s1
    v.extract    s1, v16, #5
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v5, s4, #3
    v.extract    s4, v13, #5
    s.shli       s7, s1, #32
    s.cmp.ne     s1, s6, s3
    v.extract    s3, v16, #6
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v5, s1, #4
    v.extract    s1, v13, #6
    s.shli       s7, s3, #32
    s.cmp.ne     s3, s6, s4
    v.extract    s4, v16, #7
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v5, s3, #5
    v.extract    s3, v13, #7
    s.shli       s7, s4, #32
    s.cmp.ne     s4, s6, s1
    v.extract    s1, v16, #8
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v5, s4, #6
    v.extract    s4, v13, #8
    s.shli       s7, s1, #32
    s.cmp.ne     s1, s6, s3
    v.extract    s3, v16, #9
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v5, s1, #7
    v.extract    s1, v13, #9
    s.shli       s7, s3, #32
    s.cmp.ne     s3, s6, s4
    v.extract    s4, v16, #10
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v5, s3, #8
    v.extract    s3, v13, #10
    s.shli       s7, s4, #32
    s.cmp.ne     s4, s6, s1
    v.extract    s1, v16, #11
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v5, s4, #9
    v.extract    s4, v13, #11
    s.shli       s7, s1, #32
    s.cmp.ne     s1, s6, s3
    v.extract    s3, v16, #12
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v5, s1, #10
    v.extract    s1, v13, #12
    s.shli       s7, s3, #32
    s.cmp.ne     s3, s6, s4
    v.extract    s4, v16, #13
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v5, s3, #11
    v.extract    s3, v13, #13
    s.shli       s7, s4, #32
    s.cmp.ne     s4, s6, s1
    v.extract    s1, v16, #14
    v.sub        v10, v0, v1
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v5, s4, #12
    v.extract    s4, v13, #14
    s.shli       s7, s1, #32
    s.cmp.ne     s1, s6, s3
    v.extract    s3, v16, #15
    v.extract    s6, v10, #0
    s.or         s8, s4, s7
    s.movz       s4, #0
    v.insert     v5, s1, #13
    v.extract    s1, v13, #15
    s.shli       s7, s3, #32
    s.shli       s3, s6, #32
    s.cmp.ne     s6, s8, s4
    v.extract    s4, v10, #1
    s.or         s8, s1, s7
    s.movz       s1, #0
    s.ashri      s7, s3, #32
    v.insert     v5, s6, #14
    v.movi       v0, #0
    v.movi       v13, #0
    s.shli       s3, s4, #32
    s.cmp.ne     s4, s8, s1
    s.lshri      s1, s7, #32
    v.extract    s6, v10, #2
    s.ashri      s8, s3, #32
    v.insert     v5, s4, #15
    v.insert     v0, s7, #0
    v.insert     v13, s1, #0
    s.shli       s1, s6, #32
    s.lshri      s3, s8, #32
    v.extract    s4, v10, #3
    s.ashri      s6, s1, #32
    v.insert     v0, s8, #1
    v.insert     v13, s3, #1
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v10, #4
    s.ashri      s7, s1, #32
    v.insert     v0, s6, #2
    v.insert     v13, s3, #2
    s.shli       s1, s4, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v10, #5
    s.ashri      s6, s1, #32
    v.insert     v0, s7, #3
    v.insert     v13, s3, #3
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v10, #6
    s.ashri      s7, s1, #32
    v.insert     v0, s6, #4
    v.insert     v13, s3, #4
    s.shli       s1, s4, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v10, #7
    s.ashri      s6, s1, #32
    v.insert     v0, s7, #5
    v.insert     v13, s3, #5
    s.lshri      s1, s6, #32
    v.insert     v0, s6, #6
    v.insert     v13, s1, #6
    v.movi       v14, #0
    s.shli       s1, s4, #32
    v.cmp.ne     p1, v5, v14
    v.extract    s3, v10, #8
    s.ashri      s4, s1, #32
    s.shli       s1, s3, #32
    s.lshri      s3, s4, #32
    v.extract    s6, v10, #9
    s.ashri      s7, s1, #32
    v.insert     v0, s4, #7
    v.insert     v13, s3, #7
    s.shli       s1, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v10, #10
    s.ashri      s6, s1, #32
    v.insert     v0, s7, #8
    v.insert     v13, s3, #8
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v10, #11
    s.ashri      s7, s1, #32
    v.insert     v0, s6, #9
    v.insert     v13, s3, #9
    s.shli       s1, s4, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v10, #12
    s.ashri      s6, s1, #32
    v.insert     v0, s7, #10
    v.insert     v13, s3, #10
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v10, #13
    s.ashri      s7, s1, #32
    v.insert     v0, s6, #11
    v.insert     v13, s3, #11
    s.shli       s1, s4, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v10, #14
    s.ashri      s6, s1, #32
    v.insert     v0, s7, #12
    v.insert     v13, s3, #12
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v10, #15
    s.ashri      s7, s1, #32
    v.insert     v0, s6, #13
    v.insert     v13, s3, #13
    s.shli       s1, s4, #32
    s.lshri      s3, s7, #32
    s.ashri      s4, s1, #32
    v.insert     v0, s7, #14
    v.insert     v13, s3, #14
    s.lshri      s1, s4, #32
    v.insert     v0, s4, #15
    v.insert     v13, s1, #15
    s.movz       s1, #0
    v.extract    s3, v0, #0
    v.extract    s4, v13, #0
    v.extract    s6, v13, #1
    s.shli       s7, s4, #32
    v.movi       v5, #0
    s.or         s4, s3, s7
    v.extract    s3, v0, #1
    s.shli       s7, s6, #32
    s.cmp.le     s6, s4, s1
    v.extract    s1, v13, #2
    s.or         s4, s3, s7
    s.movz       s3, #0
    v.insert     v5, s6, #0
    v.extract    s6, v0, #2
    s.shli       s7, s1, #32
    s.cmp.le     s1, s4, s3
    v.extract    s3, v13, #3
    s.or         s4, s6, s7
    s.movz       s6, #0
    v.insert     v5, s1, #1
    v.extract    s1, v0, #3
    s.shli       s7, s3, #32
    s.cmp.le     s3, s4, s6
    v.extract    s4, v13, #4
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v5, s3, #2
    v.extract    s3, v0, #4
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s1
    v.extract    s1, v13, #5
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v5, s4, #3
    v.extract    s4, v0, #5
    s.shli       s7, s1, #32
    s.cmp.le     s1, s6, s3
    v.extract    s3, v13, #6
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v5, s1, #4
    v.extract    s1, v0, #6
    s.shli       s7, s3, #32
    s.cmp.le     s3, s6, s4
    v.extract    s4, v13, #7
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v5, s3, #5
    v.extract    s3, v0, #7
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s1
    v.extract    s1, v13, #8
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v5, s4, #6
    v.extract    s4, v0, #8
    s.shli       s7, s1, #32
    s.cmp.le     s1, s6, s3
    v.extract    s3, v13, #9
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v5, s1, #7
    v.extract    s1, v0, #9
    s.shli       s7, s3, #32
    s.cmp.le     s3, s6, s4
    v.extract    s4, v13, #10
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v5, s3, #8
    v.extract    s3, v0, #10
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s1
    v.extract    s1, v13, #11
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v5, s4, #9
    v.extract    s4, v0, #11
    s.shli       s7, s1, #32
    s.cmp.le     s1, s6, s3
    v.extract    s3, v13, #12
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v5, s1, #10
    v.extract    s1, v0, #12
    s.shli       s7, s3, #32
    s.cmp.le     s3, s6, s4
    v.extract    s4, v13, #13
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v5, s3, #11
    v.extract    s3, v0, #13
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s1
    v.extract    s1, v13, #14
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v5, s4, #12
    v.extract    s4, v0, #14
    s.shli       s7, s1, #32
    s.cmp.le     s1, s6, s3
    v.extract    s3, v13, #15
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v5, s1, #13
    v.extract    s1, v0, #15
    s.shli       s7, s3, #32
    s.cmp.le     s3, s6, s4
    s.or         s4, s1, s7
    s.movz       s1, #0
    v.insert     v5, s3, #14
    s.cmp.le     s3, s4, s1
    v.movi       v0, #0
    v.insert     v5, s3, #15
    v.movi       v10, #1
    v.movi       v13, #0
    v.cmp.ne     p2, v5, v0
    @p2 v.sel        v0, v11, v12
    v.movi       v5, #1
    v.movi       v14, #0
    vf.add       v16, v3, v0
    v.movi       v0, #1
    v.movi       v3, #0
    v.movi       v17, #1
    v.movi       v18, #0
    vf.cmp.eq    p2, v16, v12
    @p2 v.sel        v16, v10, v13
    v.movi       v10, #0
    v.movi       v13, #0
    v.cmp.eq     p2, v16, v15
    @p2 v.sel        v16, v5, v14
    @p2 v.sel        v5, v0, v3
    @p2 v.sel        v0, v17, v18
    v.extract    s1, v16, #0
    v.extract    s3, v5, #1
    s.lshri      s4, s1, #32
    v.movi       v3, #1
    v.movi       v5, #0
    v.insert     v10, s1, #0
    v.insert     v13, s4, #0
    s.lshri      s1, s3, #32
    v.extract    s4, v0, #2
    @p2 v.sel        v0, v3, v5
    v.movi       v3, #1
    v.movi       v5, #0
    v.insert     v10, s3, #1
    v.insert     v13, s1, #1
    s.lshri      s1, s4, #32
    v.extract    s3, v0, #3
    @p2 v.sel        v0, v3, v5
    v.movi       v3, #1
    v.movi       v5, #0
    v.insert     v10, s4, #2
    v.insert     v13, s1, #2
    s.lshri      s1, s3, #32
    v.extract    s4, v0, #4
    @p2 v.sel        v0, v3, v5
    v.movi       v3, #1
    v.movi       v5, #0
    v.insert     v10, s3, #3
    v.insert     v13, s1, #3
    s.lshri      s1, s4, #32
    v.extract    s3, v0, #5
    @p2 v.sel        v0, v3, v5
    v.movi       v3, #1
    v.movi       v5, #0
    v.insert     v10, s4, #4
    v.insert     v13, s1, #4
    s.lshri      s1, s3, #32
    v.extract    s4, v0, #6
    @p2 v.sel        v0, v3, v5
    v.movi       v3, #1
    v.movi       v5, #0
    v.insert     v10, s3, #5
    v.insert     v13, s1, #5
    s.lshri      s1, s4, #32
    v.extract    s3, v0, #7
    @p2 v.sel        v0, v3, v5
    v.movi       v3, #1
    v.movi       v5, #0
    v.insert     v10, s4, #6
    v.insert     v13, s1, #6
    s.lshri      s1, s3, #32
    v.extract    s4, v0, #8
    @p2 v.sel        v0, v3, v5
    v.movi       v3, #1
    v.movi       v5, #0
    v.insert     v10, s3, #7
    v.insert     v13, s1, #7
    s.lshri      s1, s4, #32
    v.extract    s3, v0, #9
    @p2 v.sel        v0, v3, v5
    v.movi       v3, #1
    v.movi       v5, #0
    v.insert     v10, s4, #8
    v.insert     v13, s1, #8
    s.lshri      s1, s3, #32
    v.extract    s4, v0, #10
    @p2 v.sel        v0, v3, v5
    v.movi       v3, #1
    v.movi       v5, #0
    v.insert     v10, s3, #9
    v.insert     v13, s1, #9
    s.lshri      s1, s4, #32
    v.extract    s3, v0, #11
    @p2 v.sel        v0, v3, v5
    v.movi       v3, #1
    v.movi       v5, #0
    v.insert     v10, s4, #10
    v.insert     v13, s1, #10
    s.lshri      s1, s3, #32
    v.extract    s4, v0, #12
    @p2 v.sel        v0, v3, v5
    v.movi       v3, #1
    v.movi       v5, #0
    v.insert     v10, s3, #11
    v.insert     v13, s1, #11
    s.lshri      s1, s4, #32
    v.extract    s3, v0, #13
    @p2 v.sel        v0, v3, v5
    v.movi       v3, #1
    v.movi       v5, #0
    v.insert     v10, s4, #12
    v.insert     v13, s1, #12
    s.lshri      s1, s3, #32
    v.extract    s4, v0, #14
    @p2 v.sel        v0, v3, v5
    v.insert     v10, s3, #13
    v.insert     v13, s1, #13
    s.lshri      s1, s4, #32
    v.extract    s3, v0, #15
    v.insert     v10, s4, #14
    v.insert     v13, s1, #14
    s.lshri      s1, s3, #32
    v.insert     v10, s3, #15
    v.insert     v13, s1, #15
    s.movz       s1, #0
    v.extract    s3, v10, #0
    v.extract    s4, v13, #0
    v.extract    s6, v13, #1
    s.shli       s7, s4, #32
    v.movi       v0, #0
    s.or         s4, s3, s7
    v.extract    s3, v10, #1
    s.shli       s7, s6, #32
    s.cmp.ne     s6, s4, s1
    v.extract    s1, v13, #2
    s.or         s4, s3, s7
    s.movz       s3, #0
    v.insert     v0, s6, #0
    v.extract    s6, v10, #2
    s.shli       s7, s1, #32
    s.cmp.ne     s1, s4, s3
    v.extract    s3, v13, #3
    s.or         s4, s6, s7
    s.movz       s6, #0
    v.insert     v0, s1, #1
    v.extract    s1, v10, #3
    s.shli       s7, s3, #32
    s.cmp.ne     s3, s4, s6
    v.extract    s4, v13, #4
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #2
    v.extract    s3, v10, #4
    s.shli       s7, s4, #32
    s.cmp.ne     s4, s6, s1
    v.extract    s1, v13, #5
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v0, s4, #3
    v.extract    s4, v10, #5
    s.shli       s7, s1, #32
    s.cmp.ne     s1, s6, s3
    v.extract    s3, v13, #6
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v0, s1, #4
    v.extract    s1, v10, #6
    s.shli       s7, s3, #32
    s.cmp.ne     s3, s6, s4
    v.extract    s4, v13, #7
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #5
    v.extract    s3, v10, #7
    s.shli       s7, s4, #32
    s.cmp.ne     s4, s6, s1
    v.extract    s1, v13, #8
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v0, s4, #6
    v.extract    s4, v10, #8
    s.shli       s7, s1, #32
    s.cmp.ne     s1, s6, s3
    v.extract    s3, v13, #9
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v0, s1, #7
    v.extract    s1, v10, #9
    s.shli       s7, s3, #32
    s.cmp.ne     s3, s6, s4
    v.extract    s4, v13, #10
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #8
    v.extract    s3, v10, #10
    s.shli       s7, s4, #32
    s.cmp.ne     s4, s6, s1
    v.extract    s1, v13, #11
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v0, s4, #9
    v.extract    s4, v10, #11
    s.shli       s7, s1, #32
    s.cmp.ne     s1, s6, s3
    v.extract    s3, v13, #12
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v0, s1, #10
    v.extract    s1, v10, #12
    s.shli       s7, s3, #32
    s.cmp.ne     s3, s6, s4
    v.extract    s4, v13, #13
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #11
    v.extract    s3, v10, #13
    s.shli       s7, s4, #32
    s.cmp.ne     s4, s6, s1
    v.extract    s1, v13, #14
    v.sub        v3, v4, v1
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v0, s4, #12
    v.extract    s4, v10, #14
    s.shli       s7, s1, #32
    s.cmp.ne     s1, s6, s3
    v.extract    s3, v13, #15
    v.extract    s6, v3, #0
    s.or         s8, s4, s7
    s.movz       s4, #0
    v.insert     v0, s1, #13
    v.extract    s1, v10, #15
    s.shli       s7, s3, #32
    s.shli       s3, s6, #32
    s.cmp.ne     s6, s8, s4
    v.extract    s4, v3, #1
    s.or         s8, s1, s7
    s.movz       s1, #0
    s.ashri      s7, s3, #32
    v.insert     v0, s6, #14
    v.movi       v4, #0
    v.movi       v5, #0
    s.shli       s3, s4, #32
    s.cmp.ne     s4, s8, s1
    s.lshri      s1, s7, #32
    v.extract    s6, v3, #2
    s.ashri      s8, s3, #32
    v.insert     v0, s4, #15
    v.insert     v4, s7, #0
    v.insert     v5, s1, #0
    s.shli       s1, s6, #32
    s.lshri      s3, s8, #32
    v.extract    s4, v3, #3
    s.ashri      s6, s1, #32
    v.insert     v4, s8, #1
    v.insert     v5, s3, #1
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v3, #4
    s.ashri      s7, s1, #32
    v.insert     v4, s6, #2
    v.insert     v5, s3, #2
    s.shli       s1, s4, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v3, #5
    s.ashri      s6, s1, #32
    v.insert     v4, s7, #3
    v.insert     v5, s3, #3
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v3, #6
    s.ashri      s7, s1, #32
    v.insert     v4, s6, #4
    v.insert     v5, s3, #4
    s.shli       s1, s4, #32
    s.lshri      s3, s7, #32
    s.ashri      s4, s1, #32
    v.insert     v4, s7, #5
    v.insert     v5, s3, #5
    s.lshri      s1, s4, #32
    v.insert     v4, s4, #6
    v.insert     v5, s1, #6
    v.movi       v10, #0
    v.extract    s1, v3, #7
    v.cmp.ne     p2, v0, v10
    s.shli       s3, s1, #32
    p.or         p4, p1, p2
    v.extract    s1, v3, #8
    s.ashri      s4, s3, #32
    s.shli       s3, s1, #32
    s.lshri      s1, s4, #32
    v.extract    s6, v3, #9
    s.ashri      s7, s3, #32
    v.insert     v4, s4, #7
    v.insert     v5, s1, #7
    s.shli       s1, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v3, #10
    s.ashri      s6, s1, #32
    v.insert     v4, s7, #8
    v.insert     v5, s3, #8
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v3, #11
    s.ashri      s7, s1, #32
    v.insert     v4, s6, #9
    v.insert     v5, s3, #9
    s.shli       s1, s4, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v3, #12
    s.ashri      s6, s1, #32
    v.insert     v4, s7, #10
    v.insert     v5, s3, #10
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v3, #13
    s.ashri      s7, s1, #32
    v.insert     v4, s6, #11
    v.insert     v5, s3, #11
    s.shli       s1, s4, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v3, #14
    s.ashri      s6, s1, #32
    v.insert     v4, s7, #12
    v.insert     v5, s3, #12
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v3, #15
    s.ashri      s7, s1, #32
    v.insert     v4, s6, #13
    v.insert     v5, s3, #13
    s.shli       s1, s4, #32
    s.lshri      s3, s7, #32
    s.ashri      s4, s1, #32
    v.insert     v4, s7, #14
    v.insert     v5, s3, #14
    s.lshri      s1, s4, #32
    v.insert     v4, s4, #15
    v.insert     v5, s1, #15
    s.movz       s1, #0
    v.extract    s3, v4, #0
    v.extract    s4, v5, #0
    v.extract    s6, v5, #1
    s.shli       s7, s4, #32
    v.movi       v0, #0
    s.or         s4, s3, s7
    v.extract    s3, v4, #1
    s.shli       s7, s6, #32
    s.cmp.le     s6, s4, s1
    v.extract    s1, v5, #2
    s.or         s4, s3, s7
    s.movz       s3, #0
    v.insert     v0, s6, #0
    v.extract    s6, v4, #2
    s.shli       s7, s1, #32
    s.cmp.le     s1, s4, s3
    v.extract    s3, v5, #3
    s.or         s4, s6, s7
    s.movz       s6, #0
    v.insert     v0, s1, #1
    v.extract    s1, v4, #3
    s.shli       s7, s3, #32
    s.cmp.le     s3, s4, s6
    v.extract    s4, v5, #4
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #2
    v.extract    s3, v4, #4
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s1
    v.extract    s1, v5, #5
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v0, s4, #3
    v.extract    s4, v4, #5
    s.shli       s7, s1, #32
    s.cmp.le     s1, s6, s3
    v.extract    s3, v5, #6
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v0, s1, #4
    v.extract    s1, v4, #6
    s.shli       s7, s3, #32
    s.cmp.le     s3, s6, s4
    v.extract    s4, v5, #7
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #5
    v.extract    s3, v4, #7
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s1
    v.extract    s1, v5, #8
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v0, s4, #6
    v.extract    s4, v4, #8
    s.shli       s7, s1, #32
    s.cmp.le     s1, s6, s3
    v.extract    s3, v5, #9
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v0, s1, #7
    v.extract    s1, v4, #9
    s.shli       s7, s3, #32
    s.cmp.le     s3, s6, s4
    v.extract    s4, v5, #10
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #8
    v.extract    s3, v4, #10
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s1
    v.extract    s1, v5, #11
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v0, s4, #9
    v.extract    s4, v4, #11
    s.shli       s7, s1, #32
    s.cmp.le     s1, s6, s3
    v.extract    s3, v5, #12
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v0, s1, #10
    v.extract    s1, v4, #12
    s.shli       s7, s3, #32
    s.cmp.le     s3, s6, s4
    v.extract    s4, v5, #13
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #11
    v.extract    s3, v4, #13
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s1
    v.extract    s1, v5, #14
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v0, s4, #12
    v.extract    s4, v4, #14
    s.shli       s7, s1, #32
    s.cmp.le     s1, s6, s3
    v.extract    s3, v5, #15
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v0, s1, #13
    v.extract    s1, v4, #15
    s.shli       s7, s3, #32
    s.cmp.le     s3, s6, s4
    s.or         s4, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #14
    s.cmp.le     s3, s4, s1
    v.movi       v3, #0
    v.insert     v0, s3, #15
    v.movi       v4, #1
    v.movi       v5, #0
    v.cmp.ne     p1, v0, v3
    @p1 v.sel        v0, v11, v12
    v.movi       v3, #1
    v.movi       v10, #0
    vf.add       v13, v7, v0
    v.movi       v0, #1
    v.movi       v7, #0
    v.movi       v14, #1
    v.movi       v16, #0
    vf.cmp.eq    p1, v13, v12
    @p1 v.sel        v13, v4, v5
    v.movi       v4, #0
    v.movi       v5, #0
    v.cmp.eq     p1, v13, v15
    @p1 v.sel        v13, v3, v10
    @p1 v.sel        v3, v0, v7
    @p1 v.sel        v0, v14, v16
    v.extract    s1, v13, #0
    v.extract    s3, v3, #1
    s.lshri      s4, s1, #32
    v.movi       v3, #1
    v.movi       v7, #0
    v.insert     v4, s1, #0
    v.insert     v5, s4, #0
    s.lshri      s1, s3, #32
    v.extract    s4, v0, #2
    @p1 v.sel        v0, v3, v7
    v.movi       v3, #1
    v.movi       v7, #0
    v.insert     v4, s3, #1
    v.insert     v5, s1, #1
    s.lshri      s1, s4, #32
    v.extract    s3, v0, #3
    @p1 v.sel        v0, v3, v7
    v.movi       v3, #1
    v.movi       v7, #0
    v.insert     v4, s4, #2
    v.insert     v5, s1, #2
    s.lshri      s1, s3, #32
    v.extract    s4, v0, #4
    @p1 v.sel        v0, v3, v7
    v.movi       v3, #1
    v.movi       v7, #0
    v.insert     v4, s3, #3
    v.insert     v5, s1, #3
    s.lshri      s1, s4, #32
    v.extract    s3, v0, #5
    @p1 v.sel        v0, v3, v7
    v.movi       v3, #1
    v.movi       v7, #0
    v.insert     v4, s4, #4
    v.insert     v5, s1, #4
    s.lshri      s1, s3, #32
    v.extract    s4, v0, #6
    @p1 v.sel        v0, v3, v7
    v.movi       v3, #1
    v.movi       v7, #0
    v.insert     v4, s3, #5
    v.insert     v5, s1, #5
    s.lshri      s1, s4, #32
    v.extract    s3, v0, #7
    @p1 v.sel        v0, v3, v7
    v.movi       v3, #1
    v.movi       v7, #0
    v.insert     v4, s4, #6
    v.insert     v5, s1, #6
    s.lshri      s1, s3, #32
    v.extract    s4, v0, #8
    @p1 v.sel        v0, v3, v7
    v.movi       v3, #1
    v.movi       v7, #0
    v.insert     v4, s3, #7
    v.insert     v5, s1, #7
    s.lshri      s1, s4, #32
    v.extract    s3, v0, #9
    @p1 v.sel        v0, v3, v7
    v.movi       v3, #1
    v.movi       v7, #0
    v.insert     v4, s4, #8
    v.insert     v5, s1, #8
    s.lshri      s1, s3, #32
    v.extract    s4, v0, #10
    @p1 v.sel        v0, v3, v7
    v.movi       v3, #1
    v.movi       v7, #0
    v.insert     v4, s3, #9
    v.insert     v5, s1, #9
    s.lshri      s1, s4, #32
    v.extract    s3, v0, #11
    @p1 v.sel        v0, v3, v7
    v.movi       v3, #1
    v.movi       v7, #0
    v.insert     v4, s4, #10
    v.insert     v5, s1, #10
    s.lshri      s1, s3, #32
    v.extract    s4, v0, #12
    @p1 v.sel        v0, v3, v7
    v.movi       v3, #1
    v.movi       v7, #0
    v.insert     v4, s3, #11
    v.insert     v5, s1, #11
    s.lshri      s1, s4, #32
    v.extract    s3, v0, #13
    @p1 v.sel        v0, v3, v7
    v.movi       v3, #1
    v.movi       v7, #0
    v.insert     v4, s4, #12
    v.insert     v5, s1, #12
    s.lshri      s1, s3, #32
    v.extract    s4, v0, #14
    @p1 v.sel        v0, v3, v7
    v.insert     v4, s3, #13
    v.insert     v5, s1, #13
    s.lshri      s1, s4, #32
    v.extract    s3, v0, #15
    v.insert     v4, s4, #14
    v.insert     v5, s1, #14
    s.lshri      s1, s3, #32
    v.insert     v4, s3, #15
    v.insert     v5, s1, #15
    s.movz       s1, #0
    v.extract    s3, v4, #0
    v.extract    s4, v5, #0
    v.extract    s6, v5, #1
    s.shli       s7, s4, #32
    v.movi       v0, #0
    s.or         s4, s3, s7
    v.extract    s3, v4, #1
    s.shli       s7, s6, #32
    s.cmp.ne     s6, s4, s1
    v.extract    s1, v5, #2
    s.or         s4, s3, s7
    s.movz       s3, #0
    v.insert     v0, s6, #0
    v.extract    s6, v4, #2
    s.shli       s7, s1, #32
    s.cmp.ne     s1, s4, s3
    v.extract    s3, v5, #3
    s.or         s4, s6, s7
    s.movz       s6, #0
    v.insert     v0, s1, #1
    v.extract    s1, v4, #3
    s.shli       s7, s3, #32
    s.cmp.ne     s3, s4, s6
    v.extract    s4, v5, #4
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #2
    v.extract    s3, v4, #4
    s.shli       s7, s4, #32
    s.cmp.ne     s4, s6, s1
    v.extract    s1, v5, #5
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v0, s4, #3
    v.extract    s4, v4, #5
    s.shli       s7, s1, #32
    s.cmp.ne     s1, s6, s3
    v.extract    s3, v5, #6
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v0, s1, #4
    v.extract    s1, v4, #6
    s.shli       s7, s3, #32
    s.cmp.ne     s3, s6, s4
    v.extract    s4, v5, #7
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #5
    v.extract    s3, v4, #7
    s.shli       s7, s4, #32
    s.cmp.ne     s4, s6, s1
    v.extract    s1, v5, #8
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v0, s4, #6
    v.extract    s4, v4, #8
    s.shli       s7, s1, #32
    s.cmp.ne     s1, s6, s3
    v.extract    s3, v5, #9
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v0, s1, #7
    v.extract    s1, v4, #9
    s.shli       s7, s3, #32
    s.cmp.ne     s3, s6, s4
    v.extract    s4, v5, #10
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #8
    v.extract    s3, v4, #10
    s.shli       s7, s4, #32
    s.cmp.ne     s4, s6, s1
    v.extract    s1, v5, #11
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v0, s4, #9
    v.extract    s4, v4, #11
    s.shli       s7, s1, #32
    s.cmp.ne     s1, s6, s3
    v.extract    s3, v5, #12
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v0, s1, #10
    v.extract    s1, v4, #12
    s.shli       s7, s3, #32
    s.cmp.ne     s3, s6, s4
    v.extract    s4, v5, #13
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #11
    v.extract    s3, v4, #13
    s.shli       s7, s4, #32
    s.cmp.ne     s4, s6, s1
    v.extract    s1, v5, #14
    v.sub        v3, v2, v1
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v0, s4, #12
    v.extract    s4, v4, #14
    s.shli       s7, s1, #32
    s.cmp.ne     s1, s6, s3
    v.extract    s3, v5, #15
    v.extract    s6, v3, #0
    s.or         s8, s4, s7
    s.movz       s4, #0
    v.insert     v0, s1, #13
    v.extract    s1, v4, #15
    s.shli       s7, s3, #32
    s.shli       s3, s6, #32
    s.cmp.ne     s6, s8, s4
    v.extract    s4, v3, #1
    s.or         s8, s1, s7
    s.movz       s1, #0
    s.ashri      s7, s3, #32
    v.insert     v0, s6, #14
    v.movi       v2, #0
    v.movi       v4, #0
    s.shli       s3, s4, #32
    s.cmp.ne     s4, s8, s1
    s.lshri      s1, s7, #32
    v.extract    s6, v3, #2
    s.ashri      s8, s3, #32
    v.insert     v0, s4, #15
    v.insert     v2, s7, #0
    v.insert     v4, s1, #0
    s.shli       s1, s6, #32
    s.lshri      s3, s8, #32
    v.extract    s4, v3, #3
    s.ashri      s6, s1, #32
    v.insert     v2, s8, #1
    v.insert     v4, s3, #1
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v3, #4
    s.ashri      s7, s1, #32
    v.insert     v2, s6, #2
    v.insert     v4, s3, #2
    s.shli       s1, s4, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v3, #5
    s.ashri      s6, s1, #32
    v.insert     v2, s7, #3
    v.insert     v4, s3, #3
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v3, #6
    s.ashri      s7, s1, #32
    v.insert     v2, s6, #4
    v.insert     v4, s3, #4
    s.shli       s1, s4, #32
    s.lshri      s3, s7, #32
    s.ashri      s4, s1, #32
    v.insert     v2, s7, #5
    v.insert     v4, s3, #5
    s.lshri      s1, s4, #32
    v.insert     v2, s4, #6
    v.insert     v4, s1, #6
    v.movi       v5, #0
    v.extract    s1, v3, #7
    v.cmp.ne     p1, v0, v5
    s.shli       s3, s1, #32
    p.or         p2, p4, p1
    v.extract    s1, v3, #8
    s.ashri      s4, s3, #32
    s.shli       s3, s1, #32
    s.lshri      s1, s4, #32
    v.extract    s6, v3, #9
    s.ashri      s7, s3, #32
    v.insert     v2, s4, #7
    v.insert     v4, s1, #7
    s.shli       s1, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v3, #10
    s.ashri      s6, s1, #32
    v.insert     v2, s7, #8
    v.insert     v4, s3, #8
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v3, #11
    s.ashri      s7, s1, #32
    v.insert     v2, s6, #9
    v.insert     v4, s3, #9
    s.shli       s1, s4, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v3, #12
    s.ashri      s6, s1, #32
    v.insert     v2, s7, #10
    v.insert     v4, s3, #10
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v3, #13
    s.ashri      s7, s1, #32
    v.insert     v2, s6, #11
    v.insert     v4, s3, #11
    s.shli       s1, s4, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v3, #14
    s.ashri      s6, s1, #32
    v.insert     v2, s7, #12
    v.insert     v4, s3, #12
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v3, #15
    s.ashri      s7, s1, #32
    v.insert     v2, s6, #13
    v.insert     v4, s3, #13
    s.shli       s1, s4, #32
    s.lshri      s3, s7, #32
    s.ashri      s4, s1, #32
    v.insert     v2, s7, #14
    v.insert     v4, s3, #14
    s.lshri      s1, s4, #32
    v.insert     v2, s4, #15
    v.insert     v4, s1, #15
    s.movz       s1, #0
    v.extract    s3, v2, #0
    v.extract    s4, v4, #0
    v.extract    s6, v4, #1
    s.shli       s7, s4, #32
    v.movi       v0, #0
    s.or         s4, s3, s7
    v.extract    s3, v2, #1
    s.shli       s7, s6, #32
    s.cmp.le     s6, s4, s1
    v.extract    s1, v4, #2
    s.or         s4, s3, s7
    s.movz       s3, #0
    v.insert     v0, s6, #0
    v.extract    s6, v2, #2
    s.shli       s7, s1, #32
    s.cmp.le     s1, s4, s3
    v.extract    s3, v4, #3
    s.or         s4, s6, s7
    s.movz       s6, #0
    v.insert     v0, s1, #1
    v.extract    s1, v2, #3
    s.shli       s7, s3, #32
    s.cmp.le     s3, s4, s6
    v.extract    s4, v4, #4
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #2
    v.extract    s3, v2, #4
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s1
    v.extract    s1, v4, #5
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v0, s4, #3
    v.extract    s4, v2, #5
    s.shli       s7, s1, #32
    s.cmp.le     s1, s6, s3
    v.extract    s3, v4, #6
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v0, s1, #4
    v.extract    s1, v2, #6
    s.shli       s7, s3, #32
    s.cmp.le     s3, s6, s4
    v.extract    s4, v4, #7
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #5
    v.extract    s3, v2, #7
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s1
    v.extract    s1, v4, #8
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v0, s4, #6
    v.extract    s4, v2, #8
    s.shli       s7, s1, #32
    s.cmp.le     s1, s6, s3
    v.extract    s3, v4, #9
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v0, s1, #7
    v.extract    s1, v2, #9
    s.shli       s7, s3, #32
    s.cmp.le     s3, s6, s4
    v.extract    s4, v4, #10
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #8
    v.extract    s3, v2, #10
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s1
    v.extract    s1, v4, #11
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v0, s4, #9
    v.extract    s4, v2, #11
    s.shli       s7, s1, #32
    s.cmp.le     s1, s6, s3
    v.extract    s3, v4, #12
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v0, s1, #10
    v.extract    s1, v2, #12
    s.shli       s7, s3, #32
    s.cmp.le     s3, s6, s4
    v.extract    s4, v4, #13
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #11
    v.extract    s3, v2, #13
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s1
    v.extract    s1, v4, #14
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v0, s4, #12
    v.extract    s4, v2, #14
    s.shli       s7, s1, #32
    s.cmp.le     s1, s6, s3
    v.extract    s3, v4, #15
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v0, s1, #13
    v.extract    s1, v2, #15
    s.shli       s7, s3, #32
    s.cmp.le     s3, s6, s4
    s.or         s4, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #14
    s.cmp.le     s3, s4, s1
    v.movi       v2, #0
    v.insert     v0, s3, #15
    v.movi       v3, #1
    v.movi       v4, #0
    v.cmp.ne     p1, v0, v2
    @p1 v.sel        v0, v11, v12
    v.movi       v2, #1
    v.movi       v5, #0
    vf.add       v7, v8, v0
    v.movi       v0, #1
    v.movi       v8, #0
    v.movi       v10, #1
    v.movi       v13, #0
    vf.cmp.eq    p1, v7, v12
    @p1 v.sel        v7, v3, v4
    v.movi       v3, #0
    v.movi       v4, #0
    v.cmp.eq     p1, v7, v15
    @p1 v.sel        v7, v2, v5
    @p1 v.sel        v2, v0, v8
    @p1 v.sel        v0, v10, v13
    v.extract    s1, v7, #0
    v.extract    s3, v2, #1
    s.lshri      s4, s1, #32
    v.movi       v2, #1
    v.movi       v5, #0
    v.insert     v3, s1, #0
    v.insert     v4, s4, #0
    s.lshri      s1, s3, #32
    v.extract    s4, v0, #2
    @p1 v.sel        v0, v2, v5
    v.movi       v2, #1
    v.movi       v5, #0
    v.insert     v3, s3, #1
    v.insert     v4, s1, #1
    s.lshri      s1, s4, #32
    v.extract    s3, v0, #3
    @p1 v.sel        v0, v2, v5
    v.movi       v2, #1
    v.movi       v5, #0
    v.insert     v3, s4, #2
    v.insert     v4, s1, #2
    s.lshri      s1, s3, #32
    v.extract    s4, v0, #4
    @p1 v.sel        v0, v2, v5
    v.movi       v2, #1
    v.movi       v5, #0
    v.insert     v3, s3, #3
    v.insert     v4, s1, #3
    s.lshri      s1, s4, #32
    v.extract    s3, v0, #5
    @p1 v.sel        v0, v2, v5
    v.movi       v2, #1
    v.movi       v5, #0
    v.insert     v3, s4, #4
    v.insert     v4, s1, #4
    s.lshri      s1, s3, #32
    v.extract    s4, v0, #6
    @p1 v.sel        v0, v2, v5
    v.movi       v2, #1
    v.movi       v5, #0
    v.insert     v3, s3, #5
    v.insert     v4, s1, #5
    s.lshri      s1, s4, #32
    v.extract    s3, v0, #7
    @p1 v.sel        v0, v2, v5
    v.movi       v2, #1
    v.movi       v5, #0
    v.insert     v3, s4, #6
    v.insert     v4, s1, #6
    s.lshri      s1, s3, #32
    v.extract    s4, v0, #8
    @p1 v.sel        v0, v2, v5
    v.movi       v2, #1
    v.movi       v5, #0
    v.insert     v3, s3, #7
    v.insert     v4, s1, #7
    s.lshri      s1, s4, #32
    v.extract    s3, v0, #9
    @p1 v.sel        v0, v2, v5
    v.movi       v2, #1
    v.movi       v5, #0
    v.insert     v3, s4, #8
    v.insert     v4, s1, #8
    s.lshri      s1, s3, #32
    v.extract    s4, v0, #10
    @p1 v.sel        v0, v2, v5
    v.movi       v2, #1
    v.movi       v5, #0
    v.insert     v3, s3, #9
    v.insert     v4, s1, #9
    s.lshri      s1, s4, #32
    v.extract    s3, v0, #11
    @p1 v.sel        v0, v2, v5
    v.movi       v2, #1
    v.movi       v5, #0
    v.insert     v3, s4, #10
    v.insert     v4, s1, #10
    s.lshri      s1, s3, #32
    v.extract    s4, v0, #12
    @p1 v.sel        v0, v2, v5
    v.movi       v2, #1
    v.movi       v5, #0
    v.insert     v3, s3, #11
    v.insert     v4, s1, #11
    s.lshri      s1, s4, #32
    v.extract    s3, v0, #13
    @p1 v.sel        v0, v2, v5
    v.movi       v2, #1
    v.movi       v5, #0
    v.insert     v3, s4, #12
    v.insert     v4, s1, #12
    s.lshri      s1, s3, #32
    v.extract    s4, v0, #14
    @p1 v.sel        v0, v2, v5
    v.insert     v3, s3, #13
    v.insert     v4, s1, #13
    s.lshri      s1, s4, #32
    v.extract    s3, v0, #15
    v.insert     v3, s4, #14
    v.insert     v4, s1, #14
    s.lshri      s1, s3, #32
    v.insert     v3, s3, #15
    v.insert     v4, s1, #15
    s.movz       s1, #0
    v.extract    s3, v3, #0
    v.extract    s4, v4, #0
    v.extract    s6, v4, #1
    s.shli       s7, s4, #32
    v.movi       v0, #0
    s.or         s4, s3, s7
    v.extract    s3, v3, #1
    s.shli       s7, s6, #32
    s.cmp.ne     s6, s4, s1
    v.extract    s1, v4, #2
    s.or         s4, s3, s7
    s.movz       s3, #0
    v.insert     v0, s6, #0
    v.extract    s6, v3, #2
    s.shli       s7, s1, #32
    s.cmp.ne     s1, s4, s3
    v.extract    s3, v4, #3
    s.or         s4, s6, s7
    s.movz       s6, #0
    v.insert     v0, s1, #1
    v.extract    s1, v3, #3
    s.shli       s7, s3, #32
    s.cmp.ne     s3, s4, s6
    v.extract    s4, v4, #4
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #2
    v.extract    s3, v3, #4
    s.shli       s7, s4, #32
    s.cmp.ne     s4, s6, s1
    v.extract    s1, v4, #5
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v0, s4, #3
    v.extract    s4, v3, #5
    s.shli       s7, s1, #32
    s.cmp.ne     s1, s6, s3
    v.extract    s3, v4, #6
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v0, s1, #4
    v.extract    s1, v3, #6
    s.shli       s7, s3, #32
    s.cmp.ne     s3, s6, s4
    v.extract    s4, v4, #7
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #5
    v.extract    s3, v3, #7
    s.shli       s7, s4, #32
    s.cmp.ne     s4, s6, s1
    v.extract    s1, v4, #8
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v0, s4, #6
    v.extract    s4, v3, #8
    s.shli       s7, s1, #32
    s.cmp.ne     s1, s6, s3
    v.extract    s3, v4, #9
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v0, s1, #7
    v.extract    s1, v3, #9
    s.shli       s7, s3, #32
    s.cmp.ne     s3, s6, s4
    v.extract    s4, v4, #10
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #8
    v.extract    s3, v3, #10
    s.shli       s7, s4, #32
    s.cmp.ne     s4, s6, s1
    v.extract    s1, v4, #11
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v0, s4, #9
    v.extract    s4, v3, #11
    s.shli       s7, s1, #32
    s.cmp.ne     s1, s6, s3
    v.extract    s3, v4, #12
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v0, s1, #10
    v.extract    s1, v3, #12
    s.shli       s7, s3, #32
    s.cmp.ne     s3, s6, s4
    v.extract    s4, v4, #13
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #11
    v.extract    s3, v3, #13
    s.shli       s7, s4, #32
    s.cmp.ne     s4, s6, s1
    v.extract    s1, v4, #14
    v.sub        v2, v6, v1
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v0, s4, #12
    v.extract    s4, v3, #14
    s.shli       s7, s1, #32
    s.cmp.ne     s1, s6, s3
    v.extract    s3, v4, #15
    v.extract    s6, v2, #0
    s.or         s8, s4, s7
    s.movz       s4, #0
    v.insert     v0, s1, #13
    v.extract    s1, v3, #15
    s.shli       s7, s3, #32
    s.shli       s3, s6, #32
    s.cmp.ne     s6, s8, s4
    v.extract    s4, v2, #1
    s.or         s8, s1, s7
    s.movz       s1, #0
    s.ashri      s7, s3, #32
    v.insert     v0, s6, #14
    v.movi       v1, #0
    v.movi       v3, #0
    s.shli       s3, s4, #32
    s.cmp.ne     s4, s8, s1
    s.lshri      s1, s7, #32
    v.extract    s6, v2, #2
    s.ashri      s8, s3, #32
    v.insert     v0, s4, #15
    v.insert     v1, s7, #0
    v.insert     v3, s1, #0
    s.shli       s1, s6, #32
    s.lshri      s3, s8, #32
    v.extract    s4, v2, #3
    s.ashri      s6, s1, #32
    v.insert     v1, s8, #1
    v.insert     v3, s3, #1
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v2, #4
    s.ashri      s7, s1, #32
    v.insert     v1, s6, #2
    v.insert     v3, s3, #2
    s.shli       s1, s4, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v2, #5
    s.ashri      s6, s1, #32
    v.insert     v1, s7, #3
    v.insert     v3, s3, #3
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v2, #6
    s.ashri      s7, s1, #32
    v.insert     v1, s6, #4
    v.insert     v3, s3, #4
    s.shli       s1, s4, #32
    s.lshri      s3, s7, #32
    s.ashri      s4, s1, #32
    v.insert     v1, s7, #5
    v.insert     v3, s3, #5
    s.lshri      s1, s4, #32
    v.insert     v1, s4, #6
    v.insert     v3, s1, #6
    v.movi       v4, #0
    v.extract    s1, v2, #7
    v.cmp.ne     p1, v0, v4
    s.shli       s3, s1, #32
    p.or         p4, p2, p1
    v.extract    s1, v2, #8
    s.ashri      s4, s3, #32
    s.shli       s3, s1, #32
    s.lshri      s1, s4, #32
    v.extract    s6, v2, #9
    s.ashri      s7, s3, #32
    v.insert     v1, s4, #7
    v.insert     v3, s1, #7
    s.shli       s1, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v2, #10
    s.ashri      s6, s1, #32
    v.insert     v1, s7, #8
    v.insert     v3, s3, #8
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v2, #11
    s.ashri      s7, s1, #32
    v.insert     v1, s6, #9
    v.insert     v3, s3, #9
    s.shli       s1, s4, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v2, #12
    s.ashri      s6, s1, #32
    v.insert     v1, s7, #10
    v.insert     v3, s3, #10
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v2, #13
    s.ashri      s7, s1, #32
    v.insert     v1, s6, #11
    v.insert     v3, s3, #11
    s.shli       s1, s4, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v2, #14
    s.ashri      s6, s1, #32
    v.insert     v1, s7, #12
    v.insert     v3, s3, #12
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v2, #15
    s.ashri      s7, s1, #32
    v.insert     v1, s6, #13
    v.insert     v3, s3, #13
    s.shli       s1, s4, #32
    s.lshri      s3, s7, #32
    s.ashri      s4, s1, #32
    v.insert     v1, s7, #14
    v.insert     v3, s3, #14
    s.lshri      s1, s4, #32
    v.insert     v1, s4, #15
    v.insert     v3, s1, #15
    s.movz       s1, #0
    v.extract    s3, v1, #0
    v.extract    s4, v3, #0
    v.extract    s6, v3, #1
    s.shli       s7, s4, #32
    v.movi       v0, #0
    s.or         s4, s3, s7
    v.extract    s3, v1, #1
    s.shli       s7, s6, #32
    s.cmp.le     s6, s4, s1
    v.extract    s1, v3, #2
    s.or         s4, s3, s7
    s.movz       s3, #0
    v.insert     v0, s6, #0
    v.extract    s6, v1, #2
    s.shli       s7, s1, #32
    s.cmp.le     s1, s4, s3
    v.extract    s3, v3, #3
    s.or         s4, s6, s7
    s.movz       s6, #0
    v.insert     v0, s1, #1
    v.extract    s1, v1, #3
    s.shli       s7, s3, #32
    s.cmp.le     s3, s4, s6
    v.extract    s4, v3, #4
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #2
    v.extract    s3, v1, #4
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s1
    v.extract    s1, v3, #5
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v0, s4, #3
    v.extract    s4, v1, #5
    s.shli       s7, s1, #32
    s.cmp.le     s1, s6, s3
    v.extract    s3, v3, #6
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v0, s1, #4
    v.extract    s1, v1, #6
    s.shli       s7, s3, #32
    s.cmp.le     s3, s6, s4
    v.extract    s4, v3, #7
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #5
    v.extract    s3, v1, #7
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s1
    v.extract    s1, v3, #8
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v0, s4, #6
    v.extract    s4, v1, #8
    s.shli       s7, s1, #32
    s.cmp.le     s1, s6, s3
    v.extract    s3, v3, #9
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v0, s1, #7
    v.extract    s1, v1, #9
    s.shli       s7, s3, #32
    s.cmp.le     s3, s6, s4
    v.extract    s4, v3, #10
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #8
    v.extract    s3, v1, #10
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s1
    v.extract    s1, v3, #11
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v0, s4, #9
    v.extract    s4, v1, #11
    s.shli       s7, s1, #32
    s.cmp.le     s1, s6, s3
    v.extract    s3, v3, #12
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v0, s1, #10
    v.extract    s1, v1, #12
    s.shli       s7, s3, #32
    s.cmp.le     s3, s6, s4
    v.extract    s4, v3, #13
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #11
    v.extract    s3, v1, #13
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s1
    v.extract    s1, v3, #14
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v0, s4, #12
    v.extract    s4, v1, #14
    s.shli       s7, s1, #32
    s.cmp.le     s1, s6, s3
    v.extract    s3, v3, #15
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v0, s1, #13
    v.extract    s1, v1, #15
    s.shli       s7, s3, #32
    s.cmp.le     s3, s6, s4
    s.or         s4, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #14
    s.cmp.le     s3, s4, s1
    v.movi       v1, #0
    v.insert     v0, s3, #15
    v.movi       v2, #1
    v.movi       v3, #0
    v.cmp.ne     p1, v0, v1
    @p1 v.sel        v0, v11, v12
    v.movi       v1, #1
    v.movi       v4, #0
    vf.add       v5, v9, v0
    v.movi       v0, #1
    v.movi       v6, #0
    v.movi       v7, #1
    v.movi       v8, #0
    vf.cmp.eq    p1, v5, v12
    @p1 v.sel        v5, v2, v3
    v.movi       v2, #0
    v.movi       v3, #0
    v.cmp.eq     p1, v5, v15
    @p1 v.sel        v5, v1, v4
    @p1 v.sel        v1, v0, v6
    @p1 v.sel        v0, v7, v8
    v.extract    s1, v5, #0
    v.extract    s3, v1, #1
    s.lshri      s4, s1, #32
    v.movi       v1, #1
    v.movi       v4, #0
    v.insert     v2, s1, #0
    v.insert     v3, s4, #0
    s.lshri      s1, s3, #32
    v.extract    s4, v0, #2
    @p1 v.sel        v0, v1, v4
    v.movi       v1, #1
    v.movi       v4, #0
    v.insert     v2, s3, #1
    v.insert     v3, s1, #1
    s.lshri      s1, s4, #32
    v.extract    s3, v0, #3
    @p1 v.sel        v0, v1, v4
    v.movi       v1, #1
    v.movi       v4, #0
    v.insert     v2, s4, #2
    v.insert     v3, s1, #2
    s.lshri      s1, s3, #32
    v.extract    s4, v0, #4
    @p1 v.sel        v0, v1, v4
    v.movi       v1, #1
    v.movi       v4, #0
    v.insert     v2, s3, #3
    v.insert     v3, s1, #3
    s.lshri      s1, s4, #32
    v.extract    s3, v0, #5
    @p1 v.sel        v0, v1, v4
    v.movi       v1, #1
    v.movi       v4, #0
    v.insert     v2, s4, #4
    v.insert     v3, s1, #4
    s.lshri      s1, s3, #32
    v.extract    s4, v0, #6
    @p1 v.sel        v0, v1, v4
    v.movi       v1, #1
    v.movi       v4, #0
    v.insert     v2, s3, #5
    v.insert     v3, s1, #5
    s.lshri      s1, s4, #32
    v.extract    s3, v0, #7
    @p1 v.sel        v0, v1, v4
    v.movi       v1, #1
    v.movi       v4, #0
    v.insert     v2, s4, #6
    v.insert     v3, s1, #6
    s.lshri      s1, s3, #32
    v.extract    s4, v0, #8
    @p1 v.sel        v0, v1, v4
    v.movi       v1, #1
    v.movi       v4, #0
    v.insert     v2, s3, #7
    v.insert     v3, s1, #7
    s.lshri      s1, s4, #32
    v.extract    s3, v0, #9
    @p1 v.sel        v0, v1, v4
    v.movi       v1, #1
    v.movi       v4, #0
    v.insert     v2, s4, #8
    v.insert     v3, s1, #8
    s.lshri      s1, s3, #32
    v.extract    s4, v0, #10
    @p1 v.sel        v0, v1, v4
    v.movi       v1, #1
    v.movi       v4, #0
    v.insert     v2, s3, #9
    v.insert     v3, s1, #9
    s.lshri      s1, s4, #32
    v.extract    s3, v0, #11
    @p1 v.sel        v0, v1, v4
    v.movi       v1, #1
    v.movi       v4, #0
    v.insert     v2, s4, #10
    v.insert     v3, s1, #10
    s.lshri      s1, s3, #32
    v.extract    s4, v0, #12
    @p1 v.sel        v0, v1, v4
    v.movi       v1, #1
    v.movi       v4, #0
    v.insert     v2, s3, #11
    v.insert     v3, s1, #11
    s.lshri      s1, s4, #32
    v.extract    s3, v0, #13
    @p1 v.sel        v0, v1, v4
    v.movi       v1, #1
    v.movi       v4, #0
    v.insert     v2, s4, #12
    v.insert     v3, s1, #12
    s.lshri      s1, s3, #32
    v.extract    s4, v0, #14
    @p1 v.sel        v0, v1, v4
    v.insert     v2, s3, #13
    v.insert     v3, s1, #13
    s.lshri      s1, s4, #32
    v.extract    s3, v0, #15
    v.insert     v2, s4, #14
    v.insert     v3, s1, #14
    s.lshri      s1, s3, #32
    v.insert     v2, s3, #15
    v.insert     v3, s1, #15
    s.movz       s1, #0
    v.extract    s3, v2, #0
    v.extract    s4, v3, #0
    v.extract    s6, v3, #1
    s.shli       s7, s4, #32
    v.movi       v0, #0
    s.or         s4, s3, s7
    v.extract    s3, v2, #1
    s.shli       s7, s6, #32
    s.cmp.ne     s6, s4, s1
    v.extract    s1, v3, #2
    s.or         s4, s3, s7
    s.movz       s3, #0
    v.insert     v0, s6, #0
    v.extract    s6, v2, #2
    s.shli       s7, s1, #32
    s.cmp.ne     s1, s4, s3
    v.extract    s3, v3, #3
    s.or         s4, s6, s7
    s.movz       s6, #0
    v.insert     v0, s1, #1
    v.extract    s1, v2, #3
    s.shli       s7, s3, #32
    s.cmp.ne     s3, s4, s6
    v.extract    s4, v3, #4
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #2
    v.extract    s3, v2, #4
    s.shli       s7, s4, #32
    s.cmp.ne     s4, s6, s1
    v.extract    s1, v3, #5
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v0, s4, #3
    v.extract    s4, v2, #5
    s.shli       s7, s1, #32
    s.cmp.ne     s1, s6, s3
    v.extract    s3, v3, #6
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v0, s1, #4
    v.extract    s1, v2, #6
    s.shli       s7, s3, #32
    s.cmp.ne     s3, s6, s4
    v.extract    s4, v3, #7
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #5
    v.extract    s3, v2, #7
    s.shli       s7, s4, #32
    s.cmp.ne     s4, s6, s1
    v.extract    s1, v3, #8
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v0, s4, #6
    v.extract    s4, v2, #8
    s.shli       s7, s1, #32
    s.cmp.ne     s1, s6, s3
    v.extract    s3, v3, #9
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v0, s1, #7
    v.extract    s1, v2, #9
    s.shli       s7, s3, #32
    s.cmp.ne     s3, s6, s4
    v.extract    s4, v3, #10
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #8
    v.extract    s3, v2, #10
    s.shli       s7, s4, #32
    s.cmp.ne     s4, s6, s1
    v.extract    s1, v3, #11
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v0, s4, #9
    v.extract    s4, v2, #11
    s.shli       s7, s1, #32
    s.cmp.ne     s1, s6, s3
    v.extract    s3, v3, #12
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v0, s1, #10
    v.extract    s1, v2, #12
    s.shli       s7, s3, #32
    s.cmp.ne     s3, s6, s4
    v.extract    s4, v3, #13
    s.or         s6, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #11
    v.extract    s3, v2, #13
    s.shli       s7, s4, #32
    s.cmp.ne     s4, s6, s1
    v.extract    s1, v3, #14
    s.or         s6, s3, s7
    s.movz       s3, #0
    v.insert     v0, s4, #12
    v.extract    s4, v2, #14
    s.shli       s7, s1, #32
    s.cmp.ne     s1, s6, s3
    v.extract    s3, v3, #15
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v0, s1, #13
    v.extract    s1, v2, #15
    s.shli       s7, s3, #32
    s.cmp.ne     s3, s6, s4
    s.or         s4, s1, s7
    s.movz       s1, #0
    v.insert     v0, s3, #14
    s.cmp.ne     s3, s4, s1
    v.movi       v1, #0
    v.insert     v0, s3, #15
    v.movi       v2, #1
    v.movi       v3, #0
    v.cmp.ne     p1, v0, v1
    p.or         p2, p4, p1
    s.shli       s1, s2, #0                      // element offset -> bytes (x1)
    @p2 v.sel        v0, v2, v3
    s.add        s2, s5, s1                      // &out_ptr0[...]
    @p3 v.st.b       [s2, #0], v0
__rctx_next:
    exit
