#!/bin/bash
set -eu
export OMP_NUM_THREADS=1 MAX_JOBS=1 CUDA_VISIBLE_DEVICES= HF_HUB_OFFLINE=1 HF_HOME="$HOME/r41-fp8-kern-hf"
export TNCA_PROFILE=core-vrf-sync-v5-x8-g2c4-dp TNCA_BACKEND=systemc-tlm-grid TNCA_TLM_BINARY="$HOME/r41_vl_reason_dp/build/tnca-chip" TNCA_TLM_CONFIG="$HOME/r41_vl_reason_dp/src/tools/performance_harness/systemc/configs/r41-mma-dp.cfg" TNCA_TLM_OUT="$HOME/r41_x8_equal_output_suite_default_${1}_tlm_20261101" TNCA_HOST_TIMEOUT=600 TNCA_X8_EQUAL_OUTPUT=$1 TNCA_IEEE_DIV=0
unset TNCA_EQUAL_ROWS TNCA_X8_SPILL_LANES TNCA_X8_PIPELINE TNCA_CODE_CACHE_POLICY
cd "$HOME/r41_current_x8_equal_output_20261101"
exec "$HOME/flux-venv/bin/python" -u "$HOME/r41_cache_pinned_fp8_20261031.py" --group v4 --group compile --quick --out "$HOME/r41_x8_equal_output_suite_default_${1}_20261101"
