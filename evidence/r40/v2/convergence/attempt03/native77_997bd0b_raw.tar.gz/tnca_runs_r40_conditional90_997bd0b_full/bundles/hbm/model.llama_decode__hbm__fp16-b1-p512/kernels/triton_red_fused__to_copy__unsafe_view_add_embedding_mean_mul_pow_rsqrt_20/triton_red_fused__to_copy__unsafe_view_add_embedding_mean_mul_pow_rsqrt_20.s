    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_out_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // in_ptr1: device_ptr64 at arg_base+16
    s.ld.d       s5, [s1, #24]                   // in_ptr2: device_ptr64 at arg_base+24
    s.ld.d       s6, [s1, #32]                   // in_ptr3: device_ptr64 at arg_base+32
    s.ld.d       s7, [s1, #40]                   // in_ptr4: device_ptr64 at arg_base+40
    s.ld.d       s8, [s1, #48]                   // out_ptr1: device_ptr64 at arg_base+48
    v.iota       v0                              // arange(0, VLEN)
    s.ld.d       s1, [s3, #0]                    // one element, not a vector
    v.movi       v1, #0
    v.movi       v2, #0
    v.insert     v1, s1, #0
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #0
    v.insert     v1, s1, #1
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #1
    v.insert     v1, s1, #2
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #2
    v.insert     v1, s1, #3
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #3
    v.insert     v1, s1, #4
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #4
    v.insert     v1, s1, #5
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #5
    v.insert     v1, s1, #6
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #6
    v.insert     v1, s1, #7
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #7
    v.insert     v1, s1, #8
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #8
    v.insert     v1, s1, #9
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #9
    v.insert     v1, s1, #10
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #10
    v.insert     v1, s1, #11
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #11
    v.insert     v1, s1, #12
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #12
    v.insert     v1, s1, #13
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #13
    v.insert     v1, s1, #14
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #14
    v.insert     v1, s1, #15
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #15
    s.rdspecial  s1, arg_base
    s.ld.d       s3, [s1, #64]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.addi       s1, s3, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 1)
    s.movz       s9, #0
    s.st.d       [s1, #0], s2
    s.movz       s9, #1024
    s.st.d       [s1, #8], s9
    s.movz       s9, #2
    s.st.d       [s1, #48], s9
    s.movz       s9, #16
    s.st.d       [s1, #88], s9
    .li       s9, #4294967296
    s.st.d       [s1, #104], s9
    td.load      d0, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s3, #256                    // TensorMap 1: tl.make_tensor_descriptor (rank 1)
    s.movz       s9, #0
    s.st.d       [s1, #0], s5
    s.movz       s9, #1024
    s.st.d       [s1, #8], s9
    s.movz       s9, #2
    s.st.d       [s1, #48], s9
    s.movz       s9, #16
    s.st.d       [s1, #88], s9
    .li       s9, #4294967296
    s.st.d       [s1, #104], s9
    td.load      d1, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s3, #512                    // TensorMap 2: tl.make_tensor_descriptor (rank 1)
    s.movz       s3, #0
    s.st.d       [s1, #0], s6
    s.movz       s3, #1024
    s.st.d       [s1, #8], s3
    s.movz       s3, #2
    s.st.d       [s1, #48], s3
    s.movz       s3, #16
    s.st.d       [s1, #88], s3
    .li       s3, #4294967296
    s.st.d       [s1, #104], s3
    td.load      d2, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s3, #1024
    s.movz       s9, #16
    s.addi       s10, s1, #0
    v.movi       v3, #0
    v.movi       v4, #0
    v.mov        v4, v3
for_1:
    s.cmp.ge     s11, s10, s3
    br.nz        s11, endfor_2
    v.splat      v3, s10
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s10
    v.iota       v7                              // arange(0, VLEN)
    v.splat      v8, s10
    v.iota       v9                              // arange(0, VLEN)
    s.movz       s11, #1024
    s.movz       s12, #1024
    s.movz       s13, #1024
    v.extract    s14, v2, #0
    s.muli       s15, s10, #2
    s.muli       s16, s10, #2
    v.add        v10, v3, v5
    v.movi       v3, #0
    v.splat      v5, s11
    s.muli       s11, s10, #2
    v.add        v11, v6, v7
    v.movi       v6, #0
    v.splat      v7, s12
    v.add        v12, v8, v9
    v.movi       v8, #0
    v.splat      v9, s13
    v.extract    s12, v1, #0
    s.shli       s13, s14, #32
    v.cmp.ge     p1, v10, v3
    s.or         s14, s12, s13
    v.cmp.lt     p2, v10, v5
    v.cmp.ge     p3, v11, v6
    v.cmp.lt     p4, v11, v7
    v.movi       v3, #0
    s.add        s12, s2, s15
    p.and        p5, p1, p2
    v.cmp.ge     p1, v12, v8
    s.add        s13, s5, s16
    p.and        p2, p3, p4
    v.cmp.lt     p3, v12, v9
    s.add        s15, s6, s11
    p.and        p4, p1, p3
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v5, [s12, #0]
    v.splat      v6, s10
    s.movz       s11, #0
    v.movi       v7, #1024
    v.add        v8, v6, v0
    s.cmp.ge     s12, s14, s11
    v.cmp.lt     p1, v8, v7
    v.extract    s11, v2, #1
    v.extract    s14, v1, #1
    s.shli       s16, s11, #32
    v.extract    s11, v2, #2
    s.or         s17, s14, s16
    s.movz       s14, #0
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v6, [s13, #0]
    v.extract    s13, v1, #2
    s.shli       s16, s11, #32
    s.cmp.ge     s11, s17, s14
    s.or         s14, s13, s16
    s.movz       s13, #0
    vf.cvt.f16.f32 v7, v5
    v.extract    s16, v2, #3
    s.cmp.ge     s17, s14, s13
    v.extract    s13, v1, #3
    s.shli       s14, s16, #32
    s.or         s16, s13, s14
    v.extract    s13, v2, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v5, [s15, #0]
    v.insert     v3, s12, #0
    s.movz       s12, #0
    v.extract    s14, v1, #4
    v.insert     v3, s11, #1
    s.shli       s11, s13, #32
    s.cmp.ge     s13, s16, s12
    v.insert     v3, s17, #2
    s.or         s12, s14, s11
    s.movz       s11, #0
    v.insert     v3, s13, #3
    vf.cvt.f16.f32 v9, v6
    v.extract    s13, v2, #5
    v.extract    s14, v1, #5
    s.shli       s15, s13, #32
    s.cmp.ge     s13, s12, s11
    v.extract    s11, v2, #6
    s.or         s12, s14, s15
    s.movz       s14, #0
    v.insert     v3, s13, #4
    v.extract    s13, v1, #6
    s.shli       s15, s11, #32
    s.cmp.ge     s11, s12, s14
    s.or         s12, s13, s15
    v.insert     v3, s11, #5
    vf.cvt.f16.f32 v6, v5
    v.extract    s11, v2, #7
    s.movz       s13, #0
    v.extract    s14, v1, #7
    s.shli       s15, s11, #32
    s.cmp.ge     s11, s12, s13
    v.extract    s12, v2, #8
    s.or         s13, s14, s15
    s.movz       s14, #0
    v.insert     v3, s11, #6
    v.extract    s11, v1, #8
    s.shli       s15, s12, #32
    s.cmp.ge     s12, s13, s14
    v.extract    s13, v2, #9
    s.or         s14, s11, s15
    s.movz       s11, #0
    v.insert     v3, s12, #7
    v.extract    s12, v1, #9
    s.shli       s15, s13, #32
    s.cmp.ge     s13, s14, s11
    v.extract    s11, v2, #10
    s.or         s14, s12, s15
    s.movz       s12, #0
    v.insert     v3, s13, #8
    v.extract    s13, v1, #10
    s.shli       s15, s11, #32
    s.cmp.ge     s11, s14, s12
    v.extract    s12, v2, #11
    s.or         s14, s13, s15
    s.movz       s13, #0
    v.insert     v3, s11, #9
    v.extract    s11, v1, #11
    s.shli       s15, s12, #32
    s.cmp.ge     s12, s14, s13
    v.extract    s13, v2, #12
    s.or         s14, s11, s15
    s.movz       s11, #0
    v.insert     v3, s12, #10
    v.extract    s12, v1, #12
    s.shli       s15, s13, #32
    s.cmp.ge     s13, s14, s11
    v.extract    s11, v2, #13
    s.or         s14, s12, s15
    s.movz       s12, #0
    v.insert     v3, s13, #11
    v.extract    s13, v1, #13
    s.shli       s15, s11, #32
    s.cmp.ge     s11, s14, s12
    v.extract    s12, v2, #14
    s.or         s14, s13, s15
    s.movz       s13, #0
    v.insert     v3, s11, #12
    v.extract    s11, v1, #14
    s.shli       s15, s12, #32
    s.cmp.ge     s12, s14, s13
    v.extract    s13, v2, #15
    v.extract    s14, v2, #0
    s.or         s16, s11, s15
    s.movz       s11, #0
    v.insert     v3, s12, #13
    v.extract    s12, v1, #15
    s.shli       s15, s13, #32
    v.extract    s13, v1, #0
    s.shli       s17, s14, #32
    s.cmp.ge     s14, s16, s11
    v.extract    s11, v2, #1
    s.or         s16, s12, s15
    s.movz       s12, #0
    s.or         s15, s13, s17
    s.movz       s13, #32000
    v.insert     v3, s14, #14
    v.movi       v5, #0
    v.extract    s14, v1, #1
    s.shli       s17, s11, #32
    s.cmp.ge     s11, s16, s12
    s.cmp.lt     s12, s15, s13
    v.extract    s13, v2, #2
    s.or         s15, s14, s17
    s.movz       s14, #32000
    v.insert     v3, s11, #15
    v.insert     v5, s12, #0
    v.extract    s11, v1, #2
    s.shli       s12, s13, #32
    s.cmp.lt     s13, s15, s14
    v.extract    s14, v2, #3
    s.or         s15, s11, s12
    s.movz       s11, #32000
    v.insert     v5, s13, #1
    v.extract    s12, v1, #3
    s.shli       s13, s14, #32
    s.cmp.lt     s14, s15, s11
    v.extract    s11, v2, #4
    s.or         s15, s12, s13
    s.movz       s12, #32000
    v.insert     v5, s14, #2
    v.extract    s13, v1, #4
    s.shli       s14, s11, #32
    s.cmp.lt     s11, s15, s12
    v.extract    s12, v2, #5
    s.or         s15, s13, s14
    s.movz       s13, #32000
    v.insert     v5, s11, #3
    v.extract    s11, v1, #5
    s.shli       s14, s12, #32
    s.cmp.lt     s12, s15, s13
    v.extract    s13, v2, #6
    s.or         s15, s11, s14
    s.movz       s11, #32000
    v.insert     v5, s12, #4
    v.extract    s12, v1, #6
    s.shli       s14, s13, #32
    s.cmp.lt     s13, s15, s11
    v.movi       v10, #0
    s.or         s11, s12, s14
    v.insert     v5, s13, #5
    v.cmp.ne     p2, v3, v10
    v.extract    s12, v2, #7
    s.movz       s13, #32000
    v.extract    s14, v1, #7
    s.shli       s15, s12, #32
    s.cmp.lt     s12, s11, s13
    v.extract    s11, v2, #8
    s.or         s13, s14, s15
    s.movz       s14, #32000
    v.insert     v5, s12, #6
    v.extract    s12, v1, #8
    s.shli       s15, s11, #32
    s.cmp.lt     s11, s13, s14
    v.extract    s13, v2, #9
    s.or         s14, s12, s15
    s.movz       s12, #32000
    v.insert     v5, s11, #7
    v.extract    s11, v1, #9
    s.shli       s15, s13, #32
    s.cmp.lt     s13, s14, s12
    v.extract    s12, v2, #10
    s.or         s14, s11, s15
    s.movz       s11, #32000
    v.insert     v5, s13, #8
    v.extract    s13, v1, #10
    s.shli       s15, s12, #32
    s.cmp.lt     s12, s14, s11
    v.extract    s11, v2, #11
    s.or         s14, s13, s15
    s.movz       s13, #32000
    v.insert     v5, s12, #9
    v.extract    s12, v1, #11
    s.shli       s15, s11, #32
    s.cmp.lt     s11, s14, s13
    v.extract    s13, v2, #12
    s.or         s14, s12, s15
    s.movz       s12, #32000
    v.insert     v5, s11, #10
    v.extract    s11, v1, #12
    s.shli       s15, s13, #32
    s.cmp.lt     s13, s14, s12
    v.extract    s12, v2, #13
    s.or         s14, s11, s15
    s.movz       s11, #32000
    v.insert     v5, s13, #11
    v.extract    s13, v1, #13
    s.shli       s15, s12, #32
    s.cmp.lt     s12, s14, s11
    v.extract    s11, v2, #14
    s.or         s14, s13, s15
    s.movz       s13, #32000
    v.insert     v5, s12, #12
    v.extract    s12, v1, #14
    s.shli       s15, s11, #32
    s.cmp.lt     s11, s14, s13
    v.extract    s13, v2, #15
    s.or         s14, s12, s15
    s.movz       s12, #32000
    v.insert     v5, s11, #13
    v.extract    s11, v1, #15
    s.shli       s15, s13, #32
    s.cmp.lt     s13, s14, s12
    s.or         s12, s11, s15
    s.movz       s11, #32000
    v.insert     v5, s13, #14
    s.cmp.lt     s13, s12, s11
    v.movi       v3, #0
    v.insert     v5, s13, #15
    v.movi       v10, #0
    v.movi       v11, #1
    v.cmp.ne     p3, v5, v3
    p.and        p4, p2, p3
    s.movz       s11, #0
    @p4 v.sel        v3, v10, v11
    v.reduce.or  s12, v3
    s.cmp.eq     s13, s12, s11
    br.nz        s13, assert_ok_3
    trap         #677351
assert_ok_3:
    v.extract    s11, v2, #0
    v.extract    s12, v1, #0
    s.shli       s13, s11, #32
    v.extract    s11, v2, #1
    s.or         s14, s12, s13
    s.movz       s12, #1024
    v.extract    s13, v1, #1
    s.shli       s15, s11, #32
    s.mul        s11, s14, s12
    v.extract    s12, v2, #2
    s.or         s14, s13, s15
    s.movz       s13, #1024
    v.extract    s15, v1, #2
    s.shli       s16, s12, #32
    s.mul        s12, s14, s13
    v.extract    s13, v2, #3
    v.movi       v3, #0
    v.movi       v5, #0
    s.or         s14, s15, s16
    s.movz       s15, #1024
    s.lshri      s16, s11, #32
    v.extract    s17, v1, #3
    s.shli       s18, s13, #32
    s.mul        s13, s14, s15
    v.extract    s14, v2, #4
    v.insert     v3, s11, #0
    v.insert     v5, s16, #0
    s.or         s11, s17, s18
    s.movz       s15, #1024
    s.lshri      s16, s12, #32
    v.extract    s17, v1, #4
    s.shli       s18, s14, #32
    s.mul        s14, s11, s15
    v.extract    s11, v2, #5
    v.insert     v3, s12, #1
    v.insert     v5, s16, #1
    s.or         s12, s17, s18
    s.movz       s15, #1024
    s.lshri      s16, s13, #32
    v.extract    s17, v1, #5
    s.shli       s18, s11, #32
    s.mul        s11, s12, s15
    v.extract    s12, v2, #6
    v.insert     v3, s13, #2
    v.insert     v5, s16, #2
    s.or         s13, s17, s18
    s.movz       s15, #1024
    s.lshri      s16, s14, #32
    v.extract    s17, v1, #6
    s.shli       s18, s12, #32
    s.mul        s12, s13, s15
    v.extract    s13, v2, #7
    v.insert     v3, s14, #3
    v.insert     v5, s16, #3
    s.or         s14, s17, s18
    s.movz       s15, #1024
    s.lshri      s16, s11, #32
    v.extract    s17, v1, #7
    s.shli       s18, s13, #32
    s.mul        s13, s14, s15
    v.extract    s14, v2, #8
    v.insert     v3, s11, #4
    v.insert     v5, s16, #4
    s.or         s11, s17, s18
    s.movz       s15, #1024
    s.lshri      s16, s12, #32
    v.extract    s17, v1, #8
    s.shli       s18, s14, #32
    s.mul        s14, s11, s15
    v.extract    s11, v2, #9
    v.insert     v3, s12, #5
    v.insert     v5, s16, #5
    s.or         s12, s17, s18
    s.movz       s15, #1024
    s.lshri      s16, s13, #32
    v.extract    s17, v1, #9
    s.shli       s18, s11, #32
    s.mul        s11, s12, s15
    v.extract    s12, v2, #10
    v.insert     v3, s13, #6
    v.insert     v5, s16, #6
    s.or         s13, s17, s18
    s.movz       s15, #1024
    s.lshri      s16, s14, #32
    v.extract    s17, v1, #10
    s.shli       s18, s12, #32
    s.mul        s12, s13, s15
    v.extract    s13, v2, #11
    v.insert     v3, s14, #7
    v.insert     v5, s16, #7
    s.or         s14, s17, s18
    s.movz       s15, #1024
    s.lshri      s16, s11, #32
    v.extract    s17, v1, #11
    s.shli       s18, s13, #32
    s.mul        s13, s14, s15
    v.extract    s14, v2, #12
    v.insert     v3, s11, #8
    v.insert     v5, s16, #8
    s.or         s11, s17, s18
    s.movz       s15, #1024
    s.lshri      s16, s12, #32
    v.extract    s17, v1, #12
    s.shli       s18, s14, #32
    s.mul        s14, s11, s15
    v.extract    s11, v2, #13
    v.insert     v3, s12, #9
    v.insert     v5, s16, #9
    s.or         s12, s17, s18
    s.movz       s15, #1024
    s.lshri      s16, s13, #32
    v.extract    s17, v1, #13
    s.shli       s18, s11, #32
    s.mul        s11, s12, s15
    v.extract    s12, v2, #14
    v.insert     v3, s13, #10
    v.insert     v5, s16, #10
    s.or         s13, s17, s18
    s.movz       s15, #1024
    s.lshri      s16, s14, #32
    v.extract    s17, v1, #14
    s.shli       s18, s12, #32
    s.mul        s12, s13, s15
    v.extract    s13, v2, #15
    v.insert     v3, s14, #11
    v.insert     v5, s16, #11
    s.or         s14, s17, s18
    s.movz       s15, #1024
    s.lshri      s16, s11, #32
    v.extract    s17, v1, #15
    s.shli       s18, s13, #32
    s.mul        s13, s14, s15
    v.insert     v3, s11, #12
    v.insert     v5, s16, #12
    s.or         s11, s17, s18
    s.movz       s14, #1024
    s.lshri      s15, s12, #32
    v.extract    s16, v8, #0
    s.mul        s17, s11, s14
    v.insert     v3, s12, #13
    v.insert     v5, s15, #13
    s.shli       s11, s16, #32
    s.lshri      s12, s13, #32
    v.extract    s14, v8, #1
    s.ashri      s15, s11, #32
    v.insert     v3, s13, #14
    v.insert     v5, s12, #14
    v.movi       v10, #0
    v.movi       v11, #0
    s.shli       s11, s14, #32
    s.lshri      s12, s17, #32
    s.lshri      s13, s15, #32
    v.extract    s14, v8, #2
    s.ashri      s16, s11, #32
    v.insert     v3, s17, #15
    v.insert     v5, s12, #15
    v.insert     v10, s15, #0
    v.insert     v11, s13, #0
    s.shli       s11, s14, #32
    s.lshri      s12, s16, #32
    v.extract    s13, v8, #3
    s.ashri      s14, s11, #32
    v.insert     v10, s16, #1
    v.insert     v11, s12, #1
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v8, #4
    s.ashri      s15, s11, #32
    v.insert     v10, s14, #2
    v.insert     v11, s12, #2
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v8, #5
    s.ashri      s14, s11, #32
    v.insert     v10, s15, #3
    v.insert     v11, s12, #3
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v8, #6
    s.ashri      s15, s11, #32
    v.insert     v10, s14, #4
    v.insert     v11, s12, #4
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v8, #7
    s.ashri      s14, s11, #32
    v.insert     v10, s15, #5
    v.insert     v11, s12, #5
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v8, #8
    s.ashri      s15, s11, #32
    v.insert     v10, s14, #6
    v.insert     v11, s12, #6
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v8, #9
    s.ashri      s14, s11, #32
    v.insert     v10, s15, #7
    v.insert     v11, s12, #7
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v8, #10
    s.ashri      s15, s11, #32
    v.insert     v10, s14, #8
    v.insert     v11, s12, #8
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v8, #11
    s.ashri      s14, s11, #32
    v.insert     v10, s15, #9
    v.insert     v11, s12, #9
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v8, #12
    s.ashri      s15, s11, #32
    v.insert     v10, s14, #10
    v.insert     v11, s12, #10
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v8, #13
    s.ashri      s14, s11, #32
    v.insert     v10, s15, #11
    v.insert     v11, s12, #11
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v8, #14
    s.ashri      s15, s11, #32
    v.insert     v10, s14, #12
    v.insert     v11, s12, #12
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v8, #15
    s.ashri      s14, s11, #32
    v.insert     v10, s15, #13
    v.insert     v11, s12, #13
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    s.ashri      s13, s11, #32
    v.insert     v10, s14, #14
    v.insert     v11, s12, #14
    s.lshri      s11, s13, #32
    v.insert     v10, s13, #15
    v.insert     v11, s11, #15
    v.extract    s11, v5, #0
    v.extract    s12, v10, #0
    v.extract    s13, v11, #0
    v.extract    s14, v3, #0
    s.shli       s15, s13, #32
    s.shli       s13, s11, #32
    v.extract    s11, v11, #1
    v.extract    s16, v5, #1
    s.or         s17, s12, s15
    s.or         s12, s14, s13
    v.movi       v8, #0
    v.extract    s13, v10, #1
    s.shli       s14, s11, #32
    v.extract    s11, v3, #1
    s.shli       s15, s16, #32
    s.add        s16, s17, s12
    v.extract    s12, v11, #2
    v.extract    s17, v5, #2
    s.or         s18, s13, s14
    s.or         s13, s11, s15
    v.movi       v12, #0
    v.insert     v8, s16, #0
    v.extract    s11, v10, #2
    s.shli       s14, s12, #32
    v.extract    s12, v3, #2
    s.shli       s15, s17, #32
    s.lshri      s17, s16, #32
    s.add        s16, s18, s13
    v.extract    s13, v11, #3
    s.or         s18, s11, s14
    v.extract    s11, v5, #3
    s.or         s14, s12, s15
    v.insert     v12, s17, #0
    v.insert     v8, s16, #1
    v.extract    s12, v10, #3
    s.shli       s15, s13, #32
    v.extract    s13, v3, #3
    s.shli       s17, s11, #32
    s.lshri      s11, s16, #32
    s.add        s16, s18, s14
    v.extract    s14, v11, #4
    s.or         s18, s12, s15
    v.extract    s12, v5, #4
    s.or         s15, s13, s17
    v.insert     v12, s11, #1
    v.insert     v8, s16, #2
    v.extract    s11, v10, #4
    s.shli       s13, s14, #32
    v.extract    s14, v3, #4
    s.shli       s17, s12, #32
    s.lshri      s12, s16, #32
    s.add        s16, s18, s15
    v.extract    s15, v11, #5
    s.or         s18, s11, s13
    v.extract    s11, v5, #5
    s.or         s13, s14, s17
    v.insert     v12, s12, #2
    v.insert     v8, s16, #3
    v.extract    s12, v10, #5
    s.shli       s14, s15, #32
    v.extract    s15, v3, #5
    s.shli       s17, s11, #32
    s.lshri      s11, s16, #32
    s.add        s16, s18, s13
    v.extract    s13, v11, #6
    s.or         s18, s12, s14
    v.extract    s12, v5, #6
    s.or         s14, s15, s17
    v.insert     v12, s11, #3
    v.insert     v8, s16, #4
    v.extract    s11, v10, #6
    s.shli       s15, s13, #32
    v.extract    s13, v3, #6
    s.shli       s17, s12, #32
    s.lshri      s12, s16, #32
    s.add        s16, s18, s14
    v.extract    s14, v11, #7
    s.or         s18, s11, s15
    v.extract    s11, v5, #7
    s.or         s15, s13, s17
    v.insert     v12, s12, #4
    v.insert     v8, s16, #5
    v.extract    s12, v10, #7
    s.shli       s13, s14, #32
    v.extract    s14, v3, #7
    s.shli       s17, s11, #32
    s.lshri      s11, s16, #32
    s.add        s16, s18, s15
    v.extract    s15, v11, #8
    s.or         s18, s12, s13
    v.extract    s12, v5, #8
    s.or         s13, s14, s17
    v.insert     v12, s11, #5
    v.insert     v8, s16, #6
    v.extract    s11, v10, #8
    s.shli       s14, s15, #32
    v.extract    s15, v3, #8
    s.shli       s17, s12, #32
    s.lshri      s12, s16, #32
    s.add        s16, s18, s13
    v.extract    s13, v11, #9
    s.or         s18, s11, s14
    v.extract    s11, v5, #9
    s.or         s14, s15, s17
    v.insert     v12, s12, #6
    v.insert     v8, s16, #7
    v.extract    s12, v10, #9
    s.shli       s15, s13, #32
    v.extract    s13, v3, #9
    s.shli       s17, s11, #32
    s.lshri      s11, s16, #32
    s.add        s16, s18, s14
    v.extract    s14, v11, #10
    s.or         s18, s12, s15
    v.extract    s12, v5, #10
    s.or         s15, s13, s17
    v.insert     v12, s11, #7
    v.insert     v8, s16, #8
    v.extract    s11, v10, #10
    s.shli       s13, s14, #32
    v.extract    s14, v3, #10
    s.shli       s17, s12, #32
    s.lshri      s12, s16, #32
    s.add        s16, s18, s15
    v.extract    s15, v11, #11
    s.or         s18, s11, s13
    v.extract    s11, v5, #11
    s.or         s13, s14, s17
    v.insert     v12, s12, #8
    v.insert     v8, s16, #9
    v.extract    s12, v10, #11
    s.shli       s14, s15, #32
    v.extract    s15, v3, #11
    s.shli       s17, s11, #32
    s.lshri      s11, s16, #32
    s.add        s16, s18, s13
    v.extract    s13, v11, #12
    s.or         s18, s12, s14
    v.extract    s12, v5, #12
    s.or         s14, s15, s17
    v.insert     v12, s11, #9
    v.insert     v8, s16, #10
    v.extract    s11, v10, #12
    s.shli       s15, s13, #32
    v.extract    s13, v3, #12
    s.shli       s17, s12, #32
    s.lshri      s12, s16, #32
    s.add        s16, s18, s14
    v.extract    s14, v11, #13
    s.or         s18, s11, s15
    v.extract    s11, v5, #13
    s.or         s15, s13, s17
    v.insert     v12, s12, #10
    v.insert     v8, s16, #11
    v.extract    s12, v10, #13
    s.shli       s13, s14, #32
    v.extract    s14, v3, #13
    s.shli       s17, s11, #32
    s.lshri      s11, s16, #32
    s.add        s16, s18, s15
    v.extract    s15, v11, #14
    s.or         s18, s12, s13
    v.extract    s12, v5, #14
    s.or         s13, s14, s17
    v.insert     v12, s11, #11
    v.insert     v8, s16, #12
    v.extract    s11, v10, #14
    s.shli       s14, s15, #32
    v.extract    s15, v3, #14
    s.shli       s17, s12, #32
    s.lshri      s12, s16, #32
    s.add        s16, s18, s13
    v.extract    s13, v11, #15
    s.or         s18, s11, s14
    v.extract    s11, v5, #15
    s.or         s14, s15, s17
    v.insert     v12, s12, #12
    v.insert     v8, s16, #13
    v.extract    s12, v10, #15
    s.shli       s15, s13, #32
    v.extract    s13, v3, #15
    s.shli       s17, s11, #32
    s.lshri      s11, s16, #32
    s.add        s16, s18, s14
    s.or         s14, s12, s15
    s.or         s12, s13, s17
    v.insert     v12, s11, #13
    v.insert     v8, s16, #14
    s.lshri      s11, s16, #32
    s.add        s13, s14, s12
    v.insert     v12, s11, #14
    v.insert     v8, s13, #15
    v.movi       v3, #31
    s.lshri      s11, s13, #32
    v.movi       v5, #1
    v.insert     v12, s11, #15
    v.ashr       v10, v8, v3
    v.movi       v3, #0
    s.movz       s11, #0
    v.cmp.ne     p2, v12, v10
    @p2 v.sel        v10, v5, v3
    v.reduce.or  s12, v10
    s.cmp.eq     s13, s12, s11
    br.nz        s13, narrow_ok_4
    trap         #677220
narrow_ok_4:
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v3, [s4, v8]               // index is in elements (ISA sec 9.1)
    s.shli       s11, s10, #1                    // element offset -> bytes (x2)
    v.movi       v5, #0
    s.add        s12, s2, s11                    // &in_out_ptr0[...]
    s.add        s11, s10, s9
    s.movz       s13, #1
    vf.cvt.f16.f32 v8, v3
    vf.add       v3, v8, v7
    vf.add       v7, v3, v9
    vf.add       v3, v7, v6
    vf.mul       v6, v3, v3
    vf.cvt.f32.f16 v7, v3
    vf.add       v3, v4, v6
    @p1 v.st.h       [s12, #0], v7
    @p1 v.sel        v6, v3, v4
    v.mov        v5, v6
    v.mov        v4, v5
    s.mov        s10, s11
    br.nz        s13, for_1
endfor_2:
    vf.reduce.add.b v1, v4
    v.movi       v2, #0
    s.addi       s4, s1, #0
    vf.add       v3, v1, v2
for_5:
    s.cmp.ge     s1, s4, s3
    br.nz        s1, endfor_6
    .li       s1, #1149239296
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #925353388
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v5, v1                          // ISA 8.8: <= 2**-22 relative
    v.splat      v6, s4
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s1, #1024
    s.muli       s5, s4, #2
    v.add        v8, v6, v7
    v.movi       v6, #0
    v.splat      v7, s1
    .li       s1, #1077936128
    v.splat      v9, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.ge     p1, v8, v6
    v.cmp.lt     p2, v8, v7
    .li       s1, #3204448256
    v.splat      v6, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v7, s4
    s.add        s1, s2, s5
    p.and        p3, p1, p2
    fence.acq_rel.device
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v8, [s1, #0]
    v.add        v10, v7, v0
    v.movi       v7, #1024
    s.shli       s1, s4, #1                      // element offset -> bytes (x2)
    s.add        s5, s4, s9
    s.add        s6, s7, s1                      // &in_ptr4[...]
    v.cmp.lt     p1, v10, v7
    s.add        s10, s8, s1                     // &out_ptr1[...]
    s.movz       s1, #1
    vf.fms       v7, v1, v5, v2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s6, #0]
    vf.cvt.f16.f32 v2, v8
    vf.fms       v8, v5, v7, v5
    vf.neg       v7, v8                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v7, v7
    @p2 v.sel        v8, v7, v5
    vf.cvt.f16.f32 v5, v1
    vf.mul       v1, v3, v8                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v7, v1, v4
    v.rsqrt.approx v1, v7                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v1, v1
    vf.mul       v8, v1, v6
    vf.fms       v6, v7, v4, v9
    vf.mul       v4, v8, v6                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v6, v4, v1
    v.extract    s6, v6, #0
    v.splat      v1, s6
    vf.mul       v4, v2, v1
    vf.mul       v1, v4, v5
    vf.cvt.f32.f16 v2, v1
    @p1 v.st.h       [s10, #0], v2
    s.mov        s4, s5
    br.nz        s1, for_5
endfor_6:
    exit
    exit
