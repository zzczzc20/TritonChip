
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1024}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 12704}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_0(in_ptr0, in_ptr1, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 768
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x2 = xindex // 256
    x0 = (xindex % 64)
    x1 = ((xindex // 64) % 4)
    x3 = xindex // 64
    x4 = xindex
    tmp22 = tl.load(in_ptr0 + (4 + x1), xmask, eviction_policy='evict_last')
    tmp24 = tl.load(in_ptr1 + (x0), xmask, eviction_policy='evict_last')
    tmp28 = tl.load(in_ptr0 + (4 + x3), xmask, eviction_policy='evict_last')
    tmp0 = (x2).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int32)
    tmp2 = tmp0 == tmp1
    tmp3 = (x0).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1], 1, tl.int64)
    tmp6 = tmp4 >= tmp5
    tmp7 = tl.full([1], 60, tl.int64)
    tmp8 = tmp4 < tmp7
    tmp9 = ((((-1) + x0) % 3)).to(tl.int64)
    tmp10 = (tmp9).to(tl.int64)
    tmp11 = tl.full([1], 0, tl.int64)
    tmp12 = tmp10 == tmp11
    tmp13 = tmp6 & tmp8
    tmp14 = tmp13 & tmp12
    tmp15 = tl.load(in_ptr0 + (8 + x1), tmp14 & xmask, eviction_policy='evict_last', other=0.0)
    tmp16 = tmp15.to(tl.float32)
    tmp17 = tl.load(in_ptr1 + (1 + 3*(triton_helpers.div_floor_integer((-1) + x0,  3))), tmp14 & xmask, eviction_policy='evict_last', other=0.0)
    tmp18 = tmp16 * tmp17
    tmp19 = tl_math.sin(tmp18)
    tmp20 = tl.full(tmp19.shape, 0.0, tmp19.dtype)
    tmp21 = tl.where(tmp14, tmp19, tmp20)
    tmp23 = tmp22.to(tl.float32)
    tmp25 = tmp23 * tmp24
    tmp26 = tl_math.sin(tmp25)
    tmp27 = tl.where(tmp14, tmp21, tmp26)
    tmp29 = tmp28.to(tl.float32)
    tmp30 = tmp29 * tmp24
    tmp31 = tl_math.sin(tmp30)
    tmp32 = tl.where(tmp2, tmp27, tmp31)
    tmp33 = tl_math.cos(tmp18)
    tmp34 = tl.full(tmp33.shape, 0.0, tmp33.dtype)
    tmp35 = tl.where(tmp14, tmp33, tmp34)
    tmp36 = tl_math.cos(tmp25)
    tmp37 = tl.where(tmp14, tmp35, tmp36)
    tmp38 = tl_math.cos(tmp30)
    tmp39 = tl.where(tmp2, tmp37, tmp38)
    tl.store(out_ptr0 + (x4), tmp32, xmask)
    tl.store(out_ptr1 + (x4), tmp39, xmask)
