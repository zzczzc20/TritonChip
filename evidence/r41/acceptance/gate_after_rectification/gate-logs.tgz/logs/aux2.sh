#!/bin/bash
# Second pass of the aux lanes, after staging evidence/ in both trees and the
# pre-F03 FMA reference: the stream-removal unit tests on head and base, and the
# FMA miter. The first pass (logs/aux) is kept; its evidence-path and miter-input
# failures were staging errors of this gate.
set -u
source ~/tc_env/env.sh
G=~/r41fix_gate; P=~/tc_env/torchenv/bin/python
stamp() { date -u +%FT%TZ; }
lane() { local L=$1 n=$2 d=$3; shift 3
  echo "# $(stamp) start $n in $d: $*" > $L/$n.log
  ( cd $d && export PYTHONPATH=$d/python:$d/compiler/python:$d && echo "# PYTHONPATH=$PYTHONPATH" && nice -n 10 "$@" ) >> $L/$n.log 2>&1; local rc=$?
  echo "# $(stamp) end $n exit $rc" >> $L/$n.log; echo "$n $rc" >> $L/exit_codes.txt; }
UNITS="tools/r41/hbm_layout_tests.py tools/r40/multicore_mmio_option_tests.py tools/r40/reserved_memory_tests.py
 tools/r40/copy_range_tests.py tools/r40/device_copy_tests.py tools/r40/host_copy_tests.py
 tools/r40/memory_control_host_tests.py tools/r40/hbm_topology_tests.py
 tools/r40/image_geometry_tests.py tools/r40/storage_owner_tests.py tools/r40/physical_grid_runtime_tests.py
 tools/r40/physical_chunk_runtime_tests.py tools/r40/large_grid_tests.py tools/r40/lifetime_tests.py
 tools/r40/allocation_pressure_tests.py tools/r40/device_clock_tests.py tools/r40/code_cache_epoch_tests.py
 tools/r40/hbm_probe_storage_tests.py tools/r40/physical_grid_clock_tests.py tools/r40/dma_handoff_guard_tests.py
 tools/r40/replay_tests.py tools/r36/fpga_tests.py tools/r36/backend_tests.py tools/r36/io_tests.py
 tools/r36/config_tests.py tools/r2/runtime_tests.py tools/r2/memory_tests.py
 tools/performance_harness/test_hbm8.py tools/performance_harness/test_measurement_scope.py
 tools/performance_harness/test_locality_plan.py tools/performance_harness/test_stage2_acceptance.py"
for T in head base; do
  L=$G/logs/aux2-$T; mkdir -p $L; : > $L/exit_codes.txt
  echo "aux2 $T $(cat $G/$T/.gate_commit) started $(stamp)" > $L/run.txt
  for t in $UNITS; do
    [ -f $G/$T/$t ] || { echo "$(echo $t | tr / _) absent" >> $L/exit_codes.txt; continue; }
    lane $L unit-$(echo $t | tr / _ | sed 's/\.py$//') $G/$T $P $t
  done
  rm -rf $G/memctl-$T
  lane $L unit-tools_r40_memory_control_tests $G/$T $P tools/r40/memory_control_tests.py --out $G/memctl-$T
  lane $L bash-n-link $G/$T bash -n flow/fpga/link.sh
  echo "finished $(stamp)" >> $L/run.txt
done
L=$G/logs/aux2-head
lane $L fma-miter $G/head bash $G/miter/run_miter.sh $G/fma_ref $G/head/rtl 1000000 1
echo "miter finished $(stamp)" >> $L/run.txt
