    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #31
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    @p1 v.sel        v4, v1, v3
    s.rdspecial  s2, arg_base
    v.and        v1, v4, v0
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.sub        v0, v2, v1
    s.shli       s4, s1, #1                      // element offset -> bytes (x2)
    s.ld.d       s1, [s2, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.movi       v4, #64
    @p1 v.sel        v5, v0, v1
    s.ld.d       s5, [s2, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.add        s6, s3, s4                      // &in_ptr0[...]
    s.add        s3, s1, s4                      // &in_ptr2[...]
    s.ld.d       s1, [s2, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    v.cmp.lt     p1, v3, v4
    v.movi       v0, #0
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s6, #0]
    v.sub        v4, v0, v3
    v.cmp.lt     p2, v3, v0
    @p2 v.sel        v6, v4, v3
    v.movi       v3, #5
    v.movi       v4, #4128
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v7, [s5, v5]               // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v8, v1
    v.lshr       v1, v6, v3
    v.movi       v3, #32
    v.sub        v6, v0, v1
    v.sub        v9, v2, v3
    vf.cvt.f16.f32 v10, v7
    @p2 v.sel        v7, v6, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s3, #0]
    v.mul        v6, v7, v4
    vf.mul       v4, v8, v10
    v.sub        v7, v0, v3
    v.add        v8, v5, v6
    v.cmp.lt     p2, v3, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s1, v5]               // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v5, v1
    v.cmp.lt     p3, v3, v0
    @p2 v.sel        v0, v9, v3
    @p3 v.sel        v0, v7, v3
    vf.cvt.f16.f32 v0, v2
    s.ld.d       s1, [s2, #40]                   // out_ptr1: device_ptr64 at arg_base+40
    vf.mul       v1, v5, v0
    s.ld.d       s3, [s2, #32]                   // out_ptr0: device_ptr64 at arg_base+32
    s.add        s2, s1, s4                      // &out_ptr1[...]
    vf.add       v0, v4, v1
    vf.cvt.f32.f16 v1, v0
    @p1 v.st.scatter.h [s3, v8], v1
    @p1 v.st.h       [s2, #0], v1
__rctx_next:
    exit
