    s.rdspecial  s1, arg_base
    s.movz       s2, #256
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #0
    s.rdspecial  s5, role_id
    s.rdspecial  s6, npid.x
    s.ld.d       s7, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
__rctx_program:
    v.movi       v0, #16
    v.movi       v1, #0
    v.iota       v2                              // arange(0, VLEN)
    v.movi       v3, #32
    v.movi       v4, #48
    v.movi       v5, #64
    v.movi       v6, #80
    v.movi       v7, #96
    v.movi       v8, #112
    v.sub        v9, v1, v0
    v.cmp.lt     p1, v0, v1
    // tiled element-wise program: 256 lanes as 2 tiles of 128 (0 tensor-engine transfers, one load buffer(s))
    s.mul        s1, s5, s2
    s.addi       s8, s4, #0
    v.add        v10, v2, v0
    v.add        v11, v2, v3
    v.add        v12, v2, v4
    v.add        v4, v2, v5
    v.add        v5, v2, v6
    v.add        v6, v2, v7
    v.add        v7, v2, v8
    @p1 v.sel        v8, v9, v0
    v.movi       v0, #15
    v.movi       v8, #4
tiles_1:
    // tile 0 of the iteration: lanes t0 + 0
    s.add        s9, s1, s8
    v.splat      v9, s9
    v.add        v13, v9, v2
    v.add        v14, v9, v10
    v.add        v15, v9, v11
    v.add        v16, v9, v12
    v.add        v17, v9, v4
    v.add        v18, v9, v5
    v.add        v19, v9, v6
    v.add        v20, v9, v7
    v.sub        v9, v1, v13
    v.sub        v21, v1, v14
    v.sub        v22, v1, v15
    v.sub        v23, v1, v16
    v.sub        v24, v1, v17
    v.sub        v25, v1, v18
    v.sub        v26, v1, v19
    v.sub        v27, v1, v20
    v.cmp.lt     p1, v13, v1
    v.cmp.lt     p2, v14, v1
    v.cmp.lt     p3, v15, v1
    v.cmp.lt     p4, v16, v1
    v.cmp.lt     p5, v17, v1
    v.cmp.lt     p6, v18, v1
    v.cmp.lt     p7, v19, v1
    v.cmp.lt     p8, v20, v1
    @p1 v.sel        v28, v9, v13
    @p2 v.sel        v9, v21, v14
    @p3 v.sel        v13, v22, v15
    @p4 v.sel        v14, v23, v16
    @p5 v.sel        v15, v24, v17
    @p6 v.sel        v16, v25, v18
    @p7 v.sel        v17, v26, v19
    @p8 v.sel        v18, v27, v20
    v.lshr       v19, v28, v8
    v.and        v20, v28, v0
    v.lshr       v21, v9, v8
    v.and        v22, v9, v0
    v.and        v9, v13, v0
    v.and        v23, v14, v0
    v.and        v24, v15, v0
    v.and        v25, v16, v0
    v.and        v26, v17, v0
    v.and        v27, v18, v0
    v.sub        v28, v1, v19
    v.sub        v29, v1, v20
    v.sub        v30, v1, v21
    v.sub        v31, v1, v22
    v.sub        v32, v1, v9
    @p1 v.sel        v33, v28, v19
    v.sub        v19, v1, v23
    @p1 v.sel        v28, v29, v20
    v.lshr       v20, v13, v8
    v.lshr       v13, v14, v8
    v.sub        v14, v1, v24
    @p2 v.sel        v29, v30, v21
    v.sub        v21, v1, v20
    @p2 v.sel        v30, v31, v22
    v.lshr       v22, v15, v8
    v.lshr       v15, v16, v8
    v.sub        v16, v1, v13
    @p3 v.sel        v31, v21, v20
    v.sub        v20, v1, v22
    @p4 v.sel        v21, v16, v13
    v.sub        v13, v1, v15
    @p5 v.sel        v16, v20, v22
    v.sub        v20, v1, v25
    @p3 v.sel        v22, v32, v9
    v.lshr       v9, v17, v8
    v.lshr       v17, v18, v8
    v.sub        v18, v1, v26
    v.sub        v32, v1, v9
    @p6 v.sel        v34, v13, v15
    v.sub        v13, v1, v17
    v.sub        v15, v1, v27
    @p7 v.sel        v35, v32, v9
    @p4 v.sel        v9, v19, v23
    @p8 v.sel        v19, v13, v17
    @p5 v.sel        v13, v14, v24
    @p6 v.sel        v14, v20, v25
    @p7 v.sel        v17, v18, v26
    @p8 v.sel        v18, v15, v27
    v.mul        v15, v33, v3
    v.mul        v20, v29, v3
    v.mul        v23, v31, v3
    v.mul        v24, v21, v3
    v.mul        v21, v16, v3
    v.mul        v16, v34, v3
    v.mul        v25, v35, v3
    v.mul        v26, v19, v3
    v.add        v19, v28, v15
    v.add        v15, v30, v20
    v.add        v20, v22, v23
    v.add        v22, v9, v24
    v.add        v9, v13, v21
    v.add        v13, v14, v16
    v.add        v14, v17, v25
    v.add        v16, v18, v26
    v.ld.gather.h v17, [s3, v19]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.h v18, [s3, v15]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.h v21, [s3, v20]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.h v23, [s3, v22]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.h v24, [s3, v9]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.h v25, [s3, v13]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.h v26, [s3, v14]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.h v27, [s3, v16]                 // index is in elements (ISA sec 9.1)
    v.st.scatter.h [s7, v19], v17
    v.st.scatter.h [s7, v15], v18
    v.st.scatter.h [s7, v20], v21
    v.st.scatter.h [s7, v22], v23
    v.st.scatter.h [s7, v9], v24
    v.st.scatter.h [s7, v13], v25
    v.st.scatter.h [s7, v14], v26
    v.st.scatter.h [s7, v16], v27
    s.addi       s8, s8, #128
    s.cmp.lt     s9, s8, s2
    br.nz        s9, tiles_1
endtiles_2:
__rctx_next:
    s.addi       s1, s5, #4                      // the next program of this context: + 4
    s.cmp.lt     s8, s1, s6
    s.mov        s5, s1
    br.nz        s8, __rctx_program
    exit
