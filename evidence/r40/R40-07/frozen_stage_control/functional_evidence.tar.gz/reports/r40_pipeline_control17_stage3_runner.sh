#!/bin/bash
source ~/tc_env/env.sh
cd /tmp/r40_pipeline_control17 || exit 2
export PYTHONPATH="$PWD/python:$PWD/compiler/python:$PWD/tools/asm"
CUDA_VISIBLE_DEVICES='' TNCA_PIPELINE=3 "$HOME/tc_env/torchenv/bin/python" tools/r40/native_pipeline_tests.py --stages 3 > /tmp/r40_pipeline_control17_stage3.log 2>&1
rc=$?
printf '%s\n' "$rc" > /tmp/r40_pipeline_control17_stage3.exit
exit "$rc"
