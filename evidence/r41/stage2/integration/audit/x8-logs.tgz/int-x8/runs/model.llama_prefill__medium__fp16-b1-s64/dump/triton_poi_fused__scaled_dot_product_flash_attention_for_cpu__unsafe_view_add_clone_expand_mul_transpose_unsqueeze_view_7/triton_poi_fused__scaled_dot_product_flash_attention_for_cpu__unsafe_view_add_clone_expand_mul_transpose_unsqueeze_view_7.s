    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, pid.y
    s.movz       s2, #16
    s.movz       s3, #0
    s.mul        s5, s1, s2
    s.rdspecial  s1, role_id
    s.movz       s6, #15360
    v.movi       v0, #0
    v.movi       v1, #0
    s.add        s7, s3, s5                      // the tile origin
    s.rdspecial  s3, arg_base
    s.addi       s8, s7, #1
    v.splat      v2, s7
    v.splat      v3, s8
    s.mul        s8, s1, s6
    v.sub        v4, v0, v2
    v.sub        v5, v1, v3
    s.ld.d       s1, [s3, #80]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.cmp.lt     p1, v2, v0
    v.cmp.lt     p2, v3, v1
    @p1 v.sel        v6, v4, v2
    v.movi       v2, #63
    @p2 v.sel        v4, v5, v3
    s.add        s3, s1, s8                      // this context's own scratch
    v.and        v3, v6, v2
    s.addi       s1, s3, #0
    v.sub        v2, v0, v3
    s.rdspecial  s6, arg_base
    @p1 v.sel        v5, v2, v3
    s.addi       s8, s1, #64
    s.ld.d       s9, [s6, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.mul        s10, s4, s2
    s.movz       s2, #64
    s.ld.d       s4, [s6, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.movi       v2, #63
    v.splat      v3, s2
    s.ld.d       s2, [s6, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.and        v6, v4, v2
    v.sub        v2, v0, v3
    s.ld.d       s11, [s6, #24]                  // in_ptr3: device_ptr64 at arg_base+24
    v.sub        v4, v1, v6
    v.sub        v7, v1, v3
    s.ld.d       s12, [s6, #32]                  // in_ptr4: device_ptr64 at arg_base+32
    @p2 v.sel        v8, v4, v6
    v.cmp.lt     p1, v3, v0
    s.ld.d       s13, [s6, #40]                  // in_ptr5: device_ptr64 at arg_base+40
    v.cmp.lt     p2, v3, v1
    v.iota       v0                              // arange(0, VLEN)
    s.ld.d       s14, [s6, #48]                  // out_ptr0: device_ptr64 at arg_base+48
    s.addi       s15, s1, #128
    v.movi       v0, #1
    s.ld.d       s16, [s6, #56]                  // out_ptr1: device_ptr64 at arg_base+56
    s.addi       s6, s7, #2
    s.addi       s17, s7, #3
    v.splat      v0, s6
    v.movi       v1, #0
    v.splat      v4, s17
    v.movi       v6, #0
    v.sub        v9, v1, v0
    v.sub        v10, v6, v4
    v.cmp.lt     p3, v0, v1
    v.cmp.lt     p4, v4, v6
    @p3 v.sel        v11, v9, v0
    v.movi       v0, #63
    @p4 v.sel        v9, v10, v4
    v.and        v4, v11, v0
    s.addi       s6, s1, #192
    v.sub        v0, v1, v4
    v.st.w       [s1, #0], v5
    @p3 v.sel        v5, v0, v4
    v.sub        v0, v1, v3
    v.sub        v4, v6, v3
    v.cmp.lt     p3, v3, v1
    @p1 v.sel        v1, v2, v3
    s.addi       s17, s7, #4
    v.movi       v1, #0
    v.splat      v2, s17
    v.movi       v10, #63
    s.addi       s17, s1, #256
    v.and        v11, v9, v10
    v.st.w       [s8, #0], v8
    v.sub        v8, v6, v11
    v.cmp.lt     p1, v3, v6
    @p4 v.sel        v6, v8, v11
    v.movi       v8, #1
    v.sub        v8, v1, v2
    v.cmp.lt     p4, v2, v1
    @p4 v.sel        v9, v8, v2
    v.sub        v2, v1, v3
    @p2 v.sel        v8, v7, v3
    s.addi       s8, s7, #5
    v.movi       v7, #0
    v.splat      v8, s8
    v.movi       v10, #63
    s.addi       s8, s1, #320
    v.and        v11, v9, v10
    v.st.w       [s15, #0], v5
    v.sub        v5, v1, v11
    v.cmp.lt     p2, v3, v1
    @p4 v.sel        v1, v5, v11
    v.movi       v5, #1
    v.sub        v5, v7, v8
    v.cmp.lt     p4, v8, v7
    @p4 v.sel        v9, v5, v8
    v.sub        v5, v7, v3
    @p3 v.sel        v8, v0, v3
    s.addi       s15, s7, #6
    v.movi       v0, #0
    v.splat      v8, s15
    v.movi       v10, #63
    s.addi       s15, s1, #384
    v.and        v11, v9, v10
    v.st.w       [s6, #0], v6
    v.sub        v6, v7, v11
    v.cmp.lt     p3, v3, v7
    @p4 v.sel        v7, v6, v11
    v.movi       v6, #1
    v.sub        v6, v0, v8
    v.cmp.lt     p4, v8, v0
    @p4 v.sel        v9, v6, v8
    v.sub        v6, v0, v3
    @p1 v.sel        v8, v4, v3
    s.addi       s6, s7, #7
    v.movi       v4, #0
    v.splat      v8, s6
    v.movi       v10, #63
    s.addi       s6, s1, #448
    v.and        v11, v9, v10
    v.st.w       [s17, #0], v1
    v.sub        v1, v0, v11
    v.cmp.lt     p1, v3, v0
    @p4 v.sel        v0, v1, v11
    v.movi       v1, #1
    v.sub        v1, v4, v8
    v.cmp.lt     p4, v8, v4
    @p4 v.sel        v9, v1, v8
    v.sub        v1, v4, v3
    @p2 v.sel        v8, v2, v3
    s.addi       s17, s7, #8
    v.movi       v2, #0
    v.splat      v8, s17
    v.movi       v10, #63
    s.addi       s17, s1, #512
    v.and        v11, v9, v10
    v.st.w       [s8, #0], v7
    v.sub        v7, v4, v11
    v.cmp.lt     p2, v3, v4
    @p4 v.sel        v4, v7, v11
    v.movi       v7, #1
    v.sub        v7, v2, v8
    v.cmp.lt     p4, v8, v2
    @p4 v.sel        v9, v7, v8
    v.sub        v7, v2, v3
    @p3 v.sel        v8, v5, v3
    s.addi       s8, s7, #9
    v.movi       v5, #0
    v.splat      v8, s8
    v.movi       v10, #63
    s.addi       s8, s1, #576
    v.and        v11, v9, v10
    v.st.w       [s15, #0], v0
    v.sub        v0, v2, v11
    v.cmp.lt     p3, v3, v2
    @p4 v.sel        v2, v0, v11
    v.movi       v0, #1
    v.sub        v0, v5, v8
    v.cmp.lt     p4, v8, v5
    @p4 v.sel        v9, v0, v8
    v.sub        v0, v5, v3
    @p1 v.sel        v8, v6, v3
    s.addi       s15, s7, #10
    v.movi       v6, #0
    v.splat      v8, s15
    v.movi       v10, #63
    s.addi       s15, s1, #640
    v.and        v11, v9, v10
    v.st.w       [s6, #0], v4
    v.sub        v4, v5, v11
    v.cmp.lt     p1, v3, v5
    @p4 v.sel        v5, v4, v11
    v.movi       v4, #1
    v.sub        v4, v6, v8
    v.cmp.lt     p4, v8, v6
    @p4 v.sel        v9, v4, v8
    v.sub        v4, v6, v3
    @p2 v.sel        v8, v1, v3
    s.addi       s6, s7, #11
    v.movi       v1, #0
    v.splat      v8, s6
    v.movi       v10, #63
    s.addi       s6, s1, #704
    v.and        v11, v9, v10
    v.st.w       [s17, #0], v2
    v.sub        v2, v6, v11
    v.cmp.lt     p2, v3, v6
    @p4 v.sel        v6, v2, v11
    v.movi       v2, #1
    v.sub        v2, v1, v8
    v.cmp.lt     p4, v8, v1
    @p4 v.sel        v9, v2, v8
    v.sub        v2, v1, v3
    @p3 v.sel        v8, v7, v3
    s.addi       s17, s7, #12
    v.movi       v7, #0
    v.splat      v8, s17
    v.movi       v10, #63
    s.addi       s17, s1, #768
    v.and        v11, v9, v10
    v.st.w       [s8, #0], v5
    v.sub        v5, v1, v11
    v.cmp.lt     p3, v3, v1
    @p4 v.sel        v1, v5, v11
    v.movi       v5, #1
    v.sub        v5, v7, v8
    v.cmp.lt     p4, v8, v7
    @p4 v.sel        v9, v5, v8
    v.sub        v5, v7, v3
    @p1 v.sel        v8, v0, v3
    s.addi       s8, s7, #13
    v.movi       v0, #0
    v.splat      v8, s8
    v.movi       v10, #63
    s.addi       s8, s1, #832
    v.and        v11, v9, v10
    v.st.w       [s15, #0], v6
    v.sub        v6, v7, v11
    v.cmp.lt     p1, v3, v7
    @p4 v.sel        v7, v6, v11
    v.movi       v6, #1
    v.sub        v6, v0, v8
    v.cmp.lt     p4, v8, v0
    @p4 v.sel        v9, v6, v8
    v.sub        v6, v0, v3
    @p2 v.sel        v8, v4, v3
    s.addi       s15, s7, #14
    v.movi       v4, #0
    v.splat      v8, s15
    v.movi       v10, #63
    s.addi       s15, s1, #896
    v.and        v11, v9, v10
    v.st.w       [s6, #0], v1
    v.sub        v1, v0, v11
    v.cmp.lt     p2, v3, v0
    @p4 v.sel        v0, v1, v11
    v.movi       v1, #1
    v.sub        v1, v4, v8
    v.cmp.lt     p4, v8, v4
    @p4 v.sel        v9, v1, v8
    v.sub        v1, v4, v3
    @p3 v.sel        v8, v2, v3
    s.addi       s6, s7, #15
    v.movi       v2, #0
    v.splat      v8, s6
    v.movi       v10, #63
    s.addi       s6, s1, #960
    v.and        v11, v9, v10
    v.st.w       [s17, #0], v7
    v.sub        v7, v4, v11
    v.cmp.lt     p3, v3, v4
    @p4 v.sel        v4, v7, v11
    v.movi       v7, #1
    v.sub        v7, v2, v8
    v.cmp.lt     p4, v8, v2
    @p4 v.sel        v9, v7, v8
    v.sub        v7, v2, v3
    @p1 v.sel        v8, v5, v3
    v.splat      v5, s7
    v.movi       v8, #0
    v.movi       v10, #63
    s.addi       s1, s3, #1024
    v.and        v11, v9, v10
    v.st.w       [s8, #0], v0
    v.sub        v0, v2, v11
    v.cmp.lt     p1, v3, v2
    @p4 v.sel        v2, v0, v11
    v.movi       v0, #1
    v.sub        v0, v8, v5
    v.cmp.lt     p4, v5, v8
    @p4 v.sel        v9, v0, v5
    v.sub        v0, v8, v3
    @p2 v.sel        v5, v6, v3
    s.addi       s8, s7, #1
    v.movi       v5, #0
    v.splat      v6, s8
    v.movi       v10, #6
    s.addi       s8, s1, #64
    v.lshr       v11, v9, v10
    v.st.w       [s15, #0], v4
    v.sub        v4, v8, v11
    v.cmp.lt     p2, v3, v8
    @p4 v.sel        v8, v4, v11
    v.movi       v4, #1
    v.sub        v4, v5, v6
    v.cmp.lt     p4, v6, v5
    @p4 v.sel        v9, v4, v6
    v.sub        v4, v5, v3
    @p3 v.sel        v6, v1, v3
    s.addi       s15, s7, #2
    v.movi       v1, #0
    v.splat      v6, s15
    v.movi       v10, #6
    s.addi       s15, s1, #128
    v.lshr       v11, v9, v10
    v.st.w       [s6, #0], v2
    v.sub        v2, v5, v11
    fence.acq_rel.device
    @p4 v.sel        v9, v2, v11
    v.cmp.lt     p3, v3, v5
    v.movi       v2, #1
    v.sub        v2, v1, v6
    v.cmp.lt     p4, v6, v1
    @p4 v.sel        v5, v2, v6
    v.sub        v2, v1, v3
    v.st.w       [s1, #0], v8
    @p1 v.sel        v6, v7, v3
    s.addi       s6, s7, #3
    v.movi       v6, #0
    v.splat      v7, s6
    v.movi       v8, #6
    s.addi       s6, s1, #192
    v.lshr       v10, v5, v8
    v.cmp.lt     p1, v3, v1
    v.sub        v5, v1, v10
    v.st.w       [s8, #0], v9
    @p4 v.sel        v1, v5, v10
    v.movi       v5, #1
    v.sub        v5, v6, v7
    v.cmp.lt     p4, v7, v6
    @p4 v.sel        v8, v5, v7
    v.sub        v5, v6, v3
    @p2 v.sel        v7, v0, v3
    s.addi       s8, s7, #4
    v.movi       v0, #0
    v.splat      v7, s8
    v.movi       v9, #6
    s.addi       s8, s1, #256
    v.lshr       v10, v8, v9
    v.st.w       [s15, #0], v1
    v.sub        v1, v6, v10
    v.cmp.lt     p2, v3, v6
    @p4 v.sel        v6, v1, v10
    v.movi       v1, #1
    v.sub        v1, v0, v7
    v.cmp.lt     p4, v7, v0
    @p4 v.sel        v8, v1, v7
    v.sub        v1, v0, v3
    @p3 v.sel        v7, v4, v3
    s.addi       s15, s7, #5
    v.movi       v4, #0
    v.splat      v7, s15
    v.movi       v9, #6
    s.addi       s15, s1, #320
    v.lshr       v10, v8, v9
    v.st.w       [s6, #0], v6
    v.sub        v6, v0, v10
    v.cmp.lt     p3, v3, v0
    @p4 v.sel        v0, v6, v10
    v.movi       v6, #1
    v.sub        v6, v4, v7
    v.cmp.lt     p4, v7, v4
    @p4 v.sel        v8, v6, v7
    v.sub        v6, v4, v3
    @p1 v.sel        v7, v2, v3
    s.addi       s6, s7, #6
    v.movi       v2, #0
    v.splat      v7, s6
    v.movi       v9, #6
    s.addi       s6, s1, #384
    v.lshr       v10, v8, v9
    v.st.w       [s8, #0], v0
    v.sub        v0, v4, v10
    v.cmp.lt     p1, v3, v4
    @p4 v.sel        v4, v0, v10
    v.movi       v0, #1
    v.sub        v0, v2, v7
    v.cmp.lt     p4, v7, v2
    @p4 v.sel        v8, v0, v7
    v.sub        v0, v2, v3
    @p2 v.sel        v7, v5, v3
    s.addi       s8, s7, #7
    v.movi       v5, #0
    v.splat      v7, s8
    v.movi       v9, #6
    s.addi       s8, s1, #448
    v.lshr       v10, v8, v9
    v.st.w       [s15, #0], v4
    v.sub        v4, v2, v10
    v.cmp.lt     p2, v3, v2
    @p4 v.sel        v2, v4, v10
    v.movi       v4, #1
    v.sub        v4, v5, v7
    v.cmp.lt     p4, v7, v5
    @p4 v.sel        v8, v4, v7
    v.sub        v4, v5, v3
    @p3 v.sel        v7, v1, v3
    s.addi       s15, s7, #8
    v.movi       v1, #0
    v.splat      v7, s15
    v.movi       v9, #6
    s.addi       s15, s1, #512
    v.lshr       v10, v8, v9
    v.st.w       [s6, #0], v2
    v.sub        v2, v5, v10
    v.cmp.lt     p3, v3, v5
    @p4 v.sel        v5, v2, v10
    v.movi       v2, #1
    v.sub        v2, v1, v7
    v.cmp.lt     p4, v7, v1
    @p4 v.sel        v8, v2, v7
    v.sub        v2, v1, v3
    @p1 v.sel        v7, v6, v3
    s.addi       s6, s7, #9
    v.movi       v6, #0
    v.splat      v7, s6
    v.movi       v9, #6
    s.addi       s6, s1, #576
    v.lshr       v10, v8, v9
    v.st.w       [s8, #0], v5
    v.sub        v5, v1, v10
    v.cmp.lt     p1, v3, v1
    @p4 v.sel        v1, v5, v10
    v.movi       v5, #1
    v.sub        v5, v6, v7
    v.cmp.lt     p4, v7, v6
    @p4 v.sel        v8, v5, v7
    v.sub        v5, v6, v3
    @p2 v.sel        v7, v0, v3
    s.addi       s8, s7, #10
    v.movi       v0, #0
    v.splat      v7, s8
    v.movi       v9, #6
    s.addi       s8, s1, #640
    v.lshr       v10, v8, v9
    v.st.w       [s15, #0], v1
    v.sub        v1, v6, v10
    v.cmp.lt     p2, v3, v6
    @p4 v.sel        v6, v1, v10
    v.movi       v1, #1
    v.sub        v1, v0, v7
    v.cmp.lt     p4, v7, v0
    @p4 v.sel        v8, v1, v7
    v.sub        v1, v0, v3
    @p3 v.sel        v7, v4, v3
    s.addi       s15, s7, #11
    v.movi       v4, #0
    v.splat      v7, s15
    v.movi       v9, #6
    s.addi       s15, s1, #704
    v.lshr       v10, v8, v9
    v.st.w       [s6, #0], v6
    v.sub        v6, v0, v10
    v.cmp.lt     p3, v3, v0
    @p4 v.sel        v0, v6, v10
    v.movi       v6, #1
    v.sub        v6, v4, v7
    v.cmp.lt     p4, v7, v4
    @p4 v.sel        v8, v6, v7
    v.sub        v6, v4, v3
    @p1 v.sel        v7, v2, v3
    s.addi       s6, s7, #12
    v.movi       v2, #0
    v.splat      v7, s6
    v.movi       v9, #6
    s.addi       s6, s1, #768
    v.lshr       v10, v8, v9
    v.st.w       [s8, #0], v0
    v.sub        v0, v4, v10
    v.cmp.lt     p1, v3, v4
    @p4 v.sel        v4, v0, v10
    v.movi       v0, #1
    v.sub        v0, v2, v7
    v.cmp.lt     p4, v7, v2
    @p4 v.sel        v8, v0, v7
    v.sub        v0, v2, v3
    @p2 v.sel        v7, v5, v3
    s.addi       s8, s7, #13
    v.movi       v5, #0
    v.splat      v7, s8
    v.movi       v9, #6
    s.addi       s8, s1, #832
    v.lshr       v10, v8, v9
    v.st.w       [s15, #0], v4
    v.sub        v4, v2, v10
    v.cmp.lt     p2, v3, v2
    @p4 v.sel        v2, v4, v10
    v.movi       v4, #1
    v.sub        v4, v5, v7
    v.cmp.lt     p4, v7, v5
    @p4 v.sel        v8, v4, v7
    v.sub        v4, v5, v3
    @p3 v.sel        v7, v1, v3
    s.addi       s15, s7, #14
    v.movi       v1, #0
    v.splat      v7, s15
    v.movi       v9, #6
    s.addi       s15, s1, #896
    v.lshr       v10, v8, v9
    v.st.w       [s6, #0], v2
    v.sub        v2, v5, v10
    v.cmp.lt     p3, v3, v5
    @p4 v.sel        v5, v2, v10
    v.movi       v2, #1
    v.sub        v2, v1, v7
    v.cmp.lt     p4, v7, v1
    @p4 v.sel        v8, v2, v7
    v.sub        v2, v1, v3
    @p1 v.sel        v7, v6, v3
    s.addi       s6, s7, #15
    v.movi       v6, #0
    v.splat      v7, s6
    v.movi       v9, #6
    s.addi       s6, s1, #960
    v.lshr       v10, v8, v9
    v.st.w       [s8, #0], v5
    v.sub        v5, v1, v10
    v.cmp.lt     p1, v3, v1
    @p4 v.sel        v1, v5, v10
    v.movi       v5, #1
    v.sub        v5, v6, v7
    v.cmp.lt     p4, v7, v6
    @p4 v.sel        v8, v5, v7
    v.sub        v5, v6, v3
    @p2 v.sel        v7, v0, v3
    v.movi       v0, #6
    v.st.w       [s15, #0], v1
    v.lshr       v1, v8, v0
    s.movz       s1, #0
    v.sub        v0, v6, v1
    v.splat      v7, s1
    @p4 v.sel        v8, v0, v1
    s.addi       s8, s3, #2048
    v.cmp.lt     p2, v3, v6
    v.movi       v0, #1
    s.addi       s15, s3, #1024
    v.st.w       [s6, #0], v8
    fence.acq_rel.device
    s.movz       s6, #0
    v.iota       v0                              // arange(0, VLEN)
    s.add        s17, s6, s10                    // the tile origin
    @p3 v.sel        v1, v4, v3
    s.addi       s6, s3, #0
    s.movz       s18, #32
    v.splat      v1, s17
    v.splat      v4, s18
    v.ld.w       v6, [s15, #0]
    s.movz       s15, #192
    v.add        v8, v0, v1
    v.splat      v0, s15
    v.movi       v1, #1
    s.addi       s15, s3, #1088
    s.addi       s17, s8, #64
    @p1 v.sel        v1, v2, v3
    s.addi       s19, s3, #64
    s.addi       s20, s3, #1152
    v.ld.w       v1, [s6, #0]
    v.mul        v2, v6, v4
    s.addi       s6, s8, #128
    v.add        v6, v8, v2
    v.movi       v2, #1
    s.addi       s21, s3, #128
    @p2 v.sel        v2, v5, v3
    v.mul        v2, v1, v0
    v.add        v1, v6, v2
    v.add        v2, v7, v1
    v.st.w       [s8, #0], v2
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s3, #1216
    v.ld.w       v2, [s19, #0]
    v.mul        v5, v1, v4
    s.addi       s19, s3, #192
    v.add        v1, v8, v5
    v.mul        v5, v2, v0
    v.add        v2, v1, v5
    v.add        v1, v7, v2
    v.st.w       [s17, #0], v1
    s.addi       s17, s8, #192
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s3, #1280
    v.ld.w       v2, [s21, #0]
    v.mul        v5, v1, v4
    s.addi       s21, s3, #256
    v.add        v1, v8, v5
    v.mul        v5, v2, v0
    v.add        v2, v1, v5
    v.add        v1, v7, v2
    v.st.w       [s6, #0], v1
    s.addi       s6, s8, #256
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s3, #1344
    v.ld.w       v2, [s19, #0]
    v.mul        v5, v1, v4
    s.addi       s19, s3, #320
    v.add        v1, v8, v5
    v.mul        v5, v2, v0
    v.add        v2, v1, v5
    v.add        v1, v7, v2
    v.st.w       [s17, #0], v1
    s.addi       s17, s8, #320
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s3, #1408
    v.ld.w       v2, [s21, #0]
    v.mul        v5, v1, v4
    s.addi       s21, s3, #384
    v.add        v1, v8, v5
    v.mul        v5, v2, v0
    v.add        v2, v1, v5
    v.add        v1, v7, v2
    v.st.w       [s6, #0], v1
    s.addi       s6, s8, #384
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s3, #1472
    v.ld.w       v2, [s19, #0]
    v.mul        v5, v1, v4
    s.addi       s19, s3, #448
    v.add        v1, v8, v5
    v.mul        v5, v2, v0
    v.add        v2, v1, v5
    v.add        v1, v7, v2
    v.st.w       [s17, #0], v1
    s.addi       s17, s8, #448
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s3, #1536
    v.ld.w       v2, [s21, #0]
    v.mul        v5, v1, v4
    s.addi       s21, s3, #512
    v.add        v1, v8, v5
    v.mul        v5, v2, v0
    v.add        v2, v1, v5
    v.add        v1, v7, v2
    v.st.w       [s6, #0], v1
    s.addi       s6, s8, #512
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s3, #1600
    v.ld.w       v2, [s19, #0]
    v.mul        v5, v1, v4
    s.addi       s19, s3, #576
    v.add        v1, v8, v5
    v.mul        v5, v2, v0
    v.add        v2, v1, v5
    v.add        v1, v7, v2
    v.st.w       [s17, #0], v1
    s.addi       s17, s8, #576
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s3, #1664
    v.ld.w       v2, [s21, #0]
    v.mul        v5, v1, v4
    s.addi       s21, s3, #640
    v.add        v1, v8, v5
    v.mul        v5, v2, v0
    v.add        v2, v1, v5
    v.add        v1, v7, v2
    v.st.w       [s6, #0], v1
    s.addi       s6, s8, #640
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s3, #1728
    v.ld.w       v2, [s19, #0]
    v.mul        v5, v1, v4
    s.addi       s19, s3, #704
    v.add        v1, v8, v5
    v.mul        v5, v2, v0
    v.add        v2, v1, v5
    v.add        v1, v7, v2
    v.st.w       [s17, #0], v1
    s.addi       s17, s8, #704
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s3, #1792
    v.ld.w       v2, [s21, #0]
    v.mul        v5, v1, v4
    s.addi       s21, s3, #768
    v.add        v1, v8, v5
    v.mul        v5, v2, v0
    v.add        v2, v1, v5
    v.add        v1, v7, v2
    v.st.w       [s6, #0], v1
    s.addi       s6, s8, #768
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s3, #1856
    v.ld.w       v2, [s19, #0]
    v.mul        v5, v1, v4
    s.addi       s19, s3, #832
    v.add        v1, v8, v5
    v.mul        v5, v2, v0
    v.add        v2, v1, v5
    v.add        v1, v7, v2
    v.st.w       [s17, #0], v1
    s.addi       s17, s8, #832
    v.splat      v1, s18
    s.addi       s18, s3, #1920
    v.cmp.lt     p1, v8, v1
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s3, #896
    v.splat      v2, s7
    v.ld.w       v5, [s21, #0]
    v.mul        v6, v1, v4
    s.addi       s21, s8, #896
    v.add        v1, v8, v6
    s.addi       s22, s8, #960
    v.mul        v6, v5, v0
    v.add        v5, v1, v6
    v.add        v1, v7, v5
    v.st.w       [s6, #0], v1
    s.addi       s6, s3, #1984
    v.ld.w       v1, [s15, #0]
    s.addi       s8, s3, #960
    v.ld.w       v5, [s19, #0]
    v.mul        v6, v1, v4
    s.addi       s15, s3, #2048
    v.add        v1, v8, v6
    v.mul        v6, v5, v0
    v.add        v5, v1, v6
    v.add        v1, v7, v5
    v.st.w       [s17, #0], v1
    s.movz       s17, #384
    v.splat      v1, s17
    s.addi       s17, s3, #3072
    v.cmp.lt     p2, v2, v1
    p.and        p3, p1, p2
    v.ld.w       v2, [s18, #0]
    s.addi       s18, s3, #2112
    v.ld.w       v5, [s20, #0]
    v.mul        v6, v2, v4
    s.addi       s19, s7, #1
    v.add        v2, v8, v6
    v.splat      v6, s19
    s.addi       s19, s17, #64
    v.cmp.lt     p2, v6, v1
    p.and        p4, p1, p2
    v.mul        v6, v5, v0
    v.add        v5, v2, v6
    v.add        v2, v7, v5
    v.st.w       [s21, #0], v2
    s.addi       s20, s3, #2176
    v.ld.w       v2, [s6, #0]
    s.addi       s6, s7, #2
    v.splat      v5, s6
    s.addi       s6, s17, #128
    v.cmp.lt     p2, v5, v1
    p.and        p5, p1, p2
    v.ld.w       v5, [s8, #0]
    v.mul        v6, v2, v4
    s.addi       s8, s3, #2240
    v.add        v2, v8, v6
    v.mul        v6, v5, v0
    v.add        v0, v2, v6
    v.add        v2, v7, v0
    v.st.w       [s22, #0], v2
    fence.acq_rel.device
    s.addi       s21, s7, #3
    v.splat      v0, s21
    s.addi       s21, s17, #192
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s3, #2304
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s9, v2]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    v.st.w       [s17, #0], v5
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s7, #4
    v.splat      v2, s18
    s.addi       s18, s17, #256
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v1
    p.and        p4, p1, p2
    v.st.w       [s19, #0], v5
    s.addi       s19, s3, #2368
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s7, #5
    v.splat      v2, s20
    s.addi       s20, s17, #320
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v5, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v1
    p.and        p5, p1, p2
    v.st.w       [s6, #0], v5
    s.addi       s6, s3, #2432
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s7, #6
    v.splat      v2, s8
    s.addi       s8, s17, #384
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v1
    p.and        p3, p1, p2
    v.st.w       [s21, #0], v5
    s.addi       s21, s3, #2496
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s7, #7
    v.splat      v2, s15
    s.addi       s15, s17, #448
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v1
    p.and        p4, p1, p2
    v.st.w       [s18, #0], v5
    s.addi       s18, s3, #2560
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s7, #8
    v.splat      v2, s19
    s.addi       s19, s17, #512
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v5, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v1
    p.and        p5, p1, p2
    v.st.w       [s20, #0], v5
    s.addi       s20, s3, #2624
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s7, #9
    v.splat      v2, s6
    s.addi       s6, s17, #576
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v1
    p.and        p3, p1, p2
    v.st.w       [s8, #0], v5
    s.addi       s8, s3, #2688
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s7, #10
    v.splat      v2, s21
    s.addi       s21, s17, #640
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v1
    p.and        p4, p1, p2
    v.st.w       [s15, #0], v5
    s.addi       s15, s3, #2752
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s7, #11
    v.splat      v2, s18
    s.addi       s18, s17, #704
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v5, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v1
    p.and        p5, p1, p2
    v.st.w       [s19, #0], v5
    s.addi       s19, s3, #2816
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s7, #12
    v.splat      v2, s20
    s.addi       s20, s17, #768
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v1
    p.and        p3, p1, p2
    v.st.w       [s6, #0], v5
    s.addi       s6, s3, #2880
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s7, #13
    v.splat      v2, s8
    s.addi       s8, s17, #832
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v1
    p.and        p4, p1, p2
    v.st.w       [s21, #0], v5
    s.addi       s21, s3, #2944
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s7, #14
    v.splat      v2, s15
    s.addi       s15, s17, #896
    s.addi       s22, s17, #960
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v5, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v1
    p.and        p5, p1, p2
    v.st.w       [s18, #0], v5
    s.addi       s17, s3, #3008
    v.ld.w       v0, [s19, #0]
    s.addi       s18, s7, #15
    v.splat      v2, s18
    s.addi       s18, s3, #0
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v1
    p.and        p3, p1, p2
    v.st.w       [s20, #0], v5
    s.addi       s19, s3, #4096
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s3, #64
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v2, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s8, #0], v2
    s.addi       s8, s19, #64
    v.ld.w       v0, [s21, #0]
    s.addi       s20, s3, #128
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v2, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s19, #128
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s3, #192
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s9, v0]               // index is in elements (ISA sec 9.1)
    s.addi       s9, s19, #192
    v.st.w       [s22, #0], v2
    fence.acq_rel.device
    s.addi       s21, s3, #256
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s19, #256
    v.mul        v2, v0, v4
    v.add        v0, v8, v2
    v.st.w       [s19, #0], v0
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s3, #320
    v.mul        v2, v0, v4
    v.add        v0, v8, v2
    v.st.w       [s8, #0], v0
    s.addi       s8, s19, #320
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s3, #384
    v.mul        v2, v0, v4
    v.add        v0, v8, v2
    v.st.w       [s15, #0], v0
    s.addi       s15, s19, #384
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s3, #448
    v.mul        v2, v0, v4
    v.add        v0, v8, v2
    v.st.w       [s9, #0], v0
    s.addi       s9, s19, #448
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s3, #512
    v.mul        v2, v0, v4
    v.add        v0, v8, v2
    v.st.w       [s18, #0], v0
    s.addi       s18, s19, #512
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s3, #576
    v.mul        v2, v0, v4
    v.add        v0, v8, v2
    v.st.w       [s8, #0], v0
    s.addi       s8, s19, #576
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s3, #640
    v.mul        v2, v0, v4
    v.add        v0, v8, v2
    v.st.w       [s15, #0], v0
    s.addi       s15, s19, #640
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s3, #704
    v.mul        v2, v0, v4
    v.add        v0, v8, v2
    v.st.w       [s9, #0], v0
    s.addi       s9, s19, #704
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s3, #768
    v.splat      v2, s1
    v.mul        v5, v0, v4
    v.add        v0, v8, v5
    v.st.w       [s18, #0], v0
    s.addi       s18, s19, #768
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s3, #832
    v.mul        v5, v0, v4
    v.add        v0, v8, v5
    v.st.w       [s8, #0], v0
    s.addi       s8, s19, #832
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s3, #896
    v.mul        v5, v0, v4
    v.add        v0, v8, v5
    v.st.w       [s15, #0], v0
    s.addi       s15, s19, #896
    s.addi       s22, s19, #960
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s3, #960
    v.mul        v5, v0, v4
    v.add        v0, v8, v5
    v.st.w       [s9, #0], v0
    s.addi       s9, s3, #4096
    v.ld.w       v0, [s21, #0]
    s.addi       s19, s3, #5120
    v.mul        v5, v0, v4
    v.add        v0, v8, v5
    v.st.w       [s18, #0], v0
    s.addi       s18, s3, #4160
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s19, #64
    v.mul        v5, v0, v4
    v.add        v0, v8, v5
    v.st.w       [s8, #0], v0
    s.addi       s8, s3, #4224
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s19, #128
    v.mul        v5, v0, v4
    v.add        v0, v8, v5
    v.st.w       [s15, #0], v0
    s.addi       s15, s3, #4288
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s19, #192
    v.mul        v5, v0, v4
    v.add        v0, v8, v5
    v.st.w       [s22, #0], v0
    fence.acq_rel.device
    s.addi       s21, s3, #4352
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s19, #256
    v.add        v5, v2, v0
    v.st.w       [s19, #0], v5
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s3, #4416
    v.add        v5, v2, v0
    v.st.w       [s6, #0], v5
    s.addi       s6, s19, #320
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s3, #4480
    v.add        v5, v2, v0
    v.st.w       [s20, #0], v5
    s.addi       s20, s19, #384
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s3, #4544
    v.add        v5, v2, v0
    v.st.w       [s17, #0], v5
    s.addi       s17, s19, #448
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s3, #4608
    v.add        v5, v2, v0
    v.st.w       [s9, #0], v5
    s.addi       s9, s19, #512
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s3, #4672
    v.add        v5, v2, v0
    v.st.w       [s6, #0], v5
    s.addi       s6, s19, #576
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s3, #4736
    v.add        v5, v2, v0
    v.st.w       [s20, #0], v5
    s.addi       s20, s19, #640
    v.splat      v0, s7
    v.ld.w       v5, [s15, #0]
    s.addi       s15, s3, #4800
    v.cmp.lt     p2, v0, v1
    v.add        v0, v2, v5
    p.and        p3, p1, p2
    v.st.w       [s17, #0], v0
    s.addi       s17, s19, #704
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s3, #4864
    v.add        v5, v2, v0
    v.st.w       [s9, #0], v5
    s.addi       s9, s19, #768
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s3, #4928
    v.add        v5, v2, v0
    v.st.w       [s6, #0], v5
    s.addi       s6, s19, #832
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s3, #4992
    v.add        v5, v2, v0
    v.st.w       [s20, #0], v5
    s.addi       s20, s19, #896
    s.addi       s22, s19, #960
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s3, #5056
    v.add        v5, v2, v0
    v.st.w       [s17, #0], v5
    s.addi       s17, s3, #5120
    v.ld.w       v0, [s21, #0]
    s.addi       s19, s3, #6144
    v.add        v5, v2, v0
    v.st.w       [s9, #0], v5
    s.addi       s9, s3, #5184
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s7, #1
    v.splat      v5, s18
    s.addi       s18, s19, #64
    v.cmp.lt     p2, v5, v1
    p.and        p4, p1, p2
    v.add        v5, v2, v0
    v.st.w       [s6, #0], v5
    s.addi       s6, s3, #5248
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s7, #2
    v.splat      v5, s8
    s.addi       s8, s19, #128
    v.cmp.lt     p2, v5, v1
    p.and        p5, p1, p2
    v.add        v5, v2, v0
    v.st.w       [s20, #0], v5
    s.addi       s20, s3, #5312
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s7, #3
    v.splat      v5, s15
    s.addi       s15, s19, #192
    v.add        v6, v2, v0
    v.st.w       [s22, #0], v6
    fence.acq_rel.device
    s.addi       s21, s3, #5376
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s7, #4
    v.splat      v2, s17
    s.addi       s17, s19, #256
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v6, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    v.st.w       [s19, #0], v6
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s3, #5440
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v1
    p.and        p4, p1, p2
    v.st.w       [s18, #0], v5
    s.addi       s18, s7, #5
    v.splat      v0, s18
    s.addi       s18, s19, #320
    v.ld.w       v2, [s6, #0]
    s.addi       s6, s3, #5504
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v5, [s4, v2]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p5, p1, p2
    v.st.w       [s8, #0], v5
    s.addi       s8, s7, #6
    v.splat      v0, s8
    s.addi       s8, s19, #384
    v.ld.w       v2, [s20, #0]
    s.addi       s20, s3, #5568
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s4, v2]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    v.st.w       [s15, #0], v5
    s.addi       s15, s7, #7
    v.splat      v0, s15
    s.addi       s15, s19, #448
    v.ld.w       v2, [s21, #0]
    s.addi       s21, s3, #5632
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s4, v2]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p4, p1, p2
    v.st.w       [s17, #0], v5
    s.addi       s17, s7, #8
    v.splat      v0, s17
    s.addi       s17, s19, #512
    v.ld.w       v2, [s9, #0]
    s.addi       s9, s3, #5696
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v5, [s4, v2]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p5, p1, p2
    v.st.w       [s18, #0], v5
    s.addi       s18, s7, #9
    v.splat      v0, s18
    s.addi       s18, s19, #576
    v.ld.w       v2, [s6, #0]
    s.addi       s6, s3, #5760
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s4, v2]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    v.st.w       [s8, #0], v5
    s.addi       s8, s7, #10
    v.splat      v0, s8
    s.addi       s8, s19, #640
    v.ld.w       v2, [s20, #0]
    s.addi       s20, s3, #5824
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s4, v2]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p4, p1, p2
    v.st.w       [s15, #0], v5
    s.addi       s15, s7, #11
    v.splat      v0, s15
    s.addi       s15, s19, #704
    v.ld.w       v2, [s21, #0]
    s.addi       s21, s3, #5888
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v5, [s4, v2]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p5, p1, p2
    v.st.w       [s17, #0], v5
    s.addi       s17, s7, #12
    v.splat      v0, s17
    s.addi       s17, s19, #768
    v.ld.w       v2, [s9, #0]
    s.addi       s9, s3, #5952
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s4, v2]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    v.st.w       [s18, #0], v5
    s.addi       s18, s7, #13
    v.splat      v0, s18
    s.addi       s18, s19, #832
    v.ld.w       v2, [s6, #0]
    s.addi       s6, s3, #6016
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s4, v2]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p4, p1, p2
    v.st.w       [s8, #0], v5
    s.addi       s8, s7, #14
    v.splat      v0, s8
    s.addi       s8, s19, #896
    s.addi       s22, s19, #960
    v.ld.w       v2, [s20, #0]
    s.addi       s19, s3, #6080
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v5, [s4, v2]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p5, p1, p2
    v.st.w       [s15, #0], v5
    s.addi       s15, s7, #15
    v.splat      v0, s15
    s.addi       s15, s3, #6144
    v.ld.w       v2, [s21, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s20, #0
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s4, v2]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    v.st.w       [s17, #0], v5
    s.addi       s17, s3, #6208
    v.ld.w       v0, [s9, #0]
    s.movz       s9, #1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v2, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s18, #0], v2
    s.addi       s18, s3, #6272
    v.ld.w       v0, [s6, #0]
    s.movz       s6, #2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v2, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s8, #0], v2
    s.addi       s8, s3, #6336
    v.ld.w       v0, [s19, #0]
    s.movz       s19, #3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s4, v0]               // index is in elements (ISA sec 9.1)
    s.addi       s4, s3, #6400
    v.st.w       [s22, #0], v2
    fence.acq_rel.device
    s.movz       s21, #4
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s3, #6464
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a0, s20, v2
    v.ld.w       v0, [s17, #0]
    s.movz       s17, #5
    s.addi       s20, s3, #6528
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a0, s9, v2
    v.ld.w       v0, [s18, #0]
    s.movz       s9, #6
    s.addi       s18, s3, #6592
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a0, s6, v2
    v.ld.w       v0, [s8, #0]
    s.movz       s6, #7
    s.addi       s8, s3, #6656
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a0, s19, v2
    v.ld.w       v0, [s4, #0]
    s.movz       s4, #8
    s.addi       s19, s3, #6720
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a0, s21, v2
    v.ld.w       v0, [s15, #0]
    s.movz       s15, #9
    s.addi       s21, s3, #6784
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a0, s17, v2
    v.ld.w       v0, [s20, #0]
    s.movz       s17, #10
    s.addi       s20, s3, #6848
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a0, s9, v2
    v.ld.w       v0, [s18, #0]
    s.movz       s9, #11
    s.addi       s18, s3, #6912
    v.splat      v2, s1
    vf.cvt.f16.f32 v5, v0
    a.vwrite     a0, s6, v5
    v.ld.w       v0, [s8, #0]
    s.movz       s6, #12
    s.addi       s8, s3, #6976
    vf.cvt.f16.f32 v5, v0
    a.vwrite     a0, s4, v5
    v.ld.w       v0, [s19, #0]
    s.movz       s4, #13
    s.addi       s19, s3, #7040
    vf.cvt.f16.f32 v5, v0
    a.vwrite     a0, s15, v5
    v.ld.w       v0, [s21, #0]
    s.movz       s15, #14
    s.addi       s21, s3, #7104
    vf.cvt.f16.f32 v5, v0
    a.vwrite     a0, s17, v5
    v.ld.w       v0, [s20, #0]
    s.movz       s17, #15
    s.addi       s20, s3, #4096
    vf.cvt.f16.f32 v5, v0
    a.vwrite     a0, s9, v5
    v.ld.w       v0, [s18, #0]
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.addi       s9, s3, #7168
    s.addi       s18, s3, #4160
    vf.cvt.f16.f32 v5, v0
    a.vwrite     a0, s6, v5
    v.ld.w       v0, [s8, #0]
    s.addi       s6, s9, #64
    s.addi       s8, s3, #4224
    vf.cvt.f16.f32 v5, v0
    a.vwrite     a0, s4, v5
    v.ld.w       v0, [s19, #0]
    s.addi       s4, s9, #128
    s.addi       s19, s3, #4288
    vf.cvt.f16.f32 v5, v0
    a.vwrite     a0, s15, v5
    v.ld.w       v0, [s21, #0]
    s.addi       s15, s9, #192
    s.addi       s21, s3, #4352
    vf.cvt.f16.f32 v5, v0
    a.vwrite     a0, s17, v5
    v.ld.w       v0, [s20, #0]
    s.addi       s17, s9, #256
    s.addi       s20, s3, #4416
    v.add        v5, v2, v0
    v.st.w       [s9, #0], v5
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s9, #320
    v.add        v5, v2, v0
    v.st.w       [s6, #0], v5
    s.addi       s6, s3, #4480
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s9, #384
    v.add        v5, v2, v0
    v.st.w       [s4, #0], v5
    s.addi       s4, s3, #4544
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s9, #448
    v.add        v5, v2, v0
    v.st.w       [s15, #0], v5
    s.addi       s15, s3, #4608
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s9, #512
    v.add        v5, v2, v0
    v.st.w       [s17, #0], v5
    s.muli       s17, s10, #2                    // a runtime tile origin, x2
    s.add        s22, s2, s17                    // the tile origin
    s.muli       s2, s5, #64                     // a runtime tile origin, x64
    v.ld.w       v0, [s20, #0]
    s.addi       s17, s9, #576
    s.add        s20, s22, s2                    // the tile origin
    s.addi       s2, s3, #4672
    v.add        v5, v2, v0
    v.st.w       [s18, #0], v5
    s.addi       s18, s3, #4736
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s9, #640
    v.add        v5, v2, v0
    v.st.w       [s8, #0], v5
    s.addi       s8, s3, #4800
    v.splat      v0, s7
    v.ld.w       v5, [s4, #0]
    s.addi       s4, s9, #704
    v.cmp.lt     p2, v0, v1
    v.add        v0, v2, v5
    p.and        p3, p1, p2
    v.st.w       [s19, #0], v0
    s.addi       s19, s3, #4864
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s9, #768
    v.add        v5, v2, v0
    v.st.w       [s21, #0], v5
    s.addi       s21, s3, #4928
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s9, #832
    v.add        v5, v2, v0
    v.st.w       [s17, #0], v5
    s.addi       s17, s3, #4992
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s9, #896
    s.addi       s22, s9, #960
    v.add        v5, v2, v0
    v.st.w       [s6, #0], v5
    s.addi       s6, s3, #5056
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s3, #7168
    v.add        v5, v2, v0
    v.st.w       [s4, #0], v5
    s.addi       s4, s3, #8192
    v.ld.w       v0, [s19, #0]
    s.addi       s9, s3, #7232
    v.add        v5, v2, v0
    v.st.w       [s15, #0], v5
    s.addi       s15, s7, #1
    v.splat      v0, s15
    s.addi       s15, s4, #64
    v.cmp.lt     p2, v0, v1
    p.and        p4, p1, p2
    v.ld.w       v0, [s21, #0]
    s.addi       s19, s3, #7296
    v.add        v5, v2, v0
    v.st.w       [s2, #0], v5
    s.addi       s2, s7, #2
    v.splat      v0, s2
    s.addi       s2, s4, #128
    v.cmp.lt     p2, v0, v1
    p.and        p5, p1, p2
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s3, #7360
    v.add        v5, v2, v0
    v.st.w       [s18, #0], v5
    s.addi       s18, s7, #3
    v.splat      v0, s18
    s.addi       s18, s4, #192
    v.ld.w       v5, [s6, #0]
    s.addi       s6, s3, #7424
    v.add        v6, v2, v5
    v.st.w       [s22, #0], v6
    fence.acq_rel.device
    s.addi       s21, s7, #4
    v.splat      v2, s21
    s.addi       s21, s4, #256
    v.ld.w       v5, [s8, #0]
    s.addi       s8, s3, #7488
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v6, [s11, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    v.st.w       [s4, #0], v6
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s7, #5
    v.splat      v5, s9
    s.addi       s9, s4, #320
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v6, [s11, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v1
    p.and        p4, p1, p2
    v.st.w       [s15, #0], v6
    s.addi       s15, s3, #7552
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s7, #6
    v.splat      v2, s19
    s.addi       s19, s4, #384
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v6, [s11, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v1
    p.and        p5, p1, p2
    v.st.w       [s2, #0], v6
    s.addi       s2, s3, #7616
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s7, #7
    v.splat      v5, s17
    s.addi       s17, s4, #448
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v6, [s11, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v1
    p.and        p3, p1, p2
    v.st.w       [s18, #0], v6
    s.addi       s18, s3, #7680
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s7, #8
    v.splat      v2, s6
    s.addi       s6, s4, #512
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v6, [s11, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v1
    p.and        p4, p1, p2
    v.st.w       [s21, #0], v6
    s.addi       s21, s3, #7744
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s7, #9
    v.splat      v5, s8
    s.addi       s8, s4, #576
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v6, [s11, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v1
    p.and        p5, p1, p2
    v.st.w       [s9, #0], v6
    s.addi       s9, s3, #7808
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s7, #10
    v.splat      v2, s15
    s.addi       s15, s4, #640
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v6, [s11, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    v.st.w       [s19, #0], v6
    s.addi       s19, s3, #7872
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s7, #11
    v.splat      v5, s2
    s.addi       s2, s4, #704
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v6, [s11, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v1
    p.and        p4, p1, p2
    v.st.w       [s17, #0], v6
    s.addi       s17, s3, #7936
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s7, #12
    v.splat      v2, s18
    s.addi       s18, s4, #768
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v6, [s11, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v1
    p.and        p5, p1, p2
    v.st.w       [s6, #0], v6
    s.addi       s6, s3, #8000
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s7, #13
    v.splat      v5, s21
    s.addi       s21, s4, #832
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v6, [s11, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v1
    p.and        p3, p1, p2
    v.st.w       [s8, #0], v6
    s.addi       s8, s3, #8064
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s7, #14
    v.splat      v2, s9
    s.addi       s9, s4, #896
    s.addi       s22, s4, #960
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v6, [s11, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v1
    p.and        p4, p1, p2
    v.st.w       [s15, #0], v6
    s.addi       s4, s3, #8128
    v.ld.w       v0, [s19, #0]
    s.addi       s15, s7, #15
    v.splat      v5, s15
    s.addi       s15, s3, #8192
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v6, [s11, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v1
    p.and        p5, p1, p2
    v.st.w       [s2, #0], v6
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s2, #0
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s3, #8256
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s11, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    v.st.w       [s18, #0], v2
    s.movz       s18, #1
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s3, #8320
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v2, [s11, v0]              // index is in elements (ISA sec 9.1)
    v.st.w       [s21, #0], v2
    s.movz       s19, #2
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s3, #8384
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v2, [s11, v0]              // index is in elements (ISA sec 9.1)
    v.st.w       [s9, #0], v2
    s.movz       s9, #3
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s3, #8448
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s11, v0]              // index is in elements (ISA sec 9.1)
    s.movz       s11, #4
    v.st.w       [s22, #0], v2
    fence.acq_rel.device
    s.addi       s21, s3, #8512
    v.ld.w       v0, [s15, #0]
    s.movz       s15, #5
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s2, v2
    v.ld.w       v0, [s17, #0]
    s.addi       s2, s3, #8576
    s.movz       s17, #6
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s18, v2
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s3, #8640
    s.movz       s18, #7
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s19, v2
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s3, #8704
    s.movz       s19, #8
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s9, v2
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s3, #8768
    s.movz       s9, #9
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s11, v2
    v.ld.w       v0, [s21, #0]
    s.addi       s11, s3, #8832
    s.movz       s21, #10
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s15, v2
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s3, #8896
    s.movz       s15, #11
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s17, v2
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s3, #8960
    s.movz       s17, #12
    v.movi       v2, #0
    vf.cvt.f16.f32 v5, v0
    v.movi       v0, #1
    a.vwrite     a1, s18, v5
    v.ld.w       v5, [s8, #0]
    s.addi       s8, s3, #9024
    s.movz       s18, #13
    vf.cvt.f16.f32 v6, v5
    a.vwrite     a1, s19, v6
    v.ld.w       v5, [s4, #0]
    s.addi       s4, s3, #9088
    s.movz       s19, #14
    v.movi       v6, #0
    v.movi       v7, #0
    vf.cvt.f16.f32 v9, v5
    a.vwrite     a1, s9, v9
    v.ld.w       v5, [s11, #0]
    s.addi       s9, s3, #9152
    s.movz       s11, #15
    vf.cvt.f16.f32 v9, v5
    a.vwrite     a1, s21, v9
    v.ld.w       v5, [s2, #0]
    s.addi       s2, s3, #1024
    s.movz       s21, #3
    v.splat      v9, s21
    s.addi       s21, s3, #9216
    v.sub        v10, v2, v9
    v.cmp.lt     p2, v9, v2
    @p2 v.sel        v11, v10, v9
    vf.cvt.f16.f32 v10, v5
    a.vwrite     a1, s15, v10
    v.ld.w       v5, [s6, #0]
    s.movz       s6, #31
    vf.cvt.f16.f32 v10, v5
    a.vwrite     a1, s17, v10
    v.ld.w       v5, [s8, #0]
    vf.cvt.f16.f32 v10, v5
    a.vwrite     a1, s18, v10
    v.ld.w       v5, [s4, #0]
    vf.cvt.f16.f32 v10, v5
    a.vwrite     a1, s19, v10
    v.ld.w       v5, [s9, #0]
    vf.cvt.f16.f32 v10, v5
    a.vwrite     a1, s11, v10
    v.ld.w       v5, [s2, #0]
    v.sub        v10, v2, v5
    v.cmp.lt     p3, v5, v2
    @p3 v.sel        v12, v10, v5
idiv_1:
    v.splat      v5, s6
    v.shl        v10, v7, v0
    v.lshr       v13, v12, v5
    v.cmp.lt     p4, v7, v2
    v.and        v14, v13, v0
    v.shl        v13, v0, v5
    v.or         v5, v10, v14
    s.subi       s2, s6, #1
    v.cmp.geu    p5, v5, v11
    p.or         p6, p4, p5
    v.sub        v10, v5, v11
    @p6 v.sel        v14, v13, v2
    @p6 v.sel        v13, v10, v5
    v.or         v5, v6, v14
    v.mov        v7, v13
    v.mov        v6, v5
    s.mov        s6, s2
    s.movz       s2, #0
    s.cmp.ge     s4, s6, s2
    br.nz        s4, idiv_1
    p.xor        p4, p3, p2
    v.sub        v0, v2, v6
    s.addi       s2, s3, #1088
    @p4 v.sel        v2, v0, v6
    v.movi       v0, #0
    v.st.w       [s21, #0], v2
    v.sub        v2, v0, v9
    v.cmp.lt     p2, v9, v0
    s.addi       s4, s21, #64
    v.movi       v5, #1
    @p2 v.sel        v6, v2, v9
    v.movi       v2, #0
    v.movi       v7, #0
    s.movz       s6, #31
    v.ld.w       v10, [s2, #0]
    v.sub        v11, v0, v10
    v.cmp.lt     p3, v10, v0
    @p3 v.sel        v12, v11, v10
idiv_2:
    v.splat      v10, s6
    v.shl        v11, v7, v5
    v.lshr       v13, v12, v10
    v.cmp.lt     p4, v7, v0
    v.and        v14, v13, v5
    v.shl        v13, v5, v10
    v.or         v10, v11, v14
    s.subi       s2, s6, #1
    v.cmp.geu    p5, v10, v6
    p.or         p6, p4, p5
    v.sub        v11, v10, v6
    @p6 v.sel        v14, v13, v0
    @p6 v.sel        v13, v11, v10
    v.or         v10, v2, v14
    v.mov        v7, v13
    v.mov        v2, v10
    s.mov        s6, s2
    s.movz       s2, #0
    s.cmp.ge     s8, s6, s2
    br.nz        s8, idiv_2
    p.xor        p4, p3, p2
    v.sub        v5, v0, v2
    s.addi       s2, s3, #1152
    @p4 v.sel        v0, v5, v2
    v.movi       v2, #0
    v.st.w       [s4, #0], v0
    v.sub        v0, v2, v9
    v.cmp.lt     p2, v9, v2
    s.addi       s4, s21, #128
    v.movi       v5, #1
    @p2 v.sel        v6, v0, v9
    v.movi       v0, #0
    v.movi       v7, #0
    s.movz       s6, #31
    v.ld.w       v10, [s2, #0]
    v.sub        v11, v2, v10
    v.cmp.lt     p3, v10, v2
    @p3 v.sel        v12, v11, v10
idiv_3:
    v.splat      v10, s6
    v.shl        v11, v7, v5
    v.lshr       v13, v12, v10
    v.cmp.lt     p4, v7, v2
    v.and        v14, v13, v5
    v.shl        v13, v5, v10
    v.or         v10, v11, v14
    s.subi       s2, s6, #1
    v.cmp.geu    p5, v10, v6
    p.or         p6, p4, p5
    v.sub        v11, v10, v6
    @p6 v.sel        v14, v13, v2
    @p6 v.sel        v13, v11, v10
    v.or         v10, v0, v14
    v.mov        v7, v13
    v.mov        v0, v10
    s.mov        s6, s2
    s.movz       s2, #0
    s.cmp.ge     s8, s6, s2
    br.nz        s8, idiv_3
    p.xor        p4, p3, p2
    v.sub        v5, v2, v0
    s.addi       s2, s3, #1216
    @p4 v.sel        v2, v5, v0
    v.movi       v0, #0
    v.st.w       [s4, #0], v2
    v.sub        v2, v0, v9
    v.cmp.lt     p2, v9, v0
    s.addi       s4, s21, #192
    v.movi       v5, #1
    @p2 v.sel        v6, v2, v9
    v.movi       v2, #0
    v.movi       v7, #0
    s.movz       s6, #31
    v.ld.w       v10, [s2, #0]
    v.sub        v11, v0, v10
    v.cmp.lt     p3, v10, v0
    @p3 v.sel        v12, v11, v10
idiv_4:
    v.splat      v10, s6
    v.shl        v11, v7, v5
    v.lshr       v13, v12, v10
    v.cmp.lt     p4, v7, v0
    v.and        v14, v13, v5
    v.shl        v13, v5, v10
    v.or         v10, v11, v14
    s.subi       s2, s6, #1
    v.cmp.geu    p5, v10, v6
    p.or         p6, p4, p5
    v.sub        v11, v10, v6
    @p6 v.sel        v14, v13, v0
    @p6 v.sel        v13, v11, v10
    v.or         v10, v2, v14
    v.mov        v7, v13
    v.mov        v2, v10
    s.mov        s6, s2
    s.movz       s2, #0
    s.cmp.ge     s8, s6, s2
    br.nz        s8, idiv_4
    p.xor        p4, p3, p2
    v.sub        v5, v0, v2
    s.addi       s2, s3, #1280
    @p4 v.sel        v0, v5, v2
    v.movi       v2, #0
    v.st.w       [s4, #0], v0
    v.sub        v0, v2, v9
    v.cmp.lt     p2, v9, v2
    s.addi       s4, s21, #256
    v.movi       v5, #1
    @p2 v.sel        v6, v0, v9
    v.movi       v0, #0
    v.movi       v7, #0
    s.movz       s6, #31
    v.ld.w       v10, [s2, #0]
    v.sub        v11, v2, v10
    v.cmp.lt     p3, v10, v2
    @p3 v.sel        v12, v11, v10
idiv_5:
    v.splat      v10, s6
    v.shl        v11, v7, v5
    v.lshr       v13, v12, v10
    v.cmp.lt     p4, v7, v2
    v.and        v14, v13, v5
    v.shl        v13, v5, v10
    v.or         v10, v11, v14
    s.subi       s2, s6, #1
    v.cmp.geu    p5, v10, v6
    p.or         p6, p4, p5
    v.sub        v11, v10, v6
    @p6 v.sel        v14, v13, v2
    @p6 v.sel        v13, v11, v10
    v.or         v10, v0, v14
    v.mov        v7, v13
    v.mov        v0, v10
    s.mov        s6, s2
    s.movz       s2, #0
    s.cmp.ge     s8, s6, s2
    br.nz        s8, idiv_5
    p.xor        p4, p3, p2
    v.sub        v5, v2, v0
    s.addi       s2, s3, #1344
    @p4 v.sel        v2, v5, v0
    v.movi       v0, #0
    v.st.w       [s4, #0], v2
    v.sub        v2, v0, v9
    v.cmp.lt     p2, v9, v0
    s.addi       s4, s21, #320
    v.movi       v5, #1
    @p2 v.sel        v6, v2, v9
    v.movi       v2, #0
    v.movi       v7, #0
    s.movz       s6, #31
    v.ld.w       v10, [s2, #0]
    v.sub        v11, v0, v10
    v.cmp.lt     p3, v10, v0
    @p3 v.sel        v12, v11, v10
idiv_6:
    v.splat      v10, s6
    v.shl        v11, v7, v5
    v.lshr       v13, v12, v10
    v.cmp.lt     p4, v7, v0
    v.and        v14, v13, v5
    v.shl        v13, v5, v10
    v.or         v10, v11, v14
    s.subi       s2, s6, #1
    v.cmp.geu    p5, v10, v6
    p.or         p6, p4, p5
    v.sub        v11, v10, v6
    @p6 v.sel        v14, v13, v0
    @p6 v.sel        v13, v11, v10
    v.or         v10, v2, v14
    v.mov        v7, v13
    v.mov        v2, v10
    s.mov        s6, s2
    s.movz       s2, #0
    s.cmp.ge     s8, s6, s2
    br.nz        s8, idiv_6
    p.xor        p4, p3, p2
    v.sub        v5, v0, v2
    s.addi       s2, s3, #1408
    @p4 v.sel        v0, v5, v2
    v.movi       v2, #0
    v.st.w       [s4, #0], v0
    v.sub        v0, v2, v9
    v.cmp.lt     p2, v9, v2
    s.addi       s4, s21, #384
    v.movi       v5, #1
    @p2 v.sel        v6, v0, v9
    v.movi       v0, #0
    v.movi       v7, #0
    s.movz       s6, #31
    v.ld.w       v10, [s2, #0]
    v.sub        v11, v2, v10
    v.cmp.lt     p3, v10, v2
    @p3 v.sel        v12, v11, v10
idiv_7:
    v.splat      v10, s6
    v.shl        v11, v7, v5
    v.lshr       v13, v12, v10
    v.cmp.lt     p4, v7, v2
    v.and        v14, v13, v5
    v.shl        v13, v5, v10
    v.or         v10, v11, v14
    s.subi       s2, s6, #1
    v.cmp.geu    p5, v10, v6
    p.or         p6, p4, p5
    v.sub        v11, v10, v6
    @p6 v.sel        v14, v13, v2
    @p6 v.sel        v13, v11, v10
    v.or         v10, v0, v14
    v.mov        v7, v13
    v.mov        v0, v10
    s.mov        s6, s2
    s.movz       s2, #0
    s.cmp.ge     s8, s6, s2
    br.nz        s8, idiv_7
    p.xor        p4, p3, p2
    v.sub        v5, v2, v0
    s.addi       s2, s3, #1472
    @p4 v.sel        v2, v5, v0
    v.movi       v0, #0
    v.st.w       [s4, #0], v2
    v.sub        v2, v0, v9
    v.cmp.lt     p2, v9, v0
    s.addi       s4, s21, #448
    v.movi       v5, #1
    @p2 v.sel        v6, v2, v9
    v.movi       v2, #0
    v.movi       v7, #0
    s.movz       s6, #31
    v.ld.w       v10, [s2, #0]
    v.sub        v11, v0, v10
    v.cmp.lt     p3, v10, v0
    @p3 v.sel        v12, v11, v10
idiv_8:
    v.splat      v10, s6
    v.shl        v11, v7, v5
    v.lshr       v13, v12, v10
    v.cmp.lt     p4, v7, v0
    v.and        v14, v13, v5
    v.shl        v13, v5, v10
    v.or         v10, v11, v14
    s.subi       s2, s6, #1
    v.cmp.geu    p5, v10, v6
    p.or         p6, p4, p5
    v.sub        v11, v10, v6
    @p6 v.sel        v14, v13, v0
    @p6 v.sel        v13, v11, v10
    v.or         v10, v2, v14
    v.mov        v7, v13
    v.mov        v2, v10
    s.mov        s6, s2
    s.movz       s2, #0
    s.cmp.ge     s8, s6, s2
    br.nz        s8, idiv_8
    p.xor        p4, p3, p2
    v.sub        v5, v0, v2
    s.addi       s2, s3, #1536
    @p4 v.sel        v0, v5, v2
    v.movi       v2, #0
    v.st.w       [s4, #0], v0
    v.sub        v0, v2, v9
    v.cmp.lt     p2, v9, v2
    s.addi       s4, s21, #512
    v.movi       v5, #1
    @p2 v.sel        v6, v0, v9
    v.movi       v0, #0
    v.movi       v7, #0
    s.movz       s6, #31
    v.ld.w       v10, [s2, #0]
    v.sub        v11, v2, v10
    v.cmp.lt     p3, v10, v2
    @p3 v.sel        v12, v11, v10
idiv_9:
    v.splat      v10, s6
    v.shl        v11, v7, v5
    v.lshr       v13, v12, v10
    v.cmp.lt     p4, v7, v2
    v.and        v14, v13, v5
    v.shl        v13, v5, v10
    v.or         v10, v11, v14
    s.subi       s2, s6, #1
    v.cmp.geu    p5, v10, v6
    p.or         p6, p4, p5
    v.sub        v11, v10, v6
    @p6 v.sel        v14, v13, v2
    @p6 v.sel        v13, v11, v10
    v.or         v10, v0, v14
    v.mov        v7, v13
    v.mov        v0, v10
    s.mov        s6, s2
    s.movz       s2, #0
    s.cmp.ge     s8, s6, s2
    br.nz        s8, idiv_9
    p.xor        p4, p3, p2
    v.sub        v5, v2, v0
    s.addi       s2, s3, #1600
    @p4 v.sel        v2, v5, v0
    v.movi       v0, #0
    v.st.w       [s4, #0], v2
    v.sub        v2, v0, v9
    v.cmp.lt     p2, v9, v0
    s.addi       s4, s21, #576
    v.movi       v5, #1
    @p2 v.sel        v6, v2, v9
    v.movi       v2, #0
    v.movi       v7, #0
    s.movz       s6, #31
    v.ld.w       v10, [s2, #0]
    v.sub        v11, v0, v10
    v.cmp.lt     p3, v10, v0
    @p3 v.sel        v12, v11, v10
idiv_10:
    v.splat      v10, s6
    v.shl        v11, v7, v5
    v.lshr       v13, v12, v10
    v.cmp.lt     p4, v7, v0
    v.and        v14, v13, v5
    v.shl        v13, v5, v10
    v.or         v10, v11, v14
    s.subi       s2, s6, #1
    v.cmp.geu    p5, v10, v6
    p.or         p6, p4, p5
    v.sub        v11, v10, v6
    @p6 v.sel        v14, v13, v0
    @p6 v.sel        v13, v11, v10
    v.or         v10, v2, v14
    v.mov        v7, v13
    v.mov        v2, v10
    s.mov        s6, s2
    s.movz       s2, #0
    s.cmp.ge     s8, s6, s2
    br.nz        s8, idiv_10
    p.xor        p4, p3, p2
    v.sub        v5, v0, v2
    s.addi       s2, s3, #1664
    @p4 v.sel        v0, v5, v2
    v.movi       v2, #0
    v.st.w       [s4, #0], v0
    v.sub        v0, v2, v9
    v.cmp.lt     p2, v9, v2
    s.addi       s4, s21, #640
    v.movi       v5, #1
    @p2 v.sel        v6, v0, v9
    v.movi       v0, #0
    v.movi       v7, #0
    s.movz       s6, #31
    v.ld.w       v10, [s2, #0]
    v.sub        v11, v2, v10
    v.cmp.lt     p3, v10, v2
    @p3 v.sel        v12, v11, v10
idiv_11:
    v.splat      v10, s6
    v.shl        v11, v7, v5
    v.lshr       v13, v12, v10
    v.cmp.lt     p4, v7, v2
    v.and        v14, v13, v5
    v.shl        v13, v5, v10
    v.or         v10, v11, v14
    s.subi       s2, s6, #1
    v.cmp.geu    p5, v10, v6
    p.or         p6, p4, p5
    v.sub        v11, v10, v6
    @p6 v.sel        v14, v13, v2
    @p6 v.sel        v13, v11, v10
    v.or         v10, v0, v14
    v.mov        v7, v13
    v.mov        v0, v10
    s.mov        s6, s2
    s.movz       s2, #0
    s.cmp.ge     s8, s6, s2
    br.nz        s8, idiv_11
    p.xor        p4, p3, p2
    v.sub        v5, v2, v0
    s.addi       s2, s3, #1728
    @p4 v.sel        v2, v5, v0
    v.movi       v0, #0
    v.st.w       [s4, #0], v2
    v.sub        v2, v0, v9
    v.cmp.lt     p2, v9, v0
    s.addi       s4, s21, #704
    v.movi       v5, #1
    @p2 v.sel        v6, v2, v9
    v.movi       v2, #0
    v.movi       v7, #0
    s.movz       s6, #31
    v.ld.w       v10, [s2, #0]
    v.sub        v11, v0, v10
    v.cmp.lt     p3, v10, v0
    @p3 v.sel        v12, v11, v10
idiv_12:
    v.splat      v10, s6
    v.shl        v11, v7, v5
    v.lshr       v13, v12, v10
    v.cmp.lt     p4, v7, v0
    v.and        v14, v13, v5
    v.shl        v13, v5, v10
    v.or         v10, v11, v14
    s.subi       s2, s6, #1
    v.cmp.geu    p5, v10, v6
    p.or         p6, p4, p5
    v.sub        v11, v10, v6
    @p6 v.sel        v14, v13, v0
    @p6 v.sel        v13, v11, v10
    v.or         v10, v2, v14
    v.mov        v7, v13
    v.mov        v2, v10
    s.mov        s6, s2
    s.movz       s2, #0
    s.cmp.ge     s8, s6, s2
    br.nz        s8, idiv_12
    p.xor        p4, p3, p2
    v.sub        v5, v0, v2
    s.addi       s2, s3, #1792
    @p4 v.sel        v0, v5, v2
    v.movi       v2, #0
    v.st.w       [s4, #0], v0
    v.sub        v0, v2, v9
    v.cmp.lt     p2, v9, v2
    s.addi       s4, s21, #768
    v.movi       v5, #1
    @p2 v.sel        v6, v0, v9
    v.movi       v0, #0
    v.movi       v7, #0
    s.movz       s6, #31
    v.ld.w       v10, [s2, #0]
    v.sub        v11, v2, v10
    v.cmp.lt     p3, v10, v2
    @p3 v.sel        v12, v11, v10
idiv_13:
    v.splat      v10, s6
    v.shl        v11, v7, v5
    v.lshr       v13, v12, v10
    v.cmp.lt     p4, v7, v2
    v.and        v14, v13, v5
    v.shl        v13, v5, v10
    v.or         v10, v11, v14
    s.subi       s2, s6, #1
    v.cmp.geu    p5, v10, v6
    p.or         p6, p4, p5
    v.sub        v11, v10, v6
    @p6 v.sel        v14, v13, v2
    @p6 v.sel        v13, v11, v10
    v.or         v10, v0, v14
    v.mov        v7, v13
    v.mov        v0, v10
    s.mov        s6, s2
    s.movz       s2, #0
    s.cmp.ge     s8, s6, s2
    br.nz        s8, idiv_13
    p.xor        p4, p3, p2
    v.sub        v5, v2, v0
    s.addi       s2, s3, #1856
    @p4 v.sel        v2, v5, v0
    v.movi       v0, #0
    v.st.w       [s4, #0], v2
    v.sub        v2, v0, v9
    v.cmp.lt     p2, v9, v0
    s.addi       s4, s21, #832
    v.movi       v5, #1
    @p2 v.sel        v6, v2, v9
    v.movi       v2, #0
    v.movi       v7, #0
    s.movz       s6, #31
    v.ld.w       v10, [s2, #0]
    v.sub        v11, v0, v10
    v.cmp.lt     p3, v10, v0
    @p3 v.sel        v12, v11, v10
idiv_14:
    v.splat      v10, s6
    v.shl        v11, v7, v5
    v.lshr       v13, v12, v10
    v.cmp.lt     p4, v7, v0
    v.and        v14, v13, v5
    v.shl        v13, v5, v10
    v.or         v10, v11, v14
    s.subi       s2, s6, #1
    v.cmp.geu    p5, v10, v6
    p.or         p6, p4, p5
    v.sub        v11, v10, v6
    @p6 v.sel        v14, v13, v0
    @p6 v.sel        v13, v11, v10
    v.or         v10, v2, v14
    v.mov        v7, v13
    v.mov        v2, v10
    s.mov        s6, s2
    s.movz       s2, #0
    s.cmp.ge     s8, s6, s2
    br.nz        s8, idiv_14
    p.xor        p4, p3, p2
    v.sub        v5, v0, v2
    s.addi       s2, s3, #1920
    @p4 v.sel        v0, v5, v2
    v.movi       v2, #0
    v.st.w       [s4, #0], v0
    v.sub        v0, v2, v9
    v.cmp.lt     p2, v9, v2
    s.addi       s4, s21, #896
    v.movi       v5, #1
    @p2 v.sel        v6, v0, v9
    v.movi       v0, #0
    v.movi       v7, #0
    s.movz       s6, #31
    v.ld.w       v10, [s2, #0]
    v.sub        v11, v2, v10
    v.cmp.lt     p3, v10, v2
    @p3 v.sel        v12, v11, v10
idiv_15:
    v.splat      v10, s6
    v.shl        v11, v7, v5
    v.lshr       v13, v12, v10
    v.cmp.lt     p4, v7, v2
    v.and        v14, v13, v5
    v.shl        v13, v5, v10
    v.or         v10, v11, v14
    s.subi       s2, s6, #1
    v.cmp.geu    p5, v10, v6
    p.or         p6, p4, p5
    v.sub        v11, v10, v6
    @p6 v.sel        v14, v13, v2
    @p6 v.sel        v13, v11, v10
    v.or         v10, v0, v14
    v.mov        v7, v13
    v.mov        v0, v10
    s.mov        s6, s2
    s.movz       s2, #0
    s.cmp.ge     s8, s6, s2
    br.nz        s8, idiv_15
    p.xor        p4, p3, p2
    v.sub        v5, v2, v0
    s.addi       s2, s3, #1984
    @p4 v.sel        v2, v5, v0
    v.movi       v0, #0
    v.st.w       [s4, #0], v2
    v.sub        v2, v0, v9
    v.cmp.lt     p2, v9, v0
    s.addi       s4, s21, #960
    v.movi       v5, #1
    @p2 v.sel        v6, v2, v9
    v.movi       v2, #0
    v.movi       v7, #0
    s.movz       s6, #31
    v.ld.w       v9, [s2, #0]
    v.sub        v10, v0, v9
    v.cmp.lt     p3, v9, v0
    @p3 v.sel        v11, v10, v9
idiv_16:
    v.splat      v9, s6
    v.shl        v10, v7, v5
    v.lshr       v12, v11, v9
    v.cmp.lt     p4, v7, v0
    v.and        v13, v12, v5
    v.shl        v12, v5, v9
    v.or         v9, v10, v13
    s.subi       s2, s6, #1
    v.cmp.geu    p5, v9, v6
    p.or         p6, p4, p5
    v.sub        v10, v9, v6
    @p6 v.sel        v13, v12, v0
    @p6 v.sel        v12, v10, v9
    v.or         v9, v2, v13
    v.mov        v7, v12
    v.mov        v2, v9
    s.mov        s6, s2
    s.movz       s2, #0
    s.cmp.ge     s8, s6, s2
    br.nz        s8, idiv_16
    p.xor        p4, p3, p2
    v.sub        v5, v0, v2
    s.addi       s2, s3, #9216
    @p4 v.sel        v0, v5, v2
    s.addi       s6, s3, #0
    v.st.w       [s4, #0], v0
    fence.acq_rel.device
    v.splat      v0, s1
    s.addi       s4, s3, #10240
    s.addi       s8, s3, #9280
    s.addi       s9, s3, #64
    s.addi       s11, s4, #64
    s.addi       s15, s3, #9344
    v.ld.w       v2, [s2, #0]
    s.addi       s2, s3, #128
    v.ld.w       v5, [s6, #0]
    v.mul        v6, v2, v4
    s.addi       s6, s4, #128
    v.add        v2, v8, v6
    v.mul        v6, v5, v3
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s4, #0], v2
    v.ld.w       v2, [s8, #0]
    s.addi       s8, s3, #9408
    v.ld.w       v5, [s9, #0]
    v.mul        v6, v2, v4
    s.addi       s9, s3, #192
    v.add        v2, v8, v6
    v.mul        v6, v5, v3
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s11, #0], v2
    s.addi       s11, s4, #192
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s3, #9472
    v.ld.w       v5, [s2, #0]
    v.mul        v6, v2, v4
    s.addi       s2, s3, #256
    v.add        v2, v8, v6
    v.mul        v6, v5, v3
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s6, #0], v2
    s.addi       s6, s4, #256
    v.ld.w       v2, [s8, #0]
    s.addi       s8, s3, #9536
    v.ld.w       v5, [s9, #0]
    v.mul        v6, v2, v4
    s.addi       s9, s3, #320
    v.add        v2, v8, v6
    v.mul        v6, v5, v3
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s11, #0], v2
    s.addi       s11, s4, #320
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s3, #9600
    v.ld.w       v5, [s2, #0]
    v.mul        v6, v2, v4
    s.addi       s2, s3, #384
    v.add        v2, v8, v6
    v.mul        v6, v5, v3
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s6, #0], v2
    s.addi       s6, s4, #384
    v.ld.w       v2, [s8, #0]
    s.addi       s8, s3, #9664
    v.ld.w       v5, [s9, #0]
    v.mul        v6, v2, v4
    s.addi       s9, s3, #448
    v.add        v2, v8, v6
    v.mul        v6, v5, v3
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s11, #0], v2
    s.addi       s11, s4, #448
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s3, #9728
    v.ld.w       v5, [s2, #0]
    v.mul        v6, v2, v4
    s.addi       s2, s3, #512
    v.add        v2, v8, v6
    v.mul        v6, v5, v3
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s6, #0], v2
    s.addi       s6, s4, #512
    v.ld.w       v2, [s8, #0]
    s.addi       s8, s3, #9792
    v.ld.w       v5, [s9, #0]
    v.mul        v6, v2, v4
    s.addi       s9, s3, #576
    v.add        v2, v8, v6
    v.mul        v6, v5, v3
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s11, #0], v2
    s.addi       s11, s4, #576
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s3, #9856
    v.ld.w       v5, [s2, #0]
    v.mul        v6, v2, v4
    s.addi       s2, s3, #640
    v.add        v2, v8, v6
    v.mul        v6, v5, v3
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s6, #0], v2
    s.addi       s6, s4, #640
    v.ld.w       v2, [s8, #0]
    s.addi       s8, s3, #9920
    v.ld.w       v5, [s9, #0]
    v.mul        v6, v2, v4
    s.addi       s9, s3, #704
    v.add        v2, v8, v6
    v.mul        v6, v5, v3
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s11, #0], v2
    s.addi       s11, s4, #704
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s3, #9984
    v.ld.w       v5, [s2, #0]
    v.mul        v6, v2, v4
    s.addi       s2, s3, #768
    v.add        v2, v8, v6
    v.mul        v6, v5, v3
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s6, #0], v2
    s.addi       s6, s4, #768
    v.ld.w       v2, [s8, #0]
    s.addi       s8, s3, #10048
    v.ld.w       v5, [s9, #0]
    v.mul        v6, v2, v4
    s.addi       s9, s3, #832
    v.add        v2, v8, v6
    v.mul        v6, v5, v3
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s11, #0], v2
    s.addi       s11, s4, #832
    v.splat      v2, s7
    v.cmp.lt     p2, v2, v1
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s3, #10112
    p.and        p3, p1, p2
    v.ld.w       v5, [s2, #0]
    v.mul        v6, v2, v4
    s.addi       s2, s3, #896
    v.add        v2, v8, v6
    v.mul        v6, v5, v3
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s6, #0], v2
    s.addi       s6, s4, #896
    s.addi       s17, s4, #960
    v.ld.w       v2, [s8, #0]
    s.addi       s4, s3, #10176
    v.ld.w       v5, [s9, #0]
    v.mul        v6, v2, v4
    s.addi       s8, s3, #960
    v.add        v2, v8, v6
    v.mul        v6, v5, v3
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s11, #0], v2
    s.addi       s9, s3, #10240
    v.ld.w       v2, [s15, #0]
    s.addi       s11, s3, #11264
    v.ld.w       v5, [s2, #0]
    v.mul        v6, v2, v4
    s.addi       s2, s3, #10304
    v.add        v2, v8, v6
    v.mul        v6, v5, v3
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s6, #0], v2
    s.addi       s6, s7, #1
    v.splat      v2, s6
    s.addi       s6, s11, #64
    v.cmp.lt     p2, v2, v1
    p.and        p4, p1, p2
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s3, #10368
    v.ld.w       v5, [s8, #0]
    v.mul        v6, v2, v4
    s.addi       s8, s7, #2
    v.add        v2, v8, v6
    v.splat      v4, s8
    s.addi       s8, s11, #128
    v.mul        v6, v5, v3
    v.add        v3, v2, v6
    v.add        v2, v0, v3
    v.st.w       [s17, #0], v2
    fence.acq_rel.device
    s.addi       s15, s3, #10432
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s7, #3
    v.splat      v2, s9
    s.addi       s9, s11, #192
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v3, [s12, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v1
    p.and        p3, p1, p2
    v.st.w       [s11, #0], v3
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s3, #10496
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v3, [s12, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v1
    p.and        p4, p1, p2
    v.st.w       [s6, #0], v3
    s.addi       s6, s7, #4
    v.splat      v0, s6
    s.addi       s6, s11, #256
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s3, #10560
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v3, [s12, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    v.st.w       [s8, #0], v3
    s.addi       s8, s7, #5
    v.splat      v0, s8
    s.addi       s8, s11, #320
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s3, #10624
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v3, [s12, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p4, p1, p2
    v.st.w       [s9, #0], v3
    s.addi       s9, s7, #6
    v.splat      v0, s9
    s.addi       s9, s11, #384
    v.ld.w       v2, [s2, #0]
    s.addi       s2, s3, #10688
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v3, [s12, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    v.st.w       [s6, #0], v3
    s.addi       s6, s7, #7
    v.splat      v0, s6
    s.addi       s6, s11, #448
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s3, #10752
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v3, [s12, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p4, p1, p2
    v.st.w       [s8, #0], v3
    s.addi       s8, s7, #8
    v.splat      v0, s8
    s.addi       s8, s11, #512
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s3, #10816
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v3, [s12, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    v.st.w       [s9, #0], v3
    s.addi       s9, s7, #9
    v.splat      v0, s9
    s.addi       s9, s11, #576
    v.ld.w       v2, [s2, #0]
    s.addi       s2, s3, #10880
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v3, [s12, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p4, p1, p2
    v.st.w       [s6, #0], v3
    s.addi       s6, s7, #10
    v.splat      v0, s6
    s.addi       s6, s11, #640
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s3, #10944
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v3, [s12, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    v.st.w       [s8, #0], v3
    s.addi       s8, s7, #11
    v.splat      v0, s8
    s.addi       s8, s11, #704
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s3, #11008
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v3, [s12, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p4, p1, p2
    v.st.w       [s9, #0], v3
    s.addi       s9, s7, #12
    v.splat      v0, s9
    s.addi       s9, s11, #768
    v.ld.w       v2, [s2, #0]
    s.addi       s2, s3, #11072
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v3, [s12, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    v.st.w       [s6, #0], v3
    s.addi       s6, s7, #13
    v.splat      v0, s1
    v.splat      v2, s6
    s.addi       s6, s11, #832
    v.ld.w       v3, [s4, #0]
    s.addi       s4, s3, #11136
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v4, [s12, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v1
    p.and        p4, p1, p2
    v.st.w       [s8, #0], v4
    s.addi       s8, s7, #14
    v.splat      v2, s8
    s.addi       s8, s11, #896
    s.addi       s17, s11, #960
    v.ld.w       v3, [s15, #0]
    s.addi       s11, s3, #11200
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v4, [s12, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v1
    p.and        p3, p1, p2
    v.st.w       [s9, #0], v4
    s.addi       s9, s7, #15
    v.splat      v2, s9
    s.addi       s9, s3, #9216
    v.ld.w       v3, [s2, #0]
    s.addi       s2, s3, #4096
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v4, [s12, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v1
    p.and        p4, p1, p2
    v.st.w       [s6, #0], v4
    s.movz       s6, #2048
    v.splat      v2, s6
    s.addi       s6, s3, #12288
    v.ld.w       v3, [s4, #0]
    s.addi       s4, s3, #9280
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v4, [s12, v3]              // index is in elements (ISA sec 9.1)
    v.st.w       [s8, #0], v4
    s.addi       s8, s3, #4160
    v.ld.w       v3, [s11, #0]
    s.addi       s11, s6, #64
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v4, [s12, v3]              // index is in elements (ISA sec 9.1)
    s.addi       s12, s3, #9344
    v.st.w       [s17, #0], v4
    fence.acq_rel.device
    s.addi       s15, s3, #4224
    v.ld.w       v3, [s9, #0]
    s.addi       s9, s6, #128
    v.ld.w       v4, [s2, #0]
    v.mul        v5, v3, v2
    s.addi       s2, s3, #9408
    v.add        v3, v4, v5
    v.add        v4, v0, v3
    v.st.w       [s6, #0], v4
    v.ld.w       v3, [s4, #0]
    s.addi       s4, s3, #4288
    v.ld.w       v4, [s8, #0]
    v.mul        v5, v3, v2
    s.addi       s8, s6, #192
    v.add        v3, v4, v5
    v.add        v4, v0, v3
    v.st.w       [s11, #0], v4
    s.addi       s11, s3, #9472
    v.ld.w       v3, [s12, #0]
    s.addi       s12, s3, #4352
    v.ld.w       v4, [s15, #0]
    v.mul        v5, v3, v2
    s.addi       s15, s6, #256
    v.add        v3, v4, v5
    v.add        v4, v0, v3
    v.st.w       [s9, #0], v4
    s.addi       s9, s3, #9536
    v.ld.w       v3, [s2, #0]
    s.addi       s2, s3, #4416
    v.ld.w       v4, [s4, #0]
    v.mul        v5, v3, v2
    s.addi       s4, s6, #320
    v.add        v3, v4, v5
    v.add        v4, v0, v3
    v.st.w       [s8, #0], v4
    s.addi       s8, s3, #9600
    v.ld.w       v3, [s11, #0]
    s.addi       s11, s3, #4480
    v.ld.w       v4, [s12, #0]
    v.mul        v5, v3, v2
    s.addi       s12, s6, #384
    v.add        v3, v4, v5
    v.add        v4, v0, v3
    v.st.w       [s15, #0], v4
    s.addi       s15, s3, #9664
    v.ld.w       v3, [s9, #0]
    s.addi       s9, s3, #4544
    v.ld.w       v4, [s2, #0]
    v.mul        v5, v3, v2
    s.addi       s2, s6, #448
    v.add        v3, v4, v5
    v.add        v4, v0, v3
    v.st.w       [s4, #0], v4
    s.addi       s4, s3, #9728
    v.ld.w       v3, [s8, #0]
    s.addi       s8, s3, #4608
    v.ld.w       v4, [s11, #0]
    v.mul        v5, v3, v2
    s.addi       s11, s6, #512
    v.add        v3, v4, v5
    v.add        v4, v0, v3
    v.st.w       [s12, #0], v4
    s.addi       s12, s3, #9792
    v.ld.w       v3, [s15, #0]
    s.addi       s15, s3, #4672
    v.ld.w       v4, [s9, #0]
    v.mul        v5, v3, v2
    s.addi       s9, s6, #576
    v.add        v3, v4, v5
    v.add        v4, v0, v3
    v.st.w       [s2, #0], v4
    s.addi       s2, s3, #9856
    v.ld.w       v3, [s4, #0]
    s.addi       s4, s3, #4736
    v.ld.w       v4, [s8, #0]
    v.mul        v5, v3, v2
    s.addi       s8, s6, #640
    v.add        v3, v4, v5
    v.add        v4, v0, v3
    v.st.w       [s11, #0], v4
    s.addi       s11, s3, #9920
    v.ld.w       v3, [s12, #0]
    s.addi       s12, s3, #4800
    v.ld.w       v4, [s15, #0]
    v.mul        v5, v3, v2
    s.addi       s15, s6, #704
    v.add        v3, v4, v5
    v.add        v4, v0, v3
    v.st.w       [s9, #0], v4
    s.addi       s9, s3, #9984
    v.ld.w       v3, [s2, #0]
    s.addi       s2, s3, #4864
    v.ld.w       v4, [s4, #0]
    v.mul        v5, v3, v2
    s.addi       s4, s6, #768
    v.add        v3, v4, v5
    v.add        v4, v0, v3
    v.st.w       [s8, #0], v4
    s.addi       s8, s3, #10048
    v.splat      v3, s7
    v.ld.w       v4, [s11, #0]
    s.addi       s11, s3, #4928
    v.ld.w       v5, [s12, #0]
    v.mul        v6, v4, v2
    s.addi       s12, s6, #832
    v.cmp.lt     p2, v3, v1
    p.and        p3, p1, p2
    v.add        v3, v5, v6
    v.add        v4, v0, v3
    v.st.w       [s15, #0], v4
    s.addi       s15, s3, #10112
    v.ld.w       v3, [s9, #0]
    s.addi       s9, s3, #4992
    v.ld.w       v4, [s2, #0]
    v.mul        v5, v3, v2
    s.addi       s2, s6, #896
    s.addi       s17, s6, #960
    v.add        v3, v4, v5
    v.add        v4, v0, v3
    v.st.w       [s4, #0], v4
    s.addi       s4, s3, #10176
    v.ld.w       v3, [s8, #0]
    s.addi       s6, s3, #5056
    v.ld.w       v4, [s11, #0]
    v.mul        v5, v3, v2
    s.addi       s8, s3, #12288
    v.add        v3, v4, v5
    v.add        v4, v0, v3
    v.st.w       [s12, #0], v4
    s.addi       s11, s3, #13312
    v.ld.w       v3, [s15, #0]
    s.addi       s12, s3, #12352
    v.ld.w       v4, [s9, #0]
    v.mul        v5, v3, v2
    s.addi       s9, s7, #1
    v.splat      v3, s9
    s.addi       s9, s11, #64
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    v.add        v3, v4, v5
    v.add        v4, v0, v3
    v.st.w       [s2, #0], v4
    s.addi       s2, s3, #12416
    v.ld.w       v3, [s4, #0]
    s.addi       s4, s7, #2
    v.splat      v4, s4
    s.addi       s4, s11, #128
    v.ld.w       v5, [s6, #0]
    v.mul        v6, v3, v2
    s.addi       s6, s3, #12480
    v.add        v3, v5, v6
    v.add        v5, v0, v3
    v.st.w       [s17, #0], v5
    fence.acq_rel.device
    s.addi       s15, s7, #3
    v.splat      v0, s15
    s.addi       s15, s11, #192
    v.ld.w       v3, [s8, #0]
    s.addi       s8, s3, #12544
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s13, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v1
    p.and        p3, p1, p2
    v.st.w       [s11, #0], v5
    v.ld.w       v3, [s12, #0]
    s.addi       s12, s7, #4
    v.splat      v4, s12
    s.addi       s12, s11, #256
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s13, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p4, p1, p2
    v.st.w       [s9, #0], v5
    s.addi       s9, s3, #12608
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s7, #5
    v.splat      v3, s2
    s.addi       s2, s11, #320
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v1
    p.and        p3, p1, p2
    v.st.w       [s4, #0], v5
    s.addi       s4, s3, #12672
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s7, #6
    v.splat      v4, s6
    s.addi       s6, s11, #384
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    v.st.w       [s15, #0], v5
    s.addi       s15, s3, #12736
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s7, #7
    v.splat      v3, s8
    s.addi       s8, s11, #448
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v1
    p.and        p3, p1, p2
    v.st.w       [s12, #0], v5
    s.addi       s12, s3, #12800
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s7, #8
    v.splat      v4, s9
    s.addi       s9, s11, #512
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    v.st.w       [s2, #0], v5
    s.addi       s2, s3, #12864
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s7, #9
    v.splat      v3, s4
    s.addi       s4, s11, #576
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v1
    p.and        p3, p1, p2
    v.st.w       [s6, #0], v5
    s.addi       s6, s3, #12928
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s7, #10
    v.splat      v4, s15
    s.addi       s15, s11, #640
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    v.st.w       [s8, #0], v5
    s.addi       s8, s3, #12992
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s7, #11
    v.splat      v3, s12
    s.addi       s12, s11, #704
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v1
    p.and        p3, p1, p2
    v.st.w       [s9, #0], v5
    s.addi       s9, s3, #13056
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s7, #12
    v.splat      v4, s2
    s.addi       s2, s11, #768
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    v.st.w       [s4, #0], v5
    s.addi       s4, s3, #13120
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s7, #13
    v.splat      v3, s6
    s.addi       s6, s11, #832
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v1
    p.and        p3, p1, p2
    .li       s17, #1054295293
    v.splat      v0, s17                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.st.w       [s15, #0], v5
    s.addi       s15, s3, #13184
    .li       s17, #1054295293
    v.splat      v4, s17                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.ld.w       v5, [s8, #0]
    s.addi       s8, s7, #14
    v.splat      v6, s8
    s.addi       s8, s11, #896
    s.addi       s17, s11, #960
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v7, [s13, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    v.st.w       [s12, #0], v7
    s.addi       s11, s3, #13248
    v.ld.w       v3, [s9, #0]
    s.addi       s9, s7, #15
    v.splat      v5, s9
    s.addi       s9, s3, #11264
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v7, [s13, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v1
    p.and        p3, p1, p2
    v.st.w       [s2, #0], v7
    s.movz       s2, #0
    v.ld.w       v3, [s4, #0]
    s.addi       s4, s3, #13312
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v6, [s13, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v1
    p.and        p4, p1, p2
    v.st.w       [s6, #0], v6
    s.movz       s6, #0
    v.ld.w       v3, [s15, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s12, #0
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s13, v3]              // index is in elements (ISA sec 9.1)
    v.st.w       [s8, #0], v5
    s.addi       s8, s3, #11328
    v.ld.w       v3, [s11, #0]
    s.movz       s11, #1
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s13, v3]              // index is in elements (ISA sec 9.1)
    s.addi       s13, s3, #13376
    v.st.w       [s17, #0], v5
    fence.acq_rel.device
    s.movz       s15, #1
    v.ld.w       v3, [s9, #0]
    a.vread      v5, a0, s2
    s.movz       s2, #1
    s.addi       s9, s3, #11392
    v.ld.w       v6, [s4, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s6
    s.movz       s4, #2
    s.addi       s6, s3, #13440
    vf.mul       v8, v7, v5
    vf.cvt.f16.f32 v5, v6
    vf.mul       v6, v5, v3
    vf.add       v3, v8, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s12, v5
    v.ld.w       v3, [s8, #0]
    a.vread      v5, a0, s11
    s.movz       s8, #2
    s.movz       s11, #2
    s.addi       s12, s3, #11456
    v.ld.w       v6, [s13, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s15
    s.movz       s13, #3
    s.addi       s15, s3, #13504
    vf.mul       v8, v7, v5
    vf.cvt.f16.f32 v5, v6
    vf.mul       v6, v5, v3
    vf.add       v3, v8, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s2, v5
    v.ld.w       v3, [s9, #0]
    a.vread      v5, a0, s4
    s.movz       s2, #3
    s.movz       s4, #3
    s.addi       s9, s3, #11520
    v.ld.w       v6, [s6, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s8
    s.movz       s6, #4
    s.addi       s8, s3, #13568
    vf.mul       v8, v7, v5
    vf.cvt.f16.f32 v5, v6
    vf.mul       v6, v5, v3
    vf.add       v3, v8, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s11, v5
    v.ld.w       v3, [s12, #0]
    a.vread      v5, a0, s13
    s.movz       s11, #4
    s.movz       s12, #4
    s.addi       s13, s3, #11584
    v.ld.w       v6, [s15, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s2
    s.movz       s2, #5
    s.addi       s15, s3, #13632
    vf.mul       v8, v7, v5
    vf.cvt.f16.f32 v5, v6
    vf.mul       v6, v5, v3
    vf.add       v3, v8, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s4, v5
    v.ld.w       v3, [s9, #0]
    a.vread      v5, a0, s6
    s.movz       s4, #5
    s.movz       s6, #5
    s.addi       s9, s3, #11648
    v.ld.w       v6, [s8, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s11
    s.movz       s8, #6
    s.addi       s11, s3, #13696
    vf.mul       v8, v7, v5
    vf.cvt.f16.f32 v5, v6
    vf.mul       v6, v5, v3
    vf.add       v3, v8, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s12, v5
    v.ld.w       v3, [s13, #0]
    a.vread      v5, a0, s2
    s.movz       s2, #6
    s.movz       s12, #6
    s.addi       s13, s3, #11712
    v.ld.w       v6, [s15, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s4
    s.movz       s4, #7
    s.addi       s15, s3, #13760
    vf.mul       v8, v7, v5
    vf.cvt.f16.f32 v5, v6
    vf.mul       v6, v5, v3
    vf.add       v3, v8, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s6, v5
    v.ld.w       v3, [s9, #0]
    a.vread      v5, a0, s8
    s.movz       s6, #7
    s.movz       s8, #7
    s.addi       s9, s3, #11776
    v.ld.w       v6, [s11, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s2
    s.movz       s2, #8
    s.addi       s11, s3, #13824
    vf.mul       v8, v7, v5
    vf.cvt.f16.f32 v5, v6
    vf.mul       v6, v5, v3
    vf.add       v3, v8, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s12, v5
    v.ld.w       v3, [s13, #0]
    a.vread      v5, a0, s4
    s.movz       s4, #8
    s.movz       s12, #8
    s.addi       s13, s3, #11840
    v.ld.w       v6, [s15, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s6
    s.movz       s6, #9
    s.addi       s15, s3, #13888
    vf.mul       v8, v7, v5
    vf.cvt.f16.f32 v5, v6
    vf.mul       v6, v5, v3
    vf.add       v3, v8, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s8, v5
    v.ld.w       v3, [s9, #0]
    a.vread      v5, a0, s2
    s.movz       s2, #9
    s.movz       s8, #9
    s.addi       s9, s3, #11904
    v.ld.w       v6, [s11, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s4
    s.movz       s4, #10
    s.addi       s11, s3, #13952
    vf.mul       v8, v7, v5
    vf.cvt.f16.f32 v5, v6
    vf.mul       v6, v5, v3
    vf.add       v3, v8, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s12, v5
    v.ld.w       v3, [s13, #0]
    a.vread      v5, a0, s6
    s.movz       s6, #10
    s.movz       s12, #10
    s.addi       s13, s3, #11968
    v.ld.w       v6, [s15, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s2
    s.movz       s2, #11
    s.addi       s15, s3, #14016
    vf.mul       v8, v7, v5
    vf.cvt.f16.f32 v5, v6
    vf.mul       v6, v5, v3
    vf.add       v3, v8, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s8, v5
    v.ld.w       v3, [s9, #0]
    a.vread      v5, a0, s4
    s.movz       s4, #11
    s.movz       s8, #11
    s.addi       s9, s3, #12032
    v.ld.w       v6, [s11, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s6
    s.movz       s6, #12
    s.addi       s11, s3, #14080
    vf.mul       v8, v7, v5
    vf.cvt.f16.f32 v5, v6
    vf.mul       v6, v5, v3
    vf.add       v3, v8, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s12, v5
    v.ld.w       v3, [s13, #0]
    a.vread      v5, a0, s2
    s.movz       s2, #12
    s.movz       s12, #12
    s.addi       s13, s3, #12096
    v.ld.w       v6, [s15, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s4
    s.movz       s4, #13
    s.addi       s15, s3, #14144
    vf.mul       v8, v7, v5
    vf.cvt.f16.f32 v5, v6
    vf.mul       v6, v5, v3
    vf.add       v3, v8, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s8, v5
    v.ld.w       v3, [s9, #0]
    a.vread      v5, a0, s6
    s.movz       s6, #13
    s.movz       s8, #13
    s.addi       s9, s3, #12160
    v.ld.w       v6, [s11, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s2
    s.movz       s2, #14
    s.addi       s11, s3, #14208
    vf.mul       v8, v7, v5
    vf.cvt.f16.f32 v5, v6
    vf.mul       v6, v5, v3
    vf.add       v3, v8, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s12, v5
    v.ld.w       v3, [s13, #0]
    a.vread      v5, a0, s4
    s.movz       s4, #14
    s.movz       s12, #14
    s.addi       s13, s3, #12224
    s.muli       s17, s5, #128                   // a runtime tile origin, x128
    v.ld.w       v6, [s15, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s6
    s.movz       s5, #15
    s.addi       s6, s3, #14272
    vf.mul       v8, v7, v5
    vf.cvt.f16.f32 v5, v6
    v.splat      v6, s7
    v.cmp.lt     p2, v6, v1
    vf.mul       v6, v5, v3
    p.and        p3, p1, p2
    vf.add       v3, v8, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s8, v5
    v.ld.w       v3, [s9, #0]
    a.vread      v5, a0, s2
    s.movz       s2, #15
    s.movz       s8, #15
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.addi       s9, s3, #3072
    v.ld.w       v6, [s11, #0]
    vf.cvt.f16.f32 v7, v3
    a.vread      v3, a1, s4
    s.movz       s4, #0
    s.movz       s11, #0
    vf.mul       v8, v7, v5
    v.splat      v5, s7
    v.cmp.lt     p2, v5, v1
    p.and        p4, p1, p2
    vf.cvt.f16.f32 v5, v6
    vf.mul       v6, v5, v3
    vf.add       v3, v8, v6
    vf.mul       v5, v3, v4
    a.vwrite     a2, s12, v5
    v.ld.w       v3, [s13, #0]
    a.vread      v5, a0, s5
    s.muli       s5, s10, #4                     // a runtime tile origin, x4
    s.addi       s12, s7, #1
    s.addi       s13, s3, #3136
    v.splat      v6, s12
    s.movz       s12, #1
    s.add        s15, s14, s5                    // the tile origin
    s.addi       s5, s20, #64                    // row 1
    s.add        s14, s15, s17                   // the tile origin
    v.ld.w       v7, [s6, #0]
    vf.cvt.f16.f32 v8, v3
    a.vread      v3, a1, s2
    s.movz       s2, #1
    vf.mul       v9, v8, v5
    vf.cvt.f16.f32 v5, v7
    s.addi       s6, s7, #1
    s.addi       s15, s14, #128                  // row 1
    vf.mul       v7, v5, v3
    v.splat      v3, s6
    vf.add       v5, v9, v7
    vf.mul       v7, v5, v4
    a.vwrite     a2, s8, v7
    v.ld.w       v4, [s9, #0]
    a.vread      v5, a0, s4
    s.addi       s4, s3, #3200
    s.movz       s6, #2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s20, #0]
    vf.cvt.f16.f32 v8, v4
    a.vread      v4, a1, s11
    v.cmp.lt     p2, v6, v1
    p.and        p3, p1, p2
    vf.mul       v6, v8, v5
    vf.cvt.f16.f32 v5, v7
    s.addi       s8, s7, #2
    s.addi       s9, s20, #128                   // row 2
    v.splat      v7, s8
    vf.mul       v8, v5, v4
    s.movz       s8, #2
    vf.add       v4, v6, v8
    s.addi       s11, s14, #256                  // row 2
    vf.mul       v5, v4, v0
    @p4 v.st.w       [s14, #0], v5
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    v.ld.w       v3, [s13, #0]
    a.vread      v4, a0, s12
    s.addi       s12, s7, #2
    s.addi       s13, s3, #3264
    v.splat      v5, s12
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v6, [s5, #0]
    vf.cvt.f16.f32 v8, v3
    a.vread      v3, a1, s2
    v.cmp.lt     p2, v7, v1
    p.and        p3, p1, p2
    vf.mul       v7, v8, v4
    vf.cvt.f16.f32 v4, v6
    s.addi       s2, s7, #3
    s.movz       s5, #3
    v.splat      v6, s2
    vf.mul       v8, v4, v3
    s.addi       s2, s20, #192                   // row 3
    s.movz       s12, #3
    vf.add       v3, v7, v8
    vf.mul       v4, v3, v0
    @p4 v.st.w       [s15, #0], v4
    v.cmp.lt     p2, v5, v1
    p.and        p4, p1, p2
    s.addi       s15, s7, #3
    v.splat      v3, s15
    s.addi       s15, s14, #384                  // row 3
    v.ld.w       v4, [s4, #0]
    a.vread      v5, a0, s6
    s.addi       s4, s3, #3328
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s9, #0]
    vf.cvt.f16.f32 v8, v4
    a.vread      v4, a1, s8
    v.cmp.lt     p2, v6, v1
    p.and        p3, p1, p2
    vf.mul       v6, v8, v5
    vf.cvt.f16.f32 v5, v7
    s.addi       s6, s7, #4
    s.movz       s8, #4
    v.splat      v7, s6
    vf.mul       v8, v5, v4
    s.addi       s6, s20, #256                   // row 4
    s.movz       s9, #4
    vf.add       v4, v6, v8
    vf.mul       v5, v4, v0
    @p4 v.st.w       [s11, #0], v5
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    s.addi       s11, s7, #4
    v.splat      v3, s11
    s.addi       s11, s14, #512                  // row 4
    v.ld.w       v4, [s13, #0]
    a.vread      v5, a0, s5
    s.addi       s5, s3, #3392
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v6, [s2, #0]
    vf.cvt.f16.f32 v8, v4
    a.vread      v4, a1, s12
    v.cmp.lt     p2, v7, v1
    p.and        p3, p1, p2
    vf.mul       v7, v8, v5
    vf.cvt.f16.f32 v5, v6
    s.addi       s2, s7, #5
    s.movz       s12, #5
    v.splat      v6, s2
    vf.mul       v8, v5, v4
    s.addi       s2, s20, #320                   // row 5
    s.movz       s13, #5
    vf.add       v4, v7, v8
    vf.mul       v5, v4, v0
    @p4 v.st.w       [s15, #0], v5
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    s.addi       s15, s7, #5
    v.splat      v3, s15
    s.addi       s15, s14, #640                  // row 5
    v.ld.w       v4, [s4, #0]
    a.vread      v5, a0, s8
    s.addi       s4, s3, #3456
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s6, #0]
    vf.cvt.f16.f32 v8, v4
    a.vread      v4, a1, s9
    v.cmp.lt     p2, v6, v1
    p.and        p3, p1, p2
    vf.mul       v6, v8, v5
    vf.cvt.f16.f32 v5, v7
    s.addi       s6, s7, #6
    s.movz       s8, #6
    v.splat      v7, s6
    vf.mul       v8, v5, v4
    s.addi       s6, s20, #384                   // row 6
    s.movz       s9, #6
    vf.add       v4, v6, v8
    vf.mul       v5, v4, v0
    @p4 v.st.w       [s11, #0], v5
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    s.addi       s11, s7, #6
    v.splat      v3, s11
    s.addi       s11, s14, #768                  // row 6
    v.ld.w       v4, [s5, #0]
    a.vread      v5, a0, s12
    s.addi       s5, s3, #3520
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v6, [s2, #0]
    vf.cvt.f16.f32 v8, v4
    a.vread      v4, a1, s13
    v.cmp.lt     p2, v7, v1
    p.and        p3, p1, p2
    vf.mul       v7, v8, v5
    vf.cvt.f16.f32 v5, v6
    s.addi       s2, s7, #7
    s.movz       s12, #7
    v.splat      v6, s2
    vf.mul       v8, v5, v4
    s.addi       s2, s20, #448                   // row 7
    s.movz       s13, #7
    vf.add       v4, v7, v8
    vf.mul       v5, v4, v0
    @p4 v.st.w       [s15, #0], v5
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    s.addi       s15, s7, #7
    v.splat      v3, s15
    s.addi       s15, s14, #896                  // row 7
    v.ld.w       v4, [s4, #0]
    a.vread      v5, a0, s8
    s.addi       s4, s3, #3584
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s6, #0]
    vf.cvt.f16.f32 v8, v4
    a.vread      v4, a1, s9
    v.cmp.lt     p2, v6, v1
    p.and        p3, p1, p2
    vf.mul       v6, v8, v5
    vf.cvt.f16.f32 v5, v7
    s.addi       s6, s7, #8
    s.movz       s8, #8
    v.splat      v7, s6
    vf.mul       v8, v5, v4
    s.addi       s6, s20, #512                   // row 8
    s.movz       s9, #8
    vf.add       v4, v6, v8
    vf.mul       v5, v4, v0
    @p4 v.st.w       [s11, #0], v5
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    s.addi       s11, s7, #8
    v.splat      v3, s11
    s.addi       s11, s14, #1024                 // row 8
    v.ld.w       v4, [s5, #0]
    a.vread      v5, a0, s12
    s.addi       s5, s3, #3648
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v6, [s2, #0]
    vf.cvt.f16.f32 v8, v4
    a.vread      v4, a1, s13
    v.cmp.lt     p2, v7, v1
    p.and        p3, p1, p2
    vf.mul       v7, v8, v5
    vf.cvt.f16.f32 v5, v6
    s.addi       s2, s7, #9
    s.movz       s12, #9
    v.splat      v6, s2
    vf.mul       v8, v5, v4
    s.addi       s2, s20, #576                   // row 9
    s.movz       s13, #9
    vf.add       v4, v7, v8
    vf.mul       v5, v4, v0
    @p4 v.st.w       [s15, #0], v5
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    s.addi       s15, s7, #9
    v.splat      v3, s15
    s.addi       s15, s14, #1152                 // row 9
    v.ld.w       v4, [s4, #0]
    a.vread      v5, a0, s8
    s.addi       s4, s3, #3712
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s6, #0]
    vf.cvt.f16.f32 v8, v4
    a.vread      v4, a1, s9
    v.cmp.lt     p2, v6, v1
    p.and        p3, p1, p2
    vf.mul       v6, v8, v5
    vf.cvt.f16.f32 v5, v7
    s.addi       s6, s7, #10
    s.movz       s8, #10
    v.splat      v7, s6
    vf.mul       v8, v5, v4
    s.addi       s6, s20, #640                   // row 10
    s.movz       s9, #10
    vf.add       v4, v6, v8
    vf.mul       v5, v4, v0
    @p4 v.st.w       [s11, #0], v5
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    s.addi       s11, s7, #10
    v.splat      v3, s11
    s.addi       s11, s14, #1280                 // row 10
    v.ld.w       v4, [s5, #0]
    a.vread      v5, a0, s12
    s.addi       s5, s3, #3776
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v6, [s2, #0]
    vf.cvt.f16.f32 v8, v4
    a.vread      v4, a1, s13
    v.cmp.lt     p2, v7, v1
    p.and        p3, p1, p2
    vf.mul       v7, v8, v5
    vf.cvt.f16.f32 v5, v6
    s.addi       s2, s7, #11
    s.movz       s12, #11
    v.splat      v6, s2
    vf.mul       v8, v5, v4
    s.addi       s2, s20, #704                   // row 11
    s.movz       s13, #11
    vf.add       v4, v7, v8
    vf.mul       v5, v4, v0
    @p4 v.st.w       [s15, #0], v5
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    s.addi       s15, s7, #11
    v.splat      v3, s15
    s.addi       s15, s14, #1408                 // row 11
    v.ld.w       v4, [s4, #0]
    a.vread      v5, a0, s8
    s.addi       s4, s3, #3840
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s6, #0]
    vf.cvt.f16.f32 v8, v4
    a.vread      v4, a1, s9
    v.cmp.lt     p2, v6, v1
    p.and        p3, p1, p2
    vf.mul       v6, v8, v5
    vf.cvt.f16.f32 v5, v7
    s.addi       s6, s7, #12
    s.movz       s8, #12
    v.splat      v7, s6
    vf.mul       v8, v5, v4
    s.addi       s6, s20, #768                   // row 12
    s.movz       s9, #12
    vf.add       v4, v6, v8
    vf.mul       v5, v4, v0
    @p4 v.st.w       [s11, #0], v5
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    s.addi       s11, s7, #12
    v.splat      v3, s11
    s.addi       s11, s14, #1536                 // row 12
    v.ld.w       v4, [s5, #0]
    a.vread      v5, a0, s12
    s.addi       s5, s3, #3904
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v6, [s2, #0]
    vf.cvt.f16.f32 v8, v4
    a.vread      v4, a1, s13
    v.cmp.lt     p2, v7, v1
    p.and        p3, p1, p2
    vf.mul       v7, v8, v5
    vf.cvt.f16.f32 v5, v6
    s.addi       s2, s7, #13
    s.movz       s12, #13
    v.splat      v6, s2
    vf.mul       v8, v5, v4
    s.addi       s2, s20, #832                   // row 13
    s.movz       s13, #13
    vf.add       v4, v7, v8
    vf.mul       v5, v4, v0
    @p4 v.st.w       [s15, #0], v5
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    s.addi       s15, s7, #13
    v.splat      v3, s15
    s.addi       s15, s14, #1664                 // row 13
    v.ld.w       v4, [s4, #0]
    a.vread      v5, a0, s8
    s.addi       s4, s3, #3968
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s6, #0]
    vf.cvt.f16.f32 v8, v4
    a.vread      v4, a1, s9
    v.cmp.lt     p2, v6, v1
    p.and        p3, p1, p2
    vf.mul       v6, v8, v5
    vf.cvt.f16.f32 v5, v7
    s.addi       s6, s7, #14
    s.movz       s8, #14
    v.splat      v7, s6
    vf.mul       v8, v5, v4
    s.addi       s6, s20, #896                   // row 14
    s.movz       s9, #14
    vf.add       v4, v6, v8
    vf.mul       v5, v4, v0
    @p4 v.st.w       [s11, #0], v5
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    s.addi       s11, s7, #14
    v.splat      v3, s11
    s.addi       s11, s14, #1792                 // row 14
    v.ld.w       v4, [s5, #0]
    a.vread      v5, a0, s12
    s.addi       s5, s3, #4032
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v6, [s2, #0]
    vf.cvt.f16.f32 v8, v4
    a.vread      v4, a1, s13
    v.cmp.lt     p2, v7, v1
    p.and        p3, p1, p2
    vf.mul       v7, v8, v5
    vf.cvt.f16.f32 v5, v6
    s.addi       s2, s7, #15
    s.movz       s12, #15
    v.splat      v6, s2
    vf.mul       v8, v5, v4
    s.addi       s2, s20, #960                   // row 15
    s.movz       s13, #15
    vf.add       v4, v7, v8
    vf.mul       v5, v4, v0
    s.addi       s17, s7, #15
    s.addi       s18, s14, #1920                 // row 15
    v.splat      v4, s17
    @p4 v.st.w       [s15, #0], v5
    v.cmp.lt     p2, v3, v1
    p.and        p4, p1, p2
    s.addi       s14, s3, #14336
    v.ld.w       v3, [s4, #0]
    a.vread      v5, a0, s8
    v.splat      v7, s1
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v8, [s6, #0]
    vf.cvt.f16.f32 v9, v3
    a.vread      v3, a1, s9
    v.cmp.lt     p2, v6, v1
    p.and        p3, p1, p2
    vf.mul       v6, v9, v5
    vf.cvt.f16.f32 v5, v8
    s.addi       s1, s3, #0
    s.addi       s4, s3, #1024
    s.muli       s6, s10, #64                    // a runtime tile origin, x64
    vf.mul       v8, v5, v3
    s.movz       s8, #0
    s.movz       s9, #64
    v.iota       v3                              // arange(0, VLEN)
    vf.add       v5, v6, v8
    s.add        s10, s8, s6                     // the tile origin
    v.splat      v6, s9
    v.splat      v8, s10
    vf.mul       v9, v5, v0
    v.mul        v5, v3, v6
    s.addi       s6, s3, #64
    v.add        v3, v5, v8
    @p4 v.st.w       [s11, #0], v9
    v.cmp.lt     p2, v4, v1
    p.and        p4, p1, p2
    s.addi       s8, s3, #1088
    s.addi       s9, s14, #64
    v.ld.w       v4, [s5, #0]
    a.vread      v5, a0, s12
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v6, [s2, #0]
    vf.cvt.f16.f32 v8, v4
    a.vread      v4, a1, s13
    vf.mul       v9, v8, v5
    vf.cvt.f16.f32 v5, v6
    s.addi       s2, s3, #128
    s.addi       s5, s3, #1152
    s.addi       s10, s14, #128
    vf.mul       v6, v5, v4
    vf.add       v4, v9, v6
    s.addi       s11, s14, #192
    vf.mul       v5, v4, v0
    s.addi       s12, s3, #192
    s.addi       s13, s3, #1216
    @p4 v.st.w       [s18, #0], v5
    s.addi       s15, s14, #256
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s3, #256
    s.addi       s17, s3, #1280
    v.ld.w       v4, [s4, #0]
    v.add        v5, v0, v3
    s.addi       s4, s3, #320
    v.mul        v0, v4, v2
    v.add        v4, v5, v0
    v.add        v0, v7, v4
    v.st.w       [s14, #0], v0
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s3, #1344
    v.ld.w       v4, [s8, #0]
    v.add        v5, v0, v3
    s.addi       s8, s14, #320
    v.mul        v0, v4, v2
    v.add        v4, v5, v0
    v.add        v0, v7, v4
    v.st.w       [s9, #0], v0
    s.addi       s9, s3, #384
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s3, #1408
    v.ld.w       v4, [s5, #0]
    v.add        v5, v0, v3
    s.addi       s5, s14, #384
    v.mul        v0, v4, v2
    v.add        v4, v5, v0
    v.add        v0, v7, v4
    v.st.w       [s10, #0], v0
    s.addi       s10, s3, #448
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s3, #1472
    v.ld.w       v4, [s13, #0]
    v.add        v5, v0, v3
    s.addi       s13, s14, #448
    v.mul        v0, v4, v2
    v.add        v4, v5, v0
    v.add        v0, v7, v4
    v.st.w       [s11, #0], v0
    s.addi       s11, s3, #512
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s3, #1536
    v.ld.w       v4, [s17, #0]
    v.add        v5, v0, v3
    s.addi       s17, s14, #512
    v.mul        v0, v4, v2
    v.add        v4, v5, v0
    v.add        v0, v7, v4
    v.st.w       [s15, #0], v0
    s.addi       s15, s3, #576
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s3, #1600
    v.ld.w       v4, [s6, #0]
    v.add        v5, v0, v3
    s.addi       s6, s14, #576
    v.mul        v0, v4, v2
    v.add        v4, v5, v0
    v.add        v0, v7, v4
    v.st.w       [s8, #0], v0
    s.addi       s8, s3, #640
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s3, #1664
    v.ld.w       v4, [s2, #0]
    v.add        v5, v0, v3
    s.addi       s2, s14, #640
    v.mul        v0, v4, v2
    v.add        v4, v5, v0
    v.add        v0, v7, v4
    v.st.w       [s5, #0], v0
    s.addi       s5, s3, #704
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s3, #1728
    v.ld.w       v4, [s12, #0]
    v.add        v5, v0, v3
    s.addi       s12, s14, #704
    v.mul        v0, v4, v2
    v.add        v4, v5, v0
    v.add        v0, v7, v4
    v.st.w       [s13, #0], v0
    s.addi       s13, s3, #768
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s3, #1792
    v.ld.w       v4, [s1, #0]
    v.add        v5, v0, v3
    s.addi       s1, s14, #768
    v.mul        v0, v4, v2
    v.add        v4, v5, v0
    v.add        v0, v7, v4
    v.st.w       [s17, #0], v0
    s.addi       s17, s3, #832
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s3, #1856
    v.ld.w       v4, [s4, #0]
    v.add        v5, v0, v3
    s.addi       s4, s14, #832
    v.mul        v0, v4, v2
    v.add        v4, v5, v0
    v.add        v0, v7, v4
    v.st.w       [s6, #0], v0
    s.addi       s6, s3, #896
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s3, #1920
    v.ld.w       v4, [s9, #0]
    v.add        v5, v0, v3
    s.addi       s9, s14, #896
    s.addi       s18, s14, #960
    v.mul        v0, v4, v2
    v.add        v4, v5, v0
    v.add        v0, v7, v4
    v.st.w       [s2, #0], v0
    s.addi       s2, s3, #960
    v.ld.w       v0, [s5, #0]
    s.addi       s5, s3, #1984
    v.ld.w       v4, [s10, #0]
    v.add        v5, v0, v3
    s.movz       s10, #0
    v.mul        v0, v4, v2
    v.add        v4, v5, v0
    v.splat      v0, s7
    v.add        v5, v7, v4
    v.cmp.lt     p2, v0, v1
    v.st.w       [s12, #0], v5
    s.addi       s12, s3, #14336
    p.and        p3, p1, p2
    v.ld.w       v0, [s13, #0]
    s.movz       s13, #1
    v.ld.w       v4, [s11, #0]
    v.add        v5, v0, v3
    s.addi       s11, s3, #14400
    v.mul        v0, v4, v2
    v.add        v4, v5, v0
    v.add        v0, v7, v4
    v.st.w       [s1, #0], v0
    s.addi       s1, s7, #1
    v.splat      v0, s1
    s.movz       s1, #2
    v.cmp.lt     p2, v0, v1
    p.and        p4, p1, p2
    v.ld.w       v0, [s17, #0]
    s.addi       s14, s3, #14464
    v.ld.w       v4, [s15, #0]
    v.add        v5, v0, v3
    s.addi       s15, s7, #2
    v.splat      v0, s15
    v.mul        v6, v4, v2
    v.add        v4, v5, v6
    v.add        v5, v7, v4
    v.st.w       [s4, #0], v5
    s.movz       s4, #3
    s.addi       s15, s3, #14528
    v.ld.w       v4, [s6, #0]
    v.ld.w       v5, [s8, #0]
    v.add        v6, v4, v3
    s.addi       s6, s7, #3
    v.splat      v4, s6
    v.mul        v8, v5, v2
    v.add        v5, v6, v8
    v.add        v6, v7, v5
    s.movz       s6, #4
    v.st.w       [s9, #0], v6
    s.addi       s8, s3, #14592
    v.ld.w       v5, [s2, #0]
    s.addi       s2, s7, #4
    v.ld.w       v6, [s5, #0]
    v.add        v8, v5, v3
    v.splat      v3, s2
    v.mul        v5, v6, v2
    v.add        v2, v8, v5
    s.movz       s2, #5
    v.add        v5, v7, v2
    v.st.w       [s18, #0], v5
    fence.acq_rel.device
    a.vread      v2, a2, s10
    s.addi       s5, s3, #14656
    s.addi       s9, s7, #5
    v.splat      v5, s9
    v.ld.w       v6, [s12, #0]
    s.movz       s9, #6
    @p3 v.st.scatter.w [s16, v6], v2
    a.vread      v2, a2, s13
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    s.addi       s10, s3, #14720
    s.addi       s12, s7, #6
    v.splat      v0, s12
    v.ld.w       v6, [s11, #0]
    s.movz       s11, #7
    @p4 v.st.scatter.w [s16, v6], v2
    a.vread      v2, a2, s1
    v.cmp.lt     p2, v4, v1
    p.and        p4, p1, p2
    s.addi       s1, s3, #14784
    s.addi       s12, s7, #7
    v.splat      v4, s12
    v.ld.w       v6, [s14, #0]
    s.movz       s12, #8
    @p3 v.st.scatter.w [s16, v6], v2
    a.vread      v2, a2, s4
    v.cmp.lt     p2, v3, v1
    p.and        p3, p1, p2
    s.addi       s4, s3, #14848
    s.addi       s13, s7, #8
    v.splat      v3, s13
    v.ld.w       v6, [s15, #0]
    s.movz       s13, #9
    @p4 v.st.scatter.w [s16, v6], v2
    a.vread      v2, a2, s6
    v.cmp.lt     p2, v5, v1
    p.and        p4, p1, p2
    s.addi       s6, s3, #14912
    s.addi       s14, s7, #9
    v.splat      v5, s14
    v.ld.w       v6, [s8, #0]
    s.movz       s8, #10
    @p3 v.st.scatter.w [s16, v6], v2
    a.vread      v2, a2, s2
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    s.addi       s2, s3, #14976
    s.addi       s14, s7, #10
    v.splat      v0, s14
    v.ld.w       v6, [s5, #0]
    s.movz       s5, #11
    @p4 v.st.scatter.w [s16, v6], v2
    a.vread      v2, a2, s9
    v.cmp.lt     p2, v4, v1
    p.and        p4, p1, p2
    s.addi       s9, s3, #15040
    s.addi       s14, s7, #11
    v.splat      v4, s14
    v.ld.w       v6, [s10, #0]
    s.movz       s10, #12
    @p3 v.st.scatter.w [s16, v6], v2
    a.vread      v2, a2, s11
    v.cmp.lt     p2, v3, v1
    p.and        p3, p1, p2
    s.addi       s11, s3, #15104
    s.addi       s14, s7, #12
    v.splat      v3, s14
    v.ld.w       v6, [s1, #0]
    s.movz       s1, #13
    @p4 v.st.scatter.w [s16, v6], v2
    a.vread      v2, a2, s12
    v.cmp.lt     p2, v5, v1
    p.and        p4, p1, p2
    s.addi       s12, s3, #15168
    s.addi       s14, s7, #13
    v.splat      v5, s14
    v.ld.w       v6, [s4, #0]
    s.movz       s4, #14
    @p3 v.st.scatter.w [s16, v6], v2
    a.vread      v2, a2, s13
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    s.addi       s13, s3, #15232
    s.addi       s14, s7, #14
    v.splat      v0, s14
    v.ld.w       v6, [s6, #0]
    s.movz       s6, #15
    @p4 v.st.scatter.w [s16, v6], v2
    a.vread      v2, a2, s8
    v.cmp.lt     p2, v4, v1
    p.and        p4, p1, p2
    s.addi       s8, s3, #15296
    s.addi       s3, s7, #15
    v.splat      v4, s3
    v.ld.w       v6, [s2, #0]
    @p3 v.st.scatter.w [s16, v6], v2
    a.vread      v2, a2, s5
    v.cmp.lt     p2, v3, v1
    p.and        p3, p1, p2
    v.ld.w       v3, [s9, #0]
    @p4 v.st.scatter.w [s16, v3], v2
    a.vread      v2, a2, s10
    v.cmp.lt     p2, v5, v1
    p.and        p4, p1, p2
    v.ld.w       v3, [s11, #0]
    @p3 v.st.scatter.w [s16, v3], v2
    a.vread      v2, a2, s1
    v.cmp.lt     p2, v0, v1
    p.and        p3, p1, p2
    v.ld.w       v0, [s12, #0]
    @p4 v.st.scatter.w [s16, v0], v2
    a.vread      v0, a2, s4
    v.cmp.lt     p2, v4, v1
    p.and        p4, p1, p2
    v.ld.w       v1, [s13, #0]
    @p3 v.st.scatter.w [s16, v1], v0
    a.vread      v0, a2, s6
    v.ld.w       v1, [s8, #0]
    @p4 v.st.scatter.w [s16, v1], v0
__rctx_next:
    exit
