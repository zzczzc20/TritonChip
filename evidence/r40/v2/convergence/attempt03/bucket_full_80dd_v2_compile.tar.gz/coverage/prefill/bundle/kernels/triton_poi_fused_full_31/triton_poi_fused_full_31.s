    s.rdspecial  s1, arg_base
    v.movi       v0, #0
    s.ld.d       s2, [s1, #0]                    // out_ptr0: device_ptr64 at arg_base+0
    v.movi       v1, #1
    v.iota       v2                              // arange(0, VLEN)
    v.movi       v3, #512
    v.shl        v4, v0, v1
    v.movi       v0, #0
    v.cmpi.lt    p1, v2, #1
    s.addi       s1, s2, #4
    @p1 v.st.scatter.w [s2, v4], v3
    @p1 v.st.scatter.w [s1, v4], v0
    exit
    exit
