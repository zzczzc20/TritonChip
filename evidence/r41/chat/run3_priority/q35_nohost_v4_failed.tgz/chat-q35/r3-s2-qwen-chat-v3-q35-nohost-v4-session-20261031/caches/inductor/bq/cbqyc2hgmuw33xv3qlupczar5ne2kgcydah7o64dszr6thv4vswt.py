
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 2048}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 23768}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_0(in_ptr0, in_ptr1, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1440
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x2 = xindex // 480
    x0 = (xindex % 32)
    x1 = ((xindex // 32) % 15)
    x3 = xindex // 32
    x4 = xindex
    tmp19 = tl.load(in_ptr0 + (15 + x1), xmask, eviction_policy='evict_last')
    tmp21 = tl.load(in_ptr1 + (x0), xmask, eviction_policy='evict_last')
    tmp25 = tl.load(in_ptr0 + (15 + x3), xmask, eviction_policy='evict_last')
    tmp0 = (x2).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int32)
    tmp2 = tmp0 == tmp1
    tmp3 = (x0).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1], 1, tl.int64)
    tmp6 = tmp4 >= tmp5
    tmp7 = ((((-1) + x0) % 3)).to(tl.int64)
    tmp8 = (tmp7).to(tl.int64)
    tmp9 = tl.full([1], 0, tl.int64)
    tmp10 = tmp8 == tmp9
    tmp11 = tmp6 & tmp10
    tmp12 = tl.load(in_ptr0 + (30 + x1), tmp11 & xmask, eviction_policy='evict_last', other=0.0)
    tmp13 = tmp12.to(tl.float32)
    tmp14 = tl.load(in_ptr1 + (1 + 3*(triton_helpers.div_floor_integer((-1) + x0,  3))), tmp11 & xmask, eviction_policy='evict_last', other=0.0)
    tmp15 = tmp13 * tmp14
    tmp16 = tl_math.sin(tmp15)
    tmp17 = tl.full(tmp16.shape, 0.0, tmp16.dtype)
    tmp18 = tl.where(tmp11, tmp16, tmp17)
    tmp20 = tmp19.to(tl.float32)
    tmp22 = tmp20 * tmp21
    tmp23 = tl_math.sin(tmp22)
    tmp24 = tl.where(tmp11, tmp18, tmp23)
    tmp26 = tmp25.to(tl.float32)
    tmp27 = tmp26 * tmp21
    tmp28 = tl_math.sin(tmp27)
    tmp29 = tl.where(tmp2, tmp24, tmp28)
    tmp30 = tl_math.cos(tmp15)
    tmp31 = tl.full(tmp30.shape, 0.0, tmp30.dtype)
    tmp32 = tl.where(tmp11, tmp30, tmp31)
    tmp33 = tl_math.cos(tmp22)
    tmp34 = tl.where(tmp11, tmp32, tmp33)
    tmp35 = tl_math.cos(tmp27)
    tmp36 = tl.where(tmp2, tmp34, tmp35)
    tl.store(out_ptr0 + (x4), tmp29, xmask)
    tl.store(out_ptr1 + (x4), tmp36, xmask)
