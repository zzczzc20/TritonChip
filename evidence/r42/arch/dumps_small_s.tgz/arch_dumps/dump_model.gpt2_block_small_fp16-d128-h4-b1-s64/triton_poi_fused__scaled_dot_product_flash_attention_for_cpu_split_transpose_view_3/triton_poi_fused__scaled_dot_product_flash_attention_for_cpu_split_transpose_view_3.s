    s.rdspecial  s1, role_id
    s.rdspecial  s2, npid.x
__rctx_program:
    s.rdspecial  s3, arg_base
    s.rdspecial  s4, arg_base
    s.ld.d       s5, [s3, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.rdspecial  s6, pid.y
    s.shli       s7, s1, #4                      // x16 as a shift
    s.shli       s8, s6, #4                      // x16 as a shift
    s.rdspecial  s6, role_id
    s.movz       s9, #2560
    v.splat      v0, s8
    v.iota       v1                              // arange(0, VLEN)
    s.mul        s10, s6, s9
    s.muli       s6, s7, #768
    v.add        v2, v0, v1
    s.ld.d       s9, [s4, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.movi       v0, #0
    v.splat      v1, s7
    s.muli       s4, s8, #2
    s.addi       s11, s5, #256
    v.cmp.ge     p1, v2, v0
    v.cmpi.lt    p2, v2, #128
    v.cmp.ge     p3, v1, v0
    v.cmpi.lt    p4, v1, #64
    s.add        s5, s11, s6
    p.and        p5, p1, p2
    s.add        s6, s9, s10                     // this context's own scratch
    p.and        p1, p3, p4
    s.addi       s9, s6, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s10, #64
    s.movz       s12, #128
    s.movz       s13, #768
    s.movz       s14, #2
    .li       s15, #68719476752
    s.add        s16, s5, s4
    .li       s4, #8589934592
    p.and        p2, p5, p1
    s.ld.d       s5, [s3, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.movi       v0, #0
    s.st.d       [s9, #0], s11
    s.addi       s3, s7, #1
    v.splat      v1, s3
    s.movz       s3, #1
    s.muli       s11, s3, #768
    v.cmp.ge     p1, v1, v0
    v.cmpi.lt    p3, v1, #64
    p.and        p4, p1, p3
    s.st.d       [s9, #8], s10
    s.addi       s3, s6, #256
    p.and        p1, p5, p4
    s.add        s10, s16, s11
    v.movi       v0, #0
    s.st.d       [s9, #16], s12
    s.addi       s11, s7, #2
    v.splat      v1, s11
    s.addi       s11, s3, #64
    v.cmp.ge     p3, v1, v0
    s.st.d       [s9, #48], s13
    s.muli       s12, s14, #768
    s.st.d       [s9, #56], s14
    s.add        s13, s16, s12
    s.addi       s12, s3, #128
    s.st.d       [s9, #88], s15
    s.addi       s14, s3, #192
    s.st.d       [s9, #104], s4
    fence.release.device
    td.load      d0, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s4, s7, #3
    s.movz       s9, #3
    v.splat      v0, s4
    v.movi       v2, #0
    s.muli       s4, s9, #768
    s.addi       s9, s7, #4
    v.movi       v3, #0
    v.splat      v4, s9
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v5, [s16, #0]
    v.cmpi.lt    p2, v1, #64
    p.and        p4, p3, p2
    v.cmp.ge     p2, v0, v2
    p.and        p3, p5, p4
    s.add        s9, s16, s4
    s.movz       s4, #4
    v.st.w       [s3, #0], v5
    s.muli       s15, s4, #768
    v.movi       v1, #0
    s.add        s4, s16, s15
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v2, [s10, #0]
    v.cmpi.lt    p1, v0, #64
    p.and        p4, p2, p1
    v.cmp.ge     p1, v4, v3
    p.and        p2, p5, p4
    s.addi       s10, s7, #5
    v.splat      v0, s10
    s.movz       s10, #5
    v.st.w       [s11, #0], v2
    s.muli       s11, s10, #768
    s.addi       s10, s3, #256
    v.movi       v2, #0
    s.add        s15, s16, s11
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s13, #0]
    v.cmpi.lt    p3, v4, #64
    p.and        p4, p1, p3
    v.cmp.ge     p1, v0, v1
    p.and        p3, p5, p4
    s.addi       s11, s7, #6
    v.splat      v1, s11
    s.addi       s11, s3, #320
    v.st.w       [s12, #0], v3
    s.movz       s12, #6
    v.movi       v3, #0
    s.muli       s13, s12, #768
    s.add        s12, s16, s13
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s9, #0]
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    v.cmp.ge     p1, v1, v2
    p.and        p2, p5, p4
    s.addi       s9, s7, #7
    v.splat      v0, s9
    s.addi       s9, s3, #384
    v.st.w       [s14, #0], v4
    s.movz       s13, #7
    v.movi       v2, #0
    s.muli       s14, s13, #768
    s.add        s13, s16, s14
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s4, #0]
    v.cmpi.lt    p3, v1, #64
    p.and        p4, p1, p3
    v.cmp.ge     p1, v0, v3
    p.and        p3, p5, p4
    s.addi       s4, s7, #8
    v.splat      v1, s4
    s.addi       s4, s3, #448
    v.st.w       [s10, #0], v4
    s.movz       s10, #8
    v.movi       v3, #0
    s.muli       s14, s10, #768
    s.add        s10, s16, s14
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s15, #0]
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    v.cmp.ge     p1, v1, v2
    p.and        p2, p5, p4
    s.addi       s14, s7, #9
    v.splat      v0, s14
    s.addi       s14, s3, #512
    v.st.w       [s11, #0], v4
    s.movz       s11, #9
    v.movi       v2, #0
    s.muli       s15, s11, #768
    s.add        s11, s16, s15
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s12, #0]
    v.cmpi.lt    p3, v1, #64
    p.and        p4, p1, p3
    v.cmp.ge     p1, v0, v3
    p.and        p3, p5, p4
    s.addi       s12, s7, #10
    v.splat      v1, s12
    s.addi       s12, s3, #576
    v.st.w       [s9, #0], v4
    s.movz       s9, #10
    v.movi       v3, #0
    s.muli       s15, s9, #768
    s.add        s9, s16, s15
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s13, #0]
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    v.cmp.ge     p1, v1, v2
    p.and        p2, p5, p4
    s.addi       s13, s7, #11
    v.splat      v0, s13
    s.addi       s13, s3, #640
    v.st.w       [s4, #0], v4
    s.movz       s4, #11
    v.movi       v2, #0
    s.muli       s15, s4, #768
    s.add        s4, s16, s15
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s10, #0]
    v.cmpi.lt    p3, v1, #64
    p.and        p4, p1, p3
    v.cmp.ge     p1, v0, v3
    p.and        p3, p5, p4
    s.addi       s10, s7, #12
    v.splat      v1, s10
    s.addi       s10, s3, #704
    v.st.w       [s14, #0], v4
    s.movz       s14, #12
    v.movi       v3, #0
    s.muli       s15, s14, #768
    s.add        s14, s16, s15
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s11, #0]
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    v.cmp.ge     p1, v1, v2
    p.and        p2, p5, p4
    s.addi       s11, s7, #13
    v.splat      v0, s11
    s.addi       s11, s3, #768
    v.st.w       [s12, #0], v4
    s.movz       s12, #13
    v.movi       v2, #0
    s.muli       s15, s12, #768
    s.add        s12, s16, s15
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s9, #0]
    v.cmpi.lt    p3, v1, #64
    p.and        p4, p1, p3
    v.cmp.ge     p1, v0, v3
    p.and        p3, p5, p4
    s.addi       s9, s7, #14
    v.splat      v1, s9
    s.addi       s9, s3, #832
    v.st.w       [s13, #0], v4
    s.movz       s13, #14
    v.movi       v3, #0
    s.muli       s15, s13, #768
    s.add        s13, s16, s15
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s4, #0]
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    v.cmp.ge     p1, v1, v2
    p.and        p2, p5, p4
    s.addi       s4, s7, #15
    v.splat      v0, s4
    s.addi       s4, s3, #896
    s.addi       s15, s3, #960
    v.st.w       [s10, #0], v4
    s.movz       s3, #15
    s.muli       s10, s3, #768
    s.add        s3, s16, s10
    // tile epilogue: 16 rows through the vector unit, as f16 (ISA sec 9B)
    s.addi       s10, s6, #256
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s14, #0]
    v.cmpi.lt    p3, v1, #64
    p.and        p4, p1, p3
    v.cmp.ge     p1, v0, v3
    p.and        p3, p5, p4
    s.addi       s14, s6, #1280                  // 512 bytes of repack scratch
    v.st.w       [s11, #0], v2
    s.addi       s11, s6, #320
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s12, #0]
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    s.movz       s12, #1
    p.and        p1, p5, p4
    s.muli       s16, s12, #32
    s.add        s12, s14, s16
    v.st.w       [s9, #0], v1
    s.addi       s9, s6, #384
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s13, #0]
    s.movz       s13, #2
    s.muli       s16, s13, #32
    s.add        s13, s14, s16
    v.st.w       [s4, #0], v0
    s.addi       s4, s6, #448
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s3, #0]
    s.movz       s3, #3
    s.muli       s16, s3, #32
    s.add        s3, s14, s16
    v.st.w       [s15, #0], v0
    fence.acq_rel.device
    s.addi       s15, s6, #512
    v.ld.w       v0, [s10, #0]
    s.movz       s10, #4
    s.muli       s16, s10, #32
    s.add        s10, s14, s16
    v.st.h       [s14, #0], v0
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s6, #576
    v.st.h       [s12, #0], v0
    s.movz       s12, #5
    s.muli       s16, s12, #32
    s.add        s12, s14, s16
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s6, #640
    v.st.h       [s13, #0], v0
    s.movz       s13, #6
    s.muli       s16, s13, #32
    s.add        s13, s14, s16
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s6, #704
    v.st.h       [s3, #0], v0
    s.movz       s3, #7
    s.muli       s16, s3, #32
    s.add        s3, s14, s16
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s6, #768
    v.st.h       [s10, #0], v0
    s.movz       s10, #8
    s.muli       s16, s10, #32
    s.add        s10, s14, s16
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s6, #832
    v.st.h       [s12, #0], v0
    s.movz       s12, #9
    s.muli       s16, s12, #32
    s.add        s12, s14, s16
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s6, #896
    v.st.h       [s13, #0], v0
    s.movz       s13, #10
    s.muli       s16, s13, #32
    s.add        s13, s14, s16
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s6, #960
    v.st.h       [s3, #0], v0
    s.movz       s3, #11
    s.muli       s16, s3, #32
    s.add        s3, s14, s16
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s6, #1024
    v.st.h       [s10, #0], v0
    s.movz       s10, #12
    s.muli       s16, s10, #32
    s.add        s10, s14, s16
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s6, #1088
    // tl.trans: 16 columns, gathered %c336:scalar elements apart (ISA sec 9.1)
    v.iota       v1                              // arange(0, VLEN)
    v.st.h       [s12, #0], v0
    s.movz       s12, #13
    s.muli       s16, s12, #32
    s.add        s12, s14, s16
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s6, #1152
    v.st.h       [s13, #0], v0
    s.movz       s13, #14
    s.muli       s16, s13, #32
    s.add        s13, s14, s16
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s6, #1216
    v.st.h       [s3, #0], v0
    s.movz       s3, #0
    v.ld.w       v0, [s15, #0]
    s.muli       s15, s3, #32
    s.muli       s16, s3, #2
    s.add        s3, s14, s15
    s.add        s15, s3, s16
    s.movz       s3, #15
    s.muli       s16, s3, #32
    s.add        s3, s14, s16
    s.movz       s14, #16
    v.st.h       [s10, #0], v0
    v.splat      v0, s14
    s.addi       s10, s15, #2                    // column 1
    s.addi       s14, s15, #4                    // column 2
    v.mul        v2, v1, v0                      // one element per source row
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s15, #6                    // column 3
    v.st.h       [s12, #0], v0
    s.addi       s12, s15, #8                    // column 4
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s15, #10                    // column 5
    v.st.h       [s13, #0], v0
    s.addi       s13, s15, #12                   // column 6
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s15, #14                    // column 7
    v.st.h       [s3, #0], v0
    s.addi       s3, s15, #16                    // column 8
    fence.acq_rel.device
    v.ld.gather.h v0, [s15, v2]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.h v1, [s10, v2]                  // index is in elements (ISA sec 9.1)
    s.addi       s10, s15, #18                   // column 9
    v.ld.gather.h v3, [s14, v2]                  // index is in elements (ISA sec 9.1)
    s.addi       s14, s15, #20                   // column 10
    v.ld.gather.h v4, [s11, v2]                  // index is in elements (ISA sec 9.1)
    s.addi       s11, s15, #22                   // column 11
    v.ld.gather.h v5, [s12, v2]                  // index is in elements (ISA sec 9.1)
    s.addi       s12, s15, #24                   // column 12
    v.ld.gather.h v6, [s9, v2]                   // index is in elements (ISA sec 9.1)
    s.addi       s9, s15, #26                    // column 13
    v.ld.gather.h v7, [s13, v2]                  // index is in elements (ISA sec 9.1)
    s.addi       s13, s15, #28                   // column 14
    s.addi       s16, s15, #30                   // column 15
    v.ld.gather.h v8, [s4, v2]                   // index is in elements (ISA sec 9.1)
    s.addi       s4, s6, #1792                   // 512 bytes of repack scratch
    s.addi       s15, s6, #2304                  // TensorMap 1: a repacked tile
    v.ld.gather.h v9, [s3, v2]                   // index is in elements (ISA sec 9.1)
    s.addi       s3, s4, #32                     // row 1
    v.ld.gather.h v10, [s10, v2]                 // index is in elements (ISA sec 9.1)
    s.addi       s6, s4, #64                     // row 2
    v.ld.gather.h v11, [s14, v2]                 // index is in elements (ISA sec 9.1)
    s.addi       s10, s4, #96                    // row 3
    v.ld.gather.h v12, [s11, v2]                 // index is in elements (ISA sec 9.1)
    s.addi       s11, s4, #128                   // row 4
    v.ld.gather.h v13, [s12, v2]                 // index is in elements (ISA sec 9.1)
    s.addi       s12, s4, #160                   // row 5
    v.ld.gather.h v14, [s9, v2]                  // index is in elements (ISA sec 9.1)
    s.addi       s9, s4, #192                    // row 6
    v.ld.gather.h v15, [s13, v2]                 // index is in elements (ISA sec 9.1)
    s.addi       s13, s4, #224                   // row 7
    v.ld.gather.h v16, [s16, v2]                 // index is in elements (ISA sec 9.1)
    s.movz       s14, #0
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    v.st.h       [s4, #0], v0
    v.st.h       [s3, #0], v1
    s.muli       s3, s14, #32
    v.st.h       [s6, #0], v3
    s.muli       s6, s14, #2
    v.st.h       [s10, #0], v4
    s.add        s10, s4, s3
    .li       s16, #1054295293
    v.splat      v0, s16                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s16, s10, s6
    s.addi       s6, s4, #256                    // row 8
    v.st.h       [s11, #0], v5
    s.addi       s10, s4, #288                   // row 9
    v.st.h       [s12, #0], v6
    s.addi       s11, s4, #320                   // row 10
    v.st.h       [s9, #0], v7
    s.addi       s9, s4, #352                    // row 11
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.add        s12, s16, s3
    v.st.h       [s13, #0], v8
    s.addi       s3, s4, #384                    // row 12
    v.st.h       [s6, #0], v9
    s.addi       s6, s4, #416                    // row 13
    v.iota       v1                              // arange(0, VLEN)
    v.st.h       [s10, #0], v10
    s.addi       s10, s4, #448                   // row 14
    v.st.h       [s11, #0], v11
    s.addi       s11, s4, #480                   // row 15
    v.st.h       [s9, #0], v12
    s.movz       s9, #16
    v.st.h       [s3, #0], v13
    s.movz       s3, #32
    v.st.h       [s6, #0], v14
    s.movz       s6, #2
    v.st.h       [s10, #0], v15
    .li       s10, #68719476752
    v.st.h       [s11, #0], v16
    .li       s11, #8589934592
    s.st.d       [s15, #0], s4
    s.add        s4, s14, s7                     // the tile origin
    s.muli       s13, s7, #4                     // a runtime tile origin, x4
    v.splat      v2, s4
    s.movz       s4, #1
    s.muli       s7, s4, #32
    v.add        v3, v1, v2
    s.add        s4, s5, s13                     // the tile origin
    s.add        s5, s14, s8                     // the tile origin
    s.muli       s13, s8, #256                   // a runtime tile origin, x256
    s.st.d       [s15, #8], s9
    v.splat      v1, s5
    v.cmpi.lt    p1, v3, #64
    s.add        s8, s16, s7
    v.cmpi.lt    p2, v1, #128
    s.add        s7, s4, s13                     // the tile origin
    p.and        p3, p1, p2
    s.addi       s4, s5, #1
    v.splat      v1, s4
    s.addi       s4, s7, #256                    // row 1
    s.st.d       [s15, #16], s9
    v.cmpi.lt    p2, v1, #128
    p.and        p4, p1, p2
    s.st.d       [s15, #48], s3
    s.muli       s3, s6, #32
    s.st.d       [s15, #56], s6
    s.add        s6, s16, s3
    s.st.d       [s15, #88], s10
    s.st.d       [s15, #104], s11
    fence.release.device
    td.load      d1, [s15]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s3, b0, #0, #1                  // 0 arrival(s), 1 operation(s)
    s.addi       s9, s5, #2
    s.addi       s10, s7, #512                   // row 2
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s17, s14                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s18, s14                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d1, s17, s3
    mb.wait      s3
    s.movz       s11, #3
    v.splat      v1, s9
    v.ld.h       v2, [s12, #0]
    s.muli       s9, s11, #32
    v.cmpi.lt    p2, v1, #128
    p.and        p5, p1, p2
    s.movz       s11, #4
    s.addi       s12, s5, #3
    s.add        s13, s16, s9
    v.splat      v1, s12
    s.addi       s9, s7, #768                    // row 3
    vf.cvt.f16.f32 v3, v2
    s.muli       s12, s11, #32
    vf.mul       v2, v3, v0
    s.add        s11, s16, s12
    s.addi       s12, s5, #4
    s.addi       s14, s7, #1024                  // row 4
    v.splat      v3, s12
    @p3 v.st.w       [s7, #0], v2
    v.cmpi.lt    p2, v1, #128
    p.and        p3, p1, p2
    s.movz       s12, #5
    s.muli       s15, s12, #32
    s.add        s12, s16, s15
    v.ld.h       v1, [s8, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s8, s5, #5
    s.addi       s15, s7, #1280                  // row 5
    v.splat      v2, s8
    @p4 v.st.w       [s4, #0], v1
    v.cmpi.lt    p2, v3, #128
    p.and        p4, p1, p2
    s.movz       s4, #6
    s.muli       s8, s4, #32
    s.add        s4, s16, s8
    v.ld.h       v1, [s6, #0]
    vf.cvt.f16.f32 v3, v1
    vf.mul       v1, v3, v0
    s.addi       s6, s5, #6
    s.addi       s8, s7, #1536                   // row 6
    v.splat      v3, s6
    @p5 v.st.w       [s10, #0], v1
    v.cmpi.lt    p2, v2, #128
    p.and        p5, p1, p2
    s.movz       s6, #7
    s.muli       s10, s6, #32
    s.add        s6, s16, s10
    v.ld.h       v1, [s13, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s10, s5, #7
    s.addi       s13, s7, #1792                  // row 7
    v.splat      v2, s10
    @p3 v.st.w       [s9, #0], v1
    v.cmpi.lt    p2, v3, #128
    p.and        p3, p1, p2
    s.movz       s9, #8
    s.muli       s10, s9, #32
    s.add        s9, s16, s10
    v.ld.h       v1, [s11, #0]
    vf.cvt.f16.f32 v3, v1
    vf.mul       v1, v3, v0
    s.addi       s10, s5, #8
    s.addi       s11, s7, #2048                  // row 8
    v.splat      v3, s10
    @p4 v.st.w       [s14, #0], v1
    v.cmpi.lt    p2, v2, #128
    p.and        p4, p1, p2
    s.movz       s10, #9
    s.muli       s14, s10, #32
    s.add        s10, s16, s14
    v.ld.h       v1, [s12, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s12, s5, #9
    s.addi       s14, s7, #2304                  // row 9
    v.splat      v2, s12
    @p5 v.st.w       [s15, #0], v1
    v.cmpi.lt    p2, v3, #128
    p.and        p5, p1, p2
    s.movz       s12, #10
    s.muli       s15, s12, #32
    s.add        s12, s16, s15
    v.ld.h       v1, [s4, #0]
    vf.cvt.f16.f32 v3, v1
    vf.mul       v1, v3, v0
    s.addi       s4, s5, #10
    s.addi       s15, s7, #2560                  // row 10
    v.splat      v3, s4
    @p3 v.st.w       [s8, #0], v1
    v.cmpi.lt    p2, v2, #128
    p.and        p3, p1, p2
    s.movz       s4, #11
    s.muli       s8, s4, #32
    s.add        s4, s16, s8
    v.ld.h       v1, [s6, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s6, s5, #11
    s.addi       s8, s7, #2816                   // row 11
    v.splat      v2, s6
    @p4 v.st.w       [s13, #0], v1
    v.cmpi.lt    p2, v3, #128
    p.and        p4, p1, p2
    s.movz       s6, #12
    s.muli       s13, s6, #32
    s.add        s6, s16, s13
    v.ld.h       v1, [s9, #0]
    vf.cvt.f16.f32 v3, v1
    vf.mul       v1, v3, v0
    s.addi       s9, s5, #12
    s.addi       s13, s7, #3072                  // row 12
    v.splat      v3, s9
    @p5 v.st.w       [s11, #0], v1
    v.cmpi.lt    p2, v2, #128
    p.and        p5, p1, p2
    s.movz       s9, #13
    s.muli       s11, s9, #32
    s.add        s9, s16, s11
    v.ld.h       v1, [s10, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s10, s5, #13
    s.addi       s11, s7, #3328                  // row 13
    v.splat      v2, s10
    @p3 v.st.w       [s14, #0], v1
    v.cmpi.lt    p2, v3, #128
    p.and        p3, p1, p2
    s.movz       s10, #14
    s.muli       s14, s10, #32
    s.add        s10, s16, s14
    v.ld.h       v1, [s12, #0]
    vf.cvt.f16.f32 v3, v1
    vf.mul       v1, v3, v0
    s.addi       s12, s5, #14
    s.addi       s14, s7, #3584                  // row 14
    v.splat      v3, s12
    @p4 v.st.w       [s15, #0], v1
    v.cmpi.lt    p2, v2, #128
    p.and        p4, p1, p2
    s.movz       s12, #15
    s.muli       s15, s12, #32
    s.add        s12, s16, s15
    v.ld.h       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s4, s5, #15
    s.addi       s5, s7, #3840                   // row 15
    v.splat      v2, s4
    @p5 v.st.w       [s8, #0], v1
    v.cmpi.lt    p2, v3, #128
    p.and        p5, p1, p2
    v.ld.h       v1, [s6, #0]
    vf.cvt.f16.f32 v3, v1
    vf.mul       v1, v3, v0
    @p3 v.st.w       [s13, #0], v1
    v.cmpi.lt    p2, v2, #128
    p.and        p3, p1, p2
    v.ld.h       v1, [s9, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    @p4 v.st.w       [s11, #0], v1
    v.ld.h       v1, [s10, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    @p5 v.st.w       [s14, #0], v1
    v.ld.h       v1, [s12, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    @p3 v.st.w       [s5, #0], v1
__rctx_next:
    s.addi       s4, s1, #2                      // the next program of this context: + 2
    s.cmp.lt     s5, s4, s2
    s.mov        s1, s4
    br.nz        s5, __rctx_program
    exit
