#!/bin/bash
source /tools/Xilinx/Vivado/2023.2/settings64.sh
cd /home/zzhouch/tnca_build/r40_failed_route_diagnosis_20261016
timeout --kill-after=30s 3600s vivado -mode batch -notrace -nojournal -source diagnose.tcl -tclargs /home/zzhouch/tnca_build/u280_r40ownership_preserved09/xo/tmp/link/vivado/vpl/prj/prj.runs/impl_1/level0_wrapper_routed_error.dcp /home/zzhouch/tnca_build/r40_failed_route_diagnosis_20261016/reports
result=$?
echo $result > diagnosis.exit
exit $result
