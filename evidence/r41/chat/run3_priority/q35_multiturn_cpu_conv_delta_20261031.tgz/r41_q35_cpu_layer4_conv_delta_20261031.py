#!/usr/bin/env python3
"""Compare layer-4 CPU convolution and gated-delta prefill boundaries."""
import json,sys
from pathlib import Path
import torch
home=Path.home();tree=home/'r41_q35_multiturn_diag_20261031'
sys.path[:0]=[str(tree/'tools/models'),str(tree),str(tree/'python'),str(tree/'compiler/python'),str(tree/'tools/asm')]
import chat
import transformers.models.qwen3_5.modeling_qwen3_5 as model
prompt='My name is Alice. Please remember it and reply with one short sentence.'
args=chat.parser().parse_args(['--model','q35','--device','cpu','--threads','4','--bucket','256','--new-tokens','1'])
app=chat.ChatApplication(args);chat.L.install_fp8_route('reference',dot='exact',scale_div='ieee')
inputs,text=chat.make_inputs(app.spec,app.processor,[chat.user_message(prompt)])
layer=app.model.model.language_model.layers[4]
if layer.block_type!='linear_attention':raise ValueError('unexpected layer type')
ctx={'active':False,'n':0};capture={}
def keep(name,x):
 if not isinstance(x,torch.Tensor) or x.ndim<2:raise TypeError(f'{name} tensor shape')
 if x.ndim>3:x=x.reshape(x.shape[0],x.shape[1],-1)
 capture.setdefault(name,[]).append(x.detach().cpu().contiguous().clone())
def enter(mod,args,kwargs):
 h=kwargs.get('hidden_states',args[0] if args else None)
 if h is None:raise ValueError('missing hidden states')
 ctx.update(active=True,n=h.shape[1])
def leave(mod,args,kwargs,out):ctx['active']=False
pre=layer.linear_attn.register_forward_pre_hook(enter,with_kwargs=True)
post=layer.linear_attn.register_forward_hook(leave,with_kwargs=True)
conv0=model.causal_conv1d_fn;delta0=model.torch_chunk_gated_delta_rule
def conv(*args,**kwargs):
 out=conv0(*args,**kwargs)
 if ctx['active']:keep('causal_conv_output',out[...,-ctx['n']:].transpose(1,2))
 return out
def delta(*args,**kwargs):
 if ctx['active']:
  for name,x in zip(('q','k','v'),args[:3]):keep('delta_input_'+name,x)
  for name in ('g','beta'):keep('delta_input_'+name,kwargs[name])
 result=delta0(*args,**kwargs)
 if ctx['active']:keep('delta_output',result[0])
 return result
model.causal_conv1d_fn=conv;model.torch_chunk_gated_delta_rule=delta;values={}
try:
 for name,chunk in [('whole',0),('grouped_chunk8',8)]:
  capture.clear();session=chat.Session(app.model,app.spec,'cpu',256,chunk)
  with torch.no_grad():logits,parts,reused=session.prefill_prompt(inputs,None)
  values[name]={n:torch.cat(xs,dim=1) for n,xs in capture.items()};del session
finally:
 model.causal_conv1d_fn=conv0;model.torch_chunk_gated_delta_rule=delta0;pre.remove();post.remove()
if set(values['whole'])!=set(values['grouped_chunk8']):raise ValueError('different probe sets')
rows=[]
for n,a in values['whole'].items():
 b=values['grouped_chunk8'][n]
 if a.shape!=b.shape or a.dtype!=b.dtype:raise ValueError(f'{n} shape/dtype {a.shape} {b.shape}')
 it={2:torch.int16,4:torch.int32}.get(a.element_size())
 if it is None:raise TypeError(f'{n} dtype {a.dtype}')
 d=a.view(it)!=b.view(it);v=d.reshape(a.shape[0],a.shape[1],-1).any(dim=-1);p=torch.nonzero(v.reshape(-1)).flatten();af=a.float();bf=b.float()
 rows.append(dict(probe=n,shape=list(a.shape),first_differing_position=int(p[0]) if len(p) else None,bit_mismatches=int(d.sum()),elements=a.numel(),rel_l2=float((af-bf).norm()/af.norm().clamp_min(1e-30)),max_abs=float((af-bf).abs().max())))
out={'schema':'r41-q35-cpu-layer4-conv-delta/1','scope':'CPU full-checkpoint exact FP8 route; segmentation comparison only; not board/TLM','layer':4,'input_ids':inputs['input_ids'].tolist(),'probes':rows}
p=home/'r41_q35_cpu_layer4_conv_delta_20261031.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
