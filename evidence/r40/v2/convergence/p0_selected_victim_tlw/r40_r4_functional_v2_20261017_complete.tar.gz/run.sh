source ~/tc_env/env.sh
cd /home/zhongchun/r40_r4_functional_v2_20261017
python3 run_tests.py > runner.log 2>&1
echo $? > runner.exit
