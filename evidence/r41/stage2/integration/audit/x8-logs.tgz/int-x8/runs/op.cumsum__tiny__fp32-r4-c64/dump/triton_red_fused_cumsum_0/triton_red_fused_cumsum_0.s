    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    .li       s3, #2143289344
    v.splat      v0, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v1, #0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s5, #64
    s.movz       s6, #16
    s.ld.d       s7, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.splat      v2, s4
    v.iota       v2                              // arange(0, VLEN)
    s.addi       s1, s2, #0
    v.mov        v1, v0
for_1:
    s.cmp.ge     s8, s1, s5
    br.nz        s8, endfor_2
    s.mul        s8, s4, s5
    v.splat      v0, s1
    v.movi       v3, #64
    v.add        v4, v0, v2
    s.add        s9, s1, s8
    v.cmp.lt     p1, v4, v3
    s.shli       s10, s9, #2                     // element offset -> bytes (x4)
    v.splat      v0, s8
    s.add        s8, s3, s10                     // &in_ptr0[...]
    v.add        v3, v4, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v0, [s8, #0]
    v.movi       v3, #0
    v.extract    s8, v0, #0
    v.extract    s9, v0, #1
    v.splat      v4, s8
    v.splat      v5, s9
    v.extract    s8, v0, #2
    vf.add       v6, v4, v5
    v.splat      v5, s8
    v.extract    s8, v0, #3
    v.splat      v7, s8
    vf.add       v8, v6, v5
    v.extract    s8, v0, #4
    v.splat      v5, s8
    v.extract    s8, v0, #5
    vf.add       v9, v8, v7
    v.splat      v7, s8
    v.extract    s8, v0, #6
    v.splat      v10, s8
    vf.add       v11, v9, v5
    v.extract    s8, v0, #7
    v.splat      v5, s8
    v.extract    s8, v0, #8
    vf.add       v12, v11, v7
    v.splat      v7, s8
    v.extract    s8, v0, #9
    v.splat      v13, s8
    vf.add       v14, v12, v10
    // one value per row into one vector (ISA 0x09)
    v.extract    s8, v4, #0
    v.insert     v3, s8, #0
    v.extract    s8, v6, #0
    vf.add       v4, v14, v5
    v.extract    s9, v0, #10
    v.insert     v3, s8, #1
    v.splat      v5, s9
    vf.add       v6, v4, v7
    v.extract    s8, v8, #0
    v.insert     v3, s8, #2
    v.extract    s8, v9, #0
    vf.add       v7, v6, v13
    v.extract    s9, v0, #11
    v.insert     v3, s8, #3
    v.splat      v8, s9
    vf.add       v9, v7, v5
    v.extract    s8, v11, #0
    v.insert     v3, s8, #4
    v.extract    s8, v12, #0
    vf.add       v5, v9, v8
    v.extract    s9, v0, #12
    v.insert     v3, s8, #5
    v.splat      v8, s9
    v.extract    s8, v14, #0
    v.insert     v3, s8, #6
    vf.add       v10, v5, v8
    v.extract    s8, v4, #0
    v.extract    s9, v0, #13
    v.insert     v3, s8, #7
    v.splat      v4, s9
    v.extract    s8, v6, #0
    v.insert     v3, s8, #8
    vf.add       v6, v10, v4
    v.extract    s8, v7, #0
    v.extract    s9, v0, #14
    v.insert     v3, s8, #9
    v.splat      v4, s9
    v.extract    s8, v9, #0
    v.insert     v3, s8, #10
    vf.add       v7, v6, v4
    v.extract    s8, v5, #0
    v.extract    s9, v0, #15
    v.insert     v3, s8, #11
    v.splat      v0, s9
    v.extract    s8, v10, #0
    v.insert     v3, s8, #12
    vf.add       v4, v7, v0
    v.extract    s8, v6, #0
    v.insert     v3, s8, #13
    v.extract    s8, v7, #0
    v.movi       v0, #15
    v.insert     v3, s8, #14
    v.movi       v5, #1
    v.movi       v6, #0
    v.extract    s8, v4, #0
    v.cmp.eq     p2, v2, v0
    v.insert     v3, s8, #15
    @p2 v.sel        v0, v5, v6
    v.extract    s8, v1, #0
    v.mul        v4, v3, v0
    v.splat      v0, s8
    v.reduce.add s8, v4
    v.splat      v4, s8
    vf.add       v5, v0, v3
    vf.add       v0, v1, v4
    v.splat      v6, s1
    v.splat      v7, s2
    s.add        s8, s7, s10                     // &out_ptr0[...]
    v.cmp.gt     p2, v6, v7
    @p2 v.sel        v6, v5, v3
    @p2 v.sel        v3, v0, v4
    v.movi       v0, #0
    @p1 v.st.w       [s8, #0], v6
    v.mov        v0, v3
    s.add        s8, s1, s6
    s.movz       s9, #1
    v.mov        v1, v0
    s.mov        s1, s8
    br.nz        s9, for_1
endfor_2:
__rctx_next:
    exit
