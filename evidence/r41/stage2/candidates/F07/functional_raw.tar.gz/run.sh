source ~/tc_env/env.sh
cd /home/zhongchun/r40_mshr_service_snapshot_v2_20261018
python3 runner.py > runner.log 2>&1
echo $? > runner.exit
