#!/bin/bash
# Same-path default-identity runs: each binary is copied to one fixed path and
# each validation writes to one fixed directory, then moved aside, so the only
# legitimate differences are the binaries' own SHA256s and host wall time.
set -euo pipefail
source ~/tc_env/env.sh
W=~/r41-pmac-model-work/identity2
H=~/r41-pmac-model/tools/performance_harness/systemc
rm -rf $W; mkdir -p $W/bin
for v in base mod; do
  cp ~/r41-pmac-model-build/$v/tnca-chip $W/bin/tnca-chip
  cp ~/r41-pmac-model-build/$v/tnca-tlm $W/bin/tnca-tlm
  sha256sum $W/bin/tnca-chip $W/bin/tnca-tlm > $W/binaries-$v.sha256
  (cd $H && taskset -c 14-15 python3 validate_matrix.py --binary $W/bin/tnca-chip --out $W/run/matrix > $W/matrix-$v.log 2>&1)
  (cd $H && taskset -c 14-15 python3 validate.py --binary $W/bin/tnca-tlm --out $W/run/memory > $W/memory-$v.log 2>&1)
  mv $W/run $W/$v
done
cat $W/binaries-*.sha256
