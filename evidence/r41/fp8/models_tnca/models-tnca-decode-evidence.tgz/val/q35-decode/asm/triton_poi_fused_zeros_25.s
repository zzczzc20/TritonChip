    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.shli       s2, s4, #4                      // x16 as a shift
    s.ld.d       s3, [s1, #0]                    // out_ptr0: device_ptr64 at arg_base+0
    s.shli       s1, s2, #2                      // element offset -> bytes (x4)
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s2
    s.add        s2, s3, s1                      // &out_ptr0[...]
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.st.w       [s2, #0], v2
__rctx_next:
    exit
