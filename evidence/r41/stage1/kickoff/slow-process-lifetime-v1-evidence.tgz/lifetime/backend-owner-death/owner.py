import tlm_backend,time
b=tlm_backend.make_backend_class()(binary='/home/zhongchun/r41-stage1/runs/slow-process-lifetime-v1/build/tnca-chip',config='/home/zhongchun/r41-stage1/runs/slow-process-lifetime-v1/lifetime/model.cfg',out='/home/zhongchun/r41-stage1/runs/slow-process-lifetime-v1/lifetime/backend-owner-death')
b.start()
open('/home/zhongchun/r41-stage1/runs/slow-process-lifetime-v1/lifetime/backend-owner-death/model.pid',"w").write(str(b.proc.pid))
data=b"".join(int(w,16).to_bytes(8,"little") for w in open('/home/zhongchun/r41-stage1/runs/slow-process-lifetime-v1/lifetime/infinite.hex').read().split())
b.upload(0,data)
b.wfile.write(b"G 0 0 1 1 1 1 1 0 1 0\n")
time.sleep(60)
