    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s3, s4, s1
    s.movz       s1, #2
    s.movz       s5, #0
    s.sub        s6, s2, s3
    s.movz       s2, #0
    s.cmp.lt     s3, s1, s5
    s.xor        s5, s4, s6
    s.sub        s7, s2, s3
    s.sub        s2, s5, s6
    s.xor        s3, s6, s7
    s.lshri      s5, s2, #1
    s.movz       s6, #1
    s.xor        s8, s5, s3
    s.movz       s9, #0
    s.sub        s10, s8, s3
    s.movz       s3, #0
    s.sub        s8, s1, s10
    s.movz       s11, #0
    s.min.s      s12, s8, s6
    s.movz       s8, #0
    s.cmp.lt     s13, s12, s9
    s.cmp.lt     s9, s4, s3
    s.sub        s3, s11, s13
    s.sub        s11, s8, s9
    s.xor        s8, s12, s3
    s.muli       s9, s5, #2
    s.movz       s5, #0
    s.movz       s13, #1
    s.xor        s14, s4, s11
    s.sub        s15, s8, s3
    s.rdspecial  s3, arg_base
    s.xor        s8, s1, s7
    s.movz       s16, #0
    s.sub        s17, s14, s11
    s.addi       s14, s5, #0
    s.cmp.eq     s5, s15, s13
    s.ld.d       s13, [s3, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.sub        s18, s8, s7
    s.sub        s7, s2, s9
    s.addi       s2, s16, #0
    s.ld.d       s7, [s3, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s8, [s3, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s9, [s3, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s16, [s3, #32]                  // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s18, [s3, #40]                  // out_ptr0: device_ptr64 at arg_base+40
    s.mov        s14, s17
    br.nz        s5, sdiv_done_1
    s.movz       s3, #0
    s.movz       s5, #31
    s.mov        s14, s3
    s.addi       s3, s5, #0
sdiv_2:
    s.lshr       s5, s17, s3
    s.shli       s19, s2, #1
    s.andi       s20, s5, #1
    s.movz       s5, #0
    s.or         s21, s19, s20
    s.movz       s19, #1
    s.cmp.geu    s20, s21, s15
    s.shl        s22, s19, s3
    s.sub        s19, s5, s20
    s.subi       s5, s3, #1
    s.and        s20, s15, s19
    s.and        s23, s22, s19
    s.sub        s19, s21, s20
    s.or         s20, s14, s23
    s.mov        s2, s19
    s.mov        s14, s20
    s.mov        s3, s5
    s.movz       s5, #0
    s.cmp.ge     s19, s3, s5
    br.nz        s19, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s5, #0
    s.cmp.lt     s14, s4, s3
    s.movz       s3, #0
    s.sub        s15, s5, s14
    s.movz       s5, #0
    s.xor        s14, s4, s15
    s.movz       s4, #0
    s.sub        s17, s14, s15
    s.cmp.lt     s14, s12, s3
    s.lshri      s3, s17, #1
    s.movz       s19, #0
    s.muli       s20, s3, #2
    s.movz       s3, #0
    s.sub        s21, s4, s14
    s.movz       s4, #0
    s.cmp.lt     s14, s1, s19
    s.sub        s19, s17, s20
    s.xor        s17, s12, s21
    s.xor        s12, s19, s15
    s.xor        s19, s2, s11
    s.sub        s2, s12, s15
    s.sub        s12, s4, s14
    s.cmp.lt     s4, s2, s5
    s.sub        s5, s17, s21
    s.sub        s14, s3, s4
    s.movz       s3, #0
    s.xor        s4, s2, s14
    s.movz       s2, #1
    s.sub        s15, s19, s11
    s.xor        s11, s1, s12
    s.sub        s17, s4, s14
    s.movz       s4, #0
    s.addi       s19, s3, #0
    s.cmp.eq     s3, s5, s2
    s.add        s2, s10, s15
    s.sub        s10, s11, s12
    s.addi       s10, s4, #0
    s.mov        s19, s17
    br.nz        s3, sdiv_done_3
    s.movz       s3, #0
    s.movz       s4, #31
    s.mov        s19, s3
    s.addi       s3, s4, #0
sdiv_4:
    s.lshr       s4, s17, s3
    s.shli       s11, s10, #1
    s.andi       s12, s4, #1
    s.movz       s4, #0
    s.or         s15, s11, s12
    s.movz       s11, #1
    s.cmp.geu    s12, s15, s5
    s.shl        s20, s11, s3
    s.sub        s11, s4, s12
    s.subi       s4, s3, #1
    s.and        s12, s5, s11
    s.and        s22, s20, s11
    s.sub        s11, s15, s12
    s.or         s12, s19, s22
    s.mov        s10, s11
    s.mov        s19, s12
    s.mov        s3, s4
    s.movz       s4, #0
    s.cmp.ge     s11, s3, s4
    br.nz        s11, sdiv_4
sdiv_done_3:
    s.movz       s3, #16
    s.xor        s4, s14, s21
    s.mul        s5, s2, s3
    s.xor        s10, s19, s4
    v.iota       v0                              // arange(0, VLEN)
    s.sub        s11, s10, s4
    v.movi       v1, #17
    v.splat      v2, s5
    s.mul        s4, s11, s3
    v.movi       v3, #0
    v.add        v4, v2, v0
    s.movz       s10, #0
    v.splat      v2, s2
    v.splat      v5, s10
    v.splat      v6, s11
    v.splat      v7, s10
    v.splat      v8, s4
    v.sub        v9, v3, v4
    v.sub        v10, v3, v1
    v.cmp.lt     p1, v4, v3
    v.cmp.lt     p2, v1, v3
    v.cmp.ge     p3, v2, v5
    v.cmp.ge     p3, v6, v7
    v.add        v2, v8, v0
    v.movi       v0, #1
    @p1 v.sel        v5, v9, v4
    @p2 v.sel        v4, v10, v1
    v.movi       v1, #0
    v.movi       v6, #0
    s.movz       s2, #31
idiv_5:
    v.splat      v7, s2
    v.shl        v8, v6, v0
    v.cmp.lt     p2, v6, v3
    v.lshr       v9, v5, v7
    v.shl        v10, v0, v7
    s.subi       s11, s2, #1
    v.and        v7, v9, v0
    s.movz       s12, #0
    v.or         v9, v8, v7
    v.cmp.geu    p3, v9, v4
    p.or         p4, p2, p3
    v.sub        v7, v9, v4
    @p4 v.sel        v8, v10, v3
    @p4 v.sel        v10, v7, v9
    v.or         v7, v1, v8
    v.mov        v6, v10
    v.mov        v1, v7
    s.mov        s2, s11
    s.cmp.ge     s11, s2, s12
    br.nz        s11, idiv_5
    v.movi       v0, #24
    v.movi       v1, #0
    v.sub        v4, v3, v6
    v.movi       v3, #1
    v.sub        v5, v1, v2
    v.sub        v7, v1, v0
    v.cmp.lt     p2, v2, v1
    v.cmp.lt     p3, v0, v1
    @p1 v.sel        v8, v4, v6
    @p2 v.sel        v4, v5, v2
    @p3 v.sel        v2, v7, v0
    v.movi       v0, #0
    v.movi       v5, #0
    s.movz       s2, #31
idiv_6:
    v.splat      v6, s2
    v.shl        v7, v5, v3
    v.cmp.lt     p1, v5, v1
    v.lshr       v9, v4, v6
    v.shl        v10, v3, v6
    s.subi       s11, s2, #1
    v.and        v6, v9, v3
    s.movz       s12, #0
    v.or         v9, v7, v6
    v.cmp.geu    p3, v9, v2
    p.or         p4, p1, p3
    v.sub        v6, v9, v2
    @p4 v.sel        v7, v10, v1
    @p4 v.sel        v10, v6, v9
    v.or         v6, v0, v7
    v.mov        v5, v10
    v.mov        v0, v6
    s.mov        s2, s11
    s.cmp.ge     s11, s2, s12
    br.nz        s11, idiv_6
    v.sub        v0, v1, v5
    s.movz       s2, #3
    s.addi       s11, s10, #0
    @p2 v.sel        v1, v0, v5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_7:
    s.cmp.ge     s12, s11, s2
    br.nz        s12, endfor_8
    s.mul        s12, s11, s3
    s.rdspecial  s14, arg_base
    s.movz       s15, #0
    s.ld.d       s17, [s14, #48]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.movz       s14, #40
    s.add        s19, s15, s12                   // the tile origin
    v.extract    s15, v8, #0
    v.extract    s20, v8, #1
    v.extract    s21, v8, #2
    v.extract    s22, v8, #3
    v.extract    s23, v8, #4
    s.rdspecial  s24, role_id
    s.movz       s25, #2560
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v2, s19
    v.splat      v3, s15
    v.splat      v4, s14
    v.splat      v5, s20
    v.splat      v6, s21
    v.splat      v7, s22
    v.splat      v9, s23
    s.mul        s15, s24, s25
    v.add        v10, v0, v2
    v.mul        v2, v3, v4
    v.mul        v3, v5, v4
    v.mul        v5, v6, v4
    v.mul        v6, v7, v4
    v.mul        v7, v9, v4
    s.add        s19, s17, s15                   // this context's own scratch
    v.splat      v9, s10
    v.add        v11, v10, v2
    v.add        v2, v10, v3
    v.add        v3, v10, v5
    v.add        v5, v10, v6
    v.add        v6, v10, v7
    s.addi       s15, s19, #0
    v.add        v7, v9, v11
    v.add        v11, v9, v2
    v.add        v2, v9, v3
    v.add        v3, v9, v5
    v.add        v5, v9, v6
    s.addi       s17, s15, #64
    s.addi       s20, s15, #128
    s.addi       s21, s15, #192
    s.addi       s22, s15, #256
    v.st.w       [s15, #0], v7
    s.sub        s23, s14, s12
    v.extract    s24, v8, #5
    v.extract    s25, v8, #6
    v.splat      v6, s24
    v.extract    s24, v8, #7
    v.mul        v7, v6, v4
    v.add        v6, v10, v7
    v.add        v7, v9, v6
    v.st.w       [s17, #0], v11
    v.extract    s17, v8, #8
    v.splat      v6, s25
    v.extract    s25, v8, #9
    v.mul        v11, v6, v4
    v.add        v6, v10, v11
    v.add        v11, v9, v6
    v.st.w       [s20, #0], v2
    v.extract    s20, v8, #10
    v.splat      v2, s24
    s.addi       s24, s15, #320
    v.mul        v6, v2, v4
    v.add        v2, v10, v6
    v.add        v6, v9, v2
    v.st.w       [s21, #0], v3
    v.extract    s21, v8, #11
    v.splat      v2, s17
    s.addi       s17, s15, #384
    v.mul        v3, v2, v4
    v.add        v2, v10, v3
    v.add        v3, v9, v2
    v.st.w       [s22, #0], v5
    v.extract    s22, v8, #12
    v.splat      v2, s25
    s.addi       s25, s15, #448
    v.mul        v5, v2, v4
    v.add        v2, v10, v5
    v.add        v5, v9, v2
    v.st.w       [s24, #0], v7
    v.extract    s24, v8, #13
    v.splat      v2, s20
    s.addi       s20, s15, #512
    v.mul        v7, v2, v4
    v.add        v2, v10, v7
    v.add        v7, v9, v2
    v.st.w       [s17, #0], v11
    v.extract    s17, v8, #14
    v.splat      v2, s21
    s.addi       s21, s15, #576
    v.mul        v11, v2, v4
    v.add        v2, v10, v11
    v.add        v11, v9, v2
    v.st.w       [s25, #0], v6
    v.extract    s25, v8, #15
    v.splat      v2, s22
    v.splat      v6, s24
    s.addi       s22, s15, #640
    v.mul        v12, v2, v4
    v.mul        v2, v6, v4
    s.addi       s24, s15, #704
    v.add        v6, v10, v12
    v.add        v12, v10, v2
    v.add        v2, v9, v6
    v.add        v6, v9, v12
    v.st.w       [s20, #0], v3
    s.movz       s20, #0
    v.splat      v3, s17
    s.add        s17, s20, s12                   // the tile origin
    s.addi       s12, s19, #1024
    v.mul        v12, v3, v4
    s.addi       s20, s15, #768
    v.add        v3, v10, v12
    v.add        v12, v9, v3
    v.st.w       [s21, #0], v5
    v.splat      v3, s25
    s.addi       s21, s15, #832
    s.addi       s25, s15, #896
    v.mul        v5, v3, v4
    v.splat      v3, s14
    s.addi       s14, s15, #960
    v.add        v4, v10, v5
    v.splat      v5, s17
    s.addi       s15, s12, #64
    v.add        v10, v9, v4
    v.mul        v4, v1, v3
    v.add        v9, v5, v4
    v.splat      v4, s10
    v.add        v5, v4, v9
    v.st.w       [s22, #0], v7
    s.addi       s22, s17, #1
    v.mul        v7, v1, v3
    v.st.w       [s24, #0], v11
    s.addi       s24, s17, #2
    v.splat      v9, s22
    s.addi       s22, s12, #128
    v.add        v11, v9, v7
    v.splat      v7, s24
    s.addi       s24, s12, #192
    v.add        v9, v4, v11
    v.st.w       [s20, #0], v2
    s.addi       s20, s17, #3
    v.mul        v2, v1, v3
    v.add        v11, v7, v2
    v.splat      v2, s20
    s.addi       s20, s12, #256
    v.add        v7, v4, v11
    v.st.w       [s21, #0], v6
    s.addi       s21, s17, #4
    v.mul        v6, v1, v3
    v.add        v11, v2, v6
    v.splat      v2, s21
    s.addi       s21, s12, #320
    v.add        v6, v4, v11
    v.st.w       [s25, #0], v12
    s.addi       s25, s17, #5
    v.mul        v11, v1, v3
    v.add        v12, v2, v11
    v.splat      v2, s25
    s.addi       s25, s12, #384
    v.add        v11, v4, v12
    v.st.w       [s14, #0], v10
    s.addi       s14, s17, #6
    v.mul        v10, v1, v3
    fence.acq_rel.device
    v.add        v12, v2, v10
    v.splat      v2, s14
    s.addi       s14, s17, #7
    v.add        v10, v4, v12
    v.st.w       [s12, #0], v5
    v.mul        v5, v1, v3
    v.add        v12, v2, v5
    v.splat      v2, s14
    s.addi       s14, s17, #8
    v.add        v5, v4, v12
    v.st.w       [s15, #0], v9
    s.addi       s15, s17, #9
    v.mul        v9, v1, v3
    v.add        v12, v2, v9
    v.splat      v2, s14
    s.addi       s14, s12, #448
    v.add        v9, v4, v12
    v.st.w       [s22, #0], v7
    s.addi       s22, s17, #10
    v.mul        v7, v1, v3
    v.add        v12, v2, v7
    v.splat      v2, s15
    s.addi       s15, s12, #512
    v.add        v7, v4, v12
    v.st.w       [s24, #0], v6
    s.addi       s24, s17, #11
    v.mul        v6, v1, v3
    v.add        v12, v2, v6
    v.splat      v2, s22
    s.addi       s22, s12, #576
    v.add        v6, v4, v12
    v.st.w       [s20, #0], v11
    s.addi       s20, s17, #12
    v.mul        v11, v1, v3
    v.add        v12, v2, v11
    v.splat      v2, s24
    s.addi       s24, s12, #640
    v.add        v11, v4, v12
    v.st.w       [s21, #0], v10
    s.addi       s21, s17, #13
    v.mul        v10, v1, v3
    v.add        v12, v2, v10
    v.splat      v2, s20
    s.addi       s20, s12, #704
    v.add        v10, v4, v12
    v.st.w       [s25, #0], v5
    s.addi       s25, s17, #14
    v.mul        v5, v1, v3
    v.add        v12, v2, v5
    v.splat      v2, s21
    s.addi       s21, s12, #768
    v.add        v5, v4, v12
    v.st.w       [s14, #0], v9
    s.addi       s14, s17, #15
    v.mul        v9, v1, v3
    s.addi       s17, s12, #832
    v.add        v12, v2, v9
    v.splat      v2, s25
    s.addi       s25, s12, #896
    v.add        v9, v4, v12
    s.addi       s26, s12, #960
    v.st.w       [s15, #0], v7
    v.mul        v7, v1, v3
    v.mul        v12, v1, v3
    v.splat      v3, s14
    v.add        v13, v2, v7
    // repack 16x16 f8E4M3FN through memory: there is no v.pack (ISA sec 8.4)
    s.addi       s12, s19, #0
    v.add        v2, v3, v12
    v.add        v3, v4, v13
    s.movz       s14, #0
    v.add        v7, v4, v2
    v.st.w       [s22, #0], v6
    s.add        s15, s14, s23                   // the tile origin
    s.addi       s14, s19, #2048                 // 256 bytes of repack scratch
    v.splat      v2, s15
    s.addi       s15, s19, #64
    v.cmp.lt     p1, v0, v2
    v.st.w       [s24, #0], v11
    s.addi       s22, s14, #16                   // row 1
    v.st.w       [s20, #0], v10
    s.addi       s20, s19, #128
    v.st.w       [s21, #0], v5
    s.addi       s21, s14, #32                   // row 2
    v.st.w       [s17, #0], v9
    s.addi       s17, s19, #192
    v.st.w       [s25, #0], v3
    s.addi       s24, s14, #48                   // row 3
    v.st.w       [s26, #0], v7
    fence.acq_rel.device
    s.addi       s25, s19, #256
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s14, #64                   // row 4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.st.b       [s14, #0], v2
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s19, #320
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.st.b       [s22, #0], v2
    s.addi       s22, s14, #80                   // row 5
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s19, #384
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.st.b       [s21, #0], v2
    s.addi       s21, s14, #96                   // row 6
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s19, #448
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.st.b       [s24, #0], v2
    s.addi       s24, s14, #112                  // row 7
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s19, #512
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.st.b       [s12, #0], v2
    s.addi       s12, s14, #128                  // row 8
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s19, #576
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.st.b       [s22, #0], v2
    s.addi       s22, s14, #144                  // row 9
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s19, #640
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.st.b       [s21, #0], v2
    s.addi       s21, s14, #160                  // row 10
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s19, #704
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.st.b       [s24, #0], v2
    s.addi       s24, s14, #176                  // row 11
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s19, #768
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.st.b       [s12, #0], v2
    s.addi       s12, s14, #192                  // row 12
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s19, #832
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.splat      v0, s10
    s.addi       s26, s14, #208                  // row 13
    v.st.b       [s22, #0], v2
    s.addi       s22, s19, #896
    v.ld.w       v2, [s20, #0]
    s.addi       s20, s14, #224                  // row 14
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s13, v2]              // index is in elements (ISA sec 9.1)
    v.st.b       [s21, #0], v3
    s.addi       s21, s19, #960
    v.ld.w       v2, [s17, #0]
    s.addi       s17, s14, #240                  // row 15
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s13, v2]              // index is in elements (ISA sec 9.1)
    v.splat      v2, s6
    v.st.b       [s24, #0], v3
    s.addi       s24, s14, #64
    v.ld.w       v3, [s25, #0]
    s.addi       s25, s14, #128
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v4, [s13, v3]              // index is in elements (ISA sec 9.1)
    v.st.b       [s12, #0], v4
    s.addi       s12, s14, #192
    v.splat      v3, s1
    // repack 16x16 f8E4M3FN through memory: there is no v.pack (ISA sec 8.4)
    s.addi       s27, s19, #1024
    v.ld.w       v4, [s15, #0]
    s.movz       s15, #0
    s.add        s28, s15, s23                   // the tile origin
    s.addi       s15, s19, #2304                 // 256 bytes of repack scratch
    v.splat      v5, s28
    s.addi       s23, s19, #1088
    v.cmp.lt     p2, v0, v5
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v0, [s13, v4]              // index is in elements (ISA sec 9.1)
    v.st.b       [s26, #0], v0
    s.addi       s26, s15, #16                   // row 1
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s19, #1152
    v.splat      v4, s2
    s.addi       s28, s15, #32                   // row 2
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v6, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.st.b       [s20, #0], v6
    s.addi       s20, s19, #1216
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s15, #48                   // row 3
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v6, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v5
    s.addi       s29, s19, #1280
    v.st.b       [s17, #0], v6
    w.def        w0, #60, #4                     // v60..v63
    fence.acq_rel.device
    s.movz       s17, #4
    v.splat      v0, s17
    v.ld.w       v2, [s14, #0]
    s.addi       s14, s15, #64                   // row 4
    v.mov        v60, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s24, #0]
    s.addi       s17, s19, #1344
    v.mov        v61, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s25, #0]
    s.movz       s24, #5
    v.splat      v6, s24
    v.mov        v62, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s12, #0]
    s.addi       s12, s15, #80                   // row 5
    v.mov        v63, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s27, #0]
    s.addi       s24, s19, #1408
    s.movz       s25, #6
    s.addi       s27, s15, #96                   // row 6
    v.splat      v7, s25
    s.addi       s25, s19, #1472
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.b v9, [s7, v2]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v5
    v.st.b       [s15, #0], v9
    v.ld.w       v2, [s23, #0]
    s.movz       s23, #7
    v.splat      v3, s23
    s.addi       s23, s15, #112                  // row 7
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v9, [s7, v2]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v5
    v.st.b       [s26, #0], v9
    s.addi       s26, s19, #1536
    v.ld.w       v2, [s22, #0]
    s.movz       s22, #8
    v.splat      v4, s22
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.b v9, [s7, v2]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v5
    s.addi       s22, s15, #128                  // row 8
    v.st.b       [s28, #0], v9
    s.addi       s28, s19, #1600
    v.ld.w       v0, [s20, #0]
    s.movz       s20, #9
    v.splat      v2, s20
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v9, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v5
    s.addi       s20, s15, #144                  // row 9
    v.st.b       [s21, #0], v9
    s.addi       s21, s19, #1664
    v.ld.w       v0, [s29, #0]
    s.movz       s29, #10
    v.splat      v6, s29
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.b v9, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v7, v5
    s.addi       s29, s15, #160                  // row 10
    v.st.b       [s14, #0], v9
    s.addi       s14, s19, #1728
    v.ld.w       v0, [s17, #0]
    s.movz       s17, #11
    v.splat      v7, s17
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v9, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v3, v5
    s.addi       s17, s15, #176                  // row 11
    v.st.b       [s12, #0], v9
    s.addi       s12, s19, #1792
    v.ld.w       v0, [s24, #0]
    s.movz       s24, #12
    v.splat      v3, s24
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.b v9, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v5
    s.addi       s24, s15, #192                  // row 12
    v.st.b       [s27, #0], v9
    s.addi       s27, s19, #1856
    v.ld.w       v0, [s25, #0]
    s.movz       s25, #13
    v.splat      v4, s25
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v9, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v5
    s.addi       s25, s15, #208                  // row 13
    v.st.b       [s23, #0], v9
    s.addi       s23, s19, #1920
    v.ld.w       v0, [s26, #0]
    s.movz       s26, #14
    v.splat      v2, s26
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.b v9, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v5
    s.addi       s26, s15, #224                  // row 14
    v.st.b       [s22, #0], v9
    s.addi       s22, s19, #1984
    v.ld.w       v0, [s28, #0]
    s.movz       s19, #15
    v.splat      v6, s19
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v9, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v7, v5
    s.addi       s19, s15, #240                  // row 15
    v.st.b       [s20, #0], v9
    v.ld.w       v0, [s21, #0]
    s.addi       s20, s15, #64
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.b v7, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v5
    v.st.b       [s29, #0], v7
    s.addi       s21, s15, #128
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s15, #192
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v5
    v.st.b       [s17, #0], v3
    s.add        s17, s11, s6
    v.ld.w       v0, [s12, #0]
    s.movz       s12, #1
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.b v3, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v5
    v.st.b       [s24, #0], v3
    v.ld.w       v0, [s27, #0]
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v5
    v.st.b       [s25, #0], v2
    v.ld.w       v0, [s23, #0]
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.b v2, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.b       [s26, #0], v2
    v.ld.w       v0, [s22, #0]
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.b       [s19, #0], v2
    w.def        w1, #56, #4                     // v56..v59
    fence.acq_rel.device
    v.ld.w       v0, [s15, #0]
    v.mov        v56, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s20, #0]
    v.mov        v57, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s21, #0]
    v.mov        v58, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s14, #0]
    v.mov        v59, v0                         // hand off through the shared window (sec 7.3)
    mb.arm       s14, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.e4m3 a0, v60, v56, s14
    mb.wait      s14
    s.mov        s11, s17
    br.nz        s12, for_7
endfor_8:
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s1, #0
    s.movz       s2, #0
    s.add        s3, s2, s5                      // the tile origin
    v.splat      v0, s3
    s.movz       s2, #0
    s.add        s6, s2, s5                      // the tile origin
    v.splat      v1, s6
    s.movz       s2, #17
    v.splat      v2, s2
    v.cmp.lt     p1, v1, v2
    s.movz       s2, #0
    s.add        s7, s2, s4                      // the tile origin
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v3, s7
    v.add        v4, v1, v3
    s.movz       s2, #24
    v.splat      v1, s2
    v.cmp.lt     p2, v4, v1
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v1
    s.movz       s1, #1
    s.addi       s2, s3, #1
    v.splat      v0, s2
    s.addi       s2, s6, #1
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v1
    s.movz       s1, #2
    s.addi       s2, s3, #2
    v.splat      v0, s2
    s.addi       s2, s6, #2
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v1
    s.movz       s1, #3
    s.addi       s2, s3, #3
    v.splat      v0, s2
    s.addi       s2, s6, #3
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v1
    s.movz       s1, #4
    s.addi       s2, s3, #4
    v.splat      v0, s2
    s.addi       s2, s6, #4
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v1
    s.movz       s1, #5
    s.addi       s2, s3, #5
    v.splat      v0, s2
    s.addi       s2, s6, #5
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v1
    s.movz       s1, #6
    s.addi       s2, s3, #6
    v.splat      v0, s2
    s.addi       s2, s6, #6
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v1
    s.movz       s1, #7
    s.addi       s2, s3, #7
    v.splat      v0, s2
    s.addi       s2, s6, #7
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v1
    s.movz       s1, #8
    s.addi       s2, s3, #8
    v.splat      v0, s2
    s.addi       s2, s6, #8
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v1
    s.movz       s1, #9
    s.addi       s2, s3, #9
    v.splat      v0, s2
    s.addi       s2, s6, #9
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v1
    s.movz       s1, #10
    s.addi       s2, s3, #10
    v.splat      v0, s2
    s.addi       s2, s6, #10
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v1
    s.movz       s1, #11
    s.addi       s2, s3, #11
    v.splat      v0, s2
    s.addi       s2, s6, #11
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v1
    s.movz       s1, #12
    s.addi       s2, s3, #12
    v.splat      v0, s2
    s.addi       s2, s6, #12
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v1
    s.movz       s1, #13
    s.addi       s2, s3, #13
    v.splat      v0, s2
    s.addi       s2, s6, #13
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v1
    s.movz       s1, #14
    s.addi       s2, s3, #14
    v.splat      v0, s2
    s.addi       s2, s6, #14
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v1
    s.movz       s1, #15
    s.addi       s2, s3, #15
    v.splat      v0, s2
    s.addi       s2, s6, #15
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v1
    s.muli       s1, s4, #4                      // a runtime tile origin, x4
    s.add        s2, s9, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s1, s4, #2                      // a runtime tile origin, x2
    s.add        s3, s16, s1                     // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s1, s4, #2                      // a runtime tile origin, x2
    s.add        s4, s18, s1                     // the tile origin
    s.muli       s1, s5, #48                     // a runtime tile origin, x48
    s.add        s5, s4, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    a.vread      v0, a0, s1
    s.movz       s1, #0
    a.vread      v1, a1, s1
    v.splat      v3, s6
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s2, #0]
    vf.mul       v4, v1, v3
    vf.mul       v1, v0, v4
    v.splat      v0, s6
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s3, #0]
    vf.cvt.bf16.f32 v3, v0
    vf.add       v0, v1, v3
    vf.cvt.f32.bf16 v1, v0
    v.splat      v0, s6
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s5, #0], v1
    s.movz       s1, #1
    a.vread      v0, a0, s1
    s.movz       s1, #1
    a.vread      v1, a1, s1
    s.addi       s1, s6, #1
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s2, #0]
    vf.mul       v4, v1, v3
    vf.mul       v1, v0, v4
    s.addi       s1, s6, #1
    v.splat      v0, s1
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s3, #0]
    vf.cvt.bf16.f32 v3, v0
    vf.add       v0, v1, v3
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s5, #48                     // row 1
    s.addi       s4, s6, #1
    v.splat      v0, s4
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
    s.movz       s1, #2
    a.vread      v0, a0, s1
    s.movz       s1, #2
    a.vread      v1, a1, s1
    s.addi       s1, s6, #2
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s2, #0]
    vf.mul       v4, v1, v3
    vf.mul       v1, v0, v4
    s.addi       s1, s6, #2
    v.splat      v0, s1
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s3, #0]
    vf.cvt.bf16.f32 v3, v0
    vf.add       v0, v1, v3
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s5, #96                     // row 2
    s.addi       s4, s6, #2
    v.splat      v0, s4
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
    s.movz       s1, #3
    a.vread      v0, a0, s1
    s.movz       s1, #3
    a.vread      v1, a1, s1
    s.addi       s1, s6, #3
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s2, #0]
    vf.mul       v4, v1, v3
    vf.mul       v1, v0, v4
    s.addi       s1, s6, #3
    v.splat      v0, s1
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s3, #0]
    vf.cvt.bf16.f32 v3, v0
    vf.add       v0, v1, v3
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s5, #144                    // row 3
    s.addi       s4, s6, #3
    v.splat      v0, s4
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
    s.movz       s1, #4
    a.vread      v0, a0, s1
    s.movz       s1, #4
    a.vread      v1, a1, s1
    s.addi       s1, s6, #4
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s2, #0]
    vf.mul       v4, v1, v3
    vf.mul       v1, v0, v4
    s.addi       s1, s6, #4
    v.splat      v0, s1
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s3, #0]
    vf.cvt.bf16.f32 v3, v0
    vf.add       v0, v1, v3
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s5, #192                    // row 4
    s.addi       s4, s6, #4
    v.splat      v0, s4
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
    s.movz       s1, #5
    a.vread      v0, a0, s1
    s.movz       s1, #5
    a.vread      v1, a1, s1
    s.addi       s1, s6, #5
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s2, #0]
    vf.mul       v4, v1, v3
    vf.mul       v1, v0, v4
    s.addi       s1, s6, #5
    v.splat      v0, s1
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s3, #0]
    vf.cvt.bf16.f32 v3, v0
    vf.add       v0, v1, v3
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s5, #240                    // row 5
    s.addi       s4, s6, #5
    v.splat      v0, s4
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
    s.movz       s1, #6
    a.vread      v0, a0, s1
    s.movz       s1, #6
    a.vread      v1, a1, s1
    s.addi       s1, s6, #6
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s2, #0]
    vf.mul       v4, v1, v3
    vf.mul       v1, v0, v4
    s.addi       s1, s6, #6
    v.splat      v0, s1
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s3, #0]
    vf.cvt.bf16.f32 v3, v0
    vf.add       v0, v1, v3
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s5, #288                    // row 6
    s.addi       s4, s6, #6
    v.splat      v0, s4
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
    s.movz       s1, #7
    a.vread      v0, a0, s1
    s.movz       s1, #7
    a.vread      v1, a1, s1
    s.addi       s1, s6, #7
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s2, #0]
    vf.mul       v4, v1, v3
    vf.mul       v1, v0, v4
    s.addi       s1, s6, #7
    v.splat      v0, s1
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s3, #0]
    vf.cvt.bf16.f32 v3, v0
    vf.add       v0, v1, v3
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s5, #336                    // row 7
    s.addi       s4, s6, #7
    v.splat      v0, s4
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
    s.movz       s1, #8
    a.vread      v0, a0, s1
    s.movz       s1, #8
    a.vread      v1, a1, s1
    s.addi       s1, s6, #8
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s2, #0]
    vf.mul       v4, v1, v3
    vf.mul       v1, v0, v4
    s.addi       s1, s6, #8
    v.splat      v0, s1
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s3, #0]
    vf.cvt.bf16.f32 v3, v0
    vf.add       v0, v1, v3
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s5, #384                    // row 8
    s.addi       s4, s6, #8
    v.splat      v0, s4
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
    s.movz       s1, #9
    a.vread      v0, a0, s1
    s.movz       s1, #9
    a.vread      v1, a1, s1
    s.addi       s1, s6, #9
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s2, #0]
    vf.mul       v4, v1, v3
    vf.mul       v1, v0, v4
    s.addi       s1, s6, #9
    v.splat      v0, s1
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s3, #0]
    vf.cvt.bf16.f32 v3, v0
    vf.add       v0, v1, v3
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s5, #432                    // row 9
    s.addi       s4, s6, #9
    v.splat      v0, s4
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
    s.movz       s1, #10
    a.vread      v0, a0, s1
    s.movz       s1, #10
    a.vread      v1, a1, s1
    s.addi       s1, s6, #10
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s2, #0]
    vf.mul       v4, v1, v3
    vf.mul       v1, v0, v4
    s.addi       s1, s6, #10
    v.splat      v0, s1
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s3, #0]
    vf.cvt.bf16.f32 v3, v0
    vf.add       v0, v1, v3
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s5, #480                    // row 10
    s.addi       s4, s6, #10
    v.splat      v0, s4
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
    s.movz       s1, #11
    a.vread      v0, a0, s1
    s.movz       s1, #11
    a.vread      v1, a1, s1
    s.addi       s1, s6, #11
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s2, #0]
    vf.mul       v4, v1, v3
    vf.mul       v1, v0, v4
    s.addi       s1, s6, #11
    v.splat      v0, s1
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s3, #0]
    vf.cvt.bf16.f32 v3, v0
    vf.add       v0, v1, v3
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s5, #528                    // row 11
    s.addi       s4, s6, #11
    v.splat      v0, s4
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
    s.movz       s1, #12
    a.vread      v0, a0, s1
    s.movz       s1, #12
    a.vread      v1, a1, s1
    s.addi       s1, s6, #12
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s2, #0]
    vf.mul       v4, v1, v3
    vf.mul       v1, v0, v4
    s.addi       s1, s6, #12
    v.splat      v0, s1
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s3, #0]
    vf.cvt.bf16.f32 v3, v0
    vf.add       v0, v1, v3
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s5, #576                    // row 12
    s.addi       s4, s6, #12
    v.splat      v0, s4
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
    s.movz       s1, #13
    a.vread      v0, a0, s1
    s.movz       s1, #13
    a.vread      v1, a1, s1
    s.addi       s1, s6, #13
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s2, #0]
    vf.mul       v4, v1, v3
    vf.mul       v1, v0, v4
    s.addi       s1, s6, #13
    v.splat      v0, s1
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s3, #0]
    vf.cvt.bf16.f32 v3, v0
    vf.add       v0, v1, v3
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s5, #624                    // row 13
    s.addi       s4, s6, #13
    v.splat      v0, s4
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
    s.movz       s1, #14
    a.vread      v0, a0, s1
    s.movz       s1, #14
    a.vread      v1, a1, s1
    s.addi       s1, s6, #14
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s2, #0]
    vf.mul       v4, v1, v3
    vf.mul       v1, v0, v4
    s.addi       s1, s6, #14
    v.splat      v0, s1
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s3, #0]
    vf.cvt.bf16.f32 v3, v0
    vf.add       v0, v1, v3
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s5, #672                    // row 14
    s.addi       s4, s6, #14
    v.splat      v0, s4
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
    s.movz       s1, #15
    a.vread      v0, a0, s1
    s.movz       s1, #15
    a.vread      v1, a1, s1
    s.addi       s1, s6, #15
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s2, #0]
    vf.mul       v4, v1, v3
    vf.mul       v1, v0, v4
    s.addi       s1, s6, #15
    v.splat      v0, s1
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s3, #0]
    vf.cvt.bf16.f32 v3, v0
    vf.add       v0, v1, v3
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s5, #720                    // row 15
    s.addi       s2, s6, #15
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
__rctx_next:
    exit
