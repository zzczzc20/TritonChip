    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #7
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    @p1 v.sel        v4, v1, v3
    v.movi       v1, #0
    v.lshr       v5, v4, v0
    v.movi       v0, #127
    v.sub        v4, v2, v5
    s.rdspecial  s2, arg_base
    @p1 v.sel        v6, v4, v5
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.sub        v4, v1, v6
    v.cmp.lt     p1, v6, v1
    @p1 v.sel        v5, v4, v6
    s.ld.d       s4, [s2, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.and        v4, v5, v0
    s.movz       s5, #85
    v.sub        v0, v1, v4
    s.ld.d       s6, [s2, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    @p1 v.sel        v5, v0, v4
    s.movz       s7, #85
    s.ld.d       s8, [s2, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.movz       s9, #85
    s.movz       s10, #85
    s.ld.d       s11, [s2, #32]                  // in_ptr4: device_ptr64 at arg_base+32
    s.movz       s12, #85
    s.movz       s13, #85
    s.ld.d       s14, [s2, #40]                  // out_ptr0: device_ptr64 at arg_base+40
    v.movi       v0, #0
    s.movz       s15, #85
    s.ld.d       s16, [s2, #48]                  // out_ptr1: device_ptr64 at arg_base+48
    v.sub        v4, v0, v3
    s.movz       s17, #85
    s.ld.d       s18, [s2, #56]                  // out_ptr2: device_ptr64 at arg_base+56
    v.cmp.lt     p1, v3, v0
    @p1 v.sel        v7, v4, v3
    s.ld.d       s19, [s2, #64]                  // out_ptr3: device_ptr64 at arg_base+64
    v.movi       v4, #0
    v.movi       v8, #127
    v.sub        v9, v4, v3
    v.cmp.lt     p2, v3, v4
    @p2 v.sel        v10, v9, v3
    s.movz       s2, #85
    v.and        v3, v7, v8
    s.movz       s20, #85
    v.sub        v7, v0, v3
    s.movz       s21, #85
    v.movi       v8, #14
    v.movi       v9, #128
    @p1 v.sel        v11, v7, v3
    s.movz       s22, #85
    s.shli       s23, s1, #2                     // element offset -> bytes (x4)
    v.ld.gather.w v3, [s4, v6]                   // index is in elements (ISA sec 9.1)
    s.add        s1, s3, s23                     // &in_ptr0[...]
    v.lshr       v7, v10, v8
    v.movi       v8, #16384
    v.sub        v10, v4, v7
    v.sub        v12, v2, v9
    @p2 v.sel        v13, v10, v7
    v.sub        v7, v1, v9
    v.sub        v10, v0, v9
    v.sub        v14, v4, v8
    v.cmp.lt     p1, v9, v2
    v.ld.w       v2, [s1, #0]
    v.cmp.lt     p2, v9, v1
    v.cmp.lt     p3, v9, v0
    @p1 v.sel        v0, v12, v9
    v.extract    s1, v5, #0
    s.shli       s3, s1, #32
    v.extract    s1, v5, #1
    s.ashri      s4, s3, #32
    s.shli       s3, s1, #32
    v.movi       v0, #0
    v.movi       v1, #0
    s.lshri      s1, s4, #32
    s.ashri      s24, s3, #32
    v.ld.gather.w v12, [s6, v6]                  // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v8, v4
    vf.mul       v4, v2, v3
    @p2 v.sel        v15, v7, v9
    v.extract    s3, v5, #2
    s.shli       s6, s3, #32
    v.extract    s3, v5, #3
    s.lshri      s25, s24, #32
    s.ashri      s26, s6, #32
    s.shli       s6, s3, #32
    v.ld.gather.w v7, [s8, v6]                   // index is in elements (ISA sec 9.1)
    v.insert     v0, s4, #0
    v.insert     v1, s1, #0
    v.insert     v0, s24, #1
    v.insert     v1, s25, #1
    s.lshri      s1, s26, #32
    v.insert     v0, s26, #2
    v.insert     v1, s1, #2
    vf.mul       v6, v4, v12
    @p3 v.sel        v12, v10, v9
    v.extract    s1, v5, #4
    s.ashri      s3, s6, #32
    s.shli       s4, s1, #32
    v.extract    s1, v5, #5
    s.lshri      s6, s3, #32
    s.ashri      s8, s4, #32
    s.shli       s4, s1, #32
    v.insert     v0, s3, #3
    v.insert     v1, s6, #3
    s.lshri      s1, s8, #32
    v.insert     v0, s8, #4
    v.insert     v1, s1, #4
    vf.mul       v10, v2, v7
    @p1 v.sel        v2, v14, v8
    v.extract    s1, v5, #6
    s.ashri      s3, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v5, #7
    s.lshri      s6, s3, #32
    s.ashri      s8, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v5, #8
    v.insert     v0, s3, #5
    v.insert     v1, s6, #5
    s.lshri      s3, s8, #32
    s.ashri      s6, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v5, #9
    v.insert     v0, s8, #6
    v.insert     v1, s3, #6
    s.lshri      s3, s6, #32
    s.ashri      s8, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v5, #10
    v.insert     v0, s6, #7
    v.insert     v1, s3, #7
    s.lshri      s3, s8, #32
    s.ashri      s6, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v5, #11
    v.insert     v0, s8, #8
    v.insert     v1, s3, #8
    s.lshri      s3, s6, #32
    s.ashri      s8, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v5, #12
    v.insert     v0, s6, #9
    v.insert     v1, s3, #9
    s.lshri      s3, s8, #32
    s.ashri      s6, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v5, #13
    v.insert     v0, s8, #10
    v.insert     v1, s3, #10
    s.lshri      s3, s6, #32
    s.ashri      s8, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v5, #14
    v.insert     v0, s6, #11
    v.insert     v1, s3, #11
    s.lshri      s3, s8, #32
    s.ashri      s6, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v5, #15
    v.insert     v0, s8, #12
    v.insert     v1, s3, #12
    s.lshri      s3, s6, #32
    s.ashri      s8, s4, #32
    s.shli       s4, s1, #32
    v.insert     v0, s6, #13
    v.insert     v1, s3, #13
    s.lshri      s1, s8, #32
    s.ashri      s3, s4, #32
    v.insert     v0, s8, #14
    v.insert     v1, s1, #14
    s.lshri      s1, s3, #32
    v.insert     v0, s3, #15
    v.insert     v1, s1, #15
    v.extract    s1, v0, #0
    v.extract    s3, v1, #0
    s.shli       s4, s3, #32
    v.extract    s3, v1, #1
    s.or         s6, s1, s4
    s.shli       s1, s3, #32
    v.extract    s3, v0, #1
    v.extract    s4, v1, #2
    v.movi       v2, #0
    s.cmp.lt     s8, s6, s5
    s.or         s6, s3, s1
    s.shli       s1, s4, #32
    v.extract    s3, v0, #2
    v.extract    s4, v1, #3
    v.insert     v2, s8, #0
    s.cmp.lt     s8, s6, s5
    s.or         s6, s3, s1
    s.shli       s1, s4, #32
    v.extract    s3, v0, #3
    v.extract    s4, v1, #4
    v.insert     v2, s8, #1
    s.cmp.lt     s8, s6, s5
    s.or         s6, s3, s1
    s.shli       s1, s4, #32
    v.extract    s3, v0, #4
    v.extract    s4, v1, #5
    v.insert     v2, s8, #2
    s.cmp.lt     s8, s6, s5
    s.or         s6, s3, s1
    s.shli       s1, s4, #32
    v.extract    s3, v0, #5
    v.extract    s4, v1, #6
    v.insert     v2, s8, #3
    s.cmp.lt     s8, s6, s5
    s.or         s5, s3, s1
    s.shli       s1, s4, #32
    v.extract    s3, v0, #6
    v.extract    s4, v1, #7
    v.insert     v2, s8, #4
    s.cmp.lt     s6, s5, s7
    s.or         s5, s3, s1
    s.shli       s1, s4, #32
    v.extract    s3, v0, #7
    v.extract    s4, v1, #8
    v.insert     v2, s6, #5
    s.cmp.lt     s6, s5, s9
    s.or         s5, s3, s1
    s.shli       s1, s4, #32
    v.extract    s3, v0, #8
    v.extract    s4, v1, #9
    v.insert     v2, s6, #6
    s.cmp.lt     s6, s5, s10
    s.or         s5, s3, s1
    s.shli       s1, s4, #32
    v.extract    s3, v0, #9
    v.extract    s4, v1, #10
    v.insert     v2, s6, #7
    s.cmp.lt     s6, s5, s12
    s.or         s5, s3, s1
    s.shli       s1, s4, #32
    v.extract    s3, v0, #10
    v.extract    s4, v1, #11
    v.insert     v2, s6, #8
    s.cmp.lt     s6, s5, s13
    s.or         s5, s3, s1
    s.shli       s1, s4, #32
    v.extract    s3, v0, #11
    v.extract    s4, v1, #12
    v.insert     v2, s6, #9
    s.cmp.lt     s6, s5, s15
    s.or         s5, s3, s1
    s.shli       s1, s4, #32
    v.extract    s3, v0, #12
    v.extract    s4, v1, #13
    v.insert     v2, s6, #10
    s.cmp.lt     s6, s5, s17
    s.or         s5, s3, s1
    s.shli       s1, s4, #32
    v.extract    s3, v0, #13
    v.extract    s4, v1, #14
    v.insert     v2, s6, #11
    s.cmp.lt     s6, s5, s2
    s.or         s2, s3, s1
    s.shli       s1, s4, #32
    v.extract    s3, v0, #14
    v.extract    s4, v1, #15
    v.insert     v2, s6, #12
    s.cmp.lt     s5, s2, s20
    s.or         s2, s3, s1
    s.shli       s1, s4, #32
    v.extract    s3, v0, #15
    v.movi       v0, #4096
    v.insert     v2, s5, #13
    s.cmp.lt     s4, s2, s21
    s.or         s2, s3, s1
    v.add        v1, v11, v0
    v.mul        v0, v13, v9
    v.movi       v7, #8192
    v.insert     v2, s4, #14
    s.cmp.lt     s1, s2, s22
    v.add        v8, v1, v0
    v.mul        v0, v5, v7
    v.insert     v2, s1, #15
    v.movi       v1, #0
    v.add        v5, v8, v0
    v.cmp.ne     p1, v2, v1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v0, [s11, v5]              // index is in elements (ISA sec 9.1)
    v.movi       v1, #0
    s.add        s1, s14, s23                    // &out_ptr0[...]
    s.add        s2, s16, s23                    // &out_ptr1[...]
    s.add        s3, s18, s23                    // &out_ptr2[...]
    s.add        s4, s19, s23                    // &out_ptr3[...]
    vf.cvt.bf16.f32 v2, v0
    v.st.w       [s1, #0], v4
    @p1 v.sel        v0, v2, v1
    vf.mul       v1, v0, v3
    v.st.w       [s2, #0], v6
    v.st.w       [s3, #0], v10
    v.st.w       [s4, #0], v1
__rctx_next:
    exit
