#!/usr/bin/env bash
set -eu
mode="$1"; m="$2"; n="$3"; k="$4"
root="$HOME/r41_current_x8_depth2_20261101"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 MAX_JOBS=1 CUDA_VISIBLE_DEVICES= HF_HUB_OFFLINE=1 HF_HOME="$HOME/r41-fp8-kern-hf"
export TNCA_TLM_BINARY="$HOME/r41_vl_reason_dp/build/tnca-chip" TNCA_TLM_CONFIG="$HOME/r41_vl_reason_dp/src/tools/performance_harness/systemc/configs/r41-mma-dp.cfg" TNCA_HOST_TIMEOUT=600
export TNCA_TLM_OUT="$HOME/r41_x8_depth2_${mode}_${m}_${n}_${k}_tlm" TNCA_X8_DEPTH2="$mode"
unset TNCA_EQUAL_ROWS TNCA_X8_SPILL_LANES TNCA_X8_PIPELINE TNCA_IEEE_DIV
cd "$root"
exec "$HOME/flux-venv/bin/python" -u tools/r41/chat_speed/bench_hoisted_fp8.py --route fused --default-div --m "$m" --n "$n" --k "$k" --v1 "$HOME/r41-fp8-kern-hf/hub/kernels--kernels-community--finegrained-fp8/snapshots/48f42b23bb4e0122d4775c6d16753dd2efc7f580" --out "$HOME/r41_x8_depth2_${mode}_${m}_${n}_${k}"
