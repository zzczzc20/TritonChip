    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.shli       s2, s4, #4                      // x16 as a shift
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s2
    v.movi       v2, #2
    .li       s4, #1069066811
    v.splat      v3, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v4, v1, v0
    .li       s4, #1060205080
    v.splat      v0, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s4, s2, #2                      // element offset -> bytes (x4)
    v.mul        v1, v4, v2
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    vf.mul       v1, v2, v3
    s.ld.d       s2, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.exp2.approx v4, v1                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v2, v3, v1                  // the exact rounding error of x*log2(e)
    vf.mul       v1, v5, v0
    s.add        s1, s2, s4                      // &out_ptr0[...]
    vf.fma       v0, v4, v1, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v0, v0
    @p1 v.sel        v1, v0, v4
    v.st.w       [s1, #0], v1
__rctx_next:
    exit
