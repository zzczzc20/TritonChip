    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s3, #49600
    s.mul        s5, s1, s3
    s.add        s1, s2, s5                      // this context's own scratch
    s.rdspecial  s2, arg_base
    s.ld.d       s3, [s2, #0]                    // x_ptr: device_ptr64 at arg_base+0
    s.ld.d       s5, [s2, #8]                    // y_ptr: device_ptr64 at arg_base+8
    s.ld.d       s6, [s2, #16]                   // s_ptr: device_ptr64 at arg_base+16
    v.iota       v0                              // arange(0, VLEN)
    v.st.w       [s1, #0], v0
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #16
    v.add        v2, v0, v1
    s.addi       s2, s1, #64
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #32
    v.add        v2, v0, v1
    s.addi       s2, s1, #128
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #48
    v.add        v2, v0, v1
    s.addi       s2, s1, #192
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #64
    v.add        v2, v0, v1
    s.addi       s2, s1, #256
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #80
    v.add        v2, v0, v1
    s.addi       s2, s1, #320
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #96
    v.add        v2, v0, v1
    s.addi       s2, s1, #384
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #112
    v.add        v2, v0, v1
    s.addi       s2, s1, #448
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #128
    v.add        v2, v0, v1
    s.addi       s2, s1, #512
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #144
    v.add        v2, v0, v1
    s.addi       s2, s1, #576
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #160
    v.add        v2, v0, v1
    s.addi       s2, s1, #640
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #176
    v.add        v2, v0, v1
    s.addi       s2, s1, #704
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #192
    v.add        v2, v0, v1
    s.addi       s2, s1, #768
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #208
    v.add        v2, v0, v1
    s.addi       s2, s1, #832
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #224
    v.add        v2, v0, v1
    s.addi       s2, s1, #896
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #240
    v.add        v2, v0, v1
    s.addi       s2, s1, #960
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #256
    v.add        v2, v0, v1
    s.addi       s2, s1, #1024
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #272
    v.add        v2, v0, v1
    s.addi       s2, s1, #1088
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #288
    v.add        v2, v0, v1
    s.addi       s2, s1, #1152
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #304
    v.add        v2, v0, v1
    s.addi       s2, s1, #1216
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #320
    v.add        v2, v0, v1
    s.addi       s2, s1, #1280
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #336
    v.add        v2, v0, v1
    s.addi       s2, s1, #1344
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #352
    v.add        v2, v0, v1
    s.addi       s2, s1, #1408
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #368
    v.add        v2, v0, v1
    s.addi       s2, s1, #1472
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #384
    v.add        v2, v0, v1
    s.addi       s2, s1, #1536
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #400
    v.add        v2, v0, v1
    s.addi       s2, s1, #1600
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #416
    v.add        v2, v0, v1
    s.addi       s2, s1, #1664
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #432
    v.add        v2, v0, v1
    s.addi       s2, s1, #1728
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #448
    v.add        v2, v0, v1
    s.addi       s2, s1, #1792
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #464
    v.add        v2, v0, v1
    s.addi       s2, s1, #1856
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #480
    v.add        v2, v0, v1
    s.addi       s2, s1, #1920
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #496
    v.add        v2, v0, v1
    s.addi       s2, s1, #1984
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #512
    v.add        v2, v0, v1
    s.addi       s2, s1, #2048
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #528
    v.add        v2, v0, v1
    s.addi       s2, s1, #2112
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #544
    v.add        v2, v0, v1
    s.addi       s2, s1, #2176
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #560
    v.add        v2, v0, v1
    s.addi       s2, s1, #2240
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #576
    v.add        v2, v0, v1
    s.addi       s2, s1, #2304
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #592
    v.add        v2, v0, v1
    s.addi       s2, s1, #2368
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #608
    v.add        v2, v0, v1
    s.addi       s2, s1, #2432
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #624
    v.add        v2, v0, v1
    s.addi       s2, s1, #2496
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #640
    v.add        v2, v0, v1
    s.addi       s2, s1, #2560
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #656
    v.add        v2, v0, v1
    s.addi       s2, s1, #2624
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #672
    v.add        v2, v0, v1
    s.addi       s2, s1, #2688
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #688
    v.add        v2, v0, v1
    s.addi       s2, s1, #2752
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #704
    v.add        v2, v0, v1
    s.addi       s2, s1, #2816
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #720
    v.add        v2, v0, v1
    s.addi       s2, s1, #2880
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #736
    v.add        v2, v0, v1
    s.addi       s2, s1, #2944
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #752
    v.add        v2, v0, v1
    s.addi       s2, s1, #3008
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #768
    v.add        v2, v0, v1
    s.addi       s2, s1, #3072
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #784
    v.add        v2, v0, v1
    s.addi       s2, s1, #3136
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #800
    v.add        v2, v0, v1
    s.addi       s2, s1, #3200
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #816
    v.add        v2, v0, v1
    s.addi       s2, s1, #3264
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #832
    v.add        v2, v0, v1
    s.addi       s2, s1, #3328
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #848
    v.add        v2, v0, v1
    s.addi       s2, s1, #3392
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #864
    v.add        v2, v0, v1
    s.addi       s2, s1, #3456
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #880
    v.add        v2, v0, v1
    s.addi       s2, s1, #3520
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #896
    v.add        v2, v0, v1
    s.addi       s2, s1, #3584
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #912
    v.add        v2, v0, v1
    s.addi       s2, s1, #3648
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #928
    v.add        v2, v0, v1
    s.addi       s2, s1, #3712
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #944
    v.add        v2, v0, v1
    s.addi       s2, s1, #3776
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #960
    v.add        v2, v0, v1
    s.addi       s2, s1, #3840
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #976
    v.add        v2, v0, v1
    s.addi       s2, s1, #3904
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #992
    v.add        v2, v0, v1
    s.addi       s2, s1, #3968
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1008
    v.add        v2, v0, v1
    s.addi       s2, s1, #4032
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1024
    v.add        v2, v0, v1
    s.addi       s2, s1, #4096
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1040
    v.add        v2, v0, v1
    s.addi       s2, s1, #4160
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1056
    v.add        v2, v0, v1
    s.addi       s2, s1, #4224
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1072
    v.add        v2, v0, v1
    s.addi       s2, s1, #4288
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1088
    v.add        v2, v0, v1
    s.addi       s2, s1, #4352
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1104
    v.add        v2, v0, v1
    s.addi       s2, s1, #4416
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1120
    v.add        v2, v0, v1
    s.addi       s2, s1, #4480
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1136
    v.add        v2, v0, v1
    s.addi       s2, s1, #4544
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1152
    v.add        v2, v0, v1
    s.addi       s2, s1, #4608
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1168
    v.add        v2, v0, v1
    s.addi       s2, s1, #4672
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1184
    v.add        v2, v0, v1
    s.addi       s2, s1, #4736
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1200
    v.add        v2, v0, v1
    s.addi       s2, s1, #4800
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1216
    v.add        v2, v0, v1
    s.addi       s2, s1, #4864
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1232
    v.add        v2, v0, v1
    s.addi       s2, s1, #4928
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1248
    v.add        v2, v0, v1
    s.addi       s2, s1, #4992
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1264
    v.add        v2, v0, v1
    s.addi       s2, s1, #5056
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1280
    v.add        v2, v0, v1
    s.addi       s2, s1, #5120
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1296
    v.add        v2, v0, v1
    s.addi       s2, s1, #5184
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1312
    v.add        v2, v0, v1
    s.addi       s2, s1, #5248
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1328
    v.add        v2, v0, v1
    s.addi       s2, s1, #5312
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1344
    v.add        v2, v0, v1
    s.addi       s2, s1, #5376
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1360
    v.add        v2, v0, v1
    s.addi       s2, s1, #5440
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1376
    v.add        v2, v0, v1
    s.addi       s2, s1, #5504
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1392
    v.add        v2, v0, v1
    s.addi       s2, s1, #5568
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1408
    v.add        v2, v0, v1
    s.addi       s2, s1, #5632
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1424
    v.add        v2, v0, v1
    s.addi       s2, s1, #5696
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1440
    v.add        v2, v0, v1
    s.addi       s2, s1, #5760
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1456
    v.add        v2, v0, v1
    s.addi       s2, s1, #5824
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1472
    v.add        v2, v0, v1
    s.addi       s2, s1, #5888
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1488
    v.add        v2, v0, v1
    s.addi       s2, s1, #5952
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1504
    v.add        v2, v0, v1
    s.addi       s2, s1, #6016
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1520
    v.add        v2, v0, v1
    s.addi       s2, s1, #6080
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1536
    v.add        v2, v0, v1
    s.addi       s2, s1, #6144
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1552
    v.add        v2, v0, v1
    s.addi       s2, s1, #6208
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1568
    v.add        v2, v0, v1
    s.addi       s2, s1, #6272
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1584
    v.add        v2, v0, v1
    s.addi       s2, s1, #6336
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1600
    v.add        v2, v0, v1
    s.addi       s2, s1, #6400
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1616
    v.add        v2, v0, v1
    s.addi       s2, s1, #6464
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1632
    v.add        v2, v0, v1
    s.addi       s2, s1, #6528
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1648
    v.add        v2, v0, v1
    s.addi       s2, s1, #6592
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1664
    v.add        v2, v0, v1
    s.addi       s2, s1, #6656
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1680
    v.add        v2, v0, v1
    s.addi       s2, s1, #6720
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1696
    v.add        v2, v0, v1
    s.addi       s2, s1, #6784
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1712
    v.add        v2, v0, v1
    s.addi       s2, s1, #6848
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1728
    v.add        v2, v0, v1
    s.addi       s2, s1, #6912
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1744
    v.add        v2, v0, v1
    s.addi       s2, s1, #6976
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1760
    v.add        v2, v0, v1
    s.addi       s2, s1, #7040
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1776
    v.add        v2, v0, v1
    s.addi       s2, s1, #7104
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1792
    v.add        v2, v0, v1
    s.addi       s2, s1, #7168
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1808
    v.add        v2, v0, v1
    s.addi       s2, s1, #7232
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1824
    v.add        v2, v0, v1
    s.addi       s2, s1, #7296
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1840
    v.add        v2, v0, v1
    s.addi       s2, s1, #7360
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1856
    v.add        v2, v0, v1
    s.addi       s2, s1, #7424
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1872
    v.add        v2, v0, v1
    s.addi       s2, s1, #7488
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1888
    v.add        v2, v0, v1
    s.addi       s2, s1, #7552
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1904
    v.add        v2, v0, v1
    s.addi       s2, s1, #7616
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1920
    v.add        v2, v0, v1
    s.addi       s2, s1, #7680
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1936
    v.add        v2, v0, v1
    s.addi       s2, s1, #7744
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1952
    v.add        v2, v0, v1
    s.addi       s2, s1, #7808
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1968
    v.add        v2, v0, v1
    s.addi       s2, s1, #7872
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1984
    v.add        v2, v0, v1
    s.addi       s2, s1, #7936
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #2000
    v.add        v2, v0, v1
    s.addi       s2, s1, #8000
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #2016
    v.add        v2, v0, v1
    s.addi       s2, s1, #8064
    v.st.w       [s2, #0], v2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #2032
    v.add        v2, v0, v1
    s.addi       s2, s1, #8128
    v.st.w       [s2, #0], v2
    s.shli       s2, s4, #11                     // x2048 as a shift
    v.splat      v0, s2
    s.addi       s7, s1, #8192
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #8256
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #8320
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #8384
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #8448
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #8512
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #8576
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #8640
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #8704
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #8768
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #8832
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #8896
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #8960
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #9024
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #9088
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #9152
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #9216
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #9280
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #9344
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #9408
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #9472
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #9536
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #9600
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #9664
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #9728
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #9792
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #9856
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #9920
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #9984
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #10048
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #10112
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #10176
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #10240
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #10304
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #10368
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #10432
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #10496
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #10560
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #10624
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #10688
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #10752
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #10816
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #10880
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #10944
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #11008
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #11072
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #11136
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #11200
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #11264
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #11328
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #11392
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #11456
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #11520
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #11584
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #11648
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #11712
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #11776
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #11840
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #11904
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #11968
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #12032
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #12096
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #12160
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #12224
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #12288
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #12352
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #12416
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #12480
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #12544
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #12608
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #12672
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #12736
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #12800
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #12864
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #12928
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #12992
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    s.addi       s7, s1, #13056
    v.st.w       [s7, #0], v0
    v.splat      v0, s2
    v.splat      v1, s2
    v.splat      v2, s2
    v.splat      v3, s2
    v.splat      v4, s2
    v.splat      v5, s2
    v.splat      v6, s2
    v.splat      v7, s2
    v.splat      v8, s2
    v.splat      v9, s2
    v.splat      v10, s2
    v.splat      v11, s2
    v.splat      v12, s2
    v.splat      v13, s2
    v.splat      v14, s2
    v.splat      v15, s2
    v.splat      v16, s2
    v.splat      v17, s2
    v.splat      v18, s2
    v.splat      v19, s2
    v.splat      v20, s2
    v.splat      v21, s2
    v.splat      v22, s2
    v.splat      v23, s2
    v.splat      v24, s2
    v.splat      v25, s2
    v.splat      v26, s2
    v.splat      v27, s2
    v.splat      v28, s2
    v.splat      v29, s2
    v.splat      v30, s2
    v.splat      v31, s2
    v.splat      v32, s2
    v.splat      v33, s2
    v.splat      v34, s2
    v.splat      v35, s2
    v.splat      v36, s2
    v.splat      v37, s2
    v.splat      v38, s2
    v.splat      v39, s2
    v.splat      v40, s2
    v.splat      v41, s2
    v.splat      v42, s2
    v.splat      v43, s2
    v.splat      v44, s2
    v.splat      v45, s2
    v.splat      v46, s2
    v.splat      v47, s2
    v.splat      v48, s2
    v.splat      v49, s2
    v.splat      v50, s2
    s.addi       s7, s1, #8192
    v.ld.w       v51, [s7, #0]
    v.ld.w       v52, [s1, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #8256
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #64
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #8320
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #128
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #8384
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #192
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #8448
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #256
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #8512
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #320
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #8576
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #384
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #8640
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #448
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #8704
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #512
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #8768
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #576
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #8832
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #640
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #8896
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #704
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #8960
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #768
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #9024
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #832
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #9088
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #896
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #9152
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #960
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #9216
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #1024
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #9280
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #1088
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #9344
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #1152
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #9408
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #1216
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #9472
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #1280
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #9536
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #1344
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #9600
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #1408
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #9664
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #1472
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #9728
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #1536
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #9792
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #1600
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #9856
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #1664
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #9920
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #1728
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #9984
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #1792
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #10048
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #1856
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #10112
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #1920
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #10176
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #1984
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #10240
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #2048
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #10304
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #2112
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #10368
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #2176
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #10432
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #2240
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #10496
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #2304
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #10560
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #2368
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #10624
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #2432
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #10688
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #2496
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #10752
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #2560
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #10816
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #2624
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #10880
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #2688
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #10944
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #2752
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #11008
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #2816
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #11072
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #2880
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #11136
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #2944
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #11200
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #3008
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #11264
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #3072
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #11328
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #3136
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #11392
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #3200
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #11456
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #3264
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #11520
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #3328
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #11584
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #3392
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #11648
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #3456
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #11712
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #3520
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #11776
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #3584
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #11840
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #3648
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #11904
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #3712
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #11968
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #3776
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #12032
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #3840
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #12096
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #3904
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #12160
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #3968
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #12224
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #4032
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #12288
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #4096
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #12352
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #4160
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #12416
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #4224
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #12480
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #4288
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #12544
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #4352
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #12608
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #4416
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #12672
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #4480
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #12736
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #4544
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #12800
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #4608
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #12864
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #4672
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #12928
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #4736
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #12992
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #4800
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #13056
    v.ld.w       v51, [s7, #0]
    s.addi       s7, s1, #4864
    v.ld.w       v52, [s7, #0]
    v.add        v53, v51, v52
    s.addi       s7, s1, #4928
    v.ld.w       v51, [s7, #0]
    v.add        v52, v0, v51
    s.addi       s7, s1, #4992
    v.ld.w       v0, [s7, #0]
    v.add        v51, v1, v0
    s.addi       s7, s1, #5056
    v.ld.w       v0, [s7, #0]
    v.add        v1, v2, v0
    s.addi       s7, s1, #5120
    v.ld.w       v0, [s7, #0]
    v.add        v1, v3, v0
    s.addi       s7, s1, #5184
    v.ld.w       v0, [s7, #0]
    v.add        v1, v4, v0
    s.addi       s7, s1, #5248
    v.ld.w       v0, [s7, #0]
    v.add        v1, v5, v0
    s.addi       s7, s1, #5312
    v.ld.w       v0, [s7, #0]
    v.add        v1, v6, v0
    s.addi       s7, s1, #5376
    v.ld.w       v0, [s7, #0]
    v.add        v1, v7, v0
    s.addi       s7, s1, #5440
    v.ld.w       v0, [s7, #0]
    v.add        v1, v8, v0
    s.addi       s7, s1, #5504
    v.ld.w       v0, [s7, #0]
    v.add        v1, v9, v0
    s.addi       s7, s1, #5568
    v.ld.w       v0, [s7, #0]
    v.add        v1, v10, v0
    s.addi       s7, s1, #5632
    v.ld.w       v0, [s7, #0]
    v.add        v1, v11, v0
    s.addi       s7, s1, #5696
    v.ld.w       v0, [s7, #0]
    v.add        v1, v12, v0
    s.addi       s7, s1, #5760
    v.ld.w       v0, [s7, #0]
    v.add        v1, v13, v0
    s.addi       s7, s1, #5824
    v.ld.w       v0, [s7, #0]
    v.add        v1, v14, v0
    s.addi       s7, s1, #5888
    v.ld.w       v0, [s7, #0]
    v.add        v1, v15, v0
    s.addi       s7, s1, #5952
    v.ld.w       v0, [s7, #0]
    v.add        v1, v16, v0
    s.addi       s7, s1, #6016
    v.ld.w       v0, [s7, #0]
    v.add        v1, v17, v0
    s.addi       s7, s1, #6080
    v.ld.w       v0, [s7, #0]
    v.add        v1, v18, v0
    s.addi       s7, s1, #6144
    v.ld.w       v0, [s7, #0]
    v.add        v1, v19, v0
    s.addi       s7, s1, #6208
    v.ld.w       v0, [s7, #0]
    v.add        v1, v20, v0
    s.addi       s7, s1, #6272
    v.ld.w       v0, [s7, #0]
    v.add        v1, v21, v0
    s.addi       s7, s1, #6336
    v.ld.w       v0, [s7, #0]
    v.add        v1, v22, v0
    s.addi       s7, s1, #6400
    v.ld.w       v0, [s7, #0]
    v.add        v1, v23, v0
    s.addi       s7, s1, #6464
    v.ld.w       v0, [s7, #0]
    v.add        v1, v24, v0
    s.addi       s7, s1, #6528
    v.ld.w       v0, [s7, #0]
    v.add        v1, v25, v0
    s.addi       s7, s1, #6592
    v.ld.w       v0, [s7, #0]
    v.add        v1, v26, v0
    s.addi       s7, s1, #6656
    v.ld.w       v0, [s7, #0]
    v.add        v1, v27, v0
    s.addi       s7, s1, #6720
    v.ld.w       v0, [s7, #0]
    v.add        v1, v28, v0
    s.addi       s7, s1, #6784
    v.ld.w       v0, [s7, #0]
    v.add        v1, v29, v0
    s.addi       s7, s1, #6848
    v.ld.w       v0, [s7, #0]
    v.add        v1, v30, v0
    s.addi       s7, s1, #6912
    v.ld.w       v0, [s7, #0]
    v.add        v1, v31, v0
    s.addi       s7, s1, #6976
    v.ld.w       v0, [s7, #0]
    v.add        v1, v32, v0
    s.addi       s7, s1, #7040
    v.ld.w       v0, [s7, #0]
    v.add        v1, v33, v0
    s.addi       s7, s1, #7104
    v.ld.w       v0, [s7, #0]
    v.add        v1, v34, v0
    s.addi       s7, s1, #7168
    v.ld.w       v0, [s7, #0]
    v.add        v1, v35, v0
    s.addi       s7, s1, #7232
    v.ld.w       v0, [s7, #0]
    v.add        v1, v36, v0
    s.addi       s7, s1, #7296
    v.ld.w       v0, [s7, #0]
    v.add        v1, v37, v0
    s.addi       s7, s1, #7360
    v.ld.w       v0, [s7, #0]
    v.add        v1, v38, v0
    s.addi       s7, s1, #7424
    v.ld.w       v0, [s7, #0]
    v.add        v1, v39, v0
    s.addi       s7, s1, #7488
    v.ld.w       v0, [s7, #0]
    v.add        v1, v40, v0
    s.addi       s7, s1, #7552
    v.ld.w       v0, [s7, #0]
    v.add        v1, v41, v0
    s.addi       s7, s1, #7616
    v.ld.w       v0, [s7, #0]
    v.add        v1, v42, v0
    s.addi       s7, s1, #7680
    v.ld.w       v0, [s7, #0]
    v.add        v1, v43, v0
    s.addi       s7, s1, #7744
    v.ld.w       v0, [s7, #0]
    v.add        v1, v44, v0
    s.addi       s7, s1, #7808
    v.ld.w       v0, [s7, #0]
    v.add        v1, v45, v0
    s.addi       s7, s1, #7872
    v.ld.w       v0, [s7, #0]
    v.add        v1, v46, v0
    s.addi       s7, s1, #7936
    v.ld.w       v0, [s7, #0]
    v.add        v1, v47, v0
    s.addi       s7, s1, #8000
    v.ld.w       v0, [s7, #0]
    v.add        v1, v48, v0
    s.addi       s7, s1, #8064
    v.ld.w       v0, [s7, #0]
    v.add        v1, v49, v0
    s.addi       s7, s1, #8128
    v.ld.w       v0, [s7, #0]
    v.add        v1, v50, v0
    v.movi       v0, #2048
    s.addi       s7, s1, #13120
    v.st.w       [s7, #0], v0
    v.ld.w       v0, [s1, #0]
    s.addi       s7, s1, #13120
    v.ld.w       v1, [s7, #0]
    v.cmp.lt     p1, v0, v1
    s.shli       s7, s2, #1                      // element offset -> bytes (x2)
    s.add        s8, s3, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s8, #0]
    s.addi       s8, s1, #13184
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #13248
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #64
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #13248
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #32                     // &x_ptr[16] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #13312
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #13376
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #128
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #13376
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #64                     // &x_ptr[32] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #13440
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #13504
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #192
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #13504
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #96                     // &x_ptr[48] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #13568
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #13632
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #256
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #13632
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #128                    // &x_ptr[64] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #13696
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #13760
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #320
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #13760
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #160                    // &x_ptr[80] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #13824
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #13888
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #384
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #13888
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #192                    // &x_ptr[96] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #13952
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #14016
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #448
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #14016
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #224                    // &x_ptr[112] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #14080
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #14144
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #512
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #14144
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #256                    // &x_ptr[128] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #14208
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #14272
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #576
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #14272
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #288                    // &x_ptr[144] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #14336
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #14400
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #640
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #14400
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #320                    // &x_ptr[160] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #14464
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #14528
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #704
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #14528
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #352                    // &x_ptr[176] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #14592
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #14656
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #768
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #14656
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #384                    // &x_ptr[192] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #14720
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #14784
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #832
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #14784
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #416                    // &x_ptr[208] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #14848
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #14912
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #896
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #14912
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #448                    // &x_ptr[224] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #14976
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #15040
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #960
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #15040
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #480                    // &x_ptr[240] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #15104
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #15168
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #1024
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #15168
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #512                    // &x_ptr[256] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #15232
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #15296
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #1088
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #15296
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #544                    // &x_ptr[272] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #15360
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #15424
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #1152
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #15424
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #576                    // &x_ptr[288] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #15488
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #15552
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #1216
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #15552
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #608                    // &x_ptr[304] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #15616
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #15680
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #1280
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #15680
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #640                    // &x_ptr[320] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #15744
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #15808
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #1344
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #15808
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #672                    // &x_ptr[336] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #15872
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #15936
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #1408
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #15936
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #704                    // &x_ptr[352] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #16000
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #16064
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #1472
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #16064
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #736                    // &x_ptr[368] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #16128
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #16192
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #1536
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #16192
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #768                    // &x_ptr[384] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #16256
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #16320
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #1600
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #16320
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #800                    // &x_ptr[400] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #16384
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #16448
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #1664
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #16448
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #832                    // &x_ptr[416] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #16512
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #16576
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #1728
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #16576
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #864                    // &x_ptr[432] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #16640
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #16704
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #1792
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #16704
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #896                    // &x_ptr[448] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #16768
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #16832
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #1856
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #16832
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #928                    // &x_ptr[464] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #16896
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #16960
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #1920
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #16960
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #960                    // &x_ptr[480] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #17024
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #17088
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #1984
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #17088
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #992                    // &x_ptr[496] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #17152
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #17216
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #2048
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #17216
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1024                   // &x_ptr[512] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #17280
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #17344
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #2112
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #17344
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1056                   // &x_ptr[528] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #17408
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #17472
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #2176
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #17472
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1088                   // &x_ptr[544] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #17536
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #17600
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #2240
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #17600
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1120                   // &x_ptr[560] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #17664
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #17728
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #2304
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #17728
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1152                   // &x_ptr[576] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #17792
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #17856
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #2368
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #17856
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1184                   // &x_ptr[592] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #17920
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #17984
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #2432
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #17984
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1216                   // &x_ptr[608] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #18048
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #18112
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #2496
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #18112
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1248                   // &x_ptr[624] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #18176
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #18240
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #2560
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #18240
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1280                   // &x_ptr[640] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #18304
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #18368
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #2624
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #18368
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1312                   // &x_ptr[656] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #18432
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #18496
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #2688
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #18496
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1344                   // &x_ptr[672] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #18560
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #18624
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #2752
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #18624
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1376                   // &x_ptr[688] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #18688
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #18752
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #2816
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #18752
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1408                   // &x_ptr[704] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #18816
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #18880
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #2880
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #18880
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1440                   // &x_ptr[720] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #18944
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #19008
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #2944
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #19008
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1472                   // &x_ptr[736] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #19072
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #19136
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #3008
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #19136
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1504                   // &x_ptr[752] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #19200
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #19264
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #3072
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #19264
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1536                   // &x_ptr[768] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #19328
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #19392
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #3136
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #19392
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1568                   // &x_ptr[784] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #19456
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #19520
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #3200
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #19520
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1600                   // &x_ptr[800] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #19584
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #19648
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #3264
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #19648
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1632                   // &x_ptr[816] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #19712
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #19776
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #3328
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #19776
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1664                   // &x_ptr[832] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #19840
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #19904
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #3392
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #19904
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1696                   // &x_ptr[848] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #19968
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #20032
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #3456
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #20032
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1728                   // &x_ptr[864] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #20096
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #20160
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #3520
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #20160
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1760                   // &x_ptr[880] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #20224
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #20288
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #3584
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #20288
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1792                   // &x_ptr[896] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #20352
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #20416
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #3648
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #20416
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1824                   // &x_ptr[912] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #20480
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #20544
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #3712
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #20544
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1856                   // &x_ptr[928] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #20608
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #20672
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #3776
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #20672
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1888                   // &x_ptr[944] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #20736
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #20800
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #3840
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #20800
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1920                   // &x_ptr[960] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #20864
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #20928
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #3904
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #20928
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1952                   // &x_ptr[976] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #20992
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #21056
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #3968
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #21056
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #1984                   // &x_ptr[992] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #21120
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #21184
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #4032
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #21184
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #2016                   // &x_ptr[1008] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #21248
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #21312
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #4096
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #21312
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #2048                   // &x_ptr[1024] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #21376
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #21440
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #4160
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #21440
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #2080                   // &x_ptr[1040] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #21504
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #21568
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #4224
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #21568
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #2112                   // &x_ptr[1056] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #21632
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #21696
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #4288
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #21696
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #2144                   // &x_ptr[1072] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #21760
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #21824
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #4352
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #21824
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #2176                   // &x_ptr[1088] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #21888
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #21952
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #4416
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #21952
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #2208                   // &x_ptr[1104] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #22016
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #22080
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #4480
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #22080
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #2240                   // &x_ptr[1120] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #22144
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #22208
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #4544
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #22208
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #2272                   // &x_ptr[1136] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #22272
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #22336
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #4608
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #22336
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #2304                   // &x_ptr[1152] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #22400
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #22464
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #4672
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #22464
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #2336                   // &x_ptr[1168] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #22528
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #22592
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #4736
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #22592
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #2368                   // &x_ptr[1184] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #22656
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #22720
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #4800
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #22720
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #2400                   // &x_ptr[1200] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    s.addi       s8, s1, #22784
    v.st.w       [s8, #0], v0
    v.movi       v0, #2048
    s.addi       s8, s1, #22848
    v.st.w       [s8, #0], v0
    s.addi       s8, s1, #4864
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s1, #22848
    v.ld.w       v1, [s8, #0]
    v.cmp.lt     p1, v0, v1
    s.addi       s8, s3, #2432                   // &x_ptr[1216] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s9, #0]
    v.movi       v1, #2048
    s.addi       s8, s1, #22912
    v.st.w       [s8, #0], v1
    s.addi       s8, s1, #4928
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s1, #22912
    v.ld.w       v2, [s8, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s8, s3, #2464                   // &x_ptr[1232] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s9, #0]
    v.movi       v2, #2048
    s.addi       s8, s1, #22976
    v.st.w       [s8, #0], v2
    s.addi       s8, s1, #4992
    v.ld.w       v2, [s8, #0]
    s.addi       s8, s1, #22976
    v.ld.w       v3, [s8, #0]
    v.cmp.lt     p1, v2, v3
    s.addi       s8, s3, #2496                   // &x_ptr[1248] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v2, [s9, #0]
    v.movi       v3, #2048
    s.addi       s8, s1, #23040
    v.st.w       [s8, #0], v3
    s.addi       s8, s1, #5056
    v.ld.w       v3, [s8, #0]
    s.addi       s8, s1, #23040
    v.ld.w       v4, [s8, #0]
    v.cmp.lt     p1, v3, v4
    s.addi       s8, s3, #2528                   // &x_ptr[1264] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v3, [s9, #0]
    v.movi       v4, #2048
    s.addi       s8, s1, #23104
    v.st.w       [s8, #0], v4
    s.addi       s8, s1, #5120
    v.ld.w       v4, [s8, #0]
    s.addi       s8, s1, #23104
    v.ld.w       v5, [s8, #0]
    v.cmp.lt     p1, v4, v5
    s.addi       s8, s3, #2560                   // &x_ptr[1280] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s9, #0]
    v.movi       v5, #2048
    s.addi       s8, s1, #23168
    v.st.w       [s8, #0], v5
    s.addi       s8, s1, #5184
    v.ld.w       v5, [s8, #0]
    s.addi       s8, s1, #23168
    v.ld.w       v6, [s8, #0]
    v.cmp.lt     p1, v5, v6
    s.addi       s8, s3, #2592                   // &x_ptr[1296] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v5, [s9, #0]
    v.movi       v6, #2048
    s.addi       s8, s1, #23232
    v.st.w       [s8, #0], v6
    s.addi       s8, s1, #5248
    v.ld.w       v6, [s8, #0]
    s.addi       s8, s1, #23232
    v.ld.w       v7, [s8, #0]
    v.cmp.lt     p1, v6, v7
    s.addi       s8, s3, #2624                   // &x_ptr[1312] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v6, [s9, #0]
    v.movi       v7, #2048
    s.addi       s8, s1, #23296
    v.st.w       [s8, #0], v7
    s.addi       s8, s1, #5312
    v.ld.w       v7, [s8, #0]
    s.addi       s8, s1, #23296
    v.ld.w       v8, [s8, #0]
    v.cmp.lt     p1, v7, v8
    s.addi       s8, s3, #2656                   // &x_ptr[1328] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v7, [s9, #0]
    v.movi       v8, #2048
    s.addi       s8, s1, #23360
    v.st.w       [s8, #0], v8
    s.addi       s8, s1, #5376
    v.ld.w       v8, [s8, #0]
    s.addi       s8, s1, #23360
    v.ld.w       v9, [s8, #0]
    v.cmp.lt     p1, v8, v9
    s.addi       s8, s3, #2688                   // &x_ptr[1344] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v8, [s9, #0]
    v.movi       v9, #2048
    s.addi       s8, s1, #23424
    v.st.w       [s8, #0], v9
    s.addi       s8, s1, #5440
    v.ld.w       v9, [s8, #0]
    s.addi       s8, s1, #23424
    v.ld.w       v10, [s8, #0]
    v.cmp.lt     p1, v9, v10
    s.addi       s8, s3, #2720                   // &x_ptr[1360] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v9, [s9, #0]
    v.movi       v10, #2048
    s.addi       s8, s1, #23488
    v.st.w       [s8, #0], v10
    s.addi       s8, s1, #5504
    v.ld.w       v10, [s8, #0]
    s.addi       s8, s1, #23488
    v.ld.w       v11, [s8, #0]
    v.cmp.lt     p1, v10, v11
    s.addi       s8, s3, #2752                   // &x_ptr[1376] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v10, [s9, #0]
    v.movi       v11, #2048
    s.addi       s8, s1, #23552
    v.st.w       [s8, #0], v11
    s.addi       s8, s1, #5568
    v.ld.w       v11, [s8, #0]
    s.addi       s8, s1, #23552
    v.ld.w       v12, [s8, #0]
    v.cmp.lt     p1, v11, v12
    s.addi       s8, s3, #2784                   // &x_ptr[1392] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v11, [s9, #0]
    v.movi       v12, #2048
    s.addi       s8, s1, #23616
    v.st.w       [s8, #0], v12
    s.addi       s8, s1, #5632
    v.ld.w       v12, [s8, #0]
    s.addi       s8, s1, #23616
    v.ld.w       v13, [s8, #0]
    v.cmp.lt     p1, v12, v13
    s.addi       s8, s3, #2816                   // &x_ptr[1408] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s9, #0]
    v.movi       v13, #2048
    s.addi       s8, s1, #23680
    v.st.w       [s8, #0], v13
    s.addi       s8, s1, #5696
    v.ld.w       v13, [s8, #0]
    s.addi       s8, s1, #23680
    v.ld.w       v14, [s8, #0]
    v.cmp.lt     p1, v13, v14
    s.addi       s8, s3, #2848                   // &x_ptr[1424] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s9, #0]
    v.movi       v14, #2048
    s.addi       s8, s1, #23744
    v.st.w       [s8, #0], v14
    s.addi       s8, s1, #5760
    v.ld.w       v14, [s8, #0]
    s.addi       s8, s1, #23744
    v.ld.w       v15, [s8, #0]
    v.cmp.lt     p1, v14, v15
    s.addi       s8, s3, #2880                   // &x_ptr[1440] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s9, #0]
    v.movi       v15, #2048
    s.addi       s8, s1, #23808
    v.st.w       [s8, #0], v15
    s.addi       s8, s1, #5824
    v.ld.w       v15, [s8, #0]
    s.addi       s8, s1, #23808
    v.ld.w       v16, [s8, #0]
    v.cmp.lt     p1, v15, v16
    s.addi       s8, s3, #2912                   // &x_ptr[1456] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v15, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v15, [s9, #0]
    v.movi       v16, #2048
    s.addi       s8, s1, #23872
    v.st.w       [s8, #0], v16
    s.addi       s8, s1, #5888
    v.ld.w       v16, [s8, #0]
    s.addi       s8, s1, #23872
    v.ld.w       v17, [s8, #0]
    v.cmp.lt     p1, v16, v17
    s.addi       s8, s3, #2944                   // &x_ptr[1472] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s9, #0]
    v.movi       v17, #2048
    s.addi       s8, s1, #23936
    v.st.w       [s8, #0], v17
    s.addi       s8, s1, #5952
    v.ld.w       v17, [s8, #0]
    s.addi       s8, s1, #23936
    v.ld.w       v18, [s8, #0]
    v.cmp.lt     p1, v17, v18
    s.addi       s8, s3, #2976                   // &x_ptr[1488] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s9, #0]
    v.movi       v18, #2048
    s.addi       s8, s1, #24000
    v.st.w       [s8, #0], v18
    s.addi       s8, s1, #6016
    v.ld.w       v18, [s8, #0]
    s.addi       s8, s1, #24000
    v.ld.w       v19, [s8, #0]
    v.cmp.lt     p1, v18, v19
    s.addi       s8, s3, #3008                   // &x_ptr[1504] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v18, [s9, #0]
    v.movi       v19, #2048
    s.addi       s8, s1, #24064
    v.st.w       [s8, #0], v19
    s.addi       s8, s1, #6080
    v.ld.w       v19, [s8, #0]
    s.addi       s8, s1, #24064
    v.ld.w       v20, [s8, #0]
    v.cmp.lt     p1, v19, v20
    s.addi       s8, s3, #3040                   // &x_ptr[1520] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v19, [s9, #0]
    v.movi       v20, #2048
    s.addi       s8, s1, #24128
    v.st.w       [s8, #0], v20
    s.addi       s8, s1, #6144
    v.ld.w       v20, [s8, #0]
    s.addi       s8, s1, #24128
    v.ld.w       v21, [s8, #0]
    v.cmp.lt     p1, v20, v21
    s.addi       s8, s3, #3072                   // &x_ptr[1536] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v20, [s9, #0]
    v.movi       v21, #2048
    s.addi       s8, s1, #24192
    v.st.w       [s8, #0], v21
    s.addi       s8, s1, #6208
    v.ld.w       v21, [s8, #0]
    s.addi       s8, s1, #24192
    v.ld.w       v22, [s8, #0]
    v.cmp.lt     p1, v21, v22
    s.addi       s8, s3, #3104                   // &x_ptr[1552] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v21, [s9, #0]
    v.movi       v22, #2048
    s.addi       s8, s1, #24256
    v.st.w       [s8, #0], v22
    s.addi       s8, s1, #6272
    v.ld.w       v22, [s8, #0]
    s.addi       s8, s1, #24256
    v.ld.w       v23, [s8, #0]
    v.cmp.lt     p1, v22, v23
    s.addi       s8, s3, #3136                   // &x_ptr[1568] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v22, [s9, #0]
    v.movi       v23, #2048
    s.addi       s8, s1, #24320
    v.st.w       [s8, #0], v23
    s.addi       s8, s1, #6336
    v.ld.w       v23, [s8, #0]
    s.addi       s8, s1, #24320
    v.ld.w       v24, [s8, #0]
    v.cmp.lt     p1, v23, v24
    s.addi       s8, s3, #3168                   // &x_ptr[1584] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v23, [s9, #0]
    v.movi       v24, #2048
    s.addi       s8, s1, #24384
    v.st.w       [s8, #0], v24
    s.addi       s8, s1, #6400
    v.ld.w       v24, [s8, #0]
    s.addi       s8, s1, #24384
    v.ld.w       v25, [s8, #0]
    v.cmp.lt     p1, v24, v25
    s.addi       s8, s3, #3200                   // &x_ptr[1600] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v24, [s9, #0]
    v.movi       v25, #2048
    s.addi       s8, s1, #24448
    v.st.w       [s8, #0], v25
    s.addi       s8, s1, #6464
    v.ld.w       v25, [s8, #0]
    s.addi       s8, s1, #24448
    v.ld.w       v26, [s8, #0]
    v.cmp.lt     p1, v25, v26
    s.addi       s8, s3, #3232                   // &x_ptr[1616] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v25, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v25, [s9, #0]
    v.movi       v26, #2048
    s.addi       s8, s1, #24512
    v.st.w       [s8, #0], v26
    s.addi       s8, s1, #6528
    v.ld.w       v26, [s8, #0]
    s.addi       s8, s1, #24512
    v.ld.w       v27, [s8, #0]
    v.cmp.lt     p1, v26, v27
    s.addi       s8, s3, #3264                   // &x_ptr[1632] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v26, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v26, [s9, #0]
    v.movi       v27, #2048
    s.addi       s8, s1, #24576
    v.st.w       [s8, #0], v27
    s.addi       s8, s1, #6592
    v.ld.w       v27, [s8, #0]
    s.addi       s8, s1, #24576
    v.ld.w       v28, [s8, #0]
    v.cmp.lt     p1, v27, v28
    s.addi       s8, s3, #3296                   // &x_ptr[1648] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v27, [s9, #0]
    v.movi       v28, #2048
    s.addi       s8, s1, #24640
    v.st.w       [s8, #0], v28
    s.addi       s8, s1, #6656
    v.ld.w       v28, [s8, #0]
    s.addi       s8, s1, #24640
    v.ld.w       v29, [s8, #0]
    v.cmp.lt     p1, v28, v29
    s.addi       s8, s3, #3328                   // &x_ptr[1664] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v28, [s9, #0]
    v.movi       v29, #2048
    s.addi       s8, s1, #24704
    v.st.w       [s8, #0], v29
    s.addi       s8, s1, #6720
    v.ld.w       v29, [s8, #0]
    s.addi       s8, s1, #24704
    v.ld.w       v30, [s8, #0]
    v.cmp.lt     p1, v29, v30
    s.addi       s8, s3, #3360                   // &x_ptr[1680] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v29, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v29, [s9, #0]
    v.movi       v30, #2048
    s.addi       s8, s1, #24768
    v.st.w       [s8, #0], v30
    s.addi       s8, s1, #6784
    v.ld.w       v30, [s8, #0]
    s.addi       s8, s1, #24768
    v.ld.w       v31, [s8, #0]
    v.cmp.lt     p1, v30, v31
    s.addi       s8, s3, #3392                   // &x_ptr[1696] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v30, [s9, #0]
    v.movi       v31, #2048
    s.addi       s8, s1, #24832
    v.st.w       [s8, #0], v31
    s.addi       s8, s1, #6848
    v.ld.w       v31, [s8, #0]
    s.addi       s8, s1, #24832
    v.ld.w       v32, [s8, #0]
    v.cmp.lt     p1, v31, v32
    s.addi       s8, s3, #3424                   // &x_ptr[1712] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v31, [s9, #0]
    v.movi       v32, #2048
    s.addi       s8, s1, #24896
    v.st.w       [s8, #0], v32
    s.addi       s8, s1, #6912
    v.ld.w       v32, [s8, #0]
    s.addi       s8, s1, #24896
    v.ld.w       v33, [s8, #0]
    v.cmp.lt     p1, v32, v33
    s.addi       s8, s3, #3456                   // &x_ptr[1728] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v32, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v32, [s9, #0]
    v.movi       v33, #2048
    s.addi       s8, s1, #24960
    v.st.w       [s8, #0], v33
    s.addi       s8, s1, #6976
    v.ld.w       v33, [s8, #0]
    s.addi       s8, s1, #24960
    v.ld.w       v34, [s8, #0]
    v.cmp.lt     p1, v33, v34
    s.addi       s8, s3, #3488                   // &x_ptr[1744] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v33, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v33, [s9, #0]
    v.movi       v34, #2048
    s.addi       s8, s1, #25024
    v.st.w       [s8, #0], v34
    s.addi       s8, s1, #7040
    v.ld.w       v34, [s8, #0]
    s.addi       s8, s1, #25024
    v.ld.w       v35, [s8, #0]
    v.cmp.lt     p1, v34, v35
    s.addi       s8, s3, #3520                   // &x_ptr[1760] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v34, [s9, #0]
    v.movi       v35, #2048
    s.addi       s8, s1, #25088
    v.st.w       [s8, #0], v35
    s.addi       s8, s1, #7104
    v.ld.w       v35, [s8, #0]
    s.addi       s8, s1, #25088
    v.ld.w       v36, [s8, #0]
    v.cmp.lt     p1, v35, v36
    s.addi       s8, s3, #3552                   // &x_ptr[1776] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v35, [s9, #0]
    v.movi       v36, #2048
    s.addi       s8, s1, #25152
    v.st.w       [s8, #0], v36
    s.addi       s8, s1, #7168
    v.ld.w       v36, [s8, #0]
    s.addi       s8, s1, #25152
    v.ld.w       v37, [s8, #0]
    v.cmp.lt     p1, v36, v37
    s.addi       s8, s3, #3584                   // &x_ptr[1792] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v36, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v36, [s9, #0]
    v.movi       v37, #2048
    s.addi       s8, s1, #25216
    v.st.w       [s8, #0], v37
    s.addi       s8, s1, #7232
    v.ld.w       v37, [s8, #0]
    s.addi       s8, s1, #25216
    v.ld.w       v38, [s8, #0]
    v.cmp.lt     p1, v37, v38
    s.addi       s8, s3, #3616                   // &x_ptr[1808] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v37, [s9, #0]
    v.movi       v38, #2048
    s.addi       s8, s1, #25280
    v.st.w       [s8, #0], v38
    s.addi       s8, s1, #7296
    v.ld.w       v38, [s8, #0]
    s.addi       s8, s1, #25280
    v.ld.w       v39, [s8, #0]
    v.cmp.lt     p1, v38, v39
    s.addi       s8, s3, #3648                   // &x_ptr[1824] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s9, #0]
    v.movi       v39, #2048
    s.addi       s8, s1, #25344
    v.st.w       [s8, #0], v39
    s.addi       s8, s1, #7360
    v.ld.w       v39, [s8, #0]
    s.addi       s8, s1, #25344
    v.ld.w       v40, [s8, #0]
    v.cmp.lt     p1, v39, v40
    s.addi       s8, s3, #3680                   // &x_ptr[1840] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v39, [s9, #0]
    v.movi       v40, #2048
    s.addi       s8, s1, #25408
    v.st.w       [s8, #0], v40
    s.addi       s8, s1, #7424
    v.ld.w       v40, [s8, #0]
    s.addi       s8, s1, #25408
    v.ld.w       v41, [s8, #0]
    v.cmp.lt     p1, v40, v41
    s.addi       s8, s3, #3712                   // &x_ptr[1856] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v40, [s9, #0]
    v.movi       v41, #2048
    s.addi       s8, s1, #25472
    v.st.w       [s8, #0], v41
    s.addi       s8, s1, #7488
    v.ld.w       v41, [s8, #0]
    s.addi       s8, s1, #25472
    v.ld.w       v42, [s8, #0]
    v.cmp.lt     p1, v41, v42
    s.addi       s8, s3, #3744                   // &x_ptr[1872] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s9, #0]
    v.movi       v42, #2048
    s.addi       s8, s1, #25536
    v.st.w       [s8, #0], v42
    s.addi       s8, s1, #7552
    v.ld.w       v42, [s8, #0]
    s.addi       s8, s1, #25536
    v.ld.w       v43, [s8, #0]
    v.cmp.lt     p1, v42, v43
    s.addi       s8, s3, #3776                   // &x_ptr[1888] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s9, #0]
    v.movi       v43, #2048
    s.addi       s8, s1, #25600
    v.st.w       [s8, #0], v43
    s.addi       s8, s1, #7616
    v.ld.w       v43, [s8, #0]
    s.addi       s8, s1, #25600
    v.ld.w       v44, [s8, #0]
    v.cmp.lt     p1, v43, v44
    s.addi       s8, s3, #3808                   // &x_ptr[1904] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v43, [s9, #0]
    v.movi       v44, #2048
    s.addi       s8, s1, #25664
    v.st.w       [s8, #0], v44
    s.addi       s8, s1, #7680
    v.ld.w       v44, [s8, #0]
    s.addi       s8, s1, #25664
    v.ld.w       v45, [s8, #0]
    v.cmp.lt     p1, v44, v45
    s.addi       s8, s3, #3840                   // &x_ptr[1920] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v44, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v44, [s9, #0]
    v.movi       v45, #2048
    s.addi       s8, s1, #25728
    v.st.w       [s8, #0], v45
    s.addi       s8, s1, #7744
    v.ld.w       v45, [s8, #0]
    s.addi       s8, s1, #25728
    v.ld.w       v46, [s8, #0]
    v.cmp.lt     p1, v45, v46
    s.addi       s8, s3, #3872                   // &x_ptr[1936] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v45, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v45, [s9, #0]
    v.movi       v46, #2048
    s.addi       s8, s1, #25792
    v.st.w       [s8, #0], v46
    s.addi       s8, s1, #7808
    v.ld.w       v46, [s8, #0]
    s.addi       s8, s1, #25792
    v.ld.w       v47, [s8, #0]
    v.cmp.lt     p1, v46, v47
    s.addi       s8, s3, #3904                   // &x_ptr[1952] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v46, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v46, [s9, #0]
    v.movi       v47, #2048
    s.addi       s8, s1, #25856
    v.st.w       [s8, #0], v47
    s.addi       s8, s1, #7872
    v.ld.w       v47, [s8, #0]
    s.addi       s8, s1, #25856
    v.ld.w       v48, [s8, #0]
    v.cmp.lt     p1, v47, v48
    s.addi       s8, s3, #3936                   // &x_ptr[1968] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v47, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v47, [s9, #0]
    v.movi       v48, #2048
    s.addi       s8, s1, #25920
    v.st.w       [s8, #0], v48
    s.addi       s8, s1, #7936
    v.ld.w       v48, [s8, #0]
    s.addi       s8, s1, #25920
    v.ld.w       v49, [s8, #0]
    v.cmp.lt     p1, v48, v49
    s.addi       s8, s3, #3968                   // &x_ptr[1984] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v48, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v48, [s9, #0]
    v.movi       v49, #2048
    s.addi       s8, s1, #25984
    v.st.w       [s8, #0], v49
    s.addi       s8, s1, #8000
    v.ld.w       v49, [s8, #0]
    s.addi       s8, s1, #25984
    v.ld.w       v50, [s8, #0]
    v.cmp.lt     p1, v49, v50
    s.addi       s8, s3, #4000                   // &x_ptr[2000] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v49, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v49, [s9, #0]
    v.movi       v50, #2048
    s.addi       s8, s1, #26048
    v.st.w       [s8, #0], v50
    s.addi       s8, s1, #8064
    v.ld.w       v50, [s8, #0]
    s.addi       s8, s1, #26048
    v.ld.w       v51, [s8, #0]
    v.cmp.lt     p1, v50, v51
    s.addi       s8, s3, #4032                   // &x_ptr[2016] (a constant offset, x2)
    s.add        s9, s8, s7                      // &x_ptr[...]
    v.movi       v50, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v50, [s9, #0]
    v.movi       v51, #2048
    s.addi       s8, s1, #26112
    v.st.w       [s8, #0], v51
    s.addi       s8, s1, #8128
    v.ld.w       v51, [s8, #0]
    s.addi       s8, s1, #26112
    v.ld.w       v52, [s8, #0]
    v.cmp.lt     p1, v51, v52
    s.addi       s8, s3, #4064                   // &x_ptr[2032] (a constant offset, x2)
    s.add        s3, s8, s7                      // &x_ptr[...]
    v.movi       v51, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v51, [s3, #0]
    s.addi       s3, s1, #13184
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #26176
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #13312
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #26240
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #13440
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #26304
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #13568
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #26368
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #13696
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #26432
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #13824
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #26496
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #13952
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #26560
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #14080
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #26624
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #14208
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #26688
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #14336
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #26752
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #14464
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #26816
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #14592
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #26880
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #14720
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #26944
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #14848
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #27008
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #14976
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #27072
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #15104
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #27136
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #15232
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #27200
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #15360
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #27264
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #15488
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #27328
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #15616
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #27392
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #15744
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #27456
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #15872
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #27520
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #16000
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #27584
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #16128
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #27648
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #16256
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #27712
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #16384
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #27776
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #16512
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #27840
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #16640
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #27904
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #16768
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #27968
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #16896
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #28032
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #17024
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #28096
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #17152
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #28160
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #17280
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #28224
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #17408
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #28288
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #17536
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #28352
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #17664
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #28416
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #17792
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #28480
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #17920
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #28544
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #18048
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #28608
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #18176
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #28672
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #18304
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #28736
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #18432
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #28800
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #18560
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #28864
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #18688
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #28928
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #18816
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #28992
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #18944
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #29056
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #19072
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #29120
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #19200
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #29184
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #19328
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #29248
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #19456
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #29312
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #19584
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #29376
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #19712
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #29440
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #19840
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #29504
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #19968
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #29568
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #20096
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #29632
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #20224
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #29696
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #20352
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #29760
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #20480
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #29824
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #20608
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #29888
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #20736
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #29952
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #20864
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #30016
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #20992
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #30080
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #21120
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #30144
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #21248
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #30208
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #21376
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #30272
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #21504
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #30336
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #21632
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #30400
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #21760
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #30464
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #21888
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #30528
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #22016
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #30592
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #22144
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #30656
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #22272
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #30720
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #22400
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #30784
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #22528
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #30848
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #22656
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #30912
    v.st.w       [s3, #0], v53
    s.addi       s3, s1, #22784
    v.ld.w       v52, [s3, #0]
    vf.cvt.bf16.f32 v53, v52
    s.addi       s3, s1, #30976
    v.st.w       [s3, #0], v53
    vf.cvt.bf16.f32 v52, v0
    s.addi       s3, s1, #31040
    v.st.w       [s3, #0], v52
    vf.cvt.bf16.f32 v0, v1
    s.addi       s3, s1, #31104
    v.st.w       [s3, #0], v0
    vf.cvt.bf16.f32 v0, v2
    s.addi       s3, s1, #31168
    v.st.w       [s3, #0], v0
    vf.cvt.bf16.f32 v0, v3
    s.addi       s3, s1, #31232
    v.st.w       [s3, #0], v0
    vf.cvt.bf16.f32 v0, v4
    s.addi       s3, s1, #31296
    v.st.w       [s3, #0], v0
    vf.cvt.bf16.f32 v0, v5
    s.addi       s3, s1, #31360
    v.st.w       [s3, #0], v0
    vf.cvt.bf16.f32 v0, v6
    s.addi       s3, s1, #31424
    v.st.w       [s3, #0], v0
    vf.cvt.bf16.f32 v0, v7
    s.addi       s3, s1, #31488
    v.st.w       [s3, #0], v0
    vf.cvt.bf16.f32 v0, v8
    s.addi       s3, s1, #31552
    v.st.w       [s3, #0], v0
    vf.cvt.bf16.f32 v0, v9
    s.addi       s3, s1, #31616
    v.st.w       [s3, #0], v0
    vf.cvt.bf16.f32 v0, v10
    s.addi       s3, s1, #31680
    v.st.w       [s3, #0], v0
    vf.cvt.bf16.f32 v0, v11
    s.addi       s3, s1, #31744
    v.st.w       [s3, #0], v0
    vf.cvt.bf16.f32 v0, v12
    s.addi       s3, s1, #31808
    v.st.w       [s3, #0], v0
    vf.cvt.bf16.f32 v0, v13
    s.addi       s3, s1, #31872
    v.st.w       [s3, #0], v0
    vf.cvt.bf16.f32 v0, v14
    s.addi       s3, s1, #31936
    v.st.w       [s3, #0], v0
    vf.cvt.bf16.f32 v0, v15
    s.addi       s3, s1, #32000
    v.st.w       [s3, #0], v0
    vf.cvt.bf16.f32 v0, v16
    s.addi       s3, s1, #32064
    v.st.w       [s3, #0], v0
    vf.cvt.bf16.f32 v0, v17
    s.addi       s3, s1, #32128
    v.st.w       [s3, #0], v0
    vf.cvt.bf16.f32 v0, v18
    s.addi       s3, s1, #32192
    v.st.w       [s3, #0], v0
    vf.cvt.bf16.f32 v0, v19
    s.addi       s3, s1, #32256
    v.st.w       [s3, #0], v0
    vf.cvt.bf16.f32 v0, v20
    s.addi       s3, s1, #32320
    v.st.w       [s3, #0], v0
    vf.cvt.bf16.f32 v0, v21
    s.addi       s3, s1, #32384
    v.st.w       [s3, #0], v0
    vf.cvt.bf16.f32 v0, v22
    s.addi       s3, s1, #32448
    v.st.w       [s3, #0], v0
    vf.cvt.bf16.f32 v0, v23
    s.addi       s3, s1, #32512
    v.st.w       [s3, #0], v0
    vf.cvt.bf16.f32 v0, v24
    s.addi       s3, s1, #32576
    v.st.w       [s3, #0], v0
    vf.cvt.bf16.f32 v0, v25
    s.addi       s3, s1, #32640
    v.st.w       [s3, #0], v0
    vf.cvt.bf16.f32 v0, v26
    s.addi       s3, s1, #32704
    v.st.w       [s3, #0], v0
    vf.cvt.bf16.f32 v0, v27
    s.movz       s3, #32768
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v0
    vf.cvt.bf16.f32 v0, v28
    s.movz       s3, #32832
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v0
    vf.cvt.bf16.f32 v0, v29
    s.movz       s3, #32896
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v0
    vf.cvt.bf16.f32 v0, v30
    s.movz       s3, #32960
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v0
    vf.cvt.bf16.f32 v0, v31
    s.movz       s3, #33024
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v0
    vf.cvt.bf16.f32 v0, v32
    s.movz       s3, #33088
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v0
    vf.cvt.bf16.f32 v0, v33
    s.movz       s3, #33152
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v0
    vf.cvt.bf16.f32 v0, v34
    s.movz       s3, #33216
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v0
    vf.cvt.bf16.f32 v0, v35
    s.movz       s3, #33280
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v0
    vf.cvt.bf16.f32 v0, v36
    s.movz       s3, #33344
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v0
    vf.cvt.bf16.f32 v0, v37
    s.movz       s3, #33408
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v0
    vf.cvt.bf16.f32 v0, v38
    s.movz       s3, #33472
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v0
    vf.cvt.bf16.f32 v0, v39
    s.movz       s3, #33536
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v0
    vf.cvt.bf16.f32 v0, v40
    s.movz       s3, #33600
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v0
    vf.cvt.bf16.f32 v0, v41
    s.movz       s3, #33664
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v0
    vf.cvt.bf16.f32 v0, v42
    s.movz       s3, #33728
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v0
    vf.cvt.bf16.f32 v0, v43
    s.movz       s3, #33792
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v0
    vf.cvt.bf16.f32 v0, v44
    s.movz       s3, #33856
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v0
    vf.cvt.bf16.f32 v0, v45
    s.movz       s3, #33920
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v0
    vf.cvt.bf16.f32 v0, v46
    s.movz       s3, #33984
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v0
    vf.cvt.bf16.f32 v0, v47
    s.movz       s3, #34048
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v0
    vf.cvt.bf16.f32 v0, v48
    s.movz       s3, #34112
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v0
    vf.cvt.bf16.f32 v0, v49
    s.movz       s3, #34176
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v0
    vf.cvt.bf16.f32 v0, v50
    s.movz       s3, #34240
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v0
    vf.cvt.bf16.f32 v0, v51
    s.movz       s3, #34304
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v0
    s.addi       s3, s1, #26176
    v.ld.w       v0, [s3, #0]
    vf.abs       v1, v0
    s.addi       s3, s1, #26240
    v.ld.w       v0, [s3, #0]
    vf.abs       v2, v0
    s.addi       s3, s1, #26304
    v.ld.w       v0, [s3, #0]
    vf.abs       v3, v0
    s.addi       s3, s1, #26368
    v.ld.w       v0, [s3, #0]
    vf.abs       v4, v0
    s.addi       s3, s1, #26432
    v.ld.w       v0, [s3, #0]
    vf.abs       v5, v0
    s.addi       s3, s1, #26496
    v.ld.w       v0, [s3, #0]
    vf.abs       v6, v0
    s.addi       s3, s1, #26560
    v.ld.w       v0, [s3, #0]
    vf.abs       v7, v0
    s.addi       s3, s1, #26624
    v.ld.w       v0, [s3, #0]
    vf.abs       v8, v0
    s.addi       s3, s1, #26688
    v.ld.w       v0, [s3, #0]
    vf.abs       v9, v0
    s.addi       s3, s1, #26752
    v.ld.w       v0, [s3, #0]
    vf.abs       v10, v0
    s.addi       s3, s1, #26816
    v.ld.w       v0, [s3, #0]
    vf.abs       v11, v0
    s.addi       s3, s1, #26880
    v.ld.w       v0, [s3, #0]
    vf.abs       v12, v0
    s.addi       s3, s1, #26944
    v.ld.w       v0, [s3, #0]
    vf.abs       v13, v0
    s.addi       s3, s1, #27008
    v.ld.w       v0, [s3, #0]
    vf.abs       v14, v0
    s.addi       s3, s1, #27072
    v.ld.w       v0, [s3, #0]
    vf.abs       v15, v0
    s.addi       s3, s1, #27136
    v.ld.w       v0, [s3, #0]
    vf.abs       v16, v0
    s.addi       s3, s1, #27200
    v.ld.w       v0, [s3, #0]
    vf.abs       v17, v0
    s.addi       s3, s1, #27264
    v.ld.w       v0, [s3, #0]
    vf.abs       v18, v0
    s.addi       s3, s1, #27328
    v.ld.w       v0, [s3, #0]
    vf.abs       v19, v0
    s.addi       s3, s1, #27392
    v.ld.w       v0, [s3, #0]
    vf.abs       v20, v0
    s.addi       s3, s1, #27456
    v.ld.w       v0, [s3, #0]
    vf.abs       v21, v0
    s.addi       s3, s1, #27520
    v.ld.w       v0, [s3, #0]
    vf.abs       v22, v0
    s.addi       s3, s1, #27584
    v.ld.w       v0, [s3, #0]
    vf.abs       v23, v0
    s.addi       s3, s1, #27648
    v.ld.w       v0, [s3, #0]
    vf.abs       v24, v0
    s.addi       s3, s1, #27712
    v.ld.w       v0, [s3, #0]
    vf.abs       v25, v0
    s.addi       s3, s1, #27776
    v.ld.w       v0, [s3, #0]
    vf.abs       v26, v0
    s.addi       s3, s1, #27840
    v.ld.w       v0, [s3, #0]
    vf.abs       v27, v0
    s.addi       s3, s1, #27904
    v.ld.w       v0, [s3, #0]
    vf.abs       v28, v0
    s.addi       s3, s1, #27968
    v.ld.w       v0, [s3, #0]
    vf.abs       v29, v0
    s.addi       s3, s1, #28032
    v.ld.w       v0, [s3, #0]
    vf.abs       v30, v0
    s.addi       s3, s1, #28096
    v.ld.w       v0, [s3, #0]
    vf.abs       v31, v0
    s.addi       s3, s1, #28160
    v.ld.w       v0, [s3, #0]
    vf.abs       v32, v0
    s.addi       s3, s1, #28224
    v.ld.w       v0, [s3, #0]
    vf.abs       v33, v0
    s.addi       s3, s1, #28288
    v.ld.w       v0, [s3, #0]
    vf.abs       v34, v0
    s.addi       s3, s1, #28352
    v.ld.w       v0, [s3, #0]
    vf.abs       v35, v0
    s.addi       s3, s1, #28416
    v.ld.w       v0, [s3, #0]
    vf.abs       v36, v0
    s.addi       s3, s1, #28480
    v.ld.w       v0, [s3, #0]
    vf.abs       v37, v0
    s.addi       s3, s1, #28544
    v.ld.w       v0, [s3, #0]
    vf.abs       v38, v0
    s.addi       s3, s1, #28608
    v.ld.w       v0, [s3, #0]
    vf.abs       v39, v0
    s.addi       s3, s1, #28672
    v.ld.w       v0, [s3, #0]
    vf.abs       v40, v0
    s.addi       s3, s1, #28736
    v.ld.w       v0, [s3, #0]
    vf.abs       v41, v0
    s.addi       s3, s1, #28800
    v.ld.w       v0, [s3, #0]
    vf.abs       v42, v0
    s.addi       s3, s1, #28864
    v.ld.w       v0, [s3, #0]
    vf.abs       v43, v0
    s.addi       s3, s1, #28928
    v.ld.w       v0, [s3, #0]
    vf.abs       v44, v0
    s.addi       s3, s1, #28992
    v.ld.w       v0, [s3, #0]
    vf.abs       v45, v0
    s.addi       s3, s1, #29056
    v.ld.w       v0, [s3, #0]
    vf.abs       v46, v0
    s.addi       s3, s1, #29120
    v.ld.w       v0, [s3, #0]
    vf.abs       v47, v0
    s.addi       s3, s1, #29184
    v.ld.w       v0, [s3, #0]
    vf.abs       v48, v0
    s.addi       s3, s1, #29248
    v.ld.w       v0, [s3, #0]
    vf.abs       v49, v0
    s.addi       s3, s1, #29312
    v.ld.w       v0, [s3, #0]
    vf.abs       v50, v0
    s.addi       s3, s1, #29376
    v.ld.w       v0, [s3, #0]
    vf.abs       v51, v0
    s.addi       s3, s1, #29440
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #34368
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #29504
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #34432
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #29568
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #34496
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #29632
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #34560
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #29696
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #34624
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #29760
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #34688
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #29824
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #34752
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #29888
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #34816
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #29952
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #34880
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #30016
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #34944
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #30080
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #35008
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #30144
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #35072
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #30208
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #35136
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #30272
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #35200
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #30336
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #35264
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #30400
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #35328
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #30464
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #35392
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #30528
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #35456
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #30592
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #35520
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #30656
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #35584
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #30720
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #35648
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #30784
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #35712
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #30848
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #35776
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #30912
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #35840
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #30976
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #35904
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #31040
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #35968
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #31104
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #36032
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #31168
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #36096
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #31232
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #36160
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #31296
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #36224
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #31360
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #36288
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #31424
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #36352
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #31488
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #36416
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #31552
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #36480
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #31616
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #36544
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #31680
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #36608
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #31744
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #36672
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #31808
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #36736
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #31872
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #36800
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #31936
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #36864
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #32000
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #36928
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #32064
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #36992
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #32128
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #37056
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #32192
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #37120
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #32256
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #37184
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #32320
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #37248
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #32384
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #37312
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #32448
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #37376
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #32512
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #37440
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #32576
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #37504
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #32640
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #37568
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.addi       s3, s1, #32704
    v.ld.w       v0, [s3, #0]
    vf.abs       v52, v0
    s.movz       s3, #37632
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.movz       s3, #32768
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.abs       v52, v0
    s.movz       s3, #37696
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.movz       s3, #32832
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.abs       v52, v0
    s.movz       s3, #37760
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.movz       s3, #32896
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.abs       v52, v0
    s.movz       s3, #37824
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.movz       s3, #32960
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.abs       v52, v0
    s.movz       s3, #37888
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.movz       s3, #33024
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.abs       v52, v0
    s.movz       s3, #37952
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.movz       s3, #33088
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.abs       v52, v0
    s.movz       s3, #38016
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.movz       s3, #33152
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.abs       v52, v0
    s.movz       s3, #38080
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.movz       s3, #33216
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.abs       v52, v0
    s.movz       s3, #38144
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.movz       s3, #33280
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.abs       v52, v0
    s.movz       s3, #38208
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.movz       s3, #33344
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.abs       v52, v0
    s.movz       s3, #38272
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.movz       s3, #33408
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.abs       v52, v0
    s.movz       s3, #38336
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.movz       s3, #33472
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.abs       v52, v0
    s.movz       s3, #38400
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.movz       s3, #33536
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.abs       v52, v0
    s.movz       s3, #38464
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.movz       s3, #33600
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.abs       v52, v0
    s.movz       s3, #38528
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.movz       s3, #33664
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.abs       v52, v0
    s.movz       s3, #38592
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.movz       s3, #33728
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.abs       v52, v0
    s.movz       s3, #38656
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.movz       s3, #33792
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.abs       v52, v0
    s.movz       s3, #38720
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.movz       s3, #33856
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.abs       v52, v0
    s.movz       s3, #38784
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.movz       s3, #33920
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.abs       v52, v0
    s.movz       s3, #38848
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.movz       s3, #33984
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.abs       v52, v0
    s.movz       s3, #38912
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.movz       s3, #34048
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.abs       v52, v0
    s.movz       s3, #38976
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.movz       s3, #34112
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.abs       v52, v0
    s.movz       s3, #39040
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.movz       s3, #34176
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.abs       v52, v0
    s.movz       s3, #39104
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.movz       s3, #34240
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.abs       v52, v0
    s.movz       s3, #39168
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    s.movz       s3, #34304
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.abs       v52, v0
    s.movz       s3, #39232
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v52
    vf.reduce.max.b v0, v1
    vf.reduce.max.b v1, v2
    vf.max       v2, v0, v1
    vf.reduce.max.b v0, v3
    vf.max       v1, v2, v0
    vf.reduce.max.b v0, v4
    vf.max       v2, v1, v0
    vf.reduce.max.b v0, v5
    vf.max       v1, v2, v0
    vf.reduce.max.b v0, v6
    vf.max       v2, v1, v0
    vf.reduce.max.b v0, v7
    vf.max       v1, v2, v0
    vf.reduce.max.b v0, v8
    vf.max       v2, v1, v0
    vf.reduce.max.b v0, v9
    vf.max       v1, v2, v0
    vf.reduce.max.b v0, v10
    vf.max       v2, v1, v0
    vf.reduce.max.b v0, v11
    vf.max       v1, v2, v0
    vf.reduce.max.b v0, v12
    vf.max       v2, v1, v0
    vf.reduce.max.b v0, v13
    vf.max       v1, v2, v0
    vf.reduce.max.b v0, v14
    vf.max       v2, v1, v0
    vf.reduce.max.b v0, v15
    vf.max       v1, v2, v0
    vf.reduce.max.b v0, v16
    vf.max       v2, v1, v0
    vf.reduce.max.b v0, v17
    vf.max       v1, v2, v0
    vf.reduce.max.b v0, v18
    vf.max       v2, v1, v0
    vf.reduce.max.b v0, v19
    vf.max       v1, v2, v0
    vf.reduce.max.b v0, v20
    vf.max       v2, v1, v0
    vf.reduce.max.b v0, v21
    vf.max       v1, v2, v0
    vf.reduce.max.b v0, v22
    vf.max       v2, v1, v0
    vf.reduce.max.b v0, v23
    vf.max       v1, v2, v0
    vf.reduce.max.b v0, v24
    vf.max       v2, v1, v0
    vf.reduce.max.b v0, v25
    vf.max       v1, v2, v0
    vf.reduce.max.b v0, v26
    vf.max       v2, v1, v0
    vf.reduce.max.b v0, v27
    vf.max       v1, v2, v0
    vf.reduce.max.b v0, v28
    vf.max       v2, v1, v0
    vf.reduce.max.b v0, v29
    vf.max       v1, v2, v0
    vf.reduce.max.b v0, v30
    vf.max       v2, v1, v0
    vf.reduce.max.b v0, v31
    vf.max       v1, v2, v0
    vf.reduce.max.b v0, v32
    vf.max       v2, v1, v0
    vf.reduce.max.b v0, v33
    vf.max       v1, v2, v0
    vf.reduce.max.b v0, v34
    vf.max       v2, v1, v0
    vf.reduce.max.b v0, v35
    vf.max       v1, v2, v0
    vf.reduce.max.b v0, v36
    vf.max       v2, v1, v0
    vf.reduce.max.b v0, v37
    vf.max       v1, v2, v0
    vf.reduce.max.b v0, v38
    vf.max       v2, v1, v0
    vf.reduce.max.b v0, v39
    vf.max       v1, v2, v0
    vf.reduce.max.b v0, v40
    vf.max       v2, v1, v0
    vf.reduce.max.b v0, v41
    vf.max       v1, v2, v0
    vf.reduce.max.b v0, v42
    vf.max       v2, v1, v0
    vf.reduce.max.b v0, v43
    vf.max       v1, v2, v0
    vf.reduce.max.b v0, v44
    vf.max       v2, v1, v0
    vf.reduce.max.b v0, v45
    vf.max       v1, v2, v0
    vf.reduce.max.b v0, v46
    vf.max       v2, v1, v0
    vf.reduce.max.b v0, v47
    vf.max       v1, v2, v0
    vf.reduce.max.b v0, v48
    vf.max       v2, v1, v0
    vf.reduce.max.b v0, v49
    vf.max       v1, v2, v0
    vf.reduce.max.b v0, v50
    vf.max       v2, v1, v0
    vf.reduce.max.b v0, v51
    vf.max       v1, v2, v0
    s.movz       s3, #34368
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #34432
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #34496
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #34560
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #34624
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #34688
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #34752
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #34816
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #34880
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #34944
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #35008
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #35072
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #35136
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #35200
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #35264
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #35328
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #35392
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #35456
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #35520
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #35584
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #35648
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #35712
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #35776
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #35840
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #35904
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #35968
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #36032
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #36096
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #36160
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #36224
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #36288
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #36352
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #36416
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #36480
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #36544
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #36608
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #36672
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #36736
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #36800
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #36864
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #36928
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #36992
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #37056
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #37120
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #37184
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #37248
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #37312
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #37376
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #37440
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #37504
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #37568
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #37632
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #37696
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #37760
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #37824
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #37888
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #37952
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #38016
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #38080
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #38144
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #38208
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #38272
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #38336
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #38400
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #38464
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #38528
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #38592
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #38656
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #38720
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #38784
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #38848
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #38912
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #38976
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #39040
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #39104
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    s.movz       s3, #39168
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.reduce.max.b v2, v1
    vf.max       v1, v0, v2
    s.movz       s3, #39232
    s.add        s7, s1, s3
    v.ld.w       v0, [s7, #0]
    vf.reduce.max.b v2, v0
    vf.max       v0, v1, v2
    .li       s3, #1138753536
    v.splat      v1, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v2, v1                          // ISA 8.8: <= 2**-22 relative
    .li       s3, #1065353216
    v.splat      v3, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v3
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v1, v2, v3
    vf.fms       v3, v2, v4, v2
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v2
    vf.mul       v2, v0, v3                      // a/y: faithful quotient
    vf.fms       v4, v2, v1, v0
    vf.fms       v0, v4, v3, v2
    vf.neg       v1, v0                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v0, v1, v2
    s.movz       s7, #39360
    s.add        s8, s1, s7
    v.st.w       [s8, #0], v0
    .li       s8, #730643660
    v.splat      v0, s8                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s8, s1, s7
    v.ld.w       v1, [s8, #0]
    vf.max.ieee  v2, v1, v0
    v.rcp.approx v0, v2                          // ISA 8.8: <= 2**-22 relative
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.fms       v3, v2, v0, v1
    vf.fms       v1, v0, v3, v0
    vf.neg       v3, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v0
    s.addi       s3, s1, #26176
    v.ld.w       v0, [s3, #0]
    vf.mul       v3, v0, v1                      // a/y: faithful quotient
    s.addi       s3, s1, #26176
    v.ld.w       v0, [s3, #0]
    vf.fms       v4, v3, v2, v0
    vf.fms       v0, v4, v1, v3
    vf.neg       v1, v0                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v0, v1, v3
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #26240
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #26240
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #39424
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #26304
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #26304
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #39488
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #26368
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #26368
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #39552
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #26432
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #26432
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #39616
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #26496
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #26496
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #39680
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #26560
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #26560
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #39744
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #26624
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #26624
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #39808
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #26688
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #26688
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #39872
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #26752
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #26752
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #39936
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #26816
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #26816
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #40000
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #26880
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #26880
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #40064
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #26944
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #26944
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #40128
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #27008
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #27008
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #40192
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #27072
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #27072
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #40256
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #27136
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #27136
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #40320
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #27200
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #27200
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #40384
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #27264
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #27264
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #40448
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #27328
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #27328
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #40512
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #27392
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #27392
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #40576
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #27456
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #27456
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #40640
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #27520
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #27520
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #40704
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #27584
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #27584
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #40768
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #27648
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #27648
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #40832
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #27712
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #27712
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #40896
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #27776
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #27776
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #40960
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #27840
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #27840
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #41024
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #27904
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #27904
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #41088
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #27968
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #27968
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #41152
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #28032
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #28032
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #41216
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #28096
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #28096
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #41280
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #28160
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #28160
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #41344
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #28224
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #28224
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #41408
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #28288
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #28288
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #41472
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #28352
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #28352
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #41536
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #28416
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #28416
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #41600
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #28480
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #28480
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #41664
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #28544
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #28544
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #41728
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #28608
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #28608
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #41792
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #28672
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #28672
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #41856
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #28736
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #28736
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #41920
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #28800
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #28800
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #41984
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #28864
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #28864
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #42048
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #28928
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #28928
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #42112
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #28992
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #28992
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #42176
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #29056
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #29056
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #42240
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #29120
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #29120
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #42304
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #29184
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #29184
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #42368
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #29248
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #29248
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #42432
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #29312
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #29312
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #42496
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #29376
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #29376
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #42560
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #29440
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #29440
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #42624
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #29504
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #29504
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #42688
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #29568
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #29568
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #42752
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #29632
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #29632
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #42816
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #29696
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #29696
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #42880
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #29760
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #29760
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #42944
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #29824
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #29824
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #43008
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #29888
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #29888
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #43072
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #29952
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #29952
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #43136
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #30016
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #30016
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #43200
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #30080
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #30080
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #43264
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #30144
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #30144
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #43328
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #30208
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #30208
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #43392
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #30272
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #30272
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #43456
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #30336
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #30336
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #43520
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #30400
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #30400
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #43584
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #30464
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #30464
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #43648
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #30528
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #30528
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #43712
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #30592
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #30592
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #43776
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #30656
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #30656
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #43840
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #30720
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #30720
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #43904
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #30784
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #30784
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #43968
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #30848
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #30848
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #44032
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #30912
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #30912
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #44096
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #30976
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #30976
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #44160
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #31040
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #31040
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #44224
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #31104
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #31104
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #44288
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #31168
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #31168
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #44352
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #31232
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #31232
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    s.movz       s3, #44416
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v1
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v3, [s7, #0]
    vf.fms       v4, v2, v1, v3
    vf.fms       v3, v1, v4, v1
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    s.addi       s3, s1, #31296
    v.ld.w       v1, [s3, #0]
    vf.mul       v4, v1, v3                      // a/y: faithful quotient
    s.addi       s3, s1, #31296
    v.ld.w       v1, [s3, #0]
    vf.fms       v5, v4, v2, v1
    vf.fms       v1, v5, v3, v4
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    v.rcp.approx v3, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v4, [s7, #0]
    vf.fms       v5, v2, v3, v4
    vf.fms       v4, v3, v5, v3
    vf.neg       v5, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v4, v5, v3
    s.addi       s3, s1, #31360
    v.ld.w       v3, [s3, #0]
    vf.mul       v5, v3, v4                      // a/y: faithful quotient
    s.addi       s3, s1, #31360
    v.ld.w       v3, [s3, #0]
    vf.fms       v6, v5, v2, v3
    vf.fms       v3, v6, v4, v5
    vf.neg       v4, v3                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v5
    v.rcp.approx v4, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v5, [s7, #0]
    vf.fms       v6, v2, v4, v5
    vf.fms       v5, v4, v6, v4
    vf.neg       v6, v5                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v5, v6, v4
    s.addi       s3, s1, #31424
    v.ld.w       v4, [s3, #0]
    vf.mul       v6, v4, v5                      // a/y: faithful quotient
    s.addi       s3, s1, #31424
    v.ld.w       v4, [s3, #0]
    vf.fms       v7, v6, v2, v4
    vf.fms       v4, v7, v5, v6
    vf.neg       v5, v4                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v4, v5, v6
    v.rcp.approx v5, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v6, [s7, #0]
    vf.fms       v7, v2, v5, v6
    vf.fms       v6, v5, v7, v5
    vf.neg       v7, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v6, v7, v5
    s.addi       s3, s1, #31488
    v.ld.w       v5, [s3, #0]
    vf.mul       v7, v5, v6                      // a/y: faithful quotient
    s.addi       s3, s1, #31488
    v.ld.w       v5, [s3, #0]
    vf.fms       v8, v7, v2, v5
    vf.fms       v5, v8, v6, v7
    vf.neg       v6, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v5, v6, v7
    v.rcp.approx v6, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v7, [s7, #0]
    vf.fms       v8, v2, v6, v7
    vf.fms       v7, v6, v8, v6
    vf.neg       v8, v7                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v7, v8, v6
    s.addi       s3, s1, #31552
    v.ld.w       v6, [s3, #0]
    vf.mul       v8, v6, v7                      // a/y: faithful quotient
    s.addi       s3, s1, #31552
    v.ld.w       v6, [s3, #0]
    vf.fms       v9, v8, v2, v6
    vf.fms       v6, v9, v7, v8
    vf.neg       v7, v6                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v6, v7, v8
    v.rcp.approx v7, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v8, [s7, #0]
    vf.fms       v9, v2, v7, v8
    vf.fms       v8, v7, v9, v7
    vf.neg       v9, v8                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v8, v9, v7
    s.addi       s3, s1, #31616
    v.ld.w       v7, [s3, #0]
    vf.mul       v9, v7, v8                      // a/y: faithful quotient
    s.addi       s3, s1, #31616
    v.ld.w       v7, [s3, #0]
    vf.fms       v10, v9, v2, v7
    vf.fms       v7, v10, v8, v9
    vf.neg       v8, v7                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v7, v8, v9
    v.rcp.approx v8, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v9, [s7, #0]
    vf.fms       v10, v2, v8, v9
    vf.fms       v9, v8, v10, v8
    vf.neg       v10, v9                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v10, v10
    @p1 v.sel        v9, v10, v8
    s.addi       s3, s1, #31680
    v.ld.w       v8, [s3, #0]
    vf.mul       v10, v8, v9                     // a/y: faithful quotient
    s.addi       s3, s1, #31680
    v.ld.w       v8, [s3, #0]
    vf.fms       v11, v10, v2, v8
    vf.fms       v8, v11, v9, v10
    vf.neg       v9, v8                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v8, v9, v10
    v.rcp.approx v9, v2                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v10, [s7, #0]
    vf.fms       v11, v2, v9, v10
    vf.fms       v10, v9, v11, v9
    vf.neg       v11, v10                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v11, v11
    @p1 v.sel        v10, v11, v9
    s.addi       s3, s1, #31744
    v.ld.w       v9, [s3, #0]
    vf.mul       v11, v9, v10                    // a/y: faithful quotient
    s.addi       s3, s1, #31744
    v.ld.w       v9, [s3, #0]
    vf.fms       v12, v11, v2, v9
    vf.fms       v9, v12, v10, v11
    vf.neg       v10, v9                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v10, v10
    @p1 v.sel        v9, v10, v11
    v.rcp.approx v10, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v11, [s7, #0]
    vf.fms       v12, v2, v10, v11
    vf.fms       v11, v10, v12, v10
    vf.neg       v12, v11                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v12, v12
    @p1 v.sel        v11, v12, v10
    s.addi       s3, s1, #31808
    v.ld.w       v10, [s3, #0]
    vf.mul       v12, v10, v11                   // a/y: faithful quotient
    s.addi       s3, s1, #31808
    v.ld.w       v10, [s3, #0]
    vf.fms       v13, v12, v2, v10
    vf.fms       v10, v13, v11, v12
    vf.neg       v11, v10                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v11, v11
    @p1 v.sel        v10, v11, v12
    v.rcp.approx v11, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v12, [s7, #0]
    vf.fms       v13, v2, v11, v12
    vf.fms       v12, v11, v13, v11
    vf.neg       v13, v12                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v13, v13
    @p1 v.sel        v12, v13, v11
    s.addi       s3, s1, #31872
    v.ld.w       v11, [s3, #0]
    vf.mul       v13, v11, v12                   // a/y: faithful quotient
    s.addi       s3, s1, #31872
    v.ld.w       v11, [s3, #0]
    vf.fms       v14, v13, v2, v11
    vf.fms       v11, v14, v12, v13
    vf.neg       v12, v11                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v12, v12
    @p1 v.sel        v11, v12, v13
    v.rcp.approx v12, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v13, [s7, #0]
    vf.fms       v14, v2, v12, v13
    vf.fms       v13, v12, v14, v12
    vf.neg       v14, v13                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v14, v14
    @p1 v.sel        v13, v14, v12
    s.addi       s3, s1, #31936
    v.ld.w       v12, [s3, #0]
    vf.mul       v14, v12, v13                   // a/y: faithful quotient
    s.addi       s3, s1, #31936
    v.ld.w       v12, [s3, #0]
    vf.fms       v15, v14, v2, v12
    vf.fms       v12, v15, v13, v14
    vf.neg       v13, v12                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v13, v13
    @p1 v.sel        v12, v13, v14
    v.rcp.approx v13, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v14, [s7, #0]
    vf.fms       v15, v2, v13, v14
    vf.fms       v14, v13, v15, v13
    vf.neg       v15, v14                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v15, v15
    @p1 v.sel        v14, v15, v13
    s.addi       s3, s1, #32000
    v.ld.w       v13, [s3, #0]
    vf.mul       v15, v13, v14                   // a/y: faithful quotient
    s.addi       s3, s1, #32000
    v.ld.w       v13, [s3, #0]
    vf.fms       v16, v15, v2, v13
    vf.fms       v13, v16, v14, v15
    vf.neg       v14, v13                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v14, v14
    @p1 v.sel        v13, v14, v15
    v.rcp.approx v14, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v15, [s7, #0]
    vf.fms       v16, v2, v14, v15
    vf.fms       v15, v14, v16, v14
    vf.neg       v16, v15                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v16, v16
    @p1 v.sel        v15, v16, v14
    s.addi       s3, s1, #32064
    v.ld.w       v14, [s3, #0]
    vf.mul       v16, v14, v15                   // a/y: faithful quotient
    s.addi       s3, s1, #32064
    v.ld.w       v14, [s3, #0]
    vf.fms       v17, v16, v2, v14
    vf.fms       v14, v17, v15, v16
    vf.neg       v15, v14                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v15, v15
    @p1 v.sel        v14, v15, v16
    v.rcp.approx v15, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v16, [s7, #0]
    vf.fms       v17, v2, v15, v16
    vf.fms       v16, v15, v17, v15
    vf.neg       v17, v16                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v17, v17
    @p1 v.sel        v16, v17, v15
    s.addi       s3, s1, #32128
    v.ld.w       v15, [s3, #0]
    vf.mul       v17, v15, v16                   // a/y: faithful quotient
    s.addi       s3, s1, #32128
    v.ld.w       v15, [s3, #0]
    vf.fms       v18, v17, v2, v15
    vf.fms       v15, v18, v16, v17
    vf.neg       v16, v15                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v16, v16
    @p1 v.sel        v15, v16, v17
    v.rcp.approx v16, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v17, [s7, #0]
    vf.fms       v18, v2, v16, v17
    vf.fms       v17, v16, v18, v16
    vf.neg       v18, v17                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v18, v18
    @p1 v.sel        v17, v18, v16
    s.addi       s3, s1, #32192
    v.ld.w       v16, [s3, #0]
    vf.mul       v18, v16, v17                   // a/y: faithful quotient
    s.addi       s3, s1, #32192
    v.ld.w       v16, [s3, #0]
    vf.fms       v19, v18, v2, v16
    vf.fms       v16, v19, v17, v18
    vf.neg       v17, v16                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v17, v17
    @p1 v.sel        v16, v17, v18
    v.rcp.approx v17, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v18, [s7, #0]
    vf.fms       v19, v2, v17, v18
    vf.fms       v18, v17, v19, v17
    vf.neg       v19, v18                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v18, v19, v17
    s.addi       s3, s1, #32256
    v.ld.w       v17, [s3, #0]
    vf.mul       v19, v17, v18                   // a/y: faithful quotient
    s.addi       s3, s1, #32256
    v.ld.w       v17, [s3, #0]
    vf.fms       v20, v19, v2, v17
    vf.fms       v17, v20, v18, v19
    vf.neg       v18, v17                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v18, v18
    @p1 v.sel        v17, v18, v19
    v.rcp.approx v18, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v19, [s7, #0]
    vf.fms       v20, v2, v18, v19
    vf.fms       v19, v18, v20, v18
    vf.neg       v20, v19                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v19, v20, v18
    s.addi       s3, s1, #32320
    v.ld.w       v18, [s3, #0]
    vf.mul       v20, v18, v19                   // a/y: faithful quotient
    s.addi       s3, s1, #32320
    v.ld.w       v18, [s3, #0]
    vf.fms       v21, v20, v2, v18
    vf.fms       v18, v21, v19, v20
    vf.neg       v19, v18                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v18, v19, v20
    v.rcp.approx v19, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v20, [s7, #0]
    vf.fms       v21, v2, v19, v20
    vf.fms       v20, v19, v21, v19
    vf.neg       v21, v20                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v21, v21
    @p1 v.sel        v20, v21, v19
    s.addi       s3, s1, #32384
    v.ld.w       v19, [s3, #0]
    vf.mul       v21, v19, v20                   // a/y: faithful quotient
    s.addi       s3, s1, #32384
    v.ld.w       v19, [s3, #0]
    vf.fms       v22, v21, v2, v19
    vf.fms       v19, v22, v20, v21
    vf.neg       v20, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v19, v20, v21
    v.rcp.approx v20, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v21, [s7, #0]
    vf.fms       v22, v2, v20, v21
    vf.fms       v21, v20, v22, v20
    vf.neg       v22, v21                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v22, v22
    @p1 v.sel        v21, v22, v20
    s.addi       s3, s1, #32448
    v.ld.w       v20, [s3, #0]
    vf.mul       v22, v20, v21                   // a/y: faithful quotient
    s.addi       s3, s1, #32448
    v.ld.w       v20, [s3, #0]
    vf.fms       v23, v22, v2, v20
    vf.fms       v20, v23, v21, v22
    vf.neg       v21, v20                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v21, v21
    @p1 v.sel        v20, v21, v22
    v.rcp.approx v21, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v22, [s7, #0]
    vf.fms       v23, v2, v21, v22
    vf.fms       v22, v21, v23, v21
    vf.neg       v23, v22                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v23, v23
    @p1 v.sel        v22, v23, v21
    s.addi       s3, s1, #32512
    v.ld.w       v21, [s3, #0]
    vf.mul       v23, v21, v22                   // a/y: faithful quotient
    s.addi       s3, s1, #32512
    v.ld.w       v21, [s3, #0]
    vf.fms       v24, v23, v2, v21
    vf.fms       v21, v24, v22, v23
    vf.neg       v22, v21                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v22, v22
    @p1 v.sel        v21, v22, v23
    v.rcp.approx v22, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v23, [s7, #0]
    vf.fms       v24, v2, v22, v23
    vf.fms       v23, v22, v24, v22
    vf.neg       v24, v23                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v24, v24
    @p1 v.sel        v23, v24, v22
    s.addi       s3, s1, #32576
    v.ld.w       v22, [s3, #0]
    vf.mul       v24, v22, v23                   // a/y: faithful quotient
    s.addi       s3, s1, #32576
    v.ld.w       v22, [s3, #0]
    vf.fms       v25, v24, v2, v22
    vf.fms       v22, v25, v23, v24
    vf.neg       v23, v22                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v23, v23
    @p1 v.sel        v22, v23, v24
    v.rcp.approx v23, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v24, [s7, #0]
    vf.fms       v25, v2, v23, v24
    vf.fms       v24, v23, v25, v23
    vf.neg       v25, v24                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v25, v25
    @p1 v.sel        v24, v25, v23
    s.addi       s3, s1, #32640
    v.ld.w       v23, [s3, #0]
    vf.mul       v25, v23, v24                   // a/y: faithful quotient
    s.addi       s3, s1, #32640
    v.ld.w       v23, [s3, #0]
    vf.fms       v26, v25, v2, v23
    vf.fms       v23, v26, v24, v25
    vf.neg       v24, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v24, v24
    @p1 v.sel        v23, v24, v25
    v.rcp.approx v24, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v25, [s7, #0]
    vf.fms       v26, v2, v24, v25
    vf.fms       v25, v24, v26, v24
    vf.neg       v26, v25                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v25, v26, v24
    s.addi       s3, s1, #32704
    v.ld.w       v24, [s3, #0]
    vf.mul       v26, v24, v25                   // a/y: faithful quotient
    s.addi       s3, s1, #32704
    v.ld.w       v24, [s3, #0]
    vf.fms       v27, v26, v2, v24
    vf.fms       v24, v27, v25, v26
    vf.neg       v25, v24                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v25, v25
    @p1 v.sel        v24, v25, v26
    v.rcp.approx v25, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v26, [s7, #0]
    vf.fms       v27, v2, v25, v26
    vf.fms       v26, v25, v27, v25
    vf.neg       v27, v26                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v26, v27, v25
    s.movz       s3, #32768
    s.add        s7, s1, s3
    v.ld.w       v25, [s7, #0]
    vf.mul       v27, v25, v26                   // a/y: faithful quotient
    s.movz       s3, #32768
    s.add        s7, s1, s3
    v.ld.w       v25, [s7, #0]
    vf.fms       v28, v27, v2, v25
    vf.fms       v25, v28, v26, v27
    vf.neg       v26, v25                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v25, v26, v27
    v.rcp.approx v26, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v27, [s7, #0]
    vf.fms       v28, v2, v26, v27
    vf.fms       v27, v26, v28, v26
    vf.neg       v28, v27                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v26
    s.movz       s3, #32832
    s.add        s7, s1, s3
    v.ld.w       v26, [s7, #0]
    vf.mul       v28, v26, v27                   // a/y: faithful quotient
    s.movz       s3, #32832
    s.add        s7, s1, s3
    v.ld.w       v26, [s7, #0]
    vf.fms       v29, v28, v2, v26
    vf.fms       v26, v29, v27, v28
    vf.neg       v27, v26                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v26, v27, v28
    v.rcp.approx v27, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v28, [s7, #0]
    vf.fms       v29, v2, v27, v28
    vf.fms       v28, v27, v29, v27
    vf.neg       v29, v28                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v29, v29
    @p1 v.sel        v28, v29, v27
    s.movz       s3, #32896
    s.add        s7, s1, s3
    v.ld.w       v27, [s7, #0]
    vf.mul       v29, v27, v28                   // a/y: faithful quotient
    s.movz       s3, #32896
    s.add        s7, s1, s3
    v.ld.w       v27, [s7, #0]
    vf.fms       v30, v29, v2, v27
    vf.fms       v27, v30, v28, v29
    vf.neg       v28, v27                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v27, v28, v29
    v.rcp.approx v28, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v29, [s7, #0]
    vf.fms       v30, v2, v28, v29
    vf.fms       v29, v28, v30, v28
    vf.neg       v30, v29                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v29, v30, v28
    s.movz       s3, #32960
    s.add        s7, s1, s3
    v.ld.w       v28, [s7, #0]
    vf.mul       v30, v28, v29                   // a/y: faithful quotient
    s.movz       s3, #32960
    s.add        s7, s1, s3
    v.ld.w       v28, [s7, #0]
    vf.fms       v31, v30, v2, v28
    vf.fms       v28, v31, v29, v30
    vf.neg       v29, v28                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v29, v29
    @p1 v.sel        v28, v29, v30
    v.rcp.approx v29, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v30, [s7, #0]
    vf.fms       v31, v2, v29, v30
    vf.fms       v30, v29, v31, v29
    vf.neg       v31, v30                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v31, v31
    @p1 v.sel        v30, v31, v29
    s.movz       s3, #33024
    s.add        s7, s1, s3
    v.ld.w       v29, [s7, #0]
    vf.mul       v31, v29, v30                   // a/y: faithful quotient
    s.movz       s3, #33024
    s.add        s7, s1, s3
    v.ld.w       v29, [s7, #0]
    vf.fms       v32, v31, v2, v29
    vf.fms       v29, v32, v30, v31
    vf.neg       v30, v29                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v29, v30, v31
    v.rcp.approx v30, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v31, [s7, #0]
    vf.fms       v32, v2, v30, v31
    vf.fms       v31, v30, v32, v30
    vf.neg       v32, v31                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v32, v32
    @p1 v.sel        v31, v32, v30
    s.movz       s3, #33088
    s.add        s7, s1, s3
    v.ld.w       v30, [s7, #0]
    vf.mul       v32, v30, v31                   // a/y: faithful quotient
    s.movz       s3, #33088
    s.add        s7, s1, s3
    v.ld.w       v30, [s7, #0]
    vf.fms       v33, v32, v2, v30
    vf.fms       v30, v33, v31, v32
    vf.neg       v31, v30                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v31, v31
    @p1 v.sel        v30, v31, v32
    v.rcp.approx v31, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v32, [s7, #0]
    vf.fms       v33, v2, v31, v32
    vf.fms       v32, v31, v33, v31
    vf.neg       v33, v32                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v33, v33
    @p1 v.sel        v32, v33, v31
    s.movz       s3, #33152
    s.add        s7, s1, s3
    v.ld.w       v31, [s7, #0]
    vf.mul       v33, v31, v32                   // a/y: faithful quotient
    s.movz       s3, #33152
    s.add        s7, s1, s3
    v.ld.w       v31, [s7, #0]
    vf.fms       v34, v33, v2, v31
    vf.fms       v31, v34, v32, v33
    vf.neg       v32, v31                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v32, v32
    @p1 v.sel        v31, v32, v33
    v.rcp.approx v32, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v33, [s7, #0]
    vf.fms       v34, v2, v32, v33
    vf.fms       v33, v32, v34, v32
    vf.neg       v34, v33                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v33, v34, v32
    s.movz       s3, #33216
    s.add        s7, s1, s3
    v.ld.w       v32, [s7, #0]
    vf.mul       v34, v32, v33                   // a/y: faithful quotient
    s.movz       s3, #33216
    s.add        s7, s1, s3
    v.ld.w       v32, [s7, #0]
    vf.fms       v35, v34, v2, v32
    vf.fms       v32, v35, v33, v34
    vf.neg       v33, v32                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v33, v33
    @p1 v.sel        v32, v33, v34
    v.rcp.approx v33, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v34, [s7, #0]
    vf.fms       v35, v2, v33, v34
    vf.fms       v34, v33, v35, v33
    vf.neg       v35, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v35, v35
    @p1 v.sel        v34, v35, v33
    s.movz       s3, #33280
    s.add        s7, s1, s3
    v.ld.w       v33, [s7, #0]
    vf.mul       v35, v33, v34                   // a/y: faithful quotient
    s.movz       s3, #33280
    s.add        s7, s1, s3
    v.ld.w       v33, [s7, #0]
    vf.fms       v36, v35, v2, v33
    vf.fms       v33, v36, v34, v35
    vf.neg       v34, v33                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v33, v34, v35
    v.rcp.approx v34, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v35, [s7, #0]
    vf.fms       v36, v2, v34, v35
    vf.fms       v35, v34, v36, v34
    vf.neg       v36, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v34
    s.movz       s3, #33344
    s.add        s7, s1, s3
    v.ld.w       v34, [s7, #0]
    vf.mul       v36, v34, v35                   // a/y: faithful quotient
    s.movz       s3, #33344
    s.add        s7, s1, s3
    v.ld.w       v34, [s7, #0]
    vf.fms       v37, v36, v2, v34
    vf.fms       v34, v37, v35, v36
    vf.neg       v35, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v35, v35
    @p1 v.sel        v34, v35, v36
    v.rcp.approx v35, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v36, [s7, #0]
    vf.fms       v37, v2, v35, v36
    vf.fms       v36, v35, v37, v35
    vf.neg       v37, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v37, v37
    @p1 v.sel        v36, v37, v35
    s.movz       s3, #33408
    s.add        s7, s1, s3
    v.ld.w       v35, [s7, #0]
    vf.mul       v37, v35, v36                   // a/y: faithful quotient
    s.movz       s3, #33408
    s.add        s7, s1, s3
    v.ld.w       v35, [s7, #0]
    vf.fms       v38, v37, v2, v35
    vf.fms       v35, v38, v36, v37
    vf.neg       v36, v35                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v35, v36, v37
    v.rcp.approx v36, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v37, [s7, #0]
    vf.fms       v38, v2, v36, v37
    vf.fms       v37, v36, v38, v36
    vf.neg       v38, v37                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v37, v38, v36
    s.movz       s3, #33472
    s.add        s7, s1, s3
    v.ld.w       v36, [s7, #0]
    vf.mul       v38, v36, v37                   // a/y: faithful quotient
    s.movz       s3, #33472
    s.add        s7, s1, s3
    v.ld.w       v36, [s7, #0]
    vf.fms       v39, v38, v2, v36
    vf.fms       v36, v39, v37, v38
    vf.neg       v37, v36                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v37, v37
    @p1 v.sel        v36, v37, v38
    v.rcp.approx v37, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v38, [s7, #0]
    vf.fms       v39, v2, v37, v38
    vf.fms       v38, v37, v39, v37
    vf.neg       v39, v38                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v39, v39
    @p1 v.sel        v38, v39, v37
    s.movz       s3, #33536
    s.add        s7, s1, s3
    v.ld.w       v37, [s7, #0]
    vf.mul       v39, v37, v38                   // a/y: faithful quotient
    s.movz       s3, #33536
    s.add        s7, s1, s3
    v.ld.w       v37, [s7, #0]
    vf.fms       v40, v39, v2, v37
    vf.fms       v37, v40, v38, v39
    vf.neg       v38, v37                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v37, v38, v39
    v.rcp.approx v38, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v39, [s7, #0]
    vf.fms       v40, v2, v38, v39
    vf.fms       v39, v38, v40, v38
    vf.neg       v40, v39                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v39, v40, v38
    s.movz       s3, #33600
    s.add        s7, s1, s3
    v.ld.w       v38, [s7, #0]
    vf.mul       v40, v38, v39                   // a/y: faithful quotient
    s.movz       s3, #33600
    s.add        s7, s1, s3
    v.ld.w       v38, [s7, #0]
    vf.fms       v41, v40, v2, v38
    vf.fms       v38, v41, v39, v40
    vf.neg       v39, v38                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v39, v39
    @p1 v.sel        v38, v39, v40
    v.rcp.approx v39, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v40, [s7, #0]
    vf.fms       v41, v2, v39, v40
    vf.fms       v40, v39, v41, v39
    vf.neg       v41, v40                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v40, v41, v39
    s.movz       s3, #33664
    s.add        s7, s1, s3
    v.ld.w       v39, [s7, #0]
    vf.mul       v41, v39, v40                   // a/y: faithful quotient
    s.movz       s3, #33664
    s.add        s7, s1, s3
    v.ld.w       v39, [s7, #0]
    vf.fms       v42, v41, v2, v39
    vf.fms       v39, v42, v40, v41
    vf.neg       v40, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v39, v40, v41
    v.rcp.approx v40, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v41, [s7, #0]
    vf.fms       v42, v2, v40, v41
    vf.fms       v41, v40, v42, v40
    vf.neg       v42, v41                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v41, v42, v40
    s.movz       s3, #33728
    s.add        s7, s1, s3
    v.ld.w       v40, [s7, #0]
    vf.mul       v42, v40, v41                   // a/y: faithful quotient
    s.movz       s3, #33728
    s.add        s7, s1, s3
    v.ld.w       v40, [s7, #0]
    vf.fms       v43, v42, v2, v40
    vf.fms       v40, v43, v41, v42
    vf.neg       v41, v40                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v40, v41, v42
    v.rcp.approx v41, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v42, [s7, #0]
    vf.fms       v43, v2, v41, v42
    vf.fms       v42, v41, v43, v41
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v42, v43, v41
    s.movz       s3, #33792
    s.add        s7, s1, s3
    v.ld.w       v41, [s7, #0]
    vf.mul       v43, v41, v42                   // a/y: faithful quotient
    s.movz       s3, #33792
    s.add        s7, s1, s3
    v.ld.w       v41, [s7, #0]
    vf.fms       v44, v43, v2, v41
    vf.fms       v41, v44, v42, v43
    vf.neg       v42, v41                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v41, v42, v43
    v.rcp.approx v42, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v43, [s7, #0]
    vf.fms       v44, v2, v42, v43
    vf.fms       v43, v42, v44, v42
    vf.neg       v44, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v43, v44, v42
    s.movz       s3, #33856
    s.add        s7, s1, s3
    v.ld.w       v42, [s7, #0]
    vf.mul       v44, v42, v43                   // a/y: faithful quotient
    s.movz       s3, #33856
    s.add        s7, s1, s3
    v.ld.w       v42, [s7, #0]
    vf.fms       v45, v44, v2, v42
    vf.fms       v42, v45, v43, v44
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v42, v43, v44
    v.rcp.approx v43, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v44, [s7, #0]
    vf.fms       v45, v2, v43, v44
    vf.fms       v44, v43, v45, v43
    vf.neg       v45, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v45, v45
    @p1 v.sel        v44, v45, v43
    s.movz       s3, #33920
    s.add        s7, s1, s3
    v.ld.w       v43, [s7, #0]
    vf.mul       v45, v43, v44                   // a/y: faithful quotient
    s.movz       s3, #33920
    s.add        s7, s1, s3
    v.ld.w       v43, [s7, #0]
    vf.fms       v46, v45, v2, v43
    vf.fms       v43, v46, v44, v45
    vf.neg       v44, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v43, v44, v45
    v.rcp.approx v44, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v45, [s7, #0]
    vf.fms       v46, v2, v44, v45
    vf.fms       v45, v44, v46, v44
    vf.neg       v46, v45                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v46, v46
    @p1 v.sel        v45, v46, v44
    s.movz       s3, #33984
    s.add        s7, s1, s3
    v.ld.w       v44, [s7, #0]
    vf.mul       v46, v44, v45                   // a/y: faithful quotient
    s.movz       s3, #33984
    s.add        s7, s1, s3
    v.ld.w       v44, [s7, #0]
    vf.fms       v47, v46, v2, v44
    vf.fms       v44, v47, v45, v46
    vf.neg       v45, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v45, v45
    @p1 v.sel        v44, v45, v46
    v.rcp.approx v45, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v46, [s7, #0]
    vf.fms       v47, v2, v45, v46
    vf.fms       v46, v45, v47, v45
    vf.neg       v47, v46                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v47, v47
    @p1 v.sel        v46, v47, v45
    s.movz       s3, #34048
    s.add        s7, s1, s3
    v.ld.w       v45, [s7, #0]
    vf.mul       v47, v45, v46                   // a/y: faithful quotient
    s.movz       s3, #34048
    s.add        s7, s1, s3
    v.ld.w       v45, [s7, #0]
    vf.fms       v48, v47, v2, v45
    vf.fms       v45, v48, v46, v47
    vf.neg       v46, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v46, v46
    @p1 v.sel        v45, v46, v47
    v.rcp.approx v46, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v47, [s7, #0]
    vf.fms       v48, v2, v46, v47
    vf.fms       v47, v46, v48, v46
    vf.neg       v48, v47                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v48, v48
    @p1 v.sel        v47, v48, v46
    s.movz       s3, #34112
    s.add        s7, s1, s3
    v.ld.w       v46, [s7, #0]
    vf.mul       v48, v46, v47                   // a/y: faithful quotient
    s.movz       s3, #34112
    s.add        s7, s1, s3
    v.ld.w       v46, [s7, #0]
    vf.fms       v49, v48, v2, v46
    vf.fms       v46, v49, v47, v48
    vf.neg       v47, v46                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v47, v47
    @p1 v.sel        v46, v47, v48
    v.rcp.approx v47, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v48, [s7, #0]
    vf.fms       v49, v2, v47, v48
    vf.fms       v48, v47, v49, v47
    vf.neg       v49, v48                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v49, v49
    @p1 v.sel        v48, v49, v47
    s.movz       s3, #34176
    s.add        s7, s1, s3
    v.ld.w       v47, [s7, #0]
    vf.mul       v49, v47, v48                   // a/y: faithful quotient
    s.movz       s3, #34176
    s.add        s7, s1, s3
    v.ld.w       v47, [s7, #0]
    vf.fms       v50, v49, v2, v47
    vf.fms       v47, v50, v48, v49
    vf.neg       v48, v47                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v48, v48
    @p1 v.sel        v47, v48, v49
    v.rcp.approx v48, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v49, [s7, #0]
    vf.fms       v50, v2, v48, v49
    vf.fms       v49, v48, v50, v48
    vf.neg       v50, v49                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v50, v50
    @p1 v.sel        v49, v50, v48
    s.movz       s3, #34240
    s.add        s7, s1, s3
    v.ld.w       v48, [s7, #0]
    vf.mul       v50, v48, v49                   // a/y: faithful quotient
    s.movz       s3, #34240
    s.add        s7, s1, s3
    v.ld.w       v48, [s7, #0]
    vf.fms       v51, v50, v2, v48
    vf.fms       v48, v51, v49, v50
    vf.neg       v49, v48                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v49, v49
    @p1 v.sel        v48, v49, v50
    v.rcp.approx v49, v2                         // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #39296
    s.add        s7, s1, s3
    v.ld.w       v50, [s7, #0]
    vf.fms       v51, v2, v49, v50
    vf.fms       v50, v49, v51, v49
    vf.neg       v51, v50                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v51, v51
    @p1 v.sel        v50, v51, v49
    s.movz       s3, #34304
    s.add        s7, s1, s3
    v.ld.w       v49, [s7, #0]
    vf.mul       v51, v49, v50                   // a/y: faithful quotient
    s.movz       s3, #34304
    s.add        s7, s1, s3
    v.ld.w       v49, [s7, #0]
    vf.fms       v52, v51, v2, v49
    vf.fms       v2, v52, v50, v51
    vf.neg       v49, v2                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v49, v49
    @p1 v.sel        v2, v49, v51
    s.movz       s3, #44480
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v2
    vf.cvt.f32.e4m3 v2, v0
    v.movi       v49, #24
    v.lshr       v50, v0, v49
    v.movi       v0, #128
    v.and        v51, v50, v0
    v.or         v50, v2, v51                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #44544
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v50
    s.movz       s3, #39424
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #39424
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #44608
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #39488
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #39488
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #44672
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #39552
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #39552
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #44736
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #39616
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #39616
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #44800
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #39680
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #39680
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #44864
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #39744
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #39744
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #44928
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #39808
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #39808
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #44992
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #39872
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #39872
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #45056
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #39936
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #39936
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #45120
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #40000
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #40000
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #45184
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #40064
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #40064
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #45248
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #40128
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #40128
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #45312
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #40192
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #40192
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #45376
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #40256
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #40256
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #45440
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #40320
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #40320
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #45504
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #40384
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #40384
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #45568
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #40448
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #40448
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #45632
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #40512
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #40512
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #45696
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #40576
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #40576
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #45760
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #40640
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #40640
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #45824
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #40704
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #40704
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #45888
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #40768
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #40768
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #45952
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #40832
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #40832
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #46016
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #40896
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #40896
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #46080
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #40960
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #40960
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #46144
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #41024
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #41024
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #46208
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #41088
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #41088
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #46272
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #41152
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #41152
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #46336
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #41216
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #41216
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #46400
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #41280
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #41280
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #46464
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #41344
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #41344
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #46528
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #41408
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #41408
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #46592
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #41472
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #41472
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #46656
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #41536
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #41536
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #46720
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #41600
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #41600
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #46784
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #41664
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #41664
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #46848
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #41728
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #41728
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #46912
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #41792
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #41792
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #46976
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #41856
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #41856
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #47040
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #41920
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #41920
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #47104
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #41984
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #41984
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #47168
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #42048
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #42048
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #47232
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #42112
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #42112
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #47296
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #42176
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #42176
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #47360
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #42240
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #42240
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #47424
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #42304
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #42304
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #47488
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #42368
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #42368
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #47552
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #42432
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #42432
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #47616
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #42496
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #42496
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #47680
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #42560
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #42560
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #47744
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #42624
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #42624
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #47808
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #42688
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #42688
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #47872
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #42752
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #42752
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #47936
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #42816
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #42816
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #48000
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #42880
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #42880
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #48064
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #42944
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #42944
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #48128
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #43008
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #43008
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #48192
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #43072
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #43072
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #48256
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #43136
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #43136
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #48320
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #43200
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #43200
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #48384
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #43264
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #43264
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #48448
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #43328
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #43328
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #48512
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #43392
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #43392
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #48576
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #43456
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #43456
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #48640
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #43520
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #43520
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #48704
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #43584
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #43584
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #48768
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #43648
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #43648
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #48832
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #43712
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #43712
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #48896
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #43776
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #43776
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #48960
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #43840
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #43840
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #49024
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #43904
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #43904
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #49088
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #43968
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #43968
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #49152
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #44032
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #44032
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #49216
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #44096
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #44096
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #49280
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #44160
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #44160
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #49344
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #44224
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #44224
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #49408
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #44288
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #44288
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #49472
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #44352
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #44352
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #49536
    s.add        s7, s1, s3
    v.st.w       [s7, #0], v51
    s.movz       s3, #44416
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.e4m3 v50, v2
    s.movz       s3, #44416
    s.add        s7, s1, s3
    v.ld.w       v2, [s7, #0]
    v.lshr       v51, v2, v49
    v.and        v2, v51, v0
    v.or         v51, v50, v2                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v2, v1
    v.lshr       v50, v1, v49
    v.and        v1, v50, v0
    v.or         v50, v2, v1                     // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v3
    v.lshr       v2, v3, v49
    v.and        v3, v2, v0
    v.or         v2, v1, v3                      // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v4
    v.lshr       v3, v4, v49
    v.and        v4, v3, v0
    v.or         v3, v1, v4                      // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v5
    v.lshr       v4, v5, v49
    v.and        v5, v4, v0
    v.or         v4, v1, v5                      // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v6
    v.lshr       v5, v6, v49
    v.and        v6, v5, v0
    v.or         v5, v1, v6                      // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v7
    v.lshr       v6, v7, v49
    v.and        v7, v6, v0
    v.or         v6, v1, v7                      // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v8
    v.lshr       v7, v8, v49
    v.and        v8, v7, v0
    v.or         v7, v1, v8                      // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v9
    v.lshr       v8, v9, v49
    v.and        v9, v8, v0
    v.or         v8, v1, v9                      // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v10
    v.lshr       v9, v10, v49
    v.and        v10, v9, v0
    v.or         v9, v1, v10                     // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v11
    v.lshr       v10, v11, v49
    v.and        v11, v10, v0
    v.or         v10, v1, v11                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v12
    v.lshr       v11, v12, v49
    v.and        v12, v11, v0
    v.or         v11, v1, v12                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v13
    v.lshr       v12, v13, v49
    v.and        v13, v12, v0
    v.or         v12, v1, v13                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v14
    v.lshr       v13, v14, v49
    v.and        v14, v13, v0
    v.or         v13, v1, v14                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v15
    v.lshr       v14, v15, v49
    v.and        v15, v14, v0
    v.or         v14, v1, v15                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v16
    v.lshr       v15, v16, v49
    v.and        v16, v15, v0
    v.or         v15, v1, v16                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v17
    v.lshr       v16, v17, v49
    v.and        v17, v16, v0
    v.or         v16, v1, v17                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v18
    v.lshr       v17, v18, v49
    v.and        v18, v17, v0
    v.or         v17, v1, v18                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v19
    v.lshr       v18, v19, v49
    v.and        v19, v18, v0
    v.or         v18, v1, v19                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v20
    v.lshr       v19, v20, v49
    v.and        v20, v19, v0
    v.or         v19, v1, v20                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v21
    v.lshr       v20, v21, v49
    v.and        v21, v20, v0
    v.or         v20, v1, v21                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v22
    v.lshr       v21, v22, v49
    v.and        v22, v21, v0
    v.or         v21, v1, v22                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v23
    v.lshr       v22, v23, v49
    v.and        v23, v22, v0
    v.or         v22, v1, v23                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v24
    v.lshr       v23, v24, v49
    v.and        v24, v23, v0
    v.or         v23, v1, v24                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v25
    v.lshr       v24, v25, v49
    v.and        v25, v24, v0
    v.or         v24, v1, v25                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v26
    v.lshr       v25, v26, v49
    v.and        v26, v25, v0
    v.or         v25, v1, v26                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v27
    v.lshr       v26, v27, v49
    v.and        v27, v26, v0
    v.or         v26, v1, v27                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v28
    v.lshr       v27, v28, v49
    v.and        v28, v27, v0
    v.or         v27, v1, v28                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v29
    v.lshr       v28, v29, v49
    v.and        v29, v28, v0
    v.or         v28, v1, v29                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v30
    v.lshr       v29, v30, v49
    v.and        v30, v29, v0
    v.or         v29, v1, v30                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v31
    v.lshr       v30, v31, v49
    v.and        v31, v30, v0
    v.or         v30, v1, v31                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v32
    v.lshr       v31, v32, v49
    v.and        v32, v31, v0
    v.or         v31, v1, v32                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v33
    v.lshr       v32, v33, v49
    v.and        v33, v32, v0
    v.or         v32, v1, v33                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v34
    v.lshr       v33, v34, v49
    v.and        v34, v33, v0
    v.or         v33, v1, v34                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v35
    v.lshr       v34, v35, v49
    v.and        v35, v34, v0
    v.or         v34, v1, v35                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v36
    v.lshr       v35, v36, v49
    v.and        v36, v35, v0
    v.or         v35, v1, v36                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v37
    v.lshr       v36, v37, v49
    v.and        v37, v36, v0
    v.or         v36, v1, v37                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v38
    v.lshr       v37, v38, v49
    v.and        v38, v37, v0
    v.or         v37, v1, v38                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v39
    v.lshr       v38, v39, v49
    v.and        v39, v38, v0
    v.or         v38, v1, v39                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v40
    v.lshr       v39, v40, v49
    v.and        v40, v39, v0
    v.or         v39, v1, v40                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v41
    v.lshr       v40, v41, v49
    v.and        v41, v40, v0
    v.or         v40, v1, v41                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v42
    v.lshr       v41, v42, v49
    v.and        v42, v41, v0
    v.or         v41, v1, v42                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v43
    v.lshr       v42, v43, v49
    v.and        v43, v42, v0
    v.or         v42, v1, v43                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v44
    v.lshr       v43, v44, v49
    v.and        v44, v43, v0
    v.or         v43, v1, v44                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v45
    v.lshr       v44, v45, v49
    v.and        v45, v44, v0
    v.or         v44, v1, v45                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v46
    v.lshr       v45, v46, v49
    v.and        v46, v45, v0
    v.or         v45, v1, v46                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v47
    v.lshr       v46, v47, v49
    v.and        v47, v46, v0
    v.or         v46, v1, v47                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v1, v48
    v.lshr       v47, v48, v49
    v.and        v48, v47, v0
    v.or         v47, v1, v48                    // f32 -> f8E4M3FN: a NaN keeps its sign
    s.movz       s3, #44480
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    vf.cvt.f32.e4m3 v48, v1
    s.movz       s3, #44480
    s.add        s7, s1, s3
    v.ld.w       v1, [s7, #0]
    v.lshr       v52, v1, v49
    v.and        v1, v52, v0
    v.or         v0, v48, v1                     // f32 -> f8E4M3FN: a NaN keeps its sign
    v.ld.w       v1, [s1, #0]
    s.addi       s3, s1, #13120
    v.ld.w       v48, [s3, #0]
    v.cmp.lt     p1, v1, v48
    s.shli       s3, s2, #0                      // element offset -> bytes (x1)
    s.add        s2, s5, s3                      // &y_ptr[...]
    s.movz       s7, #44544
    s.add        s8, s1, s7
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s2, #0], v1
    s.addi       s2, s1, #64
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #13248
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #16                     // &y_ptr[16] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #44608
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #128
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #13376
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #32                     // &y_ptr[32] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #44672
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #192
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #13504
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #48                     // &y_ptr[48] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #44736
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #256
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #13632
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #64                     // &y_ptr[64] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #44800
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #320
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #13760
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #80                     // &y_ptr[80] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #44864
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #384
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #13888
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #96                     // &y_ptr[96] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #44928
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #448
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #14016
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #112                    // &y_ptr[112] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #44992
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #512
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #14144
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #128                    // &y_ptr[128] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #45056
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #576
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #14272
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #144                    // &y_ptr[144] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #45120
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #640
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #14400
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #160                    // &y_ptr[160] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #45184
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #704
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #14528
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #176                    // &y_ptr[176] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #45248
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #768
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #14656
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #192                    // &y_ptr[192] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #45312
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #832
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #14784
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #208                    // &y_ptr[208] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #45376
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #896
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #14912
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #224                    // &y_ptr[224] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #45440
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #960
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #15040
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #240                    // &y_ptr[240] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #45504
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #1024
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #15168
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #256                    // &y_ptr[256] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #45568
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #1088
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #15296
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #272                    // &y_ptr[272] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #45632
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #1152
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #15424
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #288                    // &y_ptr[288] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #45696
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #1216
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #15552
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #304                    // &y_ptr[304] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #45760
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #1280
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #15680
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #320                    // &y_ptr[320] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #45824
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #1344
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #15808
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #336                    // &y_ptr[336] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #45888
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #1408
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #15936
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #352                    // &y_ptr[352] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #45952
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #1472
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #16064
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #368                    // &y_ptr[368] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #46016
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #1536
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #16192
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #384                    // &y_ptr[384] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #46080
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #1600
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #16320
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #400                    // &y_ptr[400] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #46144
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #1664
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #16448
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #416                    // &y_ptr[416] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #46208
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #1728
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #16576
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #432                    // &y_ptr[432] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #46272
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #1792
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #16704
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #448                    // &y_ptr[448] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #46336
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #1856
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #16832
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #464                    // &y_ptr[464] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #46400
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #1920
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #16960
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #480                    // &y_ptr[480] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #46464
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #1984
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #17088
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #496                    // &y_ptr[496] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #46528
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #2048
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #17216
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #512                    // &y_ptr[512] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #46592
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #2112
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #17344
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #528                    // &y_ptr[528] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #46656
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #2176
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #17472
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #544                    // &y_ptr[544] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #46720
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #2240
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #17600
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #560                    // &y_ptr[560] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #46784
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #2304
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #17728
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #576                    // &y_ptr[576] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #46848
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #2368
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #17856
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #592                    // &y_ptr[592] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #46912
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #2432
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #17984
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #608                    // &y_ptr[608] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #46976
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #2496
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #18112
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #624                    // &y_ptr[624] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #47040
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #2560
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #18240
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #640                    // &y_ptr[640] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #47104
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #2624
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #18368
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #656                    // &y_ptr[656] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #47168
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #2688
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #18496
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #672                    // &y_ptr[672] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #47232
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #2752
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #18624
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #688                    // &y_ptr[688] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #47296
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #2816
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #18752
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #704                    // &y_ptr[704] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #47360
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #2880
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #18880
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #720                    // &y_ptr[720] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #47424
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #2944
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #19008
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #736                    // &y_ptr[736] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #47488
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #3008
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #19136
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #752                    // &y_ptr[752] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #47552
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #3072
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #19264
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #768                    // &y_ptr[768] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #47616
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #3136
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #19392
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #784                    // &y_ptr[784] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #47680
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #3200
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #19520
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #800                    // &y_ptr[800] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #47744
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #3264
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #19648
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #816                    // &y_ptr[816] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #47808
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #3328
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #19776
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #832                    // &y_ptr[832] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #47872
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #3392
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #19904
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #848                    // &y_ptr[848] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #47936
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #3456
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #20032
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #864                    // &y_ptr[864] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #48000
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #3520
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #20160
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #880                    // &y_ptr[880] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #48064
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #3584
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #20288
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #896                    // &y_ptr[896] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #48128
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #3648
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #20416
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #912                    // &y_ptr[912] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #48192
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #3712
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #20544
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #928                    // &y_ptr[928] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #48256
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #3776
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #20672
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #944                    // &y_ptr[944] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #48320
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #3840
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #20800
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #960                    // &y_ptr[960] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #48384
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #3904
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #20928
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #976                    // &y_ptr[976] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #48448
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #3968
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #21056
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #992                    // &y_ptr[992] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #48512
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #4032
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #21184
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #1008                   // &y_ptr[1008] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #48576
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #4096
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #21312
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #1024                   // &y_ptr[1024] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #48640
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #4160
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #21440
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #1040                   // &y_ptr[1040] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #48704
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #4224
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #21568
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #1056                   // &y_ptr[1056] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #48768
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #4288
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #21696
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #1072                   // &y_ptr[1072] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #48832
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #4352
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #21824
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #1088                   // &y_ptr[1088] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #48896
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #4416
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #21952
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #1104                   // &y_ptr[1104] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #48960
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #4480
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #22080
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #1120                   // &y_ptr[1120] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #49024
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #4544
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #22208
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #1136                   // &y_ptr[1136] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #49088
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #4608
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #22336
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #1152                   // &y_ptr[1152] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #49152
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #4672
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #22464
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #1168                   // &y_ptr[1168] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #49216
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #4736
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #22592
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #1184                   // &y_ptr[1184] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #49280
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #4800
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #22720
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #1200                   // &y_ptr[1200] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #49344
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #4864
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #22848
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #1216                   // &y_ptr[1216] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #49408
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #4928
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #22912
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #1232                   // &y_ptr[1232] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #49472
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #4992
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #22976
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #1248                   // &y_ptr[1248] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    s.movz       s2, #49536
    s.add        s8, s1, s2
    v.ld.w       v1, [s8, #0]
    @p1 v.st.b       [s7, #0], v1
    s.addi       s2, s1, #5056
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #23040
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #1264                   // &y_ptr[1264] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v51
    s.addi       s2, s1, #5120
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #23104
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #1280                   // &y_ptr[1280] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v50
    s.addi       s2, s1, #5184
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #23168
    v.ld.w       v48, [s2, #0]
    v.cmp.lt     p1, v1, v48
    s.addi       s2, s5, #1296                   // &y_ptr[1296] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v2
    s.addi       s2, s1, #5248
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #23232
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1312                   // &y_ptr[1312] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v3
    s.addi       s2, s1, #5312
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #23296
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1328                   // &y_ptr[1328] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v4
    s.addi       s2, s1, #5376
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #23360
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1344                   // &y_ptr[1344] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v5
    s.addi       s2, s1, #5440
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #23424
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1360                   // &y_ptr[1360] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v6
    s.addi       s2, s1, #5504
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #23488
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1376                   // &y_ptr[1376] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v7
    s.addi       s2, s1, #5568
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #23552
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1392                   // &y_ptr[1392] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v8
    s.addi       s2, s1, #5632
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #23616
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1408                   // &y_ptr[1408] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v9
    s.addi       s2, s1, #5696
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #23680
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1424                   // &y_ptr[1424] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v10
    s.addi       s2, s1, #5760
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #23744
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1440                   // &y_ptr[1440] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v11
    s.addi       s2, s1, #5824
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #23808
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1456                   // &y_ptr[1456] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v12
    s.addi       s2, s1, #5888
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #23872
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1472                   // &y_ptr[1472] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v13
    s.addi       s2, s1, #5952
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #23936
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1488                   // &y_ptr[1488] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v14
    s.addi       s2, s1, #6016
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #24000
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1504                   // &y_ptr[1504] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v15
    s.addi       s2, s1, #6080
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #24064
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1520                   // &y_ptr[1520] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v16
    s.addi       s2, s1, #6144
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #24128
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1536                   // &y_ptr[1536] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v17
    s.addi       s2, s1, #6208
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #24192
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1552                   // &y_ptr[1552] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v18
    s.addi       s2, s1, #6272
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #24256
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1568                   // &y_ptr[1568] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v19
    s.addi       s2, s1, #6336
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #24320
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1584                   // &y_ptr[1584] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v20
    s.addi       s2, s1, #6400
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #24384
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1600                   // &y_ptr[1600] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v21
    s.addi       s2, s1, #6464
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #24448
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1616                   // &y_ptr[1616] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v22
    s.addi       s2, s1, #6528
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #24512
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1632                   // &y_ptr[1632] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v23
    s.addi       s2, s1, #6592
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #24576
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1648                   // &y_ptr[1648] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v24
    s.addi       s2, s1, #6656
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #24640
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1664                   // &y_ptr[1664] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v25
    s.addi       s2, s1, #6720
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #24704
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1680                   // &y_ptr[1680] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v26
    s.addi       s2, s1, #6784
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #24768
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1696                   // &y_ptr[1696] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v27
    s.addi       s2, s1, #6848
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #24832
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1712                   // &y_ptr[1712] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v28
    s.addi       s2, s1, #6912
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #24896
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1728                   // &y_ptr[1728] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v29
    s.addi       s2, s1, #6976
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #24960
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1744                   // &y_ptr[1744] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v30
    s.addi       s2, s1, #7040
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #25024
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1760                   // &y_ptr[1760] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v31
    s.addi       s2, s1, #7104
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #25088
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1776                   // &y_ptr[1776] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v32
    s.addi       s2, s1, #7168
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #25152
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1792                   // &y_ptr[1792] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v33
    s.addi       s2, s1, #7232
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #25216
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1808                   // &y_ptr[1808] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v34
    s.addi       s2, s1, #7296
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #25280
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1824                   // &y_ptr[1824] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v35
    s.addi       s2, s1, #7360
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #25344
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1840                   // &y_ptr[1840] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v36
    s.addi       s2, s1, #7424
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #25408
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1856                   // &y_ptr[1856] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v37
    s.addi       s2, s1, #7488
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #25472
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1872                   // &y_ptr[1872] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v38
    s.addi       s2, s1, #7552
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #25536
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1888                   // &y_ptr[1888] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v39
    s.addi       s2, s1, #7616
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #25600
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1904                   // &y_ptr[1904] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v40
    s.addi       s2, s1, #7680
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #25664
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1920                   // &y_ptr[1920] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v41
    s.addi       s2, s1, #7744
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #25728
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1936                   // &y_ptr[1936] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v42
    s.addi       s2, s1, #7808
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #25792
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1952                   // &y_ptr[1952] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v43
    s.addi       s2, s1, #7872
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #25856
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1968                   // &y_ptr[1968] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v44
    s.addi       s2, s1, #7936
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #25920
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #1984                   // &y_ptr[1984] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v45
    s.addi       s2, s1, #8000
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #25984
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #2000                   // &y_ptr[2000] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v46
    s.addi       s2, s1, #8064
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #26048
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #2016                   // &y_ptr[2016] (a constant offset, x1)
    s.add        s7, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s7, #0], v47
    s.addi       s2, s1, #8128
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #26112
    v.ld.w       v2, [s2, #0]
    v.cmp.lt     p1, v1, v2
    s.addi       s2, s5, #2032                   // &y_ptr[2032] (a constant offset, x1)
    s.add        s5, s2, s3                      // &y_ptr[...]
    @p1 v.st.b       [s5, #0], v0
    s.shli       s2, s4, #2                      // element offset -> bytes (x4)
    s.add        s3, s6, s2                      // &s_ptr[...]
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p1, v0, #1
    s.movz       s2, #39360
    s.add        s4, s1, s2
    v.ld.w       v0, [s4, #0]
    @p1 v.st.w       [s3, #0], v0
__rctx_next:
    exit
