set -e
source /tools/Xilinx/Vivado/2023.2/settings64.sh
exec /tools/Xilinx/Vivado/2023.2/bin/vivado -mode batch -notrace -nojournal -log vivado.log -source "$1/input/synth.tcl" -tclargs "$1/input/$2.v" "$1/input/common" "$1/$2/ooc"
