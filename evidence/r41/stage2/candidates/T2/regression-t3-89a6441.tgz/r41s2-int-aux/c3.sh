until grep -q LANE-DONE ~/r41s2-t2-logs/C.lane; do sleep 60; done
P=/home/zhongchun/tc_env/torchenv/bin/python
bash ~/r41s2-int-aux/lane_t3.sh r41s2-t2c C "make r40-pipeline-checks PYTHON=$P TRITON_PYTHON=$P TORCH_PYTHON=$P"
