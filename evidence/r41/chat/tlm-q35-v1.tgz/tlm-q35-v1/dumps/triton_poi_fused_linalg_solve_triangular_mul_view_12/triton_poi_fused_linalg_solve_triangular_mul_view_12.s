    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #4
    v.add        v4, v1, v0
    v.movi       v0, #0
    v.movi       v1, #0
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    v.sub        v6, v1, v4
    @p1 v.sel        v7, v5, v4
    v.cmp.lt     p2, v4, v1
    @p2 v.sel        v5, v6, v4
    v.lshr       v6, v7, v3
    v.movi       v3, #15
    s.rdspecial  s2, arg_base
    v.sub        v7, v2, v6
    v.and        v8, v5, v3
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    @p1 v.sel        v3, v7, v6
    v.sub        v5, v1, v8
    .li       s4, #-1
    v.sub        v6, v0, v3
    v.cmp.lt     p1, v3, v0
    @p2 v.sel        v7, v5, v8
    @p1 v.sel        v5, v6, v3
    .li       s5, #-1
    .li       s6, #-1
    .li       s7, #-1
    s.ld.d       s8, [s2, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    .li       s9, #-1
    .li       s10, #-1
    .li       s11, #-1
    .li       s12, #-1
    .li       s13, #-1
    .li       s14, #-1
    .li       s15, #-1
    .li       s16, #-1
    v.movi       v3, #16
    s.ld.d       s17, [s2, #16]                  // out_ptr0: device_ptr64 at arg_base+16
    v.movi       v6, #15
    v.sub        v8, v1, v3
    v.sub        v9, v2, v3
    v.sub        v10, v0, v3
    v.cmp.lt     p2, v3, v1
    v.cmp.lt     p3, v3, v2
    @p2 v.sel        v1, v8, v3
    v.cmp.lt     p2, v3, v0
    @p3 v.sel        v1, v9, v3
    @p2 v.sel        v1, v10, v3
    s.ld.d       s18, [s2, #24]                  // out_ptr1: device_ptr64 at arg_base+24
    v.movi       v1, #0
    v.movi       v2, #8
    v.movi       v3, #0
    v.sub        v8, v1, v4
    v.cmp.lt     p2, v4, v1
    v.movi       v9, #0
    @p2 v.sel        v10, v8, v4
    v.and        v8, v5, v6
    v.movi       v5, #3
    v.lshr       v6, v10, v2
    v.sub        v2, v9, v4
    v.cmp.lt     p3, v4, v9
    v.sub        v10, v1, v6
    v.sub        v11, v0, v8
    @p3 v.sel        v0, v2, v4
    @p2 v.sel        v2, v10, v6
    v.movi       v4, #10
    @p1 v.sel        v6, v11, v8
    v.sub        v8, v3, v2
    v.cmp.lt     p1, v2, v3
    v.lshr       v10, v0, v4
    @p1 v.sel        v0, v8, v2
    v.movi       v2, #64
    v.sub        v4, v9, v10
    v.and        v8, v0, v5
    v.mul        v0, v6, v2
    v.movi       v2, #1040
    v.sub        v5, v3, v8
    @p3 v.sel        v11, v4, v10
    v.sub        v4, v7, v6
    @p1 v.sel        v10, v5, v8
    v.add        v5, v7, v0
    v.movi       v0, #4096
    v.mul        v8, v10, v2
    v.movi       v2, #256
    v.extract    s2, v4, #0
    v.add        v10, v5, v8
    v.mul        v5, v11, v0
    v.movi       v0, #0
    v.movi       v8, #0
    v.add        v11, v10, v5
    v.movi       v5, #4
    v.cmp.lt     p1, v2, v1
    s.shli       s19, s2, #32
    v.sub        v10, v1, v2
    s.ashri      s2, s19, #32
    v.cmp.lt     p2, v5, v3
    s.lshri      s19, s2, #32
    v.sub        v1, v3, v5
    @p1 v.sel        v3, v10, v2
    v.extract    s20, v4, #1
    v.extract    s21, v4, #2
    s.shli       s22, s20, #32
    v.ld.gather.w v2, [s3, v11]                  // index is in elements (ISA sec 9.1)
    s.ashri      s3, s22, #32
    s.shli       s20, s21, #32
    s.lshri      s21, s3, #32
    s.ashri      s22, s20, #32
    v.movi       v3, #1024
    @p2 v.sel        v10, v1, v5
    v.sub        v1, v9, v3
    v.cmp.lt     p1, v3, v9
    @p1 v.sel        v5, v1, v3
    v.ld.gather.w v1, [s8, v11]                  // index is in elements (ISA sec 9.1)
    v.insert     v0, s2, #0
    v.insert     v8, s19, #0
    v.extract    s2, v4, #3
    v.insert     v0, s3, #1
    v.insert     v8, s21, #1
    s.shli       s3, s2, #32
    s.lshri      s2, s22, #32
    v.extract    s8, v4, #4
    s.ashri      s19, s3, #32
    v.insert     v0, s22, #2
    v.insert     v8, s2, #2
    s.shli       s2, s8, #32
    s.lshri      s3, s19, #32
    v.extract    s8, v4, #5
    s.ashri      s20, s2, #32
    v.insert     v0, s19, #3
    v.insert     v8, s3, #3
    s.shli       s2, s8, #32
    s.lshri      s3, s20, #32
    v.extract    s8, v4, #6
    s.ashri      s19, s2, #32
    v.insert     v0, s20, #4
    v.insert     v8, s3, #4
    s.shli       s2, s8, #32
    s.lshri      s3, s19, #32
    v.extract    s8, v4, #7
    s.ashri      s20, s2, #32
    v.insert     v0, s19, #5
    v.insert     v8, s3, #5
    s.shli       s2, s8, #32
    s.lshri      s3, s20, #32
    v.extract    s8, v4, #8
    s.ashri      s19, s2, #32
    v.insert     v0, s20, #6
    v.insert     v8, s3, #6
    s.shli       s2, s8, #32
    s.lshri      s3, s19, #32
    v.extract    s8, v4, #9
    s.ashri      s20, s2, #32
    v.insert     v0, s19, #7
    v.insert     v8, s3, #7
    s.shli       s2, s8, #32
    s.lshri      s3, s20, #32
    v.extract    s8, v4, #10
    s.ashri      s19, s2, #32
    v.insert     v0, s20, #8
    v.insert     v8, s3, #8
    s.shli       s2, s8, #32
    s.lshri      s3, s19, #32
    v.extract    s8, v4, #11
    s.ashri      s20, s2, #32
    v.insert     v0, s19, #9
    v.insert     v8, s3, #9
    s.shli       s2, s8, #32
    s.lshri      s3, s20, #32
    v.extract    s8, v4, #12
    s.ashri      s19, s2, #32
    v.insert     v0, s20, #10
    v.insert     v8, s3, #10
    s.shli       s2, s8, #32
    s.lshri      s3, s19, #32
    v.extract    s8, v4, #13
    s.ashri      s20, s2, #32
    v.insert     v0, s19, #11
    v.insert     v8, s3, #11
    s.shli       s2, s8, #32
    s.lshri      s3, s20, #32
    v.extract    s8, v4, #14
    s.ashri      s19, s2, #32
    v.insert     v0, s20, #12
    v.insert     v8, s3, #12
    s.shli       s2, s8, #32
    s.lshri      s3, s19, #32
    v.extract    s8, v4, #15
    s.ashri      s20, s2, #32
    v.insert     v0, s19, #13
    v.insert     v8, s3, #13
    s.shli       s2, s8, #32
    s.lshri      s3, s20, #32
    s.ashri      s8, s2, #32
    v.insert     v0, s20, #14
    v.insert     v8, s3, #14
    s.lshri      s2, s8, #32
    v.insert     v0, s8, #15
    v.insert     v8, s2, #15
    v.movi       v3, #0
    v.extract    s2, v0, #0
    v.extract    s3, v8, #0
    v.extract    s8, v8, #1
    s.shli       s19, s3, #32
    v.extract    s3, v0, #1
    s.or         s20, s2, s19
    s.shli       s2, s8, #32
    s.cmp.le     s8, s20, s4
    v.extract    s19, v8, #2
    s.or         s20, s3, s2
    v.insert     v3, s8, #0
    v.extract    s2, v0, #2
    s.shli       s3, s19, #32
    s.cmp.le     s8, s20, s4
    v.extract    s19, v8, #3
    s.or         s20, s2, s3
    v.insert     v3, s8, #1
    v.extract    s2, v0, #3
    s.shli       s3, s19, #32
    s.cmp.le     s8, s20, s4
    v.extract    s19, v8, #4
    s.or         s20, s2, s3
    v.insert     v3, s8, #2
    v.extract    s2, v0, #4
    s.shli       s3, s19, #32
    s.cmp.le     s8, s20, s4
    v.extract    s19, v8, #5
    s.or         s20, s2, s3
    v.insert     v3, s8, #3
    v.extract    s2, v0, #5
    s.shli       s3, s19, #32
    s.cmp.le     s8, s20, s4
    v.extract    s4, v8, #6
    s.or         s19, s2, s3
    v.insert     v3, s8, #4
    v.extract    s2, v0, #6
    s.shli       s3, s4, #32
    s.cmp.le     s4, s19, s5
    v.extract    s5, v8, #7
    s.or         s8, s2, s3
    v.insert     v3, s4, #5
    v.extract    s2, v0, #7
    s.shli       s3, s5, #32
    s.cmp.le     s4, s8, s6
    v.extract    s5, v8, #8
    s.or         s6, s2, s3
    v.insert     v3, s4, #6
    v.extract    s2, v0, #8
    s.shli       s3, s5, #32
    s.cmp.le     s4, s6, s7
    v.extract    s5, v8, #9
    s.or         s6, s2, s3
    v.insert     v3, s4, #7
    v.extract    s2, v0, #9
    s.shli       s3, s5, #32
    s.cmp.le     s4, s6, s9
    v.extract    s5, v8, #10
    s.or         s6, s2, s3
    v.insert     v3, s4, #8
    v.extract    s2, v0, #10
    s.shli       s3, s5, #32
    s.cmp.le     s4, s6, s10
    v.extract    s5, v8, #11
    s.or         s6, s2, s3
    v.insert     v3, s4, #9
    v.extract    s2, v0, #11
    s.shli       s3, s5, #32
    s.cmp.le     s4, s6, s11
    v.extract    s5, v8, #12
    s.or         s6, s2, s3
    v.insert     v3, s4, #10
    v.extract    s2, v0, #12
    s.shli       s3, s5, #32
    s.cmp.le     s4, s6, s12
    v.extract    s5, v8, #13
    s.or         s6, s2, s3
    v.insert     v3, s4, #11
    v.extract    s2, v0, #13
    s.shli       s3, s5, #32
    s.cmp.le     s4, s6, s13
    v.extract    s5, v8, #14
    s.or         s6, s2, s3
    v.insert     v3, s4, #12
    v.extract    s2, v0, #14
    s.shli       s3, s5, #32
    s.cmp.le     s4, s6, s14
    v.extract    s5, v8, #15
    s.or         s6, s2, s3
    v.insert     v3, s4, #13
    v.extract    s2, v0, #15
    s.shli       s3, s5, #32
    s.cmp.le     s4, s6, s15
    s.or         s5, s2, s3
    v.insert     v3, s4, #14
    v.movi       v0, #255
    v.movi       v4, #255
    s.cmp.le     s2, s5, s16
    vf.mul       v5, v2, v1
    v.insert     v3, s2, #15
    v.movi       v1, #0
    v.and        v2, v6, v0
    v.and        v0, v7, v4
    v.movi       v4, #0
    v.movi       v6, #1
    v.movi       v7, #0
    v.cmp.ne     p1, v3, v1
    v.cmp.eq     p2, v2, v0
    @p1 v.sel        v0, v5, v4
    @p2 v.sel        v1, v6, v7
    s.shli       s2, s1, #2                      // element offset -> bytes (x4)
    vf.neg       v2, v0
    vf.cvt.u32.f32 v0, v1
    s.add        s1, s17, s2                     // &out_ptr0[...]
    s.add        s3, s18, s2                     // &out_ptr1[...]
    v.st.w       [s1, #0], v2
    vf.add       v1, v0, v2
    v.st.w       [s3, #0], v1
__rctx_next:
    exit
