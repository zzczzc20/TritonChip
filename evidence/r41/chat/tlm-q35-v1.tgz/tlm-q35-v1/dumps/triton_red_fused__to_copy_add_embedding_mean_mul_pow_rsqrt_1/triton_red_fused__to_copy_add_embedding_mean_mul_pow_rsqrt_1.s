    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s5, [s1, #24]                   // out_ptr1: device_ptr64 at arg_base+24
    s.ld.d       s6, [s1, #32]                   // out_ptr2: device_ptr64 at arg_base+32
    s.ld.d       s7, [s1, #40]                   // out_ptr3: device_ptr64 at arg_base+40
    v.iota       v0                              // arange(0, VLEN)
    s.ld.d       s1, [s2, #0]                    // one element, not a vector
    v.movi       v1, #0
    v.movi       v2, #0
    v.insert     v1, s1, #0
    s.lshri      s8, s1, #32
    v.insert     v2, s8, #0
    v.insert     v1, s1, #1
    s.lshri      s8, s1, #32
    v.insert     v2, s8, #1
    v.insert     v1, s1, #2
    s.lshri      s8, s1, #32
    v.insert     v2, s8, #2
    v.insert     v1, s1, #3
    s.lshri      s8, s1, #32
    v.insert     v2, s8, #3
    v.insert     v1, s1, #4
    s.lshri      s8, s1, #32
    v.insert     v2, s8, #4
    v.insert     v1, s1, #5
    s.lshri      s8, s1, #32
    v.insert     v2, s8, #5
    v.insert     v1, s1, #6
    s.lshri      s8, s1, #32
    v.insert     v2, s8, #6
    v.insert     v1, s1, #7
    s.lshri      s8, s1, #32
    v.insert     v2, s8, #7
    v.insert     v1, s1, #8
    s.lshri      s8, s1, #32
    v.insert     v2, s8, #8
    v.insert     v1, s1, #9
    s.lshri      s8, s1, #32
    v.insert     v2, s8, #9
    v.insert     v1, s1, #10
    s.lshri      s8, s1, #32
    v.insert     v2, s8, #10
    v.insert     v1, s1, #11
    s.lshri      s8, s1, #32
    v.insert     v2, s8, #11
    v.insert     v1, s1, #12
    s.lshri      s8, s1, #32
    v.insert     v2, s8, #12
    v.insert     v1, s1, #13
    s.lshri      s8, s1, #32
    v.insert     v2, s8, #13
    v.insert     v1, s1, #14
    s.lshri      s8, s1, #32
    v.insert     v2, s8, #14
    v.insert     v1, s1, #15
    s.lshri      s8, s1, #32
    v.insert     v2, s8, #15
    s.movz       s1, #0
    s.movz       s8, #2560
    s.movz       s9, #16
    s.addi       s10, s1, #0
    v.movi       v3, #0
    v.movi       v4, #0
    v.mov        v4, v3
for_1:
    s.cmp.ge     s11, s10, s8
    br.nz        s11, endfor_2
    v.extract    s11, v2, #0
    v.extract    s12, v1, #0
    s.shli       s13, s11, #32
    v.extract    s11, v2, #1
    s.or         s14, s12, s13
    s.movz       s12, #0
    v.movi       v3, #0
    v.extract    s13, v1, #1
    s.shli       s15, s11, #32
    s.cmp.ge     s11, s14, s12
    v.extract    s12, v2, #2
    s.or         s14, s13, s15
    s.movz       s13, #0
    v.insert     v3, s11, #0
    v.extract    s11, v1, #2
    s.shli       s15, s12, #32
    s.cmp.ge     s12, s14, s13
    v.extract    s13, v2, #3
    s.or         s14, s11, s15
    s.movz       s11, #0
    v.insert     v3, s12, #1
    v.extract    s12, v1, #3
    s.shli       s15, s13, #32
    s.cmp.ge     s13, s14, s11
    v.extract    s11, v2, #4
    s.or         s14, s12, s15
    s.movz       s12, #0
    v.insert     v3, s13, #2
    v.extract    s13, v1, #4
    s.shli       s15, s11, #32
    s.cmp.ge     s11, s14, s12
    v.extract    s12, v2, #5
    s.or         s14, s13, s15
    s.movz       s13, #0
    v.insert     v3, s11, #3
    v.extract    s11, v1, #5
    s.shli       s15, s12, #32
    s.cmp.ge     s12, s14, s13
    s.or         s13, s11, s15
    s.movz       s11, #0
    v.insert     v3, s12, #4
    v.extract    s12, v1, #6
    s.cmp.ge     s14, s13, s11
    v.splat      v5, s10
    v.extract    s11, v2, #6
    v.insert     v3, s14, #5
    v.add        v6, v5, v0
    s.shli       s13, s11, #32
    v.movi       v5, #2560
    s.or         s11, s12, s13
    v.cmp.lt     p1, v6, v5
    v.extract    s12, v2, #7
    s.movz       s13, #0
    v.extract    s14, v1, #7
    s.shli       s15, s12, #32
    s.cmp.ge     s12, s11, s13
    v.extract    s11, v2, #8
    s.or         s13, s14, s15
    s.movz       s14, #0
    v.insert     v3, s12, #6
    v.extract    s12, v1, #8
    s.shli       s15, s11, #32
    s.cmp.ge     s11, s13, s14
    v.extract    s13, v2, #9
    s.or         s14, s12, s15
    s.movz       s12, #0
    v.insert     v3, s11, #7
    v.extract    s11, v1, #9
    s.shli       s15, s13, #32
    s.cmp.ge     s13, s14, s12
    v.extract    s12, v2, #10
    s.or         s14, s11, s15
    s.movz       s11, #0
    v.insert     v3, s13, #8
    v.extract    s13, v1, #10
    s.shli       s15, s12, #32
    s.cmp.ge     s12, s14, s11
    v.extract    s11, v2, #11
    s.or         s14, s13, s15
    s.movz       s13, #0
    v.insert     v3, s12, #9
    v.extract    s12, v1, #11
    s.shli       s15, s11, #32
    s.cmp.ge     s11, s14, s13
    v.extract    s13, v2, #12
    s.or         s14, s12, s15
    s.movz       s12, #0
    v.insert     v3, s11, #10
    v.extract    s11, v1, #12
    s.shli       s15, s13, #32
    s.cmp.ge     s13, s14, s12
    v.extract    s12, v2, #13
    s.or         s14, s11, s15
    s.movz       s11, #0
    v.insert     v3, s13, #11
    v.extract    s13, v1, #13
    s.shli       s15, s12, #32
    s.cmp.ge     s12, s14, s11
    v.extract    s11, v2, #14
    s.or         s14, s13, s15
    s.movz       s13, #0
    v.insert     v3, s12, #12
    v.extract    s12, v1, #14
    s.shli       s15, s11, #32
    s.cmp.ge     s11, s14, s13
    v.extract    s13, v2, #15
    v.extract    s14, v2, #0
    s.or         s16, s12, s15
    s.movz       s12, #0
    v.insert     v3, s11, #13
    v.extract    s11, v1, #15
    s.shli       s15, s13, #32
    v.extract    s13, v1, #0
    s.shli       s17, s14, #32
    s.cmp.ge     s14, s16, s12
    v.extract    s12, v2, #1
    s.or         s16, s11, s15
    s.movz       s11, #0
    s.or         s15, s13, s17
    .li       s13, #248320
    v.insert     v3, s14, #14
    v.movi       v5, #0
    v.extract    s14, v1, #1
    s.shli       s17, s12, #32
    s.cmp.ge     s12, s16, s11
    s.cmp.lt     s11, s15, s13
    v.extract    s13, v2, #2
    s.or         s15, s14, s17
    .li       s14, #248320
    v.insert     v3, s12, #15
    v.insert     v5, s11, #0
    v.extract    s11, v1, #2
    s.shli       s12, s13, #32
    s.cmp.lt     s13, s15, s14
    v.extract    s14, v2, #3
    s.or         s15, s11, s12
    .li       s11, #248320
    v.insert     v5, s13, #1
    v.extract    s12, v1, #3
    s.shli       s13, s14, #32
    s.cmp.lt     s14, s15, s11
    v.extract    s11, v2, #4
    s.or         s15, s12, s13
    .li       s12, #248320
    v.insert     v5, s14, #2
    v.extract    s13, v1, #4
    s.shli       s14, s11, #32
    s.cmp.lt     s11, s15, s12
    v.extract    s12, v2, #5
    s.or         s15, s13, s14
    .li       s13, #248320
    v.insert     v5, s11, #3
    v.extract    s11, v1, #5
    s.shli       s14, s12, #32
    s.cmp.lt     s12, s15, s13
    v.extract    s13, v2, #6
    s.or         s15, s11, s14
    .li       s11, #248320
    v.insert     v5, s12, #4
    v.extract    s12, v1, #6
    s.shli       s14, s13, #32
    s.cmp.lt     s13, s15, s11
    v.movi       v7, #0
    s.or         s11, s12, s14
    v.insert     v5, s13, #5
    v.cmp.ne     p2, v3, v7
    v.extract    s12, v2, #7
    .li       s13, #248320
    v.extract    s14, v1, #7
    s.shli       s15, s12, #32
    s.cmp.lt     s12, s11, s13
    v.extract    s11, v2, #8
    s.or         s13, s14, s15
    .li       s14, #248320
    v.insert     v5, s12, #6
    v.extract    s12, v1, #8
    s.shli       s15, s11, #32
    s.cmp.lt     s11, s13, s14
    v.extract    s13, v2, #9
    s.or         s14, s12, s15
    .li       s12, #248320
    v.insert     v5, s11, #7
    v.extract    s11, v1, #9
    s.shli       s15, s13, #32
    s.cmp.lt     s13, s14, s12
    v.extract    s12, v2, #10
    s.or         s14, s11, s15
    .li       s11, #248320
    v.insert     v5, s13, #8
    v.extract    s13, v1, #10
    s.shli       s15, s12, #32
    s.cmp.lt     s12, s14, s11
    v.extract    s11, v2, #11
    s.or         s14, s13, s15
    .li       s13, #248320
    v.insert     v5, s12, #9
    v.extract    s12, v1, #11
    s.shli       s15, s11, #32
    s.cmp.lt     s11, s14, s13
    v.extract    s13, v2, #12
    s.or         s14, s12, s15
    .li       s12, #248320
    v.insert     v5, s11, #10
    v.extract    s11, v1, #12
    s.shli       s15, s13, #32
    s.cmp.lt     s13, s14, s12
    v.extract    s12, v2, #13
    s.or         s14, s11, s15
    .li       s11, #248320
    v.insert     v5, s13, #11
    v.extract    s13, v1, #13
    s.shli       s15, s12, #32
    s.cmp.lt     s12, s14, s11
    v.extract    s11, v2, #14
    s.or         s14, s13, s15
    .li       s13, #248320
    v.insert     v5, s12, #12
    v.extract    s12, v1, #14
    s.shli       s15, s11, #32
    s.cmp.lt     s11, s14, s13
    v.extract    s13, v2, #15
    s.or         s14, s12, s15
    .li       s12, #248320
    v.insert     v5, s11, #13
    v.extract    s11, v1, #15
    s.shli       s15, s13, #32
    s.cmp.lt     s13, s14, s12
    s.or         s12, s11, s15
    .li       s11, #248320
    v.insert     v5, s13, #14
    s.cmp.lt     s13, s12, s11
    v.movi       v3, #0
    v.insert     v5, s13, #15
    v.movi       v7, #0
    v.movi       v8, #1
    v.cmp.ne     p3, v5, v3
    p.and        p4, p2, p3
    s.movz       s11, #0
    @p4 v.sel        v3, v7, v8
    v.reduce.or  s12, v3
    s.cmp.eq     s13, s12, s11
    br.nz        s13, assert_ok_3
    trap         #677351
assert_ok_3:
    v.extract    s11, v2, #0
    v.extract    s12, v1, #0
    s.shli       s13, s11, #32
    v.extract    s11, v2, #1
    s.or         s14, s12, s13
    s.movz       s12, #2560
    v.extract    s13, v1, #1
    s.shli       s15, s11, #32
    s.mul        s11, s14, s12
    v.extract    s12, v2, #2
    s.or         s14, s13, s15
    s.movz       s13, #2560
    v.extract    s15, v1, #2
    s.shli       s16, s12, #32
    s.mul        s12, s14, s13
    v.extract    s13, v2, #3
    v.movi       v3, #0
    v.movi       v5, #0
    s.or         s14, s15, s16
    s.movz       s15, #2560
    s.lshri      s16, s11, #32
    v.extract    s17, v1, #3
    s.shli       s18, s13, #32
    s.mul        s13, s14, s15
    v.extract    s14, v2, #4
    v.insert     v3, s11, #0
    v.insert     v5, s16, #0
    s.or         s11, s17, s18
    s.movz       s15, #2560
    s.lshri      s16, s12, #32
    v.extract    s17, v1, #4
    s.shli       s18, s14, #32
    s.mul        s14, s11, s15
    v.extract    s11, v2, #5
    v.insert     v3, s12, #1
    v.insert     v5, s16, #1
    s.or         s12, s17, s18
    s.movz       s15, #2560
    s.lshri      s16, s13, #32
    v.extract    s17, v1, #5
    s.shli       s18, s11, #32
    s.mul        s11, s12, s15
    v.extract    s12, v2, #6
    v.insert     v3, s13, #2
    v.insert     v5, s16, #2
    s.or         s13, s17, s18
    s.movz       s15, #2560
    s.lshri      s16, s14, #32
    v.extract    s17, v1, #6
    s.shli       s18, s12, #32
    s.mul        s12, s13, s15
    v.extract    s13, v2, #7
    v.insert     v3, s14, #3
    v.insert     v5, s16, #3
    s.or         s14, s17, s18
    s.movz       s15, #2560
    s.lshri      s16, s11, #32
    v.extract    s17, v1, #7
    s.shli       s18, s13, #32
    s.mul        s13, s14, s15
    v.extract    s14, v2, #8
    v.insert     v3, s11, #4
    v.insert     v5, s16, #4
    s.or         s11, s17, s18
    s.movz       s15, #2560
    s.lshri      s16, s12, #32
    v.extract    s17, v1, #8
    s.shli       s18, s14, #32
    s.mul        s14, s11, s15
    v.extract    s11, v2, #9
    v.insert     v3, s12, #5
    v.insert     v5, s16, #5
    s.or         s12, s17, s18
    s.movz       s15, #2560
    s.lshri      s16, s13, #32
    v.extract    s17, v1, #9
    s.shli       s18, s11, #32
    s.mul        s11, s12, s15
    v.extract    s12, v2, #10
    v.insert     v3, s13, #6
    v.insert     v5, s16, #6
    s.or         s13, s17, s18
    s.movz       s15, #2560
    s.lshri      s16, s14, #32
    v.extract    s17, v1, #10
    s.shli       s18, s12, #32
    s.mul        s12, s13, s15
    v.extract    s13, v2, #11
    v.insert     v3, s14, #7
    v.insert     v5, s16, #7
    s.or         s14, s17, s18
    s.movz       s15, #2560
    s.lshri      s16, s11, #32
    v.extract    s17, v1, #11
    s.shli       s18, s13, #32
    s.mul        s13, s14, s15
    v.extract    s14, v2, #12
    v.insert     v3, s11, #8
    v.insert     v5, s16, #8
    s.or         s11, s17, s18
    s.movz       s15, #2560
    s.lshri      s16, s12, #32
    v.extract    s17, v1, #12
    s.shli       s18, s14, #32
    s.mul        s14, s11, s15
    v.extract    s11, v2, #13
    v.insert     v3, s12, #9
    v.insert     v5, s16, #9
    s.or         s12, s17, s18
    s.movz       s15, #2560
    s.lshri      s16, s13, #32
    v.extract    s17, v1, #13
    s.shli       s18, s11, #32
    s.mul        s11, s12, s15
    v.extract    s12, v2, #14
    v.insert     v3, s13, #10
    v.insert     v5, s16, #10
    s.or         s13, s17, s18
    s.movz       s15, #2560
    s.lshri      s16, s14, #32
    v.extract    s17, v1, #14
    s.shli       s18, s12, #32
    s.mul        s12, s13, s15
    v.extract    s13, v2, #15
    v.insert     v3, s14, #11
    v.insert     v5, s16, #11
    s.or         s14, s17, s18
    s.movz       s15, #2560
    s.lshri      s16, s11, #32
    v.extract    s17, v1, #15
    s.shli       s18, s13, #32
    s.mul        s13, s14, s15
    v.insert     v3, s11, #12
    v.insert     v5, s16, #12
    s.or         s11, s17, s18
    s.movz       s14, #2560
    s.lshri      s15, s12, #32
    v.extract    s16, v6, #0
    s.mul        s17, s11, s14
    v.insert     v3, s12, #13
    v.insert     v5, s15, #13
    s.shli       s11, s16, #32
    s.lshri      s12, s13, #32
    v.extract    s14, v6, #1
    s.ashri      s15, s11, #32
    v.insert     v3, s13, #14
    v.insert     v5, s12, #14
    v.movi       v7, #0
    v.movi       v8, #0
    s.shli       s11, s14, #32
    s.lshri      s12, s17, #32
    s.lshri      s13, s15, #32
    v.extract    s14, v6, #2
    s.ashri      s16, s11, #32
    v.insert     v3, s17, #15
    v.insert     v5, s12, #15
    v.insert     v7, s15, #0
    v.insert     v8, s13, #0
    s.shli       s11, s14, #32
    s.lshri      s12, s16, #32
    v.extract    s13, v6, #3
    s.ashri      s14, s11, #32
    v.insert     v7, s16, #1
    v.insert     v8, s12, #1
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v6, #4
    s.ashri      s15, s11, #32
    v.insert     v7, s14, #2
    v.insert     v8, s12, #2
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v6, #5
    s.ashri      s14, s11, #32
    v.insert     v7, s15, #3
    v.insert     v8, s12, #3
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v6, #6
    s.ashri      s15, s11, #32
    v.insert     v7, s14, #4
    v.insert     v8, s12, #4
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v6, #7
    s.ashri      s14, s11, #32
    v.insert     v7, s15, #5
    v.insert     v8, s12, #5
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v6, #8
    s.ashri      s15, s11, #32
    v.insert     v7, s14, #6
    v.insert     v8, s12, #6
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v6, #9
    s.ashri      s14, s11, #32
    v.insert     v7, s15, #7
    v.insert     v8, s12, #7
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v6, #10
    s.ashri      s15, s11, #32
    v.insert     v7, s14, #8
    v.insert     v8, s12, #8
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v6, #11
    s.ashri      s14, s11, #32
    v.insert     v7, s15, #9
    v.insert     v8, s12, #9
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v6, #12
    s.ashri      s15, s11, #32
    v.insert     v7, s14, #10
    v.insert     v8, s12, #10
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v6, #13
    s.ashri      s14, s11, #32
    v.insert     v7, s15, #11
    v.insert     v8, s12, #11
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v6, #14
    s.ashri      s15, s11, #32
    v.insert     v7, s14, #12
    v.insert     v8, s12, #12
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v6, #15
    s.ashri      s14, s11, #32
    v.insert     v7, s15, #13
    v.insert     v8, s12, #13
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    s.ashri      s13, s11, #32
    v.insert     v7, s14, #14
    v.insert     v8, s12, #14
    s.lshri      s11, s13, #32
    v.insert     v7, s13, #15
    v.insert     v8, s11, #15
    v.extract    s11, v5, #0
    v.extract    s12, v7, #0
    v.extract    s13, v8, #0
    v.extract    s14, v3, #0
    s.shli       s15, s13, #32
    s.shli       s13, s11, #32
    v.extract    s11, v8, #1
    v.extract    s16, v5, #1
    s.or         s17, s12, s15
    s.or         s12, s14, s13
    v.movi       v6, #0
    v.extract    s13, v7, #1
    s.shli       s14, s11, #32
    v.extract    s11, v3, #1
    s.shli       s15, s16, #32
    s.add        s16, s17, s12
    v.extract    s12, v8, #2
    v.extract    s17, v5, #2
    s.or         s18, s13, s14
    s.or         s13, s11, s15
    v.movi       v9, #0
    v.insert     v6, s16, #0
    v.extract    s11, v7, #2
    s.shli       s14, s12, #32
    v.extract    s12, v3, #2
    s.shli       s15, s17, #32
    s.lshri      s17, s16, #32
    s.add        s16, s18, s13
    v.extract    s13, v8, #3
    s.or         s18, s11, s14
    v.extract    s11, v5, #3
    s.or         s14, s12, s15
    v.insert     v9, s17, #0
    v.insert     v6, s16, #1
    v.extract    s12, v7, #3
    s.shli       s15, s13, #32
    v.extract    s13, v3, #3
    s.shli       s17, s11, #32
    s.lshri      s11, s16, #32
    s.add        s16, s18, s14
    v.extract    s14, v8, #4
    s.or         s18, s12, s15
    v.extract    s12, v5, #4
    s.or         s15, s13, s17
    v.insert     v9, s11, #1
    v.insert     v6, s16, #2
    v.extract    s11, v7, #4
    s.shli       s13, s14, #32
    v.extract    s14, v3, #4
    s.shli       s17, s12, #32
    s.lshri      s12, s16, #32
    s.add        s16, s18, s15
    v.extract    s15, v8, #5
    s.or         s18, s11, s13
    v.extract    s11, v5, #5
    s.or         s13, s14, s17
    v.insert     v9, s12, #2
    v.insert     v6, s16, #3
    v.extract    s12, v7, #5
    s.shli       s14, s15, #32
    v.extract    s15, v3, #5
    s.shli       s17, s11, #32
    s.lshri      s11, s16, #32
    s.add        s16, s18, s13
    v.extract    s13, v8, #6
    s.or         s18, s12, s14
    v.extract    s12, v5, #6
    s.or         s14, s15, s17
    v.insert     v9, s11, #3
    v.insert     v6, s16, #4
    v.extract    s11, v7, #6
    s.shli       s15, s13, #32
    v.extract    s13, v3, #6
    s.shli       s17, s12, #32
    s.lshri      s12, s16, #32
    s.add        s16, s18, s14
    v.extract    s14, v8, #7
    s.or         s18, s11, s15
    v.extract    s11, v5, #7
    s.or         s15, s13, s17
    v.insert     v9, s12, #4
    v.insert     v6, s16, #5
    v.extract    s12, v7, #7
    s.shli       s13, s14, #32
    v.extract    s14, v3, #7
    s.shli       s17, s11, #32
    s.lshri      s11, s16, #32
    s.add        s16, s18, s15
    v.extract    s15, v8, #8
    s.or         s18, s12, s13
    v.extract    s12, v5, #8
    s.or         s13, s14, s17
    v.insert     v9, s11, #5
    v.insert     v6, s16, #6
    v.extract    s11, v7, #8
    s.shli       s14, s15, #32
    v.extract    s15, v3, #8
    s.shli       s17, s12, #32
    s.lshri      s12, s16, #32
    s.add        s16, s18, s13
    v.extract    s13, v8, #9
    s.or         s18, s11, s14
    v.extract    s11, v5, #9
    s.or         s14, s15, s17
    v.insert     v9, s12, #6
    v.insert     v6, s16, #7
    v.extract    s12, v7, #9
    s.shli       s15, s13, #32
    v.extract    s13, v3, #9
    s.shli       s17, s11, #32
    s.lshri      s11, s16, #32
    s.add        s16, s18, s14
    v.extract    s14, v8, #10
    s.or         s18, s12, s15
    v.extract    s12, v5, #10
    s.or         s15, s13, s17
    v.insert     v9, s11, #7
    v.insert     v6, s16, #8
    v.extract    s11, v7, #10
    s.shli       s13, s14, #32
    v.extract    s14, v3, #10
    s.shli       s17, s12, #32
    s.lshri      s12, s16, #32
    s.add        s16, s18, s15
    v.extract    s15, v8, #11
    s.or         s18, s11, s13
    v.extract    s11, v5, #11
    s.or         s13, s14, s17
    v.insert     v9, s12, #8
    v.insert     v6, s16, #9
    v.extract    s12, v7, #11
    s.shli       s14, s15, #32
    v.extract    s15, v3, #11
    s.shli       s17, s11, #32
    s.lshri      s11, s16, #32
    s.add        s16, s18, s13
    v.extract    s13, v8, #12
    s.or         s18, s12, s14
    v.extract    s12, v5, #12
    s.or         s14, s15, s17
    v.insert     v9, s11, #9
    v.insert     v6, s16, #10
    v.extract    s11, v7, #12
    s.shli       s15, s13, #32
    v.extract    s13, v3, #12
    s.shli       s17, s12, #32
    s.lshri      s12, s16, #32
    s.add        s16, s18, s14
    v.extract    s14, v8, #13
    s.or         s18, s11, s15
    v.extract    s11, v5, #13
    s.or         s15, s13, s17
    v.insert     v9, s12, #10
    v.insert     v6, s16, #11
    v.extract    s12, v7, #13
    s.shli       s13, s14, #32
    v.extract    s14, v3, #13
    s.shli       s17, s11, #32
    s.lshri      s11, s16, #32
    s.add        s16, s18, s15
    v.extract    s15, v8, #14
    s.or         s18, s12, s13
    v.extract    s12, v5, #14
    s.or         s13, s14, s17
    v.insert     v9, s11, #11
    v.insert     v6, s16, #12
    v.extract    s11, v7, #14
    s.shli       s14, s15, #32
    v.extract    s15, v3, #14
    s.shli       s17, s12, #32
    s.lshri      s12, s16, #32
    s.add        s16, s18, s13
    v.extract    s13, v8, #15
    s.or         s18, s11, s14
    v.extract    s11, v5, #15
    s.or         s14, s15, s17
    v.insert     v9, s12, #12
    v.insert     v6, s16, #13
    v.extract    s12, v7, #15
    s.shli       s15, s13, #32
    v.extract    s13, v3, #15
    s.shli       s17, s11, #32
    s.lshri      s11, s16, #32
    s.add        s16, s18, s14
    s.or         s14, s12, s15
    s.or         s12, s13, s17
    v.insert     v9, s11, #13
    v.insert     v6, s16, #14
    s.lshri      s11, s16, #32
    s.add        s13, s14, s12
    v.insert     v9, s11, #14
    v.insert     v6, s13, #15
    v.movi       v3, #31
    s.lshri      s11, s13, #32
    v.movi       v5, #1
    v.insert     v9, s11, #15
    v.ashr       v7, v6, v3
    v.movi       v3, #0
    s.movz       s11, #0
    v.cmp.ne     p2, v9, v7
    @p2 v.sel        v7, v5, v3
    v.reduce.or  s12, v7
    s.cmp.eq     s13, s12, s11
    br.nz        s13, narrow_ok_4
    trap         #677220
narrow_ok_4:
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v3, [s3, v6]               // index is in elements (ISA sec 9.1)
    v.movi       v5, #0
    s.add        s11, s10, s9
    s.movz       s12, #1
    vf.cvt.bf16.f32 v6, v3
    vf.mul       v3, v6, v6
    vf.add       v6, v4, v3
    @p1 v.sel        v3, v6, v4
    v.mov        v5, v3
    v.mov        v4, v5
    s.mov        s10, s11
    br.nz        s12, for_1
endfor_2:
    s.ld.d       s10, [s2, #0]                   // one element, not a vector
    v.movi       v1, #0
    v.movi       v2, #0
    vf.reduce.add.b v3, v4
    v.movi       v4, #0
    vf.add       v5, v3, v4
    s.lshri      s2, s10, #32
    v.insert     v1, s10, #0
    v.insert     v2, s2, #0
    s.lshri      s2, s10, #32
    v.insert     v1, s10, #1
    v.insert     v2, s2, #1
    s.lshri      s2, s10, #32
    v.insert     v1, s10, #2
    v.insert     v2, s2, #2
    s.lshri      s2, s10, #32
    v.insert     v1, s10, #3
    v.insert     v2, s2, #3
    s.lshri      s2, s10, #32
    v.insert     v1, s10, #4
    v.insert     v2, s2, #4
    s.lshri      s2, s10, #32
    v.insert     v1, s10, #5
    v.insert     v2, s2, #5
    s.lshri      s2, s10, #32
    v.insert     v1, s10, #6
    v.insert     v2, s2, #6
    s.lshri      s2, s10, #32
    v.insert     v1, s10, #7
    v.insert     v2, s2, #7
    s.lshri      s2, s10, #32
    v.insert     v1, s10, #8
    v.insert     v2, s2, #8
    s.lshri      s2, s10, #32
    v.insert     v1, s10, #9
    v.insert     v2, s2, #9
    s.lshri      s2, s10, #32
    v.insert     v1, s10, #10
    v.insert     v2, s2, #10
    s.lshri      s2, s10, #32
    v.insert     v1, s10, #11
    v.insert     v2, s2, #11
    s.lshri      s2, s10, #32
    v.insert     v1, s10, #12
    v.insert     v2, s2, #12
    s.lshri      s2, s10, #32
    v.insert     v1, s10, #13
    v.insert     v2, s2, #13
    s.lshri      s2, s10, #32
    v.insert     v1, s10, #14
    v.insert     v2, s2, #14
    s.lshri      s2, s10, #32
    v.insert     v1, s10, #15
    v.insert     v2, s2, #15
    s.addi       s2, s1, #0
for_5:
    s.cmp.ge     s1, s2, s8
    br.nz        s1, endfor_6
    v.extract    s1, v2, #0
    v.splat      v3, s2
    v.extract    s10, v1, #0
    s.shli       s11, s1, #32
    v.extract    s1, v2, #1
    v.add        v4, v3, v0
    v.movi       v3, #2560
    s.shli       s12, s2, #1                     // element offset -> bytes (x2)
    s.or         s13, s10, s11
    s.movz       s10, #0
    v.movi       v6, #0
    v.extract    s11, v1, #1
    s.shli       s14, s1, #32
    s.add        s1, s4, s12                     // &in_ptr2[...]
    s.cmp.ge     s15, s13, s10
    v.extract    s10, v2, #2
    v.cmp.lt     p1, v4, v3
    s.or         s13, s11, s14
    s.movz       s11, #0
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v3, [s1, #0]
    v.insert     v6, s15, #0
    v.extract    s1, v1, #2
    s.shli       s14, s10, #32
    s.cmp.ge     s10, s13, s11
    v.extract    s11, v2, #3
    s.or         s13, s1, s14
    s.movz       s1, #0
    v.insert     v6, s10, #1
    v.extract    s10, v1, #3
    s.shli       s14, s11, #32
    s.cmp.ge     s11, s13, s1
    v.extract    s1, v2, #4
    s.or         s13, s10, s14
    s.movz       s10, #0
    v.insert     v6, s11, #2
    v.extract    s11, v1, #4
    s.shli       s14, s1, #32
    s.cmp.ge     s1, s13, s10
    v.extract    s10, v2, #5
    s.or         s13, s11, s14
    s.movz       s11, #0
    v.insert     v6, s1, #3
    v.extract    s1, v1, #5
    s.shli       s14, s10, #32
    s.cmp.ge     s10, s13, s11
    v.extract    s11, v2, #6
    s.or         s13, s1, s14
    s.movz       s1, #0
    v.insert     v6, s10, #4
    v.extract    s10, v1, #6
    s.shli       s14, s11, #32
    s.cmp.ge     s11, s13, s1
    s.or         s1, s10, s14
    v.insert     v6, s11, #5
    vf.cvt.bf16.f32 v7, v3
    v.extract    s10, v2, #7
    s.movz       s11, #0
    v.extract    s13, v1, #7
    s.shli       s14, s10, #32
    s.cmp.ge     s10, s1, s11
    v.extract    s1, v2, #8
    s.or         s11, s13, s14
    s.movz       s13, #0
    v.insert     v6, s10, #6
    v.extract    s10, v1, #8
    s.shli       s14, s1, #32
    s.cmp.ge     s1, s11, s13
    v.extract    s11, v2, #9
    s.or         s13, s10, s14
    s.movz       s10, #0
    v.insert     v6, s1, #7
    v.extract    s1, v1, #9
    s.shli       s14, s11, #32
    s.cmp.ge     s11, s13, s10
    v.extract    s10, v2, #10
    s.or         s13, s1, s14
    s.movz       s1, #0
    v.insert     v6, s11, #8
    v.extract    s11, v1, #10
    s.shli       s14, s10, #32
    s.cmp.ge     s10, s13, s1
    v.extract    s1, v2, #11
    s.or         s13, s11, s14
    s.movz       s11, #0
    v.insert     v6, s10, #9
    v.extract    s10, v1, #11
    s.shli       s14, s1, #32
    s.cmp.ge     s1, s13, s11
    v.extract    s11, v2, #12
    s.or         s13, s10, s14
    s.movz       s10, #0
    v.insert     v6, s1, #10
    v.extract    s1, v1, #12
    s.shli       s14, s11, #32
    s.cmp.ge     s11, s13, s10
    v.extract    s10, v2, #13
    s.or         s13, s1, s14
    s.movz       s1, #0
    v.insert     v6, s11, #11
    v.extract    s11, v1, #13
    s.shli       s14, s10, #32
    s.cmp.ge     s10, s13, s1
    v.extract    s1, v2, #14
    s.or         s13, s11, s14
    s.movz       s11, #0
    v.insert     v6, s10, #12
    v.extract    s10, v1, #14
    s.shli       s14, s1, #32
    s.cmp.ge     s1, s13, s11
    v.extract    s11, v2, #15
    v.extract    s13, v2, #0
    s.or         s15, s10, s14
    s.movz       s10, #0
    v.insert     v6, s1, #13
    v.extract    s1, v1, #15
    s.shli       s14, s11, #32
    v.extract    s11, v1, #0
    s.shli       s16, s13, #32
    s.cmp.ge     s13, s15, s10
    v.extract    s10, v2, #1
    s.or         s15, s1, s14
    s.movz       s1, #0
    s.or         s14, s11, s16
    .li       s11, #248320
    v.insert     v6, s13, #14
    v.movi       v3, #0
    v.extract    s13, v1, #1
    s.shli       s16, s10, #32
    s.cmp.ge     s10, s15, s1
    s.cmp.lt     s1, s14, s11
    v.extract    s11, v2, #2
    s.or         s14, s13, s16
    .li       s13, #248320
    v.insert     v6, s10, #15
    v.insert     v3, s1, #0
    v.extract    s1, v1, #2
    s.shli       s10, s11, #32
    s.cmp.lt     s11, s14, s13
    v.extract    s13, v2, #3
    s.or         s14, s1, s10
    .li       s1, #248320
    v.insert     v3, s11, #1
    v.extract    s10, v1, #3
    s.shli       s11, s13, #32
    s.cmp.lt     s13, s14, s1
    v.extract    s1, v2, #4
    s.or         s14, s10, s11
    .li       s10, #248320
    v.insert     v3, s13, #2
    v.extract    s11, v1, #4
    s.shli       s13, s1, #32
    s.cmp.lt     s1, s14, s10
    v.extract    s10, v2, #5
    s.or         s14, s11, s13
    .li       s11, #248320
    v.insert     v3, s1, #3
    v.extract    s1, v1, #5
    s.shli       s13, s10, #32
    s.cmp.lt     s10, s14, s11
    v.extract    s11, v2, #6
    s.or         s14, s1, s13
    .li       s1, #248320
    v.insert     v3, s10, #4
    v.extract    s10, v1, #6
    s.shli       s13, s11, #32
    s.cmp.lt     s11, s14, s1
    v.movi       v8, #0
    s.or         s1, s10, s13
    v.insert     v3, s11, #5
    v.cmp.ne     p2, v6, v8
    v.extract    s10, v2, #7
    .li       s11, #248320
    v.extract    s13, v1, #7
    s.shli       s14, s10, #32
    s.cmp.lt     s10, s1, s11
    v.extract    s1, v2, #8
    s.or         s11, s13, s14
    .li       s13, #248320
    v.insert     v3, s10, #6
    v.extract    s10, v1, #8
    s.shli       s14, s1, #32
    s.cmp.lt     s1, s11, s13
    v.extract    s11, v2, #9
    s.or         s13, s10, s14
    .li       s10, #248320
    v.insert     v3, s1, #7
    v.extract    s1, v1, #9
    s.shli       s14, s11, #32
    s.cmp.lt     s11, s13, s10
    v.extract    s10, v2, #10
    s.or         s13, s1, s14
    .li       s1, #248320
    v.insert     v3, s11, #8
    v.extract    s11, v1, #10
    s.shli       s14, s10, #32
    s.cmp.lt     s10, s13, s1
    v.extract    s1, v2, #11
    s.or         s13, s11, s14
    .li       s11, #248320
    v.insert     v3, s10, #9
    v.extract    s10, v1, #11
    s.shli       s14, s1, #32
    s.cmp.lt     s1, s13, s11
    v.extract    s11, v2, #12
    s.or         s13, s10, s14
    .li       s10, #248320
    v.insert     v3, s1, #10
    v.extract    s1, v1, #12
    s.shli       s14, s11, #32
    s.cmp.lt     s11, s13, s10
    v.extract    s10, v2, #13
    s.or         s13, s1, s14
    .li       s1, #248320
    v.insert     v3, s11, #11
    v.extract    s11, v1, #13
    s.shli       s14, s10, #32
    s.cmp.lt     s10, s13, s1
    v.extract    s1, v2, #14
    s.or         s13, s11, s14
    .li       s11, #248320
    v.insert     v3, s10, #12
    v.extract    s10, v1, #14
    s.shli       s14, s1, #32
    s.cmp.lt     s1, s13, s11
    v.extract    s11, v2, #15
    s.or         s13, s10, s14
    .li       s10, #248320
    v.insert     v3, s1, #13
    v.extract    s1, v1, #15
    s.shli       s14, s11, #32
    s.cmp.lt     s11, s13, s10
    s.or         s10, s1, s14
    .li       s1, #248320
    v.insert     v3, s11, #14
    s.cmp.lt     s11, s10, s1
    v.movi       v6, #0
    v.insert     v3, s11, #15
    v.movi       v8, #0
    v.movi       v9, #1
    v.cmp.ne     p3, v3, v6
    p.and        p4, p2, p3
    s.movz       s1, #0
    @p4 v.sel        v3, v8, v9
    v.reduce.or  s10, v3
    s.cmp.eq     s11, s10, s1
    br.nz        s11, assert_ok_7
    trap         #677351
assert_ok_7:
    v.extract    s1, v2, #0
    v.extract    s10, v1, #0
    s.shli       s11, s1, #32
    v.extract    s1, v2, #1
    s.or         s13, s10, s11
    s.movz       s10, #2560
    v.extract    s11, v1, #1
    s.shli       s14, s1, #32
    s.mul        s1, s13, s10
    v.extract    s10, v2, #2
    s.or         s13, s11, s14
    s.movz       s11, #2560
    v.extract    s14, v1, #2
    s.shli       s15, s10, #32
    s.mul        s10, s13, s11
    v.extract    s11, v2, #3
    v.movi       v3, #0
    v.movi       v6, #0
    s.or         s13, s14, s15
    s.movz       s14, #2560
    s.lshri      s15, s1, #32
    v.extract    s16, v1, #3
    s.shli       s17, s11, #32
    s.mul        s11, s13, s14
    v.extract    s13, v2, #4
    v.insert     v3, s1, #0
    v.insert     v6, s15, #0
    s.or         s1, s16, s17
    s.movz       s14, #2560
    s.lshri      s15, s10, #32
    v.extract    s16, v1, #4
    s.shli       s17, s13, #32
    s.mul        s13, s1, s14
    v.extract    s1, v2, #5
    v.insert     v3, s10, #1
    v.insert     v6, s15, #1
    s.or         s10, s16, s17
    s.movz       s14, #2560
    s.lshri      s15, s11, #32
    v.extract    s16, v1, #5
    s.shli       s17, s1, #32
    s.mul        s1, s10, s14
    v.extract    s10, v2, #6
    v.insert     v3, s11, #2
    v.insert     v6, s15, #2
    s.or         s11, s16, s17
    s.movz       s14, #2560
    s.lshri      s15, s13, #32
    v.extract    s16, v1, #6
    s.shli       s17, s10, #32
    s.mul        s10, s11, s14
    v.extract    s11, v2, #7
    v.insert     v3, s13, #3
    v.insert     v6, s15, #3
    s.or         s13, s16, s17
    s.movz       s14, #2560
    s.lshri      s15, s1, #32
    v.extract    s16, v1, #7
    s.shli       s17, s11, #32
    s.mul        s11, s13, s14
    v.extract    s13, v2, #8
    v.insert     v3, s1, #4
    v.insert     v6, s15, #4
    s.or         s1, s16, s17
    s.movz       s14, #2560
    s.lshri      s15, s10, #32
    v.extract    s16, v1, #8
    s.shli       s17, s13, #32
    s.mul        s13, s1, s14
    v.extract    s1, v2, #9
    v.insert     v3, s10, #5
    v.insert     v6, s15, #5
    s.or         s10, s16, s17
    s.movz       s14, #2560
    s.lshri      s15, s11, #32
    v.extract    s16, v1, #9
    s.shli       s17, s1, #32
    s.mul        s1, s10, s14
    v.extract    s10, v2, #10
    v.insert     v3, s11, #6
    v.insert     v6, s15, #6
    s.or         s11, s16, s17
    s.movz       s14, #2560
    s.lshri      s15, s13, #32
    v.extract    s16, v1, #10
    s.shli       s17, s10, #32
    s.mul        s10, s11, s14
    v.extract    s11, v2, #11
    v.insert     v3, s13, #7
    v.insert     v6, s15, #7
    s.or         s13, s16, s17
    s.movz       s14, #2560
    s.lshri      s15, s1, #32
    v.extract    s16, v1, #11
    s.shli       s17, s11, #32
    s.mul        s11, s13, s14
    v.extract    s13, v2, #12
    v.insert     v3, s1, #8
    v.insert     v6, s15, #8
    s.or         s1, s16, s17
    s.movz       s14, #2560
    s.lshri      s15, s10, #32
    v.extract    s16, v1, #12
    s.shli       s17, s13, #32
    s.mul        s13, s1, s14
    v.extract    s1, v2, #13
    v.insert     v3, s10, #9
    v.insert     v6, s15, #9
    s.or         s10, s16, s17
    s.movz       s14, #2560
    s.lshri      s15, s11, #32
    v.extract    s16, v1, #13
    s.shli       s17, s1, #32
    s.mul        s1, s10, s14
    v.extract    s10, v2, #14
    v.insert     v3, s11, #10
    v.insert     v6, s15, #10
    s.or         s11, s16, s17
    s.movz       s14, #2560
    s.lshri      s15, s13, #32
    v.extract    s16, v1, #14
    s.shli       s17, s10, #32
    s.mul        s10, s11, s14
    v.extract    s11, v2, #15
    v.insert     v3, s13, #11
    v.insert     v6, s15, #11
    s.or         s13, s16, s17
    s.movz       s14, #2560
    s.lshri      s15, s1, #32
    v.extract    s16, v1, #15
    s.shli       s17, s11, #32
    s.mul        s11, s13, s14
    v.insert     v3, s1, #12
    v.insert     v6, s15, #12
    s.or         s1, s16, s17
    s.movz       s13, #2560
    s.lshri      s14, s10, #32
    v.extract    s15, v4, #0
    s.mul        s16, s1, s13
    v.insert     v3, s10, #13
    v.insert     v6, s14, #13
    s.shli       s1, s15, #32
    s.lshri      s10, s11, #32
    v.extract    s13, v4, #1
    s.ashri      s14, s1, #32
    v.insert     v3, s11, #14
    v.insert     v6, s10, #14
    v.movi       v8, #0
    v.movi       v9, #0
    s.shli       s1, s13, #32
    s.lshri      s10, s16, #32
    s.lshri      s11, s14, #32
    v.extract    s13, v4, #2
    s.ashri      s15, s1, #32
    v.insert     v3, s16, #15
    v.insert     v6, s10, #15
    v.insert     v8, s14, #0
    v.insert     v9, s11, #0
    s.shli       s1, s13, #32
    s.lshri      s10, s15, #32
    v.extract    s11, v4, #3
    s.ashri      s13, s1, #32
    v.insert     v8, s15, #1
    v.insert     v9, s10, #1
    s.shli       s1, s11, #32
    s.lshri      s10, s13, #32
    v.extract    s11, v4, #4
    s.ashri      s14, s1, #32
    v.insert     v8, s13, #2
    v.insert     v9, s10, #2
    s.shli       s1, s11, #32
    s.lshri      s10, s14, #32
    v.extract    s11, v4, #5
    s.ashri      s13, s1, #32
    v.insert     v8, s14, #3
    v.insert     v9, s10, #3
    s.shli       s1, s11, #32
    s.lshri      s10, s13, #32
    v.extract    s11, v4, #6
    s.ashri      s14, s1, #32
    v.insert     v8, s13, #4
    v.insert     v9, s10, #4
    s.shli       s1, s11, #32
    s.lshri      s10, s14, #32
    v.extract    s11, v4, #7
    s.ashri      s13, s1, #32
    v.insert     v8, s14, #5
    v.insert     v9, s10, #5
    s.shli       s1, s11, #32
    s.lshri      s10, s13, #32
    v.extract    s11, v4, #8
    s.ashri      s14, s1, #32
    v.insert     v8, s13, #6
    v.insert     v9, s10, #6
    s.shli       s1, s11, #32
    s.lshri      s10, s14, #32
    v.extract    s11, v4, #9
    s.ashri      s13, s1, #32
    v.insert     v8, s14, #7
    v.insert     v9, s10, #7
    s.shli       s1, s11, #32
    s.lshri      s10, s13, #32
    v.extract    s11, v4, #10
    s.ashri      s14, s1, #32
    v.insert     v8, s13, #8
    v.insert     v9, s10, #8
    s.shli       s1, s11, #32
    s.lshri      s10, s14, #32
    v.extract    s11, v4, #11
    s.ashri      s13, s1, #32
    v.insert     v8, s14, #9
    v.insert     v9, s10, #9
    s.shli       s1, s11, #32
    s.lshri      s10, s13, #32
    v.extract    s11, v4, #12
    s.ashri      s14, s1, #32
    v.insert     v8, s13, #10
    v.insert     v9, s10, #10
    s.shli       s1, s11, #32
    s.lshri      s10, s14, #32
    v.extract    s11, v4, #13
    s.ashri      s13, s1, #32
    v.insert     v8, s14, #11
    v.insert     v9, s10, #11
    s.shli       s1, s11, #32
    s.lshri      s10, s13, #32
    v.extract    s11, v4, #14
    s.ashri      s14, s1, #32
    v.insert     v8, s13, #12
    v.insert     v9, s10, #12
    s.shli       s1, s11, #32
    s.lshri      s10, s14, #32
    v.extract    s11, v4, #15
    s.ashri      s13, s1, #32
    v.insert     v8, s14, #13
    v.insert     v9, s10, #13
    s.shli       s1, s11, #32
    s.lshri      s10, s13, #32
    s.ashri      s11, s1, #32
    v.insert     v8, s13, #14
    v.insert     v9, s10, #14
    s.lshri      s1, s11, #32
    v.insert     v8, s11, #15
    v.insert     v9, s1, #15
    v.extract    s1, v6, #0
    v.extract    s10, v8, #0
    v.extract    s11, v9, #0
    v.extract    s13, v3, #0
    s.shli       s14, s11, #32
    s.shli       s11, s1, #32
    v.extract    s1, v9, #1
    v.extract    s15, v6, #1
    s.or         s16, s10, s14
    s.or         s10, s13, s11
    v.movi       v4, #0
    v.extract    s11, v8, #1
    s.shli       s13, s1, #32
    v.extract    s1, v3, #1
    s.shli       s14, s15, #32
    s.add        s15, s16, s10
    v.extract    s10, v9, #2
    v.extract    s16, v6, #2
    s.or         s17, s11, s13
    s.or         s11, s1, s14
    v.movi       v10, #0
    v.insert     v4, s15, #0
    v.extract    s1, v8, #2
    s.shli       s13, s10, #32
    v.extract    s10, v3, #2
    s.shli       s14, s16, #32
    s.lshri      s16, s15, #32
    s.add        s15, s17, s11
    v.extract    s11, v9, #3
    s.or         s17, s1, s13
    v.extract    s1, v6, #3
    s.or         s13, s10, s14
    v.insert     v10, s16, #0
    v.insert     v4, s15, #1
    v.extract    s10, v8, #3
    s.shli       s14, s11, #32
    v.extract    s11, v3, #3
    s.shli       s16, s1, #32
    s.lshri      s1, s15, #32
    s.add        s15, s17, s13
    v.extract    s13, v9, #4
    s.or         s17, s10, s14
    v.extract    s10, v6, #4
    s.or         s14, s11, s16
    v.insert     v10, s1, #1
    v.insert     v4, s15, #2
    v.extract    s1, v8, #4
    s.shli       s11, s13, #32
    v.extract    s13, v3, #4
    s.shli       s16, s10, #32
    s.lshri      s10, s15, #32
    s.add        s15, s17, s14
    v.extract    s14, v9, #5
    s.or         s17, s1, s11
    v.extract    s1, v6, #5
    s.or         s11, s13, s16
    v.insert     v10, s10, #2
    v.insert     v4, s15, #3
    v.extract    s10, v8, #5
    s.shli       s13, s14, #32
    v.extract    s14, v3, #5
    s.shli       s16, s1, #32
    s.lshri      s1, s15, #32
    s.add        s15, s17, s11
    v.extract    s11, v9, #6
    s.or         s17, s10, s13
    v.extract    s10, v6, #6
    s.or         s13, s14, s16
    v.insert     v10, s1, #3
    v.insert     v4, s15, #4
    v.extract    s1, v8, #6
    s.shli       s14, s11, #32
    v.extract    s11, v3, #6
    s.shli       s16, s10, #32
    s.lshri      s10, s15, #32
    s.add        s15, s17, s13
    v.extract    s13, v9, #7
    s.or         s17, s1, s14
    v.extract    s1, v6, #7
    s.or         s14, s11, s16
    v.insert     v10, s10, #4
    v.insert     v4, s15, #5
    v.extract    s10, v8, #7
    s.shli       s11, s13, #32
    v.extract    s13, v3, #7
    s.shli       s16, s1, #32
    s.lshri      s1, s15, #32
    s.add        s15, s17, s14
    v.extract    s14, v9, #8
    s.or         s17, s10, s11
    v.extract    s10, v6, #8
    s.or         s11, s13, s16
    v.insert     v10, s1, #5
    v.insert     v4, s15, #6
    v.extract    s1, v8, #8
    s.shli       s13, s14, #32
    v.extract    s14, v3, #8
    s.shli       s16, s10, #32
    s.lshri      s10, s15, #32
    s.add        s15, s17, s11
    v.extract    s11, v9, #9
    s.or         s17, s1, s13
    v.extract    s1, v6, #9
    s.or         s13, s14, s16
    v.insert     v10, s10, #6
    v.insert     v4, s15, #7
    v.extract    s10, v8, #9
    s.shli       s14, s11, #32
    v.extract    s11, v3, #9
    s.shli       s16, s1, #32
    s.lshri      s1, s15, #32
    s.add        s15, s17, s13
    v.extract    s13, v9, #10
    s.or         s17, s10, s14
    v.extract    s10, v6, #10
    s.or         s14, s11, s16
    v.insert     v10, s1, #7
    v.insert     v4, s15, #8
    v.extract    s1, v8, #10
    s.shli       s11, s13, #32
    v.extract    s13, v3, #10
    s.shli       s16, s10, #32
    s.lshri      s10, s15, #32
    s.add        s15, s17, s14
    v.extract    s14, v9, #11
    s.or         s17, s1, s11
    v.extract    s1, v6, #11
    s.or         s11, s13, s16
    v.insert     v10, s10, #8
    v.insert     v4, s15, #9
    v.extract    s10, v8, #11
    s.shli       s13, s14, #32
    v.extract    s14, v3, #11
    s.shli       s16, s1, #32
    s.lshri      s1, s15, #32
    s.add        s15, s17, s11
    v.extract    s11, v9, #12
    s.or         s17, s10, s13
    v.extract    s10, v6, #12
    s.or         s13, s14, s16
    v.insert     v10, s1, #9
    v.insert     v4, s15, #10
    v.extract    s1, v8, #12
    s.shli       s14, s11, #32
    v.extract    s11, v3, #12
    s.shli       s16, s10, #32
    s.lshri      s10, s15, #32
    s.add        s15, s17, s13
    v.extract    s13, v9, #13
    s.or         s17, s1, s14
    v.extract    s1, v6, #13
    s.or         s14, s11, s16
    v.insert     v10, s10, #10
    v.insert     v4, s15, #11
    v.extract    s10, v8, #13
    s.shli       s11, s13, #32
    v.extract    s13, v3, #13
    s.shli       s16, s1, #32
    s.lshri      s1, s15, #32
    s.add        s15, s17, s14
    v.extract    s14, v9, #14
    s.or         s17, s10, s11
    v.extract    s10, v6, #14
    s.or         s11, s13, s16
    v.insert     v10, s1, #11
    v.insert     v4, s15, #12
    v.extract    s1, v8, #14
    s.shli       s13, s14, #32
    v.extract    s14, v3, #14
    s.shli       s16, s10, #32
    s.lshri      s10, s15, #32
    s.add        s15, s17, s11
    v.extract    s11, v9, #15
    s.or         s17, s1, s13
    v.extract    s1, v6, #15
    s.or         s13, s14, s16
    v.insert     v10, s10, #12
    v.insert     v4, s15, #13
    v.extract    s10, v8, #15
    s.shli       s14, s11, #32
    v.extract    s11, v3, #15
    s.shli       s16, s1, #32
    s.lshri      s1, s15, #32
    s.add        s15, s17, s13
    s.or         s13, s10, s14
    s.or         s10, s11, s16
    v.insert     v10, s1, #13
    v.insert     v4, s15, #14
    s.lshri      s1, s15, #32
    s.add        s11, s13, s10
    v.insert     v10, s1, #14
    v.insert     v4, s11, #15
    v.movi       v3, #31
    s.lshri      s1, s11, #32
    v.movi       v6, #1
    v.insert     v10, s1, #15
    v.ashr       v8, v4, v3
    v.movi       v3, #0
    s.movz       s1, #0
    v.cmp.ne     p2, v10, v8
    @p2 v.sel        v8, v6, v3
    v.reduce.or  s10, v8
    s.cmp.eq     s11, s10, s1
    br.nz        s11, narrow_ok_8
    trap         #677220
narrow_ok_8:
    .li       s1, #1159725056
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v6, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #897988541
    v.splat      v8, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v9, v3                          // ISA 8.8: <= 2**-22 relative
    .li       s1, #1077936128
    v.splat      v10, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #3204448256
    v.splat      v11, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v12, [s3, v4]              // index is in elements (ISA sec 9.1)
    .li       s1, #1065353216
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s1, s5, s12                     // &out_ptr1[...]
    s.add        s10, s6, s12                    // &out_ptr2[...]
    vf.add       v13, v7, v4
    s.add        s11, s7, s12                    // &out_ptr3[...]
    s.add        s12, s2, s9
    s.movz       s13, #1
    vf.cvt.bf16.f32 v4, v12
    vf.fms       v7, v3, v9, v6
    vf.fms       v6, v9, v7, v9
    vf.neg       v7, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v7, v7
    @p2 v.sel        v6, v7, v9
    vf.mul       v7, v5, v6                      // a/y: faithful quotient
    vf.fms       v9, v7, v3, v5
    vf.fms       v3, v9, v6, v7
    vf.neg       v6, v3                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v6, v6
    @p2 v.sel        v3, v6, v7
    vf.add       v6, v3, v8
    v.rsqrt.approx v3, v6                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v7, v3, v3
    vf.mul       v8, v3, v11
    vf.fms       v9, v6, v7, v10
    vf.mul       v6, v8, v9                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v6, v6
    @p2 v.sel        v7, v6, v3
    v.extract    s14, v7, #0
    v.splat      v3, s14
    vf.mul       v6, v4, v3
    vf.mul       v3, v6, v13
    vf.cvt.f32.bf16 v4, v3
    @p1 v.st.h       [s1, #0], v4
    @p1 v.st.h       [s10, #0], v4
    @p1 v.st.h       [s11, #0], v4
    s.mov        s2, s12
    br.nz        s13, for_5
endfor_6:
    exit
    exit
