    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s3, s4, s1
    .li       s1, #1431655766
    s.sub        s5, s2, s3
    s.movz       s2, #3
    s.xor        s3, s4, s5
    s.movz       s6, #0
    s.sub        s7, s3, s5
    s.movz       s3, #0
    s.mul        s8, s7, s1
    s.cmp.lt     s1, s2, s6
    s.movz       s6, #1
    s.sub        s9, s3, s1
    s.movz       s1, #0
    s.lshri      s3, s8, #32
    s.xor        s8, s5, s9
    s.sub        s5, s7, s3
    s.movz       s10, #0
    s.lshri      s11, s5, #1
    s.movz       s5, #0
    s.add        s12, s3, s11
    s.movz       s3, #0
    s.lshri      s11, s12, #1
    s.cmp.lt     s12, s4, s10
    s.xor        s10, s11, s8
    s.sub        s13, s3, s12
    s.sub        s3, s10, s8
    s.muli       s8, s11, #3
    s.sub        s10, s2, s3
    s.movz       s11, #0
    s.min.s      s12, s10, s6
    s.movz       s10, #1
    s.cmp.lt     s14, s12, s1
    s.xor        s1, s4, s13
    s.sub        s15, s5, s14
    s.rdspecial  s5, arg_base
    s.xor        s14, s12, s15
    s.xor        s16, s2, s9
    s.sub        s17, s14, s15
    s.movz       s14, #0
    s.sub        s15, s1, s13
    s.addi       s1, s11, #0
    s.ld.d       s11, [s5, #0]                   // in_ptr0: device_ptr64 at arg_base+0
    s.sub        s18, s16, s9
    s.sub        s9, s7, s8
    s.addi       s7, s14, #0
    s.ld.d       s8, [s5, #8]                    // arg_A: device_ptr64 at arg_base+8
    s.cmp.eq     s9, s17, s10
    s.ld.d       s10, [s5, #16]                  // arg_B: device_ptr64 at arg_base+16
    s.ld.d       s14, [s5, #24]                  // out_ptr0: device_ptr64 at arg_base+24
    s.mov        s1, s15
    br.nz        s9, sdiv_done_1
    s.movz       s5, #0
    s.movz       s9, #31
    s.mov        s1, s5
    s.addi       s5, s9, #0
sdiv_2:
    s.lshr       s9, s15, s5
    s.shli       s16, s7, #1
    s.andi       s18, s9, #1
    s.movz       s9, #0
    s.or         s19, s16, s18
    s.movz       s16, #1
    s.cmp.geu    s18, s19, s17
    s.shl        s20, s16, s5
    s.sub        s16, s9, s18
    s.subi       s9, s5, #1
    s.and        s18, s17, s16
    s.and        s21, s20, s16
    s.sub        s16, s19, s18
    s.or         s18, s1, s21
    s.mov        s7, s16
    s.mov        s1, s18
    s.mov        s5, s9
    s.movz       s9, #0
    s.cmp.ge     s16, s5, s9
    br.nz        s16, sdiv_2
sdiv_done_1:
    s.movz       s1, #0
    s.movz       s5, #0
    s.cmp.lt     s9, s4, s1
    .li       s1, #1431655766
    s.sub        s15, s5, s9
    s.movz       s5, #0
    s.xor        s9, s4, s15
    s.movz       s4, #0
    s.sub        s16, s9, s15
    s.movz       s9, #0
    s.mul        s17, s16, s1
    s.cmp.lt     s1, s12, s5
    s.movz       s5, #0
    s.movz       s18, #0
    s.sub        s19, s9, s1
    s.lshri      s1, s17, #32
    s.movz       s9, #0
    s.cmp.lt     s17, s2, s5
    s.xor        s5, s12, s19
    s.xor        s12, s7, s13
    s.sub        s7, s9, s17
    s.sub        s9, s16, s1
    s.sub        s17, s5, s19
    s.lshri      s5, s9, #1
    s.sub        s9, s12, s13
    s.add        s12, s1, s5
    s.movz       s1, #0
    s.lshri      s5, s12, #1
    s.movz       s12, #1
    s.muli       s13, s5, #3
    s.addi       s5, s1, #0
    s.cmp.eq     s1, s17, s12
    s.add        s12, s3, s9
    s.xor        s3, s2, s7
    s.sub        s9, s16, s13
    s.movz       s13, #0
    s.xor        s16, s9, s15
    s.sub        s9, s3, s7
    s.sub        s3, s16, s15
    s.addi       s7, s13, #0
    s.cmp.lt     s9, s3, s4
    s.sub        s4, s18, s9
    s.xor        s9, s3, s4
    s.sub        s3, s9, s4
    s.mov        s5, s3
    br.nz        s1, sdiv_done_3
    s.movz       s1, #0
    s.movz       s9, #31
    s.mov        s5, s1
    s.addi       s1, s9, #0
sdiv_4:
    s.lshr       s9, s3, s1
    s.shli       s13, s7, #1
    s.andi       s15, s9, #1
    s.movz       s9, #0
    s.or         s16, s13, s15
    s.movz       s13, #1
    s.cmp.geu    s15, s16, s17
    s.shl        s18, s13, s1
    s.sub        s13, s9, s15
    s.subi       s9, s1, #1
    s.and        s15, s17, s13
    s.and        s20, s18, s13
    s.sub        s13, s16, s15
    s.or         s15, s5, s20
    s.mov        s7, s13
    s.mov        s5, s15
    s.mov        s1, s9
    s.movz       s9, #0
    s.cmp.ge     s13, s1, s9
    br.nz        s13, sdiv_4
sdiv_done_3:
    s.movz       s1, #16
    s.xor        s3, s4, s19
    s.mul        s4, s12, s1
    s.xor        s7, s5, s3
    v.iota       v0                              // arange(0, VLEN)
    s.sub        s5, s7, s3
    v.movi       v1, #33
    v.splat      v2, s4
    s.mul        s3, s5, s1
    v.movi       v3, #0
    v.add        v4, v2, v0
    s.movz       s7, #0
    v.splat      v2, s12
    v.splat      v5, s7
    v.splat      v6, s5
    v.splat      v7, s7
    v.splat      v8, s3
    v.sub        v9, v3, v4
    v.sub        v10, v3, v1
    v.cmp.lt     p1, v4, v3
    v.cmp.lt     p2, v1, v3
    v.cmp.ge     p3, v2, v5
    v.cmp.ge     p3, v6, v7
    v.add        v2, v8, v0
    v.movi       v0, #1
    @p1 v.sel        v5, v9, v4
    @p2 v.sel        v4, v10, v1
    v.movi       v1, #0
    v.movi       v6, #0
    s.movz       s5, #31
idiv_5:
    v.splat      v7, s5
    v.shl        v8, v6, v0
    v.cmp.lt     p2, v6, v3
    v.lshr       v9, v5, v7
    v.shl        v10, v0, v7
    s.subi       s9, s5, #1
    v.and        v7, v9, v0
    s.movz       s12, #0
    v.or         v9, v8, v7
    v.cmp.geu    p3, v9, v4
    p.or         p4, p2, p3
    v.sub        v7, v9, v4
    @p4 v.sel        v8, v10, v3
    @p4 v.sel        v10, v7, v9
    v.or         v7, v1, v8
    v.mov        v6, v10
    v.mov        v1, v7
    s.mov        s5, s9
    s.cmp.ge     s9, s5, s12
    br.nz        s9, idiv_5
    v.movi       v0, #40
    v.movi       v1, #0
    v.sub        v4, v3, v6
    v.movi       v3, #1
    v.sub        v5, v1, v2
    v.sub        v7, v1, v0
    v.cmp.lt     p2, v2, v1
    v.cmp.lt     p3, v0, v1
    @p1 v.sel        v8, v4, v6
    @p2 v.sel        v4, v5, v2
    @p3 v.sel        v2, v7, v0
    v.movi       v0, #0
    v.movi       v5, #0
    s.movz       s5, #31
idiv_6:
    v.splat      v6, s5
    v.shl        v7, v5, v3
    v.cmp.lt     p1, v5, v1
    v.lshr       v9, v4, v6
    v.shl        v10, v3, v6
    s.subi       s9, s5, #1
    v.and        v6, v9, v3
    s.movz       s12, #0
    v.or         v9, v7, v6
    v.cmp.geu    p3, v9, v2
    p.or         p4, p1, p3
    v.sub        v6, v9, v2
    @p4 v.sel        v7, v10, v1
    @p4 v.sel        v10, v6, v9
    v.or         v6, v0, v7
    v.mov        v5, v10
    v.mov        v0, v6
    s.mov        s5, s9
    s.cmp.ge     s9, s5, s12
    br.nz        s9, idiv_6
    v.sub        v0, v1, v5
    s.movz       s5, #5
    s.addi       s9, s7, #0
    @p2 v.sel        v1, v0, v5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_7:
    s.cmp.ge     s12, s9, s5
    br.nz        s12, endfor_8
    s.mul        s12, s9, s1
    s.rdspecial  s13, arg_base
    s.movz       s15, #0
    s.ld.d       s16, [s13, #32]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.movz       s13, #72
    s.add        s17, s15, s12                   // the tile origin
    v.extract    s15, v8, #0
    v.extract    s18, v8, #1
    v.extract    s19, v8, #2
    v.extract    s20, v8, #3
    v.extract    s21, v8, #4
    s.rdspecial  s22, role_id
    s.movz       s23, #5632
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v2, s17
    v.splat      v3, s15
    v.splat      v4, s13
    v.splat      v5, s18
    v.splat      v6, s19
    v.splat      v7, s20
    v.splat      v9, s21
    s.mul        s15, s22, s23
    v.add        v10, v0, v2
    v.mul        v2, v3, v4
    v.mul        v3, v5, v4
    v.mul        v5, v6, v4
    v.mul        v6, v7, v4
    v.mul        v7, v9, v4
    s.add        s17, s16, s15                   // this context's own scratch
    v.splat      v9, s7
    v.add        v11, v10, v2
    v.add        v2, v10, v3
    v.add        v3, v10, v5
    v.add        v5, v10, v6
    v.add        v6, v10, v7
    s.addi       s15, s17, #0
    v.add        v7, v9, v11
    v.add        v11, v9, v2
    v.add        v2, v9, v3
    v.add        v3, v9, v5
    v.add        v5, v9, v6
    s.addi       s16, s15, #64
    s.addi       s18, s15, #128
    s.addi       s19, s15, #192
    s.addi       s20, s15, #256
    v.st.w       [s15, #0], v7
    s.sub        s21, s13, s12
    v.extract    s22, v8, #5
    v.extract    s23, v8, #6
    v.splat      v6, s22
    v.extract    s22, v8, #7
    v.mul        v7, v6, v4
    v.add        v6, v10, v7
    v.add        v7, v9, v6
    v.st.w       [s16, #0], v11
    v.extract    s16, v8, #8
    v.splat      v6, s23
    v.extract    s23, v8, #9
    v.mul        v11, v6, v4
    v.add        v6, v10, v11
    v.add        v11, v9, v6
    v.st.w       [s18, #0], v2
    v.extract    s18, v8, #10
    v.splat      v2, s22
    s.addi       s22, s15, #320
    v.mul        v6, v2, v4
    v.add        v2, v10, v6
    v.add        v6, v9, v2
    v.st.w       [s19, #0], v3
    v.extract    s19, v8, #11
    v.splat      v2, s16
    s.addi       s16, s15, #384
    v.mul        v3, v2, v4
    v.add        v2, v10, v3
    v.add        v3, v9, v2
    v.st.w       [s20, #0], v5
    v.extract    s20, v8, #12
    v.splat      v2, s23
    s.addi       s23, s15, #448
    v.mul        v5, v2, v4
    v.add        v2, v10, v5
    v.add        v5, v9, v2
    v.st.w       [s22, #0], v7
    v.extract    s22, v8, #13
    v.splat      v2, s18
    s.addi       s18, s15, #512
    v.mul        v7, v2, v4
    v.add        v2, v10, v7
    v.add        v7, v9, v2
    v.st.w       [s16, #0], v11
    v.extract    s16, v8, #14
    v.splat      v2, s19
    s.addi       s19, s15, #576
    v.mul        v11, v2, v4
    v.add        v2, v10, v11
    v.add        v11, v9, v2
    v.st.w       [s23, #0], v6
    v.extract    s23, v8, #15
    v.splat      v2, s20
    v.splat      v6, s22
    s.addi       s20, s15, #640
    v.mul        v12, v2, v4
    v.mul        v2, v6, v4
    s.addi       s22, s15, #704
    v.add        v6, v10, v12
    v.add        v12, v10, v2
    v.add        v2, v9, v6
    v.add        v6, v9, v12
    v.st.w       [s18, #0], v3
    v.splat      v3, s16
    s.addi       s16, s15, #768
    s.addi       s18, s15, #832
    v.mul        v12, v3, v4
    v.add        v3, v10, v12
    v.add        v12, v9, v3
    v.st.w       [s19, #0], v5
    v.splat      v3, s23
    s.addi       s19, s15, #896
    s.addi       s23, s15, #960
    v.mul        v5, v3, v4
    s.addi       s15, s17, #0
    v.add        v3, v10, v5
    v.add        v4, v9, v3
    v.st.w       [s20, #0], v7
    s.movz       s20, #0
    s.add        s24, s20, s21                   // the tile origin
    v.splat      v3, s24
    s.addi       s20, s17, #1024
    v.cmp.lt     p1, v0, v3
    v.st.w       [s22, #0], v11
    s.addi       s22, s17, #64
    v.st.w       [s16, #0], v2
    s.addi       s16, s20, #64
    v.st.w       [s18, #0], v6
    s.addi       s18, s17, #128
    v.st.w       [s19, #0], v12
    s.addi       s19, s20, #128
    v.st.w       [s23, #0], v4
    fence.acq_rel.device
    s.addi       s23, s17, #192
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s20, #192
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s20, #0], v2
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s17, #256
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v2
    s.addi       s16, s20, #256
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s17, #320
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s19, #0], v2
    s.addi       s19, s20, #320
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s17, #384
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s20, #384
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s17, #448
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v2
    s.addi       s16, s20, #448
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s17, #512
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s19, #0], v2
    s.addi       s19, s20, #512
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s17, #576
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s20, #576
    v.splat      v0, s7
    v.ld.w       v2, [s22, #0]
    s.addi       s22, s17, #640
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v3, [s8, v2]               // index is in elements (ISA sec 9.1)
    v.splat      v2, s13
    s.addi       s13, s20, #640
    v.st.w       [s16, #0], v3
    s.addi       s16, s17, #704
    v.mul        v3, v1, v2
    v.ld.w       v4, [s18, #0]
    s.addi       s18, s20, #704
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v5, [s8, v4]               // index is in elements (ISA sec 9.1)
    v.st.w       [s19, #0], v5
    s.addi       s19, s17, #768
    v.mul        v4, v1, v2
    v.ld.w       v5, [s23, #0]
    s.addi       s23, s20, #768
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v6, [s8, v5]               // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v6
    s.addi       s15, s17, #832
    v.ld.w       v5, [s22, #0]
    s.addi       s22, s20, #832
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v6, [s8, v5]               // index is in elements (ISA sec 9.1)
    v.mul        v5, v1, v2
    v.st.w       [s13, #0], v6
    s.addi       s13, s17, #896
    v.ld.w       v6, [s16, #0]
    s.addi       s16, s20, #896
    s.addi       s24, s20, #960
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v7, [s8, v6]               // index is in elements (ISA sec 9.1)
    v.st.w       [s18, #0], v7
    s.addi       s18, s17, #960
    v.mul        v6, v1, v2
    v.ld.w       v7, [s19, #0]
    s.movz       s19, #0
    s.add        s20, s19, s12                   // the tile origin
    s.addi       s12, s17, #2048
    v.splat      v9, s20
    v.add        v10, v9, v3
    v.add        v3, v0, v10
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v9, [s8, v7]               // index is in elements (ISA sec 9.1)
    v.st.w       [s23, #0], v9
    s.addi       s19, s20, #1
    v.splat      v7, s19
    s.addi       s19, s20, #2
    v.splat      v9, s19
    s.addi       s19, s20, #3
    v.add        v10, v7, v4
    v.splat      v4, s19
    s.addi       s19, s20, #4
    v.add        v7, v9, v5
    v.splat      v5, s19
    v.add        v9, v4, v6
    v.add        v4, v0, v10
    v.add        v6, v0, v7
    v.add        v7, v0, v9
    s.addi       s19, s12, #64
    v.ld.w       v9, [s15, #0]
    v.mul        v10, v1, v2
    s.addi       s15, s12, #128
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v11, [s8, v9]              // index is in elements (ISA sec 9.1)
    v.add        v9, v5, v10
    v.st.w       [s22, #0], v11
    v.add        v5, v0, v9
    s.addi       s22, s12, #192
    v.ld.w       v9, [s13, #0]
    s.addi       s13, s20, #5
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v10, [s8, v9]              // index is in elements (ISA sec 9.1)
    v.splat      v9, s13
    s.addi       s13, s12, #256
    v.st.w       [s16, #0], v10
    v.mul        v10, v1, v2
    s.addi       s16, s12, #320
    v.add        v11, v9, v10
    v.add        v9, v0, v11
    v.ld.w       v10, [s18, #0]
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v11, [s8, v10]             // index is in elements (ISA sec 9.1)
    s.addi       s18, s12, #384
    v.st.w       [s24, #0], v11
    s.addi       s23, s20, #6
    fence.acq_rel.device
    s.addi       s24, s20, #7
    v.splat      v10, s23
    v.mul        v11, v1, v2
    s.addi       s23, s12, #448
    v.add        v12, v10, v11
    v.splat      v10, s24
    v.add        v11, v0, v12
    v.st.w       [s12, #0], v3
    s.addi       s24, s20, #8
    v.mul        v3, v1, v2
    v.add        v12, v10, v3
    v.splat      v3, s24
    s.addi       s24, s12, #512
    v.add        v10, v0, v12
    v.st.w       [s19, #0], v4
    s.addi       s19, s20, #9
    v.mul        v4, v1, v2
    v.add        v12, v3, v4
    v.splat      v3, s19
    s.addi       s19, s12, #576
    v.add        v4, v0, v12
    v.st.w       [s15, #0], v6
    s.addi       s15, s20, #10
    v.mul        v6, v1, v2
    v.add        v12, v3, v6
    v.splat      v3, s15
    s.addi       s15, s12, #640
    v.add        v6, v0, v12
    v.st.w       [s22, #0], v7
    s.addi       s22, s20, #11
    v.mul        v7, v1, v2
    v.add        v12, v3, v7
    v.splat      v3, s22
    s.addi       s22, s12, #704
    v.add        v7, v0, v12
    v.st.w       [s13, #0], v5
    s.addi       s13, s20, #12
    v.mul        v5, v1, v2
    v.add        v12, v3, v5
    v.splat      v3, s13
    s.addi       s13, s12, #768
    v.add        v5, v0, v12
    v.st.w       [s16, #0], v9
    s.addi       s16, s20, #13
    v.mul        v9, v1, v2
    v.add        v12, v3, v9
    v.splat      v3, s16
    s.addi       s16, s12, #832
    v.add        v9, v0, v12
    v.st.w       [s18, #0], v11
    s.addi       s18, s20, #14
    v.mul        v11, v1, v2
    v.add        v12, v3, v11
    v.splat      v3, s18
    s.addi       s18, s12, #896
    v.add        v11, v0, v12
    v.st.w       [s23, #0], v10
    s.addi       s23, s20, #15
    v.mul        v10, v1, v2
    v.mul        v12, v1, v2
    v.splat      v2, s23
    v.add        v13, v3, v10
    s.addi       s20, s12, #960
    v.add        v3, v2, v12
    v.add        v2, v0, v13
    v.st.w       [s24, #0], v4
    v.add        v4, v0, v3
    s.addi       s12, s17, #2048
    v.splat      v0, s7
    s.addi       s23, s17, #3072
    v.st.w       [s19, #0], v6
    s.movz       s19, #0
    s.addi       s24, s23, #64
    s.add        s25, s19, s21                   // the tile origin
    v.splat      v3, s25
    v.cmp.lt     p1, v0, v3
    v.st.w       [s15, #0], v7
    s.addi       s15, s17, #2112
    v.splat      v0, s6
    s.addi       s19, s23, #128
    v.cmp.lt     p2, v0, v3
    v.st.w       [s22, #0], v5
    s.addi       s21, s17, #2176
    s.movz       s22, #2
    v.splat      v0, s22
    v.st.w       [s13, #0], v9
    s.addi       s13, s17, #2240
    v.splat      v5, s2
    s.addi       s22, s23, #192
    v.st.w       [s16, #0], v11
    s.addi       s16, s17, #2304
    s.movz       s25, #4
    s.addi       s26, s23, #256
    v.splat      v6, s25
    v.st.w       [s18, #0], v2
    s.addi       s18, s17, #2368
    v.splat      v2, s5
    s.addi       s25, s23, #320
    v.st.w       [s20, #0], v4
    fence.acq_rel.device
    s.addi       s20, s17, #2432
    s.addi       s27, s23, #384
    v.ld.w       v4, [s12, #0]
    s.movz       s12, #6
    v.splat      v7, s12
    s.addi       s12, s23, #448
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v9, [s10, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v0, v3
    v.st.w       [s23, #0], v9
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s17, #2496
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v4, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v3
    v.st.w       [s24, #0], v4
    s.movz       s24, #7
    v.splat      v0, s24
    s.addi       s24, s17, #2560
    v.ld.w       v4, [s21, #0]
    s.movz       s21, #8
    v.splat      v5, s21
    s.addi       s21, s23, #512
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v9, [s10, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v3
    v.st.w       [s19, #0], v9
    s.addi       s19, s17, #2624
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #9
    v.splat      v6, s13
    s.addi       s13, s23, #576
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v9, [s10, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v3
    v.st.w       [s22, #0], v9
    s.addi       s22, s17, #2688
    v.ld.w       v2, [s16, #0]
    s.movz       s16, #10
    v.splat      v4, s16
    s.addi       s16, s23, #640
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v9, [s10, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v7, v3
    v.st.w       [s26, #0], v9
    s.addi       s26, s17, #2752
    v.ld.w       v2, [s18, #0]
    s.movz       s18, #11
    v.splat      v7, s18
    s.addi       s18, s23, #704
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v9, [s10, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v3
    v.st.w       [s25, #0], v9
    s.addi       s25, s17, #2816
    v.ld.w       v0, [s20, #0]
    s.movz       s20, #12
    v.splat      v2, s20
    s.addi       s20, s23, #768
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v9, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v3
    v.st.w       [s27, #0], v9
    s.addi       s27, s17, #2880
    v.ld.w       v0, [s15, #0]
    s.movz       s15, #13
    v.splat      v5, s15
    s.addi       s15, s23, #832
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v9, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v3
    v.st.w       [s12, #0], v9
    s.addi       s12, s17, #2944
    v.ld.w       v0, [s24, #0]
    s.movz       s24, #14
    v.splat      v6, s24
    s.addi       s24, s23, #896
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v9, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v3
    v.st.w       [s21, #0], v9
    s.addi       s21, s17, #3008
    s.addi       s28, s23, #960
    v.ld.w       v0, [s19, #0]
    s.movz       s19, #15
    v.splat      v4, s19
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v9, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v7, v3
    v.st.w       [s13, #0], v9
    s.addi       s13, s17, #4096                 // 512 bytes of repack scratch
    v.ld.w       v0, [s22, #0]
    // repack 16x16 bf16 through memory: there is no v.pack (ISA sec 8.4)
    s.addi       s19, s17, #1024
    s.addi       s22, s17, #1088
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v7, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v3
    v.st.w       [s16, #0], v7
    s.addi       s16, s13, #32                   // row 1
    v.ld.w       v0, [s26, #0]
    s.addi       s23, s17, #1152
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v2, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v3
    v.st.w       [s18, #0], v2
    s.addi       s18, s13, #64                   // row 2
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s17, #1216
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v3
    v.st.w       [s20, #0], v2
    s.addi       s20, s13, #96                   // row 3
    v.ld.w       v0, [s27, #0]
    s.addi       s26, s17, #1280
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v2, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s13, #128                  // row 4
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s17, #1344
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.st.w       [s24, #0], v2
    s.addi       s24, s13, #160                  // row 5
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s17, #1408
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v2, [s10, v0]              // index is in elements (ISA sec 9.1)
    s.addi       s27, s13, #192                  // row 6
    v.st.w       [s28, #0], v2
    fence.acq_rel.device
    s.addi       s28, s17, #1472
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s13, #224                  // row 7
    v.st.h       [s13, #0], v0
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s17, #1536
    v.st.h       [s16, #0], v0
    s.addi       s16, s13, #256                  // row 8
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s17, #1600
    v.st.h       [s18, #0], v0
    s.addi       s18, s13, #288                  // row 9
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s17, #1664
    v.st.h       [s20, #0], v0
    s.addi       s20, s13, #320                  // row 10
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s17, #1728
    s.movz       s29, #0
    v.st.h       [s15, #0], v0
    s.addi       s15, s13, #352                  // row 11
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s17, #1792
    v.st.h       [s24, #0], v0
    s.addi       s24, s13, #384                  // row 12
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s17, #1856
    v.st.h       [s27, #0], v0
    s.addi       s27, s13, #416                  // row 13
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s17, #1920
    v.st.h       [s19, #0], v0
    s.addi       s19, s13, #448                  // row 14
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s17, #1984
    v.st.h       [s16, #0], v0
    s.addi       s16, s13, #480                  // row 15
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s17, #4608                 // TensorMap 0: a repacked tile
    v.st.h       [s18, #0], v0
    s.movz       s18, #16
    v.ld.w       v0, [s25, #0]
    s.movz       s25, #16
    v.st.h       [s20, #0], v0
    s.movz       s20, #32
    v.ld.w       v0, [s26, #0]
    s.movz       s26, #2
    v.st.h       [s15, #0], v0
    .li       s15, #68719476752
    v.ld.w       v0, [s12, #0]
    .li       s12, #1108101562368
    v.st.h       [s24, #0], v0
    s.movz       s24, #0
    v.ld.w       v0, [s21, #0]
    // repack 16x16 bf16 through memory: there is no v.pack (ISA sec 8.4)
    s.addi       s21, s17, #3072
    v.st.h       [s27, #0], v0
    s.addi       s27, s17, #4864                 // 512 bytes of repack scratch
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s17, #3136
    v.st.h       [s19, #0], v0
    s.addi       s19, s27, #32                   // row 1
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s17, #3200
    v.st.h       [s16, #0], v0
    s.addi       s16, s27, #64                   // row 2
    s.st.d       [s23, #0], s13
    s.addi       s13, s17, #3264
    s.st.d       [s23, #8], s18
    s.addi       s18, s27, #96                   // row 3
    s.st.d       [s23, #16], s25
    s.addi       s25, s17, #3328
    s.st.d       [s23, #48], s20
    s.addi       s20, s27, #128                  // row 4
    s.st.d       [s23, #56], s26
    s.addi       s26, s17, #3392
    s.st.d       [s23, #88], s15
    s.addi       s15, s27, #160                  // row 5
    s.st.d       [s23, #104], s12
    fence.release.device
    td.load      d0, [s23]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s12, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s23, s17, #3456
    s.addi       s29, s27, #192                  // row 6
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s30, s24                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s31, s24                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s30, s12
    mb.wait      s12
    s.addi       s24, s17, #3520
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s27, #224                  // row 7
    v.st.h       [s27, #0], v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s17, #3584
    v.st.h       [s19, #0], v0
    s.addi       s19, s27, #256                  // row 8
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s17, #3648
    v.st.h       [s16, #0], v0
    s.addi       s16, s27, #288                  // row 9
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s17, #3712
    v.st.h       [s18, #0], v0
    s.addi       s18, s27, #320                  // row 10
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s17, #3776
    s.movz       s30, #0
    v.st.h       [s20, #0], v0
    s.addi       s20, s27, #352                  // row 11
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s17, #3840
    v.st.h       [s15, #0], v0
    s.addi       s15, s27, #384                  // row 12
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s17, #3904
    v.st.h       [s29, #0], v0
    s.addi       s29, s27, #416                  // row 13
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s17, #3968
    v.st.h       [s21, #0], v0
    s.addi       s21, s27, #448                  // row 14
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s17, #4032
    s.addi       s30, s17, #5376                 // TensorMap 1: a repacked tile
    v.st.h       [s19, #0], v0
    s.addi       s17, s27, #480                  // row 15
    v.ld.w       v0, [s22, #0]
    s.movz       s19, #16
    v.st.h       [s16, #0], v0
    s.movz       s16, #16
    v.ld.w       v0, [s13, #0]
    s.movz       s13, #32
    s.add        s22, s9, s6
    v.st.h       [s18, #0], v0
    s.movz       s18, #2
    v.ld.w       v0, [s25, #0]
    .li       s25, #68719476752
    v.st.h       [s20, #0], v0
    .li       s20, #1108101562368
    v.ld.w       v0, [s26, #0]
    s.movz       s26, #0
    v.st.h       [s15, #0], v0
    s.movz       s15, #1
    v.ld.w       v0, [s23, #0]
    v.st.h       [s29, #0], v0
    v.ld.w       v0, [s24, #0]
    v.st.h       [s21, #0], v0
    v.ld.w       v0, [s28, #0]
    v.st.h       [s17, #0], v0
    s.st.d       [s30, #0], s27
    s.st.d       [s30, #8], s19
    s.st.d       [s30, #16], s16
    s.st.d       [s30, #48], s13
    s.st.d       [s30, #56], s18
    s.st.d       [s30, #88], s25
    s.st.d       [s30, #104], s20
    fence.release.device
    td.load      d1, [s30]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s13, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s16, s26                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s17, s26                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s16, s13
    mb.wait      s13
    mb.arm       s16, b2, #0, #1                 // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.bf16 a0, v56, v48, s16
    mb.wait      s16
    s.mov        s9, s22
    br.nz        s15, for_7
endfor_8:
    s.movz       s1, #0
    s.movz       s2, #0
    s.add        s5, s1, s3                      // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s5
    s.add        s1, s2, s4                      // the tile origin
    s.movz       s2, #33
    s.movz       s5, #40
    s.muli       s6, s3, #2                      // a runtime tile origin, x2
    v.splat      v2, s1
    v.splat      v3, s2
    v.add        v4, v0, v1
    v.splat      v0, s5
    v.cmp.lt     p1, v2, v3
    s.add        s2, s11, s6                     // the tile origin
    v.cmp.lt     p2, v4, v0
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s5, #0
    p.and        p3, p1, p2
    a.vread      v0, a0, s5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s2, #0]
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s5, s3, #2                      // a runtime tile origin, x2
    s.addi       s3, s1, #1
    s.muli       s6, s4, #80                     // a runtime tile origin, x80
    v.splat      v2, s1
    v.splat      v4, s3
    s.add        s3, s14, s5                     // the tile origin
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p3, v4, v3
    s.add        s4, s3, s6                      // the tile origin
    p.and        p4, p1, p2
    s.movz       s3, #1
    p.and        p1, p3, p2
    s.addi       s5, s1, #1
    vf.cvt.bf16.f32 v2, v1
    s.addi       s6, s1, #2
    v.splat      v1, s5
    v.splat      v4, s6
    s.addi       s5, s4, #80                     // row 1
    vf.add       v5, v0, v2
    s.movz       s6, #2
    s.addi       s7, s1, #2
    s.addi       s8, s1, #3
    v.splat      v0, s7
    vf.cvt.f32.bf16 v2, v5
    v.splat      v5, s8
    s.addi       s7, s4, #160                    // row 2
    s.movz       s8, #3
    s.addi       s9, s1, #3
    @p4 v.st.h       [s4, #0], v2
    a.vread      v2, a0, s3
    v.cmp.lt     p3, v1, v3
    p.and        p4, p3, p2
    s.addi       s3, s1, #4
    v.splat      v1, s9
    v.splat      v6, s3
    s.addi       s3, s4, #240                    // row 3
    s.movz       s9, #4
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v7, [s2, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v4, v7
    vf.add       v7, v2, v4
    vf.cvt.f32.bf16 v2, v7
    @p4 v.st.h       [s5, #0], v2
    a.vread      v2, a0, s6
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s5, s1, #4
    s.addi       s6, s1, #5
    v.splat      v0, s5
    v.splat      v4, s6
    s.addi       s5, s4, #320                    // row 4
    s.movz       s6, #5
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s2, #0]
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v5, v7
    vf.add       v7, v2, v5
    vf.cvt.f32.bf16 v2, v7
    @p4 v.st.h       [s7, #0], v2
    a.vread      v2, a0, s8
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s7, s1, #5
    s.addi       s8, s1, #6
    v.splat      v1, s7
    v.splat      v5, s8
    s.addi       s7, s4, #400                    // row 5
    s.movz       s8, #6
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s2, #0]
    v.cmp.lt     p1, v6, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v6, v7
    vf.add       v7, v2, v6
    vf.cvt.f32.bf16 v2, v7
    @p4 v.st.h       [s3, #0], v2
    a.vread      v2, a0, s9
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s3, s1, #6
    s.addi       s9, s1, #7
    v.splat      v0, s3
    v.splat      v6, s9
    s.addi       s3, s4, #480                    // row 6
    s.movz       s9, #7
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s2, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v4, v7
    vf.add       v7, v2, v4
    vf.cvt.f32.bf16 v2, v7
    @p4 v.st.h       [s5, #0], v2
    a.vread      v2, a0, s6
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s5, s1, #7
    s.addi       s6, s1, #8
    v.splat      v1, s5
    v.splat      v4, s6
    s.addi       s5, s4, #560                    // row 7
    s.movz       s6, #8
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s2, #0]
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v5, v7
    vf.add       v7, v2, v5
    vf.cvt.f32.bf16 v2, v7
    @p4 v.st.h       [s7, #0], v2
    a.vread      v2, a0, s8
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s7, s1, #8
    s.addi       s8, s1, #9
    v.splat      v0, s7
    v.splat      v5, s8
    s.addi       s7, s4, #640                    // row 8
    s.movz       s8, #9
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s2, #0]
    v.cmp.lt     p1, v6, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v6, v7
    vf.add       v7, v2, v6
    vf.cvt.f32.bf16 v2, v7
    @p4 v.st.h       [s3, #0], v2
    a.vread      v2, a0, s9
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s3, s1, #9
    s.addi       s9, s1, #10
    v.splat      v1, s3
    v.splat      v6, s9
    s.addi       s3, s4, #720                    // row 9
    s.movz       s9, #10
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s2, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v4, v7
    vf.add       v7, v2, v4
    vf.cvt.f32.bf16 v2, v7
    @p4 v.st.h       [s5, #0], v2
    a.vread      v2, a0, s6
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s5, s1, #10
    s.addi       s6, s1, #11
    v.splat      v0, s5
    v.splat      v4, s6
    s.addi       s5, s4, #800                    // row 10
    s.movz       s6, #11
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s2, #0]
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v5, v7
    vf.add       v7, v2, v5
    vf.cvt.f32.bf16 v2, v7
    @p4 v.st.h       [s7, #0], v2
    a.vread      v2, a0, s8
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s7, s1, #11
    s.addi       s8, s1, #12
    v.splat      v1, s7
    v.splat      v5, s8
    s.addi       s7, s4, #880                    // row 11
    s.movz       s8, #12
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s2, #0]
    v.cmp.lt     p1, v6, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v6, v7
    vf.add       v7, v2, v6
    vf.cvt.f32.bf16 v2, v7
    @p4 v.st.h       [s3, #0], v2
    a.vread      v2, a0, s9
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s3, s1, #12
    s.addi       s9, s1, #13
    v.splat      v0, s3
    v.splat      v6, s9
    s.addi       s3, s4, #960                    // row 12
    s.movz       s9, #13
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s2, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v4, v7
    vf.add       v7, v2, v4
    vf.cvt.f32.bf16 v2, v7
    @p4 v.st.h       [s5, #0], v2
    a.vread      v2, a0, s6
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s5, s1, #13
    s.addi       s6, s1, #14
    v.splat      v1, s5
    v.splat      v4, s6
    s.addi       s5, s4, #1040                   // row 13
    s.movz       s6, #14
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s2, #0]
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v5, v7
    vf.add       v7, v2, v5
    vf.cvt.f32.bf16 v2, v7
    @p4 v.st.h       [s7, #0], v2
    a.vread      v2, a0, s8
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s7, s1, #14
    s.addi       s8, s1, #15
    v.splat      v0, s7
    v.splat      v5, s8
    s.addi       s7, s4, #1120                   // row 14
    s.movz       s8, #15
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s2, #0]
    v.cmp.lt     p1, v6, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v6, v7
    vf.add       v7, v2, v6
    vf.cvt.f32.bf16 v2, v7
    s.addi       s10, s1, #15
    s.addi       s1, s4, #1200                   // row 15
    v.splat      v6, s10
    @p4 v.st.h       [s3, #0], v2
    a.vread      v2, a0, s9
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s2, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v4, v1
    vf.add       v1, v2, v4
    vf.cvt.f32.bf16 v2, v1
    @p4 v.st.h       [s5, #0], v2
    a.vread      v1, a0, s6
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s2, #0]
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v2, v0
    vf.add       v0, v1, v2
    vf.cvt.f32.bf16 v1, v0
    @p4 v.st.h       [s7, #0], v1
    a.vread      v0, a0, s8
    v.cmp.lt     p1, v6, v3
    p.and        p4, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s2, #0]
    vf.cvt.bf16.f32 v2, v1
    vf.add       v1, v0, v2
    vf.cvt.f32.bf16 v0, v1
    @p4 v.st.h       [s1, #0], v0
__rctx_next:
    exit
