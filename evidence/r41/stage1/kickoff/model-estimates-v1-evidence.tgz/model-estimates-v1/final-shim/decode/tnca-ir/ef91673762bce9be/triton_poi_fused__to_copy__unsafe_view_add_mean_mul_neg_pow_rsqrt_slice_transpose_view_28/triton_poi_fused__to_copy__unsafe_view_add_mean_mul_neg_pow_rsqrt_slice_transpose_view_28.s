    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    .li       s1, #1132462080
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v1                              // arange(0, VLEN)
    v.rcp.approx v2, v0                          // ISA 8.8: <= 2**-22 relative
    v.splat      v3, s1
    v.movi       v4, #0
    s.rdspecial  s1, arg_base
    v.add        v5, v3, v1
    v.movi       v1, #5
    s.ld.d       s2, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.sub        v3, v4, v5
    v.cmp.lt     p1, v5, v4
    v.movi       v6, #64
    @p1 v.sel        v7, v3, v5
    .li       s3, #1065353216
    v.splat      v3, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.lt     p2, v5, v6
    v.lshr       v8, v7, v1
    v.movi       v1, #0
    v.movi       v7, #31
    v.sub        v9, v4, v8
    v.sub        v10, v1, v5
    v.cmp.lt     p3, v5, v1
    @p1 v.sel        v11, v9, v8
    @p3 v.sel        v8, v10, v5
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v5, #32
    v.and        v9, v8, v7
    v.movi       v7, #256
    v.sub        v8, v1, v5
    v.sub        v10, v1, v9
    v.mul        v12, v11, v7
    vf.fms       v7, v0, v2, v3
    @p3 v.sel        v0, v10, v9
    v.sub        v3, v4, v5
    v.cmp.lt     p1, v5, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s2, v11]              // index is in elements (ISA sec 9.1)
    vf.fms       v9, v2, v7, v2
    v.add        v7, v0, v5
    v.cmp.lt     p3, v5, v4
    @p1 v.sel        v4, v8, v5
    v.add        v4, v7, v12
    vf.neg       v8, v9                          // Newton step: r0*(2 - x*r0)
    @p3 v.sel        v9, v3, v5
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v3, v8, v2
    s.ld.d       s2, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    vf.mul       v2, v1, v3                      // a/y as a refined reciprocal (ISA has no divide)
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v1, [s3, v4]               // index is in elements (ISA sec 9.1)
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v3, [s2, v7]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v4, v1
    vf.cvt.bf16.f32 v1, v3
    s.ld.d       s2, [s1, #24]                   // out_ptr0: device_ptr64 at arg_base+24
    .li       s1, #897988541
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1077936128
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #3204448256
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v8, v2, v3
    .li       s1, #1065353216
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.mul        v3, v11, v6
    vf.add       v6, v1, v2
    v.rsqrt.approx v1, v8                        // ISA 8.8: <= 2**-22 relative
    v.add        v2, v0, v3
    vf.mul       v0, v1, v1
    vf.mul       v3, v1, v7
    vf.fms       v7, v8, v0, v5
    vf.mul       v0, v3, v7                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v0, v0
    @p1 v.sel        v3, v0, v1
    vf.mul       v0, v4, v3
    vf.mul       v1, v0, v6
    vf.neg       v0, v1
    vf.cvt.f32.bf16 v1, v0
    @p2 v.st.scatter.h [s2, v2], v1
__rctx_next:
    exit
