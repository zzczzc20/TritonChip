    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, pid.y
    s.rdspecial  s2, arg_base
    s.shli       s3, s1, #4                      // x16 as a shift
    s.movz       s1, #0
    s.ld.d       s5, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s6, #4096
    s.add        s7, s1, s3                      // the tile origin
    s.movz       s8, #1
    s.movz       s9, #2
    s.movz       s10, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    s.movz       s14, #7
    s.movz       s15, #8
    s.ld.d       s16, [s2, #8]                   // out_ptr0: device_ptr64 at arg_base+8
    s.movz       s2, #9
    s.movz       s17, #10
    s.movz       s18, #11
    s.movz       s19, #12
    s.movz       s20, #13
    s.movz       s21, #14
    s.muli       s22, s3, #16384                 // a runtime tile origin, x16384
    s.movz       s3, #1
    s.movz       s23, #15
    s.shli       s24, s4, #4                     // x16 as a shift
    s.movz       s4, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.muli       s25, s24, #4096                 // a runtime tile origin, x4096
    s.muli       s26, s3, #16384
    s.movz       s3, #2
    s.movz       s27, #1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s6
    s.add        s6, s7, s25                     // the tile origin
    s.muli       s7, s3, #16384
    v.mul        v2, v0, v1
    s.movz       s3, #3
    s.movz       s25, #2
    v.splat      v0, s6
    s.muli       s28, s3, #16384
    s.movz       s3, #4
    v.add        v1, v2, v0
    s.movz       s29, #3
    s.addi       s30, s6, #1
    v.ld.gather.w v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s30
    s.muli       s30, s3, #16384
    s.movz       s3, #5
    s.movz       s31, #4
    v.add        v3, v2, v1
    s.muli       s32, s3, #16384
    s.movz       s3, #6
    s.movz       s33, #5
    s.addi       s34, s6, #2
    s.muli       s35, s3, #16384
    v.splat      v1, s34
    s.movz       s3, #7
    s.movz       s34, #6
    v.add        v4, v2, v1
    s.addi       s36, s6, #3
    s.muli       s37, s3, #16384
    s.movz       s3, #8
    a.vwrite     a0, s1, v0
    v.ld.gather.w v0, [s5, v3]                   // index is in elements (ISA sec 9.1)
    s.movz       s1, #7
    v.splat      v1, s36
    s.muli       s36, s3, #16384
    s.movz       s3, #9
    v.add        v3, v2, v1
    s.movz       s38, #8
    s.addi       s39, s6, #4
    s.muli       s40, s3, #16384
    v.splat      v1, s39
    s.movz       s3, #10
    s.movz       s39, #9
    v.add        v5, v2, v1
    s.muli       s41, s3, #16384
    s.movz       s3, #11
    s.movz       s42, #10
    s.addi       s43, s6, #5
    s.muli       s44, s3, #16384
    a.vwrite     a0, s8, v0
    v.ld.gather.w v0, [s5, v4]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s43
    s.movz       s3, #12
    s.movz       s8, #11
    v.add        v4, v2, v1
    s.addi       s43, s6, #6
    s.muli       s45, s3, #16384
    s.movz       s3, #13
    s.movz       s46, #12
    v.splat      v1, s43
    s.muli       s43, s3, #16384
    s.movz       s3, #14
    v.add        v6, v2, v1
    s.movz       s47, #13
    s.addi       s48, s6, #7
    s.muli       s49, s3, #16384
    s.movz       s3, #15
    s.movz       s50, #14
    a.vwrite     a0, s9, v0
    v.ld.gather.w v0, [s5, v3]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s48
    s.muli       s9, s3, #16384
    s.movz       s3, #15
    v.add        v3, v2, v1
    s.addi       s48, s6, #8
    s.addi       s51, s6, #9
    s.addi       s52, s6, #10
    s.addi       s53, s6, #11
    s.addi       s54, s6, #12
    s.addi       s55, s6, #13
    a.vwrite     a0, s10, v0
    v.ld.gather.w v0, [s5, v5]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s48
    s.addi       s10, s6, #14
    v.add        v5, v2, v1
    a.vwrite     a0, s11, v0
    v.ld.gather.w v0, [s5, v4]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s51
    s.addi       s11, s6, #15
    v.add        v4, v2, v1
    a.vwrite     a0, s12, v0
    v.ld.gather.w v0, [s5, v6]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s52
    s.muli       s6, s24, #4                     // a runtime tile origin, x4
    v.add        v6, v2, v1
    s.add        s12, s16, s6                    // the tile origin
    a.vwrite     a0, s13, v0
    v.ld.gather.w v0, [s5, v3]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s53
    s.add        s6, s12, s22                    // the tile origin
    v.add        v3, v2, v1
    s.add        s12, s6, s26
    a.vwrite     a0, s14, v0
    v.ld.gather.w v0, [s5, v5]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s54
    s.add        s13, s6, s7
    v.add        v5, v2, v1
    a.vwrite     a0, s15, v0
    v.ld.gather.w v0, [s5, v4]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s55
    s.add        s7, s6, s28
    s.add        s14, s6, s30
    v.add        v4, v2, v1
    a.vwrite     a0, s2, v0
    v.ld.gather.w v0, [s5, v6]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s10
    s.add        s2, s6, s32
    s.add        s10, s6, s35
    v.add        v6, v2, v1
    a.vwrite     a0, s17, v0
    v.ld.gather.w v0, [s5, v3]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s11
    s.add        s11, s6, s37
    v.add        v3, v2, v1
    a.vwrite     a0, s18, v0
    v.ld.gather.w v0, [s5, v5]                   // index is in elements (ISA sec 9.1)
    s.add        s15, s6, s36
    s.add        s16, s6, s40
    a.vwrite     a0, s19, v0
    v.ld.gather.w v0, [s5, v4]                   // index is in elements (ISA sec 9.1)
    s.add        s17, s6, s41
    s.add        s18, s6, s44
    a.vwrite     a0, s20, v0
    v.ld.gather.w v0, [s5, v6]                   // index is in elements (ISA sec 9.1)
    s.add        s19, s6, s45
    a.vwrite     a0, s21, v0
    v.ld.gather.w v0, [s5, v3]                   // index is in elements (ISA sec 9.1)
    s.add        s5, s6, s43
    s.add        s20, s6, s49
    a.vwrite     a0, s23, v0
    // tile epilogue: 16 rows through the vector unit, as f32 (ISA sec 9B)
    a.vread      v0, a0, s4
    s.add        s4, s6, s9
    v.st.w       [s6, #0], v0
    a.vread      v0, a0, s27
    v.st.w       [s12, #0], v0
    a.vread      v0, a0, s25
    v.st.w       [s13, #0], v0
    a.vread      v0, a0, s29
    v.st.w       [s7, #0], v0
    a.vread      v0, a0, s31
    v.st.w       [s14, #0], v0
    a.vread      v0, a0, s33
    v.st.w       [s2, #0], v0
    a.vread      v0, a0, s34
    v.st.w       [s10, #0], v0
    a.vread      v0, a0, s1
    v.st.w       [s11, #0], v0
    a.vread      v0, a0, s38
    v.st.w       [s15, #0], v0
    a.vread      v0, a0, s39
    v.st.w       [s16, #0], v0
    a.vread      v0, a0, s42
    v.st.w       [s17, #0], v0
    a.vread      v0, a0, s8
    v.st.w       [s18, #0], v0
    a.vread      v0, a0, s46
    v.st.w       [s19, #0], v0
    a.vread      v0, a0, s47
    v.st.w       [s5, #0], v0
    a.vread      v0, a0, s50
    v.st.w       [s20, #0], v0
    a.vread      v0, a0, s3
    v.st.w       [s4, #0], v0
__rctx_next:
    exit
