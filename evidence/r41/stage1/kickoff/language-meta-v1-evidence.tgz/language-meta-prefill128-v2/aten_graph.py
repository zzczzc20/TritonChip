


def forward(self, input_ids_1):
    full = torch.ops.aten.full.default([128, 128], -inf, dtype = torch.bfloat16, device = device(type='meta'), pin_memory = False)
    triu = torch.ops.aten.triu.default(full, 1);  full = None
    unsqueeze = torch.ops.aten.unsqueeze.default(triu, 0);  triu = None
    unsqueeze_1 = torch.ops.aten.unsqueeze.default(unsqueeze, 1);  unsqueeze = None
    _param_constant0 = self._param_constant0
    embedding = torch.ops.aten.embedding.default(_param_constant0, input_ids_1);  _param_constant0 = input_ids_1 = None
    arange = torch.ops.aten.arange.default(128, device = device(type='meta'), pin_memory = False)
    add = torch.ops.aten.add.Tensor(arange, 0);  arange = None
    view = torch.ops.aten.view.default(add, [1, 1, -1]);  add = None
    expand = torch.ops.aten.expand.default(view, [4, 1, -1]);  view = None
    select = torch.ops.aten.select.int(expand, 0, 0);  select = None
    slice_1 = torch.ops.aten.slice.Tensor(expand, 0, 1, 9223372036854775807);  expand = None
    expand_1 = torch.ops.aten.expand.default(slice_1, [3, -1, -1]);  slice_1 = None
    unsqueeze_2 = torch.ops.aten.unsqueeze.default(expand_1, 3);  expand_1 = None
    _to_copy = torch.ops.aten._to_copy.default(unsqueeze_2, dtype = torch.float32);  unsqueeze_2 = None
    _tensor_constant0 = self._tensor_constant0
    _to_copy_1 = torch.ops.aten._to_copy.default(_tensor_constant0, dtype = torch.float32, device = device(type='meta'));  _tensor_constant0 = None
    mul = torch.ops.aten.mul.Tensor(_to_copy, _to_copy_1);  _to_copy = _to_copy_1 = None
    cos = torch.ops.aten.cos.default(mul)
    mul_1 = torch.ops.aten.mul.Tensor(cos, 1.0);  cos = None
    sin = torch.ops.aten.sin.default(mul);  mul = None
    mul_2 = torch.ops.aten.mul.Tensor(sin, 1.0);  sin = None
    select_1 = torch.ops.aten.select.int(mul_2, 0, 0)
    select_2 = torch.ops.aten.select.int(mul_2, 0, 1)
    slice_2 = torch.ops.aten.slice.Tensor(select_2, 2, 1, 33, 3);  select_2 = None
    slice_3 = torch.ops.aten.slice.Tensor(select_1, 2, 1, 33, 3)
    copy_ = torch.ops.aten.copy_.default(slice_3, slice_2);  slice_3 = slice_2 = copy_ = None
    select_3 = torch.ops.aten.select.int(mul_2, 0, 2);  mul_2 = None
    slice_4 = torch.ops.aten.slice.Tensor(select_3, 2, 2, 30, 3);  select_3 = None
    slice_5 = torch.ops.aten.slice.Tensor(select_1, 2, 2, 30, 3)
    copy__1 = torch.ops.aten.copy_.default(slice_5, slice_4);  slice_5 = slice_4 = copy__1 = None
    cat = torch.ops.aten.cat.default([select_1, select_1], -1);  select_1 = None
    select_4 = torch.ops.aten.select.int(mul_1, 0, 0)
    select_5 = torch.ops.aten.select.int(mul_1, 0, 1)
    slice_6 = torch.ops.aten.slice.Tensor(select_5, 2, 1, 33, 3);  select_5 = None
    slice_7 = torch.ops.aten.slice.Tensor(select_4, 2, 1, 33, 3)
    copy__2 = torch.ops.aten.copy_.default(slice_7, slice_6);  slice_7 = slice_6 = copy__2 = None
    select_6 = torch.ops.aten.select.int(mul_1, 0, 2);  mul_1 = None
    slice_8 = torch.ops.aten.slice.Tensor(select_6, 2, 2, 30, 3);  select_6 = None
    slice_9 = torch.ops.aten.slice.Tensor(select_4, 2, 2, 30, 3)
    copy__3 = torch.ops.aten.copy_.default(slice_9, slice_8);  slice_9 = slice_8 = copy__3 = None
    cat_1 = torch.ops.aten.cat.default([select_4, select_4], -1);  select_4 = None
    _to_copy_2 = torch.ops.aten._to_copy.default(cat_1, dtype = torch.bfloat16);  cat_1 = None
    _to_copy_3 = torch.ops.aten._to_copy.default(cat, dtype = torch.bfloat16);  cat = None
    _to_copy_4 = torch.ops.aten._to_copy.default(embedding, dtype = torch.float32)
    pow_1 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_4, 2)
    mean = torch.ops.aten.mean.dim(pow_1, [-1], True);  pow_1 = None
    add_1 = torch.ops.aten.add.Tensor(mean, 1e-06);  mean = None
    rsqrt = torch.ops.aten.rsqrt.default(add_1);  add_1 = None
    mul_3 = torch.ops.aten.mul.Tensor(_to_copy_4, rsqrt);  _to_copy_4 = rsqrt = None
    _param_constant1 = self._param_constant1
    _to_copy_5 = torch.ops.aten._to_copy.default(_param_constant1, dtype = torch.float32);  _param_constant1 = None
    add_2 = torch.ops.aten.add.Tensor(_to_copy_5, 1.0);  _to_copy_5 = None
    mul_4 = torch.ops.aten.mul.Tensor(mul_3, add_2);  mul_3 = add_2 = None
    _to_copy_6 = torch.ops.aten._to_copy.default(mul_4, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_4 = None
    _param_constant2 = self._param_constant2
    t = torch.ops.aten.t.default(_param_constant2);  _param_constant2 = None
    view_1 = torch.ops.aten.view.default(_to_copy_6, [128, 2048])
    mm = torch.ops.aten.mm.default(view_1, t);  view_1 = t = None
    _unsafe_view = torch.ops.aten._unsafe_view.default(mm, [1, 128, 6144]);  mm = None
    transpose = torch.ops.aten.transpose.int(_unsafe_view, 1, 2);  _unsafe_view = None
    _param_constant3 = self._param_constant3
    t_1 = torch.ops.aten.t.default(_param_constant3);  _param_constant3 = None
    view_2 = torch.ops.aten.view.default(_to_copy_6, [128, 2048])
    mm_1 = torch.ops.aten.mm.default(view_2, t_1);  view_2 = t_1 = None
    _unsafe_view_1 = torch.ops.aten._unsafe_view.default(mm_1, [1, 128, 2048]);  mm_1 = None
    view_3 = torch.ops.aten.view.default(_unsafe_view_1, [1, 128, -1, 128]);  _unsafe_view_1 = None
    _param_constant4 = self._param_constant4
    t_2 = torch.ops.aten.t.default(_param_constant4);  _param_constant4 = None
    view_4 = torch.ops.aten.view.default(_to_copy_6, [128, 2048])
    mm_2 = torch.ops.aten.mm.default(view_4, t_2);  view_4 = t_2 = None
    _unsafe_view_2 = torch.ops.aten._unsafe_view.default(mm_2, [1, 128, 16]);  mm_2 = None
    _param_constant5 = self._param_constant5
    t_3 = torch.ops.aten.t.default(_param_constant5);  _param_constant5 = None
    view_5 = torch.ops.aten.view.default(_to_copy_6, [128, 2048]);  _to_copy_6 = None
    mm_3 = torch.ops.aten.mm.default(view_5, t_3);  view_5 = t_3 = None
    _unsafe_view_3 = torch.ops.aten._unsafe_view.default(mm_3, [1, 128, 16]);  mm_3 = None
    _param_constant6 = self._param_constant6
    squeeze = torch.ops.aten.squeeze.dim(_param_constant6, 1);  _param_constant6 = None
    unsqueeze_3 = torch.ops.aten.unsqueeze.default(squeeze, 1);  squeeze = None
    convolution = torch.ops.aten.convolution.default(transpose, unsqueeze_3, None, [1], [3], [1], False, [0], 6144);  transpose = unsqueeze_3 = None
    slice_10 = torch.ops.aten.slice.Tensor(convolution, 2, 0, 128);  convolution = None
    silu = torch.ops.aten.silu.default(slice_10);  slice_10 = None
    transpose_1 = torch.ops.aten.transpose.int(silu, 1, 2);  silu = None
    split_with_sizes = torch.ops.aten.split_with_sizes.default(transpose_1, [2048, 2048, 2048], -1);  transpose_1 = None
    getitem = split_with_sizes[0]
    getitem_1 = split_with_sizes[1]
    getitem_2 = split_with_sizes[2];  split_with_sizes = None
    view_6 = torch.ops.aten.view.default(getitem, [1, 128, 16, 128]);  getitem = None
    view_7 = torch.ops.aten.view.default(getitem_1, [1, 128, 16, 128]);  getitem_1 = None
    view_8 = torch.ops.aten.view.default(getitem_2, [1, 128, 16, 128]);  getitem_2 = None
    sigmoid = torch.ops.aten.sigmoid.default(_unsafe_view_2);  _unsafe_view_2 = None
    _param_constant7 = self._param_constant7
    exp = torch.ops.aten.exp.default(_param_constant7);  _param_constant7 = None
    neg = torch.ops.aten.neg.default(exp);  exp = None
    _to_copy_7 = torch.ops.aten._to_copy.default(_unsafe_view_3, dtype = torch.float32);  _unsafe_view_3 = None
    _param_constant8 = self._param_constant8
    add_3 = torch.ops.aten.add.Tensor(_to_copy_7, _param_constant8);  _to_copy_7 = _param_constant8 = None
    softplus = torch.ops.aten.softplus.default(add_3);  add_3 = None
    mul_5 = torch.ops.aten.mul.Tensor(neg, softplus);  neg = softplus = None
    transpose_2 = torch.ops.aten.transpose.int(view_6, 1, 2);  view_6 = None
    _to_copy_8 = torch.ops.aten._to_copy.default(transpose_2, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_2 = None
    transpose_3 = torch.ops.aten.transpose.int(view_7, 1, 2);  view_7 = None
    _to_copy_9 = torch.ops.aten._to_copy.default(transpose_3, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_3 = None
    transpose_4 = torch.ops.aten.transpose.int(view_8, 1, 2);  view_8 = None
    _to_copy_10 = torch.ops.aten._to_copy.default(transpose_4, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_4 = None
    transpose_5 = torch.ops.aten.transpose.int(sigmoid, 1, 2);  sigmoid = None
    _to_copy_11 = torch.ops.aten._to_copy.default(transpose_5, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_5 = None
    transpose_6 = torch.ops.aten.transpose.int(mul_5, 1, 2);  mul_5 = None
    mul_6 = torch.ops.aten.mul.Tensor(_to_copy_8, _to_copy_8)
    sum_1 = torch.ops.aten.sum.dim_IntList(mul_6, [-1], True);  mul_6 = None
    add_4 = torch.ops.aten.add.Tensor(sum_1, 1e-06);  sum_1 = None
    rsqrt_1 = torch.ops.aten.rsqrt.default(add_4);  add_4 = None
    mul_7 = torch.ops.aten.mul.Tensor(_to_copy_8, rsqrt_1);  _to_copy_8 = rsqrt_1 = None
    mul_8 = torch.ops.aten.mul.Tensor(_to_copy_9, _to_copy_9)
    sum_2 = torch.ops.aten.sum.dim_IntList(mul_8, [-1], True);  mul_8 = None
    add_5 = torch.ops.aten.add.Tensor(sum_2, 1e-06);  sum_2 = None
    rsqrt_2 = torch.ops.aten.rsqrt.default(add_5);  add_5 = None
    mul_9 = torch.ops.aten.mul.Tensor(_to_copy_9, rsqrt_2);  _to_copy_9 = rsqrt_2 = None
    mul_10 = torch.ops.aten.mul.Tensor(mul_7, 0.08838834764831845);  mul_7 = None
    constant_pad_nd = torch.ops.aten.constant_pad_nd.default(mul_10, [0, 0, 0, 0], 0.0);  mul_10 = None
    constant_pad_nd_1 = torch.ops.aten.constant_pad_nd.default(mul_9, [0, 0, 0, 0], 0.0);  mul_9 = None
    constant_pad_nd_2 = torch.ops.aten.constant_pad_nd.default(_to_copy_10, [0, 0, 0, 0], 0.0);  _to_copy_10 = None
    constant_pad_nd_3 = torch.ops.aten.constant_pad_nd.default(_to_copy_11, [0, 0], 0.0);  _to_copy_11 = None
    constant_pad_nd_4 = torch.ops.aten.constant_pad_nd.default(transpose_6, [0, 0], 0.0);  transpose_6 = None
    unsqueeze_4 = torch.ops.aten.unsqueeze.default(constant_pad_nd_3, -1)
    mul_11 = torch.ops.aten.mul.Tensor(constant_pad_nd_2, unsqueeze_4);  constant_pad_nd_2 = unsqueeze_4 = None
    unsqueeze_5 = torch.ops.aten.unsqueeze.default(constant_pad_nd_3, -1);  constant_pad_nd_3 = None
    mul_12 = torch.ops.aten.mul.Tensor(constant_pad_nd_1, unsqueeze_5);  unsqueeze_5 = None
    view_9 = torch.ops.aten.view.default(constant_pad_nd, [1, 16, -1, 64, 128]);  constant_pad_nd = None
    view_10 = torch.ops.aten.view.default(constant_pad_nd_1, [1, 16, -1, 64, 128]);  constant_pad_nd_1 = None
    view_11 = torch.ops.aten.view.default(mul_12, [1, 16, -1, 64, 128]);  mul_12 = None
    view_12 = torch.ops.aten.view.default(mul_11, [1, 16, -1, 64, 128]);  mul_11 = None
    view_13 = torch.ops.aten.view.default(constant_pad_nd_4, [1, 16, 2, 64]);  constant_pad_nd_4 = None
    ones = torch.ops.aten.ones.default([64, 64], dtype = torch.bool, device = device(type='meta'), pin_memory = False)
    triu_1 = torch.ops.aten.triu.default(ones, 1);  ones = None
    cumsum = torch.ops.aten.cumsum.default(view_13, 3);  view_13 = None
    unsqueeze_6 = torch.ops.aten.unsqueeze.default(cumsum, 4)
    unsqueeze_7 = torch.ops.aten.unsqueeze.default(cumsum, 3)
    sub = torch.ops.aten.sub.Tensor(unsqueeze_6, unsqueeze_7);  unsqueeze_6 = unsqueeze_7 = None
    masked_fill = torch.ops.aten.masked_fill.Scalar(sub, triu_1, -inf);  sub = triu_1 = None
    exp_1 = torch.ops.aten.exp.default(masked_fill);  masked_fill = None
    transpose_7 = torch.ops.aten.transpose.int(view_10, -1, -2)
    expand_2 = torch.ops.aten.expand.default(view_11, [1, 16, 2, 64, 128])
    view_14 = torch.ops.aten.view.default(expand_2, [32, 64, 128]);  expand_2 = None
    expand_3 = torch.ops.aten.expand.default(transpose_7, [1, 16, 2, 128, 64]);  transpose_7 = None
    view_15 = torch.ops.aten.view.default(expand_3, [32, 128, 64]);  expand_3 = None
    bmm = torch.ops.aten.bmm.default(view_14, view_15);  view_14 = view_15 = None
    _unsafe_view_4 = torch.ops.aten._unsafe_view.default(bmm, [1, 16, 2, 64, 64]);  bmm = None
    mul_13 = torch.ops.aten.mul.Tensor(_unsafe_view_4, exp_1);  _unsafe_view_4 = None
    transpose_8 = torch.ops.aten.transpose.int(view_10, -1, -2)
    expand_4 = torch.ops.aten.expand.default(view_9, [1, 16, 2, 64, 128])
    view_16 = torch.ops.aten.view.default(expand_4, [32, 64, 128]);  expand_4 = None
    expand_5 = torch.ops.aten.expand.default(transpose_8, [1, 16, 2, 128, 64]);  transpose_8 = None
    view_17 = torch.ops.aten.view.default(expand_5, [32, 128, 64]);  expand_5 = None
    bmm_1 = torch.ops.aten.bmm.default(view_16, view_17);  view_16 = view_17 = None
    _unsafe_view_5 = torch.ops.aten._unsafe_view.default(bmm_1, [1, 16, 2, 64, 64]);  bmm_1 = None
    mul_14 = torch.ops.aten.mul.Tensor(_unsafe_view_5, exp_1);  _unsafe_view_5 = exp_1 = None
    exp_2 = torch.ops.aten.exp.default(cumsum)
    unsqueeze_8 = torch.ops.aten.unsqueeze.default(exp_2, -1);  exp_2 = None
    mul_15 = torch.ops.aten.mul.Tensor(view_11, unsqueeze_8);  view_11 = unsqueeze_8 = None
    linalg_solve_triangular = torch.ops.aten.linalg_solve_triangular.default(mul_13, view_12, upper = False, unitriangular = True);  view_12 = None
    linalg_solve_triangular_1 = torch.ops.aten.linalg_solve_triangular.default(mul_13, mul_15, upper = False, unitriangular = True);  mul_13 = mul_15 = None
    zeros = torch.ops.aten.zeros.default([1, 16, 128, 128], dtype = torch.float32, device = device(type='meta'), pin_memory = False)
    zeros_like = torch.ops.aten.zeros_like.default(linalg_solve_triangular, pin_memory = False)
    exp_3 = torch.ops.aten.exp.default(cumsum)
    unsqueeze_9 = torch.ops.aten.unsqueeze.default(exp_3, -1);  exp_3 = None
    mul_16 = torch.ops.aten.mul.Tensor(view_9, unsqueeze_9);  view_9 = unsqueeze_9 = None
    slice_11 = torch.ops.aten.slice.Tensor(cumsum, 3, -1, 9223372036854775807)
    sub_1 = torch.ops.aten.sub.Tensor(slice_11, cumsum);  slice_11 = None
    exp_4 = torch.ops.aten.exp.default(sub_1);  sub_1 = None
    unsqueeze_10 = torch.ops.aten.unsqueeze.default(exp_4, -1);  exp_4 = None
    mul_17 = torch.ops.aten.mul.Tensor(view_10, unsqueeze_10);  view_10 = unsqueeze_10 = None
    select_7 = torch.ops.aten.select.int(cumsum, 3, -1);  cumsum = None
    exp_5 = torch.ops.aten.exp.default(select_7);  select_7 = None
    unsqueeze_11 = torch.ops.aten.unsqueeze.default(exp_5, 3);  exp_5 = None
    unsqueeze_12 = torch.ops.aten.unsqueeze.default(unsqueeze_11, 4);  unsqueeze_11 = None
    select_8 = torch.ops.aten.select.int(linalg_solve_triangular, 2, 0)
    select_9 = torch.ops.aten.select.int(linalg_solve_triangular_1, 2, 0)
    expand_6 = torch.ops.aten.expand.default(select_9, [1, 16, 64, 128]);  select_9 = None
    view_18 = torch.ops.aten.view.default(expand_6, [16, 64, 128]);  expand_6 = None
    expand_7 = torch.ops.aten.expand.default(zeros, [1, 16, 128, 128])
    view_19 = torch.ops.aten.view.default(expand_7, [16, 128, 128]);  expand_7 = None
    bmm_2 = torch.ops.aten.bmm.default(view_18, view_19);  view_18 = view_19 = None
    _unsafe_view_6 = torch.ops.aten._unsafe_view.default(bmm_2, [1, 16, 64, 128]);  bmm_2 = None
    sub_2 = torch.ops.aten.sub.Tensor(select_8, _unsafe_view_6);  select_8 = _unsafe_view_6 = None
    select_10 = torch.ops.aten.select.int(mul_16, 2, 0)
    expand_8 = torch.ops.aten.expand.default(select_10, [1, 16, 64, 128]);  select_10 = None
    view_20 = torch.ops.aten.view.default(expand_8, [16, 64, 128]);  expand_8 = None
    expand_9 = torch.ops.aten.expand.default(zeros, [1, 16, 128, 128])
    view_21 = torch.ops.aten.view.default(expand_9, [16, 128, 128]);  expand_9 = None
    bmm_3 = torch.ops.aten.bmm.default(view_20, view_21);  view_20 = view_21 = None
    _unsafe_view_7 = torch.ops.aten._unsafe_view.default(bmm_3, [1, 16, 64, 128]);  bmm_3 = None
    select_11 = torch.ops.aten.select.int(mul_14, 2, 0)
    expand_10 = torch.ops.aten.expand.default(select_11, [1, 16, 64, 64]);  select_11 = None
    view_22 = torch.ops.aten.view.default(expand_10, [16, 64, 64]);  expand_10 = None
    expand_11 = torch.ops.aten.expand.default(sub_2, [1, 16, 64, 128])
    view_23 = torch.ops.aten.view.default(expand_11, [16, 64, 128]);  expand_11 = None
    bmm_4 = torch.ops.aten.bmm.default(view_22, view_23);  view_22 = view_23 = None
    _unsafe_view_8 = torch.ops.aten._unsafe_view.default(bmm_4, [1, 16, 64, 128]);  bmm_4 = None
    add_6 = torch.ops.aten.add.Tensor(_unsafe_view_7, _unsafe_view_8);  _unsafe_view_7 = _unsafe_view_8 = None
    select_12 = torch.ops.aten.select.int(zeros_like, 2, 0)
    copy__4 = torch.ops.aten.copy_.default(select_12, add_6);  select_12 = add_6 = copy__4 = None
    select_13 = torch.ops.aten.select.int(unsqueeze_12, 2, 0)
    mul_18 = torch.ops.aten.mul.Tensor(zeros, select_13);  zeros = select_13 = None
    select_14 = torch.ops.aten.select.int(mul_17, 2, 0)
    transpose_9 = torch.ops.aten.transpose.int(select_14, -1, -2);  select_14 = None
    expand_12 = torch.ops.aten.expand.default(transpose_9, [1, 16, 128, 64]);  transpose_9 = None
    view_24 = torch.ops.aten.view.default(expand_12, [16, 128, 64]);  expand_12 = None
    expand_13 = torch.ops.aten.expand.default(sub_2, [1, 16, 64, 128]);  sub_2 = None
    view_25 = torch.ops.aten.view.default(expand_13, [16, 64, 128]);  expand_13 = None
    bmm_5 = torch.ops.aten.bmm.default(view_24, view_25);  view_24 = view_25 = None
    _unsafe_view_9 = torch.ops.aten._unsafe_view.default(bmm_5, [1, 16, 128, 128]);  bmm_5 = None
    add_7 = torch.ops.aten.add.Tensor(mul_18, _unsafe_view_9);  mul_18 = _unsafe_view_9 = None
    select_15 = torch.ops.aten.select.int(linalg_solve_triangular, 2, 1);  linalg_solve_triangular = None
    select_16 = torch.ops.aten.select.int(linalg_solve_triangular_1, 2, 1);  linalg_solve_triangular_1 = None
    expand_14 = torch.ops.aten.expand.default(select_16, [1, 16, 64, 128]);  select_16 = None
    view_26 = torch.ops.aten.view.default(expand_14, [16, 64, 128]);  expand_14 = None
    expand_15 = torch.ops.aten.expand.default(add_7, [1, 16, 128, 128])
    view_27 = torch.ops.aten.view.default(expand_15, [16, 128, 128]);  expand_15 = None
    bmm_6 = torch.ops.aten.bmm.default(view_26, view_27);  view_26 = view_27 = None
    _unsafe_view_10 = torch.ops.aten._unsafe_view.default(bmm_6, [1, 16, 64, 128]);  bmm_6 = None
    sub_3 = torch.ops.aten.sub.Tensor(select_15, _unsafe_view_10);  select_15 = _unsafe_view_10 = None
    select_17 = torch.ops.aten.select.int(mul_16, 2, 1);  mul_16 = None
    expand_16 = torch.ops.aten.expand.default(select_17, [1, 16, 64, 128]);  select_17 = None
    view_28 = torch.ops.aten.view.default(expand_16, [16, 64, 128]);  expand_16 = None
    expand_17 = torch.ops.aten.expand.default(add_7, [1, 16, 128, 128])
    view_29 = torch.ops.aten.view.default(expand_17, [16, 128, 128]);  expand_17 = None
    bmm_7 = torch.ops.aten.bmm.default(view_28, view_29);  view_28 = view_29 = None
    _unsafe_view_11 = torch.ops.aten._unsafe_view.default(bmm_7, [1, 16, 64, 128]);  bmm_7 = None
    select_18 = torch.ops.aten.select.int(mul_14, 2, 1);  mul_14 = None
    expand_18 = torch.ops.aten.expand.default(select_18, [1, 16, 64, 64]);  select_18 = None
    view_30 = torch.ops.aten.view.default(expand_18, [16, 64, 64]);  expand_18 = None
    expand_19 = torch.ops.aten.expand.default(sub_3, [1, 16, 64, 128])
    view_31 = torch.ops.aten.view.default(expand_19, [16, 64, 128]);  expand_19 = None
    bmm_8 = torch.ops.aten.bmm.default(view_30, view_31);  view_30 = view_31 = None
    _unsafe_view_12 = torch.ops.aten._unsafe_view.default(bmm_8, [1, 16, 64, 128]);  bmm_8 = None
    add_8 = torch.ops.aten.add.Tensor(_unsafe_view_11, _unsafe_view_12);  _unsafe_view_11 = _unsafe_view_12 = None
    select_19 = torch.ops.aten.select.int(zeros_like, 2, 1)
    copy__5 = torch.ops.aten.copy_.default(select_19, add_8);  select_19 = add_8 = copy__5 = None
    select_20 = torch.ops.aten.select.int(unsqueeze_12, 2, 1);  unsqueeze_12 = None
    mul_19 = torch.ops.aten.mul.Tensor(add_7, select_20);  add_7 = select_20 = None
    select_21 = torch.ops.aten.select.int(mul_17, 2, 1);  mul_17 = None
    transpose_10 = torch.ops.aten.transpose.int(select_21, -1, -2);  select_21 = None
    expand_20 = torch.ops.aten.expand.default(transpose_10, [1, 16, 128, 64]);  transpose_10 = None
    view_32 = torch.ops.aten.view.default(expand_20, [16, 128, 64]);  expand_20 = None
    expand_21 = torch.ops.aten.expand.default(sub_3, [1, 16, 64, 128]);  sub_3 = None
    view_33 = torch.ops.aten.view.default(expand_21, [16, 64, 128]);  expand_21 = None
    bmm_9 = torch.ops.aten.bmm.default(view_32, view_33);  view_32 = view_33 = None
    _unsafe_view_13 = torch.ops.aten._unsafe_view.default(bmm_9, [1, 16, 128, 128]);  bmm_9 = None
    add_9 = torch.ops.aten.add.Tensor(mul_19, _unsafe_view_13);  mul_19 = _unsafe_view_13 = add_9 = None
    clone = torch.ops.aten.clone.default(zeros_like, memory_format = torch.contiguous_format);  zeros_like = None
    _unsafe_view_14 = torch.ops.aten._unsafe_view.default(clone, [1, 16, 128, 128]);  clone = None
    alias = torch.ops.aten.alias.default(_unsafe_view_14);  _unsafe_view_14 = None
    transpose_11 = torch.ops.aten.transpose.int(alias, 1, 2);  alias = None
    _to_copy_12 = torch.ops.aten._to_copy.default(transpose_11, dtype = torch.bfloat16, memory_format = torch.contiguous_format);  transpose_11 = None
    view_34 = torch.ops.aten.view.default(_to_copy_12, [-1, 128]);  _to_copy_12 = None
    view_35 = torch.ops.aten.view.default(view_3, [-1, 128]);  view_3 = None
    _to_copy_13 = torch.ops.aten._to_copy.default(view_34, dtype = torch.float32);  view_34 = None
    pow_2 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_13, 2)
    mean_1 = torch.ops.aten.mean.dim(pow_2, [-1], True);  pow_2 = None
    add_10 = torch.ops.aten.add.Tensor(mean_1, 1e-06);  mean_1 = None
    rsqrt_3 = torch.ops.aten.rsqrt.default(add_10);  add_10 = None
    mul_20 = torch.ops.aten.mul.Tensor(_to_copy_13, rsqrt_3);  _to_copy_13 = rsqrt_3 = None
    _to_copy_14 = torch.ops.aten._to_copy.default(mul_20, dtype = torch.bfloat16);  mul_20 = None
    _param_constant9 = self._param_constant9
    mul_21 = torch.ops.aten.mul.Tensor(_param_constant9, _to_copy_14);  _param_constant9 = _to_copy_14 = None
    _to_copy_15 = torch.ops.aten._to_copy.default(view_35, dtype = torch.float32);  view_35 = None
    silu_1 = torch.ops.aten.silu.default(_to_copy_15);  _to_copy_15 = None
    mul_22 = torch.ops.aten.mul.Tensor(mul_21, silu_1);  mul_21 = silu_1 = None
    _to_copy_16 = torch.ops.aten._to_copy.default(mul_22, dtype = torch.bfloat16);  mul_22 = None
    view_36 = torch.ops.aten.view.default(_to_copy_16, [1, 128, -1]);  _to_copy_16 = None
    _param_constant10 = self._param_constant10
    t_4 = torch.ops.aten.t.default(_param_constant10);  _param_constant10 = None
    view_37 = torch.ops.aten.view.default(view_36, [128, 2048]);  view_36 = None
    mm_4 = torch.ops.aten.mm.default(view_37, t_4);  view_37 = t_4 = None
    _unsafe_view_15 = torch.ops.aten._unsafe_view.default(mm_4, [1, 128, 2048]);  mm_4 = None
    add_11 = torch.ops.aten.add.Tensor(embedding, _unsafe_view_15);  embedding = _unsafe_view_15 = None
    _to_copy_17 = torch.ops.aten._to_copy.default(add_11, dtype = torch.float32)
    pow_3 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_17, 2)
    mean_2 = torch.ops.aten.mean.dim(pow_3, [-1], True);  pow_3 = None
    add_12 = torch.ops.aten.add.Tensor(mean_2, 1e-06);  mean_2 = None
    rsqrt_4 = torch.ops.aten.rsqrt.default(add_12);  add_12 = None
    mul_23 = torch.ops.aten.mul.Tensor(_to_copy_17, rsqrt_4);  _to_copy_17 = rsqrt_4 = None
    _param_constant11 = self._param_constant11
    _to_copy_18 = torch.ops.aten._to_copy.default(_param_constant11, dtype = torch.float32);  _param_constant11 = None
    add_13 = torch.ops.aten.add.Tensor(_to_copy_18, 1.0);  _to_copy_18 = None
    mul_24 = torch.ops.aten.mul.Tensor(mul_23, add_13);  mul_23 = add_13 = None
    _to_copy_19 = torch.ops.aten._to_copy.default(mul_24, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_24 = None
    _param_constant12 = self._param_constant12
    t_5 = torch.ops.aten.t.default(_param_constant12);  _param_constant12 = None
    view_38 = torch.ops.aten.view.default(_to_copy_19, [128, 2048])
    mm_5 = torch.ops.aten.mm.default(view_38, t_5);  view_38 = t_5 = None
    _unsafe_view_16 = torch.ops.aten._unsafe_view.default(mm_5, [1, 128, 6144]);  mm_5 = None
    silu_2 = torch.ops.aten.silu.default(_unsafe_view_16);  _unsafe_view_16 = None
    _param_constant13 = self._param_constant13
    t_6 = torch.ops.aten.t.default(_param_constant13);  _param_constant13 = None
    view_39 = torch.ops.aten.view.default(_to_copy_19, [128, 2048]);  _to_copy_19 = None
    mm_6 = torch.ops.aten.mm.default(view_39, t_6);  view_39 = t_6 = None
    _unsafe_view_17 = torch.ops.aten._unsafe_view.default(mm_6, [1, 128, 6144]);  mm_6 = None
    mul_25 = torch.ops.aten.mul.Tensor(silu_2, _unsafe_view_17);  silu_2 = _unsafe_view_17 = None
    _param_constant14 = self._param_constant14
    t_7 = torch.ops.aten.t.default(_param_constant14);  _param_constant14 = None
    view_40 = torch.ops.aten.view.default(mul_25, [128, 6144]);  mul_25 = None
    mm_7 = torch.ops.aten.mm.default(view_40, t_7);  view_40 = t_7 = None
    _unsafe_view_18 = torch.ops.aten._unsafe_view.default(mm_7, [1, 128, 2048]);  mm_7 = None
    add_14 = torch.ops.aten.add.Tensor(add_11, _unsafe_view_18);  add_11 = _unsafe_view_18 = None
    _to_copy_20 = torch.ops.aten._to_copy.default(add_14, dtype = torch.float32)
    pow_4 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_20, 2)
    mean_3 = torch.ops.aten.mean.dim(pow_4, [-1], True);  pow_4 = None
    add_15 = torch.ops.aten.add.Tensor(mean_3, 1e-06);  mean_3 = None
    rsqrt_5 = torch.ops.aten.rsqrt.default(add_15);  add_15 = None
    mul_26 = torch.ops.aten.mul.Tensor(_to_copy_20, rsqrt_5);  _to_copy_20 = rsqrt_5 = None
    _param_constant15 = self._param_constant15
    _to_copy_21 = torch.ops.aten._to_copy.default(_param_constant15, dtype = torch.float32);  _param_constant15 = None
    add_16 = torch.ops.aten.add.Tensor(_to_copy_21, 1.0);  _to_copy_21 = None
    mul_27 = torch.ops.aten.mul.Tensor(mul_26, add_16);  mul_26 = add_16 = None
    _to_copy_22 = torch.ops.aten._to_copy.default(mul_27, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_27 = None
    _param_constant16 = self._param_constant16
    t_8 = torch.ops.aten.t.default(_param_constant16);  _param_constant16 = None
    view_41 = torch.ops.aten.view.default(_to_copy_22, [128, 2048])
    mm_8 = torch.ops.aten.mm.default(view_41, t_8);  view_41 = t_8 = None
    _unsafe_view_19 = torch.ops.aten._unsafe_view.default(mm_8, [1, 128, 6144]);  mm_8 = None
    transpose_12 = torch.ops.aten.transpose.int(_unsafe_view_19, 1, 2);  _unsafe_view_19 = None
    _param_constant17 = self._param_constant17
    t_9 = torch.ops.aten.t.default(_param_constant17);  _param_constant17 = None
    view_42 = torch.ops.aten.view.default(_to_copy_22, [128, 2048])
    mm_9 = torch.ops.aten.mm.default(view_42, t_9);  view_42 = t_9 = None
    _unsafe_view_20 = torch.ops.aten._unsafe_view.default(mm_9, [1, 128, 2048]);  mm_9 = None
    view_43 = torch.ops.aten.view.default(_unsafe_view_20, [1, 128, -1, 128]);  _unsafe_view_20 = None
    _param_constant18 = self._param_constant18
    t_10 = torch.ops.aten.t.default(_param_constant18);  _param_constant18 = None
    view_44 = torch.ops.aten.view.default(_to_copy_22, [128, 2048])
    mm_10 = torch.ops.aten.mm.default(view_44, t_10);  view_44 = t_10 = None
    _unsafe_view_21 = torch.ops.aten._unsafe_view.default(mm_10, [1, 128, 16]);  mm_10 = None
    _param_constant19 = self._param_constant19
    t_11 = torch.ops.aten.t.default(_param_constant19);  _param_constant19 = None
    view_45 = torch.ops.aten.view.default(_to_copy_22, [128, 2048]);  _to_copy_22 = None
    mm_11 = torch.ops.aten.mm.default(view_45, t_11);  view_45 = t_11 = None
    _unsafe_view_22 = torch.ops.aten._unsafe_view.default(mm_11, [1, 128, 16]);  mm_11 = None
    _param_constant20 = self._param_constant20
    squeeze_1 = torch.ops.aten.squeeze.dim(_param_constant20, 1);  _param_constant20 = None
    unsqueeze_13 = torch.ops.aten.unsqueeze.default(squeeze_1, 1);  squeeze_1 = None
    convolution_1 = torch.ops.aten.convolution.default(transpose_12, unsqueeze_13, None, [1], [3], [1], False, [0], 6144);  transpose_12 = unsqueeze_13 = None
    slice_12 = torch.ops.aten.slice.Tensor(convolution_1, 2, 0, 128);  convolution_1 = None
    silu_3 = torch.ops.aten.silu.default(slice_12);  slice_12 = None
    transpose_13 = torch.ops.aten.transpose.int(silu_3, 1, 2);  silu_3 = None
    split_with_sizes_1 = torch.ops.aten.split_with_sizes.default(transpose_13, [2048, 2048, 2048], -1);  transpose_13 = None
    getitem_3 = split_with_sizes_1[0]
    getitem_4 = split_with_sizes_1[1]
    getitem_5 = split_with_sizes_1[2];  split_with_sizes_1 = None
    view_46 = torch.ops.aten.view.default(getitem_3, [1, 128, 16, 128]);  getitem_3 = None
    view_47 = torch.ops.aten.view.default(getitem_4, [1, 128, 16, 128]);  getitem_4 = None
    view_48 = torch.ops.aten.view.default(getitem_5, [1, 128, 16, 128]);  getitem_5 = None
    sigmoid_1 = torch.ops.aten.sigmoid.default(_unsafe_view_21);  _unsafe_view_21 = None
    _param_constant21 = self._param_constant21
    exp_6 = torch.ops.aten.exp.default(_param_constant21);  _param_constant21 = None
    neg_1 = torch.ops.aten.neg.default(exp_6);  exp_6 = None
    _to_copy_23 = torch.ops.aten._to_copy.default(_unsafe_view_22, dtype = torch.float32);  _unsafe_view_22 = None
    _param_constant22 = self._param_constant22
    add_17 = torch.ops.aten.add.Tensor(_to_copy_23, _param_constant22);  _to_copy_23 = _param_constant22 = None
    softplus_1 = torch.ops.aten.softplus.default(add_17);  add_17 = None
    mul_28 = torch.ops.aten.mul.Tensor(neg_1, softplus_1);  neg_1 = softplus_1 = None
    transpose_14 = torch.ops.aten.transpose.int(view_46, 1, 2);  view_46 = None
    _to_copy_24 = torch.ops.aten._to_copy.default(transpose_14, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_14 = None
    transpose_15 = torch.ops.aten.transpose.int(view_47, 1, 2);  view_47 = None
    _to_copy_25 = torch.ops.aten._to_copy.default(transpose_15, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_15 = None
    transpose_16 = torch.ops.aten.transpose.int(view_48, 1, 2);  view_48 = None
    _to_copy_26 = torch.ops.aten._to_copy.default(transpose_16, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_16 = None
    transpose_17 = torch.ops.aten.transpose.int(sigmoid_1, 1, 2);  sigmoid_1 = None
    _to_copy_27 = torch.ops.aten._to_copy.default(transpose_17, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_17 = None
    transpose_18 = torch.ops.aten.transpose.int(mul_28, 1, 2);  mul_28 = None
    mul_29 = torch.ops.aten.mul.Tensor(_to_copy_24, _to_copy_24)
    sum_3 = torch.ops.aten.sum.dim_IntList(mul_29, [-1], True);  mul_29 = None
    add_18 = torch.ops.aten.add.Tensor(sum_3, 1e-06);  sum_3 = None
    rsqrt_6 = torch.ops.aten.rsqrt.default(add_18);  add_18 = None
    mul_30 = torch.ops.aten.mul.Tensor(_to_copy_24, rsqrt_6);  _to_copy_24 = rsqrt_6 = None
    mul_31 = torch.ops.aten.mul.Tensor(_to_copy_25, _to_copy_25)
    sum_4 = torch.ops.aten.sum.dim_IntList(mul_31, [-1], True);  mul_31 = None
    add_19 = torch.ops.aten.add.Tensor(sum_4, 1e-06);  sum_4 = None
    rsqrt_7 = torch.ops.aten.rsqrt.default(add_19);  add_19 = None
    mul_32 = torch.ops.aten.mul.Tensor(_to_copy_25, rsqrt_7);  _to_copy_25 = rsqrt_7 = None
    mul_33 = torch.ops.aten.mul.Tensor(mul_30, 0.08838834764831845);  mul_30 = None
    constant_pad_nd_5 = torch.ops.aten.constant_pad_nd.default(mul_33, [0, 0, 0, 0], 0.0);  mul_33 = None
    constant_pad_nd_6 = torch.ops.aten.constant_pad_nd.default(mul_32, [0, 0, 0, 0], 0.0);  mul_32 = None
    constant_pad_nd_7 = torch.ops.aten.constant_pad_nd.default(_to_copy_26, [0, 0, 0, 0], 0.0);  _to_copy_26 = None
    constant_pad_nd_8 = torch.ops.aten.constant_pad_nd.default(_to_copy_27, [0, 0], 0.0);  _to_copy_27 = None
    constant_pad_nd_9 = torch.ops.aten.constant_pad_nd.default(transpose_18, [0, 0], 0.0);  transpose_18 = None
    unsqueeze_14 = torch.ops.aten.unsqueeze.default(constant_pad_nd_8, -1)
    mul_34 = torch.ops.aten.mul.Tensor(constant_pad_nd_7, unsqueeze_14);  constant_pad_nd_7 = unsqueeze_14 = None
    unsqueeze_15 = torch.ops.aten.unsqueeze.default(constant_pad_nd_8, -1);  constant_pad_nd_8 = None
    mul_35 = torch.ops.aten.mul.Tensor(constant_pad_nd_6, unsqueeze_15);  unsqueeze_15 = None
    view_49 = torch.ops.aten.view.default(constant_pad_nd_5, [1, 16, -1, 64, 128]);  constant_pad_nd_5 = None
    view_50 = torch.ops.aten.view.default(constant_pad_nd_6, [1, 16, -1, 64, 128]);  constant_pad_nd_6 = None
    view_51 = torch.ops.aten.view.default(mul_35, [1, 16, -1, 64, 128]);  mul_35 = None
    view_52 = torch.ops.aten.view.default(mul_34, [1, 16, -1, 64, 128]);  mul_34 = None
    view_53 = torch.ops.aten.view.default(constant_pad_nd_9, [1, 16, 2, 64]);  constant_pad_nd_9 = None
    ones_1 = torch.ops.aten.ones.default([64, 64], dtype = torch.bool, device = device(type='meta'), pin_memory = False)
    triu_2 = torch.ops.aten.triu.default(ones_1, 1);  ones_1 = None
    cumsum_1 = torch.ops.aten.cumsum.default(view_53, 3);  view_53 = None
    unsqueeze_16 = torch.ops.aten.unsqueeze.default(cumsum_1, 4)
    unsqueeze_17 = torch.ops.aten.unsqueeze.default(cumsum_1, 3)
    sub_4 = torch.ops.aten.sub.Tensor(unsqueeze_16, unsqueeze_17);  unsqueeze_16 = unsqueeze_17 = None
    masked_fill_1 = torch.ops.aten.masked_fill.Scalar(sub_4, triu_2, -inf);  sub_4 = triu_2 = None
    exp_7 = torch.ops.aten.exp.default(masked_fill_1);  masked_fill_1 = None
    transpose_19 = torch.ops.aten.transpose.int(view_50, -1, -2)
    expand_22 = torch.ops.aten.expand.default(view_51, [1, 16, 2, 64, 128])
    view_54 = torch.ops.aten.view.default(expand_22, [32, 64, 128]);  expand_22 = None
    expand_23 = torch.ops.aten.expand.default(transpose_19, [1, 16, 2, 128, 64]);  transpose_19 = None
    view_55 = torch.ops.aten.view.default(expand_23, [32, 128, 64]);  expand_23 = None
    bmm_10 = torch.ops.aten.bmm.default(view_54, view_55);  view_54 = view_55 = None
    _unsafe_view_23 = torch.ops.aten._unsafe_view.default(bmm_10, [1, 16, 2, 64, 64]);  bmm_10 = None
    mul_36 = torch.ops.aten.mul.Tensor(_unsafe_view_23, exp_7);  _unsafe_view_23 = None
    transpose_20 = torch.ops.aten.transpose.int(view_50, -1, -2)
    expand_24 = torch.ops.aten.expand.default(view_49, [1, 16, 2, 64, 128])
    view_56 = torch.ops.aten.view.default(expand_24, [32, 64, 128]);  expand_24 = None
    expand_25 = torch.ops.aten.expand.default(transpose_20, [1, 16, 2, 128, 64]);  transpose_20 = None
    view_57 = torch.ops.aten.view.default(expand_25, [32, 128, 64]);  expand_25 = None
    bmm_11 = torch.ops.aten.bmm.default(view_56, view_57);  view_56 = view_57 = None
    _unsafe_view_24 = torch.ops.aten._unsafe_view.default(bmm_11, [1, 16, 2, 64, 64]);  bmm_11 = None
    mul_37 = torch.ops.aten.mul.Tensor(_unsafe_view_24, exp_7);  _unsafe_view_24 = exp_7 = None
    exp_8 = torch.ops.aten.exp.default(cumsum_1)
    unsqueeze_18 = torch.ops.aten.unsqueeze.default(exp_8, -1);  exp_8 = None
    mul_38 = torch.ops.aten.mul.Tensor(view_51, unsqueeze_18);  view_51 = unsqueeze_18 = None
    linalg_solve_triangular_2 = torch.ops.aten.linalg_solve_triangular.default(mul_36, view_52, upper = False, unitriangular = True);  view_52 = None
    linalg_solve_triangular_3 = torch.ops.aten.linalg_solve_triangular.default(mul_36, mul_38, upper = False, unitriangular = True);  mul_36 = mul_38 = None
    zeros_1 = torch.ops.aten.zeros.default([1, 16, 128, 128], dtype = torch.float32, device = device(type='meta'), pin_memory = False)
    zeros_like_1 = torch.ops.aten.zeros_like.default(linalg_solve_triangular_2, pin_memory = False)
    exp_9 = torch.ops.aten.exp.default(cumsum_1)
    unsqueeze_19 = torch.ops.aten.unsqueeze.default(exp_9, -1);  exp_9 = None
    mul_39 = torch.ops.aten.mul.Tensor(view_49, unsqueeze_19);  view_49 = unsqueeze_19 = None
    slice_13 = torch.ops.aten.slice.Tensor(cumsum_1, 3, -1, 9223372036854775807)
    sub_5 = torch.ops.aten.sub.Tensor(slice_13, cumsum_1);  slice_13 = None
    exp_10 = torch.ops.aten.exp.default(sub_5);  sub_5 = None
    unsqueeze_20 = torch.ops.aten.unsqueeze.default(exp_10, -1);  exp_10 = None
    mul_40 = torch.ops.aten.mul.Tensor(view_50, unsqueeze_20);  view_50 = unsqueeze_20 = None
    select_22 = torch.ops.aten.select.int(cumsum_1, 3, -1);  cumsum_1 = None
    exp_11 = torch.ops.aten.exp.default(select_22);  select_22 = None
    unsqueeze_21 = torch.ops.aten.unsqueeze.default(exp_11, 3);  exp_11 = None
    unsqueeze_22 = torch.ops.aten.unsqueeze.default(unsqueeze_21, 4);  unsqueeze_21 = None
    select_23 = torch.ops.aten.select.int(linalg_solve_triangular_2, 2, 0)
    select_24 = torch.ops.aten.select.int(linalg_solve_triangular_3, 2, 0)
    expand_26 = torch.ops.aten.expand.default(select_24, [1, 16, 64, 128]);  select_24 = None
    view_58 = torch.ops.aten.view.default(expand_26, [16, 64, 128]);  expand_26 = None
    expand_27 = torch.ops.aten.expand.default(zeros_1, [1, 16, 128, 128])
    view_59 = torch.ops.aten.view.default(expand_27, [16, 128, 128]);  expand_27 = None
    bmm_12 = torch.ops.aten.bmm.default(view_58, view_59);  view_58 = view_59 = None
    _unsafe_view_25 = torch.ops.aten._unsafe_view.default(bmm_12, [1, 16, 64, 128]);  bmm_12 = None
    sub_6 = torch.ops.aten.sub.Tensor(select_23, _unsafe_view_25);  select_23 = _unsafe_view_25 = None
    select_25 = torch.ops.aten.select.int(mul_39, 2, 0)
    expand_28 = torch.ops.aten.expand.default(select_25, [1, 16, 64, 128]);  select_25 = None
    view_60 = torch.ops.aten.view.default(expand_28, [16, 64, 128]);  expand_28 = None
    expand_29 = torch.ops.aten.expand.default(zeros_1, [1, 16, 128, 128])
    view_61 = torch.ops.aten.view.default(expand_29, [16, 128, 128]);  expand_29 = None
    bmm_13 = torch.ops.aten.bmm.default(view_60, view_61);  view_60 = view_61 = None
    _unsafe_view_26 = torch.ops.aten._unsafe_view.default(bmm_13, [1, 16, 64, 128]);  bmm_13 = None
    select_26 = torch.ops.aten.select.int(mul_37, 2, 0)
    expand_30 = torch.ops.aten.expand.default(select_26, [1, 16, 64, 64]);  select_26 = None
    view_62 = torch.ops.aten.view.default(expand_30, [16, 64, 64]);  expand_30 = None
    expand_31 = torch.ops.aten.expand.default(sub_6, [1, 16, 64, 128])
    view_63 = torch.ops.aten.view.default(expand_31, [16, 64, 128]);  expand_31 = None
    bmm_14 = torch.ops.aten.bmm.default(view_62, view_63);  view_62 = view_63 = None
    _unsafe_view_27 = torch.ops.aten._unsafe_view.default(bmm_14, [1, 16, 64, 128]);  bmm_14 = None
    add_20 = torch.ops.aten.add.Tensor(_unsafe_view_26, _unsafe_view_27);  _unsafe_view_26 = _unsafe_view_27 = None
    select_27 = torch.ops.aten.select.int(zeros_like_1, 2, 0)
    copy__6 = torch.ops.aten.copy_.default(select_27, add_20);  select_27 = add_20 = copy__6 = None
    select_28 = torch.ops.aten.select.int(unsqueeze_22, 2, 0)
    mul_41 = torch.ops.aten.mul.Tensor(zeros_1, select_28);  zeros_1 = select_28 = None
    select_29 = torch.ops.aten.select.int(mul_40, 2, 0)
    transpose_21 = torch.ops.aten.transpose.int(select_29, -1, -2);  select_29 = None
    expand_32 = torch.ops.aten.expand.default(transpose_21, [1, 16, 128, 64]);  transpose_21 = None
    view_64 = torch.ops.aten.view.default(expand_32, [16, 128, 64]);  expand_32 = None
    expand_33 = torch.ops.aten.expand.default(sub_6, [1, 16, 64, 128]);  sub_6 = None
    view_65 = torch.ops.aten.view.default(expand_33, [16, 64, 128]);  expand_33 = None
    bmm_15 = torch.ops.aten.bmm.default(view_64, view_65);  view_64 = view_65 = None
    _unsafe_view_28 = torch.ops.aten._unsafe_view.default(bmm_15, [1, 16, 128, 128]);  bmm_15 = None
    add_21 = torch.ops.aten.add.Tensor(mul_41, _unsafe_view_28);  mul_41 = _unsafe_view_28 = None
    select_30 = torch.ops.aten.select.int(linalg_solve_triangular_2, 2, 1);  linalg_solve_triangular_2 = None
    select_31 = torch.ops.aten.select.int(linalg_solve_triangular_3, 2, 1);  linalg_solve_triangular_3 = None
    expand_34 = torch.ops.aten.expand.default(select_31, [1, 16, 64, 128]);  select_31 = None
    view_66 = torch.ops.aten.view.default(expand_34, [16, 64, 128]);  expand_34 = None
    expand_35 = torch.ops.aten.expand.default(add_21, [1, 16, 128, 128])
    view_67 = torch.ops.aten.view.default(expand_35, [16, 128, 128]);  expand_35 = None
    bmm_16 = torch.ops.aten.bmm.default(view_66, view_67);  view_66 = view_67 = None
    _unsafe_view_29 = torch.ops.aten._unsafe_view.default(bmm_16, [1, 16, 64, 128]);  bmm_16 = None
    sub_7 = torch.ops.aten.sub.Tensor(select_30, _unsafe_view_29);  select_30 = _unsafe_view_29 = None
    select_32 = torch.ops.aten.select.int(mul_39, 2, 1);  mul_39 = None
    expand_36 = torch.ops.aten.expand.default(select_32, [1, 16, 64, 128]);  select_32 = None
    view_68 = torch.ops.aten.view.default(expand_36, [16, 64, 128]);  expand_36 = None
    expand_37 = torch.ops.aten.expand.default(add_21, [1, 16, 128, 128])
    view_69 = torch.ops.aten.view.default(expand_37, [16, 128, 128]);  expand_37 = None
    bmm_17 = torch.ops.aten.bmm.default(view_68, view_69);  view_68 = view_69 = None
    _unsafe_view_30 = torch.ops.aten._unsafe_view.default(bmm_17, [1, 16, 64, 128]);  bmm_17 = None
    select_33 = torch.ops.aten.select.int(mul_37, 2, 1);  mul_37 = None
    expand_38 = torch.ops.aten.expand.default(select_33, [1, 16, 64, 64]);  select_33 = None
    view_70 = torch.ops.aten.view.default(expand_38, [16, 64, 64]);  expand_38 = None
    expand_39 = torch.ops.aten.expand.default(sub_7, [1, 16, 64, 128])
    view_71 = torch.ops.aten.view.default(expand_39, [16, 64, 128]);  expand_39 = None
    bmm_18 = torch.ops.aten.bmm.default(view_70, view_71);  view_70 = view_71 = None
    _unsafe_view_31 = torch.ops.aten._unsafe_view.default(bmm_18, [1, 16, 64, 128]);  bmm_18 = None
    add_22 = torch.ops.aten.add.Tensor(_unsafe_view_30, _unsafe_view_31);  _unsafe_view_30 = _unsafe_view_31 = None
    select_34 = torch.ops.aten.select.int(zeros_like_1, 2, 1)
    copy__7 = torch.ops.aten.copy_.default(select_34, add_22);  select_34 = add_22 = copy__7 = None
    select_35 = torch.ops.aten.select.int(unsqueeze_22, 2, 1);  unsqueeze_22 = None
    mul_42 = torch.ops.aten.mul.Tensor(add_21, select_35);  add_21 = select_35 = None
    select_36 = torch.ops.aten.select.int(mul_40, 2, 1);  mul_40 = None
    transpose_22 = torch.ops.aten.transpose.int(select_36, -1, -2);  select_36 = None
    expand_40 = torch.ops.aten.expand.default(transpose_22, [1, 16, 128, 64]);  transpose_22 = None
    view_72 = torch.ops.aten.view.default(expand_40, [16, 128, 64]);  expand_40 = None
    expand_41 = torch.ops.aten.expand.default(sub_7, [1, 16, 64, 128]);  sub_7 = None
    view_73 = torch.ops.aten.view.default(expand_41, [16, 64, 128]);  expand_41 = None
    bmm_19 = torch.ops.aten.bmm.default(view_72, view_73);  view_72 = view_73 = None
    _unsafe_view_32 = torch.ops.aten._unsafe_view.default(bmm_19, [1, 16, 128, 128]);  bmm_19 = None
    add_23 = torch.ops.aten.add.Tensor(mul_42, _unsafe_view_32);  mul_42 = _unsafe_view_32 = add_23 = None
    clone_1 = torch.ops.aten.clone.default(zeros_like_1, memory_format = torch.contiguous_format);  zeros_like_1 = None
    _unsafe_view_33 = torch.ops.aten._unsafe_view.default(clone_1, [1, 16, 128, 128]);  clone_1 = None
    alias_1 = torch.ops.aten.alias.default(_unsafe_view_33);  _unsafe_view_33 = None
    transpose_23 = torch.ops.aten.transpose.int(alias_1, 1, 2);  alias_1 = None
    _to_copy_28 = torch.ops.aten._to_copy.default(transpose_23, dtype = torch.bfloat16, memory_format = torch.contiguous_format);  transpose_23 = None
    view_74 = torch.ops.aten.view.default(_to_copy_28, [-1, 128]);  _to_copy_28 = None
    view_75 = torch.ops.aten.view.default(view_43, [-1, 128]);  view_43 = None
    _to_copy_29 = torch.ops.aten._to_copy.default(view_74, dtype = torch.float32);  view_74 = None
    pow_5 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_29, 2)
    mean_4 = torch.ops.aten.mean.dim(pow_5, [-1], True);  pow_5 = None
    add_24 = torch.ops.aten.add.Tensor(mean_4, 1e-06);  mean_4 = None
    rsqrt_8 = torch.ops.aten.rsqrt.default(add_24);  add_24 = None
    mul_43 = torch.ops.aten.mul.Tensor(_to_copy_29, rsqrt_8);  _to_copy_29 = rsqrt_8 = None
    _to_copy_30 = torch.ops.aten._to_copy.default(mul_43, dtype = torch.bfloat16);  mul_43 = None
    _param_constant23 = self._param_constant23
    mul_44 = torch.ops.aten.mul.Tensor(_param_constant23, _to_copy_30);  _param_constant23 = _to_copy_30 = None
    _to_copy_31 = torch.ops.aten._to_copy.default(view_75, dtype = torch.float32);  view_75 = None
    silu_4 = torch.ops.aten.silu.default(_to_copy_31);  _to_copy_31 = None
    mul_45 = torch.ops.aten.mul.Tensor(mul_44, silu_4);  mul_44 = silu_4 = None
    _to_copy_32 = torch.ops.aten._to_copy.default(mul_45, dtype = torch.bfloat16);  mul_45 = None
    view_76 = torch.ops.aten.view.default(_to_copy_32, [1, 128, -1]);  _to_copy_32 = None
    _param_constant24 = self._param_constant24
    t_12 = torch.ops.aten.t.default(_param_constant24);  _param_constant24 = None
    view_77 = torch.ops.aten.view.default(view_76, [128, 2048]);  view_76 = None
    mm_12 = torch.ops.aten.mm.default(view_77, t_12);  view_77 = t_12 = None
    _unsafe_view_34 = torch.ops.aten._unsafe_view.default(mm_12, [1, 128, 2048]);  mm_12 = None
    add_25 = torch.ops.aten.add.Tensor(add_14, _unsafe_view_34);  add_14 = _unsafe_view_34 = None
    _to_copy_33 = torch.ops.aten._to_copy.default(add_25, dtype = torch.float32)
    pow_6 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_33, 2)
    mean_5 = torch.ops.aten.mean.dim(pow_6, [-1], True);  pow_6 = None
    add_26 = torch.ops.aten.add.Tensor(mean_5, 1e-06);  mean_5 = None
    rsqrt_9 = torch.ops.aten.rsqrt.default(add_26);  add_26 = None
    mul_46 = torch.ops.aten.mul.Tensor(_to_copy_33, rsqrt_9);  _to_copy_33 = rsqrt_9 = None
    _param_constant25 = self._param_constant25
    _to_copy_34 = torch.ops.aten._to_copy.default(_param_constant25, dtype = torch.float32);  _param_constant25 = None
    add_27 = torch.ops.aten.add.Tensor(_to_copy_34, 1.0);  _to_copy_34 = None
    mul_47 = torch.ops.aten.mul.Tensor(mul_46, add_27);  mul_46 = add_27 = None
    _to_copy_35 = torch.ops.aten._to_copy.default(mul_47, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_47 = None
    _param_constant26 = self._param_constant26
    t_13 = torch.ops.aten.t.default(_param_constant26);  _param_constant26 = None
    view_78 = torch.ops.aten.view.default(_to_copy_35, [128, 2048])
    mm_13 = torch.ops.aten.mm.default(view_78, t_13);  view_78 = t_13 = None
    _unsafe_view_35 = torch.ops.aten._unsafe_view.default(mm_13, [1, 128, 6144]);  mm_13 = None
    silu_5 = torch.ops.aten.silu.default(_unsafe_view_35);  _unsafe_view_35 = None
    _param_constant27 = self._param_constant27
    t_14 = torch.ops.aten.t.default(_param_constant27);  _param_constant27 = None
    view_79 = torch.ops.aten.view.default(_to_copy_35, [128, 2048]);  _to_copy_35 = None
    mm_14 = torch.ops.aten.mm.default(view_79, t_14);  view_79 = t_14 = None
    _unsafe_view_36 = torch.ops.aten._unsafe_view.default(mm_14, [1, 128, 6144]);  mm_14 = None
    mul_48 = torch.ops.aten.mul.Tensor(silu_5, _unsafe_view_36);  silu_5 = _unsafe_view_36 = None
    _param_constant28 = self._param_constant28
    t_15 = torch.ops.aten.t.default(_param_constant28);  _param_constant28 = None
    view_80 = torch.ops.aten.view.default(mul_48, [128, 6144]);  mul_48 = None
    mm_15 = torch.ops.aten.mm.default(view_80, t_15);  view_80 = t_15 = None
    _unsafe_view_37 = torch.ops.aten._unsafe_view.default(mm_15, [1, 128, 2048]);  mm_15 = None
    add_28 = torch.ops.aten.add.Tensor(add_25, _unsafe_view_37);  add_25 = _unsafe_view_37 = None
    _to_copy_36 = torch.ops.aten._to_copy.default(add_28, dtype = torch.float32)
    pow_7 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_36, 2)
    mean_6 = torch.ops.aten.mean.dim(pow_7, [-1], True);  pow_7 = None
    add_29 = torch.ops.aten.add.Tensor(mean_6, 1e-06);  mean_6 = None
    rsqrt_10 = torch.ops.aten.rsqrt.default(add_29);  add_29 = None
    mul_49 = torch.ops.aten.mul.Tensor(_to_copy_36, rsqrt_10);  _to_copy_36 = rsqrt_10 = None
    _param_constant29 = self._param_constant29
    _to_copy_37 = torch.ops.aten._to_copy.default(_param_constant29, dtype = torch.float32);  _param_constant29 = None
    add_30 = torch.ops.aten.add.Tensor(_to_copy_37, 1.0);  _to_copy_37 = None
    mul_50 = torch.ops.aten.mul.Tensor(mul_49, add_30);  mul_49 = add_30 = None
    _to_copy_38 = torch.ops.aten._to_copy.default(mul_50, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_50 = None
    _param_constant30 = self._param_constant30
    t_16 = torch.ops.aten.t.default(_param_constant30);  _param_constant30 = None
    view_81 = torch.ops.aten.view.default(_to_copy_38, [128, 2048])
    mm_16 = torch.ops.aten.mm.default(view_81, t_16);  view_81 = t_16 = None
    _unsafe_view_38 = torch.ops.aten._unsafe_view.default(mm_16, [1, 128, 6144]);  mm_16 = None
    transpose_24 = torch.ops.aten.transpose.int(_unsafe_view_38, 1, 2);  _unsafe_view_38 = None
    _param_constant31 = self._param_constant31
    t_17 = torch.ops.aten.t.default(_param_constant31);  _param_constant31 = None
    view_82 = torch.ops.aten.view.default(_to_copy_38, [128, 2048])
    mm_17 = torch.ops.aten.mm.default(view_82, t_17);  view_82 = t_17 = None
    _unsafe_view_39 = torch.ops.aten._unsafe_view.default(mm_17, [1, 128, 2048]);  mm_17 = None
    view_83 = torch.ops.aten.view.default(_unsafe_view_39, [1, 128, -1, 128]);  _unsafe_view_39 = None
    _param_constant32 = self._param_constant32
    t_18 = torch.ops.aten.t.default(_param_constant32);  _param_constant32 = None
    view_84 = torch.ops.aten.view.default(_to_copy_38, [128, 2048])
    mm_18 = torch.ops.aten.mm.default(view_84, t_18);  view_84 = t_18 = None
    _unsafe_view_40 = torch.ops.aten._unsafe_view.default(mm_18, [1, 128, 16]);  mm_18 = None
    _param_constant33 = self._param_constant33
    t_19 = torch.ops.aten.t.default(_param_constant33);  _param_constant33 = None
    view_85 = torch.ops.aten.view.default(_to_copy_38, [128, 2048]);  _to_copy_38 = None
    mm_19 = torch.ops.aten.mm.default(view_85, t_19);  view_85 = t_19 = None
    _unsafe_view_41 = torch.ops.aten._unsafe_view.default(mm_19, [1, 128, 16]);  mm_19 = None
    _param_constant34 = self._param_constant34
    squeeze_2 = torch.ops.aten.squeeze.dim(_param_constant34, 1);  _param_constant34 = None
    unsqueeze_23 = torch.ops.aten.unsqueeze.default(squeeze_2, 1);  squeeze_2 = None
    convolution_2 = torch.ops.aten.convolution.default(transpose_24, unsqueeze_23, None, [1], [3], [1], False, [0], 6144);  transpose_24 = unsqueeze_23 = None
    slice_14 = torch.ops.aten.slice.Tensor(convolution_2, 2, 0, 128);  convolution_2 = None
    silu_6 = torch.ops.aten.silu.default(slice_14);  slice_14 = None
    transpose_25 = torch.ops.aten.transpose.int(silu_6, 1, 2);  silu_6 = None
    split_with_sizes_2 = torch.ops.aten.split_with_sizes.default(transpose_25, [2048, 2048, 2048], -1);  transpose_25 = None
    getitem_6 = split_with_sizes_2[0]
    getitem_7 = split_with_sizes_2[1]
    getitem_8 = split_with_sizes_2[2];  split_with_sizes_2 = None
    view_86 = torch.ops.aten.view.default(getitem_6, [1, 128, 16, 128]);  getitem_6 = None
    view_87 = torch.ops.aten.view.default(getitem_7, [1, 128, 16, 128]);  getitem_7 = None
    view_88 = torch.ops.aten.view.default(getitem_8, [1, 128, 16, 128]);  getitem_8 = None
    sigmoid_2 = torch.ops.aten.sigmoid.default(_unsafe_view_40);  _unsafe_view_40 = None
    _param_constant35 = self._param_constant35
    exp_12 = torch.ops.aten.exp.default(_param_constant35);  _param_constant35 = None
    neg_2 = torch.ops.aten.neg.default(exp_12);  exp_12 = None
    _to_copy_39 = torch.ops.aten._to_copy.default(_unsafe_view_41, dtype = torch.float32);  _unsafe_view_41 = None
    _param_constant36 = self._param_constant36
    add_31 = torch.ops.aten.add.Tensor(_to_copy_39, _param_constant36);  _to_copy_39 = _param_constant36 = None
    softplus_2 = torch.ops.aten.softplus.default(add_31);  add_31 = None
    mul_51 = torch.ops.aten.mul.Tensor(neg_2, softplus_2);  neg_2 = softplus_2 = None
    transpose_26 = torch.ops.aten.transpose.int(view_86, 1, 2);  view_86 = None
    _to_copy_40 = torch.ops.aten._to_copy.default(transpose_26, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_26 = None
    transpose_27 = torch.ops.aten.transpose.int(view_87, 1, 2);  view_87 = None
    _to_copy_41 = torch.ops.aten._to_copy.default(transpose_27, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_27 = None
    transpose_28 = torch.ops.aten.transpose.int(view_88, 1, 2);  view_88 = None
    _to_copy_42 = torch.ops.aten._to_copy.default(transpose_28, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_28 = None
    transpose_29 = torch.ops.aten.transpose.int(sigmoid_2, 1, 2);  sigmoid_2 = None
    _to_copy_43 = torch.ops.aten._to_copy.default(transpose_29, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_29 = None
    transpose_30 = torch.ops.aten.transpose.int(mul_51, 1, 2);  mul_51 = None
    mul_52 = torch.ops.aten.mul.Tensor(_to_copy_40, _to_copy_40)
    sum_5 = torch.ops.aten.sum.dim_IntList(mul_52, [-1], True);  mul_52 = None
    add_32 = torch.ops.aten.add.Tensor(sum_5, 1e-06);  sum_5 = None
    rsqrt_11 = torch.ops.aten.rsqrt.default(add_32);  add_32 = None
    mul_53 = torch.ops.aten.mul.Tensor(_to_copy_40, rsqrt_11);  _to_copy_40 = rsqrt_11 = None
    mul_54 = torch.ops.aten.mul.Tensor(_to_copy_41, _to_copy_41)
    sum_6 = torch.ops.aten.sum.dim_IntList(mul_54, [-1], True);  mul_54 = None
    add_33 = torch.ops.aten.add.Tensor(sum_6, 1e-06);  sum_6 = None
    rsqrt_12 = torch.ops.aten.rsqrt.default(add_33);  add_33 = None
    mul_55 = torch.ops.aten.mul.Tensor(_to_copy_41, rsqrt_12);  _to_copy_41 = rsqrt_12 = None
    mul_56 = torch.ops.aten.mul.Tensor(mul_53, 0.08838834764831845);  mul_53 = None
    constant_pad_nd_10 = torch.ops.aten.constant_pad_nd.default(mul_56, [0, 0, 0, 0], 0.0);  mul_56 = None
    constant_pad_nd_11 = torch.ops.aten.constant_pad_nd.default(mul_55, [0, 0, 0, 0], 0.0);  mul_55 = None
    constant_pad_nd_12 = torch.ops.aten.constant_pad_nd.default(_to_copy_42, [0, 0, 0, 0], 0.0);  _to_copy_42 = None
    constant_pad_nd_13 = torch.ops.aten.constant_pad_nd.default(_to_copy_43, [0, 0], 0.0);  _to_copy_43 = None
    constant_pad_nd_14 = torch.ops.aten.constant_pad_nd.default(transpose_30, [0, 0], 0.0);  transpose_30 = None
    unsqueeze_24 = torch.ops.aten.unsqueeze.default(constant_pad_nd_13, -1)
    mul_57 = torch.ops.aten.mul.Tensor(constant_pad_nd_12, unsqueeze_24);  constant_pad_nd_12 = unsqueeze_24 = None
    unsqueeze_25 = torch.ops.aten.unsqueeze.default(constant_pad_nd_13, -1);  constant_pad_nd_13 = None
    mul_58 = torch.ops.aten.mul.Tensor(constant_pad_nd_11, unsqueeze_25);  unsqueeze_25 = None
    view_89 = torch.ops.aten.view.default(constant_pad_nd_10, [1, 16, -1, 64, 128]);  constant_pad_nd_10 = None
    view_90 = torch.ops.aten.view.default(constant_pad_nd_11, [1, 16, -1, 64, 128]);  constant_pad_nd_11 = None
    view_91 = torch.ops.aten.view.default(mul_58, [1, 16, -1, 64, 128]);  mul_58 = None
    view_92 = torch.ops.aten.view.default(mul_57, [1, 16, -1, 64, 128]);  mul_57 = None
    view_93 = torch.ops.aten.view.default(constant_pad_nd_14, [1, 16, 2, 64]);  constant_pad_nd_14 = None
    ones_2 = torch.ops.aten.ones.default([64, 64], dtype = torch.bool, device = device(type='meta'), pin_memory = False)
    triu_3 = torch.ops.aten.triu.default(ones_2, 1);  ones_2 = None
    cumsum_2 = torch.ops.aten.cumsum.default(view_93, 3);  view_93 = None
    unsqueeze_26 = torch.ops.aten.unsqueeze.default(cumsum_2, 4)
    unsqueeze_27 = torch.ops.aten.unsqueeze.default(cumsum_2, 3)
    sub_8 = torch.ops.aten.sub.Tensor(unsqueeze_26, unsqueeze_27);  unsqueeze_26 = unsqueeze_27 = None
    masked_fill_2 = torch.ops.aten.masked_fill.Scalar(sub_8, triu_3, -inf);  sub_8 = triu_3 = None
    exp_13 = torch.ops.aten.exp.default(masked_fill_2);  masked_fill_2 = None
    transpose_31 = torch.ops.aten.transpose.int(view_90, -1, -2)
    expand_42 = torch.ops.aten.expand.default(view_91, [1, 16, 2, 64, 128])
    view_94 = torch.ops.aten.view.default(expand_42, [32, 64, 128]);  expand_42 = None
    expand_43 = torch.ops.aten.expand.default(transpose_31, [1, 16, 2, 128, 64]);  transpose_31 = None
    view_95 = torch.ops.aten.view.default(expand_43, [32, 128, 64]);  expand_43 = None
    bmm_20 = torch.ops.aten.bmm.default(view_94, view_95);  view_94 = view_95 = None
    _unsafe_view_42 = torch.ops.aten._unsafe_view.default(bmm_20, [1, 16, 2, 64, 64]);  bmm_20 = None
    mul_59 = torch.ops.aten.mul.Tensor(_unsafe_view_42, exp_13);  _unsafe_view_42 = None
    transpose_32 = torch.ops.aten.transpose.int(view_90, -1, -2)
    expand_44 = torch.ops.aten.expand.default(view_89, [1, 16, 2, 64, 128])
    view_96 = torch.ops.aten.view.default(expand_44, [32, 64, 128]);  expand_44 = None
    expand_45 = torch.ops.aten.expand.default(transpose_32, [1, 16, 2, 128, 64]);  transpose_32 = None
    view_97 = torch.ops.aten.view.default(expand_45, [32, 128, 64]);  expand_45 = None
    bmm_21 = torch.ops.aten.bmm.default(view_96, view_97);  view_96 = view_97 = None
    _unsafe_view_43 = torch.ops.aten._unsafe_view.default(bmm_21, [1, 16, 2, 64, 64]);  bmm_21 = None
    mul_60 = torch.ops.aten.mul.Tensor(_unsafe_view_43, exp_13);  _unsafe_view_43 = exp_13 = None
    exp_14 = torch.ops.aten.exp.default(cumsum_2)
    unsqueeze_28 = torch.ops.aten.unsqueeze.default(exp_14, -1);  exp_14 = None
    mul_61 = torch.ops.aten.mul.Tensor(view_91, unsqueeze_28);  view_91 = unsqueeze_28 = None
    linalg_solve_triangular_4 = torch.ops.aten.linalg_solve_triangular.default(mul_59, view_92, upper = False, unitriangular = True);  view_92 = None
    linalg_solve_triangular_5 = torch.ops.aten.linalg_solve_triangular.default(mul_59, mul_61, upper = False, unitriangular = True);  mul_59 = mul_61 = None
    zeros_2 = torch.ops.aten.zeros.default([1, 16, 128, 128], dtype = torch.float32, device = device(type='meta'), pin_memory = False)
    zeros_like_2 = torch.ops.aten.zeros_like.default(linalg_solve_triangular_4, pin_memory = False)
    exp_15 = torch.ops.aten.exp.default(cumsum_2)
    unsqueeze_29 = torch.ops.aten.unsqueeze.default(exp_15, -1);  exp_15 = None
    mul_62 = torch.ops.aten.mul.Tensor(view_89, unsqueeze_29);  view_89 = unsqueeze_29 = None
    slice_15 = torch.ops.aten.slice.Tensor(cumsum_2, 3, -1, 9223372036854775807)
    sub_9 = torch.ops.aten.sub.Tensor(slice_15, cumsum_2);  slice_15 = None
    exp_16 = torch.ops.aten.exp.default(sub_9);  sub_9 = None
    unsqueeze_30 = torch.ops.aten.unsqueeze.default(exp_16, -1);  exp_16 = None
    mul_63 = torch.ops.aten.mul.Tensor(view_90, unsqueeze_30);  view_90 = unsqueeze_30 = None
    select_37 = torch.ops.aten.select.int(cumsum_2, 3, -1);  cumsum_2 = None
    exp_17 = torch.ops.aten.exp.default(select_37);  select_37 = None
    unsqueeze_31 = torch.ops.aten.unsqueeze.default(exp_17, 3);  exp_17 = None
    unsqueeze_32 = torch.ops.aten.unsqueeze.default(unsqueeze_31, 4);  unsqueeze_31 = None
    select_38 = torch.ops.aten.select.int(linalg_solve_triangular_4, 2, 0)
    select_39 = torch.ops.aten.select.int(linalg_solve_triangular_5, 2, 0)
    expand_46 = torch.ops.aten.expand.default(select_39, [1, 16, 64, 128]);  select_39 = None
    view_98 = torch.ops.aten.view.default(expand_46, [16, 64, 128]);  expand_46 = None
    expand_47 = torch.ops.aten.expand.default(zeros_2, [1, 16, 128, 128])
    view_99 = torch.ops.aten.view.default(expand_47, [16, 128, 128]);  expand_47 = None
    bmm_22 = torch.ops.aten.bmm.default(view_98, view_99);  view_98 = view_99 = None
    _unsafe_view_44 = torch.ops.aten._unsafe_view.default(bmm_22, [1, 16, 64, 128]);  bmm_22 = None
    sub_10 = torch.ops.aten.sub.Tensor(select_38, _unsafe_view_44);  select_38 = _unsafe_view_44 = None
    select_40 = torch.ops.aten.select.int(mul_62, 2, 0)
    expand_48 = torch.ops.aten.expand.default(select_40, [1, 16, 64, 128]);  select_40 = None
    view_100 = torch.ops.aten.view.default(expand_48, [16, 64, 128]);  expand_48 = None
    expand_49 = torch.ops.aten.expand.default(zeros_2, [1, 16, 128, 128])
    view_101 = torch.ops.aten.view.default(expand_49, [16, 128, 128]);  expand_49 = None
    bmm_23 = torch.ops.aten.bmm.default(view_100, view_101);  view_100 = view_101 = None
    _unsafe_view_45 = torch.ops.aten._unsafe_view.default(bmm_23, [1, 16, 64, 128]);  bmm_23 = None
    select_41 = torch.ops.aten.select.int(mul_60, 2, 0)
    expand_50 = torch.ops.aten.expand.default(select_41, [1, 16, 64, 64]);  select_41 = None
    view_102 = torch.ops.aten.view.default(expand_50, [16, 64, 64]);  expand_50 = None
    expand_51 = torch.ops.aten.expand.default(sub_10, [1, 16, 64, 128])
    view_103 = torch.ops.aten.view.default(expand_51, [16, 64, 128]);  expand_51 = None
    bmm_24 = torch.ops.aten.bmm.default(view_102, view_103);  view_102 = view_103 = None
    _unsafe_view_46 = torch.ops.aten._unsafe_view.default(bmm_24, [1, 16, 64, 128]);  bmm_24 = None
    add_34 = torch.ops.aten.add.Tensor(_unsafe_view_45, _unsafe_view_46);  _unsafe_view_45 = _unsafe_view_46 = None
    select_42 = torch.ops.aten.select.int(zeros_like_2, 2, 0)
    copy__8 = torch.ops.aten.copy_.default(select_42, add_34);  select_42 = add_34 = copy__8 = None
    select_43 = torch.ops.aten.select.int(unsqueeze_32, 2, 0)
    mul_64 = torch.ops.aten.mul.Tensor(zeros_2, select_43);  zeros_2 = select_43 = None
    select_44 = torch.ops.aten.select.int(mul_63, 2, 0)
    transpose_33 = torch.ops.aten.transpose.int(select_44, -1, -2);  select_44 = None
    expand_52 = torch.ops.aten.expand.default(transpose_33, [1, 16, 128, 64]);  transpose_33 = None
    view_104 = torch.ops.aten.view.default(expand_52, [16, 128, 64]);  expand_52 = None
    expand_53 = torch.ops.aten.expand.default(sub_10, [1, 16, 64, 128]);  sub_10 = None
    view_105 = torch.ops.aten.view.default(expand_53, [16, 64, 128]);  expand_53 = None
    bmm_25 = torch.ops.aten.bmm.default(view_104, view_105);  view_104 = view_105 = None
    _unsafe_view_47 = torch.ops.aten._unsafe_view.default(bmm_25, [1, 16, 128, 128]);  bmm_25 = None
    add_35 = torch.ops.aten.add.Tensor(mul_64, _unsafe_view_47);  mul_64 = _unsafe_view_47 = None
    select_45 = torch.ops.aten.select.int(linalg_solve_triangular_4, 2, 1);  linalg_solve_triangular_4 = None
    select_46 = torch.ops.aten.select.int(linalg_solve_triangular_5, 2, 1);  linalg_solve_triangular_5 = None
    expand_54 = torch.ops.aten.expand.default(select_46, [1, 16, 64, 128]);  select_46 = None
    view_106 = torch.ops.aten.view.default(expand_54, [16, 64, 128]);  expand_54 = None
    expand_55 = torch.ops.aten.expand.default(add_35, [1, 16, 128, 128])
    view_107 = torch.ops.aten.view.default(expand_55, [16, 128, 128]);  expand_55 = None
    bmm_26 = torch.ops.aten.bmm.default(view_106, view_107);  view_106 = view_107 = None
    _unsafe_view_48 = torch.ops.aten._unsafe_view.default(bmm_26, [1, 16, 64, 128]);  bmm_26 = None
    sub_11 = torch.ops.aten.sub.Tensor(select_45, _unsafe_view_48);  select_45 = _unsafe_view_48 = None
    select_47 = torch.ops.aten.select.int(mul_62, 2, 1);  mul_62 = None
    expand_56 = torch.ops.aten.expand.default(select_47, [1, 16, 64, 128]);  select_47 = None
    view_108 = torch.ops.aten.view.default(expand_56, [16, 64, 128]);  expand_56 = None
    expand_57 = torch.ops.aten.expand.default(add_35, [1, 16, 128, 128])
    view_109 = torch.ops.aten.view.default(expand_57, [16, 128, 128]);  expand_57 = None
    bmm_27 = torch.ops.aten.bmm.default(view_108, view_109);  view_108 = view_109 = None
    _unsafe_view_49 = torch.ops.aten._unsafe_view.default(bmm_27, [1, 16, 64, 128]);  bmm_27 = None
    select_48 = torch.ops.aten.select.int(mul_60, 2, 1);  mul_60 = None
    expand_58 = torch.ops.aten.expand.default(select_48, [1, 16, 64, 64]);  select_48 = None
    view_110 = torch.ops.aten.view.default(expand_58, [16, 64, 64]);  expand_58 = None
    expand_59 = torch.ops.aten.expand.default(sub_11, [1, 16, 64, 128])
    view_111 = torch.ops.aten.view.default(expand_59, [16, 64, 128]);  expand_59 = None
    bmm_28 = torch.ops.aten.bmm.default(view_110, view_111);  view_110 = view_111 = None
    _unsafe_view_50 = torch.ops.aten._unsafe_view.default(bmm_28, [1, 16, 64, 128]);  bmm_28 = None
    add_36 = torch.ops.aten.add.Tensor(_unsafe_view_49, _unsafe_view_50);  _unsafe_view_49 = _unsafe_view_50 = None
    select_49 = torch.ops.aten.select.int(zeros_like_2, 2, 1)
    copy__9 = torch.ops.aten.copy_.default(select_49, add_36);  select_49 = add_36 = copy__9 = None
    select_50 = torch.ops.aten.select.int(unsqueeze_32, 2, 1);  unsqueeze_32 = None
    mul_65 = torch.ops.aten.mul.Tensor(add_35, select_50);  add_35 = select_50 = None
    select_51 = torch.ops.aten.select.int(mul_63, 2, 1);  mul_63 = None
    transpose_34 = torch.ops.aten.transpose.int(select_51, -1, -2);  select_51 = None
    expand_60 = torch.ops.aten.expand.default(transpose_34, [1, 16, 128, 64]);  transpose_34 = None
    view_112 = torch.ops.aten.view.default(expand_60, [16, 128, 64]);  expand_60 = None
    expand_61 = torch.ops.aten.expand.default(sub_11, [1, 16, 64, 128]);  sub_11 = None
    view_113 = torch.ops.aten.view.default(expand_61, [16, 64, 128]);  expand_61 = None
    bmm_29 = torch.ops.aten.bmm.default(view_112, view_113);  view_112 = view_113 = None
    _unsafe_view_51 = torch.ops.aten._unsafe_view.default(bmm_29, [1, 16, 128, 128]);  bmm_29 = None
    add_37 = torch.ops.aten.add.Tensor(mul_65, _unsafe_view_51);  mul_65 = _unsafe_view_51 = add_37 = None
    clone_2 = torch.ops.aten.clone.default(zeros_like_2, memory_format = torch.contiguous_format);  zeros_like_2 = None
    _unsafe_view_52 = torch.ops.aten._unsafe_view.default(clone_2, [1, 16, 128, 128]);  clone_2 = None
    alias_2 = torch.ops.aten.alias.default(_unsafe_view_52);  _unsafe_view_52 = None
    transpose_35 = torch.ops.aten.transpose.int(alias_2, 1, 2);  alias_2 = None
    _to_copy_44 = torch.ops.aten._to_copy.default(transpose_35, dtype = torch.bfloat16, memory_format = torch.contiguous_format);  transpose_35 = None
    view_114 = torch.ops.aten.view.default(_to_copy_44, [-1, 128]);  _to_copy_44 = None
    view_115 = torch.ops.aten.view.default(view_83, [-1, 128]);  view_83 = None
    _to_copy_45 = torch.ops.aten._to_copy.default(view_114, dtype = torch.float32);  view_114 = None
    pow_8 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_45, 2)
    mean_7 = torch.ops.aten.mean.dim(pow_8, [-1], True);  pow_8 = None
    add_38 = torch.ops.aten.add.Tensor(mean_7, 1e-06);  mean_7 = None
    rsqrt_13 = torch.ops.aten.rsqrt.default(add_38);  add_38 = None
    mul_66 = torch.ops.aten.mul.Tensor(_to_copy_45, rsqrt_13);  _to_copy_45 = rsqrt_13 = None
    _to_copy_46 = torch.ops.aten._to_copy.default(mul_66, dtype = torch.bfloat16);  mul_66 = None
    _param_constant37 = self._param_constant37
    mul_67 = torch.ops.aten.mul.Tensor(_param_constant37, _to_copy_46);  _param_constant37 = _to_copy_46 = None
    _to_copy_47 = torch.ops.aten._to_copy.default(view_115, dtype = torch.float32);  view_115 = None
    silu_7 = torch.ops.aten.silu.default(_to_copy_47);  _to_copy_47 = None
    mul_68 = torch.ops.aten.mul.Tensor(mul_67, silu_7);  mul_67 = silu_7 = None
    _to_copy_48 = torch.ops.aten._to_copy.default(mul_68, dtype = torch.bfloat16);  mul_68 = None
    view_116 = torch.ops.aten.view.default(_to_copy_48, [1, 128, -1]);  _to_copy_48 = None
    _param_constant38 = self._param_constant38
    t_20 = torch.ops.aten.t.default(_param_constant38);  _param_constant38 = None
    view_117 = torch.ops.aten.view.default(view_116, [128, 2048]);  view_116 = None
    mm_20 = torch.ops.aten.mm.default(view_117, t_20);  view_117 = t_20 = None
    _unsafe_view_53 = torch.ops.aten._unsafe_view.default(mm_20, [1, 128, 2048]);  mm_20 = None
    add_39 = torch.ops.aten.add.Tensor(add_28, _unsafe_view_53);  add_28 = _unsafe_view_53 = None
    _to_copy_49 = torch.ops.aten._to_copy.default(add_39, dtype = torch.float32)
    pow_9 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_49, 2)
    mean_8 = torch.ops.aten.mean.dim(pow_9, [-1], True);  pow_9 = None
    add_40 = torch.ops.aten.add.Tensor(mean_8, 1e-06);  mean_8 = None
    rsqrt_14 = torch.ops.aten.rsqrt.default(add_40);  add_40 = None
    mul_69 = torch.ops.aten.mul.Tensor(_to_copy_49, rsqrt_14);  _to_copy_49 = rsqrt_14 = None
    _param_constant39 = self._param_constant39
    _to_copy_50 = torch.ops.aten._to_copy.default(_param_constant39, dtype = torch.float32);  _param_constant39 = None
    add_41 = torch.ops.aten.add.Tensor(_to_copy_50, 1.0);  _to_copy_50 = None
    mul_70 = torch.ops.aten.mul.Tensor(mul_69, add_41);  mul_69 = add_41 = None
    _to_copy_51 = torch.ops.aten._to_copy.default(mul_70, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_70 = None
    _param_constant40 = self._param_constant40
    t_21 = torch.ops.aten.t.default(_param_constant40);  _param_constant40 = None
    view_118 = torch.ops.aten.view.default(_to_copy_51, [128, 2048])
    mm_21 = torch.ops.aten.mm.default(view_118, t_21);  view_118 = t_21 = None
    _unsafe_view_54 = torch.ops.aten._unsafe_view.default(mm_21, [1, 128, 6144]);  mm_21 = None
    silu_8 = torch.ops.aten.silu.default(_unsafe_view_54);  _unsafe_view_54 = None
    _param_constant41 = self._param_constant41
    t_22 = torch.ops.aten.t.default(_param_constant41);  _param_constant41 = None
    view_119 = torch.ops.aten.view.default(_to_copy_51, [128, 2048]);  _to_copy_51 = None
    mm_22 = torch.ops.aten.mm.default(view_119, t_22);  view_119 = t_22 = None
    _unsafe_view_55 = torch.ops.aten._unsafe_view.default(mm_22, [1, 128, 6144]);  mm_22 = None
    mul_71 = torch.ops.aten.mul.Tensor(silu_8, _unsafe_view_55);  silu_8 = _unsafe_view_55 = None
    _param_constant42 = self._param_constant42
    t_23 = torch.ops.aten.t.default(_param_constant42);  _param_constant42 = None
    view_120 = torch.ops.aten.view.default(mul_71, [128, 6144]);  mul_71 = None
    mm_23 = torch.ops.aten.mm.default(view_120, t_23);  view_120 = t_23 = None
    _unsafe_view_56 = torch.ops.aten._unsafe_view.default(mm_23, [1, 128, 2048]);  mm_23 = None
    add_42 = torch.ops.aten.add.Tensor(add_39, _unsafe_view_56);  add_39 = _unsafe_view_56 = None
    _to_copy_52 = torch.ops.aten._to_copy.default(add_42, dtype = torch.float32)
    pow_10 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_52, 2)
    mean_9 = torch.ops.aten.mean.dim(pow_10, [-1], True);  pow_10 = None
    add_43 = torch.ops.aten.add.Tensor(mean_9, 1e-06);  mean_9 = None
    rsqrt_15 = torch.ops.aten.rsqrt.default(add_43);  add_43 = None
    mul_72 = torch.ops.aten.mul.Tensor(_to_copy_52, rsqrt_15);  _to_copy_52 = rsqrt_15 = None
    _param_constant43 = self._param_constant43
    _to_copy_53 = torch.ops.aten._to_copy.default(_param_constant43, dtype = torch.float32);  _param_constant43 = None
    add_44 = torch.ops.aten.add.Tensor(_to_copy_53, 1.0);  _to_copy_53 = None
    mul_73 = torch.ops.aten.mul.Tensor(mul_72, add_44);  mul_72 = add_44 = None
    _to_copy_54 = torch.ops.aten._to_copy.default(mul_73, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_73 = None
    _param_constant44 = self._param_constant44
    t_24 = torch.ops.aten.t.default(_param_constant44);  _param_constant44 = None
    view_121 = torch.ops.aten.view.default(_to_copy_54, [128, 2048])
    mm_24 = torch.ops.aten.mm.default(view_121, t_24);  view_121 = t_24 = None
    _unsafe_view_57 = torch.ops.aten._unsafe_view.default(mm_24, [1, 128, 4096]);  mm_24 = None
    view_122 = torch.ops.aten.view.default(_unsafe_view_57, [1, 128, -1, 512]);  _unsafe_view_57 = None
    split = torch.ops.aten.split.Tensor(view_122, 256, -1);  view_122 = None
    getitem_9 = split[0]
    getitem_10 = split[1];  split = None
    clone_3 = torch.ops.aten.clone.default(getitem_10, memory_format = torch.contiguous_format);  getitem_10 = None
    _unsafe_view_58 = torch.ops.aten._unsafe_view.default(clone_3, [1, 128, 2048]);  clone_3 = None
    view_123 = torch.ops.aten.view.default(getitem_9, [1, 128, -1, 256]);  getitem_9 = None
    _to_copy_55 = torch.ops.aten._to_copy.default(view_123, dtype = torch.float32);  view_123 = None
    pow_11 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_55, 2)
    mean_10 = torch.ops.aten.mean.dim(pow_11, [-1], True);  pow_11 = None
    add_45 = torch.ops.aten.add.Tensor(mean_10, 1e-06);  mean_10 = None
    rsqrt_16 = torch.ops.aten.rsqrt.default(add_45);  add_45 = None
    mul_74 = torch.ops.aten.mul.Tensor(_to_copy_55, rsqrt_16);  _to_copy_55 = rsqrt_16 = None
    _param_constant45 = self._param_constant45
    _to_copy_56 = torch.ops.aten._to_copy.default(_param_constant45, dtype = torch.float32);  _param_constant45 = None
    add_46 = torch.ops.aten.add.Tensor(_to_copy_56, 1.0);  _to_copy_56 = None
    mul_75 = torch.ops.aten.mul.Tensor(mul_74, add_46);  mul_74 = add_46 = None
    _to_copy_57 = torch.ops.aten._to_copy.default(mul_75, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_75 = None
    transpose_36 = torch.ops.aten.transpose.int(_to_copy_57, 1, 2);  _to_copy_57 = None
    _param_constant46 = self._param_constant46
    t_25 = torch.ops.aten.t.default(_param_constant46);  _param_constant46 = None
    view_124 = torch.ops.aten.view.default(_to_copy_54, [128, 2048])
    mm_25 = torch.ops.aten.mm.default(view_124, t_25);  view_124 = t_25 = None
    _unsafe_view_59 = torch.ops.aten._unsafe_view.default(mm_25, [1, 128, 512]);  mm_25 = None
    view_125 = torch.ops.aten.view.default(_unsafe_view_59, [1, 128, -1, 256]);  _unsafe_view_59 = None
    _to_copy_58 = torch.ops.aten._to_copy.default(view_125, dtype = torch.float32);  view_125 = None
    pow_12 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_58, 2)
    mean_11 = torch.ops.aten.mean.dim(pow_12, [-1], True);  pow_12 = None
    add_47 = torch.ops.aten.add.Tensor(mean_11, 1e-06);  mean_11 = None
    rsqrt_17 = torch.ops.aten.rsqrt.default(add_47);  add_47 = None
    mul_76 = torch.ops.aten.mul.Tensor(_to_copy_58, rsqrt_17);  _to_copy_58 = rsqrt_17 = None
    _param_constant47 = self._param_constant47
    _to_copy_59 = torch.ops.aten._to_copy.default(_param_constant47, dtype = torch.float32);  _param_constant47 = None
    add_48 = torch.ops.aten.add.Tensor(_to_copy_59, 1.0);  _to_copy_59 = None
    mul_77 = torch.ops.aten.mul.Tensor(mul_76, add_48);  mul_76 = add_48 = None
    _to_copy_60 = torch.ops.aten._to_copy.default(mul_77, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_77 = None
    transpose_37 = torch.ops.aten.transpose.int(_to_copy_60, 1, 2);  _to_copy_60 = None
    _param_constant48 = self._param_constant48
    t_26 = torch.ops.aten.t.default(_param_constant48);  _param_constant48 = None
    view_126 = torch.ops.aten.view.default(_to_copy_54, [128, 2048]);  _to_copy_54 = None
    mm_26 = torch.ops.aten.mm.default(view_126, t_26);  view_126 = t_26 = None
    _unsafe_view_60 = torch.ops.aten._unsafe_view.default(mm_26, [1, 128, 512]);  mm_26 = None
    view_127 = torch.ops.aten.view.default(_unsafe_view_60, [1, 128, -1, 256]);  _unsafe_view_60 = None
    transpose_38 = torch.ops.aten.transpose.int(view_127, 1, 2);  view_127 = None
    unsqueeze_33 = torch.ops.aten.unsqueeze.default(_to_copy_2, 1)
    unsqueeze_34 = torch.ops.aten.unsqueeze.default(_to_copy_3, 1)
    slice_16 = torch.ops.aten.slice.Tensor(transpose_36, 3, 0, 64)
    slice_17 = torch.ops.aten.slice.Tensor(transpose_36, 3, 64, 9223372036854775807);  transpose_36 = None
    slice_18 = torch.ops.aten.slice.Tensor(transpose_37, 3, 0, 64)
    slice_19 = torch.ops.aten.slice.Tensor(transpose_37, 3, 64, 9223372036854775807);  transpose_37 = None
    mul_78 = torch.ops.aten.mul.Tensor(slice_16, unsqueeze_33)
    slice_20 = torch.ops.aten.slice.Tensor(slice_16, 3, 0, 32)
    slice_21 = torch.ops.aten.slice.Tensor(slice_16, 3, 32, 9223372036854775807);  slice_16 = None
    neg_3 = torch.ops.aten.neg.default(slice_21);  slice_21 = None
    cat_2 = torch.ops.aten.cat.default([neg_3, slice_20], -1);  neg_3 = slice_20 = None
    mul_79 = torch.ops.aten.mul.Tensor(cat_2, unsqueeze_34);  cat_2 = None
    add_49 = torch.ops.aten.add.Tensor(mul_78, mul_79);  mul_78 = mul_79 = None
    mul_80 = torch.ops.aten.mul.Tensor(slice_18, unsqueeze_33);  unsqueeze_33 = None
    slice_22 = torch.ops.aten.slice.Tensor(slice_18, 3, 0, 32)
    slice_23 = torch.ops.aten.slice.Tensor(slice_18, 3, 32, 9223372036854775807);  slice_18 = None
    neg_4 = torch.ops.aten.neg.default(slice_23);  slice_23 = None
    cat_3 = torch.ops.aten.cat.default([neg_4, slice_22], -1);  neg_4 = slice_22 = None
    mul_81 = torch.ops.aten.mul.Tensor(cat_3, unsqueeze_34);  cat_3 = unsqueeze_34 = None
    add_50 = torch.ops.aten.add.Tensor(mul_80, mul_81);  mul_80 = mul_81 = None
    cat_4 = torch.ops.aten.cat.default([add_49, slice_17], -1);  add_49 = slice_17 = None
    cat_5 = torch.ops.aten.cat.default([add_50, slice_19], -1);  add_50 = slice_19 = None
    unsqueeze_35 = torch.ops.aten.unsqueeze.default(cat_5, 2);  cat_5 = None
    expand_62 = torch.ops.aten.expand.default(unsqueeze_35, [1, 2, 4, 128, 256]);  unsqueeze_35 = None
    clone_4 = torch.ops.aten.clone.default(expand_62, memory_format = torch.contiguous_format);  expand_62 = None
    _unsafe_view_61 = torch.ops.aten._unsafe_view.default(clone_4, [1, 8, 128, 256]);  clone_4 = None
    unsqueeze_36 = torch.ops.aten.unsqueeze.default(transpose_38, 2);  transpose_38 = None
    expand_63 = torch.ops.aten.expand.default(unsqueeze_36, [1, 2, 4, 128, 256]);  unsqueeze_36 = None
    clone_5 = torch.ops.aten.clone.default(expand_63, memory_format = torch.contiguous_format);  expand_63 = None
    _unsafe_view_62 = torch.ops.aten._unsafe_view.default(clone_5, [1, 8, 128, 256]);  clone_5 = None
    transpose_39 = torch.ops.aten.transpose.int(_unsafe_view_61, 2, 3);  _unsafe_view_61 = None
    expand_64 = torch.ops.aten.expand.default(cat_4, [1, 8, 128, 256]);  cat_4 = None
    view_128 = torch.ops.aten.view.default(expand_64, [8, 128, 256]);  expand_64 = None
    expand_65 = torch.ops.aten.expand.default(transpose_39, [1, 8, 256, 128]);  transpose_39 = None
    view_129 = torch.ops.aten.view.default(expand_65, [8, 256, 128]);  expand_65 = None
    bmm_30 = torch.ops.aten.bmm.default(view_128, view_129);  view_128 = view_129 = None
    _unsafe_view_63 = torch.ops.aten._unsafe_view.default(bmm_30, [1, 8, 128, 128]);  bmm_30 = None
    mul_82 = torch.ops.aten.mul.Tensor(_unsafe_view_63, 0.0625);  _unsafe_view_63 = None
    add_51 = torch.ops.aten.add.Tensor(mul_82, unsqueeze_1);  mul_82 = None
    _to_copy_61 = torch.ops.aten._to_copy.default(add_51, dtype = torch.float32, layout = torch.strided, device = device(type='meta'));  add_51 = None
    _softmax = torch.ops.aten._softmax.default(_to_copy_61, -1, False);  _to_copy_61 = None
    _to_copy_62 = torch.ops.aten._to_copy.default(_softmax, dtype = torch.bfloat16);  _softmax = None
    expand_66 = torch.ops.aten.expand.default(_to_copy_62, [1, 8, 128, 128]);  _to_copy_62 = None
    view_130 = torch.ops.aten.view.default(expand_66, [8, 128, 128]);  expand_66 = None
    expand_67 = torch.ops.aten.expand.default(_unsafe_view_62, [1, 8, 128, 256]);  _unsafe_view_62 = None
    view_131 = torch.ops.aten.view.default(expand_67, [8, 128, 256]);  expand_67 = None
    bmm_31 = torch.ops.aten.bmm.default(view_130, view_131);  view_130 = view_131 = None
    _unsafe_view_64 = torch.ops.aten._unsafe_view.default(bmm_31, [1, 8, 128, 256]);  bmm_31 = None
    transpose_40 = torch.ops.aten.transpose.int(_unsafe_view_64, 1, 2);  _unsafe_view_64 = None
    clone_6 = torch.ops.aten.clone.default(transpose_40, memory_format = torch.contiguous_format);  transpose_40 = None
    view_132 = torch.ops.aten.view.default(clone_6, [1, 128, -1]);  clone_6 = None
    sigmoid_3 = torch.ops.aten.sigmoid.default(_unsafe_view_58);  _unsafe_view_58 = None
    mul_83 = torch.ops.aten.mul.Tensor(view_132, sigmoid_3);  view_132 = sigmoid_3 = None
    _param_constant49 = self._param_constant49
    t_27 = torch.ops.aten.t.default(_param_constant49);  _param_constant49 = None
    view_133 = torch.ops.aten.view.default(mul_83, [128, 2048]);  mul_83 = None
    mm_27 = torch.ops.aten.mm.default(view_133, t_27);  view_133 = t_27 = None
    _unsafe_view_65 = torch.ops.aten._unsafe_view.default(mm_27, [1, 128, 2048]);  mm_27 = None
    add_52 = torch.ops.aten.add.Tensor(add_42, _unsafe_view_65);  add_42 = _unsafe_view_65 = None
    _to_copy_63 = torch.ops.aten._to_copy.default(add_52, dtype = torch.float32)
    pow_13 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_63, 2)
    mean_12 = torch.ops.aten.mean.dim(pow_13, [-1], True);  pow_13 = None
    add_53 = torch.ops.aten.add.Tensor(mean_12, 1e-06);  mean_12 = None
    rsqrt_18 = torch.ops.aten.rsqrt.default(add_53);  add_53 = None
    mul_84 = torch.ops.aten.mul.Tensor(_to_copy_63, rsqrt_18);  _to_copy_63 = rsqrt_18 = None
    _param_constant50 = self._param_constant50
    _to_copy_64 = torch.ops.aten._to_copy.default(_param_constant50, dtype = torch.float32);  _param_constant50 = None
    add_54 = torch.ops.aten.add.Tensor(_to_copy_64, 1.0);  _to_copy_64 = None
    mul_85 = torch.ops.aten.mul.Tensor(mul_84, add_54);  mul_84 = add_54 = None
    _to_copy_65 = torch.ops.aten._to_copy.default(mul_85, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_85 = None
    _param_constant51 = self._param_constant51
    t_28 = torch.ops.aten.t.default(_param_constant51);  _param_constant51 = None
    view_134 = torch.ops.aten.view.default(_to_copy_65, [128, 2048])
    mm_28 = torch.ops.aten.mm.default(view_134, t_28);  view_134 = t_28 = None
    _unsafe_view_66 = torch.ops.aten._unsafe_view.default(mm_28, [1, 128, 6144]);  mm_28 = None
    silu_9 = torch.ops.aten.silu.default(_unsafe_view_66);  _unsafe_view_66 = None
    _param_constant52 = self._param_constant52
    t_29 = torch.ops.aten.t.default(_param_constant52);  _param_constant52 = None
    view_135 = torch.ops.aten.view.default(_to_copy_65, [128, 2048]);  _to_copy_65 = None
    mm_29 = torch.ops.aten.mm.default(view_135, t_29);  view_135 = t_29 = None
    _unsafe_view_67 = torch.ops.aten._unsafe_view.default(mm_29, [1, 128, 6144]);  mm_29 = None
    mul_86 = torch.ops.aten.mul.Tensor(silu_9, _unsafe_view_67);  silu_9 = _unsafe_view_67 = None
    _param_constant53 = self._param_constant53
    t_30 = torch.ops.aten.t.default(_param_constant53);  _param_constant53 = None
    view_136 = torch.ops.aten.view.default(mul_86, [128, 6144]);  mul_86 = None
    mm_30 = torch.ops.aten.mm.default(view_136, t_30);  view_136 = t_30 = None
    _unsafe_view_68 = torch.ops.aten._unsafe_view.default(mm_30, [1, 128, 2048]);  mm_30 = None
    add_55 = torch.ops.aten.add.Tensor(add_52, _unsafe_view_68);  add_52 = _unsafe_view_68 = None
    _to_copy_66 = torch.ops.aten._to_copy.default(add_55, dtype = torch.float32)
    pow_14 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_66, 2)
    mean_13 = torch.ops.aten.mean.dim(pow_14, [-1], True);  pow_14 = None
    add_56 = torch.ops.aten.add.Tensor(mean_13, 1e-06);  mean_13 = None
    rsqrt_19 = torch.ops.aten.rsqrt.default(add_56);  add_56 = None
    mul_87 = torch.ops.aten.mul.Tensor(_to_copy_66, rsqrt_19);  _to_copy_66 = rsqrt_19 = None
    _param_constant54 = self._param_constant54
    _to_copy_67 = torch.ops.aten._to_copy.default(_param_constant54, dtype = torch.float32);  _param_constant54 = None
    add_57 = torch.ops.aten.add.Tensor(_to_copy_67, 1.0);  _to_copy_67 = None
    mul_88 = torch.ops.aten.mul.Tensor(mul_87, add_57);  mul_87 = add_57 = None
    _to_copy_68 = torch.ops.aten._to_copy.default(mul_88, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_88 = None
    _param_constant55 = self._param_constant55
    t_31 = torch.ops.aten.t.default(_param_constant55);  _param_constant55 = None
    view_137 = torch.ops.aten.view.default(_to_copy_68, [128, 2048])
    mm_31 = torch.ops.aten.mm.default(view_137, t_31);  view_137 = t_31 = None
    _unsafe_view_69 = torch.ops.aten._unsafe_view.default(mm_31, [1, 128, 6144]);  mm_31 = None
    transpose_41 = torch.ops.aten.transpose.int(_unsafe_view_69, 1, 2);  _unsafe_view_69 = None
    _param_constant56 = self._param_constant56
    t_32 = torch.ops.aten.t.default(_param_constant56);  _param_constant56 = None
    view_138 = torch.ops.aten.view.default(_to_copy_68, [128, 2048])
    mm_32 = torch.ops.aten.mm.default(view_138, t_32);  view_138 = t_32 = None
    _unsafe_view_70 = torch.ops.aten._unsafe_view.default(mm_32, [1, 128, 2048]);  mm_32 = None
    view_139 = torch.ops.aten.view.default(_unsafe_view_70, [1, 128, -1, 128]);  _unsafe_view_70 = None
    _param_constant57 = self._param_constant57
    t_33 = torch.ops.aten.t.default(_param_constant57);  _param_constant57 = None
    view_140 = torch.ops.aten.view.default(_to_copy_68, [128, 2048])
    mm_33 = torch.ops.aten.mm.default(view_140, t_33);  view_140 = t_33 = None
    _unsafe_view_71 = torch.ops.aten._unsafe_view.default(mm_33, [1, 128, 16]);  mm_33 = None
    _param_constant58 = self._param_constant58
    t_34 = torch.ops.aten.t.default(_param_constant58);  _param_constant58 = None
    view_141 = torch.ops.aten.view.default(_to_copy_68, [128, 2048]);  _to_copy_68 = None
    mm_34 = torch.ops.aten.mm.default(view_141, t_34);  view_141 = t_34 = None
    _unsafe_view_72 = torch.ops.aten._unsafe_view.default(mm_34, [1, 128, 16]);  mm_34 = None
    _param_constant59 = self._param_constant59
    squeeze_3 = torch.ops.aten.squeeze.dim(_param_constant59, 1);  _param_constant59 = None
    unsqueeze_37 = torch.ops.aten.unsqueeze.default(squeeze_3, 1);  squeeze_3 = None
    convolution_3 = torch.ops.aten.convolution.default(transpose_41, unsqueeze_37, None, [1], [3], [1], False, [0], 6144);  transpose_41 = unsqueeze_37 = None
    slice_24 = torch.ops.aten.slice.Tensor(convolution_3, 2, 0, 128);  convolution_3 = None
    silu_10 = torch.ops.aten.silu.default(slice_24);  slice_24 = None
    transpose_42 = torch.ops.aten.transpose.int(silu_10, 1, 2);  silu_10 = None
    split_with_sizes_3 = torch.ops.aten.split_with_sizes.default(transpose_42, [2048, 2048, 2048], -1);  transpose_42 = None
    getitem_11 = split_with_sizes_3[0]
    getitem_12 = split_with_sizes_3[1]
    getitem_13 = split_with_sizes_3[2];  split_with_sizes_3 = None
    view_142 = torch.ops.aten.view.default(getitem_11, [1, 128, 16, 128]);  getitem_11 = None
    view_143 = torch.ops.aten.view.default(getitem_12, [1, 128, 16, 128]);  getitem_12 = None
    view_144 = torch.ops.aten.view.default(getitem_13, [1, 128, 16, 128]);  getitem_13 = None
    sigmoid_4 = torch.ops.aten.sigmoid.default(_unsafe_view_71);  _unsafe_view_71 = None
    _param_constant60 = self._param_constant60
    exp_18 = torch.ops.aten.exp.default(_param_constant60);  _param_constant60 = None
    neg_5 = torch.ops.aten.neg.default(exp_18);  exp_18 = None
    _to_copy_69 = torch.ops.aten._to_copy.default(_unsafe_view_72, dtype = torch.float32);  _unsafe_view_72 = None
    _param_constant61 = self._param_constant61
    add_58 = torch.ops.aten.add.Tensor(_to_copy_69, _param_constant61);  _to_copy_69 = _param_constant61 = None
    softplus_3 = torch.ops.aten.softplus.default(add_58);  add_58 = None
    mul_89 = torch.ops.aten.mul.Tensor(neg_5, softplus_3);  neg_5 = softplus_3 = None
    transpose_43 = torch.ops.aten.transpose.int(view_142, 1, 2);  view_142 = None
    _to_copy_70 = torch.ops.aten._to_copy.default(transpose_43, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_43 = None
    transpose_44 = torch.ops.aten.transpose.int(view_143, 1, 2);  view_143 = None
    _to_copy_71 = torch.ops.aten._to_copy.default(transpose_44, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_44 = None
    transpose_45 = torch.ops.aten.transpose.int(view_144, 1, 2);  view_144 = None
    _to_copy_72 = torch.ops.aten._to_copy.default(transpose_45, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_45 = None
    transpose_46 = torch.ops.aten.transpose.int(sigmoid_4, 1, 2);  sigmoid_4 = None
    _to_copy_73 = torch.ops.aten._to_copy.default(transpose_46, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_46 = None
    transpose_47 = torch.ops.aten.transpose.int(mul_89, 1, 2);  mul_89 = None
    mul_90 = torch.ops.aten.mul.Tensor(_to_copy_70, _to_copy_70)
    sum_7 = torch.ops.aten.sum.dim_IntList(mul_90, [-1], True);  mul_90 = None
    add_59 = torch.ops.aten.add.Tensor(sum_7, 1e-06);  sum_7 = None
    rsqrt_20 = torch.ops.aten.rsqrt.default(add_59);  add_59 = None
    mul_91 = torch.ops.aten.mul.Tensor(_to_copy_70, rsqrt_20);  _to_copy_70 = rsqrt_20 = None
    mul_92 = torch.ops.aten.mul.Tensor(_to_copy_71, _to_copy_71)
    sum_8 = torch.ops.aten.sum.dim_IntList(mul_92, [-1], True);  mul_92 = None
    add_60 = torch.ops.aten.add.Tensor(sum_8, 1e-06);  sum_8 = None
    rsqrt_21 = torch.ops.aten.rsqrt.default(add_60);  add_60 = None
    mul_93 = torch.ops.aten.mul.Tensor(_to_copy_71, rsqrt_21);  _to_copy_71 = rsqrt_21 = None
    mul_94 = torch.ops.aten.mul.Tensor(mul_91, 0.08838834764831845);  mul_91 = None
    constant_pad_nd_15 = torch.ops.aten.constant_pad_nd.default(mul_94, [0, 0, 0, 0], 0.0);  mul_94 = None
    constant_pad_nd_16 = torch.ops.aten.constant_pad_nd.default(mul_93, [0, 0, 0, 0], 0.0);  mul_93 = None
    constant_pad_nd_17 = torch.ops.aten.constant_pad_nd.default(_to_copy_72, [0, 0, 0, 0], 0.0);  _to_copy_72 = None
    constant_pad_nd_18 = torch.ops.aten.constant_pad_nd.default(_to_copy_73, [0, 0], 0.0);  _to_copy_73 = None
    constant_pad_nd_19 = torch.ops.aten.constant_pad_nd.default(transpose_47, [0, 0], 0.0);  transpose_47 = None
    unsqueeze_38 = torch.ops.aten.unsqueeze.default(constant_pad_nd_18, -1)
    mul_95 = torch.ops.aten.mul.Tensor(constant_pad_nd_17, unsqueeze_38);  constant_pad_nd_17 = unsqueeze_38 = None
    unsqueeze_39 = torch.ops.aten.unsqueeze.default(constant_pad_nd_18, -1);  constant_pad_nd_18 = None
    mul_96 = torch.ops.aten.mul.Tensor(constant_pad_nd_16, unsqueeze_39);  unsqueeze_39 = None
    view_145 = torch.ops.aten.view.default(constant_pad_nd_15, [1, 16, -1, 64, 128]);  constant_pad_nd_15 = None
    view_146 = torch.ops.aten.view.default(constant_pad_nd_16, [1, 16, -1, 64, 128]);  constant_pad_nd_16 = None
    view_147 = torch.ops.aten.view.default(mul_96, [1, 16, -1, 64, 128]);  mul_96 = None
    view_148 = torch.ops.aten.view.default(mul_95, [1, 16, -1, 64, 128]);  mul_95 = None
    view_149 = torch.ops.aten.view.default(constant_pad_nd_19, [1, 16, 2, 64]);  constant_pad_nd_19 = None
    ones_3 = torch.ops.aten.ones.default([64, 64], dtype = torch.bool, device = device(type='meta'), pin_memory = False)
    triu_4 = torch.ops.aten.triu.default(ones_3, 1);  ones_3 = None
    cumsum_3 = torch.ops.aten.cumsum.default(view_149, 3);  view_149 = None
    unsqueeze_40 = torch.ops.aten.unsqueeze.default(cumsum_3, 4)
    unsqueeze_41 = torch.ops.aten.unsqueeze.default(cumsum_3, 3)
    sub_12 = torch.ops.aten.sub.Tensor(unsqueeze_40, unsqueeze_41);  unsqueeze_40 = unsqueeze_41 = None
    masked_fill_3 = torch.ops.aten.masked_fill.Scalar(sub_12, triu_4, -inf);  sub_12 = triu_4 = None
    exp_19 = torch.ops.aten.exp.default(masked_fill_3);  masked_fill_3 = None
    transpose_48 = torch.ops.aten.transpose.int(view_146, -1, -2)
    expand_68 = torch.ops.aten.expand.default(view_147, [1, 16, 2, 64, 128])
    view_150 = torch.ops.aten.view.default(expand_68, [32, 64, 128]);  expand_68 = None
    expand_69 = torch.ops.aten.expand.default(transpose_48, [1, 16, 2, 128, 64]);  transpose_48 = None
    view_151 = torch.ops.aten.view.default(expand_69, [32, 128, 64]);  expand_69 = None
    bmm_32 = torch.ops.aten.bmm.default(view_150, view_151);  view_150 = view_151 = None
    _unsafe_view_73 = torch.ops.aten._unsafe_view.default(bmm_32, [1, 16, 2, 64, 64]);  bmm_32 = None
    mul_97 = torch.ops.aten.mul.Tensor(_unsafe_view_73, exp_19);  _unsafe_view_73 = None
    transpose_49 = torch.ops.aten.transpose.int(view_146, -1, -2)
    expand_70 = torch.ops.aten.expand.default(view_145, [1, 16, 2, 64, 128])
    view_152 = torch.ops.aten.view.default(expand_70, [32, 64, 128]);  expand_70 = None
    expand_71 = torch.ops.aten.expand.default(transpose_49, [1, 16, 2, 128, 64]);  transpose_49 = None
    view_153 = torch.ops.aten.view.default(expand_71, [32, 128, 64]);  expand_71 = None
    bmm_33 = torch.ops.aten.bmm.default(view_152, view_153);  view_152 = view_153 = None
    _unsafe_view_74 = torch.ops.aten._unsafe_view.default(bmm_33, [1, 16, 2, 64, 64]);  bmm_33 = None
    mul_98 = torch.ops.aten.mul.Tensor(_unsafe_view_74, exp_19);  _unsafe_view_74 = exp_19 = None
    exp_20 = torch.ops.aten.exp.default(cumsum_3)
    unsqueeze_42 = torch.ops.aten.unsqueeze.default(exp_20, -1);  exp_20 = None
    mul_99 = torch.ops.aten.mul.Tensor(view_147, unsqueeze_42);  view_147 = unsqueeze_42 = None
    linalg_solve_triangular_6 = torch.ops.aten.linalg_solve_triangular.default(mul_97, view_148, upper = False, unitriangular = True);  view_148 = None
    linalg_solve_triangular_7 = torch.ops.aten.linalg_solve_triangular.default(mul_97, mul_99, upper = False, unitriangular = True);  mul_97 = mul_99 = None
    zeros_3 = torch.ops.aten.zeros.default([1, 16, 128, 128], dtype = torch.float32, device = device(type='meta'), pin_memory = False)
    zeros_like_3 = torch.ops.aten.zeros_like.default(linalg_solve_triangular_6, pin_memory = False)
    exp_21 = torch.ops.aten.exp.default(cumsum_3)
    unsqueeze_43 = torch.ops.aten.unsqueeze.default(exp_21, -1);  exp_21 = None
    mul_100 = torch.ops.aten.mul.Tensor(view_145, unsqueeze_43);  view_145 = unsqueeze_43 = None
    slice_25 = torch.ops.aten.slice.Tensor(cumsum_3, 3, -1, 9223372036854775807)
    sub_13 = torch.ops.aten.sub.Tensor(slice_25, cumsum_3);  slice_25 = None
    exp_22 = torch.ops.aten.exp.default(sub_13);  sub_13 = None
    unsqueeze_44 = torch.ops.aten.unsqueeze.default(exp_22, -1);  exp_22 = None
    mul_101 = torch.ops.aten.mul.Tensor(view_146, unsqueeze_44);  view_146 = unsqueeze_44 = None
    select_52 = torch.ops.aten.select.int(cumsum_3, 3, -1);  cumsum_3 = None
    exp_23 = torch.ops.aten.exp.default(select_52);  select_52 = None
    unsqueeze_45 = torch.ops.aten.unsqueeze.default(exp_23, 3);  exp_23 = None
    unsqueeze_46 = torch.ops.aten.unsqueeze.default(unsqueeze_45, 4);  unsqueeze_45 = None
    select_53 = torch.ops.aten.select.int(linalg_solve_triangular_6, 2, 0)
    select_54 = torch.ops.aten.select.int(linalg_solve_triangular_7, 2, 0)
    expand_72 = torch.ops.aten.expand.default(select_54, [1, 16, 64, 128]);  select_54 = None
    view_154 = torch.ops.aten.view.default(expand_72, [16, 64, 128]);  expand_72 = None
    expand_73 = torch.ops.aten.expand.default(zeros_3, [1, 16, 128, 128])
    view_155 = torch.ops.aten.view.default(expand_73, [16, 128, 128]);  expand_73 = None
    bmm_34 = torch.ops.aten.bmm.default(view_154, view_155);  view_154 = view_155 = None
    _unsafe_view_75 = torch.ops.aten._unsafe_view.default(bmm_34, [1, 16, 64, 128]);  bmm_34 = None
    sub_14 = torch.ops.aten.sub.Tensor(select_53, _unsafe_view_75);  select_53 = _unsafe_view_75 = None
    select_55 = torch.ops.aten.select.int(mul_100, 2, 0)
    expand_74 = torch.ops.aten.expand.default(select_55, [1, 16, 64, 128]);  select_55 = None
    view_156 = torch.ops.aten.view.default(expand_74, [16, 64, 128]);  expand_74 = None
    expand_75 = torch.ops.aten.expand.default(zeros_3, [1, 16, 128, 128])
    view_157 = torch.ops.aten.view.default(expand_75, [16, 128, 128]);  expand_75 = None
    bmm_35 = torch.ops.aten.bmm.default(view_156, view_157);  view_156 = view_157 = None
    _unsafe_view_76 = torch.ops.aten._unsafe_view.default(bmm_35, [1, 16, 64, 128]);  bmm_35 = None
    select_56 = torch.ops.aten.select.int(mul_98, 2, 0)
    expand_76 = torch.ops.aten.expand.default(select_56, [1, 16, 64, 64]);  select_56 = None
    view_158 = torch.ops.aten.view.default(expand_76, [16, 64, 64]);  expand_76 = None
    expand_77 = torch.ops.aten.expand.default(sub_14, [1, 16, 64, 128])
    view_159 = torch.ops.aten.view.default(expand_77, [16, 64, 128]);  expand_77 = None
    bmm_36 = torch.ops.aten.bmm.default(view_158, view_159);  view_158 = view_159 = None
    _unsafe_view_77 = torch.ops.aten._unsafe_view.default(bmm_36, [1, 16, 64, 128]);  bmm_36 = None
    add_61 = torch.ops.aten.add.Tensor(_unsafe_view_76, _unsafe_view_77);  _unsafe_view_76 = _unsafe_view_77 = None
    select_57 = torch.ops.aten.select.int(zeros_like_3, 2, 0)
    copy__10 = torch.ops.aten.copy_.default(select_57, add_61);  select_57 = add_61 = copy__10 = None
    select_58 = torch.ops.aten.select.int(unsqueeze_46, 2, 0)
    mul_102 = torch.ops.aten.mul.Tensor(zeros_3, select_58);  zeros_3 = select_58 = None
    select_59 = torch.ops.aten.select.int(mul_101, 2, 0)
    transpose_50 = torch.ops.aten.transpose.int(select_59, -1, -2);  select_59 = None
    expand_78 = torch.ops.aten.expand.default(transpose_50, [1, 16, 128, 64]);  transpose_50 = None
    view_160 = torch.ops.aten.view.default(expand_78, [16, 128, 64]);  expand_78 = None
    expand_79 = torch.ops.aten.expand.default(sub_14, [1, 16, 64, 128]);  sub_14 = None
    view_161 = torch.ops.aten.view.default(expand_79, [16, 64, 128]);  expand_79 = None
    bmm_37 = torch.ops.aten.bmm.default(view_160, view_161);  view_160 = view_161 = None
    _unsafe_view_78 = torch.ops.aten._unsafe_view.default(bmm_37, [1, 16, 128, 128]);  bmm_37 = None
    add_62 = torch.ops.aten.add.Tensor(mul_102, _unsafe_view_78);  mul_102 = _unsafe_view_78 = None
    select_60 = torch.ops.aten.select.int(linalg_solve_triangular_6, 2, 1);  linalg_solve_triangular_6 = None
    select_61 = torch.ops.aten.select.int(linalg_solve_triangular_7, 2, 1);  linalg_solve_triangular_7 = None
    expand_80 = torch.ops.aten.expand.default(select_61, [1, 16, 64, 128]);  select_61 = None
    view_162 = torch.ops.aten.view.default(expand_80, [16, 64, 128]);  expand_80 = None
    expand_81 = torch.ops.aten.expand.default(add_62, [1, 16, 128, 128])
    view_163 = torch.ops.aten.view.default(expand_81, [16, 128, 128]);  expand_81 = None
    bmm_38 = torch.ops.aten.bmm.default(view_162, view_163);  view_162 = view_163 = None
    _unsafe_view_79 = torch.ops.aten._unsafe_view.default(bmm_38, [1, 16, 64, 128]);  bmm_38 = None
    sub_15 = torch.ops.aten.sub.Tensor(select_60, _unsafe_view_79);  select_60 = _unsafe_view_79 = None
    select_62 = torch.ops.aten.select.int(mul_100, 2, 1);  mul_100 = None
    expand_82 = torch.ops.aten.expand.default(select_62, [1, 16, 64, 128]);  select_62 = None
    view_164 = torch.ops.aten.view.default(expand_82, [16, 64, 128]);  expand_82 = None
    expand_83 = torch.ops.aten.expand.default(add_62, [1, 16, 128, 128])
    view_165 = torch.ops.aten.view.default(expand_83, [16, 128, 128]);  expand_83 = None
    bmm_39 = torch.ops.aten.bmm.default(view_164, view_165);  view_164 = view_165 = None
    _unsafe_view_80 = torch.ops.aten._unsafe_view.default(bmm_39, [1, 16, 64, 128]);  bmm_39 = None
    select_63 = torch.ops.aten.select.int(mul_98, 2, 1);  mul_98 = None
    expand_84 = torch.ops.aten.expand.default(select_63, [1, 16, 64, 64]);  select_63 = None
    view_166 = torch.ops.aten.view.default(expand_84, [16, 64, 64]);  expand_84 = None
    expand_85 = torch.ops.aten.expand.default(sub_15, [1, 16, 64, 128])
    view_167 = torch.ops.aten.view.default(expand_85, [16, 64, 128]);  expand_85 = None
    bmm_40 = torch.ops.aten.bmm.default(view_166, view_167);  view_166 = view_167 = None
    _unsafe_view_81 = torch.ops.aten._unsafe_view.default(bmm_40, [1, 16, 64, 128]);  bmm_40 = None
    add_63 = torch.ops.aten.add.Tensor(_unsafe_view_80, _unsafe_view_81);  _unsafe_view_80 = _unsafe_view_81 = None
    select_64 = torch.ops.aten.select.int(zeros_like_3, 2, 1)
    copy__11 = torch.ops.aten.copy_.default(select_64, add_63);  select_64 = add_63 = copy__11 = None
    select_65 = torch.ops.aten.select.int(unsqueeze_46, 2, 1);  unsqueeze_46 = None
    mul_103 = torch.ops.aten.mul.Tensor(add_62, select_65);  add_62 = select_65 = None
    select_66 = torch.ops.aten.select.int(mul_101, 2, 1);  mul_101 = None
    transpose_51 = torch.ops.aten.transpose.int(select_66, -1, -2);  select_66 = None
    expand_86 = torch.ops.aten.expand.default(transpose_51, [1, 16, 128, 64]);  transpose_51 = None
    view_168 = torch.ops.aten.view.default(expand_86, [16, 128, 64]);  expand_86 = None
    expand_87 = torch.ops.aten.expand.default(sub_15, [1, 16, 64, 128]);  sub_15 = None
    view_169 = torch.ops.aten.view.default(expand_87, [16, 64, 128]);  expand_87 = None
    bmm_41 = torch.ops.aten.bmm.default(view_168, view_169);  view_168 = view_169 = None
    _unsafe_view_82 = torch.ops.aten._unsafe_view.default(bmm_41, [1, 16, 128, 128]);  bmm_41 = None
    add_64 = torch.ops.aten.add.Tensor(mul_103, _unsafe_view_82);  mul_103 = _unsafe_view_82 = add_64 = None
    clone_7 = torch.ops.aten.clone.default(zeros_like_3, memory_format = torch.contiguous_format);  zeros_like_3 = None
    _unsafe_view_83 = torch.ops.aten._unsafe_view.default(clone_7, [1, 16, 128, 128]);  clone_7 = None
    alias_3 = torch.ops.aten.alias.default(_unsafe_view_83);  _unsafe_view_83 = None
    transpose_52 = torch.ops.aten.transpose.int(alias_3, 1, 2);  alias_3 = None
    _to_copy_74 = torch.ops.aten._to_copy.default(transpose_52, dtype = torch.bfloat16, memory_format = torch.contiguous_format);  transpose_52 = None
    view_170 = torch.ops.aten.view.default(_to_copy_74, [-1, 128]);  _to_copy_74 = None
    view_171 = torch.ops.aten.view.default(view_139, [-1, 128]);  view_139 = None
    _to_copy_75 = torch.ops.aten._to_copy.default(view_170, dtype = torch.float32);  view_170 = None
    pow_15 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_75, 2)
    mean_14 = torch.ops.aten.mean.dim(pow_15, [-1], True);  pow_15 = None
    add_65 = torch.ops.aten.add.Tensor(mean_14, 1e-06);  mean_14 = None
    rsqrt_22 = torch.ops.aten.rsqrt.default(add_65);  add_65 = None
    mul_104 = torch.ops.aten.mul.Tensor(_to_copy_75, rsqrt_22);  _to_copy_75 = rsqrt_22 = None
    _to_copy_76 = torch.ops.aten._to_copy.default(mul_104, dtype = torch.bfloat16);  mul_104 = None
    _param_constant62 = self._param_constant62
    mul_105 = torch.ops.aten.mul.Tensor(_param_constant62, _to_copy_76);  _param_constant62 = _to_copy_76 = None
    _to_copy_77 = torch.ops.aten._to_copy.default(view_171, dtype = torch.float32);  view_171 = None
    silu_11 = torch.ops.aten.silu.default(_to_copy_77);  _to_copy_77 = None
    mul_106 = torch.ops.aten.mul.Tensor(mul_105, silu_11);  mul_105 = silu_11 = None
    _to_copy_78 = torch.ops.aten._to_copy.default(mul_106, dtype = torch.bfloat16);  mul_106 = None
    view_172 = torch.ops.aten.view.default(_to_copy_78, [1, 128, -1]);  _to_copy_78 = None
    _param_constant63 = self._param_constant63
    t_35 = torch.ops.aten.t.default(_param_constant63);  _param_constant63 = None
    view_173 = torch.ops.aten.view.default(view_172, [128, 2048]);  view_172 = None
    mm_35 = torch.ops.aten.mm.default(view_173, t_35);  view_173 = t_35 = None
    _unsafe_view_84 = torch.ops.aten._unsafe_view.default(mm_35, [1, 128, 2048]);  mm_35 = None
    add_66 = torch.ops.aten.add.Tensor(add_55, _unsafe_view_84);  add_55 = _unsafe_view_84 = None
    _to_copy_79 = torch.ops.aten._to_copy.default(add_66, dtype = torch.float32)
    pow_16 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_79, 2)
    mean_15 = torch.ops.aten.mean.dim(pow_16, [-1], True);  pow_16 = None
    add_67 = torch.ops.aten.add.Tensor(mean_15, 1e-06);  mean_15 = None
    rsqrt_23 = torch.ops.aten.rsqrt.default(add_67);  add_67 = None
    mul_107 = torch.ops.aten.mul.Tensor(_to_copy_79, rsqrt_23);  _to_copy_79 = rsqrt_23 = None
    _param_constant64 = self._param_constant64
    _to_copy_80 = torch.ops.aten._to_copy.default(_param_constant64, dtype = torch.float32);  _param_constant64 = None
    add_68 = torch.ops.aten.add.Tensor(_to_copy_80, 1.0);  _to_copy_80 = None
    mul_108 = torch.ops.aten.mul.Tensor(mul_107, add_68);  mul_107 = add_68 = None
    _to_copy_81 = torch.ops.aten._to_copy.default(mul_108, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_108 = None
    _param_constant65 = self._param_constant65
    t_36 = torch.ops.aten.t.default(_param_constant65);  _param_constant65 = None
    view_174 = torch.ops.aten.view.default(_to_copy_81, [128, 2048])
    mm_36 = torch.ops.aten.mm.default(view_174, t_36);  view_174 = t_36 = None
    _unsafe_view_85 = torch.ops.aten._unsafe_view.default(mm_36, [1, 128, 6144]);  mm_36 = None
    silu_12 = torch.ops.aten.silu.default(_unsafe_view_85);  _unsafe_view_85 = None
    _param_constant66 = self._param_constant66
    t_37 = torch.ops.aten.t.default(_param_constant66);  _param_constant66 = None
    view_175 = torch.ops.aten.view.default(_to_copy_81, [128, 2048]);  _to_copy_81 = None
    mm_37 = torch.ops.aten.mm.default(view_175, t_37);  view_175 = t_37 = None
    _unsafe_view_86 = torch.ops.aten._unsafe_view.default(mm_37, [1, 128, 6144]);  mm_37 = None
    mul_109 = torch.ops.aten.mul.Tensor(silu_12, _unsafe_view_86);  silu_12 = _unsafe_view_86 = None
    _param_constant67 = self._param_constant67
    t_38 = torch.ops.aten.t.default(_param_constant67);  _param_constant67 = None
    view_176 = torch.ops.aten.view.default(mul_109, [128, 6144]);  mul_109 = None
    mm_38 = torch.ops.aten.mm.default(view_176, t_38);  view_176 = t_38 = None
    _unsafe_view_87 = torch.ops.aten._unsafe_view.default(mm_38, [1, 128, 2048]);  mm_38 = None
    add_69 = torch.ops.aten.add.Tensor(add_66, _unsafe_view_87);  add_66 = _unsafe_view_87 = None
    _to_copy_82 = torch.ops.aten._to_copy.default(add_69, dtype = torch.float32)
    pow_17 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_82, 2)
    mean_16 = torch.ops.aten.mean.dim(pow_17, [-1], True);  pow_17 = None
    add_70 = torch.ops.aten.add.Tensor(mean_16, 1e-06);  mean_16 = None
    rsqrt_24 = torch.ops.aten.rsqrt.default(add_70);  add_70 = None
    mul_110 = torch.ops.aten.mul.Tensor(_to_copy_82, rsqrt_24);  _to_copy_82 = rsqrt_24 = None
    _param_constant68 = self._param_constant68
    _to_copy_83 = torch.ops.aten._to_copy.default(_param_constant68, dtype = torch.float32);  _param_constant68 = None
    add_71 = torch.ops.aten.add.Tensor(_to_copy_83, 1.0);  _to_copy_83 = None
    mul_111 = torch.ops.aten.mul.Tensor(mul_110, add_71);  mul_110 = add_71 = None
    _to_copy_84 = torch.ops.aten._to_copy.default(mul_111, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_111 = None
    _param_constant69 = self._param_constant69
    t_39 = torch.ops.aten.t.default(_param_constant69);  _param_constant69 = None
    view_177 = torch.ops.aten.view.default(_to_copy_84, [128, 2048])
    mm_39 = torch.ops.aten.mm.default(view_177, t_39);  view_177 = t_39 = None
    _unsafe_view_88 = torch.ops.aten._unsafe_view.default(mm_39, [1, 128, 6144]);  mm_39 = None
    transpose_53 = torch.ops.aten.transpose.int(_unsafe_view_88, 1, 2);  _unsafe_view_88 = None
    _param_constant70 = self._param_constant70
    t_40 = torch.ops.aten.t.default(_param_constant70);  _param_constant70 = None
    view_178 = torch.ops.aten.view.default(_to_copy_84, [128, 2048])
    mm_40 = torch.ops.aten.mm.default(view_178, t_40);  view_178 = t_40 = None
    _unsafe_view_89 = torch.ops.aten._unsafe_view.default(mm_40, [1, 128, 2048]);  mm_40 = None
    view_179 = torch.ops.aten.view.default(_unsafe_view_89, [1, 128, -1, 128]);  _unsafe_view_89 = None
    _param_constant71 = self._param_constant71
    t_41 = torch.ops.aten.t.default(_param_constant71);  _param_constant71 = None
    view_180 = torch.ops.aten.view.default(_to_copy_84, [128, 2048])
    mm_41 = torch.ops.aten.mm.default(view_180, t_41);  view_180 = t_41 = None
    _unsafe_view_90 = torch.ops.aten._unsafe_view.default(mm_41, [1, 128, 16]);  mm_41 = None
    _param_constant72 = self._param_constant72
    t_42 = torch.ops.aten.t.default(_param_constant72);  _param_constant72 = None
    view_181 = torch.ops.aten.view.default(_to_copy_84, [128, 2048]);  _to_copy_84 = None
    mm_42 = torch.ops.aten.mm.default(view_181, t_42);  view_181 = t_42 = None
    _unsafe_view_91 = torch.ops.aten._unsafe_view.default(mm_42, [1, 128, 16]);  mm_42 = None
    _param_constant73 = self._param_constant73
    squeeze_4 = torch.ops.aten.squeeze.dim(_param_constant73, 1);  _param_constant73 = None
    unsqueeze_47 = torch.ops.aten.unsqueeze.default(squeeze_4, 1);  squeeze_4 = None
    convolution_4 = torch.ops.aten.convolution.default(transpose_53, unsqueeze_47, None, [1], [3], [1], False, [0], 6144);  transpose_53 = unsqueeze_47 = None
    slice_26 = torch.ops.aten.slice.Tensor(convolution_4, 2, 0, 128);  convolution_4 = None
    silu_13 = torch.ops.aten.silu.default(slice_26);  slice_26 = None
    transpose_54 = torch.ops.aten.transpose.int(silu_13, 1, 2);  silu_13 = None
    split_with_sizes_4 = torch.ops.aten.split_with_sizes.default(transpose_54, [2048, 2048, 2048], -1);  transpose_54 = None
    getitem_14 = split_with_sizes_4[0]
    getitem_15 = split_with_sizes_4[1]
    getitem_16 = split_with_sizes_4[2];  split_with_sizes_4 = None
    view_182 = torch.ops.aten.view.default(getitem_14, [1, 128, 16, 128]);  getitem_14 = None
    view_183 = torch.ops.aten.view.default(getitem_15, [1, 128, 16, 128]);  getitem_15 = None
    view_184 = torch.ops.aten.view.default(getitem_16, [1, 128, 16, 128]);  getitem_16 = None
    sigmoid_5 = torch.ops.aten.sigmoid.default(_unsafe_view_90);  _unsafe_view_90 = None
    _param_constant74 = self._param_constant74
    exp_24 = torch.ops.aten.exp.default(_param_constant74);  _param_constant74 = None
    neg_6 = torch.ops.aten.neg.default(exp_24);  exp_24 = None
    _to_copy_85 = torch.ops.aten._to_copy.default(_unsafe_view_91, dtype = torch.float32);  _unsafe_view_91 = None
    _param_constant75 = self._param_constant75
    add_72 = torch.ops.aten.add.Tensor(_to_copy_85, _param_constant75);  _to_copy_85 = _param_constant75 = None
    softplus_4 = torch.ops.aten.softplus.default(add_72);  add_72 = None
    mul_112 = torch.ops.aten.mul.Tensor(neg_6, softplus_4);  neg_6 = softplus_4 = None
    transpose_55 = torch.ops.aten.transpose.int(view_182, 1, 2);  view_182 = None
    _to_copy_86 = torch.ops.aten._to_copy.default(transpose_55, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_55 = None
    transpose_56 = torch.ops.aten.transpose.int(view_183, 1, 2);  view_183 = None
    _to_copy_87 = torch.ops.aten._to_copy.default(transpose_56, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_56 = None
    transpose_57 = torch.ops.aten.transpose.int(view_184, 1, 2);  view_184 = None
    _to_copy_88 = torch.ops.aten._to_copy.default(transpose_57, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_57 = None
    transpose_58 = torch.ops.aten.transpose.int(sigmoid_5, 1, 2);  sigmoid_5 = None
    _to_copy_89 = torch.ops.aten._to_copy.default(transpose_58, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_58 = None
    transpose_59 = torch.ops.aten.transpose.int(mul_112, 1, 2);  mul_112 = None
    mul_113 = torch.ops.aten.mul.Tensor(_to_copy_86, _to_copy_86)
    sum_9 = torch.ops.aten.sum.dim_IntList(mul_113, [-1], True);  mul_113 = None
    add_73 = torch.ops.aten.add.Tensor(sum_9, 1e-06);  sum_9 = None
    rsqrt_25 = torch.ops.aten.rsqrt.default(add_73);  add_73 = None
    mul_114 = torch.ops.aten.mul.Tensor(_to_copy_86, rsqrt_25);  _to_copy_86 = rsqrt_25 = None
    mul_115 = torch.ops.aten.mul.Tensor(_to_copy_87, _to_copy_87)
    sum_10 = torch.ops.aten.sum.dim_IntList(mul_115, [-1], True);  mul_115 = None
    add_74 = torch.ops.aten.add.Tensor(sum_10, 1e-06);  sum_10 = None
    rsqrt_26 = torch.ops.aten.rsqrt.default(add_74);  add_74 = None
    mul_116 = torch.ops.aten.mul.Tensor(_to_copy_87, rsqrt_26);  _to_copy_87 = rsqrt_26 = None
    mul_117 = torch.ops.aten.mul.Tensor(mul_114, 0.08838834764831845);  mul_114 = None
    constant_pad_nd_20 = torch.ops.aten.constant_pad_nd.default(mul_117, [0, 0, 0, 0], 0.0);  mul_117 = None
    constant_pad_nd_21 = torch.ops.aten.constant_pad_nd.default(mul_116, [0, 0, 0, 0], 0.0);  mul_116 = None
    constant_pad_nd_22 = torch.ops.aten.constant_pad_nd.default(_to_copy_88, [0, 0, 0, 0], 0.0);  _to_copy_88 = None
    constant_pad_nd_23 = torch.ops.aten.constant_pad_nd.default(_to_copy_89, [0, 0], 0.0);  _to_copy_89 = None
    constant_pad_nd_24 = torch.ops.aten.constant_pad_nd.default(transpose_59, [0, 0], 0.0);  transpose_59 = None
    unsqueeze_48 = torch.ops.aten.unsqueeze.default(constant_pad_nd_23, -1)
    mul_118 = torch.ops.aten.mul.Tensor(constant_pad_nd_22, unsqueeze_48);  constant_pad_nd_22 = unsqueeze_48 = None
    unsqueeze_49 = torch.ops.aten.unsqueeze.default(constant_pad_nd_23, -1);  constant_pad_nd_23 = None
    mul_119 = torch.ops.aten.mul.Tensor(constant_pad_nd_21, unsqueeze_49);  unsqueeze_49 = None
    view_185 = torch.ops.aten.view.default(constant_pad_nd_20, [1, 16, -1, 64, 128]);  constant_pad_nd_20 = None
    view_186 = torch.ops.aten.view.default(constant_pad_nd_21, [1, 16, -1, 64, 128]);  constant_pad_nd_21 = None
    view_187 = torch.ops.aten.view.default(mul_119, [1, 16, -1, 64, 128]);  mul_119 = None
    view_188 = torch.ops.aten.view.default(mul_118, [1, 16, -1, 64, 128]);  mul_118 = None
    view_189 = torch.ops.aten.view.default(constant_pad_nd_24, [1, 16, 2, 64]);  constant_pad_nd_24 = None
    ones_4 = torch.ops.aten.ones.default([64, 64], dtype = torch.bool, device = device(type='meta'), pin_memory = False)
    triu_5 = torch.ops.aten.triu.default(ones_4, 1);  ones_4 = None
    cumsum_4 = torch.ops.aten.cumsum.default(view_189, 3);  view_189 = None
    unsqueeze_50 = torch.ops.aten.unsqueeze.default(cumsum_4, 4)
    unsqueeze_51 = torch.ops.aten.unsqueeze.default(cumsum_4, 3)
    sub_16 = torch.ops.aten.sub.Tensor(unsqueeze_50, unsqueeze_51);  unsqueeze_50 = unsqueeze_51 = None
    masked_fill_4 = torch.ops.aten.masked_fill.Scalar(sub_16, triu_5, -inf);  sub_16 = triu_5 = None
    exp_25 = torch.ops.aten.exp.default(masked_fill_4);  masked_fill_4 = None
    transpose_60 = torch.ops.aten.transpose.int(view_186, -1, -2)
    expand_88 = torch.ops.aten.expand.default(view_187, [1, 16, 2, 64, 128])
    view_190 = torch.ops.aten.view.default(expand_88, [32, 64, 128]);  expand_88 = None
    expand_89 = torch.ops.aten.expand.default(transpose_60, [1, 16, 2, 128, 64]);  transpose_60 = None
    view_191 = torch.ops.aten.view.default(expand_89, [32, 128, 64]);  expand_89 = None
    bmm_42 = torch.ops.aten.bmm.default(view_190, view_191);  view_190 = view_191 = None
    _unsafe_view_92 = torch.ops.aten._unsafe_view.default(bmm_42, [1, 16, 2, 64, 64]);  bmm_42 = None
    mul_120 = torch.ops.aten.mul.Tensor(_unsafe_view_92, exp_25);  _unsafe_view_92 = None
    transpose_61 = torch.ops.aten.transpose.int(view_186, -1, -2)
    expand_90 = torch.ops.aten.expand.default(view_185, [1, 16, 2, 64, 128])
    view_192 = torch.ops.aten.view.default(expand_90, [32, 64, 128]);  expand_90 = None
    expand_91 = torch.ops.aten.expand.default(transpose_61, [1, 16, 2, 128, 64]);  transpose_61 = None
    view_193 = torch.ops.aten.view.default(expand_91, [32, 128, 64]);  expand_91 = None
    bmm_43 = torch.ops.aten.bmm.default(view_192, view_193);  view_192 = view_193 = None
    _unsafe_view_93 = torch.ops.aten._unsafe_view.default(bmm_43, [1, 16, 2, 64, 64]);  bmm_43 = None
    mul_121 = torch.ops.aten.mul.Tensor(_unsafe_view_93, exp_25);  _unsafe_view_93 = exp_25 = None
    exp_26 = torch.ops.aten.exp.default(cumsum_4)
    unsqueeze_52 = torch.ops.aten.unsqueeze.default(exp_26, -1);  exp_26 = None
    mul_122 = torch.ops.aten.mul.Tensor(view_187, unsqueeze_52);  view_187 = unsqueeze_52 = None
    linalg_solve_triangular_8 = torch.ops.aten.linalg_solve_triangular.default(mul_120, view_188, upper = False, unitriangular = True);  view_188 = None
    linalg_solve_triangular_9 = torch.ops.aten.linalg_solve_triangular.default(mul_120, mul_122, upper = False, unitriangular = True);  mul_120 = mul_122 = None
    zeros_4 = torch.ops.aten.zeros.default([1, 16, 128, 128], dtype = torch.float32, device = device(type='meta'), pin_memory = False)
    zeros_like_4 = torch.ops.aten.zeros_like.default(linalg_solve_triangular_8, pin_memory = False)
    exp_27 = torch.ops.aten.exp.default(cumsum_4)
    unsqueeze_53 = torch.ops.aten.unsqueeze.default(exp_27, -1);  exp_27 = None
    mul_123 = torch.ops.aten.mul.Tensor(view_185, unsqueeze_53);  view_185 = unsqueeze_53 = None
    slice_27 = torch.ops.aten.slice.Tensor(cumsum_4, 3, -1, 9223372036854775807)
    sub_17 = torch.ops.aten.sub.Tensor(slice_27, cumsum_4);  slice_27 = None
    exp_28 = torch.ops.aten.exp.default(sub_17);  sub_17 = None
    unsqueeze_54 = torch.ops.aten.unsqueeze.default(exp_28, -1);  exp_28 = None
    mul_124 = torch.ops.aten.mul.Tensor(view_186, unsqueeze_54);  view_186 = unsqueeze_54 = None
    select_67 = torch.ops.aten.select.int(cumsum_4, 3, -1);  cumsum_4 = None
    exp_29 = torch.ops.aten.exp.default(select_67);  select_67 = None
    unsqueeze_55 = torch.ops.aten.unsqueeze.default(exp_29, 3);  exp_29 = None
    unsqueeze_56 = torch.ops.aten.unsqueeze.default(unsqueeze_55, 4);  unsqueeze_55 = None
    select_68 = torch.ops.aten.select.int(linalg_solve_triangular_8, 2, 0)
    select_69 = torch.ops.aten.select.int(linalg_solve_triangular_9, 2, 0)
    expand_92 = torch.ops.aten.expand.default(select_69, [1, 16, 64, 128]);  select_69 = None
    view_194 = torch.ops.aten.view.default(expand_92, [16, 64, 128]);  expand_92 = None
    expand_93 = torch.ops.aten.expand.default(zeros_4, [1, 16, 128, 128])
    view_195 = torch.ops.aten.view.default(expand_93, [16, 128, 128]);  expand_93 = None
    bmm_44 = torch.ops.aten.bmm.default(view_194, view_195);  view_194 = view_195 = None
    _unsafe_view_94 = torch.ops.aten._unsafe_view.default(bmm_44, [1, 16, 64, 128]);  bmm_44 = None
    sub_18 = torch.ops.aten.sub.Tensor(select_68, _unsafe_view_94);  select_68 = _unsafe_view_94 = None
    select_70 = torch.ops.aten.select.int(mul_123, 2, 0)
    expand_94 = torch.ops.aten.expand.default(select_70, [1, 16, 64, 128]);  select_70 = None
    view_196 = torch.ops.aten.view.default(expand_94, [16, 64, 128]);  expand_94 = None
    expand_95 = torch.ops.aten.expand.default(zeros_4, [1, 16, 128, 128])
    view_197 = torch.ops.aten.view.default(expand_95, [16, 128, 128]);  expand_95 = None
    bmm_45 = torch.ops.aten.bmm.default(view_196, view_197);  view_196 = view_197 = None
    _unsafe_view_95 = torch.ops.aten._unsafe_view.default(bmm_45, [1, 16, 64, 128]);  bmm_45 = None
    select_71 = torch.ops.aten.select.int(mul_121, 2, 0)
    expand_96 = torch.ops.aten.expand.default(select_71, [1, 16, 64, 64]);  select_71 = None
    view_198 = torch.ops.aten.view.default(expand_96, [16, 64, 64]);  expand_96 = None
    expand_97 = torch.ops.aten.expand.default(sub_18, [1, 16, 64, 128])
    view_199 = torch.ops.aten.view.default(expand_97, [16, 64, 128]);  expand_97 = None
    bmm_46 = torch.ops.aten.bmm.default(view_198, view_199);  view_198 = view_199 = None
    _unsafe_view_96 = torch.ops.aten._unsafe_view.default(bmm_46, [1, 16, 64, 128]);  bmm_46 = None
    add_75 = torch.ops.aten.add.Tensor(_unsafe_view_95, _unsafe_view_96);  _unsafe_view_95 = _unsafe_view_96 = None
    select_72 = torch.ops.aten.select.int(zeros_like_4, 2, 0)
    copy__12 = torch.ops.aten.copy_.default(select_72, add_75);  select_72 = add_75 = copy__12 = None
    select_73 = torch.ops.aten.select.int(unsqueeze_56, 2, 0)
    mul_125 = torch.ops.aten.mul.Tensor(zeros_4, select_73);  zeros_4 = select_73 = None
    select_74 = torch.ops.aten.select.int(mul_124, 2, 0)
    transpose_62 = torch.ops.aten.transpose.int(select_74, -1, -2);  select_74 = None
    expand_98 = torch.ops.aten.expand.default(transpose_62, [1, 16, 128, 64]);  transpose_62 = None
    view_200 = torch.ops.aten.view.default(expand_98, [16, 128, 64]);  expand_98 = None
    expand_99 = torch.ops.aten.expand.default(sub_18, [1, 16, 64, 128]);  sub_18 = None
    view_201 = torch.ops.aten.view.default(expand_99, [16, 64, 128]);  expand_99 = None
    bmm_47 = torch.ops.aten.bmm.default(view_200, view_201);  view_200 = view_201 = None
    _unsafe_view_97 = torch.ops.aten._unsafe_view.default(bmm_47, [1, 16, 128, 128]);  bmm_47 = None
    add_76 = torch.ops.aten.add.Tensor(mul_125, _unsafe_view_97);  mul_125 = _unsafe_view_97 = None
    select_75 = torch.ops.aten.select.int(linalg_solve_triangular_8, 2, 1);  linalg_solve_triangular_8 = None
    select_76 = torch.ops.aten.select.int(linalg_solve_triangular_9, 2, 1);  linalg_solve_triangular_9 = None
    expand_100 = torch.ops.aten.expand.default(select_76, [1, 16, 64, 128]);  select_76 = None
    view_202 = torch.ops.aten.view.default(expand_100, [16, 64, 128]);  expand_100 = None
    expand_101 = torch.ops.aten.expand.default(add_76, [1, 16, 128, 128])
    view_203 = torch.ops.aten.view.default(expand_101, [16, 128, 128]);  expand_101 = None
    bmm_48 = torch.ops.aten.bmm.default(view_202, view_203);  view_202 = view_203 = None
    _unsafe_view_98 = torch.ops.aten._unsafe_view.default(bmm_48, [1, 16, 64, 128]);  bmm_48 = None
    sub_19 = torch.ops.aten.sub.Tensor(select_75, _unsafe_view_98);  select_75 = _unsafe_view_98 = None
    select_77 = torch.ops.aten.select.int(mul_123, 2, 1);  mul_123 = None
    expand_102 = torch.ops.aten.expand.default(select_77, [1, 16, 64, 128]);  select_77 = None
    view_204 = torch.ops.aten.view.default(expand_102, [16, 64, 128]);  expand_102 = None
    expand_103 = torch.ops.aten.expand.default(add_76, [1, 16, 128, 128])
    view_205 = torch.ops.aten.view.default(expand_103, [16, 128, 128]);  expand_103 = None
    bmm_49 = torch.ops.aten.bmm.default(view_204, view_205);  view_204 = view_205 = None
    _unsafe_view_99 = torch.ops.aten._unsafe_view.default(bmm_49, [1, 16, 64, 128]);  bmm_49 = None
    select_78 = torch.ops.aten.select.int(mul_121, 2, 1);  mul_121 = None
    expand_104 = torch.ops.aten.expand.default(select_78, [1, 16, 64, 64]);  select_78 = None
    view_206 = torch.ops.aten.view.default(expand_104, [16, 64, 64]);  expand_104 = None
    expand_105 = torch.ops.aten.expand.default(sub_19, [1, 16, 64, 128])
    view_207 = torch.ops.aten.view.default(expand_105, [16, 64, 128]);  expand_105 = None
    bmm_50 = torch.ops.aten.bmm.default(view_206, view_207);  view_206 = view_207 = None
    _unsafe_view_100 = torch.ops.aten._unsafe_view.default(bmm_50, [1, 16, 64, 128]);  bmm_50 = None
    add_77 = torch.ops.aten.add.Tensor(_unsafe_view_99, _unsafe_view_100);  _unsafe_view_99 = _unsafe_view_100 = None
    select_79 = torch.ops.aten.select.int(zeros_like_4, 2, 1)
    copy__13 = torch.ops.aten.copy_.default(select_79, add_77);  select_79 = add_77 = copy__13 = None
    select_80 = torch.ops.aten.select.int(unsqueeze_56, 2, 1);  unsqueeze_56 = None
    mul_126 = torch.ops.aten.mul.Tensor(add_76, select_80);  add_76 = select_80 = None
    select_81 = torch.ops.aten.select.int(mul_124, 2, 1);  mul_124 = None
    transpose_63 = torch.ops.aten.transpose.int(select_81, -1, -2);  select_81 = None
    expand_106 = torch.ops.aten.expand.default(transpose_63, [1, 16, 128, 64]);  transpose_63 = None
    view_208 = torch.ops.aten.view.default(expand_106, [16, 128, 64]);  expand_106 = None
    expand_107 = torch.ops.aten.expand.default(sub_19, [1, 16, 64, 128]);  sub_19 = None
    view_209 = torch.ops.aten.view.default(expand_107, [16, 64, 128]);  expand_107 = None
    bmm_51 = torch.ops.aten.bmm.default(view_208, view_209);  view_208 = view_209 = None
    _unsafe_view_101 = torch.ops.aten._unsafe_view.default(bmm_51, [1, 16, 128, 128]);  bmm_51 = None
    add_78 = torch.ops.aten.add.Tensor(mul_126, _unsafe_view_101);  mul_126 = _unsafe_view_101 = add_78 = None
    clone_8 = torch.ops.aten.clone.default(zeros_like_4, memory_format = torch.contiguous_format);  zeros_like_4 = None
    _unsafe_view_102 = torch.ops.aten._unsafe_view.default(clone_8, [1, 16, 128, 128]);  clone_8 = None
    alias_4 = torch.ops.aten.alias.default(_unsafe_view_102);  _unsafe_view_102 = None
    transpose_64 = torch.ops.aten.transpose.int(alias_4, 1, 2);  alias_4 = None
    _to_copy_90 = torch.ops.aten._to_copy.default(transpose_64, dtype = torch.bfloat16, memory_format = torch.contiguous_format);  transpose_64 = None
    view_210 = torch.ops.aten.view.default(_to_copy_90, [-1, 128]);  _to_copy_90 = None
    view_211 = torch.ops.aten.view.default(view_179, [-1, 128]);  view_179 = None
    _to_copy_91 = torch.ops.aten._to_copy.default(view_210, dtype = torch.float32);  view_210 = None
    pow_18 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_91, 2)
    mean_17 = torch.ops.aten.mean.dim(pow_18, [-1], True);  pow_18 = None
    add_79 = torch.ops.aten.add.Tensor(mean_17, 1e-06);  mean_17 = None
    rsqrt_27 = torch.ops.aten.rsqrt.default(add_79);  add_79 = None
    mul_127 = torch.ops.aten.mul.Tensor(_to_copy_91, rsqrt_27);  _to_copy_91 = rsqrt_27 = None
    _to_copy_92 = torch.ops.aten._to_copy.default(mul_127, dtype = torch.bfloat16);  mul_127 = None
    _param_constant76 = self._param_constant76
    mul_128 = torch.ops.aten.mul.Tensor(_param_constant76, _to_copy_92);  _param_constant76 = _to_copy_92 = None
    _to_copy_93 = torch.ops.aten._to_copy.default(view_211, dtype = torch.float32);  view_211 = None
    silu_14 = torch.ops.aten.silu.default(_to_copy_93);  _to_copy_93 = None
    mul_129 = torch.ops.aten.mul.Tensor(mul_128, silu_14);  mul_128 = silu_14 = None
    _to_copy_94 = torch.ops.aten._to_copy.default(mul_129, dtype = torch.bfloat16);  mul_129 = None
    view_212 = torch.ops.aten.view.default(_to_copy_94, [1, 128, -1]);  _to_copy_94 = None
    _param_constant77 = self._param_constant77
    t_43 = torch.ops.aten.t.default(_param_constant77);  _param_constant77 = None
    view_213 = torch.ops.aten.view.default(view_212, [128, 2048]);  view_212 = None
    mm_43 = torch.ops.aten.mm.default(view_213, t_43);  view_213 = t_43 = None
    _unsafe_view_103 = torch.ops.aten._unsafe_view.default(mm_43, [1, 128, 2048]);  mm_43 = None
    add_80 = torch.ops.aten.add.Tensor(add_69, _unsafe_view_103);  add_69 = _unsafe_view_103 = None
    _to_copy_95 = torch.ops.aten._to_copy.default(add_80, dtype = torch.float32)
    pow_19 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_95, 2)
    mean_18 = torch.ops.aten.mean.dim(pow_19, [-1], True);  pow_19 = None
    add_81 = torch.ops.aten.add.Tensor(mean_18, 1e-06);  mean_18 = None
    rsqrt_28 = torch.ops.aten.rsqrt.default(add_81);  add_81 = None
    mul_130 = torch.ops.aten.mul.Tensor(_to_copy_95, rsqrt_28);  _to_copy_95 = rsqrt_28 = None
    _param_constant78 = self._param_constant78
    _to_copy_96 = torch.ops.aten._to_copy.default(_param_constant78, dtype = torch.float32);  _param_constant78 = None
    add_82 = torch.ops.aten.add.Tensor(_to_copy_96, 1.0);  _to_copy_96 = None
    mul_131 = torch.ops.aten.mul.Tensor(mul_130, add_82);  mul_130 = add_82 = None
    _to_copy_97 = torch.ops.aten._to_copy.default(mul_131, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_131 = None
    _param_constant79 = self._param_constant79
    t_44 = torch.ops.aten.t.default(_param_constant79);  _param_constant79 = None
    view_214 = torch.ops.aten.view.default(_to_copy_97, [128, 2048])
    mm_44 = torch.ops.aten.mm.default(view_214, t_44);  view_214 = t_44 = None
    _unsafe_view_104 = torch.ops.aten._unsafe_view.default(mm_44, [1, 128, 6144]);  mm_44 = None
    silu_15 = torch.ops.aten.silu.default(_unsafe_view_104);  _unsafe_view_104 = None
    _param_constant80 = self._param_constant80
    t_45 = torch.ops.aten.t.default(_param_constant80);  _param_constant80 = None
    view_215 = torch.ops.aten.view.default(_to_copy_97, [128, 2048]);  _to_copy_97 = None
    mm_45 = torch.ops.aten.mm.default(view_215, t_45);  view_215 = t_45 = None
    _unsafe_view_105 = torch.ops.aten._unsafe_view.default(mm_45, [1, 128, 6144]);  mm_45 = None
    mul_132 = torch.ops.aten.mul.Tensor(silu_15, _unsafe_view_105);  silu_15 = _unsafe_view_105 = None
    _param_constant81 = self._param_constant81
    t_46 = torch.ops.aten.t.default(_param_constant81);  _param_constant81 = None
    view_216 = torch.ops.aten.view.default(mul_132, [128, 6144]);  mul_132 = None
    mm_46 = torch.ops.aten.mm.default(view_216, t_46);  view_216 = t_46 = None
    _unsafe_view_106 = torch.ops.aten._unsafe_view.default(mm_46, [1, 128, 2048]);  mm_46 = None
    add_83 = torch.ops.aten.add.Tensor(add_80, _unsafe_view_106);  add_80 = _unsafe_view_106 = None
    _to_copy_98 = torch.ops.aten._to_copy.default(add_83, dtype = torch.float32)
    pow_20 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_98, 2)
    mean_19 = torch.ops.aten.mean.dim(pow_20, [-1], True);  pow_20 = None
    add_84 = torch.ops.aten.add.Tensor(mean_19, 1e-06);  mean_19 = None
    rsqrt_29 = torch.ops.aten.rsqrt.default(add_84);  add_84 = None
    mul_133 = torch.ops.aten.mul.Tensor(_to_copy_98, rsqrt_29);  _to_copy_98 = rsqrt_29 = None
    _param_constant82 = self._param_constant82
    _to_copy_99 = torch.ops.aten._to_copy.default(_param_constant82, dtype = torch.float32);  _param_constant82 = None
    add_85 = torch.ops.aten.add.Tensor(_to_copy_99, 1.0);  _to_copy_99 = None
    mul_134 = torch.ops.aten.mul.Tensor(mul_133, add_85);  mul_133 = add_85 = None
    _to_copy_100 = torch.ops.aten._to_copy.default(mul_134, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_134 = None
    _param_constant83 = self._param_constant83
    t_47 = torch.ops.aten.t.default(_param_constant83);  _param_constant83 = None
    view_217 = torch.ops.aten.view.default(_to_copy_100, [128, 2048])
    mm_47 = torch.ops.aten.mm.default(view_217, t_47);  view_217 = t_47 = None
    _unsafe_view_107 = torch.ops.aten._unsafe_view.default(mm_47, [1, 128, 6144]);  mm_47 = None
    transpose_65 = torch.ops.aten.transpose.int(_unsafe_view_107, 1, 2);  _unsafe_view_107 = None
    _param_constant84 = self._param_constant84
    t_48 = torch.ops.aten.t.default(_param_constant84);  _param_constant84 = None
    view_218 = torch.ops.aten.view.default(_to_copy_100, [128, 2048])
    mm_48 = torch.ops.aten.mm.default(view_218, t_48);  view_218 = t_48 = None
    _unsafe_view_108 = torch.ops.aten._unsafe_view.default(mm_48, [1, 128, 2048]);  mm_48 = None
    view_219 = torch.ops.aten.view.default(_unsafe_view_108, [1, 128, -1, 128]);  _unsafe_view_108 = None
    _param_constant85 = self._param_constant85
    t_49 = torch.ops.aten.t.default(_param_constant85);  _param_constant85 = None
    view_220 = torch.ops.aten.view.default(_to_copy_100, [128, 2048])
    mm_49 = torch.ops.aten.mm.default(view_220, t_49);  view_220 = t_49 = None
    _unsafe_view_109 = torch.ops.aten._unsafe_view.default(mm_49, [1, 128, 16]);  mm_49 = None
    _param_constant86 = self._param_constant86
    t_50 = torch.ops.aten.t.default(_param_constant86);  _param_constant86 = None
    view_221 = torch.ops.aten.view.default(_to_copy_100, [128, 2048]);  _to_copy_100 = None
    mm_50 = torch.ops.aten.mm.default(view_221, t_50);  view_221 = t_50 = None
    _unsafe_view_110 = torch.ops.aten._unsafe_view.default(mm_50, [1, 128, 16]);  mm_50 = None
    _param_constant87 = self._param_constant87
    squeeze_5 = torch.ops.aten.squeeze.dim(_param_constant87, 1);  _param_constant87 = None
    unsqueeze_57 = torch.ops.aten.unsqueeze.default(squeeze_5, 1);  squeeze_5 = None
    convolution_5 = torch.ops.aten.convolution.default(transpose_65, unsqueeze_57, None, [1], [3], [1], False, [0], 6144);  transpose_65 = unsqueeze_57 = None
    slice_28 = torch.ops.aten.slice.Tensor(convolution_5, 2, 0, 128);  convolution_5 = None
    silu_16 = torch.ops.aten.silu.default(slice_28);  slice_28 = None
    transpose_66 = torch.ops.aten.transpose.int(silu_16, 1, 2);  silu_16 = None
    split_with_sizes_5 = torch.ops.aten.split_with_sizes.default(transpose_66, [2048, 2048, 2048], -1);  transpose_66 = None
    getitem_17 = split_with_sizes_5[0]
    getitem_18 = split_with_sizes_5[1]
    getitem_19 = split_with_sizes_5[2];  split_with_sizes_5 = None
    view_222 = torch.ops.aten.view.default(getitem_17, [1, 128, 16, 128]);  getitem_17 = None
    view_223 = torch.ops.aten.view.default(getitem_18, [1, 128, 16, 128]);  getitem_18 = None
    view_224 = torch.ops.aten.view.default(getitem_19, [1, 128, 16, 128]);  getitem_19 = None
    sigmoid_6 = torch.ops.aten.sigmoid.default(_unsafe_view_109);  _unsafe_view_109 = None
    _param_constant88 = self._param_constant88
    exp_30 = torch.ops.aten.exp.default(_param_constant88);  _param_constant88 = None
    neg_7 = torch.ops.aten.neg.default(exp_30);  exp_30 = None
    _to_copy_101 = torch.ops.aten._to_copy.default(_unsafe_view_110, dtype = torch.float32);  _unsafe_view_110 = None
    _param_constant89 = self._param_constant89
    add_86 = torch.ops.aten.add.Tensor(_to_copy_101, _param_constant89);  _to_copy_101 = _param_constant89 = None
    softplus_5 = torch.ops.aten.softplus.default(add_86);  add_86 = None
    mul_135 = torch.ops.aten.mul.Tensor(neg_7, softplus_5);  neg_7 = softplus_5 = None
    transpose_67 = torch.ops.aten.transpose.int(view_222, 1, 2);  view_222 = None
    _to_copy_102 = torch.ops.aten._to_copy.default(transpose_67, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_67 = None
    transpose_68 = torch.ops.aten.transpose.int(view_223, 1, 2);  view_223 = None
    _to_copy_103 = torch.ops.aten._to_copy.default(transpose_68, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_68 = None
    transpose_69 = torch.ops.aten.transpose.int(view_224, 1, 2);  view_224 = None
    _to_copy_104 = torch.ops.aten._to_copy.default(transpose_69, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_69 = None
    transpose_70 = torch.ops.aten.transpose.int(sigmoid_6, 1, 2);  sigmoid_6 = None
    _to_copy_105 = torch.ops.aten._to_copy.default(transpose_70, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_70 = None
    transpose_71 = torch.ops.aten.transpose.int(mul_135, 1, 2);  mul_135 = None
    mul_136 = torch.ops.aten.mul.Tensor(_to_copy_102, _to_copy_102)
    sum_11 = torch.ops.aten.sum.dim_IntList(mul_136, [-1], True);  mul_136 = None
    add_87 = torch.ops.aten.add.Tensor(sum_11, 1e-06);  sum_11 = None
    rsqrt_30 = torch.ops.aten.rsqrt.default(add_87);  add_87 = None
    mul_137 = torch.ops.aten.mul.Tensor(_to_copy_102, rsqrt_30);  _to_copy_102 = rsqrt_30 = None
    mul_138 = torch.ops.aten.mul.Tensor(_to_copy_103, _to_copy_103)
    sum_12 = torch.ops.aten.sum.dim_IntList(mul_138, [-1], True);  mul_138 = None
    add_88 = torch.ops.aten.add.Tensor(sum_12, 1e-06);  sum_12 = None
    rsqrt_31 = torch.ops.aten.rsqrt.default(add_88);  add_88 = None
    mul_139 = torch.ops.aten.mul.Tensor(_to_copy_103, rsqrt_31);  _to_copy_103 = rsqrt_31 = None
    mul_140 = torch.ops.aten.mul.Tensor(mul_137, 0.08838834764831845);  mul_137 = None
    constant_pad_nd_25 = torch.ops.aten.constant_pad_nd.default(mul_140, [0, 0, 0, 0], 0.0);  mul_140 = None
    constant_pad_nd_26 = torch.ops.aten.constant_pad_nd.default(mul_139, [0, 0, 0, 0], 0.0);  mul_139 = None
    constant_pad_nd_27 = torch.ops.aten.constant_pad_nd.default(_to_copy_104, [0, 0, 0, 0], 0.0);  _to_copy_104 = None
    constant_pad_nd_28 = torch.ops.aten.constant_pad_nd.default(_to_copy_105, [0, 0], 0.0);  _to_copy_105 = None
    constant_pad_nd_29 = torch.ops.aten.constant_pad_nd.default(transpose_71, [0, 0], 0.0);  transpose_71 = None
    unsqueeze_58 = torch.ops.aten.unsqueeze.default(constant_pad_nd_28, -1)
    mul_141 = torch.ops.aten.mul.Tensor(constant_pad_nd_27, unsqueeze_58);  constant_pad_nd_27 = unsqueeze_58 = None
    unsqueeze_59 = torch.ops.aten.unsqueeze.default(constant_pad_nd_28, -1);  constant_pad_nd_28 = None
    mul_142 = torch.ops.aten.mul.Tensor(constant_pad_nd_26, unsqueeze_59);  unsqueeze_59 = None
    view_225 = torch.ops.aten.view.default(constant_pad_nd_25, [1, 16, -1, 64, 128]);  constant_pad_nd_25 = None
    view_226 = torch.ops.aten.view.default(constant_pad_nd_26, [1, 16, -1, 64, 128]);  constant_pad_nd_26 = None
    view_227 = torch.ops.aten.view.default(mul_142, [1, 16, -1, 64, 128]);  mul_142 = None
    view_228 = torch.ops.aten.view.default(mul_141, [1, 16, -1, 64, 128]);  mul_141 = None
    view_229 = torch.ops.aten.view.default(constant_pad_nd_29, [1, 16, 2, 64]);  constant_pad_nd_29 = None
    ones_5 = torch.ops.aten.ones.default([64, 64], dtype = torch.bool, device = device(type='meta'), pin_memory = False)
    triu_6 = torch.ops.aten.triu.default(ones_5, 1);  ones_5 = None
    cumsum_5 = torch.ops.aten.cumsum.default(view_229, 3);  view_229 = None
    unsqueeze_60 = torch.ops.aten.unsqueeze.default(cumsum_5, 4)
    unsqueeze_61 = torch.ops.aten.unsqueeze.default(cumsum_5, 3)
    sub_20 = torch.ops.aten.sub.Tensor(unsqueeze_60, unsqueeze_61);  unsqueeze_60 = unsqueeze_61 = None
    masked_fill_5 = torch.ops.aten.masked_fill.Scalar(sub_20, triu_6, -inf);  sub_20 = triu_6 = None
    exp_31 = torch.ops.aten.exp.default(masked_fill_5);  masked_fill_5 = None
    transpose_72 = torch.ops.aten.transpose.int(view_226, -1, -2)
    expand_108 = torch.ops.aten.expand.default(view_227, [1, 16, 2, 64, 128])
    view_230 = torch.ops.aten.view.default(expand_108, [32, 64, 128]);  expand_108 = None
    expand_109 = torch.ops.aten.expand.default(transpose_72, [1, 16, 2, 128, 64]);  transpose_72 = None
    view_231 = torch.ops.aten.view.default(expand_109, [32, 128, 64]);  expand_109 = None
    bmm_52 = torch.ops.aten.bmm.default(view_230, view_231);  view_230 = view_231 = None
    _unsafe_view_111 = torch.ops.aten._unsafe_view.default(bmm_52, [1, 16, 2, 64, 64]);  bmm_52 = None
    mul_143 = torch.ops.aten.mul.Tensor(_unsafe_view_111, exp_31);  _unsafe_view_111 = None
    transpose_73 = torch.ops.aten.transpose.int(view_226, -1, -2)
    expand_110 = torch.ops.aten.expand.default(view_225, [1, 16, 2, 64, 128])
    view_232 = torch.ops.aten.view.default(expand_110, [32, 64, 128]);  expand_110 = None
    expand_111 = torch.ops.aten.expand.default(transpose_73, [1, 16, 2, 128, 64]);  transpose_73 = None
    view_233 = torch.ops.aten.view.default(expand_111, [32, 128, 64]);  expand_111 = None
    bmm_53 = torch.ops.aten.bmm.default(view_232, view_233);  view_232 = view_233 = None
    _unsafe_view_112 = torch.ops.aten._unsafe_view.default(bmm_53, [1, 16, 2, 64, 64]);  bmm_53 = None
    mul_144 = torch.ops.aten.mul.Tensor(_unsafe_view_112, exp_31);  _unsafe_view_112 = exp_31 = None
    exp_32 = torch.ops.aten.exp.default(cumsum_5)
    unsqueeze_62 = torch.ops.aten.unsqueeze.default(exp_32, -1);  exp_32 = None
    mul_145 = torch.ops.aten.mul.Tensor(view_227, unsqueeze_62);  view_227 = unsqueeze_62 = None
    linalg_solve_triangular_10 = torch.ops.aten.linalg_solve_triangular.default(mul_143, view_228, upper = False, unitriangular = True);  view_228 = None
    linalg_solve_triangular_11 = torch.ops.aten.linalg_solve_triangular.default(mul_143, mul_145, upper = False, unitriangular = True);  mul_143 = mul_145 = None
    zeros_5 = torch.ops.aten.zeros.default([1, 16, 128, 128], dtype = torch.float32, device = device(type='meta'), pin_memory = False)
    zeros_like_5 = torch.ops.aten.zeros_like.default(linalg_solve_triangular_10, pin_memory = False)
    exp_33 = torch.ops.aten.exp.default(cumsum_5)
    unsqueeze_63 = torch.ops.aten.unsqueeze.default(exp_33, -1);  exp_33 = None
    mul_146 = torch.ops.aten.mul.Tensor(view_225, unsqueeze_63);  view_225 = unsqueeze_63 = None
    slice_29 = torch.ops.aten.slice.Tensor(cumsum_5, 3, -1, 9223372036854775807)
    sub_21 = torch.ops.aten.sub.Tensor(slice_29, cumsum_5);  slice_29 = None
    exp_34 = torch.ops.aten.exp.default(sub_21);  sub_21 = None
    unsqueeze_64 = torch.ops.aten.unsqueeze.default(exp_34, -1);  exp_34 = None
    mul_147 = torch.ops.aten.mul.Tensor(view_226, unsqueeze_64);  view_226 = unsqueeze_64 = None
    select_82 = torch.ops.aten.select.int(cumsum_5, 3, -1);  cumsum_5 = None
    exp_35 = torch.ops.aten.exp.default(select_82);  select_82 = None
    unsqueeze_65 = torch.ops.aten.unsqueeze.default(exp_35, 3);  exp_35 = None
    unsqueeze_66 = torch.ops.aten.unsqueeze.default(unsqueeze_65, 4);  unsqueeze_65 = None
    select_83 = torch.ops.aten.select.int(linalg_solve_triangular_10, 2, 0)
    select_84 = torch.ops.aten.select.int(linalg_solve_triangular_11, 2, 0)
    expand_112 = torch.ops.aten.expand.default(select_84, [1, 16, 64, 128]);  select_84 = None
    view_234 = torch.ops.aten.view.default(expand_112, [16, 64, 128]);  expand_112 = None
    expand_113 = torch.ops.aten.expand.default(zeros_5, [1, 16, 128, 128])
    view_235 = torch.ops.aten.view.default(expand_113, [16, 128, 128]);  expand_113 = None
    bmm_54 = torch.ops.aten.bmm.default(view_234, view_235);  view_234 = view_235 = None
    _unsafe_view_113 = torch.ops.aten._unsafe_view.default(bmm_54, [1, 16, 64, 128]);  bmm_54 = None
    sub_22 = torch.ops.aten.sub.Tensor(select_83, _unsafe_view_113);  select_83 = _unsafe_view_113 = None
    select_85 = torch.ops.aten.select.int(mul_146, 2, 0)
    expand_114 = torch.ops.aten.expand.default(select_85, [1, 16, 64, 128]);  select_85 = None
    view_236 = torch.ops.aten.view.default(expand_114, [16, 64, 128]);  expand_114 = None
    expand_115 = torch.ops.aten.expand.default(zeros_5, [1, 16, 128, 128])
    view_237 = torch.ops.aten.view.default(expand_115, [16, 128, 128]);  expand_115 = None
    bmm_55 = torch.ops.aten.bmm.default(view_236, view_237);  view_236 = view_237 = None
    _unsafe_view_114 = torch.ops.aten._unsafe_view.default(bmm_55, [1, 16, 64, 128]);  bmm_55 = None
    select_86 = torch.ops.aten.select.int(mul_144, 2, 0)
    expand_116 = torch.ops.aten.expand.default(select_86, [1, 16, 64, 64]);  select_86 = None
    view_238 = torch.ops.aten.view.default(expand_116, [16, 64, 64]);  expand_116 = None
    expand_117 = torch.ops.aten.expand.default(sub_22, [1, 16, 64, 128])
    view_239 = torch.ops.aten.view.default(expand_117, [16, 64, 128]);  expand_117 = None
    bmm_56 = torch.ops.aten.bmm.default(view_238, view_239);  view_238 = view_239 = None
    _unsafe_view_115 = torch.ops.aten._unsafe_view.default(bmm_56, [1, 16, 64, 128]);  bmm_56 = None
    add_89 = torch.ops.aten.add.Tensor(_unsafe_view_114, _unsafe_view_115);  _unsafe_view_114 = _unsafe_view_115 = None
    select_87 = torch.ops.aten.select.int(zeros_like_5, 2, 0)
    copy__14 = torch.ops.aten.copy_.default(select_87, add_89);  select_87 = add_89 = copy__14 = None
    select_88 = torch.ops.aten.select.int(unsqueeze_66, 2, 0)
    mul_148 = torch.ops.aten.mul.Tensor(zeros_5, select_88);  zeros_5 = select_88 = None
    select_89 = torch.ops.aten.select.int(mul_147, 2, 0)
    transpose_74 = torch.ops.aten.transpose.int(select_89, -1, -2);  select_89 = None
    expand_118 = torch.ops.aten.expand.default(transpose_74, [1, 16, 128, 64]);  transpose_74 = None
    view_240 = torch.ops.aten.view.default(expand_118, [16, 128, 64]);  expand_118 = None
    expand_119 = torch.ops.aten.expand.default(sub_22, [1, 16, 64, 128]);  sub_22 = None
    view_241 = torch.ops.aten.view.default(expand_119, [16, 64, 128]);  expand_119 = None
    bmm_57 = torch.ops.aten.bmm.default(view_240, view_241);  view_240 = view_241 = None
    _unsafe_view_116 = torch.ops.aten._unsafe_view.default(bmm_57, [1, 16, 128, 128]);  bmm_57 = None
    add_90 = torch.ops.aten.add.Tensor(mul_148, _unsafe_view_116);  mul_148 = _unsafe_view_116 = None
    select_90 = torch.ops.aten.select.int(linalg_solve_triangular_10, 2, 1);  linalg_solve_triangular_10 = None
    select_91 = torch.ops.aten.select.int(linalg_solve_triangular_11, 2, 1);  linalg_solve_triangular_11 = None
    expand_120 = torch.ops.aten.expand.default(select_91, [1, 16, 64, 128]);  select_91 = None
    view_242 = torch.ops.aten.view.default(expand_120, [16, 64, 128]);  expand_120 = None
    expand_121 = torch.ops.aten.expand.default(add_90, [1, 16, 128, 128])
    view_243 = torch.ops.aten.view.default(expand_121, [16, 128, 128]);  expand_121 = None
    bmm_58 = torch.ops.aten.bmm.default(view_242, view_243);  view_242 = view_243 = None
    _unsafe_view_117 = torch.ops.aten._unsafe_view.default(bmm_58, [1, 16, 64, 128]);  bmm_58 = None
    sub_23 = torch.ops.aten.sub.Tensor(select_90, _unsafe_view_117);  select_90 = _unsafe_view_117 = None
    select_92 = torch.ops.aten.select.int(mul_146, 2, 1);  mul_146 = None
    expand_122 = torch.ops.aten.expand.default(select_92, [1, 16, 64, 128]);  select_92 = None
    view_244 = torch.ops.aten.view.default(expand_122, [16, 64, 128]);  expand_122 = None
    expand_123 = torch.ops.aten.expand.default(add_90, [1, 16, 128, 128])
    view_245 = torch.ops.aten.view.default(expand_123, [16, 128, 128]);  expand_123 = None
    bmm_59 = torch.ops.aten.bmm.default(view_244, view_245);  view_244 = view_245 = None
    _unsafe_view_118 = torch.ops.aten._unsafe_view.default(bmm_59, [1, 16, 64, 128]);  bmm_59 = None
    select_93 = torch.ops.aten.select.int(mul_144, 2, 1);  mul_144 = None
    expand_124 = torch.ops.aten.expand.default(select_93, [1, 16, 64, 64]);  select_93 = None
    view_246 = torch.ops.aten.view.default(expand_124, [16, 64, 64]);  expand_124 = None
    expand_125 = torch.ops.aten.expand.default(sub_23, [1, 16, 64, 128])
    view_247 = torch.ops.aten.view.default(expand_125, [16, 64, 128]);  expand_125 = None
    bmm_60 = torch.ops.aten.bmm.default(view_246, view_247);  view_246 = view_247 = None
    _unsafe_view_119 = torch.ops.aten._unsafe_view.default(bmm_60, [1, 16, 64, 128]);  bmm_60 = None
    add_91 = torch.ops.aten.add.Tensor(_unsafe_view_118, _unsafe_view_119);  _unsafe_view_118 = _unsafe_view_119 = None
    select_94 = torch.ops.aten.select.int(zeros_like_5, 2, 1)
    copy__15 = torch.ops.aten.copy_.default(select_94, add_91);  select_94 = add_91 = copy__15 = None
    select_95 = torch.ops.aten.select.int(unsqueeze_66, 2, 1);  unsqueeze_66 = None
    mul_149 = torch.ops.aten.mul.Tensor(add_90, select_95);  add_90 = select_95 = None
    select_96 = torch.ops.aten.select.int(mul_147, 2, 1);  mul_147 = None
    transpose_75 = torch.ops.aten.transpose.int(select_96, -1, -2);  select_96 = None
    expand_126 = torch.ops.aten.expand.default(transpose_75, [1, 16, 128, 64]);  transpose_75 = None
    view_248 = torch.ops.aten.view.default(expand_126, [16, 128, 64]);  expand_126 = None
    expand_127 = torch.ops.aten.expand.default(sub_23, [1, 16, 64, 128]);  sub_23 = None
    view_249 = torch.ops.aten.view.default(expand_127, [16, 64, 128]);  expand_127 = None
    bmm_61 = torch.ops.aten.bmm.default(view_248, view_249);  view_248 = view_249 = None
    _unsafe_view_120 = torch.ops.aten._unsafe_view.default(bmm_61, [1, 16, 128, 128]);  bmm_61 = None
    add_92 = torch.ops.aten.add.Tensor(mul_149, _unsafe_view_120);  mul_149 = _unsafe_view_120 = add_92 = None
    clone_9 = torch.ops.aten.clone.default(zeros_like_5, memory_format = torch.contiguous_format);  zeros_like_5 = None
    _unsafe_view_121 = torch.ops.aten._unsafe_view.default(clone_9, [1, 16, 128, 128]);  clone_9 = None
    alias_5 = torch.ops.aten.alias.default(_unsafe_view_121);  _unsafe_view_121 = None
    transpose_76 = torch.ops.aten.transpose.int(alias_5, 1, 2);  alias_5 = None
    _to_copy_106 = torch.ops.aten._to_copy.default(transpose_76, dtype = torch.bfloat16, memory_format = torch.contiguous_format);  transpose_76 = None
    view_250 = torch.ops.aten.view.default(_to_copy_106, [-1, 128]);  _to_copy_106 = None
    view_251 = torch.ops.aten.view.default(view_219, [-1, 128]);  view_219 = None
    _to_copy_107 = torch.ops.aten._to_copy.default(view_250, dtype = torch.float32);  view_250 = None
    pow_21 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_107, 2)
    mean_20 = torch.ops.aten.mean.dim(pow_21, [-1], True);  pow_21 = None
    add_93 = torch.ops.aten.add.Tensor(mean_20, 1e-06);  mean_20 = None
    rsqrt_32 = torch.ops.aten.rsqrt.default(add_93);  add_93 = None
    mul_150 = torch.ops.aten.mul.Tensor(_to_copy_107, rsqrt_32);  _to_copy_107 = rsqrt_32 = None
    _to_copy_108 = torch.ops.aten._to_copy.default(mul_150, dtype = torch.bfloat16);  mul_150 = None
    _param_constant90 = self._param_constant90
    mul_151 = torch.ops.aten.mul.Tensor(_param_constant90, _to_copy_108);  _param_constant90 = _to_copy_108 = None
    _to_copy_109 = torch.ops.aten._to_copy.default(view_251, dtype = torch.float32);  view_251 = None
    silu_17 = torch.ops.aten.silu.default(_to_copy_109);  _to_copy_109 = None
    mul_152 = torch.ops.aten.mul.Tensor(mul_151, silu_17);  mul_151 = silu_17 = None
    _to_copy_110 = torch.ops.aten._to_copy.default(mul_152, dtype = torch.bfloat16);  mul_152 = None
    view_252 = torch.ops.aten.view.default(_to_copy_110, [1, 128, -1]);  _to_copy_110 = None
    _param_constant91 = self._param_constant91
    t_51 = torch.ops.aten.t.default(_param_constant91);  _param_constant91 = None
    view_253 = torch.ops.aten.view.default(view_252, [128, 2048]);  view_252 = None
    mm_51 = torch.ops.aten.mm.default(view_253, t_51);  view_253 = t_51 = None
    _unsafe_view_122 = torch.ops.aten._unsafe_view.default(mm_51, [1, 128, 2048]);  mm_51 = None
    add_94 = torch.ops.aten.add.Tensor(add_83, _unsafe_view_122);  add_83 = _unsafe_view_122 = None
    _to_copy_111 = torch.ops.aten._to_copy.default(add_94, dtype = torch.float32)
    pow_22 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_111, 2)
    mean_21 = torch.ops.aten.mean.dim(pow_22, [-1], True);  pow_22 = None
    add_95 = torch.ops.aten.add.Tensor(mean_21, 1e-06);  mean_21 = None
    rsqrt_33 = torch.ops.aten.rsqrt.default(add_95);  add_95 = None
    mul_153 = torch.ops.aten.mul.Tensor(_to_copy_111, rsqrt_33);  _to_copy_111 = rsqrt_33 = None
    _param_constant92 = self._param_constant92
    _to_copy_112 = torch.ops.aten._to_copy.default(_param_constant92, dtype = torch.float32);  _param_constant92 = None
    add_96 = torch.ops.aten.add.Tensor(_to_copy_112, 1.0);  _to_copy_112 = None
    mul_154 = torch.ops.aten.mul.Tensor(mul_153, add_96);  mul_153 = add_96 = None
    _to_copy_113 = torch.ops.aten._to_copy.default(mul_154, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_154 = None
    _param_constant93 = self._param_constant93
    t_52 = torch.ops.aten.t.default(_param_constant93);  _param_constant93 = None
    view_254 = torch.ops.aten.view.default(_to_copy_113, [128, 2048])
    mm_52 = torch.ops.aten.mm.default(view_254, t_52);  view_254 = t_52 = None
    _unsafe_view_123 = torch.ops.aten._unsafe_view.default(mm_52, [1, 128, 6144]);  mm_52 = None
    silu_18 = torch.ops.aten.silu.default(_unsafe_view_123);  _unsafe_view_123 = None
    _param_constant94 = self._param_constant94
    t_53 = torch.ops.aten.t.default(_param_constant94);  _param_constant94 = None
    view_255 = torch.ops.aten.view.default(_to_copy_113, [128, 2048]);  _to_copy_113 = None
    mm_53 = torch.ops.aten.mm.default(view_255, t_53);  view_255 = t_53 = None
    _unsafe_view_124 = torch.ops.aten._unsafe_view.default(mm_53, [1, 128, 6144]);  mm_53 = None
    mul_155 = torch.ops.aten.mul.Tensor(silu_18, _unsafe_view_124);  silu_18 = _unsafe_view_124 = None
    _param_constant95 = self._param_constant95
    t_54 = torch.ops.aten.t.default(_param_constant95);  _param_constant95 = None
    view_256 = torch.ops.aten.view.default(mul_155, [128, 6144]);  mul_155 = None
    mm_54 = torch.ops.aten.mm.default(view_256, t_54);  view_256 = t_54 = None
    _unsafe_view_125 = torch.ops.aten._unsafe_view.default(mm_54, [1, 128, 2048]);  mm_54 = None
    add_97 = torch.ops.aten.add.Tensor(add_94, _unsafe_view_125);  add_94 = _unsafe_view_125 = None
    _to_copy_114 = torch.ops.aten._to_copy.default(add_97, dtype = torch.float32)
    pow_23 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_114, 2)
    mean_22 = torch.ops.aten.mean.dim(pow_23, [-1], True);  pow_23 = None
    add_98 = torch.ops.aten.add.Tensor(mean_22, 1e-06);  mean_22 = None
    rsqrt_34 = torch.ops.aten.rsqrt.default(add_98);  add_98 = None
    mul_156 = torch.ops.aten.mul.Tensor(_to_copy_114, rsqrt_34);  _to_copy_114 = rsqrt_34 = None
    _param_constant96 = self._param_constant96
    _to_copy_115 = torch.ops.aten._to_copy.default(_param_constant96, dtype = torch.float32);  _param_constant96 = None
    add_99 = torch.ops.aten.add.Tensor(_to_copy_115, 1.0);  _to_copy_115 = None
    mul_157 = torch.ops.aten.mul.Tensor(mul_156, add_99);  mul_156 = add_99 = None
    _to_copy_116 = torch.ops.aten._to_copy.default(mul_157, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_157 = None
    _param_constant97 = self._param_constant97
    t_55 = torch.ops.aten.t.default(_param_constant97);  _param_constant97 = None
    view_257 = torch.ops.aten.view.default(_to_copy_116, [128, 2048])
    mm_55 = torch.ops.aten.mm.default(view_257, t_55);  view_257 = t_55 = None
    _unsafe_view_126 = torch.ops.aten._unsafe_view.default(mm_55, [1, 128, 4096]);  mm_55 = None
    view_258 = torch.ops.aten.view.default(_unsafe_view_126, [1, 128, -1, 512]);  _unsafe_view_126 = None
    split_1 = torch.ops.aten.split.Tensor(view_258, 256, -1);  view_258 = None
    getitem_20 = split_1[0]
    getitem_21 = split_1[1];  split_1 = None
    clone_10 = torch.ops.aten.clone.default(getitem_21, memory_format = torch.contiguous_format);  getitem_21 = None
    _unsafe_view_127 = torch.ops.aten._unsafe_view.default(clone_10, [1, 128, 2048]);  clone_10 = None
    view_259 = torch.ops.aten.view.default(getitem_20, [1, 128, -1, 256]);  getitem_20 = None
    _to_copy_117 = torch.ops.aten._to_copy.default(view_259, dtype = torch.float32);  view_259 = None
    pow_24 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_117, 2)
    mean_23 = torch.ops.aten.mean.dim(pow_24, [-1], True);  pow_24 = None
    add_100 = torch.ops.aten.add.Tensor(mean_23, 1e-06);  mean_23 = None
    rsqrt_35 = torch.ops.aten.rsqrt.default(add_100);  add_100 = None
    mul_158 = torch.ops.aten.mul.Tensor(_to_copy_117, rsqrt_35);  _to_copy_117 = rsqrt_35 = None
    _param_constant98 = self._param_constant98
    _to_copy_118 = torch.ops.aten._to_copy.default(_param_constant98, dtype = torch.float32);  _param_constant98 = None
    add_101 = torch.ops.aten.add.Tensor(_to_copy_118, 1.0);  _to_copy_118 = None
    mul_159 = torch.ops.aten.mul.Tensor(mul_158, add_101);  mul_158 = add_101 = None
    _to_copy_119 = torch.ops.aten._to_copy.default(mul_159, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_159 = None
    transpose_77 = torch.ops.aten.transpose.int(_to_copy_119, 1, 2);  _to_copy_119 = None
    _param_constant99 = self._param_constant99
    t_56 = torch.ops.aten.t.default(_param_constant99);  _param_constant99 = None
    view_260 = torch.ops.aten.view.default(_to_copy_116, [128, 2048])
    mm_56 = torch.ops.aten.mm.default(view_260, t_56);  view_260 = t_56 = None
    _unsafe_view_128 = torch.ops.aten._unsafe_view.default(mm_56, [1, 128, 512]);  mm_56 = None
    view_261 = torch.ops.aten.view.default(_unsafe_view_128, [1, 128, -1, 256]);  _unsafe_view_128 = None
    _to_copy_120 = torch.ops.aten._to_copy.default(view_261, dtype = torch.float32);  view_261 = None
    pow_25 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_120, 2)
    mean_24 = torch.ops.aten.mean.dim(pow_25, [-1], True);  pow_25 = None
    add_102 = torch.ops.aten.add.Tensor(mean_24, 1e-06);  mean_24 = None
    rsqrt_36 = torch.ops.aten.rsqrt.default(add_102);  add_102 = None
    mul_160 = torch.ops.aten.mul.Tensor(_to_copy_120, rsqrt_36);  _to_copy_120 = rsqrt_36 = None
    _param_constant100 = self._param_constant100
    _to_copy_121 = torch.ops.aten._to_copy.default(_param_constant100, dtype = torch.float32);  _param_constant100 = None
    add_103 = torch.ops.aten.add.Tensor(_to_copy_121, 1.0);  _to_copy_121 = None
    mul_161 = torch.ops.aten.mul.Tensor(mul_160, add_103);  mul_160 = add_103 = None
    _to_copy_122 = torch.ops.aten._to_copy.default(mul_161, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_161 = None
    transpose_78 = torch.ops.aten.transpose.int(_to_copy_122, 1, 2);  _to_copy_122 = None
    _param_constant101 = self._param_constant101
    t_57 = torch.ops.aten.t.default(_param_constant101);  _param_constant101 = None
    view_262 = torch.ops.aten.view.default(_to_copy_116, [128, 2048]);  _to_copy_116 = None
    mm_57 = torch.ops.aten.mm.default(view_262, t_57);  view_262 = t_57 = None
    _unsafe_view_129 = torch.ops.aten._unsafe_view.default(mm_57, [1, 128, 512]);  mm_57 = None
    view_263 = torch.ops.aten.view.default(_unsafe_view_129, [1, 128, -1, 256]);  _unsafe_view_129 = None
    transpose_79 = torch.ops.aten.transpose.int(view_263, 1, 2);  view_263 = None
    unsqueeze_67 = torch.ops.aten.unsqueeze.default(_to_copy_2, 1)
    unsqueeze_68 = torch.ops.aten.unsqueeze.default(_to_copy_3, 1)
    slice_30 = torch.ops.aten.slice.Tensor(transpose_77, 3, 0, 64)
    slice_31 = torch.ops.aten.slice.Tensor(transpose_77, 3, 64, 9223372036854775807);  transpose_77 = None
    slice_32 = torch.ops.aten.slice.Tensor(transpose_78, 3, 0, 64)
    slice_33 = torch.ops.aten.slice.Tensor(transpose_78, 3, 64, 9223372036854775807);  transpose_78 = None
    mul_162 = torch.ops.aten.mul.Tensor(slice_30, unsqueeze_67)
    slice_34 = torch.ops.aten.slice.Tensor(slice_30, 3, 0, 32)
    slice_35 = torch.ops.aten.slice.Tensor(slice_30, 3, 32, 9223372036854775807);  slice_30 = None
    neg_8 = torch.ops.aten.neg.default(slice_35);  slice_35 = None
    cat_6 = torch.ops.aten.cat.default([neg_8, slice_34], -1);  neg_8 = slice_34 = None
    mul_163 = torch.ops.aten.mul.Tensor(cat_6, unsqueeze_68);  cat_6 = None
    add_104 = torch.ops.aten.add.Tensor(mul_162, mul_163);  mul_162 = mul_163 = None
    mul_164 = torch.ops.aten.mul.Tensor(slice_32, unsqueeze_67);  unsqueeze_67 = None
    slice_36 = torch.ops.aten.slice.Tensor(slice_32, 3, 0, 32)
    slice_37 = torch.ops.aten.slice.Tensor(slice_32, 3, 32, 9223372036854775807);  slice_32 = None
    neg_9 = torch.ops.aten.neg.default(slice_37);  slice_37 = None
    cat_7 = torch.ops.aten.cat.default([neg_9, slice_36], -1);  neg_9 = slice_36 = None
    mul_165 = torch.ops.aten.mul.Tensor(cat_7, unsqueeze_68);  cat_7 = unsqueeze_68 = None
    add_105 = torch.ops.aten.add.Tensor(mul_164, mul_165);  mul_164 = mul_165 = None
    cat_8 = torch.ops.aten.cat.default([add_104, slice_31], -1);  add_104 = slice_31 = None
    cat_9 = torch.ops.aten.cat.default([add_105, slice_33], -1);  add_105 = slice_33 = None
    unsqueeze_69 = torch.ops.aten.unsqueeze.default(cat_9, 2);  cat_9 = None
    expand_128 = torch.ops.aten.expand.default(unsqueeze_69, [1, 2, 4, 128, 256]);  unsqueeze_69 = None
    clone_11 = torch.ops.aten.clone.default(expand_128, memory_format = torch.contiguous_format);  expand_128 = None
    _unsafe_view_130 = torch.ops.aten._unsafe_view.default(clone_11, [1, 8, 128, 256]);  clone_11 = None
    unsqueeze_70 = torch.ops.aten.unsqueeze.default(transpose_79, 2);  transpose_79 = None
    expand_129 = torch.ops.aten.expand.default(unsqueeze_70, [1, 2, 4, 128, 256]);  unsqueeze_70 = None
    clone_12 = torch.ops.aten.clone.default(expand_129, memory_format = torch.contiguous_format);  expand_129 = None
    _unsafe_view_131 = torch.ops.aten._unsafe_view.default(clone_12, [1, 8, 128, 256]);  clone_12 = None
    transpose_80 = torch.ops.aten.transpose.int(_unsafe_view_130, 2, 3);  _unsafe_view_130 = None
    expand_130 = torch.ops.aten.expand.default(cat_8, [1, 8, 128, 256]);  cat_8 = None
    view_264 = torch.ops.aten.view.default(expand_130, [8, 128, 256]);  expand_130 = None
    expand_131 = torch.ops.aten.expand.default(transpose_80, [1, 8, 256, 128]);  transpose_80 = None
    view_265 = torch.ops.aten.view.default(expand_131, [8, 256, 128]);  expand_131 = None
    bmm_62 = torch.ops.aten.bmm.default(view_264, view_265);  view_264 = view_265 = None
    _unsafe_view_132 = torch.ops.aten._unsafe_view.default(bmm_62, [1, 8, 128, 128]);  bmm_62 = None
    mul_166 = torch.ops.aten.mul.Tensor(_unsafe_view_132, 0.0625);  _unsafe_view_132 = None
    add_106 = torch.ops.aten.add.Tensor(mul_166, unsqueeze_1);  mul_166 = None
    _to_copy_123 = torch.ops.aten._to_copy.default(add_106, dtype = torch.float32, layout = torch.strided, device = device(type='meta'));  add_106 = None
    _softmax_1 = torch.ops.aten._softmax.default(_to_copy_123, -1, False);  _to_copy_123 = None
    _to_copy_124 = torch.ops.aten._to_copy.default(_softmax_1, dtype = torch.bfloat16);  _softmax_1 = None
    expand_132 = torch.ops.aten.expand.default(_to_copy_124, [1, 8, 128, 128]);  _to_copy_124 = None
    view_266 = torch.ops.aten.view.default(expand_132, [8, 128, 128]);  expand_132 = None
    expand_133 = torch.ops.aten.expand.default(_unsafe_view_131, [1, 8, 128, 256]);  _unsafe_view_131 = None
    view_267 = torch.ops.aten.view.default(expand_133, [8, 128, 256]);  expand_133 = None
    bmm_63 = torch.ops.aten.bmm.default(view_266, view_267);  view_266 = view_267 = None
    _unsafe_view_133 = torch.ops.aten._unsafe_view.default(bmm_63, [1, 8, 128, 256]);  bmm_63 = None
    transpose_81 = torch.ops.aten.transpose.int(_unsafe_view_133, 1, 2);  _unsafe_view_133 = None
    clone_13 = torch.ops.aten.clone.default(transpose_81, memory_format = torch.contiguous_format);  transpose_81 = None
    view_268 = torch.ops.aten.view.default(clone_13, [1, 128, -1]);  clone_13 = None
    sigmoid_7 = torch.ops.aten.sigmoid.default(_unsafe_view_127);  _unsafe_view_127 = None
    mul_167 = torch.ops.aten.mul.Tensor(view_268, sigmoid_7);  view_268 = sigmoid_7 = None
    _param_constant102 = self._param_constant102
    t_58 = torch.ops.aten.t.default(_param_constant102);  _param_constant102 = None
    view_269 = torch.ops.aten.view.default(mul_167, [128, 2048]);  mul_167 = None
    mm_58 = torch.ops.aten.mm.default(view_269, t_58);  view_269 = t_58 = None
    _unsafe_view_134 = torch.ops.aten._unsafe_view.default(mm_58, [1, 128, 2048]);  mm_58 = None
    add_107 = torch.ops.aten.add.Tensor(add_97, _unsafe_view_134);  add_97 = _unsafe_view_134 = None
    _to_copy_125 = torch.ops.aten._to_copy.default(add_107, dtype = torch.float32)
    pow_26 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_125, 2)
    mean_25 = torch.ops.aten.mean.dim(pow_26, [-1], True);  pow_26 = None
    add_108 = torch.ops.aten.add.Tensor(mean_25, 1e-06);  mean_25 = None
    rsqrt_37 = torch.ops.aten.rsqrt.default(add_108);  add_108 = None
    mul_168 = torch.ops.aten.mul.Tensor(_to_copy_125, rsqrt_37);  _to_copy_125 = rsqrt_37 = None
    _param_constant103 = self._param_constant103
    _to_copy_126 = torch.ops.aten._to_copy.default(_param_constant103, dtype = torch.float32);  _param_constant103 = None
    add_109 = torch.ops.aten.add.Tensor(_to_copy_126, 1.0);  _to_copy_126 = None
    mul_169 = torch.ops.aten.mul.Tensor(mul_168, add_109);  mul_168 = add_109 = None
    _to_copy_127 = torch.ops.aten._to_copy.default(mul_169, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_169 = None
    _param_constant104 = self._param_constant104
    t_59 = torch.ops.aten.t.default(_param_constant104);  _param_constant104 = None
    view_270 = torch.ops.aten.view.default(_to_copy_127, [128, 2048])
    mm_59 = torch.ops.aten.mm.default(view_270, t_59);  view_270 = t_59 = None
    _unsafe_view_135 = torch.ops.aten._unsafe_view.default(mm_59, [1, 128, 6144]);  mm_59 = None
    silu_19 = torch.ops.aten.silu.default(_unsafe_view_135);  _unsafe_view_135 = None
    _param_constant105 = self._param_constant105
    t_60 = torch.ops.aten.t.default(_param_constant105);  _param_constant105 = None
    view_271 = torch.ops.aten.view.default(_to_copy_127, [128, 2048]);  _to_copy_127 = None
    mm_60 = torch.ops.aten.mm.default(view_271, t_60);  view_271 = t_60 = None
    _unsafe_view_136 = torch.ops.aten._unsafe_view.default(mm_60, [1, 128, 6144]);  mm_60 = None
    mul_170 = torch.ops.aten.mul.Tensor(silu_19, _unsafe_view_136);  silu_19 = _unsafe_view_136 = None
    _param_constant106 = self._param_constant106
    t_61 = torch.ops.aten.t.default(_param_constant106);  _param_constant106 = None
    view_272 = torch.ops.aten.view.default(mul_170, [128, 6144]);  mul_170 = None
    mm_61 = torch.ops.aten.mm.default(view_272, t_61);  view_272 = t_61 = None
    _unsafe_view_137 = torch.ops.aten._unsafe_view.default(mm_61, [1, 128, 2048]);  mm_61 = None
    add_110 = torch.ops.aten.add.Tensor(add_107, _unsafe_view_137);  add_107 = _unsafe_view_137 = None
    _to_copy_128 = torch.ops.aten._to_copy.default(add_110, dtype = torch.float32)
    pow_27 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_128, 2)
    mean_26 = torch.ops.aten.mean.dim(pow_27, [-1], True);  pow_27 = None
    add_111 = torch.ops.aten.add.Tensor(mean_26, 1e-06);  mean_26 = None
    rsqrt_38 = torch.ops.aten.rsqrt.default(add_111);  add_111 = None
    mul_171 = torch.ops.aten.mul.Tensor(_to_copy_128, rsqrt_38);  _to_copy_128 = rsqrt_38 = None
    _param_constant107 = self._param_constant107
    _to_copy_129 = torch.ops.aten._to_copy.default(_param_constant107, dtype = torch.float32);  _param_constant107 = None
    add_112 = torch.ops.aten.add.Tensor(_to_copy_129, 1.0);  _to_copy_129 = None
    mul_172 = torch.ops.aten.mul.Tensor(mul_171, add_112);  mul_171 = add_112 = None
    _to_copy_130 = torch.ops.aten._to_copy.default(mul_172, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_172 = None
    _param_constant108 = self._param_constant108
    t_62 = torch.ops.aten.t.default(_param_constant108);  _param_constant108 = None
    view_273 = torch.ops.aten.view.default(_to_copy_130, [128, 2048])
    mm_62 = torch.ops.aten.mm.default(view_273, t_62);  view_273 = t_62 = None
    _unsafe_view_138 = torch.ops.aten._unsafe_view.default(mm_62, [1, 128, 6144]);  mm_62 = None
    transpose_82 = torch.ops.aten.transpose.int(_unsafe_view_138, 1, 2);  _unsafe_view_138 = None
    _param_constant109 = self._param_constant109
    t_63 = torch.ops.aten.t.default(_param_constant109);  _param_constant109 = None
    view_274 = torch.ops.aten.view.default(_to_copy_130, [128, 2048])
    mm_63 = torch.ops.aten.mm.default(view_274, t_63);  view_274 = t_63 = None
    _unsafe_view_139 = torch.ops.aten._unsafe_view.default(mm_63, [1, 128, 2048]);  mm_63 = None
    view_275 = torch.ops.aten.view.default(_unsafe_view_139, [1, 128, -1, 128]);  _unsafe_view_139 = None
    _param_constant110 = self._param_constant110
    t_64 = torch.ops.aten.t.default(_param_constant110);  _param_constant110 = None
    view_276 = torch.ops.aten.view.default(_to_copy_130, [128, 2048])
    mm_64 = torch.ops.aten.mm.default(view_276, t_64);  view_276 = t_64 = None
    _unsafe_view_140 = torch.ops.aten._unsafe_view.default(mm_64, [1, 128, 16]);  mm_64 = None
    _param_constant111 = self._param_constant111
    t_65 = torch.ops.aten.t.default(_param_constant111);  _param_constant111 = None
    view_277 = torch.ops.aten.view.default(_to_copy_130, [128, 2048]);  _to_copy_130 = None
    mm_65 = torch.ops.aten.mm.default(view_277, t_65);  view_277 = t_65 = None
    _unsafe_view_141 = torch.ops.aten._unsafe_view.default(mm_65, [1, 128, 16]);  mm_65 = None
    _param_constant112 = self._param_constant112
    squeeze_6 = torch.ops.aten.squeeze.dim(_param_constant112, 1);  _param_constant112 = None
    unsqueeze_71 = torch.ops.aten.unsqueeze.default(squeeze_6, 1);  squeeze_6 = None
    convolution_6 = torch.ops.aten.convolution.default(transpose_82, unsqueeze_71, None, [1], [3], [1], False, [0], 6144);  transpose_82 = unsqueeze_71 = None
    slice_38 = torch.ops.aten.slice.Tensor(convolution_6, 2, 0, 128);  convolution_6 = None
    silu_20 = torch.ops.aten.silu.default(slice_38);  slice_38 = None
    transpose_83 = torch.ops.aten.transpose.int(silu_20, 1, 2);  silu_20 = None
    split_with_sizes_6 = torch.ops.aten.split_with_sizes.default(transpose_83, [2048, 2048, 2048], -1);  transpose_83 = None
    getitem_22 = split_with_sizes_6[0]
    getitem_23 = split_with_sizes_6[1]
    getitem_24 = split_with_sizes_6[2];  split_with_sizes_6 = None
    view_278 = torch.ops.aten.view.default(getitem_22, [1, 128, 16, 128]);  getitem_22 = None
    view_279 = torch.ops.aten.view.default(getitem_23, [1, 128, 16, 128]);  getitem_23 = None
    view_280 = torch.ops.aten.view.default(getitem_24, [1, 128, 16, 128]);  getitem_24 = None
    sigmoid_8 = torch.ops.aten.sigmoid.default(_unsafe_view_140);  _unsafe_view_140 = None
    _param_constant113 = self._param_constant113
    exp_36 = torch.ops.aten.exp.default(_param_constant113);  _param_constant113 = None
    neg_10 = torch.ops.aten.neg.default(exp_36);  exp_36 = None
    _to_copy_131 = torch.ops.aten._to_copy.default(_unsafe_view_141, dtype = torch.float32);  _unsafe_view_141 = None
    _param_constant114 = self._param_constant114
    add_113 = torch.ops.aten.add.Tensor(_to_copy_131, _param_constant114);  _to_copy_131 = _param_constant114 = None
    softplus_6 = torch.ops.aten.softplus.default(add_113);  add_113 = None
    mul_173 = torch.ops.aten.mul.Tensor(neg_10, softplus_6);  neg_10 = softplus_6 = None
    transpose_84 = torch.ops.aten.transpose.int(view_278, 1, 2);  view_278 = None
    _to_copy_132 = torch.ops.aten._to_copy.default(transpose_84, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_84 = None
    transpose_85 = torch.ops.aten.transpose.int(view_279, 1, 2);  view_279 = None
    _to_copy_133 = torch.ops.aten._to_copy.default(transpose_85, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_85 = None
    transpose_86 = torch.ops.aten.transpose.int(view_280, 1, 2);  view_280 = None
    _to_copy_134 = torch.ops.aten._to_copy.default(transpose_86, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_86 = None
    transpose_87 = torch.ops.aten.transpose.int(sigmoid_8, 1, 2);  sigmoid_8 = None
    _to_copy_135 = torch.ops.aten._to_copy.default(transpose_87, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_87 = None
    transpose_88 = torch.ops.aten.transpose.int(mul_173, 1, 2);  mul_173 = None
    mul_174 = torch.ops.aten.mul.Tensor(_to_copy_132, _to_copy_132)
    sum_13 = torch.ops.aten.sum.dim_IntList(mul_174, [-1], True);  mul_174 = None
    add_114 = torch.ops.aten.add.Tensor(sum_13, 1e-06);  sum_13 = None
    rsqrt_39 = torch.ops.aten.rsqrt.default(add_114);  add_114 = None
    mul_175 = torch.ops.aten.mul.Tensor(_to_copy_132, rsqrt_39);  _to_copy_132 = rsqrt_39 = None
    mul_176 = torch.ops.aten.mul.Tensor(_to_copy_133, _to_copy_133)
    sum_14 = torch.ops.aten.sum.dim_IntList(mul_176, [-1], True);  mul_176 = None
    add_115 = torch.ops.aten.add.Tensor(sum_14, 1e-06);  sum_14 = None
    rsqrt_40 = torch.ops.aten.rsqrt.default(add_115);  add_115 = None
    mul_177 = torch.ops.aten.mul.Tensor(_to_copy_133, rsqrt_40);  _to_copy_133 = rsqrt_40 = None
    mul_178 = torch.ops.aten.mul.Tensor(mul_175, 0.08838834764831845);  mul_175 = None
    constant_pad_nd_30 = torch.ops.aten.constant_pad_nd.default(mul_178, [0, 0, 0, 0], 0.0);  mul_178 = None
    constant_pad_nd_31 = torch.ops.aten.constant_pad_nd.default(mul_177, [0, 0, 0, 0], 0.0);  mul_177 = None
    constant_pad_nd_32 = torch.ops.aten.constant_pad_nd.default(_to_copy_134, [0, 0, 0, 0], 0.0);  _to_copy_134 = None
    constant_pad_nd_33 = torch.ops.aten.constant_pad_nd.default(_to_copy_135, [0, 0], 0.0);  _to_copy_135 = None
    constant_pad_nd_34 = torch.ops.aten.constant_pad_nd.default(transpose_88, [0, 0], 0.0);  transpose_88 = None
    unsqueeze_72 = torch.ops.aten.unsqueeze.default(constant_pad_nd_33, -1)
    mul_179 = torch.ops.aten.mul.Tensor(constant_pad_nd_32, unsqueeze_72);  constant_pad_nd_32 = unsqueeze_72 = None
    unsqueeze_73 = torch.ops.aten.unsqueeze.default(constant_pad_nd_33, -1);  constant_pad_nd_33 = None
    mul_180 = torch.ops.aten.mul.Tensor(constant_pad_nd_31, unsqueeze_73);  unsqueeze_73 = None
    view_281 = torch.ops.aten.view.default(constant_pad_nd_30, [1, 16, -1, 64, 128]);  constant_pad_nd_30 = None
    view_282 = torch.ops.aten.view.default(constant_pad_nd_31, [1, 16, -1, 64, 128]);  constant_pad_nd_31 = None
    view_283 = torch.ops.aten.view.default(mul_180, [1, 16, -1, 64, 128]);  mul_180 = None
    view_284 = torch.ops.aten.view.default(mul_179, [1, 16, -1, 64, 128]);  mul_179 = None
    view_285 = torch.ops.aten.view.default(constant_pad_nd_34, [1, 16, 2, 64]);  constant_pad_nd_34 = None
    ones_6 = torch.ops.aten.ones.default([64, 64], dtype = torch.bool, device = device(type='meta'), pin_memory = False)
    triu_7 = torch.ops.aten.triu.default(ones_6, 1);  ones_6 = None
    cumsum_6 = torch.ops.aten.cumsum.default(view_285, 3);  view_285 = None
    unsqueeze_74 = torch.ops.aten.unsqueeze.default(cumsum_6, 4)
    unsqueeze_75 = torch.ops.aten.unsqueeze.default(cumsum_6, 3)
    sub_24 = torch.ops.aten.sub.Tensor(unsqueeze_74, unsqueeze_75);  unsqueeze_74 = unsqueeze_75 = None
    masked_fill_6 = torch.ops.aten.masked_fill.Scalar(sub_24, triu_7, -inf);  sub_24 = triu_7 = None
    exp_37 = torch.ops.aten.exp.default(masked_fill_6);  masked_fill_6 = None
    transpose_89 = torch.ops.aten.transpose.int(view_282, -1, -2)
    expand_134 = torch.ops.aten.expand.default(view_283, [1, 16, 2, 64, 128])
    view_286 = torch.ops.aten.view.default(expand_134, [32, 64, 128]);  expand_134 = None
    expand_135 = torch.ops.aten.expand.default(transpose_89, [1, 16, 2, 128, 64]);  transpose_89 = None
    view_287 = torch.ops.aten.view.default(expand_135, [32, 128, 64]);  expand_135 = None
    bmm_64 = torch.ops.aten.bmm.default(view_286, view_287);  view_286 = view_287 = None
    _unsafe_view_142 = torch.ops.aten._unsafe_view.default(bmm_64, [1, 16, 2, 64, 64]);  bmm_64 = None
    mul_181 = torch.ops.aten.mul.Tensor(_unsafe_view_142, exp_37);  _unsafe_view_142 = None
    transpose_90 = torch.ops.aten.transpose.int(view_282, -1, -2)
    expand_136 = torch.ops.aten.expand.default(view_281, [1, 16, 2, 64, 128])
    view_288 = torch.ops.aten.view.default(expand_136, [32, 64, 128]);  expand_136 = None
    expand_137 = torch.ops.aten.expand.default(transpose_90, [1, 16, 2, 128, 64]);  transpose_90 = None
    view_289 = torch.ops.aten.view.default(expand_137, [32, 128, 64]);  expand_137 = None
    bmm_65 = torch.ops.aten.bmm.default(view_288, view_289);  view_288 = view_289 = None
    _unsafe_view_143 = torch.ops.aten._unsafe_view.default(bmm_65, [1, 16, 2, 64, 64]);  bmm_65 = None
    mul_182 = torch.ops.aten.mul.Tensor(_unsafe_view_143, exp_37);  _unsafe_view_143 = exp_37 = None
    exp_38 = torch.ops.aten.exp.default(cumsum_6)
    unsqueeze_76 = torch.ops.aten.unsqueeze.default(exp_38, -1);  exp_38 = None
    mul_183 = torch.ops.aten.mul.Tensor(view_283, unsqueeze_76);  view_283 = unsqueeze_76 = None
    linalg_solve_triangular_12 = torch.ops.aten.linalg_solve_triangular.default(mul_181, view_284, upper = False, unitriangular = True);  view_284 = None
    linalg_solve_triangular_13 = torch.ops.aten.linalg_solve_triangular.default(mul_181, mul_183, upper = False, unitriangular = True);  mul_181 = mul_183 = None
    zeros_6 = torch.ops.aten.zeros.default([1, 16, 128, 128], dtype = torch.float32, device = device(type='meta'), pin_memory = False)
    zeros_like_6 = torch.ops.aten.zeros_like.default(linalg_solve_triangular_12, pin_memory = False)
    exp_39 = torch.ops.aten.exp.default(cumsum_6)
    unsqueeze_77 = torch.ops.aten.unsqueeze.default(exp_39, -1);  exp_39 = None
    mul_184 = torch.ops.aten.mul.Tensor(view_281, unsqueeze_77);  view_281 = unsqueeze_77 = None
    slice_39 = torch.ops.aten.slice.Tensor(cumsum_6, 3, -1, 9223372036854775807)
    sub_25 = torch.ops.aten.sub.Tensor(slice_39, cumsum_6);  slice_39 = None
    exp_40 = torch.ops.aten.exp.default(sub_25);  sub_25 = None
    unsqueeze_78 = torch.ops.aten.unsqueeze.default(exp_40, -1);  exp_40 = None
    mul_185 = torch.ops.aten.mul.Tensor(view_282, unsqueeze_78);  view_282 = unsqueeze_78 = None
    select_97 = torch.ops.aten.select.int(cumsum_6, 3, -1);  cumsum_6 = None
    exp_41 = torch.ops.aten.exp.default(select_97);  select_97 = None
    unsqueeze_79 = torch.ops.aten.unsqueeze.default(exp_41, 3);  exp_41 = None
    unsqueeze_80 = torch.ops.aten.unsqueeze.default(unsqueeze_79, 4);  unsqueeze_79 = None
    select_98 = torch.ops.aten.select.int(linalg_solve_triangular_12, 2, 0)
    select_99 = torch.ops.aten.select.int(linalg_solve_triangular_13, 2, 0)
    expand_138 = torch.ops.aten.expand.default(select_99, [1, 16, 64, 128]);  select_99 = None
    view_290 = torch.ops.aten.view.default(expand_138, [16, 64, 128]);  expand_138 = None
    expand_139 = torch.ops.aten.expand.default(zeros_6, [1, 16, 128, 128])
    view_291 = torch.ops.aten.view.default(expand_139, [16, 128, 128]);  expand_139 = None
    bmm_66 = torch.ops.aten.bmm.default(view_290, view_291);  view_290 = view_291 = None
    _unsafe_view_144 = torch.ops.aten._unsafe_view.default(bmm_66, [1, 16, 64, 128]);  bmm_66 = None
    sub_26 = torch.ops.aten.sub.Tensor(select_98, _unsafe_view_144);  select_98 = _unsafe_view_144 = None
    select_100 = torch.ops.aten.select.int(mul_184, 2, 0)
    expand_140 = torch.ops.aten.expand.default(select_100, [1, 16, 64, 128]);  select_100 = None
    view_292 = torch.ops.aten.view.default(expand_140, [16, 64, 128]);  expand_140 = None
    expand_141 = torch.ops.aten.expand.default(zeros_6, [1, 16, 128, 128])
    view_293 = torch.ops.aten.view.default(expand_141, [16, 128, 128]);  expand_141 = None
    bmm_67 = torch.ops.aten.bmm.default(view_292, view_293);  view_292 = view_293 = None
    _unsafe_view_145 = torch.ops.aten._unsafe_view.default(bmm_67, [1, 16, 64, 128]);  bmm_67 = None
    select_101 = torch.ops.aten.select.int(mul_182, 2, 0)
    expand_142 = torch.ops.aten.expand.default(select_101, [1, 16, 64, 64]);  select_101 = None
    view_294 = torch.ops.aten.view.default(expand_142, [16, 64, 64]);  expand_142 = None
    expand_143 = torch.ops.aten.expand.default(sub_26, [1, 16, 64, 128])
    view_295 = torch.ops.aten.view.default(expand_143, [16, 64, 128]);  expand_143 = None
    bmm_68 = torch.ops.aten.bmm.default(view_294, view_295);  view_294 = view_295 = None
    _unsafe_view_146 = torch.ops.aten._unsafe_view.default(bmm_68, [1, 16, 64, 128]);  bmm_68 = None
    add_116 = torch.ops.aten.add.Tensor(_unsafe_view_145, _unsafe_view_146);  _unsafe_view_145 = _unsafe_view_146 = None
    select_102 = torch.ops.aten.select.int(zeros_like_6, 2, 0)
    copy__16 = torch.ops.aten.copy_.default(select_102, add_116);  select_102 = add_116 = copy__16 = None
    select_103 = torch.ops.aten.select.int(unsqueeze_80, 2, 0)
    mul_186 = torch.ops.aten.mul.Tensor(zeros_6, select_103);  zeros_6 = select_103 = None
    select_104 = torch.ops.aten.select.int(mul_185, 2, 0)
    transpose_91 = torch.ops.aten.transpose.int(select_104, -1, -2);  select_104 = None
    expand_144 = torch.ops.aten.expand.default(transpose_91, [1, 16, 128, 64]);  transpose_91 = None
    view_296 = torch.ops.aten.view.default(expand_144, [16, 128, 64]);  expand_144 = None
    expand_145 = torch.ops.aten.expand.default(sub_26, [1, 16, 64, 128]);  sub_26 = None
    view_297 = torch.ops.aten.view.default(expand_145, [16, 64, 128]);  expand_145 = None
    bmm_69 = torch.ops.aten.bmm.default(view_296, view_297);  view_296 = view_297 = None
    _unsafe_view_147 = torch.ops.aten._unsafe_view.default(bmm_69, [1, 16, 128, 128]);  bmm_69 = None
    add_117 = torch.ops.aten.add.Tensor(mul_186, _unsafe_view_147);  mul_186 = _unsafe_view_147 = None
    select_105 = torch.ops.aten.select.int(linalg_solve_triangular_12, 2, 1);  linalg_solve_triangular_12 = None
    select_106 = torch.ops.aten.select.int(linalg_solve_triangular_13, 2, 1);  linalg_solve_triangular_13 = None
    expand_146 = torch.ops.aten.expand.default(select_106, [1, 16, 64, 128]);  select_106 = None
    view_298 = torch.ops.aten.view.default(expand_146, [16, 64, 128]);  expand_146 = None
    expand_147 = torch.ops.aten.expand.default(add_117, [1, 16, 128, 128])
    view_299 = torch.ops.aten.view.default(expand_147, [16, 128, 128]);  expand_147 = None
    bmm_70 = torch.ops.aten.bmm.default(view_298, view_299);  view_298 = view_299 = None
    _unsafe_view_148 = torch.ops.aten._unsafe_view.default(bmm_70, [1, 16, 64, 128]);  bmm_70 = None
    sub_27 = torch.ops.aten.sub.Tensor(select_105, _unsafe_view_148);  select_105 = _unsafe_view_148 = None
    select_107 = torch.ops.aten.select.int(mul_184, 2, 1);  mul_184 = None
    expand_148 = torch.ops.aten.expand.default(select_107, [1, 16, 64, 128]);  select_107 = None
    view_300 = torch.ops.aten.view.default(expand_148, [16, 64, 128]);  expand_148 = None
    expand_149 = torch.ops.aten.expand.default(add_117, [1, 16, 128, 128])
    view_301 = torch.ops.aten.view.default(expand_149, [16, 128, 128]);  expand_149 = None
    bmm_71 = torch.ops.aten.bmm.default(view_300, view_301);  view_300 = view_301 = None
    _unsafe_view_149 = torch.ops.aten._unsafe_view.default(bmm_71, [1, 16, 64, 128]);  bmm_71 = None
    select_108 = torch.ops.aten.select.int(mul_182, 2, 1);  mul_182 = None
    expand_150 = torch.ops.aten.expand.default(select_108, [1, 16, 64, 64]);  select_108 = None
    view_302 = torch.ops.aten.view.default(expand_150, [16, 64, 64]);  expand_150 = None
    expand_151 = torch.ops.aten.expand.default(sub_27, [1, 16, 64, 128])
    view_303 = torch.ops.aten.view.default(expand_151, [16, 64, 128]);  expand_151 = None
    bmm_72 = torch.ops.aten.bmm.default(view_302, view_303);  view_302 = view_303 = None
    _unsafe_view_150 = torch.ops.aten._unsafe_view.default(bmm_72, [1, 16, 64, 128]);  bmm_72 = None
    add_118 = torch.ops.aten.add.Tensor(_unsafe_view_149, _unsafe_view_150);  _unsafe_view_149 = _unsafe_view_150 = None
    select_109 = torch.ops.aten.select.int(zeros_like_6, 2, 1)
    copy__17 = torch.ops.aten.copy_.default(select_109, add_118);  select_109 = add_118 = copy__17 = None
    select_110 = torch.ops.aten.select.int(unsqueeze_80, 2, 1);  unsqueeze_80 = None
    mul_187 = torch.ops.aten.mul.Tensor(add_117, select_110);  add_117 = select_110 = None
    select_111 = torch.ops.aten.select.int(mul_185, 2, 1);  mul_185 = None
    transpose_92 = torch.ops.aten.transpose.int(select_111, -1, -2);  select_111 = None
    expand_152 = torch.ops.aten.expand.default(transpose_92, [1, 16, 128, 64]);  transpose_92 = None
    view_304 = torch.ops.aten.view.default(expand_152, [16, 128, 64]);  expand_152 = None
    expand_153 = torch.ops.aten.expand.default(sub_27, [1, 16, 64, 128]);  sub_27 = None
    view_305 = torch.ops.aten.view.default(expand_153, [16, 64, 128]);  expand_153 = None
    bmm_73 = torch.ops.aten.bmm.default(view_304, view_305);  view_304 = view_305 = None
    _unsafe_view_151 = torch.ops.aten._unsafe_view.default(bmm_73, [1, 16, 128, 128]);  bmm_73 = None
    add_119 = torch.ops.aten.add.Tensor(mul_187, _unsafe_view_151);  mul_187 = _unsafe_view_151 = add_119 = None
    clone_14 = torch.ops.aten.clone.default(zeros_like_6, memory_format = torch.contiguous_format);  zeros_like_6 = None
    _unsafe_view_152 = torch.ops.aten._unsafe_view.default(clone_14, [1, 16, 128, 128]);  clone_14 = None
    alias_6 = torch.ops.aten.alias.default(_unsafe_view_152);  _unsafe_view_152 = None
    transpose_93 = torch.ops.aten.transpose.int(alias_6, 1, 2);  alias_6 = None
    _to_copy_136 = torch.ops.aten._to_copy.default(transpose_93, dtype = torch.bfloat16, memory_format = torch.contiguous_format);  transpose_93 = None
    view_306 = torch.ops.aten.view.default(_to_copy_136, [-1, 128]);  _to_copy_136 = None
    view_307 = torch.ops.aten.view.default(view_275, [-1, 128]);  view_275 = None
    _to_copy_137 = torch.ops.aten._to_copy.default(view_306, dtype = torch.float32);  view_306 = None
    pow_28 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_137, 2)
    mean_27 = torch.ops.aten.mean.dim(pow_28, [-1], True);  pow_28 = None
    add_120 = torch.ops.aten.add.Tensor(mean_27, 1e-06);  mean_27 = None
    rsqrt_41 = torch.ops.aten.rsqrt.default(add_120);  add_120 = None
    mul_188 = torch.ops.aten.mul.Tensor(_to_copy_137, rsqrt_41);  _to_copy_137 = rsqrt_41 = None
    _to_copy_138 = torch.ops.aten._to_copy.default(mul_188, dtype = torch.bfloat16);  mul_188 = None
    _param_constant115 = self._param_constant115
    mul_189 = torch.ops.aten.mul.Tensor(_param_constant115, _to_copy_138);  _param_constant115 = _to_copy_138 = None
    _to_copy_139 = torch.ops.aten._to_copy.default(view_307, dtype = torch.float32);  view_307 = None
    silu_21 = torch.ops.aten.silu.default(_to_copy_139);  _to_copy_139 = None
    mul_190 = torch.ops.aten.mul.Tensor(mul_189, silu_21);  mul_189 = silu_21 = None
    _to_copy_140 = torch.ops.aten._to_copy.default(mul_190, dtype = torch.bfloat16);  mul_190 = None
    view_308 = torch.ops.aten.view.default(_to_copy_140, [1, 128, -1]);  _to_copy_140 = None
    _param_constant116 = self._param_constant116
    t_66 = torch.ops.aten.t.default(_param_constant116);  _param_constant116 = None
    view_309 = torch.ops.aten.view.default(view_308, [128, 2048]);  view_308 = None
    mm_66 = torch.ops.aten.mm.default(view_309, t_66);  view_309 = t_66 = None
    _unsafe_view_153 = torch.ops.aten._unsafe_view.default(mm_66, [1, 128, 2048]);  mm_66 = None
    add_121 = torch.ops.aten.add.Tensor(add_110, _unsafe_view_153);  add_110 = _unsafe_view_153 = None
    _to_copy_141 = torch.ops.aten._to_copy.default(add_121, dtype = torch.float32)
    pow_29 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_141, 2)
    mean_28 = torch.ops.aten.mean.dim(pow_29, [-1], True);  pow_29 = None
    add_122 = torch.ops.aten.add.Tensor(mean_28, 1e-06);  mean_28 = None
    rsqrt_42 = torch.ops.aten.rsqrt.default(add_122);  add_122 = None
    mul_191 = torch.ops.aten.mul.Tensor(_to_copy_141, rsqrt_42);  _to_copy_141 = rsqrt_42 = None
    _param_constant117 = self._param_constant117
    _to_copy_142 = torch.ops.aten._to_copy.default(_param_constant117, dtype = torch.float32);  _param_constant117 = None
    add_123 = torch.ops.aten.add.Tensor(_to_copy_142, 1.0);  _to_copy_142 = None
    mul_192 = torch.ops.aten.mul.Tensor(mul_191, add_123);  mul_191 = add_123 = None
    _to_copy_143 = torch.ops.aten._to_copy.default(mul_192, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_192 = None
    _param_constant118 = self._param_constant118
    t_67 = torch.ops.aten.t.default(_param_constant118);  _param_constant118 = None
    view_310 = torch.ops.aten.view.default(_to_copy_143, [128, 2048])
    mm_67 = torch.ops.aten.mm.default(view_310, t_67);  view_310 = t_67 = None
    _unsafe_view_154 = torch.ops.aten._unsafe_view.default(mm_67, [1, 128, 6144]);  mm_67 = None
    silu_22 = torch.ops.aten.silu.default(_unsafe_view_154);  _unsafe_view_154 = None
    _param_constant119 = self._param_constant119
    t_68 = torch.ops.aten.t.default(_param_constant119);  _param_constant119 = None
    view_311 = torch.ops.aten.view.default(_to_copy_143, [128, 2048]);  _to_copy_143 = None
    mm_68 = torch.ops.aten.mm.default(view_311, t_68);  view_311 = t_68 = None
    _unsafe_view_155 = torch.ops.aten._unsafe_view.default(mm_68, [1, 128, 6144]);  mm_68 = None
    mul_193 = torch.ops.aten.mul.Tensor(silu_22, _unsafe_view_155);  silu_22 = _unsafe_view_155 = None
    _param_constant120 = self._param_constant120
    t_69 = torch.ops.aten.t.default(_param_constant120);  _param_constant120 = None
    view_312 = torch.ops.aten.view.default(mul_193, [128, 6144]);  mul_193 = None
    mm_69 = torch.ops.aten.mm.default(view_312, t_69);  view_312 = t_69 = None
    _unsafe_view_156 = torch.ops.aten._unsafe_view.default(mm_69, [1, 128, 2048]);  mm_69 = None
    add_124 = torch.ops.aten.add.Tensor(add_121, _unsafe_view_156);  add_121 = _unsafe_view_156 = None
    _to_copy_144 = torch.ops.aten._to_copy.default(add_124, dtype = torch.float32)
    pow_30 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_144, 2)
    mean_29 = torch.ops.aten.mean.dim(pow_30, [-1], True);  pow_30 = None
    add_125 = torch.ops.aten.add.Tensor(mean_29, 1e-06);  mean_29 = None
    rsqrt_43 = torch.ops.aten.rsqrt.default(add_125);  add_125 = None
    mul_194 = torch.ops.aten.mul.Tensor(_to_copy_144, rsqrt_43);  _to_copy_144 = rsqrt_43 = None
    _param_constant121 = self._param_constant121
    _to_copy_145 = torch.ops.aten._to_copy.default(_param_constant121, dtype = torch.float32);  _param_constant121 = None
    add_126 = torch.ops.aten.add.Tensor(_to_copy_145, 1.0);  _to_copy_145 = None
    mul_195 = torch.ops.aten.mul.Tensor(mul_194, add_126);  mul_194 = add_126 = None
    _to_copy_146 = torch.ops.aten._to_copy.default(mul_195, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_195 = None
    _param_constant122 = self._param_constant122
    t_70 = torch.ops.aten.t.default(_param_constant122);  _param_constant122 = None
    view_313 = torch.ops.aten.view.default(_to_copy_146, [128, 2048])
    mm_70 = torch.ops.aten.mm.default(view_313, t_70);  view_313 = t_70 = None
    _unsafe_view_157 = torch.ops.aten._unsafe_view.default(mm_70, [1, 128, 6144]);  mm_70 = None
    transpose_94 = torch.ops.aten.transpose.int(_unsafe_view_157, 1, 2);  _unsafe_view_157 = None
    _param_constant123 = self._param_constant123
    t_71 = torch.ops.aten.t.default(_param_constant123);  _param_constant123 = None
    view_314 = torch.ops.aten.view.default(_to_copy_146, [128, 2048])
    mm_71 = torch.ops.aten.mm.default(view_314, t_71);  view_314 = t_71 = None
    _unsafe_view_158 = torch.ops.aten._unsafe_view.default(mm_71, [1, 128, 2048]);  mm_71 = None
    view_315 = torch.ops.aten.view.default(_unsafe_view_158, [1, 128, -1, 128]);  _unsafe_view_158 = None
    _param_constant124 = self._param_constant124
    t_72 = torch.ops.aten.t.default(_param_constant124);  _param_constant124 = None
    view_316 = torch.ops.aten.view.default(_to_copy_146, [128, 2048])
    mm_72 = torch.ops.aten.mm.default(view_316, t_72);  view_316 = t_72 = None
    _unsafe_view_159 = torch.ops.aten._unsafe_view.default(mm_72, [1, 128, 16]);  mm_72 = None
    _param_constant125 = self._param_constant125
    t_73 = torch.ops.aten.t.default(_param_constant125);  _param_constant125 = None
    view_317 = torch.ops.aten.view.default(_to_copy_146, [128, 2048]);  _to_copy_146 = None
    mm_73 = torch.ops.aten.mm.default(view_317, t_73);  view_317 = t_73 = None
    _unsafe_view_160 = torch.ops.aten._unsafe_view.default(mm_73, [1, 128, 16]);  mm_73 = None
    _param_constant126 = self._param_constant126
    squeeze_7 = torch.ops.aten.squeeze.dim(_param_constant126, 1);  _param_constant126 = None
    unsqueeze_81 = torch.ops.aten.unsqueeze.default(squeeze_7, 1);  squeeze_7 = None
    convolution_7 = torch.ops.aten.convolution.default(transpose_94, unsqueeze_81, None, [1], [3], [1], False, [0], 6144);  transpose_94 = unsqueeze_81 = None
    slice_40 = torch.ops.aten.slice.Tensor(convolution_7, 2, 0, 128);  convolution_7 = None
    silu_23 = torch.ops.aten.silu.default(slice_40);  slice_40 = None
    transpose_95 = torch.ops.aten.transpose.int(silu_23, 1, 2);  silu_23 = None
    split_with_sizes_7 = torch.ops.aten.split_with_sizes.default(transpose_95, [2048, 2048, 2048], -1);  transpose_95 = None
    getitem_25 = split_with_sizes_7[0]
    getitem_26 = split_with_sizes_7[1]
    getitem_27 = split_with_sizes_7[2];  split_with_sizes_7 = None
    view_318 = torch.ops.aten.view.default(getitem_25, [1, 128, 16, 128]);  getitem_25 = None
    view_319 = torch.ops.aten.view.default(getitem_26, [1, 128, 16, 128]);  getitem_26 = None
    view_320 = torch.ops.aten.view.default(getitem_27, [1, 128, 16, 128]);  getitem_27 = None
    sigmoid_9 = torch.ops.aten.sigmoid.default(_unsafe_view_159);  _unsafe_view_159 = None
    _param_constant127 = self._param_constant127
    exp_42 = torch.ops.aten.exp.default(_param_constant127);  _param_constant127 = None
    neg_11 = torch.ops.aten.neg.default(exp_42);  exp_42 = None
    _to_copy_147 = torch.ops.aten._to_copy.default(_unsafe_view_160, dtype = torch.float32);  _unsafe_view_160 = None
    _param_constant128 = self._param_constant128
    add_127 = torch.ops.aten.add.Tensor(_to_copy_147, _param_constant128);  _to_copy_147 = _param_constant128 = None
    softplus_7 = torch.ops.aten.softplus.default(add_127);  add_127 = None
    mul_196 = torch.ops.aten.mul.Tensor(neg_11, softplus_7);  neg_11 = softplus_7 = None
    transpose_96 = torch.ops.aten.transpose.int(view_318, 1, 2);  view_318 = None
    _to_copy_148 = torch.ops.aten._to_copy.default(transpose_96, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_96 = None
    transpose_97 = torch.ops.aten.transpose.int(view_319, 1, 2);  view_319 = None
    _to_copy_149 = torch.ops.aten._to_copy.default(transpose_97, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_97 = None
    transpose_98 = torch.ops.aten.transpose.int(view_320, 1, 2);  view_320 = None
    _to_copy_150 = torch.ops.aten._to_copy.default(transpose_98, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_98 = None
    transpose_99 = torch.ops.aten.transpose.int(sigmoid_9, 1, 2);  sigmoid_9 = None
    _to_copy_151 = torch.ops.aten._to_copy.default(transpose_99, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_99 = None
    transpose_100 = torch.ops.aten.transpose.int(mul_196, 1, 2);  mul_196 = None
    mul_197 = torch.ops.aten.mul.Tensor(_to_copy_148, _to_copy_148)
    sum_15 = torch.ops.aten.sum.dim_IntList(mul_197, [-1], True);  mul_197 = None
    add_128 = torch.ops.aten.add.Tensor(sum_15, 1e-06);  sum_15 = None
    rsqrt_44 = torch.ops.aten.rsqrt.default(add_128);  add_128 = None
    mul_198 = torch.ops.aten.mul.Tensor(_to_copy_148, rsqrt_44);  _to_copy_148 = rsqrt_44 = None
    mul_199 = torch.ops.aten.mul.Tensor(_to_copy_149, _to_copy_149)
    sum_16 = torch.ops.aten.sum.dim_IntList(mul_199, [-1], True);  mul_199 = None
    add_129 = torch.ops.aten.add.Tensor(sum_16, 1e-06);  sum_16 = None
    rsqrt_45 = torch.ops.aten.rsqrt.default(add_129);  add_129 = None
    mul_200 = torch.ops.aten.mul.Tensor(_to_copy_149, rsqrt_45);  _to_copy_149 = rsqrt_45 = None
    mul_201 = torch.ops.aten.mul.Tensor(mul_198, 0.08838834764831845);  mul_198 = None
    constant_pad_nd_35 = torch.ops.aten.constant_pad_nd.default(mul_201, [0, 0, 0, 0], 0.0);  mul_201 = None
    constant_pad_nd_36 = torch.ops.aten.constant_pad_nd.default(mul_200, [0, 0, 0, 0], 0.0);  mul_200 = None
    constant_pad_nd_37 = torch.ops.aten.constant_pad_nd.default(_to_copy_150, [0, 0, 0, 0], 0.0);  _to_copy_150 = None
    constant_pad_nd_38 = torch.ops.aten.constant_pad_nd.default(_to_copy_151, [0, 0], 0.0);  _to_copy_151 = None
    constant_pad_nd_39 = torch.ops.aten.constant_pad_nd.default(transpose_100, [0, 0], 0.0);  transpose_100 = None
    unsqueeze_82 = torch.ops.aten.unsqueeze.default(constant_pad_nd_38, -1)
    mul_202 = torch.ops.aten.mul.Tensor(constant_pad_nd_37, unsqueeze_82);  constant_pad_nd_37 = unsqueeze_82 = None
    unsqueeze_83 = torch.ops.aten.unsqueeze.default(constant_pad_nd_38, -1);  constant_pad_nd_38 = None
    mul_203 = torch.ops.aten.mul.Tensor(constant_pad_nd_36, unsqueeze_83);  unsqueeze_83 = None
    view_321 = torch.ops.aten.view.default(constant_pad_nd_35, [1, 16, -1, 64, 128]);  constant_pad_nd_35 = None
    view_322 = torch.ops.aten.view.default(constant_pad_nd_36, [1, 16, -1, 64, 128]);  constant_pad_nd_36 = None
    view_323 = torch.ops.aten.view.default(mul_203, [1, 16, -1, 64, 128]);  mul_203 = None
    view_324 = torch.ops.aten.view.default(mul_202, [1, 16, -1, 64, 128]);  mul_202 = None
    view_325 = torch.ops.aten.view.default(constant_pad_nd_39, [1, 16, 2, 64]);  constant_pad_nd_39 = None
    ones_7 = torch.ops.aten.ones.default([64, 64], dtype = torch.bool, device = device(type='meta'), pin_memory = False)
    triu_8 = torch.ops.aten.triu.default(ones_7, 1);  ones_7 = None
    cumsum_7 = torch.ops.aten.cumsum.default(view_325, 3);  view_325 = None
    unsqueeze_84 = torch.ops.aten.unsqueeze.default(cumsum_7, 4)
    unsqueeze_85 = torch.ops.aten.unsqueeze.default(cumsum_7, 3)
    sub_28 = torch.ops.aten.sub.Tensor(unsqueeze_84, unsqueeze_85);  unsqueeze_84 = unsqueeze_85 = None
    masked_fill_7 = torch.ops.aten.masked_fill.Scalar(sub_28, triu_8, -inf);  sub_28 = triu_8 = None
    exp_43 = torch.ops.aten.exp.default(masked_fill_7);  masked_fill_7 = None
    transpose_101 = torch.ops.aten.transpose.int(view_322, -1, -2)
    expand_154 = torch.ops.aten.expand.default(view_323, [1, 16, 2, 64, 128])
    view_326 = torch.ops.aten.view.default(expand_154, [32, 64, 128]);  expand_154 = None
    expand_155 = torch.ops.aten.expand.default(transpose_101, [1, 16, 2, 128, 64]);  transpose_101 = None
    view_327 = torch.ops.aten.view.default(expand_155, [32, 128, 64]);  expand_155 = None
    bmm_74 = torch.ops.aten.bmm.default(view_326, view_327);  view_326 = view_327 = None
    _unsafe_view_161 = torch.ops.aten._unsafe_view.default(bmm_74, [1, 16, 2, 64, 64]);  bmm_74 = None
    mul_204 = torch.ops.aten.mul.Tensor(_unsafe_view_161, exp_43);  _unsafe_view_161 = None
    transpose_102 = torch.ops.aten.transpose.int(view_322, -1, -2)
    expand_156 = torch.ops.aten.expand.default(view_321, [1, 16, 2, 64, 128])
    view_328 = torch.ops.aten.view.default(expand_156, [32, 64, 128]);  expand_156 = None
    expand_157 = torch.ops.aten.expand.default(transpose_102, [1, 16, 2, 128, 64]);  transpose_102 = None
    view_329 = torch.ops.aten.view.default(expand_157, [32, 128, 64]);  expand_157 = None
    bmm_75 = torch.ops.aten.bmm.default(view_328, view_329);  view_328 = view_329 = None
    _unsafe_view_162 = torch.ops.aten._unsafe_view.default(bmm_75, [1, 16, 2, 64, 64]);  bmm_75 = None
    mul_205 = torch.ops.aten.mul.Tensor(_unsafe_view_162, exp_43);  _unsafe_view_162 = exp_43 = None
    exp_44 = torch.ops.aten.exp.default(cumsum_7)
    unsqueeze_86 = torch.ops.aten.unsqueeze.default(exp_44, -1);  exp_44 = None
    mul_206 = torch.ops.aten.mul.Tensor(view_323, unsqueeze_86);  view_323 = unsqueeze_86 = None
    linalg_solve_triangular_14 = torch.ops.aten.linalg_solve_triangular.default(mul_204, view_324, upper = False, unitriangular = True);  view_324 = None
    linalg_solve_triangular_15 = torch.ops.aten.linalg_solve_triangular.default(mul_204, mul_206, upper = False, unitriangular = True);  mul_204 = mul_206 = None
    zeros_7 = torch.ops.aten.zeros.default([1, 16, 128, 128], dtype = torch.float32, device = device(type='meta'), pin_memory = False)
    zeros_like_7 = torch.ops.aten.zeros_like.default(linalg_solve_triangular_14, pin_memory = False)
    exp_45 = torch.ops.aten.exp.default(cumsum_7)
    unsqueeze_87 = torch.ops.aten.unsqueeze.default(exp_45, -1);  exp_45 = None
    mul_207 = torch.ops.aten.mul.Tensor(view_321, unsqueeze_87);  view_321 = unsqueeze_87 = None
    slice_41 = torch.ops.aten.slice.Tensor(cumsum_7, 3, -1, 9223372036854775807)
    sub_29 = torch.ops.aten.sub.Tensor(slice_41, cumsum_7);  slice_41 = None
    exp_46 = torch.ops.aten.exp.default(sub_29);  sub_29 = None
    unsqueeze_88 = torch.ops.aten.unsqueeze.default(exp_46, -1);  exp_46 = None
    mul_208 = torch.ops.aten.mul.Tensor(view_322, unsqueeze_88);  view_322 = unsqueeze_88 = None
    select_112 = torch.ops.aten.select.int(cumsum_7, 3, -1);  cumsum_7 = None
    exp_47 = torch.ops.aten.exp.default(select_112);  select_112 = None
    unsqueeze_89 = torch.ops.aten.unsqueeze.default(exp_47, 3);  exp_47 = None
    unsqueeze_90 = torch.ops.aten.unsqueeze.default(unsqueeze_89, 4);  unsqueeze_89 = None
    select_113 = torch.ops.aten.select.int(linalg_solve_triangular_14, 2, 0)
    select_114 = torch.ops.aten.select.int(linalg_solve_triangular_15, 2, 0)
    expand_158 = torch.ops.aten.expand.default(select_114, [1, 16, 64, 128]);  select_114 = None
    view_330 = torch.ops.aten.view.default(expand_158, [16, 64, 128]);  expand_158 = None
    expand_159 = torch.ops.aten.expand.default(zeros_7, [1, 16, 128, 128])
    view_331 = torch.ops.aten.view.default(expand_159, [16, 128, 128]);  expand_159 = None
    bmm_76 = torch.ops.aten.bmm.default(view_330, view_331);  view_330 = view_331 = None
    _unsafe_view_163 = torch.ops.aten._unsafe_view.default(bmm_76, [1, 16, 64, 128]);  bmm_76 = None
    sub_30 = torch.ops.aten.sub.Tensor(select_113, _unsafe_view_163);  select_113 = _unsafe_view_163 = None
    select_115 = torch.ops.aten.select.int(mul_207, 2, 0)
    expand_160 = torch.ops.aten.expand.default(select_115, [1, 16, 64, 128]);  select_115 = None
    view_332 = torch.ops.aten.view.default(expand_160, [16, 64, 128]);  expand_160 = None
    expand_161 = torch.ops.aten.expand.default(zeros_7, [1, 16, 128, 128])
    view_333 = torch.ops.aten.view.default(expand_161, [16, 128, 128]);  expand_161 = None
    bmm_77 = torch.ops.aten.bmm.default(view_332, view_333);  view_332 = view_333 = None
    _unsafe_view_164 = torch.ops.aten._unsafe_view.default(bmm_77, [1, 16, 64, 128]);  bmm_77 = None
    select_116 = torch.ops.aten.select.int(mul_205, 2, 0)
    expand_162 = torch.ops.aten.expand.default(select_116, [1, 16, 64, 64]);  select_116 = None
    view_334 = torch.ops.aten.view.default(expand_162, [16, 64, 64]);  expand_162 = None
    expand_163 = torch.ops.aten.expand.default(sub_30, [1, 16, 64, 128])
    view_335 = torch.ops.aten.view.default(expand_163, [16, 64, 128]);  expand_163 = None
    bmm_78 = torch.ops.aten.bmm.default(view_334, view_335);  view_334 = view_335 = None
    _unsafe_view_165 = torch.ops.aten._unsafe_view.default(bmm_78, [1, 16, 64, 128]);  bmm_78 = None
    add_130 = torch.ops.aten.add.Tensor(_unsafe_view_164, _unsafe_view_165);  _unsafe_view_164 = _unsafe_view_165 = None
    select_117 = torch.ops.aten.select.int(zeros_like_7, 2, 0)
    copy__18 = torch.ops.aten.copy_.default(select_117, add_130);  select_117 = add_130 = copy__18 = None
    select_118 = torch.ops.aten.select.int(unsqueeze_90, 2, 0)
    mul_209 = torch.ops.aten.mul.Tensor(zeros_7, select_118);  zeros_7 = select_118 = None
    select_119 = torch.ops.aten.select.int(mul_208, 2, 0)
    transpose_103 = torch.ops.aten.transpose.int(select_119, -1, -2);  select_119 = None
    expand_164 = torch.ops.aten.expand.default(transpose_103, [1, 16, 128, 64]);  transpose_103 = None
    view_336 = torch.ops.aten.view.default(expand_164, [16, 128, 64]);  expand_164 = None
    expand_165 = torch.ops.aten.expand.default(sub_30, [1, 16, 64, 128]);  sub_30 = None
    view_337 = torch.ops.aten.view.default(expand_165, [16, 64, 128]);  expand_165 = None
    bmm_79 = torch.ops.aten.bmm.default(view_336, view_337);  view_336 = view_337 = None
    _unsafe_view_166 = torch.ops.aten._unsafe_view.default(bmm_79, [1, 16, 128, 128]);  bmm_79 = None
    add_131 = torch.ops.aten.add.Tensor(mul_209, _unsafe_view_166);  mul_209 = _unsafe_view_166 = None
    select_120 = torch.ops.aten.select.int(linalg_solve_triangular_14, 2, 1);  linalg_solve_triangular_14 = None
    select_121 = torch.ops.aten.select.int(linalg_solve_triangular_15, 2, 1);  linalg_solve_triangular_15 = None
    expand_166 = torch.ops.aten.expand.default(select_121, [1, 16, 64, 128]);  select_121 = None
    view_338 = torch.ops.aten.view.default(expand_166, [16, 64, 128]);  expand_166 = None
    expand_167 = torch.ops.aten.expand.default(add_131, [1, 16, 128, 128])
    view_339 = torch.ops.aten.view.default(expand_167, [16, 128, 128]);  expand_167 = None
    bmm_80 = torch.ops.aten.bmm.default(view_338, view_339);  view_338 = view_339 = None
    _unsafe_view_167 = torch.ops.aten._unsafe_view.default(bmm_80, [1, 16, 64, 128]);  bmm_80 = None
    sub_31 = torch.ops.aten.sub.Tensor(select_120, _unsafe_view_167);  select_120 = _unsafe_view_167 = None
    select_122 = torch.ops.aten.select.int(mul_207, 2, 1);  mul_207 = None
    expand_168 = torch.ops.aten.expand.default(select_122, [1, 16, 64, 128]);  select_122 = None
    view_340 = torch.ops.aten.view.default(expand_168, [16, 64, 128]);  expand_168 = None
    expand_169 = torch.ops.aten.expand.default(add_131, [1, 16, 128, 128])
    view_341 = torch.ops.aten.view.default(expand_169, [16, 128, 128]);  expand_169 = None
    bmm_81 = torch.ops.aten.bmm.default(view_340, view_341);  view_340 = view_341 = None
    _unsafe_view_168 = torch.ops.aten._unsafe_view.default(bmm_81, [1, 16, 64, 128]);  bmm_81 = None
    select_123 = torch.ops.aten.select.int(mul_205, 2, 1);  mul_205 = None
    expand_170 = torch.ops.aten.expand.default(select_123, [1, 16, 64, 64]);  select_123 = None
    view_342 = torch.ops.aten.view.default(expand_170, [16, 64, 64]);  expand_170 = None
    expand_171 = torch.ops.aten.expand.default(sub_31, [1, 16, 64, 128])
    view_343 = torch.ops.aten.view.default(expand_171, [16, 64, 128]);  expand_171 = None
    bmm_82 = torch.ops.aten.bmm.default(view_342, view_343);  view_342 = view_343 = None
    _unsafe_view_169 = torch.ops.aten._unsafe_view.default(bmm_82, [1, 16, 64, 128]);  bmm_82 = None
    add_132 = torch.ops.aten.add.Tensor(_unsafe_view_168, _unsafe_view_169);  _unsafe_view_168 = _unsafe_view_169 = None
    select_124 = torch.ops.aten.select.int(zeros_like_7, 2, 1)
    copy__19 = torch.ops.aten.copy_.default(select_124, add_132);  select_124 = add_132 = copy__19 = None
    select_125 = torch.ops.aten.select.int(unsqueeze_90, 2, 1);  unsqueeze_90 = None
    mul_210 = torch.ops.aten.mul.Tensor(add_131, select_125);  add_131 = select_125 = None
    select_126 = torch.ops.aten.select.int(mul_208, 2, 1);  mul_208 = None
    transpose_104 = torch.ops.aten.transpose.int(select_126, -1, -2);  select_126 = None
    expand_172 = torch.ops.aten.expand.default(transpose_104, [1, 16, 128, 64]);  transpose_104 = None
    view_344 = torch.ops.aten.view.default(expand_172, [16, 128, 64]);  expand_172 = None
    expand_173 = torch.ops.aten.expand.default(sub_31, [1, 16, 64, 128]);  sub_31 = None
    view_345 = torch.ops.aten.view.default(expand_173, [16, 64, 128]);  expand_173 = None
    bmm_83 = torch.ops.aten.bmm.default(view_344, view_345);  view_344 = view_345 = None
    _unsafe_view_170 = torch.ops.aten._unsafe_view.default(bmm_83, [1, 16, 128, 128]);  bmm_83 = None
    add_133 = torch.ops.aten.add.Tensor(mul_210, _unsafe_view_170);  mul_210 = _unsafe_view_170 = add_133 = None
    clone_15 = torch.ops.aten.clone.default(zeros_like_7, memory_format = torch.contiguous_format);  zeros_like_7 = None
    _unsafe_view_171 = torch.ops.aten._unsafe_view.default(clone_15, [1, 16, 128, 128]);  clone_15 = None
    alias_7 = torch.ops.aten.alias.default(_unsafe_view_171);  _unsafe_view_171 = None
    transpose_105 = torch.ops.aten.transpose.int(alias_7, 1, 2);  alias_7 = None
    _to_copy_152 = torch.ops.aten._to_copy.default(transpose_105, dtype = torch.bfloat16, memory_format = torch.contiguous_format);  transpose_105 = None
    view_346 = torch.ops.aten.view.default(_to_copy_152, [-1, 128]);  _to_copy_152 = None
    view_347 = torch.ops.aten.view.default(view_315, [-1, 128]);  view_315 = None
    _to_copy_153 = torch.ops.aten._to_copy.default(view_346, dtype = torch.float32);  view_346 = None
    pow_31 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_153, 2)
    mean_30 = torch.ops.aten.mean.dim(pow_31, [-1], True);  pow_31 = None
    add_134 = torch.ops.aten.add.Tensor(mean_30, 1e-06);  mean_30 = None
    rsqrt_46 = torch.ops.aten.rsqrt.default(add_134);  add_134 = None
    mul_211 = torch.ops.aten.mul.Tensor(_to_copy_153, rsqrt_46);  _to_copy_153 = rsqrt_46 = None
    _to_copy_154 = torch.ops.aten._to_copy.default(mul_211, dtype = torch.bfloat16);  mul_211 = None
    _param_constant129 = self._param_constant129
    mul_212 = torch.ops.aten.mul.Tensor(_param_constant129, _to_copy_154);  _param_constant129 = _to_copy_154 = None
    _to_copy_155 = torch.ops.aten._to_copy.default(view_347, dtype = torch.float32);  view_347 = None
    silu_24 = torch.ops.aten.silu.default(_to_copy_155);  _to_copy_155 = None
    mul_213 = torch.ops.aten.mul.Tensor(mul_212, silu_24);  mul_212 = silu_24 = None
    _to_copy_156 = torch.ops.aten._to_copy.default(mul_213, dtype = torch.bfloat16);  mul_213 = None
    view_348 = torch.ops.aten.view.default(_to_copy_156, [1, 128, -1]);  _to_copy_156 = None
    _param_constant130 = self._param_constant130
    t_74 = torch.ops.aten.t.default(_param_constant130);  _param_constant130 = None
    view_349 = torch.ops.aten.view.default(view_348, [128, 2048]);  view_348 = None
    mm_74 = torch.ops.aten.mm.default(view_349, t_74);  view_349 = t_74 = None
    _unsafe_view_172 = torch.ops.aten._unsafe_view.default(mm_74, [1, 128, 2048]);  mm_74 = None
    add_135 = torch.ops.aten.add.Tensor(add_124, _unsafe_view_172);  add_124 = _unsafe_view_172 = None
    _to_copy_157 = torch.ops.aten._to_copy.default(add_135, dtype = torch.float32)
    pow_32 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_157, 2)
    mean_31 = torch.ops.aten.mean.dim(pow_32, [-1], True);  pow_32 = None
    add_136 = torch.ops.aten.add.Tensor(mean_31, 1e-06);  mean_31 = None
    rsqrt_47 = torch.ops.aten.rsqrt.default(add_136);  add_136 = None
    mul_214 = torch.ops.aten.mul.Tensor(_to_copy_157, rsqrt_47);  _to_copy_157 = rsqrt_47 = None
    _param_constant131 = self._param_constant131
    _to_copy_158 = torch.ops.aten._to_copy.default(_param_constant131, dtype = torch.float32);  _param_constant131 = None
    add_137 = torch.ops.aten.add.Tensor(_to_copy_158, 1.0);  _to_copy_158 = None
    mul_215 = torch.ops.aten.mul.Tensor(mul_214, add_137);  mul_214 = add_137 = None
    _to_copy_159 = torch.ops.aten._to_copy.default(mul_215, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_215 = None
    _param_constant132 = self._param_constant132
    t_75 = torch.ops.aten.t.default(_param_constant132);  _param_constant132 = None
    view_350 = torch.ops.aten.view.default(_to_copy_159, [128, 2048])
    mm_75 = torch.ops.aten.mm.default(view_350, t_75);  view_350 = t_75 = None
    _unsafe_view_173 = torch.ops.aten._unsafe_view.default(mm_75, [1, 128, 6144]);  mm_75 = None
    silu_25 = torch.ops.aten.silu.default(_unsafe_view_173);  _unsafe_view_173 = None
    _param_constant133 = self._param_constant133
    t_76 = torch.ops.aten.t.default(_param_constant133);  _param_constant133 = None
    view_351 = torch.ops.aten.view.default(_to_copy_159, [128, 2048]);  _to_copy_159 = None
    mm_76 = torch.ops.aten.mm.default(view_351, t_76);  view_351 = t_76 = None
    _unsafe_view_174 = torch.ops.aten._unsafe_view.default(mm_76, [1, 128, 6144]);  mm_76 = None
    mul_216 = torch.ops.aten.mul.Tensor(silu_25, _unsafe_view_174);  silu_25 = _unsafe_view_174 = None
    _param_constant134 = self._param_constant134
    t_77 = torch.ops.aten.t.default(_param_constant134);  _param_constant134 = None
    view_352 = torch.ops.aten.view.default(mul_216, [128, 6144]);  mul_216 = None
    mm_77 = torch.ops.aten.mm.default(view_352, t_77);  view_352 = t_77 = None
    _unsafe_view_175 = torch.ops.aten._unsafe_view.default(mm_77, [1, 128, 2048]);  mm_77 = None
    add_138 = torch.ops.aten.add.Tensor(add_135, _unsafe_view_175);  add_135 = _unsafe_view_175 = None
    _to_copy_160 = torch.ops.aten._to_copy.default(add_138, dtype = torch.float32)
    pow_33 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_160, 2)
    mean_32 = torch.ops.aten.mean.dim(pow_33, [-1], True);  pow_33 = None
    add_139 = torch.ops.aten.add.Tensor(mean_32, 1e-06);  mean_32 = None
    rsqrt_48 = torch.ops.aten.rsqrt.default(add_139);  add_139 = None
    mul_217 = torch.ops.aten.mul.Tensor(_to_copy_160, rsqrt_48);  _to_copy_160 = rsqrt_48 = None
    _param_constant135 = self._param_constant135
    _to_copy_161 = torch.ops.aten._to_copy.default(_param_constant135, dtype = torch.float32);  _param_constant135 = None
    add_140 = torch.ops.aten.add.Tensor(_to_copy_161, 1.0);  _to_copy_161 = None
    mul_218 = torch.ops.aten.mul.Tensor(mul_217, add_140);  mul_217 = add_140 = None
    _to_copy_162 = torch.ops.aten._to_copy.default(mul_218, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_218 = None
    _param_constant136 = self._param_constant136
    t_78 = torch.ops.aten.t.default(_param_constant136);  _param_constant136 = None
    view_353 = torch.ops.aten.view.default(_to_copy_162, [128, 2048])
    mm_78 = torch.ops.aten.mm.default(view_353, t_78);  view_353 = t_78 = None
    _unsafe_view_176 = torch.ops.aten._unsafe_view.default(mm_78, [1, 128, 6144]);  mm_78 = None
    transpose_106 = torch.ops.aten.transpose.int(_unsafe_view_176, 1, 2);  _unsafe_view_176 = None
    _param_constant137 = self._param_constant137
    t_79 = torch.ops.aten.t.default(_param_constant137);  _param_constant137 = None
    view_354 = torch.ops.aten.view.default(_to_copy_162, [128, 2048])
    mm_79 = torch.ops.aten.mm.default(view_354, t_79);  view_354 = t_79 = None
    _unsafe_view_177 = torch.ops.aten._unsafe_view.default(mm_79, [1, 128, 2048]);  mm_79 = None
    view_355 = torch.ops.aten.view.default(_unsafe_view_177, [1, 128, -1, 128]);  _unsafe_view_177 = None
    _param_constant138 = self._param_constant138
    t_80 = torch.ops.aten.t.default(_param_constant138);  _param_constant138 = None
    view_356 = torch.ops.aten.view.default(_to_copy_162, [128, 2048])
    mm_80 = torch.ops.aten.mm.default(view_356, t_80);  view_356 = t_80 = None
    _unsafe_view_178 = torch.ops.aten._unsafe_view.default(mm_80, [1, 128, 16]);  mm_80 = None
    _param_constant139 = self._param_constant139
    t_81 = torch.ops.aten.t.default(_param_constant139);  _param_constant139 = None
    view_357 = torch.ops.aten.view.default(_to_copy_162, [128, 2048]);  _to_copy_162 = None
    mm_81 = torch.ops.aten.mm.default(view_357, t_81);  view_357 = t_81 = None
    _unsafe_view_179 = torch.ops.aten._unsafe_view.default(mm_81, [1, 128, 16]);  mm_81 = None
    _param_constant140 = self._param_constant140
    squeeze_8 = torch.ops.aten.squeeze.dim(_param_constant140, 1);  _param_constant140 = None
    unsqueeze_91 = torch.ops.aten.unsqueeze.default(squeeze_8, 1);  squeeze_8 = None
    convolution_8 = torch.ops.aten.convolution.default(transpose_106, unsqueeze_91, None, [1], [3], [1], False, [0], 6144);  transpose_106 = unsqueeze_91 = None
    slice_42 = torch.ops.aten.slice.Tensor(convolution_8, 2, 0, 128);  convolution_8 = None
    silu_26 = torch.ops.aten.silu.default(slice_42);  slice_42 = None
    transpose_107 = torch.ops.aten.transpose.int(silu_26, 1, 2);  silu_26 = None
    split_with_sizes_8 = torch.ops.aten.split_with_sizes.default(transpose_107, [2048, 2048, 2048], -1);  transpose_107 = None
    getitem_28 = split_with_sizes_8[0]
    getitem_29 = split_with_sizes_8[1]
    getitem_30 = split_with_sizes_8[2];  split_with_sizes_8 = None
    view_358 = torch.ops.aten.view.default(getitem_28, [1, 128, 16, 128]);  getitem_28 = None
    view_359 = torch.ops.aten.view.default(getitem_29, [1, 128, 16, 128]);  getitem_29 = None
    view_360 = torch.ops.aten.view.default(getitem_30, [1, 128, 16, 128]);  getitem_30 = None
    sigmoid_10 = torch.ops.aten.sigmoid.default(_unsafe_view_178);  _unsafe_view_178 = None
    _param_constant141 = self._param_constant141
    exp_48 = torch.ops.aten.exp.default(_param_constant141);  _param_constant141 = None
    neg_12 = torch.ops.aten.neg.default(exp_48);  exp_48 = None
    _to_copy_163 = torch.ops.aten._to_copy.default(_unsafe_view_179, dtype = torch.float32);  _unsafe_view_179 = None
    _param_constant142 = self._param_constant142
    add_141 = torch.ops.aten.add.Tensor(_to_copy_163, _param_constant142);  _to_copy_163 = _param_constant142 = None
    softplus_8 = torch.ops.aten.softplus.default(add_141);  add_141 = None
    mul_219 = torch.ops.aten.mul.Tensor(neg_12, softplus_8);  neg_12 = softplus_8 = None
    transpose_108 = torch.ops.aten.transpose.int(view_358, 1, 2);  view_358 = None
    _to_copy_164 = torch.ops.aten._to_copy.default(transpose_108, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_108 = None
    transpose_109 = torch.ops.aten.transpose.int(view_359, 1, 2);  view_359 = None
    _to_copy_165 = torch.ops.aten._to_copy.default(transpose_109, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_109 = None
    transpose_110 = torch.ops.aten.transpose.int(view_360, 1, 2);  view_360 = None
    _to_copy_166 = torch.ops.aten._to_copy.default(transpose_110, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_110 = None
    transpose_111 = torch.ops.aten.transpose.int(sigmoid_10, 1, 2);  sigmoid_10 = None
    _to_copy_167 = torch.ops.aten._to_copy.default(transpose_111, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_111 = None
    transpose_112 = torch.ops.aten.transpose.int(mul_219, 1, 2);  mul_219 = None
    mul_220 = torch.ops.aten.mul.Tensor(_to_copy_164, _to_copy_164)
    sum_17 = torch.ops.aten.sum.dim_IntList(mul_220, [-1], True);  mul_220 = None
    add_142 = torch.ops.aten.add.Tensor(sum_17, 1e-06);  sum_17 = None
    rsqrt_49 = torch.ops.aten.rsqrt.default(add_142);  add_142 = None
    mul_221 = torch.ops.aten.mul.Tensor(_to_copy_164, rsqrt_49);  _to_copy_164 = rsqrt_49 = None
    mul_222 = torch.ops.aten.mul.Tensor(_to_copy_165, _to_copy_165)
    sum_18 = torch.ops.aten.sum.dim_IntList(mul_222, [-1], True);  mul_222 = None
    add_143 = torch.ops.aten.add.Tensor(sum_18, 1e-06);  sum_18 = None
    rsqrt_50 = torch.ops.aten.rsqrt.default(add_143);  add_143 = None
    mul_223 = torch.ops.aten.mul.Tensor(_to_copy_165, rsqrt_50);  _to_copy_165 = rsqrt_50 = None
    mul_224 = torch.ops.aten.mul.Tensor(mul_221, 0.08838834764831845);  mul_221 = None
    constant_pad_nd_40 = torch.ops.aten.constant_pad_nd.default(mul_224, [0, 0, 0, 0], 0.0);  mul_224 = None
    constant_pad_nd_41 = torch.ops.aten.constant_pad_nd.default(mul_223, [0, 0, 0, 0], 0.0);  mul_223 = None
    constant_pad_nd_42 = torch.ops.aten.constant_pad_nd.default(_to_copy_166, [0, 0, 0, 0], 0.0);  _to_copy_166 = None
    constant_pad_nd_43 = torch.ops.aten.constant_pad_nd.default(_to_copy_167, [0, 0], 0.0);  _to_copy_167 = None
    constant_pad_nd_44 = torch.ops.aten.constant_pad_nd.default(transpose_112, [0, 0], 0.0);  transpose_112 = None
    unsqueeze_92 = torch.ops.aten.unsqueeze.default(constant_pad_nd_43, -1)
    mul_225 = torch.ops.aten.mul.Tensor(constant_pad_nd_42, unsqueeze_92);  constant_pad_nd_42 = unsqueeze_92 = None
    unsqueeze_93 = torch.ops.aten.unsqueeze.default(constant_pad_nd_43, -1);  constant_pad_nd_43 = None
    mul_226 = torch.ops.aten.mul.Tensor(constant_pad_nd_41, unsqueeze_93);  unsqueeze_93 = None
    view_361 = torch.ops.aten.view.default(constant_pad_nd_40, [1, 16, -1, 64, 128]);  constant_pad_nd_40 = None
    view_362 = torch.ops.aten.view.default(constant_pad_nd_41, [1, 16, -1, 64, 128]);  constant_pad_nd_41 = None
    view_363 = torch.ops.aten.view.default(mul_226, [1, 16, -1, 64, 128]);  mul_226 = None
    view_364 = torch.ops.aten.view.default(mul_225, [1, 16, -1, 64, 128]);  mul_225 = None
    view_365 = torch.ops.aten.view.default(constant_pad_nd_44, [1, 16, 2, 64]);  constant_pad_nd_44 = None
    ones_8 = torch.ops.aten.ones.default([64, 64], dtype = torch.bool, device = device(type='meta'), pin_memory = False)
    triu_9 = torch.ops.aten.triu.default(ones_8, 1);  ones_8 = None
    cumsum_8 = torch.ops.aten.cumsum.default(view_365, 3);  view_365 = None
    unsqueeze_94 = torch.ops.aten.unsqueeze.default(cumsum_8, 4)
    unsqueeze_95 = torch.ops.aten.unsqueeze.default(cumsum_8, 3)
    sub_32 = torch.ops.aten.sub.Tensor(unsqueeze_94, unsqueeze_95);  unsqueeze_94 = unsqueeze_95 = None
    masked_fill_8 = torch.ops.aten.masked_fill.Scalar(sub_32, triu_9, -inf);  sub_32 = triu_9 = None
    exp_49 = torch.ops.aten.exp.default(masked_fill_8);  masked_fill_8 = None
    transpose_113 = torch.ops.aten.transpose.int(view_362, -1, -2)
    expand_174 = torch.ops.aten.expand.default(view_363, [1, 16, 2, 64, 128])
    view_366 = torch.ops.aten.view.default(expand_174, [32, 64, 128]);  expand_174 = None
    expand_175 = torch.ops.aten.expand.default(transpose_113, [1, 16, 2, 128, 64]);  transpose_113 = None
    view_367 = torch.ops.aten.view.default(expand_175, [32, 128, 64]);  expand_175 = None
    bmm_84 = torch.ops.aten.bmm.default(view_366, view_367);  view_366 = view_367 = None
    _unsafe_view_180 = torch.ops.aten._unsafe_view.default(bmm_84, [1, 16, 2, 64, 64]);  bmm_84 = None
    mul_227 = torch.ops.aten.mul.Tensor(_unsafe_view_180, exp_49);  _unsafe_view_180 = None
    transpose_114 = torch.ops.aten.transpose.int(view_362, -1, -2)
    expand_176 = torch.ops.aten.expand.default(view_361, [1, 16, 2, 64, 128])
    view_368 = torch.ops.aten.view.default(expand_176, [32, 64, 128]);  expand_176 = None
    expand_177 = torch.ops.aten.expand.default(transpose_114, [1, 16, 2, 128, 64]);  transpose_114 = None
    view_369 = torch.ops.aten.view.default(expand_177, [32, 128, 64]);  expand_177 = None
    bmm_85 = torch.ops.aten.bmm.default(view_368, view_369);  view_368 = view_369 = None
    _unsafe_view_181 = torch.ops.aten._unsafe_view.default(bmm_85, [1, 16, 2, 64, 64]);  bmm_85 = None
    mul_228 = torch.ops.aten.mul.Tensor(_unsafe_view_181, exp_49);  _unsafe_view_181 = exp_49 = None
    exp_50 = torch.ops.aten.exp.default(cumsum_8)
    unsqueeze_96 = torch.ops.aten.unsqueeze.default(exp_50, -1);  exp_50 = None
    mul_229 = torch.ops.aten.mul.Tensor(view_363, unsqueeze_96);  view_363 = unsqueeze_96 = None
    linalg_solve_triangular_16 = torch.ops.aten.linalg_solve_triangular.default(mul_227, view_364, upper = False, unitriangular = True);  view_364 = None
    linalg_solve_triangular_17 = torch.ops.aten.linalg_solve_triangular.default(mul_227, mul_229, upper = False, unitriangular = True);  mul_227 = mul_229 = None
    zeros_8 = torch.ops.aten.zeros.default([1, 16, 128, 128], dtype = torch.float32, device = device(type='meta'), pin_memory = False)
    zeros_like_8 = torch.ops.aten.zeros_like.default(linalg_solve_triangular_16, pin_memory = False)
    exp_51 = torch.ops.aten.exp.default(cumsum_8)
    unsqueeze_97 = torch.ops.aten.unsqueeze.default(exp_51, -1);  exp_51 = None
    mul_230 = torch.ops.aten.mul.Tensor(view_361, unsqueeze_97);  view_361 = unsqueeze_97 = None
    slice_43 = torch.ops.aten.slice.Tensor(cumsum_8, 3, -1, 9223372036854775807)
    sub_33 = torch.ops.aten.sub.Tensor(slice_43, cumsum_8);  slice_43 = None
    exp_52 = torch.ops.aten.exp.default(sub_33);  sub_33 = None
    unsqueeze_98 = torch.ops.aten.unsqueeze.default(exp_52, -1);  exp_52 = None
    mul_231 = torch.ops.aten.mul.Tensor(view_362, unsqueeze_98);  view_362 = unsqueeze_98 = None
    select_127 = torch.ops.aten.select.int(cumsum_8, 3, -1);  cumsum_8 = None
    exp_53 = torch.ops.aten.exp.default(select_127);  select_127 = None
    unsqueeze_99 = torch.ops.aten.unsqueeze.default(exp_53, 3);  exp_53 = None
    unsqueeze_100 = torch.ops.aten.unsqueeze.default(unsqueeze_99, 4);  unsqueeze_99 = None
    select_128 = torch.ops.aten.select.int(linalg_solve_triangular_16, 2, 0)
    select_129 = torch.ops.aten.select.int(linalg_solve_triangular_17, 2, 0)
    expand_178 = torch.ops.aten.expand.default(select_129, [1, 16, 64, 128]);  select_129 = None
    view_370 = torch.ops.aten.view.default(expand_178, [16, 64, 128]);  expand_178 = None
    expand_179 = torch.ops.aten.expand.default(zeros_8, [1, 16, 128, 128])
    view_371 = torch.ops.aten.view.default(expand_179, [16, 128, 128]);  expand_179 = None
    bmm_86 = torch.ops.aten.bmm.default(view_370, view_371);  view_370 = view_371 = None
    _unsafe_view_182 = torch.ops.aten._unsafe_view.default(bmm_86, [1, 16, 64, 128]);  bmm_86 = None
    sub_34 = torch.ops.aten.sub.Tensor(select_128, _unsafe_view_182);  select_128 = _unsafe_view_182 = None
    select_130 = torch.ops.aten.select.int(mul_230, 2, 0)
    expand_180 = torch.ops.aten.expand.default(select_130, [1, 16, 64, 128]);  select_130 = None
    view_372 = torch.ops.aten.view.default(expand_180, [16, 64, 128]);  expand_180 = None
    expand_181 = torch.ops.aten.expand.default(zeros_8, [1, 16, 128, 128])
    view_373 = torch.ops.aten.view.default(expand_181, [16, 128, 128]);  expand_181 = None
    bmm_87 = torch.ops.aten.bmm.default(view_372, view_373);  view_372 = view_373 = None
    _unsafe_view_183 = torch.ops.aten._unsafe_view.default(bmm_87, [1, 16, 64, 128]);  bmm_87 = None
    select_131 = torch.ops.aten.select.int(mul_228, 2, 0)
    expand_182 = torch.ops.aten.expand.default(select_131, [1, 16, 64, 64]);  select_131 = None
    view_374 = torch.ops.aten.view.default(expand_182, [16, 64, 64]);  expand_182 = None
    expand_183 = torch.ops.aten.expand.default(sub_34, [1, 16, 64, 128])
    view_375 = torch.ops.aten.view.default(expand_183, [16, 64, 128]);  expand_183 = None
    bmm_88 = torch.ops.aten.bmm.default(view_374, view_375);  view_374 = view_375 = None
    _unsafe_view_184 = torch.ops.aten._unsafe_view.default(bmm_88, [1, 16, 64, 128]);  bmm_88 = None
    add_144 = torch.ops.aten.add.Tensor(_unsafe_view_183, _unsafe_view_184);  _unsafe_view_183 = _unsafe_view_184 = None
    select_132 = torch.ops.aten.select.int(zeros_like_8, 2, 0)
    copy__20 = torch.ops.aten.copy_.default(select_132, add_144);  select_132 = add_144 = copy__20 = None
    select_133 = torch.ops.aten.select.int(unsqueeze_100, 2, 0)
    mul_232 = torch.ops.aten.mul.Tensor(zeros_8, select_133);  zeros_8 = select_133 = None
    select_134 = torch.ops.aten.select.int(mul_231, 2, 0)
    transpose_115 = torch.ops.aten.transpose.int(select_134, -1, -2);  select_134 = None
    expand_184 = torch.ops.aten.expand.default(transpose_115, [1, 16, 128, 64]);  transpose_115 = None
    view_376 = torch.ops.aten.view.default(expand_184, [16, 128, 64]);  expand_184 = None
    expand_185 = torch.ops.aten.expand.default(sub_34, [1, 16, 64, 128]);  sub_34 = None
    view_377 = torch.ops.aten.view.default(expand_185, [16, 64, 128]);  expand_185 = None
    bmm_89 = torch.ops.aten.bmm.default(view_376, view_377);  view_376 = view_377 = None
    _unsafe_view_185 = torch.ops.aten._unsafe_view.default(bmm_89, [1, 16, 128, 128]);  bmm_89 = None
    add_145 = torch.ops.aten.add.Tensor(mul_232, _unsafe_view_185);  mul_232 = _unsafe_view_185 = None
    select_135 = torch.ops.aten.select.int(linalg_solve_triangular_16, 2, 1);  linalg_solve_triangular_16 = None
    select_136 = torch.ops.aten.select.int(linalg_solve_triangular_17, 2, 1);  linalg_solve_triangular_17 = None
    expand_186 = torch.ops.aten.expand.default(select_136, [1, 16, 64, 128]);  select_136 = None
    view_378 = torch.ops.aten.view.default(expand_186, [16, 64, 128]);  expand_186 = None
    expand_187 = torch.ops.aten.expand.default(add_145, [1, 16, 128, 128])
    view_379 = torch.ops.aten.view.default(expand_187, [16, 128, 128]);  expand_187 = None
    bmm_90 = torch.ops.aten.bmm.default(view_378, view_379);  view_378 = view_379 = None
    _unsafe_view_186 = torch.ops.aten._unsafe_view.default(bmm_90, [1, 16, 64, 128]);  bmm_90 = None
    sub_35 = torch.ops.aten.sub.Tensor(select_135, _unsafe_view_186);  select_135 = _unsafe_view_186 = None
    select_137 = torch.ops.aten.select.int(mul_230, 2, 1);  mul_230 = None
    expand_188 = torch.ops.aten.expand.default(select_137, [1, 16, 64, 128]);  select_137 = None
    view_380 = torch.ops.aten.view.default(expand_188, [16, 64, 128]);  expand_188 = None
    expand_189 = torch.ops.aten.expand.default(add_145, [1, 16, 128, 128])
    view_381 = torch.ops.aten.view.default(expand_189, [16, 128, 128]);  expand_189 = None
    bmm_91 = torch.ops.aten.bmm.default(view_380, view_381);  view_380 = view_381 = None
    _unsafe_view_187 = torch.ops.aten._unsafe_view.default(bmm_91, [1, 16, 64, 128]);  bmm_91 = None
    select_138 = torch.ops.aten.select.int(mul_228, 2, 1);  mul_228 = None
    expand_190 = torch.ops.aten.expand.default(select_138, [1, 16, 64, 64]);  select_138 = None
    view_382 = torch.ops.aten.view.default(expand_190, [16, 64, 64]);  expand_190 = None
    expand_191 = torch.ops.aten.expand.default(sub_35, [1, 16, 64, 128])
    view_383 = torch.ops.aten.view.default(expand_191, [16, 64, 128]);  expand_191 = None
    bmm_92 = torch.ops.aten.bmm.default(view_382, view_383);  view_382 = view_383 = None
    _unsafe_view_188 = torch.ops.aten._unsafe_view.default(bmm_92, [1, 16, 64, 128]);  bmm_92 = None
    add_146 = torch.ops.aten.add.Tensor(_unsafe_view_187, _unsafe_view_188);  _unsafe_view_187 = _unsafe_view_188 = None
    select_139 = torch.ops.aten.select.int(zeros_like_8, 2, 1)
    copy__21 = torch.ops.aten.copy_.default(select_139, add_146);  select_139 = add_146 = copy__21 = None
    select_140 = torch.ops.aten.select.int(unsqueeze_100, 2, 1);  unsqueeze_100 = None
    mul_233 = torch.ops.aten.mul.Tensor(add_145, select_140);  add_145 = select_140 = None
    select_141 = torch.ops.aten.select.int(mul_231, 2, 1);  mul_231 = None
    transpose_116 = torch.ops.aten.transpose.int(select_141, -1, -2);  select_141 = None
    expand_192 = torch.ops.aten.expand.default(transpose_116, [1, 16, 128, 64]);  transpose_116 = None
    view_384 = torch.ops.aten.view.default(expand_192, [16, 128, 64]);  expand_192 = None
    expand_193 = torch.ops.aten.expand.default(sub_35, [1, 16, 64, 128]);  sub_35 = None
    view_385 = torch.ops.aten.view.default(expand_193, [16, 64, 128]);  expand_193 = None
    bmm_93 = torch.ops.aten.bmm.default(view_384, view_385);  view_384 = view_385 = None
    _unsafe_view_189 = torch.ops.aten._unsafe_view.default(bmm_93, [1, 16, 128, 128]);  bmm_93 = None
    add_147 = torch.ops.aten.add.Tensor(mul_233, _unsafe_view_189);  mul_233 = _unsafe_view_189 = add_147 = None
    clone_16 = torch.ops.aten.clone.default(zeros_like_8, memory_format = torch.contiguous_format);  zeros_like_8 = None
    _unsafe_view_190 = torch.ops.aten._unsafe_view.default(clone_16, [1, 16, 128, 128]);  clone_16 = None
    alias_8 = torch.ops.aten.alias.default(_unsafe_view_190);  _unsafe_view_190 = None
    transpose_117 = torch.ops.aten.transpose.int(alias_8, 1, 2);  alias_8 = None
    _to_copy_168 = torch.ops.aten._to_copy.default(transpose_117, dtype = torch.bfloat16, memory_format = torch.contiguous_format);  transpose_117 = None
    view_386 = torch.ops.aten.view.default(_to_copy_168, [-1, 128]);  _to_copy_168 = None
    view_387 = torch.ops.aten.view.default(view_355, [-1, 128]);  view_355 = None
    _to_copy_169 = torch.ops.aten._to_copy.default(view_386, dtype = torch.float32);  view_386 = None
    pow_34 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_169, 2)
    mean_33 = torch.ops.aten.mean.dim(pow_34, [-1], True);  pow_34 = None
    add_148 = torch.ops.aten.add.Tensor(mean_33, 1e-06);  mean_33 = None
    rsqrt_51 = torch.ops.aten.rsqrt.default(add_148);  add_148 = None
    mul_234 = torch.ops.aten.mul.Tensor(_to_copy_169, rsqrt_51);  _to_copy_169 = rsqrt_51 = None
    _to_copy_170 = torch.ops.aten._to_copy.default(mul_234, dtype = torch.bfloat16);  mul_234 = None
    _param_constant143 = self._param_constant143
    mul_235 = torch.ops.aten.mul.Tensor(_param_constant143, _to_copy_170);  _param_constant143 = _to_copy_170 = None
    _to_copy_171 = torch.ops.aten._to_copy.default(view_387, dtype = torch.float32);  view_387 = None
    silu_27 = torch.ops.aten.silu.default(_to_copy_171);  _to_copy_171 = None
    mul_236 = torch.ops.aten.mul.Tensor(mul_235, silu_27);  mul_235 = silu_27 = None
    _to_copy_172 = torch.ops.aten._to_copy.default(mul_236, dtype = torch.bfloat16);  mul_236 = None
    view_388 = torch.ops.aten.view.default(_to_copy_172, [1, 128, -1]);  _to_copy_172 = None
    _param_constant144 = self._param_constant144
    t_82 = torch.ops.aten.t.default(_param_constant144);  _param_constant144 = None
    view_389 = torch.ops.aten.view.default(view_388, [128, 2048]);  view_388 = None
    mm_82 = torch.ops.aten.mm.default(view_389, t_82);  view_389 = t_82 = None
    _unsafe_view_191 = torch.ops.aten._unsafe_view.default(mm_82, [1, 128, 2048]);  mm_82 = None
    add_149 = torch.ops.aten.add.Tensor(add_138, _unsafe_view_191);  add_138 = _unsafe_view_191 = None
    _to_copy_173 = torch.ops.aten._to_copy.default(add_149, dtype = torch.float32)
    pow_35 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_173, 2)
    mean_34 = torch.ops.aten.mean.dim(pow_35, [-1], True);  pow_35 = None
    add_150 = torch.ops.aten.add.Tensor(mean_34, 1e-06);  mean_34 = None
    rsqrt_52 = torch.ops.aten.rsqrt.default(add_150);  add_150 = None
    mul_237 = torch.ops.aten.mul.Tensor(_to_copy_173, rsqrt_52);  _to_copy_173 = rsqrt_52 = None
    _param_constant145 = self._param_constant145
    _to_copy_174 = torch.ops.aten._to_copy.default(_param_constant145, dtype = torch.float32);  _param_constant145 = None
    add_151 = torch.ops.aten.add.Tensor(_to_copy_174, 1.0);  _to_copy_174 = None
    mul_238 = torch.ops.aten.mul.Tensor(mul_237, add_151);  mul_237 = add_151 = None
    _to_copy_175 = torch.ops.aten._to_copy.default(mul_238, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_238 = None
    _param_constant146 = self._param_constant146
    t_83 = torch.ops.aten.t.default(_param_constant146);  _param_constant146 = None
    view_390 = torch.ops.aten.view.default(_to_copy_175, [128, 2048])
    mm_83 = torch.ops.aten.mm.default(view_390, t_83);  view_390 = t_83 = None
    _unsafe_view_192 = torch.ops.aten._unsafe_view.default(mm_83, [1, 128, 6144]);  mm_83 = None
    silu_28 = torch.ops.aten.silu.default(_unsafe_view_192);  _unsafe_view_192 = None
    _param_constant147 = self._param_constant147
    t_84 = torch.ops.aten.t.default(_param_constant147);  _param_constant147 = None
    view_391 = torch.ops.aten.view.default(_to_copy_175, [128, 2048]);  _to_copy_175 = None
    mm_84 = torch.ops.aten.mm.default(view_391, t_84);  view_391 = t_84 = None
    _unsafe_view_193 = torch.ops.aten._unsafe_view.default(mm_84, [1, 128, 6144]);  mm_84 = None
    mul_239 = torch.ops.aten.mul.Tensor(silu_28, _unsafe_view_193);  silu_28 = _unsafe_view_193 = None
    _param_constant148 = self._param_constant148
    t_85 = torch.ops.aten.t.default(_param_constant148);  _param_constant148 = None
    view_392 = torch.ops.aten.view.default(mul_239, [128, 6144]);  mul_239 = None
    mm_85 = torch.ops.aten.mm.default(view_392, t_85);  view_392 = t_85 = None
    _unsafe_view_194 = torch.ops.aten._unsafe_view.default(mm_85, [1, 128, 2048]);  mm_85 = None
    add_152 = torch.ops.aten.add.Tensor(add_149, _unsafe_view_194);  add_149 = _unsafe_view_194 = None
    _to_copy_176 = torch.ops.aten._to_copy.default(add_152, dtype = torch.float32)
    pow_36 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_176, 2)
    mean_35 = torch.ops.aten.mean.dim(pow_36, [-1], True);  pow_36 = None
    add_153 = torch.ops.aten.add.Tensor(mean_35, 1e-06);  mean_35 = None
    rsqrt_53 = torch.ops.aten.rsqrt.default(add_153);  add_153 = None
    mul_240 = torch.ops.aten.mul.Tensor(_to_copy_176, rsqrt_53);  _to_copy_176 = rsqrt_53 = None
    _param_constant149 = self._param_constant149
    _to_copy_177 = torch.ops.aten._to_copy.default(_param_constant149, dtype = torch.float32);  _param_constant149 = None
    add_154 = torch.ops.aten.add.Tensor(_to_copy_177, 1.0);  _to_copy_177 = None
    mul_241 = torch.ops.aten.mul.Tensor(mul_240, add_154);  mul_240 = add_154 = None
    _to_copy_178 = torch.ops.aten._to_copy.default(mul_241, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_241 = None
    _param_constant150 = self._param_constant150
    t_86 = torch.ops.aten.t.default(_param_constant150);  _param_constant150 = None
    view_393 = torch.ops.aten.view.default(_to_copy_178, [128, 2048])
    mm_86 = torch.ops.aten.mm.default(view_393, t_86);  view_393 = t_86 = None
    _unsafe_view_195 = torch.ops.aten._unsafe_view.default(mm_86, [1, 128, 4096]);  mm_86 = None
    view_394 = torch.ops.aten.view.default(_unsafe_view_195, [1, 128, -1, 512]);  _unsafe_view_195 = None
    split_2 = torch.ops.aten.split.Tensor(view_394, 256, -1);  view_394 = None
    getitem_31 = split_2[0]
    getitem_32 = split_2[1];  split_2 = None
    clone_17 = torch.ops.aten.clone.default(getitem_32, memory_format = torch.contiguous_format);  getitem_32 = None
    _unsafe_view_196 = torch.ops.aten._unsafe_view.default(clone_17, [1, 128, 2048]);  clone_17 = None
    view_395 = torch.ops.aten.view.default(getitem_31, [1, 128, -1, 256]);  getitem_31 = None
    _to_copy_179 = torch.ops.aten._to_copy.default(view_395, dtype = torch.float32);  view_395 = None
    pow_37 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_179, 2)
    mean_36 = torch.ops.aten.mean.dim(pow_37, [-1], True);  pow_37 = None
    add_155 = torch.ops.aten.add.Tensor(mean_36, 1e-06);  mean_36 = None
    rsqrt_54 = torch.ops.aten.rsqrt.default(add_155);  add_155 = None
    mul_242 = torch.ops.aten.mul.Tensor(_to_copy_179, rsqrt_54);  _to_copy_179 = rsqrt_54 = None
    _param_constant151 = self._param_constant151
    _to_copy_180 = torch.ops.aten._to_copy.default(_param_constant151, dtype = torch.float32);  _param_constant151 = None
    add_156 = torch.ops.aten.add.Tensor(_to_copy_180, 1.0);  _to_copy_180 = None
    mul_243 = torch.ops.aten.mul.Tensor(mul_242, add_156);  mul_242 = add_156 = None
    _to_copy_181 = torch.ops.aten._to_copy.default(mul_243, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_243 = None
    transpose_118 = torch.ops.aten.transpose.int(_to_copy_181, 1, 2);  _to_copy_181 = None
    _param_constant152 = self._param_constant152
    t_87 = torch.ops.aten.t.default(_param_constant152);  _param_constant152 = None
    view_396 = torch.ops.aten.view.default(_to_copy_178, [128, 2048])
    mm_87 = torch.ops.aten.mm.default(view_396, t_87);  view_396 = t_87 = None
    _unsafe_view_197 = torch.ops.aten._unsafe_view.default(mm_87, [1, 128, 512]);  mm_87 = None
    view_397 = torch.ops.aten.view.default(_unsafe_view_197, [1, 128, -1, 256]);  _unsafe_view_197 = None
    _to_copy_182 = torch.ops.aten._to_copy.default(view_397, dtype = torch.float32);  view_397 = None
    pow_38 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_182, 2)
    mean_37 = torch.ops.aten.mean.dim(pow_38, [-1], True);  pow_38 = None
    add_157 = torch.ops.aten.add.Tensor(mean_37, 1e-06);  mean_37 = None
    rsqrt_55 = torch.ops.aten.rsqrt.default(add_157);  add_157 = None
    mul_244 = torch.ops.aten.mul.Tensor(_to_copy_182, rsqrt_55);  _to_copy_182 = rsqrt_55 = None
    _param_constant153 = self._param_constant153
    _to_copy_183 = torch.ops.aten._to_copy.default(_param_constant153, dtype = torch.float32);  _param_constant153 = None
    add_158 = torch.ops.aten.add.Tensor(_to_copy_183, 1.0);  _to_copy_183 = None
    mul_245 = torch.ops.aten.mul.Tensor(mul_244, add_158);  mul_244 = add_158 = None
    _to_copy_184 = torch.ops.aten._to_copy.default(mul_245, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_245 = None
    transpose_119 = torch.ops.aten.transpose.int(_to_copy_184, 1, 2);  _to_copy_184 = None
    _param_constant154 = self._param_constant154
    t_88 = torch.ops.aten.t.default(_param_constant154);  _param_constant154 = None
    view_398 = torch.ops.aten.view.default(_to_copy_178, [128, 2048]);  _to_copy_178 = None
    mm_88 = torch.ops.aten.mm.default(view_398, t_88);  view_398 = t_88 = None
    _unsafe_view_198 = torch.ops.aten._unsafe_view.default(mm_88, [1, 128, 512]);  mm_88 = None
    view_399 = torch.ops.aten.view.default(_unsafe_view_198, [1, 128, -1, 256]);  _unsafe_view_198 = None
    transpose_120 = torch.ops.aten.transpose.int(view_399, 1, 2);  view_399 = None
    unsqueeze_101 = torch.ops.aten.unsqueeze.default(_to_copy_2, 1)
    unsqueeze_102 = torch.ops.aten.unsqueeze.default(_to_copy_3, 1)
    slice_44 = torch.ops.aten.slice.Tensor(transpose_118, 3, 0, 64)
    slice_45 = torch.ops.aten.slice.Tensor(transpose_118, 3, 64, 9223372036854775807);  transpose_118 = None
    slice_46 = torch.ops.aten.slice.Tensor(transpose_119, 3, 0, 64)
    slice_47 = torch.ops.aten.slice.Tensor(transpose_119, 3, 64, 9223372036854775807);  transpose_119 = None
    mul_246 = torch.ops.aten.mul.Tensor(slice_44, unsqueeze_101)
    slice_48 = torch.ops.aten.slice.Tensor(slice_44, 3, 0, 32)
    slice_49 = torch.ops.aten.slice.Tensor(slice_44, 3, 32, 9223372036854775807);  slice_44 = None
    neg_13 = torch.ops.aten.neg.default(slice_49);  slice_49 = None
    cat_10 = torch.ops.aten.cat.default([neg_13, slice_48], -1);  neg_13 = slice_48 = None
    mul_247 = torch.ops.aten.mul.Tensor(cat_10, unsqueeze_102);  cat_10 = None
    add_159 = torch.ops.aten.add.Tensor(mul_246, mul_247);  mul_246 = mul_247 = None
    mul_248 = torch.ops.aten.mul.Tensor(slice_46, unsqueeze_101);  unsqueeze_101 = None
    slice_50 = torch.ops.aten.slice.Tensor(slice_46, 3, 0, 32)
    slice_51 = torch.ops.aten.slice.Tensor(slice_46, 3, 32, 9223372036854775807);  slice_46 = None
    neg_14 = torch.ops.aten.neg.default(slice_51);  slice_51 = None
    cat_11 = torch.ops.aten.cat.default([neg_14, slice_50], -1);  neg_14 = slice_50 = None
    mul_249 = torch.ops.aten.mul.Tensor(cat_11, unsqueeze_102);  cat_11 = unsqueeze_102 = None
    add_160 = torch.ops.aten.add.Tensor(mul_248, mul_249);  mul_248 = mul_249 = None
    cat_12 = torch.ops.aten.cat.default([add_159, slice_45], -1);  add_159 = slice_45 = None
    cat_13 = torch.ops.aten.cat.default([add_160, slice_47], -1);  add_160 = slice_47 = None
    unsqueeze_103 = torch.ops.aten.unsqueeze.default(cat_13, 2);  cat_13 = None
    expand_194 = torch.ops.aten.expand.default(unsqueeze_103, [1, 2, 4, 128, 256]);  unsqueeze_103 = None
    clone_18 = torch.ops.aten.clone.default(expand_194, memory_format = torch.contiguous_format);  expand_194 = None
    _unsafe_view_199 = torch.ops.aten._unsafe_view.default(clone_18, [1, 8, 128, 256]);  clone_18 = None
    unsqueeze_104 = torch.ops.aten.unsqueeze.default(transpose_120, 2);  transpose_120 = None
    expand_195 = torch.ops.aten.expand.default(unsqueeze_104, [1, 2, 4, 128, 256]);  unsqueeze_104 = None
    clone_19 = torch.ops.aten.clone.default(expand_195, memory_format = torch.contiguous_format);  expand_195 = None
    _unsafe_view_200 = torch.ops.aten._unsafe_view.default(clone_19, [1, 8, 128, 256]);  clone_19 = None
    transpose_121 = torch.ops.aten.transpose.int(_unsafe_view_199, 2, 3);  _unsafe_view_199 = None
    expand_196 = torch.ops.aten.expand.default(cat_12, [1, 8, 128, 256]);  cat_12 = None
    view_400 = torch.ops.aten.view.default(expand_196, [8, 128, 256]);  expand_196 = None
    expand_197 = torch.ops.aten.expand.default(transpose_121, [1, 8, 256, 128]);  transpose_121 = None
    view_401 = torch.ops.aten.view.default(expand_197, [8, 256, 128]);  expand_197 = None
    bmm_94 = torch.ops.aten.bmm.default(view_400, view_401);  view_400 = view_401 = None
    _unsafe_view_201 = torch.ops.aten._unsafe_view.default(bmm_94, [1, 8, 128, 128]);  bmm_94 = None
    mul_250 = torch.ops.aten.mul.Tensor(_unsafe_view_201, 0.0625);  _unsafe_view_201 = None
    add_161 = torch.ops.aten.add.Tensor(mul_250, unsqueeze_1);  mul_250 = None
    _to_copy_185 = torch.ops.aten._to_copy.default(add_161, dtype = torch.float32, layout = torch.strided, device = device(type='meta'));  add_161 = None
    _softmax_2 = torch.ops.aten._softmax.default(_to_copy_185, -1, False);  _to_copy_185 = None
    _to_copy_186 = torch.ops.aten._to_copy.default(_softmax_2, dtype = torch.bfloat16);  _softmax_2 = None
    expand_198 = torch.ops.aten.expand.default(_to_copy_186, [1, 8, 128, 128]);  _to_copy_186 = None
    view_402 = torch.ops.aten.view.default(expand_198, [8, 128, 128]);  expand_198 = None
    expand_199 = torch.ops.aten.expand.default(_unsafe_view_200, [1, 8, 128, 256]);  _unsafe_view_200 = None
    view_403 = torch.ops.aten.view.default(expand_199, [8, 128, 256]);  expand_199 = None
    bmm_95 = torch.ops.aten.bmm.default(view_402, view_403);  view_402 = view_403 = None
    _unsafe_view_202 = torch.ops.aten._unsafe_view.default(bmm_95, [1, 8, 128, 256]);  bmm_95 = None
    transpose_122 = torch.ops.aten.transpose.int(_unsafe_view_202, 1, 2);  _unsafe_view_202 = None
    clone_20 = torch.ops.aten.clone.default(transpose_122, memory_format = torch.contiguous_format);  transpose_122 = None
    view_404 = torch.ops.aten.view.default(clone_20, [1, 128, -1]);  clone_20 = None
    sigmoid_11 = torch.ops.aten.sigmoid.default(_unsafe_view_196);  _unsafe_view_196 = None
    mul_251 = torch.ops.aten.mul.Tensor(view_404, sigmoid_11);  view_404 = sigmoid_11 = None
    _param_constant155 = self._param_constant155
    t_89 = torch.ops.aten.t.default(_param_constant155);  _param_constant155 = None
    view_405 = torch.ops.aten.view.default(mul_251, [128, 2048]);  mul_251 = None
    mm_89 = torch.ops.aten.mm.default(view_405, t_89);  view_405 = t_89 = None
    _unsafe_view_203 = torch.ops.aten._unsafe_view.default(mm_89, [1, 128, 2048]);  mm_89 = None
    add_162 = torch.ops.aten.add.Tensor(add_152, _unsafe_view_203);  add_152 = _unsafe_view_203 = None
    _to_copy_187 = torch.ops.aten._to_copy.default(add_162, dtype = torch.float32)
    pow_39 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_187, 2)
    mean_38 = torch.ops.aten.mean.dim(pow_39, [-1], True);  pow_39 = None
    add_163 = torch.ops.aten.add.Tensor(mean_38, 1e-06);  mean_38 = None
    rsqrt_56 = torch.ops.aten.rsqrt.default(add_163);  add_163 = None
    mul_252 = torch.ops.aten.mul.Tensor(_to_copy_187, rsqrt_56);  _to_copy_187 = rsqrt_56 = None
    _param_constant156 = self._param_constant156
    _to_copy_188 = torch.ops.aten._to_copy.default(_param_constant156, dtype = torch.float32);  _param_constant156 = None
    add_164 = torch.ops.aten.add.Tensor(_to_copy_188, 1.0);  _to_copy_188 = None
    mul_253 = torch.ops.aten.mul.Tensor(mul_252, add_164);  mul_252 = add_164 = None
    _to_copy_189 = torch.ops.aten._to_copy.default(mul_253, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_253 = None
    _param_constant157 = self._param_constant157
    t_90 = torch.ops.aten.t.default(_param_constant157);  _param_constant157 = None
    view_406 = torch.ops.aten.view.default(_to_copy_189, [128, 2048])
    mm_90 = torch.ops.aten.mm.default(view_406, t_90);  view_406 = t_90 = None
    _unsafe_view_204 = torch.ops.aten._unsafe_view.default(mm_90, [1, 128, 6144]);  mm_90 = None
    silu_29 = torch.ops.aten.silu.default(_unsafe_view_204);  _unsafe_view_204 = None
    _param_constant158 = self._param_constant158
    t_91 = torch.ops.aten.t.default(_param_constant158);  _param_constant158 = None
    view_407 = torch.ops.aten.view.default(_to_copy_189, [128, 2048]);  _to_copy_189 = None
    mm_91 = torch.ops.aten.mm.default(view_407, t_91);  view_407 = t_91 = None
    _unsafe_view_205 = torch.ops.aten._unsafe_view.default(mm_91, [1, 128, 6144]);  mm_91 = None
    mul_254 = torch.ops.aten.mul.Tensor(silu_29, _unsafe_view_205);  silu_29 = _unsafe_view_205 = None
    _param_constant159 = self._param_constant159
    t_92 = torch.ops.aten.t.default(_param_constant159);  _param_constant159 = None
    view_408 = torch.ops.aten.view.default(mul_254, [128, 6144]);  mul_254 = None
    mm_92 = torch.ops.aten.mm.default(view_408, t_92);  view_408 = t_92 = None
    _unsafe_view_206 = torch.ops.aten._unsafe_view.default(mm_92, [1, 128, 2048]);  mm_92 = None
    add_165 = torch.ops.aten.add.Tensor(add_162, _unsafe_view_206);  add_162 = _unsafe_view_206 = None
    _to_copy_190 = torch.ops.aten._to_copy.default(add_165, dtype = torch.float32)
    pow_40 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_190, 2)
    mean_39 = torch.ops.aten.mean.dim(pow_40, [-1], True);  pow_40 = None
    add_166 = torch.ops.aten.add.Tensor(mean_39, 1e-06);  mean_39 = None
    rsqrt_57 = torch.ops.aten.rsqrt.default(add_166);  add_166 = None
    mul_255 = torch.ops.aten.mul.Tensor(_to_copy_190, rsqrt_57);  _to_copy_190 = rsqrt_57 = None
    _param_constant160 = self._param_constant160
    _to_copy_191 = torch.ops.aten._to_copy.default(_param_constant160, dtype = torch.float32);  _param_constant160 = None
    add_167 = torch.ops.aten.add.Tensor(_to_copy_191, 1.0);  _to_copy_191 = None
    mul_256 = torch.ops.aten.mul.Tensor(mul_255, add_167);  mul_255 = add_167 = None
    _to_copy_192 = torch.ops.aten._to_copy.default(mul_256, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_256 = None
    _param_constant161 = self._param_constant161
    t_93 = torch.ops.aten.t.default(_param_constant161);  _param_constant161 = None
    view_409 = torch.ops.aten.view.default(_to_copy_192, [128, 2048])
    mm_93 = torch.ops.aten.mm.default(view_409, t_93);  view_409 = t_93 = None
    _unsafe_view_207 = torch.ops.aten._unsafe_view.default(mm_93, [1, 128, 6144]);  mm_93 = None
    transpose_123 = torch.ops.aten.transpose.int(_unsafe_view_207, 1, 2);  _unsafe_view_207 = None
    _param_constant162 = self._param_constant162
    t_94 = torch.ops.aten.t.default(_param_constant162);  _param_constant162 = None
    view_410 = torch.ops.aten.view.default(_to_copy_192, [128, 2048])
    mm_94 = torch.ops.aten.mm.default(view_410, t_94);  view_410 = t_94 = None
    _unsafe_view_208 = torch.ops.aten._unsafe_view.default(mm_94, [1, 128, 2048]);  mm_94 = None
    view_411 = torch.ops.aten.view.default(_unsafe_view_208, [1, 128, -1, 128]);  _unsafe_view_208 = None
    _param_constant163 = self._param_constant163
    t_95 = torch.ops.aten.t.default(_param_constant163);  _param_constant163 = None
    view_412 = torch.ops.aten.view.default(_to_copy_192, [128, 2048])
    mm_95 = torch.ops.aten.mm.default(view_412, t_95);  view_412 = t_95 = None
    _unsafe_view_209 = torch.ops.aten._unsafe_view.default(mm_95, [1, 128, 16]);  mm_95 = None
    _param_constant164 = self._param_constant164
    t_96 = torch.ops.aten.t.default(_param_constant164);  _param_constant164 = None
    view_413 = torch.ops.aten.view.default(_to_copy_192, [128, 2048]);  _to_copy_192 = None
    mm_96 = torch.ops.aten.mm.default(view_413, t_96);  view_413 = t_96 = None
    _unsafe_view_210 = torch.ops.aten._unsafe_view.default(mm_96, [1, 128, 16]);  mm_96 = None
    _param_constant165 = self._param_constant165
    squeeze_9 = torch.ops.aten.squeeze.dim(_param_constant165, 1);  _param_constant165 = None
    unsqueeze_105 = torch.ops.aten.unsqueeze.default(squeeze_9, 1);  squeeze_9 = None
    convolution_9 = torch.ops.aten.convolution.default(transpose_123, unsqueeze_105, None, [1], [3], [1], False, [0], 6144);  transpose_123 = unsqueeze_105 = None
    slice_52 = torch.ops.aten.slice.Tensor(convolution_9, 2, 0, 128);  convolution_9 = None
    silu_30 = torch.ops.aten.silu.default(slice_52);  slice_52 = None
    transpose_124 = torch.ops.aten.transpose.int(silu_30, 1, 2);  silu_30 = None
    split_with_sizes_9 = torch.ops.aten.split_with_sizes.default(transpose_124, [2048, 2048, 2048], -1);  transpose_124 = None
    getitem_33 = split_with_sizes_9[0]
    getitem_34 = split_with_sizes_9[1]
    getitem_35 = split_with_sizes_9[2];  split_with_sizes_9 = None
    view_414 = torch.ops.aten.view.default(getitem_33, [1, 128, 16, 128]);  getitem_33 = None
    view_415 = torch.ops.aten.view.default(getitem_34, [1, 128, 16, 128]);  getitem_34 = None
    view_416 = torch.ops.aten.view.default(getitem_35, [1, 128, 16, 128]);  getitem_35 = None
    sigmoid_12 = torch.ops.aten.sigmoid.default(_unsafe_view_209);  _unsafe_view_209 = None
    _param_constant166 = self._param_constant166
    exp_54 = torch.ops.aten.exp.default(_param_constant166);  _param_constant166 = None
    neg_15 = torch.ops.aten.neg.default(exp_54);  exp_54 = None
    _to_copy_193 = torch.ops.aten._to_copy.default(_unsafe_view_210, dtype = torch.float32);  _unsafe_view_210 = None
    _param_constant167 = self._param_constant167
    add_168 = torch.ops.aten.add.Tensor(_to_copy_193, _param_constant167);  _to_copy_193 = _param_constant167 = None
    softplus_9 = torch.ops.aten.softplus.default(add_168);  add_168 = None
    mul_257 = torch.ops.aten.mul.Tensor(neg_15, softplus_9);  neg_15 = softplus_9 = None
    transpose_125 = torch.ops.aten.transpose.int(view_414, 1, 2);  view_414 = None
    _to_copy_194 = torch.ops.aten._to_copy.default(transpose_125, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_125 = None
    transpose_126 = torch.ops.aten.transpose.int(view_415, 1, 2);  view_415 = None
    _to_copy_195 = torch.ops.aten._to_copy.default(transpose_126, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_126 = None
    transpose_127 = torch.ops.aten.transpose.int(view_416, 1, 2);  view_416 = None
    _to_copy_196 = torch.ops.aten._to_copy.default(transpose_127, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_127 = None
    transpose_128 = torch.ops.aten.transpose.int(sigmoid_12, 1, 2);  sigmoid_12 = None
    _to_copy_197 = torch.ops.aten._to_copy.default(transpose_128, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_128 = None
    transpose_129 = torch.ops.aten.transpose.int(mul_257, 1, 2);  mul_257 = None
    mul_258 = torch.ops.aten.mul.Tensor(_to_copy_194, _to_copy_194)
    sum_19 = torch.ops.aten.sum.dim_IntList(mul_258, [-1], True);  mul_258 = None
    add_169 = torch.ops.aten.add.Tensor(sum_19, 1e-06);  sum_19 = None
    rsqrt_58 = torch.ops.aten.rsqrt.default(add_169);  add_169 = None
    mul_259 = torch.ops.aten.mul.Tensor(_to_copy_194, rsqrt_58);  _to_copy_194 = rsqrt_58 = None
    mul_260 = torch.ops.aten.mul.Tensor(_to_copy_195, _to_copy_195)
    sum_20 = torch.ops.aten.sum.dim_IntList(mul_260, [-1], True);  mul_260 = None
    add_170 = torch.ops.aten.add.Tensor(sum_20, 1e-06);  sum_20 = None
    rsqrt_59 = torch.ops.aten.rsqrt.default(add_170);  add_170 = None
    mul_261 = torch.ops.aten.mul.Tensor(_to_copy_195, rsqrt_59);  _to_copy_195 = rsqrt_59 = None
    mul_262 = torch.ops.aten.mul.Tensor(mul_259, 0.08838834764831845);  mul_259 = None
    constant_pad_nd_45 = torch.ops.aten.constant_pad_nd.default(mul_262, [0, 0, 0, 0], 0.0);  mul_262 = None
    constant_pad_nd_46 = torch.ops.aten.constant_pad_nd.default(mul_261, [0, 0, 0, 0], 0.0);  mul_261 = None
    constant_pad_nd_47 = torch.ops.aten.constant_pad_nd.default(_to_copy_196, [0, 0, 0, 0], 0.0);  _to_copy_196 = None
    constant_pad_nd_48 = torch.ops.aten.constant_pad_nd.default(_to_copy_197, [0, 0], 0.0);  _to_copy_197 = None
    constant_pad_nd_49 = torch.ops.aten.constant_pad_nd.default(transpose_129, [0, 0], 0.0);  transpose_129 = None
    unsqueeze_106 = torch.ops.aten.unsqueeze.default(constant_pad_nd_48, -1)
    mul_263 = torch.ops.aten.mul.Tensor(constant_pad_nd_47, unsqueeze_106);  constant_pad_nd_47 = unsqueeze_106 = None
    unsqueeze_107 = torch.ops.aten.unsqueeze.default(constant_pad_nd_48, -1);  constant_pad_nd_48 = None
    mul_264 = torch.ops.aten.mul.Tensor(constant_pad_nd_46, unsqueeze_107);  unsqueeze_107 = None
    view_417 = torch.ops.aten.view.default(constant_pad_nd_45, [1, 16, -1, 64, 128]);  constant_pad_nd_45 = None
    view_418 = torch.ops.aten.view.default(constant_pad_nd_46, [1, 16, -1, 64, 128]);  constant_pad_nd_46 = None
    view_419 = torch.ops.aten.view.default(mul_264, [1, 16, -1, 64, 128]);  mul_264 = None
    view_420 = torch.ops.aten.view.default(mul_263, [1, 16, -1, 64, 128]);  mul_263 = None
    view_421 = torch.ops.aten.view.default(constant_pad_nd_49, [1, 16, 2, 64]);  constant_pad_nd_49 = None
    ones_9 = torch.ops.aten.ones.default([64, 64], dtype = torch.bool, device = device(type='meta'), pin_memory = False)
    triu_10 = torch.ops.aten.triu.default(ones_9, 1);  ones_9 = None
    cumsum_9 = torch.ops.aten.cumsum.default(view_421, 3);  view_421 = None
    unsqueeze_108 = torch.ops.aten.unsqueeze.default(cumsum_9, 4)
    unsqueeze_109 = torch.ops.aten.unsqueeze.default(cumsum_9, 3)
    sub_36 = torch.ops.aten.sub.Tensor(unsqueeze_108, unsqueeze_109);  unsqueeze_108 = unsqueeze_109 = None
    masked_fill_9 = torch.ops.aten.masked_fill.Scalar(sub_36, triu_10, -inf);  sub_36 = triu_10 = None
    exp_55 = torch.ops.aten.exp.default(masked_fill_9);  masked_fill_9 = None
    transpose_130 = torch.ops.aten.transpose.int(view_418, -1, -2)
    expand_200 = torch.ops.aten.expand.default(view_419, [1, 16, 2, 64, 128])
    view_422 = torch.ops.aten.view.default(expand_200, [32, 64, 128]);  expand_200 = None
    expand_201 = torch.ops.aten.expand.default(transpose_130, [1, 16, 2, 128, 64]);  transpose_130 = None
    view_423 = torch.ops.aten.view.default(expand_201, [32, 128, 64]);  expand_201 = None
    bmm_96 = torch.ops.aten.bmm.default(view_422, view_423);  view_422 = view_423 = None
    _unsafe_view_211 = torch.ops.aten._unsafe_view.default(bmm_96, [1, 16, 2, 64, 64]);  bmm_96 = None
    mul_265 = torch.ops.aten.mul.Tensor(_unsafe_view_211, exp_55);  _unsafe_view_211 = None
    transpose_131 = torch.ops.aten.transpose.int(view_418, -1, -2)
    expand_202 = torch.ops.aten.expand.default(view_417, [1, 16, 2, 64, 128])
    view_424 = torch.ops.aten.view.default(expand_202, [32, 64, 128]);  expand_202 = None
    expand_203 = torch.ops.aten.expand.default(transpose_131, [1, 16, 2, 128, 64]);  transpose_131 = None
    view_425 = torch.ops.aten.view.default(expand_203, [32, 128, 64]);  expand_203 = None
    bmm_97 = torch.ops.aten.bmm.default(view_424, view_425);  view_424 = view_425 = None
    _unsafe_view_212 = torch.ops.aten._unsafe_view.default(bmm_97, [1, 16, 2, 64, 64]);  bmm_97 = None
    mul_266 = torch.ops.aten.mul.Tensor(_unsafe_view_212, exp_55);  _unsafe_view_212 = exp_55 = None
    exp_56 = torch.ops.aten.exp.default(cumsum_9)
    unsqueeze_110 = torch.ops.aten.unsqueeze.default(exp_56, -1);  exp_56 = None
    mul_267 = torch.ops.aten.mul.Tensor(view_419, unsqueeze_110);  view_419 = unsqueeze_110 = None
    linalg_solve_triangular_18 = torch.ops.aten.linalg_solve_triangular.default(mul_265, view_420, upper = False, unitriangular = True);  view_420 = None
    linalg_solve_triangular_19 = torch.ops.aten.linalg_solve_triangular.default(mul_265, mul_267, upper = False, unitriangular = True);  mul_265 = mul_267 = None
    zeros_9 = torch.ops.aten.zeros.default([1, 16, 128, 128], dtype = torch.float32, device = device(type='meta'), pin_memory = False)
    zeros_like_9 = torch.ops.aten.zeros_like.default(linalg_solve_triangular_18, pin_memory = False)
    exp_57 = torch.ops.aten.exp.default(cumsum_9)
    unsqueeze_111 = torch.ops.aten.unsqueeze.default(exp_57, -1);  exp_57 = None
    mul_268 = torch.ops.aten.mul.Tensor(view_417, unsqueeze_111);  view_417 = unsqueeze_111 = None
    slice_53 = torch.ops.aten.slice.Tensor(cumsum_9, 3, -1, 9223372036854775807)
    sub_37 = torch.ops.aten.sub.Tensor(slice_53, cumsum_9);  slice_53 = None
    exp_58 = torch.ops.aten.exp.default(sub_37);  sub_37 = None
    unsqueeze_112 = torch.ops.aten.unsqueeze.default(exp_58, -1);  exp_58 = None
    mul_269 = torch.ops.aten.mul.Tensor(view_418, unsqueeze_112);  view_418 = unsqueeze_112 = None
    select_142 = torch.ops.aten.select.int(cumsum_9, 3, -1);  cumsum_9 = None
    exp_59 = torch.ops.aten.exp.default(select_142);  select_142 = None
    unsqueeze_113 = torch.ops.aten.unsqueeze.default(exp_59, 3);  exp_59 = None
    unsqueeze_114 = torch.ops.aten.unsqueeze.default(unsqueeze_113, 4);  unsqueeze_113 = None
    select_143 = torch.ops.aten.select.int(linalg_solve_triangular_18, 2, 0)
    select_144 = torch.ops.aten.select.int(linalg_solve_triangular_19, 2, 0)
    expand_204 = torch.ops.aten.expand.default(select_144, [1, 16, 64, 128]);  select_144 = None
    view_426 = torch.ops.aten.view.default(expand_204, [16, 64, 128]);  expand_204 = None
    expand_205 = torch.ops.aten.expand.default(zeros_9, [1, 16, 128, 128])
    view_427 = torch.ops.aten.view.default(expand_205, [16, 128, 128]);  expand_205 = None
    bmm_98 = torch.ops.aten.bmm.default(view_426, view_427);  view_426 = view_427 = None
    _unsafe_view_213 = torch.ops.aten._unsafe_view.default(bmm_98, [1, 16, 64, 128]);  bmm_98 = None
    sub_38 = torch.ops.aten.sub.Tensor(select_143, _unsafe_view_213);  select_143 = _unsafe_view_213 = None
    select_145 = torch.ops.aten.select.int(mul_268, 2, 0)
    expand_206 = torch.ops.aten.expand.default(select_145, [1, 16, 64, 128]);  select_145 = None
    view_428 = torch.ops.aten.view.default(expand_206, [16, 64, 128]);  expand_206 = None
    expand_207 = torch.ops.aten.expand.default(zeros_9, [1, 16, 128, 128])
    view_429 = torch.ops.aten.view.default(expand_207, [16, 128, 128]);  expand_207 = None
    bmm_99 = torch.ops.aten.bmm.default(view_428, view_429);  view_428 = view_429 = None
    _unsafe_view_214 = torch.ops.aten._unsafe_view.default(bmm_99, [1, 16, 64, 128]);  bmm_99 = None
    select_146 = torch.ops.aten.select.int(mul_266, 2, 0)
    expand_208 = torch.ops.aten.expand.default(select_146, [1, 16, 64, 64]);  select_146 = None
    view_430 = torch.ops.aten.view.default(expand_208, [16, 64, 64]);  expand_208 = None
    expand_209 = torch.ops.aten.expand.default(sub_38, [1, 16, 64, 128])
    view_431 = torch.ops.aten.view.default(expand_209, [16, 64, 128]);  expand_209 = None
    bmm_100 = torch.ops.aten.bmm.default(view_430, view_431);  view_430 = view_431 = None
    _unsafe_view_215 = torch.ops.aten._unsafe_view.default(bmm_100, [1, 16, 64, 128]);  bmm_100 = None
    add_171 = torch.ops.aten.add.Tensor(_unsafe_view_214, _unsafe_view_215);  _unsafe_view_214 = _unsafe_view_215 = None
    select_147 = torch.ops.aten.select.int(zeros_like_9, 2, 0)
    copy__22 = torch.ops.aten.copy_.default(select_147, add_171);  select_147 = add_171 = copy__22 = None
    select_148 = torch.ops.aten.select.int(unsqueeze_114, 2, 0)
    mul_270 = torch.ops.aten.mul.Tensor(zeros_9, select_148);  zeros_9 = select_148 = None
    select_149 = torch.ops.aten.select.int(mul_269, 2, 0)
    transpose_132 = torch.ops.aten.transpose.int(select_149, -1, -2);  select_149 = None
    expand_210 = torch.ops.aten.expand.default(transpose_132, [1, 16, 128, 64]);  transpose_132 = None
    view_432 = torch.ops.aten.view.default(expand_210, [16, 128, 64]);  expand_210 = None
    expand_211 = torch.ops.aten.expand.default(sub_38, [1, 16, 64, 128]);  sub_38 = None
    view_433 = torch.ops.aten.view.default(expand_211, [16, 64, 128]);  expand_211 = None
    bmm_101 = torch.ops.aten.bmm.default(view_432, view_433);  view_432 = view_433 = None
    _unsafe_view_216 = torch.ops.aten._unsafe_view.default(bmm_101, [1, 16, 128, 128]);  bmm_101 = None
    add_172 = torch.ops.aten.add.Tensor(mul_270, _unsafe_view_216);  mul_270 = _unsafe_view_216 = None
    select_150 = torch.ops.aten.select.int(linalg_solve_triangular_18, 2, 1);  linalg_solve_triangular_18 = None
    select_151 = torch.ops.aten.select.int(linalg_solve_triangular_19, 2, 1);  linalg_solve_triangular_19 = None
    expand_212 = torch.ops.aten.expand.default(select_151, [1, 16, 64, 128]);  select_151 = None
    view_434 = torch.ops.aten.view.default(expand_212, [16, 64, 128]);  expand_212 = None
    expand_213 = torch.ops.aten.expand.default(add_172, [1, 16, 128, 128])
    view_435 = torch.ops.aten.view.default(expand_213, [16, 128, 128]);  expand_213 = None
    bmm_102 = torch.ops.aten.bmm.default(view_434, view_435);  view_434 = view_435 = None
    _unsafe_view_217 = torch.ops.aten._unsafe_view.default(bmm_102, [1, 16, 64, 128]);  bmm_102 = None
    sub_39 = torch.ops.aten.sub.Tensor(select_150, _unsafe_view_217);  select_150 = _unsafe_view_217 = None
    select_152 = torch.ops.aten.select.int(mul_268, 2, 1);  mul_268 = None
    expand_214 = torch.ops.aten.expand.default(select_152, [1, 16, 64, 128]);  select_152 = None
    view_436 = torch.ops.aten.view.default(expand_214, [16, 64, 128]);  expand_214 = None
    expand_215 = torch.ops.aten.expand.default(add_172, [1, 16, 128, 128])
    view_437 = torch.ops.aten.view.default(expand_215, [16, 128, 128]);  expand_215 = None
    bmm_103 = torch.ops.aten.bmm.default(view_436, view_437);  view_436 = view_437 = None
    _unsafe_view_218 = torch.ops.aten._unsafe_view.default(bmm_103, [1, 16, 64, 128]);  bmm_103 = None
    select_153 = torch.ops.aten.select.int(mul_266, 2, 1);  mul_266 = None
    expand_216 = torch.ops.aten.expand.default(select_153, [1, 16, 64, 64]);  select_153 = None
    view_438 = torch.ops.aten.view.default(expand_216, [16, 64, 64]);  expand_216 = None
    expand_217 = torch.ops.aten.expand.default(sub_39, [1, 16, 64, 128])
    view_439 = torch.ops.aten.view.default(expand_217, [16, 64, 128]);  expand_217 = None
    bmm_104 = torch.ops.aten.bmm.default(view_438, view_439);  view_438 = view_439 = None
    _unsafe_view_219 = torch.ops.aten._unsafe_view.default(bmm_104, [1, 16, 64, 128]);  bmm_104 = None
    add_173 = torch.ops.aten.add.Tensor(_unsafe_view_218, _unsafe_view_219);  _unsafe_view_218 = _unsafe_view_219 = None
    select_154 = torch.ops.aten.select.int(zeros_like_9, 2, 1)
    copy__23 = torch.ops.aten.copy_.default(select_154, add_173);  select_154 = add_173 = copy__23 = None
    select_155 = torch.ops.aten.select.int(unsqueeze_114, 2, 1);  unsqueeze_114 = None
    mul_271 = torch.ops.aten.mul.Tensor(add_172, select_155);  add_172 = select_155 = None
    select_156 = torch.ops.aten.select.int(mul_269, 2, 1);  mul_269 = None
    transpose_133 = torch.ops.aten.transpose.int(select_156, -1, -2);  select_156 = None
    expand_218 = torch.ops.aten.expand.default(transpose_133, [1, 16, 128, 64]);  transpose_133 = None
    view_440 = torch.ops.aten.view.default(expand_218, [16, 128, 64]);  expand_218 = None
    expand_219 = torch.ops.aten.expand.default(sub_39, [1, 16, 64, 128]);  sub_39 = None
    view_441 = torch.ops.aten.view.default(expand_219, [16, 64, 128]);  expand_219 = None
    bmm_105 = torch.ops.aten.bmm.default(view_440, view_441);  view_440 = view_441 = None
    _unsafe_view_220 = torch.ops.aten._unsafe_view.default(bmm_105, [1, 16, 128, 128]);  bmm_105 = None
    add_174 = torch.ops.aten.add.Tensor(mul_271, _unsafe_view_220);  mul_271 = _unsafe_view_220 = add_174 = None
    clone_21 = torch.ops.aten.clone.default(zeros_like_9, memory_format = torch.contiguous_format);  zeros_like_9 = None
    _unsafe_view_221 = torch.ops.aten._unsafe_view.default(clone_21, [1, 16, 128, 128]);  clone_21 = None
    alias_9 = torch.ops.aten.alias.default(_unsafe_view_221);  _unsafe_view_221 = None
    transpose_134 = torch.ops.aten.transpose.int(alias_9, 1, 2);  alias_9 = None
    _to_copy_198 = torch.ops.aten._to_copy.default(transpose_134, dtype = torch.bfloat16, memory_format = torch.contiguous_format);  transpose_134 = None
    view_442 = torch.ops.aten.view.default(_to_copy_198, [-1, 128]);  _to_copy_198 = None
    view_443 = torch.ops.aten.view.default(view_411, [-1, 128]);  view_411 = None
    _to_copy_199 = torch.ops.aten._to_copy.default(view_442, dtype = torch.float32);  view_442 = None
    pow_41 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_199, 2)
    mean_40 = torch.ops.aten.mean.dim(pow_41, [-1], True);  pow_41 = None
    add_175 = torch.ops.aten.add.Tensor(mean_40, 1e-06);  mean_40 = None
    rsqrt_60 = torch.ops.aten.rsqrt.default(add_175);  add_175 = None
    mul_272 = torch.ops.aten.mul.Tensor(_to_copy_199, rsqrt_60);  _to_copy_199 = rsqrt_60 = None
    _to_copy_200 = torch.ops.aten._to_copy.default(mul_272, dtype = torch.bfloat16);  mul_272 = None
    _param_constant168 = self._param_constant168
    mul_273 = torch.ops.aten.mul.Tensor(_param_constant168, _to_copy_200);  _param_constant168 = _to_copy_200 = None
    _to_copy_201 = torch.ops.aten._to_copy.default(view_443, dtype = torch.float32);  view_443 = None
    silu_31 = torch.ops.aten.silu.default(_to_copy_201);  _to_copy_201 = None
    mul_274 = torch.ops.aten.mul.Tensor(mul_273, silu_31);  mul_273 = silu_31 = None
    _to_copy_202 = torch.ops.aten._to_copy.default(mul_274, dtype = torch.bfloat16);  mul_274 = None
    view_444 = torch.ops.aten.view.default(_to_copy_202, [1, 128, -1]);  _to_copy_202 = None
    _param_constant169 = self._param_constant169
    t_97 = torch.ops.aten.t.default(_param_constant169);  _param_constant169 = None
    view_445 = torch.ops.aten.view.default(view_444, [128, 2048]);  view_444 = None
    mm_97 = torch.ops.aten.mm.default(view_445, t_97);  view_445 = t_97 = None
    _unsafe_view_222 = torch.ops.aten._unsafe_view.default(mm_97, [1, 128, 2048]);  mm_97 = None
    add_176 = torch.ops.aten.add.Tensor(add_165, _unsafe_view_222);  add_165 = _unsafe_view_222 = None
    _to_copy_203 = torch.ops.aten._to_copy.default(add_176, dtype = torch.float32)
    pow_42 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_203, 2)
    mean_41 = torch.ops.aten.mean.dim(pow_42, [-1], True);  pow_42 = None
    add_177 = torch.ops.aten.add.Tensor(mean_41, 1e-06);  mean_41 = None
    rsqrt_61 = torch.ops.aten.rsqrt.default(add_177);  add_177 = None
    mul_275 = torch.ops.aten.mul.Tensor(_to_copy_203, rsqrt_61);  _to_copy_203 = rsqrt_61 = None
    _param_constant170 = self._param_constant170
    _to_copy_204 = torch.ops.aten._to_copy.default(_param_constant170, dtype = torch.float32);  _param_constant170 = None
    add_178 = torch.ops.aten.add.Tensor(_to_copy_204, 1.0);  _to_copy_204 = None
    mul_276 = torch.ops.aten.mul.Tensor(mul_275, add_178);  mul_275 = add_178 = None
    _to_copy_205 = torch.ops.aten._to_copy.default(mul_276, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_276 = None
    _param_constant171 = self._param_constant171
    t_98 = torch.ops.aten.t.default(_param_constant171);  _param_constant171 = None
    view_446 = torch.ops.aten.view.default(_to_copy_205, [128, 2048])
    mm_98 = torch.ops.aten.mm.default(view_446, t_98);  view_446 = t_98 = None
    _unsafe_view_223 = torch.ops.aten._unsafe_view.default(mm_98, [1, 128, 6144]);  mm_98 = None
    silu_32 = torch.ops.aten.silu.default(_unsafe_view_223);  _unsafe_view_223 = None
    _param_constant172 = self._param_constant172
    t_99 = torch.ops.aten.t.default(_param_constant172);  _param_constant172 = None
    view_447 = torch.ops.aten.view.default(_to_copy_205, [128, 2048]);  _to_copy_205 = None
    mm_99 = torch.ops.aten.mm.default(view_447, t_99);  view_447 = t_99 = None
    _unsafe_view_224 = torch.ops.aten._unsafe_view.default(mm_99, [1, 128, 6144]);  mm_99 = None
    mul_277 = torch.ops.aten.mul.Tensor(silu_32, _unsafe_view_224);  silu_32 = _unsafe_view_224 = None
    _param_constant173 = self._param_constant173
    t_100 = torch.ops.aten.t.default(_param_constant173);  _param_constant173 = None
    view_448 = torch.ops.aten.view.default(mul_277, [128, 6144]);  mul_277 = None
    mm_100 = torch.ops.aten.mm.default(view_448, t_100);  view_448 = t_100 = None
    _unsafe_view_225 = torch.ops.aten._unsafe_view.default(mm_100, [1, 128, 2048]);  mm_100 = None
    add_179 = torch.ops.aten.add.Tensor(add_176, _unsafe_view_225);  add_176 = _unsafe_view_225 = None
    _to_copy_206 = torch.ops.aten._to_copy.default(add_179, dtype = torch.float32)
    pow_43 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_206, 2)
    mean_42 = torch.ops.aten.mean.dim(pow_43, [-1], True);  pow_43 = None
    add_180 = torch.ops.aten.add.Tensor(mean_42, 1e-06);  mean_42 = None
    rsqrt_62 = torch.ops.aten.rsqrt.default(add_180);  add_180 = None
    mul_278 = torch.ops.aten.mul.Tensor(_to_copy_206, rsqrt_62);  _to_copy_206 = rsqrt_62 = None
    _param_constant174 = self._param_constant174
    _to_copy_207 = torch.ops.aten._to_copy.default(_param_constant174, dtype = torch.float32);  _param_constant174 = None
    add_181 = torch.ops.aten.add.Tensor(_to_copy_207, 1.0);  _to_copy_207 = None
    mul_279 = torch.ops.aten.mul.Tensor(mul_278, add_181);  mul_278 = add_181 = None
    _to_copy_208 = torch.ops.aten._to_copy.default(mul_279, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_279 = None
    _param_constant175 = self._param_constant175
    t_101 = torch.ops.aten.t.default(_param_constant175);  _param_constant175 = None
    view_449 = torch.ops.aten.view.default(_to_copy_208, [128, 2048])
    mm_101 = torch.ops.aten.mm.default(view_449, t_101);  view_449 = t_101 = None
    _unsafe_view_226 = torch.ops.aten._unsafe_view.default(mm_101, [1, 128, 6144]);  mm_101 = None
    transpose_135 = torch.ops.aten.transpose.int(_unsafe_view_226, 1, 2);  _unsafe_view_226 = None
    _param_constant176 = self._param_constant176
    t_102 = torch.ops.aten.t.default(_param_constant176);  _param_constant176 = None
    view_450 = torch.ops.aten.view.default(_to_copy_208, [128, 2048])
    mm_102 = torch.ops.aten.mm.default(view_450, t_102);  view_450 = t_102 = None
    _unsafe_view_227 = torch.ops.aten._unsafe_view.default(mm_102, [1, 128, 2048]);  mm_102 = None
    view_451 = torch.ops.aten.view.default(_unsafe_view_227, [1, 128, -1, 128]);  _unsafe_view_227 = None
    _param_constant177 = self._param_constant177
    t_103 = torch.ops.aten.t.default(_param_constant177);  _param_constant177 = None
    view_452 = torch.ops.aten.view.default(_to_copy_208, [128, 2048])
    mm_103 = torch.ops.aten.mm.default(view_452, t_103);  view_452 = t_103 = None
    _unsafe_view_228 = torch.ops.aten._unsafe_view.default(mm_103, [1, 128, 16]);  mm_103 = None
    _param_constant178 = self._param_constant178
    t_104 = torch.ops.aten.t.default(_param_constant178);  _param_constant178 = None
    view_453 = torch.ops.aten.view.default(_to_copy_208, [128, 2048]);  _to_copy_208 = None
    mm_104 = torch.ops.aten.mm.default(view_453, t_104);  view_453 = t_104 = None
    _unsafe_view_229 = torch.ops.aten._unsafe_view.default(mm_104, [1, 128, 16]);  mm_104 = None
    _param_constant179 = self._param_constant179
    squeeze_10 = torch.ops.aten.squeeze.dim(_param_constant179, 1);  _param_constant179 = None
    unsqueeze_115 = torch.ops.aten.unsqueeze.default(squeeze_10, 1);  squeeze_10 = None
    convolution_10 = torch.ops.aten.convolution.default(transpose_135, unsqueeze_115, None, [1], [3], [1], False, [0], 6144);  transpose_135 = unsqueeze_115 = None
    slice_54 = torch.ops.aten.slice.Tensor(convolution_10, 2, 0, 128);  convolution_10 = None
    silu_33 = torch.ops.aten.silu.default(slice_54);  slice_54 = None
    transpose_136 = torch.ops.aten.transpose.int(silu_33, 1, 2);  silu_33 = None
    split_with_sizes_10 = torch.ops.aten.split_with_sizes.default(transpose_136, [2048, 2048, 2048], -1);  transpose_136 = None
    getitem_36 = split_with_sizes_10[0]
    getitem_37 = split_with_sizes_10[1]
    getitem_38 = split_with_sizes_10[2];  split_with_sizes_10 = None
    view_454 = torch.ops.aten.view.default(getitem_36, [1, 128, 16, 128]);  getitem_36 = None
    view_455 = torch.ops.aten.view.default(getitem_37, [1, 128, 16, 128]);  getitem_37 = None
    view_456 = torch.ops.aten.view.default(getitem_38, [1, 128, 16, 128]);  getitem_38 = None
    sigmoid_13 = torch.ops.aten.sigmoid.default(_unsafe_view_228);  _unsafe_view_228 = None
    _param_constant180 = self._param_constant180
    exp_60 = torch.ops.aten.exp.default(_param_constant180);  _param_constant180 = None
    neg_16 = torch.ops.aten.neg.default(exp_60);  exp_60 = None
    _to_copy_209 = torch.ops.aten._to_copy.default(_unsafe_view_229, dtype = torch.float32);  _unsafe_view_229 = None
    _param_constant181 = self._param_constant181
    add_182 = torch.ops.aten.add.Tensor(_to_copy_209, _param_constant181);  _to_copy_209 = _param_constant181 = None
    softplus_10 = torch.ops.aten.softplus.default(add_182);  add_182 = None
    mul_280 = torch.ops.aten.mul.Tensor(neg_16, softplus_10);  neg_16 = softplus_10 = None
    transpose_137 = torch.ops.aten.transpose.int(view_454, 1, 2);  view_454 = None
    _to_copy_210 = torch.ops.aten._to_copy.default(transpose_137, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_137 = None
    transpose_138 = torch.ops.aten.transpose.int(view_455, 1, 2);  view_455 = None
    _to_copy_211 = torch.ops.aten._to_copy.default(transpose_138, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_138 = None
    transpose_139 = torch.ops.aten.transpose.int(view_456, 1, 2);  view_456 = None
    _to_copy_212 = torch.ops.aten._to_copy.default(transpose_139, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_139 = None
    transpose_140 = torch.ops.aten.transpose.int(sigmoid_13, 1, 2);  sigmoid_13 = None
    _to_copy_213 = torch.ops.aten._to_copy.default(transpose_140, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_140 = None
    transpose_141 = torch.ops.aten.transpose.int(mul_280, 1, 2);  mul_280 = None
    mul_281 = torch.ops.aten.mul.Tensor(_to_copy_210, _to_copy_210)
    sum_21 = torch.ops.aten.sum.dim_IntList(mul_281, [-1], True);  mul_281 = None
    add_183 = torch.ops.aten.add.Tensor(sum_21, 1e-06);  sum_21 = None
    rsqrt_63 = torch.ops.aten.rsqrt.default(add_183);  add_183 = None
    mul_282 = torch.ops.aten.mul.Tensor(_to_copy_210, rsqrt_63);  _to_copy_210 = rsqrt_63 = None
    mul_283 = torch.ops.aten.mul.Tensor(_to_copy_211, _to_copy_211)
    sum_22 = torch.ops.aten.sum.dim_IntList(mul_283, [-1], True);  mul_283 = None
    add_184 = torch.ops.aten.add.Tensor(sum_22, 1e-06);  sum_22 = None
    rsqrt_64 = torch.ops.aten.rsqrt.default(add_184);  add_184 = None
    mul_284 = torch.ops.aten.mul.Tensor(_to_copy_211, rsqrt_64);  _to_copy_211 = rsqrt_64 = None
    mul_285 = torch.ops.aten.mul.Tensor(mul_282, 0.08838834764831845);  mul_282 = None
    constant_pad_nd_50 = torch.ops.aten.constant_pad_nd.default(mul_285, [0, 0, 0, 0], 0.0);  mul_285 = None
    constant_pad_nd_51 = torch.ops.aten.constant_pad_nd.default(mul_284, [0, 0, 0, 0], 0.0);  mul_284 = None
    constant_pad_nd_52 = torch.ops.aten.constant_pad_nd.default(_to_copy_212, [0, 0, 0, 0], 0.0);  _to_copy_212 = None
    constant_pad_nd_53 = torch.ops.aten.constant_pad_nd.default(_to_copy_213, [0, 0], 0.0);  _to_copy_213 = None
    constant_pad_nd_54 = torch.ops.aten.constant_pad_nd.default(transpose_141, [0, 0], 0.0);  transpose_141 = None
    unsqueeze_116 = torch.ops.aten.unsqueeze.default(constant_pad_nd_53, -1)
    mul_286 = torch.ops.aten.mul.Tensor(constant_pad_nd_52, unsqueeze_116);  constant_pad_nd_52 = unsqueeze_116 = None
    unsqueeze_117 = torch.ops.aten.unsqueeze.default(constant_pad_nd_53, -1);  constant_pad_nd_53 = None
    mul_287 = torch.ops.aten.mul.Tensor(constant_pad_nd_51, unsqueeze_117);  unsqueeze_117 = None
    view_457 = torch.ops.aten.view.default(constant_pad_nd_50, [1, 16, -1, 64, 128]);  constant_pad_nd_50 = None
    view_458 = torch.ops.aten.view.default(constant_pad_nd_51, [1, 16, -1, 64, 128]);  constant_pad_nd_51 = None
    view_459 = torch.ops.aten.view.default(mul_287, [1, 16, -1, 64, 128]);  mul_287 = None
    view_460 = torch.ops.aten.view.default(mul_286, [1, 16, -1, 64, 128]);  mul_286 = None
    view_461 = torch.ops.aten.view.default(constant_pad_nd_54, [1, 16, 2, 64]);  constant_pad_nd_54 = None
    ones_10 = torch.ops.aten.ones.default([64, 64], dtype = torch.bool, device = device(type='meta'), pin_memory = False)
    triu_11 = torch.ops.aten.triu.default(ones_10, 1);  ones_10 = None
    cumsum_10 = torch.ops.aten.cumsum.default(view_461, 3);  view_461 = None
    unsqueeze_118 = torch.ops.aten.unsqueeze.default(cumsum_10, 4)
    unsqueeze_119 = torch.ops.aten.unsqueeze.default(cumsum_10, 3)
    sub_40 = torch.ops.aten.sub.Tensor(unsqueeze_118, unsqueeze_119);  unsqueeze_118 = unsqueeze_119 = None
    masked_fill_10 = torch.ops.aten.masked_fill.Scalar(sub_40, triu_11, -inf);  sub_40 = triu_11 = None
    exp_61 = torch.ops.aten.exp.default(masked_fill_10);  masked_fill_10 = None
    transpose_142 = torch.ops.aten.transpose.int(view_458, -1, -2)
    expand_220 = torch.ops.aten.expand.default(view_459, [1, 16, 2, 64, 128])
    view_462 = torch.ops.aten.view.default(expand_220, [32, 64, 128]);  expand_220 = None
    expand_221 = torch.ops.aten.expand.default(transpose_142, [1, 16, 2, 128, 64]);  transpose_142 = None
    view_463 = torch.ops.aten.view.default(expand_221, [32, 128, 64]);  expand_221 = None
    bmm_106 = torch.ops.aten.bmm.default(view_462, view_463);  view_462 = view_463 = None
    _unsafe_view_230 = torch.ops.aten._unsafe_view.default(bmm_106, [1, 16, 2, 64, 64]);  bmm_106 = None
    mul_288 = torch.ops.aten.mul.Tensor(_unsafe_view_230, exp_61);  _unsafe_view_230 = None
    transpose_143 = torch.ops.aten.transpose.int(view_458, -1, -2)
    expand_222 = torch.ops.aten.expand.default(view_457, [1, 16, 2, 64, 128])
    view_464 = torch.ops.aten.view.default(expand_222, [32, 64, 128]);  expand_222 = None
    expand_223 = torch.ops.aten.expand.default(transpose_143, [1, 16, 2, 128, 64]);  transpose_143 = None
    view_465 = torch.ops.aten.view.default(expand_223, [32, 128, 64]);  expand_223 = None
    bmm_107 = torch.ops.aten.bmm.default(view_464, view_465);  view_464 = view_465 = None
    _unsafe_view_231 = torch.ops.aten._unsafe_view.default(bmm_107, [1, 16, 2, 64, 64]);  bmm_107 = None
    mul_289 = torch.ops.aten.mul.Tensor(_unsafe_view_231, exp_61);  _unsafe_view_231 = exp_61 = None
    exp_62 = torch.ops.aten.exp.default(cumsum_10)
    unsqueeze_120 = torch.ops.aten.unsqueeze.default(exp_62, -1);  exp_62 = None
    mul_290 = torch.ops.aten.mul.Tensor(view_459, unsqueeze_120);  view_459 = unsqueeze_120 = None
    linalg_solve_triangular_20 = torch.ops.aten.linalg_solve_triangular.default(mul_288, view_460, upper = False, unitriangular = True);  view_460 = None
    linalg_solve_triangular_21 = torch.ops.aten.linalg_solve_triangular.default(mul_288, mul_290, upper = False, unitriangular = True);  mul_288 = mul_290 = None
    zeros_10 = torch.ops.aten.zeros.default([1, 16, 128, 128], dtype = torch.float32, device = device(type='meta'), pin_memory = False)
    zeros_like_10 = torch.ops.aten.zeros_like.default(linalg_solve_triangular_20, pin_memory = False)
    exp_63 = torch.ops.aten.exp.default(cumsum_10)
    unsqueeze_121 = torch.ops.aten.unsqueeze.default(exp_63, -1);  exp_63 = None
    mul_291 = torch.ops.aten.mul.Tensor(view_457, unsqueeze_121);  view_457 = unsqueeze_121 = None
    slice_55 = torch.ops.aten.slice.Tensor(cumsum_10, 3, -1, 9223372036854775807)
    sub_41 = torch.ops.aten.sub.Tensor(slice_55, cumsum_10);  slice_55 = None
    exp_64 = torch.ops.aten.exp.default(sub_41);  sub_41 = None
    unsqueeze_122 = torch.ops.aten.unsqueeze.default(exp_64, -1);  exp_64 = None
    mul_292 = torch.ops.aten.mul.Tensor(view_458, unsqueeze_122);  view_458 = unsqueeze_122 = None
    select_157 = torch.ops.aten.select.int(cumsum_10, 3, -1);  cumsum_10 = None
    exp_65 = torch.ops.aten.exp.default(select_157);  select_157 = None
    unsqueeze_123 = torch.ops.aten.unsqueeze.default(exp_65, 3);  exp_65 = None
    unsqueeze_124 = torch.ops.aten.unsqueeze.default(unsqueeze_123, 4);  unsqueeze_123 = None
    select_158 = torch.ops.aten.select.int(linalg_solve_triangular_20, 2, 0)
    select_159 = torch.ops.aten.select.int(linalg_solve_triangular_21, 2, 0)
    expand_224 = torch.ops.aten.expand.default(select_159, [1, 16, 64, 128]);  select_159 = None
    view_466 = torch.ops.aten.view.default(expand_224, [16, 64, 128]);  expand_224 = None
    expand_225 = torch.ops.aten.expand.default(zeros_10, [1, 16, 128, 128])
    view_467 = torch.ops.aten.view.default(expand_225, [16, 128, 128]);  expand_225 = None
    bmm_108 = torch.ops.aten.bmm.default(view_466, view_467);  view_466 = view_467 = None
    _unsafe_view_232 = torch.ops.aten._unsafe_view.default(bmm_108, [1, 16, 64, 128]);  bmm_108 = None
    sub_42 = torch.ops.aten.sub.Tensor(select_158, _unsafe_view_232);  select_158 = _unsafe_view_232 = None
    select_160 = torch.ops.aten.select.int(mul_291, 2, 0)
    expand_226 = torch.ops.aten.expand.default(select_160, [1, 16, 64, 128]);  select_160 = None
    view_468 = torch.ops.aten.view.default(expand_226, [16, 64, 128]);  expand_226 = None
    expand_227 = torch.ops.aten.expand.default(zeros_10, [1, 16, 128, 128])
    view_469 = torch.ops.aten.view.default(expand_227, [16, 128, 128]);  expand_227 = None
    bmm_109 = torch.ops.aten.bmm.default(view_468, view_469);  view_468 = view_469 = None
    _unsafe_view_233 = torch.ops.aten._unsafe_view.default(bmm_109, [1, 16, 64, 128]);  bmm_109 = None
    select_161 = torch.ops.aten.select.int(mul_289, 2, 0)
    expand_228 = torch.ops.aten.expand.default(select_161, [1, 16, 64, 64]);  select_161 = None
    view_470 = torch.ops.aten.view.default(expand_228, [16, 64, 64]);  expand_228 = None
    expand_229 = torch.ops.aten.expand.default(sub_42, [1, 16, 64, 128])
    view_471 = torch.ops.aten.view.default(expand_229, [16, 64, 128]);  expand_229 = None
    bmm_110 = torch.ops.aten.bmm.default(view_470, view_471);  view_470 = view_471 = None
    _unsafe_view_234 = torch.ops.aten._unsafe_view.default(bmm_110, [1, 16, 64, 128]);  bmm_110 = None
    add_185 = torch.ops.aten.add.Tensor(_unsafe_view_233, _unsafe_view_234);  _unsafe_view_233 = _unsafe_view_234 = None
    select_162 = torch.ops.aten.select.int(zeros_like_10, 2, 0)
    copy__24 = torch.ops.aten.copy_.default(select_162, add_185);  select_162 = add_185 = copy__24 = None
    select_163 = torch.ops.aten.select.int(unsqueeze_124, 2, 0)
    mul_293 = torch.ops.aten.mul.Tensor(zeros_10, select_163);  zeros_10 = select_163 = None
    select_164 = torch.ops.aten.select.int(mul_292, 2, 0)
    transpose_144 = torch.ops.aten.transpose.int(select_164, -1, -2);  select_164 = None
    expand_230 = torch.ops.aten.expand.default(transpose_144, [1, 16, 128, 64]);  transpose_144 = None
    view_472 = torch.ops.aten.view.default(expand_230, [16, 128, 64]);  expand_230 = None
    expand_231 = torch.ops.aten.expand.default(sub_42, [1, 16, 64, 128]);  sub_42 = None
    view_473 = torch.ops.aten.view.default(expand_231, [16, 64, 128]);  expand_231 = None
    bmm_111 = torch.ops.aten.bmm.default(view_472, view_473);  view_472 = view_473 = None
    _unsafe_view_235 = torch.ops.aten._unsafe_view.default(bmm_111, [1, 16, 128, 128]);  bmm_111 = None
    add_186 = torch.ops.aten.add.Tensor(mul_293, _unsafe_view_235);  mul_293 = _unsafe_view_235 = None
    select_165 = torch.ops.aten.select.int(linalg_solve_triangular_20, 2, 1);  linalg_solve_triangular_20 = None
    select_166 = torch.ops.aten.select.int(linalg_solve_triangular_21, 2, 1);  linalg_solve_triangular_21 = None
    expand_232 = torch.ops.aten.expand.default(select_166, [1, 16, 64, 128]);  select_166 = None
    view_474 = torch.ops.aten.view.default(expand_232, [16, 64, 128]);  expand_232 = None
    expand_233 = torch.ops.aten.expand.default(add_186, [1, 16, 128, 128])
    view_475 = torch.ops.aten.view.default(expand_233, [16, 128, 128]);  expand_233 = None
    bmm_112 = torch.ops.aten.bmm.default(view_474, view_475);  view_474 = view_475 = None
    _unsafe_view_236 = torch.ops.aten._unsafe_view.default(bmm_112, [1, 16, 64, 128]);  bmm_112 = None
    sub_43 = torch.ops.aten.sub.Tensor(select_165, _unsafe_view_236);  select_165 = _unsafe_view_236 = None
    select_167 = torch.ops.aten.select.int(mul_291, 2, 1);  mul_291 = None
    expand_234 = torch.ops.aten.expand.default(select_167, [1, 16, 64, 128]);  select_167 = None
    view_476 = torch.ops.aten.view.default(expand_234, [16, 64, 128]);  expand_234 = None
    expand_235 = torch.ops.aten.expand.default(add_186, [1, 16, 128, 128])
    view_477 = torch.ops.aten.view.default(expand_235, [16, 128, 128]);  expand_235 = None
    bmm_113 = torch.ops.aten.bmm.default(view_476, view_477);  view_476 = view_477 = None
    _unsafe_view_237 = torch.ops.aten._unsafe_view.default(bmm_113, [1, 16, 64, 128]);  bmm_113 = None
    select_168 = torch.ops.aten.select.int(mul_289, 2, 1);  mul_289 = None
    expand_236 = torch.ops.aten.expand.default(select_168, [1, 16, 64, 64]);  select_168 = None
    view_478 = torch.ops.aten.view.default(expand_236, [16, 64, 64]);  expand_236 = None
    expand_237 = torch.ops.aten.expand.default(sub_43, [1, 16, 64, 128])
    view_479 = torch.ops.aten.view.default(expand_237, [16, 64, 128]);  expand_237 = None
    bmm_114 = torch.ops.aten.bmm.default(view_478, view_479);  view_478 = view_479 = None
    _unsafe_view_238 = torch.ops.aten._unsafe_view.default(bmm_114, [1, 16, 64, 128]);  bmm_114 = None
    add_187 = torch.ops.aten.add.Tensor(_unsafe_view_237, _unsafe_view_238);  _unsafe_view_237 = _unsafe_view_238 = None
    select_169 = torch.ops.aten.select.int(zeros_like_10, 2, 1)
    copy__25 = torch.ops.aten.copy_.default(select_169, add_187);  select_169 = add_187 = copy__25 = None
    select_170 = torch.ops.aten.select.int(unsqueeze_124, 2, 1);  unsqueeze_124 = None
    mul_294 = torch.ops.aten.mul.Tensor(add_186, select_170);  add_186 = select_170 = None
    select_171 = torch.ops.aten.select.int(mul_292, 2, 1);  mul_292 = None
    transpose_145 = torch.ops.aten.transpose.int(select_171, -1, -2);  select_171 = None
    expand_238 = torch.ops.aten.expand.default(transpose_145, [1, 16, 128, 64]);  transpose_145 = None
    view_480 = torch.ops.aten.view.default(expand_238, [16, 128, 64]);  expand_238 = None
    expand_239 = torch.ops.aten.expand.default(sub_43, [1, 16, 64, 128]);  sub_43 = None
    view_481 = torch.ops.aten.view.default(expand_239, [16, 64, 128]);  expand_239 = None
    bmm_115 = torch.ops.aten.bmm.default(view_480, view_481);  view_480 = view_481 = None
    _unsafe_view_239 = torch.ops.aten._unsafe_view.default(bmm_115, [1, 16, 128, 128]);  bmm_115 = None
    add_188 = torch.ops.aten.add.Tensor(mul_294, _unsafe_view_239);  mul_294 = _unsafe_view_239 = add_188 = None
    clone_22 = torch.ops.aten.clone.default(zeros_like_10, memory_format = torch.contiguous_format);  zeros_like_10 = None
    _unsafe_view_240 = torch.ops.aten._unsafe_view.default(clone_22, [1, 16, 128, 128]);  clone_22 = None
    alias_10 = torch.ops.aten.alias.default(_unsafe_view_240);  _unsafe_view_240 = None
    transpose_146 = torch.ops.aten.transpose.int(alias_10, 1, 2);  alias_10 = None
    _to_copy_214 = torch.ops.aten._to_copy.default(transpose_146, dtype = torch.bfloat16, memory_format = torch.contiguous_format);  transpose_146 = None
    view_482 = torch.ops.aten.view.default(_to_copy_214, [-1, 128]);  _to_copy_214 = None
    view_483 = torch.ops.aten.view.default(view_451, [-1, 128]);  view_451 = None
    _to_copy_215 = torch.ops.aten._to_copy.default(view_482, dtype = torch.float32);  view_482 = None
    pow_44 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_215, 2)
    mean_43 = torch.ops.aten.mean.dim(pow_44, [-1], True);  pow_44 = None
    add_189 = torch.ops.aten.add.Tensor(mean_43, 1e-06);  mean_43 = None
    rsqrt_65 = torch.ops.aten.rsqrt.default(add_189);  add_189 = None
    mul_295 = torch.ops.aten.mul.Tensor(_to_copy_215, rsqrt_65);  _to_copy_215 = rsqrt_65 = None
    _to_copy_216 = torch.ops.aten._to_copy.default(mul_295, dtype = torch.bfloat16);  mul_295 = None
    _param_constant182 = self._param_constant182
    mul_296 = torch.ops.aten.mul.Tensor(_param_constant182, _to_copy_216);  _param_constant182 = _to_copy_216 = None
    _to_copy_217 = torch.ops.aten._to_copy.default(view_483, dtype = torch.float32);  view_483 = None
    silu_34 = torch.ops.aten.silu.default(_to_copy_217);  _to_copy_217 = None
    mul_297 = torch.ops.aten.mul.Tensor(mul_296, silu_34);  mul_296 = silu_34 = None
    _to_copy_218 = torch.ops.aten._to_copy.default(mul_297, dtype = torch.bfloat16);  mul_297 = None
    view_484 = torch.ops.aten.view.default(_to_copy_218, [1, 128, -1]);  _to_copy_218 = None
    _param_constant183 = self._param_constant183
    t_105 = torch.ops.aten.t.default(_param_constant183);  _param_constant183 = None
    view_485 = torch.ops.aten.view.default(view_484, [128, 2048]);  view_484 = None
    mm_105 = torch.ops.aten.mm.default(view_485, t_105);  view_485 = t_105 = None
    _unsafe_view_241 = torch.ops.aten._unsafe_view.default(mm_105, [1, 128, 2048]);  mm_105 = None
    add_190 = torch.ops.aten.add.Tensor(add_179, _unsafe_view_241);  add_179 = _unsafe_view_241 = None
    _to_copy_219 = torch.ops.aten._to_copy.default(add_190, dtype = torch.float32)
    pow_45 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_219, 2)
    mean_44 = torch.ops.aten.mean.dim(pow_45, [-1], True);  pow_45 = None
    add_191 = torch.ops.aten.add.Tensor(mean_44, 1e-06);  mean_44 = None
    rsqrt_66 = torch.ops.aten.rsqrt.default(add_191);  add_191 = None
    mul_298 = torch.ops.aten.mul.Tensor(_to_copy_219, rsqrt_66);  _to_copy_219 = rsqrt_66 = None
    _param_constant184 = self._param_constant184
    _to_copy_220 = torch.ops.aten._to_copy.default(_param_constant184, dtype = torch.float32);  _param_constant184 = None
    add_192 = torch.ops.aten.add.Tensor(_to_copy_220, 1.0);  _to_copy_220 = None
    mul_299 = torch.ops.aten.mul.Tensor(mul_298, add_192);  mul_298 = add_192 = None
    _to_copy_221 = torch.ops.aten._to_copy.default(mul_299, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_299 = None
    _param_constant185 = self._param_constant185
    t_106 = torch.ops.aten.t.default(_param_constant185);  _param_constant185 = None
    view_486 = torch.ops.aten.view.default(_to_copy_221, [128, 2048])
    mm_106 = torch.ops.aten.mm.default(view_486, t_106);  view_486 = t_106 = None
    _unsafe_view_242 = torch.ops.aten._unsafe_view.default(mm_106, [1, 128, 6144]);  mm_106 = None
    silu_35 = torch.ops.aten.silu.default(_unsafe_view_242);  _unsafe_view_242 = None
    _param_constant186 = self._param_constant186
    t_107 = torch.ops.aten.t.default(_param_constant186);  _param_constant186 = None
    view_487 = torch.ops.aten.view.default(_to_copy_221, [128, 2048]);  _to_copy_221 = None
    mm_107 = torch.ops.aten.mm.default(view_487, t_107);  view_487 = t_107 = None
    _unsafe_view_243 = torch.ops.aten._unsafe_view.default(mm_107, [1, 128, 6144]);  mm_107 = None
    mul_300 = torch.ops.aten.mul.Tensor(silu_35, _unsafe_view_243);  silu_35 = _unsafe_view_243 = None
    _param_constant187 = self._param_constant187
    t_108 = torch.ops.aten.t.default(_param_constant187);  _param_constant187 = None
    view_488 = torch.ops.aten.view.default(mul_300, [128, 6144]);  mul_300 = None
    mm_108 = torch.ops.aten.mm.default(view_488, t_108);  view_488 = t_108 = None
    _unsafe_view_244 = torch.ops.aten._unsafe_view.default(mm_108, [1, 128, 2048]);  mm_108 = None
    add_193 = torch.ops.aten.add.Tensor(add_190, _unsafe_view_244);  add_190 = _unsafe_view_244 = None
    _to_copy_222 = torch.ops.aten._to_copy.default(add_193, dtype = torch.float32)
    pow_46 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_222, 2)
    mean_45 = torch.ops.aten.mean.dim(pow_46, [-1], True);  pow_46 = None
    add_194 = torch.ops.aten.add.Tensor(mean_45, 1e-06);  mean_45 = None
    rsqrt_67 = torch.ops.aten.rsqrt.default(add_194);  add_194 = None
    mul_301 = torch.ops.aten.mul.Tensor(_to_copy_222, rsqrt_67);  _to_copy_222 = rsqrt_67 = None
    _param_constant188 = self._param_constant188
    _to_copy_223 = torch.ops.aten._to_copy.default(_param_constant188, dtype = torch.float32);  _param_constant188 = None
    add_195 = torch.ops.aten.add.Tensor(_to_copy_223, 1.0);  _to_copy_223 = None
    mul_302 = torch.ops.aten.mul.Tensor(mul_301, add_195);  mul_301 = add_195 = None
    _to_copy_224 = torch.ops.aten._to_copy.default(mul_302, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_302 = None
    _param_constant189 = self._param_constant189
    t_109 = torch.ops.aten.t.default(_param_constant189);  _param_constant189 = None
    view_489 = torch.ops.aten.view.default(_to_copy_224, [128, 2048])
    mm_109 = torch.ops.aten.mm.default(view_489, t_109);  view_489 = t_109 = None
    _unsafe_view_245 = torch.ops.aten._unsafe_view.default(mm_109, [1, 128, 6144]);  mm_109 = None
    transpose_147 = torch.ops.aten.transpose.int(_unsafe_view_245, 1, 2);  _unsafe_view_245 = None
    _param_constant190 = self._param_constant190
    t_110 = torch.ops.aten.t.default(_param_constant190);  _param_constant190 = None
    view_490 = torch.ops.aten.view.default(_to_copy_224, [128, 2048])
    mm_110 = torch.ops.aten.mm.default(view_490, t_110);  view_490 = t_110 = None
    _unsafe_view_246 = torch.ops.aten._unsafe_view.default(mm_110, [1, 128, 2048]);  mm_110 = None
    view_491 = torch.ops.aten.view.default(_unsafe_view_246, [1, 128, -1, 128]);  _unsafe_view_246 = None
    _param_constant191 = self._param_constant191
    t_111 = torch.ops.aten.t.default(_param_constant191);  _param_constant191 = None
    view_492 = torch.ops.aten.view.default(_to_copy_224, [128, 2048])
    mm_111 = torch.ops.aten.mm.default(view_492, t_111);  view_492 = t_111 = None
    _unsafe_view_247 = torch.ops.aten._unsafe_view.default(mm_111, [1, 128, 16]);  mm_111 = None
    _param_constant192 = self._param_constant192
    t_112 = torch.ops.aten.t.default(_param_constant192);  _param_constant192 = None
    view_493 = torch.ops.aten.view.default(_to_copy_224, [128, 2048]);  _to_copy_224 = None
    mm_112 = torch.ops.aten.mm.default(view_493, t_112);  view_493 = t_112 = None
    _unsafe_view_248 = torch.ops.aten._unsafe_view.default(mm_112, [1, 128, 16]);  mm_112 = None
    _param_constant193 = self._param_constant193
    squeeze_11 = torch.ops.aten.squeeze.dim(_param_constant193, 1);  _param_constant193 = None
    unsqueeze_125 = torch.ops.aten.unsqueeze.default(squeeze_11, 1);  squeeze_11 = None
    convolution_11 = torch.ops.aten.convolution.default(transpose_147, unsqueeze_125, None, [1], [3], [1], False, [0], 6144);  transpose_147 = unsqueeze_125 = None
    slice_56 = torch.ops.aten.slice.Tensor(convolution_11, 2, 0, 128);  convolution_11 = None
    silu_36 = torch.ops.aten.silu.default(slice_56);  slice_56 = None
    transpose_148 = torch.ops.aten.transpose.int(silu_36, 1, 2);  silu_36 = None
    split_with_sizes_11 = torch.ops.aten.split_with_sizes.default(transpose_148, [2048, 2048, 2048], -1);  transpose_148 = None
    getitem_39 = split_with_sizes_11[0]
    getitem_40 = split_with_sizes_11[1]
    getitem_41 = split_with_sizes_11[2];  split_with_sizes_11 = None
    view_494 = torch.ops.aten.view.default(getitem_39, [1, 128, 16, 128]);  getitem_39 = None
    view_495 = torch.ops.aten.view.default(getitem_40, [1, 128, 16, 128]);  getitem_40 = None
    view_496 = torch.ops.aten.view.default(getitem_41, [1, 128, 16, 128]);  getitem_41 = None
    sigmoid_14 = torch.ops.aten.sigmoid.default(_unsafe_view_247);  _unsafe_view_247 = None
    _param_constant194 = self._param_constant194
    exp_66 = torch.ops.aten.exp.default(_param_constant194);  _param_constant194 = None
    neg_17 = torch.ops.aten.neg.default(exp_66);  exp_66 = None
    _to_copy_225 = torch.ops.aten._to_copy.default(_unsafe_view_248, dtype = torch.float32);  _unsafe_view_248 = None
    _param_constant195 = self._param_constant195
    add_196 = torch.ops.aten.add.Tensor(_to_copy_225, _param_constant195);  _to_copy_225 = _param_constant195 = None
    softplus_11 = torch.ops.aten.softplus.default(add_196);  add_196 = None
    mul_303 = torch.ops.aten.mul.Tensor(neg_17, softplus_11);  neg_17 = softplus_11 = None
    transpose_149 = torch.ops.aten.transpose.int(view_494, 1, 2);  view_494 = None
    _to_copy_226 = torch.ops.aten._to_copy.default(transpose_149, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_149 = None
    transpose_150 = torch.ops.aten.transpose.int(view_495, 1, 2);  view_495 = None
    _to_copy_227 = torch.ops.aten._to_copy.default(transpose_150, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_150 = None
    transpose_151 = torch.ops.aten.transpose.int(view_496, 1, 2);  view_496 = None
    _to_copy_228 = torch.ops.aten._to_copy.default(transpose_151, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_151 = None
    transpose_152 = torch.ops.aten.transpose.int(sigmoid_14, 1, 2);  sigmoid_14 = None
    _to_copy_229 = torch.ops.aten._to_copy.default(transpose_152, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_152 = None
    transpose_153 = torch.ops.aten.transpose.int(mul_303, 1, 2);  mul_303 = None
    mul_304 = torch.ops.aten.mul.Tensor(_to_copy_226, _to_copy_226)
    sum_23 = torch.ops.aten.sum.dim_IntList(mul_304, [-1], True);  mul_304 = None
    add_197 = torch.ops.aten.add.Tensor(sum_23, 1e-06);  sum_23 = None
    rsqrt_68 = torch.ops.aten.rsqrt.default(add_197);  add_197 = None
    mul_305 = torch.ops.aten.mul.Tensor(_to_copy_226, rsqrt_68);  _to_copy_226 = rsqrt_68 = None
    mul_306 = torch.ops.aten.mul.Tensor(_to_copy_227, _to_copy_227)
    sum_24 = torch.ops.aten.sum.dim_IntList(mul_306, [-1], True);  mul_306 = None
    add_198 = torch.ops.aten.add.Tensor(sum_24, 1e-06);  sum_24 = None
    rsqrt_69 = torch.ops.aten.rsqrt.default(add_198);  add_198 = None
    mul_307 = torch.ops.aten.mul.Tensor(_to_copy_227, rsqrt_69);  _to_copy_227 = rsqrt_69 = None
    mul_308 = torch.ops.aten.mul.Tensor(mul_305, 0.08838834764831845);  mul_305 = None
    constant_pad_nd_55 = torch.ops.aten.constant_pad_nd.default(mul_308, [0, 0, 0, 0], 0.0);  mul_308 = None
    constant_pad_nd_56 = torch.ops.aten.constant_pad_nd.default(mul_307, [0, 0, 0, 0], 0.0);  mul_307 = None
    constant_pad_nd_57 = torch.ops.aten.constant_pad_nd.default(_to_copy_228, [0, 0, 0, 0], 0.0);  _to_copy_228 = None
    constant_pad_nd_58 = torch.ops.aten.constant_pad_nd.default(_to_copy_229, [0, 0], 0.0);  _to_copy_229 = None
    constant_pad_nd_59 = torch.ops.aten.constant_pad_nd.default(transpose_153, [0, 0], 0.0);  transpose_153 = None
    unsqueeze_126 = torch.ops.aten.unsqueeze.default(constant_pad_nd_58, -1)
    mul_309 = torch.ops.aten.mul.Tensor(constant_pad_nd_57, unsqueeze_126);  constant_pad_nd_57 = unsqueeze_126 = None
    unsqueeze_127 = torch.ops.aten.unsqueeze.default(constant_pad_nd_58, -1);  constant_pad_nd_58 = None
    mul_310 = torch.ops.aten.mul.Tensor(constant_pad_nd_56, unsqueeze_127);  unsqueeze_127 = None
    view_497 = torch.ops.aten.view.default(constant_pad_nd_55, [1, 16, -1, 64, 128]);  constant_pad_nd_55 = None
    view_498 = torch.ops.aten.view.default(constant_pad_nd_56, [1, 16, -1, 64, 128]);  constant_pad_nd_56 = None
    view_499 = torch.ops.aten.view.default(mul_310, [1, 16, -1, 64, 128]);  mul_310 = None
    view_500 = torch.ops.aten.view.default(mul_309, [1, 16, -1, 64, 128]);  mul_309 = None
    view_501 = torch.ops.aten.view.default(constant_pad_nd_59, [1, 16, 2, 64]);  constant_pad_nd_59 = None
    ones_11 = torch.ops.aten.ones.default([64, 64], dtype = torch.bool, device = device(type='meta'), pin_memory = False)
    triu_12 = torch.ops.aten.triu.default(ones_11, 1);  ones_11 = None
    cumsum_11 = torch.ops.aten.cumsum.default(view_501, 3);  view_501 = None
    unsqueeze_128 = torch.ops.aten.unsqueeze.default(cumsum_11, 4)
    unsqueeze_129 = torch.ops.aten.unsqueeze.default(cumsum_11, 3)
    sub_44 = torch.ops.aten.sub.Tensor(unsqueeze_128, unsqueeze_129);  unsqueeze_128 = unsqueeze_129 = None
    masked_fill_11 = torch.ops.aten.masked_fill.Scalar(sub_44, triu_12, -inf);  sub_44 = triu_12 = None
    exp_67 = torch.ops.aten.exp.default(masked_fill_11);  masked_fill_11 = None
    transpose_154 = torch.ops.aten.transpose.int(view_498, -1, -2)
    expand_240 = torch.ops.aten.expand.default(view_499, [1, 16, 2, 64, 128])
    view_502 = torch.ops.aten.view.default(expand_240, [32, 64, 128]);  expand_240 = None
    expand_241 = torch.ops.aten.expand.default(transpose_154, [1, 16, 2, 128, 64]);  transpose_154 = None
    view_503 = torch.ops.aten.view.default(expand_241, [32, 128, 64]);  expand_241 = None
    bmm_116 = torch.ops.aten.bmm.default(view_502, view_503);  view_502 = view_503 = None
    _unsafe_view_249 = torch.ops.aten._unsafe_view.default(bmm_116, [1, 16, 2, 64, 64]);  bmm_116 = None
    mul_311 = torch.ops.aten.mul.Tensor(_unsafe_view_249, exp_67);  _unsafe_view_249 = None
    transpose_155 = torch.ops.aten.transpose.int(view_498, -1, -2)
    expand_242 = torch.ops.aten.expand.default(view_497, [1, 16, 2, 64, 128])
    view_504 = torch.ops.aten.view.default(expand_242, [32, 64, 128]);  expand_242 = None
    expand_243 = torch.ops.aten.expand.default(transpose_155, [1, 16, 2, 128, 64]);  transpose_155 = None
    view_505 = torch.ops.aten.view.default(expand_243, [32, 128, 64]);  expand_243 = None
    bmm_117 = torch.ops.aten.bmm.default(view_504, view_505);  view_504 = view_505 = None
    _unsafe_view_250 = torch.ops.aten._unsafe_view.default(bmm_117, [1, 16, 2, 64, 64]);  bmm_117 = None
    mul_312 = torch.ops.aten.mul.Tensor(_unsafe_view_250, exp_67);  _unsafe_view_250 = exp_67 = None
    exp_68 = torch.ops.aten.exp.default(cumsum_11)
    unsqueeze_130 = torch.ops.aten.unsqueeze.default(exp_68, -1);  exp_68 = None
    mul_313 = torch.ops.aten.mul.Tensor(view_499, unsqueeze_130);  view_499 = unsqueeze_130 = None
    linalg_solve_triangular_22 = torch.ops.aten.linalg_solve_triangular.default(mul_311, view_500, upper = False, unitriangular = True);  view_500 = None
    linalg_solve_triangular_23 = torch.ops.aten.linalg_solve_triangular.default(mul_311, mul_313, upper = False, unitriangular = True);  mul_311 = mul_313 = None
    zeros_11 = torch.ops.aten.zeros.default([1, 16, 128, 128], dtype = torch.float32, device = device(type='meta'), pin_memory = False)
    zeros_like_11 = torch.ops.aten.zeros_like.default(linalg_solve_triangular_22, pin_memory = False)
    exp_69 = torch.ops.aten.exp.default(cumsum_11)
    unsqueeze_131 = torch.ops.aten.unsqueeze.default(exp_69, -1);  exp_69 = None
    mul_314 = torch.ops.aten.mul.Tensor(view_497, unsqueeze_131);  view_497 = unsqueeze_131 = None
    slice_57 = torch.ops.aten.slice.Tensor(cumsum_11, 3, -1, 9223372036854775807)
    sub_45 = torch.ops.aten.sub.Tensor(slice_57, cumsum_11);  slice_57 = None
    exp_70 = torch.ops.aten.exp.default(sub_45);  sub_45 = None
    unsqueeze_132 = torch.ops.aten.unsqueeze.default(exp_70, -1);  exp_70 = None
    mul_315 = torch.ops.aten.mul.Tensor(view_498, unsqueeze_132);  view_498 = unsqueeze_132 = None
    select_172 = torch.ops.aten.select.int(cumsum_11, 3, -1);  cumsum_11 = None
    exp_71 = torch.ops.aten.exp.default(select_172);  select_172 = None
    unsqueeze_133 = torch.ops.aten.unsqueeze.default(exp_71, 3);  exp_71 = None
    unsqueeze_134 = torch.ops.aten.unsqueeze.default(unsqueeze_133, 4);  unsqueeze_133 = None
    select_173 = torch.ops.aten.select.int(linalg_solve_triangular_22, 2, 0)
    select_174 = torch.ops.aten.select.int(linalg_solve_triangular_23, 2, 0)
    expand_244 = torch.ops.aten.expand.default(select_174, [1, 16, 64, 128]);  select_174 = None
    view_506 = torch.ops.aten.view.default(expand_244, [16, 64, 128]);  expand_244 = None
    expand_245 = torch.ops.aten.expand.default(zeros_11, [1, 16, 128, 128])
    view_507 = torch.ops.aten.view.default(expand_245, [16, 128, 128]);  expand_245 = None
    bmm_118 = torch.ops.aten.bmm.default(view_506, view_507);  view_506 = view_507 = None
    _unsafe_view_251 = torch.ops.aten._unsafe_view.default(bmm_118, [1, 16, 64, 128]);  bmm_118 = None
    sub_46 = torch.ops.aten.sub.Tensor(select_173, _unsafe_view_251);  select_173 = _unsafe_view_251 = None
    select_175 = torch.ops.aten.select.int(mul_314, 2, 0)
    expand_246 = torch.ops.aten.expand.default(select_175, [1, 16, 64, 128]);  select_175 = None
    view_508 = torch.ops.aten.view.default(expand_246, [16, 64, 128]);  expand_246 = None
    expand_247 = torch.ops.aten.expand.default(zeros_11, [1, 16, 128, 128])
    view_509 = torch.ops.aten.view.default(expand_247, [16, 128, 128]);  expand_247 = None
    bmm_119 = torch.ops.aten.bmm.default(view_508, view_509);  view_508 = view_509 = None
    _unsafe_view_252 = torch.ops.aten._unsafe_view.default(bmm_119, [1, 16, 64, 128]);  bmm_119 = None
    select_176 = torch.ops.aten.select.int(mul_312, 2, 0)
    expand_248 = torch.ops.aten.expand.default(select_176, [1, 16, 64, 64]);  select_176 = None
    view_510 = torch.ops.aten.view.default(expand_248, [16, 64, 64]);  expand_248 = None
    expand_249 = torch.ops.aten.expand.default(sub_46, [1, 16, 64, 128])
    view_511 = torch.ops.aten.view.default(expand_249, [16, 64, 128]);  expand_249 = None
    bmm_120 = torch.ops.aten.bmm.default(view_510, view_511);  view_510 = view_511 = None
    _unsafe_view_253 = torch.ops.aten._unsafe_view.default(bmm_120, [1, 16, 64, 128]);  bmm_120 = None
    add_199 = torch.ops.aten.add.Tensor(_unsafe_view_252, _unsafe_view_253);  _unsafe_view_252 = _unsafe_view_253 = None
    select_177 = torch.ops.aten.select.int(zeros_like_11, 2, 0)
    copy__26 = torch.ops.aten.copy_.default(select_177, add_199);  select_177 = add_199 = copy__26 = None
    select_178 = torch.ops.aten.select.int(unsqueeze_134, 2, 0)
    mul_316 = torch.ops.aten.mul.Tensor(zeros_11, select_178);  zeros_11 = select_178 = None
    select_179 = torch.ops.aten.select.int(mul_315, 2, 0)
    transpose_156 = torch.ops.aten.transpose.int(select_179, -1, -2);  select_179 = None
    expand_250 = torch.ops.aten.expand.default(transpose_156, [1, 16, 128, 64]);  transpose_156 = None
    view_512 = torch.ops.aten.view.default(expand_250, [16, 128, 64]);  expand_250 = None
    expand_251 = torch.ops.aten.expand.default(sub_46, [1, 16, 64, 128]);  sub_46 = None
    view_513 = torch.ops.aten.view.default(expand_251, [16, 64, 128]);  expand_251 = None
    bmm_121 = torch.ops.aten.bmm.default(view_512, view_513);  view_512 = view_513 = None
    _unsafe_view_254 = torch.ops.aten._unsafe_view.default(bmm_121, [1, 16, 128, 128]);  bmm_121 = None
    add_200 = torch.ops.aten.add.Tensor(mul_316, _unsafe_view_254);  mul_316 = _unsafe_view_254 = None
    select_180 = torch.ops.aten.select.int(linalg_solve_triangular_22, 2, 1);  linalg_solve_triangular_22 = None
    select_181 = torch.ops.aten.select.int(linalg_solve_triangular_23, 2, 1);  linalg_solve_triangular_23 = None
    expand_252 = torch.ops.aten.expand.default(select_181, [1, 16, 64, 128]);  select_181 = None
    view_514 = torch.ops.aten.view.default(expand_252, [16, 64, 128]);  expand_252 = None
    expand_253 = torch.ops.aten.expand.default(add_200, [1, 16, 128, 128])
    view_515 = torch.ops.aten.view.default(expand_253, [16, 128, 128]);  expand_253 = None
    bmm_122 = torch.ops.aten.bmm.default(view_514, view_515);  view_514 = view_515 = None
    _unsafe_view_255 = torch.ops.aten._unsafe_view.default(bmm_122, [1, 16, 64, 128]);  bmm_122 = None
    sub_47 = torch.ops.aten.sub.Tensor(select_180, _unsafe_view_255);  select_180 = _unsafe_view_255 = None
    select_182 = torch.ops.aten.select.int(mul_314, 2, 1);  mul_314 = None
    expand_254 = torch.ops.aten.expand.default(select_182, [1, 16, 64, 128]);  select_182 = None
    view_516 = torch.ops.aten.view.default(expand_254, [16, 64, 128]);  expand_254 = None
    expand_255 = torch.ops.aten.expand.default(add_200, [1, 16, 128, 128])
    view_517 = torch.ops.aten.view.default(expand_255, [16, 128, 128]);  expand_255 = None
    bmm_123 = torch.ops.aten.bmm.default(view_516, view_517);  view_516 = view_517 = None
    _unsafe_view_256 = torch.ops.aten._unsafe_view.default(bmm_123, [1, 16, 64, 128]);  bmm_123 = None
    select_183 = torch.ops.aten.select.int(mul_312, 2, 1);  mul_312 = None
    expand_256 = torch.ops.aten.expand.default(select_183, [1, 16, 64, 64]);  select_183 = None
    view_518 = torch.ops.aten.view.default(expand_256, [16, 64, 64]);  expand_256 = None
    expand_257 = torch.ops.aten.expand.default(sub_47, [1, 16, 64, 128])
    view_519 = torch.ops.aten.view.default(expand_257, [16, 64, 128]);  expand_257 = None
    bmm_124 = torch.ops.aten.bmm.default(view_518, view_519);  view_518 = view_519 = None
    _unsafe_view_257 = torch.ops.aten._unsafe_view.default(bmm_124, [1, 16, 64, 128]);  bmm_124 = None
    add_201 = torch.ops.aten.add.Tensor(_unsafe_view_256, _unsafe_view_257);  _unsafe_view_256 = _unsafe_view_257 = None
    select_184 = torch.ops.aten.select.int(zeros_like_11, 2, 1)
    copy__27 = torch.ops.aten.copy_.default(select_184, add_201);  select_184 = add_201 = copy__27 = None
    select_185 = torch.ops.aten.select.int(unsqueeze_134, 2, 1);  unsqueeze_134 = None
    mul_317 = torch.ops.aten.mul.Tensor(add_200, select_185);  add_200 = select_185 = None
    select_186 = torch.ops.aten.select.int(mul_315, 2, 1);  mul_315 = None
    transpose_157 = torch.ops.aten.transpose.int(select_186, -1, -2);  select_186 = None
    expand_258 = torch.ops.aten.expand.default(transpose_157, [1, 16, 128, 64]);  transpose_157 = None
    view_520 = torch.ops.aten.view.default(expand_258, [16, 128, 64]);  expand_258 = None
    expand_259 = torch.ops.aten.expand.default(sub_47, [1, 16, 64, 128]);  sub_47 = None
    view_521 = torch.ops.aten.view.default(expand_259, [16, 64, 128]);  expand_259 = None
    bmm_125 = torch.ops.aten.bmm.default(view_520, view_521);  view_520 = view_521 = None
    _unsafe_view_258 = torch.ops.aten._unsafe_view.default(bmm_125, [1, 16, 128, 128]);  bmm_125 = None
    add_202 = torch.ops.aten.add.Tensor(mul_317, _unsafe_view_258);  mul_317 = _unsafe_view_258 = add_202 = None
    clone_23 = torch.ops.aten.clone.default(zeros_like_11, memory_format = torch.contiguous_format);  zeros_like_11 = None
    _unsafe_view_259 = torch.ops.aten._unsafe_view.default(clone_23, [1, 16, 128, 128]);  clone_23 = None
    alias_11 = torch.ops.aten.alias.default(_unsafe_view_259);  _unsafe_view_259 = None
    transpose_158 = torch.ops.aten.transpose.int(alias_11, 1, 2);  alias_11 = None
    _to_copy_230 = torch.ops.aten._to_copy.default(transpose_158, dtype = torch.bfloat16, memory_format = torch.contiguous_format);  transpose_158 = None
    view_522 = torch.ops.aten.view.default(_to_copy_230, [-1, 128]);  _to_copy_230 = None
    view_523 = torch.ops.aten.view.default(view_491, [-1, 128]);  view_491 = None
    _to_copy_231 = torch.ops.aten._to_copy.default(view_522, dtype = torch.float32);  view_522 = None
    pow_47 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_231, 2)
    mean_46 = torch.ops.aten.mean.dim(pow_47, [-1], True);  pow_47 = None
    add_203 = torch.ops.aten.add.Tensor(mean_46, 1e-06);  mean_46 = None
    rsqrt_70 = torch.ops.aten.rsqrt.default(add_203);  add_203 = None
    mul_318 = torch.ops.aten.mul.Tensor(_to_copy_231, rsqrt_70);  _to_copy_231 = rsqrt_70 = None
    _to_copy_232 = torch.ops.aten._to_copy.default(mul_318, dtype = torch.bfloat16);  mul_318 = None
    _param_constant196 = self._param_constant196
    mul_319 = torch.ops.aten.mul.Tensor(_param_constant196, _to_copy_232);  _param_constant196 = _to_copy_232 = None
    _to_copy_233 = torch.ops.aten._to_copy.default(view_523, dtype = torch.float32);  view_523 = None
    silu_37 = torch.ops.aten.silu.default(_to_copy_233);  _to_copy_233 = None
    mul_320 = torch.ops.aten.mul.Tensor(mul_319, silu_37);  mul_319 = silu_37 = None
    _to_copy_234 = torch.ops.aten._to_copy.default(mul_320, dtype = torch.bfloat16);  mul_320 = None
    view_524 = torch.ops.aten.view.default(_to_copy_234, [1, 128, -1]);  _to_copy_234 = None
    _param_constant197 = self._param_constant197
    t_113 = torch.ops.aten.t.default(_param_constant197);  _param_constant197 = None
    view_525 = torch.ops.aten.view.default(view_524, [128, 2048]);  view_524 = None
    mm_113 = torch.ops.aten.mm.default(view_525, t_113);  view_525 = t_113 = None
    _unsafe_view_260 = torch.ops.aten._unsafe_view.default(mm_113, [1, 128, 2048]);  mm_113 = None
    add_204 = torch.ops.aten.add.Tensor(add_193, _unsafe_view_260);  add_193 = _unsafe_view_260 = None
    _to_copy_235 = torch.ops.aten._to_copy.default(add_204, dtype = torch.float32)
    pow_48 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_235, 2)
    mean_47 = torch.ops.aten.mean.dim(pow_48, [-1], True);  pow_48 = None
    add_205 = torch.ops.aten.add.Tensor(mean_47, 1e-06);  mean_47 = None
    rsqrt_71 = torch.ops.aten.rsqrt.default(add_205);  add_205 = None
    mul_321 = torch.ops.aten.mul.Tensor(_to_copy_235, rsqrt_71);  _to_copy_235 = rsqrt_71 = None
    _param_constant198 = self._param_constant198
    _to_copy_236 = torch.ops.aten._to_copy.default(_param_constant198, dtype = torch.float32);  _param_constant198 = None
    add_206 = torch.ops.aten.add.Tensor(_to_copy_236, 1.0);  _to_copy_236 = None
    mul_322 = torch.ops.aten.mul.Tensor(mul_321, add_206);  mul_321 = add_206 = None
    _to_copy_237 = torch.ops.aten._to_copy.default(mul_322, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_322 = None
    _param_constant199 = self._param_constant199
    t_114 = torch.ops.aten.t.default(_param_constant199);  _param_constant199 = None
    view_526 = torch.ops.aten.view.default(_to_copy_237, [128, 2048])
    mm_114 = torch.ops.aten.mm.default(view_526, t_114);  view_526 = t_114 = None
    _unsafe_view_261 = torch.ops.aten._unsafe_view.default(mm_114, [1, 128, 6144]);  mm_114 = None
    silu_38 = torch.ops.aten.silu.default(_unsafe_view_261);  _unsafe_view_261 = None
    _param_constant200 = self._param_constant200
    t_115 = torch.ops.aten.t.default(_param_constant200);  _param_constant200 = None
    view_527 = torch.ops.aten.view.default(_to_copy_237, [128, 2048]);  _to_copy_237 = None
    mm_115 = torch.ops.aten.mm.default(view_527, t_115);  view_527 = t_115 = None
    _unsafe_view_262 = torch.ops.aten._unsafe_view.default(mm_115, [1, 128, 6144]);  mm_115 = None
    mul_323 = torch.ops.aten.mul.Tensor(silu_38, _unsafe_view_262);  silu_38 = _unsafe_view_262 = None
    _param_constant201 = self._param_constant201
    t_116 = torch.ops.aten.t.default(_param_constant201);  _param_constant201 = None
    view_528 = torch.ops.aten.view.default(mul_323, [128, 6144]);  mul_323 = None
    mm_116 = torch.ops.aten.mm.default(view_528, t_116);  view_528 = t_116 = None
    _unsafe_view_263 = torch.ops.aten._unsafe_view.default(mm_116, [1, 128, 2048]);  mm_116 = None
    add_207 = torch.ops.aten.add.Tensor(add_204, _unsafe_view_263);  add_204 = _unsafe_view_263 = None
    _to_copy_238 = torch.ops.aten._to_copy.default(add_207, dtype = torch.float32)
    pow_49 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_238, 2)
    mean_48 = torch.ops.aten.mean.dim(pow_49, [-1], True);  pow_49 = None
    add_208 = torch.ops.aten.add.Tensor(mean_48, 1e-06);  mean_48 = None
    rsqrt_72 = torch.ops.aten.rsqrt.default(add_208);  add_208 = None
    mul_324 = torch.ops.aten.mul.Tensor(_to_copy_238, rsqrt_72);  _to_copy_238 = rsqrt_72 = None
    _param_constant202 = self._param_constant202
    _to_copy_239 = torch.ops.aten._to_copy.default(_param_constant202, dtype = torch.float32);  _param_constant202 = None
    add_209 = torch.ops.aten.add.Tensor(_to_copy_239, 1.0);  _to_copy_239 = None
    mul_325 = torch.ops.aten.mul.Tensor(mul_324, add_209);  mul_324 = add_209 = None
    _to_copy_240 = torch.ops.aten._to_copy.default(mul_325, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_325 = None
    _param_constant203 = self._param_constant203
    t_117 = torch.ops.aten.t.default(_param_constant203);  _param_constant203 = None
    view_529 = torch.ops.aten.view.default(_to_copy_240, [128, 2048])
    mm_117 = torch.ops.aten.mm.default(view_529, t_117);  view_529 = t_117 = None
    _unsafe_view_264 = torch.ops.aten._unsafe_view.default(mm_117, [1, 128, 4096]);  mm_117 = None
    view_530 = torch.ops.aten.view.default(_unsafe_view_264, [1, 128, -1, 512]);  _unsafe_view_264 = None
    split_3 = torch.ops.aten.split.Tensor(view_530, 256, -1);  view_530 = None
    getitem_42 = split_3[0]
    getitem_43 = split_3[1];  split_3 = None
    clone_24 = torch.ops.aten.clone.default(getitem_43, memory_format = torch.contiguous_format);  getitem_43 = None
    _unsafe_view_265 = torch.ops.aten._unsafe_view.default(clone_24, [1, 128, 2048]);  clone_24 = None
    view_531 = torch.ops.aten.view.default(getitem_42, [1, 128, -1, 256]);  getitem_42 = None
    _to_copy_241 = torch.ops.aten._to_copy.default(view_531, dtype = torch.float32);  view_531 = None
    pow_50 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_241, 2)
    mean_49 = torch.ops.aten.mean.dim(pow_50, [-1], True);  pow_50 = None
    add_210 = torch.ops.aten.add.Tensor(mean_49, 1e-06);  mean_49 = None
    rsqrt_73 = torch.ops.aten.rsqrt.default(add_210);  add_210 = None
    mul_326 = torch.ops.aten.mul.Tensor(_to_copy_241, rsqrt_73);  _to_copy_241 = rsqrt_73 = None
    _param_constant204 = self._param_constant204
    _to_copy_242 = torch.ops.aten._to_copy.default(_param_constant204, dtype = torch.float32);  _param_constant204 = None
    add_211 = torch.ops.aten.add.Tensor(_to_copy_242, 1.0);  _to_copy_242 = None
    mul_327 = torch.ops.aten.mul.Tensor(mul_326, add_211);  mul_326 = add_211 = None
    _to_copy_243 = torch.ops.aten._to_copy.default(mul_327, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_327 = None
    transpose_159 = torch.ops.aten.transpose.int(_to_copy_243, 1, 2);  _to_copy_243 = None
    _param_constant205 = self._param_constant205
    t_118 = torch.ops.aten.t.default(_param_constant205);  _param_constant205 = None
    view_532 = torch.ops.aten.view.default(_to_copy_240, [128, 2048])
    mm_118 = torch.ops.aten.mm.default(view_532, t_118);  view_532 = t_118 = None
    _unsafe_view_266 = torch.ops.aten._unsafe_view.default(mm_118, [1, 128, 512]);  mm_118 = None
    view_533 = torch.ops.aten.view.default(_unsafe_view_266, [1, 128, -1, 256]);  _unsafe_view_266 = None
    _to_copy_244 = torch.ops.aten._to_copy.default(view_533, dtype = torch.float32);  view_533 = None
    pow_51 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_244, 2)
    mean_50 = torch.ops.aten.mean.dim(pow_51, [-1], True);  pow_51 = None
    add_212 = torch.ops.aten.add.Tensor(mean_50, 1e-06);  mean_50 = None
    rsqrt_74 = torch.ops.aten.rsqrt.default(add_212);  add_212 = None
    mul_328 = torch.ops.aten.mul.Tensor(_to_copy_244, rsqrt_74);  _to_copy_244 = rsqrt_74 = None
    _param_constant206 = self._param_constant206
    _to_copy_245 = torch.ops.aten._to_copy.default(_param_constant206, dtype = torch.float32);  _param_constant206 = None
    add_213 = torch.ops.aten.add.Tensor(_to_copy_245, 1.0);  _to_copy_245 = None
    mul_329 = torch.ops.aten.mul.Tensor(mul_328, add_213);  mul_328 = add_213 = None
    _to_copy_246 = torch.ops.aten._to_copy.default(mul_329, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_329 = None
    transpose_160 = torch.ops.aten.transpose.int(_to_copy_246, 1, 2);  _to_copy_246 = None
    _param_constant207 = self._param_constant207
    t_119 = torch.ops.aten.t.default(_param_constant207);  _param_constant207 = None
    view_534 = torch.ops.aten.view.default(_to_copy_240, [128, 2048]);  _to_copy_240 = None
    mm_119 = torch.ops.aten.mm.default(view_534, t_119);  view_534 = t_119 = None
    _unsafe_view_267 = torch.ops.aten._unsafe_view.default(mm_119, [1, 128, 512]);  mm_119 = None
    view_535 = torch.ops.aten.view.default(_unsafe_view_267, [1, 128, -1, 256]);  _unsafe_view_267 = None
    transpose_161 = torch.ops.aten.transpose.int(view_535, 1, 2);  view_535 = None
    unsqueeze_135 = torch.ops.aten.unsqueeze.default(_to_copy_2, 1)
    unsqueeze_136 = torch.ops.aten.unsqueeze.default(_to_copy_3, 1)
    slice_58 = torch.ops.aten.slice.Tensor(transpose_159, 3, 0, 64)
    slice_59 = torch.ops.aten.slice.Tensor(transpose_159, 3, 64, 9223372036854775807);  transpose_159 = None
    slice_60 = torch.ops.aten.slice.Tensor(transpose_160, 3, 0, 64)
    slice_61 = torch.ops.aten.slice.Tensor(transpose_160, 3, 64, 9223372036854775807);  transpose_160 = None
    mul_330 = torch.ops.aten.mul.Tensor(slice_58, unsqueeze_135)
    slice_62 = torch.ops.aten.slice.Tensor(slice_58, 3, 0, 32)
    slice_63 = torch.ops.aten.slice.Tensor(slice_58, 3, 32, 9223372036854775807);  slice_58 = None
    neg_18 = torch.ops.aten.neg.default(slice_63);  slice_63 = None
    cat_14 = torch.ops.aten.cat.default([neg_18, slice_62], -1);  neg_18 = slice_62 = None
    mul_331 = torch.ops.aten.mul.Tensor(cat_14, unsqueeze_136);  cat_14 = None
    add_214 = torch.ops.aten.add.Tensor(mul_330, mul_331);  mul_330 = mul_331 = None
    mul_332 = torch.ops.aten.mul.Tensor(slice_60, unsqueeze_135);  unsqueeze_135 = None
    slice_64 = torch.ops.aten.slice.Tensor(slice_60, 3, 0, 32)
    slice_65 = torch.ops.aten.slice.Tensor(slice_60, 3, 32, 9223372036854775807);  slice_60 = None
    neg_19 = torch.ops.aten.neg.default(slice_65);  slice_65 = None
    cat_15 = torch.ops.aten.cat.default([neg_19, slice_64], -1);  neg_19 = slice_64 = None
    mul_333 = torch.ops.aten.mul.Tensor(cat_15, unsqueeze_136);  cat_15 = unsqueeze_136 = None
    add_215 = torch.ops.aten.add.Tensor(mul_332, mul_333);  mul_332 = mul_333 = None
    cat_16 = torch.ops.aten.cat.default([add_214, slice_59], -1);  add_214 = slice_59 = None
    cat_17 = torch.ops.aten.cat.default([add_215, slice_61], -1);  add_215 = slice_61 = None
    unsqueeze_137 = torch.ops.aten.unsqueeze.default(cat_17, 2);  cat_17 = None
    expand_260 = torch.ops.aten.expand.default(unsqueeze_137, [1, 2, 4, 128, 256]);  unsqueeze_137 = None
    clone_25 = torch.ops.aten.clone.default(expand_260, memory_format = torch.contiguous_format);  expand_260 = None
    _unsafe_view_268 = torch.ops.aten._unsafe_view.default(clone_25, [1, 8, 128, 256]);  clone_25 = None
    unsqueeze_138 = torch.ops.aten.unsqueeze.default(transpose_161, 2);  transpose_161 = None
    expand_261 = torch.ops.aten.expand.default(unsqueeze_138, [1, 2, 4, 128, 256]);  unsqueeze_138 = None
    clone_26 = torch.ops.aten.clone.default(expand_261, memory_format = torch.contiguous_format);  expand_261 = None
    _unsafe_view_269 = torch.ops.aten._unsafe_view.default(clone_26, [1, 8, 128, 256]);  clone_26 = None
    transpose_162 = torch.ops.aten.transpose.int(_unsafe_view_268, 2, 3);  _unsafe_view_268 = None
    expand_262 = torch.ops.aten.expand.default(cat_16, [1, 8, 128, 256]);  cat_16 = None
    view_536 = torch.ops.aten.view.default(expand_262, [8, 128, 256]);  expand_262 = None
    expand_263 = torch.ops.aten.expand.default(transpose_162, [1, 8, 256, 128]);  transpose_162 = None
    view_537 = torch.ops.aten.view.default(expand_263, [8, 256, 128]);  expand_263 = None
    bmm_126 = torch.ops.aten.bmm.default(view_536, view_537);  view_536 = view_537 = None
    _unsafe_view_270 = torch.ops.aten._unsafe_view.default(bmm_126, [1, 8, 128, 128]);  bmm_126 = None
    mul_334 = torch.ops.aten.mul.Tensor(_unsafe_view_270, 0.0625);  _unsafe_view_270 = None
    add_216 = torch.ops.aten.add.Tensor(mul_334, unsqueeze_1);  mul_334 = None
    _to_copy_247 = torch.ops.aten._to_copy.default(add_216, dtype = torch.float32, layout = torch.strided, device = device(type='meta'));  add_216 = None
    _softmax_3 = torch.ops.aten._softmax.default(_to_copy_247, -1, False);  _to_copy_247 = None
    _to_copy_248 = torch.ops.aten._to_copy.default(_softmax_3, dtype = torch.bfloat16);  _softmax_3 = None
    expand_264 = torch.ops.aten.expand.default(_to_copy_248, [1, 8, 128, 128]);  _to_copy_248 = None
    view_538 = torch.ops.aten.view.default(expand_264, [8, 128, 128]);  expand_264 = None
    expand_265 = torch.ops.aten.expand.default(_unsafe_view_269, [1, 8, 128, 256]);  _unsafe_view_269 = None
    view_539 = torch.ops.aten.view.default(expand_265, [8, 128, 256]);  expand_265 = None
    bmm_127 = torch.ops.aten.bmm.default(view_538, view_539);  view_538 = view_539 = None
    _unsafe_view_271 = torch.ops.aten._unsafe_view.default(bmm_127, [1, 8, 128, 256]);  bmm_127 = None
    transpose_163 = torch.ops.aten.transpose.int(_unsafe_view_271, 1, 2);  _unsafe_view_271 = None
    clone_27 = torch.ops.aten.clone.default(transpose_163, memory_format = torch.contiguous_format);  transpose_163 = None
    view_540 = torch.ops.aten.view.default(clone_27, [1, 128, -1]);  clone_27 = None
    sigmoid_15 = torch.ops.aten.sigmoid.default(_unsafe_view_265);  _unsafe_view_265 = None
    mul_335 = torch.ops.aten.mul.Tensor(view_540, sigmoid_15);  view_540 = sigmoid_15 = None
    _param_constant208 = self._param_constant208
    t_120 = torch.ops.aten.t.default(_param_constant208);  _param_constant208 = None
    view_541 = torch.ops.aten.view.default(mul_335, [128, 2048]);  mul_335 = None
    mm_120 = torch.ops.aten.mm.default(view_541, t_120);  view_541 = t_120 = None
    _unsafe_view_272 = torch.ops.aten._unsafe_view.default(mm_120, [1, 128, 2048]);  mm_120 = None
    add_217 = torch.ops.aten.add.Tensor(add_207, _unsafe_view_272);  add_207 = _unsafe_view_272 = None
    _to_copy_249 = torch.ops.aten._to_copy.default(add_217, dtype = torch.float32)
    pow_52 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_249, 2)
    mean_51 = torch.ops.aten.mean.dim(pow_52, [-1], True);  pow_52 = None
    add_218 = torch.ops.aten.add.Tensor(mean_51, 1e-06);  mean_51 = None
    rsqrt_75 = torch.ops.aten.rsqrt.default(add_218);  add_218 = None
    mul_336 = torch.ops.aten.mul.Tensor(_to_copy_249, rsqrt_75);  _to_copy_249 = rsqrt_75 = None
    _param_constant209 = self._param_constant209
    _to_copy_250 = torch.ops.aten._to_copy.default(_param_constant209, dtype = torch.float32);  _param_constant209 = None
    add_219 = torch.ops.aten.add.Tensor(_to_copy_250, 1.0);  _to_copy_250 = None
    mul_337 = torch.ops.aten.mul.Tensor(mul_336, add_219);  mul_336 = add_219 = None
    _to_copy_251 = torch.ops.aten._to_copy.default(mul_337, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_337 = None
    _param_constant210 = self._param_constant210
    t_121 = torch.ops.aten.t.default(_param_constant210);  _param_constant210 = None
    view_542 = torch.ops.aten.view.default(_to_copy_251, [128, 2048])
    mm_121 = torch.ops.aten.mm.default(view_542, t_121);  view_542 = t_121 = None
    _unsafe_view_273 = torch.ops.aten._unsafe_view.default(mm_121, [1, 128, 6144]);  mm_121 = None
    silu_39 = torch.ops.aten.silu.default(_unsafe_view_273);  _unsafe_view_273 = None
    _param_constant211 = self._param_constant211
    t_122 = torch.ops.aten.t.default(_param_constant211);  _param_constant211 = None
    view_543 = torch.ops.aten.view.default(_to_copy_251, [128, 2048]);  _to_copy_251 = None
    mm_122 = torch.ops.aten.mm.default(view_543, t_122);  view_543 = t_122 = None
    _unsafe_view_274 = torch.ops.aten._unsafe_view.default(mm_122, [1, 128, 6144]);  mm_122 = None
    mul_338 = torch.ops.aten.mul.Tensor(silu_39, _unsafe_view_274);  silu_39 = _unsafe_view_274 = None
    _param_constant212 = self._param_constant212
    t_123 = torch.ops.aten.t.default(_param_constant212);  _param_constant212 = None
    view_544 = torch.ops.aten.view.default(mul_338, [128, 6144]);  mul_338 = None
    mm_123 = torch.ops.aten.mm.default(view_544, t_123);  view_544 = t_123 = None
    _unsafe_view_275 = torch.ops.aten._unsafe_view.default(mm_123, [1, 128, 2048]);  mm_123 = None
    add_220 = torch.ops.aten.add.Tensor(add_217, _unsafe_view_275);  add_217 = _unsafe_view_275 = None
    _to_copy_252 = torch.ops.aten._to_copy.default(add_220, dtype = torch.float32)
    pow_53 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_252, 2)
    mean_52 = torch.ops.aten.mean.dim(pow_53, [-1], True);  pow_53 = None
    add_221 = torch.ops.aten.add.Tensor(mean_52, 1e-06);  mean_52 = None
    rsqrt_76 = torch.ops.aten.rsqrt.default(add_221);  add_221 = None
    mul_339 = torch.ops.aten.mul.Tensor(_to_copy_252, rsqrt_76);  _to_copy_252 = rsqrt_76 = None
    _param_constant213 = self._param_constant213
    _to_copy_253 = torch.ops.aten._to_copy.default(_param_constant213, dtype = torch.float32);  _param_constant213 = None
    add_222 = torch.ops.aten.add.Tensor(_to_copy_253, 1.0);  _to_copy_253 = None
    mul_340 = torch.ops.aten.mul.Tensor(mul_339, add_222);  mul_339 = add_222 = None
    _to_copy_254 = torch.ops.aten._to_copy.default(mul_340, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_340 = None
    _param_constant214 = self._param_constant214
    t_124 = torch.ops.aten.t.default(_param_constant214);  _param_constant214 = None
    view_545 = torch.ops.aten.view.default(_to_copy_254, [128, 2048])
    mm_124 = torch.ops.aten.mm.default(view_545, t_124);  view_545 = t_124 = None
    _unsafe_view_276 = torch.ops.aten._unsafe_view.default(mm_124, [1, 128, 6144]);  mm_124 = None
    transpose_164 = torch.ops.aten.transpose.int(_unsafe_view_276, 1, 2);  _unsafe_view_276 = None
    _param_constant215 = self._param_constant215
    t_125 = torch.ops.aten.t.default(_param_constant215);  _param_constant215 = None
    view_546 = torch.ops.aten.view.default(_to_copy_254, [128, 2048])
    mm_125 = torch.ops.aten.mm.default(view_546, t_125);  view_546 = t_125 = None
    _unsafe_view_277 = torch.ops.aten._unsafe_view.default(mm_125, [1, 128, 2048]);  mm_125 = None
    view_547 = torch.ops.aten.view.default(_unsafe_view_277, [1, 128, -1, 128]);  _unsafe_view_277 = None
    _param_constant216 = self._param_constant216
    t_126 = torch.ops.aten.t.default(_param_constant216);  _param_constant216 = None
    view_548 = torch.ops.aten.view.default(_to_copy_254, [128, 2048])
    mm_126 = torch.ops.aten.mm.default(view_548, t_126);  view_548 = t_126 = None
    _unsafe_view_278 = torch.ops.aten._unsafe_view.default(mm_126, [1, 128, 16]);  mm_126 = None
    _param_constant217 = self._param_constant217
    t_127 = torch.ops.aten.t.default(_param_constant217);  _param_constant217 = None
    view_549 = torch.ops.aten.view.default(_to_copy_254, [128, 2048]);  _to_copy_254 = None
    mm_127 = torch.ops.aten.mm.default(view_549, t_127);  view_549 = t_127 = None
    _unsafe_view_279 = torch.ops.aten._unsafe_view.default(mm_127, [1, 128, 16]);  mm_127 = None
    _param_constant218 = self._param_constant218
    squeeze_12 = torch.ops.aten.squeeze.dim(_param_constant218, 1);  _param_constant218 = None
    unsqueeze_139 = torch.ops.aten.unsqueeze.default(squeeze_12, 1);  squeeze_12 = None
    convolution_12 = torch.ops.aten.convolution.default(transpose_164, unsqueeze_139, None, [1], [3], [1], False, [0], 6144);  transpose_164 = unsqueeze_139 = None
    slice_66 = torch.ops.aten.slice.Tensor(convolution_12, 2, 0, 128);  convolution_12 = None
    silu_40 = torch.ops.aten.silu.default(slice_66);  slice_66 = None
    transpose_165 = torch.ops.aten.transpose.int(silu_40, 1, 2);  silu_40 = None
    split_with_sizes_12 = torch.ops.aten.split_with_sizes.default(transpose_165, [2048, 2048, 2048], -1);  transpose_165 = None
    getitem_44 = split_with_sizes_12[0]
    getitem_45 = split_with_sizes_12[1]
    getitem_46 = split_with_sizes_12[2];  split_with_sizes_12 = None
    view_550 = torch.ops.aten.view.default(getitem_44, [1, 128, 16, 128]);  getitem_44 = None
    view_551 = torch.ops.aten.view.default(getitem_45, [1, 128, 16, 128]);  getitem_45 = None
    view_552 = torch.ops.aten.view.default(getitem_46, [1, 128, 16, 128]);  getitem_46 = None
    sigmoid_16 = torch.ops.aten.sigmoid.default(_unsafe_view_278);  _unsafe_view_278 = None
    _param_constant219 = self._param_constant219
    exp_72 = torch.ops.aten.exp.default(_param_constant219);  _param_constant219 = None
    neg_20 = torch.ops.aten.neg.default(exp_72);  exp_72 = None
    _to_copy_255 = torch.ops.aten._to_copy.default(_unsafe_view_279, dtype = torch.float32);  _unsafe_view_279 = None
    _param_constant220 = self._param_constant220
    add_223 = torch.ops.aten.add.Tensor(_to_copy_255, _param_constant220);  _to_copy_255 = _param_constant220 = None
    softplus_12 = torch.ops.aten.softplus.default(add_223);  add_223 = None
    mul_341 = torch.ops.aten.mul.Tensor(neg_20, softplus_12);  neg_20 = softplus_12 = None
    transpose_166 = torch.ops.aten.transpose.int(view_550, 1, 2);  view_550 = None
    _to_copy_256 = torch.ops.aten._to_copy.default(transpose_166, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_166 = None
    transpose_167 = torch.ops.aten.transpose.int(view_551, 1, 2);  view_551 = None
    _to_copy_257 = torch.ops.aten._to_copy.default(transpose_167, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_167 = None
    transpose_168 = torch.ops.aten.transpose.int(view_552, 1, 2);  view_552 = None
    _to_copy_258 = torch.ops.aten._to_copy.default(transpose_168, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_168 = None
    transpose_169 = torch.ops.aten.transpose.int(sigmoid_16, 1, 2);  sigmoid_16 = None
    _to_copy_259 = torch.ops.aten._to_copy.default(transpose_169, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_169 = None
    transpose_170 = torch.ops.aten.transpose.int(mul_341, 1, 2);  mul_341 = None
    mul_342 = torch.ops.aten.mul.Tensor(_to_copy_256, _to_copy_256)
    sum_25 = torch.ops.aten.sum.dim_IntList(mul_342, [-1], True);  mul_342 = None
    add_224 = torch.ops.aten.add.Tensor(sum_25, 1e-06);  sum_25 = None
    rsqrt_77 = torch.ops.aten.rsqrt.default(add_224);  add_224 = None
    mul_343 = torch.ops.aten.mul.Tensor(_to_copy_256, rsqrt_77);  _to_copy_256 = rsqrt_77 = None
    mul_344 = torch.ops.aten.mul.Tensor(_to_copy_257, _to_copy_257)
    sum_26 = torch.ops.aten.sum.dim_IntList(mul_344, [-1], True);  mul_344 = None
    add_225 = torch.ops.aten.add.Tensor(sum_26, 1e-06);  sum_26 = None
    rsqrt_78 = torch.ops.aten.rsqrt.default(add_225);  add_225 = None
    mul_345 = torch.ops.aten.mul.Tensor(_to_copy_257, rsqrt_78);  _to_copy_257 = rsqrt_78 = None
    mul_346 = torch.ops.aten.mul.Tensor(mul_343, 0.08838834764831845);  mul_343 = None
    constant_pad_nd_60 = torch.ops.aten.constant_pad_nd.default(mul_346, [0, 0, 0, 0], 0.0);  mul_346 = None
    constant_pad_nd_61 = torch.ops.aten.constant_pad_nd.default(mul_345, [0, 0, 0, 0], 0.0);  mul_345 = None
    constant_pad_nd_62 = torch.ops.aten.constant_pad_nd.default(_to_copy_258, [0, 0, 0, 0], 0.0);  _to_copy_258 = None
    constant_pad_nd_63 = torch.ops.aten.constant_pad_nd.default(_to_copy_259, [0, 0], 0.0);  _to_copy_259 = None
    constant_pad_nd_64 = torch.ops.aten.constant_pad_nd.default(transpose_170, [0, 0], 0.0);  transpose_170 = None
    unsqueeze_140 = torch.ops.aten.unsqueeze.default(constant_pad_nd_63, -1)
    mul_347 = torch.ops.aten.mul.Tensor(constant_pad_nd_62, unsqueeze_140);  constant_pad_nd_62 = unsqueeze_140 = None
    unsqueeze_141 = torch.ops.aten.unsqueeze.default(constant_pad_nd_63, -1);  constant_pad_nd_63 = None
    mul_348 = torch.ops.aten.mul.Tensor(constant_pad_nd_61, unsqueeze_141);  unsqueeze_141 = None
    view_553 = torch.ops.aten.view.default(constant_pad_nd_60, [1, 16, -1, 64, 128]);  constant_pad_nd_60 = None
    view_554 = torch.ops.aten.view.default(constant_pad_nd_61, [1, 16, -1, 64, 128]);  constant_pad_nd_61 = None
    view_555 = torch.ops.aten.view.default(mul_348, [1, 16, -1, 64, 128]);  mul_348 = None
    view_556 = torch.ops.aten.view.default(mul_347, [1, 16, -1, 64, 128]);  mul_347 = None
    view_557 = torch.ops.aten.view.default(constant_pad_nd_64, [1, 16, 2, 64]);  constant_pad_nd_64 = None
    ones_12 = torch.ops.aten.ones.default([64, 64], dtype = torch.bool, device = device(type='meta'), pin_memory = False)
    triu_13 = torch.ops.aten.triu.default(ones_12, 1);  ones_12 = None
    cumsum_12 = torch.ops.aten.cumsum.default(view_557, 3);  view_557 = None
    unsqueeze_142 = torch.ops.aten.unsqueeze.default(cumsum_12, 4)
    unsqueeze_143 = torch.ops.aten.unsqueeze.default(cumsum_12, 3)
    sub_48 = torch.ops.aten.sub.Tensor(unsqueeze_142, unsqueeze_143);  unsqueeze_142 = unsqueeze_143 = None
    masked_fill_12 = torch.ops.aten.masked_fill.Scalar(sub_48, triu_13, -inf);  sub_48 = triu_13 = None
    exp_73 = torch.ops.aten.exp.default(masked_fill_12);  masked_fill_12 = None
    transpose_171 = torch.ops.aten.transpose.int(view_554, -1, -2)
    expand_266 = torch.ops.aten.expand.default(view_555, [1, 16, 2, 64, 128])
    view_558 = torch.ops.aten.view.default(expand_266, [32, 64, 128]);  expand_266 = None
    expand_267 = torch.ops.aten.expand.default(transpose_171, [1, 16, 2, 128, 64]);  transpose_171 = None
    view_559 = torch.ops.aten.view.default(expand_267, [32, 128, 64]);  expand_267 = None
    bmm_128 = torch.ops.aten.bmm.default(view_558, view_559);  view_558 = view_559 = None
    _unsafe_view_280 = torch.ops.aten._unsafe_view.default(bmm_128, [1, 16, 2, 64, 64]);  bmm_128 = None
    mul_349 = torch.ops.aten.mul.Tensor(_unsafe_view_280, exp_73);  _unsafe_view_280 = None
    transpose_172 = torch.ops.aten.transpose.int(view_554, -1, -2)
    expand_268 = torch.ops.aten.expand.default(view_553, [1, 16, 2, 64, 128])
    view_560 = torch.ops.aten.view.default(expand_268, [32, 64, 128]);  expand_268 = None
    expand_269 = torch.ops.aten.expand.default(transpose_172, [1, 16, 2, 128, 64]);  transpose_172 = None
    view_561 = torch.ops.aten.view.default(expand_269, [32, 128, 64]);  expand_269 = None
    bmm_129 = torch.ops.aten.bmm.default(view_560, view_561);  view_560 = view_561 = None
    _unsafe_view_281 = torch.ops.aten._unsafe_view.default(bmm_129, [1, 16, 2, 64, 64]);  bmm_129 = None
    mul_350 = torch.ops.aten.mul.Tensor(_unsafe_view_281, exp_73);  _unsafe_view_281 = exp_73 = None
    exp_74 = torch.ops.aten.exp.default(cumsum_12)
    unsqueeze_144 = torch.ops.aten.unsqueeze.default(exp_74, -1);  exp_74 = None
    mul_351 = torch.ops.aten.mul.Tensor(view_555, unsqueeze_144);  view_555 = unsqueeze_144 = None
    linalg_solve_triangular_24 = torch.ops.aten.linalg_solve_triangular.default(mul_349, view_556, upper = False, unitriangular = True);  view_556 = None
    linalg_solve_triangular_25 = torch.ops.aten.linalg_solve_triangular.default(mul_349, mul_351, upper = False, unitriangular = True);  mul_349 = mul_351 = None
    zeros_12 = torch.ops.aten.zeros.default([1, 16, 128, 128], dtype = torch.float32, device = device(type='meta'), pin_memory = False)
    zeros_like_12 = torch.ops.aten.zeros_like.default(linalg_solve_triangular_24, pin_memory = False)
    exp_75 = torch.ops.aten.exp.default(cumsum_12)
    unsqueeze_145 = torch.ops.aten.unsqueeze.default(exp_75, -1);  exp_75 = None
    mul_352 = torch.ops.aten.mul.Tensor(view_553, unsqueeze_145);  view_553 = unsqueeze_145 = None
    slice_67 = torch.ops.aten.slice.Tensor(cumsum_12, 3, -1, 9223372036854775807)
    sub_49 = torch.ops.aten.sub.Tensor(slice_67, cumsum_12);  slice_67 = None
    exp_76 = torch.ops.aten.exp.default(sub_49);  sub_49 = None
    unsqueeze_146 = torch.ops.aten.unsqueeze.default(exp_76, -1);  exp_76 = None
    mul_353 = torch.ops.aten.mul.Tensor(view_554, unsqueeze_146);  view_554 = unsqueeze_146 = None
    select_187 = torch.ops.aten.select.int(cumsum_12, 3, -1);  cumsum_12 = None
    exp_77 = torch.ops.aten.exp.default(select_187);  select_187 = None
    unsqueeze_147 = torch.ops.aten.unsqueeze.default(exp_77, 3);  exp_77 = None
    unsqueeze_148 = torch.ops.aten.unsqueeze.default(unsqueeze_147, 4);  unsqueeze_147 = None
    select_188 = torch.ops.aten.select.int(linalg_solve_triangular_24, 2, 0)
    select_189 = torch.ops.aten.select.int(linalg_solve_triangular_25, 2, 0)
    expand_270 = torch.ops.aten.expand.default(select_189, [1, 16, 64, 128]);  select_189 = None
    view_562 = torch.ops.aten.view.default(expand_270, [16, 64, 128]);  expand_270 = None
    expand_271 = torch.ops.aten.expand.default(zeros_12, [1, 16, 128, 128])
    view_563 = torch.ops.aten.view.default(expand_271, [16, 128, 128]);  expand_271 = None
    bmm_130 = torch.ops.aten.bmm.default(view_562, view_563);  view_562 = view_563 = None
    _unsafe_view_282 = torch.ops.aten._unsafe_view.default(bmm_130, [1, 16, 64, 128]);  bmm_130 = None
    sub_50 = torch.ops.aten.sub.Tensor(select_188, _unsafe_view_282);  select_188 = _unsafe_view_282 = None
    select_190 = torch.ops.aten.select.int(mul_352, 2, 0)
    expand_272 = torch.ops.aten.expand.default(select_190, [1, 16, 64, 128]);  select_190 = None
    view_564 = torch.ops.aten.view.default(expand_272, [16, 64, 128]);  expand_272 = None
    expand_273 = torch.ops.aten.expand.default(zeros_12, [1, 16, 128, 128])
    view_565 = torch.ops.aten.view.default(expand_273, [16, 128, 128]);  expand_273 = None
    bmm_131 = torch.ops.aten.bmm.default(view_564, view_565);  view_564 = view_565 = None
    _unsafe_view_283 = torch.ops.aten._unsafe_view.default(bmm_131, [1, 16, 64, 128]);  bmm_131 = None
    select_191 = torch.ops.aten.select.int(mul_350, 2, 0)
    expand_274 = torch.ops.aten.expand.default(select_191, [1, 16, 64, 64]);  select_191 = None
    view_566 = torch.ops.aten.view.default(expand_274, [16, 64, 64]);  expand_274 = None
    expand_275 = torch.ops.aten.expand.default(sub_50, [1, 16, 64, 128])
    view_567 = torch.ops.aten.view.default(expand_275, [16, 64, 128]);  expand_275 = None
    bmm_132 = torch.ops.aten.bmm.default(view_566, view_567);  view_566 = view_567 = None
    _unsafe_view_284 = torch.ops.aten._unsafe_view.default(bmm_132, [1, 16, 64, 128]);  bmm_132 = None
    add_226 = torch.ops.aten.add.Tensor(_unsafe_view_283, _unsafe_view_284);  _unsafe_view_283 = _unsafe_view_284 = None
    select_192 = torch.ops.aten.select.int(zeros_like_12, 2, 0)
    copy__28 = torch.ops.aten.copy_.default(select_192, add_226);  select_192 = add_226 = copy__28 = None
    select_193 = torch.ops.aten.select.int(unsqueeze_148, 2, 0)
    mul_354 = torch.ops.aten.mul.Tensor(zeros_12, select_193);  zeros_12 = select_193 = None
    select_194 = torch.ops.aten.select.int(mul_353, 2, 0)
    transpose_173 = torch.ops.aten.transpose.int(select_194, -1, -2);  select_194 = None
    expand_276 = torch.ops.aten.expand.default(transpose_173, [1, 16, 128, 64]);  transpose_173 = None
    view_568 = torch.ops.aten.view.default(expand_276, [16, 128, 64]);  expand_276 = None
    expand_277 = torch.ops.aten.expand.default(sub_50, [1, 16, 64, 128]);  sub_50 = None
    view_569 = torch.ops.aten.view.default(expand_277, [16, 64, 128]);  expand_277 = None
    bmm_133 = torch.ops.aten.bmm.default(view_568, view_569);  view_568 = view_569 = None
    _unsafe_view_285 = torch.ops.aten._unsafe_view.default(bmm_133, [1, 16, 128, 128]);  bmm_133 = None
    add_227 = torch.ops.aten.add.Tensor(mul_354, _unsafe_view_285);  mul_354 = _unsafe_view_285 = None
    select_195 = torch.ops.aten.select.int(linalg_solve_triangular_24, 2, 1);  linalg_solve_triangular_24 = None
    select_196 = torch.ops.aten.select.int(linalg_solve_triangular_25, 2, 1);  linalg_solve_triangular_25 = None
    expand_278 = torch.ops.aten.expand.default(select_196, [1, 16, 64, 128]);  select_196 = None
    view_570 = torch.ops.aten.view.default(expand_278, [16, 64, 128]);  expand_278 = None
    expand_279 = torch.ops.aten.expand.default(add_227, [1, 16, 128, 128])
    view_571 = torch.ops.aten.view.default(expand_279, [16, 128, 128]);  expand_279 = None
    bmm_134 = torch.ops.aten.bmm.default(view_570, view_571);  view_570 = view_571 = None
    _unsafe_view_286 = torch.ops.aten._unsafe_view.default(bmm_134, [1, 16, 64, 128]);  bmm_134 = None
    sub_51 = torch.ops.aten.sub.Tensor(select_195, _unsafe_view_286);  select_195 = _unsafe_view_286 = None
    select_197 = torch.ops.aten.select.int(mul_352, 2, 1);  mul_352 = None
    expand_280 = torch.ops.aten.expand.default(select_197, [1, 16, 64, 128]);  select_197 = None
    view_572 = torch.ops.aten.view.default(expand_280, [16, 64, 128]);  expand_280 = None
    expand_281 = torch.ops.aten.expand.default(add_227, [1, 16, 128, 128])
    view_573 = torch.ops.aten.view.default(expand_281, [16, 128, 128]);  expand_281 = None
    bmm_135 = torch.ops.aten.bmm.default(view_572, view_573);  view_572 = view_573 = None
    _unsafe_view_287 = torch.ops.aten._unsafe_view.default(bmm_135, [1, 16, 64, 128]);  bmm_135 = None
    select_198 = torch.ops.aten.select.int(mul_350, 2, 1);  mul_350 = None
    expand_282 = torch.ops.aten.expand.default(select_198, [1, 16, 64, 64]);  select_198 = None
    view_574 = torch.ops.aten.view.default(expand_282, [16, 64, 64]);  expand_282 = None
    expand_283 = torch.ops.aten.expand.default(sub_51, [1, 16, 64, 128])
    view_575 = torch.ops.aten.view.default(expand_283, [16, 64, 128]);  expand_283 = None
    bmm_136 = torch.ops.aten.bmm.default(view_574, view_575);  view_574 = view_575 = None
    _unsafe_view_288 = torch.ops.aten._unsafe_view.default(bmm_136, [1, 16, 64, 128]);  bmm_136 = None
    add_228 = torch.ops.aten.add.Tensor(_unsafe_view_287, _unsafe_view_288);  _unsafe_view_287 = _unsafe_view_288 = None
    select_199 = torch.ops.aten.select.int(zeros_like_12, 2, 1)
    copy__29 = torch.ops.aten.copy_.default(select_199, add_228);  select_199 = add_228 = copy__29 = None
    select_200 = torch.ops.aten.select.int(unsqueeze_148, 2, 1);  unsqueeze_148 = None
    mul_355 = torch.ops.aten.mul.Tensor(add_227, select_200);  add_227 = select_200 = None
    select_201 = torch.ops.aten.select.int(mul_353, 2, 1);  mul_353 = None
    transpose_174 = torch.ops.aten.transpose.int(select_201, -1, -2);  select_201 = None
    expand_284 = torch.ops.aten.expand.default(transpose_174, [1, 16, 128, 64]);  transpose_174 = None
    view_576 = torch.ops.aten.view.default(expand_284, [16, 128, 64]);  expand_284 = None
    expand_285 = torch.ops.aten.expand.default(sub_51, [1, 16, 64, 128]);  sub_51 = None
    view_577 = torch.ops.aten.view.default(expand_285, [16, 64, 128]);  expand_285 = None
    bmm_137 = torch.ops.aten.bmm.default(view_576, view_577);  view_576 = view_577 = None
    _unsafe_view_289 = torch.ops.aten._unsafe_view.default(bmm_137, [1, 16, 128, 128]);  bmm_137 = None
    add_229 = torch.ops.aten.add.Tensor(mul_355, _unsafe_view_289);  mul_355 = _unsafe_view_289 = add_229 = None
    clone_28 = torch.ops.aten.clone.default(zeros_like_12, memory_format = torch.contiguous_format);  zeros_like_12 = None
    _unsafe_view_290 = torch.ops.aten._unsafe_view.default(clone_28, [1, 16, 128, 128]);  clone_28 = None
    alias_12 = torch.ops.aten.alias.default(_unsafe_view_290);  _unsafe_view_290 = None
    transpose_175 = torch.ops.aten.transpose.int(alias_12, 1, 2);  alias_12 = None
    _to_copy_260 = torch.ops.aten._to_copy.default(transpose_175, dtype = torch.bfloat16, memory_format = torch.contiguous_format);  transpose_175 = None
    view_578 = torch.ops.aten.view.default(_to_copy_260, [-1, 128]);  _to_copy_260 = None
    view_579 = torch.ops.aten.view.default(view_547, [-1, 128]);  view_547 = None
    _to_copy_261 = torch.ops.aten._to_copy.default(view_578, dtype = torch.float32);  view_578 = None
    pow_54 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_261, 2)
    mean_53 = torch.ops.aten.mean.dim(pow_54, [-1], True);  pow_54 = None
    add_230 = torch.ops.aten.add.Tensor(mean_53, 1e-06);  mean_53 = None
    rsqrt_79 = torch.ops.aten.rsqrt.default(add_230);  add_230 = None
    mul_356 = torch.ops.aten.mul.Tensor(_to_copy_261, rsqrt_79);  _to_copy_261 = rsqrt_79 = None
    _to_copy_262 = torch.ops.aten._to_copy.default(mul_356, dtype = torch.bfloat16);  mul_356 = None
    _param_constant221 = self._param_constant221
    mul_357 = torch.ops.aten.mul.Tensor(_param_constant221, _to_copy_262);  _param_constant221 = _to_copy_262 = None
    _to_copy_263 = torch.ops.aten._to_copy.default(view_579, dtype = torch.float32);  view_579 = None
    silu_41 = torch.ops.aten.silu.default(_to_copy_263);  _to_copy_263 = None
    mul_358 = torch.ops.aten.mul.Tensor(mul_357, silu_41);  mul_357 = silu_41 = None
    _to_copy_264 = torch.ops.aten._to_copy.default(mul_358, dtype = torch.bfloat16);  mul_358 = None
    view_580 = torch.ops.aten.view.default(_to_copy_264, [1, 128, -1]);  _to_copy_264 = None
    _param_constant222 = self._param_constant222
    t_128 = torch.ops.aten.t.default(_param_constant222);  _param_constant222 = None
    view_581 = torch.ops.aten.view.default(view_580, [128, 2048]);  view_580 = None
    mm_128 = torch.ops.aten.mm.default(view_581, t_128);  view_581 = t_128 = None
    _unsafe_view_291 = torch.ops.aten._unsafe_view.default(mm_128, [1, 128, 2048]);  mm_128 = None
    add_231 = torch.ops.aten.add.Tensor(add_220, _unsafe_view_291);  add_220 = _unsafe_view_291 = None
    _to_copy_265 = torch.ops.aten._to_copy.default(add_231, dtype = torch.float32)
    pow_55 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_265, 2)
    mean_54 = torch.ops.aten.mean.dim(pow_55, [-1], True);  pow_55 = None
    add_232 = torch.ops.aten.add.Tensor(mean_54, 1e-06);  mean_54 = None
    rsqrt_80 = torch.ops.aten.rsqrt.default(add_232);  add_232 = None
    mul_359 = torch.ops.aten.mul.Tensor(_to_copy_265, rsqrt_80);  _to_copy_265 = rsqrt_80 = None
    _param_constant223 = self._param_constant223
    _to_copy_266 = torch.ops.aten._to_copy.default(_param_constant223, dtype = torch.float32);  _param_constant223 = None
    add_233 = torch.ops.aten.add.Tensor(_to_copy_266, 1.0);  _to_copy_266 = None
    mul_360 = torch.ops.aten.mul.Tensor(mul_359, add_233);  mul_359 = add_233 = None
    _to_copy_267 = torch.ops.aten._to_copy.default(mul_360, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_360 = None
    _param_constant224 = self._param_constant224
    t_129 = torch.ops.aten.t.default(_param_constant224);  _param_constant224 = None
    view_582 = torch.ops.aten.view.default(_to_copy_267, [128, 2048])
    mm_129 = torch.ops.aten.mm.default(view_582, t_129);  view_582 = t_129 = None
    _unsafe_view_292 = torch.ops.aten._unsafe_view.default(mm_129, [1, 128, 6144]);  mm_129 = None
    silu_42 = torch.ops.aten.silu.default(_unsafe_view_292);  _unsafe_view_292 = None
    _param_constant225 = self._param_constant225
    t_130 = torch.ops.aten.t.default(_param_constant225);  _param_constant225 = None
    view_583 = torch.ops.aten.view.default(_to_copy_267, [128, 2048]);  _to_copy_267 = None
    mm_130 = torch.ops.aten.mm.default(view_583, t_130);  view_583 = t_130 = None
    _unsafe_view_293 = torch.ops.aten._unsafe_view.default(mm_130, [1, 128, 6144]);  mm_130 = None
    mul_361 = torch.ops.aten.mul.Tensor(silu_42, _unsafe_view_293);  silu_42 = _unsafe_view_293 = None
    _param_constant226 = self._param_constant226
    t_131 = torch.ops.aten.t.default(_param_constant226);  _param_constant226 = None
    view_584 = torch.ops.aten.view.default(mul_361, [128, 6144]);  mul_361 = None
    mm_131 = torch.ops.aten.mm.default(view_584, t_131);  view_584 = t_131 = None
    _unsafe_view_294 = torch.ops.aten._unsafe_view.default(mm_131, [1, 128, 2048]);  mm_131 = None
    add_234 = torch.ops.aten.add.Tensor(add_231, _unsafe_view_294);  add_231 = _unsafe_view_294 = None
    _to_copy_268 = torch.ops.aten._to_copy.default(add_234, dtype = torch.float32)
    pow_56 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_268, 2)
    mean_55 = torch.ops.aten.mean.dim(pow_56, [-1], True);  pow_56 = None
    add_235 = torch.ops.aten.add.Tensor(mean_55, 1e-06);  mean_55 = None
    rsqrt_81 = torch.ops.aten.rsqrt.default(add_235);  add_235 = None
    mul_362 = torch.ops.aten.mul.Tensor(_to_copy_268, rsqrt_81);  _to_copy_268 = rsqrt_81 = None
    _param_constant227 = self._param_constant227
    _to_copy_269 = torch.ops.aten._to_copy.default(_param_constant227, dtype = torch.float32);  _param_constant227 = None
    add_236 = torch.ops.aten.add.Tensor(_to_copy_269, 1.0);  _to_copy_269 = None
    mul_363 = torch.ops.aten.mul.Tensor(mul_362, add_236);  mul_362 = add_236 = None
    _to_copy_270 = torch.ops.aten._to_copy.default(mul_363, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_363 = None
    _param_constant228 = self._param_constant228
    t_132 = torch.ops.aten.t.default(_param_constant228);  _param_constant228 = None
    view_585 = torch.ops.aten.view.default(_to_copy_270, [128, 2048])
    mm_132 = torch.ops.aten.mm.default(view_585, t_132);  view_585 = t_132 = None
    _unsafe_view_295 = torch.ops.aten._unsafe_view.default(mm_132, [1, 128, 6144]);  mm_132 = None
    transpose_176 = torch.ops.aten.transpose.int(_unsafe_view_295, 1, 2);  _unsafe_view_295 = None
    _param_constant229 = self._param_constant229
    t_133 = torch.ops.aten.t.default(_param_constant229);  _param_constant229 = None
    view_586 = torch.ops.aten.view.default(_to_copy_270, [128, 2048])
    mm_133 = torch.ops.aten.mm.default(view_586, t_133);  view_586 = t_133 = None
    _unsafe_view_296 = torch.ops.aten._unsafe_view.default(mm_133, [1, 128, 2048]);  mm_133 = None
    view_587 = torch.ops.aten.view.default(_unsafe_view_296, [1, 128, -1, 128]);  _unsafe_view_296 = None
    _param_constant230 = self._param_constant230
    t_134 = torch.ops.aten.t.default(_param_constant230);  _param_constant230 = None
    view_588 = torch.ops.aten.view.default(_to_copy_270, [128, 2048])
    mm_134 = torch.ops.aten.mm.default(view_588, t_134);  view_588 = t_134 = None
    _unsafe_view_297 = torch.ops.aten._unsafe_view.default(mm_134, [1, 128, 16]);  mm_134 = None
    _param_constant231 = self._param_constant231
    t_135 = torch.ops.aten.t.default(_param_constant231);  _param_constant231 = None
    view_589 = torch.ops.aten.view.default(_to_copy_270, [128, 2048]);  _to_copy_270 = None
    mm_135 = torch.ops.aten.mm.default(view_589, t_135);  view_589 = t_135 = None
    _unsafe_view_298 = torch.ops.aten._unsafe_view.default(mm_135, [1, 128, 16]);  mm_135 = None
    _param_constant232 = self._param_constant232
    squeeze_13 = torch.ops.aten.squeeze.dim(_param_constant232, 1);  _param_constant232 = None
    unsqueeze_149 = torch.ops.aten.unsqueeze.default(squeeze_13, 1);  squeeze_13 = None
    convolution_13 = torch.ops.aten.convolution.default(transpose_176, unsqueeze_149, None, [1], [3], [1], False, [0], 6144);  transpose_176 = unsqueeze_149 = None
    slice_68 = torch.ops.aten.slice.Tensor(convolution_13, 2, 0, 128);  convolution_13 = None
    silu_43 = torch.ops.aten.silu.default(slice_68);  slice_68 = None
    transpose_177 = torch.ops.aten.transpose.int(silu_43, 1, 2);  silu_43 = None
    split_with_sizes_13 = torch.ops.aten.split_with_sizes.default(transpose_177, [2048, 2048, 2048], -1);  transpose_177 = None
    getitem_47 = split_with_sizes_13[0]
    getitem_48 = split_with_sizes_13[1]
    getitem_49 = split_with_sizes_13[2];  split_with_sizes_13 = None
    view_590 = torch.ops.aten.view.default(getitem_47, [1, 128, 16, 128]);  getitem_47 = None
    view_591 = torch.ops.aten.view.default(getitem_48, [1, 128, 16, 128]);  getitem_48 = None
    view_592 = torch.ops.aten.view.default(getitem_49, [1, 128, 16, 128]);  getitem_49 = None
    sigmoid_17 = torch.ops.aten.sigmoid.default(_unsafe_view_297);  _unsafe_view_297 = None
    _param_constant233 = self._param_constant233
    exp_78 = torch.ops.aten.exp.default(_param_constant233);  _param_constant233 = None
    neg_21 = torch.ops.aten.neg.default(exp_78);  exp_78 = None
    _to_copy_271 = torch.ops.aten._to_copy.default(_unsafe_view_298, dtype = torch.float32);  _unsafe_view_298 = None
    _param_constant234 = self._param_constant234
    add_237 = torch.ops.aten.add.Tensor(_to_copy_271, _param_constant234);  _to_copy_271 = _param_constant234 = None
    softplus_13 = torch.ops.aten.softplus.default(add_237);  add_237 = None
    mul_364 = torch.ops.aten.mul.Tensor(neg_21, softplus_13);  neg_21 = softplus_13 = None
    transpose_178 = torch.ops.aten.transpose.int(view_590, 1, 2);  view_590 = None
    _to_copy_272 = torch.ops.aten._to_copy.default(transpose_178, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_178 = None
    transpose_179 = torch.ops.aten.transpose.int(view_591, 1, 2);  view_591 = None
    _to_copy_273 = torch.ops.aten._to_copy.default(transpose_179, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_179 = None
    transpose_180 = torch.ops.aten.transpose.int(view_592, 1, 2);  view_592 = None
    _to_copy_274 = torch.ops.aten._to_copy.default(transpose_180, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_180 = None
    transpose_181 = torch.ops.aten.transpose.int(sigmoid_17, 1, 2);  sigmoid_17 = None
    _to_copy_275 = torch.ops.aten._to_copy.default(transpose_181, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_181 = None
    transpose_182 = torch.ops.aten.transpose.int(mul_364, 1, 2);  mul_364 = None
    mul_365 = torch.ops.aten.mul.Tensor(_to_copy_272, _to_copy_272)
    sum_27 = torch.ops.aten.sum.dim_IntList(mul_365, [-1], True);  mul_365 = None
    add_238 = torch.ops.aten.add.Tensor(sum_27, 1e-06);  sum_27 = None
    rsqrt_82 = torch.ops.aten.rsqrt.default(add_238);  add_238 = None
    mul_366 = torch.ops.aten.mul.Tensor(_to_copy_272, rsqrt_82);  _to_copy_272 = rsqrt_82 = None
    mul_367 = torch.ops.aten.mul.Tensor(_to_copy_273, _to_copy_273)
    sum_28 = torch.ops.aten.sum.dim_IntList(mul_367, [-1], True);  mul_367 = None
    add_239 = torch.ops.aten.add.Tensor(sum_28, 1e-06);  sum_28 = None
    rsqrt_83 = torch.ops.aten.rsqrt.default(add_239);  add_239 = None
    mul_368 = torch.ops.aten.mul.Tensor(_to_copy_273, rsqrt_83);  _to_copy_273 = rsqrt_83 = None
    mul_369 = torch.ops.aten.mul.Tensor(mul_366, 0.08838834764831845);  mul_366 = None
    constant_pad_nd_65 = torch.ops.aten.constant_pad_nd.default(mul_369, [0, 0, 0, 0], 0.0);  mul_369 = None
    constant_pad_nd_66 = torch.ops.aten.constant_pad_nd.default(mul_368, [0, 0, 0, 0], 0.0);  mul_368 = None
    constant_pad_nd_67 = torch.ops.aten.constant_pad_nd.default(_to_copy_274, [0, 0, 0, 0], 0.0);  _to_copy_274 = None
    constant_pad_nd_68 = torch.ops.aten.constant_pad_nd.default(_to_copy_275, [0, 0], 0.0);  _to_copy_275 = None
    constant_pad_nd_69 = torch.ops.aten.constant_pad_nd.default(transpose_182, [0, 0], 0.0);  transpose_182 = None
    unsqueeze_150 = torch.ops.aten.unsqueeze.default(constant_pad_nd_68, -1)
    mul_370 = torch.ops.aten.mul.Tensor(constant_pad_nd_67, unsqueeze_150);  constant_pad_nd_67 = unsqueeze_150 = None
    unsqueeze_151 = torch.ops.aten.unsqueeze.default(constant_pad_nd_68, -1);  constant_pad_nd_68 = None
    mul_371 = torch.ops.aten.mul.Tensor(constant_pad_nd_66, unsqueeze_151);  unsqueeze_151 = None
    view_593 = torch.ops.aten.view.default(constant_pad_nd_65, [1, 16, -1, 64, 128]);  constant_pad_nd_65 = None
    view_594 = torch.ops.aten.view.default(constant_pad_nd_66, [1, 16, -1, 64, 128]);  constant_pad_nd_66 = None
    view_595 = torch.ops.aten.view.default(mul_371, [1, 16, -1, 64, 128]);  mul_371 = None
    view_596 = torch.ops.aten.view.default(mul_370, [1, 16, -1, 64, 128]);  mul_370 = None
    view_597 = torch.ops.aten.view.default(constant_pad_nd_69, [1, 16, 2, 64]);  constant_pad_nd_69 = None
    ones_13 = torch.ops.aten.ones.default([64, 64], dtype = torch.bool, device = device(type='meta'), pin_memory = False)
    triu_14 = torch.ops.aten.triu.default(ones_13, 1);  ones_13 = None
    cumsum_13 = torch.ops.aten.cumsum.default(view_597, 3);  view_597 = None
    unsqueeze_152 = torch.ops.aten.unsqueeze.default(cumsum_13, 4)
    unsqueeze_153 = torch.ops.aten.unsqueeze.default(cumsum_13, 3)
    sub_52 = torch.ops.aten.sub.Tensor(unsqueeze_152, unsqueeze_153);  unsqueeze_152 = unsqueeze_153 = None
    masked_fill_13 = torch.ops.aten.masked_fill.Scalar(sub_52, triu_14, -inf);  sub_52 = triu_14 = None
    exp_79 = torch.ops.aten.exp.default(masked_fill_13);  masked_fill_13 = None
    transpose_183 = torch.ops.aten.transpose.int(view_594, -1, -2)
    expand_286 = torch.ops.aten.expand.default(view_595, [1, 16, 2, 64, 128])
    view_598 = torch.ops.aten.view.default(expand_286, [32, 64, 128]);  expand_286 = None
    expand_287 = torch.ops.aten.expand.default(transpose_183, [1, 16, 2, 128, 64]);  transpose_183 = None
    view_599 = torch.ops.aten.view.default(expand_287, [32, 128, 64]);  expand_287 = None
    bmm_138 = torch.ops.aten.bmm.default(view_598, view_599);  view_598 = view_599 = None
    _unsafe_view_299 = torch.ops.aten._unsafe_view.default(bmm_138, [1, 16, 2, 64, 64]);  bmm_138 = None
    mul_372 = torch.ops.aten.mul.Tensor(_unsafe_view_299, exp_79);  _unsafe_view_299 = None
    transpose_184 = torch.ops.aten.transpose.int(view_594, -1, -2)
    expand_288 = torch.ops.aten.expand.default(view_593, [1, 16, 2, 64, 128])
    view_600 = torch.ops.aten.view.default(expand_288, [32, 64, 128]);  expand_288 = None
    expand_289 = torch.ops.aten.expand.default(transpose_184, [1, 16, 2, 128, 64]);  transpose_184 = None
    view_601 = torch.ops.aten.view.default(expand_289, [32, 128, 64]);  expand_289 = None
    bmm_139 = torch.ops.aten.bmm.default(view_600, view_601);  view_600 = view_601 = None
    _unsafe_view_300 = torch.ops.aten._unsafe_view.default(bmm_139, [1, 16, 2, 64, 64]);  bmm_139 = None
    mul_373 = torch.ops.aten.mul.Tensor(_unsafe_view_300, exp_79);  _unsafe_view_300 = exp_79 = None
    exp_80 = torch.ops.aten.exp.default(cumsum_13)
    unsqueeze_154 = torch.ops.aten.unsqueeze.default(exp_80, -1);  exp_80 = None
    mul_374 = torch.ops.aten.mul.Tensor(view_595, unsqueeze_154);  view_595 = unsqueeze_154 = None
    linalg_solve_triangular_26 = torch.ops.aten.linalg_solve_triangular.default(mul_372, view_596, upper = False, unitriangular = True);  view_596 = None
    linalg_solve_triangular_27 = torch.ops.aten.linalg_solve_triangular.default(mul_372, mul_374, upper = False, unitriangular = True);  mul_372 = mul_374 = None
    zeros_13 = torch.ops.aten.zeros.default([1, 16, 128, 128], dtype = torch.float32, device = device(type='meta'), pin_memory = False)
    zeros_like_13 = torch.ops.aten.zeros_like.default(linalg_solve_triangular_26, pin_memory = False)
    exp_81 = torch.ops.aten.exp.default(cumsum_13)
    unsqueeze_155 = torch.ops.aten.unsqueeze.default(exp_81, -1);  exp_81 = None
    mul_375 = torch.ops.aten.mul.Tensor(view_593, unsqueeze_155);  view_593 = unsqueeze_155 = None
    slice_69 = torch.ops.aten.slice.Tensor(cumsum_13, 3, -1, 9223372036854775807)
    sub_53 = torch.ops.aten.sub.Tensor(slice_69, cumsum_13);  slice_69 = None
    exp_82 = torch.ops.aten.exp.default(sub_53);  sub_53 = None
    unsqueeze_156 = torch.ops.aten.unsqueeze.default(exp_82, -1);  exp_82 = None
    mul_376 = torch.ops.aten.mul.Tensor(view_594, unsqueeze_156);  view_594 = unsqueeze_156 = None
    select_202 = torch.ops.aten.select.int(cumsum_13, 3, -1);  cumsum_13 = None
    exp_83 = torch.ops.aten.exp.default(select_202);  select_202 = None
    unsqueeze_157 = torch.ops.aten.unsqueeze.default(exp_83, 3);  exp_83 = None
    unsqueeze_158 = torch.ops.aten.unsqueeze.default(unsqueeze_157, 4);  unsqueeze_157 = None
    select_203 = torch.ops.aten.select.int(linalg_solve_triangular_26, 2, 0)
    select_204 = torch.ops.aten.select.int(linalg_solve_triangular_27, 2, 0)
    expand_290 = torch.ops.aten.expand.default(select_204, [1, 16, 64, 128]);  select_204 = None
    view_602 = torch.ops.aten.view.default(expand_290, [16, 64, 128]);  expand_290 = None
    expand_291 = torch.ops.aten.expand.default(zeros_13, [1, 16, 128, 128])
    view_603 = torch.ops.aten.view.default(expand_291, [16, 128, 128]);  expand_291 = None
    bmm_140 = torch.ops.aten.bmm.default(view_602, view_603);  view_602 = view_603 = None
    _unsafe_view_301 = torch.ops.aten._unsafe_view.default(bmm_140, [1, 16, 64, 128]);  bmm_140 = None
    sub_54 = torch.ops.aten.sub.Tensor(select_203, _unsafe_view_301);  select_203 = _unsafe_view_301 = None
    select_205 = torch.ops.aten.select.int(mul_375, 2, 0)
    expand_292 = torch.ops.aten.expand.default(select_205, [1, 16, 64, 128]);  select_205 = None
    view_604 = torch.ops.aten.view.default(expand_292, [16, 64, 128]);  expand_292 = None
    expand_293 = torch.ops.aten.expand.default(zeros_13, [1, 16, 128, 128])
    view_605 = torch.ops.aten.view.default(expand_293, [16, 128, 128]);  expand_293 = None
    bmm_141 = torch.ops.aten.bmm.default(view_604, view_605);  view_604 = view_605 = None
    _unsafe_view_302 = torch.ops.aten._unsafe_view.default(bmm_141, [1, 16, 64, 128]);  bmm_141 = None
    select_206 = torch.ops.aten.select.int(mul_373, 2, 0)
    expand_294 = torch.ops.aten.expand.default(select_206, [1, 16, 64, 64]);  select_206 = None
    view_606 = torch.ops.aten.view.default(expand_294, [16, 64, 64]);  expand_294 = None
    expand_295 = torch.ops.aten.expand.default(sub_54, [1, 16, 64, 128])
    view_607 = torch.ops.aten.view.default(expand_295, [16, 64, 128]);  expand_295 = None
    bmm_142 = torch.ops.aten.bmm.default(view_606, view_607);  view_606 = view_607 = None
    _unsafe_view_303 = torch.ops.aten._unsafe_view.default(bmm_142, [1, 16, 64, 128]);  bmm_142 = None
    add_240 = torch.ops.aten.add.Tensor(_unsafe_view_302, _unsafe_view_303);  _unsafe_view_302 = _unsafe_view_303 = None
    select_207 = torch.ops.aten.select.int(zeros_like_13, 2, 0)
    copy__30 = torch.ops.aten.copy_.default(select_207, add_240);  select_207 = add_240 = copy__30 = None
    select_208 = torch.ops.aten.select.int(unsqueeze_158, 2, 0)
    mul_377 = torch.ops.aten.mul.Tensor(zeros_13, select_208);  zeros_13 = select_208 = None
    select_209 = torch.ops.aten.select.int(mul_376, 2, 0)
    transpose_185 = torch.ops.aten.transpose.int(select_209, -1, -2);  select_209 = None
    expand_296 = torch.ops.aten.expand.default(transpose_185, [1, 16, 128, 64]);  transpose_185 = None
    view_608 = torch.ops.aten.view.default(expand_296, [16, 128, 64]);  expand_296 = None
    expand_297 = torch.ops.aten.expand.default(sub_54, [1, 16, 64, 128]);  sub_54 = None
    view_609 = torch.ops.aten.view.default(expand_297, [16, 64, 128]);  expand_297 = None
    bmm_143 = torch.ops.aten.bmm.default(view_608, view_609);  view_608 = view_609 = None
    _unsafe_view_304 = torch.ops.aten._unsafe_view.default(bmm_143, [1, 16, 128, 128]);  bmm_143 = None
    add_241 = torch.ops.aten.add.Tensor(mul_377, _unsafe_view_304);  mul_377 = _unsafe_view_304 = None
    select_210 = torch.ops.aten.select.int(linalg_solve_triangular_26, 2, 1);  linalg_solve_triangular_26 = None
    select_211 = torch.ops.aten.select.int(linalg_solve_triangular_27, 2, 1);  linalg_solve_triangular_27 = None
    expand_298 = torch.ops.aten.expand.default(select_211, [1, 16, 64, 128]);  select_211 = None
    view_610 = torch.ops.aten.view.default(expand_298, [16, 64, 128]);  expand_298 = None
    expand_299 = torch.ops.aten.expand.default(add_241, [1, 16, 128, 128])
    view_611 = torch.ops.aten.view.default(expand_299, [16, 128, 128]);  expand_299 = None
    bmm_144 = torch.ops.aten.bmm.default(view_610, view_611);  view_610 = view_611 = None
    _unsafe_view_305 = torch.ops.aten._unsafe_view.default(bmm_144, [1, 16, 64, 128]);  bmm_144 = None
    sub_55 = torch.ops.aten.sub.Tensor(select_210, _unsafe_view_305);  select_210 = _unsafe_view_305 = None
    select_212 = torch.ops.aten.select.int(mul_375, 2, 1);  mul_375 = None
    expand_300 = torch.ops.aten.expand.default(select_212, [1, 16, 64, 128]);  select_212 = None
    view_612 = torch.ops.aten.view.default(expand_300, [16, 64, 128]);  expand_300 = None
    expand_301 = torch.ops.aten.expand.default(add_241, [1, 16, 128, 128])
    view_613 = torch.ops.aten.view.default(expand_301, [16, 128, 128]);  expand_301 = None
    bmm_145 = torch.ops.aten.bmm.default(view_612, view_613);  view_612 = view_613 = None
    _unsafe_view_306 = torch.ops.aten._unsafe_view.default(bmm_145, [1, 16, 64, 128]);  bmm_145 = None
    select_213 = torch.ops.aten.select.int(mul_373, 2, 1);  mul_373 = None
    expand_302 = torch.ops.aten.expand.default(select_213, [1, 16, 64, 64]);  select_213 = None
    view_614 = torch.ops.aten.view.default(expand_302, [16, 64, 64]);  expand_302 = None
    expand_303 = torch.ops.aten.expand.default(sub_55, [1, 16, 64, 128])
    view_615 = torch.ops.aten.view.default(expand_303, [16, 64, 128]);  expand_303 = None
    bmm_146 = torch.ops.aten.bmm.default(view_614, view_615);  view_614 = view_615 = None
    _unsafe_view_307 = torch.ops.aten._unsafe_view.default(bmm_146, [1, 16, 64, 128]);  bmm_146 = None
    add_242 = torch.ops.aten.add.Tensor(_unsafe_view_306, _unsafe_view_307);  _unsafe_view_306 = _unsafe_view_307 = None
    select_214 = torch.ops.aten.select.int(zeros_like_13, 2, 1)
    copy__31 = torch.ops.aten.copy_.default(select_214, add_242);  select_214 = add_242 = copy__31 = None
    select_215 = torch.ops.aten.select.int(unsqueeze_158, 2, 1);  unsqueeze_158 = None
    mul_378 = torch.ops.aten.mul.Tensor(add_241, select_215);  add_241 = select_215 = None
    select_216 = torch.ops.aten.select.int(mul_376, 2, 1);  mul_376 = None
    transpose_186 = torch.ops.aten.transpose.int(select_216, -1, -2);  select_216 = None
    expand_304 = torch.ops.aten.expand.default(transpose_186, [1, 16, 128, 64]);  transpose_186 = None
    view_616 = torch.ops.aten.view.default(expand_304, [16, 128, 64]);  expand_304 = None
    expand_305 = torch.ops.aten.expand.default(sub_55, [1, 16, 64, 128]);  sub_55 = None
    view_617 = torch.ops.aten.view.default(expand_305, [16, 64, 128]);  expand_305 = None
    bmm_147 = torch.ops.aten.bmm.default(view_616, view_617);  view_616 = view_617 = None
    _unsafe_view_308 = torch.ops.aten._unsafe_view.default(bmm_147, [1, 16, 128, 128]);  bmm_147 = None
    add_243 = torch.ops.aten.add.Tensor(mul_378, _unsafe_view_308);  mul_378 = _unsafe_view_308 = add_243 = None
    clone_29 = torch.ops.aten.clone.default(zeros_like_13, memory_format = torch.contiguous_format);  zeros_like_13 = None
    _unsafe_view_309 = torch.ops.aten._unsafe_view.default(clone_29, [1, 16, 128, 128]);  clone_29 = None
    alias_13 = torch.ops.aten.alias.default(_unsafe_view_309);  _unsafe_view_309 = None
    transpose_187 = torch.ops.aten.transpose.int(alias_13, 1, 2);  alias_13 = None
    _to_copy_276 = torch.ops.aten._to_copy.default(transpose_187, dtype = torch.bfloat16, memory_format = torch.contiguous_format);  transpose_187 = None
    view_618 = torch.ops.aten.view.default(_to_copy_276, [-1, 128]);  _to_copy_276 = None
    view_619 = torch.ops.aten.view.default(view_587, [-1, 128]);  view_587 = None
    _to_copy_277 = torch.ops.aten._to_copy.default(view_618, dtype = torch.float32);  view_618 = None
    pow_57 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_277, 2)
    mean_56 = torch.ops.aten.mean.dim(pow_57, [-1], True);  pow_57 = None
    add_244 = torch.ops.aten.add.Tensor(mean_56, 1e-06);  mean_56 = None
    rsqrt_84 = torch.ops.aten.rsqrt.default(add_244);  add_244 = None
    mul_379 = torch.ops.aten.mul.Tensor(_to_copy_277, rsqrt_84);  _to_copy_277 = rsqrt_84 = None
    _to_copy_278 = torch.ops.aten._to_copy.default(mul_379, dtype = torch.bfloat16);  mul_379 = None
    _param_constant235 = self._param_constant235
    mul_380 = torch.ops.aten.mul.Tensor(_param_constant235, _to_copy_278);  _param_constant235 = _to_copy_278 = None
    _to_copy_279 = torch.ops.aten._to_copy.default(view_619, dtype = torch.float32);  view_619 = None
    silu_44 = torch.ops.aten.silu.default(_to_copy_279);  _to_copy_279 = None
    mul_381 = torch.ops.aten.mul.Tensor(mul_380, silu_44);  mul_380 = silu_44 = None
    _to_copy_280 = torch.ops.aten._to_copy.default(mul_381, dtype = torch.bfloat16);  mul_381 = None
    view_620 = torch.ops.aten.view.default(_to_copy_280, [1, 128, -1]);  _to_copy_280 = None
    _param_constant236 = self._param_constant236
    t_136 = torch.ops.aten.t.default(_param_constant236);  _param_constant236 = None
    view_621 = torch.ops.aten.view.default(view_620, [128, 2048]);  view_620 = None
    mm_136 = torch.ops.aten.mm.default(view_621, t_136);  view_621 = t_136 = None
    _unsafe_view_310 = torch.ops.aten._unsafe_view.default(mm_136, [1, 128, 2048]);  mm_136 = None
    add_245 = torch.ops.aten.add.Tensor(add_234, _unsafe_view_310);  add_234 = _unsafe_view_310 = None
    _to_copy_281 = torch.ops.aten._to_copy.default(add_245, dtype = torch.float32)
    pow_58 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_281, 2)
    mean_57 = torch.ops.aten.mean.dim(pow_58, [-1], True);  pow_58 = None
    add_246 = torch.ops.aten.add.Tensor(mean_57, 1e-06);  mean_57 = None
    rsqrt_85 = torch.ops.aten.rsqrt.default(add_246);  add_246 = None
    mul_382 = torch.ops.aten.mul.Tensor(_to_copy_281, rsqrt_85);  _to_copy_281 = rsqrt_85 = None
    _param_constant237 = self._param_constant237
    _to_copy_282 = torch.ops.aten._to_copy.default(_param_constant237, dtype = torch.float32);  _param_constant237 = None
    add_247 = torch.ops.aten.add.Tensor(_to_copy_282, 1.0);  _to_copy_282 = None
    mul_383 = torch.ops.aten.mul.Tensor(mul_382, add_247);  mul_382 = add_247 = None
    _to_copy_283 = torch.ops.aten._to_copy.default(mul_383, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_383 = None
    _param_constant238 = self._param_constant238
    t_137 = torch.ops.aten.t.default(_param_constant238);  _param_constant238 = None
    view_622 = torch.ops.aten.view.default(_to_copy_283, [128, 2048])
    mm_137 = torch.ops.aten.mm.default(view_622, t_137);  view_622 = t_137 = None
    _unsafe_view_311 = torch.ops.aten._unsafe_view.default(mm_137, [1, 128, 6144]);  mm_137 = None
    silu_45 = torch.ops.aten.silu.default(_unsafe_view_311);  _unsafe_view_311 = None
    _param_constant239 = self._param_constant239
    t_138 = torch.ops.aten.t.default(_param_constant239);  _param_constant239 = None
    view_623 = torch.ops.aten.view.default(_to_copy_283, [128, 2048]);  _to_copy_283 = None
    mm_138 = torch.ops.aten.mm.default(view_623, t_138);  view_623 = t_138 = None
    _unsafe_view_312 = torch.ops.aten._unsafe_view.default(mm_138, [1, 128, 6144]);  mm_138 = None
    mul_384 = torch.ops.aten.mul.Tensor(silu_45, _unsafe_view_312);  silu_45 = _unsafe_view_312 = None
    _param_constant240 = self._param_constant240
    t_139 = torch.ops.aten.t.default(_param_constant240);  _param_constant240 = None
    view_624 = torch.ops.aten.view.default(mul_384, [128, 6144]);  mul_384 = None
    mm_139 = torch.ops.aten.mm.default(view_624, t_139);  view_624 = t_139 = None
    _unsafe_view_313 = torch.ops.aten._unsafe_view.default(mm_139, [1, 128, 2048]);  mm_139 = None
    add_248 = torch.ops.aten.add.Tensor(add_245, _unsafe_view_313);  add_245 = _unsafe_view_313 = None
    _to_copy_284 = torch.ops.aten._to_copy.default(add_248, dtype = torch.float32)
    pow_59 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_284, 2)
    mean_58 = torch.ops.aten.mean.dim(pow_59, [-1], True);  pow_59 = None
    add_249 = torch.ops.aten.add.Tensor(mean_58, 1e-06);  mean_58 = None
    rsqrt_86 = torch.ops.aten.rsqrt.default(add_249);  add_249 = None
    mul_385 = torch.ops.aten.mul.Tensor(_to_copy_284, rsqrt_86);  _to_copy_284 = rsqrt_86 = None
    _param_constant241 = self._param_constant241
    _to_copy_285 = torch.ops.aten._to_copy.default(_param_constant241, dtype = torch.float32);  _param_constant241 = None
    add_250 = torch.ops.aten.add.Tensor(_to_copy_285, 1.0);  _to_copy_285 = None
    mul_386 = torch.ops.aten.mul.Tensor(mul_385, add_250);  mul_385 = add_250 = None
    _to_copy_286 = torch.ops.aten._to_copy.default(mul_386, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_386 = None
    _param_constant242 = self._param_constant242
    t_140 = torch.ops.aten.t.default(_param_constant242);  _param_constant242 = None
    view_625 = torch.ops.aten.view.default(_to_copy_286, [128, 2048])
    mm_140 = torch.ops.aten.mm.default(view_625, t_140);  view_625 = t_140 = None
    _unsafe_view_314 = torch.ops.aten._unsafe_view.default(mm_140, [1, 128, 6144]);  mm_140 = None
    transpose_188 = torch.ops.aten.transpose.int(_unsafe_view_314, 1, 2);  _unsafe_view_314 = None
    _param_constant243 = self._param_constant243
    t_141 = torch.ops.aten.t.default(_param_constant243);  _param_constant243 = None
    view_626 = torch.ops.aten.view.default(_to_copy_286, [128, 2048])
    mm_141 = torch.ops.aten.mm.default(view_626, t_141);  view_626 = t_141 = None
    _unsafe_view_315 = torch.ops.aten._unsafe_view.default(mm_141, [1, 128, 2048]);  mm_141 = None
    view_627 = torch.ops.aten.view.default(_unsafe_view_315, [1, 128, -1, 128]);  _unsafe_view_315 = None
    _param_constant244 = self._param_constant244
    t_142 = torch.ops.aten.t.default(_param_constant244);  _param_constant244 = None
    view_628 = torch.ops.aten.view.default(_to_copy_286, [128, 2048])
    mm_142 = torch.ops.aten.mm.default(view_628, t_142);  view_628 = t_142 = None
    _unsafe_view_316 = torch.ops.aten._unsafe_view.default(mm_142, [1, 128, 16]);  mm_142 = None
    _param_constant245 = self._param_constant245
    t_143 = torch.ops.aten.t.default(_param_constant245);  _param_constant245 = None
    view_629 = torch.ops.aten.view.default(_to_copy_286, [128, 2048]);  _to_copy_286 = None
    mm_143 = torch.ops.aten.mm.default(view_629, t_143);  view_629 = t_143 = None
    _unsafe_view_317 = torch.ops.aten._unsafe_view.default(mm_143, [1, 128, 16]);  mm_143 = None
    _param_constant246 = self._param_constant246
    squeeze_14 = torch.ops.aten.squeeze.dim(_param_constant246, 1);  _param_constant246 = None
    unsqueeze_159 = torch.ops.aten.unsqueeze.default(squeeze_14, 1);  squeeze_14 = None
    convolution_14 = torch.ops.aten.convolution.default(transpose_188, unsqueeze_159, None, [1], [3], [1], False, [0], 6144);  transpose_188 = unsqueeze_159 = None
    slice_70 = torch.ops.aten.slice.Tensor(convolution_14, 2, 0, 128);  convolution_14 = None
    silu_46 = torch.ops.aten.silu.default(slice_70);  slice_70 = None
    transpose_189 = torch.ops.aten.transpose.int(silu_46, 1, 2);  silu_46 = None
    split_with_sizes_14 = torch.ops.aten.split_with_sizes.default(transpose_189, [2048, 2048, 2048], -1);  transpose_189 = None
    getitem_50 = split_with_sizes_14[0]
    getitem_51 = split_with_sizes_14[1]
    getitem_52 = split_with_sizes_14[2];  split_with_sizes_14 = None
    view_630 = torch.ops.aten.view.default(getitem_50, [1, 128, 16, 128]);  getitem_50 = None
    view_631 = torch.ops.aten.view.default(getitem_51, [1, 128, 16, 128]);  getitem_51 = None
    view_632 = torch.ops.aten.view.default(getitem_52, [1, 128, 16, 128]);  getitem_52 = None
    sigmoid_18 = torch.ops.aten.sigmoid.default(_unsafe_view_316);  _unsafe_view_316 = None
    _param_constant247 = self._param_constant247
    exp_84 = torch.ops.aten.exp.default(_param_constant247);  _param_constant247 = None
    neg_22 = torch.ops.aten.neg.default(exp_84);  exp_84 = None
    _to_copy_287 = torch.ops.aten._to_copy.default(_unsafe_view_317, dtype = torch.float32);  _unsafe_view_317 = None
    _param_constant248 = self._param_constant248
    add_251 = torch.ops.aten.add.Tensor(_to_copy_287, _param_constant248);  _to_copy_287 = _param_constant248 = None
    softplus_14 = torch.ops.aten.softplus.default(add_251);  add_251 = None
    mul_387 = torch.ops.aten.mul.Tensor(neg_22, softplus_14);  neg_22 = softplus_14 = None
    transpose_190 = torch.ops.aten.transpose.int(view_630, 1, 2);  view_630 = None
    _to_copy_288 = torch.ops.aten._to_copy.default(transpose_190, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_190 = None
    transpose_191 = torch.ops.aten.transpose.int(view_631, 1, 2);  view_631 = None
    _to_copy_289 = torch.ops.aten._to_copy.default(transpose_191, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_191 = None
    transpose_192 = torch.ops.aten.transpose.int(view_632, 1, 2);  view_632 = None
    _to_copy_290 = torch.ops.aten._to_copy.default(transpose_192, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_192 = None
    transpose_193 = torch.ops.aten.transpose.int(sigmoid_18, 1, 2);  sigmoid_18 = None
    _to_copy_291 = torch.ops.aten._to_copy.default(transpose_193, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_193 = None
    transpose_194 = torch.ops.aten.transpose.int(mul_387, 1, 2);  mul_387 = None
    mul_388 = torch.ops.aten.mul.Tensor(_to_copy_288, _to_copy_288)
    sum_29 = torch.ops.aten.sum.dim_IntList(mul_388, [-1], True);  mul_388 = None
    add_252 = torch.ops.aten.add.Tensor(sum_29, 1e-06);  sum_29 = None
    rsqrt_87 = torch.ops.aten.rsqrt.default(add_252);  add_252 = None
    mul_389 = torch.ops.aten.mul.Tensor(_to_copy_288, rsqrt_87);  _to_copy_288 = rsqrt_87 = None
    mul_390 = torch.ops.aten.mul.Tensor(_to_copy_289, _to_copy_289)
    sum_30 = torch.ops.aten.sum.dim_IntList(mul_390, [-1], True);  mul_390 = None
    add_253 = torch.ops.aten.add.Tensor(sum_30, 1e-06);  sum_30 = None
    rsqrt_88 = torch.ops.aten.rsqrt.default(add_253);  add_253 = None
    mul_391 = torch.ops.aten.mul.Tensor(_to_copy_289, rsqrt_88);  _to_copy_289 = rsqrt_88 = None
    mul_392 = torch.ops.aten.mul.Tensor(mul_389, 0.08838834764831845);  mul_389 = None
    constant_pad_nd_70 = torch.ops.aten.constant_pad_nd.default(mul_392, [0, 0, 0, 0], 0.0);  mul_392 = None
    constant_pad_nd_71 = torch.ops.aten.constant_pad_nd.default(mul_391, [0, 0, 0, 0], 0.0);  mul_391 = None
    constant_pad_nd_72 = torch.ops.aten.constant_pad_nd.default(_to_copy_290, [0, 0, 0, 0], 0.0);  _to_copy_290 = None
    constant_pad_nd_73 = torch.ops.aten.constant_pad_nd.default(_to_copy_291, [0, 0], 0.0);  _to_copy_291 = None
    constant_pad_nd_74 = torch.ops.aten.constant_pad_nd.default(transpose_194, [0, 0], 0.0);  transpose_194 = None
    unsqueeze_160 = torch.ops.aten.unsqueeze.default(constant_pad_nd_73, -1)
    mul_393 = torch.ops.aten.mul.Tensor(constant_pad_nd_72, unsqueeze_160);  constant_pad_nd_72 = unsqueeze_160 = None
    unsqueeze_161 = torch.ops.aten.unsqueeze.default(constant_pad_nd_73, -1);  constant_pad_nd_73 = None
    mul_394 = torch.ops.aten.mul.Tensor(constant_pad_nd_71, unsqueeze_161);  unsqueeze_161 = None
    view_633 = torch.ops.aten.view.default(constant_pad_nd_70, [1, 16, -1, 64, 128]);  constant_pad_nd_70 = None
    view_634 = torch.ops.aten.view.default(constant_pad_nd_71, [1, 16, -1, 64, 128]);  constant_pad_nd_71 = None
    view_635 = torch.ops.aten.view.default(mul_394, [1, 16, -1, 64, 128]);  mul_394 = None
    view_636 = torch.ops.aten.view.default(mul_393, [1, 16, -1, 64, 128]);  mul_393 = None
    view_637 = torch.ops.aten.view.default(constant_pad_nd_74, [1, 16, 2, 64]);  constant_pad_nd_74 = None
    ones_14 = torch.ops.aten.ones.default([64, 64], dtype = torch.bool, device = device(type='meta'), pin_memory = False)
    triu_15 = torch.ops.aten.triu.default(ones_14, 1);  ones_14 = None
    cumsum_14 = torch.ops.aten.cumsum.default(view_637, 3);  view_637 = None
    unsqueeze_162 = torch.ops.aten.unsqueeze.default(cumsum_14, 4)
    unsqueeze_163 = torch.ops.aten.unsqueeze.default(cumsum_14, 3)
    sub_56 = torch.ops.aten.sub.Tensor(unsqueeze_162, unsqueeze_163);  unsqueeze_162 = unsqueeze_163 = None
    masked_fill_14 = torch.ops.aten.masked_fill.Scalar(sub_56, triu_15, -inf);  sub_56 = triu_15 = None
    exp_85 = torch.ops.aten.exp.default(masked_fill_14);  masked_fill_14 = None
    transpose_195 = torch.ops.aten.transpose.int(view_634, -1, -2)
    expand_306 = torch.ops.aten.expand.default(view_635, [1, 16, 2, 64, 128])
    view_638 = torch.ops.aten.view.default(expand_306, [32, 64, 128]);  expand_306 = None
    expand_307 = torch.ops.aten.expand.default(transpose_195, [1, 16, 2, 128, 64]);  transpose_195 = None
    view_639 = torch.ops.aten.view.default(expand_307, [32, 128, 64]);  expand_307 = None
    bmm_148 = torch.ops.aten.bmm.default(view_638, view_639);  view_638 = view_639 = None
    _unsafe_view_318 = torch.ops.aten._unsafe_view.default(bmm_148, [1, 16, 2, 64, 64]);  bmm_148 = None
    mul_395 = torch.ops.aten.mul.Tensor(_unsafe_view_318, exp_85);  _unsafe_view_318 = None
    transpose_196 = torch.ops.aten.transpose.int(view_634, -1, -2)
    expand_308 = torch.ops.aten.expand.default(view_633, [1, 16, 2, 64, 128])
    view_640 = torch.ops.aten.view.default(expand_308, [32, 64, 128]);  expand_308 = None
    expand_309 = torch.ops.aten.expand.default(transpose_196, [1, 16, 2, 128, 64]);  transpose_196 = None
    view_641 = torch.ops.aten.view.default(expand_309, [32, 128, 64]);  expand_309 = None
    bmm_149 = torch.ops.aten.bmm.default(view_640, view_641);  view_640 = view_641 = None
    _unsafe_view_319 = torch.ops.aten._unsafe_view.default(bmm_149, [1, 16, 2, 64, 64]);  bmm_149 = None
    mul_396 = torch.ops.aten.mul.Tensor(_unsafe_view_319, exp_85);  _unsafe_view_319 = exp_85 = None
    exp_86 = torch.ops.aten.exp.default(cumsum_14)
    unsqueeze_164 = torch.ops.aten.unsqueeze.default(exp_86, -1);  exp_86 = None
    mul_397 = torch.ops.aten.mul.Tensor(view_635, unsqueeze_164);  view_635 = unsqueeze_164 = None
    linalg_solve_triangular_28 = torch.ops.aten.linalg_solve_triangular.default(mul_395, view_636, upper = False, unitriangular = True);  view_636 = None
    linalg_solve_triangular_29 = torch.ops.aten.linalg_solve_triangular.default(mul_395, mul_397, upper = False, unitriangular = True);  mul_395 = mul_397 = None
    zeros_14 = torch.ops.aten.zeros.default([1, 16, 128, 128], dtype = torch.float32, device = device(type='meta'), pin_memory = False)
    zeros_like_14 = torch.ops.aten.zeros_like.default(linalg_solve_triangular_28, pin_memory = False)
    exp_87 = torch.ops.aten.exp.default(cumsum_14)
    unsqueeze_165 = torch.ops.aten.unsqueeze.default(exp_87, -1);  exp_87 = None
    mul_398 = torch.ops.aten.mul.Tensor(view_633, unsqueeze_165);  view_633 = unsqueeze_165 = None
    slice_71 = torch.ops.aten.slice.Tensor(cumsum_14, 3, -1, 9223372036854775807)
    sub_57 = torch.ops.aten.sub.Tensor(slice_71, cumsum_14);  slice_71 = None
    exp_88 = torch.ops.aten.exp.default(sub_57);  sub_57 = None
    unsqueeze_166 = torch.ops.aten.unsqueeze.default(exp_88, -1);  exp_88 = None
    mul_399 = torch.ops.aten.mul.Tensor(view_634, unsqueeze_166);  view_634 = unsqueeze_166 = None
    select_217 = torch.ops.aten.select.int(cumsum_14, 3, -1);  cumsum_14 = None
    exp_89 = torch.ops.aten.exp.default(select_217);  select_217 = None
    unsqueeze_167 = torch.ops.aten.unsqueeze.default(exp_89, 3);  exp_89 = None
    unsqueeze_168 = torch.ops.aten.unsqueeze.default(unsqueeze_167, 4);  unsqueeze_167 = None
    select_218 = torch.ops.aten.select.int(linalg_solve_triangular_28, 2, 0)
    select_219 = torch.ops.aten.select.int(linalg_solve_triangular_29, 2, 0)
    expand_310 = torch.ops.aten.expand.default(select_219, [1, 16, 64, 128]);  select_219 = None
    view_642 = torch.ops.aten.view.default(expand_310, [16, 64, 128]);  expand_310 = None
    expand_311 = torch.ops.aten.expand.default(zeros_14, [1, 16, 128, 128])
    view_643 = torch.ops.aten.view.default(expand_311, [16, 128, 128]);  expand_311 = None
    bmm_150 = torch.ops.aten.bmm.default(view_642, view_643);  view_642 = view_643 = None
    _unsafe_view_320 = torch.ops.aten._unsafe_view.default(bmm_150, [1, 16, 64, 128]);  bmm_150 = None
    sub_58 = torch.ops.aten.sub.Tensor(select_218, _unsafe_view_320);  select_218 = _unsafe_view_320 = None
    select_220 = torch.ops.aten.select.int(mul_398, 2, 0)
    expand_312 = torch.ops.aten.expand.default(select_220, [1, 16, 64, 128]);  select_220 = None
    view_644 = torch.ops.aten.view.default(expand_312, [16, 64, 128]);  expand_312 = None
    expand_313 = torch.ops.aten.expand.default(zeros_14, [1, 16, 128, 128])
    view_645 = torch.ops.aten.view.default(expand_313, [16, 128, 128]);  expand_313 = None
    bmm_151 = torch.ops.aten.bmm.default(view_644, view_645);  view_644 = view_645 = None
    _unsafe_view_321 = torch.ops.aten._unsafe_view.default(bmm_151, [1, 16, 64, 128]);  bmm_151 = None
    select_221 = torch.ops.aten.select.int(mul_396, 2, 0)
    expand_314 = torch.ops.aten.expand.default(select_221, [1, 16, 64, 64]);  select_221 = None
    view_646 = torch.ops.aten.view.default(expand_314, [16, 64, 64]);  expand_314 = None
    expand_315 = torch.ops.aten.expand.default(sub_58, [1, 16, 64, 128])
    view_647 = torch.ops.aten.view.default(expand_315, [16, 64, 128]);  expand_315 = None
    bmm_152 = torch.ops.aten.bmm.default(view_646, view_647);  view_646 = view_647 = None
    _unsafe_view_322 = torch.ops.aten._unsafe_view.default(bmm_152, [1, 16, 64, 128]);  bmm_152 = None
    add_254 = torch.ops.aten.add.Tensor(_unsafe_view_321, _unsafe_view_322);  _unsafe_view_321 = _unsafe_view_322 = None
    select_222 = torch.ops.aten.select.int(zeros_like_14, 2, 0)
    copy__32 = torch.ops.aten.copy_.default(select_222, add_254);  select_222 = add_254 = copy__32 = None
    select_223 = torch.ops.aten.select.int(unsqueeze_168, 2, 0)
    mul_400 = torch.ops.aten.mul.Tensor(zeros_14, select_223);  zeros_14 = select_223 = None
    select_224 = torch.ops.aten.select.int(mul_399, 2, 0)
    transpose_197 = torch.ops.aten.transpose.int(select_224, -1, -2);  select_224 = None
    expand_316 = torch.ops.aten.expand.default(transpose_197, [1, 16, 128, 64]);  transpose_197 = None
    view_648 = torch.ops.aten.view.default(expand_316, [16, 128, 64]);  expand_316 = None
    expand_317 = torch.ops.aten.expand.default(sub_58, [1, 16, 64, 128]);  sub_58 = None
    view_649 = torch.ops.aten.view.default(expand_317, [16, 64, 128]);  expand_317 = None
    bmm_153 = torch.ops.aten.bmm.default(view_648, view_649);  view_648 = view_649 = None
    _unsafe_view_323 = torch.ops.aten._unsafe_view.default(bmm_153, [1, 16, 128, 128]);  bmm_153 = None
    add_255 = torch.ops.aten.add.Tensor(mul_400, _unsafe_view_323);  mul_400 = _unsafe_view_323 = None
    select_225 = torch.ops.aten.select.int(linalg_solve_triangular_28, 2, 1);  linalg_solve_triangular_28 = None
    select_226 = torch.ops.aten.select.int(linalg_solve_triangular_29, 2, 1);  linalg_solve_triangular_29 = None
    expand_318 = torch.ops.aten.expand.default(select_226, [1, 16, 64, 128]);  select_226 = None
    view_650 = torch.ops.aten.view.default(expand_318, [16, 64, 128]);  expand_318 = None
    expand_319 = torch.ops.aten.expand.default(add_255, [1, 16, 128, 128])
    view_651 = torch.ops.aten.view.default(expand_319, [16, 128, 128]);  expand_319 = None
    bmm_154 = torch.ops.aten.bmm.default(view_650, view_651);  view_650 = view_651 = None
    _unsafe_view_324 = torch.ops.aten._unsafe_view.default(bmm_154, [1, 16, 64, 128]);  bmm_154 = None
    sub_59 = torch.ops.aten.sub.Tensor(select_225, _unsafe_view_324);  select_225 = _unsafe_view_324 = None
    select_227 = torch.ops.aten.select.int(mul_398, 2, 1);  mul_398 = None
    expand_320 = torch.ops.aten.expand.default(select_227, [1, 16, 64, 128]);  select_227 = None
    view_652 = torch.ops.aten.view.default(expand_320, [16, 64, 128]);  expand_320 = None
    expand_321 = torch.ops.aten.expand.default(add_255, [1, 16, 128, 128])
    view_653 = torch.ops.aten.view.default(expand_321, [16, 128, 128]);  expand_321 = None
    bmm_155 = torch.ops.aten.bmm.default(view_652, view_653);  view_652 = view_653 = None
    _unsafe_view_325 = torch.ops.aten._unsafe_view.default(bmm_155, [1, 16, 64, 128]);  bmm_155 = None
    select_228 = torch.ops.aten.select.int(mul_396, 2, 1);  mul_396 = None
    expand_322 = torch.ops.aten.expand.default(select_228, [1, 16, 64, 64]);  select_228 = None
    view_654 = torch.ops.aten.view.default(expand_322, [16, 64, 64]);  expand_322 = None
    expand_323 = torch.ops.aten.expand.default(sub_59, [1, 16, 64, 128])
    view_655 = torch.ops.aten.view.default(expand_323, [16, 64, 128]);  expand_323 = None
    bmm_156 = torch.ops.aten.bmm.default(view_654, view_655);  view_654 = view_655 = None
    _unsafe_view_326 = torch.ops.aten._unsafe_view.default(bmm_156, [1, 16, 64, 128]);  bmm_156 = None
    add_256 = torch.ops.aten.add.Tensor(_unsafe_view_325, _unsafe_view_326);  _unsafe_view_325 = _unsafe_view_326 = None
    select_229 = torch.ops.aten.select.int(zeros_like_14, 2, 1)
    copy__33 = torch.ops.aten.copy_.default(select_229, add_256);  select_229 = add_256 = copy__33 = None
    select_230 = torch.ops.aten.select.int(unsqueeze_168, 2, 1);  unsqueeze_168 = None
    mul_401 = torch.ops.aten.mul.Tensor(add_255, select_230);  add_255 = select_230 = None
    select_231 = torch.ops.aten.select.int(mul_399, 2, 1);  mul_399 = None
    transpose_198 = torch.ops.aten.transpose.int(select_231, -1, -2);  select_231 = None
    expand_324 = torch.ops.aten.expand.default(transpose_198, [1, 16, 128, 64]);  transpose_198 = None
    view_656 = torch.ops.aten.view.default(expand_324, [16, 128, 64]);  expand_324 = None
    expand_325 = torch.ops.aten.expand.default(sub_59, [1, 16, 64, 128]);  sub_59 = None
    view_657 = torch.ops.aten.view.default(expand_325, [16, 64, 128]);  expand_325 = None
    bmm_157 = torch.ops.aten.bmm.default(view_656, view_657);  view_656 = view_657 = None
    _unsafe_view_327 = torch.ops.aten._unsafe_view.default(bmm_157, [1, 16, 128, 128]);  bmm_157 = None
    add_257 = torch.ops.aten.add.Tensor(mul_401, _unsafe_view_327);  mul_401 = _unsafe_view_327 = add_257 = None
    clone_30 = torch.ops.aten.clone.default(zeros_like_14, memory_format = torch.contiguous_format);  zeros_like_14 = None
    _unsafe_view_328 = torch.ops.aten._unsafe_view.default(clone_30, [1, 16, 128, 128]);  clone_30 = None
    alias_14 = torch.ops.aten.alias.default(_unsafe_view_328);  _unsafe_view_328 = None
    transpose_199 = torch.ops.aten.transpose.int(alias_14, 1, 2);  alias_14 = None
    _to_copy_292 = torch.ops.aten._to_copy.default(transpose_199, dtype = torch.bfloat16, memory_format = torch.contiguous_format);  transpose_199 = None
    view_658 = torch.ops.aten.view.default(_to_copy_292, [-1, 128]);  _to_copy_292 = None
    view_659 = torch.ops.aten.view.default(view_627, [-1, 128]);  view_627 = None
    _to_copy_293 = torch.ops.aten._to_copy.default(view_658, dtype = torch.float32);  view_658 = None
    pow_60 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_293, 2)
    mean_59 = torch.ops.aten.mean.dim(pow_60, [-1], True);  pow_60 = None
    add_258 = torch.ops.aten.add.Tensor(mean_59, 1e-06);  mean_59 = None
    rsqrt_89 = torch.ops.aten.rsqrt.default(add_258);  add_258 = None
    mul_402 = torch.ops.aten.mul.Tensor(_to_copy_293, rsqrt_89);  _to_copy_293 = rsqrt_89 = None
    _to_copy_294 = torch.ops.aten._to_copy.default(mul_402, dtype = torch.bfloat16);  mul_402 = None
    _param_constant249 = self._param_constant249
    mul_403 = torch.ops.aten.mul.Tensor(_param_constant249, _to_copy_294);  _param_constant249 = _to_copy_294 = None
    _to_copy_295 = torch.ops.aten._to_copy.default(view_659, dtype = torch.float32);  view_659 = None
    silu_47 = torch.ops.aten.silu.default(_to_copy_295);  _to_copy_295 = None
    mul_404 = torch.ops.aten.mul.Tensor(mul_403, silu_47);  mul_403 = silu_47 = None
    _to_copy_296 = torch.ops.aten._to_copy.default(mul_404, dtype = torch.bfloat16);  mul_404 = None
    view_660 = torch.ops.aten.view.default(_to_copy_296, [1, 128, -1]);  _to_copy_296 = None
    _param_constant250 = self._param_constant250
    t_144 = torch.ops.aten.t.default(_param_constant250);  _param_constant250 = None
    view_661 = torch.ops.aten.view.default(view_660, [128, 2048]);  view_660 = None
    mm_144 = torch.ops.aten.mm.default(view_661, t_144);  view_661 = t_144 = None
    _unsafe_view_329 = torch.ops.aten._unsafe_view.default(mm_144, [1, 128, 2048]);  mm_144 = None
    add_259 = torch.ops.aten.add.Tensor(add_248, _unsafe_view_329);  add_248 = _unsafe_view_329 = None
    _to_copy_297 = torch.ops.aten._to_copy.default(add_259, dtype = torch.float32)
    pow_61 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_297, 2)
    mean_60 = torch.ops.aten.mean.dim(pow_61, [-1], True);  pow_61 = None
    add_260 = torch.ops.aten.add.Tensor(mean_60, 1e-06);  mean_60 = None
    rsqrt_90 = torch.ops.aten.rsqrt.default(add_260);  add_260 = None
    mul_405 = torch.ops.aten.mul.Tensor(_to_copy_297, rsqrt_90);  _to_copy_297 = rsqrt_90 = None
    _param_constant251 = self._param_constant251
    _to_copy_298 = torch.ops.aten._to_copy.default(_param_constant251, dtype = torch.float32);  _param_constant251 = None
    add_261 = torch.ops.aten.add.Tensor(_to_copy_298, 1.0);  _to_copy_298 = None
    mul_406 = torch.ops.aten.mul.Tensor(mul_405, add_261);  mul_405 = add_261 = None
    _to_copy_299 = torch.ops.aten._to_copy.default(mul_406, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_406 = None
    _param_constant252 = self._param_constant252
    t_145 = torch.ops.aten.t.default(_param_constant252);  _param_constant252 = None
    view_662 = torch.ops.aten.view.default(_to_copy_299, [128, 2048])
    mm_145 = torch.ops.aten.mm.default(view_662, t_145);  view_662 = t_145 = None
    _unsafe_view_330 = torch.ops.aten._unsafe_view.default(mm_145, [1, 128, 6144]);  mm_145 = None
    silu_48 = torch.ops.aten.silu.default(_unsafe_view_330);  _unsafe_view_330 = None
    _param_constant253 = self._param_constant253
    t_146 = torch.ops.aten.t.default(_param_constant253);  _param_constant253 = None
    view_663 = torch.ops.aten.view.default(_to_copy_299, [128, 2048]);  _to_copy_299 = None
    mm_146 = torch.ops.aten.mm.default(view_663, t_146);  view_663 = t_146 = None
    _unsafe_view_331 = torch.ops.aten._unsafe_view.default(mm_146, [1, 128, 6144]);  mm_146 = None
    mul_407 = torch.ops.aten.mul.Tensor(silu_48, _unsafe_view_331);  silu_48 = _unsafe_view_331 = None
    _param_constant254 = self._param_constant254
    t_147 = torch.ops.aten.t.default(_param_constant254);  _param_constant254 = None
    view_664 = torch.ops.aten.view.default(mul_407, [128, 6144]);  mul_407 = None
    mm_147 = torch.ops.aten.mm.default(view_664, t_147);  view_664 = t_147 = None
    _unsafe_view_332 = torch.ops.aten._unsafe_view.default(mm_147, [1, 128, 2048]);  mm_147 = None
    add_262 = torch.ops.aten.add.Tensor(add_259, _unsafe_view_332);  add_259 = _unsafe_view_332 = None
    _to_copy_300 = torch.ops.aten._to_copy.default(add_262, dtype = torch.float32)
    pow_62 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_300, 2)
    mean_61 = torch.ops.aten.mean.dim(pow_62, [-1], True);  pow_62 = None
    add_263 = torch.ops.aten.add.Tensor(mean_61, 1e-06);  mean_61 = None
    rsqrt_91 = torch.ops.aten.rsqrt.default(add_263);  add_263 = None
    mul_408 = torch.ops.aten.mul.Tensor(_to_copy_300, rsqrt_91);  _to_copy_300 = rsqrt_91 = None
    _param_constant255 = self._param_constant255
    _to_copy_301 = torch.ops.aten._to_copy.default(_param_constant255, dtype = torch.float32);  _param_constant255 = None
    add_264 = torch.ops.aten.add.Tensor(_to_copy_301, 1.0);  _to_copy_301 = None
    mul_409 = torch.ops.aten.mul.Tensor(mul_408, add_264);  mul_408 = add_264 = None
    _to_copy_302 = torch.ops.aten._to_copy.default(mul_409, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_409 = None
    _param_constant256 = self._param_constant256
    t_148 = torch.ops.aten.t.default(_param_constant256);  _param_constant256 = None
    view_665 = torch.ops.aten.view.default(_to_copy_302, [128, 2048])
    mm_148 = torch.ops.aten.mm.default(view_665, t_148);  view_665 = t_148 = None
    _unsafe_view_333 = torch.ops.aten._unsafe_view.default(mm_148, [1, 128, 4096]);  mm_148 = None
    view_666 = torch.ops.aten.view.default(_unsafe_view_333, [1, 128, -1, 512]);  _unsafe_view_333 = None
    split_4 = torch.ops.aten.split.Tensor(view_666, 256, -1);  view_666 = None
    getitem_53 = split_4[0]
    getitem_54 = split_4[1];  split_4 = None
    clone_31 = torch.ops.aten.clone.default(getitem_54, memory_format = torch.contiguous_format);  getitem_54 = None
    _unsafe_view_334 = torch.ops.aten._unsafe_view.default(clone_31, [1, 128, 2048]);  clone_31 = None
    view_667 = torch.ops.aten.view.default(getitem_53, [1, 128, -1, 256]);  getitem_53 = None
    _to_copy_303 = torch.ops.aten._to_copy.default(view_667, dtype = torch.float32);  view_667 = None
    pow_63 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_303, 2)
    mean_62 = torch.ops.aten.mean.dim(pow_63, [-1], True);  pow_63 = None
    add_265 = torch.ops.aten.add.Tensor(mean_62, 1e-06);  mean_62 = None
    rsqrt_92 = torch.ops.aten.rsqrt.default(add_265);  add_265 = None
    mul_410 = torch.ops.aten.mul.Tensor(_to_copy_303, rsqrt_92);  _to_copy_303 = rsqrt_92 = None
    _param_constant257 = self._param_constant257
    _to_copy_304 = torch.ops.aten._to_copy.default(_param_constant257, dtype = torch.float32);  _param_constant257 = None
    add_266 = torch.ops.aten.add.Tensor(_to_copy_304, 1.0);  _to_copy_304 = None
    mul_411 = torch.ops.aten.mul.Tensor(mul_410, add_266);  mul_410 = add_266 = None
    _to_copy_305 = torch.ops.aten._to_copy.default(mul_411, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_411 = None
    transpose_200 = torch.ops.aten.transpose.int(_to_copy_305, 1, 2);  _to_copy_305 = None
    _param_constant258 = self._param_constant258
    t_149 = torch.ops.aten.t.default(_param_constant258);  _param_constant258 = None
    view_668 = torch.ops.aten.view.default(_to_copy_302, [128, 2048])
    mm_149 = torch.ops.aten.mm.default(view_668, t_149);  view_668 = t_149 = None
    _unsafe_view_335 = torch.ops.aten._unsafe_view.default(mm_149, [1, 128, 512]);  mm_149 = None
    view_669 = torch.ops.aten.view.default(_unsafe_view_335, [1, 128, -1, 256]);  _unsafe_view_335 = None
    _to_copy_306 = torch.ops.aten._to_copy.default(view_669, dtype = torch.float32);  view_669 = None
    pow_64 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_306, 2)
    mean_63 = torch.ops.aten.mean.dim(pow_64, [-1], True);  pow_64 = None
    add_267 = torch.ops.aten.add.Tensor(mean_63, 1e-06);  mean_63 = None
    rsqrt_93 = torch.ops.aten.rsqrt.default(add_267);  add_267 = None
    mul_412 = torch.ops.aten.mul.Tensor(_to_copy_306, rsqrt_93);  _to_copy_306 = rsqrt_93 = None
    _param_constant259 = self._param_constant259
    _to_copy_307 = torch.ops.aten._to_copy.default(_param_constant259, dtype = torch.float32);  _param_constant259 = None
    add_268 = torch.ops.aten.add.Tensor(_to_copy_307, 1.0);  _to_copy_307 = None
    mul_413 = torch.ops.aten.mul.Tensor(mul_412, add_268);  mul_412 = add_268 = None
    _to_copy_308 = torch.ops.aten._to_copy.default(mul_413, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_413 = None
    transpose_201 = torch.ops.aten.transpose.int(_to_copy_308, 1, 2);  _to_copy_308 = None
    _param_constant260 = self._param_constant260
    t_150 = torch.ops.aten.t.default(_param_constant260);  _param_constant260 = None
    view_670 = torch.ops.aten.view.default(_to_copy_302, [128, 2048]);  _to_copy_302 = None
    mm_150 = torch.ops.aten.mm.default(view_670, t_150);  view_670 = t_150 = None
    _unsafe_view_336 = torch.ops.aten._unsafe_view.default(mm_150, [1, 128, 512]);  mm_150 = None
    view_671 = torch.ops.aten.view.default(_unsafe_view_336, [1, 128, -1, 256]);  _unsafe_view_336 = None
    transpose_202 = torch.ops.aten.transpose.int(view_671, 1, 2);  view_671 = None
    unsqueeze_169 = torch.ops.aten.unsqueeze.default(_to_copy_2, 1)
    unsqueeze_170 = torch.ops.aten.unsqueeze.default(_to_copy_3, 1)
    slice_72 = torch.ops.aten.slice.Tensor(transpose_200, 3, 0, 64)
    slice_73 = torch.ops.aten.slice.Tensor(transpose_200, 3, 64, 9223372036854775807);  transpose_200 = None
    slice_74 = torch.ops.aten.slice.Tensor(transpose_201, 3, 0, 64)
    slice_75 = torch.ops.aten.slice.Tensor(transpose_201, 3, 64, 9223372036854775807);  transpose_201 = None
    mul_414 = torch.ops.aten.mul.Tensor(slice_72, unsqueeze_169)
    slice_76 = torch.ops.aten.slice.Tensor(slice_72, 3, 0, 32)
    slice_77 = torch.ops.aten.slice.Tensor(slice_72, 3, 32, 9223372036854775807);  slice_72 = None
    neg_23 = torch.ops.aten.neg.default(slice_77);  slice_77 = None
    cat_18 = torch.ops.aten.cat.default([neg_23, slice_76], -1);  neg_23 = slice_76 = None
    mul_415 = torch.ops.aten.mul.Tensor(cat_18, unsqueeze_170);  cat_18 = None
    add_269 = torch.ops.aten.add.Tensor(mul_414, mul_415);  mul_414 = mul_415 = None
    mul_416 = torch.ops.aten.mul.Tensor(slice_74, unsqueeze_169);  unsqueeze_169 = None
    slice_78 = torch.ops.aten.slice.Tensor(slice_74, 3, 0, 32)
    slice_79 = torch.ops.aten.slice.Tensor(slice_74, 3, 32, 9223372036854775807);  slice_74 = None
    neg_24 = torch.ops.aten.neg.default(slice_79);  slice_79 = None
    cat_19 = torch.ops.aten.cat.default([neg_24, slice_78], -1);  neg_24 = slice_78 = None
    mul_417 = torch.ops.aten.mul.Tensor(cat_19, unsqueeze_170);  cat_19 = unsqueeze_170 = None
    add_270 = torch.ops.aten.add.Tensor(mul_416, mul_417);  mul_416 = mul_417 = None
    cat_20 = torch.ops.aten.cat.default([add_269, slice_73], -1);  add_269 = slice_73 = None
    cat_21 = torch.ops.aten.cat.default([add_270, slice_75], -1);  add_270 = slice_75 = None
    unsqueeze_171 = torch.ops.aten.unsqueeze.default(cat_21, 2);  cat_21 = None
    expand_326 = torch.ops.aten.expand.default(unsqueeze_171, [1, 2, 4, 128, 256]);  unsqueeze_171 = None
    clone_32 = torch.ops.aten.clone.default(expand_326, memory_format = torch.contiguous_format);  expand_326 = None
    _unsafe_view_337 = torch.ops.aten._unsafe_view.default(clone_32, [1, 8, 128, 256]);  clone_32 = None
    unsqueeze_172 = torch.ops.aten.unsqueeze.default(transpose_202, 2);  transpose_202 = None
    expand_327 = torch.ops.aten.expand.default(unsqueeze_172, [1, 2, 4, 128, 256]);  unsqueeze_172 = None
    clone_33 = torch.ops.aten.clone.default(expand_327, memory_format = torch.contiguous_format);  expand_327 = None
    _unsafe_view_338 = torch.ops.aten._unsafe_view.default(clone_33, [1, 8, 128, 256]);  clone_33 = None
    transpose_203 = torch.ops.aten.transpose.int(_unsafe_view_337, 2, 3);  _unsafe_view_337 = None
    expand_328 = torch.ops.aten.expand.default(cat_20, [1, 8, 128, 256]);  cat_20 = None
    view_672 = torch.ops.aten.view.default(expand_328, [8, 128, 256]);  expand_328 = None
    expand_329 = torch.ops.aten.expand.default(transpose_203, [1, 8, 256, 128]);  transpose_203 = None
    view_673 = torch.ops.aten.view.default(expand_329, [8, 256, 128]);  expand_329 = None
    bmm_158 = torch.ops.aten.bmm.default(view_672, view_673);  view_672 = view_673 = None
    _unsafe_view_339 = torch.ops.aten._unsafe_view.default(bmm_158, [1, 8, 128, 128]);  bmm_158 = None
    mul_418 = torch.ops.aten.mul.Tensor(_unsafe_view_339, 0.0625);  _unsafe_view_339 = None
    add_271 = torch.ops.aten.add.Tensor(mul_418, unsqueeze_1);  mul_418 = None
    _to_copy_309 = torch.ops.aten._to_copy.default(add_271, dtype = torch.float32, layout = torch.strided, device = device(type='meta'));  add_271 = None
    _softmax_4 = torch.ops.aten._softmax.default(_to_copy_309, -1, False);  _to_copy_309 = None
    _to_copy_310 = torch.ops.aten._to_copy.default(_softmax_4, dtype = torch.bfloat16);  _softmax_4 = None
    expand_330 = torch.ops.aten.expand.default(_to_copy_310, [1, 8, 128, 128]);  _to_copy_310 = None
    view_674 = torch.ops.aten.view.default(expand_330, [8, 128, 128]);  expand_330 = None
    expand_331 = torch.ops.aten.expand.default(_unsafe_view_338, [1, 8, 128, 256]);  _unsafe_view_338 = None
    view_675 = torch.ops.aten.view.default(expand_331, [8, 128, 256]);  expand_331 = None
    bmm_159 = torch.ops.aten.bmm.default(view_674, view_675);  view_674 = view_675 = None
    _unsafe_view_340 = torch.ops.aten._unsafe_view.default(bmm_159, [1, 8, 128, 256]);  bmm_159 = None
    transpose_204 = torch.ops.aten.transpose.int(_unsafe_view_340, 1, 2);  _unsafe_view_340 = None
    clone_34 = torch.ops.aten.clone.default(transpose_204, memory_format = torch.contiguous_format);  transpose_204 = None
    view_676 = torch.ops.aten.view.default(clone_34, [1, 128, -1]);  clone_34 = None
    sigmoid_19 = torch.ops.aten.sigmoid.default(_unsafe_view_334);  _unsafe_view_334 = None
    mul_419 = torch.ops.aten.mul.Tensor(view_676, sigmoid_19);  view_676 = sigmoid_19 = None
    _param_constant261 = self._param_constant261
    t_151 = torch.ops.aten.t.default(_param_constant261);  _param_constant261 = None
    view_677 = torch.ops.aten.view.default(mul_419, [128, 2048]);  mul_419 = None
    mm_151 = torch.ops.aten.mm.default(view_677, t_151);  view_677 = t_151 = None
    _unsafe_view_341 = torch.ops.aten._unsafe_view.default(mm_151, [1, 128, 2048]);  mm_151 = None
    add_272 = torch.ops.aten.add.Tensor(add_262, _unsafe_view_341);  add_262 = _unsafe_view_341 = None
    _to_copy_311 = torch.ops.aten._to_copy.default(add_272, dtype = torch.float32)
    pow_65 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_311, 2)
    mean_64 = torch.ops.aten.mean.dim(pow_65, [-1], True);  pow_65 = None
    add_273 = torch.ops.aten.add.Tensor(mean_64, 1e-06);  mean_64 = None
    rsqrt_94 = torch.ops.aten.rsqrt.default(add_273);  add_273 = None
    mul_420 = torch.ops.aten.mul.Tensor(_to_copy_311, rsqrt_94);  _to_copy_311 = rsqrt_94 = None
    _param_constant262 = self._param_constant262
    _to_copy_312 = torch.ops.aten._to_copy.default(_param_constant262, dtype = torch.float32);  _param_constant262 = None
    add_274 = torch.ops.aten.add.Tensor(_to_copy_312, 1.0);  _to_copy_312 = None
    mul_421 = torch.ops.aten.mul.Tensor(mul_420, add_274);  mul_420 = add_274 = None
    _to_copy_313 = torch.ops.aten._to_copy.default(mul_421, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_421 = None
    _param_constant263 = self._param_constant263
    t_152 = torch.ops.aten.t.default(_param_constant263);  _param_constant263 = None
    view_678 = torch.ops.aten.view.default(_to_copy_313, [128, 2048])
    mm_152 = torch.ops.aten.mm.default(view_678, t_152);  view_678 = t_152 = None
    _unsafe_view_342 = torch.ops.aten._unsafe_view.default(mm_152, [1, 128, 6144]);  mm_152 = None
    silu_49 = torch.ops.aten.silu.default(_unsafe_view_342);  _unsafe_view_342 = None
    _param_constant264 = self._param_constant264
    t_153 = torch.ops.aten.t.default(_param_constant264);  _param_constant264 = None
    view_679 = torch.ops.aten.view.default(_to_copy_313, [128, 2048]);  _to_copy_313 = None
    mm_153 = torch.ops.aten.mm.default(view_679, t_153);  view_679 = t_153 = None
    _unsafe_view_343 = torch.ops.aten._unsafe_view.default(mm_153, [1, 128, 6144]);  mm_153 = None
    mul_422 = torch.ops.aten.mul.Tensor(silu_49, _unsafe_view_343);  silu_49 = _unsafe_view_343 = None
    _param_constant265 = self._param_constant265
    t_154 = torch.ops.aten.t.default(_param_constant265);  _param_constant265 = None
    view_680 = torch.ops.aten.view.default(mul_422, [128, 6144]);  mul_422 = None
    mm_154 = torch.ops.aten.mm.default(view_680, t_154);  view_680 = t_154 = None
    _unsafe_view_344 = torch.ops.aten._unsafe_view.default(mm_154, [1, 128, 2048]);  mm_154 = None
    add_275 = torch.ops.aten.add.Tensor(add_272, _unsafe_view_344);  add_272 = _unsafe_view_344 = None
    _to_copy_314 = torch.ops.aten._to_copy.default(add_275, dtype = torch.float32)
    pow_66 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_314, 2)
    mean_65 = torch.ops.aten.mean.dim(pow_66, [-1], True);  pow_66 = None
    add_276 = torch.ops.aten.add.Tensor(mean_65, 1e-06);  mean_65 = None
    rsqrt_95 = torch.ops.aten.rsqrt.default(add_276);  add_276 = None
    mul_423 = torch.ops.aten.mul.Tensor(_to_copy_314, rsqrt_95);  _to_copy_314 = rsqrt_95 = None
    _param_constant266 = self._param_constant266
    _to_copy_315 = torch.ops.aten._to_copy.default(_param_constant266, dtype = torch.float32);  _param_constant266 = None
    add_277 = torch.ops.aten.add.Tensor(_to_copy_315, 1.0);  _to_copy_315 = None
    mul_424 = torch.ops.aten.mul.Tensor(mul_423, add_277);  mul_423 = add_277 = None
    _to_copy_316 = torch.ops.aten._to_copy.default(mul_424, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_424 = None
    _param_constant267 = self._param_constant267
    t_155 = torch.ops.aten.t.default(_param_constant267);  _param_constant267 = None
    view_681 = torch.ops.aten.view.default(_to_copy_316, [128, 2048])
    mm_155 = torch.ops.aten.mm.default(view_681, t_155);  view_681 = t_155 = None
    _unsafe_view_345 = torch.ops.aten._unsafe_view.default(mm_155, [1, 128, 6144]);  mm_155 = None
    transpose_205 = torch.ops.aten.transpose.int(_unsafe_view_345, 1, 2);  _unsafe_view_345 = None
    _param_constant268 = self._param_constant268
    t_156 = torch.ops.aten.t.default(_param_constant268);  _param_constant268 = None
    view_682 = torch.ops.aten.view.default(_to_copy_316, [128, 2048])
    mm_156 = torch.ops.aten.mm.default(view_682, t_156);  view_682 = t_156 = None
    _unsafe_view_346 = torch.ops.aten._unsafe_view.default(mm_156, [1, 128, 2048]);  mm_156 = None
    view_683 = torch.ops.aten.view.default(_unsafe_view_346, [1, 128, -1, 128]);  _unsafe_view_346 = None
    _param_constant269 = self._param_constant269
    t_157 = torch.ops.aten.t.default(_param_constant269);  _param_constant269 = None
    view_684 = torch.ops.aten.view.default(_to_copy_316, [128, 2048])
    mm_157 = torch.ops.aten.mm.default(view_684, t_157);  view_684 = t_157 = None
    _unsafe_view_347 = torch.ops.aten._unsafe_view.default(mm_157, [1, 128, 16]);  mm_157 = None
    _param_constant270 = self._param_constant270
    t_158 = torch.ops.aten.t.default(_param_constant270);  _param_constant270 = None
    view_685 = torch.ops.aten.view.default(_to_copy_316, [128, 2048]);  _to_copy_316 = None
    mm_158 = torch.ops.aten.mm.default(view_685, t_158);  view_685 = t_158 = None
    _unsafe_view_348 = torch.ops.aten._unsafe_view.default(mm_158, [1, 128, 16]);  mm_158 = None
    _param_constant271 = self._param_constant271
    squeeze_15 = torch.ops.aten.squeeze.dim(_param_constant271, 1);  _param_constant271 = None
    unsqueeze_173 = torch.ops.aten.unsqueeze.default(squeeze_15, 1);  squeeze_15 = None
    convolution_15 = torch.ops.aten.convolution.default(transpose_205, unsqueeze_173, None, [1], [3], [1], False, [0], 6144);  transpose_205 = unsqueeze_173 = None
    slice_80 = torch.ops.aten.slice.Tensor(convolution_15, 2, 0, 128);  convolution_15 = None
    silu_50 = torch.ops.aten.silu.default(slice_80);  slice_80 = None
    transpose_206 = torch.ops.aten.transpose.int(silu_50, 1, 2);  silu_50 = None
    split_with_sizes_15 = torch.ops.aten.split_with_sizes.default(transpose_206, [2048, 2048, 2048], -1);  transpose_206 = None
    getitem_55 = split_with_sizes_15[0]
    getitem_56 = split_with_sizes_15[1]
    getitem_57 = split_with_sizes_15[2];  split_with_sizes_15 = None
    view_686 = torch.ops.aten.view.default(getitem_55, [1, 128, 16, 128]);  getitem_55 = None
    view_687 = torch.ops.aten.view.default(getitem_56, [1, 128, 16, 128]);  getitem_56 = None
    view_688 = torch.ops.aten.view.default(getitem_57, [1, 128, 16, 128]);  getitem_57 = None
    sigmoid_20 = torch.ops.aten.sigmoid.default(_unsafe_view_347);  _unsafe_view_347 = None
    _param_constant272 = self._param_constant272
    exp_90 = torch.ops.aten.exp.default(_param_constant272);  _param_constant272 = None
    neg_25 = torch.ops.aten.neg.default(exp_90);  exp_90 = None
    _to_copy_317 = torch.ops.aten._to_copy.default(_unsafe_view_348, dtype = torch.float32);  _unsafe_view_348 = None
    _param_constant273 = self._param_constant273
    add_278 = torch.ops.aten.add.Tensor(_to_copy_317, _param_constant273);  _to_copy_317 = _param_constant273 = None
    softplus_15 = torch.ops.aten.softplus.default(add_278);  add_278 = None
    mul_425 = torch.ops.aten.mul.Tensor(neg_25, softplus_15);  neg_25 = softplus_15 = None
    transpose_207 = torch.ops.aten.transpose.int(view_686, 1, 2);  view_686 = None
    _to_copy_318 = torch.ops.aten._to_copy.default(transpose_207, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_207 = None
    transpose_208 = torch.ops.aten.transpose.int(view_687, 1, 2);  view_687 = None
    _to_copy_319 = torch.ops.aten._to_copy.default(transpose_208, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_208 = None
    transpose_209 = torch.ops.aten.transpose.int(view_688, 1, 2);  view_688 = None
    _to_copy_320 = torch.ops.aten._to_copy.default(transpose_209, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_209 = None
    transpose_210 = torch.ops.aten.transpose.int(sigmoid_20, 1, 2);  sigmoid_20 = None
    _to_copy_321 = torch.ops.aten._to_copy.default(transpose_210, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_210 = None
    transpose_211 = torch.ops.aten.transpose.int(mul_425, 1, 2);  mul_425 = None
    mul_426 = torch.ops.aten.mul.Tensor(_to_copy_318, _to_copy_318)
    sum_31 = torch.ops.aten.sum.dim_IntList(mul_426, [-1], True);  mul_426 = None
    add_279 = torch.ops.aten.add.Tensor(sum_31, 1e-06);  sum_31 = None
    rsqrt_96 = torch.ops.aten.rsqrt.default(add_279);  add_279 = None
    mul_427 = torch.ops.aten.mul.Tensor(_to_copy_318, rsqrt_96);  _to_copy_318 = rsqrt_96 = None
    mul_428 = torch.ops.aten.mul.Tensor(_to_copy_319, _to_copy_319)
    sum_32 = torch.ops.aten.sum.dim_IntList(mul_428, [-1], True);  mul_428 = None
    add_280 = torch.ops.aten.add.Tensor(sum_32, 1e-06);  sum_32 = None
    rsqrt_97 = torch.ops.aten.rsqrt.default(add_280);  add_280 = None
    mul_429 = torch.ops.aten.mul.Tensor(_to_copy_319, rsqrt_97);  _to_copy_319 = rsqrt_97 = None
    mul_430 = torch.ops.aten.mul.Tensor(mul_427, 0.08838834764831845);  mul_427 = None
    constant_pad_nd_75 = torch.ops.aten.constant_pad_nd.default(mul_430, [0, 0, 0, 0], 0.0);  mul_430 = None
    constant_pad_nd_76 = torch.ops.aten.constant_pad_nd.default(mul_429, [0, 0, 0, 0], 0.0);  mul_429 = None
    constant_pad_nd_77 = torch.ops.aten.constant_pad_nd.default(_to_copy_320, [0, 0, 0, 0], 0.0);  _to_copy_320 = None
    constant_pad_nd_78 = torch.ops.aten.constant_pad_nd.default(_to_copy_321, [0, 0], 0.0);  _to_copy_321 = None
    constant_pad_nd_79 = torch.ops.aten.constant_pad_nd.default(transpose_211, [0, 0], 0.0);  transpose_211 = None
    unsqueeze_174 = torch.ops.aten.unsqueeze.default(constant_pad_nd_78, -1)
    mul_431 = torch.ops.aten.mul.Tensor(constant_pad_nd_77, unsqueeze_174);  constant_pad_nd_77 = unsqueeze_174 = None
    unsqueeze_175 = torch.ops.aten.unsqueeze.default(constant_pad_nd_78, -1);  constant_pad_nd_78 = None
    mul_432 = torch.ops.aten.mul.Tensor(constant_pad_nd_76, unsqueeze_175);  unsqueeze_175 = None
    view_689 = torch.ops.aten.view.default(constant_pad_nd_75, [1, 16, -1, 64, 128]);  constant_pad_nd_75 = None
    view_690 = torch.ops.aten.view.default(constant_pad_nd_76, [1, 16, -1, 64, 128]);  constant_pad_nd_76 = None
    view_691 = torch.ops.aten.view.default(mul_432, [1, 16, -1, 64, 128]);  mul_432 = None
    view_692 = torch.ops.aten.view.default(mul_431, [1, 16, -1, 64, 128]);  mul_431 = None
    view_693 = torch.ops.aten.view.default(constant_pad_nd_79, [1, 16, 2, 64]);  constant_pad_nd_79 = None
    ones_15 = torch.ops.aten.ones.default([64, 64], dtype = torch.bool, device = device(type='meta'), pin_memory = False)
    triu_16 = torch.ops.aten.triu.default(ones_15, 1);  ones_15 = None
    cumsum_15 = torch.ops.aten.cumsum.default(view_693, 3);  view_693 = None
    unsqueeze_176 = torch.ops.aten.unsqueeze.default(cumsum_15, 4)
    unsqueeze_177 = torch.ops.aten.unsqueeze.default(cumsum_15, 3)
    sub_60 = torch.ops.aten.sub.Tensor(unsqueeze_176, unsqueeze_177);  unsqueeze_176 = unsqueeze_177 = None
    masked_fill_15 = torch.ops.aten.masked_fill.Scalar(sub_60, triu_16, -inf);  sub_60 = triu_16 = None
    exp_91 = torch.ops.aten.exp.default(masked_fill_15);  masked_fill_15 = None
    transpose_212 = torch.ops.aten.transpose.int(view_690, -1, -2)
    expand_332 = torch.ops.aten.expand.default(view_691, [1, 16, 2, 64, 128])
    view_694 = torch.ops.aten.view.default(expand_332, [32, 64, 128]);  expand_332 = None
    expand_333 = torch.ops.aten.expand.default(transpose_212, [1, 16, 2, 128, 64]);  transpose_212 = None
    view_695 = torch.ops.aten.view.default(expand_333, [32, 128, 64]);  expand_333 = None
    bmm_160 = torch.ops.aten.bmm.default(view_694, view_695);  view_694 = view_695 = None
    _unsafe_view_349 = torch.ops.aten._unsafe_view.default(bmm_160, [1, 16, 2, 64, 64]);  bmm_160 = None
    mul_433 = torch.ops.aten.mul.Tensor(_unsafe_view_349, exp_91);  _unsafe_view_349 = None
    transpose_213 = torch.ops.aten.transpose.int(view_690, -1, -2)
    expand_334 = torch.ops.aten.expand.default(view_689, [1, 16, 2, 64, 128])
    view_696 = torch.ops.aten.view.default(expand_334, [32, 64, 128]);  expand_334 = None
    expand_335 = torch.ops.aten.expand.default(transpose_213, [1, 16, 2, 128, 64]);  transpose_213 = None
    view_697 = torch.ops.aten.view.default(expand_335, [32, 128, 64]);  expand_335 = None
    bmm_161 = torch.ops.aten.bmm.default(view_696, view_697);  view_696 = view_697 = None
    _unsafe_view_350 = torch.ops.aten._unsafe_view.default(bmm_161, [1, 16, 2, 64, 64]);  bmm_161 = None
    mul_434 = torch.ops.aten.mul.Tensor(_unsafe_view_350, exp_91);  _unsafe_view_350 = exp_91 = None
    exp_92 = torch.ops.aten.exp.default(cumsum_15)
    unsqueeze_178 = torch.ops.aten.unsqueeze.default(exp_92, -1);  exp_92 = None
    mul_435 = torch.ops.aten.mul.Tensor(view_691, unsqueeze_178);  view_691 = unsqueeze_178 = None
    linalg_solve_triangular_30 = torch.ops.aten.linalg_solve_triangular.default(mul_433, view_692, upper = False, unitriangular = True);  view_692 = None
    linalg_solve_triangular_31 = torch.ops.aten.linalg_solve_triangular.default(mul_433, mul_435, upper = False, unitriangular = True);  mul_433 = mul_435 = None
    zeros_15 = torch.ops.aten.zeros.default([1, 16, 128, 128], dtype = torch.float32, device = device(type='meta'), pin_memory = False)
    zeros_like_15 = torch.ops.aten.zeros_like.default(linalg_solve_triangular_30, pin_memory = False)
    exp_93 = torch.ops.aten.exp.default(cumsum_15)
    unsqueeze_179 = torch.ops.aten.unsqueeze.default(exp_93, -1);  exp_93 = None
    mul_436 = torch.ops.aten.mul.Tensor(view_689, unsqueeze_179);  view_689 = unsqueeze_179 = None
    slice_81 = torch.ops.aten.slice.Tensor(cumsum_15, 3, -1, 9223372036854775807)
    sub_61 = torch.ops.aten.sub.Tensor(slice_81, cumsum_15);  slice_81 = None
    exp_94 = torch.ops.aten.exp.default(sub_61);  sub_61 = None
    unsqueeze_180 = torch.ops.aten.unsqueeze.default(exp_94, -1);  exp_94 = None
    mul_437 = torch.ops.aten.mul.Tensor(view_690, unsqueeze_180);  view_690 = unsqueeze_180 = None
    select_232 = torch.ops.aten.select.int(cumsum_15, 3, -1);  cumsum_15 = None
    exp_95 = torch.ops.aten.exp.default(select_232);  select_232 = None
    unsqueeze_181 = torch.ops.aten.unsqueeze.default(exp_95, 3);  exp_95 = None
    unsqueeze_182 = torch.ops.aten.unsqueeze.default(unsqueeze_181, 4);  unsqueeze_181 = None
    select_233 = torch.ops.aten.select.int(linalg_solve_triangular_30, 2, 0)
    select_234 = torch.ops.aten.select.int(linalg_solve_triangular_31, 2, 0)
    expand_336 = torch.ops.aten.expand.default(select_234, [1, 16, 64, 128]);  select_234 = None
    view_698 = torch.ops.aten.view.default(expand_336, [16, 64, 128]);  expand_336 = None
    expand_337 = torch.ops.aten.expand.default(zeros_15, [1, 16, 128, 128])
    view_699 = torch.ops.aten.view.default(expand_337, [16, 128, 128]);  expand_337 = None
    bmm_162 = torch.ops.aten.bmm.default(view_698, view_699);  view_698 = view_699 = None
    _unsafe_view_351 = torch.ops.aten._unsafe_view.default(bmm_162, [1, 16, 64, 128]);  bmm_162 = None
    sub_62 = torch.ops.aten.sub.Tensor(select_233, _unsafe_view_351);  select_233 = _unsafe_view_351 = None
    select_235 = torch.ops.aten.select.int(mul_436, 2, 0)
    expand_338 = torch.ops.aten.expand.default(select_235, [1, 16, 64, 128]);  select_235 = None
    view_700 = torch.ops.aten.view.default(expand_338, [16, 64, 128]);  expand_338 = None
    expand_339 = torch.ops.aten.expand.default(zeros_15, [1, 16, 128, 128])
    view_701 = torch.ops.aten.view.default(expand_339, [16, 128, 128]);  expand_339 = None
    bmm_163 = torch.ops.aten.bmm.default(view_700, view_701);  view_700 = view_701 = None
    _unsafe_view_352 = torch.ops.aten._unsafe_view.default(bmm_163, [1, 16, 64, 128]);  bmm_163 = None
    select_236 = torch.ops.aten.select.int(mul_434, 2, 0)
    expand_340 = torch.ops.aten.expand.default(select_236, [1, 16, 64, 64]);  select_236 = None
    view_702 = torch.ops.aten.view.default(expand_340, [16, 64, 64]);  expand_340 = None
    expand_341 = torch.ops.aten.expand.default(sub_62, [1, 16, 64, 128])
    view_703 = torch.ops.aten.view.default(expand_341, [16, 64, 128]);  expand_341 = None
    bmm_164 = torch.ops.aten.bmm.default(view_702, view_703);  view_702 = view_703 = None
    _unsafe_view_353 = torch.ops.aten._unsafe_view.default(bmm_164, [1, 16, 64, 128]);  bmm_164 = None
    add_281 = torch.ops.aten.add.Tensor(_unsafe_view_352, _unsafe_view_353);  _unsafe_view_352 = _unsafe_view_353 = None
    select_237 = torch.ops.aten.select.int(zeros_like_15, 2, 0)
    copy__34 = torch.ops.aten.copy_.default(select_237, add_281);  select_237 = add_281 = copy__34 = None
    select_238 = torch.ops.aten.select.int(unsqueeze_182, 2, 0)
    mul_438 = torch.ops.aten.mul.Tensor(zeros_15, select_238);  zeros_15 = select_238 = None
    select_239 = torch.ops.aten.select.int(mul_437, 2, 0)
    transpose_214 = torch.ops.aten.transpose.int(select_239, -1, -2);  select_239 = None
    expand_342 = torch.ops.aten.expand.default(transpose_214, [1, 16, 128, 64]);  transpose_214 = None
    view_704 = torch.ops.aten.view.default(expand_342, [16, 128, 64]);  expand_342 = None
    expand_343 = torch.ops.aten.expand.default(sub_62, [1, 16, 64, 128]);  sub_62 = None
    view_705 = torch.ops.aten.view.default(expand_343, [16, 64, 128]);  expand_343 = None
    bmm_165 = torch.ops.aten.bmm.default(view_704, view_705);  view_704 = view_705 = None
    _unsafe_view_354 = torch.ops.aten._unsafe_view.default(bmm_165, [1, 16, 128, 128]);  bmm_165 = None
    add_282 = torch.ops.aten.add.Tensor(mul_438, _unsafe_view_354);  mul_438 = _unsafe_view_354 = None
    select_240 = torch.ops.aten.select.int(linalg_solve_triangular_30, 2, 1);  linalg_solve_triangular_30 = None
    select_241 = torch.ops.aten.select.int(linalg_solve_triangular_31, 2, 1);  linalg_solve_triangular_31 = None
    expand_344 = torch.ops.aten.expand.default(select_241, [1, 16, 64, 128]);  select_241 = None
    view_706 = torch.ops.aten.view.default(expand_344, [16, 64, 128]);  expand_344 = None
    expand_345 = torch.ops.aten.expand.default(add_282, [1, 16, 128, 128])
    view_707 = torch.ops.aten.view.default(expand_345, [16, 128, 128]);  expand_345 = None
    bmm_166 = torch.ops.aten.bmm.default(view_706, view_707);  view_706 = view_707 = None
    _unsafe_view_355 = torch.ops.aten._unsafe_view.default(bmm_166, [1, 16, 64, 128]);  bmm_166 = None
    sub_63 = torch.ops.aten.sub.Tensor(select_240, _unsafe_view_355);  select_240 = _unsafe_view_355 = None
    select_242 = torch.ops.aten.select.int(mul_436, 2, 1);  mul_436 = None
    expand_346 = torch.ops.aten.expand.default(select_242, [1, 16, 64, 128]);  select_242 = None
    view_708 = torch.ops.aten.view.default(expand_346, [16, 64, 128]);  expand_346 = None
    expand_347 = torch.ops.aten.expand.default(add_282, [1, 16, 128, 128])
    view_709 = torch.ops.aten.view.default(expand_347, [16, 128, 128]);  expand_347 = None
    bmm_167 = torch.ops.aten.bmm.default(view_708, view_709);  view_708 = view_709 = None
    _unsafe_view_356 = torch.ops.aten._unsafe_view.default(bmm_167, [1, 16, 64, 128]);  bmm_167 = None
    select_243 = torch.ops.aten.select.int(mul_434, 2, 1);  mul_434 = None
    expand_348 = torch.ops.aten.expand.default(select_243, [1, 16, 64, 64]);  select_243 = None
    view_710 = torch.ops.aten.view.default(expand_348, [16, 64, 64]);  expand_348 = None
    expand_349 = torch.ops.aten.expand.default(sub_63, [1, 16, 64, 128])
    view_711 = torch.ops.aten.view.default(expand_349, [16, 64, 128]);  expand_349 = None
    bmm_168 = torch.ops.aten.bmm.default(view_710, view_711);  view_710 = view_711 = None
    _unsafe_view_357 = torch.ops.aten._unsafe_view.default(bmm_168, [1, 16, 64, 128]);  bmm_168 = None
    add_283 = torch.ops.aten.add.Tensor(_unsafe_view_356, _unsafe_view_357);  _unsafe_view_356 = _unsafe_view_357 = None
    select_244 = torch.ops.aten.select.int(zeros_like_15, 2, 1)
    copy__35 = torch.ops.aten.copy_.default(select_244, add_283);  select_244 = add_283 = copy__35 = None
    select_245 = torch.ops.aten.select.int(unsqueeze_182, 2, 1);  unsqueeze_182 = None
    mul_439 = torch.ops.aten.mul.Tensor(add_282, select_245);  add_282 = select_245 = None
    select_246 = torch.ops.aten.select.int(mul_437, 2, 1);  mul_437 = None
    transpose_215 = torch.ops.aten.transpose.int(select_246, -1, -2);  select_246 = None
    expand_350 = torch.ops.aten.expand.default(transpose_215, [1, 16, 128, 64]);  transpose_215 = None
    view_712 = torch.ops.aten.view.default(expand_350, [16, 128, 64]);  expand_350 = None
    expand_351 = torch.ops.aten.expand.default(sub_63, [1, 16, 64, 128]);  sub_63 = None
    view_713 = torch.ops.aten.view.default(expand_351, [16, 64, 128]);  expand_351 = None
    bmm_169 = torch.ops.aten.bmm.default(view_712, view_713);  view_712 = view_713 = None
    _unsafe_view_358 = torch.ops.aten._unsafe_view.default(bmm_169, [1, 16, 128, 128]);  bmm_169 = None
    add_284 = torch.ops.aten.add.Tensor(mul_439, _unsafe_view_358);  mul_439 = _unsafe_view_358 = add_284 = None
    clone_35 = torch.ops.aten.clone.default(zeros_like_15, memory_format = torch.contiguous_format);  zeros_like_15 = None
    _unsafe_view_359 = torch.ops.aten._unsafe_view.default(clone_35, [1, 16, 128, 128]);  clone_35 = None
    alias_15 = torch.ops.aten.alias.default(_unsafe_view_359);  _unsafe_view_359 = None
    transpose_216 = torch.ops.aten.transpose.int(alias_15, 1, 2);  alias_15 = None
    _to_copy_322 = torch.ops.aten._to_copy.default(transpose_216, dtype = torch.bfloat16, memory_format = torch.contiguous_format);  transpose_216 = None
    view_714 = torch.ops.aten.view.default(_to_copy_322, [-1, 128]);  _to_copy_322 = None
    view_715 = torch.ops.aten.view.default(view_683, [-1, 128]);  view_683 = None
    _to_copy_323 = torch.ops.aten._to_copy.default(view_714, dtype = torch.float32);  view_714 = None
    pow_67 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_323, 2)
    mean_66 = torch.ops.aten.mean.dim(pow_67, [-1], True);  pow_67 = None
    add_285 = torch.ops.aten.add.Tensor(mean_66, 1e-06);  mean_66 = None
    rsqrt_98 = torch.ops.aten.rsqrt.default(add_285);  add_285 = None
    mul_440 = torch.ops.aten.mul.Tensor(_to_copy_323, rsqrt_98);  _to_copy_323 = rsqrt_98 = None
    _to_copy_324 = torch.ops.aten._to_copy.default(mul_440, dtype = torch.bfloat16);  mul_440 = None
    _param_constant274 = self._param_constant274
    mul_441 = torch.ops.aten.mul.Tensor(_param_constant274, _to_copy_324);  _param_constant274 = _to_copy_324 = None
    _to_copy_325 = torch.ops.aten._to_copy.default(view_715, dtype = torch.float32);  view_715 = None
    silu_51 = torch.ops.aten.silu.default(_to_copy_325);  _to_copy_325 = None
    mul_442 = torch.ops.aten.mul.Tensor(mul_441, silu_51);  mul_441 = silu_51 = None
    _to_copy_326 = torch.ops.aten._to_copy.default(mul_442, dtype = torch.bfloat16);  mul_442 = None
    view_716 = torch.ops.aten.view.default(_to_copy_326, [1, 128, -1]);  _to_copy_326 = None
    _param_constant275 = self._param_constant275
    t_159 = torch.ops.aten.t.default(_param_constant275);  _param_constant275 = None
    view_717 = torch.ops.aten.view.default(view_716, [128, 2048]);  view_716 = None
    mm_159 = torch.ops.aten.mm.default(view_717, t_159);  view_717 = t_159 = None
    _unsafe_view_360 = torch.ops.aten._unsafe_view.default(mm_159, [1, 128, 2048]);  mm_159 = None
    add_286 = torch.ops.aten.add.Tensor(add_275, _unsafe_view_360);  add_275 = _unsafe_view_360 = None
    _to_copy_327 = torch.ops.aten._to_copy.default(add_286, dtype = torch.float32)
    pow_68 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_327, 2)
    mean_67 = torch.ops.aten.mean.dim(pow_68, [-1], True);  pow_68 = None
    add_287 = torch.ops.aten.add.Tensor(mean_67, 1e-06);  mean_67 = None
    rsqrt_99 = torch.ops.aten.rsqrt.default(add_287);  add_287 = None
    mul_443 = torch.ops.aten.mul.Tensor(_to_copy_327, rsqrt_99);  _to_copy_327 = rsqrt_99 = None
    _param_constant276 = self._param_constant276
    _to_copy_328 = torch.ops.aten._to_copy.default(_param_constant276, dtype = torch.float32);  _param_constant276 = None
    add_288 = torch.ops.aten.add.Tensor(_to_copy_328, 1.0);  _to_copy_328 = None
    mul_444 = torch.ops.aten.mul.Tensor(mul_443, add_288);  mul_443 = add_288 = None
    _to_copy_329 = torch.ops.aten._to_copy.default(mul_444, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_444 = None
    _param_constant277 = self._param_constant277
    t_160 = torch.ops.aten.t.default(_param_constant277);  _param_constant277 = None
    view_718 = torch.ops.aten.view.default(_to_copy_329, [128, 2048])
    mm_160 = torch.ops.aten.mm.default(view_718, t_160);  view_718 = t_160 = None
    _unsafe_view_361 = torch.ops.aten._unsafe_view.default(mm_160, [1, 128, 6144]);  mm_160 = None
    silu_52 = torch.ops.aten.silu.default(_unsafe_view_361);  _unsafe_view_361 = None
    _param_constant278 = self._param_constant278
    t_161 = torch.ops.aten.t.default(_param_constant278);  _param_constant278 = None
    view_719 = torch.ops.aten.view.default(_to_copy_329, [128, 2048]);  _to_copy_329 = None
    mm_161 = torch.ops.aten.mm.default(view_719, t_161);  view_719 = t_161 = None
    _unsafe_view_362 = torch.ops.aten._unsafe_view.default(mm_161, [1, 128, 6144]);  mm_161 = None
    mul_445 = torch.ops.aten.mul.Tensor(silu_52, _unsafe_view_362);  silu_52 = _unsafe_view_362 = None
    _param_constant279 = self._param_constant279
    t_162 = torch.ops.aten.t.default(_param_constant279);  _param_constant279 = None
    view_720 = torch.ops.aten.view.default(mul_445, [128, 6144]);  mul_445 = None
    mm_162 = torch.ops.aten.mm.default(view_720, t_162);  view_720 = t_162 = None
    _unsafe_view_363 = torch.ops.aten._unsafe_view.default(mm_162, [1, 128, 2048]);  mm_162 = None
    add_289 = torch.ops.aten.add.Tensor(add_286, _unsafe_view_363);  add_286 = _unsafe_view_363 = None
    _to_copy_330 = torch.ops.aten._to_copy.default(add_289, dtype = torch.float32)
    pow_69 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_330, 2)
    mean_68 = torch.ops.aten.mean.dim(pow_69, [-1], True);  pow_69 = None
    add_290 = torch.ops.aten.add.Tensor(mean_68, 1e-06);  mean_68 = None
    rsqrt_100 = torch.ops.aten.rsqrt.default(add_290);  add_290 = None
    mul_446 = torch.ops.aten.mul.Tensor(_to_copy_330, rsqrt_100);  _to_copy_330 = rsqrt_100 = None
    _param_constant280 = self._param_constant280
    _to_copy_331 = torch.ops.aten._to_copy.default(_param_constant280, dtype = torch.float32);  _param_constant280 = None
    add_291 = torch.ops.aten.add.Tensor(_to_copy_331, 1.0);  _to_copy_331 = None
    mul_447 = torch.ops.aten.mul.Tensor(mul_446, add_291);  mul_446 = add_291 = None
    _to_copy_332 = torch.ops.aten._to_copy.default(mul_447, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_447 = None
    _param_constant281 = self._param_constant281
    t_163 = torch.ops.aten.t.default(_param_constant281);  _param_constant281 = None
    view_721 = torch.ops.aten.view.default(_to_copy_332, [128, 2048])
    mm_163 = torch.ops.aten.mm.default(view_721, t_163);  view_721 = t_163 = None
    _unsafe_view_364 = torch.ops.aten._unsafe_view.default(mm_163, [1, 128, 6144]);  mm_163 = None
    transpose_217 = torch.ops.aten.transpose.int(_unsafe_view_364, 1, 2);  _unsafe_view_364 = None
    _param_constant282 = self._param_constant282
    t_164 = torch.ops.aten.t.default(_param_constant282);  _param_constant282 = None
    view_722 = torch.ops.aten.view.default(_to_copy_332, [128, 2048])
    mm_164 = torch.ops.aten.mm.default(view_722, t_164);  view_722 = t_164 = None
    _unsafe_view_365 = torch.ops.aten._unsafe_view.default(mm_164, [1, 128, 2048]);  mm_164 = None
    view_723 = torch.ops.aten.view.default(_unsafe_view_365, [1, 128, -1, 128]);  _unsafe_view_365 = None
    _param_constant283 = self._param_constant283
    t_165 = torch.ops.aten.t.default(_param_constant283);  _param_constant283 = None
    view_724 = torch.ops.aten.view.default(_to_copy_332, [128, 2048])
    mm_165 = torch.ops.aten.mm.default(view_724, t_165);  view_724 = t_165 = None
    _unsafe_view_366 = torch.ops.aten._unsafe_view.default(mm_165, [1, 128, 16]);  mm_165 = None
    _param_constant284 = self._param_constant284
    t_166 = torch.ops.aten.t.default(_param_constant284);  _param_constant284 = None
    view_725 = torch.ops.aten.view.default(_to_copy_332, [128, 2048]);  _to_copy_332 = None
    mm_166 = torch.ops.aten.mm.default(view_725, t_166);  view_725 = t_166 = None
    _unsafe_view_367 = torch.ops.aten._unsafe_view.default(mm_166, [1, 128, 16]);  mm_166 = None
    _param_constant285 = self._param_constant285
    squeeze_16 = torch.ops.aten.squeeze.dim(_param_constant285, 1);  _param_constant285 = None
    unsqueeze_183 = torch.ops.aten.unsqueeze.default(squeeze_16, 1);  squeeze_16 = None
    convolution_16 = torch.ops.aten.convolution.default(transpose_217, unsqueeze_183, None, [1], [3], [1], False, [0], 6144);  transpose_217 = unsqueeze_183 = None
    slice_82 = torch.ops.aten.slice.Tensor(convolution_16, 2, 0, 128);  convolution_16 = None
    silu_53 = torch.ops.aten.silu.default(slice_82);  slice_82 = None
    transpose_218 = torch.ops.aten.transpose.int(silu_53, 1, 2);  silu_53 = None
    split_with_sizes_16 = torch.ops.aten.split_with_sizes.default(transpose_218, [2048, 2048, 2048], -1);  transpose_218 = None
    getitem_58 = split_with_sizes_16[0]
    getitem_59 = split_with_sizes_16[1]
    getitem_60 = split_with_sizes_16[2];  split_with_sizes_16 = None
    view_726 = torch.ops.aten.view.default(getitem_58, [1, 128, 16, 128]);  getitem_58 = None
    view_727 = torch.ops.aten.view.default(getitem_59, [1, 128, 16, 128]);  getitem_59 = None
    view_728 = torch.ops.aten.view.default(getitem_60, [1, 128, 16, 128]);  getitem_60 = None
    sigmoid_21 = torch.ops.aten.sigmoid.default(_unsafe_view_366);  _unsafe_view_366 = None
    _param_constant286 = self._param_constant286
    exp_96 = torch.ops.aten.exp.default(_param_constant286);  _param_constant286 = None
    neg_26 = torch.ops.aten.neg.default(exp_96);  exp_96 = None
    _to_copy_333 = torch.ops.aten._to_copy.default(_unsafe_view_367, dtype = torch.float32);  _unsafe_view_367 = None
    _param_constant287 = self._param_constant287
    add_292 = torch.ops.aten.add.Tensor(_to_copy_333, _param_constant287);  _to_copy_333 = _param_constant287 = None
    softplus_16 = torch.ops.aten.softplus.default(add_292);  add_292 = None
    mul_448 = torch.ops.aten.mul.Tensor(neg_26, softplus_16);  neg_26 = softplus_16 = None
    transpose_219 = torch.ops.aten.transpose.int(view_726, 1, 2);  view_726 = None
    _to_copy_334 = torch.ops.aten._to_copy.default(transpose_219, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_219 = None
    transpose_220 = torch.ops.aten.transpose.int(view_727, 1, 2);  view_727 = None
    _to_copy_335 = torch.ops.aten._to_copy.default(transpose_220, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_220 = None
    transpose_221 = torch.ops.aten.transpose.int(view_728, 1, 2);  view_728 = None
    _to_copy_336 = torch.ops.aten._to_copy.default(transpose_221, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_221 = None
    transpose_222 = torch.ops.aten.transpose.int(sigmoid_21, 1, 2);  sigmoid_21 = None
    _to_copy_337 = torch.ops.aten._to_copy.default(transpose_222, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_222 = None
    transpose_223 = torch.ops.aten.transpose.int(mul_448, 1, 2);  mul_448 = None
    mul_449 = torch.ops.aten.mul.Tensor(_to_copy_334, _to_copy_334)
    sum_33 = torch.ops.aten.sum.dim_IntList(mul_449, [-1], True);  mul_449 = None
    add_293 = torch.ops.aten.add.Tensor(sum_33, 1e-06);  sum_33 = None
    rsqrt_101 = torch.ops.aten.rsqrt.default(add_293);  add_293 = None
    mul_450 = torch.ops.aten.mul.Tensor(_to_copy_334, rsqrt_101);  _to_copy_334 = rsqrt_101 = None
    mul_451 = torch.ops.aten.mul.Tensor(_to_copy_335, _to_copy_335)
    sum_34 = torch.ops.aten.sum.dim_IntList(mul_451, [-1], True);  mul_451 = None
    add_294 = torch.ops.aten.add.Tensor(sum_34, 1e-06);  sum_34 = None
    rsqrt_102 = torch.ops.aten.rsqrt.default(add_294);  add_294 = None
    mul_452 = torch.ops.aten.mul.Tensor(_to_copy_335, rsqrt_102);  _to_copy_335 = rsqrt_102 = None
    mul_453 = torch.ops.aten.mul.Tensor(mul_450, 0.08838834764831845);  mul_450 = None
    constant_pad_nd_80 = torch.ops.aten.constant_pad_nd.default(mul_453, [0, 0, 0, 0], 0.0);  mul_453 = None
    constant_pad_nd_81 = torch.ops.aten.constant_pad_nd.default(mul_452, [0, 0, 0, 0], 0.0);  mul_452 = None
    constant_pad_nd_82 = torch.ops.aten.constant_pad_nd.default(_to_copy_336, [0, 0, 0, 0], 0.0);  _to_copy_336 = None
    constant_pad_nd_83 = torch.ops.aten.constant_pad_nd.default(_to_copy_337, [0, 0], 0.0);  _to_copy_337 = None
    constant_pad_nd_84 = torch.ops.aten.constant_pad_nd.default(transpose_223, [0, 0], 0.0);  transpose_223 = None
    unsqueeze_184 = torch.ops.aten.unsqueeze.default(constant_pad_nd_83, -1)
    mul_454 = torch.ops.aten.mul.Tensor(constant_pad_nd_82, unsqueeze_184);  constant_pad_nd_82 = unsqueeze_184 = None
    unsqueeze_185 = torch.ops.aten.unsqueeze.default(constant_pad_nd_83, -1);  constant_pad_nd_83 = None
    mul_455 = torch.ops.aten.mul.Tensor(constant_pad_nd_81, unsqueeze_185);  unsqueeze_185 = None
    view_729 = torch.ops.aten.view.default(constant_pad_nd_80, [1, 16, -1, 64, 128]);  constant_pad_nd_80 = None
    view_730 = torch.ops.aten.view.default(constant_pad_nd_81, [1, 16, -1, 64, 128]);  constant_pad_nd_81 = None
    view_731 = torch.ops.aten.view.default(mul_455, [1, 16, -1, 64, 128]);  mul_455 = None
    view_732 = torch.ops.aten.view.default(mul_454, [1, 16, -1, 64, 128]);  mul_454 = None
    view_733 = torch.ops.aten.view.default(constant_pad_nd_84, [1, 16, 2, 64]);  constant_pad_nd_84 = None
    ones_16 = torch.ops.aten.ones.default([64, 64], dtype = torch.bool, device = device(type='meta'), pin_memory = False)
    triu_17 = torch.ops.aten.triu.default(ones_16, 1);  ones_16 = None
    cumsum_16 = torch.ops.aten.cumsum.default(view_733, 3);  view_733 = None
    unsqueeze_186 = torch.ops.aten.unsqueeze.default(cumsum_16, 4)
    unsqueeze_187 = torch.ops.aten.unsqueeze.default(cumsum_16, 3)
    sub_64 = torch.ops.aten.sub.Tensor(unsqueeze_186, unsqueeze_187);  unsqueeze_186 = unsqueeze_187 = None
    masked_fill_16 = torch.ops.aten.masked_fill.Scalar(sub_64, triu_17, -inf);  sub_64 = triu_17 = None
    exp_97 = torch.ops.aten.exp.default(masked_fill_16);  masked_fill_16 = None
    transpose_224 = torch.ops.aten.transpose.int(view_730, -1, -2)
    expand_352 = torch.ops.aten.expand.default(view_731, [1, 16, 2, 64, 128])
    view_734 = torch.ops.aten.view.default(expand_352, [32, 64, 128]);  expand_352 = None
    expand_353 = torch.ops.aten.expand.default(transpose_224, [1, 16, 2, 128, 64]);  transpose_224 = None
    view_735 = torch.ops.aten.view.default(expand_353, [32, 128, 64]);  expand_353 = None
    bmm_170 = torch.ops.aten.bmm.default(view_734, view_735);  view_734 = view_735 = None
    _unsafe_view_368 = torch.ops.aten._unsafe_view.default(bmm_170, [1, 16, 2, 64, 64]);  bmm_170 = None
    mul_456 = torch.ops.aten.mul.Tensor(_unsafe_view_368, exp_97);  _unsafe_view_368 = None
    transpose_225 = torch.ops.aten.transpose.int(view_730, -1, -2)
    expand_354 = torch.ops.aten.expand.default(view_729, [1, 16, 2, 64, 128])
    view_736 = torch.ops.aten.view.default(expand_354, [32, 64, 128]);  expand_354 = None
    expand_355 = torch.ops.aten.expand.default(transpose_225, [1, 16, 2, 128, 64]);  transpose_225 = None
    view_737 = torch.ops.aten.view.default(expand_355, [32, 128, 64]);  expand_355 = None
    bmm_171 = torch.ops.aten.bmm.default(view_736, view_737);  view_736 = view_737 = None
    _unsafe_view_369 = torch.ops.aten._unsafe_view.default(bmm_171, [1, 16, 2, 64, 64]);  bmm_171 = None
    mul_457 = torch.ops.aten.mul.Tensor(_unsafe_view_369, exp_97);  _unsafe_view_369 = exp_97 = None
    exp_98 = torch.ops.aten.exp.default(cumsum_16)
    unsqueeze_188 = torch.ops.aten.unsqueeze.default(exp_98, -1);  exp_98 = None
    mul_458 = torch.ops.aten.mul.Tensor(view_731, unsqueeze_188);  view_731 = unsqueeze_188 = None
    linalg_solve_triangular_32 = torch.ops.aten.linalg_solve_triangular.default(mul_456, view_732, upper = False, unitriangular = True);  view_732 = None
    linalg_solve_triangular_33 = torch.ops.aten.linalg_solve_triangular.default(mul_456, mul_458, upper = False, unitriangular = True);  mul_456 = mul_458 = None
    zeros_16 = torch.ops.aten.zeros.default([1, 16, 128, 128], dtype = torch.float32, device = device(type='meta'), pin_memory = False)
    zeros_like_16 = torch.ops.aten.zeros_like.default(linalg_solve_triangular_32, pin_memory = False)
    exp_99 = torch.ops.aten.exp.default(cumsum_16)
    unsqueeze_189 = torch.ops.aten.unsqueeze.default(exp_99, -1);  exp_99 = None
    mul_459 = torch.ops.aten.mul.Tensor(view_729, unsqueeze_189);  view_729 = unsqueeze_189 = None
    slice_83 = torch.ops.aten.slice.Tensor(cumsum_16, 3, -1, 9223372036854775807)
    sub_65 = torch.ops.aten.sub.Tensor(slice_83, cumsum_16);  slice_83 = None
    exp_100 = torch.ops.aten.exp.default(sub_65);  sub_65 = None
    unsqueeze_190 = torch.ops.aten.unsqueeze.default(exp_100, -1);  exp_100 = None
    mul_460 = torch.ops.aten.mul.Tensor(view_730, unsqueeze_190);  view_730 = unsqueeze_190 = None
    select_247 = torch.ops.aten.select.int(cumsum_16, 3, -1);  cumsum_16 = None
    exp_101 = torch.ops.aten.exp.default(select_247);  select_247 = None
    unsqueeze_191 = torch.ops.aten.unsqueeze.default(exp_101, 3);  exp_101 = None
    unsqueeze_192 = torch.ops.aten.unsqueeze.default(unsqueeze_191, 4);  unsqueeze_191 = None
    select_248 = torch.ops.aten.select.int(linalg_solve_triangular_32, 2, 0)
    select_249 = torch.ops.aten.select.int(linalg_solve_triangular_33, 2, 0)
    expand_356 = torch.ops.aten.expand.default(select_249, [1, 16, 64, 128]);  select_249 = None
    view_738 = torch.ops.aten.view.default(expand_356, [16, 64, 128]);  expand_356 = None
    expand_357 = torch.ops.aten.expand.default(zeros_16, [1, 16, 128, 128])
    view_739 = torch.ops.aten.view.default(expand_357, [16, 128, 128]);  expand_357 = None
    bmm_172 = torch.ops.aten.bmm.default(view_738, view_739);  view_738 = view_739 = None
    _unsafe_view_370 = torch.ops.aten._unsafe_view.default(bmm_172, [1, 16, 64, 128]);  bmm_172 = None
    sub_66 = torch.ops.aten.sub.Tensor(select_248, _unsafe_view_370);  select_248 = _unsafe_view_370 = None
    select_250 = torch.ops.aten.select.int(mul_459, 2, 0)
    expand_358 = torch.ops.aten.expand.default(select_250, [1, 16, 64, 128]);  select_250 = None
    view_740 = torch.ops.aten.view.default(expand_358, [16, 64, 128]);  expand_358 = None
    expand_359 = torch.ops.aten.expand.default(zeros_16, [1, 16, 128, 128])
    view_741 = torch.ops.aten.view.default(expand_359, [16, 128, 128]);  expand_359 = None
    bmm_173 = torch.ops.aten.bmm.default(view_740, view_741);  view_740 = view_741 = None
    _unsafe_view_371 = torch.ops.aten._unsafe_view.default(bmm_173, [1, 16, 64, 128]);  bmm_173 = None
    select_251 = torch.ops.aten.select.int(mul_457, 2, 0)
    expand_360 = torch.ops.aten.expand.default(select_251, [1, 16, 64, 64]);  select_251 = None
    view_742 = torch.ops.aten.view.default(expand_360, [16, 64, 64]);  expand_360 = None
    expand_361 = torch.ops.aten.expand.default(sub_66, [1, 16, 64, 128])
    view_743 = torch.ops.aten.view.default(expand_361, [16, 64, 128]);  expand_361 = None
    bmm_174 = torch.ops.aten.bmm.default(view_742, view_743);  view_742 = view_743 = None
    _unsafe_view_372 = torch.ops.aten._unsafe_view.default(bmm_174, [1, 16, 64, 128]);  bmm_174 = None
    add_295 = torch.ops.aten.add.Tensor(_unsafe_view_371, _unsafe_view_372);  _unsafe_view_371 = _unsafe_view_372 = None
    select_252 = torch.ops.aten.select.int(zeros_like_16, 2, 0)
    copy__36 = torch.ops.aten.copy_.default(select_252, add_295);  select_252 = add_295 = copy__36 = None
    select_253 = torch.ops.aten.select.int(unsqueeze_192, 2, 0)
    mul_461 = torch.ops.aten.mul.Tensor(zeros_16, select_253);  zeros_16 = select_253 = None
    select_254 = torch.ops.aten.select.int(mul_460, 2, 0)
    transpose_226 = torch.ops.aten.transpose.int(select_254, -1, -2);  select_254 = None
    expand_362 = torch.ops.aten.expand.default(transpose_226, [1, 16, 128, 64]);  transpose_226 = None
    view_744 = torch.ops.aten.view.default(expand_362, [16, 128, 64]);  expand_362 = None
    expand_363 = torch.ops.aten.expand.default(sub_66, [1, 16, 64, 128]);  sub_66 = None
    view_745 = torch.ops.aten.view.default(expand_363, [16, 64, 128]);  expand_363 = None
    bmm_175 = torch.ops.aten.bmm.default(view_744, view_745);  view_744 = view_745 = None
    _unsafe_view_373 = torch.ops.aten._unsafe_view.default(bmm_175, [1, 16, 128, 128]);  bmm_175 = None
    add_296 = torch.ops.aten.add.Tensor(mul_461, _unsafe_view_373);  mul_461 = _unsafe_view_373 = None
    select_255 = torch.ops.aten.select.int(linalg_solve_triangular_32, 2, 1);  linalg_solve_triangular_32 = None
    select_256 = torch.ops.aten.select.int(linalg_solve_triangular_33, 2, 1);  linalg_solve_triangular_33 = None
    expand_364 = torch.ops.aten.expand.default(select_256, [1, 16, 64, 128]);  select_256 = None
    view_746 = torch.ops.aten.view.default(expand_364, [16, 64, 128]);  expand_364 = None
    expand_365 = torch.ops.aten.expand.default(add_296, [1, 16, 128, 128])
    view_747 = torch.ops.aten.view.default(expand_365, [16, 128, 128]);  expand_365 = None
    bmm_176 = torch.ops.aten.bmm.default(view_746, view_747);  view_746 = view_747 = None
    _unsafe_view_374 = torch.ops.aten._unsafe_view.default(bmm_176, [1, 16, 64, 128]);  bmm_176 = None
    sub_67 = torch.ops.aten.sub.Tensor(select_255, _unsafe_view_374);  select_255 = _unsafe_view_374 = None
    select_257 = torch.ops.aten.select.int(mul_459, 2, 1);  mul_459 = None
    expand_366 = torch.ops.aten.expand.default(select_257, [1, 16, 64, 128]);  select_257 = None
    view_748 = torch.ops.aten.view.default(expand_366, [16, 64, 128]);  expand_366 = None
    expand_367 = torch.ops.aten.expand.default(add_296, [1, 16, 128, 128])
    view_749 = torch.ops.aten.view.default(expand_367, [16, 128, 128]);  expand_367 = None
    bmm_177 = torch.ops.aten.bmm.default(view_748, view_749);  view_748 = view_749 = None
    _unsafe_view_375 = torch.ops.aten._unsafe_view.default(bmm_177, [1, 16, 64, 128]);  bmm_177 = None
    select_258 = torch.ops.aten.select.int(mul_457, 2, 1);  mul_457 = None
    expand_368 = torch.ops.aten.expand.default(select_258, [1, 16, 64, 64]);  select_258 = None
    view_750 = torch.ops.aten.view.default(expand_368, [16, 64, 64]);  expand_368 = None
    expand_369 = torch.ops.aten.expand.default(sub_67, [1, 16, 64, 128])
    view_751 = torch.ops.aten.view.default(expand_369, [16, 64, 128]);  expand_369 = None
    bmm_178 = torch.ops.aten.bmm.default(view_750, view_751);  view_750 = view_751 = None
    _unsafe_view_376 = torch.ops.aten._unsafe_view.default(bmm_178, [1, 16, 64, 128]);  bmm_178 = None
    add_297 = torch.ops.aten.add.Tensor(_unsafe_view_375, _unsafe_view_376);  _unsafe_view_375 = _unsafe_view_376 = None
    select_259 = torch.ops.aten.select.int(zeros_like_16, 2, 1)
    copy__37 = torch.ops.aten.copy_.default(select_259, add_297);  select_259 = add_297 = copy__37 = None
    select_260 = torch.ops.aten.select.int(unsqueeze_192, 2, 1);  unsqueeze_192 = None
    mul_462 = torch.ops.aten.mul.Tensor(add_296, select_260);  add_296 = select_260 = None
    select_261 = torch.ops.aten.select.int(mul_460, 2, 1);  mul_460 = None
    transpose_227 = torch.ops.aten.transpose.int(select_261, -1, -2);  select_261 = None
    expand_370 = torch.ops.aten.expand.default(transpose_227, [1, 16, 128, 64]);  transpose_227 = None
    view_752 = torch.ops.aten.view.default(expand_370, [16, 128, 64]);  expand_370 = None
    expand_371 = torch.ops.aten.expand.default(sub_67, [1, 16, 64, 128]);  sub_67 = None
    view_753 = torch.ops.aten.view.default(expand_371, [16, 64, 128]);  expand_371 = None
    bmm_179 = torch.ops.aten.bmm.default(view_752, view_753);  view_752 = view_753 = None
    _unsafe_view_377 = torch.ops.aten._unsafe_view.default(bmm_179, [1, 16, 128, 128]);  bmm_179 = None
    add_298 = torch.ops.aten.add.Tensor(mul_462, _unsafe_view_377);  mul_462 = _unsafe_view_377 = add_298 = None
    clone_36 = torch.ops.aten.clone.default(zeros_like_16, memory_format = torch.contiguous_format);  zeros_like_16 = None
    _unsafe_view_378 = torch.ops.aten._unsafe_view.default(clone_36, [1, 16, 128, 128]);  clone_36 = None
    alias_16 = torch.ops.aten.alias.default(_unsafe_view_378);  _unsafe_view_378 = None
    transpose_228 = torch.ops.aten.transpose.int(alias_16, 1, 2);  alias_16 = None
    _to_copy_338 = torch.ops.aten._to_copy.default(transpose_228, dtype = torch.bfloat16, memory_format = torch.contiguous_format);  transpose_228 = None
    view_754 = torch.ops.aten.view.default(_to_copy_338, [-1, 128]);  _to_copy_338 = None
    view_755 = torch.ops.aten.view.default(view_723, [-1, 128]);  view_723 = None
    _to_copy_339 = torch.ops.aten._to_copy.default(view_754, dtype = torch.float32);  view_754 = None
    pow_70 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_339, 2)
    mean_69 = torch.ops.aten.mean.dim(pow_70, [-1], True);  pow_70 = None
    add_299 = torch.ops.aten.add.Tensor(mean_69, 1e-06);  mean_69 = None
    rsqrt_103 = torch.ops.aten.rsqrt.default(add_299);  add_299 = None
    mul_463 = torch.ops.aten.mul.Tensor(_to_copy_339, rsqrt_103);  _to_copy_339 = rsqrt_103 = None
    _to_copy_340 = torch.ops.aten._to_copy.default(mul_463, dtype = torch.bfloat16);  mul_463 = None
    _param_constant288 = self._param_constant288
    mul_464 = torch.ops.aten.mul.Tensor(_param_constant288, _to_copy_340);  _param_constant288 = _to_copy_340 = None
    _to_copy_341 = torch.ops.aten._to_copy.default(view_755, dtype = torch.float32);  view_755 = None
    silu_54 = torch.ops.aten.silu.default(_to_copy_341);  _to_copy_341 = None
    mul_465 = torch.ops.aten.mul.Tensor(mul_464, silu_54);  mul_464 = silu_54 = None
    _to_copy_342 = torch.ops.aten._to_copy.default(mul_465, dtype = torch.bfloat16);  mul_465 = None
    view_756 = torch.ops.aten.view.default(_to_copy_342, [1, 128, -1]);  _to_copy_342 = None
    _param_constant289 = self._param_constant289
    t_167 = torch.ops.aten.t.default(_param_constant289);  _param_constant289 = None
    view_757 = torch.ops.aten.view.default(view_756, [128, 2048]);  view_756 = None
    mm_167 = torch.ops.aten.mm.default(view_757, t_167);  view_757 = t_167 = None
    _unsafe_view_379 = torch.ops.aten._unsafe_view.default(mm_167, [1, 128, 2048]);  mm_167 = None
    add_300 = torch.ops.aten.add.Tensor(add_289, _unsafe_view_379);  add_289 = _unsafe_view_379 = None
    _to_copy_343 = torch.ops.aten._to_copy.default(add_300, dtype = torch.float32)
    pow_71 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_343, 2)
    mean_70 = torch.ops.aten.mean.dim(pow_71, [-1], True);  pow_71 = None
    add_301 = torch.ops.aten.add.Tensor(mean_70, 1e-06);  mean_70 = None
    rsqrt_104 = torch.ops.aten.rsqrt.default(add_301);  add_301 = None
    mul_466 = torch.ops.aten.mul.Tensor(_to_copy_343, rsqrt_104);  _to_copy_343 = rsqrt_104 = None
    _param_constant290 = self._param_constant290
    _to_copy_344 = torch.ops.aten._to_copy.default(_param_constant290, dtype = torch.float32);  _param_constant290 = None
    add_302 = torch.ops.aten.add.Tensor(_to_copy_344, 1.0);  _to_copy_344 = None
    mul_467 = torch.ops.aten.mul.Tensor(mul_466, add_302);  mul_466 = add_302 = None
    _to_copy_345 = torch.ops.aten._to_copy.default(mul_467, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_467 = None
    _param_constant291 = self._param_constant291
    t_168 = torch.ops.aten.t.default(_param_constant291);  _param_constant291 = None
    view_758 = torch.ops.aten.view.default(_to_copy_345, [128, 2048])
    mm_168 = torch.ops.aten.mm.default(view_758, t_168);  view_758 = t_168 = None
    _unsafe_view_380 = torch.ops.aten._unsafe_view.default(mm_168, [1, 128, 6144]);  mm_168 = None
    silu_55 = torch.ops.aten.silu.default(_unsafe_view_380);  _unsafe_view_380 = None
    _param_constant292 = self._param_constant292
    t_169 = torch.ops.aten.t.default(_param_constant292);  _param_constant292 = None
    view_759 = torch.ops.aten.view.default(_to_copy_345, [128, 2048]);  _to_copy_345 = None
    mm_169 = torch.ops.aten.mm.default(view_759, t_169);  view_759 = t_169 = None
    _unsafe_view_381 = torch.ops.aten._unsafe_view.default(mm_169, [1, 128, 6144]);  mm_169 = None
    mul_468 = torch.ops.aten.mul.Tensor(silu_55, _unsafe_view_381);  silu_55 = _unsafe_view_381 = None
    _param_constant293 = self._param_constant293
    t_170 = torch.ops.aten.t.default(_param_constant293);  _param_constant293 = None
    view_760 = torch.ops.aten.view.default(mul_468, [128, 6144]);  mul_468 = None
    mm_170 = torch.ops.aten.mm.default(view_760, t_170);  view_760 = t_170 = None
    _unsafe_view_382 = torch.ops.aten._unsafe_view.default(mm_170, [1, 128, 2048]);  mm_170 = None
    add_303 = torch.ops.aten.add.Tensor(add_300, _unsafe_view_382);  add_300 = _unsafe_view_382 = None
    _to_copy_346 = torch.ops.aten._to_copy.default(add_303, dtype = torch.float32)
    pow_72 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_346, 2)
    mean_71 = torch.ops.aten.mean.dim(pow_72, [-1], True);  pow_72 = None
    add_304 = torch.ops.aten.add.Tensor(mean_71, 1e-06);  mean_71 = None
    rsqrt_105 = torch.ops.aten.rsqrt.default(add_304);  add_304 = None
    mul_469 = torch.ops.aten.mul.Tensor(_to_copy_346, rsqrt_105);  _to_copy_346 = rsqrt_105 = None
    _param_constant294 = self._param_constant294
    _to_copy_347 = torch.ops.aten._to_copy.default(_param_constant294, dtype = torch.float32);  _param_constant294 = None
    add_305 = torch.ops.aten.add.Tensor(_to_copy_347, 1.0);  _to_copy_347 = None
    mul_470 = torch.ops.aten.mul.Tensor(mul_469, add_305);  mul_469 = add_305 = None
    _to_copy_348 = torch.ops.aten._to_copy.default(mul_470, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_470 = None
    _param_constant295 = self._param_constant295
    t_171 = torch.ops.aten.t.default(_param_constant295);  _param_constant295 = None
    view_761 = torch.ops.aten.view.default(_to_copy_348, [128, 2048])
    mm_171 = torch.ops.aten.mm.default(view_761, t_171);  view_761 = t_171 = None
    _unsafe_view_383 = torch.ops.aten._unsafe_view.default(mm_171, [1, 128, 6144]);  mm_171 = None
    transpose_229 = torch.ops.aten.transpose.int(_unsafe_view_383, 1, 2);  _unsafe_view_383 = None
    _param_constant296 = self._param_constant296
    t_172 = torch.ops.aten.t.default(_param_constant296);  _param_constant296 = None
    view_762 = torch.ops.aten.view.default(_to_copy_348, [128, 2048])
    mm_172 = torch.ops.aten.mm.default(view_762, t_172);  view_762 = t_172 = None
    _unsafe_view_384 = torch.ops.aten._unsafe_view.default(mm_172, [1, 128, 2048]);  mm_172 = None
    view_763 = torch.ops.aten.view.default(_unsafe_view_384, [1, 128, -1, 128]);  _unsafe_view_384 = None
    _param_constant297 = self._param_constant297
    t_173 = torch.ops.aten.t.default(_param_constant297);  _param_constant297 = None
    view_764 = torch.ops.aten.view.default(_to_copy_348, [128, 2048])
    mm_173 = torch.ops.aten.mm.default(view_764, t_173);  view_764 = t_173 = None
    _unsafe_view_385 = torch.ops.aten._unsafe_view.default(mm_173, [1, 128, 16]);  mm_173 = None
    _param_constant298 = self._param_constant298
    t_174 = torch.ops.aten.t.default(_param_constant298);  _param_constant298 = None
    view_765 = torch.ops.aten.view.default(_to_copy_348, [128, 2048]);  _to_copy_348 = None
    mm_174 = torch.ops.aten.mm.default(view_765, t_174);  view_765 = t_174 = None
    _unsafe_view_386 = torch.ops.aten._unsafe_view.default(mm_174, [1, 128, 16]);  mm_174 = None
    _param_constant299 = self._param_constant299
    squeeze_17 = torch.ops.aten.squeeze.dim(_param_constant299, 1);  _param_constant299 = None
    unsqueeze_193 = torch.ops.aten.unsqueeze.default(squeeze_17, 1);  squeeze_17 = None
    convolution_17 = torch.ops.aten.convolution.default(transpose_229, unsqueeze_193, None, [1], [3], [1], False, [0], 6144);  transpose_229 = unsqueeze_193 = None
    slice_84 = torch.ops.aten.slice.Tensor(convolution_17, 2, 0, 128);  convolution_17 = None
    silu_56 = torch.ops.aten.silu.default(slice_84);  slice_84 = None
    transpose_230 = torch.ops.aten.transpose.int(silu_56, 1, 2);  silu_56 = None
    split_with_sizes_17 = torch.ops.aten.split_with_sizes.default(transpose_230, [2048, 2048, 2048], -1);  transpose_230 = None
    getitem_61 = split_with_sizes_17[0]
    getitem_62 = split_with_sizes_17[1]
    getitem_63 = split_with_sizes_17[2];  split_with_sizes_17 = None
    view_766 = torch.ops.aten.view.default(getitem_61, [1, 128, 16, 128]);  getitem_61 = None
    view_767 = torch.ops.aten.view.default(getitem_62, [1, 128, 16, 128]);  getitem_62 = None
    view_768 = torch.ops.aten.view.default(getitem_63, [1, 128, 16, 128]);  getitem_63 = None
    sigmoid_22 = torch.ops.aten.sigmoid.default(_unsafe_view_385);  _unsafe_view_385 = None
    _param_constant300 = self._param_constant300
    exp_102 = torch.ops.aten.exp.default(_param_constant300);  _param_constant300 = None
    neg_27 = torch.ops.aten.neg.default(exp_102);  exp_102 = None
    _to_copy_349 = torch.ops.aten._to_copy.default(_unsafe_view_386, dtype = torch.float32);  _unsafe_view_386 = None
    _param_constant301 = self._param_constant301
    add_306 = torch.ops.aten.add.Tensor(_to_copy_349, _param_constant301);  _to_copy_349 = _param_constant301 = None
    softplus_17 = torch.ops.aten.softplus.default(add_306);  add_306 = None
    mul_471 = torch.ops.aten.mul.Tensor(neg_27, softplus_17);  neg_27 = softplus_17 = None
    transpose_231 = torch.ops.aten.transpose.int(view_766, 1, 2);  view_766 = None
    _to_copy_350 = torch.ops.aten._to_copy.default(transpose_231, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_231 = None
    transpose_232 = torch.ops.aten.transpose.int(view_767, 1, 2);  view_767 = None
    _to_copy_351 = torch.ops.aten._to_copy.default(transpose_232, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_232 = None
    transpose_233 = torch.ops.aten.transpose.int(view_768, 1, 2);  view_768 = None
    _to_copy_352 = torch.ops.aten._to_copy.default(transpose_233, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_233 = None
    transpose_234 = torch.ops.aten.transpose.int(sigmoid_22, 1, 2);  sigmoid_22 = None
    _to_copy_353 = torch.ops.aten._to_copy.default(transpose_234, dtype = torch.float32, memory_format = torch.contiguous_format);  transpose_234 = None
    transpose_235 = torch.ops.aten.transpose.int(mul_471, 1, 2);  mul_471 = None
    mul_472 = torch.ops.aten.mul.Tensor(_to_copy_350, _to_copy_350)
    sum_35 = torch.ops.aten.sum.dim_IntList(mul_472, [-1], True);  mul_472 = None
    add_307 = torch.ops.aten.add.Tensor(sum_35, 1e-06);  sum_35 = None
    rsqrt_106 = torch.ops.aten.rsqrt.default(add_307);  add_307 = None
    mul_473 = torch.ops.aten.mul.Tensor(_to_copy_350, rsqrt_106);  _to_copy_350 = rsqrt_106 = None
    mul_474 = torch.ops.aten.mul.Tensor(_to_copy_351, _to_copy_351)
    sum_36 = torch.ops.aten.sum.dim_IntList(mul_474, [-1], True);  mul_474 = None
    add_308 = torch.ops.aten.add.Tensor(sum_36, 1e-06);  sum_36 = None
    rsqrt_107 = torch.ops.aten.rsqrt.default(add_308);  add_308 = None
    mul_475 = torch.ops.aten.mul.Tensor(_to_copy_351, rsqrt_107);  _to_copy_351 = rsqrt_107 = None
    mul_476 = torch.ops.aten.mul.Tensor(mul_473, 0.08838834764831845);  mul_473 = None
    constant_pad_nd_85 = torch.ops.aten.constant_pad_nd.default(mul_476, [0, 0, 0, 0], 0.0);  mul_476 = None
    constant_pad_nd_86 = torch.ops.aten.constant_pad_nd.default(mul_475, [0, 0, 0, 0], 0.0);  mul_475 = None
    constant_pad_nd_87 = torch.ops.aten.constant_pad_nd.default(_to_copy_352, [0, 0, 0, 0], 0.0);  _to_copy_352 = None
    constant_pad_nd_88 = torch.ops.aten.constant_pad_nd.default(_to_copy_353, [0, 0], 0.0);  _to_copy_353 = None
    constant_pad_nd_89 = torch.ops.aten.constant_pad_nd.default(transpose_235, [0, 0], 0.0);  transpose_235 = None
    unsqueeze_194 = torch.ops.aten.unsqueeze.default(constant_pad_nd_88, -1)
    mul_477 = torch.ops.aten.mul.Tensor(constant_pad_nd_87, unsqueeze_194);  constant_pad_nd_87 = unsqueeze_194 = None
    unsqueeze_195 = torch.ops.aten.unsqueeze.default(constant_pad_nd_88, -1);  constant_pad_nd_88 = None
    mul_478 = torch.ops.aten.mul.Tensor(constant_pad_nd_86, unsqueeze_195);  unsqueeze_195 = None
    view_769 = torch.ops.aten.view.default(constant_pad_nd_85, [1, 16, -1, 64, 128]);  constant_pad_nd_85 = None
    view_770 = torch.ops.aten.view.default(constant_pad_nd_86, [1, 16, -1, 64, 128]);  constant_pad_nd_86 = None
    view_771 = torch.ops.aten.view.default(mul_478, [1, 16, -1, 64, 128]);  mul_478 = None
    view_772 = torch.ops.aten.view.default(mul_477, [1, 16, -1, 64, 128]);  mul_477 = None
    view_773 = torch.ops.aten.view.default(constant_pad_nd_89, [1, 16, 2, 64]);  constant_pad_nd_89 = None
    ones_17 = torch.ops.aten.ones.default([64, 64], dtype = torch.bool, device = device(type='meta'), pin_memory = False)
    triu_18 = torch.ops.aten.triu.default(ones_17, 1);  ones_17 = None
    cumsum_17 = torch.ops.aten.cumsum.default(view_773, 3);  view_773 = None
    unsqueeze_196 = torch.ops.aten.unsqueeze.default(cumsum_17, 4)
    unsqueeze_197 = torch.ops.aten.unsqueeze.default(cumsum_17, 3)
    sub_68 = torch.ops.aten.sub.Tensor(unsqueeze_196, unsqueeze_197);  unsqueeze_196 = unsqueeze_197 = None
    masked_fill_17 = torch.ops.aten.masked_fill.Scalar(sub_68, triu_18, -inf);  sub_68 = triu_18 = None
    exp_103 = torch.ops.aten.exp.default(masked_fill_17);  masked_fill_17 = None
    transpose_236 = torch.ops.aten.transpose.int(view_770, -1, -2)
    expand_372 = torch.ops.aten.expand.default(view_771, [1, 16, 2, 64, 128])
    view_774 = torch.ops.aten.view.default(expand_372, [32, 64, 128]);  expand_372 = None
    expand_373 = torch.ops.aten.expand.default(transpose_236, [1, 16, 2, 128, 64]);  transpose_236 = None
    view_775 = torch.ops.aten.view.default(expand_373, [32, 128, 64]);  expand_373 = None
    bmm_180 = torch.ops.aten.bmm.default(view_774, view_775);  view_774 = view_775 = None
    _unsafe_view_387 = torch.ops.aten._unsafe_view.default(bmm_180, [1, 16, 2, 64, 64]);  bmm_180 = None
    mul_479 = torch.ops.aten.mul.Tensor(_unsafe_view_387, exp_103);  _unsafe_view_387 = None
    transpose_237 = torch.ops.aten.transpose.int(view_770, -1, -2)
    expand_374 = torch.ops.aten.expand.default(view_769, [1, 16, 2, 64, 128])
    view_776 = torch.ops.aten.view.default(expand_374, [32, 64, 128]);  expand_374 = None
    expand_375 = torch.ops.aten.expand.default(transpose_237, [1, 16, 2, 128, 64]);  transpose_237 = None
    view_777 = torch.ops.aten.view.default(expand_375, [32, 128, 64]);  expand_375 = None
    bmm_181 = torch.ops.aten.bmm.default(view_776, view_777);  view_776 = view_777 = None
    _unsafe_view_388 = torch.ops.aten._unsafe_view.default(bmm_181, [1, 16, 2, 64, 64]);  bmm_181 = None
    mul_480 = torch.ops.aten.mul.Tensor(_unsafe_view_388, exp_103);  _unsafe_view_388 = exp_103 = None
    exp_104 = torch.ops.aten.exp.default(cumsum_17)
    unsqueeze_198 = torch.ops.aten.unsqueeze.default(exp_104, -1);  exp_104 = None
    mul_481 = torch.ops.aten.mul.Tensor(view_771, unsqueeze_198);  view_771 = unsqueeze_198 = None
    linalg_solve_triangular_34 = torch.ops.aten.linalg_solve_triangular.default(mul_479, view_772, upper = False, unitriangular = True);  view_772 = None
    linalg_solve_triangular_35 = torch.ops.aten.linalg_solve_triangular.default(mul_479, mul_481, upper = False, unitriangular = True);  mul_479 = mul_481 = None
    zeros_17 = torch.ops.aten.zeros.default([1, 16, 128, 128], dtype = torch.float32, device = device(type='meta'), pin_memory = False)
    zeros_like_17 = torch.ops.aten.zeros_like.default(linalg_solve_triangular_34, pin_memory = False)
    exp_105 = torch.ops.aten.exp.default(cumsum_17)
    unsqueeze_199 = torch.ops.aten.unsqueeze.default(exp_105, -1);  exp_105 = None
    mul_482 = torch.ops.aten.mul.Tensor(view_769, unsqueeze_199);  view_769 = unsqueeze_199 = None
    slice_85 = torch.ops.aten.slice.Tensor(cumsum_17, 3, -1, 9223372036854775807)
    sub_69 = torch.ops.aten.sub.Tensor(slice_85, cumsum_17);  slice_85 = None
    exp_106 = torch.ops.aten.exp.default(sub_69);  sub_69 = None
    unsqueeze_200 = torch.ops.aten.unsqueeze.default(exp_106, -1);  exp_106 = None
    mul_483 = torch.ops.aten.mul.Tensor(view_770, unsqueeze_200);  view_770 = unsqueeze_200 = None
    select_262 = torch.ops.aten.select.int(cumsum_17, 3, -1);  cumsum_17 = None
    exp_107 = torch.ops.aten.exp.default(select_262);  select_262 = None
    unsqueeze_201 = torch.ops.aten.unsqueeze.default(exp_107, 3);  exp_107 = None
    unsqueeze_202 = torch.ops.aten.unsqueeze.default(unsqueeze_201, 4);  unsqueeze_201 = None
    select_263 = torch.ops.aten.select.int(linalg_solve_triangular_34, 2, 0)
    select_264 = torch.ops.aten.select.int(linalg_solve_triangular_35, 2, 0)
    expand_376 = torch.ops.aten.expand.default(select_264, [1, 16, 64, 128]);  select_264 = None
    view_778 = torch.ops.aten.view.default(expand_376, [16, 64, 128]);  expand_376 = None
    expand_377 = torch.ops.aten.expand.default(zeros_17, [1, 16, 128, 128])
    view_779 = torch.ops.aten.view.default(expand_377, [16, 128, 128]);  expand_377 = None
    bmm_182 = torch.ops.aten.bmm.default(view_778, view_779);  view_778 = view_779 = None
    _unsafe_view_389 = torch.ops.aten._unsafe_view.default(bmm_182, [1, 16, 64, 128]);  bmm_182 = None
    sub_70 = torch.ops.aten.sub.Tensor(select_263, _unsafe_view_389);  select_263 = _unsafe_view_389 = None
    select_265 = torch.ops.aten.select.int(mul_482, 2, 0)
    expand_378 = torch.ops.aten.expand.default(select_265, [1, 16, 64, 128]);  select_265 = None
    view_780 = torch.ops.aten.view.default(expand_378, [16, 64, 128]);  expand_378 = None
    expand_379 = torch.ops.aten.expand.default(zeros_17, [1, 16, 128, 128])
    view_781 = torch.ops.aten.view.default(expand_379, [16, 128, 128]);  expand_379 = None
    bmm_183 = torch.ops.aten.bmm.default(view_780, view_781);  view_780 = view_781 = None
    _unsafe_view_390 = torch.ops.aten._unsafe_view.default(bmm_183, [1, 16, 64, 128]);  bmm_183 = None
    select_266 = torch.ops.aten.select.int(mul_480, 2, 0)
    expand_380 = torch.ops.aten.expand.default(select_266, [1, 16, 64, 64]);  select_266 = None
    view_782 = torch.ops.aten.view.default(expand_380, [16, 64, 64]);  expand_380 = None
    expand_381 = torch.ops.aten.expand.default(sub_70, [1, 16, 64, 128])
    view_783 = torch.ops.aten.view.default(expand_381, [16, 64, 128]);  expand_381 = None
    bmm_184 = torch.ops.aten.bmm.default(view_782, view_783);  view_782 = view_783 = None
    _unsafe_view_391 = torch.ops.aten._unsafe_view.default(bmm_184, [1, 16, 64, 128]);  bmm_184 = None
    add_309 = torch.ops.aten.add.Tensor(_unsafe_view_390, _unsafe_view_391);  _unsafe_view_390 = _unsafe_view_391 = None
    select_267 = torch.ops.aten.select.int(zeros_like_17, 2, 0)
    copy__38 = torch.ops.aten.copy_.default(select_267, add_309);  select_267 = add_309 = copy__38 = None
    select_268 = torch.ops.aten.select.int(unsqueeze_202, 2, 0)
    mul_484 = torch.ops.aten.mul.Tensor(zeros_17, select_268);  zeros_17 = select_268 = None
    select_269 = torch.ops.aten.select.int(mul_483, 2, 0)
    transpose_238 = torch.ops.aten.transpose.int(select_269, -1, -2);  select_269 = None
    expand_382 = torch.ops.aten.expand.default(transpose_238, [1, 16, 128, 64]);  transpose_238 = None
    view_784 = torch.ops.aten.view.default(expand_382, [16, 128, 64]);  expand_382 = None
    expand_383 = torch.ops.aten.expand.default(sub_70, [1, 16, 64, 128]);  sub_70 = None
    view_785 = torch.ops.aten.view.default(expand_383, [16, 64, 128]);  expand_383 = None
    bmm_185 = torch.ops.aten.bmm.default(view_784, view_785);  view_784 = view_785 = None
    _unsafe_view_392 = torch.ops.aten._unsafe_view.default(bmm_185, [1, 16, 128, 128]);  bmm_185 = None
    add_310 = torch.ops.aten.add.Tensor(mul_484, _unsafe_view_392);  mul_484 = _unsafe_view_392 = None
    select_270 = torch.ops.aten.select.int(linalg_solve_triangular_34, 2, 1);  linalg_solve_triangular_34 = None
    select_271 = torch.ops.aten.select.int(linalg_solve_triangular_35, 2, 1);  linalg_solve_triangular_35 = None
    expand_384 = torch.ops.aten.expand.default(select_271, [1, 16, 64, 128]);  select_271 = None
    view_786 = torch.ops.aten.view.default(expand_384, [16, 64, 128]);  expand_384 = None
    expand_385 = torch.ops.aten.expand.default(add_310, [1, 16, 128, 128])
    view_787 = torch.ops.aten.view.default(expand_385, [16, 128, 128]);  expand_385 = None
    bmm_186 = torch.ops.aten.bmm.default(view_786, view_787);  view_786 = view_787 = None
    _unsafe_view_393 = torch.ops.aten._unsafe_view.default(bmm_186, [1, 16, 64, 128]);  bmm_186 = None
    sub_71 = torch.ops.aten.sub.Tensor(select_270, _unsafe_view_393);  select_270 = _unsafe_view_393 = None
    select_272 = torch.ops.aten.select.int(mul_482, 2, 1);  mul_482 = None
    expand_386 = torch.ops.aten.expand.default(select_272, [1, 16, 64, 128]);  select_272 = None
    view_788 = torch.ops.aten.view.default(expand_386, [16, 64, 128]);  expand_386 = None
    expand_387 = torch.ops.aten.expand.default(add_310, [1, 16, 128, 128])
    view_789 = torch.ops.aten.view.default(expand_387, [16, 128, 128]);  expand_387 = None
    bmm_187 = torch.ops.aten.bmm.default(view_788, view_789);  view_788 = view_789 = None
    _unsafe_view_394 = torch.ops.aten._unsafe_view.default(bmm_187, [1, 16, 64, 128]);  bmm_187 = None
    select_273 = torch.ops.aten.select.int(mul_480, 2, 1);  mul_480 = None
    expand_388 = torch.ops.aten.expand.default(select_273, [1, 16, 64, 64]);  select_273 = None
    view_790 = torch.ops.aten.view.default(expand_388, [16, 64, 64]);  expand_388 = None
    expand_389 = torch.ops.aten.expand.default(sub_71, [1, 16, 64, 128])
    view_791 = torch.ops.aten.view.default(expand_389, [16, 64, 128]);  expand_389 = None
    bmm_188 = torch.ops.aten.bmm.default(view_790, view_791);  view_790 = view_791 = None
    _unsafe_view_395 = torch.ops.aten._unsafe_view.default(bmm_188, [1, 16, 64, 128]);  bmm_188 = None
    add_311 = torch.ops.aten.add.Tensor(_unsafe_view_394, _unsafe_view_395);  _unsafe_view_394 = _unsafe_view_395 = None
    select_274 = torch.ops.aten.select.int(zeros_like_17, 2, 1)
    copy__39 = torch.ops.aten.copy_.default(select_274, add_311);  select_274 = add_311 = copy__39 = None
    select_275 = torch.ops.aten.select.int(unsqueeze_202, 2, 1);  unsqueeze_202 = None
    mul_485 = torch.ops.aten.mul.Tensor(add_310, select_275);  add_310 = select_275 = None
    select_276 = torch.ops.aten.select.int(mul_483, 2, 1);  mul_483 = None
    transpose_239 = torch.ops.aten.transpose.int(select_276, -1, -2);  select_276 = None
    expand_390 = torch.ops.aten.expand.default(transpose_239, [1, 16, 128, 64]);  transpose_239 = None
    view_792 = torch.ops.aten.view.default(expand_390, [16, 128, 64]);  expand_390 = None
    expand_391 = torch.ops.aten.expand.default(sub_71, [1, 16, 64, 128]);  sub_71 = None
    view_793 = torch.ops.aten.view.default(expand_391, [16, 64, 128]);  expand_391 = None
    bmm_189 = torch.ops.aten.bmm.default(view_792, view_793);  view_792 = view_793 = None
    _unsafe_view_396 = torch.ops.aten._unsafe_view.default(bmm_189, [1, 16, 128, 128]);  bmm_189 = None
    add_312 = torch.ops.aten.add.Tensor(mul_485, _unsafe_view_396);  mul_485 = _unsafe_view_396 = add_312 = None
    clone_37 = torch.ops.aten.clone.default(zeros_like_17, memory_format = torch.contiguous_format);  zeros_like_17 = None
    _unsafe_view_397 = torch.ops.aten._unsafe_view.default(clone_37, [1, 16, 128, 128]);  clone_37 = None
    alias_17 = torch.ops.aten.alias.default(_unsafe_view_397);  _unsafe_view_397 = None
    transpose_240 = torch.ops.aten.transpose.int(alias_17, 1, 2);  alias_17 = None
    _to_copy_354 = torch.ops.aten._to_copy.default(transpose_240, dtype = torch.bfloat16, memory_format = torch.contiguous_format);  transpose_240 = None
    view_794 = torch.ops.aten.view.default(_to_copy_354, [-1, 128]);  _to_copy_354 = None
    view_795 = torch.ops.aten.view.default(view_763, [-1, 128]);  view_763 = None
    _to_copy_355 = torch.ops.aten._to_copy.default(view_794, dtype = torch.float32);  view_794 = None
    pow_73 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_355, 2)
    mean_72 = torch.ops.aten.mean.dim(pow_73, [-1], True);  pow_73 = None
    add_313 = torch.ops.aten.add.Tensor(mean_72, 1e-06);  mean_72 = None
    rsqrt_108 = torch.ops.aten.rsqrt.default(add_313);  add_313 = None
    mul_486 = torch.ops.aten.mul.Tensor(_to_copy_355, rsqrt_108);  _to_copy_355 = rsqrt_108 = None
    _to_copy_356 = torch.ops.aten._to_copy.default(mul_486, dtype = torch.bfloat16);  mul_486 = None
    _param_constant302 = self._param_constant302
    mul_487 = torch.ops.aten.mul.Tensor(_param_constant302, _to_copy_356);  _param_constant302 = _to_copy_356 = None
    _to_copy_357 = torch.ops.aten._to_copy.default(view_795, dtype = torch.float32);  view_795 = None
    silu_57 = torch.ops.aten.silu.default(_to_copy_357);  _to_copy_357 = None
    mul_488 = torch.ops.aten.mul.Tensor(mul_487, silu_57);  mul_487 = silu_57 = None
    _to_copy_358 = torch.ops.aten._to_copy.default(mul_488, dtype = torch.bfloat16);  mul_488 = None
    view_796 = torch.ops.aten.view.default(_to_copy_358, [1, 128, -1]);  _to_copy_358 = None
    _param_constant303 = self._param_constant303
    t_175 = torch.ops.aten.t.default(_param_constant303);  _param_constant303 = None
    view_797 = torch.ops.aten.view.default(view_796, [128, 2048]);  view_796 = None
    mm_175 = torch.ops.aten.mm.default(view_797, t_175);  view_797 = t_175 = None
    _unsafe_view_398 = torch.ops.aten._unsafe_view.default(mm_175, [1, 128, 2048]);  mm_175 = None
    add_314 = torch.ops.aten.add.Tensor(add_303, _unsafe_view_398);  add_303 = _unsafe_view_398 = None
    _to_copy_359 = torch.ops.aten._to_copy.default(add_314, dtype = torch.float32)
    pow_74 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_359, 2)
    mean_73 = torch.ops.aten.mean.dim(pow_74, [-1], True);  pow_74 = None
    add_315 = torch.ops.aten.add.Tensor(mean_73, 1e-06);  mean_73 = None
    rsqrt_109 = torch.ops.aten.rsqrt.default(add_315);  add_315 = None
    mul_489 = torch.ops.aten.mul.Tensor(_to_copy_359, rsqrt_109);  _to_copy_359 = rsqrt_109 = None
    _param_constant304 = self._param_constant304
    _to_copy_360 = torch.ops.aten._to_copy.default(_param_constant304, dtype = torch.float32);  _param_constant304 = None
    add_316 = torch.ops.aten.add.Tensor(_to_copy_360, 1.0);  _to_copy_360 = None
    mul_490 = torch.ops.aten.mul.Tensor(mul_489, add_316);  mul_489 = add_316 = None
    _to_copy_361 = torch.ops.aten._to_copy.default(mul_490, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_490 = None
    _param_constant305 = self._param_constant305
    t_176 = torch.ops.aten.t.default(_param_constant305);  _param_constant305 = None
    view_798 = torch.ops.aten.view.default(_to_copy_361, [128, 2048])
    mm_176 = torch.ops.aten.mm.default(view_798, t_176);  view_798 = t_176 = None
    _unsafe_view_399 = torch.ops.aten._unsafe_view.default(mm_176, [1, 128, 6144]);  mm_176 = None
    silu_58 = torch.ops.aten.silu.default(_unsafe_view_399);  _unsafe_view_399 = None
    _param_constant306 = self._param_constant306
    t_177 = torch.ops.aten.t.default(_param_constant306);  _param_constant306 = None
    view_799 = torch.ops.aten.view.default(_to_copy_361, [128, 2048]);  _to_copy_361 = None
    mm_177 = torch.ops.aten.mm.default(view_799, t_177);  view_799 = t_177 = None
    _unsafe_view_400 = torch.ops.aten._unsafe_view.default(mm_177, [1, 128, 6144]);  mm_177 = None
    mul_491 = torch.ops.aten.mul.Tensor(silu_58, _unsafe_view_400);  silu_58 = _unsafe_view_400 = None
    _param_constant307 = self._param_constant307
    t_178 = torch.ops.aten.t.default(_param_constant307);  _param_constant307 = None
    view_800 = torch.ops.aten.view.default(mul_491, [128, 6144]);  mul_491 = None
    mm_178 = torch.ops.aten.mm.default(view_800, t_178);  view_800 = t_178 = None
    _unsafe_view_401 = torch.ops.aten._unsafe_view.default(mm_178, [1, 128, 2048]);  mm_178 = None
    add_317 = torch.ops.aten.add.Tensor(add_314, _unsafe_view_401);  add_314 = _unsafe_view_401 = None
    _to_copy_362 = torch.ops.aten._to_copy.default(add_317, dtype = torch.float32)
    pow_75 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_362, 2)
    mean_74 = torch.ops.aten.mean.dim(pow_75, [-1], True);  pow_75 = None
    add_318 = torch.ops.aten.add.Tensor(mean_74, 1e-06);  mean_74 = None
    rsqrt_110 = torch.ops.aten.rsqrt.default(add_318);  add_318 = None
    mul_492 = torch.ops.aten.mul.Tensor(_to_copy_362, rsqrt_110);  _to_copy_362 = rsqrt_110 = None
    _param_constant308 = self._param_constant308
    _to_copy_363 = torch.ops.aten._to_copy.default(_param_constant308, dtype = torch.float32);  _param_constant308 = None
    add_319 = torch.ops.aten.add.Tensor(_to_copy_363, 1.0);  _to_copy_363 = None
    mul_493 = torch.ops.aten.mul.Tensor(mul_492, add_319);  mul_492 = add_319 = None
    _to_copy_364 = torch.ops.aten._to_copy.default(mul_493, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_493 = None
    _param_constant309 = self._param_constant309
    t_179 = torch.ops.aten.t.default(_param_constant309);  _param_constant309 = None
    view_801 = torch.ops.aten.view.default(_to_copy_364, [128, 2048])
    mm_179 = torch.ops.aten.mm.default(view_801, t_179);  view_801 = t_179 = None
    _unsafe_view_402 = torch.ops.aten._unsafe_view.default(mm_179, [1, 128, 4096]);  mm_179 = None
    view_802 = torch.ops.aten.view.default(_unsafe_view_402, [1, 128, -1, 512]);  _unsafe_view_402 = None
    split_5 = torch.ops.aten.split.Tensor(view_802, 256, -1);  view_802 = None
    getitem_64 = split_5[0]
    getitem_65 = split_5[1];  split_5 = None
    clone_38 = torch.ops.aten.clone.default(getitem_65, memory_format = torch.contiguous_format);  getitem_65 = None
    _unsafe_view_403 = torch.ops.aten._unsafe_view.default(clone_38, [1, 128, 2048]);  clone_38 = None
    view_803 = torch.ops.aten.view.default(getitem_64, [1, 128, -1, 256]);  getitem_64 = None
    _to_copy_365 = torch.ops.aten._to_copy.default(view_803, dtype = torch.float32);  view_803 = None
    pow_76 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_365, 2)
    mean_75 = torch.ops.aten.mean.dim(pow_76, [-1], True);  pow_76 = None
    add_320 = torch.ops.aten.add.Tensor(mean_75, 1e-06);  mean_75 = None
    rsqrt_111 = torch.ops.aten.rsqrt.default(add_320);  add_320 = None
    mul_494 = torch.ops.aten.mul.Tensor(_to_copy_365, rsqrt_111);  _to_copy_365 = rsqrt_111 = None
    _param_constant310 = self._param_constant310
    _to_copy_366 = torch.ops.aten._to_copy.default(_param_constant310, dtype = torch.float32);  _param_constant310 = None
    add_321 = torch.ops.aten.add.Tensor(_to_copy_366, 1.0);  _to_copy_366 = None
    mul_495 = torch.ops.aten.mul.Tensor(mul_494, add_321);  mul_494 = add_321 = None
    _to_copy_367 = torch.ops.aten._to_copy.default(mul_495, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_495 = None
    transpose_241 = torch.ops.aten.transpose.int(_to_copy_367, 1, 2);  _to_copy_367 = None
    _param_constant311 = self._param_constant311
    t_180 = torch.ops.aten.t.default(_param_constant311);  _param_constant311 = None
    view_804 = torch.ops.aten.view.default(_to_copy_364, [128, 2048])
    mm_180 = torch.ops.aten.mm.default(view_804, t_180);  view_804 = t_180 = None
    _unsafe_view_404 = torch.ops.aten._unsafe_view.default(mm_180, [1, 128, 512]);  mm_180 = None
    view_805 = torch.ops.aten.view.default(_unsafe_view_404, [1, 128, -1, 256]);  _unsafe_view_404 = None
    _to_copy_368 = torch.ops.aten._to_copy.default(view_805, dtype = torch.float32);  view_805 = None
    pow_77 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_368, 2)
    mean_76 = torch.ops.aten.mean.dim(pow_77, [-1], True);  pow_77 = None
    add_322 = torch.ops.aten.add.Tensor(mean_76, 1e-06);  mean_76 = None
    rsqrt_112 = torch.ops.aten.rsqrt.default(add_322);  add_322 = None
    mul_496 = torch.ops.aten.mul.Tensor(_to_copy_368, rsqrt_112);  _to_copy_368 = rsqrt_112 = None
    _param_constant312 = self._param_constant312
    _to_copy_369 = torch.ops.aten._to_copy.default(_param_constant312, dtype = torch.float32);  _param_constant312 = None
    add_323 = torch.ops.aten.add.Tensor(_to_copy_369, 1.0);  _to_copy_369 = None
    mul_497 = torch.ops.aten.mul.Tensor(mul_496, add_323);  mul_496 = add_323 = None
    _to_copy_370 = torch.ops.aten._to_copy.default(mul_497, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_497 = None
    transpose_242 = torch.ops.aten.transpose.int(_to_copy_370, 1, 2);  _to_copy_370 = None
    _param_constant313 = self._param_constant313
    t_181 = torch.ops.aten.t.default(_param_constant313);  _param_constant313 = None
    view_806 = torch.ops.aten.view.default(_to_copy_364, [128, 2048]);  _to_copy_364 = None
    mm_181 = torch.ops.aten.mm.default(view_806, t_181);  view_806 = t_181 = None
    _unsafe_view_405 = torch.ops.aten._unsafe_view.default(mm_181, [1, 128, 512]);  mm_181 = None
    view_807 = torch.ops.aten.view.default(_unsafe_view_405, [1, 128, -1, 256]);  _unsafe_view_405 = None
    transpose_243 = torch.ops.aten.transpose.int(view_807, 1, 2);  view_807 = None
    unsqueeze_203 = torch.ops.aten.unsqueeze.default(_to_copy_2, 1);  _to_copy_2 = None
    unsqueeze_204 = torch.ops.aten.unsqueeze.default(_to_copy_3, 1);  _to_copy_3 = None
    slice_86 = torch.ops.aten.slice.Tensor(transpose_241, 3, 0, 64)
    slice_87 = torch.ops.aten.slice.Tensor(transpose_241, 3, 64, 9223372036854775807);  transpose_241 = None
    slice_88 = torch.ops.aten.slice.Tensor(transpose_242, 3, 0, 64)
    slice_89 = torch.ops.aten.slice.Tensor(transpose_242, 3, 64, 9223372036854775807);  transpose_242 = None
    mul_498 = torch.ops.aten.mul.Tensor(slice_86, unsqueeze_203)
    slice_90 = torch.ops.aten.slice.Tensor(slice_86, 3, 0, 32)
    slice_91 = torch.ops.aten.slice.Tensor(slice_86, 3, 32, 9223372036854775807);  slice_86 = None
    neg_28 = torch.ops.aten.neg.default(slice_91);  slice_91 = None
    cat_22 = torch.ops.aten.cat.default([neg_28, slice_90], -1);  neg_28 = slice_90 = None
    mul_499 = torch.ops.aten.mul.Tensor(cat_22, unsqueeze_204);  cat_22 = None
    add_324 = torch.ops.aten.add.Tensor(mul_498, mul_499);  mul_498 = mul_499 = None
    mul_500 = torch.ops.aten.mul.Tensor(slice_88, unsqueeze_203);  unsqueeze_203 = None
    slice_92 = torch.ops.aten.slice.Tensor(slice_88, 3, 0, 32)
    slice_93 = torch.ops.aten.slice.Tensor(slice_88, 3, 32, 9223372036854775807);  slice_88 = None
    neg_29 = torch.ops.aten.neg.default(slice_93);  slice_93 = None
    cat_23 = torch.ops.aten.cat.default([neg_29, slice_92], -1);  neg_29 = slice_92 = None
    mul_501 = torch.ops.aten.mul.Tensor(cat_23, unsqueeze_204);  cat_23 = unsqueeze_204 = None
    add_325 = torch.ops.aten.add.Tensor(mul_500, mul_501);  mul_500 = mul_501 = None
    cat_24 = torch.ops.aten.cat.default([add_324, slice_87], -1);  add_324 = slice_87 = None
    cat_25 = torch.ops.aten.cat.default([add_325, slice_89], -1);  add_325 = slice_89 = None
    unsqueeze_205 = torch.ops.aten.unsqueeze.default(cat_25, 2);  cat_25 = None
    expand_392 = torch.ops.aten.expand.default(unsqueeze_205, [1, 2, 4, 128, 256]);  unsqueeze_205 = None
    clone_39 = torch.ops.aten.clone.default(expand_392, memory_format = torch.contiguous_format);  expand_392 = None
    _unsafe_view_406 = torch.ops.aten._unsafe_view.default(clone_39, [1, 8, 128, 256]);  clone_39 = None
    unsqueeze_206 = torch.ops.aten.unsqueeze.default(transpose_243, 2);  transpose_243 = None
    expand_393 = torch.ops.aten.expand.default(unsqueeze_206, [1, 2, 4, 128, 256]);  unsqueeze_206 = None
    clone_40 = torch.ops.aten.clone.default(expand_393, memory_format = torch.contiguous_format);  expand_393 = None
    _unsafe_view_407 = torch.ops.aten._unsafe_view.default(clone_40, [1, 8, 128, 256]);  clone_40 = None
    transpose_244 = torch.ops.aten.transpose.int(_unsafe_view_406, 2, 3);  _unsafe_view_406 = None
    expand_394 = torch.ops.aten.expand.default(cat_24, [1, 8, 128, 256]);  cat_24 = None
    view_808 = torch.ops.aten.view.default(expand_394, [8, 128, 256]);  expand_394 = None
    expand_395 = torch.ops.aten.expand.default(transpose_244, [1, 8, 256, 128]);  transpose_244 = None
    view_809 = torch.ops.aten.view.default(expand_395, [8, 256, 128]);  expand_395 = None
    bmm_190 = torch.ops.aten.bmm.default(view_808, view_809);  view_808 = view_809 = None
    _unsafe_view_408 = torch.ops.aten._unsafe_view.default(bmm_190, [1, 8, 128, 128]);  bmm_190 = None
    mul_502 = torch.ops.aten.mul.Tensor(_unsafe_view_408, 0.0625);  _unsafe_view_408 = None
    add_326 = torch.ops.aten.add.Tensor(mul_502, unsqueeze_1);  mul_502 = unsqueeze_1 = None
    _to_copy_371 = torch.ops.aten._to_copy.default(add_326, dtype = torch.float32, layout = torch.strided, device = device(type='meta'));  add_326 = None
    _softmax_5 = torch.ops.aten._softmax.default(_to_copy_371, -1, False);  _to_copy_371 = None
    _to_copy_372 = torch.ops.aten._to_copy.default(_softmax_5, dtype = torch.bfloat16);  _softmax_5 = None
    expand_396 = torch.ops.aten.expand.default(_to_copy_372, [1, 8, 128, 128]);  _to_copy_372 = None
    view_810 = torch.ops.aten.view.default(expand_396, [8, 128, 128]);  expand_396 = None
    expand_397 = torch.ops.aten.expand.default(_unsafe_view_407, [1, 8, 128, 256]);  _unsafe_view_407 = None
    view_811 = torch.ops.aten.view.default(expand_397, [8, 128, 256]);  expand_397 = None
    bmm_191 = torch.ops.aten.bmm.default(view_810, view_811);  view_810 = view_811 = None
    _unsafe_view_409 = torch.ops.aten._unsafe_view.default(bmm_191, [1, 8, 128, 256]);  bmm_191 = None
    transpose_245 = torch.ops.aten.transpose.int(_unsafe_view_409, 1, 2);  _unsafe_view_409 = None
    clone_41 = torch.ops.aten.clone.default(transpose_245, memory_format = torch.contiguous_format);  transpose_245 = None
    view_812 = torch.ops.aten.view.default(clone_41, [1, 128, -1]);  clone_41 = None
    sigmoid_23 = torch.ops.aten.sigmoid.default(_unsafe_view_403);  _unsafe_view_403 = None
    mul_503 = torch.ops.aten.mul.Tensor(view_812, sigmoid_23);  view_812 = sigmoid_23 = None
    _param_constant314 = self._param_constant314
    t_182 = torch.ops.aten.t.default(_param_constant314);  _param_constant314 = None
    view_813 = torch.ops.aten.view.default(mul_503, [128, 2048]);  mul_503 = None
    mm_182 = torch.ops.aten.mm.default(view_813, t_182);  view_813 = t_182 = None
    _unsafe_view_410 = torch.ops.aten._unsafe_view.default(mm_182, [1, 128, 2048]);  mm_182 = None
    add_327 = torch.ops.aten.add.Tensor(add_317, _unsafe_view_410);  add_317 = _unsafe_view_410 = None
    _to_copy_373 = torch.ops.aten._to_copy.default(add_327, dtype = torch.float32)
    pow_78 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_373, 2)
    mean_77 = torch.ops.aten.mean.dim(pow_78, [-1], True);  pow_78 = None
    add_328 = torch.ops.aten.add.Tensor(mean_77, 1e-06);  mean_77 = None
    rsqrt_113 = torch.ops.aten.rsqrt.default(add_328);  add_328 = None
    mul_504 = torch.ops.aten.mul.Tensor(_to_copy_373, rsqrt_113);  _to_copy_373 = rsqrt_113 = None
    _param_constant315 = self._param_constant315
    _to_copy_374 = torch.ops.aten._to_copy.default(_param_constant315, dtype = torch.float32);  _param_constant315 = None
    add_329 = torch.ops.aten.add.Tensor(_to_copy_374, 1.0);  _to_copy_374 = None
    mul_505 = torch.ops.aten.mul.Tensor(mul_504, add_329);  mul_504 = add_329 = None
    _to_copy_375 = torch.ops.aten._to_copy.default(mul_505, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_505 = None
    _param_constant316 = self._param_constant316
    t_183 = torch.ops.aten.t.default(_param_constant316);  _param_constant316 = None
    view_814 = torch.ops.aten.view.default(_to_copy_375, [128, 2048])
    mm_183 = torch.ops.aten.mm.default(view_814, t_183);  view_814 = t_183 = None
    _unsafe_view_411 = torch.ops.aten._unsafe_view.default(mm_183, [1, 128, 6144]);  mm_183 = None
    silu_59 = torch.ops.aten.silu.default(_unsafe_view_411);  _unsafe_view_411 = None
    _param_constant317 = self._param_constant317
    t_184 = torch.ops.aten.t.default(_param_constant317);  _param_constant317 = None
    view_815 = torch.ops.aten.view.default(_to_copy_375, [128, 2048]);  _to_copy_375 = None
    mm_184 = torch.ops.aten.mm.default(view_815, t_184);  view_815 = t_184 = None
    _unsafe_view_412 = torch.ops.aten._unsafe_view.default(mm_184, [1, 128, 6144]);  mm_184 = None
    mul_506 = torch.ops.aten.mul.Tensor(silu_59, _unsafe_view_412);  silu_59 = _unsafe_view_412 = None
    _param_constant318 = self._param_constant318
    t_185 = torch.ops.aten.t.default(_param_constant318);  _param_constant318 = None
    view_816 = torch.ops.aten.view.default(mul_506, [128, 6144]);  mul_506 = None
    mm_185 = torch.ops.aten.mm.default(view_816, t_185);  view_816 = t_185 = None
    _unsafe_view_413 = torch.ops.aten._unsafe_view.default(mm_185, [1, 128, 2048]);  mm_185 = None
    add_330 = torch.ops.aten.add.Tensor(add_327, _unsafe_view_413);  add_327 = _unsafe_view_413 = None
    _to_copy_376 = torch.ops.aten._to_copy.default(add_330, dtype = torch.float32);  add_330 = None
    pow_79 = torch.ops.aten.pow.Tensor_Scalar(_to_copy_376, 2)
    mean_78 = torch.ops.aten.mean.dim(pow_79, [-1], True);  pow_79 = None
    add_331 = torch.ops.aten.add.Tensor(mean_78, 1e-06);  mean_78 = None
    rsqrt_114 = torch.ops.aten.rsqrt.default(add_331);  add_331 = None
    mul_507 = torch.ops.aten.mul.Tensor(_to_copy_376, rsqrt_114);  _to_copy_376 = rsqrt_114 = None
    _param_constant319 = self._param_constant319
    _to_copy_377 = torch.ops.aten._to_copy.default(_param_constant319, dtype = torch.float32);  _param_constant319 = None
    add_332 = torch.ops.aten.add.Tensor(_to_copy_377, 1.0);  _to_copy_377 = None
    mul_508 = torch.ops.aten.mul.Tensor(mul_507, add_332);  mul_507 = add_332 = None
    _to_copy_378 = torch.ops.aten._to_copy.default(mul_508, dtype = torch.bfloat16, layout = torch.strided, device = device(type='meta'));  mul_508 = None
    alias_18 = torch.ops.aten.alias.default(_to_copy_378);  _to_copy_378 = None
    _param_constant0_1 = self._param_constant0
    t_186 = torch.ops.aten.t.default(_param_constant0_1);  _param_constant0_1 = None
    view_817 = torch.ops.aten.view.default(alias_18, [128, 2048]);  alias_18 = None
    mm_186 = torch.ops.aten.mm.default(view_817, t_186);  view_817 = t_186 = None
    _unsafe_view_414 = torch.ops.aten._unsafe_view.default(mm_186, [1, 128, 248320]);  mm_186 = None
    return _unsafe_view_414
    