    s.rdspecial  s1, arg_base
    s.rdspecial  s2, role_id
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.rdspecial  s4, npid.x
    s.ld.d       s5, [s1, #8]                    // out_ptr1: device_ptr64 at arg_base+8
__rctx_program:
    v.splat      v0, s2
    v.movi       v1, #0
    v.movi       v2, #0
    v.movi       v3, #63
    v.sub        v4, v1, v0
    v.sub        v5, v2, v0
    v.cmp.lt     p1, v0, v1
    v.cmp.lt     p2, v0, v2
    @p1 v.sel        v6, v4, v0
    @p2 v.sel        v4, v5, v0
    v.movi       v0, #6
    v.and        v5, v6, v3
    v.movi       v3, #320
    v.lshr       v6, v4, v0
    v.sub        v0, v1, v5
    v.iota       v4                              // arange(0, VLEN)
    v.sub        v7, v2, v6
    @p1 v.sel        v8, v0, v5
    v.movi       v0, #64
    @p2 v.sel        v5, v7, v6
    v.extract    s1, v8, #0
    v.mul        v6, v4, v0
    v.mul        v0, v5, v3
    v.splat      v3, s1
    v.movi       v5, #5
    v.extract    s1, v0, #0
    v.add        v0, v3, v6
    v.splat      v3, s1
    v.iota       v6                              // arange(0, VLEN)
    v.cmp.lt     p1, v4, v5
    v.add        v4, v0, v3
    v.cmpi.lt    p2, v6, #8
    p.and        p3, p2, p1
    v.movi       v0, #0
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v3, [s3, v4]               // index is in elements (ISA sec 9.1)
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v5, #0
    v.movi       v6, #64
    v.cmpi.lt    p2, v4, #8
    s.shli       s1, s2, #1                      // element offset -> bytes (x2)
    v.iota       v4                              // arange(0, VLEN)
    v.sub        v7, v1, v6
    v.sub        v8, v2, v6
    s.add        s6, s5, s1                      // &out_ptr1[...]
    v.cmp.lt     p3, v6, v1
    @p3 v.sel        v1, v7, v6
    v.cmp.lt     p3, v6, v2
    @p3 v.sel        v1, v8, v6
    v.cmpi.lt    p3, v4, #1
    vf.add       v1, v3, v0
    @p1 v.sel        v2, v1, v0
    @p2 vf.reduce.add.b v0, v2
    vf.add       v1, v0, v5
    vf.cvt.f32.f16 v0, v1
    @p3 v.st.h       [s6, #0], v0
__rctx_next:
    s.addi       s1, s2, #4                      // the next program of this context: + 4
    s.cmp.lt     s6, s1, s4
    s.mov        s2, s1
    br.nz        s6, __rctx_program
    exit
