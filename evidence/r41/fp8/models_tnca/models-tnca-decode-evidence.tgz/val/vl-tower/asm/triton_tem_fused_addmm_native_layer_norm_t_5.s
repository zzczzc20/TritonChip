    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, role_id
    s.movz       s2, #512
    s.rdspecial  s3, arg_base
    s.mul        s5, s1, s2
    s.ld.d       s1, [s3, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s2, arg_base
    s.rdspecial  s3, role_id
    s.movz       s6, #512
    s.add        s7, s1, s5                      // this context's own scratch
    s.ld.d       s1, [s2, #8]                    // arg_A: device_ptr64 at arg_base+8
    s.addi       s5, s7, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    .li       s7, #2147483647
    .li       s8, #2147483647
    s.movz       s9, #2048
    s.movz       s10, #2
    .li       s11, #68719476752
    .li       s12, #1108101562368
    s.rdspecial  s13, arg_base
    s.mul        s14, s3, s6
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    .li       s6, #2147483647
    .li       s15, #2147483647
    s.ld.d       s16, [s2, #16]                  // arg_B: device_ptr64 at arg_base+16
    s.movz       s17, #192
    s.movz       s18, #2048
    s.ld.d       s19, [s2, #24]                  // out_ptr0: device_ptr64 at arg_base+24
    s.movz       s2, #0
    s.movz       s20, #0
    s.movz       s21, #0
    s.movz       s22, #0
    s.cmp.lt     s23, s17, s21
    s.st.d       [s5, #0], s1
    s.sub        s1, s22, s23
    s.movz       s21, #2
    s.st.d       [s5, #8], s7
    .li       s7, #68719476752
    .li       s22, #1108101562368
    s.st.d       [s5, #16], s8
    s.xor        s8, s17, s1
    s.movz       s23, #0
    s.st.d       [s5, #48], s9
    .li       s9, #1431655766
    s.movz       s23, #0
    s.st.d       [s5, #56], s10
    s.cmp.lt     s10, s4, s2
    s.movz       s2, #16
    s.st.d       [s5, #88], s11
    s.sub        s11, s20, s10
    s.movz       s10, #1
    s.xor        s20, s4, s11
    s.st.d       [s5, #104], s12
    s.sub        s12, s20, s11
    s.movz       s20, #0
    fence.release.device
    s.mul        s23, s12, s9
    td.load      d0, [s5]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s5, #0
    s.ld.d       s9, [s13, #32]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.sub        s13, s8, s1
    s.lshri      s8, s23, #32
    s.movz       s13, #0
    s.add        s23, s9, s14                    // this context's own scratch
    s.sub        s9, s12, s8
    s.addi       s14, s23, #256                  // TensorMap 1: a tile contiguous down its columns (built once, at entry)
    s.lshri      s23, s9, #1
    s.xor        s9, s11, s1
    s.add        s1, s8, s23
    s.movz       s8, #0
    s.lshri      s11, s1, #7
    s.movz       s1, #0
    s.st.d       [s14, #0], s16
    s.xor        s16, s11, s9
    s.muli       s23, s11, #192
    s.sub        s11, s16, s9
    s.movz       s9, #1
    s.st.d       [s14, #8], s6
    s.sub        s6, s2, s11
    s.cmp.lt     s16, s4, s5
    s.min.s      s5, s6, s10
    s.st.d       [s14, #16], s15
    s.cmp.lt     s6, s5, s20
    s.sub        s15, s8, s16
    s.movz       s8, #0
    s.st.d       [s14, #48], s18
    s.sub        s16, s13, s6
    s.xor        s6, s4, s15
    s.st.d       [s14, #56], s21
    s.xor        s13, s5, s16
    s.sub        s18, s6, s15
    s.st.d       [s14, #88], s7
    s.sub        s6, s13, s16
    s.addi       s7, s1, #0
    s.st.d       [s14, #104], s22
    fence.release.device
    s.cmp.eq     s1, s6, s9
    td.load      d1, [s14]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.sub        s9, s12, s23
    s.addi       s9, s8, #0
    s.mov        s7, s18
    br.nz        s1, sdiv_done_1
    s.movz       s1, #0
    s.movz       s8, #31
    s.mov        s7, s1
    s.addi       s1, s8, #0
sdiv_2:
    s.lshr       s8, s18, s1
    s.shli       s12, s9, #1
    s.andi       s13, s8, #1
    s.movz       s8, #0
    s.or         s14, s12, s13
    s.movz       s12, #1
    s.cmp.geu    s13, s14, s6
    s.shl        s16, s12, s1
    s.sub        s12, s8, s13
    s.subi       s8, s1, #1
    s.and        s13, s6, s12
    s.and        s20, s16, s12
    s.sub        s12, s14, s13
    s.or         s13, s7, s20
    s.mov        s9, s12
    s.mov        s7, s13
    s.mov        s1, s8
    s.movz       s8, #0
    s.cmp.ge     s12, s1, s8
    br.nz        s12, sdiv_2
sdiv_done_1:
    s.movz       s1, #0
    s.movz       s6, #0
    s.cmp.lt     s7, s4, s1
    .li       s1, #1431655766
    s.sub        s8, s6, s7
    s.movz       s6, #0
    s.xor        s7, s4, s8
    s.movz       s4, #0
    s.sub        s12, s7, s8
    s.movz       s7, #0
    s.mul        s13, s12, s1
    s.cmp.lt     s1, s5, s6
    s.movz       s6, #0
    s.sub        s14, s7, s1
    s.movz       s1, #0
    s.lshri      s7, s13, #32
    s.cmp.lt     s13, s17, s6
    s.xor        s6, s5, s14
    s.xor        s5, s9, s15
    s.sub        s9, s6, s14
    s.sub        s6, s5, s15
    s.sub        s5, s12, s7
    s.add        s15, s11, s6
    s.lshri      s6, s5, #1
    s.movz       s5, #0
    s.add        s11, s7, s6
    s.sub        s6, s5, s13
    s.lshri      s5, s11, #7
    s.movz       s7, #0
    s.muli       s11, s5, #192
    s.movz       s5, #1
    s.xor        s13, s17, s6
    s.addi       s16, s7, #0
    s.cmp.eq     s7, s9, s5
    s.sub        s5, s12, s11
    s.movz       s11, #0
    s.xor        s12, s5, s8
    s.sub        s5, s13, s6
    s.sub        s5, s12, s8
    s.addi       s6, s11, #0
    s.cmp.lt     s8, s5, s4
    s.sub        s4, s1, s8
    s.xor        s1, s5, s4
    s.sub        s5, s1, s4
    s.mov        s16, s5
    br.nz        s7, sdiv_done_3
    s.movz       s1, #0
    s.movz       s7, #31
    s.mov        s16, s1
    s.addi       s1, s7, #0
sdiv_4:
    s.lshr       s7, s5, s1
    s.shli       s8, s6, #1
    s.andi       s11, s7, #1
    s.movz       s7, #0
    s.or         s12, s8, s11
    s.movz       s8, #1
    s.cmp.geu    s11, s12, s9
    s.shl        s13, s8, s1
    s.sub        s8, s7, s11
    s.subi       s7, s1, #1
    s.and        s11, s9, s8
    s.and        s17, s13, s8
    s.sub        s8, s12, s11
    s.or         s11, s16, s17
    s.mov        s6, s8
    s.mov        s16, s11
    s.mov        s1, s7
    s.movz       s7, #0
    s.cmp.ge     s8, s1, s7
    br.nz        s8, sdiv_4
sdiv_done_3:
    s.xor        s1, s4, s14
    .li       s4, #1431655766
    s.xor        s5, s16, s1
    s.mul        s6, s15, s2
    s.sub        s7, s5, s1
    s.movz       s1, #0
    s.mul        s5, s7, s2
    v.splat      v0, s15
    s.andi       s8, s6, #255
    v.splat      v1, s1
    v.splat      v2, s7
    s.mul        s7, s5, s4
    v.splat      v3, s1
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s6
    v.cmp.ge     p1, v0, v1
    s.lshri      s4, s7, #32
    v.splat      v0, s5
    s.sub        s7, s5, s4
    v.splat      v1, s8
    s.lshri      s9, s7, #1
    v.cmp.ge     p1, v2, v3
    s.add        s7, s4, s9
    v.iota       v2                              // arange(0, VLEN)
    s.lshri      s4, s7, #11
    v.iota       v3                              // arange(0, VLEN)
    s.muli       s7, s4, #3072
    v.add        v6, v5, v4
    v.add        v5, v0, v4
    v.add        v0, v1, v2
    s.movz       s4, #64
    s.sub        s9, s5, s7
    s.addi       s7, s1, #0
    v.splat      v0, s9
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    v.add        v1, v0, v3
for_5:
    s.cmp.ge     s1, s7, s4
    br.nz        s1, endfor_6
    s.mul        s1, s7, s2
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s11, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s12, s7, s10
    s.movz       s13, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s14, s8                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s1                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s14, s11
    mb.wait      s11
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s14, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s15, s9                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s16, s1                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s15, s14
    mb.wait      s14
    mb.arm       s1, b2, #0, #1                  // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.bf16 a0, v56, v48, s1
    mb.wait      s1
    s.mov        s7, s12
    br.nz        s13, for_5
endfor_6:
    s.movz       s2, #0
    s.movz       s4, #0
    s.add        s7, s2, s5                      // the tile origin
    s.muli       s2, s5, #2                      // a runtime tile origin, x2
    s.add        s8, s4, s6                      // the tile origin
    s.movz       s4, #256
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s7
    s.movz       s7, #3072
    v.splat      v2, s8
    v.splat      v3, s4
    v.add        v4, v0, v1
    v.splat      v0, s7
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v4, v0
    s.add        s4, s3, s2                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s2, #0
    p.and        p3, p1, p2
    a.vread      v0, a0, s2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s4, #0]
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s2, s5, #2                      // a runtime tile origin, x2
    s.muli       s3, s6, #6144                   // a runtime tile origin, x6144
    s.addi       s5, s8, #1
    v.splat      v2, s8
    v.splat      v4, s5
    vf.cvt.bf16.f32 v5, v1
    s.add        s5, s19, s2                     // the tile origin
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p3, v4, v3
    vf.add       v1, v0, v5
    s.add        s2, s5, s3                      // the tile origin
    p.and        p4, p1, p2
    s.movz       s3, #1
    vf.cvt.f32.bf16 v0, v1
    p.and        p1, p3, p2
    s.addi       s5, s8, #1
    s.addi       s6, s8, #2
    @p4 v.st.h       [s2, #0], v0
    a.vread      v0, a0, s3
    v.splat      v1, s5
    v.splat      v2, s6
    v.cmp.lt     p3, v1, v3
    s.addi       s3, s2, #6144                   // row 1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s4, #0]
    v.cmp.lt     p1, v2, v3
    p.and        p4, p3, p2
    s.movz       s5, #2
    p.and        p3, p1, p2
    s.addi       s6, s8, #2
    vf.cvt.bf16.f32 v2, v1
    s.addi       s7, s8, #3
    v.splat      v1, s6
    v.splat      v4, s7
    vf.add       v5, v0, v2
    s.addi       s6, s2, #12288                  // row 2
    s.movz       s7, #3
    s.addi       s9, s8, #3
    vf.cvt.f32.bf16 v0, v5
    s.addi       s10, s8, #4
    v.splat      v2, s9
    v.splat      v5, s10
    @p4 v.st.h       [s3, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s3, s2, #18432                  // row 3
    s.movz       s5, #4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s4, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    s.addi       s9, s8, #4
    s.addi       s10, s8, #5
    v.splat      v4, s9
    vf.cvt.bf16.f32 v6, v1
    v.splat      v1, s10
    s.addi       s9, s2, #24576                  // row 4
    s.movz       s10, #5
    vf.add       v7, v0, v6
    vf.cvt.f32.bf16 v0, v7
    @p4 v.st.h       [s6, #0], v0
    a.vread      v0, a0, s7
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.addi       s6, s8, #5
    s.addi       s7, s8, #6
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s4, #0]
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    v.splat      v5, s6
    v.splat      v6, s7
    s.addi       s6, s2, #30720                  // row 5
    vf.cvt.bf16.f32 v7, v2
    s.movz       s7, #6
    vf.add       v2, v0, v7
    vf.cvt.f32.bf16 v0, v2
    @p4 v.st.h       [s3, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    s.addi       s3, s8, #6
    s.addi       s5, s8, #7
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s4, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    v.splat      v1, s3
    v.splat      v4, s5
    s.movz       s3, #36864
    vf.cvt.bf16.f32 v7, v2
    s.add        s5, s2, s3                      // row 6
    s.movz       s3, #7
    vf.add       v2, v0, v7
    vf.cvt.f32.bf16 v0, v2
    @p4 v.st.h       [s9, #0], v0
    a.vread      v0, a0, s10
    v.cmp.lt     p1, v5, v3
    p.and        p4, p1, p2
    s.addi       s9, s8, #7
    s.addi       s10, s8, #8
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s4, #0]
    v.cmp.lt     p1, v6, v3
    p.and        p3, p1, p2
    v.splat      v5, s9
    v.splat      v6, s10
    s.movz       s9, #43008
    vf.cvt.bf16.f32 v7, v2
    s.add        s10, s2, s9                     // row 7
    s.movz       s9, #8
    vf.add       v2, v0, v7
    vf.cvt.f32.bf16 v0, v2
    @p4 v.st.h       [s6, #0], v0
    a.vread      v0, a0, s7
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s6, s8, #8
    s.addi       s7, s8, #9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s4, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    v.splat      v2, s6
    v.splat      v4, s7
    s.movz       s6, #49152
    vf.cvt.bf16.f32 v7, v1
    s.add        s7, s2, s6                      // row 8
    s.movz       s6, #9
    vf.add       v1, v0, v7
    vf.cvt.f32.bf16 v0, v1
    @p4 v.st.h       [s5, #0], v0
    a.vread      v0, a0, s3
    v.cmp.lt     p1, v5, v3
    p.and        p4, p1, p2
    s.addi       s3, s8, #9
    s.addi       s5, s8, #10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s4, #0]
    v.cmp.lt     p1, v6, v3
    p.and        p3, p1, p2
    v.splat      v5, s3
    v.splat      v6, s5
    s.movz       s3, #55296
    vf.cvt.bf16.f32 v7, v1
    s.add        s5, s2, s3                      // row 9
    s.movz       s3, #10
    vf.add       v1, v0, v7
    vf.cvt.f32.bf16 v0, v1
    @p4 v.st.h       [s10, #0], v0
    a.vread      v0, a0, s9
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.addi       s9, s8, #10
    s.addi       s10, s8, #11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s4, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    v.splat      v2, s9
    v.splat      v4, s10
    s.movz       s9, #61440
    vf.cvt.bf16.f32 v7, v1
    s.add        s10, s2, s9                     // row 10
    s.movz       s9, #11
    vf.add       v1, v0, v7
    vf.cvt.f32.bf16 v0, v1
    @p4 v.st.h       [s7, #0], v0
    a.vread      v0, a0, s6
    v.cmp.lt     p1, v5, v3
    p.and        p4, p1, p2
    s.addi       s6, s8, #11
    s.addi       s7, s8, #12
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s4, #0]
    v.cmp.lt     p1, v6, v3
    p.and        p3, p1, p2
    v.splat      v5, s6
    v.splat      v6, s7
    .li       s6, #67584
    vf.cvt.bf16.f32 v7, v1
    s.add        s7, s2, s6                      // row 11
    s.movz       s6, #12
    vf.add       v1, v0, v7
    vf.cvt.f32.bf16 v0, v1
    @p4 v.st.h       [s5, #0], v0
    a.vread      v0, a0, s3
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.addi       s3, s8, #12
    s.addi       s5, s8, #13
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s4, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    v.splat      v2, s3
    v.splat      v4, s5
    .li       s3, #73728
    vf.cvt.bf16.f32 v7, v1
    s.add        s5, s2, s3                      // row 12
    s.movz       s3, #13
    vf.add       v1, v0, v7
    vf.cvt.f32.bf16 v0, v1
    @p4 v.st.h       [s10, #0], v0
    a.vread      v0, a0, s9
    v.cmp.lt     p1, v5, v3
    p.and        p4, p1, p2
    s.addi       s9, s8, #13
    s.addi       s10, s8, #14
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s4, #0]
    v.cmp.lt     p1, v6, v3
    p.and        p3, p1, p2
    v.splat      v5, s9
    v.splat      v6, s10
    .li       s9, #79872
    vf.cvt.bf16.f32 v7, v1
    s.add        s10, s2, s9                     // row 13
    s.movz       s9, #14
    vf.add       v1, v0, v7
    vf.cvt.f32.bf16 v0, v1
    @p4 v.st.h       [s7, #0], v0
    a.vread      v0, a0, s6
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.addi       s6, s8, #14
    s.addi       s7, s8, #15
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s4, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    v.splat      v2, s6
    v.splat      v4, s7
    .li       s6, #86016
    vf.cvt.bf16.f32 v7, v1
    s.add        s7, s2, s6                      // row 14
    s.movz       s6, #15
    vf.add       v1, v0, v7
    vf.cvt.f32.bf16 v0, v1
    s.addi       s12, s8, #15
    @p4 v.st.h       [s5, #0], v0
    a.vread      v0, a0, s3
    v.cmp.lt     p1, v5, v3
    p.and        p4, p1, p2
    v.splat      v1, s12
    .li       s3, #92160
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v5, [s4, #0]
    v.cmp.lt     p1, v6, v3
    p.and        p3, p1, p2
    s.add        s5, s2, s3                      // row 15
    vf.cvt.bf16.f32 v6, v5
    vf.add       v5, v0, v6
    vf.cvt.f32.bf16 v0, v5
    @p4 v.st.h       [s10, #0], v0
    a.vread      v0, a0, s9
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s4, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v0, v4
    vf.cvt.f32.bf16 v0, v2
    @p4 v.st.h       [s7, #0], v0
    a.vread      v0, a0, s6
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s4, #0]
    vf.cvt.bf16.f32 v2, v1
    vf.add       v1, v0, v2
    vf.cvt.f32.bf16 v0, v1
    @p4 v.st.h       [s5, #0], v0
__rctx_next:
    exit
