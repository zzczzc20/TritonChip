    s.rdspecial  s1, arg_base
    s.movz       s2, #16
    s.ld.d       s3, [s1, #0]                    // x_ptr: device_ptr64 at arg_base+0
    s.movz       s4, #32
    s.movz       s5, #48
    s.movz       s6, #64
    s.movz       s7, #80
    s.movz       s8, #96
    s.movz       s9, #112
    s.rdspecial  s10, role_id
    s.rdspecial  s11, npid.x
    s.ld.d       s12, [s1, #8]                   // y_ptr: device_ptr64 at arg_base+8
    s.ld.d       s13, [s1, #16]                  // s_ptr: device_ptr64 at arg_base+16
__rctx_program:
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #16
    v.add        v2, v0, v1
    v.movi       v1, #32
    v.add        v3, v0, v1
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v4, #48
    v.add        v5, v1, v4
    v.movi       v4, #64
    v.add        v6, v1, v4
    v.movi       v4, #80
    v.add        v7, v1, v4
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v4, #96
    v.add        v8, v1, v4
    v.movi       v4, #112
    v.add        v9, v1, v4
    s.shli       s1, s10, #7                     // x128 as a shift
    v.splat      v1, s1
    v.add        v4, v1, v0
    v.add        v4, v1, v2
    s.add        s14, s2, s1
    v.add        v4, v1, v3
    s.add        s15, s4, s1
    v.add        v4, v1, v5
    s.add        s16, s5, s1
    v.add        v4, v1, v6
    s.add        s17, s6, s1
    v.add        v4, v1, v7
    s.add        s18, s7, s1
    v.add        v4, v1, v8
    s.add        s19, s8, s1
    v.add        v4, v1, v9
    s.add        s20, s9, s1
    v.movi       v1, #128
    v.cmp.lt     p1, v0, v1
    s.shli       s21, s1, #1                     // element offset -> bytes (x2)
    s.add        s22, s3, s21                    // &x_ptr[...]
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s22, #0]
    v.cmp.lt     p1, v2, v1
    s.shli       s21, s14, #1                    // element offset -> bytes (x2)
    s.add        s22, s3, s21                    // &x_ptr[...]
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v10, [s22, #0]
    v.movi       v11, #128
    v.cmp.lt     p1, v3, v11
    s.shli       s21, s15, #1                    // element offset -> bytes (x2)
    s.add        s22, s3, s21                    // &x_ptr[...]
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s22, #0]
    v.cmp.lt     p1, v5, v11
    s.shli       s21, s16, #1                    // element offset -> bytes (x2)
    s.add        s22, s3, s21                    // &x_ptr[...]
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s22, #0]
    v.movi       v14, #128
    v.cmp.lt     p1, v6, v14
    s.shli       s21, s17, #1                    // element offset -> bytes (x2)
    s.add        s22, s3, s21                    // &x_ptr[...]
    v.movi       v15, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v15, [s22, #0]
    v.cmp.lt     p1, v7, v14
    s.shli       s21, s18, #1                    // element offset -> bytes (x2)
    s.add        s22, s3, s21                    // &x_ptr[...]
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v16, [s22, #0]
    v.movi       v17, #128
    v.cmp.lt     p1, v8, v17
    s.shli       s21, s19, #1                    // element offset -> bytes (x2)
    s.add        s22, s3, s21                    // &x_ptr[...]
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v18, [s22, #0]
    v.cmp.lt     p1, v9, v17
    s.shli       s21, s20, #1                    // element offset -> bytes (x2)
    s.add        s22, s3, s21                    // &x_ptr[...]
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v19, [s22, #0]
    vf.cvt.f16.f32 v20, v4
    vf.cvt.f16.f32 v4, v10
    vf.cvt.f16.f32 v10, v12
    vf.cvt.f16.f32 v12, v13
    vf.cvt.f16.f32 v13, v15
    vf.cvt.f16.f32 v15, v16
    vf.cvt.f16.f32 v16, v18
    vf.cvt.f16.f32 v18, v19
    vf.abs       v19, v20
    vf.abs       v21, v4
    vf.abs       v22, v10
    vf.abs       v23, v12
    vf.abs       v24, v13
    vf.abs       v25, v15
    vf.abs       v26, v16
    vf.abs       v27, v18
    vf.reduce.max.b v28, v19
    vf.reduce.max.b v19, v21
    vf.reduce.max.b v21, v22
    vf.reduce.max.b v22, v23
    vf.reduce.max.b v23, v24
    vf.reduce.max.b v24, v25
    vf.reduce.max.b v25, v26
    vf.reduce.max.b v26, v27
    vf.max       v27, v28, v19
    vf.max       v19, v21, v22
    vf.max       v21, v23, v24
    vf.max       v22, v25, v26
    vf.max       v23, v27, v19
    vf.max       v19, v21, v22
    vf.max       v21, v23, v19
    .li       s21, #1138753536
    v.splat      v19, s21                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v22, v19                        // ISA 8.8: <= 2**-22 relative
    .li       s21, #1065353216
    v.splat      v23, s21                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v24, v19, v22, v23
    vf.fms       v19, v22, v24, v22
    vf.neg       v24, v19                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v24, v24
    @p1 v.sel        v19, v24, v22
    vf.mul       v22, v21, v19                   // a/y as a refined reciprocal (ISA has no divide)
    .li       s21, #730643660
    v.splat      v19, s21                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.max.ieee  v21, v22, v19
    v.rcp.approx v19, v21                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v24, v21, v19, v23
    vf.fms       v25, v19, v24, v19
    vf.neg       v24, v25                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v24, v24
    @p1 v.sel        v25, v24, v19
    vf.mul       v19, v20, v25                   // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v20, v4, v25                    // a/y as a refined reciprocal (ISA has no divide)
    v.rcp.approx v4, v21                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v24, v21, v4, v23
    vf.fms       v25, v4, v24, v4
    vf.neg       v24, v25                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v24, v24
    @p1 v.sel        v25, v24, v4
    vf.mul       v4, v10, v25                    // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v10, v12, v25                   // a/y as a refined reciprocal (ISA has no divide)
    v.rcp.approx v12, v21                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v24, v21, v12, v23
    vf.fms       v25, v12, v24, v12
    vf.neg       v24, v25                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v24, v24
    @p1 v.sel        v25, v24, v12
    vf.mul       v12, v13, v25                   // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v13, v15, v25                   // a/y as a refined reciprocal (ISA has no divide)
    v.rcp.approx v15, v21                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v24, v21, v15, v23
    vf.fms       v21, v15, v24, v15
    vf.neg       v23, v21                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v23, v23
    @p1 v.sel        v21, v23, v15
    vf.mul       v15, v16, v21                   // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v16, v18, v21                   // a/y as a refined reciprocal (ISA has no divide)
    vf.cvt.f32.e4m3 v18, v19
    v.cmpi.lt    p1, v19, #0
    @p1 v.ori        v18, v18, #128              // a NaN keeps its sign
    vf.cvt.f32.e4m3 v19, v20
    v.cmpi.lt    p1, v20, #0
    @p1 v.ori        v19, v19, #128              // a NaN keeps its sign
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    vf.cvt.f32.e4m3 v4, v10
    v.cmpi.lt    p1, v10, #0
    @p1 v.ori        v4, v4, #128                // a NaN keeps its sign
    vf.cvt.f32.e4m3 v10, v12
    v.cmpi.lt    p1, v12, #0
    @p1 v.ori        v10, v10, #128              // a NaN keeps its sign
    vf.cvt.f32.e4m3 v12, v13
    v.cmpi.lt    p1, v13, #0
    @p1 v.ori        v12, v12, #128              // a NaN keeps its sign
    vf.cvt.f32.e4m3 v13, v15
    v.cmpi.lt    p1, v15, #0
    @p1 v.ori        v13, v13, #128              // a NaN keeps its sign
    vf.cvt.f32.e4m3 v15, v16
    v.cmpi.lt    p1, v16, #0
    @p1 v.ori        v15, v15, #128              // a NaN keeps its sign
    v.cmp.lt     p1, v0, v1
    s.shli       s21, s1, #0                     // element offset -> bytes (x1)
    s.add        s1, s12, s21                    // &y_ptr[...]
    @p1 v.st.b       [s1, #0], v18
    v.cmp.lt     p1, v2, v1
    s.shli       s1, s14, #0                     // element offset -> bytes (x1)
    s.add        s14, s12, s1                    // &y_ptr[...]
    @p1 v.st.b       [s14, #0], v19
    v.cmp.lt     p1, v3, v11
    s.shli       s1, s15, #0                     // element offset -> bytes (x1)
    s.add        s14, s12, s1                    // &y_ptr[...]
    @p1 v.st.b       [s14, #0], v20
    v.cmp.lt     p1, v5, v11
    s.shli       s1, s16, #0                     // element offset -> bytes (x1)
    s.add        s14, s12, s1                    // &y_ptr[...]
    @p1 v.st.b       [s14, #0], v4
    v.cmp.lt     p1, v6, v14
    s.shli       s1, s17, #0                     // element offset -> bytes (x1)
    s.add        s14, s12, s1                    // &y_ptr[...]
    @p1 v.st.b       [s14, #0], v10
    v.cmp.lt     p1, v7, v14
    s.shli       s1, s18, #0                     // element offset -> bytes (x1)
    s.add        s14, s12, s1                    // &y_ptr[...]
    @p1 v.st.b       [s14, #0], v12
    v.cmp.lt     p1, v8, v17
    s.shli       s1, s19, #0                     // element offset -> bytes (x1)
    s.add        s14, s12, s1                    // &y_ptr[...]
    @p1 v.st.b       [s14, #0], v13
    v.cmp.lt     p1, v9, v17
    s.shli       s1, s20, #0                     // element offset -> bytes (x1)
    s.add        s14, s12, s1                    // &y_ptr[...]
    @p1 v.st.b       [s14, #0], v15
    s.shli       s1, s10, #2                     // element offset -> bytes (x4)
    s.add        s14, s13, s1                    // &s_ptr[...]
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p1, v0, #1
    @p1 v.st.w       [s14, #0], v22
__rctx_next:
    s.addi       s1, s10, #4                     // the next program of this context: + 4
    s.cmp.lt     s14, s1, s11
    s.mov        s10, s1
    br.nz        s14, __rctx_program
    exit
