    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    s.rdspecial  s2, pid.y
    s.mul        s3, s4, s1
    s.mul        s4, s2, s1
    s.rdspecial  s1, role_id
    s.movz       s2, #1024
    s.movz       s5, #0
    s.rdspecial  s6, arg_base
    s.rdspecial  s7, arg_base
    s.mul        s8, s1, s2
    s.muli       s1, s3, #4                      // a runtime tile origin, x4
    s.add        s2, s5, s4                      // the tile origin
    s.movz       s5, #24
    s.ld.d       s9, [s6, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.muli       s10, s4, #36                    // a runtime tile origin, x36
    v.splat      v0, s2
    s.ld.d       s4, [s7, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.splat      v1, s5
    v.movi       v2, #0
    s.add        s5, s4, s8                      // this context's own scratch
    s.movz       s4, #0
    s.add        s7, s9, s1                      // the tile origin
    v.sub        v3, v2, v0
    v.sub        v4, v2, v1
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    s.ld.d       s1, [s6, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.addi       s6, s5, #0
    v.iota       v5                              // arange(0, VLEN)
    s.add        s8, s7, s10                     // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    v.splat      v5, s4
    v.movi       v6, #1
    @p1 v.sel        v7, v3, v0
    @p2 v.sel        v0, v4, v1
    v.movi       v3, #0
    v.movi       v4, #0
    s.movz       s4, #31
idiv_1:
    v.splat      v8, s4
    v.shl        v9, v4, v6
    v.lshr       v10, v7, v8
    v.cmp.lt     p2, v4, v2
    v.and        v11, v10, v6
    v.shl        v10, v6, v8
    v.or         v8, v9, v11
    s.subi       s7, s4, #1
    v.cmp.geu    p3, v8, v0
    p.or         p4, p2, p3
    v.sub        v9, v8, v0
    @p4 v.sel        v11, v10, v2
    @p4 v.sel        v10, v9, v8
    v.or         v8, v3, v11
    v.mov        v4, v10
    v.mov        v3, v8
    s.mov        s4, s7
    s.movz       s7, #0
    s.cmp.ge     s9, s4, s7
    br.nz        s9, idiv_1
    s.muli       s4, s3, #24                     // a runtime tile origin, x24
    s.movz       s7, #0
    s.movz       s9, #24
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v3, s9
    s.add        s9, s7, s4                      // the tile origin
    v.sub        v6, v2, v4
    v.mul        v2, v0, v3
    v.splat      v0, s9
    v.splat      v3, s2
    v.movi       v7, #0
    @p1 v.sel        v8, v6, v4
    v.add        v4, v2, v0
    v.sub        v0, v7, v3
    v.sub        v2, v7, v1
    v.cmp.lt     p1, v3, v7
    v.cmp.lt     p2, v1, v7
    v.add        v6, v8, v4
    v.movi       v8, #1
    @p1 v.sel        v9, v0, v3
    @p2 v.sel        v0, v2, v1
    v.movi       v2, #0
    v.movi       v3, #0
    s.movz       s4, #31
idiv_2:
    v.splat      v10, s4
    v.shl        v11, v3, v8
    v.lshr       v12, v9, v10
    v.cmp.lt     p3, v3, v7
    v.and        v13, v12, v8
    v.shl        v12, v8, v10
    v.or         v10, v11, v13
    s.subi       s7, s4, #1
    v.cmp.geu    p4, v10, v0
    p.or         p5, p3, p4
    v.sub        v11, v10, v0
    @p5 v.sel        v13, v12, v7
    @p5 v.sel        v12, v11, v10
    v.or         v10, v2, v13
    v.mov        v3, v12
    v.mov        v2, v10
    s.mov        s4, s7
    s.movz       s7, #0
    s.cmp.ge     s9, s4, s7
    br.nz        s9, idiv_2
    p.xor        p3, p1, p2
    v.sub        v0, v7, v2
    s.movz       s4, #216
    @p3 v.sel        v3, v0, v2
    v.splat      v0, s4
    s.addi       s4, s2, #1
    v.mul        v2, v3, v0
    v.splat      v3, s4
    v.add        v7, v6, v2
    v.movi       v2, #0
    v.add        v6, v5, v7
    v.sub        v7, v2, v3
    v.sub        v8, v2, v1
    v.cmp.lt     p1, v3, v2
    v.cmp.lt     p2, v1, v2
    v.st.w       [s6, #0], v6
    s.addi       s4, s6, #64
    v.movi       v6, #1
    @p1 v.sel        v9, v7, v3
    @p2 v.sel        v3, v8, v1
    v.movi       v7, #0
    v.movi       v8, #0
    s.movz       s7, #31
idiv_3:
    v.splat      v10, s7
    v.shl        v11, v8, v6
    v.lshr       v12, v9, v10
    v.cmp.lt     p2, v8, v2
    v.and        v13, v12, v6
    v.shl        v12, v6, v10
    v.or         v10, v11, v13
    s.subi       s9, s7, #1
    v.cmp.geu    p3, v10, v3
    p.or         p4, p2, p3
    v.sub        v11, v10, v3
    @p4 v.sel        v13, v12, v2
    @p4 v.sel        v12, v11, v10
    v.or         v10, v7, v13
    v.mov        v8, v12
    v.mov        v7, v10
    s.mov        s7, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s7, s9
    br.nz        s10, idiv_3
    s.addi       s7, s2, #1
    v.sub        v3, v2, v8
    v.splat      v2, s7
    v.movi       v6, #0
    @p1 v.sel        v7, v3, v8
    v.sub        v3, v6, v2
    v.sub        v8, v6, v1
    v.cmp.lt     p1, v2, v6
    v.cmp.lt     p2, v1, v6
    v.add        v9, v7, v4
    v.movi       v7, #1
    @p1 v.sel        v10, v3, v2
    @p2 v.sel        v2, v8, v1
    v.movi       v3, #0
    v.movi       v8, #0
    s.movz       s7, #31
idiv_4:
    v.splat      v11, s7
    v.shl        v12, v8, v7
    v.lshr       v13, v10, v11
    v.cmp.lt     p3, v8, v6
    v.and        v14, v13, v7
    v.shl        v13, v7, v11
    v.or         v11, v12, v14
    s.subi       s9, s7, #1
    v.cmp.geu    p4, v11, v2
    p.or         p5, p3, p4
    v.sub        v12, v11, v2
    @p5 v.sel        v14, v13, v6
    @p5 v.sel        v13, v12, v11
    v.or         v11, v3, v14
    v.mov        v8, v13
    v.mov        v3, v11
    s.mov        s7, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s7, s9
    br.nz        s10, idiv_4
    p.xor        p3, p1, p2
    v.sub        v2, v6, v3
    s.addi       s7, s2, #2
    @p3 v.sel        v6, v2, v3
    v.splat      v2, s7
    v.mul        v3, v6, v0
    v.movi       v6, #0
    v.add        v7, v9, v3
    v.sub        v3, v6, v2
    v.add        v8, v5, v7
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v2, v6
    v.cmp.lt     p2, v1, v6
    v.st.w       [s4, #0], v8
    s.addi       s4, s6, #128
    v.movi       v8, #1
    @p1 v.sel        v9, v3, v2
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s7, #31
idiv_5:
    v.splat      v10, s7
    v.shl        v11, v7, v8
    v.lshr       v12, v9, v10
    v.cmp.lt     p2, v7, v6
    v.and        v13, v12, v8
    v.shl        v12, v8, v10
    v.or         v10, v11, v13
    s.subi       s9, s7, #1
    v.cmp.geu    p3, v10, v2
    p.or         p4, p2, p3
    v.sub        v11, v10, v2
    @p4 v.sel        v13, v12, v6
    @p4 v.sel        v12, v11, v10
    v.or         v10, v3, v13
    v.mov        v7, v12
    v.mov        v3, v10
    s.mov        s7, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s7, s9
    br.nz        s10, idiv_5
    s.addi       s7, s2, #2
    v.sub        v2, v6, v7
    v.splat      v3, s7
    v.movi       v6, #0
    @p1 v.sel        v8, v2, v7
    v.sub        v2, v6, v3
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v1, v6
    v.add        v9, v8, v4
    v.movi       v8, #1
    @p1 v.sel        v10, v2, v3
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s7, #31
idiv_6:
    v.splat      v11, s7
    v.shl        v12, v7, v8
    v.lshr       v13, v10, v11
    v.cmp.lt     p3, v7, v6
    v.and        v14, v13, v8
    v.shl        v13, v8, v11
    v.or         v11, v12, v14
    s.subi       s9, s7, #1
    v.cmp.geu    p4, v11, v2
    p.or         p5, p3, p4
    v.sub        v12, v11, v2
    @p5 v.sel        v14, v13, v6
    @p5 v.sel        v13, v12, v11
    v.or         v11, v3, v14
    v.mov        v7, v13
    v.mov        v3, v11
    s.mov        s7, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s7, s9
    br.nz        s10, idiv_6
    p.xor        p3, p1, p2
    v.sub        v2, v6, v3
    s.addi       s7, s2, #3
    @p3 v.sel        v6, v2, v3
    v.splat      v2, s7
    v.mul        v3, v6, v0
    v.movi       v6, #0
    v.add        v7, v9, v3
    v.sub        v3, v6, v2
    v.add        v8, v5, v7
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v2, v6
    v.cmp.lt     p2, v1, v6
    v.st.w       [s4, #0], v8
    s.addi       s4, s6, #192
    v.movi       v8, #1
    @p1 v.sel        v9, v3, v2
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s7, #31
idiv_7:
    v.splat      v10, s7
    v.shl        v11, v7, v8
    v.lshr       v12, v9, v10
    v.cmp.lt     p2, v7, v6
    v.and        v13, v12, v8
    v.shl        v12, v8, v10
    v.or         v10, v11, v13
    s.subi       s9, s7, #1
    v.cmp.geu    p3, v10, v2
    p.or         p4, p2, p3
    v.sub        v11, v10, v2
    @p4 v.sel        v13, v12, v6
    @p4 v.sel        v12, v11, v10
    v.or         v10, v3, v13
    v.mov        v7, v12
    v.mov        v3, v10
    s.mov        s7, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s7, s9
    br.nz        s10, idiv_7
    s.addi       s7, s2, #3
    v.sub        v2, v6, v7
    v.splat      v3, s7
    v.movi       v6, #0
    @p1 v.sel        v8, v2, v7
    v.sub        v2, v6, v3
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v1, v6
    v.add        v9, v8, v4
    v.movi       v8, #1
    @p1 v.sel        v10, v2, v3
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s7, #31
idiv_8:
    v.splat      v11, s7
    v.shl        v12, v7, v8
    v.lshr       v13, v10, v11
    v.cmp.lt     p3, v7, v6
    v.and        v14, v13, v8
    v.shl        v13, v8, v11
    v.or         v11, v12, v14
    s.subi       s9, s7, #1
    v.cmp.geu    p4, v11, v2
    p.or         p5, p3, p4
    v.sub        v12, v11, v2
    @p5 v.sel        v14, v13, v6
    @p5 v.sel        v13, v12, v11
    v.or         v11, v3, v14
    v.mov        v7, v13
    v.mov        v3, v11
    s.mov        s7, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s7, s9
    br.nz        s10, idiv_8
    p.xor        p3, p1, p2
    v.sub        v2, v6, v3
    s.addi       s7, s2, #4
    @p3 v.sel        v6, v2, v3
    v.splat      v2, s7
    v.mul        v3, v6, v0
    v.movi       v6, #0
    v.add        v7, v9, v3
    v.sub        v3, v6, v2
    v.add        v8, v5, v7
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v2, v6
    v.cmp.lt     p2, v1, v6
    v.st.w       [s4, #0], v8
    s.addi       s4, s6, #256
    v.movi       v8, #1
    @p1 v.sel        v9, v3, v2
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s7, #31
idiv_9:
    v.splat      v10, s7
    v.shl        v11, v7, v8
    v.lshr       v12, v9, v10
    v.cmp.lt     p2, v7, v6
    v.and        v13, v12, v8
    v.shl        v12, v8, v10
    v.or         v10, v11, v13
    s.subi       s9, s7, #1
    v.cmp.geu    p3, v10, v2
    p.or         p4, p2, p3
    v.sub        v11, v10, v2
    @p4 v.sel        v13, v12, v6
    @p4 v.sel        v12, v11, v10
    v.or         v10, v3, v13
    v.mov        v7, v12
    v.mov        v3, v10
    s.mov        s7, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s7, s9
    br.nz        s10, idiv_9
    s.addi       s7, s2, #4
    v.sub        v2, v6, v7
    v.splat      v3, s7
    v.movi       v6, #0
    @p1 v.sel        v8, v2, v7
    v.sub        v2, v6, v3
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v1, v6
    v.add        v9, v8, v4
    v.movi       v8, #1
    @p1 v.sel        v10, v2, v3
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s7, #31
idiv_10:
    v.splat      v11, s7
    v.shl        v12, v7, v8
    v.lshr       v13, v10, v11
    v.cmp.lt     p3, v7, v6
    v.and        v14, v13, v8
    v.shl        v13, v8, v11
    v.or         v11, v12, v14
    s.subi       s9, s7, #1
    v.cmp.geu    p4, v11, v2
    p.or         p5, p3, p4
    v.sub        v12, v11, v2
    @p5 v.sel        v14, v13, v6
    @p5 v.sel        v13, v12, v11
    v.or         v11, v3, v14
    v.mov        v7, v13
    v.mov        v3, v11
    s.mov        s7, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s7, s9
    br.nz        s10, idiv_10
    p.xor        p3, p1, p2
    v.sub        v2, v6, v3
    s.addi       s7, s2, #5
    @p3 v.sel        v6, v2, v3
    v.splat      v2, s7
    v.mul        v3, v6, v0
    v.movi       v6, #0
    v.add        v7, v9, v3
    v.sub        v3, v6, v2
    v.add        v8, v5, v7
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v2, v6
    v.cmp.lt     p2, v1, v6
    v.st.w       [s4, #0], v8
    s.addi       s4, s6, #320
    v.movi       v8, #1
    @p1 v.sel        v9, v3, v2
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s7, #31
idiv_11:
    v.splat      v10, s7
    v.shl        v11, v7, v8
    v.lshr       v12, v9, v10
    v.cmp.lt     p2, v7, v6
    v.and        v13, v12, v8
    v.shl        v12, v8, v10
    v.or         v10, v11, v13
    s.subi       s9, s7, #1
    v.cmp.geu    p3, v10, v2
    p.or         p4, p2, p3
    v.sub        v11, v10, v2
    @p4 v.sel        v13, v12, v6
    @p4 v.sel        v12, v11, v10
    v.or         v10, v3, v13
    v.mov        v7, v12
    v.mov        v3, v10
    s.mov        s7, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s7, s9
    br.nz        s10, idiv_11
    s.addi       s7, s2, #5
    v.sub        v2, v6, v7
    v.splat      v3, s7
    v.movi       v6, #0
    @p1 v.sel        v8, v2, v7
    v.sub        v2, v6, v3
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v1, v6
    v.add        v9, v8, v4
    v.movi       v8, #1
    @p1 v.sel        v10, v2, v3
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s7, #31
idiv_12:
    v.splat      v11, s7
    v.shl        v12, v7, v8
    v.lshr       v13, v10, v11
    v.cmp.lt     p3, v7, v6
    v.and        v14, v13, v8
    v.shl        v13, v8, v11
    v.or         v11, v12, v14
    s.subi       s9, s7, #1
    v.cmp.geu    p4, v11, v2
    p.or         p5, p3, p4
    v.sub        v12, v11, v2
    @p5 v.sel        v14, v13, v6
    @p5 v.sel        v13, v12, v11
    v.or         v11, v3, v14
    v.mov        v7, v13
    v.mov        v3, v11
    s.mov        s7, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s7, s9
    br.nz        s10, idiv_12
    p.xor        p3, p1, p2
    v.sub        v2, v6, v3
    s.addi       s7, s2, #6
    @p3 v.sel        v6, v2, v3
    v.splat      v2, s7
    v.mul        v3, v6, v0
    v.movi       v6, #0
    v.add        v7, v9, v3
    v.sub        v3, v6, v2
    v.add        v8, v5, v7
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v2, v6
    v.cmp.lt     p2, v1, v6
    v.st.w       [s4, #0], v8
    s.addi       s4, s6, #384
    v.movi       v8, #1
    @p1 v.sel        v9, v3, v2
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s7, #31
idiv_13:
    v.splat      v10, s7
    v.shl        v11, v7, v8
    v.lshr       v12, v9, v10
    v.cmp.lt     p2, v7, v6
    v.and        v13, v12, v8
    v.shl        v12, v8, v10
    v.or         v10, v11, v13
    s.subi       s9, s7, #1
    v.cmp.geu    p3, v10, v2
    p.or         p4, p2, p3
    v.sub        v11, v10, v2
    @p4 v.sel        v13, v12, v6
    @p4 v.sel        v12, v11, v10
    v.or         v10, v3, v13
    v.mov        v7, v12
    v.mov        v3, v10
    s.mov        s7, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s7, s9
    br.nz        s10, idiv_13
    s.addi       s7, s2, #6
    v.sub        v2, v6, v7
    v.splat      v3, s7
    v.movi       v6, #0
    @p1 v.sel        v8, v2, v7
    v.sub        v2, v6, v3
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v1, v6
    v.add        v9, v8, v4
    v.movi       v8, #1
    @p1 v.sel        v10, v2, v3
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s7, #31
idiv_14:
    v.splat      v11, s7
    v.shl        v12, v7, v8
    v.lshr       v13, v10, v11
    v.cmp.lt     p3, v7, v6
    v.and        v14, v13, v8
    v.shl        v13, v8, v11
    v.or         v11, v12, v14
    s.subi       s9, s7, #1
    v.cmp.geu    p4, v11, v2
    p.or         p5, p3, p4
    v.sub        v12, v11, v2
    @p5 v.sel        v14, v13, v6
    @p5 v.sel        v13, v12, v11
    v.or         v11, v3, v14
    v.mov        v7, v13
    v.mov        v3, v11
    s.mov        s7, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s7, s9
    br.nz        s10, idiv_14
    p.xor        p3, p1, p2
    v.sub        v2, v6, v3
    s.addi       s7, s2, #7
    @p3 v.sel        v6, v2, v3
    v.splat      v2, s7
    v.mul        v3, v6, v0
    v.movi       v6, #0
    v.add        v7, v9, v3
    v.sub        v3, v6, v2
    v.add        v8, v5, v7
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v2, v6
    v.cmp.lt     p2, v1, v6
    v.st.w       [s4, #0], v8
    s.addi       s4, s6, #448
    v.movi       v8, #1
    @p1 v.sel        v9, v3, v2
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s7, #31
idiv_15:
    v.splat      v10, s7
    v.shl        v11, v7, v8
    v.lshr       v12, v9, v10
    v.cmp.lt     p2, v7, v6
    v.and        v13, v12, v8
    v.shl        v12, v8, v10
    v.or         v10, v11, v13
    s.subi       s9, s7, #1
    v.cmp.geu    p3, v10, v2
    p.or         p4, p2, p3
    v.sub        v11, v10, v2
    @p4 v.sel        v13, v12, v6
    @p4 v.sel        v12, v11, v10
    v.or         v10, v3, v13
    v.mov        v7, v12
    v.mov        v3, v10
    s.mov        s7, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s7, s9
    br.nz        s10, idiv_15
    s.addi       s7, s2, #7
    v.sub        v2, v6, v7
    v.splat      v3, s7
    v.movi       v6, #0
    @p1 v.sel        v8, v2, v7
    v.sub        v2, v6, v3
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v1, v6
    v.add        v9, v8, v4
    v.movi       v8, #1
    @p1 v.sel        v10, v2, v3
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s7, #31
idiv_16:
    v.splat      v11, s7
    v.shl        v12, v7, v8
    v.lshr       v13, v10, v11
    v.cmp.lt     p3, v7, v6
    v.and        v14, v13, v8
    v.shl        v13, v8, v11
    v.or         v11, v12, v14
    s.subi       s9, s7, #1
    v.cmp.geu    p4, v11, v2
    p.or         p5, p3, p4
    v.sub        v12, v11, v2
    @p5 v.sel        v14, v13, v6
    @p5 v.sel        v13, v12, v11
    v.or         v11, v3, v14
    v.mov        v7, v13
    v.mov        v3, v11
    s.mov        s7, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s7, s9
    br.nz        s10, idiv_16
    p.xor        p3, p1, p2
    v.sub        v2, v6, v3
    s.addi       s7, s2, #8
    @p3 v.sel        v6, v2, v3
    v.splat      v2, s7
    v.mul        v3, v6, v0
    v.movi       v6, #0
    v.add        v7, v9, v3
    v.sub        v3, v6, v2
    v.add        v8, v5, v7
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v2, v6
    v.cmp.lt     p2, v1, v6
    v.st.w       [s4, #0], v8
    s.addi       s4, s6, #512
    v.movi       v8, #1
    @p1 v.sel        v9, v3, v2
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s7, #31
idiv_17:
    v.splat      v10, s7
    v.shl        v11, v7, v8
    v.lshr       v12, v9, v10
    v.cmp.lt     p2, v7, v6
    v.and        v13, v12, v8
    v.shl        v12, v8, v10
    v.or         v10, v11, v13
    s.subi       s9, s7, #1
    v.cmp.geu    p3, v10, v2
    p.or         p4, p2, p3
    v.sub        v11, v10, v2
    @p4 v.sel        v13, v12, v6
    @p4 v.sel        v12, v11, v10
    v.or         v10, v3, v13
    v.mov        v7, v12
    v.mov        v3, v10
    s.mov        s7, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s7, s9
    br.nz        s10, idiv_17
    s.addi       s7, s2, #8
    v.sub        v2, v6, v7
    v.splat      v3, s7
    v.movi       v6, #0
    @p1 v.sel        v8, v2, v7
    v.sub        v2, v6, v3
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v1, v6
    v.add        v9, v8, v4
    v.movi       v8, #1
    @p1 v.sel        v10, v2, v3
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s7, #31
idiv_18:
    v.splat      v11, s7
    v.shl        v12, v7, v8
    v.lshr       v13, v10, v11
    v.cmp.lt     p3, v7, v6
    v.and        v14, v13, v8
    v.shl        v13, v8, v11
    v.or         v11, v12, v14
    s.subi       s9, s7, #1
    v.cmp.geu    p4, v11, v2
    p.or         p5, p3, p4
    v.sub        v12, v11, v2
    @p5 v.sel        v14, v13, v6
    @p5 v.sel        v13, v12, v11
    v.or         v11, v3, v14
    v.mov        v7, v13
    v.mov        v3, v11
    s.mov        s7, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s7, s9
    br.nz        s10, idiv_18
    p.xor        p3, p1, p2
    v.sub        v2, v6, v3
    s.addi       s7, s2, #9
    @p3 v.sel        v6, v2, v3
    v.splat      v2, s7
    v.mul        v3, v6, v0
    v.movi       v6, #0
    v.add        v7, v9, v3
    v.sub        v3, v6, v2
    v.add        v8, v5, v7
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v2, v6
    v.cmp.lt     p2, v1, v6
    v.st.w       [s4, #0], v8
    s.addi       s4, s6, #576
    v.movi       v8, #1
    @p1 v.sel        v9, v3, v2
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s7, #31
idiv_19:
    v.splat      v10, s7
    v.shl        v11, v7, v8
    v.lshr       v12, v9, v10
    v.cmp.lt     p2, v7, v6
    v.and        v13, v12, v8
    v.shl        v12, v8, v10
    v.or         v10, v11, v13
    s.subi       s9, s7, #1
    v.cmp.geu    p3, v10, v2
    p.or         p4, p2, p3
    v.sub        v11, v10, v2
    @p4 v.sel        v13, v12, v6
    @p4 v.sel        v12, v11, v10
    v.or         v10, v3, v13
    v.mov        v7, v12
    v.mov        v3, v10
    s.mov        s7, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s7, s9
    br.nz        s10, idiv_19
    s.addi       s7, s2, #9
    v.sub        v2, v6, v7
    v.splat      v3, s7
    v.movi       v6, #0
    @p1 v.sel        v8, v2, v7
    v.sub        v2, v6, v3
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v1, v6
    v.add        v9, v8, v4
    v.movi       v8, #1
    @p1 v.sel        v10, v2, v3
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s7, #31
idiv_20:
    v.splat      v11, s7
    v.shl        v12, v7, v8
    v.lshr       v13, v10, v11
    v.cmp.lt     p3, v7, v6
    v.and        v14, v13, v8
    v.shl        v13, v8, v11
    v.or         v11, v12, v14
    s.subi       s9, s7, #1
    v.cmp.geu    p4, v11, v2
    p.or         p5, p3, p4
    v.sub        v12, v11, v2
    @p5 v.sel        v14, v13, v6
    @p5 v.sel        v13, v12, v11
    v.or         v11, v3, v14
    v.mov        v7, v13
    v.mov        v3, v11
    s.mov        s7, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s7, s9
    br.nz        s10, idiv_20
    p.xor        p3, p1, p2
    v.sub        v2, v6, v3
    s.addi       s7, s2, #10
    @p3 v.sel        v6, v2, v3
    v.splat      v2, s7
    v.mul        v3, v6, v0
    v.movi       v6, #0
    v.add        v7, v9, v3
    v.sub        v3, v6, v2
    v.add        v8, v5, v7
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v2, v6
    v.cmp.lt     p2, v1, v6
    v.st.w       [s4, #0], v8
    s.addi       s4, s6, #640
    v.movi       v8, #1
    @p1 v.sel        v9, v3, v2
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s7, #31
idiv_21:
    v.splat      v10, s7
    v.shl        v11, v7, v8
    v.lshr       v12, v9, v10
    v.cmp.lt     p2, v7, v6
    v.and        v13, v12, v8
    v.shl        v12, v8, v10
    v.or         v10, v11, v13
    s.subi       s9, s7, #1
    v.cmp.geu    p3, v10, v2
    p.or         p4, p2, p3
    v.sub        v11, v10, v2
    @p4 v.sel        v13, v12, v6
    @p4 v.sel        v12, v11, v10
    v.or         v10, v3, v13
    v.mov        v7, v12
    v.mov        v3, v10
    s.mov        s7, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s7, s9
    br.nz        s10, idiv_21
    s.addi       s7, s2, #10
    v.sub        v2, v6, v7
    v.splat      v3, s7
    v.movi       v6, #0
    @p1 v.sel        v8, v2, v7
    v.sub        v2, v6, v3
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v1, v6
    v.add        v9, v8, v4
    v.movi       v8, #1
    @p1 v.sel        v10, v2, v3
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s7, #31
idiv_22:
    v.splat      v11, s7
    v.shl        v12, v7, v8
    v.lshr       v13, v10, v11
    v.cmp.lt     p3, v7, v6
    v.and        v14, v13, v8
    v.shl        v13, v8, v11
    v.or         v11, v12, v14
    s.subi       s9, s7, #1
    v.cmp.geu    p4, v11, v2
    p.or         p5, p3, p4
    v.sub        v12, v11, v2
    @p5 v.sel        v14, v13, v6
    @p5 v.sel        v13, v12, v11
    v.or         v11, v3, v14
    v.mov        v7, v13
    v.mov        v3, v11
    s.mov        s7, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s7, s9
    br.nz        s10, idiv_22
    p.xor        p3, p1, p2
    v.sub        v2, v6, v3
    s.addi       s7, s2, #11
    @p3 v.sel        v6, v2, v3
    v.splat      v2, s7
    v.mul        v3, v6, v0
    v.movi       v6, #0
    v.add        v7, v9, v3
    v.sub        v3, v6, v2
    v.add        v8, v5, v7
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v2, v6
    v.cmp.lt     p2, v1, v6
    v.st.w       [s4, #0], v8
    s.addi       s4, s6, #704
    v.movi       v8, #1
    @p1 v.sel        v9, v3, v2
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s7, #31
idiv_23:
    v.splat      v10, s7
    v.shl        v11, v7, v8
    v.lshr       v12, v9, v10
    v.cmp.lt     p2, v7, v6
    v.and        v13, v12, v8
    v.shl        v12, v8, v10
    v.or         v10, v11, v13
    s.subi       s9, s7, #1
    v.cmp.geu    p3, v10, v2
    p.or         p4, p2, p3
    v.sub        v11, v10, v2
    @p4 v.sel        v13, v12, v6
    @p4 v.sel        v12, v11, v10
    v.or         v10, v3, v13
    v.mov        v7, v12
    v.mov        v3, v10
    s.mov        s7, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s7, s9
    br.nz        s10, idiv_23
    s.addi       s7, s2, #11
    v.sub        v2, v6, v7
    v.splat      v3, s7
    v.movi       v6, #0
    @p1 v.sel        v8, v2, v7
    v.sub        v2, v6, v3
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v1, v6
    v.add        v9, v8, v4
    v.movi       v8, #1
    @p1 v.sel        v10, v2, v3
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s7, #31
idiv_24:
    v.splat      v11, s7
    v.shl        v12, v7, v8
    v.lshr       v13, v10, v11
    v.cmp.lt     p3, v7, v6
    v.and        v14, v13, v8
    v.shl        v13, v8, v11
    v.or         v11, v12, v14
    s.subi       s9, s7, #1
    v.cmp.geu    p4, v11, v2
    p.or         p5, p3, p4
    v.sub        v12, v11, v2
    @p5 v.sel        v14, v13, v6
    @p5 v.sel        v13, v12, v11
    v.or         v11, v3, v14
    v.mov        v7, v13
    v.mov        v3, v11
    s.mov        s7, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s7, s9
    br.nz        s10, idiv_24
    p.xor        p3, p1, p2
    v.sub        v2, v6, v3
    s.addi       s7, s2, #12
    @p3 v.sel        v6, v2, v3
    v.splat      v2, s7
    v.mul        v3, v6, v0
    v.movi       v6, #0
    v.add        v7, v9, v3
    v.sub        v3, v6, v2
    v.add        v8, v5, v7
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v2, v6
    v.cmp.lt     p2, v1, v6
    v.st.w       [s4, #0], v8
    s.addi       s4, s6, #768
    v.movi       v8, #1
    @p1 v.sel        v9, v3, v2
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s7, #31
idiv_25:
    v.splat      v10, s7
    v.shl        v11, v7, v8
    v.lshr       v12, v9, v10
    v.cmp.lt     p2, v7, v6
    v.and        v13, v12, v8
    v.shl        v12, v8, v10
    v.or         v10, v11, v13
    s.subi       s9, s7, #1
    v.cmp.geu    p3, v10, v2
    p.or         p4, p2, p3
    v.sub        v11, v10, v2
    @p4 v.sel        v13, v12, v6
    @p4 v.sel        v12, v11, v10
    v.or         v10, v3, v13
    v.mov        v7, v12
    v.mov        v3, v10
    s.mov        s7, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s7, s9
    br.nz        s10, idiv_25
    s.addi       s7, s2, #12
    v.sub        v2, v6, v7
    v.splat      v3, s7
    v.movi       v6, #0
    @p1 v.sel        v8, v2, v7
    v.sub        v2, v6, v3
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v1, v6
    v.add        v9, v8, v4
    v.movi       v8, #1
    @p1 v.sel        v10, v2, v3
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s7, #31
idiv_26:
    v.splat      v11, s7
    v.shl        v12, v7, v8
    v.lshr       v13, v10, v11
    v.cmp.lt     p3, v7, v6
    v.and        v14, v13, v8
    v.shl        v13, v8, v11
    v.or         v11, v12, v14
    s.subi       s9, s7, #1
    v.cmp.geu    p4, v11, v2
    p.or         p5, p3, p4
    v.sub        v12, v11, v2
    @p5 v.sel        v14, v13, v6
    @p5 v.sel        v13, v12, v11
    v.or         v11, v3, v14
    v.mov        v7, v13
    v.mov        v3, v11
    s.mov        s7, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s7, s9
    br.nz        s10, idiv_26
    p.xor        p3, p1, p2
    v.sub        v2, v6, v3
    s.addi       s7, s2, #13
    @p3 v.sel        v6, v2, v3
    v.splat      v2, s7
    v.mul        v3, v6, v0
    v.movi       v6, #0
    v.add        v7, v9, v3
    v.sub        v3, v6, v2
    v.add        v8, v5, v7
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v2, v6
    v.cmp.lt     p2, v1, v6
    v.st.w       [s4, #0], v8
    s.addi       s4, s6, #832
    v.movi       v8, #1
    @p1 v.sel        v9, v3, v2
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s7, #31
idiv_27:
    v.splat      v10, s7
    v.shl        v11, v7, v8
    v.lshr       v12, v9, v10
    v.cmp.lt     p2, v7, v6
    v.and        v13, v12, v8
    v.shl        v12, v8, v10
    v.or         v10, v11, v13
    s.subi       s9, s7, #1
    v.cmp.geu    p3, v10, v2
    p.or         p4, p2, p3
    v.sub        v11, v10, v2
    @p4 v.sel        v13, v12, v6
    @p4 v.sel        v12, v11, v10
    v.or         v10, v3, v13
    v.mov        v7, v12
    v.mov        v3, v10
    s.mov        s7, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s7, s9
    br.nz        s10, idiv_27
    s.addi       s7, s2, #13
    v.sub        v2, v6, v7
    v.splat      v3, s7
    v.movi       v6, #0
    @p1 v.sel        v8, v2, v7
    v.sub        v2, v6, v3
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v1, v6
    v.add        v9, v8, v4
    v.movi       v8, #1
    @p1 v.sel        v10, v2, v3
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s7, #31
idiv_28:
    v.splat      v11, s7
    v.shl        v12, v7, v8
    v.lshr       v13, v10, v11
    v.cmp.lt     p3, v7, v6
    v.and        v14, v13, v8
    v.shl        v13, v8, v11
    v.or         v11, v12, v14
    s.subi       s9, s7, #1
    v.cmp.geu    p4, v11, v2
    p.or         p5, p3, p4
    v.sub        v12, v11, v2
    @p5 v.sel        v14, v13, v6
    @p5 v.sel        v13, v12, v11
    v.or         v11, v3, v14
    v.mov        v7, v13
    v.mov        v3, v11
    s.mov        s7, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s7, s9
    br.nz        s10, idiv_28
    p.xor        p3, p1, p2
    v.sub        v2, v6, v3
    s.addi       s7, s2, #14
    @p3 v.sel        v6, v2, v3
    v.splat      v2, s7
    v.mul        v3, v6, v0
    v.movi       v6, #0
    v.add        v7, v9, v3
    v.sub        v3, v6, v2
    v.add        v8, v5, v7
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v2, v6
    v.cmp.lt     p2, v1, v6
    v.st.w       [s4, #0], v8
    s.addi       s4, s6, #896
    v.movi       v8, #1
    @p1 v.sel        v9, v3, v2
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s7, #31
idiv_29:
    v.splat      v10, s7
    v.shl        v11, v7, v8
    v.lshr       v12, v9, v10
    v.cmp.lt     p2, v7, v6
    v.and        v13, v12, v8
    v.shl        v12, v8, v10
    v.or         v10, v11, v13
    s.subi       s9, s7, #1
    v.cmp.geu    p3, v10, v2
    p.or         p4, p2, p3
    v.sub        v11, v10, v2
    @p4 v.sel        v13, v12, v6
    @p4 v.sel        v12, v11, v10
    v.or         v10, v3, v13
    v.mov        v7, v12
    v.mov        v3, v10
    s.mov        s7, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s7, s9
    br.nz        s10, idiv_29
    s.addi       s7, s2, #14
    v.sub        v2, v6, v7
    v.splat      v3, s7
    v.movi       v6, #0
    @p1 v.sel        v8, v2, v7
    v.sub        v2, v6, v3
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v1, v6
    v.add        v9, v8, v4
    v.movi       v8, #1
    @p1 v.sel        v10, v2, v3
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s7, #31
idiv_30:
    v.splat      v11, s7
    v.shl        v12, v7, v8
    v.lshr       v13, v10, v11
    v.cmp.lt     p3, v7, v6
    v.and        v14, v13, v8
    v.shl        v13, v8, v11
    v.or         v11, v12, v14
    s.subi       s9, s7, #1
    v.cmp.geu    p4, v11, v2
    p.or         p5, p3, p4
    v.sub        v12, v11, v2
    @p5 v.sel        v14, v13, v6
    @p5 v.sel        v13, v12, v11
    v.or         v11, v3, v14
    v.mov        v7, v13
    v.mov        v3, v11
    s.mov        s7, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s7, s9
    br.nz        s10, idiv_30
    p.xor        p3, p1, p2
    v.sub        v2, v6, v3
    s.addi       s7, s2, #15
    @p3 v.sel        v6, v2, v3
    v.splat      v2, s7
    v.mul        v3, v6, v0
    v.movi       v6, #0
    v.add        v7, v9, v3
    v.sub        v3, v6, v2
    v.add        v8, v5, v7
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v2, v6
    v.cmp.lt     p2, v1, v6
    v.st.w       [s4, #0], v8
    s.addi       s4, s6, #960
    v.movi       v8, #1
    @p1 v.sel        v9, v3, v2
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s6, #31
idiv_31:
    v.splat      v10, s6
    v.shl        v11, v7, v8
    v.lshr       v12, v9, v10
    v.cmp.lt     p2, v7, v6
    v.and        v13, v12, v8
    v.shl        v12, v8, v10
    v.or         v10, v11, v13
    s.subi       s7, s6, #1
    v.cmp.geu    p3, v10, v2
    p.or         p4, p2, p3
    v.sub        v11, v10, v2
    @p4 v.sel        v13, v12, v6
    @p4 v.sel        v12, v11, v10
    v.or         v10, v3, v13
    v.mov        v7, v12
    v.mov        v3, v10
    s.mov        s6, s7
    s.movz       s7, #0
    s.cmp.ge     s9, s6, s7
    br.nz        s9, idiv_31
    s.addi       s6, s2, #15
    v.sub        v2, v6, v7
    v.splat      v3, s6
    v.movi       v6, #0
    @p1 v.sel        v8, v2, v7
    v.sub        v2, v6, v3
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v1, v6
    v.add        v9, v8, v4
    v.movi       v4, #1
    @p1 v.sel        v8, v2, v3
    @p2 v.sel        v2, v7, v1
    v.movi       v1, #0
    v.movi       v3, #0
    s.movz       s6, #31
idiv_32:
    v.splat      v7, s6
    v.shl        v10, v3, v4
    v.lshr       v11, v8, v7
    v.cmp.lt     p3, v3, v6
    v.and        v12, v11, v4
    v.shl        v11, v4, v7
    v.or         v7, v10, v12
    s.subi       s7, s6, #1
    v.cmp.geu    p4, v7, v2
    p.or         p5, p3, p4
    v.sub        v10, v7, v2
    @p5 v.sel        v12, v11, v6
    @p5 v.sel        v11, v10, v7
    v.or         v7, v1, v12
    v.mov        v3, v11
    v.mov        v1, v7
    s.mov        s6, s7
    s.movz       s7, #0
    s.cmp.ge     s9, s6, s7
    br.nz        s9, idiv_32
    s.movz       s6, #0
    p.xor        p3, p1, p2
    v.sub        v2, v6, v1
    s.add        s7, s6, s3                      // the tile origin
    @p3 v.sel        v3, v2, v1
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v2, s7
    s.movz       s3, #9
    s.movz       s6, #576
    v.mul        v4, v3, v0
    v.add        v0, v1, v2
    v.splat      v1, s3
    v.splat      v2, s2
    v.splat      v3, s6
    v.add        v6, v9, v4
    v.cmp.lt     p1, v0, v1
    v.cmp.lt     p2, v2, v3
    v.add        v0, v5, v6
    p.and        p3, p1, p2
    s.addi       s3, s5, #0
    v.st.w       [s4, #0], v0
    fence.acq_rel.device
    s.addi       s4, s2, #1
    v.splat      v0, s2
    v.splat      v1, s4
    v.cmp.lt     p2, v0, v3
    p.and        p4, p1, p2
    s.addi       s4, s8, #36                     // row 1
    s.addi       s6, s5, #64
    s.addi       s7, s2, #1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s8, #0]
    v.cmp.lt     p2, v1, v3
    p.and        p3, p1, p2
    s.addi       s9, s2, #2
    v.splat      v1, s7
    v.splat      v2, s9
    s.addi       s7, s8, #72                     // row 2
    s.addi       s9, s5, #128
    s.addi       s10, s2, #2
    v.ld.w       v4, [s3, #0]
    s.addi       s3, s2, #3
    v.splat      v5, s10
    v.splat      v6, s3
    s.addi       s3, s8, #108                    // row 3
    s.addi       s10, s5, #192
    @p4 v.st.scatter.w [s1, v4], v0
    v.cmp.lt     p2, v1, v3
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s4, #0]
    v.cmp.lt     p2, v2, v3
    p.and        p3, p1, p2
    s.addi       s4, s2, #3
    v.splat      v1, s4
    s.addi       s4, s2, #4
    v.splat      v2, s4
    s.addi       s4, s8, #144                    // row 4
    v.ld.w       v4, [s6, #0]
    s.addi       s6, s5, #256
    @p4 v.st.scatter.w [s1, v4], v0
    v.cmp.lt     p2, v5, v3
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s7, #0]
    v.cmp.lt     p2, v6, v3
    p.and        p3, p1, p2
    s.addi       s7, s2, #4
    v.splat      v4, s7
    s.addi       s7, s2, #5
    v.splat      v5, s7
    s.addi       s7, s8, #180                    // row 5
    v.ld.w       v6, [s9, #0]
    s.addi       s9, s5, #320
    @p4 v.st.scatter.w [s1, v6], v0
    v.cmp.lt     p2, v1, v3
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s3, #0]
    v.cmp.lt     p2, v2, v3
    p.and        p3, p1, p2
    s.addi       s3, s2, #5
    v.splat      v1, s3
    s.addi       s3, s2, #6
    v.splat      v2, s3
    s.addi       s3, s8, #216                    // row 6
    v.ld.w       v6, [s10, #0]
    s.addi       s10, s5, #384
    @p4 v.st.scatter.w [s1, v6], v0
    v.cmp.lt     p2, v4, v3
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s4, #0]
    v.cmp.lt     p2, v5, v3
    p.and        p3, p1, p2
    s.addi       s4, s2, #6
    v.splat      v4, s4
    s.addi       s4, s2, #7
    v.splat      v5, s4
    s.addi       s4, s8, #252                    // row 7
    v.ld.w       v6, [s6, #0]
    s.addi       s6, s5, #448
    @p4 v.st.scatter.w [s1, v6], v0
    v.cmp.lt     p2, v1, v3
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s7, #0]
    v.cmp.lt     p2, v2, v3
    p.and        p3, p1, p2
    s.addi       s7, s2, #7
    v.splat      v1, s7
    s.addi       s7, s2, #8
    v.splat      v2, s7
    s.addi       s7, s8, #288                    // row 8
    v.ld.w       v6, [s9, #0]
    s.addi       s9, s5, #512
    @p4 v.st.scatter.w [s1, v6], v0
    v.cmp.lt     p2, v4, v3
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s3, #0]
    v.cmp.lt     p2, v5, v3
    p.and        p3, p1, p2
    s.addi       s3, s2, #8
    v.splat      v4, s3
    s.addi       s3, s2, #9
    v.splat      v5, s3
    s.addi       s3, s8, #324                    // row 9
    v.ld.w       v6, [s10, #0]
    s.addi       s10, s5, #576
    @p4 v.st.scatter.w [s1, v6], v0
    v.cmp.lt     p2, v1, v3
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s4, #0]
    v.cmp.lt     p2, v2, v3
    p.and        p3, p1, p2
    s.addi       s4, s2, #9
    v.splat      v1, s4
    s.addi       s4, s2, #10
    v.splat      v2, s4
    s.addi       s4, s8, #360                    // row 10
    v.ld.w       v6, [s6, #0]
    s.addi       s6, s5, #640
    @p4 v.st.scatter.w [s1, v6], v0
    v.cmp.lt     p2, v4, v3
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s7, #0]
    v.cmp.lt     p2, v5, v3
    p.and        p3, p1, p2
    s.addi       s7, s2, #10
    v.splat      v4, s7
    s.addi       s7, s2, #11
    v.splat      v5, s7
    s.addi       s7, s8, #396                    // row 11
    v.ld.w       v6, [s9, #0]
    s.addi       s9, s5, #704
    @p4 v.st.scatter.w [s1, v6], v0
    v.cmp.lt     p2, v1, v3
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s3, #0]
    v.cmp.lt     p2, v2, v3
    p.and        p3, p1, p2
    s.addi       s3, s2, #11
    v.splat      v1, s3
    s.addi       s3, s2, #12
    v.splat      v2, s3
    s.addi       s3, s8, #432                    // row 12
    v.ld.w       v6, [s10, #0]
    s.addi       s10, s5, #768
    @p4 v.st.scatter.w [s1, v6], v0
    v.cmp.lt     p2, v4, v3
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s4, #0]
    v.cmp.lt     p2, v5, v3
    p.and        p3, p1, p2
    s.addi       s4, s2, #12
    v.splat      v4, s4
    s.addi       s4, s2, #13
    v.splat      v5, s4
    s.addi       s4, s8, #468                    // row 13
    v.ld.w       v6, [s6, #0]
    s.addi       s6, s5, #832
    @p4 v.st.scatter.w [s1, v6], v0
    v.cmp.lt     p2, v1, v3
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s7, #0]
    v.cmp.lt     p2, v2, v3
    p.and        p3, p1, p2
    s.addi       s7, s2, #13
    v.splat      v1, s7
    s.addi       s7, s2, #14
    v.splat      v2, s7
    s.addi       s7, s8, #504                    // row 14
    v.ld.w       v6, [s9, #0]
    s.addi       s9, s5, #896
    s.addi       s11, s8, #540                   // row 15
    s.addi       s8, s5, #960
    @p4 v.st.scatter.w [s1, v6], v0
    v.cmp.lt     p2, v4, v3
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s3, #0]
    v.cmp.lt     p2, v5, v3
    p.and        p3, p1, p2
    s.addi       s3, s2, #14
    v.splat      v4, s3
    s.addi       s3, s2, #15
    s.addi       s5, s2, #15
    v.splat      v5, s3
    v.splat      v6, s5
    v.ld.w       v7, [s10, #0]
    @p4 v.st.scatter.w [s1, v7], v0
    v.cmp.lt     p2, v1, v3
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s4, #0]
    v.cmp.lt     p2, v2, v3
    p.and        p3, p1, p2
    v.ld.w       v1, [s6, #0]
    @p4 v.st.scatter.w [s1, v1], v0
    v.cmp.lt     p2, v4, v3
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s7, #0]
    v.cmp.lt     p2, v5, v3
    p.and        p3, p1, p2
    v.ld.w       v1, [s9, #0]
    @p4 v.st.scatter.w [s1, v1], v0
    v.cmp.lt     p2, v6, v3
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s11, #0]
    v.ld.w       v1, [s8, #0]
    @p4 v.st.scatter.w [s1, v1], v0
__rctx_next:
    exit
