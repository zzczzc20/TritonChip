    s.rdspecial  s1, arg_base
    s.movz       s2, #16
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.rdspecial  s4, role_id
    s.rdspecial  s5, npid.x
    s.ld.d       s6, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
__rctx_program:
    s.mul        s1, s4, s2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #0
    v.movi       v2, #6
    v.movi       v3, #64
    v.splat      v4, s1
    v.movi       v5, #576
    v.movi       v6, #0
    v.add        v7, v4, v0
    v.sub        v0, v1, v3
    v.sub        v4, v6, v5
    v.sub        v8, v1, v7
    v.cmp.lt     p1, v7, v1
    v.cmp.lt     p2, v3, v1
    @p1 v.sel        v9, v8, v7
    v.cmp.lt     p3, v5, v6
    v.movi       v8, #1
    v.lshr       v8, v9, v2
    @p2 v.sel        v2, v0, v3
    v.movi       v0, #1
    v.sub        v2, v1, v8
    @p3 v.sel        v1, v4, v5
    v.movi       v3, #0
    @p1 v.sel        v4, v2, v8
    v.movi       v2, #0
    s.movz       s7, #31
    v.sub        v5, v6, v4
    v.cmp.lt     p1, v4, v6
    @p1 v.sel        v8, v5, v4
idiv_1:
    v.splat      v4, s7
    v.shl        v5, v2, v0
    v.cmp.lt     p2, v2, v6
    v.lshr       v9, v8, v4
    v.shl        v10, v0, v4
    s.subi       s8, s7, #1
    v.and        v4, v9, v0
    s.movz       s9, #0
    v.or         v9, v5, v4
    v.cmp.geu    p3, v9, v1
    p.or         p4, p2, p3
    v.sub        v4, v9, v1
    @p4 v.sel        v5, v10, v6
    @p4 v.sel        v10, v4, v9
    v.or         v4, v3, v5
    v.mov        v2, v10
    v.mov        v3, v4
    s.mov        s7, s8
    s.cmp.ge     s8, s7, s9
    br.nz        s8, idiv_1
    s.movz       s7, #36864
    v.splat      v0, s7                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v1, #0
    v.sub        v3, v6, v2
    v.movi       v4, #1
    v.sub        v5, v1, v7
    v.sub        v6, v1, v0
    v.cmp.lt     p2, v7, v1
    v.cmp.lt     p3, v0, v1
    @p1 v.sel        v8, v3, v2
    @p2 v.sel        v2, v5, v7
    @p3 v.sel        v3, v6, v0
    v.movi       v5, #0
    v.movi       v6, #0
    s.movz       s7, #31
idiv_2:
    v.splat      v9, s7
    v.shl        v10, v6, v4
    v.cmp.lt     p1, v6, v1
    v.lshr       v11, v2, v9
    v.shl        v12, v4, v9
    s.subi       s8, s7, #1
    v.and        v9, v11, v4
    s.movz       s9, #0
    v.or         v11, v10, v9
    v.cmp.geu    p4, v11, v3
    p.or         p5, p1, p4
    v.sub        v9, v11, v3
    @p5 v.sel        v10, v12, v1
    @p5 v.sel        v12, v9, v11
    v.or         v9, v5, v10
    v.mov        v6, v12
    v.mov        v5, v9
    s.mov        s7, s8
    s.cmp.ge     s8, s7, s9
    br.nz        s8, idiv_2
    v.movi       v2, #0
    v.sub        v3, v1, v5
    p.xor        p1, p2, p3
    v.sub        v1, v2, v7
    v.sub        v4, v2, v0
    v.cmp.lt     p2, v7, v2
    v.cmp.lt     p3, v0, v2
    @p1 v.sel        v6, v3, v5
    v.movi       v3, #1
    @p2 v.sel        v5, v1, v7
    @p3 v.sel        v1, v4, v0
    v.movi       v0, #0
    v.movi       v4, #0
    s.movz       s7, #31
idiv_3:
    v.splat      v7, s7
    v.shl        v9, v4, v3
    v.cmp.lt     p1, v4, v2
    v.lshr       v10, v5, v7
    v.shl        v11, v3, v7
    s.subi       s8, s7, #1
    v.and        v7, v10, v3
    s.movz       s9, #0
    v.or         v10, v9, v7
    v.cmp.geu    p3, v10, v1
    p.or         p4, p1, p3
    v.sub        v7, v10, v1
    @p4 v.sel        v9, v11, v2
    @p4 v.sel        v11, v7, v10
    v.or         v7, v0, v9
    v.mov        v4, v11
    v.mov        v0, v7
    s.mov        s7, s8
    s.cmp.ge     s8, s7, s9
    br.nz        s8, idiv_3
    v.extract    s7, v8, #0
    v.extract    s8, v8, #1
    s.shli       s9, s7, #32
    v.movi       v0, #0
    s.ashri      s7, s9, #32
    v.movi       v1, #0
    s.shli       s9, s8, #32
    s.lshri      s8, s7, #32
    v.extract    s10, v8, #2
    s.ashri      s11, s9, #32
    v.insert     v0, s7, #0
    v.insert     v1, s8, #0
    s.shli       s7, s10, #32
    s.lshri      s8, s11, #32
    v.extract    s9, v8, #3
    s.ashri      s10, s7, #32
    v.insert     v0, s11, #1
    v.insert     v1, s8, #1
    s.shli       s7, s9, #32
    s.lshri      s8, s10, #32
    v.extract    s9, v8, #4
    s.ashri      s11, s7, #32
    v.insert     v0, s10, #2
    v.insert     v1, s8, #2
    s.shli       s7, s9, #32
    s.lshri      s8, s11, #32
    v.extract    s9, v8, #5
    s.ashri      s10, s7, #32
    v.insert     v0, s11, #3
    v.insert     v1, s8, #3
    s.shli       s7, s9, #32
    s.lshri      s8, s10, #32
    v.extract    s9, v8, #6
    s.ashri      s11, s7, #32
    v.insert     v0, s10, #4
    v.insert     v1, s8, #4
    s.shli       s7, s9, #32
    s.lshri      s8, s11, #32
    v.extract    s9, v8, #7
    s.ashri      s10, s7, #32
    v.insert     v0, s11, #5
    v.insert     v1, s8, #5
    s.shli       s7, s9, #32
    s.lshri      s8, s10, #32
    v.insert     v0, s10, #6
    v.insert     v1, s8, #6
    v.sub        v3, v2, v4
    s.ashri      s8, s7, #32
    @p2 v.sel        v2, v3, v4
    v.extract    s7, v8, #8
    s.lshri      s9, s8, #32
    s.shli       s10, s7, #32
    v.extract    s7, v8, #9
    s.ashri      s11, s10, #32
    v.insert     v0, s8, #7
    v.insert     v1, s9, #7
    s.shli       s8, s7, #32
    s.lshri      s7, s11, #32
    v.extract    s9, v8, #10
    s.ashri      s10, s8, #32
    v.insert     v0, s11, #8
    v.insert     v1, s7, #8
    s.shli       s7, s9, #32
    s.lshri      s8, s10, #32
    v.extract    s9, v8, #11
    s.ashri      s11, s7, #32
    v.insert     v0, s10, #9
    v.insert     v1, s8, #9
    s.shli       s7, s9, #32
    s.lshri      s8, s11, #32
    v.extract    s9, v8, #12
    s.ashri      s10, s7, #32
    v.insert     v0, s11, #10
    v.insert     v1, s8, #10
    s.shli       s7, s9, #32
    s.lshri      s8, s10, #32
    v.extract    s9, v8, #13
    s.ashri      s11, s7, #32
    v.insert     v0, s10, #11
    v.insert     v1, s8, #11
    s.shli       s7, s9, #32
    s.lshri      s8, s11, #32
    v.extract    s9, v8, #14
    s.ashri      s10, s7, #32
    v.insert     v0, s11, #12
    v.insert     v1, s8, #12
    s.shli       s7, s9, #32
    s.lshri      s8, s10, #32
    v.extract    s9, v8, #15
    s.ashri      s11, s7, #32
    v.insert     v0, s10, #13
    v.insert     v1, s8, #13
    s.shli       s7, s9, #32
    s.lshri      s8, s11, #32
    s.ashri      s9, s7, #32
    v.insert     v0, s11, #14
    v.insert     v1, s8, #14
    s.lshri      s7, s9, #32
    v.insert     v0, s9, #15
    v.insert     v1, s7, #15
    s.movz       s7, #512
    v.extract    s8, v0, #0
    v.extract    s9, v1, #0
    v.extract    s10, v1, #1
    s.shli       s11, s9, #32
    v.movi       v3, #0
    s.or         s9, s8, s11
    v.extract    s8, v0, #1
    s.shli       s11, s10, #32
    s.cmp.lt     s10, s9, s7
    v.extract    s7, v1, #2
    s.or         s9, s8, s11
    s.movz       s8, #512
    v.insert     v3, s10, #0
    v.extract    s10, v0, #2
    s.shli       s11, s7, #32
    s.cmp.lt     s7, s9, s8
    v.extract    s8, v1, #3
    s.or         s9, s10, s11
    s.movz       s10, #512
    v.insert     v3, s7, #1
    v.extract    s7, v0, #3
    s.shli       s11, s8, #32
    s.cmp.lt     s8, s9, s10
    v.extract    s9, v1, #4
    s.or         s10, s7, s11
    s.movz       s7, #512
    v.insert     v3, s8, #2
    v.extract    s8, v0, #4
    s.shli       s11, s9, #32
    s.cmp.lt     s9, s10, s7
    v.extract    s7, v1, #5
    s.or         s10, s8, s11
    s.movz       s8, #512
    v.insert     v3, s9, #3
    v.extract    s9, v0, #5
    s.shli       s11, s7, #32
    s.cmp.lt     s7, s10, s8
    v.extract    s8, v1, #6
    s.or         s10, s9, s11
    s.movz       s9, #512
    v.insert     v3, s7, #4
    v.extract    s7, v0, #6
    s.shli       s11, s8, #32
    s.cmp.lt     s8, s10, s9
    v.extract    s9, v1, #7
    s.or         s10, s7, s11
    s.movz       s7, #512
    v.insert     v3, s8, #5
    v.extract    s8, v0, #7
    s.shli       s11, s9, #32
    s.cmp.lt     s9, s10, s7
    v.extract    s7, v1, #8
    s.or         s10, s8, s11
    s.movz       s8, #512
    v.insert     v3, s9, #6
    v.extract    s9, v0, #8
    s.shli       s11, s7, #32
    s.cmp.lt     s7, s10, s8
    v.extract    s8, v1, #9
    s.or         s10, s9, s11
    s.movz       s9, #512
    v.insert     v3, s7, #7
    v.extract    s7, v0, #9
    s.shli       s11, s8, #32
    s.cmp.lt     s8, s10, s9
    v.extract    s9, v1, #10
    s.or         s10, s7, s11
    s.movz       s7, #512
    v.insert     v3, s8, #8
    v.extract    s8, v0, #10
    s.shli       s11, s9, #32
    s.cmp.lt     s9, s10, s7
    v.extract    s7, v1, #11
    s.or         s10, s8, s11
    s.movz       s8, #512
    v.insert     v3, s9, #9
    v.extract    s9, v0, #11
    s.shli       s11, s7, #32
    s.cmp.lt     s7, s10, s8
    v.extract    s8, v1, #12
    s.or         s10, s9, s11
    s.movz       s9, #512
    v.insert     v3, s7, #10
    v.extract    s7, v0, #12
    s.shli       s11, s8, #32
    s.cmp.lt     s8, s10, s9
    v.extract    s9, v1, #13
    s.or         s10, s7, s11
    s.movz       s7, #512
    v.insert     v3, s8, #11
    v.extract    s8, v0, #13
    s.shli       s11, s9, #32
    s.cmp.lt     s9, s10, s7
    v.extract    s7, v1, #14
    s.or         s10, s8, s11
    s.movz       s8, #512
    v.insert     v3, s9, #12
    v.extract    s9, v0, #14
    s.shli       s11, s7, #32
    s.cmp.lt     s7, s10, s8
    v.extract    s8, v1, #15
    s.or         s10, s9, s11
    s.movz       s9, #512
    v.insert     v3, s7, #13
    v.extract    s7, v0, #15
    s.shli       s11, s8, #32
    s.cmp.lt     s8, s10, s9
    s.movz       s9, #32768
    v.splat      v0, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.or         s9, s7, s11
    s.movz       s7, #512
    v.insert     v3, s8, #14
    s.cmp.lt     s8, s9, s7
    v.mul        v1, v6, v0
    v.insert     v3, s8, #15
    v.movi       v0, #0
    v.add        v4, v2, v1
    s.shli       s7, s1, #1                      // element offset -> bytes (x2)
    v.cmp.ne     p1, v3, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v0, [s3, v4]               // index is in elements (ISA sec 9.1)
    s.add        s1, s6, s7                      // &out_ptr0[...]
    s.movz       s7, #32768
    v.st.h       [s1, #0], v0
__rctx_next:
    s.addi       s1, s4, #4                      // the next program of this context: + 4
    s.cmp.lt     s7, s1, s5
    s.mov        s4, s1
    br.nz        s7, __rctx_program
    exit
