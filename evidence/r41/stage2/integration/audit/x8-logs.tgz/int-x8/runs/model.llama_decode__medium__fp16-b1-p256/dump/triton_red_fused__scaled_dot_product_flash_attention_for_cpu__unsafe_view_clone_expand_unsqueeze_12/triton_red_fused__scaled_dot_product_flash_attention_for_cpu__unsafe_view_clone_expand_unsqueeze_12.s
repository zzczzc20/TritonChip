    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.splat      v0, s4
    v.movi       v1, #0
    v.movi       v2, #5
    v.sub        v3, v1, v0
    v.cmp.lt     p1, v0, v1
    @p1 v.sel        v4, v3, v0
    s.rdspecial  s1, arg_base
    v.lshr       v3, v4, v2
    s.movz       s2, #1
    v.sub        v2, v1, v3
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s2
    @p1 v.sel        v6, v2, v3
    v.cmp.lt     p1, v4, v5
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.sb v2, [s3, v6]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.movi       v4, #31
    v.sub        v5, v3, v0
    v.cmp.lt     p1, v0, v3
    @p1 v.sel        v7, v5, v0
    s.movz       s2, #1
    v.movi       v0, #32
    v.and        v5, v7, v4
    v.iota       v4                              // arange(0, VLEN)
    s.ld.d       s3, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.splat      v7, s2
    s.movz       s2, #0
    v.sub        v8, v1, v0
    v.movi       v9, #0
    v.sub        v10, v3, v0
    v.cmp.lt     p2, v0, v1
    v.sub        v1, v3, v5
    v.cmp.lt     p3, v4, v7
    v.movi       v4, #0
    v.cmp.lt     p4, v0, v3
    s.ld.d       s5, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.movi       v3, #0
    s.movz       s6, #257
    s.ld.d       s7, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.movz       s8, #16
    v.iota       v7                              // arange(0, VLEN)
    s.ld.d       s9, [s1, #32]                   // out_ptr1: device_ptr64 at arg_base+32
    v.movi       v11, #1
    @p2 v.sel        v11, v8, v0
    v.cmp.ne     p2, v2, v9
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v2, [s3, v6]               // index is in elements (ISA sec 9.1)
    v.movi       v8, #1
    @p4 v.sel        v8, v10, v0
    @p1 v.sel        v0, v1, v5
    s.addi       s1, s2, #0
    v.mov        v3, v4
for_1:
    s.cmp.ge     s2, s1, s6
    br.nz        s2, endfor_2
    v.movi       v1, #257
    v.splat      v5, s1
    v.mul        v8, v6, v1
    v.add        v1, v5, v7
    v.extract    s2, v8, #0
    v.splat      v5, s2
    v.movi       v8, #32
    v.movi       v9, #3
    v.movi       v10, #0
    v.movi       v11, #257
    v.extract    s2, v0, #0
    v.add        v12, v1, v5
    v.mul        v5, v1, v8
    v.splat      v8, s2
    v.sub        v13, v10, v6
    v.sub        v14, v10, v9
    v.cmp.lt     p1, v1, v11
    v.cmp.lt     p3, v6, v10
    v.cmp.lt     p4, v9, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s5, v12]              // index is in elements (ISA sec 9.1)
    s.movz       s2, #32
    v.add        v11, v8, v5
    v.movi       v5, #1
    @p3 v.sel        v8, v13, v6
    @p4 v.sel        v12, v14, v9
    v.movi       v9, #0
    v.movi       v13, #0
    s.movz       s2, #31
idiv_3:
    v.splat      v14, s2
    v.shl        v15, v13, v5
    v.lshr       v16, v8, v14
    v.cmp.lt     p5, v13, v10
    v.and        v17, v16, v5
    v.shl        v16, v5, v14
    v.or         v14, v15, v17
    s.subi       s3, s2, #1
    v.cmp.geu    p6, v14, v12
    p.or         p7, p5, p6
    v.sub        v15, v14, v12
    @p7 v.sel        v17, v16, v10
    @p7 v.sel        v16, v15, v14
    v.or         v14, v9, v17
    v.mov        v13, v16
    v.mov        v9, v14
    s.mov        s2, s3
    s.movz       s3, #0
    s.cmp.ge     s10, s2, s3
    br.nz        s10, idiv_3
    v.extract    s2, v2, #0
    v.splat      v5, s2
    .li       s2, #1065353216
    v.splat      v8, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v12, v5                         // ISA 8.8: <= 2**-22 relative
    p.xor        p5, p3, p4
    v.sub        v13, v10, v9
    v.movi       v10, #8224
    @p5 v.sel        v14, v13, v9
    v.movi       v9, #1
    v.mul        v13, v14, v10
    v.movi       v10, #0
    v.extract    s2, v13, #0
    v.splat      v13, s2
    @p2 v.sel        v14, v9, v10
    v.add        v9, v11, v13
    v.movi       v10, #0
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v11, [s7, v9]              // index is in elements (ISA sec 9.1)
    v.movi       v9, #1
    v.movi       v13, #0
    v.cmp.eq     p3, v14, v10
    @p3 v.sel        v10, v9, v13
    v.movi       v9, #0
    v.extract    s2, v10, #0
    v.splat      v10, s2
    vf.cvt.f16.f32 v13, v11
    v.cmp.ne     p3, v10, v9
    v.movi       v9, #0
    s.add        s2, s1, s8
    s.movz       s3, #1
    s.movz       s10, #8224
    vf.fms       v10, v5, v12, v8
    vf.fms       v5, v12, v10, v12
    vf.neg       v8, v5                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v8, v8
    @p4 v.sel        v5, v8, v12
    vf.mul       v8, v1, v5                      // a/y as a refined reciprocal (ISA has no divide)
    @p3 v.sel        v1, v4, v8
    vf.mul       v5, v1, v13
    vf.add       v1, v3, v5
    @p1 v.sel        v5, v1, v3
    v.mov        v9, v5
    v.mov        v3, v9
    s.mov        s1, s2
    br.nz        s3, for_1
endfor_2:
    vf.reduce.add.b v0, v3
    v.movi       v1, #0
    s.movz       s1, #1
    vf.add       v2, v0, v1
    s.shli       s2, s4, #1                      // element offset -> bytes (x2)
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    vf.cvt.f32.f16 v3, v2
    s.add        s1, s9, s2                      // &out_ptr1[...]
    v.cmp.lt     p1, v0, v1
    @p1 v.st.h       [s1, #0], v3
__rctx_next:
    exit
