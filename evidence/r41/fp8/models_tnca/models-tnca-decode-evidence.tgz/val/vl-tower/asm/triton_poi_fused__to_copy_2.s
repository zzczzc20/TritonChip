    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.shli       s2, s4, #4                      // x16 as a shift
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.shli       s4, s2, #2                      // element offset -> bytes (x4)
    s.shli       s5, s2, #1                      // element offset -> bytes (x2)
    s.add        s6, s3, s4                      // &in_ptr0[...]
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s2
    v.ld.w       v2, [s6, #0]
    s.add        s1, s3, s5                      // &out_ptr0[...]
    v.add        v3, v1, v0
    vf.cvt.f32.bf16 v0, v2
    v.st.h       [s1, #0], v0
__rctx_next:
    exit
