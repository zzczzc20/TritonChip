    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.shli       s2, s4, #4                      // x16 as a shift
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s2
    v.movi       v2, #0
    s.shli       s4, s2, #2                      // element offset -> bytes (x4)
    v.add        v3, v1, v0
    v.movi       v0, #0
    v.movi       v1, #11
    v.sub        v4, v2, v3
    v.cmp.lt     p1, v3, v2
    v.sub        v5, v0, v3
    s.add        s2, s3, s4                      // &in_ptr0[...]
    @p1 v.sel        v6, v4, v3
    v.ld.w       v4, [s2, #0]
    v.cmp.lt     p2, v3, v0
    @p2 v.sel        v7, v5, v3
    v.movi       v3, #2047
    v.lshr       v5, v6, v1
    v.movi       v1, #8192
    v.and        v6, v7, v3
    v.sub        v3, v2, v5
    v.movi       v7, #2048
    v.sub        v8, v0, v6
    @p1 v.sel        v9, v3, v5
    v.sub        v3, v0, v7
    @p2 v.sel        v5, v8, v6
    v.mul        v6, v9, v1
    v.sub        v1, v2, v7
    v.cmp.lt     p1, v7, v0
    v.add        v0, v5, v6
    v.cmp.lt     p2, v7, v2
    s.ld.d       s2, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    @p1 v.sel        v2, v3, v7
    @p2 v.sel        v2, v1, v7
    v.st.scatter.w [s2, v0], v4
__rctx_next:
    exit
