import os,select,subprocess,sys
from pathlib import Path
fd=os.pidfd_open(int(sys.argv[1])); select.select([fd],[],[]); os.close(fd)
h=Path.home(); root=h/'r41_current_x8_equal_output_20261101'
subprocess.run([str(h/'flux-venv/bin/python'),str(root/'tools/performance_harness/default_change_audit.py'),'compare','--control',str(h/'r41_current_div_base_113_20261101/report.json'),'--candidate',str(h/'r41_current_div_x8_equal_output_113_20261101/report.json'),'--out',str(h/'r41_x8_equal_output_audit_compare_20261101.json')],cwd=root,check=True)
