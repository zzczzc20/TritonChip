    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.addi       s3, s2, #4                      // &in_ptr0[1] (a constant offset, x4)
    s.ld.w       s4, [s2, #0]                    // one element, not a vector
    s.ld.w       s2, [s3, #0]                    // one element, not a vector
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.sub        s1, s2, s4
    s.st.w       [s3, #0], s1                    // lane 0 of a broadcast is one word
    exit
    exit
