    s.rdspecial  s1, arg_base
    s.rdspecial  s2, arg_base
    s.ld.d       s3, [s1, #48]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.movz       s1, #2048
    s.movz       s4, #2
    s.ld.d       s5, [s2, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.addi       s6, s3, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 1)
    s.movz       s3, #16
    .li       s7, #1103806595072
    s.movz       s8, #0
    v.movi       v0, #0
    v.movi       v1, #0
    s.ld.d       s9, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s10, #0
    s.ld.d       s10, [s2, #16]                  // in_ptr2: device_ptr64 at arg_base+16
    s.movz       s11, #2048
    s.movz       s12, #16
    s.ld.d       s13, [s2, #24]                  // out_ptr1: device_ptr64 at arg_base+24
    s.ld.d       s14, [s2, #32]                  // out_ptr2: device_ptr64 at arg_base+32
    s.st.d       [s6, #0], s5
    s.st.d       [s6, #8], s1
    s.addi       s1, s8, #0
    s.st.d       [s6, #48], s4
    s.st.d       [s6, #88], s3
    s.st.d       [s6, #104], s7
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    v.mov        v1, v0
for_1:
    s.cmp.ge     s2, s1, s11
    br.nz        s2, endfor_2
    s.muli       s2, s1, #2
    v.splat      v0, s1
    v.iota       v3                              // arange(0, VLEN)
    s.movz       s3, #2048
    v.splat      v4, s1
    v.add        v5, v0, v3
    v.movi       v0, #0
    v.splat      v3, s3
    s.shli       s3, s1, #1                      // element offset -> bytes (x2)
    v.add        v6, v4, v2
    v.movi       v4, #2048
    v.cmp.ge     p1, v5, v0
    v.cmp.lt     p2, v5, v3
    s.add        s4, s9, s3                      // &in_ptr0[...]
    s.add        s3, s5, s2
    p.and        p3, p1, p2
    v.cmp.lt     p1, v6, v4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s4, #0]
    v.movi       v3, #0
    s.add        s2, s1, s12
    s.movz       s4, #1
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s3, #0]
    vf.cvt.bf16.f32 v5, v0
    vf.cvt.bf16.f32 v0, v4
    vf.add       v4, v5, v0
    vf.mul       v0, v4, v4
    vf.add       v4, v1, v0
    @p1 v.sel        v0, v4, v1
    v.mov        v3, v0
    v.mov        v1, v3
    s.mov        s1, s2
    br.nz        s4, for_1
endfor_2:
    vf.reduce.add.b v0, v1
    v.movi       v1, #0
    s.addi       s1, s8, #0
    vf.add       v3, v0, v1
for_3:
    s.cmp.ge     s2, s1, s11
    br.nz        s2, endfor_4
    .li       s2, #1157627904
    v.splat      v0, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1065353216
    v.splat      v1, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v4, v0                          // ISA 8.8: <= 2**-22 relative
    .li       s2, #897988541
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.muli       s2, s1, #2
    v.splat      v6, s1
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s3, #2048
    v.splat      v8, s1
    v.add        v9, v6, v7
    v.movi       v6, #0
    v.splat      v7, s3
    s.shli       s3, s1, #1                      // element offset -> bytes (x2)
    v.add        v10, v8, v2
    v.movi       v8, #2048
    v.cmp.ge     p1, v9, v6
    v.cmp.lt     p2, v9, v7
    s.add        s4, s9, s3                      // &in_ptr0[...]
    s.add        s6, s5, s2
    p.and        p3, p1, p2
    .li       s2, #1077936128
    v.splat      v6, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #3204448256
    v.splat      v7, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.lt     p1, v10, v8
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v8, [s4, #0]
    s.add        s2, s10, s3                     // &in_ptr2[...]
    vf.fms       v9, v0, v4, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s6, #0]
    vf.cvt.bf16.f32 v10, v8
    vf.fms       v8, v4, v9, v4
    vf.cvt.bf16.f32 v9, v1
    vf.neg       v1, v8                          // Newton step: r0*(2 - x*r0)
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v8, [s2, #0]
    vf.add       v11, v10, v9
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v9, v1, v4
    vf.mul       v1, v3, v9                      // a/y: faithful quotient
    vf.cvt.bf16.f32 v4, v8
    s.add        s2, s13, s3                     // &out_ptr1[...]
    s.add        s4, s14, s3                     // &out_ptr2[...]
    vf.fms       v8, v1, v0, v3
    s.add        s3, s1, s12
    s.movz       s6, #1
    vf.fms       v0, v8, v9, v1
    vf.neg       v8, v0                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v8, v8
    @p2 v.sel        v0, v8, v1
    vf.add       v1, v0, v5
    v.rsqrt.approx v0, v1                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v0, v0
    vf.mul       v8, v0, v7
    vf.fms       v7, v1, v5, v6
    vf.mul       v1, v8, v7                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v5, v1, v0
    v.extract    s7, v5, #0
    v.splat      v0, s7
    vf.mul       v1, v11, v0
    vf.mul       v0, v4, v1
    vf.cvt.f32.bf16 v1, v0
    @p1 v.st.h       [s2, #0], v1
    @p1 v.st.h       [s4, #0], v1
    s.mov        s1, s3
    br.nz        s6, for_3
endfor_4:
    exit
    exit
