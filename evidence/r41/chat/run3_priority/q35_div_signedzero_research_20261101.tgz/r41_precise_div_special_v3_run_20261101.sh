#!/usr/bin/env bash
set -eu
root="$1";name="$2"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 CUDA_VISIBLE_DEVICES=
export PYTHONPATH="$root:$root/python:$root/compiler/python:$root/tools/asm:$root/tools/performance_harness/systemc"
export TNCA_TLM_BINARY="$HOME/r41_vl_reason_dp/build/tnca-chip" TNCA_TLM_CONFIG="$HOME/r41_vl_reason_dp/src/tools/performance_harness/systemc/configs/r41-mma-dp.cfg" TNCA_TLM_MEMORY_BYTES=0x200000000 TNCA_DRAM_PATH=fast TNCA_TLM_UNTIMED_COLD=0 TNCA_TLM_OUT="$HOME/r41_precise_div_special_v3_${name}_20261101_tlm" R41_DIV_SPECIAL_OUT="$HOME/r41_precise_div_special_v3_${name}_20261101.json"
exec "$HOME/flux-venv/bin/python" -u "$HOME/r41_precise_div_special_v3_20261101.py"
