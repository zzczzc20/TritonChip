    s.rdspecial  s1, arg_base
    s.movz       s2, #256
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #0
    s.rdspecial  s5, role_id
    s.rdspecial  s6, npid.x
    s.ld.d       s7, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
__rctx_program:
    v.movi       v0, #4096
    v.movi       v1, #0
    v.iota       v2                              // arange(0, VLEN)
    v.movi       v3, #16
    v.movi       v4, #32
    v.movi       v5, #48
    v.movi       v6, #64
    v.movi       v7, #80
    v.movi       v8, #96
    v.movi       v9, #112
    v.sub        v10, v1, v0
    v.cmp.lt     p1, v0, v1
    // tiled element-wise program: 256 lanes as 2 tiles of 128 (1 tensor-engine transfers, one load buffer(s))
    s.mul        s1, s5, s2
    s.addi       s8, s4, #0
    v.add        v11, v2, v3
    v.add        v3, v2, v4
    v.add        v4, v2, v5
    v.add        v5, v2, v6
    v.add        v6, v2, v7
    v.add        v7, v2, v8
    v.add        v8, v2, v9
    @p1 v.sel        v9, v10, v0
    v.movi       v0, #4095
    v.movi       v9, #12
    v.movi       v10, #4128
tiles_1:
    // tile 1 of the iteration: lanes t0 + 128
    s.addi       s9, s8, #128
    // tile 0 of the iteration: lanes t0 + 0
    s.add        s10, s1, s8
    s.add        s11, s1, s9
    v.splat      v12, s10
    v.splat      v13, s11
    v.add        v14, v12, v2
    v.add        v15, v12, v11
    v.add        v16, v12, v3
    v.add        v17, v12, v4
    v.add        v18, v12, v5
    v.add        v19, v12, v6
    v.add        v20, v12, v7
    v.add        v21, v12, v8
    v.sub        v12, v1, v14
    v.sub        v22, v1, v15
    v.sub        v23, v1, v16
    v.sub        v24, v1, v17
    v.sub        v25, v1, v18
    v.sub        v26, v1, v19
    v.sub        v27, v1, v20
    v.sub        v28, v1, v21
    v.cmp.lt     p1, v14, v1
    v.cmp.lt     p2, v15, v1
    v.cmp.lt     p3, v16, v1
    v.cmp.lt     p4, v17, v1
    v.cmp.lt     p5, v18, v1
    v.cmp.lt     p6, v19, v1
    v.cmp.lt     p7, v20, v1
    v.cmp.lt     p8, v21, v1
    @p1 v.sel        v29, v12, v14
    @p2 v.sel        v12, v22, v15
    @p3 v.sel        v14, v23, v16
    @p4 v.sel        v15, v24, v17
    @p5 v.sel        v16, v25, v18
    @p6 v.sel        v17, v26, v19
    @p7 v.sel        v18, v27, v20
    @p8 v.sel        v19, v28, v21
    v.lshr       v20, v29, v9
    v.and        v21, v29, v0
    v.lshr       v22, v12, v9
    v.and        v23, v12, v0
    v.and        v12, v14, v0
    v.and        v24, v15, v0
    v.and        v25, v16, v0
    v.and        v26, v17, v0
    v.and        v27, v18, v0
    v.and        v28, v19, v0
    v.sub        v29, v1, v20
    v.sub        v30, v1, v21
    v.sub        v31, v1, v22
    v.sub        v32, v1, v23
    v.sub        v33, v1, v12
    v.sub        v34, v1, v24
    v.sub        v35, v1, v25
    v.sub        v36, v1, v26
    v.sub        v37, v1, v27
    v.sub        v38, v1, v28
    @p1 v.sel        v39, v29, v20
    @p1 v.sel        v20, v30, v21
    v.lshr       v21, v14, v9
    v.lshr       v14, v15, v9
    @p2 v.sel        v15, v31, v22
    v.sub        v22, v1, v21
    v.sub        v29, v1, v14
    @p2 v.sel        v30, v32, v23
    v.lshr       v23, v16, v9
    v.lshr       v16, v17, v9
    @p3 v.sel        v17, v22, v21
    v.sub        v21, v1, v23
    v.sub        v22, v1, v16
    @p4 v.sel        v31, v29, v14
    @p5 v.sel        v14, v21, v23
    @p3 v.sel        v21, v33, v12
    v.lshr       v12, v18, v9
    v.lshr       v18, v19, v9
    @p6 v.sel        v19, v22, v16
    v.sub        v16, v1, v12
    v.sub        v22, v1, v18
    @p4 v.sel        v23, v34, v24
    s.shli       s9, s10, #1
    @p7 v.sel        v24, v16, v12
    s.add        s10, s3, s9
    @p8 v.sel        v12, v22, v18
    v.ld.h       v16, [s10, #0]
    @p5 v.sel        v18, v35, v25
    v.add        v22, v13, v2
    @p6 v.sel        v25, v36, v26
    v.add        v26, v13, v11
    v.add        v29, v13, v3
    v.add        v32, v13, v4
    v.add        v33, v13, v5
    v.add        v34, v13, v6
    v.add        v35, v13, v7
    @p7 v.sel        v36, v37, v27
    v.add        v27, v13, v8
    v.sub        v13, v1, v22
    v.cmp.lt     p1, v22, v1
    v.ld.h       v37, [s10, #32]
    @p1 v.sel        v40, v13, v22
    @p8 v.sel        v13, v38, v28
    v.sub        v22, v1, v26
    v.sub        v28, v1, v29
    v.sub        v38, v1, v32
    v.sub        v41, v1, v33
    v.sub        v42, v1, v34
    v.cmp.lt     p2, v26, v1
    v.cmp.lt     p3, v29, v1
    v.cmp.lt     p4, v32, v1
    v.cmp.lt     p5, v33, v1
    v.cmp.lt     p6, v34, v1
    @p2 v.sel        v43, v22, v26
    @p3 v.sel        v22, v28, v29
    @p4 v.sel        v26, v38, v32
    @p5 v.sel        v28, v41, v33
    @p6 v.sel        v29, v42, v34
    v.ld.h       v32, [s10, #64]
    v.and        v33, v40, v0
    v.and        v34, v43, v0
    v.and        v38, v22, v0
    v.and        v41, v26, v0
    v.and        v42, v28, v0
    v.and        v44, v29, v0
    v.sub        v45, v1, v33
    v.sub        v46, v1, v34
    v.sub        v47, v1, v38
    v.sub        v48, v1, v41
    v.sub        v49, v1, v42
    v.sub        v50, v1, v44
    @p1 v.sel        v51, v45, v33
    v.ld.h       v33, [s10, #96]
    @p2 v.sel        v45, v46, v34
    @p3 v.sel        v34, v47, v38
    @p4 v.sel        v38, v48, v41
    @p5 v.sel        v41, v49, v42
    @p6 v.sel        v42, v50, v44
    v.ld.h       v44, [s10, #128]
    v.cmp.lt     p7, v35, v1
    v.ld.h       v46, [s10, #160]
    v.sub        v47, v1, v35
    v.ld.h       v48, [s10, #192]
    @p7 v.sel        v49, v47, v35
    v.ld.h       v35, [s10, #224]
    v.sub        v47, v1, v27
    v.cmp.lt     p8, v27, v1
    s.shli       s9, s11, #1
    @p8 v.sel        v50, v47, v27
    s.add        s10, s3, s9
    v.lshr       v27, v40, v9
    v.lshr       v40, v43, v9
    v.lshr       v43, v22, v9
    v.lshr       v22, v26, v9
    v.lshr       v26, v28, v9
    v.lshr       v28, v29, v9
    v.lshr       v29, v49, v9
    v.lshr       v47, v50, v9
    v.ld.h       v52, [s10, #0]
    v.and        v53, v49, v0
    v.and        v49, v50, v0
    v.sub        v50, v1, v27
    v.sub        v54, v1, v40
    v.sub        v55, v1, v43
    v.sub        v56, v1, v22
    v.sub        v57, v1, v26
    v.sub        v58, v1, v28
    v.sub        v59, v1, v29
    v.sub        v60, v1, v47
    v.sub        v61, v1, v53
    v.sub        v62, v1, v49
    @p1 v.sel        v63, v50, v27
    v.ld.h       v27, [s10, #32]
    @p2 v.sel        v50, v54, v40
    @p3 v.sel        v40, v55, v43
    @p4 v.sel        v43, v56, v22
    @p5 v.sel        v22, v57, v26
    @p6 v.sel        v26, v58, v28
    @p7 v.sel        v28, v59, v29
    @p8 v.sel        v29, v60, v47
    @p7 v.sel        v47, v61, v53
    @p8 v.sel        v53, v62, v49
    v.mul        v49, v39, v10
    v.mul        v39, v15, v10
    v.mul        v15, v17, v10
    v.mul        v17, v31, v10
    v.ld.h       v31, [s10, #64]
    v.mul        v54, v14, v10
    v.mul        v14, v19, v10
    v.mul        v19, v24, v10
    v.mul        v24, v12, v10
    v.mul        v12, v63, v10
    v.mul        v55, v50, v10
    v.mul        v50, v40, v10
    v.mul        v40, v43, v10
    v.mul        v43, v22, v10
    v.mul        v22, v26, v10
    v.mul        v26, v28, v10
    v.mul        v28, v29, v10
    v.add        v29, v20, v49
    v.ld.h       v20, [s10, #96]
    v.add        v49, v30, v39
    v.add        v30, v21, v15
    v.add        v15, v23, v17
    v.add        v17, v18, v54
    v.add        v18, v25, v14
    v.add        v14, v36, v19
    v.add        v19, v13, v24
    v.add        v13, v51, v12
    v.add        v12, v45, v55
    v.add        v21, v34, v50
    v.add        v23, v38, v40
    v.add        v24, v41, v43
    v.add        v25, v42, v22
    v.ld.h       v22, [s10, #128]
    v.add        v34, v47, v26
    v.add        v26, v53, v28
    v.ld.h       v28, [s10, #160]
    v.ld.h       v36, [s10, #192]
    v.ld.h       v38, [s10, #224]
    v.st.scatter.h [s7, v29], v16
    v.st.scatter.h [s7, v49], v37
    v.st.scatter.h [s7, v30], v32
    v.st.scatter.h [s7, v15], v33
    v.st.scatter.h [s7, v17], v44
    v.st.scatter.h [s7, v18], v46
    v.st.scatter.h [s7, v14], v48
    v.st.scatter.h [s7, v19], v35
    v.st.scatter.h [s7, v13], v52
    v.st.scatter.h [s7, v12], v27
    v.st.scatter.h [s7, v21], v31
    v.st.scatter.h [s7, v23], v20
    v.st.scatter.h [s7, v24], v22
    v.st.scatter.h [s7, v25], v28
    v.st.scatter.h [s7, v34], v36
    v.st.scatter.h [s7, v26], v38
    s.addi       s8, s8, #256
    s.cmp.lt     s9, s8, s2
    br.nz        s9, tiles_1
endtiles_2:
__rctx_next:
    s.addi       s1, s5, #4                      // the next program of this context: + 4
    s.cmp.lt     s8, s1, s6
    s.mov        s5, s1
    br.nz        s8, __rctx_program
    exit
