    s.rdspecial  s1, arg_base
    s.movz       s2, #256
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #0
    s.rdspecial  s5, role_id
    s.rdspecial  s6, npid.x
    s.ld.d       s7, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
__rctx_program:
    v.movi       v0, #32
    v.movi       v1, #64
    v.movi       v2, #0
    v.movi       v3, #2048
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v5, #16
    v.movi       v6, #48
    v.movi       v7, #80
    v.movi       v8, #96
    v.movi       v9, #112
    v.sub        v10, v2, v0
    v.sub        v11, v2, v1
    v.sub        v12, v2, v3
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    // tiled element-wise program: 256 lanes as 2 tiles of 128 (1 tensor-engine transfers, one load buffer(s))
    s.mul        s1, s5, s2
    s.addi       s8, s4, #0
    v.add        v13, v4, v5
    v.add        v5, v4, v0
    v.add        v14, v4, v6
    v.add        v6, v4, v1
    v.add        v15, v4, v7
    v.add        v7, v4, v8
    v.add        v8, v4, v9
    @p1 v.sel        v9, v10, v0
    v.cmp.lt     p1, v3, v2
    v.movi       v9, #31
    v.movi       v10, #5
    @p2 v.sel        v16, v11, v1
    v.movi       v1, #63
    @p1 v.sel        v11, v12, v3
    v.movi       v3, #11
    v.movi       v11, #256
    v.movi       v12, #384
tiles_1:
    // tile 0 of the iteration: lanes t0 + 0
    s.add        s9, s1, s8
    v.splat      v16, s9
    v.add        v17, v16, v4
    v.add        v18, v16, v13
    v.add        v19, v16, v5
    v.add        v20, v16, v14
    v.add        v21, v16, v6
    v.add        v22, v16, v15
    v.add        v23, v16, v7
    v.add        v24, v16, v8
    v.cmp.lt     p1, v17, v2
    v.sub        v16, v2, v17
    @p1 v.sel        v25, v16, v17
    v.and        v16, v25, v9
    v.sub        v17, v2, v16
    @p1 v.sel        v26, v17, v16
    v.cmp.lt     p2, v18, v2
    v.sub        v16, v2, v18
    @p2 v.sel        v17, v16, v18
    v.and        v16, v17, v9
    v.sub        v18, v2, v16
    @p2 v.sel        v27, v18, v16
    v.cmp.lt     p3, v19, v2
    v.sub        v16, v2, v19
    @p3 v.sel        v18, v16, v19
    v.and        v16, v18, v9
    v.sub        v19, v2, v16
    @p3 v.sel        v28, v19, v16
    v.cmp.lt     p4, v20, v2
    v.sub        v16, v2, v20
    @p4 v.sel        v19, v16, v20
    v.and        v16, v19, v9
    v.sub        v20, v2, v16
    @p4 v.sel        v29, v20, v16
    v.cmp.lt     p5, v21, v2
    v.sub        v16, v2, v21
    @p5 v.sel        v20, v16, v21
    v.and        v16, v20, v9
    v.sub        v21, v2, v16
    @p5 v.sel        v30, v21, v16
    v.cmp.lt     p6, v22, v2
    v.sub        v16, v2, v22
    @p6 v.sel        v21, v16, v22
    v.and        v16, v21, v9
    v.sub        v22, v2, v16
    @p6 v.sel        v31, v22, v16
    v.cmp.lt     p7, v23, v2
    v.sub        v16, v2, v23
    @p7 v.sel        v22, v16, v23
    v.and        v16, v22, v9
    v.sub        v23, v2, v16
    @p7 v.sel        v32, v23, v16
    v.cmp.lt     p8, v24, v2
    v.sub        v16, v2, v24
    @p8 v.sel        v23, v16, v24
    v.and        v16, v23, v9
    v.sub        v24, v2, v16
    @p8 v.sel        v33, v24, v16
    v.lshr       v16, v25, v10
    v.sub        v24, v2, v16
    @p1 v.sel        v34, v24, v16
    v.lshr       v16, v17, v10
    v.sub        v24, v2, v16
    @p2 v.sel        v35, v24, v16
    v.lshr       v16, v18, v10
    v.sub        v24, v2, v16
    @p3 v.sel        v36, v24, v16
    v.lshr       v16, v19, v10
    v.sub        v24, v2, v16
    @p4 v.sel        v37, v24, v16
    v.lshr       v16, v20, v10
    v.sub        v24, v2, v16
    @p5 v.sel        v38, v24, v16
    v.lshr       v16, v21, v10
    v.sub        v24, v2, v16
    @p6 v.sel        v39, v24, v16
    v.lshr       v16, v22, v10
    v.sub        v24, v2, v16
    @p7 v.sel        v40, v24, v16
    v.lshr       v16, v23, v10
    v.sub        v24, v2, v16
    @p8 v.sel        v41, v24, v16
    v.cmp.lt     p9, v34, v2
    v.sub        v16, v2, v34
    @p9 v.sel        v24, v16, v34
    v.and        v16, v24, v1
    v.sub        v24, v2, v16
    @p9 v.sel        v34, v24, v16
    v.cmp.lt     p9, v35, v2
    v.sub        v16, v2, v35
    @p9 v.sel        v24, v16, v35
    v.and        v16, v24, v1
    v.sub        v24, v2, v16
    @p9 v.sel        v35, v24, v16
    v.cmp.lt     p9, v36, v2
    v.sub        v16, v2, v36
    @p9 v.sel        v24, v16, v36
    v.and        v16, v24, v1
    v.sub        v24, v2, v16
    @p9 v.sel        v36, v24, v16
    v.cmp.lt     p9, v37, v2
    v.sub        v16, v2, v37
    @p9 v.sel        v24, v16, v37
    v.and        v16, v24, v1
    v.sub        v24, v2, v16
    @p9 v.sel        v37, v24, v16
    v.cmp.lt     p9, v38, v2
    v.sub        v16, v2, v38
    @p9 v.sel        v24, v16, v38
    v.and        v16, v24, v1
    v.sub        v24, v2, v16
    @p9 v.sel        v38, v24, v16
    v.cmp.lt     p9, v39, v2
    v.sub        v16, v2, v39
    @p9 v.sel        v24, v16, v39
    v.and        v16, v24, v1
    v.sub        v24, v2, v16
    @p9 v.sel        v39, v24, v16
    v.cmp.lt     p9, v40, v2
    v.sub        v16, v2, v40
    @p9 v.sel        v24, v16, v40
    v.and        v16, v24, v1
    v.sub        v24, v2, v16
    @p9 v.sel        v40, v24, v16
    v.cmp.lt     p9, v41, v2
    v.sub        v16, v2, v41
    @p9 v.sel        v24, v16, v41
    v.and        v16, v24, v1
    v.sub        v24, v2, v16
    @p9 v.sel        v41, v24, v16
    v.lshr       v16, v25, v3
    v.sub        v24, v2, v16
    @p1 v.sel        v25, v24, v16
    v.lshr       v16, v17, v3
    v.sub        v17, v2, v16
    @p2 v.sel        v24, v17, v16
    v.lshr       v16, v18, v3
    v.sub        v17, v2, v16
    @p3 v.sel        v18, v17, v16
    v.lshr       v16, v19, v3
    v.sub        v17, v2, v16
    @p4 v.sel        v19, v17, v16
    v.lshr       v16, v20, v3
    v.sub        v17, v2, v16
    @p5 v.sel        v20, v17, v16
    v.lshr       v16, v21, v3
    v.sub        v17, v2, v16
    @p6 v.sel        v21, v17, v16
    v.lshr       v16, v22, v3
    v.sub        v17, v2, v16
    @p7 v.sel        v22, v17, v16
    v.lshr       v16, v23, v3
    v.sub        v17, v2, v16
    @p8 v.sel        v23, v17, v16
    v.add        v16, v26, v11
    v.add        v17, v27, v11
    v.add        v26, v28, v11
    v.add        v27, v29, v11
    v.add        v28, v30, v11
    v.add        v29, v31, v11
    v.add        v30, v32, v11
    v.add        v31, v33, v11
    v.mul        v32, v25, v0
    v.mul        v25, v24, v0
    v.mul        v24, v18, v0
    v.mul        v18, v19, v0
    v.mul        v19, v20, v0
    v.mul        v20, v21, v0
    v.mul        v21, v22, v0
    v.mul        v22, v23, v0
    v.add        v23, v16, v32
    v.add        v16, v17, v25
    v.add        v17, v26, v24
    v.add        v24, v27, v18
    v.add        v18, v28, v19
    v.add        v19, v29, v20
    v.add        v20, v30, v21
    v.add        v21, v31, v22
    v.mul        v22, v34, v12
    v.mul        v25, v35, v12
    v.mul        v26, v36, v12
    v.mul        v27, v37, v12
    v.mul        v28, v38, v12
    v.mul        v29, v39, v12
    v.mul        v30, v40, v12
    v.mul        v31, v41, v12
    v.add        v32, v23, v22
    v.add        v22, v16, v25
    v.add        v16, v17, v26
    v.add        v17, v24, v27
    v.add        v23, v18, v28
    v.add        v18, v19, v29
    v.add        v19, v20, v30
    v.add        v20, v21, v31
    v.ld.gather.h v21, [s3, v32]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.h v24, [s3, v22]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.h v22, [s3, v16]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.h v16, [s3, v17]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.h v17, [s3, v23]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.h v23, [s3, v18]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.h v18, [s3, v19]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.h v19, [s3, v20]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v20, v21
    vf.cvt.f16.f32 v21, v24
    vf.cvt.f16.f32 v24, v22
    vf.cvt.f16.f32 v22, v16
    vf.cvt.f16.f32 v16, v17
    vf.cvt.f16.f32 v17, v23
    vf.cvt.f16.f32 v23, v18
    vf.cvt.f16.f32 v18, v19
    s.shli       s10, s9, #2
    s.add        s9, s7, s10
    v.st.w       [s9, #0], v20
    v.st.w       [s9, #64], v21
    v.st.w       [s9, #128], v24
    v.st.w       [s9, #192], v22
    v.st.w       [s9, #256], v16
    v.st.w       [s9, #320], v17
    v.st.w       [s9, #384], v23
    v.st.w       [s9, #448], v18
    s.addi       s8, s8, #128
    s.cmp.lt     s9, s8, s2
    br.nz        s9, tiles_1
endtiles_2:
__rctx_next:
    s.addi       s1, s5, #4                      // the next program of this context: + 4
    s.cmp.lt     s8, s1, s6
    s.mov        s5, s1
    br.nz        s8, __rctx_program
    exit
