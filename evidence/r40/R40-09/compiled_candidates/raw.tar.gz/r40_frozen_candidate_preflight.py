"""Fixed candidate compile preflight only; no selection, ranking or holdout tuning."""
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
root=Path.home()/'tritonchip-r40-convergence-bbb9321'
out=Path('/tmp/r40_frozen_candidate_preflight_bbb9321')
out.mkdir(exist_ok=False)
subset=json.loads((root/'spec/r40/suites/hbm-core.json').read_text())
identity={'commit':'bbb93210f5df8598acd9b4a1b632d8965cd84a55','software_tree':'files:b618b58f337359d77d81b6d2e940b0e19fd164a89a526aaa7f05926d5dc243f5','source_archive_sha256':'1f3e7d05a1a2f457fe7acf7bfe2e560fe733671eba567e3f09898f9799328b07','contract_sha256':'49fc0e02733139707ae2292eff2ef893e76e73f0723d0d002b2e7e1864af71c8','candidates':[16,32],'selection':'none; fixed before preflight','performance':'not-measured','gate_status':'not-measured','image':'none: compile-only'}
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
for i,p in enumerate(subset['points']):
    start=time.monotonic()
    for width in identity['candidates']:
        stem=f'{i:02d}_block{width}'
        remaining=600-(time.monotonic()-start)
        if remaining<=0:
            result={'point':p['id'],'width':width,'status':'budget-exhausted','performance':'not-measured'}
        else:
            command=[sys.executable,'-u','-m','archbench.run','--child','--platform','tnca','--backend','sim-file','--profile','core-vrf-sync-v5','--compile-only','--point',p['id'],'--set',f'TNCA_MAX_BLOCK={width}','--set','TNCA_RCTX_ROLES=0']
            try:
                with (out/(stem+'.log')).open('w') as log:
                    child=subprocess.run(command,cwd=root,env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT,timeout=remaining)
                lines=(out/(stem+'.log')).read_text().splitlines()
                records=[json.loads(line.removeprefix('ARCHBENCH-RECORD ')) for line in lines if line.startswith('ARCHBENCH-RECORD ')]
                result={'point':p['id'],'point_sha256':p['sha256'],'width':width,'returncode':child.returncode,'records':records,'elapsed_graph_s':time.monotonic()-start,'performance':'not-measured'}
            except subprocess.TimeoutExpired:
                result={'point':p['id'],'width':width,'status':'timeout','elapsed_graph_s':time.monotonic()-start,'performance':'not-measured'}
        (out/(stem+'.json')).write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps({'point':p['id'],'width':width,'status':result.get('status',[(r['status'],r.get('problems')) for r in result.get('records',[])])}),flush=True)
print('PREFLIGHT FINISHED; no performance gate measured',flush=True)
