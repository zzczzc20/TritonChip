# AOT ID: ['0_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream
from torch._inductor.runtime.runtime_utils import assert_tensor_metadata

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/55/c55s5az6uyenjbdrpyokjt6npdiud2zulftvgmto7buaktimb2pd.py
# Topologically Sorted Source Nodes: [inputs_embeds, float_2, pow_1, mean, add, rsqrt, output, float_3, add_1, output_1, hidden_states], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add => add
#   add_1 => add_1
#   float_2 => convert_element_type_4
#   float_3 => convert_element_type_5
#   hidden_states => convert_element_type_6
#   inputs_embeds => embedding
#   mean => mean
#   output => mul_3
#   output_1 => mul_4
#   pow_1 => pow_1
#   rsqrt => rsqrt
# Graph fragment:
#   %arg0_1 : Tensor "i64[1, 128][128, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %arg1_1 : Tensor "bf16[248320, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %buf0 : Tensor "f32[1, 128, 1][128, 1, 128]tnca:0" = PlaceHolder[target=buf0]
#   %arg4_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg4_1]
#   %embedding : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg1_1, %arg0_1), kwargs = {})
#   %convert_element_type_4 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%embedding, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_4, 2), kwargs = {})
#   %mean : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [-1], True), kwargs = {})
#   %add : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean, 1e-06), kwargs = {})
#   %rsqrt : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %mul_3 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_4, %rsqrt), kwargs = {})
#   %convert_element_type_5 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg4_1, torch.float32), kwargs = {})
#   %add_1 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_5, 1.0), kwargs = {})
#   %mul_4 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_3, %add_1), kwargs = {})
#   %convert_element_type_6 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=4] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_4, torch.bfloat16), kwargs = {})
#   return %buf0,%convert_element_type_6
triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0 = async_compile.triton('triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 128, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 1024, 'r0_': 1052672}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0(in_ptr0, in_ptr1, in_ptr2, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 128
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), None, eviction_policy='evict_last')
    _tmp6 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tl.device_assert((0 <= tmp0) & (tmp0 < 248320), "index out of bounds: 0 <= tmp0 < 248320")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 2048*tmp0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp3 * tmp3
        tmp5 = tl.broadcast_to(tmp4, [R0_BLOCK])
        tmp7 = _tmp6 + tmp5
        _tmp6 = tl.where(r0_mask, tmp7, _tmp6)
    tmp6 = triton_helpers.promote_to_tensor(tl.sum(_tmp6, 0))
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp17 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp0) & (tmp0 < 248320), "index out of bounds: 0 <= tmp0 < 248320")
        tmp9 = tl.load(in_ptr1 + (r0_1 + 2048*tmp0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp10 = tmp9.to(tl.float32)
        tmp11 = tl.full([1], 2048.0, tl.float32)
        tmp12 = (tmp6 / tmp11)
        tmp13 = tl.full([1], 1e-06, tl.float32)
        tmp14 = tmp12 + tmp13
        tmp15 = libdevice.rsqrt(tmp14)
        tmp16 = tmp10 * tmp15
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tl.full([1], 1.0, tl.float32)
        tmp20 = tmp18 + tmp19
        tmp21 = tmp16 * tmp20
        tmp22 = tmp21.to(tl.float32)
        tl.store(out_ptr1 + (r0_1 + 2048*x0), tmp22, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/3q/c3q45sbqu7bzc3gu6fxg7lpxgz4hikyzmc7cibrc5iqj2vxkokoa.py
# Topologically Sorted Source Nodes: [inputs_embeds, float_2, pow_1, mean, add, rsqrt, output, float_3, add_1, output_1, hidden_states, mixed_qkv], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   add => add
#   add_1 => add_1
#   float_2 => convert_element_type_4
#   float_3 => convert_element_type_5
#   hidden_states => convert_element_type_6
#   inputs_embeds => embedding
#   mean => mean
#   mixed_qkv => mm, permute, view_2
#   output => mul_3
#   output_1 => mul_4
#   pow_1 => pow_1
#   rsqrt => rsqrt
# Graph fragment:
#   %convert_element_type_6 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0" = PlaceHolder[target=convert_element_type_6]
#   %arg5_1 : Tensor "bf16[6144, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg5_1]
#   %embedding : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg1_1, %arg0_1), kwargs = {})
#   %convert_element_type_4 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%embedding, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_4, 2), kwargs = {})
#   %mean : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [-1], True), kwargs = {})
#   %add : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean, 1e-06), kwargs = {})
#   %rsqrt : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %mul_3 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_4, %rsqrt), kwargs = {})
#   %convert_element_type_5 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg4_1, torch.float32), kwargs = {})
#   %add_1 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_5, 1.0), kwargs = {})
#   %mul_4 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_3, %add_1), kwargs = {})
#   %convert_element_type_6 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=4] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_4, torch.bfloat16), kwargs = {})
#   %view_2 : Tensor "bf16[128, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_6, [128, 2048]), kwargs = {})
#   %permute : Tensor "bf16[2048, 6144][1, 2048]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg5_1, [1, 0]), kwargs = {})
#   %mm : Tensor "bf16[128, 6144][6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_2, %permute), kwargs = {})
#   return %mm
triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1 = async_compile.triton('triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*bf16', 'arg_B': '*bf16', 'out_ptr0': '*bf16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 128
    N = 6144
    K = 2048
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 2048
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2048

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2048*idx_m
        a = tl.load(A + (xindex))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 6144*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2048*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 6144*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/kd/ckdqzahpemt23c4ufdp3iq5pwkolgdfufuv7tz62oeearyoslyv5.py
# Topologically Sorted Source Nodes: [mixed_qkv, mixed_qkv_1, conv1d, squeeze, unsqueeze, out, out_1], Original ATen: [aten._unsafe_view, aten.transpose, aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
# Source node to ATen node mapping:
#   conv1d => add_2, add_3, add_4, constant_pad_nd, convert_element_type_15, convert_element_type_16, convert_element_type_17, mul_5, mul_6, mul_7, mul_8, select_24, select_25, select_26, select_27, select_28, select_29, select_30, select_31, slice_18, slice_19, slice_20, slice_21, view_11, view_12, view_13, view_14
#   mixed_qkv => view_3
#   mixed_qkv_1 => permute_1
#   out => slice_22
#   out_1 => convert_element_type_18
#   squeeze => squeeze
#   unsqueeze => unsqueeze_8
# Graph fragment:
#   %mm : Tensor "bf16[128, 6144][6144, 1]tnca:0" = PlaceHolder[target=mm]
#   %arg9_1 : Tensor "bf16[6144, 1, 4][4, 4, 1]tnca:0" = PlaceHolder[target=arg9_1]
#   %view_3 : Tensor "bf16[1, 128, 6144][786432, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [1, 128, 6144]), kwargs = {})
#   %permute_1 : Tensor "bf16[1, 6144, 128][786432, 1, 6144]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_3, [0, 2, 1]), kwargs = {})
#   %convert_element_type_15 : Tensor "f32[1, 6144, 128][786432, 1, 6144]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_1, torch.float32), kwargs = {})
#   %constant_pad_nd : Tensor "f32[1, 6144, 134][823296, 134, 1]tnca:0"[num_users=4] = call_function[target=torch.ops.aten.constant_pad_nd.default](args = (%convert_element_type_15, [3, 3], 0.0), kwargs = {})
#   %slice_18 : Tensor "f32[1, 6144, 131][823296, 134, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%constant_pad_nd, 2, 0, 131), kwargs = {})
#   %squeeze : Tensor "bf16[6144, 4][4, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.squeeze.dim](args = (%arg9_1, 1), kwargs = {})
#   %unsqueeze_8 : Tensor "bf16[6144, 1, 4][4, 4, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%squeeze, 1), kwargs = {})
#   %convert_element_type_16 : Tensor "f32[6144, 1, 4][4, 4, 1]tnca:0"[num_users=4] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_8, torch.float32), kwargs = {})
#   %select_24 : Tensor "f32[6144, 4][4, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%convert_element_type_16, 1, 0), kwargs = {})
#   %select_25 : Tensor "f32[6144][4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_24, 1, 0), kwargs = {})
#   %view_11 : Tensor "f32[1, 6144, 1][24576, 4, 4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%select_25, [1, -1, 1]), kwargs = {})
#   %mul_5 : Tensor "f32[1, 6144, 131][804864, 131, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_18, %view_11), kwargs = {})
#   %slice_19 : Tensor "f32[1, 6144, 131][823296, 134, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%constant_pad_nd, 2, 1, 132), kwargs = {})
#   %select_26 : Tensor "f32[6144, 4][4, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%convert_element_type_16, 1, 0), kwargs = {})
#   %select_27 : Tensor "f32[6144][4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_26, 1, 1), kwargs = {})
#   %view_12 : Tensor "f32[1, 6144, 1][24576, 4, 4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%select_27, [1, -1, 1]), kwargs = {})
#   %mul_6 : Tensor "f32[1, 6144, 131][804864, 131, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_19, %view_12), kwargs = {})
#   %add_2 : Tensor "f32[1, 6144, 131][804864, 131, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_5, %mul_6), kwargs = {})
#   %slice_20 : Tensor "f32[1, 6144, 131][823296, 134, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%constant_pad_nd, 2, 2, 133), kwargs = {})
#   %select_28 : Tensor "f32[6144, 4][4, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%convert_element_type_16, 1, 0), kwargs = {})
#   %select_29 : Tensor "f32[6144][4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_28, 1, 2), kwargs = {})
#   %view_13 : Tensor "f32[1, 6144, 1][24576, 4, 4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%select_29, [1, -1, 1]), kwargs = {})
#   %mul_7 : Tensor "f32[1, 6144, 131][804864, 131, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_20, %view_13), kwargs = {})
#   %add_3 : Tensor "f32[1, 6144, 131][804864, 131, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_2, %mul_7), kwargs = {})
#   %slice_21 : Tensor "f32[1, 6144, 131][823296, 134, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%constant_pad_nd, 2, 3, 134), kwargs = {})
#   %select_30 : Tensor "f32[6144, 4][4, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%convert_element_type_16, 1, 0), kwargs = {})
#   %select_31 : Tensor "f32[6144][4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_30, 1, 3), kwargs = {})
#   %view_14 : Tensor "f32[1, 6144, 1][24576, 4, 4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%select_31, [1, -1, 1]), kwargs = {})
#   %mul_8 : Tensor "f32[1, 6144, 131][804864, 131, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_21, %view_14), kwargs = {})
#   %add_4 : Tensor "f32[1, 6144, 131][804864, 131, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_3, %mul_8), kwargs = {})
#   %convert_element_type_17 : Tensor "bf16[1, 6144, 131][804864, 131, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_4, torch.bfloat16), kwargs = {})
#   %slice_22 : Tensor "bf16[1, 6144, 128][804864, 131, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%convert_element_type_17, 2, 0, 128), kwargs = {})
#   %convert_element_type_18 : Tensor "f32[1, 6144, 128][786432, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%slice_22, torch.float32), kwargs = {})
#   return %convert_element_type_18
triton_poi_fused__unsafe_view_convolution_silu_slice_squeeze_transpose_unsqueeze_2 = async_compile.triton('triton_poi_fused__unsafe_view_convolution_silu_slice_squeeze_transpose_unsqueeze_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1048576}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_convolution_silu_slice_squeeze_transpose_unsqueeze_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 12582912}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_convolution_silu_slice_squeeze_transpose_unsqueeze_2(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 786432
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x1 = xindex // 6144
    x2 = xindex
    x0 = (xindex % 6144)
    tmp10 = tl.load(in_ptr1 + (4*x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp21 = tl.load(in_ptr1 + (1 + 4*x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp33 = tl.load(in_ptr1 + (2 + 4*x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp45 = tl.load(in_ptr1 + (3 + 4*x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp0 = ((-3) + x1).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = tl.full([1], 128, tl.int64)
    tmp4 = tmp0 < tmp3
    tmp5 = tmp2 & tmp4
    tmp6 = tl.load(in_ptr0 + ((-18432) + x2), tmp5, other=0.0).to(tl.float32)
    tmp7 = tmp6.to(tl.float32)
    tmp8 = tl.full(tmp7.shape, 0.0, tmp7.dtype)
    tmp9 = tl.where(tmp5, tmp7, tmp8)
    tmp11 = tmp10.to(tl.float32)
    tmp12 = tmp9 * tmp11
    tmp13 = ((-2) + x1).to(tl.int32)
    tmp14 = tmp13 >= tmp1
    tmp15 = tmp13 < tmp3
    tmp16 = tmp14 & tmp15
    tmp17 = tl.load(in_ptr0 + ((-12288) + x2), tmp16, other=0.0).to(tl.float32)
    tmp18 = tmp17.to(tl.float32)
    tmp19 = tl.full(tmp18.shape, 0.0, tmp18.dtype)
    tmp20 = tl.where(tmp16, tmp18, tmp19)
    tmp22 = tmp21.to(tl.float32)
    tmp23 = tmp20 * tmp22
    tmp24 = tmp12 + tmp23
    tmp25 = ((-1) + x1).to(tl.int32)
    tmp26 = tmp25 >= tmp1
    tmp27 = tmp25 < tmp3
    tmp28 = tmp26 & tmp27
    tmp29 = tl.load(in_ptr0 + ((-6144) + x2), tmp28, other=0.0).to(tl.float32)
    tmp30 = tmp29.to(tl.float32)
    tmp31 = tl.full(tmp30.shape, 0.0, tmp30.dtype)
    tmp32 = tl.where(tmp28, tmp30, tmp31)
    tmp34 = tmp33.to(tl.float32)
    tmp35 = tmp32 * tmp34
    tmp36 = tmp24 + tmp35
    tmp37 = (x1).to(tl.int32)
    tmp38 = tmp37 >= tmp1
    tmp39 = tmp37 < tmp3
    tmp40 = tmp38 & tmp39
    tmp41 = tl.load(in_ptr0 + (x2), tmp40, other=0.0).to(tl.float32)
    tmp42 = tmp41.to(tl.float32)
    tmp43 = tl.full(tmp42.shape, 0.0, tmp42.dtype)
    tmp44 = tl.where(tmp40, tmp42, tmp43)
    tmp46 = tmp45.to(tl.float32)
    tmp47 = tmp44 * tmp46
    tmp48 = tmp36 + tmp47
    tmp49 = tmp48.to(tl.float32)
    tmp50 = tmp49.to(tl.float32)
    tl.store(out_ptr0 + (x2), tmp50, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/iq/ciqrwvslh6h2qxyrasm6etk7rof552qxrbmgrb5rlkpvkaaf3b3h.py
# Topologically Sorted Source Nodes: [out_1, mixed_qkv_3, split, query_1, transpose_2, query_2, mul_6, sum_1, add_3, inv_norm, query_3, query_4], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
# Source node to ATen node mapping:
#   add_3 => add_7
#   inv_norm => rsqrt_1
#   mixed_qkv_3 => permute_5
#   mul_6 => mul_10
#   out_1 => add_5, convert_element_type_19, div, exp, neg
#   query_1 => view_15
#   query_2 => clone_4, convert_element_type_21
#   query_3 => mul_11
#   query_4 => mul_14
#   split => split_with_sizes
#   sum_1 => sum_1
#   transpose_2 => permute_6
# Graph fragment:
#   %convert_element_type_18 : Tensor "f32[1, 6144, 128][786432, 1, 6144]tnca:0" = PlaceHolder[target=convert_element_type_18]
#   %clone_4 : Tensor "f32[1, 16, 128, 128][262144, 128, 2048, 1]tnca:0" = PlaceHolder[target=clone_4]
#   %sum_1 : Tensor "f32[1, 16, 128, 1][2048, 1, 16, 2048]tnca:0" = PlaceHolder[target=sum_1]
#   %neg : Tensor "f32[1, 6144, 128][786432, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_18,), kwargs = {})
#   %exp : Tensor "f32[1, 6144, 128][786432, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg,), kwargs = {})
#   %add_5 : Tensor "f32[1, 6144, 128][786432, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div : Tensor "f32[1, 6144, 128][786432, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_18, %add_5), kwargs = {})
#   %convert_element_type_19 : Tensor "bf16[1, 6144, 128][786432, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div, torch.bfloat16), kwargs = {})
#   %permute_5 : Tensor "bf16[1, 128, 6144][786432, 1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_19, [0, 2, 1]), kwargs = {})
#   %split_with_sizes : [num_users=3] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%permute_5, [2048, 2048, 2048], -1), kwargs = {})
#   %view_15 : Tensor "bf16[1, 128, 16, 128][786432, 1, 16384, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem, [1, 128, 16, 128]), kwargs = {})
#   %permute_6 : Tensor "bf16[1, 16, 128, 128][786432, 16384, 1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_15, [0, 2, 1, 3]), kwargs = {})
#   %convert_element_type_21 : Tensor "f32[1, 16, 128, 128][786432, 16384, 1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_6, torch.float32), kwargs = {})
#   %clone_4 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.clone.default](args = (%convert_element_type_21,), kwargs = {memory_format: torch.contiguous_format})
#   %mul_10 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%clone_4, %clone_4), kwargs = {})
#   %sum_1 : Tensor "f32[1, 16, 128, 1][2048, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%mul_10, [-1], True), kwargs = {})
#   %add_7 : Tensor "f32[1, 16, 128, 1][2048, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%sum_1, 1e-06), kwargs = {})
#   %rsqrt_1 : Tensor "f32[1, 16, 128, 1][2048, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_7,), kwargs = {})
#   %mul_11 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%clone_4, %rsqrt_1), kwargs = {})
#   %mul_14 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_11, 0.08838834764831845), kwargs = {})
#   return %clone_4,%sum_1,%mul_14
triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_3 = async_compile.triton('triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 2048, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'out_ptr2': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 2, 'num_store': 3, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 16384, 'r0_': 5242880}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 4}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_3(in_ptr0, out_ptr0, out_ptr1, out_ptr2, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 2048
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = (xindex % 16)
    x1 = xindex // 16
    x3 = xindex
    _tmp10 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_2 + 128*x0 + 6144*x1), r0_mask, eviction_policy='evict_first', other=0.0)
        tmp1 = -tmp0
        tmp2 = libdevice.exp(tmp1)
        tmp3 = tl.full([1], 1.0, tl.float32)
        tmp4 = tmp2 + tmp3
        tmp5 = (tmp0 / tmp4)
        tmp6 = tmp5.to(tl.float32)
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tmp7 * tmp7
        tmp9 = tl.broadcast_to(tmp8, [R0_BLOCK])
        tmp11 = _tmp10 + tmp9
        _tmp10 = tl.where(r0_mask, tmp11, _tmp10)
        tl.store(out_ptr0 + (r0_2 + 128*x3), tmp7, r0_mask)
    tmp10 = triton_helpers.promote_to_tensor(tl.sum(_tmp10, 0))
    tl.store(out_ptr1 + (x3), tmp10, None)
    tma_descriptor0 = tl.make_tensor_descriptor(out_ptr0, shape=[2048, 128], strides=[128, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tl.debug_barrier()
        tmp12 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp13 = tl.full([1], 1e-06, tl.float32)
        tmp14 = tmp10 + tmp13
        tmp15 = libdevice.rsqrt(tmp14)
        tmp16 = tmp12 * tmp15
        tmp17 = tl.full([1], 0.08838834764831845, tl.float32)
        tmp18 = tmp16 * tmp17
        tl.store(out_ptr2 + (r0_2 + 128*x1 + 16384*x0), tmp18, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/cc/cccm3rbfe23g6ie2cwmxi7fdbfv2s6es76rnvvxps3wqa6fpjres.py
# Topologically Sorted Source Nodes: [a], Original ATen: [aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   a => mm_3, permute_4, view_9
# Graph fragment:
#   %convert_element_type_6 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0" = PlaceHolder[target=convert_element_type_6]
#   %arg8_1 : Tensor "bf16[16, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg8_1]
#   %view_9 : Tensor "bf16[128, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_6, [128, 2048]), kwargs = {})
#   %permute_4 : Tensor "bf16[2048, 16][1, 2048]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg8_1, [1, 0]), kwargs = {})
#   %mm_3 : Tensor "bf16[128, 16][16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_9, %permute_4), kwargs = {})
#   return %mm_3
triton_tem_fused_mm_t_view_4 = async_compile.triton('triton_tem_fused_mm_t_view_4', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*bf16', 'arg_B': '*bf16', 'out_ptr0': '*bf16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_mm_t_view_4', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_mm_t_view_4(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 128
    N = 16
    K = 2048
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 2048
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2048

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2048*idx_m
        a = tl.load(A + (xindex))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 16*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2048*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 16*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/ab/caby5t3cmu4g5tctjejnqfusqfztepbnsmyr2qg6svetbqmq3jga.py
# Topologically Sorted Source Nodes: [exp, neg], Original ATen: [aten.exp, aten.neg]
# Source node to ATen node mapping:
#   exp => exp_1
#   neg => neg_1
# Graph fragment:
#   %arg10_1 : Tensor "f32[16][1]tnca:0" = PlaceHolder[target=arg10_1]
#   %exp_1 : Tensor "f32[16][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%arg10_1,), kwargs = {})
#   %neg_1 : Tensor "f32[16][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%exp_1,), kwargs = {})
#   return %neg_1
triton_poi_fused_exp_neg_5 = async_compile.triton('triton_poi_fused_exp_neg_5', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 16}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_exp_neg_5', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 192}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_exp_neg_5(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 16
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask)
    tmp1 = libdevice.exp(tmp0)
    tmp2 = -tmp1
    tl.store(out_ptr0 + (x0), tmp2, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/yk/cykhohqhreap7zezedwoawvui3svtbwme3cxlhft3g7kngvawzy3.py
# Topologically Sorted Source Nodes: [exp, neg, a, float_5, add_2, softplus, g, transpose_6, decay_2, cum_decay], Original ATen: [aten.exp, aten.neg, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.view, aten.cumsum]
# Source node to ATen node mapping:
#   a => view_10
#   add_2 => add_6
#   cum_decay => cumsum
#   decay_2 => view_22
#   exp => exp_1
#   float_5 => convert_element_type_20
#   g => mul_9
#   neg => neg_1
#   softplus => exp_2, gt, log1p, where_1
#   transpose_6 => permute_10
# Graph fragment:
#   %neg_1 : Tensor "f32[16][1]tnca:0" = PlaceHolder[target=neg_1]
#   %mm_3 : Tensor "bf16[128, 16][16, 1]tnca:0" = PlaceHolder[target=mm_3]
#   %arg11_1 : Tensor "bf16[16][1]tnca:0" = PlaceHolder[target=arg11_1]
#   %exp_1 : Tensor "f32[16][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%arg10_1,), kwargs = {})
#   %neg_1 : Tensor "f32[16][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%exp_1,), kwargs = {})
#   %view_10 : Tensor "bf16[1, 128, 16][2048, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [1, 128, 16]), kwargs = {})
#   %convert_element_type_20 : Tensor "f32[1, 128, 16][2048, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_10, torch.float32), kwargs = {})
#   %add_6 : Tensor "f32[1, 128, 16][2048, 16, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_20, %arg11_1), kwargs = {})
#   %gt : Tensor "b8[1, 128, 16][2048, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.gt.Scalar](args = (%add_6, 20), kwargs = {})
#   %exp_2 : Tensor "f32[1, 128, 16][2048, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%add_6,), kwargs = {})
#   %log1p : Tensor "f32[1, 128, 16][2048, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.log1p.default](args = (%exp_2,), kwargs = {})
#   %where_1 : Tensor "f32[1, 128, 16][2048, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%gt, %add_6, %log1p), kwargs = {})
#   %mul_9 : Tensor "f32[1, 128, 16][2048, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%neg_1, %where_1), kwargs = {})
#   %permute_10 : Tensor "f32[1, 16, 128][2048, 1, 16]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%mul_9, [0, 2, 1]), kwargs = {})
#   %view_22 : Tensor "f32[1, 16, 2, 64][2048, 1, 1024, 16]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%permute_10, [1, 16, 2, 64]), kwargs = {})
#   %cumsum : Tensor "f32[1, 16, 2, 64][2048, 128, 64, 1]tnca:0"[num_users=7] = call_function[target=torch.ops.aten.cumsum.default](args = (%view_22, 3), kwargs = {})
#   return %cumsum
triton_spl_fused__to_copy__unsafe_view_add_cumsum_exp_mul_neg_softplus_transpose_view_6 = async_compile.triton('triton_spl_fused__to_copy__unsafe_view_add_cumsum_exp_mul_neg_softplus_transpose_view_6', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton.jit
def _triton_helper_fn_add0(arg0_0, arg1_0):
    tmp0 = arg0_0 + arg1_0
    return tmp0

@triton_heuristics.split_scan(
    size_hints={'x': 32, 'r0_': 64},
    reduction_hint=ReductionHint.OUTER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'out_ptr0': '*fp32', 'ws_ptr': '*u8', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'SplitScanGrid', 'kernel_name': 'triton_spl_fused__to_copy__unsafe_view_add_cumsum_exp_mul_neg_softplus_transpose_view_6', 'mutated_arg_names': ['ws_ptr'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 4192, 'r0_': 16384}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_spl_fused__to_copy__unsafe_view_add_cumsum_exp_mul_neg_softplus_transpose_view_6(in_ptr0, in_ptr1, in_ptr2, out_ptr0, ws_ptr, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 32
    XBLOCK: tl.constexpr = 1
    r0_numel = 64
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(1) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_offset = tl.program_id(0) * R0_BLOCK
    r0_index = r0_offset + tl.arange(0, R0_BLOCK)[:]
    r0_mask = r0_index < r0_numel
    roffset = r0_offset
    rindex = r0_index
    x0 = (xindex % 16)
    r0_2 = r0_index
    x1 = xindex // 16
    tmp0 = tl.load(in_ptr0 + (x0), None, eviction_policy='evict_last')
    tmp1 = tl.load(in_ptr1 + (x0 + 16*r0_2 + 1024*x1), r0_mask, other=0.0).to(tl.float32)
    tmp3 = tl.load(in_ptr2 + (x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp2 = tmp1.to(tl.float32)
    tmp4 = tmp3.to(tl.float32)
    tmp5 = tmp2 + tmp4
    tmp6 = tl.full([1], 20.0, tl.float32)
    tmp7 = tmp5 > tmp6
    tmp8 = libdevice.exp(tmp5)
    tmp9 = libdevice.log1p(tmp8)
    tmp10 = tl.where(tmp7, tmp5, tmp9)
    tmp11 = tmp0 * tmp10
    tmp12 = tmp11.to(tl.float32)
    tmp13 = tl.broadcast_to(tmp12, [R0_BLOCK])
    tmp14 = tl.reduce(tmp13, 0, _triton_helper_fn_add0)
    tmp15 = triton_helpers.exclusive_scan_decoupled_lookback(
        ws_ptr.to(tl.pointer_type(tl.uint64)) + xoffset * 1 * tl.num_programs(0),
        tmp14,
        tl.program_id(0),
        _triton_helper_fn_add0,
        DTYPE_VALUE_AS_UINT=tl.uint32,
        DTYPE_PACK=tl.uint64,
    )
    tmp16 = tl.associative_scan(tmp13, 0, _triton_helper_fn_add0)
    tmp17 = _triton_helper_fn_add0(tmp15, tmp16)
    tmp18 = tl.where(roffset == 0, tmp16, tmp17)
    tl.store(out_ptr0 + (r0_2 + 64*x1 + 128*x0), tmp18, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/se/csef73ir3kmx5qbmd63nu32f4x4ltavl7imngsnnt5r2nluvknvt.py
# Topologically Sorted Source Nodes: [exp_3, exp_2, getitem_15, sub_1, exp_4], Original ATen: [aten.exp, aten.slice, aten.sub]
# Source node to ATen node mapping:
#   exp_2 => exp_4
#   exp_3 => exp_5
#   exp_4 => exp_6
#   getitem_15 => slice_23
#   sub_1 => sub_3
# Graph fragment:
#   %cumsum : Tensor "f32[1, 16, 2, 64][2048, 128, 64, 1]tnca:0" = PlaceHolder[target=cumsum]
#   %exp_5 : Tensor "f32[1, 16, 2, 64][2048, 128, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%cumsum,), kwargs = {})
#   %exp_4 : Tensor "f32[1, 16, 2, 64][2048, 128, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%cumsum,), kwargs = {})
#   %slice_23 : Tensor "f32[1, 16, 2, 1][2048, 128, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%cumsum, 3, -1, 9223372036854775807), kwargs = {})
#   %sub_3 : Tensor "f32[1, 16, 2, 64][2048, 128, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%slice_23, %cumsum), kwargs = {})
#   %exp_6 : Tensor "f32[1, 16, 2, 64][2048, 128, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%sub_3,), kwargs = {})
#   return %exp_5,%exp_4,%exp_6
triton_poi_fused_exp_slice_sub_7 = async_compile.triton('triton_poi_fused_exp_slice_sub_7', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 2048}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'out_ptr2': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_exp_slice_sub_7', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 3, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 57344}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_exp_slice_sub_7(in_ptr0, out_ptr0, out_ptr1, out_ptr2, xnumel, XBLOCK : tl.constexpr):
    xnumel = 2048
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    x2 = xindex // 64
    tmp0 = tl.load(in_ptr0 + (x0), xmask)
    tmp2 = tl.load(in_ptr0 + (63 + 64*x2), xmask, eviction_policy='evict_last')
    tmp1 = libdevice.exp(tmp0)
    tmp3 = tmp2 - tmp0
    tmp4 = libdevice.exp(tmp3)
    tl.store(out_ptr0 + (x0), tmp1, xmask)
    tl.store(out_ptr1 + (x0), tmp1, xmask)
    tl.store(out_ptr2 + (x0), tmp4, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/uz/cuzec3vn4uqoyz3cnhbkodfcg4sy6raxsm5urfm5zvxlzqvjfhbp.py
# Topologically Sorted Source Nodes: [add_3, inv_norm, query_3, query_4, query_6, exp_3, unsqueeze_6, query_7], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze]
# Source node to ATen node mapping:
#   add_3 => add_7
#   exp_3 => exp_5
#   inv_norm => rsqrt_1
#   query_3 => mul_11
#   query_4 => mul_14
#   query_6 => view_18
#   query_7 => mul_20
#   unsqueeze_6 => unsqueeze_16
# Graph fragment:
#   %clone_4 : Tensor "f32[1, 16, 128, 128][262144, 128, 2048, 1]tnca:0" = PlaceHolder[target=clone_4]
#   %sum_1 : Tensor "f32[1, 16, 128, 1][2048, 1, 16, 2048]tnca:0" = PlaceHolder[target=sum_1]
#   %exp_5 : Tensor "f32[1, 16, 2, 64][2048, 128, 64, 1]tnca:0" = PlaceHolder[target=exp_5]
#   %add_7 : Tensor "f32[1, 16, 128, 1][2048, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%sum_1, 1e-06), kwargs = {})
#   %rsqrt_1 : Tensor "f32[1, 16, 128, 1][2048, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_7,), kwargs = {})
#   %mul_11 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%clone_4, %rsqrt_1), kwargs = {})
#   %mul_14 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_11, 0.08838834764831845), kwargs = {})
#   %view_18 : Tensor "f32[1, 16, 2, 64, 128][262144, 16384, 8192, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%mul_14, [1, 16, -1, 64, 128]), kwargs = {})
#   %exp_5 : Tensor "f32[1, 16, 2, 64][2048, 128, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%cumsum,), kwargs = {})
#   %unsqueeze_16 : Tensor "f32[1, 16, 2, 64, 1][2048, 128, 64, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%exp_5, -1), kwargs = {})
#   %mul_20 : Tensor "f32[1, 16, 2, 64, 128][262144, 16384, 8192, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%view_18, %unsqueeze_16), kwargs = {})
#   return %mul_20
triton_poi_fused_add_exp_mul_rsqrt_unsqueeze_view_8 = async_compile.triton('triton_poi_fused_add_exp_mul_rsqrt_unsqueeze_view_8', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_add_exp_mul_rsqrt_unsqueeze_view_8', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 3162112}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_exp_mul_rsqrt_unsqueeze_view_8(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 262144
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 128)
    x1 = ((xindex // 128) % 128)
    x2 = xindex // 16384
    x3 = xindex // 128
    x4 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 128*x2 + 2048*x1), None)
    tmp1 = tl.load(in_ptr1 + (x2 + 16*x1), None, eviction_policy='evict_last')
    tmp8 = tl.load(in_ptr2 + (x3), None, eviction_policy='evict_last')
    tmp2 = tl.full([1], 1e-06, tl.float32)
    tmp3 = tmp1 + tmp2
    tmp4 = libdevice.rsqrt(tmp3)
    tmp5 = tmp0 * tmp4
    tmp6 = tl.full([1], 0.08838834764831845, tl.float32)
    tmp7 = tmp5 * tmp6
    tmp9 = tmp7 * tmp8
    tl.store(out_ptr0 + (x4), tmp9, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/hb/chbebigmnjjgmswwi6b2svk4lkldort6pnmncljn3fhj7jjmgwao.py
# Topologically Sorted Source Nodes: [last_recurrent_state], Original ATen: [aten.zeros]
# Source node to ATen node mapping:
#   last_recurrent_state => full_2
# Graph fragment:
#   %full_2 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.full.default](args = ([1, 16, 128, 128], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   return %expand_9
triton_poi_fused_zeros_9 = async_compile.triton('triton_poi_fused_zeros_9', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_zeros_9', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 0, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 2097152}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_zeros_9(out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 262144
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = xindex
    tmp0 = tl.full([1], 0.0, tl.float32)
    tl.store(out_ptr0 + (x0), tmp0, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/3x/c3xapu5wquwl5do5tf356aj6nc63unosjauusmni4hoyo3l5uhta.py
# Topologically Sorted Source Nodes: [add_3, inv_norm, query_3, query_4, query_6, exp_3, unsqueeze_6, query_7, getitem_20, inter_chunk_attn, last_recurrent_state], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze, aten.select, aten.zeros, aten.bmm]
# Source node to ATen node mapping:
#   add_3 => add_7
#   exp_3 => exp_5
#   getitem_20 => select_35
#   inter_chunk_attn => bmm_3, view_32, view_33
#   inv_norm => rsqrt_1
#   last_recurrent_state => full_2
#   query_3 => mul_11
#   query_4 => mul_14
#   query_6 => view_18
#   query_7 => mul_20
#   unsqueeze_6 => unsqueeze_16
# Graph fragment:
#   %mul_20 : Tensor "f32[1, 16, 2, 64, 128][262144, 16384, 8192, 128, 1]tnca:0" = PlaceHolder[target=mul_20]
#   %expand_9 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0" = PlaceHolder[target=expand_9]
#   %add_7 : Tensor "f32[1, 16, 128, 1][2048, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%sum_1, 1e-06), kwargs = {})
#   %rsqrt_1 : Tensor "f32[1, 16, 128, 1][2048, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_7,), kwargs = {})
#   %mul_11 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%clone_4, %rsqrt_1), kwargs = {})
#   %mul_14 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_11, 0.08838834764831845), kwargs = {})
#   %view_18 : Tensor "f32[1, 16, 2, 64, 128][262144, 16384, 8192, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%mul_14, [1, 16, -1, 64, 128]), kwargs = {})
#   %exp_5 : Tensor "f32[1, 16, 2, 64][2048, 128, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%cumsum,), kwargs = {})
#   %unsqueeze_16 : Tensor "f32[1, 16, 2, 64, 1][2048, 128, 64, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%exp_5, -1), kwargs = {})
#   %mul_20 : Tensor "f32[1, 16, 2, 64, 128][262144, 16384, 8192, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%view_18, %unsqueeze_16), kwargs = {})
#   %select_35 : Tensor "f32[1, 16, 64, 128][262144, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%mul_20, 2, 0), kwargs = {})
#   %view_32 : Tensor "f32[16, 64, 128][16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_10, [16, 64, 128]), kwargs = {})
#   %full_2 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.full.default](args = ([1, 16, 128, 128], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %view_33 : Tensor "f32[16, 128, 128][16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_11, [16, 128, 128]), kwargs = {})
#   %bmm_3 : Tensor "f32[16, 64, 128][8192, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_32, %view_33), kwargs = {})
#   return %bmm_3
triton_tem_fused_add_bmm_exp_mul_rsqrt_select_unsqueeze_view_zeros_10 = async_compile.triton('triton_tem_fused_add_bmm_exp_mul_rsqrt_select_unsqueeze_view_zeros_10', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp32', 'arg_B': '*fp32', 'out_ptr0': '*fp32'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_add_bmm_exp_mul_rsqrt_select_unsqueeze_view_zeros_10', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_add_bmm_exp_mul_rsqrt_select_unsqueeze_view_zeros_10(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 64
    N = 128
    K = 128
    BATCH = 16

    stride_aq = 16384
    stride_am = 128
    stride_ak = 1

    stride_bq = 16384
    stride_bk = 128
    stride_bn = 1

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        ram = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        ram = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        rbn = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        rbn = rn % N

    rk = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)

    # Reconstruct batch index from grid_y/grid_z split (handles batch > 65535)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    # Clamp to valid range for safe pointer arithmetic; out-of-bounds CTAs are
    # masked off at the store below.
    idx_q_clamped = tl.minimum(idx_q, BATCH - 1)
    A = A + (ram[:, None] * stride_am + rk[None, :] * stride_ak + idx_q_clamped*stride_aq)
    B = B + (rk[:, None] * stride_bk + rbn[None, :] * stride_bn + idx_q_clamped*stride_bq)

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)
    for k in range(K, 0, -BLOCK_K):
        if EVEN_K:
            a = tl.load(A)
            b = tl.load(B)
        else:
            a = tl.load(A, mask=rk[None, :] < k, other=0.)
            b = tl.load(B, mask=rk[:, None] < k, other=0.)
        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32)
        A += BLOCK_K * stride_ak
        B += BLOCK_K * stride_bk

    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N) & (idx_q < BATCH)

    # inductor generates a suffix
    xindex = idx_n + 128*idx_m + 8192*idx_q
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/om/com3c7njqg2vudyx6azne2otc3myu3niwbj2i3wwhtjpn4p5mzqc.py
# Topologically Sorted Source Nodes: [out_1, mixed_qkv_3, split, key_1, transpose_3, key_2, mul_8, sum_2, add_4, inv_norm_1, key_3], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
# Source node to ATen node mapping:
#   add_4 => add_8
#   inv_norm_1 => rsqrt_2
#   key_1 => view_16
#   key_2 => clone_5, convert_element_type_22
#   key_3 => mul_13
#   mixed_qkv_3 => permute_5
#   mul_8 => mul_12
#   out_1 => add_5, convert_element_type_19, div, exp, neg
#   split => split_with_sizes
#   sum_2 => sum_2
#   transpose_3 => permute_7
# Graph fragment:
#   %convert_element_type_18 : Tensor "f32[1, 6144, 128][786432, 1, 6144]tnca:0" = PlaceHolder[target=convert_element_type_18]
#   %clone_5 : Tensor "f32[1, 16, 128, 128][262144, 128, 2048, 1]tnca:0" = PlaceHolder[target=clone_5]
#   %sum_2 : Tensor "f32[1, 16, 128, 1][2048, 1, 16, 2048]tnca:0" = PlaceHolder[target=sum_2]
#   %neg : Tensor "f32[1, 6144, 128][786432, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_18,), kwargs = {})
#   %exp : Tensor "f32[1, 6144, 128][786432, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg,), kwargs = {})
#   %add_5 : Tensor "f32[1, 6144, 128][786432, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div : Tensor "f32[1, 6144, 128][786432, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_18, %add_5), kwargs = {})
#   %convert_element_type_19 : Tensor "bf16[1, 6144, 128][786432, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div, torch.bfloat16), kwargs = {})
#   %permute_5 : Tensor "bf16[1, 128, 6144][786432, 1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_19, [0, 2, 1]), kwargs = {})
#   %split_with_sizes : [num_users=3] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%permute_5, [2048, 2048, 2048], -1), kwargs = {})
#   %view_16 : Tensor "bf16[1, 128, 16, 128][786432, 1, 16384, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_1, [1, 128, 16, 128]), kwargs = {})
#   %permute_7 : Tensor "bf16[1, 16, 128, 128][786432, 16384, 1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_16, [0, 2, 1, 3]), kwargs = {})
#   %convert_element_type_22 : Tensor "f32[1, 16, 128, 128][786432, 16384, 1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_7, torch.float32), kwargs = {})
#   %clone_5 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.clone.default](args = (%convert_element_type_22,), kwargs = {memory_format: torch.contiguous_format})
#   %mul_12 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%clone_5, %clone_5), kwargs = {})
#   %sum_2 : Tensor "f32[1, 16, 128, 1][2048, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%mul_12, [-1], True), kwargs = {})
#   %add_8 : Tensor "f32[1, 16, 128, 1][2048, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%sum_2, 1e-06), kwargs = {})
#   %rsqrt_2 : Tensor "f32[1, 16, 128, 1][2048, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_8,), kwargs = {})
#   %mul_13 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%clone_5, %rsqrt_2), kwargs = {})
#   return %clone_5,%sum_2,%mul_13
triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_11 = async_compile.triton('triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_11', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 2048, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'out_ptr2': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_11', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 2, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 3145728}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 4}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_11(in_ptr0, out_ptr0, out_ptr2, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 2048
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = (xindex % 16)
    x1 = xindex // 16
    x3 = xindex
    _tmp10 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp0 = tl.load(in_ptr0 + (2048 + r0_2 + 128*x0 + 6144*x1), r0_mask, eviction_policy='evict_first', other=0.0)
        tmp1 = -tmp0
        tmp2 = libdevice.exp(tmp1)
        tmp3 = tl.full([1], 1.0, tl.float32)
        tmp4 = tmp2 + tmp3
        tmp5 = (tmp0 / tmp4)
        tmp6 = tmp5.to(tl.float32)
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tmp7 * tmp7
        tmp9 = tl.broadcast_to(tmp8, [R0_BLOCK])
        tmp11 = _tmp10 + tmp9
        _tmp10 = tl.where(r0_mask, tmp11, _tmp10)
        tl.store(out_ptr0 + (r0_2 + 128*x3), tmp7, r0_mask)
    tmp10 = triton_helpers.promote_to_tensor(tl.sum(_tmp10, 0))
    tma_descriptor0 = tl.make_tensor_descriptor(out_ptr0, shape=[2048, 128], strides=[128, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tl.debug_barrier()
        tmp12 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp13 = tl.full([1], 1e-06, tl.float32)
        tmp14 = tmp10 + tmp13
        tmp15 = libdevice.rsqrt(tmp14)
        tmp16 = tmp12 * tmp15
        tl.store(out_ptr2 + (r0_2 + 128*x1 + 16384*x0), tmp16, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/wr/cwrhb2zru4mlwovdlnsf374k67vwiivyogvh5obsm56g5pg7njtg.py
# Topologically Sorted Source Nodes: [add_3, inv_norm, query_3, query_4, query_6, matmul_1, add_4, inv_norm_1, key_3, key_5, transpose_8], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.transpose, aten.bmm]
# Source node to ATen node mapping:
#   add_3 => add_7
#   add_4 => add_8
#   inv_norm => rsqrt_1
#   inv_norm_1 => rsqrt_2
#   key_3 => mul_13
#   key_5 => view_19
#   matmul_1 => bmm_1, view_26, view_27
#   query_3 => mul_11
#   query_4 => mul_14
#   query_6 => view_18
#   transpose_8 => permute_12
# Graph fragment:
#   %mul_14 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0" = PlaceHolder[target=mul_14]
#   %mul_13 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0" = PlaceHolder[target=mul_13]
#   %add_7 : Tensor "f32[1, 16, 128, 1][2048, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%sum_1, 1e-06), kwargs = {})
#   %rsqrt_1 : Tensor "f32[1, 16, 128, 1][2048, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_7,), kwargs = {})
#   %mul_11 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%clone_4, %rsqrt_1), kwargs = {})
#   %mul_14 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_11, 0.08838834764831845), kwargs = {})
#   %view_18 : Tensor "f32[1, 16, 2, 64, 128][262144, 16384, 8192, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%mul_14, [1, 16, -1, 64, 128]), kwargs = {})
#   %view_26 : Tensor "f32[32, 64, 128][8192, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_6, [32, 64, 128]), kwargs = {})
#   %add_8 : Tensor "f32[1, 16, 128, 1][2048, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%sum_2, 1e-06), kwargs = {})
#   %rsqrt_2 : Tensor "f32[1, 16, 128, 1][2048, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_8,), kwargs = {})
#   %mul_13 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%clone_5, %rsqrt_2), kwargs = {})
#   %view_19 : Tensor "f32[1, 16, 2, 64, 128][262144, 16384, 8192, 128, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.reshape.default](args = (%mul_13, [1, 16, -1, 64, 128]), kwargs = {})
#   %permute_12 : Tensor "f32[1, 16, 2, 128, 64][262144, 16384, 8192, 1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_19, [0, 1, 2, 4, 3]), kwargs = {})
#   %view_27 : Tensor "f32[32, 128, 64][8192, 1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_7, [32, 128, 64]), kwargs = {})
#   %bmm_1 : Tensor "f32[32, 64, 64][4096, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_26, %view_27), kwargs = {})
#   return %bmm_1
triton_tem_fused_add_bmm_mul_rsqrt_transpose_view_12 = async_compile.triton('triton_tem_fused_add_bmm_mul_rsqrt_transpose_view_12', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp32', 'arg_B': '*fp32', 'out_ptr0': '*fp32'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_add_bmm_mul_rsqrt_transpose_view_12', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_add_bmm_mul_rsqrt_transpose_view_12(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 64
    N = 64
    K = 128
    BATCH = 32

    stride_aq = 8192
    stride_am = 128
    stride_ak = 1

    stride_bq = 8192
    stride_bk = 1
    stride_bn = 128

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        ram = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        ram = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        rbn = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        rbn = rn % N

    rk = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)

    # Reconstruct batch index from grid_y/grid_z split (handles batch > 65535)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    # Clamp to valid range for safe pointer arithmetic; out-of-bounds CTAs are
    # masked off at the store below.
    idx_q_clamped = tl.minimum(idx_q, BATCH - 1)
    A = A + (ram[:, None] * stride_am + rk[None, :] * stride_ak + idx_q_clamped*stride_aq)
    B = B + (rk[:, None] * stride_bk + rbn[None, :] * stride_bn + idx_q_clamped*stride_bq)

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)
    for k in range(K, 0, -BLOCK_K):
        if EVEN_K:
            a = tl.load(A)
            b = tl.load(B)
        else:
            a = tl.load(A, mask=rk[None, :] < k, other=0.)
            b = tl.load(B, mask=rk[:, None] < k, other=0.)
        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32)
        A += BLOCK_K * stride_ak
        B += BLOCK_K * stride_bk

    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N) & (idx_q < BATCH)

    # inductor generates a suffix
    xindex = idx_n + 64*idx_m + 4096*idx_q
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/rg/crgwm4llufvnzzuq2jelrlmgrwcadlmefsqj36ghaeibums2d7vz.py
# Topologically Sorted Source Nodes: [b, beta, transpose_5, beta_1], Original ATen: [aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
# Source node to ATen node mapping:
#   b => view_8
#   beta => sigmoid
#   beta_1 => clone_7, convert_element_type_24
#   transpose_5 => permute_9
# Graph fragment:
#   %mm_2 : Tensor "bf16[128, 16][16, 1]tnca:0" = PlaceHolder[target=mm_2]
#   %view_8 : Tensor "bf16[1, 128, 16][2048, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_2, [1, 128, 16]), kwargs = {})
#   %sigmoid : Tensor "bf16[1, 128, 16][2048, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sigmoid.default](args = (%view_8,), kwargs = {})
#   %permute_9 : Tensor "bf16[1, 16, 128][2048, 1, 16]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%sigmoid, [0, 2, 1]), kwargs = {})
#   %convert_element_type_24 : Tensor "f32[1, 16, 128][2048, 1, 16]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_9, torch.float32), kwargs = {})
#   %clone_7 : Tensor "f32[1, 16, 128][2048, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.clone.default](args = (%convert_element_type_24,), kwargs = {memory_format: torch.contiguous_format})
#   return %clone_7
triton_poi_fused__to_copy__unsafe_view_sigmoid_transpose_13 = async_compile.triton('triton_poi_fused__to_copy__unsafe_view_sigmoid_transpose_13', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'y': 16, 'x': 128}, tile_hint=TileHint.SQUARE,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'ynumel': 'i32', 'xnumel': 'i32', 'YBLOCK': 'constexpr', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid2D', 'kernel_name': 'triton_poi_fused__to_copy__unsafe_view_sigmoid_transpose_13', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'y': 4096, 'x': 16384}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'YBLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy__unsafe_view_sigmoid_transpose_13(in_ptr0, out_ptr0, ynumel, xnumel, YBLOCK : tl.constexpr, XBLOCK : tl.constexpr):
    ynumel = 16
    xnumel = 128
    yoffset = tl.program_id(1) * YBLOCK
    yindex = yoffset + tl.arange(0, YBLOCK)[:, None]
    ymask = yindex < ynumel
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[None, :]
    xmask = xindex < xnumel
    x1 = xindex
    y0 = yindex
    tmp0 = tl.trans(tl.make_tensor_descriptor(in_ptr0, shape=[128, 16], strides=[16, 1], block_shape=[XBLOCK, YBLOCK]).load([xoffset, yoffset]), [1, 0]).to(tl.float32)
    tmp1 = tl.sigmoid(tmp0)
    tmp2 = tmp1.to(tl.float32)
    tl.store(out_ptr0 + (x1 + 128*y0), tmp2, xmask & ymask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/np/cnpiuchhdsdifvojcsbyznrmpk3megvk22ahljwkqqsck2rpvlzo.py
# Topologically Sorted Source Nodes: [out_1, mixed_qkv_3, split, add_4, inv_norm_1, key_3, key_5, unsqueeze_2, k_beta, k_beta_1, value_1, transpose_4, value_2, unsqueeze_1, v_beta, exp_2, unsqueeze_5, decayed_k_beta, getitem_15, sub_1, exp_4, unsqueeze_7, key_6], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.view, aten.unsqueeze, aten._to_copy, aten.exp, aten.slice, aten.sub]
# Source node to ATen node mapping:
#   add_4 => add_8
#   decayed_k_beta => mul_19
#   exp_2 => exp_4
#   exp_4 => exp_6
#   getitem_15 => slice_23
#   inv_norm_1 => rsqrt_2
#   k_beta => mul_16
#   k_beta_1 => view_20
#   key_3 => mul_13
#   key_5 => view_19
#   key_6 => mul_21
#   mixed_qkv_3 => permute_5
#   out_1 => add_5, convert_element_type_19, div, exp, neg
#   split => split_with_sizes
#   sub_1 => sub_3
#   transpose_4 => permute_8
#   unsqueeze_1 => unsqueeze_9
#   unsqueeze_2 => unsqueeze_10
#   unsqueeze_5 => unsqueeze_15
#   unsqueeze_7 => unsqueeze_17
#   v_beta => mul_15
#   value_1 => view_17
#   value_2 => clone_6, convert_element_type_23
# Graph fragment:
#   %mul_13 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0" = PlaceHolder[target=mul_13]
#   %clone_7 : Tensor "f32[1, 16, 128][2048, 128, 1]tnca:0" = PlaceHolder[target=clone_7]
#   %mul_16 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0" = PlaceHolder[target=mul_16]
#   %exp_4 : Tensor "f32[1, 16, 2, 64][2048, 128, 64, 1]tnca:0" = PlaceHolder[target=exp_4]
#   %exp_6 : Tensor "f32[1, 16, 2, 64][2048, 128, 64, 1]tnca:0" = PlaceHolder[target=exp_6]
#   %convert_element_type_18 : Tensor "f32[1, 6144, 128][786432, 1, 6144]tnca:0" = PlaceHolder[target=convert_element_type_18]
#   %neg : Tensor "f32[1, 6144, 128][786432, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_18,), kwargs = {})
#   %exp : Tensor "f32[1, 6144, 128][786432, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg,), kwargs = {})
#   %add_5 : Tensor "f32[1, 6144, 128][786432, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div : Tensor "f32[1, 6144, 128][786432, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_18, %add_5), kwargs = {})
#   %convert_element_type_19 : Tensor "bf16[1, 6144, 128][786432, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div, torch.bfloat16), kwargs = {})
#   %permute_5 : Tensor "bf16[1, 128, 6144][786432, 1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_19, [0, 2, 1]), kwargs = {})
#   %split_with_sizes : [num_users=3] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%permute_5, [2048, 2048, 2048], -1), kwargs = {})
#   %add_8 : Tensor "f32[1, 16, 128, 1][2048, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%sum_2, 1e-06), kwargs = {})
#   %rsqrt_2 : Tensor "f32[1, 16, 128, 1][2048, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_8,), kwargs = {})
#   %mul_13 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%clone_5, %rsqrt_2), kwargs = {})
#   %view_19 : Tensor "f32[1, 16, 2, 64, 128][262144, 16384, 8192, 128, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.reshape.default](args = (%mul_13, [1, 16, -1, 64, 128]), kwargs = {})
#   %unsqueeze_10 : Tensor "f32[1, 16, 128, 1][2048, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%clone_7, -1), kwargs = {})
#   %mul_16 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_13, %unsqueeze_10), kwargs = {})
#   %view_20 : Tensor "f32[1, 16, 2, 64, 128][262144, 16384, 8192, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%mul_16, [1, 16, -1, 64, 128]), kwargs = {})
#   %view_17 : Tensor "bf16[1, 128, 16, 128][786432, 1, 16384, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_2, [1, 128, 16, 128]), kwargs = {})
#   %permute_8 : Tensor "bf16[1, 16, 128, 128][786432, 16384, 1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_17, [0, 2, 1, 3]), kwargs = {})
#   %convert_element_type_23 : Tensor "f32[1, 16, 128, 128][786432, 16384, 1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_8, torch.float32), kwargs = {})
#   %clone_6 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%convert_element_type_23,), kwargs = {memory_format: torch.contiguous_format})
#   %unsqueeze_9 : Tensor "f32[1, 16, 128, 1][2048, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%clone_7, -1), kwargs = {})
#   %mul_15 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%clone_6, %unsqueeze_9), kwargs = {})
#   %exp_4 : Tensor "f32[1, 16, 2, 64][2048, 128, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%cumsum,), kwargs = {})
#   %unsqueeze_15 : Tensor "f32[1, 16, 2, 64, 1][2048, 128, 64, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%exp_4, -1), kwargs = {})
#   %mul_19 : Tensor "f32[1, 16, 2, 64, 128][262144, 16384, 8192, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%view_20, %unsqueeze_15), kwargs = {})
#   %slice_23 : Tensor "f32[1, 16, 2, 1][2048, 128, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%cumsum, 3, -1, 9223372036854775807), kwargs = {})
#   %sub_3 : Tensor "f32[1, 16, 2, 64][2048, 128, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%slice_23, %cumsum), kwargs = {})
#   %exp_6 : Tensor "f32[1, 16, 2, 64][2048, 128, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%sub_3,), kwargs = {})
#   %unsqueeze_17 : Tensor "f32[1, 16, 2, 64, 1][2048, 128, 64, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%exp_6, -1), kwargs = {})
#   %mul_21 : Tensor "f32[1, 16, 2, 64, 128][262144, 16384, 8192, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%view_19, %unsqueeze_17), kwargs = {})
#   return %mul_16,%mul_19,%mul_21,%mul_15
triton_poi_fused__to_copy_add_exp_mul_rsqrt_silu_slice_split_with_sizes_sub_transpose_unsqueeze_view_14 = async_compile.triton('triton_poi_fused__to_copy_add_exp_mul_rsqrt_silu_slice_split_with_sizes_sub_transpose_unsqueeze_view_14', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'out_ptr2': '*fp32', 'out_ptr3': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_add_exp_mul_rsqrt_silu_slice_split_with_sizes_sub_transpose_unsqueeze_view_14', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 4, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 10510336}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_exp_mul_rsqrt_silu_slice_split_with_sizes_sub_transpose_unsqueeze_view_14(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr0, out_ptr1, out_ptr2, out_ptr3, xnumel, XBLOCK : tl.constexpr):
    xnumel = 262144
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x4 = xindex
    x1 = xindex // 128
    x0 = (xindex % 128)
    x2 = ((xindex // 128) % 128)
    x3 = xindex // 16384
    tmp0 = tl.load(in_ptr0 + (x4), None)
    tmp1 = tl.load(in_ptr1 + (x1), None, eviction_policy='evict_last')
    tmp3 = tl.load(in_ptr2 + (x1), None, eviction_policy='evict_last')
    tmp5 = tl.load(in_ptr3 + (x1), None, eviction_policy='evict_last')
    tmp7 = tl.load(in_ptr4 + (4096 + x0 + 128*x3 + 6144*x2), None)
    tmp2 = tmp0 * tmp1
    tmp4 = tmp2 * tmp3
    tmp6 = tmp0 * tmp5
    tmp8 = -tmp7
    tmp9 = libdevice.exp(tmp8)
    tmp10 = tl.full([1], 1.0, tl.float32)
    tmp11 = tmp9 + tmp10
    tmp12 = (tmp7 / tmp11)
    tmp13 = tmp12.to(tl.float32)
    tmp14 = tmp13.to(tl.float32)
    tmp15 = tmp14 * tmp1
    tl.store(out_ptr0 + (x4), tmp2, None)
    tl.store(out_ptr1 + (x4), tmp4, None)
    tl.store(out_ptr2 + (x4), tmp6, None)
    tl.store(out_ptr3 + (x4), tmp15, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/w4/cw4pnp6mcxiacgmm56vdaruptmw5bitrictgb4vdzfxxtvbxis2q.py
# Topologically Sorted Source Nodes: [add_4, inv_norm_1, key_3, key_5, matmul_1, strictly_upper_mask, ones, pairwise_decay_1, unsqueeze_3, unsqueeze_4, pairwise_decay, pairwise_decay_2, intra_chunk_attn, unsqueeze_2, k_beta, k_beta_1, matmul, transpose_7, ut_system], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.triu, aten.ones, aten.masked_fill, aten.unsqueeze, aten.sub, aten.exp, aten.transpose, aten.bmm]
# Source node to ATen node mapping:
#   add_4 => add_8
#   intra_chunk_attn => mul_18
#   inv_norm_1 => rsqrt_2
#   k_beta => mul_16
#   k_beta_1 => view_20
#   key_3 => mul_13
#   key_5 => view_19
#   matmul => bmm, view_23, view_24, view_25
#   matmul_1 => view_28
#   ones => full_default_2
#   pairwise_decay => sub_2
#   pairwise_decay_1 => full_default_3, where_2
#   pairwise_decay_2 => exp_3
#   strictly_upper_mask => ge_1, iota_2, iota_3, logical_and, sub_1, unsqueeze_11, unsqueeze_12
#   transpose_7 => permute_11
#   unsqueeze_2 => unsqueeze_10
#   unsqueeze_3 => unsqueeze_13
#   unsqueeze_4 => unsqueeze_14
#   ut_system => mul_17
# Graph fragment:
#   %mul_16 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0" = PlaceHolder[target=mul_16]
#   %mul_13 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0" = PlaceHolder[target=mul_13]
#   %cumsum : Tensor "f32[1, 16, 2, 64][2048, 128, 64, 1]tnca:0" = PlaceHolder[target=cumsum]
#   %bmm : Tensor "f32[32, 64, 64][4096, 64, 1]tnca:0" = PlaceHolder[target=bmm]
#   %exp_3 : Tensor "f32[1, 16, 2, 64, 64][131072, 8192, 4096, 64, 1]tnca:0" = PlaceHolder[target=exp_3]
#   %bmm_1 : Tensor "f32[32, 64, 64][4096, 64, 1]tnca:0" = PlaceHolder[target=bmm_1]
#   %add_8 : Tensor "f32[1, 16, 128, 1][2048, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%sum_2, 1e-06), kwargs = {})
#   %rsqrt_2 : Tensor "f32[1, 16, 128, 1][2048, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_8,), kwargs = {})
#   %mul_13 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%clone_5, %rsqrt_2), kwargs = {})
#   %view_19 : Tensor "f32[1, 16, 2, 64, 128][262144, 16384, 8192, 128, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.reshape.default](args = (%mul_13, [1, 16, -1, 64, 128]), kwargs = {})
#   %view_28 : Tensor "f32[1, 16, 2, 64, 64][131072, 8192, 4096, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_1, [1, 16, 2, 64, 64]), kwargs = {})
#   %iota_2 : Tensor "i64[64][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (64,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %unsqueeze_11 : Tensor "i64[1, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%iota_2, -2), kwargs = {})
#   %iota_3 : Tensor "i64[64][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (64,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %unsqueeze_12 : Tensor "i64[64, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%iota_3, -1), kwargs = {})
#   %sub_1 : Tensor "i64[64, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%unsqueeze_11, %unsqueeze_12), kwargs = {})
#   %ge_1 : Tensor "b8[64, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.ge.Scalar](args = (%sub_1, 1), kwargs = {})
#   %full_default_2 : Tensor "b8[64, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([64, 64], True), kwargs = {dtype: torch.bool, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %logical_and : Tensor "b8[64, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_and.default](args = (%ge_1, %full_default_2), kwargs = {})
#   %full_default_3 : Tensor "f32[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([], -inf), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %unsqueeze_13 : Tensor "f32[1, 16, 2, 64, 1][2048, 128, 64, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%cumsum, 4), kwargs = {})
#   %unsqueeze_14 : Tensor "f32[1, 16, 2, 1, 64][2048, 128, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%cumsum, 3), kwargs = {})
#   %sub_2 : Tensor "f32[1, 16, 2, 64, 64][131072, 8192, 4096, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%unsqueeze_13, %unsqueeze_14), kwargs = {})
#   %where_2 : Tensor "f32[1, 16, 2, 64, 64][131072, 8192, 4096, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_and, %full_default_3, %sub_2), kwargs = {})
#   %exp_3 : Tensor "f32[1, 16, 2, 64, 64][131072, 8192, 4096, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.exp.default](args = (%where_2,), kwargs = {})
#   %mul_18 : Tensor "f32[1, 16, 2, 64, 64][131072, 8192, 4096, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%view_28, %exp_3), kwargs = {})
#   %unsqueeze_10 : Tensor "f32[1, 16, 128, 1][2048, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%clone_7, -1), kwargs = {})
#   %mul_16 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_13, %unsqueeze_10), kwargs = {})
#   %view_20 : Tensor "f32[1, 16, 2, 64, 128][262144, 16384, 8192, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%mul_16, [1, 16, -1, 64, 128]), kwargs = {})
#   %view_23 : Tensor "f32[32, 64, 128][8192, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_4, [32, 64, 128]), kwargs = {})
#   %permute_11 : Tensor "f32[1, 16, 2, 128, 64][262144, 16384, 8192, 1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_19, [0, 1, 2, 4, 3]), kwargs = {})
#   %view_24 : Tensor "f32[32, 128, 64][8192, 1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_5, [32, 128, 64]), kwargs = {})
#   %bmm : Tensor "f32[32, 64, 64][4096, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_23, %view_24), kwargs = {})
#   %view_25 : Tensor "f32[1, 16, 2, 64, 64][131072, 8192, 4096, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm, [1, 16, 2, 64, 64]), kwargs = {})
#   %mul_17 : Tensor "f32[1, 16, 2, 64, 64][131072, 8192, 4096, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%view_25, %exp_3), kwargs = {})
#   return %bmm,%exp_3,%mul_17,%mul_18
triton_tem_fused_add_bmm_exp_masked_fill_mul_ones_rsqrt_sub_transpose_triu_unsqueeze_view_15 = async_compile.triton('triton_tem_fused_add_bmm_exp_masked_fill_mul_ones_rsqrt_sub_transpose_triu_unsqueeze_view_15', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp32', 'arg_B': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'out_ptr2': '*fp32', 'out_ptr3': '*fp32'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_add_bmm_exp_masked_fill_mul_ones_rsqrt_sub_transpose_triu_unsqueeze_view_15', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_add_bmm_exp_masked_fill_mul_ones_rsqrt_sub_transpose_triu_unsqueeze_view_15(arg_A, arg_B, in_ptr2, in_ptr3, out_ptr2, out_ptr3):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 64
    N = 64
    K = 128
    BATCH = 32

    stride_aq = 8192
    stride_am = 128
    stride_ak = 1

    stride_bq = 8192
    stride_bk = 1
    stride_bn = 128

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        ram = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        ram = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        rbn = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        rbn = rn % N

    rk = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)

    # Reconstruct batch index from grid_y/grid_z split (handles batch > 65535)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    # Clamp to valid range for safe pointer arithmetic; out-of-bounds CTAs are
    # masked off at the store below.
    idx_q_clamped = tl.minimum(idx_q, BATCH - 1)
    A = A + (ram[:, None] * stride_am + rk[None, :] * stride_ak + idx_q_clamped*stride_aq)
    B = B + (rk[:, None] * stride_bk + rbn[None, :] * stride_bn + idx_q_clamped*stride_bq)

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)
    for k in range(K, 0, -BLOCK_K):
        if EVEN_K:
            a = tl.load(A)
            b = tl.load(B)
        else:
            a = tl.load(A, mask=rk[None, :] < k, other=0.)
            b = tl.load(B, mask=rk[:, None] < k, other=0.)
        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32)
        A += BLOCK_K * stride_ak
        B += BLOCK_K * stride_bk

    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N) & (idx_q < BATCH)

    # inductor generates a suffix
    xindex = idx_n + 64*idx_m + 4096*idx_q
    tmp5 = tl.load(in_ptr2 + (tl.broadcast_to(idx_m + 64*idx_q, [BLOCK_M, BLOCK_N])), mask, eviction_policy='evict_last')
    tmp6 = tl.load(in_ptr2 + (tl.broadcast_to(idx_n + 64*idx_q, [BLOCK_M, BLOCK_N])), mask, eviction_policy='evict_last')
    tmp12 = tl.load(in_ptr3 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), mask)
    tmp0 = (tl.broadcast_to(idx_n + ((-1)*idx_m), [BLOCK_M, BLOCK_N])).to(tl.int32)
    tmp1 = tl.full([1], 1, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = tl.full([1], True, tl.int1)
    tmp4 = tmp2 & tmp3
    tmp7 = tmp5 - tmp6
    tmp8 = tl.full([1], float("-inf"), tl.float32)
    tmp9 = tl.where(tmp4, tmp8, tmp7)
    tmp10 = libdevice.exp(tmp9)
    tmp11 = acc * tmp10
    tmp13 = tmp12 * tmp10
    tl.store(out_ptr2 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), tmp11, mask)
    tl.store(out_ptr3 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), tmp13, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/u3/cu3gqy3qdqaeoavuv7j54rzovgbjeq7vwt32ywfwq3jqdvgitrae.py
# Topologically Sorted Source Nodes: [getitem_18, getitem_19, matmul_2, v_new], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
# Source node to ATen node mapping:
#   getitem_18 => select_33
#   getitem_19 => select_34
#   matmul_2 => bmm_2, view_29, view_30, view_31
#   v_new => sub_4
# Graph fragment:
#   %linalg_solve_triangular_1 : Tensor "f32[1, 16, 2, 64, 128][262144, 16384, 8192, 1, 64]tnca:0" = PlaceHolder[target=linalg_solve_triangular_1]
#   %expand_9 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0" = PlaceHolder[target=expand_9]
#   %linalg_solve_triangular : Tensor "f32[1, 16, 2, 64, 128][262144, 16384, 8192, 1, 64]tnca:0" = PlaceHolder[target=linalg_solve_triangular]
#   %bmm_2 : Tensor "f32[16, 64, 128][8192, 128, 1]tnca:0" = PlaceHolder[target=bmm_2]
#   %select_33 : Tensor "f32[1, 16, 64, 128][262144, 16384, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%linalg_solve_triangular, 2, 0), kwargs = {})
#   %select_34 : Tensor "f32[1, 16, 64, 128][262144, 16384, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%linalg_solve_triangular_1, 2, 0), kwargs = {})
#   %view_29 : Tensor "f32[16, 64, 128][16384, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_8, [16, 64, 128]), kwargs = {})
#   %view_30 : Tensor "f32[16, 128, 128][16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_9, [16, 128, 128]), kwargs = {})
#   %bmm_2 : Tensor "f32[16, 64, 128][8192, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_29, %view_30), kwargs = {})
#   %view_31 : Tensor "f32[1, 16, 64, 128][131072, 8192, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_2, [1, 16, 64, 128]), kwargs = {})
#   %sub_4 : Tensor "f32[1, 16, 64, 128][131072, 8192, 1, 64]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.sub.Tensor](args = (%select_33, %view_31), kwargs = {})
#   return %bmm_2,%expand_15
triton_tem_fused_bmm_select_sub_view_16 = async_compile.triton('triton_tem_fused_bmm_select_sub_view_16', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp32', 'arg_B': '*fp32', 'in_ptr2': '*fp32', 'out_ptr1': '*fp32'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_bmm_select_sub_view_16', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_bmm_select_sub_view_16(arg_A, arg_B, in_ptr2, out_ptr1):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 64
    N = 128
    K = 128
    BATCH = 16

    stride_aq = 16384
    stride_am = 1
    stride_ak = 64

    stride_bq = 16384
    stride_bk = 128
    stride_bn = 1

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        ram = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        ram = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        rbn = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        rbn = rn % N

    rk = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)

    # Reconstruct batch index from grid_y/grid_z split (handles batch > 65535)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    # Clamp to valid range for safe pointer arithmetic; out-of-bounds CTAs are
    # masked off at the store below.
    idx_q_clamped = tl.minimum(idx_q, BATCH - 1)
    A = A + (ram[:, None] * stride_am + rk[None, :] * stride_ak + idx_q_clamped*stride_aq)
    B = B + (rk[:, None] * stride_bk + rbn[None, :] * stride_bn + idx_q_clamped*stride_bq)

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)
    for k in range(K, 0, -BLOCK_K):
        if EVEN_K:
            a = tl.load(A)
            b = tl.load(B)
        else:
            a = tl.load(A, mask=rk[None, :] < k, other=0.)
            b = tl.load(B, mask=rk[:, None] < k, other=0.)
        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32)
        A += BLOCK_K * stride_ak
        B += BLOCK_K * stride_bk

    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N) & (idx_q < BATCH)

    # inductor generates a suffix
    xindex = idx_n + 128*idx_m + 8192*idx_q
    tmp0 = tl.load(in_ptr2 + (tl.broadcast_to(idx_m + 64*idx_n + 16384*idx_q, [BLOCK_M, BLOCK_N])), mask, eviction_policy='evict_last')
    tmp1 = tmp0 - acc
    tl.store(out_ptr1 + (tl.broadcast_to(idx_n + 128*idx_m + 8192*idx_q, [BLOCK_M, BLOCK_N])), tmp1, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/yr/cyr2agy7blratdzzxk6k6tlonci2d2mkf26rjovocbtaxxauwkdu.py
# Topologically Sorted Source Nodes: [matmul_1, intra_chunk_attn, getitem_21, matmul_4, getitem_18, matmul_2, v_new], Original ATen: [aten.view, aten.mul, aten.select, aten.sub, aten.bmm]
# Source node to ATen node mapping:
#   getitem_18 => select_33
#   getitem_21 => select_36
#   intra_chunk_attn => mul_18
#   matmul_1 => view_28
#   matmul_2 => view_31
#   matmul_4 => bmm_4, view_35, view_36
#   v_new => sub_4
# Graph fragment:
#   %mul_18 : Tensor "f32[1, 16, 2, 64, 64][131072, 8192, 4096, 64, 1]tnca:0" = PlaceHolder[target=mul_18]
#   %expand_15 : Tensor "f32[1, 16, 64, 128][131072, 8192, 128, 1]tnca:0" = PlaceHolder[target=expand_15]
#   %view_28 : Tensor "f32[1, 16, 2, 64, 64][131072, 8192, 4096, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_1, [1, 16, 2, 64, 64]), kwargs = {})
#   %mul_18 : Tensor "f32[1, 16, 2, 64, 64][131072, 8192, 4096, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%view_28, %exp_3), kwargs = {})
#   %select_36 : Tensor "f32[1, 16, 64, 64][131072, 8192, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%mul_18, 2, 0), kwargs = {})
#   %view_35 : Tensor "f32[16, 64, 64][8192, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_12, [16, 64, 64]), kwargs = {})
#   %select_33 : Tensor "f32[1, 16, 64, 128][262144, 16384, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%linalg_solve_triangular, 2, 0), kwargs = {})
#   %view_31 : Tensor "f32[1, 16, 64, 128][131072, 8192, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_2, [1, 16, 64, 128]), kwargs = {})
#   %sub_4 : Tensor "f32[1, 16, 64, 128][131072, 8192, 1, 64]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.sub.Tensor](args = (%select_33, %view_31), kwargs = {})
#   %view_36 : Tensor "f32[16, 64, 128][8192, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_13, [16, 64, 128]), kwargs = {})
#   %bmm_4 : Tensor "f32[16, 64, 128][8192, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_35, %view_36), kwargs = {})
#   return %bmm_4
triton_tem_fused_bmm_mul_select_sub_view_17 = async_compile.triton('triton_tem_fused_bmm_mul_select_sub_view_17', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp32', 'arg_B': '*fp32', 'out_ptr0': '*fp32'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_bmm_mul_select_sub_view_17', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_bmm_mul_select_sub_view_17(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 64
    N = 128
    K = 64
    BATCH = 16

    stride_aq = 8192
    stride_am = 64
    stride_ak = 1

    stride_bq = 8192
    stride_bk = 128
    stride_bn = 1

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        ram = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        ram = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        rbn = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        rbn = rn % N

    rk = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)

    # Reconstruct batch index from grid_y/grid_z split (handles batch > 65535)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    # Clamp to valid range for safe pointer arithmetic; out-of-bounds CTAs are
    # masked off at the store below.
    idx_q_clamped = tl.minimum(idx_q, BATCH - 1)
    A = A + (ram[:, None] * stride_am + rk[None, :] * stride_ak + idx_q_clamped*stride_aq)
    B = B + (rk[:, None] * stride_bk + rbn[None, :] * stride_bn + idx_q_clamped*stride_bq)

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)
    for k in range(K, 0, -BLOCK_K):
        if EVEN_K:
            a = tl.load(A)
            b = tl.load(B)
        else:
            a = tl.load(A, mask=rk[None, :] < k, other=0.)
            b = tl.load(B, mask=rk[:, None] < k, other=0.)
        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32)
        A += BLOCK_K * stride_ak
        B += BLOCK_K * stride_bk

    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N) & (idx_q < BATCH)

    # inductor generates a suffix
    xindex = idx_n + 128*idx_m + 8192*idx_q
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/eh/cehozpqikexz5cg3n36leenuxxfbrznn2ot2zferfwvkua7b24dt.py
# Topologically Sorted Source Nodes: [getitem_16, exp_5], Original ATen: [aten.select, aten.exp]
# Source node to ATen node mapping:
#   exp_5 => exp_7
#   getitem_16 => select_32
# Graph fragment:
#   %cumsum : Tensor "f32[1, 16, 2, 64][2048, 128, 64, 1]tnca:0" = PlaceHolder[target=cumsum]
#   %select_32 : Tensor "f32[1, 16, 2][2048, 128, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%cumsum, 3, -1), kwargs = {})
#   %exp_7 : Tensor "f32[1, 16, 2][32, 2, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%select_32,), kwargs = {})
#   return %exp_7
triton_poi_fused_exp_select_18 = async_compile.triton('triton_poi_fused_exp_select_18', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 32}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_exp_select_18', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 256}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_exp_select_18(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 32
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (63 + 64*x0), xmask, eviction_policy='evict_last')
    tmp1 = libdevice.exp(tmp0)
    tl.store(out_ptr0 + (x0), tmp1, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/vd/cvdhmtokmcwqgvl2wqnd2nqoxu6a56zwzy6xok5ebrkjrqjpevbz.py
# Topologically Sorted Source Nodes: [add_4, inv_norm_1, key_3, key_5, getitem_16, exp_5, chunk_decay, getitem_22, mul_18, getitem_15, sub_1, exp_4, unsqueeze_7, key_6, getitem_23, transpose_9, matmul_5, last_recurrent_state_1], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.select, aten.exp, aten.unsqueeze, aten.slice, aten.sub, aten.transpose, aten.bmm]
# Source node to ATen node mapping:
#   add_4 => add_8
#   chunk_decay => unsqueeze_18, unsqueeze_19
#   exp_4 => exp_6
#   exp_5 => exp_7
#   getitem_15 => slice_23
#   getitem_16 => select_32
#   getitem_22 => select_39
#   getitem_23 => select_40
#   inv_norm_1 => rsqrt_2
#   key_3 => mul_13
#   key_5 => view_19
#   key_6 => mul_21
#   last_recurrent_state_1 => add_10
#   matmul_5 => bmm_5, view_38, view_39, view_40
#   mul_18 => mul_22
#   sub_1 => sub_3
#   transpose_9 => permute_14
#   unsqueeze_7 => unsqueeze_17
# Graph fragment:
#   %mul_21 : Tensor "f32[1, 16, 2, 64, 128][262144, 16384, 8192, 128, 1]tnca:0" = PlaceHolder[target=mul_21]
#   %expand_15 : Tensor "f32[1, 16, 64, 128][131072, 8192, 128, 1]tnca:0" = PlaceHolder[target=expand_15]
#   %exp_7 : Tensor "f32[1, 16, 2][32, 2, 1]tnca:0" = PlaceHolder[target=exp_7]
#   %bmm_5 : Tensor "f32[16, 128, 128][16384, 128, 1]tnca:0" = PlaceHolder[target=bmm_5]
#   %add_8 : Tensor "f32[1, 16, 128, 1][2048, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%sum_2, 1e-06), kwargs = {})
#   %rsqrt_2 : Tensor "f32[1, 16, 128, 1][2048, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_8,), kwargs = {})
#   %mul_13 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%clone_5, %rsqrt_2), kwargs = {})
#   %view_19 : Tensor "f32[1, 16, 2, 64, 128][262144, 16384, 8192, 128, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.reshape.default](args = (%mul_13, [1, 16, -1, 64, 128]), kwargs = {})
#   %select_32 : Tensor "f32[1, 16, 2][2048, 128, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%cumsum, 3, -1), kwargs = {})
#   %exp_7 : Tensor "f32[1, 16, 2][32, 2, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%select_32,), kwargs = {})
#   %unsqueeze_18 : Tensor "f32[1, 16, 2, 1][32, 2, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%exp_7, 3), kwargs = {})
#   %unsqueeze_19 : Tensor "f32[1, 16, 2, 1, 1][32, 2, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze_18, 4), kwargs = {})
#   %select_39 : Tensor "f32[1, 16, 1, 1][32, 2, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%unsqueeze_19, 2, 0), kwargs = {})
#   %mul_22 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%full_2, %select_39), kwargs = {})
#   %slice_23 : Tensor "f32[1, 16, 2, 1][2048, 128, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%cumsum, 3, -1, 9223372036854775807), kwargs = {})
#   %sub_3 : Tensor "f32[1, 16, 2, 64][2048, 128, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%slice_23, %cumsum), kwargs = {})
#   %exp_6 : Tensor "f32[1, 16, 2, 64][2048, 128, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%sub_3,), kwargs = {})
#   %unsqueeze_17 : Tensor "f32[1, 16, 2, 64, 1][2048, 128, 64, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%exp_6, -1), kwargs = {})
#   %mul_21 : Tensor "f32[1, 16, 2, 64, 128][262144, 16384, 8192, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%view_19, %unsqueeze_17), kwargs = {})
#   %select_40 : Tensor "f32[1, 16, 64, 128][262144, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%mul_21, 2, 0), kwargs = {})
#   %permute_14 : Tensor "f32[1, 16, 128, 64][262144, 16384, 1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%select_40, [0, 1, 3, 2]), kwargs = {})
#   %view_38 : Tensor "f32[16, 128, 64][16384, 1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_14, [16, 128, 64]), kwargs = {})
#   %view_39 : Tensor "f32[16, 64, 128][8192, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_15, [16, 64, 128]), kwargs = {})
#   %bmm_5 : Tensor "f32[16, 128, 128][16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_38, %view_39), kwargs = {})
#   %view_40 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_5, [1, 16, 128, 128]), kwargs = {})
#   %add_10 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_22, %view_40), kwargs = {})
#   return %bmm_5,%expand_17
triton_tem_fused_add_bmm_exp_mul_rsqrt_select_slice_sub_transpose_unsqueeze_view_19 = async_compile.triton('triton_tem_fused_add_bmm_exp_mul_rsqrt_select_slice_sub_transpose_unsqueeze_view_19', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp32', 'arg_B': '*fp32', 'in_ptr2': '*fp32', 'out_ptr1': '*fp32'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_add_bmm_exp_mul_rsqrt_select_slice_sub_transpose_unsqueeze_view_19', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_add_bmm_exp_mul_rsqrt_select_slice_sub_transpose_unsqueeze_view_19(arg_A, arg_B, in_ptr2, out_ptr1):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 128
    N = 128
    K = 64
    BATCH = 16

    stride_aq = 16384
    stride_am = 1
    stride_ak = 128

    stride_bq = 8192
    stride_bk = 128
    stride_bn = 1

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        ram = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        ram = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        rbn = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        rbn = rn % N

    rk = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)

    # Reconstruct batch index from grid_y/grid_z split (handles batch > 65535)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    # Clamp to valid range for safe pointer arithmetic; out-of-bounds CTAs are
    # masked off at the store below.
    idx_q_clamped = tl.minimum(idx_q, BATCH - 1)
    A = A + (ram[:, None] * stride_am + rk[None, :] * stride_ak + idx_q_clamped*stride_aq)
    B = B + (rk[:, None] * stride_bk + rbn[None, :] * stride_bn + idx_q_clamped*stride_bq)

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)
    for k in range(K, 0, -BLOCK_K):
        if EVEN_K:
            a = tl.load(A)
            b = tl.load(B)
        else:
            a = tl.load(A, mask=rk[None, :] < k, other=0.)
            b = tl.load(B, mask=rk[:, None] < k, other=0.)
        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32)
        A += BLOCK_K * stride_ak
        B += BLOCK_K * stride_bk

    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N) & (idx_q < BATCH)

    # inductor generates a suffix
    xindex = idx_n + 128*idx_m + 16384*idx_q
    tmp0 = tl.load(in_ptr2 + (tl.broadcast_to(2*idx_q, [BLOCK_M, BLOCK_N])), mask, eviction_policy='evict_last')
    tmp1 = tl.full([1], 0.0, tl.float32)
    tmp2 = tmp1 * tmp0
    tmp3 = tmp2 + acc
    tl.store(out_ptr1 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), tmp3, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/tk/ctkbm632mey77ankxpjwuichuxfctyghwfrbxqpy46zlhyqhxk22.py
# Topologically Sorted Source Nodes: [getitem_26, inter_chunk_attn_1, getitem_16, exp_5, chunk_decay, getitem_22, mul_18, matmul_5, last_recurrent_state_1], Original ATen: [aten.select, aten.view, aten.exp, aten.unsqueeze, aten.mul, aten.add, aten.bmm]
# Source node to ATen node mapping:
#   chunk_decay => unsqueeze_18, unsqueeze_19
#   exp_5 => exp_7
#   getitem_16 => select_32
#   getitem_22 => select_39
#   getitem_26 => select_43
#   inter_chunk_attn_1 => bmm_7, view_44, view_45
#   last_recurrent_state_1 => add_10
#   matmul_5 => view_40
#   mul_18 => mul_22
# Graph fragment:
#   %mul_20 : Tensor "f32[1, 16, 2, 64, 128][262144, 16384, 8192, 128, 1]tnca:0" = PlaceHolder[target=mul_20]
#   %expand_17 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0" = PlaceHolder[target=expand_17]
#   %select_43 : Tensor "f32[1, 16, 64, 128][262144, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%mul_20, 2, 1), kwargs = {})
#   %view_44 : Tensor "f32[16, 64, 128][16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_18, [16, 64, 128]), kwargs = {})
#   %select_32 : Tensor "f32[1, 16, 2][2048, 128, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%cumsum, 3, -1), kwargs = {})
#   %exp_7 : Tensor "f32[1, 16, 2][32, 2, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%select_32,), kwargs = {})
#   %unsqueeze_18 : Tensor "f32[1, 16, 2, 1][32, 2, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%exp_7, 3), kwargs = {})
#   %unsqueeze_19 : Tensor "f32[1, 16, 2, 1, 1][32, 2, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze_18, 4), kwargs = {})
#   %select_39 : Tensor "f32[1, 16, 1, 1][32, 2, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%unsqueeze_19, 2, 0), kwargs = {})
#   %mul_22 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%full_2, %select_39), kwargs = {})
#   %view_40 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_5, [1, 16, 128, 128]), kwargs = {})
#   %add_10 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_22, %view_40), kwargs = {})
#   %view_45 : Tensor "f32[16, 128, 128][16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_19, [16, 128, 128]), kwargs = {})
#   %bmm_7 : Tensor "f32[16, 64, 128][8192, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_44, %view_45), kwargs = {})
#   return %bmm_7
triton_tem_fused_add_bmm_exp_mul_select_unsqueeze_view_20 = async_compile.triton('triton_tem_fused_add_bmm_exp_mul_select_unsqueeze_view_20', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp32', 'arg_B': '*fp32', 'out_ptr0': '*fp32'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_add_bmm_exp_mul_select_unsqueeze_view_20', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_add_bmm_exp_mul_select_unsqueeze_view_20(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A + 8192
    B = arg_B

    M = 64
    N = 128
    K = 128
    BATCH = 16

    stride_aq = 16384
    stride_am = 128
    stride_ak = 1

    stride_bq = 16384
    stride_bk = 128
    stride_bn = 1

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        ram = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        ram = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        rbn = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        rbn = rn % N

    rk = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)

    # Reconstruct batch index from grid_y/grid_z split (handles batch > 65535)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    # Clamp to valid range for safe pointer arithmetic; out-of-bounds CTAs are
    # masked off at the store below.
    idx_q_clamped = tl.minimum(idx_q, BATCH - 1)
    A = A + (ram[:, None] * stride_am + rk[None, :] * stride_ak + idx_q_clamped*stride_aq)
    B = B + (rk[:, None] * stride_bk + rbn[None, :] * stride_bn + idx_q_clamped*stride_bq)

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)
    for k in range(K, 0, -BLOCK_K):
        if EVEN_K:
            a = tl.load(A)
            b = tl.load(B)
        else:
            a = tl.load(A, mask=rk[None, :] < k, other=0.)
            b = tl.load(B, mask=rk[:, None] < k, other=0.)
        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32)
        A += BLOCK_K * stride_ak
        B += BLOCK_K * stride_bk

    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N) & (idx_q < BATCH)

    # inductor generates a suffix
    xindex = idx_n + 128*idx_m + 8192*idx_q
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/b3/cb3u45foekzjg3q2jrbajinoazkost76xztmsfyuoget24horpoe.py
# Topologically Sorted Source Nodes: [getitem_24, getitem_25, matmul_6, v_new_1], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
# Source node to ATen node mapping:
#   getitem_24 => select_41
#   getitem_25 => select_42
#   matmul_6 => bmm_6, view_41, view_42, view_43
#   v_new_1 => sub_5
# Graph fragment:
#   %linalg_solve_triangular_1 : Tensor "f32[1, 16, 2, 64, 128][262144, 16384, 8192, 1, 64]tnca:0" = PlaceHolder[target=linalg_solve_triangular_1]
#   %expand_17 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0" = PlaceHolder[target=expand_17]
#   %linalg_solve_triangular : Tensor "f32[1, 16, 2, 64, 128][262144, 16384, 8192, 1, 64]tnca:0" = PlaceHolder[target=linalg_solve_triangular]
#   %bmm_6 : Tensor "f32[16, 64, 128][8192, 128, 1]tnca:0" = PlaceHolder[target=bmm_6]
#   %select_41 : Tensor "f32[1, 16, 64, 128][262144, 16384, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%linalg_solve_triangular, 2, 1), kwargs = {})
#   %select_42 : Tensor "f32[1, 16, 64, 128][262144, 16384, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%linalg_solve_triangular_1, 2, 1), kwargs = {})
#   %view_41 : Tensor "f32[16, 64, 128][16384, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_16, [16, 64, 128]), kwargs = {})
#   %view_42 : Tensor "f32[16, 128, 128][16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_17, [16, 128, 128]), kwargs = {})
#   %bmm_6 : Tensor "f32[16, 64, 128][8192, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_41, %view_42), kwargs = {})
#   %view_43 : Tensor "f32[1, 16, 64, 128][131072, 8192, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_6, [1, 16, 64, 128]), kwargs = {})
#   %sub_5 : Tensor "f32[1, 16, 64, 128][131072, 8192, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%select_41, %view_43), kwargs = {})
#   return %bmm_6,%expand_21
triton_tem_fused_bmm_select_sub_view_21 = async_compile.triton('triton_tem_fused_bmm_select_sub_view_21', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp32', 'arg_B': '*fp32', 'in_ptr2': '*fp32', 'out_ptr1': '*fp32'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_bmm_select_sub_view_21', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_bmm_select_sub_view_21(arg_A, arg_B, in_ptr2, out_ptr1):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A + 8192
    B = arg_B

    M = 64
    N = 128
    K = 128
    BATCH = 16

    stride_aq = 16384
    stride_am = 1
    stride_ak = 64

    stride_bq = 16384
    stride_bk = 128
    stride_bn = 1

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        ram = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        ram = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        rbn = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        rbn = rn % N

    rk = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)

    # Reconstruct batch index from grid_y/grid_z split (handles batch > 65535)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    # Clamp to valid range for safe pointer arithmetic; out-of-bounds CTAs are
    # masked off at the store below.
    idx_q_clamped = tl.minimum(idx_q, BATCH - 1)
    A = A + (ram[:, None] * stride_am + rk[None, :] * stride_ak + idx_q_clamped*stride_aq)
    B = B + (rk[:, None] * stride_bk + rbn[None, :] * stride_bn + idx_q_clamped*stride_bq)

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)
    for k in range(K, 0, -BLOCK_K):
        if EVEN_K:
            a = tl.load(A)
            b = tl.load(B)
        else:
            a = tl.load(A, mask=rk[None, :] < k, other=0.)
            b = tl.load(B, mask=rk[:, None] < k, other=0.)
        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32)
        A += BLOCK_K * stride_ak
        B += BLOCK_K * stride_bk

    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N) & (idx_q < BATCH)

    # inductor generates a suffix
    xindex = idx_n + 128*idx_m + 8192*idx_q
    tmp0 = tl.load(in_ptr2 + (tl.broadcast_to(8192 + idx_m + 64*idx_n + 16384*idx_q, [BLOCK_M, BLOCK_N])), mask, eviction_policy='evict_last')
    tmp1 = tmp0 - acc
    tl.store(out_ptr1 + (tl.broadcast_to(idx_n + 128*idx_m + 8192*idx_q, [BLOCK_M, BLOCK_N])), tmp1, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/dg/cdgr5gr5z56lsjjxu2h6bzu7drnm7ymetl2fva6jsafaz3zvshyd.py
# Topologically Sorted Source Nodes: [getitem_27, matmul_8, getitem_24, matmul_6, v_new_1], Original ATen: [aten.select, aten.view, aten.sub, aten.bmm]
# Source node to ATen node mapping:
#   getitem_24 => select_41
#   getitem_27 => select_44
#   matmul_6 => view_43
#   matmul_8 => bmm_8, view_47, view_48
#   v_new_1 => sub_5
# Graph fragment:
#   %mul_18 : Tensor "f32[1, 16, 2, 64, 64][131072, 8192, 4096, 64, 1]tnca:0" = PlaceHolder[target=mul_18]
#   %expand_21 : Tensor "f32[1, 16, 64, 128][131072, 8192, 128, 1]tnca:0" = PlaceHolder[target=expand_21]
#   %select_44 : Tensor "f32[1, 16, 64, 64][131072, 8192, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%mul_18, 2, 1), kwargs = {})
#   %view_47 : Tensor "f32[16, 64, 64][8192, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_20, [16, 64, 64]), kwargs = {})
#   %select_41 : Tensor "f32[1, 16, 64, 128][262144, 16384, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%linalg_solve_triangular, 2, 1), kwargs = {})
#   %view_43 : Tensor "f32[1, 16, 64, 128][131072, 8192, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_6, [1, 16, 64, 128]), kwargs = {})
#   %sub_5 : Tensor "f32[1, 16, 64, 128][131072, 8192, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%select_41, %view_43), kwargs = {})
#   %view_48 : Tensor "f32[16, 64, 128][8192, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_21, [16, 64, 128]), kwargs = {})
#   %bmm_8 : Tensor "f32[16, 64, 128][8192, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_47, %view_48), kwargs = {})
#   return %bmm_8
triton_tem_fused_bmm_select_sub_view_22 = async_compile.triton('triton_tem_fused_bmm_select_sub_view_22', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp32', 'arg_B': '*fp32', 'out_ptr0': '*fp32'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_bmm_select_sub_view_22', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_bmm_select_sub_view_22(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A + 4096
    B = arg_B

    M = 64
    N = 128
    K = 64
    BATCH = 16

    stride_aq = 8192
    stride_am = 64
    stride_ak = 1

    stride_bq = 8192
    stride_bk = 128
    stride_bn = 1

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        ram = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        ram = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        rbn = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        rbn = rn % N

    rk = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)

    # Reconstruct batch index from grid_y/grid_z split (handles batch > 65535)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    # Clamp to valid range for safe pointer arithmetic; out-of-bounds CTAs are
    # masked off at the store below.
    idx_q_clamped = tl.minimum(idx_q, BATCH - 1)
    A = A + (ram[:, None] * stride_am + rk[None, :] * stride_ak + idx_q_clamped*stride_aq)
    B = B + (rk[:, None] * stride_bk + rbn[None, :] * stride_bn + idx_q_clamped*stride_bq)

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)
    for k in range(K, 0, -BLOCK_K):
        if EVEN_K:
            a = tl.load(A)
            b = tl.load(B)
        else:
            a = tl.load(A, mask=rk[None, :] < k, other=0.)
            b = tl.load(B, mask=rk[:, None] < k, other=0.)
        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32)
        A += BLOCK_K * stride_ak
        B += BLOCK_K * stride_bk

    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N) & (idx_q < BATCH)

    # inductor generates a suffix
    xindex = idx_n + 128*idx_m + 8192*idx_q
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/4h/c4hfv7d7m5ojhqh2abglxmesl66ulrsybf3shuej62e435cmataj.py
# Topologically Sorted Source Nodes: [z], Original ATen: [aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   z => mm_1, permute_2, view_4
# Graph fragment:
#   %convert_element_type_6 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0" = PlaceHolder[target=convert_element_type_6]
#   %arg6_1 : Tensor "bf16[2048, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg6_1]
#   %view_4 : Tensor "bf16[128, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_6, [128, 2048]), kwargs = {})
#   %permute_2 : Tensor "bf16[2048, 2048][1, 2048]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg6_1, [1, 0]), kwargs = {})
#   %mm_1 : Tensor "bf16[128, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_4, %permute_2), kwargs = {})
#   return %mm_1
triton_tem_fused_mm_t_view_23 = async_compile.triton('triton_tem_fused_mm_t_view_23', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*bf16', 'arg_B': '*bf16', 'out_ptr0': '*bf16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_mm_t_view_23', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_mm_t_view_23(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 128
    N = 2048
    K = 2048
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 2048
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2048

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2048*idx_m
        a = tl.load(A + (xindex))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 2048*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2048*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 2048*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/ti/ctiydmwytbnnp34qwgg5yerptl42rwchq7piazn2il3sngzvzd2b.py
# Topologically Sorted Source Nodes: [core_attn_out, setitem_4, inter_chunk_attn, matmul_4, add_5, setitem_5, inter_chunk_attn_1, matmul_8, add_7, core_attn_out_1, transpose_11, core_attn_out_3, core_attn_out_4, hidden_states_1, pow_2, variance, add_9, rsqrt_3, hidden_states_2, to_12, hidden_states_3, z, z_1, z_2, to_13, silu_1, hidden_states_4, core_attn_out_5], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu]
# Source node to ATen node mapping:
#   add_5 => add_9
#   add_7 => add_11
#   add_9 => add_13
#   core_attn_out => full_3, permute_13
#   core_attn_out_1 => clone_9, view_53
#   core_attn_out_3 => clone_10, convert_element_type_25
#   core_attn_out_4 => view_54
#   core_attn_out_5 => convert_element_type_29
#   hidden_states_1 => convert_element_type_26
#   hidden_states_2 => mul_24
#   hidden_states_3 => mul_25
#   hidden_states_4 => mul_26
#   inter_chunk_attn => view_34
#   inter_chunk_attn_1 => view_46
#   matmul_4 => view_37
#   matmul_8 => view_49
#   pow_2 => pow_2
#   rsqrt_3 => rsqrt_3
#   setitem_4 => copy_4, select_37
#   setitem_5 => copy_5, select_46
#   silu_1 => add_14, div_1, exp_8, neg_2
#   to_12 => convert_element_type_27
#   to_13 => convert_element_type_28
#   transpose_11 => permute_16
#   variance => mean_1
#   z => view_5
#   z_1 => view_6
#   z_2 => view_55
# Graph fragment:
#   %bmm_7 : Tensor "f32[16, 64, 128][8192, 128, 1]tnca:0" = PlaceHolder[target=bmm_7]
#   %bmm_8 : Tensor "f32[16, 64, 128][8192, 128, 1]tnca:0" = PlaceHolder[target=bmm_8]
#   %bmm_3 : Tensor "f32[16, 64, 128][8192, 128, 1]tnca:0" = PlaceHolder[target=bmm_3]
#   %bmm_4 : Tensor "f32[16, 64, 128][8192, 128, 1]tnca:0" = PlaceHolder[target=bmm_4]
#   %arg12_1 : Tensor "f32[128][1]tnca:0" = PlaceHolder[target=arg12_1]
#   %buf42 : Tensor "f32[2048, 1][1, 2048]tnca:0" = PlaceHolder[target=buf42]
#   %mm_1 : Tensor "bf16[128, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_1]
#   %full_3 : Tensor "f32[1, 16, 2, 128, 64][262144, 16384, 8192, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([1, 16, 2, 128, 64], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %permute_13 : Tensor "f32[1, 16, 2, 64, 128][262144, 16384, 8192, 1, 64]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%full_3, [0, 1, 2, 4, 3]), kwargs = {})
#   %select_37 : Tensor "f32[1, 16, 64, 128][262144, 16384, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%permute_13, 2, 0), kwargs = {})
#   %view_34 : Tensor "f32[1, 16, 64, 128][131072, 8192, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_3, [1, 16, 64, 128]), kwargs = {})
#   %view_37 : Tensor "f32[1, 16, 64, 128][131072, 8192, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_4, [1, 16, 64, 128]), kwargs = {})
#   %add_9 : Tensor "f32[1, 16, 64, 128][131072, 8192, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%view_34, %view_37), kwargs = {})
#   %copy_4 : Tensor "f32[1, 16, 64, 128][262144, 16384, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.copy.default](args = (%select_37, %add_9), kwargs = {})
#   %select_scatter_default_2 : Tensor "f32[1, 16, 2, 64, 128][262144, 16384, 8192, 1, 64]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.select_scatter.default](args = (%permute_13, %copy_4, 2, 0), kwargs = {})
#   %select_46 : Tensor "f32[1, 16, 64, 128][262144, 16384, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_2, 2, 1), kwargs = {})
#   %view_46 : Tensor "f32[1, 16, 64, 128][131072, 8192, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_7, [1, 16, 64, 128]), kwargs = {})
#   %view_49 : Tensor "f32[1, 16, 64, 128][131072, 8192, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_8, [1, 16, 64, 128]), kwargs = {})
#   %add_11 : Tensor "f32[1, 16, 64, 128][131072, 8192, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%view_46, %view_49), kwargs = {})
#   %copy_5 : Tensor "f32[1, 16, 64, 128][262144, 16384, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.copy.default](args = (%select_46, %add_11), kwargs = {})
#   %select_scatter_default_3 : Tensor "f32[1, 16, 2, 64, 128][262144, 16384, 8192, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default_2, %copy_5, 2, 1), kwargs = {})
#   %clone_9 : Tensor "f32[1, 16, 2, 64, 128][262144, 16384, 8192, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%select_scatter_default_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_53 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_9, [1, 16, 128, 128]), kwargs = {})
#   %permute_16 : Tensor "f32[1, 128, 16, 128][262144, 128, 16384, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_53, [0, 2, 1, 3]), kwargs = {})
#   %convert_element_type_25 : Tensor "bf16[1, 128, 16, 128][262144, 128, 16384, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_16, torch.bfloat16), kwargs = {})
#   %clone_10 : Tensor "bf16[1, 128, 16, 128][262144, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%convert_element_type_25,), kwargs = {memory_format: torch.contiguous_format})
#   %view_54 : Tensor "bf16[2048, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_10, [-1, 128]), kwargs = {})
#   %convert_element_type_26 : Tensor "f32[2048, 128][128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_54, torch.float32), kwargs = {})
#   %pow_2 : Tensor "f32[2048, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_26, 2), kwargs = {})
#   %mean_1 : Tensor "f32[2048, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_2, [-1], True), kwargs = {})
#   %add_13 : Tensor "f32[2048, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_1, 1e-06), kwargs = {})
#   %rsqrt_3 : Tensor "f32[2048, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_13,), kwargs = {})
#   %mul_24 : Tensor "f32[2048, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_26, %rsqrt_3), kwargs = {})
#   %convert_element_type_27 : Tensor "bf16[2048, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_24, torch.bfloat16), kwargs = {})
#   %mul_25 : Tensor "f32[2048, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg12_1, %convert_element_type_27), kwargs = {})
#   %view_5 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 128, 2048]), kwargs = {})
#   %view_6 : Tensor "bf16[1, 128, 16, 128][262144, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_5, [1, 128, -1, 128]), kwargs = {})
#   %view_55 : Tensor "bf16[2048, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_6, [-1, 128]), kwargs = {})
#   %convert_element_type_28 : Tensor "f32[2048, 128][128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_55, torch.float32), kwargs = {})
#   %neg_2 : Tensor "f32[2048, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_28,), kwargs = {})
#   %exp_8 : Tensor "f32[2048, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_2,), kwargs = {})
#   %add_14 : Tensor "f32[2048, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp_8, 1), kwargs = {})
#   %div_1 : Tensor "f32[2048, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_28, %add_14), kwargs = {})
#   %mul_26 : Tensor "f32[2048, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_25, %div_1), kwargs = {})
#   %convert_element_type_29 : Tensor "bf16[2048, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_26, torch.bfloat16), kwargs = {})
#   return %buf42,%convert_element_type_29
triton_red_fused__to_copy__unsafe_view_add_clone_copy_mean_mul_pow_rsqrt_select_silu_transpose_view_zeros_like_24 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_clone_copy_mean_mul_pow_rsqrt_select_silu_transpose_view_zeros_like_24', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 2048, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*bf16', 'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_clone_copy_mean_mul_pow_rsqrt_select_silu_transpose_view_zeros_like_24', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 10, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 3670528}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_clone_copy_mean_mul_pow_rsqrt_select_silu_transpose_view_zeros_like_24(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 2048
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    _tmp18 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.load(in_ptr0 + (r0_1 + 128*(((x0 // 16) % 64)) + 8192*((x0 % 16))), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp4 = tl.load(in_ptr1 + (r0_1 + 128*(((x0 // 16) % 64)) + 8192*((x0 % 16))), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp8 = tl.load(in_ptr2 + (r0_1 + 128*(((x0 // 16) % 64)) + 8192*((x0 % 16))), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp9 = tl.load(in_ptr3 + (r0_1 + 128*(((x0 // 16) % 64)) + 8192*((x0 % 16))), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp0 = (x0 // 1024).to(tl.int32)
        tmp1 = tl.full([1], 1, tl.int32)
        tmp2 = tmp0 == tmp1
        tmp5 = tmp3 + tmp4
        tmp6 = tl.full([1], 0, tl.int32)
        tmp7 = tmp0 == tmp6
        tmp10 = tmp8 + tmp9
        tmp11 = tl.full([1], 0.0, tl.float32)
        tmp12 = tl.where(tmp7, tmp10, tmp11)
        tmp13 = tl.where(tmp2, tmp5, tmp12)
        tmp14 = tmp13.to(tl.float32)
        tmp15 = tmp14.to(tl.float32)
        tmp16 = tmp15 * tmp15
        tmp17 = tl.broadcast_to(tmp16, [R0_BLOCK])
        tmp19 = _tmp18 + tmp17
        _tmp18 = tl.where(r0_mask, tmp19, _tmp18)
    tmp18 = triton_helpers.promote_to_tensor(tl.sum(_tmp18, 0))
    tma_descriptor0 = tl.make_tensor_descriptor(in_out_ptr0, shape=[2048, 128], strides=[128, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp20 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp24 = tl.load(in_ptr0 + (r0_1 + 128*(((x0 // 16) % 64)) + 8192*((x0 % 16))), r0_mask, eviction_policy='evict_first', other=0.0)
        tmp25 = tl.load(in_ptr1 + (r0_1 + 128*(((x0 // 16) % 64)) + 8192*((x0 % 16))), r0_mask, eviction_policy='evict_first', other=0.0)
        tmp29 = tl.load(in_ptr2 + (r0_1 + 128*(((x0 // 16) % 64)) + 8192*((x0 % 16))), r0_mask, eviction_policy='evict_first', other=0.0)
        tmp30 = tl.load(in_ptr3 + (r0_1 + 128*(((x0 // 16) % 64)) + 8192*((x0 % 16))), r0_mask, eviction_policy='evict_first', other=0.0)
        tmp46 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp21 = (x0 // 1024).to(tl.int32)
        tmp22 = tl.full([1], 1, tl.int32)
        tmp23 = tmp21 == tmp22
        tmp26 = tmp24 + tmp25
        tmp27 = tl.full([1], 0, tl.int32)
        tmp28 = tmp21 == tmp27
        tmp31 = tmp29 + tmp30
        tmp32 = tl.full([1], 0.0, tl.float32)
        tmp33 = tl.where(tmp28, tmp31, tmp32)
        tmp34 = tl.where(tmp23, tmp26, tmp33)
        tmp35 = tmp34.to(tl.float32)
        tmp36 = tmp35.to(tl.float32)
        tmp37 = tl.full([1], 128.0, tl.float32)
        tmp38 = (tmp18 / tmp37)
        tmp39 = tl.full([1], 1e-06, tl.float32)
        tmp40 = tmp38 + tmp39
        tmp41 = libdevice.rsqrt(tmp40)
        tmp42 = tmp36 * tmp41
        tmp43 = tmp42.to(tl.float32)
        tmp44 = tmp43.to(tl.float32)
        tmp45 = tmp20 * tmp44
        tmp47 = tmp46.to(tl.float32)
        tmp48 = -tmp47
        tmp49 = libdevice.exp(tmp48)
        tmp50 = tl.full([1], 1.0, tl.float32)
        tmp51 = tmp49 + tmp50
        tmp52 = (tmp47 / tmp51)
        tmp53 = tmp45 * tmp52
        tmp54 = tmp53.to(tl.float32)
        tl.store(in_out_ptr0 + (r0_1 + 128*x0), tmp54, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/zo/czof7oaemmfu6d4ef3ra5pxgukcadoojusziamo6btq23dl3azbe.py
# Topologically Sorted Source Nodes: [inputs_embeds, output_2, hidden_states_5, float_6, pow_3, mean_2, add_11, rsqrt_4, output_3, float_7, add_12, output_4, hidden_states_6], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_11 => add_16
#   add_12 => add_17
#   float_6 => convert_element_type_32
#   float_7 => convert_element_type_33
#   hidden_states_5 => add_15
#   hidden_states_6 => convert_element_type_34
#   inputs_embeds => embedding
#   mean_2 => mean_2
#   output_2 => view_58
#   output_3 => mul_27
#   output_4 => mul_28
#   pow_3 => pow_3
#   rsqrt_4 => rsqrt_4
# Graph fragment:
#   %arg0_1 : Tensor "i64[1, 128][128, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %arg1_1 : Tensor "bf16[248320, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %mm_4 : Tensor "bf16[128, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_4]
#   %buf46 : Tensor "f32[1, 128, 1][128, 1, 128]tnca:0" = PlaceHolder[target=buf46]
#   %arg14_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg14_1]
#   %embedding : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg1_1, %arg0_1), kwargs = {})
#   %view_58 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_4, [1, 128, 2048]), kwargs = {})
#   %add_15 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_58), kwargs = {})
#   %convert_element_type_32 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_15, torch.float32), kwargs = {})
#   %pow_3 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_32, 2), kwargs = {})
#   %mean_2 : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_3, [-1], True), kwargs = {})
#   %add_16 : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_2, 1e-06), kwargs = {})
#   %rsqrt_4 : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_16,), kwargs = {})
#   %mul_27 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_32, %rsqrt_4), kwargs = {})
#   %convert_element_type_33 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg14_1, torch.float32), kwargs = {})
#   %add_17 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_33, 1.0), kwargs = {})
#   %mul_28 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_27, %add_17), kwargs = {})
#   %convert_element_type_34 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_28, torch.bfloat16), kwargs = {})
#   return %buf46,%convert_element_type_34
triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_25 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_25', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 128, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_25', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 4, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 1024, 'r0_': 1576960}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_25(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 128
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), None, eviction_policy='evict_last')
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr2, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp8 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp0) & (tmp0 < 248320), "index out of bounds: 0 <= tmp0 < 248320")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 2048*tmp0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tmp5 * tmp5
        tmp7 = tl.broadcast_to(tmp6, [R0_BLOCK])
        tmp9 = _tmp8 + tmp7
        _tmp8 = tl.where(r0_mask, tmp9, _tmp8)
    tmp8 = triton_helpers.promote_to_tensor(tl.sum(_tmp8, 0))
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr2, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp12 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp21 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp0) & (tmp0 < 248320), "index out of bounds: 0 <= tmp0 < 248320")
        tmp11 = tl.load(in_ptr1 + (r0_1 + 2048*tmp0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp13 = tmp11 + tmp12
        tmp14 = tmp13.to(tl.float32)
        tmp15 = tl.full([1], 2048.0, tl.float32)
        tmp16 = (tmp8 / tmp15)
        tmp17 = tl.full([1], 1e-06, tl.float32)
        tmp18 = tmp16 + tmp17
        tmp19 = libdevice.rsqrt(tmp18)
        tmp20 = tmp14 * tmp19
        tmp22 = tmp21.to(tl.float32)
        tmp23 = tl.full([1], 1.0, tl.float32)
        tmp24 = tmp22 + tmp23
        tmp25 = tmp20 * tmp24
        tmp26 = tmp25.to(tl.float32)
        tl.store(out_ptr1 + (r0_1 + 2048*x0), tmp26, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/sa/csau7xd4qjyfj3qlh5uvtzcfsrg7vy4z6ajquc43bi7pklwe3c5g.py
# Topologically Sorted Source Nodes: [linear_5, silu_2, linear_6, mul_25], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
# Source node to ATen node mapping:
#   linear_5 => view_60
#   linear_6 => mm_6, permute_19, view_61, view_62
#   mul_25 => mul_29
#   silu_2 => add_18, convert_element_type_37, convert_element_type_38, div_2, exp_9, neg_3
# Graph fragment:
#   %convert_element_type_34 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0" = PlaceHolder[target=convert_element_type_34]
#   %arg16_1 : Tensor "bf16[6144, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg16_1]
#   %mm_5 : Tensor "bf16[128, 6144][6144, 1]tnca:0" = PlaceHolder[target=mm_5]
#   %mm_6 : Tensor "bf16[128, 6144][6144, 1]tnca:0" = PlaceHolder[target=mm_6]
#   %view_60 : Tensor "bf16[1, 128, 6144][786432, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_5, [1, 128, 6144]), kwargs = {})
#   %convert_element_type_37 : Tensor "f32[1, 128, 6144][786432, 6144, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_60, torch.float32), kwargs = {})
#   %neg_3 : Tensor "f32[1, 128, 6144][786432, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_37,), kwargs = {})
#   %exp_9 : Tensor "f32[1, 128, 6144][786432, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_3,), kwargs = {})
#   %add_18 : Tensor "f32[1, 128, 6144][786432, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp_9, 1), kwargs = {})
#   %div_2 : Tensor "f32[1, 128, 6144][786432, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_37, %add_18), kwargs = {})
#   %convert_element_type_38 : Tensor "bf16[1, 128, 6144][786432, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_2, torch.bfloat16), kwargs = {})
#   %view_61 : Tensor "bf16[128, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_34, [128, 2048]), kwargs = {})
#   %permute_19 : Tensor "bf16[2048, 6144][1, 2048]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg16_1, [1, 0]), kwargs = {})
#   %mm_6 : Tensor "bf16[128, 6144][6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_61, %permute_19), kwargs = {})
#   %view_62 : Tensor "bf16[1, 128, 6144][786432, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_6, [1, 128, 6144]), kwargs = {})
#   %mul_29 : Tensor "bf16[1, 128, 6144][786432, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_38, %view_62), kwargs = {})
#   return %mm_6,%mul_29
triton_tem_fused__unsafe_view_mm_mul_silu_t_view_26 = async_compile.triton('triton_tem_fused__unsafe_view_mm_mul_silu_t_view_26', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*bf16', 'arg_B': '*bf16', 'in_ptr2': '*bf16', 'out_ptr1': '*bf16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__unsafe_view_mm_mul_silu_t_view_26', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__unsafe_view_mm_mul_silu_t_view_26(arg_A, arg_B, in_ptr2, out_ptr1):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 128
    N = 6144
    K = 2048
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 2048
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2048

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2048*idx_m
        a = tl.load(A + (xindex))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 6144*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2048*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 6144*idx_m
    tmp0 = acc.to(tl.bfloat16)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tl.load(in_ptr2 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), mask).to(tl.float32)
    tmp3 = tmp2.to(tl.float32)
    tmp4 = -tmp3
    tmp5 = libdevice.exp(tmp4)
    tmp6 = tl.full([1], 1.0, tl.float32)
    tmp7 = tmp5 + tmp6
    tmp8 = (tmp3 / tmp7)
    tmp9 = tmp8.to(tl.float32)
    tmp10 = tmp9 * tmp1
    tl.store(out_ptr1 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), tmp10, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/pa/cpa42aaz4tqtjlhtrg7bysk3hvcaljtesqqmrlv2265r2te6rwym.py
# Topologically Sorted Source Nodes: [linear_5, silu_2, linear_6, mul_25, down_proj], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   down_proj => mm_7, permute_20, view_63
#   linear_5 => view_60
#   linear_6 => view_62
#   mul_25 => mul_29
#   silu_2 => add_18, convert_element_type_37, convert_element_type_38, div_2, exp_9, neg_3
# Graph fragment:
#   %mul_29 : Tensor "bf16[1, 128, 6144][786432, 6144, 1]tnca:0" = PlaceHolder[target=mul_29]
#   %arg17_1 : Tensor "bf16[2048, 6144][6144, 1]tnca:0" = PlaceHolder[target=arg17_1]
#   %view_60 : Tensor "bf16[1, 128, 6144][786432, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_5, [1, 128, 6144]), kwargs = {})
#   %convert_element_type_37 : Tensor "f32[1, 128, 6144][786432, 6144, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_60, torch.float32), kwargs = {})
#   %neg_3 : Tensor "f32[1, 128, 6144][786432, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_37,), kwargs = {})
#   %exp_9 : Tensor "f32[1, 128, 6144][786432, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_3,), kwargs = {})
#   %add_18 : Tensor "f32[1, 128, 6144][786432, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp_9, 1), kwargs = {})
#   %div_2 : Tensor "f32[1, 128, 6144][786432, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_37, %add_18), kwargs = {})
#   %convert_element_type_38 : Tensor "bf16[1, 128, 6144][786432, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_2, torch.bfloat16), kwargs = {})
#   %view_62 : Tensor "bf16[1, 128, 6144][786432, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_6, [1, 128, 6144]), kwargs = {})
#   %mul_29 : Tensor "bf16[1, 128, 6144][786432, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_38, %view_62), kwargs = {})
#   %view_63 : Tensor "bf16[128, 6144][6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mul_29, [128, 6144]), kwargs = {})
#   %permute_20 : Tensor "bf16[6144, 2048][1, 6144]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg17_1, [1, 0]), kwargs = {})
#   %mm_7 : Tensor "bf16[128, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_63, %permute_20), kwargs = {})
#   return %mm_7
triton_tem_fused__unsafe_view_mm_mul_silu_t_view_27 = async_compile.triton('triton_tem_fused__unsafe_view_mm_mul_silu_t_view_27', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*bf16', 'arg_B': '*bf16', 'out_ptr0': '*bf16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__unsafe_view_mm_mul_silu_t_view_27', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__unsafe_view_mm_mul_silu_t_view_27(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 128
    N = 2048
    K = 6144
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 6144
    stride_ak = 1
    stride_bk = 1
    stride_bn = 6144

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 6144*idx_m
        a = tl.load(A + (xindex))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 2048*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 6144*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 2048*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/fn/cfn6e5wrrmzrvuw2modradhbuzcen7wnzfdl2mrv52vqnu2u4wdx.py
# Topologically Sorted Source Nodes: [inputs_embeds, output_2, hidden_states_5, down_proj, hidden_states_7, float_8, pow_4, mean_3, add_14, rsqrt_5, output_5, float_9, add_15, output_6, hidden_states_8], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_14 => add_20
#   add_15 => add_21
#   down_proj => view_64
#   float_8 => convert_element_type_43
#   float_9 => convert_element_type_44
#   hidden_states_5 => add_15
#   hidden_states_7 => add_19
#   hidden_states_8 => convert_element_type_45
#   inputs_embeds => embedding
#   mean_3 => mean_3
#   output_2 => view_58
#   output_5 => mul_30
#   output_6 => mul_31
#   pow_4 => pow_4
#   rsqrt_5 => rsqrt_5
# Graph fragment:
#   %arg0_1 : Tensor "i64[1, 128][128, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %arg1_1 : Tensor "bf16[248320, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %mm_4 : Tensor "bf16[128, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_4]
#   %mm_7 : Tensor "bf16[128, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_7]
#   %buf52 : Tensor "f32[1, 128, 1][128, 1, 128]tnca:0" = PlaceHolder[target=buf52]
#   %arg18_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg18_1]
#   %embedding : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg1_1, %arg0_1), kwargs = {})
#   %view_58 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_4, [1, 128, 2048]), kwargs = {})
#   %add_15 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_58), kwargs = {})
#   %view_64 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_7, [1, 128, 2048]), kwargs = {})
#   %add_19 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_15, %view_64), kwargs = {})
#   %convert_element_type_43 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_19, torch.float32), kwargs = {})
#   %pow_4 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_43, 2), kwargs = {})
#   %mean_3 : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_4, [-1], True), kwargs = {})
#   %add_20 : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_3, 1e-06), kwargs = {})
#   %rsqrt_5 : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_20,), kwargs = {})
#   %mul_30 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_43, %rsqrt_5), kwargs = {})
#   %convert_element_type_44 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg18_1, torch.float32), kwargs = {})
#   %add_21 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_44, 1.0), kwargs = {})
#   %mul_31 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_30, %add_21), kwargs = {})
#   %convert_element_type_45 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=4] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_31, torch.bfloat16), kwargs = {})
#   return %buf52,%convert_element_type_45
triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_28 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_28', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 128, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_28', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 1024, 'r0_': 2101248}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_28(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 128
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), None, eviction_policy='evict_last')
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr2, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr3, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp10 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp5 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp0) & (tmp0 < 248320), "index out of bounds: 0 <= tmp0 < 248320")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 2048*tmp0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tmp7 * tmp7
        tmp9 = tl.broadcast_to(tmp8, [R0_BLOCK])
        tmp11 = _tmp10 + tmp9
        _tmp10 = tl.where(r0_mask, tmp11, _tmp10)
    tmp10 = triton_helpers.promote_to_tensor(tl.sum(_tmp10, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr2, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr3, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp14 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp16 = tl.reshape(tma_descriptor3.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp25 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp0) & (tmp0 < 248320), "index out of bounds: 0 <= tmp0 < 248320")
        tmp13 = tl.load(in_ptr1 + (r0_1 + 2048*tmp0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp15 = tmp13 + tmp14
        tmp17 = tmp15 + tmp16
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tl.full([1], 2048.0, tl.float32)
        tmp20 = (tmp10 / tmp19)
        tmp21 = tl.full([1], 1e-06, tl.float32)
        tmp22 = tmp20 + tmp21
        tmp23 = libdevice.rsqrt(tmp22)
        tmp24 = tmp18 * tmp23
        tmp26 = tmp25.to(tl.float32)
        tmp27 = tl.full([1], 1.0, tl.float32)
        tmp28 = tmp26 + tmp27
        tmp29 = tmp24 * tmp28
        tmp30 = tmp29.to(tl.float32)
        tl.store(out_ptr1 + (r0_1 + 2048*x0), tmp30, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/el/cel4tjblo67wlwztmzdrri6yhgzyizhcc5rfxif7fuheilly5jdy.py
# Topologically Sorted Source Nodes: [inputs_embeds, output_2, hidden_states_5, down_proj, hidden_states_7, output_7, hidden_states_13, float_12, pow_6, mean_5, add_25, rsqrt_9, output_8, float_13, add_26, output_9, hidden_states_14], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_25 => add_36
#   add_26 => add_37
#   down_proj => view_64
#   float_12 => convert_element_type_71
#   float_13 => convert_element_type_72
#   hidden_states_13 => add_35
#   hidden_states_14 => convert_element_type_73
#   hidden_states_5 => add_15
#   hidden_states_7 => add_19
#   inputs_embeds => embedding
#   mean_5 => mean_5
#   output_2 => view_58
#   output_7 => view_121
#   output_8 => mul_54
#   output_9 => mul_55
#   pow_6 => pow_6
#   rsqrt_9 => rsqrt_9
# Graph fragment:
#   %arg0_1 : Tensor "i64[1, 128][128, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %arg1_1 : Tensor "bf16[248320, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %mm_4 : Tensor "bf16[128, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_4]
#   %mm_7 : Tensor "bf16[128, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_7]
#   %mm_12 : Tensor "bf16[128, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_12]
#   %add_35 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0" = PlaceHolder[target=add_35]
#   %buf99 : Tensor "f32[1, 128, 1][128, 1, 128]tnca:0" = PlaceHolder[target=buf99]
#   %arg28_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg28_1]
#   %embedding : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg1_1, %arg0_1), kwargs = {})
#   %view_58 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_4, [1, 128, 2048]), kwargs = {})
#   %add_15 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_58), kwargs = {})
#   %view_64 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_7, [1, 128, 2048]), kwargs = {})
#   %add_19 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_15, %view_64), kwargs = {})
#   %view_121 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_12, [1, 128, 2048]), kwargs = {})
#   %add_35 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_19, %view_121), kwargs = {})
#   %convert_element_type_71 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_35, torch.float32), kwargs = {})
#   %pow_6 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_71, 2), kwargs = {})
#   %mean_5 : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_6, [-1], True), kwargs = {})
#   %add_36 : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_5, 1e-06), kwargs = {})
#   %rsqrt_9 : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_36,), kwargs = {})
#   %mul_54 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_71, %rsqrt_9), kwargs = {})
#   %convert_element_type_72 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg28_1, torch.float32), kwargs = {})
#   %add_37 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_72, 1.0), kwargs = {})
#   %mul_55 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_54, %add_37), kwargs = {})
#   %convert_element_type_73 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_55, torch.bfloat16), kwargs = {})
#   return %add_35,%buf99,%convert_element_type_73
triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_29 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_29', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 128, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*bf16', 'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_29', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 6, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 1024, 'r0_': 3674112}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_29(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 128
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), None, eviction_policy='evict_last')
    tma_descriptor0 = tl.make_tensor_descriptor(in_out_ptr0, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr2, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr3, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp12 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp5 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp7 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp0) & (tmp0 < 248320), "index out of bounds: 0 <= tmp0 < 248320")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 2048*tmp0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp8 = tmp6 + tmp7
        tmp9 = tmp8.to(tl.float32)
        tmp10 = tmp9 * tmp9
        tmp11 = tl.broadcast_to(tmp10, [R0_BLOCK])
        tmp13 = _tmp12 + tmp11
        _tmp12 = tl.where(r0_mask, tmp13, _tmp12)
        tl.store(in_out_ptr0 + (r0_1 + 2048*x0), tmp8, r0_mask)
    tmp12 = triton_helpers.promote_to_tensor(tl.sum(_tmp12, 0))
    tma_descriptor3 = tl.make_tensor_descriptor(in_out_ptr0, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tl.debug_barrier()
        tmp14 = tl.reshape(tma_descriptor3.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp22 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp15 = tmp14.to(tl.float32)
        tmp16 = tl.full([1], 2048.0, tl.float32)
        tmp17 = (tmp12 / tmp16)
        tmp18 = tl.full([1], 1e-06, tl.float32)
        tmp19 = tmp17 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp15 * tmp20
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tl.full([1], 1.0, tl.float32)
        tmp25 = tmp23 + tmp24
        tmp26 = tmp21 * tmp25
        tmp27 = tmp26.to(tl.float32)
        tl.store(out_ptr1 + (r0_1 + 2048*x0), tmp27, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/vx/cvxelbivketa6flt5av24vcpy7zviofq7lugbgs7m3cvjuhkgenu.py
# Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, float_14, pow_7, mean_6, add_28, rsqrt_10, output_10, float_15, add_29, output_11, hidden_states_16], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_28 => add_40
#   add_29 => add_41
#   down_proj_1 => view_127
#   float_14 => convert_element_type_82
#   float_15 => convert_element_type_83
#   hidden_states_15 => add_39
#   hidden_states_16 => convert_element_type_84
#   mean_6 => mean_6
#   output_10 => mul_57
#   output_11 => mul_58
#   pow_7 => pow_7
#   rsqrt_10 => rsqrt_10
# Graph fragment:
#   %add_35 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0" = PlaceHolder[target=add_35]
#   %mm_15 : Tensor "bf16[128, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_15]
#   %buf105 : Tensor "f32[1, 128, 1][128, 1, 128]tnca:0" = PlaceHolder[target=buf105]
#   %arg32_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg32_1]
#   %view_127 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_15, [1, 128, 2048]), kwargs = {})
#   %add_39 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_35, %view_127), kwargs = {})
#   %convert_element_type_82 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_39, torch.float32), kwargs = {})
#   %pow_7 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_82, 2), kwargs = {})
#   %mean_6 : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_7, [-1], True), kwargs = {})
#   %add_40 : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_6, 1e-06), kwargs = {})
#   %rsqrt_10 : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_40,), kwargs = {})
#   %mul_57 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_82, %rsqrt_10), kwargs = {})
#   %convert_element_type_83 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg32_1, torch.float32), kwargs = {})
#   %add_41 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_83, 1.0), kwargs = {})
#   %mul_58 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_57, %add_41), kwargs = {})
#   %convert_element_type_84 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=4] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_58, torch.bfloat16), kwargs = {})
#   return %buf105,%convert_element_type_84
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_30 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_30', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 128, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_30', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 2101248}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_30(in_ptr0, in_ptr1, in_ptr2, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 128
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp6 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp3 * tmp3
        tmp5 = tl.broadcast_to(tmp4, [R0_BLOCK])
        tmp7 = _tmp6 + tmp5
        _tmp6 = tl.where(r0_mask, tmp7, _tmp6)
    tmp6 = triton_helpers.promote_to_tensor(tl.sum(_tmp6, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr0, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr1, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp8 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp9 = tl.reshape(tma_descriptor3.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp18 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp10 = tmp8 + tmp9
        tmp11 = tmp10.to(tl.float32)
        tmp12 = tl.full([1], 2048.0, tl.float32)
        tmp13 = (tmp6 / tmp12)
        tmp14 = tl.full([1], 1e-06, tl.float32)
        tmp15 = tmp13 + tmp14
        tmp16 = libdevice.rsqrt(tmp15)
        tmp17 = tmp11 * tmp16
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tl.full([1], 1.0, tl.float32)
        tmp21 = tmp19 + tmp20
        tmp22 = tmp17 * tmp21
        tmp23 = tmp22.to(tl.float32)
        tl.store(out_ptr1 + (r0_1 + 2048*x0), tmp23, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/jz/cjzi4jag6fmgh5vf77zpr2eqg2yhewedmmoukklcq4a4rz4aq3ea.py
# Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, output_12, hidden_states_21, float_18, pow_9, mean_8, add_39, rsqrt_14, output_13, float_19, add_40, output_14, hidden_states_22], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_39 => add_56
#   add_40 => add_57
#   down_proj_1 => view_127
#   float_18 => convert_element_type_110
#   float_19 => convert_element_type_111
#   hidden_states_15 => add_39
#   hidden_states_21 => add_55
#   hidden_states_22 => convert_element_type_112
#   mean_8 => mean_8
#   output_12 => view_184
#   output_13 => mul_81
#   output_14 => mul_82
#   pow_9 => pow_9
#   rsqrt_14 => rsqrt_14
# Graph fragment:
#   %add_35 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0" = PlaceHolder[target=add_35]
#   %mm_15 : Tensor "bf16[128, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_15]
#   %mm_20 : Tensor "bf16[128, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_20]
#   %buf151 : Tensor "f32[1, 128, 1][128, 1, 128]tnca:0" = PlaceHolder[target=buf151]
#   %arg42_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg42_1]
#   %view_127 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_15, [1, 128, 2048]), kwargs = {})
#   %add_39 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_35, %view_127), kwargs = {})
#   %view_184 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_20, [1, 128, 2048]), kwargs = {})
#   %add_55 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_39, %view_184), kwargs = {})
#   %convert_element_type_110 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_55, torch.float32), kwargs = {})
#   %pow_9 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_110, 2), kwargs = {})
#   %mean_8 : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_9, [-1], True), kwargs = {})
#   %add_56 : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_8, 1e-06), kwargs = {})
#   %rsqrt_14 : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_56,), kwargs = {})
#   %mul_81 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_110, %rsqrt_14), kwargs = {})
#   %convert_element_type_111 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg42_1, torch.float32), kwargs = {})
#   %add_57 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_111, 1.0), kwargs = {})
#   %mul_82 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_81, %add_57), kwargs = {})
#   %convert_element_type_112 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_82, torch.bfloat16), kwargs = {})
#   return %buf151,%convert_element_type_112
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_31 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_31', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 128, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_31', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 2625536}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_31(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 128
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr2, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp8 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp3 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tmp5 * tmp5
        tmp7 = tl.broadcast_to(tmp6, [R0_BLOCK])
        tmp9 = _tmp8 + tmp7
        _tmp8 = tl.where(r0_mask, tmp9, _tmp8)
    tmp8 = triton_helpers.promote_to_tensor(tl.sum(_tmp8, 0))
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr0, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor4 = tl.make_tensor_descriptor(in_ptr1, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor5 = tl.make_tensor_descriptor(in_ptr2, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp10 = tl.reshape(tma_descriptor3.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp11 = tl.reshape(tma_descriptor4.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp13 = tl.reshape(tma_descriptor5.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp22 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp12 = tmp10 + tmp11
        tmp14 = tmp12 + tmp13
        tmp15 = tmp14.to(tl.float32)
        tmp16 = tl.full([1], 2048.0, tl.float32)
        tmp17 = (tmp8 / tmp16)
        tmp18 = tl.full([1], 1e-06, tl.float32)
        tmp19 = tmp17 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp15 * tmp20
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tl.full([1], 1.0, tl.float32)
        tmp25 = tmp23 + tmp24
        tmp26 = tmp21 * tmp25
        tmp27 = tmp26.to(tl.float32)
        tl.store(out_ptr1 + (r0_1 + 2048*x0), tmp27, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/gm/cgmc75mksv2unfibp3ulvyhpv63s7ry7olygyuu3cptvsimuxb7e.py
# Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, output_12, hidden_states_21, down_proj_2, hidden_states_23, float_20, pow_10, mean_9, add_42, rsqrt_15, output_15, float_21, add_43, output_16, hidden_states_24], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_42 => add_60
#   add_43 => add_61
#   down_proj_1 => view_127
#   down_proj_2 => view_190
#   float_20 => convert_element_type_121
#   float_21 => convert_element_type_122
#   hidden_states_15 => add_39
#   hidden_states_21 => add_55
#   hidden_states_23 => add_59
#   hidden_states_24 => convert_element_type_123
#   mean_9 => mean_9
#   output_12 => view_184
#   output_15 => mul_84
#   output_16 => mul_85
#   pow_10 => pow_10
#   rsqrt_15 => rsqrt_15
# Graph fragment:
#   %add_35 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0" = PlaceHolder[target=add_35]
#   %mm_15 : Tensor "bf16[128, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_15]
#   %mm_20 : Tensor "bf16[128, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_20]
#   %mm_23 : Tensor "bf16[128, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_23]
#   %buf157 : Tensor "f32[1, 128, 1][128, 1, 128]tnca:0" = PlaceHolder[target=buf157]
#   %arg46_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg46_1]
#   %view_127 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_15, [1, 128, 2048]), kwargs = {})
#   %add_39 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_35, %view_127), kwargs = {})
#   %view_184 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_20, [1, 128, 2048]), kwargs = {})
#   %add_55 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_39, %view_184), kwargs = {})
#   %view_190 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_23, [1, 128, 2048]), kwargs = {})
#   %add_59 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_55, %view_190), kwargs = {})
#   %convert_element_type_121 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_59, torch.float32), kwargs = {})
#   %pow_10 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_121, 2), kwargs = {})
#   %mean_9 : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_10, [-1], True), kwargs = {})
#   %add_60 : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_9, 1e-06), kwargs = {})
#   %rsqrt_15 : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_60,), kwargs = {})
#   %mul_84 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_121, %rsqrt_15), kwargs = {})
#   %convert_element_type_122 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg46_1, torch.float32), kwargs = {})
#   %add_61 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_122, 1.0), kwargs = {})
#   %mul_85 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_84, %add_61), kwargs = {})
#   %convert_element_type_123 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_85, torch.bfloat16), kwargs = {})
#   return %buf157,%convert_element_type_123
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_32 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_32', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 128, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_32', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 9, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 3149824}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_32(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 128
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr2, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr3, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp10 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp3 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp5 = tl.reshape(tma_descriptor3.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tmp7 * tmp7
        tmp9 = tl.broadcast_to(tmp8, [R0_BLOCK])
        tmp11 = _tmp10 + tmp9
        _tmp10 = tl.where(r0_mask, tmp11, _tmp10)
    tmp10 = triton_helpers.promote_to_tensor(tl.sum(_tmp10, 0))
    tma_descriptor4 = tl.make_tensor_descriptor(in_ptr0, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor5 = tl.make_tensor_descriptor(in_ptr1, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor6 = tl.make_tensor_descriptor(in_ptr2, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor7 = tl.make_tensor_descriptor(in_ptr3, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp12 = tl.reshape(tma_descriptor4.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp13 = tl.reshape(tma_descriptor5.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp15 = tl.reshape(tma_descriptor6.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp17 = tl.reshape(tma_descriptor7.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp26 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp14 = tmp12 + tmp13
        tmp16 = tmp14 + tmp15
        tmp18 = tmp16 + tmp17
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tl.full([1], 2048.0, tl.float32)
        tmp21 = (tmp10 / tmp20)
        tmp22 = tl.full([1], 1e-06, tl.float32)
        tmp23 = tmp21 + tmp22
        tmp24 = libdevice.rsqrt(tmp23)
        tmp25 = tmp19 * tmp24
        tmp27 = tmp26.to(tl.float32)
        tmp28 = tl.full([1], 1.0, tl.float32)
        tmp29 = tmp27 + tmp28
        tmp30 = tmp25 * tmp29
        tmp31 = tmp30.to(tl.float32)
        tl.store(out_ptr1 + (r0_1 + 2048*x0), tmp31, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/36/c36egfbmg2nmeoqtwgyjgmhyte5dsgcgphsd6xwjek4qk47erdj4.py
# Topologically Sorted Source Nodes: [linear_24], Original ATen: [aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_24 => mm_24, permute_63, view_191
# Graph fragment:
#   %convert_element_type_123 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0" = PlaceHolder[target=convert_element_type_123]
#   %arg47_1 : Tensor "bf16[4096, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg47_1]
#   %view_191 : Tensor "bf16[128, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_123, [128, 2048]), kwargs = {})
#   %permute_63 : Tensor "bf16[2048, 4096][1, 2048]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg47_1, [1, 0]), kwargs = {})
#   %mm_24 : Tensor "bf16[128, 4096][4096, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_191, %permute_63), kwargs = {})
#   return %mm_24
triton_tem_fused_mm_t_view_33 = async_compile.triton('triton_tem_fused_mm_t_view_33', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*bf16', 'arg_B': '*bf16', 'out_ptr0': '*bf16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_mm_t_view_33', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_mm_t_view_33(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 128
    N = 4096
    K = 2048
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 2048
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2048

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2048*idx_m
        a = tl.load(A + (xindex))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 4096*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2048*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 4096*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/h3/ch3ricrak6r5gvzzer44y442oqzs7aibgnqhpisv5thyqfhnrbbg.py
# Topologically Sorted Source Nodes: [linear_24, view, chunk, float_22, pow_11, mean_10], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean]
# Source node to ATen node mapping:
#   chunk => split
#   float_22 => convert_element_type_126
#   linear_24 => view_192
#   mean_10 => mean_10
#   pow_11 => pow_11
#   view => view_193
# Graph fragment:
#   %mm_24 : Tensor "bf16[128, 4096][4096, 1]tnca:0" = PlaceHolder[target=mm_24]
#   %view_192 : Tensor "bf16[1, 128, 4096][524288, 4096, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_24, [1, 128, 4096]), kwargs = {})
#   %view_193 : Tensor "bf16[1, 128, 8, 512][524288, 4096, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_192, [1, 128, -1, 512]), kwargs = {})
#   %split : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_193, 256, -1), kwargs = {})
#   %convert_element_type_126 : Tensor "f32[1, 128, 8, 256][262144, 2048, 256, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%getitem_9, torch.float32), kwargs = {})
#   %pow_11 : Tensor "f32[1, 128, 8, 256][262144, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_126, 2), kwargs = {})
#   %mean_10 : Tensor "f32[1, 128, 8, 1][1024, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_11, [-1], True), kwargs = {})
#   return %buf160
triton_red_fused__to_copy__unsafe_view_mean_pow_split_view_34 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_mean_pow_split_view_34', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1024, 'r0_': 256},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_mean_pow_split_view_34', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 8192, 'r0_': 524288}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_mean_pow_split_view_34(in_ptr0, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1024
    XBLOCK: tl.constexpr = 1
    r0_numel = 256
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[1024, 256], strides=[512, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp4 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp2 = tmp1 * tmp1
        tmp3 = tl.broadcast_to(tmp2, [R0_BLOCK])
        tmp5 = _tmp4 + tmp3
        _tmp4 = tl.where(r0_mask, tmp5, _tmp4)
    tmp4 = triton_helpers.promote_to_tensor(tl.sum(_tmp4, 0))
    tl.store(out_ptr0 + (x0), tmp4, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/2q/c2qaanfxxhtpehxwp6gyh7pcykj4tlef5kggihojlkmfjwnonjjo.py
# Topologically Sorted Source Nodes: [getitem_1, position_ids, position_ids_1, position_ids_2, getitem_4, float_1, to, freqs, sin_1, getitem_6, cos_1, getitem_9, setitem_3, setitem_1], Original ATen: [aten.unsqueeze, aten.expand, aten.slice, aten._to_copy, aten.mul, aten.select]
# Source node to ATen node mapping:
#   cos_1 => cos
#   float_1 => convert_element_type
#   freqs => mul
#   getitem_1 => unsqueeze_4
#   getitem_4 => unsqueeze_5
#   getitem_6 => select_1, slice_2
#   getitem_9 => select_13, slice_10
#   position_ids => expand
#   position_ids_1 => slice_1
#   position_ids_2 => expand_1
#   setitem_1 => select_8, slice_8
#   setitem_3 => select_20, slice_16
#   sin_1 => sin
#   to => convert_element_type_1
# Graph fragment:
#   %arg2_1 : Tensor "i64[1, 128][128, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %arg3_1 : Tensor "bf16[32][1]tnca:0" = PlaceHolder[target=arg3_1]
#   %unsqueeze_4 : Tensor "i64[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg2_1, 0), kwargs = {})
#   %expand : Tensor "i64[4, 1, 128][0, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_4, [4, 1, -1]), kwargs = {})
#   %slice_1 : Tensor "i64[3, 1, 128][0, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%expand, 0, 1, 9223372036854775807), kwargs = {})
#   %expand_1 : Tensor "i64[3, 1, 128][0, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%slice_1, [3, -1, -1]), kwargs = {})
#   %unsqueeze_5 : Tensor "i64[3, 1, 128, 1][0, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%expand_1, 3), kwargs = {})
#   %convert_element_type : Tensor "f32[3, 1, 128, 1][128, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_5, torch.float32), kwargs = {})
#   %convert_element_type_1 : Tensor "f32[32][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg3_1, torch.float32), kwargs = {})
#   %mul : Tensor "f32[3, 1, 128, 32][4096, 4096, 32, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, %convert_element_type_1), kwargs = {})
#   %sin : Tensor "f32[3, 1, 128, 32][4096, 4096, 32, 1]tnca:0"[num_users=5] = call_function[target=torch.ops.aten.sin.default](args = (%mul,), kwargs = {})
#   %select_1 : Tensor "f32[1, 128, 32][4096, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%sin, 0, 1), kwargs = {})
#   %slice_2 : Tensor "f32[1, 128, 11][4096, 32, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_1, 2, 1, 33, 3), kwargs = {})
#   %select_int : Tensor "f32[1, 128, 32][4096, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%sin, 0, 0), kwargs = {})
#   %slice_scatter_default : Tensor "f32[1, 128, 32][4096, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int, %slice_2, 2, 1, 33, 3), kwargs = {})
#   %select_scatter_default : Tensor "f32[3, 1, 128, 32][4096, 4096, 32, 1]tnca:0"[num_users=5] = call_function[target=torch.ops.aten.select_scatter.default](args = (%sin, %slice_scatter_default, 0, 0), kwargs = {})
#   %cos : Tensor "f32[3, 1, 128, 32][4096, 4096, 32, 1]tnca:0"[num_users=5] = call_function[target=torch.ops.aten.cos.default](args = (%mul,), kwargs = {})
#   %select_13 : Tensor "f32[1, 128, 32][4096, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%cos, 0, 1), kwargs = {})
#   %slice_10 : Tensor "f32[1, 128, 11][4096, 32, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_13, 2, 1, 33, 3), kwargs = {})
#   %select_int_1 : Tensor "f32[1, 128, 32][4096, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%cos, 0, 0), kwargs = {})
#   %slice_scatter_default_1 : Tensor "f32[1, 128, 32][4096, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_1, %slice_10, 2, 1, 33, 3), kwargs = {})
#   %select_scatter_default_1 : Tensor "f32[3, 1, 128, 32][4096, 4096, 32, 1]tnca:0"[num_users=5] = call_function[target=torch.ops.aten.select_scatter.default](args = (%cos, %slice_scatter_default_1, 0, 0), kwargs = {})
#   %select_20 : Tensor "f32[1, 128, 32][4096, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 2), kwargs = {})
#   %slice_16 : Tensor "f32[1, 128, 10][4096, 32, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_20, 2, 2, 30, 3), kwargs = {})
#   %select_int_2 : Tensor "f32[1, 128, 32][4096, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 0), kwargs = {})
#   %slice_scatter_default_2 : Tensor "f32[1, 128, 32][4096, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_2, %slice_16, 2, 2, 30, 3), kwargs = {})
#   %select_scatter_default_8 : Tensor "f32[3, 1, 128, 32][4096, 4096, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default_1, %slice_scatter_default_2, 0, 0), kwargs = {})
#   %select_8 : Tensor "f32[1, 128, 32][4096, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 2), kwargs = {})
#   %slice_8 : Tensor "f32[1, 128, 10][4096, 32, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_8, 2, 2, 30, 3), kwargs = {})
#   %select_int_3 : Tensor "f32[1, 128, 32][4096, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 0), kwargs = {})
#   %slice_scatter_default_3 : Tensor "f32[1, 128, 32][4096, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_3, %slice_8, 2, 2, 30, 3), kwargs = {})
#   %select_scatter_default_9 : Tensor "f32[3, 1, 128, 32][4096, 4096, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default, %slice_scatter_default_3, 0, 0), kwargs = {})
#   return %select_scatter_default_8,%select_scatter_default_9
triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_35 = async_compile.triton('triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_35', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 16384}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_35', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 197824}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_35(in_ptr0, in_ptr1, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 12288
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x2 = xindex // 4096
    x0 = (xindex % 32)
    x1 = ((xindex // 32) % 128)
    x4 = xindex
    tmp59 = tl.load(in_ptr0 + (x1), None, eviction_policy='evict_last')
    tmp61 = tl.load(in_ptr1 + (x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp0 = (x2).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int32)
    tmp2 = tmp0 == tmp1
    tmp3 = (x0).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1], 2, tl.int64)
    tmp6 = tmp4 >= tmp5
    tmp7 = tl.full([1], 30, tl.int64)
    tmp8 = tmp4 < tmp7
    tmp9 = ((((-2) + x0) % 3)).to(tl.int64)
    tmp10 = (tmp9).to(tl.int64)
    tmp11 = tl.full([1], 0, tl.int64)
    tmp12 = tmp10 == tmp11
    tmp13 = tmp6 & tmp8
    tmp14 = tmp13 & tmp12
    tmp15 = tl.full([1], 2, tl.int32)
    tmp16 = tl.full([1], 0, tl.int32)
    tmp17 = tmp15 == tmp16
    tmp18 = (2 + 3*(triton_helpers.div_floor_integer((-2) + x0,  3))).to(tl.int64)
    tmp19 = (tmp18).to(tl.int64)
    tmp20 = tl.full([1], 1, tl.int64)
    tmp21 = tmp19 >= tmp20
    tmp22 = tl.full([1], 0, tl.int64)
    tmp23 = tmp20 == tmp22
    tmp24 = tmp21 & tmp23
    tmp25 = tmp24 & tmp14
    tmp26 = tl.load(in_ptr0 + (x1), tmp25, eviction_policy='evict_last', other=0.0)
    tmp27 = tmp26.to(tl.float32)
    tmp28 = tl.load(in_ptr1 + (1 + 3*(triton_helpers.div_floor_integer((-2) + x0,  3))), tmp25, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp29 = tmp28.to(tl.float32)
    tmp30 = tmp27 * tmp29
    tmp31 = tl_math.cos(tmp30)
    tmp32 = tl.full(tmp31.shape, 0.0, tmp31.dtype)
    tmp33 = tl.where(tmp25, tmp31, tmp32)
    tmp34 = tl.load(in_ptr0 + (x1), tmp14, eviction_policy='evict_last', other=0.0)
    tmp35 = tmp34.to(tl.float32)
    tmp36 = tl.load(in_ptr1 + (2 + 3*(triton_helpers.div_floor_integer((-2) + x0,  3))), tmp14, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp37 = tmp36.to(tl.float32)
    tmp38 = tmp35 * tmp37
    tmp39 = tl_math.cos(tmp38)
    tmp40 = tl.where(tmp24, tmp33, tmp39)
    tmp41 = tl.where(tmp17, tmp40, tmp39)
    tmp42 = tl.full(tmp41.shape, 0.0, tmp41.dtype)
    tmp43 = tl.where(tmp14, tmp41, tmp42)
    tmp44 = tmp1 == tmp1
    tmp45 = tl.full([1], 1, tl.int64)
    tmp46 = tmp4 >= tmp45
    tmp47 = ((((-1) + x0) % 3)).to(tl.int64)
    tmp48 = (tmp47).to(tl.int64)
    tmp49 = tmp48 == tmp11
    tmp50 = tmp46 & tmp49
    tmp51 = tl.load(in_ptr0 + (x1), tmp50, eviction_policy='evict_last', other=0.0)
    tmp52 = tmp51.to(tl.float32)
    tmp53 = tl.load(in_ptr1 + (1 + 3*(triton_helpers.div_floor_integer((-1) + x0,  3))), tmp50, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp54 = tmp53.to(tl.float32)
    tmp55 = tmp52 * tmp54
    tmp56 = tl_math.cos(tmp55)
    tmp57 = tl.full(tmp56.shape, 0.0, tmp56.dtype)
    tmp58 = tl.where(tmp50, tmp56, tmp57)
    tmp60 = tmp59.to(tl.float32)
    tmp62 = tmp61.to(tl.float32)
    tmp63 = tmp60 * tmp62
    tmp64 = tl_math.cos(tmp63)
    tmp65 = tl.where(tmp50, tmp58, tmp64)
    tmp66 = tl.where(tmp44, tmp65, tmp64)
    tmp67 = tl.where(tmp14, tmp43, tmp66)
    tmp68 = tl.where(tmp2, tmp65, tmp64)
    tmp69 = tl.where(tmp2, tmp67, tmp68)
    tmp70 = tl_math.sin(tmp30)
    tmp71 = tl.full(tmp70.shape, 0.0, tmp70.dtype)
    tmp72 = tl.where(tmp25, tmp70, tmp71)
    tmp73 = tl_math.sin(tmp38)
    tmp74 = tl.where(tmp24, tmp72, tmp73)
    tmp75 = tl.where(tmp17, tmp74, tmp73)
    tmp76 = tl.full(tmp75.shape, 0.0, tmp75.dtype)
    tmp77 = tl.where(tmp14, tmp75, tmp76)
    tmp78 = tl_math.sin(tmp55)
    tmp79 = tl.full(tmp78.shape, 0.0, tmp78.dtype)
    tmp80 = tl.where(tmp50, tmp78, tmp79)
    tmp81 = tl_math.sin(tmp63)
    tmp82 = tl.where(tmp50, tmp80, tmp81)
    tmp83 = tl.where(tmp44, tmp82, tmp81)
    tmp84 = tl.where(tmp14, tmp77, tmp83)
    tmp85 = tl.where(tmp2, tmp82, tmp81)
    tmp86 = tl.where(tmp2, tmp84, tmp85)
    tl.store(out_ptr0 + (x4), tmp69, None)
    tl.store(out_ptr1 + (x4), tmp86, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/ai/caif23fg74v335ftq7lpzaheovsufpccjo5u2wkpnyyqx63fijqi.py
# Topologically Sorted Source Nodes: [linear_24, view, chunk, float_22, pow_11, mean_10, add_44, rsqrt_16, output_17, float_23, add_45, output_18, type_as_7, query_states_1, q_rot, x2, neg_3, x1, cat_2], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
# Source node to ATen node mapping:
#   add_44 => add_62
#   add_45 => add_63
#   cat_2 => cat
#   chunk => split
#   float_22 => convert_element_type_126
#   float_23 => convert_element_type_127
#   linear_24 => view_192
#   mean_10 => mean_10
#   neg_3 => neg_12
#   output_17 => mul_86
#   output_18 => mul_87
#   pow_11 => pow_11
#   q_rot => slice_36
#   query_states_1 => permute_64
#   rsqrt_16 => rsqrt_16
#   type_as_7 => convert_element_type_128
#   view => view_193
#   x1 => slice_40
#   x2 => slice_41
# Graph fragment:
#   %mm_24 : Tensor "bf16[128, 4096][4096, 1]tnca:0" = PlaceHolder[target=mm_24]
#   %buf160 : Tensor "f32[1, 128, 8, 1][1024, 8, 1, 1024]tnca:0" = PlaceHolder[target=buf160]
#   %arg48_1 : Tensor "bf16[256][1]tnca:0" = PlaceHolder[target=arg48_1]
#   %view_192 : Tensor "bf16[1, 128, 4096][524288, 4096, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_24, [1, 128, 4096]), kwargs = {})
#   %view_193 : Tensor "bf16[1, 128, 8, 512][524288, 4096, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_192, [1, 128, -1, 512]), kwargs = {})
#   %split : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_193, 256, -1), kwargs = {})
#   %convert_element_type_126 : Tensor "f32[1, 128, 8, 256][262144, 2048, 256, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%getitem_9, torch.float32), kwargs = {})
#   %pow_11 : Tensor "f32[1, 128, 8, 256][262144, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_126, 2), kwargs = {})
#   %mean_10 : Tensor "f32[1, 128, 8, 1][1024, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_11, [-1], True), kwargs = {})
#   %add_62 : Tensor "f32[1, 128, 8, 1][1024, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_10, 1e-06), kwargs = {})
#   %rsqrt_16 : Tensor "f32[1, 128, 8, 1][1024, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_62,), kwargs = {})
#   %mul_86 : Tensor "f32[1, 128, 8, 256][262144, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_126, %rsqrt_16), kwargs = {})
#   %convert_element_type_127 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg48_1, torch.float32), kwargs = {})
#   %add_63 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_127, 1.0), kwargs = {})
#   %mul_87 : Tensor "f32[1, 128, 8, 256][262144, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_86, %add_63), kwargs = {})
#   %convert_element_type_128 : Tensor "bf16[1, 128, 8, 256][262144, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_87, torch.bfloat16), kwargs = {})
#   %permute_64 : Tensor "bf16[1, 8, 128, 256][262144, 256, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_128, [0, 2, 1, 3]), kwargs = {})
#   %slice_36 : Tensor "bf16[1, 8, 128, 64][262144, 256, 2048, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_64, 3, 0, 64), kwargs = {})
#   %slice_41 : Tensor "bf16[1, 8, 128, 32][262144, 256, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_36, 3, 32, 9223372036854775807), kwargs = {})
#   %neg_12 : Tensor "bf16[1, 8, 128, 32][32768, 32, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_41,), kwargs = {})
#   %slice_40 : Tensor "bf16[1, 8, 128, 32][262144, 256, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_36, 3, 0, 32), kwargs = {})
#   %cat : Tensor "bf16[1, 8, 128, 64][65536, 8192, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg_12, %slice_40], -1), kwargs = {})
#   return %neg_12,%buf163
triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_36 = async_compile.triton('triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_36', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 32768}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'out_ptr0': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_36', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 397440}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_36(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 32768
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 32)
    x3 = xindex // 32
    x1 = ((xindex // 32) % 8)
    x2 = xindex // 256
    tmp0 = tl.load(in_ptr0 + (32 + x0 + 512*x3), None).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (x3), None, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr2 + (32 + x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp16 = tl.load(in_ptr0 + (x0 + 512*x3), None).to(tl.float32)
    tmp19 = tl.load(in_ptr2 + (x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tl.full([1], 256.0, tl.float32)
    tmp4 = (tmp2 / tmp3)
    tmp5 = tl.full([1], 1e-06, tl.float32)
    tmp6 = tmp4 + tmp5
    tmp7 = libdevice.rsqrt(tmp6)
    tmp8 = tmp1 * tmp7
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tl.full([1], 1.0, tl.float32)
    tmp12 = tmp10 + tmp11
    tmp13 = tmp8 * tmp12
    tmp14 = tmp13.to(tl.float32)
    tmp15 = -tmp14
    tmp17 = tmp16.to(tl.float32)
    tmp18 = tmp17 * tmp7
    tmp20 = tmp19.to(tl.float32)
    tmp21 = tmp20 + tmp11
    tmp22 = tmp18 * tmp21
    tmp23 = tmp22.to(tl.float32)
    tl.store(out_ptr0 + (x0 + 64*x2 + 8192*x1), tmp15, None)
    tl.store(out_ptr1 + (x0 + 64*x2 + 8192*x1), tmp23, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/qx/cqxi7j4vjurshxoe6zvxwgxe7wkqwgb7wy6gotde5ns5pwdjsegs.py
# Topologically Sorted Source Nodes: [linear_24, view, chunk, float_22, pow_11, mean_10, add_44, rsqrt_16, output_17, float_23, add_45, output_18, type_as_7, query_states_1, q_rot, cos_2, cos_3, cos_4, mul_78, sin_2, sin_3, sin_4, mul_79, q_embed], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.select, aten.cat, aten.unsqueeze]
# Source node to ATen node mapping:
#   add_44 => add_62
#   add_45 => add_63
#   chunk => split
#   cos_2 => clone_2, expand_3, select_23, unsqueeze_7, view_1
#   cos_3 => convert_element_type_2
#   cos_4 => unsqueeze_44
#   float_22 => convert_element_type_126
#   float_23 => convert_element_type_127
#   linear_24 => view_192
#   mean_10 => mean_10
#   mul_78 => mul_90
#   mul_79 => mul_91
#   output_17 => mul_86
#   output_18 => mul_87
#   pow_11 => pow_11
#   q_embed => add_66
#   q_rot => slice_36
#   query_states_1 => permute_64
#   rsqrt_16 => rsqrt_16
#   sin_2 => clone, expand_2, select_11, unsqueeze_6, view
#   sin_3 => convert_element_type_3
#   sin_4 => unsqueeze_45
#   type_as_7 => convert_element_type_128
#   view => view_193
# Graph fragment:
#   %mm_24 : Tensor "bf16[128, 4096][4096, 1]tnca:0" = PlaceHolder[target=mm_24]
#   %buf160 : Tensor "f32[1, 128, 8, 1][1024, 8, 1, 1024]tnca:0" = PlaceHolder[target=buf160]
#   %arg48_1 : Tensor "bf16[256][1]tnca:0" = PlaceHolder[target=arg48_1]
#   %select_scatter_default_8 : Tensor "f32[3, 1, 128, 32][4096, 12288, 32, 1]tnca:0" = PlaceHolder[target=select_scatter_default_8]
#   %cat : Tensor "bf16[1, 8, 128, 64][65536, 8192, 64, 1]tnca:0" = PlaceHolder[target=cat]
#   %select_scatter_default_9 : Tensor "f32[3, 1, 128, 32][4096, 12288, 32, 1]tnca:0" = PlaceHolder[target=select_scatter_default_9]
#   %view_192 : Tensor "bf16[1, 128, 4096][524288, 4096, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_24, [1, 128, 4096]), kwargs = {})
#   %view_193 : Tensor "bf16[1, 128, 8, 512][524288, 4096, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_192, [1, 128, -1, 512]), kwargs = {})
#   %split : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_193, 256, -1), kwargs = {})
#   %convert_element_type_126 : Tensor "f32[1, 128, 8, 256][262144, 2048, 256, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%getitem_9, torch.float32), kwargs = {})
#   %pow_11 : Tensor "f32[1, 128, 8, 256][262144, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_126, 2), kwargs = {})
#   %mean_10 : Tensor "f32[1, 128, 8, 1][1024, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_11, [-1], True), kwargs = {})
#   %add_62 : Tensor "f32[1, 128, 8, 1][1024, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_10, 1e-06), kwargs = {})
#   %rsqrt_16 : Tensor "f32[1, 128, 8, 1][1024, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_62,), kwargs = {})
#   %mul_86 : Tensor "f32[1, 128, 8, 256][262144, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_126, %rsqrt_16), kwargs = {})
#   %convert_element_type_127 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg48_1, torch.float32), kwargs = {})
#   %add_63 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_127, 1.0), kwargs = {})
#   %mul_87 : Tensor "f32[1, 128, 8, 256][262144, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_86, %add_63), kwargs = {})
#   %convert_element_type_128 : Tensor "bf16[1, 128, 8, 256][262144, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_87, torch.bfloat16), kwargs = {})
#   %permute_64 : Tensor "bf16[1, 8, 128, 256][262144, 256, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_128, [0, 2, 1, 3]), kwargs = {})
#   %slice_36 : Tensor "bf16[1, 8, 128, 64][262144, 256, 2048, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_64, 3, 0, 64), kwargs = {})
#   %select_23 : Tensor "f32[1, 128, 32][4096, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_8, 0, 0), kwargs = {})
#   %unsqueeze_7 : Tensor "f32[1, 128, 1, 32][4096, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_23, 2), kwargs = {})
#   %expand_3 : Tensor "f32[1, 128, 2, 32][4096, 32, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_7, [1, 128, 2, 32]), kwargs = {})
#   %clone_2 : Tensor "f32[1, 128, 2, 32][8192, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_1 : Tensor "f32[1, 128, 64][8192, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_2, [1, 128, 64]), kwargs = {})
#   %convert_element_type_2 : Tensor "bf16[1, 128, 64][8192, 64, 1]tnca:0"[num_users=6] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_1, torch.bfloat16), kwargs = {})
#   %unsqueeze_44 : Tensor "bf16[1, 1, 128, 64][8192, 8192, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_2, 1), kwargs = {})
#   %mul_90 : Tensor "bf16[1, 8, 128, 64][65536, 64, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_36, %unsqueeze_44), kwargs = {})
#   %select_11 : Tensor "f32[1, 128, 32][4096, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_9, 0, 0), kwargs = {})
#   %unsqueeze_6 : Tensor "f32[1, 128, 1, 32][4096, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_11, 2), kwargs = {})
#   %expand_2 : Tensor "f32[1, 128, 2, 32][4096, 32, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_6, [1, 128, 2, 32]), kwargs = {})
#   %clone : Tensor "f32[1, 128, 2, 32][8192, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_2,), kwargs = {memory_format: torch.contiguous_format})
#   %view : Tensor "f32[1, 128, 64][8192, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 128, 64]), kwargs = {})
#   %convert_element_type_3 : Tensor "bf16[1, 128, 64][8192, 64, 1]tnca:0"[num_users=6] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view, torch.bfloat16), kwargs = {})
#   %unsqueeze_45 : Tensor "bf16[1, 1, 128, 64][8192, 8192, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_3, 1), kwargs = {})
#   %mul_91 : Tensor "bf16[1, 8, 128, 64][65536, 8192, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat, %unsqueeze_45), kwargs = {})
#   %add_66 : Tensor "bf16[1, 8, 128, 64][65536, 64, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_90, %mul_91), kwargs = {})
#   return %add_66
triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_37 = async_compile.triton('triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_37', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 65536}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'in_ptr3': '*fp32', 'in_ptr4': '*bf16', 'in_ptr5': '*fp32', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_37', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 594048}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_37(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 65536
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 64)
    x1 = ((xindex // 64) % 128)
    x2 = xindex // 8192
    x3 = xindex
    x4 = xindex // 64
    tmp0 = tl.load(in_ptr0 + (x0 + 512*x2 + 4096*x1), None).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (x2 + 8*x1), None, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr2 + (x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp15 = tl.load(in_ptr3 + (32*x1 + ((x0 % 32))), None, eviction_policy='evict_last')
    tmp18 = tl.load(in_ptr4 + (x3), None).to(tl.float32)
    tmp19 = tl.load(in_ptr5 + (32*x1 + ((x0 % 32))), None, eviction_policy='evict_last')
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tl.full([1], 256.0, tl.float32)
    tmp4 = (tmp2 / tmp3)
    tmp5 = tl.full([1], 1e-06, tl.float32)
    tmp6 = tmp4 + tmp5
    tmp7 = libdevice.rsqrt(tmp6)
    tmp8 = tmp1 * tmp7
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tl.full([1], 1.0, tl.float32)
    tmp12 = tmp10 + tmp11
    tmp13 = tmp8 * tmp12
    tmp14 = tmp13.to(tl.float32)
    tmp16 = tmp15.to(tl.float32)
    tmp17 = tmp14 * tmp16
    tmp20 = tmp19.to(tl.float32)
    tmp21 = tmp18 * tmp20
    tmp22 = tmp17 + tmp21
    tl.store(out_ptr0 + (x0 + 256*x4), tmp22, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/c4/cc4tddc23x2pbfv6qel5wunix3ab6wzg6oc7afscr2gaoevdke77.py
# Topologically Sorted Source Nodes: [linear_24, view, chunk, float_22, pow_11, mean_10, add_44, rsqrt_16, output_17, float_23, add_45, output_18, type_as_7, query_states_1, q_rot, cos_2, cos_3, cos_4, mul_78, sin_2, sin_3, sin_4, mul_79, q_embed, q_pass, q_embed_1], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.select, aten.cat, aten.unsqueeze]
# Source node to ATen node mapping:
#   add_44 => add_62
#   add_45 => add_63
#   chunk => split
#   cos_2 => clone_2, expand_3, select_23, unsqueeze_7, view_1
#   cos_3 => convert_element_type_2
#   cos_4 => unsqueeze_44
#   float_22 => convert_element_type_126
#   float_23 => convert_element_type_127
#   linear_24 => view_192
#   mean_10 => mean_10
#   mul_78 => mul_90
#   mul_79 => mul_91
#   output_17 => mul_86
#   output_18 => mul_87
#   pow_11 => pow_11
#   q_embed => add_66
#   q_embed_1 => cat_2
#   q_pass => slice_37
#   q_rot => slice_36
#   query_states_1 => permute_64
#   rsqrt_16 => rsqrt_16
#   sin_2 => clone, expand_2, select_11, unsqueeze_6, view
#   sin_3 => convert_element_type_3
#   sin_4 => unsqueeze_45
#   type_as_7 => convert_element_type_128
#   view => view_193
# Graph fragment:
#   %mm_24 : Tensor "bf16[128, 4096][4096, 1]tnca:0" = PlaceHolder[target=mm_24]
#   %buf160 : Tensor "f32[1, 128, 8, 1][1024, 8, 1, 1024]tnca:0" = PlaceHolder[target=buf160]
#   %arg48_1 : Tensor "bf16[256][1]tnca:0" = PlaceHolder[target=arg48_1]
#   %view_192 : Tensor "bf16[1, 128, 4096][524288, 4096, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_24, [1, 128, 4096]), kwargs = {})
#   %view_193 : Tensor "bf16[1, 128, 8, 512][524288, 4096, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_192, [1, 128, -1, 512]), kwargs = {})
#   %split : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_193, 256, -1), kwargs = {})
#   %convert_element_type_126 : Tensor "f32[1, 128, 8, 256][262144, 2048, 256, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%getitem_9, torch.float32), kwargs = {})
#   %pow_11 : Tensor "f32[1, 128, 8, 256][262144, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_126, 2), kwargs = {})
#   %mean_10 : Tensor "f32[1, 128, 8, 1][1024, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_11, [-1], True), kwargs = {})
#   %add_62 : Tensor "f32[1, 128, 8, 1][1024, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_10, 1e-06), kwargs = {})
#   %rsqrt_16 : Tensor "f32[1, 128, 8, 1][1024, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_62,), kwargs = {})
#   %mul_86 : Tensor "f32[1, 128, 8, 256][262144, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_126, %rsqrt_16), kwargs = {})
#   %convert_element_type_127 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg48_1, torch.float32), kwargs = {})
#   %add_63 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_127, 1.0), kwargs = {})
#   %mul_87 : Tensor "f32[1, 128, 8, 256][262144, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_86, %add_63), kwargs = {})
#   %convert_element_type_128 : Tensor "bf16[1, 128, 8, 256][262144, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_87, torch.bfloat16), kwargs = {})
#   %permute_64 : Tensor "bf16[1, 8, 128, 256][262144, 256, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_128, [0, 2, 1, 3]), kwargs = {})
#   %slice_36 : Tensor "bf16[1, 8, 128, 64][262144, 256, 2048, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_64, 3, 0, 64), kwargs = {})
#   %select_23 : Tensor "f32[1, 128, 32][4096, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_8, 0, 0), kwargs = {})
#   %unsqueeze_7 : Tensor "f32[1, 128, 1, 32][4096, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_23, 2), kwargs = {})
#   %expand_3 : Tensor "f32[1, 128, 2, 32][4096, 32, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_7, [1, 128, 2, 32]), kwargs = {})
#   %clone_2 : Tensor "f32[1, 128, 2, 32][8192, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_1 : Tensor "f32[1, 128, 64][8192, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_2, [1, 128, 64]), kwargs = {})
#   %convert_element_type_2 : Tensor "bf16[1, 128, 64][8192, 64, 1]tnca:0"[num_users=6] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_1, torch.bfloat16), kwargs = {})
#   %unsqueeze_44 : Tensor "bf16[1, 1, 128, 64][8192, 8192, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_2, 1), kwargs = {})
#   %mul_90 : Tensor "bf16[1, 8, 128, 64][65536, 64, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_36, %unsqueeze_44), kwargs = {})
#   %select_11 : Tensor "f32[1, 128, 32][4096, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_9, 0, 0), kwargs = {})
#   %unsqueeze_6 : Tensor "f32[1, 128, 1, 32][4096, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_11, 2), kwargs = {})
#   %expand_2 : Tensor "f32[1, 128, 2, 32][4096, 32, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_6, [1, 128, 2, 32]), kwargs = {})
#   %clone : Tensor "f32[1, 128, 2, 32][8192, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_2,), kwargs = {memory_format: torch.contiguous_format})
#   %view : Tensor "f32[1, 128, 64][8192, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 128, 64]), kwargs = {})
#   %convert_element_type_3 : Tensor "bf16[1, 128, 64][8192, 64, 1]tnca:0"[num_users=6] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view, torch.bfloat16), kwargs = {})
#   %unsqueeze_45 : Tensor "bf16[1, 1, 128, 64][8192, 8192, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_3, 1), kwargs = {})
#   %mul_91 : Tensor "bf16[1, 8, 128, 64][65536, 8192, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat, %unsqueeze_45), kwargs = {})
#   %add_66 : Tensor "bf16[1, 8, 128, 64][65536, 64, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_90, %mul_91), kwargs = {})
#   %slice_37 : Tensor "bf16[1, 8, 128, 192][262144, 256, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_64, 3, 64, 9223372036854775807), kwargs = {})
#   %cat_2 : Tensor "bf16[1, 8, 128, 256][262144, 32768, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%add_66, %slice_37], -1), kwargs = {})
#   return %buf167
triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_38 = async_compile.triton('triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_38', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_38', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1184128}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_38(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 196608
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 192)
    x3 = xindex // 192
    x1 = ((xindex // 192) % 8)
    x2 = xindex // 1536
    tmp0 = tl.load(in_ptr0 + (64 + x0 + 512*x3), None).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (x3), None, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr2 + (64 + x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tl.full([1], 256.0, tl.float32)
    tmp4 = (tmp2 / tmp3)
    tmp5 = tl.full([1], 1e-06, tl.float32)
    tmp6 = tmp4 + tmp5
    tmp7 = libdevice.rsqrt(tmp6)
    tmp8 = tmp1 * tmp7
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tl.full([1], 1.0, tl.float32)
    tmp12 = tmp10 + tmp11
    tmp13 = tmp8 * tmp12
    tmp14 = tmp13.to(tl.float32)
    tl.store(out_ptr0 + (x0 + 256*x2 + 32768*x1), tmp14, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/sv/csvorum7nppd3xjkyyzdw573o4w3v47bfoummuuzq3bjroyszyhj.py
# Topologically Sorted Source Nodes: [linear_25], Original ATen: [aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_25 => mm_25, permute_65, view_196
# Graph fragment:
#   %convert_element_type_123 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0" = PlaceHolder[target=convert_element_type_123]
#   %arg49_1 : Tensor "bf16[512, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg49_1]
#   %view_196 : Tensor "bf16[128, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_123, [128, 2048]), kwargs = {})
#   %permute_65 : Tensor "bf16[2048, 512][1, 2048]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg49_1, [1, 0]), kwargs = {})
#   %mm_25 : Tensor "bf16[128, 512][512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_196, %permute_65), kwargs = {})
#   return %mm_25
triton_tem_fused_mm_t_view_39 = async_compile.triton('triton_tem_fused_mm_t_view_39', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*bf16', 'arg_B': '*bf16', 'out_ptr0': '*bf16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_mm_t_view_39', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_mm_t_view_39(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 128
    N = 512
    K = 2048
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 2048
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2048

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2048*idx_m
        a = tl.load(A + (xindex))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 512*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2048*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 512*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/r5/cr5ar4f4goea32b3nxdv44parz4b4om2xqhaxqjhnk4d2qae3mzk.py
# Topologically Sorted Source Nodes: [linear_25, view_2, float_24, pow_12, mean_11], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean]
# Source node to ATen node mapping:
#   float_24 => convert_element_type_131
#   linear_25 => view_197
#   mean_11 => mean_11
#   pow_12 => pow_12
#   view_2 => view_198
# Graph fragment:
#   %mm_25 : Tensor "bf16[128, 512][512, 1]tnca:0" = PlaceHolder[target=mm_25]
#   %view_197 : Tensor "bf16[1, 128, 512][65536, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_25, [1, 128, 512]), kwargs = {})
#   %view_198 : Tensor "bf16[1, 128, 2, 256][65536, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_197, [1, 128, -1, 256]), kwargs = {})
#   %convert_element_type_131 : Tensor "f32[1, 128, 2, 256][65536, 512, 256, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_198, torch.float32), kwargs = {})
#   %pow_12 : Tensor "f32[1, 128, 2, 256][65536, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_131, 2), kwargs = {})
#   %mean_11 : Tensor "f32[1, 128, 2, 1][256, 2, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_12, [-1], True), kwargs = {})
#   return %buf170
triton_red_fused__to_copy__unsafe_view_mean_pow_view_40 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_mean_pow_view_40', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 256, 'r0_': 256},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_mean_pow_view_40', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 2048, 'r0_': 131072}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_mean_pow_view_40(in_ptr0, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 256
    XBLOCK: tl.constexpr = 1
    r0_numel = 256
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[256, 256], strides=[256, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp4 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp2 = tmp1 * tmp1
        tmp3 = tl.broadcast_to(tmp2, [R0_BLOCK])
        tmp5 = _tmp4 + tmp3
        _tmp4 = tl.where(r0_mask, tmp5, _tmp4)
    tmp4 = triton_helpers.promote_to_tensor(tl.sum(_tmp4, 0))
    tl.store(out_ptr0 + (x0), tmp4, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/ar/cartnfxdolnuofnuyhxrfz4lkycp3a4tdcvacb2wnwgw5np2u6mj.py
# Topologically Sorted Source Nodes: [linear_25, view_2, float_24, pow_12, mean_11, add_46, rsqrt_17, output_19, float_25, add_47, output_20, type_as_8, key_states, k_rot, x2_1, neg_4, x1_1, cat_3], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
# Source node to ATen node mapping:
#   add_46 => add_64
#   add_47 => add_65
#   cat_3 => cat_1
#   float_24 => convert_element_type_131
#   float_25 => convert_element_type_132
#   k_rot => slice_38
#   key_states => permute_66
#   linear_25 => view_197
#   mean_11 => mean_11
#   neg_4 => neg_13
#   output_19 => mul_88
#   output_20 => mul_89
#   pow_12 => pow_12
#   rsqrt_17 => rsqrt_17
#   type_as_8 => convert_element_type_133
#   view_2 => view_198
#   x1_1 => slice_42
#   x2_1 => slice_43
# Graph fragment:
#   %mm_25 : Tensor "bf16[128, 512][512, 1]tnca:0" = PlaceHolder[target=mm_25]
#   %buf170 : Tensor "f32[1, 128, 2, 1][256, 2, 1, 256]tnca:0" = PlaceHolder[target=buf170]
#   %arg50_1 : Tensor "bf16[256][1]tnca:0" = PlaceHolder[target=arg50_1]
#   %view_197 : Tensor "bf16[1, 128, 512][65536, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_25, [1, 128, 512]), kwargs = {})
#   %view_198 : Tensor "bf16[1, 128, 2, 256][65536, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_197, [1, 128, -1, 256]), kwargs = {})
#   %convert_element_type_131 : Tensor "f32[1, 128, 2, 256][65536, 512, 256, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_198, torch.float32), kwargs = {})
#   %pow_12 : Tensor "f32[1, 128, 2, 256][65536, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_131, 2), kwargs = {})
#   %mean_11 : Tensor "f32[1, 128, 2, 1][256, 2, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_12, [-1], True), kwargs = {})
#   %add_64 : Tensor "f32[1, 128, 2, 1][256, 2, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_11, 1e-06), kwargs = {})
#   %rsqrt_17 : Tensor "f32[1, 128, 2, 1][256, 2, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_64,), kwargs = {})
#   %mul_88 : Tensor "f32[1, 128, 2, 256][65536, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_131, %rsqrt_17), kwargs = {})
#   %convert_element_type_132 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg50_1, torch.float32), kwargs = {})
#   %add_65 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_132, 1.0), kwargs = {})
#   %mul_89 : Tensor "f32[1, 128, 2, 256][65536, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_88, %add_65), kwargs = {})
#   %convert_element_type_133 : Tensor "bf16[1, 128, 2, 256][65536, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_89, torch.bfloat16), kwargs = {})
#   %permute_66 : Tensor "bf16[1, 2, 128, 256][65536, 256, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_133, [0, 2, 1, 3]), kwargs = {})
#   %slice_38 : Tensor "bf16[1, 2, 128, 64][65536, 256, 512, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_66, 3, 0, 64), kwargs = {})
#   %slice_43 : Tensor "bf16[1, 2, 128, 32][65536, 256, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_38, 3, 32, 9223372036854775807), kwargs = {})
#   %neg_13 : Tensor "bf16[1, 2, 128, 32][8192, 32, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_43,), kwargs = {})
#   %slice_42 : Tensor "bf16[1, 2, 128, 32][65536, 256, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_38, 3, 0, 32), kwargs = {})
#   %cat_1 : Tensor "bf16[1, 2, 128, 64][16384, 8192, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg_13, %slice_42], -1), kwargs = {})
#   return %neg_13,%buf172
triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_41 = async_compile.triton('triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_41', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 8192}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'out_ptr0': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_41', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 99456}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_41(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 8192
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 32)
    x3 = xindex // 32
    x1 = ((xindex // 32) % 2)
    x2 = xindex // 64
    tmp0 = tl.load(in_ptr0 + (32 + x0 + 256*x3), None).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (x3), None, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr2 + (32 + x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp16 = tl.load(in_ptr0 + (x0 + 256*x3), None).to(tl.float32)
    tmp19 = tl.load(in_ptr2 + (x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tl.full([1], 256.0, tl.float32)
    tmp4 = (tmp2 / tmp3)
    tmp5 = tl.full([1], 1e-06, tl.float32)
    tmp6 = tmp4 + tmp5
    tmp7 = libdevice.rsqrt(tmp6)
    tmp8 = tmp1 * tmp7
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tl.full([1], 1.0, tl.float32)
    tmp12 = tmp10 + tmp11
    tmp13 = tmp8 * tmp12
    tmp14 = tmp13.to(tl.float32)
    tmp15 = -tmp14
    tmp17 = tmp16.to(tl.float32)
    tmp18 = tmp17 * tmp7
    tmp20 = tmp19.to(tl.float32)
    tmp21 = tmp20 + tmp11
    tmp22 = tmp18 * tmp21
    tmp23 = tmp22.to(tl.float32)
    tl.store(out_ptr0 + (x0 + 64*x2 + 8192*x1), tmp15, None)
    tl.store(out_ptr1 + (x0 + 64*x2 + 8192*x1), tmp23, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/e3/ce3p4p4n5a6wpiwabedzl4sifxcstpevyykpxx5ibgfstfvb5sie.py
# Topologically Sorted Source Nodes: [cos_2, cos_3, cos_4, sin_2, sin_3, sin_4, linear_25, view_2, float_24, pow_12, mean_11, add_46, rsqrt_17, output_19, float_25, add_47, output_20, type_as_8, key_states, k_rot, mul_80, mul_81, k_embed], Original ATen: [aten.select, aten.cat, aten._to_copy, aten.unsqueeze, aten._unsafe_view, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice]
# Source node to ATen node mapping:
#   add_46 => add_64
#   add_47 => add_65
#   cos_2 => clone_2, expand_3, select_23, unsqueeze_7, view_1
#   cos_3 => convert_element_type_2
#   cos_4 => unsqueeze_44
#   float_24 => convert_element_type_131
#   float_25 => convert_element_type_132
#   k_embed => add_67
#   k_rot => slice_38
#   key_states => permute_66
#   linear_25 => view_197
#   mean_11 => mean_11
#   mul_80 => mul_92
#   mul_81 => mul_93
#   output_19 => mul_88
#   output_20 => mul_89
#   pow_12 => pow_12
#   rsqrt_17 => rsqrt_17
#   sin_2 => clone, expand_2, select_11, unsqueeze_6, view
#   sin_3 => convert_element_type_3
#   sin_4 => unsqueeze_45
#   type_as_8 => convert_element_type_133
#   view_2 => view_198
# Graph fragment:
#   %mm_25 : Tensor "bf16[128, 512][512, 1]tnca:0" = PlaceHolder[target=mm_25]
#   %buf170 : Tensor "f32[1, 128, 2, 1][256, 2, 1, 256]tnca:0" = PlaceHolder[target=buf170]
#   %arg50_1 : Tensor "bf16[256][1]tnca:0" = PlaceHolder[target=arg50_1]
#   %select_scatter_default_8 : Tensor "f32[3, 1, 128, 32][4096, 12288, 32, 1]tnca:0" = PlaceHolder[target=select_scatter_default_8]
#   %cat_1 : Tensor "bf16[1, 2, 128, 64][16384, 8192, 64, 1]tnca:0" = PlaceHolder[target=cat_1]
#   %select_scatter_default_9 : Tensor "f32[3, 1, 128, 32][4096, 12288, 32, 1]tnca:0" = PlaceHolder[target=select_scatter_default_9]
#   %select_23 : Tensor "f32[1, 128, 32][4096, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_8, 0, 0), kwargs = {})
#   %unsqueeze_7 : Tensor "f32[1, 128, 1, 32][4096, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_23, 2), kwargs = {})
#   %expand_3 : Tensor "f32[1, 128, 2, 32][4096, 32, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_7, [1, 128, 2, 32]), kwargs = {})
#   %clone_2 : Tensor "f32[1, 128, 2, 32][8192, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_1 : Tensor "f32[1, 128, 64][8192, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_2, [1, 128, 64]), kwargs = {})
#   %convert_element_type_2 : Tensor "bf16[1, 128, 64][8192, 64, 1]tnca:0"[num_users=6] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_1, torch.bfloat16), kwargs = {})
#   %unsqueeze_44 : Tensor "bf16[1, 1, 128, 64][8192, 8192, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_2, 1), kwargs = {})
#   %select_11 : Tensor "f32[1, 128, 32][4096, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_9, 0, 0), kwargs = {})
#   %unsqueeze_6 : Tensor "f32[1, 128, 1, 32][4096, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_11, 2), kwargs = {})
#   %expand_2 : Tensor "f32[1, 128, 2, 32][4096, 32, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_6, [1, 128, 2, 32]), kwargs = {})
#   %clone : Tensor "f32[1, 128, 2, 32][8192, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_2,), kwargs = {memory_format: torch.contiguous_format})
#   %view : Tensor "f32[1, 128, 64][8192, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 128, 64]), kwargs = {})
#   %convert_element_type_3 : Tensor "bf16[1, 128, 64][8192, 64, 1]tnca:0"[num_users=6] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view, torch.bfloat16), kwargs = {})
#   %unsqueeze_45 : Tensor "bf16[1, 1, 128, 64][8192, 8192, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_3, 1), kwargs = {})
#   %view_197 : Tensor "bf16[1, 128, 512][65536, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_25, [1, 128, 512]), kwargs = {})
#   %view_198 : Tensor "bf16[1, 128, 2, 256][65536, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_197, [1, 128, -1, 256]), kwargs = {})
#   %convert_element_type_131 : Tensor "f32[1, 128, 2, 256][65536, 512, 256, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_198, torch.float32), kwargs = {})
#   %pow_12 : Tensor "f32[1, 128, 2, 256][65536, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_131, 2), kwargs = {})
#   %mean_11 : Tensor "f32[1, 128, 2, 1][256, 2, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_12, [-1], True), kwargs = {})
#   %add_64 : Tensor "f32[1, 128, 2, 1][256, 2, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_11, 1e-06), kwargs = {})
#   %rsqrt_17 : Tensor "f32[1, 128, 2, 1][256, 2, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_64,), kwargs = {})
#   %mul_88 : Tensor "f32[1, 128, 2, 256][65536, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_131, %rsqrt_17), kwargs = {})
#   %convert_element_type_132 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg50_1, torch.float32), kwargs = {})
#   %add_65 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_132, 1.0), kwargs = {})
#   %mul_89 : Tensor "f32[1, 128, 2, 256][65536, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_88, %add_65), kwargs = {})
#   %convert_element_type_133 : Tensor "bf16[1, 128, 2, 256][65536, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_89, torch.bfloat16), kwargs = {})
#   %permute_66 : Tensor "bf16[1, 2, 128, 256][65536, 256, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_133, [0, 2, 1, 3]), kwargs = {})
#   %slice_38 : Tensor "bf16[1, 2, 128, 64][65536, 256, 512, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_66, 3, 0, 64), kwargs = {})
#   %mul_92 : Tensor "bf16[1, 2, 128, 64][16384, 64, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_38, %unsqueeze_44), kwargs = {})
#   %mul_93 : Tensor "bf16[1, 2, 128, 64][16384, 8192, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_1, %unsqueeze_45), kwargs = {})
#   %add_67 : Tensor "bf16[1, 2, 128, 64][16384, 64, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_92, %mul_93), kwargs = {})
#   return %add_67
triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_42 = async_compile.triton('triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_42', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 16384}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'in_ptr3': '*fp32', 'in_ptr4': '*bf16', 'in_ptr5': '*fp32', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_42', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 197760}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_42(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 16384
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 64)
    x1 = ((xindex // 64) % 128)
    x2 = xindex // 8192
    x3 = xindex
    x4 = xindex // 64
    tmp0 = tl.load(in_ptr0 + (x0 + 256*x2 + 512*x1), None).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (x2 + 2*x1), None, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr2 + (x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp15 = tl.load(in_ptr3 + (32*x1 + ((x0 % 32))), None, eviction_policy='evict_last')
    tmp18 = tl.load(in_ptr4 + (x3), None).to(tl.float32)
    tmp19 = tl.load(in_ptr5 + (32*x1 + ((x0 % 32))), None, eviction_policy='evict_last')
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tl.full([1], 256.0, tl.float32)
    tmp4 = (tmp2 / tmp3)
    tmp5 = tl.full([1], 1e-06, tl.float32)
    tmp6 = tmp4 + tmp5
    tmp7 = libdevice.rsqrt(tmp6)
    tmp8 = tmp1 * tmp7
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tl.full([1], 1.0, tl.float32)
    tmp12 = tmp10 + tmp11
    tmp13 = tmp8 * tmp12
    tmp14 = tmp13.to(tl.float32)
    tmp16 = tmp15.to(tl.float32)
    tmp17 = tmp14 * tmp16
    tmp20 = tmp19.to(tl.float32)
    tmp21 = tmp18 * tmp20
    tmp22 = tmp17 + tmp21
    tl.store(out_ptr0 + (x0 + 256*x4), tmp22, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/lx/clxsrbg4puuqrahhwcvcdhztfpw5kqrezgeq4fzn33ikvlyypwjq.py
# Topologically Sorted Source Nodes: [cos_2, cos_3, cos_4, sin_2, sin_3, sin_4, linear_25, view_2, float_24, pow_12, mean_11, add_46, rsqrt_17, output_19, float_25, add_47, output_20, type_as_8, key_states, k_rot, mul_80, mul_81, k_embed, k_pass, k_embed_1], Original ATen: [aten.select, aten.cat, aten._to_copy, aten.unsqueeze, aten._unsafe_view, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice]
# Source node to ATen node mapping:
#   add_46 => add_64
#   add_47 => add_65
#   cos_2 => clone_2, expand_3, select_23, unsqueeze_7, view_1
#   cos_3 => convert_element_type_2
#   cos_4 => unsqueeze_44
#   float_24 => convert_element_type_131
#   float_25 => convert_element_type_132
#   k_embed => add_67
#   k_embed_1 => cat_3
#   k_pass => slice_39
#   k_rot => slice_38
#   key_states => permute_66
#   linear_25 => view_197
#   mean_11 => mean_11
#   mul_80 => mul_92
#   mul_81 => mul_93
#   output_19 => mul_88
#   output_20 => mul_89
#   pow_12 => pow_12
#   rsqrt_17 => rsqrt_17
#   sin_2 => clone, expand_2, select_11, unsqueeze_6, view
#   sin_3 => convert_element_type_3
#   sin_4 => unsqueeze_45
#   type_as_8 => convert_element_type_133
#   view_2 => view_198
# Graph fragment:
#   %mm_25 : Tensor "bf16[128, 512][512, 1]tnca:0" = PlaceHolder[target=mm_25]
#   %buf170 : Tensor "f32[1, 128, 2, 1][256, 2, 1, 256]tnca:0" = PlaceHolder[target=buf170]
#   %arg50_1 : Tensor "bf16[256][1]tnca:0" = PlaceHolder[target=arg50_1]
#   %select_23 : Tensor "f32[1, 128, 32][4096, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_8, 0, 0), kwargs = {})
#   %unsqueeze_7 : Tensor "f32[1, 128, 1, 32][4096, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_23, 2), kwargs = {})
#   %expand_3 : Tensor "f32[1, 128, 2, 32][4096, 32, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_7, [1, 128, 2, 32]), kwargs = {})
#   %clone_2 : Tensor "f32[1, 128, 2, 32][8192, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_1 : Tensor "f32[1, 128, 64][8192, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_2, [1, 128, 64]), kwargs = {})
#   %convert_element_type_2 : Tensor "bf16[1, 128, 64][8192, 64, 1]tnca:0"[num_users=6] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_1, torch.bfloat16), kwargs = {})
#   %unsqueeze_44 : Tensor "bf16[1, 1, 128, 64][8192, 8192, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_2, 1), kwargs = {})
#   %select_11 : Tensor "f32[1, 128, 32][4096, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_9, 0, 0), kwargs = {})
#   %unsqueeze_6 : Tensor "f32[1, 128, 1, 32][4096, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_11, 2), kwargs = {})
#   %expand_2 : Tensor "f32[1, 128, 2, 32][4096, 32, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_6, [1, 128, 2, 32]), kwargs = {})
#   %clone : Tensor "f32[1, 128, 2, 32][8192, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_2,), kwargs = {memory_format: torch.contiguous_format})
#   %view : Tensor "f32[1, 128, 64][8192, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 128, 64]), kwargs = {})
#   %convert_element_type_3 : Tensor "bf16[1, 128, 64][8192, 64, 1]tnca:0"[num_users=6] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view, torch.bfloat16), kwargs = {})
#   %unsqueeze_45 : Tensor "bf16[1, 1, 128, 64][8192, 8192, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_3, 1), kwargs = {})
#   %view_197 : Tensor "bf16[1, 128, 512][65536, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_25, [1, 128, 512]), kwargs = {})
#   %view_198 : Tensor "bf16[1, 128, 2, 256][65536, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_197, [1, 128, -1, 256]), kwargs = {})
#   %convert_element_type_131 : Tensor "f32[1, 128, 2, 256][65536, 512, 256, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_198, torch.float32), kwargs = {})
#   %pow_12 : Tensor "f32[1, 128, 2, 256][65536, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_131, 2), kwargs = {})
#   %mean_11 : Tensor "f32[1, 128, 2, 1][256, 2, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_12, [-1], True), kwargs = {})
#   %add_64 : Tensor "f32[1, 128, 2, 1][256, 2, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_11, 1e-06), kwargs = {})
#   %rsqrt_17 : Tensor "f32[1, 128, 2, 1][256, 2, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_64,), kwargs = {})
#   %mul_88 : Tensor "f32[1, 128, 2, 256][65536, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_131, %rsqrt_17), kwargs = {})
#   %convert_element_type_132 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg50_1, torch.float32), kwargs = {})
#   %add_65 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_132, 1.0), kwargs = {})
#   %mul_89 : Tensor "f32[1, 128, 2, 256][65536, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_88, %add_65), kwargs = {})
#   %convert_element_type_133 : Tensor "bf16[1, 128, 2, 256][65536, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_89, torch.bfloat16), kwargs = {})
#   %permute_66 : Tensor "bf16[1, 2, 128, 256][65536, 256, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_133, [0, 2, 1, 3]), kwargs = {})
#   %slice_38 : Tensor "bf16[1, 2, 128, 64][65536, 256, 512, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_66, 3, 0, 64), kwargs = {})
#   %mul_92 : Tensor "bf16[1, 2, 128, 64][16384, 64, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_38, %unsqueeze_44), kwargs = {})
#   %mul_93 : Tensor "bf16[1, 2, 128, 64][16384, 8192, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_1, %unsqueeze_45), kwargs = {})
#   %add_67 : Tensor "bf16[1, 2, 128, 64][16384, 64, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_92, %mul_93), kwargs = {})
#   %slice_39 : Tensor "bf16[1, 2, 128, 192][65536, 256, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_66, 3, 64, 9223372036854775807), kwargs = {})
#   %cat_3 : Tensor "bf16[1, 2, 128, 256][65536, 32768, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%add_67, %slice_39], -1), kwargs = {})
#   return %buf175
triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_43 = async_compile.triton('triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_43', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 65536}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_43', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 296320}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_43(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 49152
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 192)
    x3 = xindex // 192
    x1 = ((xindex // 192) % 2)
    x2 = xindex // 384
    tmp0 = tl.load(in_ptr0 + (64 + x0 + 256*x3), None).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (x3), None, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr2 + (64 + x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tl.full([1], 256.0, tl.float32)
    tmp4 = (tmp2 / tmp3)
    tmp5 = tl.full([1], 1e-06, tl.float32)
    tmp6 = tmp4 + tmp5
    tmp7 = libdevice.rsqrt(tmp6)
    tmp8 = tmp1 * tmp7
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tl.full([1], 1.0, tl.float32)
    tmp12 = tmp10 + tmp11
    tmp13 = tmp8 * tmp12
    tmp14 = tmp13.to(tl.float32)
    tl.store(out_ptr0 + (x0 + 256*x2 + 32768*x1), tmp14, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/dv/cdvbj6lpq7kc3hcbogngxxw7wq6bc4gpl24dgbavy3j5aua6q3fa.py
# Topologically Sorted Source Nodes: [getitem_81, hidden_states_25, key_states_1], Original ATen: [aten.unsqueeze, aten.expand, aten.clone]
# Source node to ATen node mapping:
#   getitem_81 => unsqueeze_46
#   hidden_states_25 => expand_64
#   key_states_1 => clone_26
# Graph fragment:
#   %cat_3 : Tensor "bf16[1, 2, 128, 256][65536, 32768, 256, 1]tnca:0" = PlaceHolder[target=cat_3]
#   %unsqueeze_46 : Tensor "bf16[1, 2, 1, 128, 256][65536, 32768, 32768, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%cat_3, 2), kwargs = {})
#   %expand_64 : Tensor "bf16[1, 2, 4, 128, 256][65536, 32768, 0, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_46, [1, 2, 4, 128, 256]), kwargs = {})
#   %clone_26 : Tensor "bf16[1, 2, 4, 128, 256][262144, 131072, 32768, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_64,), kwargs = {memory_format: torch.contiguous_format})
#   return %clone_26
triton_poi_fused_clone_expand_unsqueeze_44 = async_compile.triton('triton_poi_fused_clone_expand_unsqueeze_44', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_clone_expand_unsqueeze_44', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1179648}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_clone_expand_unsqueeze_44(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 262144
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 32768)
    x2 = xindex // 131072
    x3 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 32768*x2), None, eviction_policy='evict_last').to(tl.float32)
    tl.store(out_ptr0 + (x3), tmp0, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/3u/c3uh2vdnlhgfgxf2zype6o2efy7rimmizd2wj2giz44klez64rbs.py
# Topologically Sorted Source Nodes: [matmul_30, getitem_81, hidden_states_25, key_states_1, transpose_39], Original ATen: [aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.bmm]
# Source node to ATen node mapping:
#   getitem_81 => unsqueeze_46
#   hidden_states_25 => expand_64
#   key_states_1 => clone_26, view_202
#   matmul_30 => bmm_30, view_204, view_205
#   transpose_39 => permute_69
# Graph fragment:
#   %expand_66 : Tensor "bf16[1, 8, 128, 256][262144, 32768, 256, 1]tnca:0" = PlaceHolder[target=expand_66]
#   %clone_26 : Tensor "bf16[1, 2, 4, 128, 256][262144, 131072, 32768, 256, 1]tnca:0" = PlaceHolder[target=clone_26]
#   %view_204 : Tensor "bf16[8, 128, 256][32768, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_66, [8, 128, 256]), kwargs = {})
#   %unsqueeze_46 : Tensor "bf16[1, 2, 1, 128, 256][65536, 32768, 32768, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%cat_3, 2), kwargs = {})
#   %expand_64 : Tensor "bf16[1, 2, 4, 128, 256][65536, 32768, 0, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_46, [1, 2, 4, 128, 256]), kwargs = {})
#   %clone_26 : Tensor "bf16[1, 2, 4, 128, 256][262144, 131072, 32768, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_64,), kwargs = {memory_format: torch.contiguous_format})
#   %view_202 : Tensor "bf16[1, 8, 128, 256][262144, 32768, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_26, [1, 8, 128, 256]), kwargs = {})
#   %permute_69 : Tensor "bf16[1, 8, 256, 128][262144, 32768, 1, 256]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_202, [0, 1, 3, 2]), kwargs = {})
#   %view_205 : Tensor "bf16[8, 256, 128][32768, 1, 256]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_67, [8, 256, 128]), kwargs = {})
#   %bmm_30 : Tensor "bf16[8, 128, 128][16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_204, %view_205), kwargs = {})
#   return %bmm_30
triton_tem_fused__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_45 = async_compile.triton('triton_tem_fused__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_45', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*bf16', 'arg_B': '*bf16', 'out_ptr0': '*bf16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_45', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_45(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 128
    N = 128
    K = 256
    BATCH = 8

    stride_aq = 32768
    stride_am = 256
    stride_ak = 1

    stride_bq = 32768
    stride_bk = 1
    stride_bn = 256

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        ram = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        ram = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        rbn = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        rbn = rn % N

    rk = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)

    # Reconstruct batch index from grid_y/grid_z split (handles batch > 65535)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    # Clamp to valid range for safe pointer arithmetic; out-of-bounds CTAs are
    # masked off at the store below.
    idx_q_clamped = tl.minimum(idx_q, BATCH - 1)
    A = A + (ram[:, None] * stride_am + rk[None, :] * stride_ak + idx_q_clamped*stride_aq)
    B = B + (rk[:, None] * stride_bk + rbn[None, :] * stride_bn + idx_q_clamped*stride_bq)

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)
    for k in range(K, 0, -BLOCK_K):
        if EVEN_K:
            a = tl.load(A)
            b = tl.load(B)
        else:
            a = tl.load(A, mask=rk[None, :] < k, other=0.)
            b = tl.load(B, mask=rk[:, None] < k, other=0.)
        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32)
        A += BLOCK_K * stride_ak
        B += BLOCK_K * stride_bk

    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N) & (idx_q < BATCH)

    # inductor generates a suffix
    xindex = idx_n + 128*idx_m + 16384*idx_q
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/4a/c4ajhhpp55bzr37bx6if5pp32e2cwvhg63izmxkwcunivnp6zmvz.py
# Topologically Sorted Source Nodes: [matmul_30, attn_weights, mask, full, getitem, attn_weights_1, softmax, attn_weights_2], Original ATen: [aten.view, aten.mul, aten.triu, aten.full, aten.unsqueeze, aten.add, aten._to_copy, aten._softmax]
# Source node to ATen node mapping:
#   attn_weights => mul_94
#   attn_weights_1 => add_68
#   attn_weights_2 => convert_element_type_139
#   full => full_default
#   getitem => unsqueeze_2, unsqueeze_3
#   mask => full_default_1, ge, iota, iota_1, sub, unsqueeze, unsqueeze_1, where
#   matmul_30 => view_206
#   softmax => amax, convert_element_type_138, div_9, exp_30, sub_16, sum_7
# Graph fragment:
#   %bmm_30 : Tensor "bf16[8, 128, 128][16384, 128, 1]tnca:0" = PlaceHolder[target=bmm_30]
#   %amax : Tensor "f32[1, 8, 128, 1][1024, 128, 1, 1024]tnca:0" = PlaceHolder[target=amax]
#   %exp_30 : Tensor "f32[1, 8, 128, 128][131072, 16384, 128, 1]tnca:0" = PlaceHolder[target=exp_30]
#   %sum_7 : Tensor "f32[1, 8, 128, 1][1024, 128, 1, 1024]tnca:0" = PlaceHolder[target=sum_7]
#   %view_206 : Tensor "bf16[1, 8, 128, 128][131072, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_30, [1, 8, 128, 128]), kwargs = {})
#   %mul_94 : Tensor "bf16[1, 8, 128, 128][131072, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%view_206, 0.0625), kwargs = {})
#   %iota : Tensor "i64[128][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (128,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %unsqueeze : Tensor "i64[1, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%iota, -2), kwargs = {})
#   %iota_1 : Tensor "i64[128][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (128,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %unsqueeze_1 : Tensor "i64[128, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%iota_1, -1), kwargs = {})
#   %sub : Tensor "i64[128, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%unsqueeze, %unsqueeze_1), kwargs = {})
#   %ge : Tensor "b8[128, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.ge.Scalar](args = (%sub, 1), kwargs = {})
#   %full_default : Tensor "bf16[128, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([128, 128], -inf), kwargs = {dtype: torch.bfloat16, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %full_default_1 : Tensor "bf16[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([], 0.0), kwargs = {dtype: torch.bfloat16, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %where : Tensor "bf16[128, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%ge, %full_default, %full_default_1), kwargs = {})
#   %unsqueeze_2 : Tensor "bf16[1, 128, 128][16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%where, 0), kwargs = {})
#   %unsqueeze_3 : Tensor "bf16[1, 1, 128, 128][16384, 16384, 128, 1]tnca:0"[num_users=6] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze_2, 1), kwargs = {})
#   %add_68 : Tensor "bf16[1, 8, 128, 128][131072, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_94, %unsqueeze_3), kwargs = {})
#   %convert_element_type_138 : Tensor "f32[1, 8, 128, 128][131072, 16384, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_68, torch.float32), kwargs = {})
#   %amax : Tensor "f32[1, 8, 128, 1][1024, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.amax.default](args = (%convert_element_type_138, [-1], True), kwargs = {})
#   %sub_16 : Tensor "f32[1, 8, 128, 128][131072, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%convert_element_type_138, %amax), kwargs = {})
#   %exp_30 : Tensor "f32[1, 8, 128, 128][131072, 16384, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.exp.default](args = (%sub_16,), kwargs = {})
#   %sum_7 : Tensor "f32[1, 8, 128, 1][1024, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%exp_30, [-1], True), kwargs = {})
#   %div_9 : Tensor "f32[1, 8, 128, 128][131072, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp_30, %sum_7), kwargs = {})
#   %convert_element_type_139 : Tensor "bf16[1, 8, 128, 128][131072, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_9, torch.bfloat16), kwargs = {})
#   return %amax,%exp_30,%sum_7,%expand_68
triton_red_fused__softmax__to_copy_add_full_mul_triu_unsqueeze_view_46 = async_compile.triton('triton_red_fused__softmax__to_copy_add_full_mul_triu_unsqueeze_view_46', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1024, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr1': '*fp32', 'out_ptr3': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__softmax__to_copy_add_full_mul_triu_unsqueeze_view_46', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 3, 'num_store': 2, 'num_reduction': 2, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 786432}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__softmax__to_copy_add_full_mul_triu_unsqueeze_view_46(in_ptr0, out_ptr1, out_ptr3, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1024
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x3 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[1024, 128], strides=[128, 1], block_shape=[XBLOCK, R0_BLOCK])
    x0 = (xindex % 128)
    _tmp13 = tl.full([R0_BLOCK], float("-inf"), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.full([1], 0.0625, tl.float32)
        tmp2 = tmp0 * tmp1
        tmp3 = (r0_2 + ((-1)*x0)).to(tl.int64)
        tmp4 = (tmp3).to(tl.int64)
        tmp5 = tl.full([1], 1, tl.int64)
        tmp6 = tmp4 >= tmp5
        tmp7 = tl.full([1], float("-inf"), tl.float32)
        tmp8 = tl.full([1], 0.0, tl.float32)
        tmp9 = tl.where(tmp6, tmp7, tmp8)
        tmp10 = tmp2 + tmp9
        tmp11 = tmp10.to(tl.float32)
        tmp12 = tl.broadcast_to(tmp11, [R0_BLOCK])
        tmp14 = tl.maximum(_tmp13, tmp12, tl.PropagateNan.ALL)
        _tmp13 = tl.where(r0_mask, tmp14, _tmp13)
    tmp13 = triton_helpers.promote_to_tensor(triton_helpers.max2(_tmp13, 0))
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[1024, 128], strides=[128, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp30 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp15 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp16 = tl.full([1], 0.0625, tl.float32)
        tmp17 = tmp15 * tmp16
        tmp18 = (r0_2 + ((-1)*x0)).to(tl.int64)
        tmp19 = (tmp18).to(tl.int64)
        tmp20 = tl.full([1], 1, tl.int64)
        tmp21 = tmp19 >= tmp20
        tmp22 = tl.full([1], float("-inf"), tl.float32)
        tmp23 = tl.full([1], 0.0, tl.float32)
        tmp24 = tl.where(tmp21, tmp22, tmp23)
        tmp25 = tmp17 + tmp24
        tmp26 = tmp25.to(tl.float32)
        tmp27 = tmp26 - tmp13
        tmp28 = libdevice.exp(tmp27)
        tmp29 = tl.broadcast_to(tmp28, [R0_BLOCK])
        tmp31 = _tmp30 + tmp29
        _tmp30 = tl.where(r0_mask, tmp31, _tmp30)
        tl.store(out_ptr1 + (r0_2 + 128*x3), tmp28, r0_mask)
    tmp30 = triton_helpers.promote_to_tensor(tl.sum(_tmp30, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(out_ptr1, shape=[1024, 128], strides=[128, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tl.debug_barrier()
        tmp32 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp33 = (tmp32 / tmp30)
        tmp34 = tmp33.to(tl.float32)
        tl.store(out_ptr3 + (r0_2 + 128*x3), tmp34, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/ov/covx4txlgg2u7qokjtnasztghvf2v5o5d7izv66jydg7u6jd66tl.py
# Topologically Sorted Source Nodes: [linear_26, view_3, value_states, getitem_82, hidden_states_26, value_states_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten.clone]
# Source node to ATen node mapping:
#   getitem_82 => unsqueeze_47
#   hidden_states_26 => expand_65
#   linear_26 => view_200
#   value_states => permute_68
#   value_states_1 => clone_27
#   view_3 => view_201
# Graph fragment:
#   %mm_26 : Tensor "bf16[128, 512][512, 1]tnca:0" = PlaceHolder[target=mm_26]
#   %view_200 : Tensor "bf16[1, 128, 512][65536, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_26, [1, 128, 512]), kwargs = {})
#   %view_201 : Tensor "bf16[1, 128, 2, 256][65536, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_200, [1, 128, -1, 256]), kwargs = {})
#   %permute_68 : Tensor "bf16[1, 2, 128, 256][65536, 256, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_201, [0, 2, 1, 3]), kwargs = {})
#   %unsqueeze_47 : Tensor "bf16[1, 2, 1, 128, 256][65536, 256, 65536, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute_68, 2), kwargs = {})
#   %expand_65 : Tensor "bf16[1, 2, 4, 128, 256][65536, 256, 0, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_47, [1, 2, 4, 128, 256]), kwargs = {})
#   %clone_27 : Tensor "bf16[1, 2, 4, 128, 256][262144, 131072, 32768, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_65,), kwargs = {memory_format: torch.contiguous_format})
#   return %clone_27
triton_poi_fused__unsafe_view_clone_expand_transpose_unsqueeze_view_47 = async_compile.triton('triton_poi_fused__unsafe_view_clone_expand_transpose_unsqueeze_view_47', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_clone_expand_transpose_unsqueeze_view_47', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1179648}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_clone_expand_transpose_unsqueeze_view_47(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 262144
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 256)
    x1 = ((xindex // 256) % 128)
    x3 = xindex // 131072
    x4 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 256*x3 + 512*x1), None, eviction_policy='evict_last').to(tl.float32)
    tl.store(out_ptr0 + (x4), tmp0, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/l6/cl6n4q3iit4xjkrixr46h2w3io5pce7oplabzmtwbtwart7kzhb4.py
# Topologically Sorted Source Nodes: [softmax, attn_weights_2, attn_output, linear_26, view_3, value_states, getitem_82, hidden_states_26, value_states_1], Original ATen: [aten._softmax, aten._to_copy, aten.view, aten._unsafe_view, aten.transpose, aten.unsqueeze, aten.expand, aten.clone, aten.bmm]
# Source node to ATen node mapping:
#   attn_output => bmm_31, view_207, view_208
#   attn_weights_2 => convert_element_type_139
#   getitem_82 => unsqueeze_47
#   hidden_states_26 => expand_65
#   linear_26 => view_200
#   softmax => div_9
#   value_states => permute_68
#   value_states_1 => clone_27, view_203
#   view_3 => view_201
# Graph fragment:
#   %expand_68 : Tensor "bf16[1, 8, 128, 128][131072, 16384, 128, 1]tnca:0" = PlaceHolder[target=expand_68]
#   %clone_27 : Tensor "bf16[1, 2, 4, 128, 256][262144, 131072, 32768, 256, 1]tnca:0" = PlaceHolder[target=clone_27]
#   %div_9 : Tensor "f32[1, 8, 128, 128][131072, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp_30, %sum_7), kwargs = {})
#   %convert_element_type_139 : Tensor "bf16[1, 8, 128, 128][131072, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_9, torch.bfloat16), kwargs = {})
#   %view_207 : Tensor "bf16[8, 128, 128][16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_68, [8, 128, 128]), kwargs = {})
#   %view_200 : Tensor "bf16[1, 128, 512][65536, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_26, [1, 128, 512]), kwargs = {})
#   %view_201 : Tensor "bf16[1, 128, 2, 256][65536, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_200, [1, 128, -1, 256]), kwargs = {})
#   %permute_68 : Tensor "bf16[1, 2, 128, 256][65536, 256, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_201, [0, 2, 1, 3]), kwargs = {})
#   %unsqueeze_47 : Tensor "bf16[1, 2, 1, 128, 256][65536, 256, 65536, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute_68, 2), kwargs = {})
#   %expand_65 : Tensor "bf16[1, 2, 4, 128, 256][65536, 256, 0, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_47, [1, 2, 4, 128, 256]), kwargs = {})
#   %clone_27 : Tensor "bf16[1, 2, 4, 128, 256][262144, 131072, 32768, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_65,), kwargs = {memory_format: torch.contiguous_format})
#   %view_203 : Tensor "bf16[1, 8, 128, 256][262144, 32768, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_27, [1, 8, 128, 256]), kwargs = {})
#   %view_208 : Tensor "bf16[8, 128, 256][32768, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_69, [8, 128, 256]), kwargs = {})
#   %bmm_31 : Tensor "bf16[8, 128, 256][32768, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_207, %view_208), kwargs = {})
#   return %bmm_31
triton_tem_fused__softmax__to_copy__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_48 = async_compile.triton('triton_tem_fused__softmax__to_copy__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_48', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*bf16', 'arg_B': '*bf16', 'out_ptr0': '*bf16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__softmax__to_copy__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_48', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__softmax__to_copy__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_48(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 128
    N = 256
    K = 128
    BATCH = 8

    stride_aq = 16384
    stride_am = 128
    stride_ak = 1

    stride_bq = 32768
    stride_bk = 256
    stride_bn = 1

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        ram = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        ram = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        rbn = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        rbn = rn % N

    rk = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)

    # Reconstruct batch index from grid_y/grid_z split (handles batch > 65535)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    # Clamp to valid range for safe pointer arithmetic; out-of-bounds CTAs are
    # masked off at the store below.
    idx_q_clamped = tl.minimum(idx_q, BATCH - 1)
    A = A + (ram[:, None] * stride_am + rk[None, :] * stride_ak + idx_q_clamped*stride_aq)
    B = B + (rk[:, None] * stride_bk + rbn[None, :] * stride_bn + idx_q_clamped*stride_bq)

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)
    for k in range(K, 0, -BLOCK_K):
        if EVEN_K:
            a = tl.load(A)
            b = tl.load(B)
        else:
            a = tl.load(A, mask=rk[None, :] < k, other=0.)
            b = tl.load(B, mask=rk[:, None] < k, other=0.)
        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32)
        A += BLOCK_K * stride_ak
        B += BLOCK_K * stride_bk

    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N) & (idx_q < BATCH)

    # inductor generates a suffix
    xindex = idx_n + 256*idx_m + 32768*idx_q
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/h6/ch6vmq7h6l3hbvihcc5fvseywmkxhyrs73hewo5bfukkmdia6gvc.py
# Topologically Sorted Source Nodes: [linear_24, view, chunk, attn_output, transpose_40, attn_output_1, reshape_42, gate_1, sigmoid_3, attn_output_3], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten.transpose, aten.clone, aten.sigmoid, aten.mul]
# Source node to ATen node mapping:
#   attn_output => view_209
#   attn_output_1 => clone_28
#   attn_output_3 => mul_95
#   chunk => split
#   gate_1 => clone_25, view_194
#   linear_24 => view_192
#   reshape_42 => view_210
#   sigmoid_3 => sigmoid_3
#   transpose_40 => permute_70
#   view => view_193
# Graph fragment:
#   %bmm_31 : Tensor "bf16[8, 128, 256][32768, 256, 1]tnca:0" = PlaceHolder[target=bmm_31]
#   %mm_24 : Tensor "bf16[128, 4096][4096, 1]tnca:0" = PlaceHolder[target=mm_24]
#   %view_192 : Tensor "bf16[1, 128, 4096][524288, 4096, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_24, [1, 128, 4096]), kwargs = {})
#   %view_193 : Tensor "bf16[1, 128, 8, 512][524288, 4096, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_192, [1, 128, -1, 512]), kwargs = {})
#   %split : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_193, 256, -1), kwargs = {})
#   %view_209 : Tensor "bf16[1, 8, 128, 256][262144, 32768, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_31, [1, 8, 128, 256]), kwargs = {})
#   %permute_70 : Tensor "bf16[1, 128, 8, 256][262144, 256, 32768, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_209, [0, 2, 1, 3]), kwargs = {})
#   %clone_28 : Tensor "bf16[1, 128, 8, 256][262144, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%permute_70,), kwargs = {memory_format: torch.contiguous_format})
#   %view_210 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_28, [1, 128, -1]), kwargs = {})
#   %clone_25 : Tensor "bf16[1, 128, 8, 256][262144, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%getitem_10,), kwargs = {memory_format: torch.contiguous_format})
#   %view_194 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_25, [1, 128, 2048]), kwargs = {})
#   %sigmoid_3 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sigmoid.default](args = (%view_194,), kwargs = {})
#   %mul_95 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%view_210, %sigmoid_3), kwargs = {})
#   return %mul_95
triton_poi_fused__unsafe_view_clone_mul_sigmoid_split_transpose_view_49 = async_compile.triton('triton_poi_fused__unsafe_view_clone_mul_sigmoid_split_transpose_view_49', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_clone_mul_sigmoid_split_transpose_view_49', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 2097152}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_clone_mul_sigmoid_split_transpose_view_49(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 262144
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 2048)
    x1 = xindex // 2048
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (256*x1 + 32768*(x0 // 256) + ((x0 % 256))), None).to(tl.float32)
    tmp1 = tl.load(in_ptr1 + (256 + 512*(x0 // 256) + 4096*x1 + ((x0 % 256))), None).to(tl.float32)
    tmp2 = tl.sigmoid(tmp1)
    tmp3 = tmp0 * tmp2
    tl.store(out_ptr0 + (x2), tmp3, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/ac/cacn6ldaklxshw5kap3h53aoowtajd3lzpzqt7j4enqenytqiesr.py
# Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, output_12, hidden_states_21, down_proj_2, hidden_states_23, attn_output_4, hidden_states_27, float_26, pow_13, mean_12, add_52, rsqrt_18, output_21, float_27, add_53, output_22, hidden_states_28], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_52 => add_70
#   add_53 => add_71
#   attn_output_4 => view_212
#   down_proj_1 => view_127
#   down_proj_2 => view_190
#   float_26 => convert_element_type_144
#   float_27 => convert_element_type_145
#   hidden_states_15 => add_39
#   hidden_states_21 => add_55
#   hidden_states_23 => add_59
#   hidden_states_27 => add_69
#   hidden_states_28 => convert_element_type_146
#   mean_12 => mean_12
#   output_12 => view_184
#   output_21 => mul_96
#   output_22 => mul_97
#   pow_13 => pow_13
#   rsqrt_18 => rsqrt_18
# Graph fragment:
#   %add_35 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0" = PlaceHolder[target=add_35]
#   %mm_15 : Tensor "bf16[128, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_15]
#   %mm_20 : Tensor "bf16[128, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_20]
#   %mm_23 : Tensor "bf16[128, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_23]
#   %mm_27 : Tensor "bf16[128, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_27]
#   %add_69 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0" = PlaceHolder[target=add_69]
#   %buf189 : Tensor "f32[1, 128, 1][128, 1, 128]tnca:0" = PlaceHolder[target=buf189]
#   %arg53_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg53_1]
#   %view_127 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_15, [1, 128, 2048]), kwargs = {})
#   %add_39 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_35, %view_127), kwargs = {})
#   %view_184 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_20, [1, 128, 2048]), kwargs = {})
#   %add_55 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_39, %view_184), kwargs = {})
#   %view_190 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_23, [1, 128, 2048]), kwargs = {})
#   %add_59 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_55, %view_190), kwargs = {})
#   %view_212 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_27, [1, 128, 2048]), kwargs = {})
#   %add_69 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_59, %view_212), kwargs = {})
#   %convert_element_type_144 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_69, torch.float32), kwargs = {})
#   %pow_13 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_144, 2), kwargs = {})
#   %mean_12 : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_13, [-1], True), kwargs = {})
#   %add_70 : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_12, 1e-06), kwargs = {})
#   %rsqrt_18 : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_70,), kwargs = {})
#   %mul_96 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_144, %rsqrt_18), kwargs = {})
#   %convert_element_type_145 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg53_1, torch.float32), kwargs = {})
#   %add_71 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_145, 1.0), kwargs = {})
#   %mul_97 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_96, %add_71), kwargs = {})
#   %convert_element_type_146 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_97, torch.bfloat16), kwargs = {})
#   return %add_69,%buf189,%convert_element_type_146
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_50 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_50', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 128, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*bf16', 'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_50', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 7, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 4722688}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_50(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 128
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_out_ptr0, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr1, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr2, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor4 = tl.make_tensor_descriptor(in_ptr3, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp12 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp3 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp5 = tl.reshape(tma_descriptor3.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp7 = tl.reshape(tma_descriptor4.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp8 = tmp6 + tmp7
        tmp9 = tmp8.to(tl.float32)
        tmp10 = tmp9 * tmp9
        tmp11 = tl.broadcast_to(tmp10, [R0_BLOCK])
        tmp13 = _tmp12 + tmp11
        _tmp12 = tl.where(r0_mask, tmp13, _tmp12)
        tl.store(in_out_ptr0 + (r0_1 + 2048*x0), tmp8, r0_mask)
    tmp12 = triton_helpers.promote_to_tensor(tl.sum(_tmp12, 0))
    tma_descriptor5 = tl.make_tensor_descriptor(in_out_ptr0, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tl.debug_barrier()
        tmp14 = tl.reshape(tma_descriptor5.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp22 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp15 = tmp14.to(tl.float32)
        tmp16 = tl.full([1], 2048.0, tl.float32)
        tmp17 = (tmp12 / tmp16)
        tmp18 = tl.full([1], 1e-06, tl.float32)
        tmp19 = tmp17 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp15 * tmp20
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tl.full([1], 1.0, tl.float32)
        tmp25 = tmp23 + tmp24
        tmp26 = tmp21 * tmp25
        tmp27 = tmp26.to(tl.float32)
        tl.store(out_ptr1 + (r0_1 + 2048*x0), tmp27, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/xw/cxwvapin3ljoprxekxpf6w73ueorsoqbhnpbpiry66hrlhq2tlmz.py
# Topologically Sorted Source Nodes: [down_proj_23, hidden_states_179, float_158, pow_79, mean_78, add_330, rsqrt_114, output_138, float_159, add_331, output_139, hidden_states_180], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_330 => add_444
#   add_331 => add_445
#   down_proj_23 => view_1303
#   float_158 => convert_element_type_910
#   float_159 => convert_element_type_911
#   hidden_states_179 => add_443
#   hidden_states_180 => convert_element_type_912
#   mean_78 => mean_78
#   output_138 => mul_579
#   output_139 => mul_580
#   pow_79 => pow_79
#   rsqrt_114 => rsqrt_114
# Graph fragment:
#   %add_439 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0" = PlaceHolder[target=add_439]
#   %mm_185 : Tensor "bf16[128, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_185]
#   %buf1160 : Tensor "f32[1, 128, 1][128, 1, 128]tnca:0" = PlaceHolder[target=buf1160]
#   %arg322_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg322_1]
#   %view_1303 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_185, [1, 128, 2048]), kwargs = {})
#   %add_443 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_439, %view_1303), kwargs = {})
#   %convert_element_type_910 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_443, torch.float32), kwargs = {})
#   %pow_79 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_910, 2), kwargs = {})
#   %mean_78 : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_79, [-1], True), kwargs = {})
#   %add_444 : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_78, 1e-06), kwargs = {})
#   %rsqrt_114 : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_444,), kwargs = {})
#   %mul_579 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_910, %rsqrt_114), kwargs = {})
#   %convert_element_type_911 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg322_1, torch.float32), kwargs = {})
#   %add_445 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_911, 1.0), kwargs = {})
#   %mul_580 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_579, %add_445), kwargs = {})
#   %convert_element_type_912 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_580, torch.bfloat16), kwargs = {})
#   return %buf1160,%convert_element_type_912
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_51 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_51', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 128, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*bf16', 'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_51', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 2101248}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_51(in_out_ptr0, in_ptr0, in_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 128
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_out_ptr0, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp6 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp3 * tmp3
        tmp5 = tl.broadcast_to(tmp4, [R0_BLOCK])
        tmp7 = _tmp6 + tmp5
        _tmp6 = tl.where(r0_mask, tmp7, _tmp6)
    tmp6 = triton_helpers.promote_to_tensor(tl.sum(_tmp6, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_out_ptr0, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr0, shape=[128, 2048], strides=[2048, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp8 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp9 = tl.reshape(tma_descriptor3.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp18 = tl.load(in_ptr1 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp10 = tmp8 + tmp9
        tmp11 = tmp10.to(tl.float32)
        tmp12 = tl.full([1], 2048.0, tl.float32)
        tmp13 = (tmp6 / tmp12)
        tmp14 = tl.full([1], 1e-06, tl.float32)
        tmp15 = tmp13 + tmp14
        tmp16 = libdevice.rsqrt(tmp15)
        tmp17 = tmp11 * tmp16
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tl.full([1], 1.0, tl.float32)
        tmp21 = tmp19 + tmp20
        tmp22 = tmp17 * tmp21
        tmp23 = tmp22.to(tl.float32)
        tl.store(in_out_ptr0 + (r0_1 + 2048*x0), tmp23, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-std/prefill-nocache/inductor_cache/c2/cc2sczy3ha2wmxevspu3nh4ic7mvpafcazspklznuobudeo4fpaa.py
# Topologically Sorted Source Nodes: [down_proj_23, hidden_states_179, float_158, pow_79, mean_78, add_330, rsqrt_114, output_138, float_159, add_331, output_139, hidden_states_180, logits], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   add_330 => add_444
#   add_331 => add_445
#   down_proj_23 => view_1303
#   float_158 => convert_element_type_910
#   float_159 => convert_element_type_911
#   hidden_states_179 => add_443
#   hidden_states_180 => convert_element_type_912
#   logits => mm_186, permute_450, view_1304
#   mean_78 => mean_78
#   output_138 => mul_579
#   output_139 => mul_580
#   pow_79 => pow_79
#   rsqrt_114 => rsqrt_114
# Graph fragment:
#   %convert_element_type_912 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0" = PlaceHolder[target=convert_element_type_912]
#   %arg1_1 : Tensor "bf16[248320, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %view_1303 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_185, [1, 128, 2048]), kwargs = {})
#   %add_443 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_439, %view_1303), kwargs = {})
#   %convert_element_type_910 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_443, torch.float32), kwargs = {})
#   %pow_79 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_910, 2), kwargs = {})
#   %mean_78 : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_79, [-1], True), kwargs = {})
#   %add_444 : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_78, 1e-06), kwargs = {})
#   %rsqrt_114 : Tensor "f32[1, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_444,), kwargs = {})
#   %mul_579 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_910, %rsqrt_114), kwargs = {})
#   %convert_element_type_911 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg322_1, torch.float32), kwargs = {})
#   %add_445 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_911, 1.0), kwargs = {})
#   %mul_580 : Tensor "f32[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_579, %add_445), kwargs = {})
#   %convert_element_type_912 : Tensor "bf16[1, 128, 2048][262144, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_580, torch.bfloat16), kwargs = {})
#   %view_1304 : Tensor "bf16[128, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_912, [128, 2048]), kwargs = {})
#   %permute_450 : Tensor "bf16[2048, 248320][1, 2048]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg1_1, [1, 0]), kwargs = {})
#   %mm_186 : Tensor "bf16[128, 248320][248320, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_1304, %permute_450), kwargs = {})
#   return %mm_186
triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_t_view_52 = async_compile.triton('triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_t_view_52', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*bf16', 'arg_B': '*bf16', 'out_ptr0': '*bf16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_t_view_52', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_t_view_52(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 128
    N = 248320
    K = 2048
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 2048
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2048

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2048*idx_m
        a = tl.load(A + (xindex))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 248320*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2048*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 248320*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1, arg123_1, arg124_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg132_1, arg133_1, arg134_1, arg135_1, arg136_1, arg137_1, arg138_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg146_1, arg147_1, arg148_1, arg149_1, arg150_1, arg151_1, arg152_1, arg153_1, arg154_1, arg155_1, arg156_1, arg157_1, arg158_1, arg159_1, arg160_1, arg161_1, arg162_1, arg163_1, arg164_1, arg165_1, arg166_1, arg167_1, arg168_1, arg169_1, arg170_1, arg171_1, arg172_1, arg173_1, arg174_1, arg175_1, arg176_1, arg177_1, arg178_1, arg179_1, arg180_1, arg181_1, arg182_1, arg183_1, arg184_1, arg185_1, arg186_1, arg187_1, arg188_1, arg189_1, arg190_1, arg191_1, arg192_1, arg193_1, arg194_1, arg195_1, arg196_1, arg197_1, arg198_1, arg199_1, arg200_1, arg201_1, arg202_1, arg203_1, arg204_1, arg205_1, arg206_1, arg207_1, arg208_1, arg209_1, arg210_1, arg211_1, arg212_1, arg213_1, arg214_1, arg215_1, arg216_1, arg217_1, arg218_1, arg219_1, arg220_1, arg221_1, arg222_1, arg223_1, arg224_1, arg225_1, arg226_1, arg227_1, arg228_1, arg229_1, arg230_1, arg231_1, arg232_1, arg233_1, arg234_1, arg235_1, arg236_1, arg237_1, arg238_1, arg239_1, arg240_1, arg241_1, arg242_1, arg243_1, arg244_1, arg245_1, arg246_1, arg247_1, arg248_1, arg249_1, arg250_1, arg251_1, arg252_1, arg253_1, arg254_1, arg255_1, arg256_1, arg257_1, arg258_1, arg259_1, arg260_1, arg261_1, arg262_1, arg263_1, arg264_1, arg265_1, arg266_1, arg267_1, arg268_1, arg269_1, arg270_1, arg271_1, arg272_1, arg273_1, arg274_1, arg275_1, arg276_1, arg277_1, arg278_1, arg279_1, arg280_1, arg281_1, arg282_1, arg283_1, arg284_1, arg285_1, arg286_1, arg287_1, arg288_1, arg289_1, arg290_1, arg291_1, arg292_1, arg293_1, arg294_1, arg295_1, arg296_1, arg297_1, arg298_1, arg299_1, arg300_1, arg301_1, arg302_1, arg303_1, arg304_1, arg305_1, arg306_1, arg307_1, arg308_1, arg309_1, arg310_1, arg311_1, arg312_1, arg313_1, arg314_1, arg315_1, arg316_1, arg317_1, arg318_1, arg319_1, arg320_1, arg321_1, arg322_1 = args
        args.clear()
        assert_size_stride_grouped((arg0_1, arg1_1, arg4_1), ((1, 128), (248320, 2048), (2048, )), ((128, 1), (2048, 1), (1, )), 'input')
        buf1 = empty_strided((1, 128, 2048), (262144, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [inputs_embeds, float_2, pow_1, mean, add, rsqrt, output, float_3, add_1, output_1, hidden_states], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0.run(arg0_1, arg1_1, arg4_1, buf1, 128, 2048, stream=raw_stream0)
        del arg4_1
        assert_size_stride(arg5_1, (6144, 2048), (2048, 1), 'input')
        buf2 = empty_strided((128, 6144), (6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [inputs_embeds, float_2, pow_1, mean, add, rsqrt, output, float_3, add_1, output_1, hidden_states, mixed_qkv], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf1, arg5_1, buf2, 3072, 1, 1, stream=raw_stream0)
        del arg5_1
        assert_size_stride(arg9_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf3 = empty_strided((1, 6144, 128), (786432, 1, 6144), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [mixed_qkv, mixed_qkv_1, conv1d, squeeze, unsqueeze, out, out_1], Original ATen: [aten._unsafe_view, aten.transpose, aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_convolution_silu_slice_squeeze_transpose_unsqueeze_2.run(buf2, arg9_1, buf3, 786432, stream=raw_stream0)
        del arg9_1
        buf4 = empty_strided((1, 16, 128, 128), (262144, 128, 2048, 1), device='tnca', dtype=torch.float32)
        buf5 = empty_strided((1, 16, 128, 1), (2048, 1, 16, 2048), device='tnca', dtype=torch.float32)
        buf15 = empty_strided((1, 16, 128, 128), (262144, 16384, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [out_1, mixed_qkv_3, split, query_1, transpose_2, query_2, mul_6, sum_1, add_3, inv_norm, query_3, query_4], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_3.run(buf3, buf4, buf5, buf15, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg8_1, (16, 2048), (2048, 1), 'input')
        buf6 = empty_strided((128, 16), (16, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [a], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf1, arg8_1, buf6, 8, 1, 1, stream=raw_stream0)
        del arg8_1
        assert_size_stride(arg10_1, (16, ), (1, ), 'input')
        buf7 = empty_strided((16, ), (1, ), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [exp, neg], Original ATen: [aten.exp, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_neg_5.run(arg10_1, buf7, 16, stream=raw_stream0)
        del arg10_1
        assert_size_stride(arg11_1, (16, ), (1, ), 'input')
        buf8 = empty_strided((1, 16, 2, 64), (2048, 128, 64, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [exp, neg, a, float_5, add_2, softplus, g, transpose_6, decay_2, cum_decay], Original ATen: [aten.exp, aten.neg, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.view, aten.cumsum]
        workspace_0 = empty_strided((256, ), (1, ), device='tnca', dtype=torch.uint8)
        workspace_0.zero_()
        raw_stream0 = get_raw_stream(0)
        triton_spl_fused__to_copy__unsafe_view_add_cumsum_exp_mul_neg_softplus_transpose_view_6.run(buf7, buf6, arg11_1, buf8, workspace_0, 32, 64, stream=raw_stream0)
        del arg11_1
        buf9 = empty_strided((1, 16, 2, 64), (2048, 128, 64, 1), device='tnca', dtype=torch.float32)
        buf26 = empty_strided((1, 16, 2, 64), (2048, 128, 64, 1), device='tnca', dtype=torch.float32)
        buf34 = empty_strided((1, 16, 2, 64), (2048, 128, 64, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [exp_3, exp_2, getitem_15, sub_1, exp_4], Original ATen: [aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_slice_sub_7.run(buf8, buf9, buf26, buf34, 2048, stream=raw_stream0)
        buf10 = empty_strided((1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [add_3, inv_norm, query_3, query_4, query_6, exp_3, unsqueeze_6, query_7], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_exp_mul_rsqrt_unsqueeze_view_8.run(buf4, buf5, buf9, buf10, 262144, stream=raw_stream0)
        buf11 = reinterpret_tensor(buf4, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf4  # reuse
        # Topologically Sorted Source Nodes: [last_recurrent_state], Original ATen: [aten.zeros]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_zeros_9.run(buf11, 262144, stream=raw_stream0)
        buf12 = empty_strided((16, 64, 128), (8192, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [add_3, inv_norm, query_3, query_4, query_6, exp_3, unsqueeze_6, query_7, getitem_20, inter_chunk_attn, last_recurrent_state], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze, aten.select, aten.zeros, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_unsqueeze_view_zeros_10.run(buf10, buf11, buf12, 32, 16, 1, stream=raw_stream0)
        buf13 = empty_strided((1, 16, 128, 128), (262144, 128, 2048, 1), device='tnca', dtype=torch.float32)
        buf16 = empty_strided((1, 16, 128, 128), (262144, 16384, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [out_1, mixed_qkv_3, split, key_1, transpose_3, key_2, mul_8, sum_2, add_4, inv_norm_1, key_3], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_11.run(buf3, buf13, buf16, 2048, 128, stream=raw_stream0)
        buf17 = empty_strided((32, 64, 64), (4096, 64, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [add_3, inv_norm, query_3, query_4, query_6, matmul_1, add_4, inv_norm_1, key_3, key_5, transpose_8], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_mul_rsqrt_transpose_view_12.run(buf15, buf16, buf17, 16, 32, 1, stream=raw_stream0)
        assert_size_stride(arg7_1, (16, 2048), (2048, 1), 'input')
        buf19 = buf6; del buf6  # reuse
        # Topologically Sorted Source Nodes: [b], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf1, arg7_1, buf19, 8, 1, 1, stream=raw_stream0)
        del arg7_1
        buf20 = reinterpret_tensor(buf9, (1, 16, 128), (2048, 128, 1), 0); del buf9  # reuse
        # Topologically Sorted Source Nodes: [b, beta, transpose_5, beta_1], Original ATen: [aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_sigmoid_transpose_13.run(buf19, buf20, 16, 128, stream=raw_stream0)
        buf21 = buf15; del buf15  # reuse
        buf27 = reinterpret_tensor(buf13, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf13  # reuse
        buf35 = empty_strided((1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), device='tnca', dtype=torch.float32)
        buf24 = empty_strided((1, 16, 128, 128), (262144, 16384, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [out_1, mixed_qkv_3, split, add_4, inv_norm_1, key_3, key_5, unsqueeze_2, k_beta, k_beta_1, value_1, transpose_4, value_2, unsqueeze_1, v_beta, exp_2, unsqueeze_5, decayed_k_beta, getitem_15, sub_1, exp_4, unsqueeze_7, key_6], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.view, aten.unsqueeze, aten._to_copy, aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_exp_mul_rsqrt_silu_slice_split_with_sizes_sub_transpose_unsqueeze_view_14.run(buf16, buf20, buf26, buf34, buf3, buf21, buf27, buf35, buf24, 262144, stream=raw_stream0)
        buf23 = empty_strided((1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), device='tnca', dtype=torch.float32)
        buf30 = empty_strided((1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [add_4, inv_norm_1, key_3, key_5, matmul_1, strictly_upper_mask, ones, pairwise_decay_1, unsqueeze_3, unsqueeze_4, pairwise_decay, pairwise_decay_2, intra_chunk_attn, unsqueeze_2, k_beta, k_beta_1, matmul, transpose_7, ut_system], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.triu, aten.ones, aten.masked_fill, aten.unsqueeze, aten.sub, aten.exp, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_masked_fill_mul_ones_rsqrt_sub_transpose_triu_unsqueeze_view_15.run(buf21, buf16, buf8, buf17, buf23, buf30, 16, 32, 1, stream=raw_stream0)
        del buf16
        del buf21
        # Topologically Sorted Source Nodes: [out_1, mixed_qkv_3, split, value_1, transpose_4, value_2, unsqueeze_1, v_beta, v_beta_1, new_values], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.unsqueeze, aten.mul, aten.linalg_solve_triangular]
        buf25 = torch.ops.aten.linalg_solve_triangular.default(buf23, reinterpret_tensor(buf24, (1, 16, 2, 64, 128), (0, 16384, 8192, 128, 1), 0), upper=False, unitriangular=True)
        assert_tensor_metadata(buf25, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf25, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        # Topologically Sorted Source Nodes: [unsqueeze_2, k_beta, k_beta_1, exp_2, unsqueeze_5, decayed_k_beta, k_cumdecay], Original ATen: [aten.unsqueeze, aten.mul, aten.view, aten.exp, aten.linalg_solve_triangular]
        buf28 = torch.ops.aten.linalg_solve_triangular.default(buf23, buf27, upper=False, unitriangular=True)
        assert_tensor_metadata(buf28, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf28, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        buf31 = reinterpret_tensor(buf23, (1, 16, 64, 128), (131072, 8192, 128, 1), 0); del buf23  # reuse
        # Topologically Sorted Source Nodes: [getitem_18, getitem_19, matmul_2, v_new], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_16.run(buf28, buf11, buf25, buf31, 32, 16, 1, stream=raw_stream0)
        buf32 = reinterpret_tensor(buf17, (16, 64, 128), (8192, 128, 1), 0); del buf17  # reuse
        # Topologically Sorted Source Nodes: [matmul_1, intra_chunk_attn, getitem_21, matmul_4, getitem_18, matmul_2, v_new], Original ATen: [aten.view, aten.mul, aten.select, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_mul_select_sub_view_17.run(buf30, buf31, buf32, 32, 16, 1, stream=raw_stream0)
        buf33 = empty_strided((1, 16, 2), (32, 2, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [getitem_16, exp_5], Original ATen: [aten.select, aten.exp]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_select_18.run(buf8, buf33, 32, stream=raw_stream0)
        buf37 = buf11; del buf11  # reuse
        # Topologically Sorted Source Nodes: [add_4, inv_norm_1, key_3, key_5, getitem_16, exp_5, chunk_decay, getitem_22, mul_18, getitem_15, sub_1, exp_4, unsqueeze_7, key_6, getitem_23, transpose_9, matmul_5, last_recurrent_state_1], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.select, aten.exp, aten.unsqueeze, aten.slice, aten.sub, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_slice_sub_transpose_unsqueeze_view_19.run(buf35, buf31, buf33, buf37, 64, 16, 1, stream=raw_stream0)
        buf38 = reinterpret_tensor(buf31, (16, 64, 128), (8192, 128, 1), 0); del buf31  # reuse
        # Topologically Sorted Source Nodes: [getitem_26, inter_chunk_attn_1, getitem_16, exp_5, chunk_decay, getitem_22, mul_18, matmul_5, last_recurrent_state_1], Original ATen: [aten.select, aten.view, aten.exp, aten.unsqueeze, aten.mul, aten.add, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_select_unsqueeze_view_20.run(buf10, buf37, buf38, 32, 16, 1, stream=raw_stream0)
        buf40 = empty_strided((1, 16, 64, 128), (131072, 8192, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [getitem_24, getitem_25, matmul_6, v_new_1], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_21.run(buf28, buf37, buf25, buf40, 32, 16, 1, stream=raw_stream0)
        buf41 = empty_strided((16, 64, 128), (8192, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [getitem_27, matmul_8, getitem_24, matmul_6, v_new_1], Original ATen: [aten.select, aten.view, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_22.run(buf30, buf40, buf41, 32, 16, 1, stream=raw_stream0)
        assert_size_stride(arg6_1, (2048, 2048), (2048, 1), 'input')
        buf43 = empty_strided((128, 2048), (2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [z], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf1, arg6_1, buf43, 1024, 1, 1, stream=raw_stream0)
        del arg6_1
        assert_size_stride(arg12_1, (128, ), (1, ), 'input')
        buf44 = reinterpret_tensor(buf43, (2048, 128), (128, 1), 0); del buf43  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out, setitem_4, inter_chunk_attn, matmul_4, add_5, setitem_5, inter_chunk_attn_1, matmul_8, add_7, core_attn_out_1, transpose_11, core_attn_out_3, core_attn_out_4, hidden_states_1, pow_2, variance, add_9, rsqrt_3, hidden_states_2, to_12, hidden_states_3, z, z_1, z_2, to_13, silu_1, hidden_states_4, core_attn_out_5], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_copy_mean_mul_pow_rsqrt_select_silu_transpose_view_zeros_like_24.run(buf44, buf38, buf41, buf12, buf32, arg12_1, 2048, 128, stream=raw_stream0)
        del arg12_1
        assert_size_stride(arg13_1, (2048, 2048), (2048, 1), 'input')
        buf45 = reinterpret_tensor(buf1, (128, 2048), (2048, 1), 0); del buf1  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out, setitem_4, inter_chunk_attn, matmul_4, add_5, setitem_5, inter_chunk_attn_1, matmul_8, add_7, core_attn_out_1, transpose_11, core_attn_out_3, core_attn_out_4, hidden_states_1, pow_2, variance, add_9, rsqrt_3, hidden_states_2, to_12, hidden_states_3, z, z_1, z_2, to_13, silu_1, hidden_states_4, core_attn_out_5, core_attn_out_6, output_2], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf44, arg13_1, buf45, 1024, 1, 1, stream=raw_stream0)
        del arg13_1
        assert_size_stride(arg14_1, (2048, ), (1, ), 'input')
        buf47 = reinterpret_tensor(buf44, (1, 128, 2048), (262144, 2048, 1), 0); del buf44  # reuse
        # Topologically Sorted Source Nodes: [inputs_embeds, output_2, hidden_states_5, float_6, pow_3, mean_2, add_11, rsqrt_4, output_3, float_7, add_12, output_4, hidden_states_6], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_25.run(arg0_1, arg1_1, buf45, arg14_1, buf47, 128, 2048, stream=raw_stream0)
        del arg14_1
        assert_size_stride(arg15_1, (6144, 2048), (2048, 1), 'input')
        buf48 = buf2; del buf2  # reuse
        # Topologically Sorted Source Nodes: [linear_5], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf47, arg15_1, buf48, 3072, 1, 1, stream=raw_stream0)
        del arg15_1
        assert_size_stride(arg16_1, (6144, 2048), (2048, 1), 'input')
        buf50 = empty_strided((1, 128, 6144), (786432, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [linear_5, silu_2, linear_6, mul_25], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_26.run(buf47, arg16_1, buf48, buf50, 3072, 1, 1, stream=raw_stream0)
        del arg16_1
        assert_size_stride(arg17_1, (2048, 6144), (6144, 1), 'input')
        buf51 = reinterpret_tensor(buf47, (128, 2048), (2048, 1), 0); del buf47  # reuse
        # Topologically Sorted Source Nodes: [linear_5, silu_2, linear_6, mul_25, down_proj], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_27.run(buf50, arg17_1, buf51, 1024, 1, 1, stream=raw_stream0)
        del arg17_1
        assert_size_stride(arg18_1, (2048, ), (1, ), 'input')
        buf53 = empty_strided((1, 128, 2048), (262144, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [inputs_embeds, output_2, hidden_states_5, down_proj, hidden_states_7, float_8, pow_4, mean_3, add_14, rsqrt_5, output_5, float_9, add_15, output_6, hidden_states_8], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_28.run(arg0_1, arg1_1, buf45, buf51, arg18_1, buf53, 128, 2048, stream=raw_stream0)
        del arg18_1
        assert_size_stride(arg19_1, (6144, 2048), (2048, 1), 'input')
        buf54 = reinterpret_tensor(buf50, (128, 6144), (6144, 1), 0); del buf50  # reuse
        # Topologically Sorted Source Nodes: [mixed_qkv_4], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf53, arg19_1, buf54, 3072, 1, 1, stream=raw_stream0)
        del arg19_1
        assert_size_stride(arg23_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf55 = buf3; del buf3  # reuse
        # Topologically Sorted Source Nodes: [mixed_qkv_4, mixed_qkv_5, conv1d_1, squeeze_1, unsqueeze_8, out_2, out_3], Original ATen: [aten._unsafe_view, aten.transpose, aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_convolution_silu_slice_squeeze_transpose_unsqueeze_2.run(buf54, arg23_1, buf55, 786432, stream=raw_stream0)
        del arg23_1
        buf56 = reinterpret_tensor(buf37, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf37  # reuse
        buf57 = reinterpret_tensor(buf8, (1, 16, 128, 1), (2048, 1, 16, 2048), 0); del buf8  # reuse
        buf67 = reinterpret_tensor(buf28, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf28  # reuse
        # Topologically Sorted Source Nodes: [out_3, mixed_qkv_7, split_1, query_9, transpose_14, query_10, mul_29, sum_3, add_17, inv_norm_2, query_11, query_12], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_3.run(buf55, buf56, buf57, buf67, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg22_1, (16, 2048), (2048, 1), 'input')
        buf58 = buf19; del buf19  # reuse
        # Topologically Sorted Source Nodes: [a_1], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf53, arg22_1, buf58, 8, 1, 1, stream=raw_stream0)
        del arg22_1
        assert_size_stride(arg24_1, (16, ), (1, ), 'input')
        buf59 = buf7; del buf7  # reuse
        # Topologically Sorted Source Nodes: [exp_6, neg_1], Original ATen: [aten.exp, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_neg_5.run(arg24_1, buf59, 16, stream=raw_stream0)
        del arg24_1
        assert_size_stride(arg25_1, (16, ), (1, ), 'input')
        buf60 = buf34; del buf34  # reuse
        # Topologically Sorted Source Nodes: [exp_6, neg_1, a_1, float_11, add_16, softplus_1, g_1, transpose_18, decay_5, cum_decay_1], Original ATen: [aten.exp, aten.neg, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.view, aten.cumsum]
        workspace_1 = workspace_0; del workspace_0  # reuse
        workspace_1.zero_()
        raw_stream0 = get_raw_stream(0)
        triton_spl_fused__to_copy__unsafe_view_add_cumsum_exp_mul_neg_softplus_transpose_view_6.run(buf59, buf58, arg25_1, buf60, workspace_1, 32, 64, stream=raw_stream0)
        del arg25_1
        buf61 = buf26; del buf26  # reuse
        buf78 = reinterpret_tensor(buf20, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf20  # reuse
        buf86 = reinterpret_tensor(buf5, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf5  # reuse
        # Topologically Sorted Source Nodes: [exp_9, exp_8, getitem_35, sub_5, exp_10], Original ATen: [aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_slice_sub_7.run(buf60, buf61, buf78, buf86, 2048, stream=raw_stream0)
        buf62 = reinterpret_tensor(buf25, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf25  # reuse
        # Topologically Sorted Source Nodes: [add_17, inv_norm_2, query_11, query_12, query_14, exp_9, unsqueeze_14, query_15], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_exp_mul_rsqrt_unsqueeze_view_8.run(buf56, buf57, buf61, buf62, 262144, stream=raw_stream0)
        buf63 = reinterpret_tensor(buf56, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf56  # reuse
        # Topologically Sorted Source Nodes: [last_recurrent_state_3], Original ATen: [aten.zeros]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_zeros_9.run(buf63, 262144, stream=raw_stream0)
        buf64 = buf41; del buf41  # reuse
        # Topologically Sorted Source Nodes: [add_17, inv_norm_2, query_11, query_12, query_14, exp_9, unsqueeze_14, query_15, getitem_40, inter_chunk_attn_2, last_recurrent_state_3], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze, aten.select, aten.zeros, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_unsqueeze_view_zeros_10.run(buf62, buf63, buf64, 32, 16, 1, stream=raw_stream0)
        buf65 = reinterpret_tensor(buf10, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf10  # reuse
        buf68 = reinterpret_tensor(buf35, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf35  # reuse
        # Topologically Sorted Source Nodes: [out_3, mixed_qkv_7, split_1, key_8, transpose_15, key_9, mul_31, sum_4, add_18, inv_norm_3, key_10], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_11.run(buf55, buf65, buf68, 2048, 128, stream=raw_stream0)
        buf69 = reinterpret_tensor(buf38, (32, 64, 64), (4096, 64, 1), 0); del buf38  # reuse
        # Topologically Sorted Source Nodes: [add_17, inv_norm_2, query_11, query_12, query_14, matmul_11, add_18, inv_norm_3, key_10, key_12, transpose_20], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_mul_rsqrt_transpose_view_12.run(buf67, buf68, buf69, 16, 32, 1, stream=raw_stream0)
        assert_size_stride(arg21_1, (16, 2048), (2048, 1), 'input')
        buf71 = buf58; del buf58  # reuse
        # Topologically Sorted Source Nodes: [b_1], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf53, arg21_1, buf71, 8, 1, 1, stream=raw_stream0)
        del arg21_1
        buf72 = reinterpret_tensor(buf61, (1, 16, 128), (2048, 128, 1), 0); del buf61  # reuse
        # Topologically Sorted Source Nodes: [b_1, beta_3, transpose_17, beta_4], Original ATen: [aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_sigmoid_transpose_13.run(buf71, buf72, 16, 128, stream=raw_stream0)
        buf73 = buf67; del buf67  # reuse
        buf79 = reinterpret_tensor(buf65, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf65  # reuse
        buf87 = buf27; del buf27  # reuse
        buf76 = buf24; del buf24  # reuse
        # Topologically Sorted Source Nodes: [out_3, mixed_qkv_7, split_1, add_18, inv_norm_3, key_10, key_12, unsqueeze_10, k_beta_2, k_beta_3, value_5, transpose_16, value_6, unsqueeze_9, v_beta_2, exp_8, unsqueeze_13, decayed_k_beta_1, getitem_35, sub_5, exp_10, unsqueeze_15, key_13], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.view, aten.unsqueeze, aten._to_copy, aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_exp_mul_rsqrt_silu_slice_split_with_sizes_sub_transpose_unsqueeze_view_14.run(buf68, buf72, buf78, buf86, buf55, buf73, buf79, buf87, buf76, 262144, stream=raw_stream0)
        buf75 = reinterpret_tensor(buf32, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf32  # reuse
        buf82 = reinterpret_tensor(buf12, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf12  # reuse
        # Topologically Sorted Source Nodes: [add_18, inv_norm_3, key_10, key_12, matmul_11, strictly_upper_mask_1, ones_1, pairwise_decay_4, unsqueeze_11, unsqueeze_12, pairwise_decay_3, pairwise_decay_5, intra_chunk_attn_1, unsqueeze_10, k_beta_2, k_beta_3, matmul_10, transpose_19, ut_system_1], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.triu, aten.ones, aten.masked_fill, aten.unsqueeze, aten.sub, aten.exp, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_masked_fill_mul_ones_rsqrt_sub_transpose_triu_unsqueeze_view_15.run(buf73, buf68, buf60, buf69, buf75, buf82, 16, 32, 1, stream=raw_stream0)
        del buf68
        del buf73
        # Topologically Sorted Source Nodes: [out_3, mixed_qkv_7, split_1, value_5, transpose_16, value_6, unsqueeze_9, v_beta_2, v_beta_3, new_values_1], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.unsqueeze, aten.mul, aten.linalg_solve_triangular]
        buf77 = torch.ops.aten.linalg_solve_triangular.default(buf75, reinterpret_tensor(buf76, (1, 16, 2, 64, 128), (0, 16384, 8192, 128, 1), 0), upper=False, unitriangular=True)
        assert_tensor_metadata(buf77, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf77, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        # Topologically Sorted Source Nodes: [unsqueeze_10, k_beta_2, k_beta_3, exp_8, unsqueeze_13, decayed_k_beta_1, k_cumdecay_1], Original ATen: [aten.unsqueeze, aten.mul, aten.view, aten.exp, aten.linalg_solve_triangular]
        buf80 = torch.ops.aten.linalg_solve_triangular.default(buf75, buf79, upper=False, unitriangular=True)
        assert_tensor_metadata(buf80, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf80, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        buf83 = reinterpret_tensor(buf75, (1, 16, 64, 128), (131072, 8192, 128, 1), 0); del buf75  # reuse
        # Topologically Sorted Source Nodes: [getitem_38, getitem_39, matmul_12, v_new_2], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_16.run(buf80, buf63, buf77, buf83, 32, 16, 1, stream=raw_stream0)
        buf84 = reinterpret_tensor(buf69, (16, 64, 128), (8192, 128, 1), 0); del buf69  # reuse
        # Topologically Sorted Source Nodes: [matmul_11, intra_chunk_attn_1, getitem_41, matmul_14, getitem_38, matmul_12, v_new_2], Original ATen: [aten.view, aten.mul, aten.select, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_mul_select_sub_view_17.run(buf82, buf83, buf84, 32, 16, 1, stream=raw_stream0)
        buf85 = buf33; del buf33  # reuse
        # Topologically Sorted Source Nodes: [getitem_36, exp_11], Original ATen: [aten.select, aten.exp]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_select_18.run(buf60, buf85, 32, stream=raw_stream0)
        buf89 = buf63; del buf63  # reuse
        # Topologically Sorted Source Nodes: [add_18, inv_norm_3, key_10, key_12, getitem_36, exp_11, chunk_decay_1, getitem_42, mul_41, getitem_35, sub_5, exp_10, unsqueeze_15, key_13, getitem_43, transpose_21, matmul_15, last_recurrent_state_4], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.select, aten.exp, aten.unsqueeze, aten.slice, aten.sub, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_slice_sub_transpose_unsqueeze_view_19.run(buf87, buf83, buf85, buf89, 64, 16, 1, stream=raw_stream0)
        buf90 = reinterpret_tensor(buf83, (16, 64, 128), (8192, 128, 1), 0); del buf83  # reuse
        # Topologically Sorted Source Nodes: [getitem_46, inter_chunk_attn_3, getitem_36, exp_11, chunk_decay_1, getitem_42, mul_41, matmul_15, last_recurrent_state_4], Original ATen: [aten.select, aten.view, aten.exp, aten.unsqueeze, aten.mul, aten.add, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_select_unsqueeze_view_20.run(buf62, buf89, buf90, 32, 16, 1, stream=raw_stream0)
        buf92 = buf40; del buf40  # reuse
        # Topologically Sorted Source Nodes: [getitem_44, getitem_45, matmul_16, v_new_3], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_21.run(buf80, buf89, buf77, buf92, 32, 16, 1, stream=raw_stream0)
        buf93 = reinterpret_tensor(buf30, (16, 64, 128), (8192, 128, 1), 0); del buf30  # reuse
        # Topologically Sorted Source Nodes: [getitem_47, matmul_18, getitem_44, matmul_16, v_new_3], Original ATen: [aten.select, aten.view, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_22.run(buf82, buf92, buf93, 32, 16, 1, stream=raw_stream0)
        assert_size_stride(arg20_1, (2048, 2048), (2048, 1), 'input')
        buf95 = empty_strided((128, 2048), (2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [z_3], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf53, arg20_1, buf95, 1024, 1, 1, stream=raw_stream0)
        del arg20_1
        assert_size_stride(arg26_1, (128, ), (1, ), 'input')
        buf96 = reinterpret_tensor(buf95, (2048, 128), (128, 1), 0); del buf95  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_7, setitem_6, inter_chunk_attn_2, matmul_14, add_19, setitem_7, inter_chunk_attn_3, matmul_18, add_21, core_attn_out_8, transpose_23, core_attn_out_10, core_attn_out_11, hidden_states_9, pow_5, variance_1, add_23, rsqrt_8, hidden_states_10, to_24, hidden_states_11, z_3, z_4, z_5, to_25, silu_4, hidden_states_12, core_attn_out_12], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_copy_mean_mul_pow_rsqrt_select_silu_transpose_view_zeros_like_24.run(buf96, buf90, buf93, buf64, buf84, arg26_1, 2048, 128, stream=raw_stream0)
        del arg26_1
        assert_size_stride(arg27_1, (2048, 2048), (2048, 1), 'input')
        buf97 = reinterpret_tensor(buf53, (128, 2048), (2048, 1), 0); del buf53  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_7, setitem_6, inter_chunk_attn_2, matmul_14, add_19, setitem_7, inter_chunk_attn_3, matmul_18, add_21, core_attn_out_8, transpose_23, core_attn_out_10, core_attn_out_11, hidden_states_9, pow_5, variance_1, add_23, rsqrt_8, hidden_states_10, to_24, hidden_states_11, z_3, z_4, z_5, to_25, silu_4, hidden_states_12, core_attn_out_12, core_attn_out_13, output_7], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf96, arg27_1, buf97, 1024, 1, 1, stream=raw_stream0)
        del arg27_1
        assert_size_stride(arg28_1, (2048, ), (1, ), 'input')
        buf98 = reinterpret_tensor(buf45, (1, 128, 2048), (262144, 2048, 1), 0); del buf45  # reuse
        buf100 = reinterpret_tensor(buf96, (1, 128, 2048), (262144, 2048, 1), 0); del buf96  # reuse
        # Topologically Sorted Source Nodes: [inputs_embeds, output_2, hidden_states_5, down_proj, hidden_states_7, output_7, hidden_states_13, float_12, pow_6, mean_5, add_25, rsqrt_9, output_8, float_13, add_26, output_9, hidden_states_14], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_29.run(buf98, arg0_1, arg1_1, buf51, buf97, arg28_1, buf100, 128, 2048, stream=raw_stream0)
        del arg0_1
        del arg28_1
        assert_size_stride(arg29_1, (6144, 2048), (2048, 1), 'input')
        buf101 = buf54; del buf54  # reuse
        # Topologically Sorted Source Nodes: [float_12, pow_6, mean_5, add_25, rsqrt_9, output_8, float_13, add_26, output_9, hidden_states_14, linear_13], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf100, arg29_1, buf101, 3072, 1, 1, stream=raw_stream0)
        del arg29_1
        assert_size_stride(arg30_1, (6144, 2048), (2048, 1), 'input')
        buf103 = reinterpret_tensor(buf48, (1, 128, 6144), (786432, 6144, 1), 0); del buf48  # reuse
        # Topologically Sorted Source Nodes: [linear_13, silu_5, linear_14, mul_48], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_26.run(buf100, arg30_1, buf101, buf103, 3072, 1, 1, stream=raw_stream0)
        del arg30_1
        assert_size_stride(arg31_1, (2048, 6144), (6144, 1), 'input')
        buf104 = reinterpret_tensor(buf100, (128, 2048), (2048, 1), 0); del buf100  # reuse
        # Topologically Sorted Source Nodes: [linear_13, silu_5, linear_14, mul_48, down_proj_1], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_27.run(buf103, arg31_1, buf104, 1024, 1, 1, stream=raw_stream0)
        del arg31_1
        assert_size_stride(arg32_1, (2048, ), (1, ), 'input')
        buf106 = reinterpret_tensor(buf97, (1, 128, 2048), (262144, 2048, 1), 0); del buf97  # reuse
        # Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, float_14, pow_7, mean_6, add_28, rsqrt_10, output_10, float_15, add_29, output_11, hidden_states_16], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_30.run(buf98, buf104, arg32_1, buf106, 128, 2048, stream=raw_stream0)
        del arg32_1
        assert_size_stride(arg33_1, (6144, 2048), (2048, 1), 'input')
        buf107 = reinterpret_tensor(buf103, (128, 6144), (6144, 1), 0); del buf103  # reuse
        # Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, float_14, pow_7, mean_6, add_28, rsqrt_10, output_10, float_15, add_29, output_11, hidden_states_16, mixed_qkv_8], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf106, arg33_1, buf107, 3072, 1, 1, stream=raw_stream0)
        del arg33_1
        assert_size_stride(arg37_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf108 = buf55; del buf55  # reuse
        # Topologically Sorted Source Nodes: [mixed_qkv_8, mixed_qkv_9, conv1d_2, squeeze_2, unsqueeze_16, out_4, out_5], Original ATen: [aten._unsafe_view, aten.transpose, aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_convolution_silu_slice_squeeze_transpose_unsqueeze_2.run(buf107, arg37_1, buf108, 786432, stream=raw_stream0)
        del arg37_1
        buf109 = reinterpret_tensor(buf89, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf89  # reuse
        buf110 = reinterpret_tensor(buf60, (1, 16, 128, 1), (2048, 1, 16, 2048), 0); del buf60  # reuse
        buf120 = reinterpret_tensor(buf80, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf80  # reuse
        # Topologically Sorted Source Nodes: [out_5, mixed_qkv_11, split_2, query_17, transpose_26, query_18, mul_52, sum_5, add_31, inv_norm_4, query_19, query_20], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_3.run(buf108, buf109, buf110, buf120, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg36_1, (16, 2048), (2048, 1), 'input')
        buf111 = buf71; del buf71  # reuse
        # Topologically Sorted Source Nodes: [a_2], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf106, arg36_1, buf111, 8, 1, 1, stream=raw_stream0)
        del arg36_1
        assert_size_stride(arg38_1, (16, ), (1, ), 'input')
        buf112 = buf59; del buf59  # reuse
        # Topologically Sorted Source Nodes: [exp_12, neg_2], Original ATen: [aten.exp, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_neg_5.run(arg38_1, buf112, 16, stream=raw_stream0)
        del arg38_1
        assert_size_stride(arg39_1, (16, ), (1, ), 'input')
        buf113 = buf86; del buf86  # reuse
        # Topologically Sorted Source Nodes: [exp_12, neg_2, a_2, float_17, add_30, softplus_2, g_2, transpose_30, decay_8, cum_decay_2], Original ATen: [aten.exp, aten.neg, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.view, aten.cumsum]
        workspace_2 = workspace_1; del workspace_1  # reuse
        workspace_2.zero_()
        raw_stream0 = get_raw_stream(0)
        triton_spl_fused__to_copy__unsafe_view_add_cumsum_exp_mul_neg_softplus_transpose_view_6.run(buf112, buf111, arg39_1, buf113, workspace_2, 32, 64, stream=raw_stream0)
        del arg39_1
        buf114 = buf78; del buf78  # reuse
        buf131 = reinterpret_tensor(buf72, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf72  # reuse
        buf139 = reinterpret_tensor(buf57, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf57  # reuse
        # Topologically Sorted Source Nodes: [exp_15, exp_14, getitem_55, sub_9, exp_16], Original ATen: [aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_slice_sub_7.run(buf113, buf114, buf131, buf139, 2048, stream=raw_stream0)
        buf115 = reinterpret_tensor(buf77, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf77  # reuse
        # Topologically Sorted Source Nodes: [add_31, inv_norm_4, query_19, query_20, query_22, exp_15, unsqueeze_22, query_23], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_exp_mul_rsqrt_unsqueeze_view_8.run(buf109, buf110, buf114, buf115, 262144, stream=raw_stream0)
        buf116 = reinterpret_tensor(buf109, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf109  # reuse
        # Topologically Sorted Source Nodes: [last_recurrent_state_6], Original ATen: [aten.zeros]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_zeros_9.run(buf116, 262144, stream=raw_stream0)
        buf117 = buf93; del buf93  # reuse
        # Topologically Sorted Source Nodes: [add_31, inv_norm_4, query_19, query_20, query_22, exp_15, unsqueeze_22, query_23, getitem_60, inter_chunk_attn_4, last_recurrent_state_6], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze, aten.select, aten.zeros, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_unsqueeze_view_zeros_10.run(buf115, buf116, buf117, 32, 16, 1, stream=raw_stream0)
        buf118 = reinterpret_tensor(buf62, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf62  # reuse
        buf121 = reinterpret_tensor(buf87, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf87  # reuse
        # Topologically Sorted Source Nodes: [out_5, mixed_qkv_11, split_2, key_15, transpose_27, key_16, mul_54, sum_6, add_32, inv_norm_5, key_17], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_11.run(buf108, buf118, buf121, 2048, 128, stream=raw_stream0)
        buf122 = reinterpret_tensor(buf90, (32, 64, 64), (4096, 64, 1), 0); del buf90  # reuse
        # Topologically Sorted Source Nodes: [add_31, inv_norm_4, query_19, query_20, query_22, matmul_21, add_32, inv_norm_5, key_17, key_19, transpose_32], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_mul_rsqrt_transpose_view_12.run(buf120, buf121, buf122, 16, 32, 1, stream=raw_stream0)
        assert_size_stride(arg35_1, (16, 2048), (2048, 1), 'input')
        buf124 = buf111; del buf111  # reuse
        # Topologically Sorted Source Nodes: [b_2], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf106, arg35_1, buf124, 8, 1, 1, stream=raw_stream0)
        del arg35_1
        buf125 = reinterpret_tensor(buf114, (1, 16, 128), (2048, 128, 1), 0); del buf114  # reuse
        # Topologically Sorted Source Nodes: [b_2, beta_6, transpose_29, beta_7], Original ATen: [aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_sigmoid_transpose_13.run(buf124, buf125, 16, 128, stream=raw_stream0)
        buf126 = buf120; del buf120  # reuse
        buf132 = reinterpret_tensor(buf118, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf118  # reuse
        buf140 = buf79; del buf79  # reuse
        buf129 = buf76; del buf76  # reuse
        # Topologically Sorted Source Nodes: [out_5, mixed_qkv_11, split_2, add_32, inv_norm_5, key_17, key_19, unsqueeze_18, k_beta_4, k_beta_5, value_9, transpose_28, value_10, unsqueeze_17, v_beta_4, exp_14, unsqueeze_21, decayed_k_beta_2, getitem_55, sub_9, exp_16, unsqueeze_23, key_20], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.view, aten.unsqueeze, aten._to_copy, aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_exp_mul_rsqrt_silu_slice_split_with_sizes_sub_transpose_unsqueeze_view_14.run(buf121, buf125, buf131, buf139, buf108, buf126, buf132, buf140, buf129, 262144, stream=raw_stream0)
        buf128 = reinterpret_tensor(buf84, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf84  # reuse
        buf135 = reinterpret_tensor(buf64, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf64  # reuse
        # Topologically Sorted Source Nodes: [add_32, inv_norm_5, key_17, key_19, matmul_21, strictly_upper_mask_2, ones_2, pairwise_decay_7, unsqueeze_19, unsqueeze_20, pairwise_decay_6, pairwise_decay_8, intra_chunk_attn_2, unsqueeze_18, k_beta_4, k_beta_5, matmul_20, transpose_31, ut_system_2], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.triu, aten.ones, aten.masked_fill, aten.unsqueeze, aten.sub, aten.exp, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_masked_fill_mul_ones_rsqrt_sub_transpose_triu_unsqueeze_view_15.run(buf126, buf121, buf113, buf122, buf128, buf135, 16, 32, 1, stream=raw_stream0)
        del buf121
        del buf126
        # Topologically Sorted Source Nodes: [out_5, mixed_qkv_11, split_2, value_9, transpose_28, value_10, unsqueeze_17, v_beta_4, v_beta_5, new_values_2], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.unsqueeze, aten.mul, aten.linalg_solve_triangular]
        buf130 = torch.ops.aten.linalg_solve_triangular.default(buf128, reinterpret_tensor(buf129, (1, 16, 2, 64, 128), (0, 16384, 8192, 128, 1), 0), upper=False, unitriangular=True)
        assert_tensor_metadata(buf130, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf130, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        # Topologically Sorted Source Nodes: [unsqueeze_18, k_beta_4, k_beta_5, exp_14, unsqueeze_21, decayed_k_beta_2, k_cumdecay_2], Original ATen: [aten.unsqueeze, aten.mul, aten.view, aten.exp, aten.linalg_solve_triangular]
        buf133 = torch.ops.aten.linalg_solve_triangular.default(buf128, buf132, upper=False, unitriangular=True)
        assert_tensor_metadata(buf133, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf133, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        buf136 = reinterpret_tensor(buf128, (1, 16, 64, 128), (131072, 8192, 128, 1), 0); del buf128  # reuse
        # Topologically Sorted Source Nodes: [getitem_58, getitem_59, matmul_22, v_new_4], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_16.run(buf133, buf116, buf130, buf136, 32, 16, 1, stream=raw_stream0)
        buf137 = reinterpret_tensor(buf122, (16, 64, 128), (8192, 128, 1), 0); del buf122  # reuse
        # Topologically Sorted Source Nodes: [matmul_21, intra_chunk_attn_2, getitem_61, matmul_24, getitem_58, matmul_22, v_new_4], Original ATen: [aten.view, aten.mul, aten.select, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_mul_select_sub_view_17.run(buf135, buf136, buf137, 32, 16, 1, stream=raw_stream0)
        buf138 = buf85; del buf85  # reuse
        # Topologically Sorted Source Nodes: [getitem_56, exp_17], Original ATen: [aten.select, aten.exp]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_select_18.run(buf113, buf138, 32, stream=raw_stream0)
        buf142 = buf116; del buf116  # reuse
        # Topologically Sorted Source Nodes: [add_32, inv_norm_5, key_17, key_19, getitem_56, exp_17, chunk_decay_2, getitem_62, mul_64, getitem_55, sub_9, exp_16, unsqueeze_23, key_20, getitem_63, transpose_33, matmul_25, last_recurrent_state_7], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.select, aten.exp, aten.unsqueeze, aten.slice, aten.sub, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_slice_sub_transpose_unsqueeze_view_19.run(buf140, buf136, buf138, buf142, 64, 16, 1, stream=raw_stream0)
        buf143 = reinterpret_tensor(buf136, (16, 64, 128), (8192, 128, 1), 0); del buf136  # reuse
        # Topologically Sorted Source Nodes: [getitem_66, inter_chunk_attn_5, getitem_56, exp_17, chunk_decay_2, getitem_62, mul_64, matmul_25, last_recurrent_state_7], Original ATen: [aten.select, aten.view, aten.exp, aten.unsqueeze, aten.mul, aten.add, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_select_unsqueeze_view_20.run(buf115, buf142, buf143, 32, 16, 1, stream=raw_stream0)
        buf145 = buf92; del buf92  # reuse
        # Topologically Sorted Source Nodes: [getitem_64, getitem_65, matmul_26, v_new_5], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_21.run(buf133, buf142, buf130, buf145, 32, 16, 1, stream=raw_stream0)
        buf146 = reinterpret_tensor(buf82, (16, 64, 128), (8192, 128, 1), 0); del buf82  # reuse
        # Topologically Sorted Source Nodes: [getitem_67, matmul_28, getitem_64, matmul_26, v_new_5], Original ATen: [aten.select, aten.view, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_22.run(buf135, buf145, buf146, 32, 16, 1, stream=raw_stream0)
        assert_size_stride(arg34_1, (2048, 2048), (2048, 1), 'input')
        buf148 = buf51; del buf51  # reuse
        # Topologically Sorted Source Nodes: [z_6], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf106, arg34_1, buf148, 1024, 1, 1, stream=raw_stream0)
        del arg34_1
        assert_size_stride(arg40_1, (128, ), (1, ), 'input')
        buf149 = reinterpret_tensor(buf148, (2048, 128), (128, 1), 0); del buf148  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_14, setitem_8, inter_chunk_attn_4, matmul_24, add_33, setitem_9, inter_chunk_attn_5, matmul_28, add_35, core_attn_out_15, transpose_35, core_attn_out_17, core_attn_out_18, hidden_states_17, pow_8, variance_2, add_37, rsqrt_13, hidden_states_18, to_36, hidden_states_19, z_6, z_7, z_8, to_37, silu_7, hidden_states_20, core_attn_out_19], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_copy_mean_mul_pow_rsqrt_select_silu_transpose_view_zeros_like_24.run(buf149, buf143, buf146, buf117, buf137, arg40_1, 2048, 128, stream=raw_stream0)
        del arg40_1
        assert_size_stride(arg41_1, (2048, 2048), (2048, 1), 'input')
        buf150 = reinterpret_tensor(buf106, (128, 2048), (2048, 1), 0); del buf106  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_14, setitem_8, inter_chunk_attn_4, matmul_24, add_33, setitem_9, inter_chunk_attn_5, matmul_28, add_35, core_attn_out_15, transpose_35, core_attn_out_17, core_attn_out_18, hidden_states_17, pow_8, variance_2, add_37, rsqrt_13, hidden_states_18, to_36, hidden_states_19, z_6, z_7, z_8, to_37, silu_7, hidden_states_20, core_attn_out_19, core_attn_out_20, output_12], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf149, arg41_1, buf150, 1024, 1, 1, stream=raw_stream0)
        del arg41_1
        assert_size_stride(arg42_1, (2048, ), (1, ), 'input')
        buf152 = reinterpret_tensor(buf149, (1, 128, 2048), (262144, 2048, 1), 0); del buf149  # reuse
        # Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, output_12, hidden_states_21, float_18, pow_9, mean_8, add_39, rsqrt_14, output_13, float_19, add_40, output_14, hidden_states_22], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_31.run(buf98, buf104, buf150, arg42_1, buf152, 128, 2048, stream=raw_stream0)
        del arg42_1
        assert_size_stride(arg43_1, (6144, 2048), (2048, 1), 'input')
        buf153 = buf107; del buf107  # reuse
        # Topologically Sorted Source Nodes: [linear_21], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf152, arg43_1, buf153, 3072, 1, 1, stream=raw_stream0)
        del arg43_1
        assert_size_stride(arg44_1, (6144, 2048), (2048, 1), 'input')
        buf155 = reinterpret_tensor(buf101, (1, 128, 6144), (786432, 6144, 1), 0); del buf101  # reuse
        # Topologically Sorted Source Nodes: [linear_21, silu_8, linear_22, mul_71], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_26.run(buf152, arg44_1, buf153, buf155, 3072, 1, 1, stream=raw_stream0)
        del arg44_1
        assert_size_stride(arg45_1, (2048, 6144), (6144, 1), 'input')
        buf156 = reinterpret_tensor(buf152, (128, 2048), (2048, 1), 0); del buf152  # reuse
        # Topologically Sorted Source Nodes: [linear_21, silu_8, linear_22, mul_71, down_proj_2], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_27.run(buf155, arg45_1, buf156, 1024, 1, 1, stream=raw_stream0)
        del arg45_1
        assert_size_stride(arg46_1, (2048, ), (1, ), 'input')
        buf158 = empty_strided((1, 128, 2048), (262144, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, output_12, hidden_states_21, down_proj_2, hidden_states_23, float_20, pow_10, mean_9, add_42, rsqrt_15, output_15, float_21, add_43, output_16, hidden_states_24], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_32.run(buf98, buf104, buf150, buf156, arg46_1, buf158, 128, 2048, stream=raw_stream0)
        del arg46_1
        assert_size_stride(arg47_1, (4096, 2048), (2048, 1), 'input')
        buf159 = empty_strided((128, 4096), (4096, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [linear_24], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_33.run(buf158, arg47_1, buf159, 2048, 1, 1, stream=raw_stream0)
        del arg47_1
        buf160 = empty_strided((1, 128, 8, 1), (1024, 8, 1, 1024), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [linear_24, view, chunk, float_22, pow_11, mean_10], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_mean_pow_split_view_34.run(buf159, buf160, 1024, 256, stream=raw_stream0)
        assert_size_stride_grouped((arg2_1, arg3_1), ((1, 128), (32, )), ((128, 1), (1, )), 'input')
        buf161 = empty_strided((3, 1, 128, 32), (4096, 12288, 32, 1), device='tnca', dtype=torch.float32)
        buf165 = empty_strided((3, 1, 128, 32), (4096, 12288, 32, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [getitem_1, position_ids, position_ids_1, position_ids_2, getitem_4, float_1, to, freqs, sin_1, getitem_6, cos_1, getitem_9, setitem_3, setitem_1], Original ATen: [aten.unsqueeze, aten.expand, aten.slice, aten._to_copy, aten.mul, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_35.run(arg2_1, arg3_1, buf161, buf165, 12288, stream=raw_stream0)
        del arg2_1
        del arg3_1
        assert_size_stride(arg48_1, (256, ), (1, ), 'input')
        buf164 = empty_strided((1, 8, 128, 64), (65536, 8192, 64, 1), device='tnca', dtype=torch.bfloat16)
        buf162 = reinterpret_tensor(buf164, (1, 8, 128, 32), (65536, 8192, 64, 1), 0)  # alias
        buf163 = reinterpret_tensor(buf164, (1, 8, 128, 32), (65536, 8192, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_24, view, chunk, float_22, pow_11, mean_10, add_44, rsqrt_16, output_17, float_23, add_45, output_18, type_as_7, query_states_1, q_rot, x2, neg_3, x1, cat_2], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_36.run(buf159, buf160, arg48_1, buf162, buf163, 32768, stream=raw_stream0)
        buf168 = empty_strided((1, 8, 128, 256), (262144, 32768, 256, 1), device='tnca', dtype=torch.bfloat16)
        buf166 = reinterpret_tensor(buf168, (1, 8, 128, 64), (262144, 32768, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_24, view, chunk, float_22, pow_11, mean_10, add_44, rsqrt_16, output_17, float_23, add_45, output_18, type_as_7, query_states_1, q_rot, cos_2, cos_3, cos_4, mul_78, sin_2, sin_3, sin_4, mul_79, q_embed], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.select, aten.cat, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_37.run(buf159, buf160, arg48_1, buf161, buf164, buf165, buf166, 65536, stream=raw_stream0)
        del buf162
        del buf163
        buf167 = reinterpret_tensor(buf168, (1, 8, 128, 192), (262144, 32768, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [linear_24, view, chunk, float_22, pow_11, mean_10, add_44, rsqrt_16, output_17, float_23, add_45, output_18, type_as_7, query_states_1, q_rot, cos_2, cos_3, cos_4, mul_78, sin_2, sin_3, sin_4, mul_79, q_embed, q_pass, q_embed_1], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.select, aten.cat, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_38.run(buf159, buf160, arg48_1, buf167, 196608, stream=raw_stream0)
        del arg48_1
        assert_size_stride(arg49_1, (512, 2048), (2048, 1), 'input')
        del buf166
        del buf167
        buf169 = reinterpret_tensor(buf164, (128, 512), (512, 1), 0); del buf164  # reuse
        # Topologically Sorted Source Nodes: [linear_25], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_39.run(buf158, arg49_1, buf169, 256, 1, 1, stream=raw_stream0)
        del arg49_1
        buf170 = empty_strided((1, 128, 2, 1), (256, 2, 1, 256), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [linear_25, view_2, float_24, pow_12, mean_11], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_mean_pow_view_40.run(buf169, buf170, 256, 256, stream=raw_stream0)
        assert_size_stride(arg50_1, (256, ), (1, ), 'input')
        buf173 = empty_strided((1, 2, 128, 64), (16384, 8192, 64, 1), device='tnca', dtype=torch.bfloat16)
        buf171 = reinterpret_tensor(buf173, (1, 2, 128, 32), (16384, 8192, 64, 1), 0)  # alias
        buf172 = reinterpret_tensor(buf173, (1, 2, 128, 32), (16384, 8192, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_25, view_2, float_24, pow_12, mean_11, add_46, rsqrt_17, output_19, float_25, add_47, output_20, type_as_8, key_states, k_rot, x2_1, neg_4, x1_1, cat_3], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_41.run(buf169, buf170, arg50_1, buf171, buf172, 8192, stream=raw_stream0)
        buf176 = empty_strided((1, 2, 128, 256), (65536, 32768, 256, 1), device='tnca', dtype=torch.bfloat16)
        buf174 = reinterpret_tensor(buf176, (1, 2, 128, 64), (65536, 32768, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, cos_4, sin_2, sin_3, sin_4, linear_25, view_2, float_24, pow_12, mean_11, add_46, rsqrt_17, output_19, float_25, add_47, output_20, type_as_8, key_states, k_rot, mul_80, mul_81, k_embed], Original ATen: [aten.select, aten.cat, aten._to_copy, aten.unsqueeze, aten._unsafe_view, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_42.run(buf169, buf170, arg50_1, buf161, buf173, buf165, buf174, 16384, stream=raw_stream0)
        del buf171
        del buf172
        buf175 = reinterpret_tensor(buf176, (1, 2, 128, 192), (65536, 32768, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, cos_4, sin_2, sin_3, sin_4, linear_25, view_2, float_24, pow_12, mean_11, add_46, rsqrt_17, output_19, float_25, add_47, output_20, type_as_8, key_states, k_rot, mul_80, mul_81, k_embed, k_pass, k_embed_1], Original ATen: [aten.select, aten.cat, aten._to_copy, aten.unsqueeze, aten._unsafe_view, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_43.run(buf169, buf170, arg50_1, buf175, 49152, stream=raw_stream0)
        del arg50_1
        buf177 = empty_strided((1, 2, 4, 128, 256), (262144, 131072, 32768, 256, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [getitem_81, hidden_states_25, key_states_1], Original ATen: [aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_clone_expand_unsqueeze_44.run(buf176, buf177, 262144, stream=raw_stream0)
        del buf174
        del buf175
        buf178 = empty_strided((8, 128, 128), (16384, 128, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [matmul_30, getitem_81, hidden_states_25, key_states_1, transpose_39], Original ATen: [aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_45.run(buf168, buf177, buf178, 64, 8, 1, stream=raw_stream0)
        buf180 = reinterpret_tensor(buf146, (1, 8, 128, 128), (131072, 16384, 128, 1), 0); del buf146  # reuse
        buf183 = empty_strided((1, 8, 128, 128), (131072, 16384, 128, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [matmul_30, attn_weights, mask, full, getitem, attn_weights_1, softmax, attn_weights_2], Original ATen: [aten.view, aten.mul, aten.triu, aten.full, aten.unsqueeze, aten.add, aten._to_copy, aten._softmax]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__softmax__to_copy_add_full_mul_triu_unsqueeze_view_46.run(buf178, buf180, buf183, 1024, 128, stream=raw_stream0)
        assert_size_stride(arg51_1, (512, 2048), (2048, 1), 'input')
        buf182 = reinterpret_tensor(buf176, (128, 512), (512, 1), 0); del buf176  # reuse
        # Topologically Sorted Source Nodes: [linear_26], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_39.run(buf158, arg51_1, buf182, 256, 1, 1, stream=raw_stream0)
        del arg51_1
        buf184 = reinterpret_tensor(buf158, (1, 2, 4, 128, 256), (262144, 131072, 32768, 256, 1), 0); del buf158  # reuse
        # Topologically Sorted Source Nodes: [linear_26, view_3, value_states, getitem_82, hidden_states_26, value_states_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_clone_expand_transpose_unsqueeze_view_47.run(buf182, buf184, 262144, stream=raw_stream0)
        buf185 = reinterpret_tensor(buf177, (8, 128, 256), (32768, 256, 1), 0); del buf177  # reuse
        # Topologically Sorted Source Nodes: [softmax, attn_weights_2, attn_output, linear_26, view_3, value_states, getitem_82, hidden_states_26, value_states_1], Original ATen: [aten._softmax, aten._to_copy, aten.view, aten._unsafe_view, aten.transpose, aten.unsqueeze, aten.expand, aten.clone, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__softmax__to_copy__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_48.run(buf183, buf184, buf185, 128, 8, 1, stream=raw_stream0)
        buf186 = reinterpret_tensor(buf184, (1, 128, 2048), (262144, 2048, 1), 0); del buf184  # reuse
        # Topologically Sorted Source Nodes: [linear_24, view, chunk, attn_output, transpose_40, attn_output_1, reshape_42, gate_1, sigmoid_3, attn_output_3], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten.transpose, aten.clone, aten.sigmoid, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_clone_mul_sigmoid_split_transpose_view_49.run(buf185, buf159, buf186, 262144, stream=raw_stream0)
        assert_size_stride(arg52_1, (2048, 2048), (2048, 1), 'input')
        buf187 = reinterpret_tensor(buf185, (128, 2048), (2048, 1), 0); del buf185  # reuse
        # Topologically Sorted Source Nodes: [linear_24, view, chunk, attn_output, transpose_40, attn_output_1, reshape_42, gate_1, sigmoid_3, attn_output_3, attn_output_4], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten.transpose, aten.clone, aten.sigmoid, aten.mul, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf186, arg52_1, buf187, 1024, 1, 1, stream=raw_stream0)
        del arg52_1
        assert_size_stride(arg53_1, (2048, ), (1, ), 'input')
        buf188 = buf98; del buf98  # reuse
        buf190 = buf186; del buf186  # reuse
        # Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, output_12, hidden_states_21, down_proj_2, hidden_states_23, attn_output_4, hidden_states_27, float_26, pow_13, mean_12, add_52, rsqrt_18, output_21, float_27, add_53, output_22, hidden_states_28], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_50.run(buf188, buf104, buf150, buf156, buf187, arg53_1, buf190, 128, 2048, stream=raw_stream0)
        del arg53_1
        assert_size_stride(arg54_1, (6144, 2048), (2048, 1), 'input')
        buf191 = reinterpret_tensor(buf155, (128, 6144), (6144, 1), 0); del buf155  # reuse
        # Topologically Sorted Source Nodes: [float_26, pow_13, mean_12, add_52, rsqrt_18, output_21, float_27, add_53, output_22, hidden_states_28, linear_28], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf190, arg54_1, buf191, 3072, 1, 1, stream=raw_stream0)
        del arg54_1
        assert_size_stride(arg55_1, (6144, 2048), (2048, 1), 'input')
        buf193 = reinterpret_tensor(buf153, (1, 128, 6144), (786432, 6144, 1), 0); del buf153  # reuse
        # Topologically Sorted Source Nodes: [linear_28, silu_9, linear_29, mul_86], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_26.run(buf190, arg55_1, buf191, buf193, 3072, 1, 1, stream=raw_stream0)
        del arg55_1
        assert_size_stride(arg56_1, (2048, 6144), (6144, 1), 'input')
        buf194 = reinterpret_tensor(buf190, (128, 2048), (2048, 1), 0); del buf190  # reuse
        # Topologically Sorted Source Nodes: [linear_28, silu_9, linear_29, mul_86, down_proj_3], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_27.run(buf193, arg56_1, buf194, 1024, 1, 1, stream=raw_stream0)
        del arg56_1
        assert_size_stride(arg57_1, (2048, ), (1, ), 'input')
        buf196 = reinterpret_tensor(buf187, (1, 128, 2048), (262144, 2048, 1), 0); del buf187  # reuse
        # Topologically Sorted Source Nodes: [down_proj_3, hidden_states_29, float_28, pow_14, mean_13, add_55, rsqrt_19, output_23, float_29, add_56, output_24, hidden_states_30], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_30.run(buf188, buf194, arg57_1, buf196, 128, 2048, stream=raw_stream0)
        del arg57_1
        assert_size_stride(arg58_1, (6144, 2048), (2048, 1), 'input')
        buf197 = reinterpret_tensor(buf193, (128, 6144), (6144, 1), 0); del buf193  # reuse
        # Topologically Sorted Source Nodes: [down_proj_3, hidden_states_29, float_28, pow_14, mean_13, add_55, rsqrt_19, output_23, float_29, add_56, output_24, hidden_states_30, mixed_qkv_12], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf196, arg58_1, buf197, 3072, 1, 1, stream=raw_stream0)
        del arg58_1
        assert_size_stride(arg62_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf198 = buf108; del buf108  # reuse
        # Topologically Sorted Source Nodes: [mixed_qkv_12, mixed_qkv_13, conv1d_3, squeeze_3, unsqueeze_26, out_6, out_7], Original ATen: [aten._unsafe_view, aten.transpose, aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_convolution_silu_slice_squeeze_transpose_unsqueeze_2.run(buf197, arg62_1, buf198, 786432, stream=raw_stream0)
        del arg62_1
        buf199 = reinterpret_tensor(buf142, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf142  # reuse
        buf200 = reinterpret_tensor(buf113, (1, 16, 128, 1), (2048, 1, 16, 2048), 0); del buf113  # reuse
        buf210 = reinterpret_tensor(buf133, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf133  # reuse
        # Topologically Sorted Source Nodes: [out_7, mixed_qkv_15, split_3, query_25, transpose_43, query_26, mul_90, sum_7, add_58, inv_norm_6, query_27, query_28], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_3.run(buf198, buf199, buf200, buf210, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg61_1, (16, 2048), (2048, 1), 'input')
        buf201 = buf124; del buf124  # reuse
        # Topologically Sorted Source Nodes: [a_3], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf196, arg61_1, buf201, 8, 1, 1, stream=raw_stream0)
        del arg61_1
        assert_size_stride(arg63_1, (16, ), (1, ), 'input')
        buf202 = buf112; del buf112  # reuse
        # Topologically Sorted Source Nodes: [exp_18, neg_5], Original ATen: [aten.exp, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_neg_5.run(arg63_1, buf202, 16, stream=raw_stream0)
        del arg63_1
        assert_size_stride(arg64_1, (16, ), (1, ), 'input')
        buf203 = buf139; del buf139  # reuse
        # Topologically Sorted Source Nodes: [exp_18, neg_5, a_3, float_31, add_57, softplus_3, g_3, transpose_47, decay_11, cum_decay_3], Original ATen: [aten.exp, aten.neg, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.view, aten.cumsum]
        workspace_3 = workspace_2; del workspace_2  # reuse
        workspace_3.zero_()
        raw_stream0 = get_raw_stream(0)
        triton_spl_fused__to_copy__unsafe_view_add_cumsum_exp_mul_neg_softplus_transpose_view_6.run(buf202, buf201, arg64_1, buf203, workspace_3, 32, 64, stream=raw_stream0)
        del arg64_1
        buf204 = buf131; del buf131  # reuse
        buf221 = reinterpret_tensor(buf125, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf125  # reuse
        buf229 = reinterpret_tensor(buf110, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf110  # reuse
        # Topologically Sorted Source Nodes: [exp_21, exp_20, getitem_87, sub_13, exp_22], Original ATen: [aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_slice_sub_7.run(buf203, buf204, buf221, buf229, 2048, stream=raw_stream0)
        buf205 = reinterpret_tensor(buf130, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf130  # reuse
        # Topologically Sorted Source Nodes: [add_58, inv_norm_6, query_27, query_28, query_30, exp_21, unsqueeze_32, query_31], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_exp_mul_rsqrt_unsqueeze_view_8.run(buf199, buf200, buf204, buf205, 262144, stream=raw_stream0)
        buf206 = reinterpret_tensor(buf199, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf199  # reuse
        # Topologically Sorted Source Nodes: [last_recurrent_state_9], Original ATen: [aten.zeros]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_zeros_9.run(buf206, 262144, stream=raw_stream0)
        buf207 = reinterpret_tensor(buf180, (16, 64, 128), (8192, 128, 1), 0); del buf180  # reuse
        # Topologically Sorted Source Nodes: [add_58, inv_norm_6, query_27, query_28, query_30, exp_21, unsqueeze_32, query_31, getitem_92, inter_chunk_attn_6, last_recurrent_state_9], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze, aten.select, aten.zeros, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_unsqueeze_view_zeros_10.run(buf205, buf206, buf207, 32, 16, 1, stream=raw_stream0)
        buf208 = reinterpret_tensor(buf115, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf115  # reuse
        buf211 = reinterpret_tensor(buf140, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf140  # reuse
        # Topologically Sorted Source Nodes: [out_7, mixed_qkv_15, split_3, key_22, transpose_44, key_23, mul_92, sum_8, add_59, inv_norm_7, key_24], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_11.run(buf198, buf208, buf211, 2048, 128, stream=raw_stream0)
        buf212 = reinterpret_tensor(buf143, (32, 64, 64), (4096, 64, 1), 0); del buf143  # reuse
        # Topologically Sorted Source Nodes: [add_58, inv_norm_6, query_27, query_28, query_30, matmul_33, add_59, inv_norm_7, key_24, key_26, transpose_49], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_mul_rsqrt_transpose_view_12.run(buf210, buf211, buf212, 16, 32, 1, stream=raw_stream0)
        assert_size_stride(arg60_1, (16, 2048), (2048, 1), 'input')
        buf214 = buf201; del buf201  # reuse
        # Topologically Sorted Source Nodes: [b_3], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf196, arg60_1, buf214, 8, 1, 1, stream=raw_stream0)
        del arg60_1
        buf215 = reinterpret_tensor(buf204, (1, 16, 128), (2048, 128, 1), 0); del buf204  # reuse
        # Topologically Sorted Source Nodes: [b_3, beta_9, transpose_46, beta_10], Original ATen: [aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_sigmoid_transpose_13.run(buf214, buf215, 16, 128, stream=raw_stream0)
        buf216 = buf210; del buf210  # reuse
        buf222 = reinterpret_tensor(buf208, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf208  # reuse
        buf230 = buf132; del buf132  # reuse
        buf219 = buf129; del buf129  # reuse
        # Topologically Sorted Source Nodes: [out_7, mixed_qkv_15, split_3, add_59, inv_norm_7, key_24, key_26, unsqueeze_28, k_beta_6, k_beta_7, value_13, transpose_45, value_14, unsqueeze_27, v_beta_6, exp_20, unsqueeze_31, decayed_k_beta_3, getitem_87, sub_13, exp_22, unsqueeze_33, key_27], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.view, aten.unsqueeze, aten._to_copy, aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_exp_mul_rsqrt_silu_slice_split_with_sizes_sub_transpose_unsqueeze_view_14.run(buf211, buf215, buf221, buf229, buf198, buf216, buf222, buf230, buf219, 262144, stream=raw_stream0)
        buf218 = reinterpret_tensor(buf137, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf137  # reuse
        buf225 = reinterpret_tensor(buf117, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf117  # reuse
        # Topologically Sorted Source Nodes: [add_59, inv_norm_7, key_24, key_26, matmul_33, strictly_upper_mask_3, ones_3, pairwise_decay_10, unsqueeze_29, unsqueeze_30, pairwise_decay_9, pairwise_decay_11, intra_chunk_attn_3, unsqueeze_28, k_beta_6, k_beta_7, matmul_32, transpose_48, ut_system_3], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.triu, aten.ones, aten.masked_fill, aten.unsqueeze, aten.sub, aten.exp, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_masked_fill_mul_ones_rsqrt_sub_transpose_triu_unsqueeze_view_15.run(buf216, buf211, buf203, buf212, buf218, buf225, 16, 32, 1, stream=raw_stream0)
        del buf211
        del buf216
        # Topologically Sorted Source Nodes: [out_7, mixed_qkv_15, split_3, value_13, transpose_45, value_14, unsqueeze_27, v_beta_6, v_beta_7, new_values_3], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.unsqueeze, aten.mul, aten.linalg_solve_triangular]
        buf220 = torch.ops.aten.linalg_solve_triangular.default(buf218, reinterpret_tensor(buf219, (1, 16, 2, 64, 128), (0, 16384, 8192, 128, 1), 0), upper=False, unitriangular=True)
        assert_tensor_metadata(buf220, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf220, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        # Topologically Sorted Source Nodes: [unsqueeze_28, k_beta_6, k_beta_7, exp_20, unsqueeze_31, decayed_k_beta_3, k_cumdecay_3], Original ATen: [aten.unsqueeze, aten.mul, aten.view, aten.exp, aten.linalg_solve_triangular]
        buf223 = torch.ops.aten.linalg_solve_triangular.default(buf218, buf222, upper=False, unitriangular=True)
        assert_tensor_metadata(buf223, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf223, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        buf226 = reinterpret_tensor(buf218, (1, 16, 64, 128), (131072, 8192, 128, 1), 0); del buf218  # reuse
        # Topologically Sorted Source Nodes: [getitem_90, getitem_91, matmul_34, v_new_6], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_16.run(buf223, buf206, buf220, buf226, 32, 16, 1, stream=raw_stream0)
        buf227 = reinterpret_tensor(buf212, (16, 64, 128), (8192, 128, 1), 0); del buf212  # reuse
        # Topologically Sorted Source Nodes: [matmul_33, intra_chunk_attn_3, getitem_93, matmul_36, getitem_90, matmul_34, v_new_6], Original ATen: [aten.view, aten.mul, aten.select, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_mul_select_sub_view_17.run(buf225, buf226, buf227, 32, 16, 1, stream=raw_stream0)
        buf228 = buf138; del buf138  # reuse
        # Topologically Sorted Source Nodes: [getitem_88, exp_23], Original ATen: [aten.select, aten.exp]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_select_18.run(buf203, buf228, 32, stream=raw_stream0)
        buf232 = buf206; del buf206  # reuse
        # Topologically Sorted Source Nodes: [add_59, inv_norm_7, key_24, key_26, getitem_88, exp_23, chunk_decay_3, getitem_94, mul_102, getitem_87, sub_13, exp_22, unsqueeze_33, key_27, getitem_95, transpose_50, matmul_37, last_recurrent_state_10], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.select, aten.exp, aten.unsqueeze, aten.slice, aten.sub, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_slice_sub_transpose_unsqueeze_view_19.run(buf230, buf226, buf228, buf232, 64, 16, 1, stream=raw_stream0)
        buf233 = reinterpret_tensor(buf226, (16, 64, 128), (8192, 128, 1), 0); del buf226  # reuse
        # Topologically Sorted Source Nodes: [getitem_98, inter_chunk_attn_7, getitem_88, exp_23, chunk_decay_3, getitem_94, mul_102, matmul_37, last_recurrent_state_10], Original ATen: [aten.select, aten.view, aten.exp, aten.unsqueeze, aten.mul, aten.add, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_select_unsqueeze_view_20.run(buf205, buf232, buf233, 32, 16, 1, stream=raw_stream0)
        buf235 = buf145; del buf145  # reuse
        # Topologically Sorted Source Nodes: [getitem_96, getitem_97, matmul_38, v_new_7], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_21.run(buf223, buf232, buf220, buf235, 32, 16, 1, stream=raw_stream0)
        buf236 = reinterpret_tensor(buf135, (16, 64, 128), (8192, 128, 1), 0); del buf135  # reuse
        # Topologically Sorted Source Nodes: [getitem_99, matmul_40, getitem_96, matmul_38, v_new_7], Original ATen: [aten.select, aten.view, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_22.run(buf225, buf235, buf236, 32, 16, 1, stream=raw_stream0)
        assert_size_stride(arg59_1, (2048, 2048), (2048, 1), 'input')
        buf238 = buf156; del buf156  # reuse
        # Topologically Sorted Source Nodes: [z_9], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf196, arg59_1, buf238, 1024, 1, 1, stream=raw_stream0)
        del arg59_1
        assert_size_stride(arg65_1, (128, ), (1, ), 'input')
        buf239 = reinterpret_tensor(buf238, (2048, 128), (128, 1), 0); del buf238  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_21, setitem_10, inter_chunk_attn_6, matmul_36, add_60, setitem_11, inter_chunk_attn_7, matmul_40, add_62, core_attn_out_22, transpose_52, core_attn_out_24, core_attn_out_25, hidden_states_31, pow_15, variance_3, add_64, rsqrt_22, hidden_states_32, to_49, hidden_states_33, z_9, z_10, z_11, to_50, silu_11, hidden_states_34, core_attn_out_26], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_copy_mean_mul_pow_rsqrt_select_silu_transpose_view_zeros_like_24.run(buf239, buf233, buf236, buf207, buf227, arg65_1, 2048, 128, stream=raw_stream0)
        del arg65_1
        assert_size_stride(arg66_1, (2048, 2048), (2048, 1), 'input')
        buf240 = reinterpret_tensor(buf196, (128, 2048), (2048, 1), 0); del buf196  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_21, setitem_10, inter_chunk_attn_6, matmul_36, add_60, setitem_11, inter_chunk_attn_7, matmul_40, add_62, core_attn_out_22, transpose_52, core_attn_out_24, core_attn_out_25, hidden_states_31, pow_15, variance_3, add_64, rsqrt_22, hidden_states_32, to_49, hidden_states_33, z_9, z_10, z_11, to_50, silu_11, hidden_states_34, core_attn_out_26, core_attn_out_27, output_25], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf239, arg66_1, buf240, 1024, 1, 1, stream=raw_stream0)
        del arg66_1
        assert_size_stride(arg67_1, (2048, ), (1, ), 'input')
        buf242 = reinterpret_tensor(buf239, (1, 128, 2048), (262144, 2048, 1), 0); del buf239  # reuse
        # Topologically Sorted Source Nodes: [down_proj_3, hidden_states_29, output_25, hidden_states_35, float_32, pow_16, mean_15, add_66, rsqrt_23, output_26, float_33, add_67, output_27, hidden_states_36], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_31.run(buf188, buf194, buf240, arg67_1, buf242, 128, 2048, stream=raw_stream0)
        del arg67_1
        assert_size_stride(arg68_1, (6144, 2048), (2048, 1), 'input')
        buf243 = buf197; del buf197  # reuse
        # Topologically Sorted Source Nodes: [linear_36], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf242, arg68_1, buf243, 3072, 1, 1, stream=raw_stream0)
        del arg68_1
        assert_size_stride(arg69_1, (6144, 2048), (2048, 1), 'input')
        buf245 = reinterpret_tensor(buf191, (1, 128, 6144), (786432, 6144, 1), 0); del buf191  # reuse
        # Topologically Sorted Source Nodes: [linear_36, silu_12, linear_37, mul_109], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_26.run(buf242, arg69_1, buf243, buf245, 3072, 1, 1, stream=raw_stream0)
        del arg69_1
        assert_size_stride(arg70_1, (2048, 6144), (6144, 1), 'input')
        buf246 = reinterpret_tensor(buf242, (128, 2048), (2048, 1), 0); del buf242  # reuse
        # Topologically Sorted Source Nodes: [linear_36, silu_12, linear_37, mul_109, down_proj_4], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_27.run(buf245, arg70_1, buf246, 1024, 1, 1, stream=raw_stream0)
        del arg70_1
        assert_size_stride(arg71_1, (2048, ), (1, ), 'input')
        buf248 = reinterpret_tensor(buf150, (1, 128, 2048), (262144, 2048, 1), 0); del buf150  # reuse
        # Topologically Sorted Source Nodes: [down_proj_3, hidden_states_29, output_25, hidden_states_35, down_proj_4, hidden_states_37, float_34, pow_17, mean_16, add_69, rsqrt_24, output_28, float_35, add_70, output_29, hidden_states_38], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_32.run(buf188, buf194, buf240, buf246, arg71_1, buf248, 128, 2048, stream=raw_stream0)
        del arg71_1
        assert_size_stride(arg72_1, (6144, 2048), (2048, 1), 'input')
        buf249 = reinterpret_tensor(buf245, (128, 6144), (6144, 1), 0); del buf245  # reuse
        # Topologically Sorted Source Nodes: [mixed_qkv_16], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf248, arg72_1, buf249, 3072, 1, 1, stream=raw_stream0)
        del arg72_1
        assert_size_stride(arg76_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf250 = buf198; del buf198  # reuse
        # Topologically Sorted Source Nodes: [mixed_qkv_16, mixed_qkv_17, conv1d_4, squeeze_4, unsqueeze_34, out_8, out_9], Original ATen: [aten._unsafe_view, aten.transpose, aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_convolution_silu_slice_squeeze_transpose_unsqueeze_2.run(buf249, arg76_1, buf250, 786432, stream=raw_stream0)
        del arg76_1
        buf251 = reinterpret_tensor(buf232, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf232  # reuse
        buf252 = reinterpret_tensor(buf203, (1, 16, 128, 1), (2048, 1, 16, 2048), 0); del buf203  # reuse
        buf262 = reinterpret_tensor(buf223, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf223  # reuse
        # Topologically Sorted Source Nodes: [out_9, mixed_qkv_19, split_4, query_33, transpose_55, query_34, mul_113, sum_9, add_72, inv_norm_8, query_35, query_36], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_3.run(buf250, buf251, buf252, buf262, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg75_1, (16, 2048), (2048, 1), 'input')
        buf253 = buf214; del buf214  # reuse
        # Topologically Sorted Source Nodes: [a_4], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf248, arg75_1, buf253, 8, 1, 1, stream=raw_stream0)
        del arg75_1
        assert_size_stride(arg77_1, (16, ), (1, ), 'input')
        buf254 = buf202; del buf202  # reuse
        # Topologically Sorted Source Nodes: [exp_24, neg_6], Original ATen: [aten.exp, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_neg_5.run(arg77_1, buf254, 16, stream=raw_stream0)
        del arg77_1
        assert_size_stride(arg78_1, (16, ), (1, ), 'input')
        buf255 = buf229; del buf229  # reuse
        # Topologically Sorted Source Nodes: [exp_24, neg_6, a_4, float_37, add_71, softplus_4, g_4, transpose_59, decay_14, cum_decay_4], Original ATen: [aten.exp, aten.neg, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.view, aten.cumsum]
        workspace_4 = workspace_3; del workspace_3  # reuse
        workspace_4.zero_()
        raw_stream0 = get_raw_stream(0)
        triton_spl_fused__to_copy__unsafe_view_add_cumsum_exp_mul_neg_softplus_transpose_view_6.run(buf254, buf253, arg78_1, buf255, workspace_4, 32, 64, stream=raw_stream0)
        del arg78_1
        buf256 = buf221; del buf221  # reuse
        buf273 = reinterpret_tensor(buf215, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf215  # reuse
        buf281 = reinterpret_tensor(buf200, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf200  # reuse
        # Topologically Sorted Source Nodes: [exp_27, exp_26, getitem_107, sub_17, exp_28], Original ATen: [aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_slice_sub_7.run(buf255, buf256, buf273, buf281, 2048, stream=raw_stream0)
        buf257 = reinterpret_tensor(buf220, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf220  # reuse
        # Topologically Sorted Source Nodes: [add_72, inv_norm_8, query_35, query_36, query_38, exp_27, unsqueeze_40, query_39], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_exp_mul_rsqrt_unsqueeze_view_8.run(buf251, buf252, buf256, buf257, 262144, stream=raw_stream0)
        buf258 = reinterpret_tensor(buf251, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf251  # reuse
        # Topologically Sorted Source Nodes: [last_recurrent_state_12], Original ATen: [aten.zeros]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_zeros_9.run(buf258, 262144, stream=raw_stream0)
        buf259 = buf236; del buf236  # reuse
        # Topologically Sorted Source Nodes: [add_72, inv_norm_8, query_35, query_36, query_38, exp_27, unsqueeze_40, query_39, getitem_112, inter_chunk_attn_8, last_recurrent_state_12], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze, aten.select, aten.zeros, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_unsqueeze_view_zeros_10.run(buf257, buf258, buf259, 32, 16, 1, stream=raw_stream0)
        buf260 = reinterpret_tensor(buf205, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf205  # reuse
        buf263 = reinterpret_tensor(buf230, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf230  # reuse
        # Topologically Sorted Source Nodes: [out_9, mixed_qkv_19, split_4, key_29, transpose_56, key_30, mul_115, sum_10, add_73, inv_norm_9, key_31], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_11.run(buf250, buf260, buf263, 2048, 128, stream=raw_stream0)
        buf264 = reinterpret_tensor(buf233, (32, 64, 64), (4096, 64, 1), 0); del buf233  # reuse
        # Topologically Sorted Source Nodes: [add_72, inv_norm_8, query_35, query_36, query_38, matmul_43, add_73, inv_norm_9, key_31, key_33, transpose_61], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_mul_rsqrt_transpose_view_12.run(buf262, buf263, buf264, 16, 32, 1, stream=raw_stream0)
        assert_size_stride(arg74_1, (16, 2048), (2048, 1), 'input')
        buf266 = buf253; del buf253  # reuse
        # Topologically Sorted Source Nodes: [b_4], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf248, arg74_1, buf266, 8, 1, 1, stream=raw_stream0)
        del arg74_1
        buf267 = reinterpret_tensor(buf256, (1, 16, 128), (2048, 128, 1), 0); del buf256  # reuse
        # Topologically Sorted Source Nodes: [b_4, beta_12, transpose_58, beta_13], Original ATen: [aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_sigmoid_transpose_13.run(buf266, buf267, 16, 128, stream=raw_stream0)
        buf268 = buf262; del buf262  # reuse
        buf274 = reinterpret_tensor(buf260, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf260  # reuse
        buf282 = buf222; del buf222  # reuse
        buf271 = buf219; del buf219  # reuse
        # Topologically Sorted Source Nodes: [out_9, mixed_qkv_19, split_4, add_73, inv_norm_9, key_31, key_33, unsqueeze_36, k_beta_8, k_beta_9, value_17, transpose_57, value_18, unsqueeze_35, v_beta_8, exp_26, unsqueeze_39, decayed_k_beta_4, getitem_107, sub_17, exp_28, unsqueeze_41, key_34], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.view, aten.unsqueeze, aten._to_copy, aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_exp_mul_rsqrt_silu_slice_split_with_sizes_sub_transpose_unsqueeze_view_14.run(buf263, buf267, buf273, buf281, buf250, buf268, buf274, buf282, buf271, 262144, stream=raw_stream0)
        buf270 = reinterpret_tensor(buf227, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf227  # reuse
        buf277 = reinterpret_tensor(buf207, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf207  # reuse
        # Topologically Sorted Source Nodes: [add_73, inv_norm_9, key_31, key_33, matmul_43, strictly_upper_mask_4, ones_4, pairwise_decay_13, unsqueeze_37, unsqueeze_38, pairwise_decay_12, pairwise_decay_14, intra_chunk_attn_4, unsqueeze_36, k_beta_8, k_beta_9, matmul_42, transpose_60, ut_system_4], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.triu, aten.ones, aten.masked_fill, aten.unsqueeze, aten.sub, aten.exp, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_masked_fill_mul_ones_rsqrt_sub_transpose_triu_unsqueeze_view_15.run(buf268, buf263, buf255, buf264, buf270, buf277, 16, 32, 1, stream=raw_stream0)
        del buf263
        del buf268
        # Topologically Sorted Source Nodes: [out_9, mixed_qkv_19, split_4, value_17, transpose_57, value_18, unsqueeze_35, v_beta_8, v_beta_9, new_values_4], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.unsqueeze, aten.mul, aten.linalg_solve_triangular]
        buf272 = torch.ops.aten.linalg_solve_triangular.default(buf270, reinterpret_tensor(buf271, (1, 16, 2, 64, 128), (0, 16384, 8192, 128, 1), 0), upper=False, unitriangular=True)
        assert_tensor_metadata(buf272, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf272, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        # Topologically Sorted Source Nodes: [unsqueeze_36, k_beta_8, k_beta_9, exp_26, unsqueeze_39, decayed_k_beta_4, k_cumdecay_4], Original ATen: [aten.unsqueeze, aten.mul, aten.view, aten.exp, aten.linalg_solve_triangular]
        buf275 = torch.ops.aten.linalg_solve_triangular.default(buf270, buf274, upper=False, unitriangular=True)
        assert_tensor_metadata(buf275, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf275, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        buf278 = reinterpret_tensor(buf270, (1, 16, 64, 128), (131072, 8192, 128, 1), 0); del buf270  # reuse
        # Topologically Sorted Source Nodes: [getitem_110, getitem_111, matmul_44, v_new_8], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_16.run(buf275, buf258, buf272, buf278, 32, 16, 1, stream=raw_stream0)
        buf279 = reinterpret_tensor(buf264, (16, 64, 128), (8192, 128, 1), 0); del buf264  # reuse
        # Topologically Sorted Source Nodes: [matmul_43, intra_chunk_attn_4, getitem_113, matmul_46, getitem_110, matmul_44, v_new_8], Original ATen: [aten.view, aten.mul, aten.select, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_mul_select_sub_view_17.run(buf277, buf278, buf279, 32, 16, 1, stream=raw_stream0)
        buf280 = buf228; del buf228  # reuse
        # Topologically Sorted Source Nodes: [getitem_108, exp_29], Original ATen: [aten.select, aten.exp]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_select_18.run(buf255, buf280, 32, stream=raw_stream0)
        buf284 = buf258; del buf258  # reuse
        # Topologically Sorted Source Nodes: [add_73, inv_norm_9, key_31, key_33, getitem_108, exp_29, chunk_decay_4, getitem_114, mul_125, getitem_107, sub_17, exp_28, unsqueeze_41, key_34, getitem_115, transpose_62, matmul_47, last_recurrent_state_13], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.select, aten.exp, aten.unsqueeze, aten.slice, aten.sub, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_slice_sub_transpose_unsqueeze_view_19.run(buf282, buf278, buf280, buf284, 64, 16, 1, stream=raw_stream0)
        buf285 = reinterpret_tensor(buf278, (16, 64, 128), (8192, 128, 1), 0); del buf278  # reuse
        # Topologically Sorted Source Nodes: [getitem_118, inter_chunk_attn_9, getitem_108, exp_29, chunk_decay_4, getitem_114, mul_125, matmul_47, last_recurrent_state_13], Original ATen: [aten.select, aten.view, aten.exp, aten.unsqueeze, aten.mul, aten.add, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_select_unsqueeze_view_20.run(buf257, buf284, buf285, 32, 16, 1, stream=raw_stream0)
        buf287 = buf235; del buf235  # reuse
        # Topologically Sorted Source Nodes: [getitem_116, getitem_117, matmul_48, v_new_9], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_21.run(buf275, buf284, buf272, buf287, 32, 16, 1, stream=raw_stream0)
        buf288 = reinterpret_tensor(buf225, (16, 64, 128), (8192, 128, 1), 0); del buf225  # reuse
        # Topologically Sorted Source Nodes: [getitem_119, matmul_50, getitem_116, matmul_48, v_new_9], Original ATen: [aten.select, aten.view, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_22.run(buf277, buf287, buf288, 32, 16, 1, stream=raw_stream0)
        assert_size_stride(arg73_1, (2048, 2048), (2048, 1), 'input')
        buf290 = buf104; del buf104  # reuse
        # Topologically Sorted Source Nodes: [z_12], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf248, arg73_1, buf290, 1024, 1, 1, stream=raw_stream0)
        del arg73_1
        assert_size_stride(arg79_1, (128, ), (1, ), 'input')
        buf291 = reinterpret_tensor(buf290, (2048, 128), (128, 1), 0); del buf290  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_28, setitem_12, inter_chunk_attn_8, matmul_46, add_74, setitem_13, inter_chunk_attn_9, matmul_50, add_76, core_attn_out_29, transpose_64, core_attn_out_31, core_attn_out_32, hidden_states_39, pow_18, variance_4, add_78, rsqrt_27, hidden_states_40, to_61, hidden_states_41, z_12, z_13, z_14, to_62, silu_14, hidden_states_42, core_attn_out_33], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_copy_mean_mul_pow_rsqrt_select_silu_transpose_view_zeros_like_24.run(buf291, buf285, buf288, buf259, buf279, arg79_1, 2048, 128, stream=raw_stream0)
        del arg79_1
        assert_size_stride(arg80_1, (2048, 2048), (2048, 1), 'input')
        buf292 = reinterpret_tensor(buf248, (128, 2048), (2048, 1), 0); del buf248  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_28, setitem_12, inter_chunk_attn_8, matmul_46, add_74, setitem_13, inter_chunk_attn_9, matmul_50, add_76, core_attn_out_29, transpose_64, core_attn_out_31, core_attn_out_32, hidden_states_39, pow_18, variance_4, add_78, rsqrt_27, hidden_states_40, to_61, hidden_states_41, z_12, z_13, z_14, to_62, silu_14, hidden_states_42, core_attn_out_33, core_attn_out_34, output_30], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf291, arg80_1, buf292, 1024, 1, 1, stream=raw_stream0)
        del arg80_1
        assert_size_stride(arg81_1, (2048, ), (1, ), 'input')
        buf293 = buf188; del buf188  # reuse
        buf295 = reinterpret_tensor(buf291, (1, 128, 2048), (262144, 2048, 1), 0); del buf291  # reuse
        # Topologically Sorted Source Nodes: [down_proj_3, hidden_states_29, output_25, hidden_states_35, down_proj_4, hidden_states_37, output_30, hidden_states_43, float_38, pow_19, mean_18, add_80, rsqrt_28, output_31, float_39, add_81, output_32, hidden_states_44], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_50.run(buf293, buf194, buf240, buf246, buf292, arg81_1, buf295, 128, 2048, stream=raw_stream0)
        del arg81_1
        assert_size_stride(arg82_1, (6144, 2048), (2048, 1), 'input')
        buf296 = buf249; del buf249  # reuse
        # Topologically Sorted Source Nodes: [float_38, pow_19, mean_18, add_80, rsqrt_28, output_31, float_39, add_81, output_32, hidden_states_44, linear_44], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf295, arg82_1, buf296, 3072, 1, 1, stream=raw_stream0)
        del arg82_1
        assert_size_stride(arg83_1, (6144, 2048), (2048, 1), 'input')
        buf298 = reinterpret_tensor(buf243, (1, 128, 6144), (786432, 6144, 1), 0); del buf243  # reuse
        # Topologically Sorted Source Nodes: [linear_44, silu_15, linear_45, mul_132], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_26.run(buf295, arg83_1, buf296, buf298, 3072, 1, 1, stream=raw_stream0)
        del arg83_1
        assert_size_stride(arg84_1, (2048, 6144), (6144, 1), 'input')
        buf299 = reinterpret_tensor(buf295, (128, 2048), (2048, 1), 0); del buf295  # reuse
        # Topologically Sorted Source Nodes: [linear_44, silu_15, linear_45, mul_132, down_proj_5], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_27.run(buf298, arg84_1, buf299, 1024, 1, 1, stream=raw_stream0)
        del arg84_1
        assert_size_stride(arg85_1, (2048, ), (1, ), 'input')
        buf301 = reinterpret_tensor(buf292, (1, 128, 2048), (262144, 2048, 1), 0); del buf292  # reuse
        # Topologically Sorted Source Nodes: [down_proj_5, hidden_states_45, float_40, pow_20, mean_19, add_83, rsqrt_29, output_33, float_41, add_84, output_34, hidden_states_46], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_30.run(buf293, buf299, arg85_1, buf301, 128, 2048, stream=raw_stream0)
        del arg85_1
        assert_size_stride(arg86_1, (6144, 2048), (2048, 1), 'input')
        buf302 = reinterpret_tensor(buf298, (128, 6144), (6144, 1), 0); del buf298  # reuse
        # Topologically Sorted Source Nodes: [down_proj_5, hidden_states_45, float_40, pow_20, mean_19, add_83, rsqrt_29, output_33, float_41, add_84, output_34, hidden_states_46, mixed_qkv_20], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf301, arg86_1, buf302, 3072, 1, 1, stream=raw_stream0)
        del arg86_1
        assert_size_stride(arg90_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf303 = buf250; del buf250  # reuse
        # Topologically Sorted Source Nodes: [mixed_qkv_20, mixed_qkv_21, conv1d_5, squeeze_5, unsqueeze_42, out_10, out_11], Original ATen: [aten._unsafe_view, aten.transpose, aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_convolution_silu_slice_squeeze_transpose_unsqueeze_2.run(buf302, arg90_1, buf303, 786432, stream=raw_stream0)
        del arg90_1
        buf304 = reinterpret_tensor(buf284, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf284  # reuse
        buf305 = reinterpret_tensor(buf255, (1, 16, 128, 1), (2048, 1, 16, 2048), 0); del buf255  # reuse
        buf315 = reinterpret_tensor(buf275, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf275  # reuse
        # Topologically Sorted Source Nodes: [out_11, mixed_qkv_23, split_5, query_41, transpose_67, query_42, mul_136, sum_11, add_86, inv_norm_10, query_43, query_44], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_3.run(buf303, buf304, buf305, buf315, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg89_1, (16, 2048), (2048, 1), 'input')
        buf306 = buf266; del buf266  # reuse
        # Topologically Sorted Source Nodes: [a_5], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf301, arg89_1, buf306, 8, 1, 1, stream=raw_stream0)
        del arg89_1
        assert_size_stride(arg91_1, (16, ), (1, ), 'input')
        buf307 = buf254; del buf254  # reuse
        # Topologically Sorted Source Nodes: [exp_30, neg_7], Original ATen: [aten.exp, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_neg_5.run(arg91_1, buf307, 16, stream=raw_stream0)
        del arg91_1
        assert_size_stride(arg92_1, (16, ), (1, ), 'input')
        buf308 = buf281; del buf281  # reuse
        # Topologically Sorted Source Nodes: [exp_30, neg_7, a_5, float_43, add_85, softplus_5, g_5, transpose_71, decay_17, cum_decay_5], Original ATen: [aten.exp, aten.neg, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.view, aten.cumsum]
        workspace_5 = workspace_4; del workspace_4  # reuse
        workspace_5.zero_()
        raw_stream0 = get_raw_stream(0)
        triton_spl_fused__to_copy__unsafe_view_add_cumsum_exp_mul_neg_softplus_transpose_view_6.run(buf307, buf306, arg92_1, buf308, workspace_5, 32, 64, stream=raw_stream0)
        del arg92_1
        buf309 = buf273; del buf273  # reuse
        buf326 = reinterpret_tensor(buf267, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf267  # reuse
        buf334 = reinterpret_tensor(buf252, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf252  # reuse
        # Topologically Sorted Source Nodes: [exp_33, exp_32, getitem_127, sub_21, exp_34], Original ATen: [aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_slice_sub_7.run(buf308, buf309, buf326, buf334, 2048, stream=raw_stream0)
        buf310 = reinterpret_tensor(buf272, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf272  # reuse
        # Topologically Sorted Source Nodes: [add_86, inv_norm_10, query_43, query_44, query_46, exp_33, unsqueeze_48, query_47], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_exp_mul_rsqrt_unsqueeze_view_8.run(buf304, buf305, buf309, buf310, 262144, stream=raw_stream0)
        buf311 = reinterpret_tensor(buf304, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf304  # reuse
        # Topologically Sorted Source Nodes: [last_recurrent_state_15], Original ATen: [aten.zeros]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_zeros_9.run(buf311, 262144, stream=raw_stream0)
        buf312 = buf288; del buf288  # reuse
        # Topologically Sorted Source Nodes: [add_86, inv_norm_10, query_43, query_44, query_46, exp_33, unsqueeze_48, query_47, getitem_132, inter_chunk_attn_10, last_recurrent_state_15], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze, aten.select, aten.zeros, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_unsqueeze_view_zeros_10.run(buf310, buf311, buf312, 32, 16, 1, stream=raw_stream0)
        buf313 = reinterpret_tensor(buf257, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf257  # reuse
        buf316 = reinterpret_tensor(buf282, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf282  # reuse
        # Topologically Sorted Source Nodes: [out_11, mixed_qkv_23, split_5, key_36, transpose_68, key_37, mul_138, sum_12, add_87, inv_norm_11, key_38], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_11.run(buf303, buf313, buf316, 2048, 128, stream=raw_stream0)
        buf317 = reinterpret_tensor(buf285, (32, 64, 64), (4096, 64, 1), 0); del buf285  # reuse
        # Topologically Sorted Source Nodes: [add_86, inv_norm_10, query_43, query_44, query_46, matmul_53, add_87, inv_norm_11, key_38, key_40, transpose_73], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_mul_rsqrt_transpose_view_12.run(buf315, buf316, buf317, 16, 32, 1, stream=raw_stream0)
        assert_size_stride(arg88_1, (16, 2048), (2048, 1), 'input')
        buf319 = buf306; del buf306  # reuse
        # Topologically Sorted Source Nodes: [b_5], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf301, arg88_1, buf319, 8, 1, 1, stream=raw_stream0)
        del arg88_1
        buf320 = reinterpret_tensor(buf309, (1, 16, 128), (2048, 128, 1), 0); del buf309  # reuse
        # Topologically Sorted Source Nodes: [b_5, beta_15, transpose_70, beta_16], Original ATen: [aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_sigmoid_transpose_13.run(buf319, buf320, 16, 128, stream=raw_stream0)
        buf321 = buf315; del buf315  # reuse
        buf327 = reinterpret_tensor(buf313, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf313  # reuse
        buf335 = buf274; del buf274  # reuse
        buf324 = buf271; del buf271  # reuse
        # Topologically Sorted Source Nodes: [out_11, mixed_qkv_23, split_5, add_87, inv_norm_11, key_38, key_40, unsqueeze_44, k_beta_10, k_beta_11, value_21, transpose_69, value_22, unsqueeze_43, v_beta_10, exp_32, unsqueeze_47, decayed_k_beta_5, getitem_127, sub_21, exp_34, unsqueeze_49, key_41], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.view, aten.unsqueeze, aten._to_copy, aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_exp_mul_rsqrt_silu_slice_split_with_sizes_sub_transpose_unsqueeze_view_14.run(buf316, buf320, buf326, buf334, buf303, buf321, buf327, buf335, buf324, 262144, stream=raw_stream0)
        buf323 = reinterpret_tensor(buf279, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf279  # reuse
        buf330 = reinterpret_tensor(buf259, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf259  # reuse
        # Topologically Sorted Source Nodes: [add_87, inv_norm_11, key_38, key_40, matmul_53, strictly_upper_mask_5, ones_5, pairwise_decay_16, unsqueeze_45, unsqueeze_46, pairwise_decay_15, pairwise_decay_17, intra_chunk_attn_5, unsqueeze_44, k_beta_10, k_beta_11, matmul_52, transpose_72, ut_system_5], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.triu, aten.ones, aten.masked_fill, aten.unsqueeze, aten.sub, aten.exp, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_masked_fill_mul_ones_rsqrt_sub_transpose_triu_unsqueeze_view_15.run(buf321, buf316, buf308, buf317, buf323, buf330, 16, 32, 1, stream=raw_stream0)
        del buf316
        del buf321
        # Topologically Sorted Source Nodes: [out_11, mixed_qkv_23, split_5, value_21, transpose_69, value_22, unsqueeze_43, v_beta_10, v_beta_11, new_values_5], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.unsqueeze, aten.mul, aten.linalg_solve_triangular]
        buf325 = torch.ops.aten.linalg_solve_triangular.default(buf323, reinterpret_tensor(buf324, (1, 16, 2, 64, 128), (0, 16384, 8192, 128, 1), 0), upper=False, unitriangular=True)
        assert_tensor_metadata(buf325, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf325, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        # Topologically Sorted Source Nodes: [unsqueeze_44, k_beta_10, k_beta_11, exp_32, unsqueeze_47, decayed_k_beta_5, k_cumdecay_5], Original ATen: [aten.unsqueeze, aten.mul, aten.view, aten.exp, aten.linalg_solve_triangular]
        buf328 = torch.ops.aten.linalg_solve_triangular.default(buf323, buf327, upper=False, unitriangular=True)
        assert_tensor_metadata(buf328, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf328, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        buf331 = reinterpret_tensor(buf323, (1, 16, 64, 128), (131072, 8192, 128, 1), 0); del buf323  # reuse
        # Topologically Sorted Source Nodes: [getitem_130, getitem_131, matmul_54, v_new_10], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_16.run(buf328, buf311, buf325, buf331, 32, 16, 1, stream=raw_stream0)
        buf332 = reinterpret_tensor(buf317, (16, 64, 128), (8192, 128, 1), 0); del buf317  # reuse
        # Topologically Sorted Source Nodes: [matmul_53, intra_chunk_attn_5, getitem_133, matmul_56, getitem_130, matmul_54, v_new_10], Original ATen: [aten.view, aten.mul, aten.select, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_mul_select_sub_view_17.run(buf330, buf331, buf332, 32, 16, 1, stream=raw_stream0)
        buf333 = buf280; del buf280  # reuse
        # Topologically Sorted Source Nodes: [getitem_128, exp_35], Original ATen: [aten.select, aten.exp]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_select_18.run(buf308, buf333, 32, stream=raw_stream0)
        buf337 = buf311; del buf311  # reuse
        # Topologically Sorted Source Nodes: [add_87, inv_norm_11, key_38, key_40, getitem_128, exp_35, chunk_decay_5, getitem_134, mul_148, getitem_127, sub_21, exp_34, unsqueeze_49, key_41, getitem_135, transpose_74, matmul_57, last_recurrent_state_16], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.select, aten.exp, aten.unsqueeze, aten.slice, aten.sub, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_slice_sub_transpose_unsqueeze_view_19.run(buf335, buf331, buf333, buf337, 64, 16, 1, stream=raw_stream0)
        buf338 = reinterpret_tensor(buf331, (16, 64, 128), (8192, 128, 1), 0); del buf331  # reuse
        # Topologically Sorted Source Nodes: [getitem_138, inter_chunk_attn_11, getitem_128, exp_35, chunk_decay_5, getitem_134, mul_148, matmul_57, last_recurrent_state_16], Original ATen: [aten.select, aten.view, aten.exp, aten.unsqueeze, aten.mul, aten.add, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_select_unsqueeze_view_20.run(buf310, buf337, buf338, 32, 16, 1, stream=raw_stream0)
        buf340 = buf287; del buf287  # reuse
        # Topologically Sorted Source Nodes: [getitem_136, getitem_137, matmul_58, v_new_11], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_21.run(buf328, buf337, buf325, buf340, 32, 16, 1, stream=raw_stream0)
        buf341 = reinterpret_tensor(buf277, (16, 64, 128), (8192, 128, 1), 0); del buf277  # reuse
        # Topologically Sorted Source Nodes: [getitem_139, matmul_60, getitem_136, matmul_58, v_new_11], Original ATen: [aten.select, aten.view, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_22.run(buf330, buf340, buf341, 32, 16, 1, stream=raw_stream0)
        assert_size_stride(arg87_1, (2048, 2048), (2048, 1), 'input')
        buf343 = buf246; del buf246  # reuse
        # Topologically Sorted Source Nodes: [z_15], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf301, arg87_1, buf343, 1024, 1, 1, stream=raw_stream0)
        del arg87_1
        assert_size_stride(arg93_1, (128, ), (1, ), 'input')
        buf344 = reinterpret_tensor(buf343, (2048, 128), (128, 1), 0); del buf343  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_35, setitem_14, inter_chunk_attn_10, matmul_56, add_88, setitem_15, inter_chunk_attn_11, matmul_60, add_90, core_attn_out_36, transpose_76, core_attn_out_38, core_attn_out_39, hidden_states_47, pow_21, variance_5, add_92, rsqrt_32, hidden_states_48, to_73, hidden_states_49, z_15, z_16, z_17, to_74, silu_17, hidden_states_50, core_attn_out_40], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_copy_mean_mul_pow_rsqrt_select_silu_transpose_view_zeros_like_24.run(buf344, buf338, buf341, buf312, buf332, arg93_1, 2048, 128, stream=raw_stream0)
        del arg93_1
        assert_size_stride(arg94_1, (2048, 2048), (2048, 1), 'input')
        buf345 = reinterpret_tensor(buf301, (128, 2048), (2048, 1), 0); del buf301  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_35, setitem_14, inter_chunk_attn_10, matmul_56, add_88, setitem_15, inter_chunk_attn_11, matmul_60, add_90, core_attn_out_36, transpose_76, core_attn_out_38, core_attn_out_39, hidden_states_47, pow_21, variance_5, add_92, rsqrt_32, hidden_states_48, to_73, hidden_states_49, z_15, z_16, z_17, to_74, silu_17, hidden_states_50, core_attn_out_40, core_attn_out_41, output_35], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf344, arg94_1, buf345, 1024, 1, 1, stream=raw_stream0)
        del arg94_1
        assert_size_stride(arg95_1, (2048, ), (1, ), 'input')
        buf347 = reinterpret_tensor(buf344, (1, 128, 2048), (262144, 2048, 1), 0); del buf344  # reuse
        # Topologically Sorted Source Nodes: [down_proj_5, hidden_states_45, output_35, hidden_states_51, float_44, pow_22, mean_21, add_94, rsqrt_33, output_36, float_45, add_95, output_37, hidden_states_52], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_31.run(buf293, buf299, buf345, arg95_1, buf347, 128, 2048, stream=raw_stream0)
        del arg95_1
        assert_size_stride(arg96_1, (6144, 2048), (2048, 1), 'input')
        buf348 = buf302; del buf302  # reuse
        # Topologically Sorted Source Nodes: [linear_52], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf347, arg96_1, buf348, 3072, 1, 1, stream=raw_stream0)
        del arg96_1
        assert_size_stride(arg97_1, (6144, 2048), (2048, 1), 'input')
        buf350 = reinterpret_tensor(buf296, (1, 128, 6144), (786432, 6144, 1), 0); del buf296  # reuse
        # Topologically Sorted Source Nodes: [linear_52, silu_18, linear_53, mul_155], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_26.run(buf347, arg97_1, buf348, buf350, 3072, 1, 1, stream=raw_stream0)
        del arg97_1
        assert_size_stride(arg98_1, (2048, 6144), (6144, 1), 'input')
        buf351 = reinterpret_tensor(buf347, (128, 2048), (2048, 1), 0); del buf347  # reuse
        # Topologically Sorted Source Nodes: [linear_52, silu_18, linear_53, mul_155, down_proj_6], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_27.run(buf350, arg98_1, buf351, 1024, 1, 1, stream=raw_stream0)
        del arg98_1
        assert_size_stride(arg99_1, (2048, ), (1, ), 'input')
        buf353 = reinterpret_tensor(buf240, (1, 128, 2048), (262144, 2048, 1), 0); del buf240  # reuse
        # Topologically Sorted Source Nodes: [down_proj_5, hidden_states_45, output_35, hidden_states_51, down_proj_6, hidden_states_53, float_46, pow_23, mean_22, add_97, rsqrt_34, output_38, float_47, add_98, output_39, hidden_states_54], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_32.run(buf293, buf299, buf345, buf351, arg99_1, buf353, 128, 2048, stream=raw_stream0)
        del arg99_1
        assert_size_stride(arg100_1, (4096, 2048), (2048, 1), 'input')
        buf354 = buf159; del buf159  # reuse
        # Topologically Sorted Source Nodes: [linear_55], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_33.run(buf353, arg100_1, buf354, 2048, 1, 1, stream=raw_stream0)
        del arg100_1
        buf355 = buf160; del buf160  # reuse
        # Topologically Sorted Source Nodes: [linear_55, view_4, chunk_1, float_48, pow_24, mean_23], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_mean_pow_split_view_34.run(buf354, buf355, 1024, 256, stream=raw_stream0)
        assert_size_stride(arg101_1, (256, ), (1, ), 'input')
        buf358 = reinterpret_tensor(buf182, (1, 8, 128, 64), (65536, 8192, 64, 1), 0); del buf182  # reuse
        buf356 = reinterpret_tensor(buf358, (1, 8, 128, 32), (65536, 8192, 64, 1), 0)  # alias
        buf357 = reinterpret_tensor(buf358, (1, 8, 128, 32), (65536, 8192, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_55, view_4, chunk_1, float_48, pow_24, mean_23, add_99, rsqrt_35, output_40, float_49, add_100, output_41, type_as_17, query_states_3, q_rot_1, x2_2, neg_8, x1_2, cat_6], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_36.run(buf354, buf355, arg101_1, buf356, buf357, 32768, stream=raw_stream0)
        buf361 = reinterpret_tensor(buf194, (1, 8, 128, 256), (262144, 32768, 256, 1), 0); del buf194  # reuse
        buf359 = reinterpret_tensor(buf361, (1, 8, 128, 64), (262144, 32768, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, linear_55, view_4, chunk_1, float_48, pow_24, mean_23, add_99, rsqrt_35, output_40, float_49, add_100, output_41, type_as_17, query_states_3, q_rot_1, cos_5, mul_162, sin_5, mul_163, q_embed_2], Original ATen: [aten.select, aten.cat, aten._to_copy, aten._unsafe_view, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_37.run(buf354, buf355, arg101_1, buf161, buf358, buf165, buf359, 65536, stream=raw_stream0)
        del buf356
        del buf357
        buf360 = reinterpret_tensor(buf361, (1, 8, 128, 192), (262144, 32768, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, linear_55, view_4, chunk_1, float_48, pow_24, mean_23, add_99, rsqrt_35, output_40, float_49, add_100, output_41, type_as_17, query_states_3, q_rot_1, cos_5, mul_162, sin_5, mul_163, q_embed_2, q_pass_1, q_embed_3], Original ATen: [aten.select, aten.cat, aten._to_copy, aten._unsafe_view, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_38.run(buf354, buf355, arg101_1, buf360, 196608, stream=raw_stream0)
        del arg101_1
        assert_size_stride(arg102_1, (512, 2048), (2048, 1), 'input')
        del buf359
        del buf360
        buf362 = reinterpret_tensor(buf358, (128, 512), (512, 1), 0); del buf358  # reuse
        # Topologically Sorted Source Nodes: [linear_56], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_39.run(buf353, arg102_1, buf362, 256, 1, 1, stream=raw_stream0)
        del arg102_1
        buf363 = buf170; del buf170  # reuse
        # Topologically Sorted Source Nodes: [linear_56, view_6, float_50, pow_25, mean_24], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_mean_pow_view_40.run(buf362, buf363, 256, 256, stream=raw_stream0)
        assert_size_stride(arg103_1, (256, ), (1, ), 'input')
        buf366 = buf173; del buf173  # reuse
        buf364 = reinterpret_tensor(buf366, (1, 2, 128, 32), (16384, 8192, 64, 1), 0)  # alias
        buf365 = reinterpret_tensor(buf366, (1, 2, 128, 32), (16384, 8192, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_56, view_6, float_50, pow_25, mean_24, add_101, rsqrt_36, output_42, float_51, add_102, output_43, type_as_18, key_states_2, k_rot_1, x2_3, neg_9, x1_3, cat_7], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_41.run(buf362, buf363, arg103_1, buf364, buf365, 8192, stream=raw_stream0)
        buf369 = reinterpret_tensor(buf169, (1, 2, 128, 256), (65536, 32768, 256, 1), 0); del buf169  # reuse
        buf367 = reinterpret_tensor(buf369, (1, 2, 128, 64), (65536, 32768, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, cos_5, sin_5, linear_56, view_6, float_50, pow_25, mean_24, add_101, rsqrt_36, output_42, float_51, add_102, output_43, type_as_18, key_states_2, k_rot_1, mul_164, mul_165, k_embed_2], Original ATen: [aten.select, aten.cat, aten._to_copy, aten.unsqueeze, aten._unsafe_view, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_42.run(buf362, buf363, arg103_1, buf161, buf366, buf165, buf367, 16384, stream=raw_stream0)
        del buf364
        del buf365
        buf368 = reinterpret_tensor(buf369, (1, 2, 128, 192), (65536, 32768, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, cos_5, sin_5, linear_56, view_6, float_50, pow_25, mean_24, add_101, rsqrt_36, output_42, float_51, add_102, output_43, type_as_18, key_states_2, k_rot_1, mul_164, mul_165, k_embed_2, k_pass_1, k_embed_3], Original ATen: [aten.select, aten.cat, aten._to_copy, aten.unsqueeze, aten._unsafe_view, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_43.run(buf362, buf363, arg103_1, buf368, 49152, stream=raw_stream0)
        del arg103_1
        buf370 = reinterpret_tensor(buf168, (1, 2, 4, 128, 256), (262144, 131072, 32768, 256, 1), 0); del buf168  # reuse
        # Topologically Sorted Source Nodes: [getitem_153, hidden_states_55, key_states_3], Original ATen: [aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_clone_expand_unsqueeze_44.run(buf369, buf370, 262144, stream=raw_stream0)
        del buf367
        del buf368
        buf371 = reinterpret_tensor(buf183, (8, 128, 128), (16384, 128, 1), 0); del buf183  # reuse
        # Topologically Sorted Source Nodes: [matmul_62, getitem_153, hidden_states_55, key_states_3, transpose_80], Original ATen: [aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_45.run(buf361, buf370, buf371, 64, 8, 1, stream=raw_stream0)
        buf373 = reinterpret_tensor(buf341, (1, 8, 128, 128), (131072, 16384, 128, 1), 0); del buf341  # reuse
        buf376 = reinterpret_tensor(buf178, (1, 8, 128, 128), (131072, 16384, 128, 1), 0); del buf178  # reuse
        # Topologically Sorted Source Nodes: [mask, full, getitem, matmul_62, attn_weights_4, attn_weights_5, softmax_1, attn_weights_6], Original ATen: [aten.triu, aten.full, aten.unsqueeze, aten.view, aten.mul, aten.add, aten._to_copy, aten._softmax]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__softmax__to_copy_add_full_mul_triu_unsqueeze_view_46.run(buf371, buf373, buf376, 1024, 128, stream=raw_stream0)
        assert_size_stride(arg104_1, (512, 2048), (2048, 1), 'input')
        buf375 = reinterpret_tensor(buf369, (128, 512), (512, 1), 0); del buf369  # reuse
        # Topologically Sorted Source Nodes: [linear_57], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_39.run(buf353, arg104_1, buf375, 256, 1, 1, stream=raw_stream0)
        del arg104_1
        buf377 = reinterpret_tensor(buf353, (1, 2, 4, 128, 256), (262144, 131072, 32768, 256, 1), 0); del buf353  # reuse
        # Topologically Sorted Source Nodes: [linear_57, view_7, value_states_2, getitem_154, hidden_states_56, value_states_3], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_clone_expand_transpose_unsqueeze_view_47.run(buf375, buf377, 262144, stream=raw_stream0)
        buf378 = reinterpret_tensor(buf370, (8, 128, 256), (32768, 256, 1), 0); del buf370  # reuse
        # Topologically Sorted Source Nodes: [softmax_1, attn_weights_6, attn_output_5, linear_57, view_7, value_states_2, getitem_154, hidden_states_56, value_states_3], Original ATen: [aten._softmax, aten._to_copy, aten.view, aten._unsafe_view, aten.transpose, aten.unsqueeze, aten.expand, aten.clone, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__softmax__to_copy__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_48.run(buf376, buf377, buf378, 128, 8, 1, stream=raw_stream0)
        buf379 = reinterpret_tensor(buf377, (1, 128, 2048), (262144, 2048, 1), 0); del buf377  # reuse
        # Topologically Sorted Source Nodes: [linear_55, view_4, chunk_1, attn_output_5, transpose_81, attn_output_6, reshape_85, gate_3, sigmoid_7, attn_output_8], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten.transpose, aten.clone, aten.sigmoid, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_clone_mul_sigmoid_split_transpose_view_49.run(buf378, buf354, buf379, 262144, stream=raw_stream0)
        assert_size_stride(arg105_1, (2048, 2048), (2048, 1), 'input')
        buf380 = reinterpret_tensor(buf378, (128, 2048), (2048, 1), 0); del buf378  # reuse
        # Topologically Sorted Source Nodes: [linear_55, view_4, chunk_1, attn_output_5, transpose_81, attn_output_6, reshape_85, gate_3, sigmoid_7, attn_output_8, attn_output_9], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten.transpose, aten.clone, aten.sigmoid, aten.mul, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf379, arg105_1, buf380, 1024, 1, 1, stream=raw_stream0)
        del arg105_1
        assert_size_stride(arg106_1, (2048, ), (1, ), 'input')
        buf381 = buf293; del buf293  # reuse
        buf383 = buf379; del buf379  # reuse
        # Topologically Sorted Source Nodes: [down_proj_5, hidden_states_45, output_35, hidden_states_51, down_proj_6, hidden_states_53, attn_output_9, hidden_states_57, float_52, pow_26, mean_25, add_107, rsqrt_37, output_44, float_53, add_108, output_45, hidden_states_58], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_50.run(buf381, buf299, buf345, buf351, buf380, arg106_1, buf383, 128, 2048, stream=raw_stream0)
        del arg106_1
        assert_size_stride(arg107_1, (6144, 2048), (2048, 1), 'input')
        buf384 = reinterpret_tensor(buf350, (128, 6144), (6144, 1), 0); del buf350  # reuse
        # Topologically Sorted Source Nodes: [float_52, pow_26, mean_25, add_107, rsqrt_37, output_44, float_53, add_108, output_45, hidden_states_58, linear_59], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf383, arg107_1, buf384, 3072, 1, 1, stream=raw_stream0)
        del arg107_1
        assert_size_stride(arg108_1, (6144, 2048), (2048, 1), 'input')
        buf386 = reinterpret_tensor(buf348, (1, 128, 6144), (786432, 6144, 1), 0); del buf348  # reuse
        # Topologically Sorted Source Nodes: [linear_59, silu_19, linear_60, mul_170], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_26.run(buf383, arg108_1, buf384, buf386, 3072, 1, 1, stream=raw_stream0)
        del arg108_1
        assert_size_stride(arg109_1, (2048, 6144), (6144, 1), 'input')
        buf387 = reinterpret_tensor(buf383, (128, 2048), (2048, 1), 0); del buf383  # reuse
        # Topologically Sorted Source Nodes: [linear_59, silu_19, linear_60, mul_170, down_proj_7], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_27.run(buf386, arg109_1, buf387, 1024, 1, 1, stream=raw_stream0)
        del arg109_1
        assert_size_stride(arg110_1, (2048, ), (1, ), 'input')
        buf389 = reinterpret_tensor(buf380, (1, 128, 2048), (262144, 2048, 1), 0); del buf380  # reuse
        # Topologically Sorted Source Nodes: [down_proj_7, hidden_states_59, float_54, pow_27, mean_26, add_110, rsqrt_38, output_46, float_55, add_111, output_47, hidden_states_60], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_30.run(buf381, buf387, arg110_1, buf389, 128, 2048, stream=raw_stream0)
        del arg110_1
        assert_size_stride(arg111_1, (6144, 2048), (2048, 1), 'input')
        buf390 = reinterpret_tensor(buf386, (128, 6144), (6144, 1), 0); del buf386  # reuse
        # Topologically Sorted Source Nodes: [down_proj_7, hidden_states_59, float_54, pow_27, mean_26, add_110, rsqrt_38, output_46, float_55, add_111, output_47, hidden_states_60, mixed_qkv_24], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf389, arg111_1, buf390, 3072, 1, 1, stream=raw_stream0)
        del arg111_1
        assert_size_stride(arg115_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf391 = buf303; del buf303  # reuse
        # Topologically Sorted Source Nodes: [mixed_qkv_24, mixed_qkv_25, conv1d_6, squeeze_6, unsqueeze_52, out_12, out_13], Original ATen: [aten._unsafe_view, aten.transpose, aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_convolution_silu_slice_squeeze_transpose_unsqueeze_2.run(buf390, arg115_1, buf391, 786432, stream=raw_stream0)
        del arg115_1
        buf392 = reinterpret_tensor(buf337, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf337  # reuse
        buf393 = reinterpret_tensor(buf308, (1, 16, 128, 1), (2048, 1, 16, 2048), 0); del buf308  # reuse
        buf403 = reinterpret_tensor(buf328, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf328  # reuse
        # Topologically Sorted Source Nodes: [out_13, mixed_qkv_27, split_6, query_49, transpose_84, query_50, mul_174, sum_13, add_113, inv_norm_12, query_51, query_52], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_3.run(buf391, buf392, buf393, buf403, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg114_1, (16, 2048), (2048, 1), 'input')
        buf394 = buf319; del buf319  # reuse
        # Topologically Sorted Source Nodes: [a_6], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf389, arg114_1, buf394, 8, 1, 1, stream=raw_stream0)
        del arg114_1
        assert_size_stride(arg116_1, (16, ), (1, ), 'input')
        buf395 = buf307; del buf307  # reuse
        # Topologically Sorted Source Nodes: [exp_36, neg_10], Original ATen: [aten.exp, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_neg_5.run(arg116_1, buf395, 16, stream=raw_stream0)
        del arg116_1
        assert_size_stride(arg117_1, (16, ), (1, ), 'input')
        buf396 = buf334; del buf334  # reuse
        # Topologically Sorted Source Nodes: [exp_36, neg_10, a_6, float_57, add_112, softplus_6, g_6, transpose_88, decay_20, cum_decay_6], Original ATen: [aten.exp, aten.neg, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.view, aten.cumsum]
        workspace_6 = workspace_5; del workspace_5  # reuse
        workspace_6.zero_()
        raw_stream0 = get_raw_stream(0)
        triton_spl_fused__to_copy__unsafe_view_add_cumsum_exp_mul_neg_softplus_transpose_view_6.run(buf395, buf394, arg117_1, buf396, workspace_6, 32, 64, stream=raw_stream0)
        del arg117_1
        buf397 = buf326; del buf326  # reuse
        buf414 = reinterpret_tensor(buf320, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf320  # reuse
        buf422 = reinterpret_tensor(buf305, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf305  # reuse
        # Topologically Sorted Source Nodes: [exp_39, exp_38, getitem_159, sub_25, exp_40], Original ATen: [aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_slice_sub_7.run(buf396, buf397, buf414, buf422, 2048, stream=raw_stream0)
        buf398 = reinterpret_tensor(buf325, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf325  # reuse
        # Topologically Sorted Source Nodes: [add_113, inv_norm_12, query_51, query_52, query_54, exp_39, unsqueeze_58, query_55], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_exp_mul_rsqrt_unsqueeze_view_8.run(buf392, buf393, buf397, buf398, 262144, stream=raw_stream0)
        buf399 = reinterpret_tensor(buf392, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf392  # reuse
        # Topologically Sorted Source Nodes: [last_recurrent_state_18], Original ATen: [aten.zeros]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_zeros_9.run(buf399, 262144, stream=raw_stream0)
        buf400 = reinterpret_tensor(buf373, (16, 64, 128), (8192, 128, 1), 0); del buf373  # reuse
        # Topologically Sorted Source Nodes: [add_113, inv_norm_12, query_51, query_52, query_54, exp_39, unsqueeze_58, query_55, getitem_164, inter_chunk_attn_12, last_recurrent_state_18], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze, aten.select, aten.zeros, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_unsqueeze_view_zeros_10.run(buf398, buf399, buf400, 32, 16, 1, stream=raw_stream0)
        buf401 = reinterpret_tensor(buf310, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf310  # reuse
        buf404 = reinterpret_tensor(buf335, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf335  # reuse
        # Topologically Sorted Source Nodes: [out_13, mixed_qkv_27, split_6, key_43, transpose_85, key_44, mul_176, sum_14, add_114, inv_norm_13, key_45], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_11.run(buf391, buf401, buf404, 2048, 128, stream=raw_stream0)
        buf405 = reinterpret_tensor(buf338, (32, 64, 64), (4096, 64, 1), 0); del buf338  # reuse
        # Topologically Sorted Source Nodes: [add_113, inv_norm_12, query_51, query_52, query_54, matmul_65, add_114, inv_norm_13, key_45, key_47, transpose_90], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_mul_rsqrt_transpose_view_12.run(buf403, buf404, buf405, 16, 32, 1, stream=raw_stream0)
        assert_size_stride(arg113_1, (16, 2048), (2048, 1), 'input')
        buf407 = buf394; del buf394  # reuse
        # Topologically Sorted Source Nodes: [b_6], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf389, arg113_1, buf407, 8, 1, 1, stream=raw_stream0)
        del arg113_1
        buf408 = reinterpret_tensor(buf397, (1, 16, 128), (2048, 128, 1), 0); del buf397  # reuse
        # Topologically Sorted Source Nodes: [b_6, beta_18, transpose_87, beta_19], Original ATen: [aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_sigmoid_transpose_13.run(buf407, buf408, 16, 128, stream=raw_stream0)
        buf409 = buf403; del buf403  # reuse
        buf415 = reinterpret_tensor(buf401, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf401  # reuse
        buf423 = buf327; del buf327  # reuse
        buf412 = buf324; del buf324  # reuse
        # Topologically Sorted Source Nodes: [out_13, mixed_qkv_27, split_6, add_114, inv_norm_13, key_45, key_47, unsqueeze_54, k_beta_12, k_beta_13, value_25, transpose_86, value_26, unsqueeze_53, v_beta_12, exp_38, unsqueeze_57, decayed_k_beta_6, getitem_159, sub_25, exp_40, unsqueeze_59, key_48], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.view, aten.unsqueeze, aten._to_copy, aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_exp_mul_rsqrt_silu_slice_split_with_sizes_sub_transpose_unsqueeze_view_14.run(buf404, buf408, buf414, buf422, buf391, buf409, buf415, buf423, buf412, 262144, stream=raw_stream0)
        buf411 = reinterpret_tensor(buf332, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf332  # reuse
        buf418 = reinterpret_tensor(buf312, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf312  # reuse
        # Topologically Sorted Source Nodes: [add_114, inv_norm_13, key_45, key_47, matmul_65, strictly_upper_mask_6, ones_6, pairwise_decay_19, unsqueeze_55, unsqueeze_56, pairwise_decay_18, pairwise_decay_20, intra_chunk_attn_6, unsqueeze_54, k_beta_12, k_beta_13, matmul_64, transpose_89, ut_system_6], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.triu, aten.ones, aten.masked_fill, aten.unsqueeze, aten.sub, aten.exp, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_masked_fill_mul_ones_rsqrt_sub_transpose_triu_unsqueeze_view_15.run(buf409, buf404, buf396, buf405, buf411, buf418, 16, 32, 1, stream=raw_stream0)
        del buf404
        del buf409
        # Topologically Sorted Source Nodes: [out_13, mixed_qkv_27, split_6, value_25, transpose_86, value_26, unsqueeze_53, v_beta_12, v_beta_13, new_values_6], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.unsqueeze, aten.mul, aten.linalg_solve_triangular]
        buf413 = torch.ops.aten.linalg_solve_triangular.default(buf411, reinterpret_tensor(buf412, (1, 16, 2, 64, 128), (0, 16384, 8192, 128, 1), 0), upper=False, unitriangular=True)
        assert_tensor_metadata(buf413, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf413, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        # Topologically Sorted Source Nodes: [unsqueeze_54, k_beta_12, k_beta_13, exp_38, unsqueeze_57, decayed_k_beta_6, k_cumdecay_6], Original ATen: [aten.unsqueeze, aten.mul, aten.view, aten.exp, aten.linalg_solve_triangular]
        buf416 = torch.ops.aten.linalg_solve_triangular.default(buf411, buf415, upper=False, unitriangular=True)
        assert_tensor_metadata(buf416, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf416, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        buf419 = reinterpret_tensor(buf411, (1, 16, 64, 128), (131072, 8192, 128, 1), 0); del buf411  # reuse
        # Topologically Sorted Source Nodes: [getitem_162, getitem_163, matmul_66, v_new_12], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_16.run(buf416, buf399, buf413, buf419, 32, 16, 1, stream=raw_stream0)
        buf420 = reinterpret_tensor(buf405, (16, 64, 128), (8192, 128, 1), 0); del buf405  # reuse
        # Topologically Sorted Source Nodes: [matmul_65, intra_chunk_attn_6, getitem_165, matmul_68, getitem_162, matmul_66, v_new_12], Original ATen: [aten.view, aten.mul, aten.select, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_mul_select_sub_view_17.run(buf418, buf419, buf420, 32, 16, 1, stream=raw_stream0)
        buf421 = buf333; del buf333  # reuse
        # Topologically Sorted Source Nodes: [getitem_160, exp_41], Original ATen: [aten.select, aten.exp]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_select_18.run(buf396, buf421, 32, stream=raw_stream0)
        buf425 = buf399; del buf399  # reuse
        # Topologically Sorted Source Nodes: [add_114, inv_norm_13, key_45, key_47, getitem_160, exp_41, chunk_decay_6, getitem_166, mul_186, getitem_159, sub_25, exp_40, unsqueeze_59, key_48, getitem_167, transpose_91, matmul_69, last_recurrent_state_19], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.select, aten.exp, aten.unsqueeze, aten.slice, aten.sub, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_slice_sub_transpose_unsqueeze_view_19.run(buf423, buf419, buf421, buf425, 64, 16, 1, stream=raw_stream0)
        buf426 = reinterpret_tensor(buf419, (16, 64, 128), (8192, 128, 1), 0); del buf419  # reuse
        # Topologically Sorted Source Nodes: [getitem_170, inter_chunk_attn_13, getitem_160, exp_41, chunk_decay_6, getitem_166, mul_186, matmul_69, last_recurrent_state_19], Original ATen: [aten.select, aten.view, aten.exp, aten.unsqueeze, aten.mul, aten.add, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_select_unsqueeze_view_20.run(buf398, buf425, buf426, 32, 16, 1, stream=raw_stream0)
        buf428 = buf340; del buf340  # reuse
        # Topologically Sorted Source Nodes: [getitem_168, getitem_169, matmul_70, v_new_13], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_21.run(buf416, buf425, buf413, buf428, 32, 16, 1, stream=raw_stream0)
        buf429 = reinterpret_tensor(buf330, (16, 64, 128), (8192, 128, 1), 0); del buf330  # reuse
        # Topologically Sorted Source Nodes: [getitem_171, matmul_72, getitem_168, matmul_70, v_new_13], Original ATen: [aten.select, aten.view, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_22.run(buf418, buf428, buf429, 32, 16, 1, stream=raw_stream0)
        assert_size_stride(arg112_1, (2048, 2048), (2048, 1), 'input')
        buf431 = buf351; del buf351  # reuse
        # Topologically Sorted Source Nodes: [z_18], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf389, arg112_1, buf431, 1024, 1, 1, stream=raw_stream0)
        del arg112_1
        assert_size_stride(arg118_1, (128, ), (1, ), 'input')
        buf432 = reinterpret_tensor(buf431, (2048, 128), (128, 1), 0); del buf431  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_42, setitem_16, inter_chunk_attn_12, matmul_68, add_115, setitem_17, inter_chunk_attn_13, matmul_72, add_117, core_attn_out_43, transpose_93, core_attn_out_45, core_attn_out_46, hidden_states_61, pow_28, variance_6, add_119, rsqrt_41, hidden_states_62, to_86, hidden_states_63, z_18, z_19, z_20, to_87, silu_21, hidden_states_64, core_attn_out_47], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_copy_mean_mul_pow_rsqrt_select_silu_transpose_view_zeros_like_24.run(buf432, buf426, buf429, buf400, buf420, arg118_1, 2048, 128, stream=raw_stream0)
        del arg118_1
        assert_size_stride(arg119_1, (2048, 2048), (2048, 1), 'input')
        buf433 = reinterpret_tensor(buf389, (128, 2048), (2048, 1), 0); del buf389  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_42, setitem_16, inter_chunk_attn_12, matmul_68, add_115, setitem_17, inter_chunk_attn_13, matmul_72, add_117, core_attn_out_43, transpose_93, core_attn_out_45, core_attn_out_46, hidden_states_61, pow_28, variance_6, add_119, rsqrt_41, hidden_states_62, to_86, hidden_states_63, z_18, z_19, z_20, to_87, silu_21, hidden_states_64, core_attn_out_47, core_attn_out_48, output_48], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf432, arg119_1, buf433, 1024, 1, 1, stream=raw_stream0)
        del arg119_1
        assert_size_stride(arg120_1, (2048, ), (1, ), 'input')
        buf435 = reinterpret_tensor(buf432, (1, 128, 2048), (262144, 2048, 1), 0); del buf432  # reuse
        # Topologically Sorted Source Nodes: [down_proj_7, hidden_states_59, output_48, hidden_states_65, float_58, pow_29, mean_28, add_121, rsqrt_42, output_49, float_59, add_122, output_50, hidden_states_66], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_31.run(buf381, buf387, buf433, arg120_1, buf435, 128, 2048, stream=raw_stream0)
        del arg120_1
        assert_size_stride(arg121_1, (6144, 2048), (2048, 1), 'input')
        buf436 = buf390; del buf390  # reuse
        # Topologically Sorted Source Nodes: [linear_67], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf435, arg121_1, buf436, 3072, 1, 1, stream=raw_stream0)
        del arg121_1
        assert_size_stride(arg122_1, (6144, 2048), (2048, 1), 'input')
        buf438 = reinterpret_tensor(buf384, (1, 128, 6144), (786432, 6144, 1), 0); del buf384  # reuse
        # Topologically Sorted Source Nodes: [linear_67, silu_22, linear_68, mul_193], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_26.run(buf435, arg122_1, buf436, buf438, 3072, 1, 1, stream=raw_stream0)
        del arg122_1
        assert_size_stride(arg123_1, (2048, 6144), (6144, 1), 'input')
        buf439 = reinterpret_tensor(buf435, (128, 2048), (2048, 1), 0); del buf435  # reuse
        # Topologically Sorted Source Nodes: [linear_67, silu_22, linear_68, mul_193, down_proj_8], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_27.run(buf438, arg123_1, buf439, 1024, 1, 1, stream=raw_stream0)
        del arg123_1
        assert_size_stride(arg124_1, (2048, ), (1, ), 'input')
        buf441 = reinterpret_tensor(buf345, (1, 128, 2048), (262144, 2048, 1), 0); del buf345  # reuse
        # Topologically Sorted Source Nodes: [down_proj_7, hidden_states_59, output_48, hidden_states_65, down_proj_8, hidden_states_67, float_60, pow_30, mean_29, add_124, rsqrt_43, output_51, float_61, add_125, output_52, hidden_states_68], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_32.run(buf381, buf387, buf433, buf439, arg124_1, buf441, 128, 2048, stream=raw_stream0)
        del arg124_1
        assert_size_stride(arg125_1, (6144, 2048), (2048, 1), 'input')
        buf442 = reinterpret_tensor(buf438, (128, 6144), (6144, 1), 0); del buf438  # reuse
        # Topologically Sorted Source Nodes: [mixed_qkv_28], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf441, arg125_1, buf442, 3072, 1, 1, stream=raw_stream0)
        del arg125_1
        assert_size_stride(arg129_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf443 = buf391; del buf391  # reuse
        # Topologically Sorted Source Nodes: [mixed_qkv_28, mixed_qkv_29, conv1d_7, squeeze_7, unsqueeze_60, out_14, out_15], Original ATen: [aten._unsafe_view, aten.transpose, aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_convolution_silu_slice_squeeze_transpose_unsqueeze_2.run(buf442, arg129_1, buf443, 786432, stream=raw_stream0)
        del arg129_1
        buf444 = reinterpret_tensor(buf425, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf425  # reuse
        buf445 = reinterpret_tensor(buf396, (1, 16, 128, 1), (2048, 1, 16, 2048), 0); del buf396  # reuse
        buf455 = reinterpret_tensor(buf416, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf416  # reuse
        # Topologically Sorted Source Nodes: [out_15, mixed_qkv_31, split_7, query_57, transpose_96, query_58, mul_197, sum_15, add_127, inv_norm_14, query_59, query_60], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_3.run(buf443, buf444, buf445, buf455, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg128_1, (16, 2048), (2048, 1), 'input')
        buf446 = buf407; del buf407  # reuse
        # Topologically Sorted Source Nodes: [a_7], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf441, arg128_1, buf446, 8, 1, 1, stream=raw_stream0)
        del arg128_1
        assert_size_stride(arg130_1, (16, ), (1, ), 'input')
        buf447 = buf395; del buf395  # reuse
        # Topologically Sorted Source Nodes: [exp_42, neg_11], Original ATen: [aten.exp, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_neg_5.run(arg130_1, buf447, 16, stream=raw_stream0)
        del arg130_1
        assert_size_stride(arg131_1, (16, ), (1, ), 'input')
        buf448 = buf422; del buf422  # reuse
        # Topologically Sorted Source Nodes: [exp_42, neg_11, a_7, float_63, add_126, softplus_7, g_7, transpose_100, decay_23, cum_decay_7], Original ATen: [aten.exp, aten.neg, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.view, aten.cumsum]
        workspace_7 = workspace_6; del workspace_6  # reuse
        workspace_7.zero_()
        raw_stream0 = get_raw_stream(0)
        triton_spl_fused__to_copy__unsafe_view_add_cumsum_exp_mul_neg_softplus_transpose_view_6.run(buf447, buf446, arg131_1, buf448, workspace_7, 32, 64, stream=raw_stream0)
        del arg131_1
        buf449 = buf414; del buf414  # reuse
        buf466 = reinterpret_tensor(buf408, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf408  # reuse
        buf474 = reinterpret_tensor(buf393, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf393  # reuse
        # Topologically Sorted Source Nodes: [exp_45, exp_44, getitem_179, sub_29, exp_46], Original ATen: [aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_slice_sub_7.run(buf448, buf449, buf466, buf474, 2048, stream=raw_stream0)
        buf450 = reinterpret_tensor(buf413, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf413  # reuse
        # Topologically Sorted Source Nodes: [add_127, inv_norm_14, query_59, query_60, query_62, exp_45, unsqueeze_66, query_63], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_exp_mul_rsqrt_unsqueeze_view_8.run(buf444, buf445, buf449, buf450, 262144, stream=raw_stream0)
        buf451 = reinterpret_tensor(buf444, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf444  # reuse
        # Topologically Sorted Source Nodes: [last_recurrent_state_21], Original ATen: [aten.zeros]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_zeros_9.run(buf451, 262144, stream=raw_stream0)
        buf452 = buf429; del buf429  # reuse
        # Topologically Sorted Source Nodes: [add_127, inv_norm_14, query_59, query_60, query_62, exp_45, unsqueeze_66, query_63, getitem_184, inter_chunk_attn_14, last_recurrent_state_21], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze, aten.select, aten.zeros, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_unsqueeze_view_zeros_10.run(buf450, buf451, buf452, 32, 16, 1, stream=raw_stream0)
        buf453 = reinterpret_tensor(buf398, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf398  # reuse
        buf456 = reinterpret_tensor(buf423, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf423  # reuse
        # Topologically Sorted Source Nodes: [out_15, mixed_qkv_31, split_7, key_50, transpose_97, key_51, mul_199, sum_16, add_128, inv_norm_15, key_52], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_11.run(buf443, buf453, buf456, 2048, 128, stream=raw_stream0)
        buf457 = reinterpret_tensor(buf426, (32, 64, 64), (4096, 64, 1), 0); del buf426  # reuse
        # Topologically Sorted Source Nodes: [add_127, inv_norm_14, query_59, query_60, query_62, matmul_75, add_128, inv_norm_15, key_52, key_54, transpose_102], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_mul_rsqrt_transpose_view_12.run(buf455, buf456, buf457, 16, 32, 1, stream=raw_stream0)
        assert_size_stride(arg127_1, (16, 2048), (2048, 1), 'input')
        buf459 = buf446; del buf446  # reuse
        # Topologically Sorted Source Nodes: [b_7], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf441, arg127_1, buf459, 8, 1, 1, stream=raw_stream0)
        del arg127_1
        buf460 = reinterpret_tensor(buf449, (1, 16, 128), (2048, 128, 1), 0); del buf449  # reuse
        # Topologically Sorted Source Nodes: [b_7, beta_21, transpose_99, beta_22], Original ATen: [aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_sigmoid_transpose_13.run(buf459, buf460, 16, 128, stream=raw_stream0)
        buf461 = buf455; del buf455  # reuse
        buf467 = reinterpret_tensor(buf453, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf453  # reuse
        buf475 = buf415; del buf415  # reuse
        buf464 = buf412; del buf412  # reuse
        # Topologically Sorted Source Nodes: [out_15, mixed_qkv_31, split_7, add_128, inv_norm_15, key_52, key_54, unsqueeze_62, k_beta_14, k_beta_15, value_29, transpose_98, value_30, unsqueeze_61, v_beta_14, exp_44, unsqueeze_65, decayed_k_beta_7, getitem_179, sub_29, exp_46, unsqueeze_67, key_55], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.view, aten.unsqueeze, aten._to_copy, aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_exp_mul_rsqrt_silu_slice_split_with_sizes_sub_transpose_unsqueeze_view_14.run(buf456, buf460, buf466, buf474, buf443, buf461, buf467, buf475, buf464, 262144, stream=raw_stream0)
        buf463 = reinterpret_tensor(buf420, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf420  # reuse
        buf470 = reinterpret_tensor(buf400, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf400  # reuse
        # Topologically Sorted Source Nodes: [add_128, inv_norm_15, key_52, key_54, matmul_75, strictly_upper_mask_7, ones_7, pairwise_decay_22, unsqueeze_63, unsqueeze_64, pairwise_decay_21, pairwise_decay_23, intra_chunk_attn_7, unsqueeze_62, k_beta_14, k_beta_15, matmul_74, transpose_101, ut_system_7], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.triu, aten.ones, aten.masked_fill, aten.unsqueeze, aten.sub, aten.exp, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_masked_fill_mul_ones_rsqrt_sub_transpose_triu_unsqueeze_view_15.run(buf461, buf456, buf448, buf457, buf463, buf470, 16, 32, 1, stream=raw_stream0)
        del buf456
        del buf461
        # Topologically Sorted Source Nodes: [out_15, mixed_qkv_31, split_7, value_29, transpose_98, value_30, unsqueeze_61, v_beta_14, v_beta_15, new_values_7], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.unsqueeze, aten.mul, aten.linalg_solve_triangular]
        buf465 = torch.ops.aten.linalg_solve_triangular.default(buf463, reinterpret_tensor(buf464, (1, 16, 2, 64, 128), (0, 16384, 8192, 128, 1), 0), upper=False, unitriangular=True)
        assert_tensor_metadata(buf465, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf465, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        # Topologically Sorted Source Nodes: [unsqueeze_62, k_beta_14, k_beta_15, exp_44, unsqueeze_65, decayed_k_beta_7, k_cumdecay_7], Original ATen: [aten.unsqueeze, aten.mul, aten.view, aten.exp, aten.linalg_solve_triangular]
        buf468 = torch.ops.aten.linalg_solve_triangular.default(buf463, buf467, upper=False, unitriangular=True)
        assert_tensor_metadata(buf468, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf468, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        buf471 = reinterpret_tensor(buf463, (1, 16, 64, 128), (131072, 8192, 128, 1), 0); del buf463  # reuse
        # Topologically Sorted Source Nodes: [getitem_182, getitem_183, matmul_76, v_new_14], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_16.run(buf468, buf451, buf465, buf471, 32, 16, 1, stream=raw_stream0)
        buf472 = reinterpret_tensor(buf457, (16, 64, 128), (8192, 128, 1), 0); del buf457  # reuse
        # Topologically Sorted Source Nodes: [matmul_75, intra_chunk_attn_7, getitem_185, matmul_78, getitem_182, matmul_76, v_new_14], Original ATen: [aten.view, aten.mul, aten.select, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_mul_select_sub_view_17.run(buf470, buf471, buf472, 32, 16, 1, stream=raw_stream0)
        buf473 = buf421; del buf421  # reuse
        # Topologically Sorted Source Nodes: [getitem_180, exp_47], Original ATen: [aten.select, aten.exp]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_select_18.run(buf448, buf473, 32, stream=raw_stream0)
        buf477 = buf451; del buf451  # reuse
        # Topologically Sorted Source Nodes: [add_128, inv_norm_15, key_52, key_54, getitem_180, exp_47, chunk_decay_7, getitem_186, mul_209, getitem_179, sub_29, exp_46, unsqueeze_67, key_55, getitem_187, transpose_103, matmul_79, last_recurrent_state_22], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.select, aten.exp, aten.unsqueeze, aten.slice, aten.sub, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_slice_sub_transpose_unsqueeze_view_19.run(buf475, buf471, buf473, buf477, 64, 16, 1, stream=raw_stream0)
        buf478 = reinterpret_tensor(buf471, (16, 64, 128), (8192, 128, 1), 0); del buf471  # reuse
        # Topologically Sorted Source Nodes: [getitem_190, inter_chunk_attn_15, getitem_180, exp_47, chunk_decay_7, getitem_186, mul_209, matmul_79, last_recurrent_state_22], Original ATen: [aten.select, aten.view, aten.exp, aten.unsqueeze, aten.mul, aten.add, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_select_unsqueeze_view_20.run(buf450, buf477, buf478, 32, 16, 1, stream=raw_stream0)
        buf480 = buf428; del buf428  # reuse
        # Topologically Sorted Source Nodes: [getitem_188, getitem_189, matmul_80, v_new_15], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_21.run(buf468, buf477, buf465, buf480, 32, 16, 1, stream=raw_stream0)
        buf481 = reinterpret_tensor(buf418, (16, 64, 128), (8192, 128, 1), 0); del buf418  # reuse
        # Topologically Sorted Source Nodes: [getitem_191, matmul_82, getitem_188, matmul_80, v_new_15], Original ATen: [aten.select, aten.view, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_22.run(buf470, buf480, buf481, 32, 16, 1, stream=raw_stream0)
        assert_size_stride(arg126_1, (2048, 2048), (2048, 1), 'input')
        buf483 = buf299; del buf299  # reuse
        # Topologically Sorted Source Nodes: [z_21], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf441, arg126_1, buf483, 1024, 1, 1, stream=raw_stream0)
        del arg126_1
        assert_size_stride(arg132_1, (128, ), (1, ), 'input')
        buf484 = reinterpret_tensor(buf483, (2048, 128), (128, 1), 0); del buf483  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_49, setitem_18, inter_chunk_attn_14, matmul_78, add_129, setitem_19, inter_chunk_attn_15, matmul_82, add_131, core_attn_out_50, transpose_105, core_attn_out_52, core_attn_out_53, hidden_states_69, pow_31, variance_7, add_133, rsqrt_46, hidden_states_70, to_98, hidden_states_71, z_21, z_22, z_23, to_99, silu_24, hidden_states_72, core_attn_out_54], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_copy_mean_mul_pow_rsqrt_select_silu_transpose_view_zeros_like_24.run(buf484, buf478, buf481, buf452, buf472, arg132_1, 2048, 128, stream=raw_stream0)
        del arg132_1
        assert_size_stride(arg133_1, (2048, 2048), (2048, 1), 'input')
        buf485 = reinterpret_tensor(buf441, (128, 2048), (2048, 1), 0); del buf441  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_49, setitem_18, inter_chunk_attn_14, matmul_78, add_129, setitem_19, inter_chunk_attn_15, matmul_82, add_131, core_attn_out_50, transpose_105, core_attn_out_52, core_attn_out_53, hidden_states_69, pow_31, variance_7, add_133, rsqrt_46, hidden_states_70, to_98, hidden_states_71, z_21, z_22, z_23, to_99, silu_24, hidden_states_72, core_attn_out_54, core_attn_out_55, output_53], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf484, arg133_1, buf485, 1024, 1, 1, stream=raw_stream0)
        del arg133_1
        assert_size_stride(arg134_1, (2048, ), (1, ), 'input')
        buf486 = buf381; del buf381  # reuse
        buf488 = reinterpret_tensor(buf484, (1, 128, 2048), (262144, 2048, 1), 0); del buf484  # reuse
        # Topologically Sorted Source Nodes: [down_proj_7, hidden_states_59, output_48, hidden_states_65, down_proj_8, hidden_states_67, output_53, hidden_states_73, float_64, pow_32, mean_31, add_135, rsqrt_47, output_54, float_65, add_136, output_55, hidden_states_74], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_50.run(buf486, buf387, buf433, buf439, buf485, arg134_1, buf488, 128, 2048, stream=raw_stream0)
        del arg134_1
        assert_size_stride(arg135_1, (6144, 2048), (2048, 1), 'input')
        buf489 = buf442; del buf442  # reuse
        # Topologically Sorted Source Nodes: [float_64, pow_32, mean_31, add_135, rsqrt_47, output_54, float_65, add_136, output_55, hidden_states_74, linear_75], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf488, arg135_1, buf489, 3072, 1, 1, stream=raw_stream0)
        del arg135_1
        assert_size_stride(arg136_1, (6144, 2048), (2048, 1), 'input')
        buf491 = reinterpret_tensor(buf436, (1, 128, 6144), (786432, 6144, 1), 0); del buf436  # reuse
        # Topologically Sorted Source Nodes: [linear_75, silu_25, linear_76, mul_216], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_26.run(buf488, arg136_1, buf489, buf491, 3072, 1, 1, stream=raw_stream0)
        del arg136_1
        assert_size_stride(arg137_1, (2048, 6144), (6144, 1), 'input')
        buf492 = reinterpret_tensor(buf488, (128, 2048), (2048, 1), 0); del buf488  # reuse
        # Topologically Sorted Source Nodes: [linear_75, silu_25, linear_76, mul_216, down_proj_9], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_27.run(buf491, arg137_1, buf492, 1024, 1, 1, stream=raw_stream0)
        del arg137_1
        assert_size_stride(arg138_1, (2048, ), (1, ), 'input')
        buf494 = reinterpret_tensor(buf485, (1, 128, 2048), (262144, 2048, 1), 0); del buf485  # reuse
        # Topologically Sorted Source Nodes: [down_proj_9, hidden_states_75, float_66, pow_33, mean_32, add_138, rsqrt_48, output_56, float_67, add_139, output_57, hidden_states_76], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_30.run(buf486, buf492, arg138_1, buf494, 128, 2048, stream=raw_stream0)
        del arg138_1
        assert_size_stride(arg139_1, (6144, 2048), (2048, 1), 'input')
        buf495 = reinterpret_tensor(buf491, (128, 6144), (6144, 1), 0); del buf491  # reuse
        # Topologically Sorted Source Nodes: [down_proj_9, hidden_states_75, float_66, pow_33, mean_32, add_138, rsqrt_48, output_56, float_67, add_139, output_57, hidden_states_76, mixed_qkv_32], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf494, arg139_1, buf495, 3072, 1, 1, stream=raw_stream0)
        del arg139_1
        assert_size_stride(arg143_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf496 = buf443; del buf443  # reuse
        # Topologically Sorted Source Nodes: [mixed_qkv_32, mixed_qkv_33, conv1d_8, squeeze_8, unsqueeze_68, out_16, out_17], Original ATen: [aten._unsafe_view, aten.transpose, aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_convolution_silu_slice_squeeze_transpose_unsqueeze_2.run(buf495, arg143_1, buf496, 786432, stream=raw_stream0)
        del arg143_1
        buf497 = reinterpret_tensor(buf477, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf477  # reuse
        buf498 = reinterpret_tensor(buf448, (1, 16, 128, 1), (2048, 1, 16, 2048), 0); del buf448  # reuse
        buf508 = reinterpret_tensor(buf468, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf468  # reuse
        # Topologically Sorted Source Nodes: [out_17, mixed_qkv_35, split_8, query_65, transpose_108, query_66, mul_220, sum_17, add_141, inv_norm_16, query_67, query_68], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_3.run(buf496, buf497, buf498, buf508, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg142_1, (16, 2048), (2048, 1), 'input')
        buf499 = buf459; del buf459  # reuse
        # Topologically Sorted Source Nodes: [a_8], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf494, arg142_1, buf499, 8, 1, 1, stream=raw_stream0)
        del arg142_1
        assert_size_stride(arg144_1, (16, ), (1, ), 'input')
        buf500 = buf447; del buf447  # reuse
        # Topologically Sorted Source Nodes: [exp_48, neg_12], Original ATen: [aten.exp, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_neg_5.run(arg144_1, buf500, 16, stream=raw_stream0)
        del arg144_1
        assert_size_stride(arg145_1, (16, ), (1, ), 'input')
        buf501 = buf474; del buf474  # reuse
        # Topologically Sorted Source Nodes: [exp_48, neg_12, a_8, float_69, add_140, softplus_8, g_8, transpose_112, decay_26, cum_decay_8], Original ATen: [aten.exp, aten.neg, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.view, aten.cumsum]
        workspace_8 = workspace_7; del workspace_7  # reuse
        workspace_8.zero_()
        raw_stream0 = get_raw_stream(0)
        triton_spl_fused__to_copy__unsafe_view_add_cumsum_exp_mul_neg_softplus_transpose_view_6.run(buf500, buf499, arg145_1, buf501, workspace_8, 32, 64, stream=raw_stream0)
        del arg145_1
        buf502 = buf466; del buf466  # reuse
        buf519 = reinterpret_tensor(buf460, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf460  # reuse
        buf527 = reinterpret_tensor(buf445, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf445  # reuse
        # Topologically Sorted Source Nodes: [exp_51, exp_50, getitem_199, sub_33, exp_52], Original ATen: [aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_slice_sub_7.run(buf501, buf502, buf519, buf527, 2048, stream=raw_stream0)
        buf503 = reinterpret_tensor(buf465, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf465  # reuse
        # Topologically Sorted Source Nodes: [add_141, inv_norm_16, query_67, query_68, query_70, exp_51, unsqueeze_74, query_71], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_exp_mul_rsqrt_unsqueeze_view_8.run(buf497, buf498, buf502, buf503, 262144, stream=raw_stream0)
        buf504 = reinterpret_tensor(buf497, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf497  # reuse
        # Topologically Sorted Source Nodes: [last_recurrent_state_24], Original ATen: [aten.zeros]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_zeros_9.run(buf504, 262144, stream=raw_stream0)
        buf505 = buf481; del buf481  # reuse
        # Topologically Sorted Source Nodes: [add_141, inv_norm_16, query_67, query_68, query_70, exp_51, unsqueeze_74, query_71, getitem_204, inter_chunk_attn_16, last_recurrent_state_24], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze, aten.select, aten.zeros, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_unsqueeze_view_zeros_10.run(buf503, buf504, buf505, 32, 16, 1, stream=raw_stream0)
        buf506 = reinterpret_tensor(buf450, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf450  # reuse
        buf509 = reinterpret_tensor(buf475, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf475  # reuse
        # Topologically Sorted Source Nodes: [out_17, mixed_qkv_35, split_8, key_57, transpose_109, key_58, mul_222, sum_18, add_142, inv_norm_17, key_59], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_11.run(buf496, buf506, buf509, 2048, 128, stream=raw_stream0)
        buf510 = reinterpret_tensor(buf478, (32, 64, 64), (4096, 64, 1), 0); del buf478  # reuse
        # Topologically Sorted Source Nodes: [add_141, inv_norm_16, query_67, query_68, query_70, matmul_85, add_142, inv_norm_17, key_59, key_61, transpose_114], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_mul_rsqrt_transpose_view_12.run(buf508, buf509, buf510, 16, 32, 1, stream=raw_stream0)
        assert_size_stride(arg141_1, (16, 2048), (2048, 1), 'input')
        buf512 = buf499; del buf499  # reuse
        # Topologically Sorted Source Nodes: [b_8], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf494, arg141_1, buf512, 8, 1, 1, stream=raw_stream0)
        del arg141_1
        buf513 = reinterpret_tensor(buf502, (1, 16, 128), (2048, 128, 1), 0); del buf502  # reuse
        # Topologically Sorted Source Nodes: [b_8, beta_24, transpose_111, beta_25], Original ATen: [aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_sigmoid_transpose_13.run(buf512, buf513, 16, 128, stream=raw_stream0)
        buf514 = buf508; del buf508  # reuse
        buf520 = reinterpret_tensor(buf506, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf506  # reuse
        buf528 = buf467; del buf467  # reuse
        buf517 = buf464; del buf464  # reuse
        # Topologically Sorted Source Nodes: [out_17, mixed_qkv_35, split_8, add_142, inv_norm_17, key_59, key_61, unsqueeze_70, k_beta_16, k_beta_17, value_33, transpose_110, value_34, unsqueeze_69, v_beta_16, exp_50, unsqueeze_73, decayed_k_beta_8, getitem_199, sub_33, exp_52, unsqueeze_75, key_62], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.view, aten.unsqueeze, aten._to_copy, aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_exp_mul_rsqrt_silu_slice_split_with_sizes_sub_transpose_unsqueeze_view_14.run(buf509, buf513, buf519, buf527, buf496, buf514, buf520, buf528, buf517, 262144, stream=raw_stream0)
        buf516 = reinterpret_tensor(buf472, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf472  # reuse
        buf523 = reinterpret_tensor(buf452, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf452  # reuse
        # Topologically Sorted Source Nodes: [add_142, inv_norm_17, key_59, key_61, matmul_85, strictly_upper_mask_8, ones_8, pairwise_decay_25, unsqueeze_71, unsqueeze_72, pairwise_decay_24, pairwise_decay_26, intra_chunk_attn_8, unsqueeze_70, k_beta_16, k_beta_17, matmul_84, transpose_113, ut_system_8], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.triu, aten.ones, aten.masked_fill, aten.unsqueeze, aten.sub, aten.exp, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_masked_fill_mul_ones_rsqrt_sub_transpose_triu_unsqueeze_view_15.run(buf514, buf509, buf501, buf510, buf516, buf523, 16, 32, 1, stream=raw_stream0)
        del buf509
        del buf514
        # Topologically Sorted Source Nodes: [out_17, mixed_qkv_35, split_8, value_33, transpose_110, value_34, unsqueeze_69, v_beta_16, v_beta_17, new_values_8], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.unsqueeze, aten.mul, aten.linalg_solve_triangular]
        buf518 = torch.ops.aten.linalg_solve_triangular.default(buf516, reinterpret_tensor(buf517, (1, 16, 2, 64, 128), (0, 16384, 8192, 128, 1), 0), upper=False, unitriangular=True)
        assert_tensor_metadata(buf518, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf518, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        # Topologically Sorted Source Nodes: [unsqueeze_70, k_beta_16, k_beta_17, exp_50, unsqueeze_73, decayed_k_beta_8, k_cumdecay_8], Original ATen: [aten.unsqueeze, aten.mul, aten.view, aten.exp, aten.linalg_solve_triangular]
        buf521 = torch.ops.aten.linalg_solve_triangular.default(buf516, buf520, upper=False, unitriangular=True)
        assert_tensor_metadata(buf521, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf521, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        buf524 = reinterpret_tensor(buf516, (1, 16, 64, 128), (131072, 8192, 128, 1), 0); del buf516  # reuse
        # Topologically Sorted Source Nodes: [getitem_202, getitem_203, matmul_86, v_new_16], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_16.run(buf521, buf504, buf518, buf524, 32, 16, 1, stream=raw_stream0)
        buf525 = reinterpret_tensor(buf510, (16, 64, 128), (8192, 128, 1), 0); del buf510  # reuse
        # Topologically Sorted Source Nodes: [matmul_85, intra_chunk_attn_8, getitem_205, matmul_88, getitem_202, matmul_86, v_new_16], Original ATen: [aten.view, aten.mul, aten.select, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_mul_select_sub_view_17.run(buf523, buf524, buf525, 32, 16, 1, stream=raw_stream0)
        buf526 = buf473; del buf473  # reuse
        # Topologically Sorted Source Nodes: [getitem_200, exp_53], Original ATen: [aten.select, aten.exp]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_select_18.run(buf501, buf526, 32, stream=raw_stream0)
        buf530 = buf504; del buf504  # reuse
        # Topologically Sorted Source Nodes: [add_142, inv_norm_17, key_59, key_61, getitem_200, exp_53, chunk_decay_8, getitem_206, mul_232, getitem_199, sub_33, exp_52, unsqueeze_75, key_62, getitem_207, transpose_115, matmul_89, last_recurrent_state_25], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.select, aten.exp, aten.unsqueeze, aten.slice, aten.sub, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_slice_sub_transpose_unsqueeze_view_19.run(buf528, buf524, buf526, buf530, 64, 16, 1, stream=raw_stream0)
        buf531 = reinterpret_tensor(buf524, (16, 64, 128), (8192, 128, 1), 0); del buf524  # reuse
        # Topologically Sorted Source Nodes: [getitem_210, inter_chunk_attn_17, getitem_200, exp_53, chunk_decay_8, getitem_206, mul_232, matmul_89, last_recurrent_state_25], Original ATen: [aten.select, aten.view, aten.exp, aten.unsqueeze, aten.mul, aten.add, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_select_unsqueeze_view_20.run(buf503, buf530, buf531, 32, 16, 1, stream=raw_stream0)
        buf533 = buf480; del buf480  # reuse
        # Topologically Sorted Source Nodes: [getitem_208, getitem_209, matmul_90, v_new_17], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_21.run(buf521, buf530, buf518, buf533, 32, 16, 1, stream=raw_stream0)
        buf534 = reinterpret_tensor(buf470, (16, 64, 128), (8192, 128, 1), 0); del buf470  # reuse
        # Topologically Sorted Source Nodes: [getitem_211, matmul_92, getitem_208, matmul_90, v_new_17], Original ATen: [aten.select, aten.view, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_22.run(buf523, buf533, buf534, 32, 16, 1, stream=raw_stream0)
        assert_size_stride(arg140_1, (2048, 2048), (2048, 1), 'input')
        buf536 = buf439; del buf439  # reuse
        # Topologically Sorted Source Nodes: [z_24], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf494, arg140_1, buf536, 1024, 1, 1, stream=raw_stream0)
        del arg140_1
        assert_size_stride(arg146_1, (128, ), (1, ), 'input')
        buf537 = reinterpret_tensor(buf536, (2048, 128), (128, 1), 0); del buf536  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_56, setitem_20, inter_chunk_attn_16, matmul_88, add_143, setitem_21, inter_chunk_attn_17, matmul_92, add_145, core_attn_out_57, transpose_117, core_attn_out_59, core_attn_out_60, hidden_states_77, pow_34, variance_8, add_147, rsqrt_51, hidden_states_78, to_110, hidden_states_79, z_24, z_25, z_26, to_111, silu_27, hidden_states_80, core_attn_out_61], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_copy_mean_mul_pow_rsqrt_select_silu_transpose_view_zeros_like_24.run(buf537, buf531, buf534, buf505, buf525, arg146_1, 2048, 128, stream=raw_stream0)
        del arg146_1
        assert_size_stride(arg147_1, (2048, 2048), (2048, 1), 'input')
        buf538 = reinterpret_tensor(buf494, (128, 2048), (2048, 1), 0); del buf494  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_56, setitem_20, inter_chunk_attn_16, matmul_88, add_143, setitem_21, inter_chunk_attn_17, matmul_92, add_145, core_attn_out_57, transpose_117, core_attn_out_59, core_attn_out_60, hidden_states_77, pow_34, variance_8, add_147, rsqrt_51, hidden_states_78, to_110, hidden_states_79, z_24, z_25, z_26, to_111, silu_27, hidden_states_80, core_attn_out_61, core_attn_out_62, output_58], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf537, arg147_1, buf538, 1024, 1, 1, stream=raw_stream0)
        del arg147_1
        assert_size_stride(arg148_1, (2048, ), (1, ), 'input')
        buf540 = reinterpret_tensor(buf537, (1, 128, 2048), (262144, 2048, 1), 0); del buf537  # reuse
        # Topologically Sorted Source Nodes: [down_proj_9, hidden_states_75, output_58, hidden_states_81, float_70, pow_35, mean_34, add_149, rsqrt_52, output_59, float_71, add_150, output_60, hidden_states_82], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_31.run(buf486, buf492, buf538, arg148_1, buf540, 128, 2048, stream=raw_stream0)
        del arg148_1
        assert_size_stride(arg149_1, (6144, 2048), (2048, 1), 'input')
        buf541 = buf495; del buf495  # reuse
        # Topologically Sorted Source Nodes: [linear_83], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf540, arg149_1, buf541, 3072, 1, 1, stream=raw_stream0)
        del arg149_1
        assert_size_stride(arg150_1, (6144, 2048), (2048, 1), 'input')
        buf543 = reinterpret_tensor(buf489, (1, 128, 6144), (786432, 6144, 1), 0); del buf489  # reuse
        # Topologically Sorted Source Nodes: [linear_83, silu_28, linear_84, mul_239], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_26.run(buf540, arg150_1, buf541, buf543, 3072, 1, 1, stream=raw_stream0)
        del arg150_1
        assert_size_stride(arg151_1, (2048, 6144), (6144, 1), 'input')
        buf544 = reinterpret_tensor(buf540, (128, 2048), (2048, 1), 0); del buf540  # reuse
        # Topologically Sorted Source Nodes: [linear_83, silu_28, linear_84, mul_239, down_proj_10], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_27.run(buf543, arg151_1, buf544, 1024, 1, 1, stream=raw_stream0)
        del arg151_1
        assert_size_stride(arg152_1, (2048, ), (1, ), 'input')
        buf546 = reinterpret_tensor(buf433, (1, 128, 2048), (262144, 2048, 1), 0); del buf433  # reuse
        # Topologically Sorted Source Nodes: [down_proj_9, hidden_states_75, output_58, hidden_states_81, down_proj_10, hidden_states_83, float_72, pow_36, mean_35, add_152, rsqrt_53, output_61, float_73, add_153, output_62, hidden_states_84], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_32.run(buf486, buf492, buf538, buf544, arg152_1, buf546, 128, 2048, stream=raw_stream0)
        del arg152_1
        assert_size_stride(arg153_1, (4096, 2048), (2048, 1), 'input')
        buf547 = buf354; del buf354  # reuse
        # Topologically Sorted Source Nodes: [linear_86], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_33.run(buf546, arg153_1, buf547, 2048, 1, 1, stream=raw_stream0)
        del arg153_1
        buf548 = buf355; del buf355  # reuse
        # Topologically Sorted Source Nodes: [linear_86, view_8, chunk_2, float_74, pow_37, mean_36], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_mean_pow_split_view_34.run(buf547, buf548, 1024, 256, stream=raw_stream0)
        assert_size_stride(arg154_1, (256, ), (1, ), 'input')
        buf551 = reinterpret_tensor(buf375, (1, 8, 128, 64), (65536, 8192, 64, 1), 0); del buf375  # reuse
        buf549 = reinterpret_tensor(buf551, (1, 8, 128, 32), (65536, 8192, 64, 1), 0)  # alias
        buf550 = reinterpret_tensor(buf551, (1, 8, 128, 32), (65536, 8192, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_86, view_8, chunk_2, float_74, pow_37, mean_36, add_154, rsqrt_54, output_63, float_75, add_155, output_64, type_as_27, query_states_5, q_rot_2, x2_4, neg_13, x1_4, cat_10], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_36.run(buf547, buf548, arg154_1, buf549, buf550, 32768, stream=raw_stream0)
        buf554 = reinterpret_tensor(buf387, (1, 8, 128, 256), (262144, 32768, 256, 1), 0); del buf387  # reuse
        buf552 = reinterpret_tensor(buf554, (1, 8, 128, 64), (262144, 32768, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, linear_86, view_8, chunk_2, float_74, pow_37, mean_36, add_154, rsqrt_54, output_63, float_75, add_155, output_64, type_as_27, query_states_5, q_rot_2, cos_6, mul_246, sin_6, mul_247, q_embed_4], Original ATen: [aten.select, aten.cat, aten._to_copy, aten._unsafe_view, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_37.run(buf547, buf548, arg154_1, buf161, buf551, buf165, buf552, 65536, stream=raw_stream0)
        del buf549
        del buf550
        buf553 = reinterpret_tensor(buf554, (1, 8, 128, 192), (262144, 32768, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, linear_86, view_8, chunk_2, float_74, pow_37, mean_36, add_154, rsqrt_54, output_63, float_75, add_155, output_64, type_as_27, query_states_5, q_rot_2, cos_6, mul_246, sin_6, mul_247, q_embed_4, q_pass_2, q_embed_5], Original ATen: [aten.select, aten.cat, aten._to_copy, aten._unsafe_view, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_38.run(buf547, buf548, arg154_1, buf553, 196608, stream=raw_stream0)
        del arg154_1
        assert_size_stride(arg155_1, (512, 2048), (2048, 1), 'input')
        del buf552
        del buf553
        buf555 = reinterpret_tensor(buf551, (128, 512), (512, 1), 0); del buf551  # reuse
        # Topologically Sorted Source Nodes: [linear_87], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_39.run(buf546, arg155_1, buf555, 256, 1, 1, stream=raw_stream0)
        del arg155_1
        buf556 = buf363; del buf363  # reuse
        # Topologically Sorted Source Nodes: [linear_87, view_10, float_76, pow_38, mean_37], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_mean_pow_view_40.run(buf555, buf556, 256, 256, stream=raw_stream0)
        assert_size_stride(arg156_1, (256, ), (1, ), 'input')
        buf559 = buf366; del buf366  # reuse
        buf557 = reinterpret_tensor(buf559, (1, 2, 128, 32), (16384, 8192, 64, 1), 0)  # alias
        buf558 = reinterpret_tensor(buf559, (1, 2, 128, 32), (16384, 8192, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_87, view_10, float_76, pow_38, mean_37, add_156, rsqrt_55, output_65, float_77, add_157, output_66, type_as_28, key_states_4, k_rot_2, x2_5, neg_14, x1_5, cat_11], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_41.run(buf555, buf556, arg156_1, buf557, buf558, 8192, stream=raw_stream0)
        buf562 = reinterpret_tensor(buf362, (1, 2, 128, 256), (65536, 32768, 256, 1), 0); del buf362  # reuse
        buf560 = reinterpret_tensor(buf562, (1, 2, 128, 64), (65536, 32768, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, cos_6, sin_6, linear_87, view_10, float_76, pow_38, mean_37, add_156, rsqrt_55, output_65, float_77, add_157, output_66, type_as_28, key_states_4, k_rot_2, mul_248, mul_249, k_embed_4], Original ATen: [aten.select, aten.cat, aten._to_copy, aten.unsqueeze, aten._unsafe_view, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_42.run(buf555, buf556, arg156_1, buf161, buf559, buf165, buf560, 16384, stream=raw_stream0)
        del buf557
        del buf558
        buf561 = reinterpret_tensor(buf562, (1, 2, 128, 192), (65536, 32768, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, cos_6, sin_6, linear_87, view_10, float_76, pow_38, mean_37, add_156, rsqrt_55, output_65, float_77, add_157, output_66, type_as_28, key_states_4, k_rot_2, mul_248, mul_249, k_embed_4, k_pass_2, k_embed_5], Original ATen: [aten.select, aten.cat, aten._to_copy, aten.unsqueeze, aten._unsafe_view, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_43.run(buf555, buf556, arg156_1, buf561, 49152, stream=raw_stream0)
        del arg156_1
        buf563 = reinterpret_tensor(buf361, (1, 2, 4, 128, 256), (262144, 131072, 32768, 256, 1), 0); del buf361  # reuse
        # Topologically Sorted Source Nodes: [getitem_225, hidden_states_85, key_states_5], Original ATen: [aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_clone_expand_unsqueeze_44.run(buf562, buf563, 262144, stream=raw_stream0)
        del buf560
        del buf561
        buf564 = reinterpret_tensor(buf376, (8, 128, 128), (16384, 128, 1), 0); del buf376  # reuse
        # Topologically Sorted Source Nodes: [matmul_94, getitem_225, hidden_states_85, key_states_5, transpose_121], Original ATen: [aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_45.run(buf554, buf563, buf564, 64, 8, 1, stream=raw_stream0)
        buf566 = reinterpret_tensor(buf534, (1, 8, 128, 128), (131072, 16384, 128, 1), 0); del buf534  # reuse
        buf569 = reinterpret_tensor(buf371, (1, 8, 128, 128), (131072, 16384, 128, 1), 0); del buf371  # reuse
        # Topologically Sorted Source Nodes: [mask, full, getitem, matmul_94, attn_weights_8, attn_weights_9, softmax_2, attn_weights_10], Original ATen: [aten.triu, aten.full, aten.unsqueeze, aten.view, aten.mul, aten.add, aten._to_copy, aten._softmax]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__softmax__to_copy_add_full_mul_triu_unsqueeze_view_46.run(buf564, buf566, buf569, 1024, 128, stream=raw_stream0)
        assert_size_stride(arg157_1, (512, 2048), (2048, 1), 'input')
        buf568 = reinterpret_tensor(buf562, (128, 512), (512, 1), 0); del buf562  # reuse
        # Topologically Sorted Source Nodes: [linear_88], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_39.run(buf546, arg157_1, buf568, 256, 1, 1, stream=raw_stream0)
        del arg157_1
        buf570 = reinterpret_tensor(buf546, (1, 2, 4, 128, 256), (262144, 131072, 32768, 256, 1), 0); del buf546  # reuse
        # Topologically Sorted Source Nodes: [linear_88, view_11, value_states_4, getitem_226, hidden_states_86, value_states_5], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_clone_expand_transpose_unsqueeze_view_47.run(buf568, buf570, 262144, stream=raw_stream0)
        buf571 = reinterpret_tensor(buf563, (8, 128, 256), (32768, 256, 1), 0); del buf563  # reuse
        # Topologically Sorted Source Nodes: [softmax_2, attn_weights_10, attn_output_10, linear_88, view_11, value_states_4, getitem_226, hidden_states_86, value_states_5], Original ATen: [aten._softmax, aten._to_copy, aten.view, aten._unsafe_view, aten.transpose, aten.unsqueeze, aten.expand, aten.clone, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__softmax__to_copy__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_48.run(buf569, buf570, buf571, 128, 8, 1, stream=raw_stream0)
        buf572 = reinterpret_tensor(buf570, (1, 128, 2048), (262144, 2048, 1), 0); del buf570  # reuse
        # Topologically Sorted Source Nodes: [linear_86, view_8, chunk_2, attn_output_10, transpose_122, attn_output_11, reshape_128, gate_5, sigmoid_11, attn_output_13], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten.transpose, aten.clone, aten.sigmoid, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_clone_mul_sigmoid_split_transpose_view_49.run(buf571, buf547, buf572, 262144, stream=raw_stream0)
        assert_size_stride(arg158_1, (2048, 2048), (2048, 1), 'input')
        buf573 = reinterpret_tensor(buf571, (128, 2048), (2048, 1), 0); del buf571  # reuse
        # Topologically Sorted Source Nodes: [linear_86, view_8, chunk_2, attn_output_10, transpose_122, attn_output_11, reshape_128, gate_5, sigmoid_11, attn_output_13, attn_output_14], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten.transpose, aten.clone, aten.sigmoid, aten.mul, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf572, arg158_1, buf573, 1024, 1, 1, stream=raw_stream0)
        del arg158_1
        assert_size_stride(arg159_1, (2048, ), (1, ), 'input')
        buf574 = buf486; del buf486  # reuse
        buf576 = buf572; del buf572  # reuse
        # Topologically Sorted Source Nodes: [down_proj_9, hidden_states_75, output_58, hidden_states_81, down_proj_10, hidden_states_83, attn_output_14, hidden_states_87, float_78, pow_39, mean_38, add_162, rsqrt_56, output_67, float_79, add_163, output_68, hidden_states_88], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_50.run(buf574, buf492, buf538, buf544, buf573, arg159_1, buf576, 128, 2048, stream=raw_stream0)
        del arg159_1
        assert_size_stride(arg160_1, (6144, 2048), (2048, 1), 'input')
        buf577 = reinterpret_tensor(buf543, (128, 6144), (6144, 1), 0); del buf543  # reuse
        # Topologically Sorted Source Nodes: [float_78, pow_39, mean_38, add_162, rsqrt_56, output_67, float_79, add_163, output_68, hidden_states_88, linear_90], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf576, arg160_1, buf577, 3072, 1, 1, stream=raw_stream0)
        del arg160_1
        assert_size_stride(arg161_1, (6144, 2048), (2048, 1), 'input')
        buf579 = reinterpret_tensor(buf541, (1, 128, 6144), (786432, 6144, 1), 0); del buf541  # reuse
        # Topologically Sorted Source Nodes: [linear_90, silu_29, linear_91, mul_254], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_26.run(buf576, arg161_1, buf577, buf579, 3072, 1, 1, stream=raw_stream0)
        del arg161_1
        assert_size_stride(arg162_1, (2048, 6144), (6144, 1), 'input')
        buf580 = reinterpret_tensor(buf576, (128, 2048), (2048, 1), 0); del buf576  # reuse
        # Topologically Sorted Source Nodes: [linear_90, silu_29, linear_91, mul_254, down_proj_11], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_27.run(buf579, arg162_1, buf580, 1024, 1, 1, stream=raw_stream0)
        del arg162_1
        assert_size_stride(arg163_1, (2048, ), (1, ), 'input')
        buf582 = reinterpret_tensor(buf573, (1, 128, 2048), (262144, 2048, 1), 0); del buf573  # reuse
        # Topologically Sorted Source Nodes: [down_proj_11, hidden_states_89, float_80, pow_40, mean_39, add_165, rsqrt_57, output_69, float_81, add_166, output_70, hidden_states_90], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_30.run(buf574, buf580, arg163_1, buf582, 128, 2048, stream=raw_stream0)
        del arg163_1
        assert_size_stride(arg164_1, (6144, 2048), (2048, 1), 'input')
        buf583 = reinterpret_tensor(buf579, (128, 6144), (6144, 1), 0); del buf579  # reuse
        # Topologically Sorted Source Nodes: [down_proj_11, hidden_states_89, float_80, pow_40, mean_39, add_165, rsqrt_57, output_69, float_81, add_166, output_70, hidden_states_90, mixed_qkv_36], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf582, arg164_1, buf583, 3072, 1, 1, stream=raw_stream0)
        del arg164_1
        assert_size_stride(arg168_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf584 = buf496; del buf496  # reuse
        # Topologically Sorted Source Nodes: [mixed_qkv_36, mixed_qkv_37, conv1d_9, squeeze_9, unsqueeze_78, out_18, out_19], Original ATen: [aten._unsafe_view, aten.transpose, aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_convolution_silu_slice_squeeze_transpose_unsqueeze_2.run(buf583, arg168_1, buf584, 786432, stream=raw_stream0)
        del arg168_1
        buf585 = reinterpret_tensor(buf530, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf530  # reuse
        buf586 = reinterpret_tensor(buf501, (1, 16, 128, 1), (2048, 1, 16, 2048), 0); del buf501  # reuse
        buf596 = reinterpret_tensor(buf521, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf521  # reuse
        # Topologically Sorted Source Nodes: [out_19, mixed_qkv_39, split_9, query_73, transpose_125, query_74, mul_258, sum_19, add_168, inv_norm_18, query_75, query_76], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_3.run(buf584, buf585, buf586, buf596, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg167_1, (16, 2048), (2048, 1), 'input')
        buf587 = buf512; del buf512  # reuse
        # Topologically Sorted Source Nodes: [a_9], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf582, arg167_1, buf587, 8, 1, 1, stream=raw_stream0)
        del arg167_1
        assert_size_stride(arg169_1, (16, ), (1, ), 'input')
        buf588 = buf500; del buf500  # reuse
        # Topologically Sorted Source Nodes: [exp_54, neg_15], Original ATen: [aten.exp, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_neg_5.run(arg169_1, buf588, 16, stream=raw_stream0)
        del arg169_1
        assert_size_stride(arg170_1, (16, ), (1, ), 'input')
        buf589 = buf527; del buf527  # reuse
        # Topologically Sorted Source Nodes: [exp_54, neg_15, a_9, float_83, add_167, softplus_9, g_9, transpose_129, decay_29, cum_decay_9], Original ATen: [aten.exp, aten.neg, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.view, aten.cumsum]
        workspace_9 = workspace_8; del workspace_8  # reuse
        workspace_9.zero_()
        raw_stream0 = get_raw_stream(0)
        triton_spl_fused__to_copy__unsafe_view_add_cumsum_exp_mul_neg_softplus_transpose_view_6.run(buf588, buf587, arg170_1, buf589, workspace_9, 32, 64, stream=raw_stream0)
        del arg170_1
        buf590 = buf519; del buf519  # reuse
        buf607 = reinterpret_tensor(buf513, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf513  # reuse
        buf615 = reinterpret_tensor(buf498, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf498  # reuse
        # Topologically Sorted Source Nodes: [exp_57, exp_56, getitem_231, sub_37, exp_58], Original ATen: [aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_slice_sub_7.run(buf589, buf590, buf607, buf615, 2048, stream=raw_stream0)
        buf591 = reinterpret_tensor(buf518, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf518  # reuse
        # Topologically Sorted Source Nodes: [add_168, inv_norm_18, query_75, query_76, query_78, exp_57, unsqueeze_84, query_79], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_exp_mul_rsqrt_unsqueeze_view_8.run(buf585, buf586, buf590, buf591, 262144, stream=raw_stream0)
        buf592 = reinterpret_tensor(buf585, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf585  # reuse
        # Topologically Sorted Source Nodes: [last_recurrent_state_27], Original ATen: [aten.zeros]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_zeros_9.run(buf592, 262144, stream=raw_stream0)
        buf593 = reinterpret_tensor(buf566, (16, 64, 128), (8192, 128, 1), 0); del buf566  # reuse
        # Topologically Sorted Source Nodes: [add_168, inv_norm_18, query_75, query_76, query_78, exp_57, unsqueeze_84, query_79, getitem_236, inter_chunk_attn_18, last_recurrent_state_27], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze, aten.select, aten.zeros, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_unsqueeze_view_zeros_10.run(buf591, buf592, buf593, 32, 16, 1, stream=raw_stream0)
        buf594 = reinterpret_tensor(buf503, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf503  # reuse
        buf597 = reinterpret_tensor(buf528, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf528  # reuse
        # Topologically Sorted Source Nodes: [out_19, mixed_qkv_39, split_9, key_64, transpose_126, key_65, mul_260, sum_20, add_169, inv_norm_19, key_66], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_11.run(buf584, buf594, buf597, 2048, 128, stream=raw_stream0)
        buf598 = reinterpret_tensor(buf531, (32, 64, 64), (4096, 64, 1), 0); del buf531  # reuse
        # Topologically Sorted Source Nodes: [add_168, inv_norm_18, query_75, query_76, query_78, matmul_97, add_169, inv_norm_19, key_66, key_68, transpose_131], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_mul_rsqrt_transpose_view_12.run(buf596, buf597, buf598, 16, 32, 1, stream=raw_stream0)
        assert_size_stride(arg166_1, (16, 2048), (2048, 1), 'input')
        buf600 = buf587; del buf587  # reuse
        # Topologically Sorted Source Nodes: [b_9], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf582, arg166_1, buf600, 8, 1, 1, stream=raw_stream0)
        del arg166_1
        buf601 = reinterpret_tensor(buf590, (1, 16, 128), (2048, 128, 1), 0); del buf590  # reuse
        # Topologically Sorted Source Nodes: [b_9, beta_27, transpose_128, beta_28], Original ATen: [aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_sigmoid_transpose_13.run(buf600, buf601, 16, 128, stream=raw_stream0)
        buf602 = buf596; del buf596  # reuse
        buf608 = reinterpret_tensor(buf594, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf594  # reuse
        buf616 = buf520; del buf520  # reuse
        buf605 = buf517; del buf517  # reuse
        # Topologically Sorted Source Nodes: [out_19, mixed_qkv_39, split_9, add_169, inv_norm_19, key_66, key_68, unsqueeze_80, k_beta_18, k_beta_19, value_37, transpose_127, value_38, unsqueeze_79, v_beta_18, exp_56, unsqueeze_83, decayed_k_beta_9, getitem_231, sub_37, exp_58, unsqueeze_85, key_69], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.view, aten.unsqueeze, aten._to_copy, aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_exp_mul_rsqrt_silu_slice_split_with_sizes_sub_transpose_unsqueeze_view_14.run(buf597, buf601, buf607, buf615, buf584, buf602, buf608, buf616, buf605, 262144, stream=raw_stream0)
        buf604 = reinterpret_tensor(buf525, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf525  # reuse
        buf611 = reinterpret_tensor(buf505, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf505  # reuse
        # Topologically Sorted Source Nodes: [add_169, inv_norm_19, key_66, key_68, matmul_97, strictly_upper_mask_9, ones_9, pairwise_decay_28, unsqueeze_81, unsqueeze_82, pairwise_decay_27, pairwise_decay_29, intra_chunk_attn_9, unsqueeze_80, k_beta_18, k_beta_19, matmul_96, transpose_130, ut_system_9], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.triu, aten.ones, aten.masked_fill, aten.unsqueeze, aten.sub, aten.exp, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_masked_fill_mul_ones_rsqrt_sub_transpose_triu_unsqueeze_view_15.run(buf602, buf597, buf589, buf598, buf604, buf611, 16, 32, 1, stream=raw_stream0)
        del buf597
        del buf602
        # Topologically Sorted Source Nodes: [out_19, mixed_qkv_39, split_9, value_37, transpose_127, value_38, unsqueeze_79, v_beta_18, v_beta_19, new_values_9], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.unsqueeze, aten.mul, aten.linalg_solve_triangular]
        buf606 = torch.ops.aten.linalg_solve_triangular.default(buf604, reinterpret_tensor(buf605, (1, 16, 2, 64, 128), (0, 16384, 8192, 128, 1), 0), upper=False, unitriangular=True)
        assert_tensor_metadata(buf606, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf606, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        # Topologically Sorted Source Nodes: [unsqueeze_80, k_beta_18, k_beta_19, exp_56, unsqueeze_83, decayed_k_beta_9, k_cumdecay_9], Original ATen: [aten.unsqueeze, aten.mul, aten.view, aten.exp, aten.linalg_solve_triangular]
        buf609 = torch.ops.aten.linalg_solve_triangular.default(buf604, buf608, upper=False, unitriangular=True)
        assert_tensor_metadata(buf609, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf609, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        buf612 = reinterpret_tensor(buf604, (1, 16, 64, 128), (131072, 8192, 128, 1), 0); del buf604  # reuse
        # Topologically Sorted Source Nodes: [getitem_234, getitem_235, matmul_98, v_new_18], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_16.run(buf609, buf592, buf606, buf612, 32, 16, 1, stream=raw_stream0)
        buf613 = reinterpret_tensor(buf598, (16, 64, 128), (8192, 128, 1), 0); del buf598  # reuse
        # Topologically Sorted Source Nodes: [matmul_97, intra_chunk_attn_9, getitem_237, matmul_100, getitem_234, matmul_98, v_new_18], Original ATen: [aten.view, aten.mul, aten.select, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_mul_select_sub_view_17.run(buf611, buf612, buf613, 32, 16, 1, stream=raw_stream0)
        buf614 = buf526; del buf526  # reuse
        # Topologically Sorted Source Nodes: [getitem_232, exp_59], Original ATen: [aten.select, aten.exp]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_select_18.run(buf589, buf614, 32, stream=raw_stream0)
        buf618 = buf592; del buf592  # reuse
        # Topologically Sorted Source Nodes: [add_169, inv_norm_19, key_66, key_68, getitem_232, exp_59, chunk_decay_9, getitem_238, mul_270, getitem_231, sub_37, exp_58, unsqueeze_85, key_69, getitem_239, transpose_132, matmul_101, last_recurrent_state_28], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.select, aten.exp, aten.unsqueeze, aten.slice, aten.sub, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_slice_sub_transpose_unsqueeze_view_19.run(buf616, buf612, buf614, buf618, 64, 16, 1, stream=raw_stream0)
        buf619 = reinterpret_tensor(buf612, (16, 64, 128), (8192, 128, 1), 0); del buf612  # reuse
        # Topologically Sorted Source Nodes: [getitem_242, inter_chunk_attn_19, getitem_232, exp_59, chunk_decay_9, getitem_238, mul_270, matmul_101, last_recurrent_state_28], Original ATen: [aten.select, aten.view, aten.exp, aten.unsqueeze, aten.mul, aten.add, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_select_unsqueeze_view_20.run(buf591, buf618, buf619, 32, 16, 1, stream=raw_stream0)
        buf621 = buf533; del buf533  # reuse
        # Topologically Sorted Source Nodes: [getitem_240, getitem_241, matmul_102, v_new_19], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_21.run(buf609, buf618, buf606, buf621, 32, 16, 1, stream=raw_stream0)
        buf622 = reinterpret_tensor(buf523, (16, 64, 128), (8192, 128, 1), 0); del buf523  # reuse
        # Topologically Sorted Source Nodes: [getitem_243, matmul_104, getitem_240, matmul_102, v_new_19], Original ATen: [aten.select, aten.view, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_22.run(buf611, buf621, buf622, 32, 16, 1, stream=raw_stream0)
        assert_size_stride(arg165_1, (2048, 2048), (2048, 1), 'input')
        buf624 = buf544; del buf544  # reuse
        # Topologically Sorted Source Nodes: [z_27], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf582, arg165_1, buf624, 1024, 1, 1, stream=raw_stream0)
        del arg165_1
        assert_size_stride(arg171_1, (128, ), (1, ), 'input')
        buf625 = reinterpret_tensor(buf624, (2048, 128), (128, 1), 0); del buf624  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_63, setitem_22, inter_chunk_attn_18, matmul_100, add_170, setitem_23, inter_chunk_attn_19, matmul_104, add_172, core_attn_out_64, transpose_134, core_attn_out_66, core_attn_out_67, hidden_states_91, pow_41, variance_9, add_174, rsqrt_60, hidden_states_92, to_123, hidden_states_93, z_27, z_28, z_29, to_124, silu_31, hidden_states_94, core_attn_out_68], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_copy_mean_mul_pow_rsqrt_select_silu_transpose_view_zeros_like_24.run(buf625, buf619, buf622, buf593, buf613, arg171_1, 2048, 128, stream=raw_stream0)
        del arg171_1
        assert_size_stride(arg172_1, (2048, 2048), (2048, 1), 'input')
        buf626 = reinterpret_tensor(buf582, (128, 2048), (2048, 1), 0); del buf582  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_63, setitem_22, inter_chunk_attn_18, matmul_100, add_170, setitem_23, inter_chunk_attn_19, matmul_104, add_172, core_attn_out_64, transpose_134, core_attn_out_66, core_attn_out_67, hidden_states_91, pow_41, variance_9, add_174, rsqrt_60, hidden_states_92, to_123, hidden_states_93, z_27, z_28, z_29, to_124, silu_31, hidden_states_94, core_attn_out_68, core_attn_out_69, output_71], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf625, arg172_1, buf626, 1024, 1, 1, stream=raw_stream0)
        del arg172_1
        assert_size_stride(arg173_1, (2048, ), (1, ), 'input')
        buf628 = reinterpret_tensor(buf625, (1, 128, 2048), (262144, 2048, 1), 0); del buf625  # reuse
        # Topologically Sorted Source Nodes: [down_proj_11, hidden_states_89, output_71, hidden_states_95, float_84, pow_42, mean_41, add_176, rsqrt_61, output_72, float_85, add_177, output_73, hidden_states_96], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_31.run(buf574, buf580, buf626, arg173_1, buf628, 128, 2048, stream=raw_stream0)
        del arg173_1
        assert_size_stride(arg174_1, (6144, 2048), (2048, 1), 'input')
        buf629 = buf583; del buf583  # reuse
        # Topologically Sorted Source Nodes: [linear_98], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf628, arg174_1, buf629, 3072, 1, 1, stream=raw_stream0)
        del arg174_1
        assert_size_stride(arg175_1, (6144, 2048), (2048, 1), 'input')
        buf631 = reinterpret_tensor(buf577, (1, 128, 6144), (786432, 6144, 1), 0); del buf577  # reuse
        # Topologically Sorted Source Nodes: [linear_98, silu_32, linear_99, mul_277], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_26.run(buf628, arg175_1, buf629, buf631, 3072, 1, 1, stream=raw_stream0)
        del arg175_1
        assert_size_stride(arg176_1, (2048, 6144), (6144, 1), 'input')
        buf632 = reinterpret_tensor(buf628, (128, 2048), (2048, 1), 0); del buf628  # reuse
        # Topologically Sorted Source Nodes: [linear_98, silu_32, linear_99, mul_277, down_proj_12], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_27.run(buf631, arg176_1, buf632, 1024, 1, 1, stream=raw_stream0)
        del arg176_1
        assert_size_stride(arg177_1, (2048, ), (1, ), 'input')
        buf634 = reinterpret_tensor(buf538, (1, 128, 2048), (262144, 2048, 1), 0); del buf538  # reuse
        # Topologically Sorted Source Nodes: [down_proj_11, hidden_states_89, output_71, hidden_states_95, down_proj_12, hidden_states_97, float_86, pow_43, mean_42, add_179, rsqrt_62, output_74, float_87, add_180, output_75, hidden_states_98], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_32.run(buf574, buf580, buf626, buf632, arg177_1, buf634, 128, 2048, stream=raw_stream0)
        del arg177_1
        assert_size_stride(arg178_1, (6144, 2048), (2048, 1), 'input')
        buf635 = reinterpret_tensor(buf631, (128, 6144), (6144, 1), 0); del buf631  # reuse
        # Topologically Sorted Source Nodes: [mixed_qkv_40], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf634, arg178_1, buf635, 3072, 1, 1, stream=raw_stream0)
        del arg178_1
        assert_size_stride(arg182_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf636 = buf584; del buf584  # reuse
        # Topologically Sorted Source Nodes: [mixed_qkv_40, mixed_qkv_41, conv1d_10, squeeze_10, unsqueeze_86, out_20, out_21], Original ATen: [aten._unsafe_view, aten.transpose, aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_convolution_silu_slice_squeeze_transpose_unsqueeze_2.run(buf635, arg182_1, buf636, 786432, stream=raw_stream0)
        del arg182_1
        buf637 = reinterpret_tensor(buf618, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf618  # reuse
        buf638 = reinterpret_tensor(buf589, (1, 16, 128, 1), (2048, 1, 16, 2048), 0); del buf589  # reuse
        buf648 = reinterpret_tensor(buf609, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf609  # reuse
        # Topologically Sorted Source Nodes: [out_21, mixed_qkv_43, split_10, query_81, transpose_137, query_82, mul_281, sum_21, add_182, inv_norm_20, query_83, query_84], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_3.run(buf636, buf637, buf638, buf648, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg181_1, (16, 2048), (2048, 1), 'input')
        buf639 = buf600; del buf600  # reuse
        # Topologically Sorted Source Nodes: [a_10], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf634, arg181_1, buf639, 8, 1, 1, stream=raw_stream0)
        del arg181_1
        assert_size_stride(arg183_1, (16, ), (1, ), 'input')
        buf640 = buf588; del buf588  # reuse
        # Topologically Sorted Source Nodes: [exp_60, neg_16], Original ATen: [aten.exp, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_neg_5.run(arg183_1, buf640, 16, stream=raw_stream0)
        del arg183_1
        assert_size_stride(arg184_1, (16, ), (1, ), 'input')
        buf641 = buf615; del buf615  # reuse
        # Topologically Sorted Source Nodes: [exp_60, neg_16, a_10, float_89, add_181, softplus_10, g_10, transpose_141, decay_32, cum_decay_10], Original ATen: [aten.exp, aten.neg, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.view, aten.cumsum]
        workspace_10 = workspace_9; del workspace_9  # reuse
        workspace_10.zero_()
        raw_stream0 = get_raw_stream(0)
        triton_spl_fused__to_copy__unsafe_view_add_cumsum_exp_mul_neg_softplus_transpose_view_6.run(buf640, buf639, arg184_1, buf641, workspace_10, 32, 64, stream=raw_stream0)
        del arg184_1
        buf642 = buf607; del buf607  # reuse
        buf659 = reinterpret_tensor(buf601, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf601  # reuse
        buf667 = reinterpret_tensor(buf586, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf586  # reuse
        # Topologically Sorted Source Nodes: [exp_63, exp_62, getitem_251, sub_41, exp_64], Original ATen: [aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_slice_sub_7.run(buf641, buf642, buf659, buf667, 2048, stream=raw_stream0)
        buf643 = reinterpret_tensor(buf606, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf606  # reuse
        # Topologically Sorted Source Nodes: [add_182, inv_norm_20, query_83, query_84, query_86, exp_63, unsqueeze_92, query_87], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_exp_mul_rsqrt_unsqueeze_view_8.run(buf637, buf638, buf642, buf643, 262144, stream=raw_stream0)
        buf644 = reinterpret_tensor(buf637, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf637  # reuse
        # Topologically Sorted Source Nodes: [last_recurrent_state_30], Original ATen: [aten.zeros]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_zeros_9.run(buf644, 262144, stream=raw_stream0)
        buf645 = buf622; del buf622  # reuse
        # Topologically Sorted Source Nodes: [add_182, inv_norm_20, query_83, query_84, query_86, exp_63, unsqueeze_92, query_87, getitem_256, inter_chunk_attn_20, last_recurrent_state_30], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze, aten.select, aten.zeros, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_unsqueeze_view_zeros_10.run(buf643, buf644, buf645, 32, 16, 1, stream=raw_stream0)
        buf646 = reinterpret_tensor(buf591, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf591  # reuse
        buf649 = reinterpret_tensor(buf616, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf616  # reuse
        # Topologically Sorted Source Nodes: [out_21, mixed_qkv_43, split_10, key_71, transpose_138, key_72, mul_283, sum_22, add_183, inv_norm_21, key_73], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_11.run(buf636, buf646, buf649, 2048, 128, stream=raw_stream0)
        buf650 = reinterpret_tensor(buf619, (32, 64, 64), (4096, 64, 1), 0); del buf619  # reuse
        # Topologically Sorted Source Nodes: [add_182, inv_norm_20, query_83, query_84, query_86, matmul_107, add_183, inv_norm_21, key_73, key_75, transpose_143], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_mul_rsqrt_transpose_view_12.run(buf648, buf649, buf650, 16, 32, 1, stream=raw_stream0)
        assert_size_stride(arg180_1, (16, 2048), (2048, 1), 'input')
        buf652 = buf639; del buf639  # reuse
        # Topologically Sorted Source Nodes: [b_10], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf634, arg180_1, buf652, 8, 1, 1, stream=raw_stream0)
        del arg180_1
        buf653 = reinterpret_tensor(buf642, (1, 16, 128), (2048, 128, 1), 0); del buf642  # reuse
        # Topologically Sorted Source Nodes: [b_10, beta_30, transpose_140, beta_31], Original ATen: [aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_sigmoid_transpose_13.run(buf652, buf653, 16, 128, stream=raw_stream0)
        buf654 = buf648; del buf648  # reuse
        buf660 = reinterpret_tensor(buf646, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf646  # reuse
        buf668 = buf608; del buf608  # reuse
        buf657 = buf605; del buf605  # reuse
        # Topologically Sorted Source Nodes: [out_21, mixed_qkv_43, split_10, add_183, inv_norm_21, key_73, key_75, unsqueeze_88, k_beta_20, k_beta_21, value_41, transpose_139, value_42, unsqueeze_87, v_beta_20, exp_62, unsqueeze_91, decayed_k_beta_10, getitem_251, sub_41, exp_64, unsqueeze_93, key_76], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.view, aten.unsqueeze, aten._to_copy, aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_exp_mul_rsqrt_silu_slice_split_with_sizes_sub_transpose_unsqueeze_view_14.run(buf649, buf653, buf659, buf667, buf636, buf654, buf660, buf668, buf657, 262144, stream=raw_stream0)
        buf656 = reinterpret_tensor(buf613, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf613  # reuse
        buf663 = reinterpret_tensor(buf593, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf593  # reuse
        # Topologically Sorted Source Nodes: [add_183, inv_norm_21, key_73, key_75, matmul_107, strictly_upper_mask_10, ones_10, pairwise_decay_31, unsqueeze_89, unsqueeze_90, pairwise_decay_30, pairwise_decay_32, intra_chunk_attn_10, unsqueeze_88, k_beta_20, k_beta_21, matmul_106, transpose_142, ut_system_10], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.triu, aten.ones, aten.masked_fill, aten.unsqueeze, aten.sub, aten.exp, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_masked_fill_mul_ones_rsqrt_sub_transpose_triu_unsqueeze_view_15.run(buf654, buf649, buf641, buf650, buf656, buf663, 16, 32, 1, stream=raw_stream0)
        del buf649
        del buf654
        # Topologically Sorted Source Nodes: [out_21, mixed_qkv_43, split_10, value_41, transpose_139, value_42, unsqueeze_87, v_beta_20, v_beta_21, new_values_10], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.unsqueeze, aten.mul, aten.linalg_solve_triangular]
        buf658 = torch.ops.aten.linalg_solve_triangular.default(buf656, reinterpret_tensor(buf657, (1, 16, 2, 64, 128), (0, 16384, 8192, 128, 1), 0), upper=False, unitriangular=True)
        assert_tensor_metadata(buf658, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf658, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        # Topologically Sorted Source Nodes: [unsqueeze_88, k_beta_20, k_beta_21, exp_62, unsqueeze_91, decayed_k_beta_10, k_cumdecay_10], Original ATen: [aten.unsqueeze, aten.mul, aten.view, aten.exp, aten.linalg_solve_triangular]
        buf661 = torch.ops.aten.linalg_solve_triangular.default(buf656, buf660, upper=False, unitriangular=True)
        assert_tensor_metadata(buf661, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf661, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        buf664 = reinterpret_tensor(buf656, (1, 16, 64, 128), (131072, 8192, 128, 1), 0); del buf656  # reuse
        # Topologically Sorted Source Nodes: [getitem_254, getitem_255, matmul_108, v_new_20], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_16.run(buf661, buf644, buf658, buf664, 32, 16, 1, stream=raw_stream0)
        buf665 = reinterpret_tensor(buf650, (16, 64, 128), (8192, 128, 1), 0); del buf650  # reuse
        # Topologically Sorted Source Nodes: [matmul_107, intra_chunk_attn_10, getitem_257, matmul_110, getitem_254, matmul_108, v_new_20], Original ATen: [aten.view, aten.mul, aten.select, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_mul_select_sub_view_17.run(buf663, buf664, buf665, 32, 16, 1, stream=raw_stream0)
        buf666 = buf614; del buf614  # reuse
        # Topologically Sorted Source Nodes: [getitem_252, exp_65], Original ATen: [aten.select, aten.exp]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_select_18.run(buf641, buf666, 32, stream=raw_stream0)
        buf670 = buf644; del buf644  # reuse
        # Topologically Sorted Source Nodes: [add_183, inv_norm_21, key_73, key_75, getitem_252, exp_65, chunk_decay_10, getitem_258, mul_293, getitem_251, sub_41, exp_64, unsqueeze_93, key_76, getitem_259, transpose_144, matmul_111, last_recurrent_state_31], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.select, aten.exp, aten.unsqueeze, aten.slice, aten.sub, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_slice_sub_transpose_unsqueeze_view_19.run(buf668, buf664, buf666, buf670, 64, 16, 1, stream=raw_stream0)
        buf671 = reinterpret_tensor(buf664, (16, 64, 128), (8192, 128, 1), 0); del buf664  # reuse
        # Topologically Sorted Source Nodes: [getitem_262, inter_chunk_attn_21, getitem_252, exp_65, chunk_decay_10, getitem_258, mul_293, matmul_111, last_recurrent_state_31], Original ATen: [aten.select, aten.view, aten.exp, aten.unsqueeze, aten.mul, aten.add, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_select_unsqueeze_view_20.run(buf643, buf670, buf671, 32, 16, 1, stream=raw_stream0)
        buf673 = buf621; del buf621  # reuse
        # Topologically Sorted Source Nodes: [getitem_260, getitem_261, matmul_112, v_new_21], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_21.run(buf661, buf670, buf658, buf673, 32, 16, 1, stream=raw_stream0)
        buf674 = reinterpret_tensor(buf611, (16, 64, 128), (8192, 128, 1), 0); del buf611  # reuse
        # Topologically Sorted Source Nodes: [getitem_263, matmul_114, getitem_260, matmul_112, v_new_21], Original ATen: [aten.select, aten.view, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_22.run(buf663, buf673, buf674, 32, 16, 1, stream=raw_stream0)
        assert_size_stride(arg179_1, (2048, 2048), (2048, 1), 'input')
        buf676 = buf492; del buf492  # reuse
        # Topologically Sorted Source Nodes: [z_30], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf634, arg179_1, buf676, 1024, 1, 1, stream=raw_stream0)
        del arg179_1
        assert_size_stride(arg185_1, (128, ), (1, ), 'input')
        buf677 = reinterpret_tensor(buf676, (2048, 128), (128, 1), 0); del buf676  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_70, setitem_24, inter_chunk_attn_20, matmul_110, add_184, setitem_25, inter_chunk_attn_21, matmul_114, add_186, core_attn_out_71, transpose_146, core_attn_out_73, core_attn_out_74, hidden_states_99, pow_44, variance_10, add_188, rsqrt_65, hidden_states_100, to_135, hidden_states_101, z_30, z_31, z_32, to_136, silu_34, hidden_states_102, core_attn_out_75], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_copy_mean_mul_pow_rsqrt_select_silu_transpose_view_zeros_like_24.run(buf677, buf671, buf674, buf645, buf665, arg185_1, 2048, 128, stream=raw_stream0)
        del arg185_1
        assert_size_stride(arg186_1, (2048, 2048), (2048, 1), 'input')
        buf678 = reinterpret_tensor(buf634, (128, 2048), (2048, 1), 0); del buf634  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_70, setitem_24, inter_chunk_attn_20, matmul_110, add_184, setitem_25, inter_chunk_attn_21, matmul_114, add_186, core_attn_out_71, transpose_146, core_attn_out_73, core_attn_out_74, hidden_states_99, pow_44, variance_10, add_188, rsqrt_65, hidden_states_100, to_135, hidden_states_101, z_30, z_31, z_32, to_136, silu_34, hidden_states_102, core_attn_out_75, core_attn_out_76, output_76], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf677, arg186_1, buf678, 1024, 1, 1, stream=raw_stream0)
        del arg186_1
        assert_size_stride(arg187_1, (2048, ), (1, ), 'input')
        buf679 = buf574; del buf574  # reuse
        buf681 = reinterpret_tensor(buf677, (1, 128, 2048), (262144, 2048, 1), 0); del buf677  # reuse
        # Topologically Sorted Source Nodes: [down_proj_11, hidden_states_89, output_71, hidden_states_95, down_proj_12, hidden_states_97, output_76, hidden_states_103, float_90, pow_45, mean_44, add_190, rsqrt_66, output_77, float_91, add_191, output_78, hidden_states_104], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_50.run(buf679, buf580, buf626, buf632, buf678, arg187_1, buf681, 128, 2048, stream=raw_stream0)
        del arg187_1
        assert_size_stride(arg188_1, (6144, 2048), (2048, 1), 'input')
        buf682 = buf635; del buf635  # reuse
        # Topologically Sorted Source Nodes: [float_90, pow_45, mean_44, add_190, rsqrt_66, output_77, float_91, add_191, output_78, hidden_states_104, linear_106], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf681, arg188_1, buf682, 3072, 1, 1, stream=raw_stream0)
        del arg188_1
        assert_size_stride(arg189_1, (6144, 2048), (2048, 1), 'input')
        buf684 = reinterpret_tensor(buf629, (1, 128, 6144), (786432, 6144, 1), 0); del buf629  # reuse
        # Topologically Sorted Source Nodes: [linear_106, silu_35, linear_107, mul_300], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_26.run(buf681, arg189_1, buf682, buf684, 3072, 1, 1, stream=raw_stream0)
        del arg189_1
        assert_size_stride(arg190_1, (2048, 6144), (6144, 1), 'input')
        buf685 = reinterpret_tensor(buf681, (128, 2048), (2048, 1), 0); del buf681  # reuse
        # Topologically Sorted Source Nodes: [linear_106, silu_35, linear_107, mul_300, down_proj_13], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_27.run(buf684, arg190_1, buf685, 1024, 1, 1, stream=raw_stream0)
        del arg190_1
        assert_size_stride(arg191_1, (2048, ), (1, ), 'input')
        buf687 = reinterpret_tensor(buf678, (1, 128, 2048), (262144, 2048, 1), 0); del buf678  # reuse
        # Topologically Sorted Source Nodes: [down_proj_13, hidden_states_105, float_92, pow_46, mean_45, add_193, rsqrt_67, output_79, float_93, add_194, output_80, hidden_states_106], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_30.run(buf679, buf685, arg191_1, buf687, 128, 2048, stream=raw_stream0)
        del arg191_1
        assert_size_stride(arg192_1, (6144, 2048), (2048, 1), 'input')
        buf688 = reinterpret_tensor(buf684, (128, 6144), (6144, 1), 0); del buf684  # reuse
        # Topologically Sorted Source Nodes: [down_proj_13, hidden_states_105, float_92, pow_46, mean_45, add_193, rsqrt_67, output_79, float_93, add_194, output_80, hidden_states_106, mixed_qkv_44], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf687, arg192_1, buf688, 3072, 1, 1, stream=raw_stream0)
        del arg192_1
        assert_size_stride(arg196_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf689 = buf636; del buf636  # reuse
        # Topologically Sorted Source Nodes: [mixed_qkv_44, mixed_qkv_45, conv1d_11, squeeze_11, unsqueeze_94, out_22, out_23], Original ATen: [aten._unsafe_view, aten.transpose, aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_convolution_silu_slice_squeeze_transpose_unsqueeze_2.run(buf688, arg196_1, buf689, 786432, stream=raw_stream0)
        del arg196_1
        buf690 = reinterpret_tensor(buf670, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf670  # reuse
        buf691 = reinterpret_tensor(buf641, (1, 16, 128, 1), (2048, 1, 16, 2048), 0); del buf641  # reuse
        buf701 = reinterpret_tensor(buf661, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf661  # reuse
        # Topologically Sorted Source Nodes: [out_23, mixed_qkv_47, split_11, query_89, transpose_149, query_90, mul_304, sum_23, add_196, inv_norm_22, query_91, query_92], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_3.run(buf689, buf690, buf691, buf701, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg195_1, (16, 2048), (2048, 1), 'input')
        buf692 = buf652; del buf652  # reuse
        # Topologically Sorted Source Nodes: [a_11], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf687, arg195_1, buf692, 8, 1, 1, stream=raw_stream0)
        del arg195_1
        assert_size_stride(arg197_1, (16, ), (1, ), 'input')
        buf693 = buf640; del buf640  # reuse
        # Topologically Sorted Source Nodes: [exp_66, neg_17], Original ATen: [aten.exp, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_neg_5.run(arg197_1, buf693, 16, stream=raw_stream0)
        del arg197_1
        assert_size_stride(arg198_1, (16, ), (1, ), 'input')
        buf694 = buf667; del buf667  # reuse
        # Topologically Sorted Source Nodes: [exp_66, neg_17, a_11, float_95, add_195, softplus_11, g_11, transpose_153, decay_35, cum_decay_11], Original ATen: [aten.exp, aten.neg, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.view, aten.cumsum]
        workspace_11 = workspace_10; del workspace_10  # reuse
        workspace_11.zero_()
        raw_stream0 = get_raw_stream(0)
        triton_spl_fused__to_copy__unsafe_view_add_cumsum_exp_mul_neg_softplus_transpose_view_6.run(buf693, buf692, arg198_1, buf694, workspace_11, 32, 64, stream=raw_stream0)
        del arg198_1
        buf695 = buf659; del buf659  # reuse
        buf712 = reinterpret_tensor(buf653, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf653  # reuse
        buf720 = reinterpret_tensor(buf638, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf638  # reuse
        # Topologically Sorted Source Nodes: [exp_69, exp_68, getitem_271, sub_45, exp_70], Original ATen: [aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_slice_sub_7.run(buf694, buf695, buf712, buf720, 2048, stream=raw_stream0)
        buf696 = reinterpret_tensor(buf658, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf658  # reuse
        # Topologically Sorted Source Nodes: [add_196, inv_norm_22, query_91, query_92, query_94, exp_69, unsqueeze_100, query_95], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_exp_mul_rsqrt_unsqueeze_view_8.run(buf690, buf691, buf695, buf696, 262144, stream=raw_stream0)
        buf697 = reinterpret_tensor(buf690, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf690  # reuse
        # Topologically Sorted Source Nodes: [last_recurrent_state_33], Original ATen: [aten.zeros]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_zeros_9.run(buf697, 262144, stream=raw_stream0)
        buf698 = buf674; del buf674  # reuse
        # Topologically Sorted Source Nodes: [add_196, inv_norm_22, query_91, query_92, query_94, exp_69, unsqueeze_100, query_95, getitem_276, inter_chunk_attn_22, last_recurrent_state_33], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze, aten.select, aten.zeros, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_unsqueeze_view_zeros_10.run(buf696, buf697, buf698, 32, 16, 1, stream=raw_stream0)
        buf699 = reinterpret_tensor(buf643, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf643  # reuse
        buf702 = reinterpret_tensor(buf668, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf668  # reuse
        # Topologically Sorted Source Nodes: [out_23, mixed_qkv_47, split_11, key_78, transpose_150, key_79, mul_306, sum_24, add_197, inv_norm_23, key_80], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_11.run(buf689, buf699, buf702, 2048, 128, stream=raw_stream0)
        buf703 = reinterpret_tensor(buf671, (32, 64, 64), (4096, 64, 1), 0); del buf671  # reuse
        # Topologically Sorted Source Nodes: [add_196, inv_norm_22, query_91, query_92, query_94, matmul_117, add_197, inv_norm_23, key_80, key_82, transpose_155], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_mul_rsqrt_transpose_view_12.run(buf701, buf702, buf703, 16, 32, 1, stream=raw_stream0)
        assert_size_stride(arg194_1, (16, 2048), (2048, 1), 'input')
        buf705 = buf692; del buf692  # reuse
        # Topologically Sorted Source Nodes: [b_11], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf687, arg194_1, buf705, 8, 1, 1, stream=raw_stream0)
        del arg194_1
        buf706 = reinterpret_tensor(buf695, (1, 16, 128), (2048, 128, 1), 0); del buf695  # reuse
        # Topologically Sorted Source Nodes: [b_11, beta_33, transpose_152, beta_34], Original ATen: [aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_sigmoid_transpose_13.run(buf705, buf706, 16, 128, stream=raw_stream0)
        buf707 = buf701; del buf701  # reuse
        buf713 = reinterpret_tensor(buf699, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf699  # reuse
        buf721 = buf660; del buf660  # reuse
        buf710 = buf657; del buf657  # reuse
        # Topologically Sorted Source Nodes: [out_23, mixed_qkv_47, split_11, add_197, inv_norm_23, key_80, key_82, unsqueeze_96, k_beta_22, k_beta_23, value_45, transpose_151, value_46, unsqueeze_95, v_beta_22, exp_68, unsqueeze_99, decayed_k_beta_11, getitem_271, sub_45, exp_70, unsqueeze_101, key_83], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.view, aten.unsqueeze, aten._to_copy, aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_exp_mul_rsqrt_silu_slice_split_with_sizes_sub_transpose_unsqueeze_view_14.run(buf702, buf706, buf712, buf720, buf689, buf707, buf713, buf721, buf710, 262144, stream=raw_stream0)
        buf709 = reinterpret_tensor(buf665, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf665  # reuse
        buf716 = reinterpret_tensor(buf645, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf645  # reuse
        # Topologically Sorted Source Nodes: [add_197, inv_norm_23, key_80, key_82, matmul_117, strictly_upper_mask_11, ones_11, pairwise_decay_34, unsqueeze_97, unsqueeze_98, pairwise_decay_33, pairwise_decay_35, intra_chunk_attn_11, unsqueeze_96, k_beta_22, k_beta_23, matmul_116, transpose_154, ut_system_11], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.triu, aten.ones, aten.masked_fill, aten.unsqueeze, aten.sub, aten.exp, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_masked_fill_mul_ones_rsqrt_sub_transpose_triu_unsqueeze_view_15.run(buf707, buf702, buf694, buf703, buf709, buf716, 16, 32, 1, stream=raw_stream0)
        del buf702
        del buf707
        # Topologically Sorted Source Nodes: [out_23, mixed_qkv_47, split_11, value_45, transpose_151, value_46, unsqueeze_95, v_beta_22, v_beta_23, new_values_11], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.unsqueeze, aten.mul, aten.linalg_solve_triangular]
        buf711 = torch.ops.aten.linalg_solve_triangular.default(buf709, reinterpret_tensor(buf710, (1, 16, 2, 64, 128), (0, 16384, 8192, 128, 1), 0), upper=False, unitriangular=True)
        assert_tensor_metadata(buf711, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf711, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        # Topologically Sorted Source Nodes: [unsqueeze_96, k_beta_22, k_beta_23, exp_68, unsqueeze_99, decayed_k_beta_11, k_cumdecay_11], Original ATen: [aten.unsqueeze, aten.mul, aten.view, aten.exp, aten.linalg_solve_triangular]
        buf714 = torch.ops.aten.linalg_solve_triangular.default(buf709, buf713, upper=False, unitriangular=True)
        assert_tensor_metadata(buf714, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf714, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        buf717 = reinterpret_tensor(buf709, (1, 16, 64, 128), (131072, 8192, 128, 1), 0); del buf709  # reuse
        # Topologically Sorted Source Nodes: [getitem_274, getitem_275, matmul_118, v_new_22], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_16.run(buf714, buf697, buf711, buf717, 32, 16, 1, stream=raw_stream0)
        buf718 = reinterpret_tensor(buf703, (16, 64, 128), (8192, 128, 1), 0); del buf703  # reuse
        # Topologically Sorted Source Nodes: [matmul_117, intra_chunk_attn_11, getitem_277, matmul_120, getitem_274, matmul_118, v_new_22], Original ATen: [aten.view, aten.mul, aten.select, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_mul_select_sub_view_17.run(buf716, buf717, buf718, 32, 16, 1, stream=raw_stream0)
        buf719 = buf666; del buf666  # reuse
        # Topologically Sorted Source Nodes: [getitem_272, exp_71], Original ATen: [aten.select, aten.exp]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_select_18.run(buf694, buf719, 32, stream=raw_stream0)
        buf723 = buf697; del buf697  # reuse
        # Topologically Sorted Source Nodes: [add_197, inv_norm_23, key_80, key_82, getitem_272, exp_71, chunk_decay_11, getitem_278, mul_316, getitem_271, sub_45, exp_70, unsqueeze_101, key_83, getitem_279, transpose_156, matmul_121, last_recurrent_state_34], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.select, aten.exp, aten.unsqueeze, aten.slice, aten.sub, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_slice_sub_transpose_unsqueeze_view_19.run(buf721, buf717, buf719, buf723, 64, 16, 1, stream=raw_stream0)
        buf724 = reinterpret_tensor(buf717, (16, 64, 128), (8192, 128, 1), 0); del buf717  # reuse
        # Topologically Sorted Source Nodes: [getitem_282, inter_chunk_attn_23, getitem_272, exp_71, chunk_decay_11, getitem_278, mul_316, matmul_121, last_recurrent_state_34], Original ATen: [aten.select, aten.view, aten.exp, aten.unsqueeze, aten.mul, aten.add, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_select_unsqueeze_view_20.run(buf696, buf723, buf724, 32, 16, 1, stream=raw_stream0)
        buf726 = buf673; del buf673  # reuse
        # Topologically Sorted Source Nodes: [getitem_280, getitem_281, matmul_122, v_new_23], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_21.run(buf714, buf723, buf711, buf726, 32, 16, 1, stream=raw_stream0)
        buf727 = reinterpret_tensor(buf663, (16, 64, 128), (8192, 128, 1), 0); del buf663  # reuse
        # Topologically Sorted Source Nodes: [getitem_283, matmul_124, getitem_280, matmul_122, v_new_23], Original ATen: [aten.select, aten.view, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_22.run(buf716, buf726, buf727, 32, 16, 1, stream=raw_stream0)
        assert_size_stride(arg193_1, (2048, 2048), (2048, 1), 'input')
        buf729 = buf632; del buf632  # reuse
        # Topologically Sorted Source Nodes: [z_33], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf687, arg193_1, buf729, 1024, 1, 1, stream=raw_stream0)
        del arg193_1
        assert_size_stride(arg199_1, (128, ), (1, ), 'input')
        buf730 = reinterpret_tensor(buf729, (2048, 128), (128, 1), 0); del buf729  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_77, setitem_26, inter_chunk_attn_22, matmul_120, add_198, setitem_27, inter_chunk_attn_23, matmul_124, add_200, core_attn_out_78, transpose_158, core_attn_out_80, core_attn_out_81, hidden_states_107, pow_47, variance_11, add_202, rsqrt_70, hidden_states_108, to_147, hidden_states_109, z_33, z_34, z_35, to_148, silu_37, hidden_states_110, core_attn_out_82], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_copy_mean_mul_pow_rsqrt_select_silu_transpose_view_zeros_like_24.run(buf730, buf724, buf727, buf698, buf718, arg199_1, 2048, 128, stream=raw_stream0)
        del arg199_1
        assert_size_stride(arg200_1, (2048, 2048), (2048, 1), 'input')
        buf731 = reinterpret_tensor(buf687, (128, 2048), (2048, 1), 0); del buf687  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_77, setitem_26, inter_chunk_attn_22, matmul_120, add_198, setitem_27, inter_chunk_attn_23, matmul_124, add_200, core_attn_out_78, transpose_158, core_attn_out_80, core_attn_out_81, hidden_states_107, pow_47, variance_11, add_202, rsqrt_70, hidden_states_108, to_147, hidden_states_109, z_33, z_34, z_35, to_148, silu_37, hidden_states_110, core_attn_out_82, core_attn_out_83, output_81], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf730, arg200_1, buf731, 1024, 1, 1, stream=raw_stream0)
        del arg200_1
        assert_size_stride(arg201_1, (2048, ), (1, ), 'input')
        buf733 = reinterpret_tensor(buf730, (1, 128, 2048), (262144, 2048, 1), 0); del buf730  # reuse
        # Topologically Sorted Source Nodes: [down_proj_13, hidden_states_105, output_81, hidden_states_111, float_96, pow_48, mean_47, add_204, rsqrt_71, output_82, float_97, add_205, output_83, hidden_states_112], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_31.run(buf679, buf685, buf731, arg201_1, buf733, 128, 2048, stream=raw_stream0)
        del arg201_1
        assert_size_stride(arg202_1, (6144, 2048), (2048, 1), 'input')
        buf734 = buf688; del buf688  # reuse
        # Topologically Sorted Source Nodes: [linear_114], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf733, arg202_1, buf734, 3072, 1, 1, stream=raw_stream0)
        del arg202_1
        assert_size_stride(arg203_1, (6144, 2048), (2048, 1), 'input')
        buf736 = reinterpret_tensor(buf682, (1, 128, 6144), (786432, 6144, 1), 0); del buf682  # reuse
        # Topologically Sorted Source Nodes: [linear_114, silu_38, linear_115, mul_323], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_26.run(buf733, arg203_1, buf734, buf736, 3072, 1, 1, stream=raw_stream0)
        del arg203_1
        assert_size_stride(arg204_1, (2048, 6144), (6144, 1), 'input')
        buf737 = reinterpret_tensor(buf733, (128, 2048), (2048, 1), 0); del buf733  # reuse
        # Topologically Sorted Source Nodes: [linear_114, silu_38, linear_115, mul_323, down_proj_14], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_27.run(buf736, arg204_1, buf737, 1024, 1, 1, stream=raw_stream0)
        del arg204_1
        assert_size_stride(arg205_1, (2048, ), (1, ), 'input')
        buf739 = reinterpret_tensor(buf626, (1, 128, 2048), (262144, 2048, 1), 0); del buf626  # reuse
        # Topologically Sorted Source Nodes: [down_proj_13, hidden_states_105, output_81, hidden_states_111, down_proj_14, hidden_states_113, float_98, pow_49, mean_48, add_207, rsqrt_72, output_84, float_99, add_208, output_85, hidden_states_114], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_32.run(buf679, buf685, buf731, buf737, arg205_1, buf739, 128, 2048, stream=raw_stream0)
        del arg205_1
        assert_size_stride(arg206_1, (4096, 2048), (2048, 1), 'input')
        buf740 = buf547; del buf547  # reuse
        # Topologically Sorted Source Nodes: [linear_117], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_33.run(buf739, arg206_1, buf740, 2048, 1, 1, stream=raw_stream0)
        del arg206_1
        buf741 = buf548; del buf548  # reuse
        # Topologically Sorted Source Nodes: [linear_117, view_12, chunk_3, float_100, pow_50, mean_49], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_mean_pow_split_view_34.run(buf740, buf741, 1024, 256, stream=raw_stream0)
        assert_size_stride(arg207_1, (256, ), (1, ), 'input')
        buf744 = reinterpret_tensor(buf568, (1, 8, 128, 64), (65536, 8192, 64, 1), 0); del buf568  # reuse
        buf742 = reinterpret_tensor(buf744, (1, 8, 128, 32), (65536, 8192, 64, 1), 0)  # alias
        buf743 = reinterpret_tensor(buf744, (1, 8, 128, 32), (65536, 8192, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_117, view_12, chunk_3, float_100, pow_50, mean_49, add_209, rsqrt_73, output_86, float_101, add_210, output_87, type_as_37, query_states_7, q_rot_3, x2_6, neg_18, x1_6, cat_14], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_36.run(buf740, buf741, arg207_1, buf742, buf743, 32768, stream=raw_stream0)
        buf747 = reinterpret_tensor(buf580, (1, 8, 128, 256), (262144, 32768, 256, 1), 0); del buf580  # reuse
        buf745 = reinterpret_tensor(buf747, (1, 8, 128, 64), (262144, 32768, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, linear_117, view_12, chunk_3, float_100, pow_50, mean_49, add_209, rsqrt_73, output_86, float_101, add_210, output_87, type_as_37, query_states_7, q_rot_3, cos_7, mul_330, sin_7, mul_331, q_embed_6], Original ATen: [aten.select, aten.cat, aten._to_copy, aten._unsafe_view, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_37.run(buf740, buf741, arg207_1, buf161, buf744, buf165, buf745, 65536, stream=raw_stream0)
        del buf742
        del buf743
        buf746 = reinterpret_tensor(buf747, (1, 8, 128, 192), (262144, 32768, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, linear_117, view_12, chunk_3, float_100, pow_50, mean_49, add_209, rsqrt_73, output_86, float_101, add_210, output_87, type_as_37, query_states_7, q_rot_3, cos_7, mul_330, sin_7, mul_331, q_embed_6, q_pass_3, q_embed_7], Original ATen: [aten.select, aten.cat, aten._to_copy, aten._unsafe_view, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_38.run(buf740, buf741, arg207_1, buf746, 196608, stream=raw_stream0)
        del arg207_1
        assert_size_stride(arg208_1, (512, 2048), (2048, 1), 'input')
        del buf745
        del buf746
        buf748 = reinterpret_tensor(buf744, (128, 512), (512, 1), 0); del buf744  # reuse
        # Topologically Sorted Source Nodes: [linear_118], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_39.run(buf739, arg208_1, buf748, 256, 1, 1, stream=raw_stream0)
        del arg208_1
        buf749 = buf556; del buf556  # reuse
        # Topologically Sorted Source Nodes: [linear_118, view_14, float_102, pow_51, mean_50], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_mean_pow_view_40.run(buf748, buf749, 256, 256, stream=raw_stream0)
        assert_size_stride(arg209_1, (256, ), (1, ), 'input')
        buf752 = buf559; del buf559  # reuse
        buf750 = reinterpret_tensor(buf752, (1, 2, 128, 32), (16384, 8192, 64, 1), 0)  # alias
        buf751 = reinterpret_tensor(buf752, (1, 2, 128, 32), (16384, 8192, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_118, view_14, float_102, pow_51, mean_50, add_211, rsqrt_74, output_88, float_103, add_212, output_89, type_as_38, key_states_6, k_rot_3, x2_7, neg_19, x1_7, cat_15], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_41.run(buf748, buf749, arg209_1, buf750, buf751, 8192, stream=raw_stream0)
        buf755 = reinterpret_tensor(buf555, (1, 2, 128, 256), (65536, 32768, 256, 1), 0); del buf555  # reuse
        buf753 = reinterpret_tensor(buf755, (1, 2, 128, 64), (65536, 32768, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, cos_7, sin_7, linear_118, view_14, float_102, pow_51, mean_50, add_211, rsqrt_74, output_88, float_103, add_212, output_89, type_as_38, key_states_6, k_rot_3, mul_332, mul_333, k_embed_6], Original ATen: [aten.select, aten.cat, aten._to_copy, aten.unsqueeze, aten._unsafe_view, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_42.run(buf748, buf749, arg209_1, buf161, buf752, buf165, buf753, 16384, stream=raw_stream0)
        del buf750
        del buf751
        buf754 = reinterpret_tensor(buf755, (1, 2, 128, 192), (65536, 32768, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, cos_7, sin_7, linear_118, view_14, float_102, pow_51, mean_50, add_211, rsqrt_74, output_88, float_103, add_212, output_89, type_as_38, key_states_6, k_rot_3, mul_332, mul_333, k_embed_6, k_pass_3, k_embed_7], Original ATen: [aten.select, aten.cat, aten._to_copy, aten.unsqueeze, aten._unsafe_view, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_43.run(buf748, buf749, arg209_1, buf754, 49152, stream=raw_stream0)
        del arg209_1
        buf756 = reinterpret_tensor(buf554, (1, 2, 4, 128, 256), (262144, 131072, 32768, 256, 1), 0); del buf554  # reuse
        # Topologically Sorted Source Nodes: [getitem_297, hidden_states_115, key_states_7], Original ATen: [aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_clone_expand_unsqueeze_44.run(buf755, buf756, 262144, stream=raw_stream0)
        del buf753
        del buf754
        buf757 = reinterpret_tensor(buf569, (8, 128, 128), (16384, 128, 1), 0); del buf569  # reuse
        # Topologically Sorted Source Nodes: [matmul_126, getitem_297, hidden_states_115, key_states_7, transpose_162], Original ATen: [aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_45.run(buf747, buf756, buf757, 64, 8, 1, stream=raw_stream0)
        buf759 = reinterpret_tensor(buf727, (1, 8, 128, 128), (131072, 16384, 128, 1), 0); del buf727  # reuse
        buf762 = reinterpret_tensor(buf564, (1, 8, 128, 128), (131072, 16384, 128, 1), 0); del buf564  # reuse
        # Topologically Sorted Source Nodes: [mask, full, getitem, matmul_126, attn_weights_12, attn_weights_13, softmax_3, attn_weights_14], Original ATen: [aten.triu, aten.full, aten.unsqueeze, aten.view, aten.mul, aten.add, aten._to_copy, aten._softmax]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__softmax__to_copy_add_full_mul_triu_unsqueeze_view_46.run(buf757, buf759, buf762, 1024, 128, stream=raw_stream0)
        assert_size_stride(arg210_1, (512, 2048), (2048, 1), 'input')
        buf761 = reinterpret_tensor(buf755, (128, 512), (512, 1), 0); del buf755  # reuse
        # Topologically Sorted Source Nodes: [linear_119], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_39.run(buf739, arg210_1, buf761, 256, 1, 1, stream=raw_stream0)
        del arg210_1
        buf763 = reinterpret_tensor(buf739, (1, 2, 4, 128, 256), (262144, 131072, 32768, 256, 1), 0); del buf739  # reuse
        # Topologically Sorted Source Nodes: [linear_119, view_15, value_states_6, getitem_298, hidden_states_116, value_states_7], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_clone_expand_transpose_unsqueeze_view_47.run(buf761, buf763, 262144, stream=raw_stream0)
        buf764 = reinterpret_tensor(buf756, (8, 128, 256), (32768, 256, 1), 0); del buf756  # reuse
        # Topologically Sorted Source Nodes: [softmax_3, attn_weights_14, attn_output_15, linear_119, view_15, value_states_6, getitem_298, hidden_states_116, value_states_7], Original ATen: [aten._softmax, aten._to_copy, aten.view, aten._unsafe_view, aten.transpose, aten.unsqueeze, aten.expand, aten.clone, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__softmax__to_copy__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_48.run(buf762, buf763, buf764, 128, 8, 1, stream=raw_stream0)
        buf765 = reinterpret_tensor(buf763, (1, 128, 2048), (262144, 2048, 1), 0); del buf763  # reuse
        # Topologically Sorted Source Nodes: [linear_117, view_12, chunk_3, attn_output_15, transpose_163, attn_output_16, reshape_171, gate_7, sigmoid_15, attn_output_18], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten.transpose, aten.clone, aten.sigmoid, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_clone_mul_sigmoid_split_transpose_view_49.run(buf764, buf740, buf765, 262144, stream=raw_stream0)
        assert_size_stride(arg211_1, (2048, 2048), (2048, 1), 'input')
        buf766 = reinterpret_tensor(buf764, (128, 2048), (2048, 1), 0); del buf764  # reuse
        # Topologically Sorted Source Nodes: [linear_117, view_12, chunk_3, attn_output_15, transpose_163, attn_output_16, reshape_171, gate_7, sigmoid_15, attn_output_18, attn_output_19], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten.transpose, aten.clone, aten.sigmoid, aten.mul, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf765, arg211_1, buf766, 1024, 1, 1, stream=raw_stream0)
        del arg211_1
        assert_size_stride(arg212_1, (2048, ), (1, ), 'input')
        buf767 = buf679; del buf679  # reuse
        buf769 = buf765; del buf765  # reuse
        # Topologically Sorted Source Nodes: [down_proj_13, hidden_states_105, output_81, hidden_states_111, down_proj_14, hidden_states_113, attn_output_19, hidden_states_117, float_104, pow_52, mean_51, add_217, rsqrt_75, output_90, float_105, add_218, output_91, hidden_states_118], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_50.run(buf767, buf685, buf731, buf737, buf766, arg212_1, buf769, 128, 2048, stream=raw_stream0)
        del arg212_1
        assert_size_stride(arg213_1, (6144, 2048), (2048, 1), 'input')
        buf770 = reinterpret_tensor(buf736, (128, 6144), (6144, 1), 0); del buf736  # reuse
        # Topologically Sorted Source Nodes: [float_104, pow_52, mean_51, add_217, rsqrt_75, output_90, float_105, add_218, output_91, hidden_states_118, linear_121], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf769, arg213_1, buf770, 3072, 1, 1, stream=raw_stream0)
        del arg213_1
        assert_size_stride(arg214_1, (6144, 2048), (2048, 1), 'input')
        buf772 = reinterpret_tensor(buf734, (1, 128, 6144), (786432, 6144, 1), 0); del buf734  # reuse
        # Topologically Sorted Source Nodes: [linear_121, silu_39, linear_122, mul_338], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_26.run(buf769, arg214_1, buf770, buf772, 3072, 1, 1, stream=raw_stream0)
        del arg214_1
        assert_size_stride(arg215_1, (2048, 6144), (6144, 1), 'input')
        buf773 = reinterpret_tensor(buf769, (128, 2048), (2048, 1), 0); del buf769  # reuse
        # Topologically Sorted Source Nodes: [linear_121, silu_39, linear_122, mul_338, down_proj_15], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_27.run(buf772, arg215_1, buf773, 1024, 1, 1, stream=raw_stream0)
        del arg215_1
        assert_size_stride(arg216_1, (2048, ), (1, ), 'input')
        buf775 = reinterpret_tensor(buf766, (1, 128, 2048), (262144, 2048, 1), 0); del buf766  # reuse
        # Topologically Sorted Source Nodes: [down_proj_15, hidden_states_119, float_106, pow_53, mean_52, add_220, rsqrt_76, output_92, float_107, add_221, output_93, hidden_states_120], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_30.run(buf767, buf773, arg216_1, buf775, 128, 2048, stream=raw_stream0)
        del arg216_1
        assert_size_stride(arg217_1, (6144, 2048), (2048, 1), 'input')
        buf776 = reinterpret_tensor(buf772, (128, 6144), (6144, 1), 0); del buf772  # reuse
        # Topologically Sorted Source Nodes: [down_proj_15, hidden_states_119, float_106, pow_53, mean_52, add_220, rsqrt_76, output_92, float_107, add_221, output_93, hidden_states_120, mixed_qkv_48], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf775, arg217_1, buf776, 3072, 1, 1, stream=raw_stream0)
        del arg217_1
        assert_size_stride(arg221_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf777 = buf689; del buf689  # reuse
        # Topologically Sorted Source Nodes: [mixed_qkv_48, mixed_qkv_49, conv1d_12, squeeze_12, unsqueeze_104, out_24, out_25], Original ATen: [aten._unsafe_view, aten.transpose, aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_convolution_silu_slice_squeeze_transpose_unsqueeze_2.run(buf776, arg221_1, buf777, 786432, stream=raw_stream0)
        del arg221_1
        buf778 = reinterpret_tensor(buf723, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf723  # reuse
        buf779 = reinterpret_tensor(buf694, (1, 16, 128, 1), (2048, 1, 16, 2048), 0); del buf694  # reuse
        buf789 = reinterpret_tensor(buf714, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf714  # reuse
        # Topologically Sorted Source Nodes: [out_25, mixed_qkv_51, split_12, query_97, transpose_166, query_98, mul_342, sum_25, add_223, inv_norm_24, query_99, query_100], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_3.run(buf777, buf778, buf779, buf789, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg220_1, (16, 2048), (2048, 1), 'input')
        buf780 = buf705; del buf705  # reuse
        # Topologically Sorted Source Nodes: [a_12], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf775, arg220_1, buf780, 8, 1, 1, stream=raw_stream0)
        del arg220_1
        assert_size_stride(arg222_1, (16, ), (1, ), 'input')
        buf781 = buf693; del buf693  # reuse
        # Topologically Sorted Source Nodes: [exp_72, neg_20], Original ATen: [aten.exp, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_neg_5.run(arg222_1, buf781, 16, stream=raw_stream0)
        del arg222_1
        assert_size_stride(arg223_1, (16, ), (1, ), 'input')
        buf782 = buf720; del buf720  # reuse
        # Topologically Sorted Source Nodes: [exp_72, neg_20, a_12, float_109, add_222, softplus_12, g_12, transpose_170, decay_38, cum_decay_12], Original ATen: [aten.exp, aten.neg, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.view, aten.cumsum]
        workspace_12 = workspace_11; del workspace_11  # reuse
        workspace_12.zero_()
        raw_stream0 = get_raw_stream(0)
        triton_spl_fused__to_copy__unsafe_view_add_cumsum_exp_mul_neg_softplus_transpose_view_6.run(buf781, buf780, arg223_1, buf782, workspace_12, 32, 64, stream=raw_stream0)
        del arg223_1
        buf783 = buf712; del buf712  # reuse
        buf800 = reinterpret_tensor(buf706, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf706  # reuse
        buf808 = reinterpret_tensor(buf691, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf691  # reuse
        # Topologically Sorted Source Nodes: [exp_75, exp_74, getitem_303, sub_49, exp_76], Original ATen: [aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_slice_sub_7.run(buf782, buf783, buf800, buf808, 2048, stream=raw_stream0)
        buf784 = reinterpret_tensor(buf711, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf711  # reuse
        # Topologically Sorted Source Nodes: [add_223, inv_norm_24, query_99, query_100, query_102, exp_75, unsqueeze_110, query_103], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_exp_mul_rsqrt_unsqueeze_view_8.run(buf778, buf779, buf783, buf784, 262144, stream=raw_stream0)
        buf785 = reinterpret_tensor(buf778, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf778  # reuse
        # Topologically Sorted Source Nodes: [last_recurrent_state_36], Original ATen: [aten.zeros]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_zeros_9.run(buf785, 262144, stream=raw_stream0)
        buf786 = reinterpret_tensor(buf759, (16, 64, 128), (8192, 128, 1), 0); del buf759  # reuse
        # Topologically Sorted Source Nodes: [add_223, inv_norm_24, query_99, query_100, query_102, exp_75, unsqueeze_110, query_103, getitem_308, inter_chunk_attn_24, last_recurrent_state_36], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze, aten.select, aten.zeros, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_unsqueeze_view_zeros_10.run(buf784, buf785, buf786, 32, 16, 1, stream=raw_stream0)
        buf787 = reinterpret_tensor(buf696, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf696  # reuse
        buf790 = reinterpret_tensor(buf721, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf721  # reuse
        # Topologically Sorted Source Nodes: [out_25, mixed_qkv_51, split_12, key_85, transpose_167, key_86, mul_344, sum_26, add_224, inv_norm_25, key_87], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_11.run(buf777, buf787, buf790, 2048, 128, stream=raw_stream0)
        buf791 = reinterpret_tensor(buf724, (32, 64, 64), (4096, 64, 1), 0); del buf724  # reuse
        # Topologically Sorted Source Nodes: [add_223, inv_norm_24, query_99, query_100, query_102, matmul_129, add_224, inv_norm_25, key_87, key_89, transpose_172], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_mul_rsqrt_transpose_view_12.run(buf789, buf790, buf791, 16, 32, 1, stream=raw_stream0)
        assert_size_stride(arg219_1, (16, 2048), (2048, 1), 'input')
        buf793 = buf780; del buf780  # reuse
        # Topologically Sorted Source Nodes: [b_12], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf775, arg219_1, buf793, 8, 1, 1, stream=raw_stream0)
        del arg219_1
        buf794 = reinterpret_tensor(buf783, (1, 16, 128), (2048, 128, 1), 0); del buf783  # reuse
        # Topologically Sorted Source Nodes: [b_12, beta_36, transpose_169, beta_37], Original ATen: [aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_sigmoid_transpose_13.run(buf793, buf794, 16, 128, stream=raw_stream0)
        buf795 = buf789; del buf789  # reuse
        buf801 = reinterpret_tensor(buf787, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf787  # reuse
        buf809 = buf713; del buf713  # reuse
        buf798 = buf710; del buf710  # reuse
        # Topologically Sorted Source Nodes: [out_25, mixed_qkv_51, split_12, add_224, inv_norm_25, key_87, key_89, unsqueeze_106, k_beta_24, k_beta_25, value_49, transpose_168, value_50, unsqueeze_105, v_beta_24, exp_74, unsqueeze_109, decayed_k_beta_12, getitem_303, sub_49, exp_76, unsqueeze_111, key_90], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.view, aten.unsqueeze, aten._to_copy, aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_exp_mul_rsqrt_silu_slice_split_with_sizes_sub_transpose_unsqueeze_view_14.run(buf790, buf794, buf800, buf808, buf777, buf795, buf801, buf809, buf798, 262144, stream=raw_stream0)
        buf797 = reinterpret_tensor(buf718, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf718  # reuse
        buf804 = reinterpret_tensor(buf698, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf698  # reuse
        # Topologically Sorted Source Nodes: [add_224, inv_norm_25, key_87, key_89, matmul_129, strictly_upper_mask_12, ones_12, pairwise_decay_37, unsqueeze_107, unsqueeze_108, pairwise_decay_36, pairwise_decay_38, intra_chunk_attn_12, unsqueeze_106, k_beta_24, k_beta_25, matmul_128, transpose_171, ut_system_12], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.triu, aten.ones, aten.masked_fill, aten.unsqueeze, aten.sub, aten.exp, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_masked_fill_mul_ones_rsqrt_sub_transpose_triu_unsqueeze_view_15.run(buf795, buf790, buf782, buf791, buf797, buf804, 16, 32, 1, stream=raw_stream0)
        del buf790
        del buf795
        # Topologically Sorted Source Nodes: [out_25, mixed_qkv_51, split_12, value_49, transpose_168, value_50, unsqueeze_105, v_beta_24, v_beta_25, new_values_12], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.unsqueeze, aten.mul, aten.linalg_solve_triangular]
        buf799 = torch.ops.aten.linalg_solve_triangular.default(buf797, reinterpret_tensor(buf798, (1, 16, 2, 64, 128), (0, 16384, 8192, 128, 1), 0), upper=False, unitriangular=True)
        assert_tensor_metadata(buf799, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf799, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        # Topologically Sorted Source Nodes: [unsqueeze_106, k_beta_24, k_beta_25, exp_74, unsqueeze_109, decayed_k_beta_12, k_cumdecay_12], Original ATen: [aten.unsqueeze, aten.mul, aten.view, aten.exp, aten.linalg_solve_triangular]
        buf802 = torch.ops.aten.linalg_solve_triangular.default(buf797, buf801, upper=False, unitriangular=True)
        assert_tensor_metadata(buf802, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf802, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        buf805 = reinterpret_tensor(buf797, (1, 16, 64, 128), (131072, 8192, 128, 1), 0); del buf797  # reuse
        # Topologically Sorted Source Nodes: [getitem_306, getitem_307, matmul_130, v_new_24], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_16.run(buf802, buf785, buf799, buf805, 32, 16, 1, stream=raw_stream0)
        buf806 = reinterpret_tensor(buf791, (16, 64, 128), (8192, 128, 1), 0); del buf791  # reuse
        # Topologically Sorted Source Nodes: [matmul_129, intra_chunk_attn_12, getitem_309, matmul_132, getitem_306, matmul_130, v_new_24], Original ATen: [aten.view, aten.mul, aten.select, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_mul_select_sub_view_17.run(buf804, buf805, buf806, 32, 16, 1, stream=raw_stream0)
        buf807 = buf719; del buf719  # reuse
        # Topologically Sorted Source Nodes: [getitem_304, exp_77], Original ATen: [aten.select, aten.exp]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_select_18.run(buf782, buf807, 32, stream=raw_stream0)
        buf811 = buf785; del buf785  # reuse
        # Topologically Sorted Source Nodes: [add_224, inv_norm_25, key_87, key_89, getitem_304, exp_77, chunk_decay_12, getitem_310, mul_354, getitem_303, sub_49, exp_76, unsqueeze_111, key_90, getitem_311, transpose_173, matmul_133, last_recurrent_state_37], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.select, aten.exp, aten.unsqueeze, aten.slice, aten.sub, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_slice_sub_transpose_unsqueeze_view_19.run(buf809, buf805, buf807, buf811, 64, 16, 1, stream=raw_stream0)
        buf812 = reinterpret_tensor(buf805, (16, 64, 128), (8192, 128, 1), 0); del buf805  # reuse
        # Topologically Sorted Source Nodes: [getitem_314, inter_chunk_attn_25, getitem_304, exp_77, chunk_decay_12, getitem_310, mul_354, matmul_133, last_recurrent_state_37], Original ATen: [aten.select, aten.view, aten.exp, aten.unsqueeze, aten.mul, aten.add, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_select_unsqueeze_view_20.run(buf784, buf811, buf812, 32, 16, 1, stream=raw_stream0)
        buf814 = buf726; del buf726  # reuse
        # Topologically Sorted Source Nodes: [getitem_312, getitem_313, matmul_134, v_new_25], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_21.run(buf802, buf811, buf799, buf814, 32, 16, 1, stream=raw_stream0)
        buf815 = reinterpret_tensor(buf716, (16, 64, 128), (8192, 128, 1), 0); del buf716  # reuse
        # Topologically Sorted Source Nodes: [getitem_315, matmul_136, getitem_312, matmul_134, v_new_25], Original ATen: [aten.select, aten.view, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_22.run(buf804, buf814, buf815, 32, 16, 1, stream=raw_stream0)
        assert_size_stride(arg218_1, (2048, 2048), (2048, 1), 'input')
        buf817 = buf737; del buf737  # reuse
        # Topologically Sorted Source Nodes: [z_36], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf775, arg218_1, buf817, 1024, 1, 1, stream=raw_stream0)
        del arg218_1
        assert_size_stride(arg224_1, (128, ), (1, ), 'input')
        buf818 = reinterpret_tensor(buf817, (2048, 128), (128, 1), 0); del buf817  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_84, setitem_28, inter_chunk_attn_24, matmul_132, add_225, setitem_29, inter_chunk_attn_25, matmul_136, add_227, core_attn_out_85, transpose_175, core_attn_out_87, core_attn_out_88, hidden_states_121, pow_54, variance_12, add_229, rsqrt_79, hidden_states_122, to_160, hidden_states_123, z_36, z_37, z_38, to_161, silu_41, hidden_states_124, core_attn_out_89], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_copy_mean_mul_pow_rsqrt_select_silu_transpose_view_zeros_like_24.run(buf818, buf812, buf815, buf786, buf806, arg224_1, 2048, 128, stream=raw_stream0)
        del arg224_1
        assert_size_stride(arg225_1, (2048, 2048), (2048, 1), 'input')
        buf819 = reinterpret_tensor(buf775, (128, 2048), (2048, 1), 0); del buf775  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_84, setitem_28, inter_chunk_attn_24, matmul_132, add_225, setitem_29, inter_chunk_attn_25, matmul_136, add_227, core_attn_out_85, transpose_175, core_attn_out_87, core_attn_out_88, hidden_states_121, pow_54, variance_12, add_229, rsqrt_79, hidden_states_122, to_160, hidden_states_123, z_36, z_37, z_38, to_161, silu_41, hidden_states_124, core_attn_out_89, core_attn_out_90, output_94], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf818, arg225_1, buf819, 1024, 1, 1, stream=raw_stream0)
        del arg225_1
        assert_size_stride(arg226_1, (2048, ), (1, ), 'input')
        buf821 = reinterpret_tensor(buf818, (1, 128, 2048), (262144, 2048, 1), 0); del buf818  # reuse
        # Topologically Sorted Source Nodes: [down_proj_15, hidden_states_119, output_94, hidden_states_125, float_110, pow_55, mean_54, add_231, rsqrt_80, output_95, float_111, add_232, output_96, hidden_states_126], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_31.run(buf767, buf773, buf819, arg226_1, buf821, 128, 2048, stream=raw_stream0)
        del arg226_1
        assert_size_stride(arg227_1, (6144, 2048), (2048, 1), 'input')
        buf822 = buf776; del buf776  # reuse
        # Topologically Sorted Source Nodes: [linear_129], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf821, arg227_1, buf822, 3072, 1, 1, stream=raw_stream0)
        del arg227_1
        assert_size_stride(arg228_1, (6144, 2048), (2048, 1), 'input')
        buf824 = reinterpret_tensor(buf770, (1, 128, 6144), (786432, 6144, 1), 0); del buf770  # reuse
        # Topologically Sorted Source Nodes: [linear_129, silu_42, linear_130, mul_361], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_26.run(buf821, arg228_1, buf822, buf824, 3072, 1, 1, stream=raw_stream0)
        del arg228_1
        assert_size_stride(arg229_1, (2048, 6144), (6144, 1), 'input')
        buf825 = reinterpret_tensor(buf821, (128, 2048), (2048, 1), 0); del buf821  # reuse
        # Topologically Sorted Source Nodes: [linear_129, silu_42, linear_130, mul_361, down_proj_16], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_27.run(buf824, arg229_1, buf825, 1024, 1, 1, stream=raw_stream0)
        del arg229_1
        assert_size_stride(arg230_1, (2048, ), (1, ), 'input')
        buf827 = reinterpret_tensor(buf731, (1, 128, 2048), (262144, 2048, 1), 0); del buf731  # reuse
        # Topologically Sorted Source Nodes: [down_proj_15, hidden_states_119, output_94, hidden_states_125, down_proj_16, hidden_states_127, float_112, pow_56, mean_55, add_234, rsqrt_81, output_97, float_113, add_235, output_98, hidden_states_128], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_32.run(buf767, buf773, buf819, buf825, arg230_1, buf827, 128, 2048, stream=raw_stream0)
        del arg230_1
        assert_size_stride(arg231_1, (6144, 2048), (2048, 1), 'input')
        buf828 = reinterpret_tensor(buf824, (128, 6144), (6144, 1), 0); del buf824  # reuse
        # Topologically Sorted Source Nodes: [mixed_qkv_52], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf827, arg231_1, buf828, 3072, 1, 1, stream=raw_stream0)
        del arg231_1
        assert_size_stride(arg235_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf829 = buf777; del buf777  # reuse
        # Topologically Sorted Source Nodes: [mixed_qkv_52, mixed_qkv_53, conv1d_13, squeeze_13, unsqueeze_112, out_26, out_27], Original ATen: [aten._unsafe_view, aten.transpose, aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_convolution_silu_slice_squeeze_transpose_unsqueeze_2.run(buf828, arg235_1, buf829, 786432, stream=raw_stream0)
        del arg235_1
        buf830 = reinterpret_tensor(buf811, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf811  # reuse
        buf831 = reinterpret_tensor(buf782, (1, 16, 128, 1), (2048, 1, 16, 2048), 0); del buf782  # reuse
        buf841 = reinterpret_tensor(buf802, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf802  # reuse
        # Topologically Sorted Source Nodes: [out_27, mixed_qkv_55, split_13, query_105, transpose_178, query_106, mul_365, sum_27, add_237, inv_norm_26, query_107, query_108], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_3.run(buf829, buf830, buf831, buf841, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg234_1, (16, 2048), (2048, 1), 'input')
        buf832 = buf793; del buf793  # reuse
        # Topologically Sorted Source Nodes: [a_13], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf827, arg234_1, buf832, 8, 1, 1, stream=raw_stream0)
        del arg234_1
        assert_size_stride(arg236_1, (16, ), (1, ), 'input')
        buf833 = buf781; del buf781  # reuse
        # Topologically Sorted Source Nodes: [exp_78, neg_21], Original ATen: [aten.exp, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_neg_5.run(arg236_1, buf833, 16, stream=raw_stream0)
        del arg236_1
        assert_size_stride(arg237_1, (16, ), (1, ), 'input')
        buf834 = buf808; del buf808  # reuse
        # Topologically Sorted Source Nodes: [exp_78, neg_21, a_13, float_115, add_236, softplus_13, g_13, transpose_182, decay_41, cum_decay_13], Original ATen: [aten.exp, aten.neg, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.view, aten.cumsum]
        workspace_13 = workspace_12; del workspace_12  # reuse
        workspace_13.zero_()
        raw_stream0 = get_raw_stream(0)
        triton_spl_fused__to_copy__unsafe_view_add_cumsum_exp_mul_neg_softplus_transpose_view_6.run(buf833, buf832, arg237_1, buf834, workspace_13, 32, 64, stream=raw_stream0)
        del arg237_1
        buf835 = buf800; del buf800  # reuse
        buf852 = reinterpret_tensor(buf794, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf794  # reuse
        buf860 = reinterpret_tensor(buf779, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf779  # reuse
        # Topologically Sorted Source Nodes: [exp_81, exp_80, getitem_323, sub_53, exp_82], Original ATen: [aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_slice_sub_7.run(buf834, buf835, buf852, buf860, 2048, stream=raw_stream0)
        buf836 = reinterpret_tensor(buf799, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf799  # reuse
        # Topologically Sorted Source Nodes: [add_237, inv_norm_26, query_107, query_108, query_110, exp_81, unsqueeze_118, query_111], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_exp_mul_rsqrt_unsqueeze_view_8.run(buf830, buf831, buf835, buf836, 262144, stream=raw_stream0)
        buf837 = reinterpret_tensor(buf830, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf830  # reuse
        # Topologically Sorted Source Nodes: [last_recurrent_state_39], Original ATen: [aten.zeros]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_zeros_9.run(buf837, 262144, stream=raw_stream0)
        buf838 = buf815; del buf815  # reuse
        # Topologically Sorted Source Nodes: [add_237, inv_norm_26, query_107, query_108, query_110, exp_81, unsqueeze_118, query_111, getitem_328, inter_chunk_attn_26, last_recurrent_state_39], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze, aten.select, aten.zeros, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_unsqueeze_view_zeros_10.run(buf836, buf837, buf838, 32, 16, 1, stream=raw_stream0)
        buf839 = reinterpret_tensor(buf784, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf784  # reuse
        buf842 = reinterpret_tensor(buf809, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf809  # reuse
        # Topologically Sorted Source Nodes: [out_27, mixed_qkv_55, split_13, key_92, transpose_179, key_93, mul_367, sum_28, add_238, inv_norm_27, key_94], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_11.run(buf829, buf839, buf842, 2048, 128, stream=raw_stream0)
        buf843 = reinterpret_tensor(buf812, (32, 64, 64), (4096, 64, 1), 0); del buf812  # reuse
        # Topologically Sorted Source Nodes: [add_237, inv_norm_26, query_107, query_108, query_110, matmul_139, add_238, inv_norm_27, key_94, key_96, transpose_184], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_mul_rsqrt_transpose_view_12.run(buf841, buf842, buf843, 16, 32, 1, stream=raw_stream0)
        assert_size_stride(arg233_1, (16, 2048), (2048, 1), 'input')
        buf845 = buf832; del buf832  # reuse
        # Topologically Sorted Source Nodes: [b_13], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf827, arg233_1, buf845, 8, 1, 1, stream=raw_stream0)
        del arg233_1
        buf846 = reinterpret_tensor(buf835, (1, 16, 128), (2048, 128, 1), 0); del buf835  # reuse
        # Topologically Sorted Source Nodes: [b_13, beta_39, transpose_181, beta_40], Original ATen: [aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_sigmoid_transpose_13.run(buf845, buf846, 16, 128, stream=raw_stream0)
        buf847 = buf841; del buf841  # reuse
        buf853 = reinterpret_tensor(buf839, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf839  # reuse
        buf861 = buf801; del buf801  # reuse
        buf850 = buf798; del buf798  # reuse
        # Topologically Sorted Source Nodes: [out_27, mixed_qkv_55, split_13, add_238, inv_norm_27, key_94, key_96, unsqueeze_114, k_beta_26, k_beta_27, value_53, transpose_180, value_54, unsqueeze_113, v_beta_26, exp_80, unsqueeze_117, decayed_k_beta_13, getitem_323, sub_53, exp_82, unsqueeze_119, key_97], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.view, aten.unsqueeze, aten._to_copy, aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_exp_mul_rsqrt_silu_slice_split_with_sizes_sub_transpose_unsqueeze_view_14.run(buf842, buf846, buf852, buf860, buf829, buf847, buf853, buf861, buf850, 262144, stream=raw_stream0)
        buf849 = reinterpret_tensor(buf806, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf806  # reuse
        buf856 = reinterpret_tensor(buf786, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf786  # reuse
        # Topologically Sorted Source Nodes: [add_238, inv_norm_27, key_94, key_96, matmul_139, strictly_upper_mask_13, ones_13, pairwise_decay_40, unsqueeze_115, unsqueeze_116, pairwise_decay_39, pairwise_decay_41, intra_chunk_attn_13, unsqueeze_114, k_beta_26, k_beta_27, matmul_138, transpose_183, ut_system_13], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.triu, aten.ones, aten.masked_fill, aten.unsqueeze, aten.sub, aten.exp, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_masked_fill_mul_ones_rsqrt_sub_transpose_triu_unsqueeze_view_15.run(buf847, buf842, buf834, buf843, buf849, buf856, 16, 32, 1, stream=raw_stream0)
        del buf842
        del buf847
        # Topologically Sorted Source Nodes: [out_27, mixed_qkv_55, split_13, value_53, transpose_180, value_54, unsqueeze_113, v_beta_26, v_beta_27, new_values_13], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.unsqueeze, aten.mul, aten.linalg_solve_triangular]
        buf851 = torch.ops.aten.linalg_solve_triangular.default(buf849, reinterpret_tensor(buf850, (1, 16, 2, 64, 128), (0, 16384, 8192, 128, 1), 0), upper=False, unitriangular=True)
        assert_tensor_metadata(buf851, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf851, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        # Topologically Sorted Source Nodes: [unsqueeze_114, k_beta_26, k_beta_27, exp_80, unsqueeze_117, decayed_k_beta_13, k_cumdecay_13], Original ATen: [aten.unsqueeze, aten.mul, aten.view, aten.exp, aten.linalg_solve_triangular]
        buf854 = torch.ops.aten.linalg_solve_triangular.default(buf849, buf853, upper=False, unitriangular=True)
        assert_tensor_metadata(buf854, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf854, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        buf857 = reinterpret_tensor(buf849, (1, 16, 64, 128), (131072, 8192, 128, 1), 0); del buf849  # reuse
        # Topologically Sorted Source Nodes: [getitem_326, getitem_327, matmul_140, v_new_26], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_16.run(buf854, buf837, buf851, buf857, 32, 16, 1, stream=raw_stream0)
        buf858 = reinterpret_tensor(buf843, (16, 64, 128), (8192, 128, 1), 0); del buf843  # reuse
        # Topologically Sorted Source Nodes: [matmul_139, intra_chunk_attn_13, getitem_329, matmul_142, getitem_326, matmul_140, v_new_26], Original ATen: [aten.view, aten.mul, aten.select, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_mul_select_sub_view_17.run(buf856, buf857, buf858, 32, 16, 1, stream=raw_stream0)
        buf859 = buf807; del buf807  # reuse
        # Topologically Sorted Source Nodes: [getitem_324, exp_83], Original ATen: [aten.select, aten.exp]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_select_18.run(buf834, buf859, 32, stream=raw_stream0)
        buf863 = buf837; del buf837  # reuse
        # Topologically Sorted Source Nodes: [add_238, inv_norm_27, key_94, key_96, getitem_324, exp_83, chunk_decay_13, getitem_330, mul_377, getitem_323, sub_53, exp_82, unsqueeze_119, key_97, getitem_331, transpose_185, matmul_143, last_recurrent_state_40], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.select, aten.exp, aten.unsqueeze, aten.slice, aten.sub, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_slice_sub_transpose_unsqueeze_view_19.run(buf861, buf857, buf859, buf863, 64, 16, 1, stream=raw_stream0)
        buf864 = reinterpret_tensor(buf857, (16, 64, 128), (8192, 128, 1), 0); del buf857  # reuse
        # Topologically Sorted Source Nodes: [getitem_334, inter_chunk_attn_27, getitem_324, exp_83, chunk_decay_13, getitem_330, mul_377, matmul_143, last_recurrent_state_40], Original ATen: [aten.select, aten.view, aten.exp, aten.unsqueeze, aten.mul, aten.add, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_select_unsqueeze_view_20.run(buf836, buf863, buf864, 32, 16, 1, stream=raw_stream0)
        buf866 = buf814; del buf814  # reuse
        # Topologically Sorted Source Nodes: [getitem_332, getitem_333, matmul_144, v_new_27], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_21.run(buf854, buf863, buf851, buf866, 32, 16, 1, stream=raw_stream0)
        buf867 = reinterpret_tensor(buf804, (16, 64, 128), (8192, 128, 1), 0); del buf804  # reuse
        # Topologically Sorted Source Nodes: [getitem_335, matmul_146, getitem_332, matmul_144, v_new_27], Original ATen: [aten.select, aten.view, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_22.run(buf856, buf866, buf867, 32, 16, 1, stream=raw_stream0)
        assert_size_stride(arg232_1, (2048, 2048), (2048, 1), 'input')
        buf869 = buf685; del buf685  # reuse
        # Topologically Sorted Source Nodes: [z_39], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf827, arg232_1, buf869, 1024, 1, 1, stream=raw_stream0)
        del arg232_1
        assert_size_stride(arg238_1, (128, ), (1, ), 'input')
        buf870 = reinterpret_tensor(buf869, (2048, 128), (128, 1), 0); del buf869  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_91, setitem_30, inter_chunk_attn_26, matmul_142, add_239, setitem_31, inter_chunk_attn_27, matmul_146, add_241, core_attn_out_92, transpose_187, core_attn_out_94, core_attn_out_95, hidden_states_129, pow_57, variance_13, add_243, rsqrt_84, hidden_states_130, to_172, hidden_states_131, z_39, z_40, z_41, to_173, silu_44, hidden_states_132, core_attn_out_96], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_copy_mean_mul_pow_rsqrt_select_silu_transpose_view_zeros_like_24.run(buf870, buf864, buf867, buf838, buf858, arg238_1, 2048, 128, stream=raw_stream0)
        del arg238_1
        assert_size_stride(arg239_1, (2048, 2048), (2048, 1), 'input')
        buf871 = reinterpret_tensor(buf827, (128, 2048), (2048, 1), 0); del buf827  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_91, setitem_30, inter_chunk_attn_26, matmul_142, add_239, setitem_31, inter_chunk_attn_27, matmul_146, add_241, core_attn_out_92, transpose_187, core_attn_out_94, core_attn_out_95, hidden_states_129, pow_57, variance_13, add_243, rsqrt_84, hidden_states_130, to_172, hidden_states_131, z_39, z_40, z_41, to_173, silu_44, hidden_states_132, core_attn_out_96, core_attn_out_97, output_99], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf870, arg239_1, buf871, 1024, 1, 1, stream=raw_stream0)
        del arg239_1
        assert_size_stride(arg240_1, (2048, ), (1, ), 'input')
        buf872 = buf767; del buf767  # reuse
        buf874 = reinterpret_tensor(buf870, (1, 128, 2048), (262144, 2048, 1), 0); del buf870  # reuse
        # Topologically Sorted Source Nodes: [down_proj_15, hidden_states_119, output_94, hidden_states_125, down_proj_16, hidden_states_127, output_99, hidden_states_133, float_116, pow_58, mean_57, add_245, rsqrt_85, output_100, float_117, add_246, output_101, hidden_states_134], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_50.run(buf872, buf773, buf819, buf825, buf871, arg240_1, buf874, 128, 2048, stream=raw_stream0)
        del arg240_1
        assert_size_stride(arg241_1, (6144, 2048), (2048, 1), 'input')
        buf875 = buf828; del buf828  # reuse
        # Topologically Sorted Source Nodes: [float_116, pow_58, mean_57, add_245, rsqrt_85, output_100, float_117, add_246, output_101, hidden_states_134, linear_137], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf874, arg241_1, buf875, 3072, 1, 1, stream=raw_stream0)
        del arg241_1
        assert_size_stride(arg242_1, (6144, 2048), (2048, 1), 'input')
        buf877 = reinterpret_tensor(buf822, (1, 128, 6144), (786432, 6144, 1), 0); del buf822  # reuse
        # Topologically Sorted Source Nodes: [linear_137, silu_45, linear_138, mul_384], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_26.run(buf874, arg242_1, buf875, buf877, 3072, 1, 1, stream=raw_stream0)
        del arg242_1
        assert_size_stride(arg243_1, (2048, 6144), (6144, 1), 'input')
        buf878 = reinterpret_tensor(buf874, (128, 2048), (2048, 1), 0); del buf874  # reuse
        # Topologically Sorted Source Nodes: [linear_137, silu_45, linear_138, mul_384, down_proj_17], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_27.run(buf877, arg243_1, buf878, 1024, 1, 1, stream=raw_stream0)
        del arg243_1
        assert_size_stride(arg244_1, (2048, ), (1, ), 'input')
        buf880 = reinterpret_tensor(buf871, (1, 128, 2048), (262144, 2048, 1), 0); del buf871  # reuse
        # Topologically Sorted Source Nodes: [down_proj_17, hidden_states_135, float_118, pow_59, mean_58, add_248, rsqrt_86, output_102, float_119, add_249, output_103, hidden_states_136], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_30.run(buf872, buf878, arg244_1, buf880, 128, 2048, stream=raw_stream0)
        del arg244_1
        assert_size_stride(arg245_1, (6144, 2048), (2048, 1), 'input')
        buf881 = reinterpret_tensor(buf877, (128, 6144), (6144, 1), 0); del buf877  # reuse
        # Topologically Sorted Source Nodes: [down_proj_17, hidden_states_135, float_118, pow_59, mean_58, add_248, rsqrt_86, output_102, float_119, add_249, output_103, hidden_states_136, mixed_qkv_56], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf880, arg245_1, buf881, 3072, 1, 1, stream=raw_stream0)
        del arg245_1
        assert_size_stride(arg249_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf882 = buf829; del buf829  # reuse
        # Topologically Sorted Source Nodes: [mixed_qkv_56, mixed_qkv_57, conv1d_14, squeeze_14, unsqueeze_120, out_28, out_29], Original ATen: [aten._unsafe_view, aten.transpose, aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_convolution_silu_slice_squeeze_transpose_unsqueeze_2.run(buf881, arg249_1, buf882, 786432, stream=raw_stream0)
        del arg249_1
        buf883 = reinterpret_tensor(buf863, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf863  # reuse
        buf884 = reinterpret_tensor(buf834, (1, 16, 128, 1), (2048, 1, 16, 2048), 0); del buf834  # reuse
        buf894 = reinterpret_tensor(buf854, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf854  # reuse
        # Topologically Sorted Source Nodes: [out_29, mixed_qkv_59, split_14, query_113, transpose_190, query_114, mul_388, sum_29, add_251, inv_norm_28, query_115, query_116], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_3.run(buf882, buf883, buf884, buf894, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg248_1, (16, 2048), (2048, 1), 'input')
        buf885 = buf845; del buf845  # reuse
        # Topologically Sorted Source Nodes: [a_14], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf880, arg248_1, buf885, 8, 1, 1, stream=raw_stream0)
        del arg248_1
        assert_size_stride(arg250_1, (16, ), (1, ), 'input')
        buf886 = buf833; del buf833  # reuse
        # Topologically Sorted Source Nodes: [exp_84, neg_22], Original ATen: [aten.exp, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_neg_5.run(arg250_1, buf886, 16, stream=raw_stream0)
        del arg250_1
        assert_size_stride(arg251_1, (16, ), (1, ), 'input')
        buf887 = buf860; del buf860  # reuse
        # Topologically Sorted Source Nodes: [exp_84, neg_22, a_14, float_121, add_250, softplus_14, g_14, transpose_194, decay_44, cum_decay_14], Original ATen: [aten.exp, aten.neg, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.view, aten.cumsum]
        workspace_14 = workspace_13; del workspace_13  # reuse
        workspace_14.zero_()
        raw_stream0 = get_raw_stream(0)
        triton_spl_fused__to_copy__unsafe_view_add_cumsum_exp_mul_neg_softplus_transpose_view_6.run(buf886, buf885, arg251_1, buf887, workspace_14, 32, 64, stream=raw_stream0)
        del arg251_1
        buf888 = buf852; del buf852  # reuse
        buf905 = reinterpret_tensor(buf846, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf846  # reuse
        buf913 = reinterpret_tensor(buf831, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf831  # reuse
        # Topologically Sorted Source Nodes: [exp_87, exp_86, getitem_343, sub_57, exp_88], Original ATen: [aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_slice_sub_7.run(buf887, buf888, buf905, buf913, 2048, stream=raw_stream0)
        buf889 = reinterpret_tensor(buf851, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf851  # reuse
        # Topologically Sorted Source Nodes: [add_251, inv_norm_28, query_115, query_116, query_118, exp_87, unsqueeze_126, query_119], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_exp_mul_rsqrt_unsqueeze_view_8.run(buf883, buf884, buf888, buf889, 262144, stream=raw_stream0)
        buf890 = reinterpret_tensor(buf883, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf883  # reuse
        # Topologically Sorted Source Nodes: [last_recurrent_state_42], Original ATen: [aten.zeros]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_zeros_9.run(buf890, 262144, stream=raw_stream0)
        buf891 = buf867; del buf867  # reuse
        # Topologically Sorted Source Nodes: [add_251, inv_norm_28, query_115, query_116, query_118, exp_87, unsqueeze_126, query_119, getitem_348, inter_chunk_attn_28, last_recurrent_state_42], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze, aten.select, aten.zeros, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_unsqueeze_view_zeros_10.run(buf889, buf890, buf891, 32, 16, 1, stream=raw_stream0)
        buf892 = reinterpret_tensor(buf836, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf836  # reuse
        buf895 = reinterpret_tensor(buf861, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf861  # reuse
        # Topologically Sorted Source Nodes: [out_29, mixed_qkv_59, split_14, key_99, transpose_191, key_100, mul_390, sum_30, add_252, inv_norm_29, key_101], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_11.run(buf882, buf892, buf895, 2048, 128, stream=raw_stream0)
        buf896 = reinterpret_tensor(buf864, (32, 64, 64), (4096, 64, 1), 0); del buf864  # reuse
        # Topologically Sorted Source Nodes: [add_251, inv_norm_28, query_115, query_116, query_118, matmul_149, add_252, inv_norm_29, key_101, key_103, transpose_196], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_mul_rsqrt_transpose_view_12.run(buf894, buf895, buf896, 16, 32, 1, stream=raw_stream0)
        assert_size_stride(arg247_1, (16, 2048), (2048, 1), 'input')
        buf898 = buf885; del buf885  # reuse
        # Topologically Sorted Source Nodes: [b_14], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf880, arg247_1, buf898, 8, 1, 1, stream=raw_stream0)
        del arg247_1
        buf899 = reinterpret_tensor(buf888, (1, 16, 128), (2048, 128, 1), 0); del buf888  # reuse
        # Topologically Sorted Source Nodes: [b_14, beta_42, transpose_193, beta_43], Original ATen: [aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_sigmoid_transpose_13.run(buf898, buf899, 16, 128, stream=raw_stream0)
        buf900 = buf894; del buf894  # reuse
        buf906 = reinterpret_tensor(buf892, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf892  # reuse
        buf914 = buf853; del buf853  # reuse
        buf903 = buf850; del buf850  # reuse
        # Topologically Sorted Source Nodes: [out_29, mixed_qkv_59, split_14, add_252, inv_norm_29, key_101, key_103, unsqueeze_122, k_beta_28, k_beta_29, value_57, transpose_192, value_58, unsqueeze_121, v_beta_28, exp_86, unsqueeze_125, decayed_k_beta_14, getitem_343, sub_57, exp_88, unsqueeze_127, key_104], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.view, aten.unsqueeze, aten._to_copy, aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_exp_mul_rsqrt_silu_slice_split_with_sizes_sub_transpose_unsqueeze_view_14.run(buf895, buf899, buf905, buf913, buf882, buf900, buf906, buf914, buf903, 262144, stream=raw_stream0)
        buf902 = reinterpret_tensor(buf858, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf858  # reuse
        buf909 = reinterpret_tensor(buf838, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf838  # reuse
        # Topologically Sorted Source Nodes: [add_252, inv_norm_29, key_101, key_103, matmul_149, strictly_upper_mask_14, ones_14, pairwise_decay_43, unsqueeze_123, unsqueeze_124, pairwise_decay_42, pairwise_decay_44, intra_chunk_attn_14, unsqueeze_122, k_beta_28, k_beta_29, matmul_148, transpose_195, ut_system_14], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.triu, aten.ones, aten.masked_fill, aten.unsqueeze, aten.sub, aten.exp, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_masked_fill_mul_ones_rsqrt_sub_transpose_triu_unsqueeze_view_15.run(buf900, buf895, buf887, buf896, buf902, buf909, 16, 32, 1, stream=raw_stream0)
        del buf895
        del buf900
        # Topologically Sorted Source Nodes: [out_29, mixed_qkv_59, split_14, value_57, transpose_192, value_58, unsqueeze_121, v_beta_28, v_beta_29, new_values_14], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.unsqueeze, aten.mul, aten.linalg_solve_triangular]
        buf904 = torch.ops.aten.linalg_solve_triangular.default(buf902, reinterpret_tensor(buf903, (1, 16, 2, 64, 128), (0, 16384, 8192, 128, 1), 0), upper=False, unitriangular=True)
        assert_tensor_metadata(buf904, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf904, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        # Topologically Sorted Source Nodes: [unsqueeze_122, k_beta_28, k_beta_29, exp_86, unsqueeze_125, decayed_k_beta_14, k_cumdecay_14], Original ATen: [aten.unsqueeze, aten.mul, aten.view, aten.exp, aten.linalg_solve_triangular]
        buf907 = torch.ops.aten.linalg_solve_triangular.default(buf902, buf906, upper=False, unitriangular=True)
        assert_tensor_metadata(buf907, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf907, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        buf910 = reinterpret_tensor(buf902, (1, 16, 64, 128), (131072, 8192, 128, 1), 0); del buf902  # reuse
        # Topologically Sorted Source Nodes: [getitem_346, getitem_347, matmul_150, v_new_28], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_16.run(buf907, buf890, buf904, buf910, 32, 16, 1, stream=raw_stream0)
        buf911 = reinterpret_tensor(buf896, (16, 64, 128), (8192, 128, 1), 0); del buf896  # reuse
        # Topologically Sorted Source Nodes: [matmul_149, intra_chunk_attn_14, getitem_349, matmul_152, getitem_346, matmul_150, v_new_28], Original ATen: [aten.view, aten.mul, aten.select, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_mul_select_sub_view_17.run(buf909, buf910, buf911, 32, 16, 1, stream=raw_stream0)
        buf912 = buf859; del buf859  # reuse
        # Topologically Sorted Source Nodes: [getitem_344, exp_89], Original ATen: [aten.select, aten.exp]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_select_18.run(buf887, buf912, 32, stream=raw_stream0)
        buf916 = buf890; del buf890  # reuse
        # Topologically Sorted Source Nodes: [add_252, inv_norm_29, key_101, key_103, getitem_344, exp_89, chunk_decay_14, getitem_350, mul_400, getitem_343, sub_57, exp_88, unsqueeze_127, key_104, getitem_351, transpose_197, matmul_153, last_recurrent_state_43], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.select, aten.exp, aten.unsqueeze, aten.slice, aten.sub, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_slice_sub_transpose_unsqueeze_view_19.run(buf914, buf910, buf912, buf916, 64, 16, 1, stream=raw_stream0)
        buf917 = reinterpret_tensor(buf910, (16, 64, 128), (8192, 128, 1), 0); del buf910  # reuse
        # Topologically Sorted Source Nodes: [getitem_354, inter_chunk_attn_29, getitem_344, exp_89, chunk_decay_14, getitem_350, mul_400, matmul_153, last_recurrent_state_43], Original ATen: [aten.select, aten.view, aten.exp, aten.unsqueeze, aten.mul, aten.add, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_select_unsqueeze_view_20.run(buf889, buf916, buf917, 32, 16, 1, stream=raw_stream0)
        buf919 = buf866; del buf866  # reuse
        # Topologically Sorted Source Nodes: [getitem_352, getitem_353, matmul_154, v_new_29], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_21.run(buf907, buf916, buf904, buf919, 32, 16, 1, stream=raw_stream0)
        buf920 = reinterpret_tensor(buf856, (16, 64, 128), (8192, 128, 1), 0); del buf856  # reuse
        # Topologically Sorted Source Nodes: [getitem_355, matmul_156, getitem_352, matmul_154, v_new_29], Original ATen: [aten.select, aten.view, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_22.run(buf909, buf919, buf920, 32, 16, 1, stream=raw_stream0)
        assert_size_stride(arg246_1, (2048, 2048), (2048, 1), 'input')
        buf922 = buf825; del buf825  # reuse
        # Topologically Sorted Source Nodes: [z_42], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf880, arg246_1, buf922, 1024, 1, 1, stream=raw_stream0)
        del arg246_1
        assert_size_stride(arg252_1, (128, ), (1, ), 'input')
        buf923 = reinterpret_tensor(buf922, (2048, 128), (128, 1), 0); del buf922  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_98, setitem_32, inter_chunk_attn_28, matmul_152, add_253, setitem_33, inter_chunk_attn_29, matmul_156, add_255, core_attn_out_99, transpose_199, core_attn_out_101, core_attn_out_102, hidden_states_137, pow_60, variance_14, add_257, rsqrt_89, hidden_states_138, to_184, hidden_states_139, z_42, z_43, z_44, to_185, silu_47, hidden_states_140, core_attn_out_103], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_copy_mean_mul_pow_rsqrt_select_silu_transpose_view_zeros_like_24.run(buf923, buf917, buf920, buf891, buf911, arg252_1, 2048, 128, stream=raw_stream0)
        del arg252_1
        assert_size_stride(arg253_1, (2048, 2048), (2048, 1), 'input')
        buf924 = reinterpret_tensor(buf880, (128, 2048), (2048, 1), 0); del buf880  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_98, setitem_32, inter_chunk_attn_28, matmul_152, add_253, setitem_33, inter_chunk_attn_29, matmul_156, add_255, core_attn_out_99, transpose_199, core_attn_out_101, core_attn_out_102, hidden_states_137, pow_60, variance_14, add_257, rsqrt_89, hidden_states_138, to_184, hidden_states_139, z_42, z_43, z_44, to_185, silu_47, hidden_states_140, core_attn_out_103, core_attn_out_104, output_104], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf923, arg253_1, buf924, 1024, 1, 1, stream=raw_stream0)
        del arg253_1
        assert_size_stride(arg254_1, (2048, ), (1, ), 'input')
        buf926 = reinterpret_tensor(buf923, (1, 128, 2048), (262144, 2048, 1), 0); del buf923  # reuse
        # Topologically Sorted Source Nodes: [down_proj_17, hidden_states_135, output_104, hidden_states_141, float_122, pow_61, mean_60, add_259, rsqrt_90, output_105, float_123, add_260, output_106, hidden_states_142], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_31.run(buf872, buf878, buf924, arg254_1, buf926, 128, 2048, stream=raw_stream0)
        del arg254_1
        assert_size_stride(arg255_1, (6144, 2048), (2048, 1), 'input')
        buf927 = buf881; del buf881  # reuse
        # Topologically Sorted Source Nodes: [linear_145], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf926, arg255_1, buf927, 3072, 1, 1, stream=raw_stream0)
        del arg255_1
        assert_size_stride(arg256_1, (6144, 2048), (2048, 1), 'input')
        buf929 = reinterpret_tensor(buf875, (1, 128, 6144), (786432, 6144, 1), 0); del buf875  # reuse
        # Topologically Sorted Source Nodes: [linear_145, silu_48, linear_146, mul_407], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_26.run(buf926, arg256_1, buf927, buf929, 3072, 1, 1, stream=raw_stream0)
        del arg256_1
        assert_size_stride(arg257_1, (2048, 6144), (6144, 1), 'input')
        buf930 = reinterpret_tensor(buf926, (128, 2048), (2048, 1), 0); del buf926  # reuse
        # Topologically Sorted Source Nodes: [linear_145, silu_48, linear_146, mul_407, down_proj_18], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_27.run(buf929, arg257_1, buf930, 1024, 1, 1, stream=raw_stream0)
        del arg257_1
        assert_size_stride(arg258_1, (2048, ), (1, ), 'input')
        buf932 = reinterpret_tensor(buf819, (1, 128, 2048), (262144, 2048, 1), 0); del buf819  # reuse
        # Topologically Sorted Source Nodes: [down_proj_17, hidden_states_135, output_104, hidden_states_141, down_proj_18, hidden_states_143, float_124, pow_62, mean_61, add_262, rsqrt_91, output_107, float_125, add_263, output_108, hidden_states_144], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_32.run(buf872, buf878, buf924, buf930, arg258_1, buf932, 128, 2048, stream=raw_stream0)
        del arg258_1
        assert_size_stride(arg259_1, (4096, 2048), (2048, 1), 'input')
        buf933 = buf740; del buf740  # reuse
        # Topologically Sorted Source Nodes: [linear_148], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_33.run(buf932, arg259_1, buf933, 2048, 1, 1, stream=raw_stream0)
        del arg259_1
        buf934 = buf741; del buf741  # reuse
        # Topologically Sorted Source Nodes: [linear_148, view_16, chunk_4, float_126, pow_63, mean_62], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_mean_pow_split_view_34.run(buf933, buf934, 1024, 256, stream=raw_stream0)
        assert_size_stride(arg260_1, (256, ), (1, ), 'input')
        buf937 = reinterpret_tensor(buf761, (1, 8, 128, 64), (65536, 8192, 64, 1), 0); del buf761  # reuse
        buf935 = reinterpret_tensor(buf937, (1, 8, 128, 32), (65536, 8192, 64, 1), 0)  # alias
        buf936 = reinterpret_tensor(buf937, (1, 8, 128, 32), (65536, 8192, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_148, view_16, chunk_4, float_126, pow_63, mean_62, add_264, rsqrt_92, output_109, float_127, add_265, output_110, type_as_47, query_states_9, q_rot_4, x2_8, neg_23, x1_8, cat_18], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_36.run(buf933, buf934, arg260_1, buf935, buf936, 32768, stream=raw_stream0)
        buf940 = reinterpret_tensor(buf773, (1, 8, 128, 256), (262144, 32768, 256, 1), 0); del buf773  # reuse
        buf938 = reinterpret_tensor(buf940, (1, 8, 128, 64), (262144, 32768, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, linear_148, view_16, chunk_4, float_126, pow_63, mean_62, add_264, rsqrt_92, output_109, float_127, add_265, output_110, type_as_47, query_states_9, q_rot_4, cos_8, mul_414, sin_8, mul_415, q_embed_8], Original ATen: [aten.select, aten.cat, aten._to_copy, aten._unsafe_view, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_37.run(buf933, buf934, arg260_1, buf161, buf937, buf165, buf938, 65536, stream=raw_stream0)
        del buf935
        del buf936
        buf939 = reinterpret_tensor(buf940, (1, 8, 128, 192), (262144, 32768, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, linear_148, view_16, chunk_4, float_126, pow_63, mean_62, add_264, rsqrt_92, output_109, float_127, add_265, output_110, type_as_47, query_states_9, q_rot_4, cos_8, mul_414, sin_8, mul_415, q_embed_8, q_pass_4, q_embed_9], Original ATen: [aten.select, aten.cat, aten._to_copy, aten._unsafe_view, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_38.run(buf933, buf934, arg260_1, buf939, 196608, stream=raw_stream0)
        del arg260_1
        assert_size_stride(arg261_1, (512, 2048), (2048, 1), 'input')
        del buf938
        del buf939
        buf941 = reinterpret_tensor(buf937, (128, 512), (512, 1), 0); del buf937  # reuse
        # Topologically Sorted Source Nodes: [linear_149], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_39.run(buf932, arg261_1, buf941, 256, 1, 1, stream=raw_stream0)
        del arg261_1
        buf942 = buf749; del buf749  # reuse
        # Topologically Sorted Source Nodes: [linear_149, view_18, float_128, pow_64, mean_63], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_mean_pow_view_40.run(buf941, buf942, 256, 256, stream=raw_stream0)
        assert_size_stride(arg262_1, (256, ), (1, ), 'input')
        buf945 = buf752; del buf752  # reuse
        buf943 = reinterpret_tensor(buf945, (1, 2, 128, 32), (16384, 8192, 64, 1), 0)  # alias
        buf944 = reinterpret_tensor(buf945, (1, 2, 128, 32), (16384, 8192, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_149, view_18, float_128, pow_64, mean_63, add_266, rsqrt_93, output_111, float_129, add_267, output_112, type_as_48, key_states_8, k_rot_4, x2_9, neg_24, x1_9, cat_19], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_41.run(buf941, buf942, arg262_1, buf943, buf944, 8192, stream=raw_stream0)
        buf948 = reinterpret_tensor(buf748, (1, 2, 128, 256), (65536, 32768, 256, 1), 0); del buf748  # reuse
        buf946 = reinterpret_tensor(buf948, (1, 2, 128, 64), (65536, 32768, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, cos_8, sin_8, linear_149, view_18, float_128, pow_64, mean_63, add_266, rsqrt_93, output_111, float_129, add_267, output_112, type_as_48, key_states_8, k_rot_4, mul_416, mul_417, k_embed_8], Original ATen: [aten.select, aten.cat, aten._to_copy, aten.unsqueeze, aten._unsafe_view, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_42.run(buf941, buf942, arg262_1, buf161, buf945, buf165, buf946, 16384, stream=raw_stream0)
        del buf943
        del buf944
        buf947 = reinterpret_tensor(buf948, (1, 2, 128, 192), (65536, 32768, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, cos_8, sin_8, linear_149, view_18, float_128, pow_64, mean_63, add_266, rsqrt_93, output_111, float_129, add_267, output_112, type_as_48, key_states_8, k_rot_4, mul_416, mul_417, k_embed_8, k_pass_4, k_embed_9], Original ATen: [aten.select, aten.cat, aten._to_copy, aten.unsqueeze, aten._unsafe_view, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_43.run(buf941, buf942, arg262_1, buf947, 49152, stream=raw_stream0)
        del arg262_1
        buf949 = reinterpret_tensor(buf747, (1, 2, 4, 128, 256), (262144, 131072, 32768, 256, 1), 0); del buf747  # reuse
        # Topologically Sorted Source Nodes: [getitem_369, hidden_states_145, key_states_9], Original ATen: [aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_clone_expand_unsqueeze_44.run(buf948, buf949, 262144, stream=raw_stream0)
        del buf946
        del buf947
        buf950 = reinterpret_tensor(buf762, (8, 128, 128), (16384, 128, 1), 0); del buf762  # reuse
        # Topologically Sorted Source Nodes: [matmul_158, getitem_369, hidden_states_145, key_states_9, transpose_203], Original ATen: [aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_45.run(buf940, buf949, buf950, 64, 8, 1, stream=raw_stream0)
        buf952 = reinterpret_tensor(buf920, (1, 8, 128, 128), (131072, 16384, 128, 1), 0); del buf920  # reuse
        buf955 = reinterpret_tensor(buf757, (1, 8, 128, 128), (131072, 16384, 128, 1), 0); del buf757  # reuse
        # Topologically Sorted Source Nodes: [mask, full, getitem, matmul_158, attn_weights_16, attn_weights_17, softmax_4, attn_weights_18], Original ATen: [aten.triu, aten.full, aten.unsqueeze, aten.view, aten.mul, aten.add, aten._to_copy, aten._softmax]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__softmax__to_copy_add_full_mul_triu_unsqueeze_view_46.run(buf950, buf952, buf955, 1024, 128, stream=raw_stream0)
        assert_size_stride(arg263_1, (512, 2048), (2048, 1), 'input')
        buf954 = reinterpret_tensor(buf948, (128, 512), (512, 1), 0); del buf948  # reuse
        # Topologically Sorted Source Nodes: [linear_150], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_39.run(buf932, arg263_1, buf954, 256, 1, 1, stream=raw_stream0)
        del arg263_1
        buf956 = reinterpret_tensor(buf932, (1, 2, 4, 128, 256), (262144, 131072, 32768, 256, 1), 0); del buf932  # reuse
        # Topologically Sorted Source Nodes: [linear_150, view_19, value_states_8, getitem_370, hidden_states_146, value_states_9], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_clone_expand_transpose_unsqueeze_view_47.run(buf954, buf956, 262144, stream=raw_stream0)
        buf957 = reinterpret_tensor(buf949, (8, 128, 256), (32768, 256, 1), 0); del buf949  # reuse
        # Topologically Sorted Source Nodes: [softmax_4, attn_weights_18, attn_output_20, linear_150, view_19, value_states_8, getitem_370, hidden_states_146, value_states_9], Original ATen: [aten._softmax, aten._to_copy, aten.view, aten._unsafe_view, aten.transpose, aten.unsqueeze, aten.expand, aten.clone, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__softmax__to_copy__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_48.run(buf955, buf956, buf957, 128, 8, 1, stream=raw_stream0)
        buf958 = reinterpret_tensor(buf956, (1, 128, 2048), (262144, 2048, 1), 0); del buf956  # reuse
        # Topologically Sorted Source Nodes: [linear_148, view_16, chunk_4, attn_output_20, transpose_204, attn_output_21, reshape_214, gate_9, sigmoid_19, attn_output_23], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten.transpose, aten.clone, aten.sigmoid, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_clone_mul_sigmoid_split_transpose_view_49.run(buf957, buf933, buf958, 262144, stream=raw_stream0)
        assert_size_stride(arg264_1, (2048, 2048), (2048, 1), 'input')
        buf959 = reinterpret_tensor(buf957, (128, 2048), (2048, 1), 0); del buf957  # reuse
        # Topologically Sorted Source Nodes: [linear_148, view_16, chunk_4, attn_output_20, transpose_204, attn_output_21, reshape_214, gate_9, sigmoid_19, attn_output_23, attn_output_24], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten.transpose, aten.clone, aten.sigmoid, aten.mul, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf958, arg264_1, buf959, 1024, 1, 1, stream=raw_stream0)
        del arg264_1
        assert_size_stride(arg265_1, (2048, ), (1, ), 'input')
        buf960 = buf872; del buf872  # reuse
        buf962 = buf958; del buf958  # reuse
        # Topologically Sorted Source Nodes: [down_proj_17, hidden_states_135, output_104, hidden_states_141, down_proj_18, hidden_states_143, attn_output_24, hidden_states_147, float_130, pow_65, mean_64, add_272, rsqrt_94, output_113, float_131, add_273, output_114, hidden_states_148], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_50.run(buf960, buf878, buf924, buf930, buf959, arg265_1, buf962, 128, 2048, stream=raw_stream0)
        del arg265_1
        assert_size_stride(arg266_1, (6144, 2048), (2048, 1), 'input')
        buf963 = reinterpret_tensor(buf929, (128, 6144), (6144, 1), 0); del buf929  # reuse
        # Topologically Sorted Source Nodes: [float_130, pow_65, mean_64, add_272, rsqrt_94, output_113, float_131, add_273, output_114, hidden_states_148, linear_152], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf962, arg266_1, buf963, 3072, 1, 1, stream=raw_stream0)
        del arg266_1
        assert_size_stride(arg267_1, (6144, 2048), (2048, 1), 'input')
        buf965 = reinterpret_tensor(buf927, (1, 128, 6144), (786432, 6144, 1), 0); del buf927  # reuse
        # Topologically Sorted Source Nodes: [linear_152, silu_49, linear_153, mul_422], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_26.run(buf962, arg267_1, buf963, buf965, 3072, 1, 1, stream=raw_stream0)
        del arg267_1
        assert_size_stride(arg268_1, (2048, 6144), (6144, 1), 'input')
        buf966 = reinterpret_tensor(buf962, (128, 2048), (2048, 1), 0); del buf962  # reuse
        # Topologically Sorted Source Nodes: [linear_152, silu_49, linear_153, mul_422, down_proj_19], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_27.run(buf965, arg268_1, buf966, 1024, 1, 1, stream=raw_stream0)
        del arg268_1
        assert_size_stride(arg269_1, (2048, ), (1, ), 'input')
        buf968 = reinterpret_tensor(buf959, (1, 128, 2048), (262144, 2048, 1), 0); del buf959  # reuse
        # Topologically Sorted Source Nodes: [down_proj_19, hidden_states_149, float_132, pow_66, mean_65, add_275, rsqrt_95, output_115, float_133, add_276, output_116, hidden_states_150], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_30.run(buf960, buf966, arg269_1, buf968, 128, 2048, stream=raw_stream0)
        del arg269_1
        assert_size_stride(arg270_1, (6144, 2048), (2048, 1), 'input')
        buf969 = reinterpret_tensor(buf965, (128, 6144), (6144, 1), 0); del buf965  # reuse
        # Topologically Sorted Source Nodes: [down_proj_19, hidden_states_149, float_132, pow_66, mean_65, add_275, rsqrt_95, output_115, float_133, add_276, output_116, hidden_states_150, mixed_qkv_60], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf968, arg270_1, buf969, 3072, 1, 1, stream=raw_stream0)
        del arg270_1
        assert_size_stride(arg274_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf970 = buf882; del buf882  # reuse
        # Topologically Sorted Source Nodes: [mixed_qkv_60, mixed_qkv_61, conv1d_15, squeeze_15, unsqueeze_130, out_30, out_31], Original ATen: [aten._unsafe_view, aten.transpose, aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_convolution_silu_slice_squeeze_transpose_unsqueeze_2.run(buf969, arg274_1, buf970, 786432, stream=raw_stream0)
        del arg274_1
        buf971 = reinterpret_tensor(buf916, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf916  # reuse
        buf972 = reinterpret_tensor(buf887, (1, 16, 128, 1), (2048, 1, 16, 2048), 0); del buf887  # reuse
        buf982 = reinterpret_tensor(buf907, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf907  # reuse
        # Topologically Sorted Source Nodes: [out_31, mixed_qkv_63, split_15, query_121, transpose_207, query_122, mul_426, sum_31, add_278, inv_norm_30, query_123, query_124], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_3.run(buf970, buf971, buf972, buf982, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg273_1, (16, 2048), (2048, 1), 'input')
        buf973 = buf898; del buf898  # reuse
        # Topologically Sorted Source Nodes: [a_15], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf968, arg273_1, buf973, 8, 1, 1, stream=raw_stream0)
        del arg273_1
        assert_size_stride(arg275_1, (16, ), (1, ), 'input')
        buf974 = buf886; del buf886  # reuse
        # Topologically Sorted Source Nodes: [exp_90, neg_25], Original ATen: [aten.exp, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_neg_5.run(arg275_1, buf974, 16, stream=raw_stream0)
        del arg275_1
        assert_size_stride(arg276_1, (16, ), (1, ), 'input')
        buf975 = buf913; del buf913  # reuse
        # Topologically Sorted Source Nodes: [exp_90, neg_25, a_15, float_135, add_277, softplus_15, g_15, transpose_211, decay_47, cum_decay_15], Original ATen: [aten.exp, aten.neg, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.view, aten.cumsum]
        workspace_15 = workspace_14; del workspace_14  # reuse
        workspace_15.zero_()
        raw_stream0 = get_raw_stream(0)
        triton_spl_fused__to_copy__unsafe_view_add_cumsum_exp_mul_neg_softplus_transpose_view_6.run(buf974, buf973, arg276_1, buf975, workspace_15, 32, 64, stream=raw_stream0)
        del arg276_1
        buf976 = buf905; del buf905  # reuse
        buf993 = reinterpret_tensor(buf899, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf899  # reuse
        buf1001 = reinterpret_tensor(buf884, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf884  # reuse
        # Topologically Sorted Source Nodes: [exp_93, exp_92, getitem_375, sub_61, exp_94], Original ATen: [aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_slice_sub_7.run(buf975, buf976, buf993, buf1001, 2048, stream=raw_stream0)
        buf977 = reinterpret_tensor(buf904, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf904  # reuse
        # Topologically Sorted Source Nodes: [add_278, inv_norm_30, query_123, query_124, query_126, exp_93, unsqueeze_136, query_127], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_exp_mul_rsqrt_unsqueeze_view_8.run(buf971, buf972, buf976, buf977, 262144, stream=raw_stream0)
        buf978 = reinterpret_tensor(buf971, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf971  # reuse
        # Topologically Sorted Source Nodes: [last_recurrent_state_45], Original ATen: [aten.zeros]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_zeros_9.run(buf978, 262144, stream=raw_stream0)
        buf979 = reinterpret_tensor(buf952, (16, 64, 128), (8192, 128, 1), 0); del buf952  # reuse
        # Topologically Sorted Source Nodes: [add_278, inv_norm_30, query_123, query_124, query_126, exp_93, unsqueeze_136, query_127, getitem_380, inter_chunk_attn_30, last_recurrent_state_45], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze, aten.select, aten.zeros, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_unsqueeze_view_zeros_10.run(buf977, buf978, buf979, 32, 16, 1, stream=raw_stream0)
        buf980 = reinterpret_tensor(buf889, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf889  # reuse
        buf983 = reinterpret_tensor(buf914, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf914  # reuse
        # Topologically Sorted Source Nodes: [out_31, mixed_qkv_63, split_15, key_106, transpose_208, key_107, mul_428, sum_32, add_279, inv_norm_31, key_108], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_11.run(buf970, buf980, buf983, 2048, 128, stream=raw_stream0)
        buf984 = reinterpret_tensor(buf917, (32, 64, 64), (4096, 64, 1), 0); del buf917  # reuse
        # Topologically Sorted Source Nodes: [add_278, inv_norm_30, query_123, query_124, query_126, matmul_161, add_279, inv_norm_31, key_108, key_110, transpose_213], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_mul_rsqrt_transpose_view_12.run(buf982, buf983, buf984, 16, 32, 1, stream=raw_stream0)
        assert_size_stride(arg272_1, (16, 2048), (2048, 1), 'input')
        buf986 = buf973; del buf973  # reuse
        # Topologically Sorted Source Nodes: [b_15], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf968, arg272_1, buf986, 8, 1, 1, stream=raw_stream0)
        del arg272_1
        buf987 = reinterpret_tensor(buf976, (1, 16, 128), (2048, 128, 1), 0); del buf976  # reuse
        # Topologically Sorted Source Nodes: [b_15, beta_45, transpose_210, beta_46], Original ATen: [aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_sigmoid_transpose_13.run(buf986, buf987, 16, 128, stream=raw_stream0)
        buf988 = buf982; del buf982  # reuse
        buf994 = reinterpret_tensor(buf980, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf980  # reuse
        buf1002 = buf906; del buf906  # reuse
        buf991 = buf903; del buf903  # reuse
        # Topologically Sorted Source Nodes: [out_31, mixed_qkv_63, split_15, add_279, inv_norm_31, key_108, key_110, unsqueeze_132, k_beta_30, k_beta_31, value_61, transpose_209, value_62, unsqueeze_131, v_beta_30, exp_92, unsqueeze_135, decayed_k_beta_15, getitem_375, sub_61, exp_94, unsqueeze_137, key_111], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.view, aten.unsqueeze, aten._to_copy, aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_exp_mul_rsqrt_silu_slice_split_with_sizes_sub_transpose_unsqueeze_view_14.run(buf983, buf987, buf993, buf1001, buf970, buf988, buf994, buf1002, buf991, 262144, stream=raw_stream0)
        buf990 = reinterpret_tensor(buf911, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf911  # reuse
        buf997 = reinterpret_tensor(buf891, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf891  # reuse
        # Topologically Sorted Source Nodes: [add_279, inv_norm_31, key_108, key_110, matmul_161, strictly_upper_mask_15, ones_15, pairwise_decay_46, unsqueeze_133, unsqueeze_134, pairwise_decay_45, pairwise_decay_47, intra_chunk_attn_15, unsqueeze_132, k_beta_30, k_beta_31, matmul_160, transpose_212, ut_system_15], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.triu, aten.ones, aten.masked_fill, aten.unsqueeze, aten.sub, aten.exp, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_masked_fill_mul_ones_rsqrt_sub_transpose_triu_unsqueeze_view_15.run(buf988, buf983, buf975, buf984, buf990, buf997, 16, 32, 1, stream=raw_stream0)
        del buf983
        del buf988
        # Topologically Sorted Source Nodes: [out_31, mixed_qkv_63, split_15, value_61, transpose_209, value_62, unsqueeze_131, v_beta_30, v_beta_31, new_values_15], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.unsqueeze, aten.mul, aten.linalg_solve_triangular]
        buf992 = torch.ops.aten.linalg_solve_triangular.default(buf990, reinterpret_tensor(buf991, (1, 16, 2, 64, 128), (0, 16384, 8192, 128, 1), 0), upper=False, unitriangular=True)
        assert_tensor_metadata(buf992, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf992, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        # Topologically Sorted Source Nodes: [unsqueeze_132, k_beta_30, k_beta_31, exp_92, unsqueeze_135, decayed_k_beta_15, k_cumdecay_15], Original ATen: [aten.unsqueeze, aten.mul, aten.view, aten.exp, aten.linalg_solve_triangular]
        buf995 = torch.ops.aten.linalg_solve_triangular.default(buf990, buf994, upper=False, unitriangular=True)
        assert_tensor_metadata(buf995, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf995, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        buf998 = reinterpret_tensor(buf990, (1, 16, 64, 128), (131072, 8192, 128, 1), 0); del buf990  # reuse
        # Topologically Sorted Source Nodes: [getitem_378, getitem_379, matmul_162, v_new_30], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_16.run(buf995, buf978, buf992, buf998, 32, 16, 1, stream=raw_stream0)
        buf999 = reinterpret_tensor(buf984, (16, 64, 128), (8192, 128, 1), 0); del buf984  # reuse
        # Topologically Sorted Source Nodes: [matmul_161, intra_chunk_attn_15, getitem_381, matmul_164, getitem_378, matmul_162, v_new_30], Original ATen: [aten.view, aten.mul, aten.select, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_mul_select_sub_view_17.run(buf997, buf998, buf999, 32, 16, 1, stream=raw_stream0)
        buf1000 = buf912; del buf912  # reuse
        # Topologically Sorted Source Nodes: [getitem_376, exp_95], Original ATen: [aten.select, aten.exp]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_select_18.run(buf975, buf1000, 32, stream=raw_stream0)
        buf1004 = buf978; del buf978  # reuse
        # Topologically Sorted Source Nodes: [add_279, inv_norm_31, key_108, key_110, getitem_376, exp_95, chunk_decay_15, getitem_382, mul_438, getitem_375, sub_61, exp_94, unsqueeze_137, key_111, getitem_383, transpose_214, matmul_165, last_recurrent_state_46], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.select, aten.exp, aten.unsqueeze, aten.slice, aten.sub, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_slice_sub_transpose_unsqueeze_view_19.run(buf1002, buf998, buf1000, buf1004, 64, 16, 1, stream=raw_stream0)
        buf1005 = reinterpret_tensor(buf998, (16, 64, 128), (8192, 128, 1), 0); del buf998  # reuse
        # Topologically Sorted Source Nodes: [getitem_386, inter_chunk_attn_31, getitem_376, exp_95, chunk_decay_15, getitem_382, mul_438, matmul_165, last_recurrent_state_46], Original ATen: [aten.select, aten.view, aten.exp, aten.unsqueeze, aten.mul, aten.add, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_select_unsqueeze_view_20.run(buf977, buf1004, buf1005, 32, 16, 1, stream=raw_stream0)
        buf1007 = buf919; del buf919  # reuse
        # Topologically Sorted Source Nodes: [getitem_384, getitem_385, matmul_166, v_new_31], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_21.run(buf995, buf1004, buf992, buf1007, 32, 16, 1, stream=raw_stream0)
        buf1008 = reinterpret_tensor(buf909, (16, 64, 128), (8192, 128, 1), 0); del buf909  # reuse
        # Topologically Sorted Source Nodes: [getitem_387, matmul_168, getitem_384, matmul_166, v_new_31], Original ATen: [aten.select, aten.view, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_22.run(buf997, buf1007, buf1008, 32, 16, 1, stream=raw_stream0)
        assert_size_stride(arg271_1, (2048, 2048), (2048, 1), 'input')
        buf1010 = buf930; del buf930  # reuse
        # Topologically Sorted Source Nodes: [z_45], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf968, arg271_1, buf1010, 1024, 1, 1, stream=raw_stream0)
        del arg271_1
        assert_size_stride(arg277_1, (128, ), (1, ), 'input')
        buf1011 = reinterpret_tensor(buf1010, (2048, 128), (128, 1), 0); del buf1010  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_105, setitem_34, inter_chunk_attn_30, matmul_164, add_280, setitem_35, inter_chunk_attn_31, matmul_168, add_282, core_attn_out_106, transpose_216, core_attn_out_108, core_attn_out_109, hidden_states_151, pow_67, variance_15, add_284, rsqrt_98, hidden_states_152, to_197, hidden_states_153, z_45, z_46, z_47, to_198, silu_51, hidden_states_154, core_attn_out_110], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_copy_mean_mul_pow_rsqrt_select_silu_transpose_view_zeros_like_24.run(buf1011, buf1005, buf1008, buf979, buf999, arg277_1, 2048, 128, stream=raw_stream0)
        del arg277_1
        assert_size_stride(arg278_1, (2048, 2048), (2048, 1), 'input')
        buf1012 = reinterpret_tensor(buf968, (128, 2048), (2048, 1), 0); del buf968  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_105, setitem_34, inter_chunk_attn_30, matmul_164, add_280, setitem_35, inter_chunk_attn_31, matmul_168, add_282, core_attn_out_106, transpose_216, core_attn_out_108, core_attn_out_109, hidden_states_151, pow_67, variance_15, add_284, rsqrt_98, hidden_states_152, to_197, hidden_states_153, z_45, z_46, z_47, to_198, silu_51, hidden_states_154, core_attn_out_110, core_attn_out_111, output_117], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf1011, arg278_1, buf1012, 1024, 1, 1, stream=raw_stream0)
        del arg278_1
        assert_size_stride(arg279_1, (2048, ), (1, ), 'input')
        buf1014 = reinterpret_tensor(buf1011, (1, 128, 2048), (262144, 2048, 1), 0); del buf1011  # reuse
        # Topologically Sorted Source Nodes: [down_proj_19, hidden_states_149, output_117, hidden_states_155, float_136, pow_68, mean_67, add_286, rsqrt_99, output_118, float_137, add_287, output_119, hidden_states_156], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_31.run(buf960, buf966, buf1012, arg279_1, buf1014, 128, 2048, stream=raw_stream0)
        del arg279_1
        assert_size_stride(arg280_1, (6144, 2048), (2048, 1), 'input')
        buf1015 = buf969; del buf969  # reuse
        # Topologically Sorted Source Nodes: [linear_160], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf1014, arg280_1, buf1015, 3072, 1, 1, stream=raw_stream0)
        del arg280_1
        assert_size_stride(arg281_1, (6144, 2048), (2048, 1), 'input')
        buf1017 = reinterpret_tensor(buf963, (1, 128, 6144), (786432, 6144, 1), 0); del buf963  # reuse
        # Topologically Sorted Source Nodes: [linear_160, silu_52, linear_161, mul_445], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_26.run(buf1014, arg281_1, buf1015, buf1017, 3072, 1, 1, stream=raw_stream0)
        del arg281_1
        assert_size_stride(arg282_1, (2048, 6144), (6144, 1), 'input')
        buf1018 = reinterpret_tensor(buf1014, (128, 2048), (2048, 1), 0); del buf1014  # reuse
        # Topologically Sorted Source Nodes: [linear_160, silu_52, linear_161, mul_445, down_proj_20], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_27.run(buf1017, arg282_1, buf1018, 1024, 1, 1, stream=raw_stream0)
        del arg282_1
        assert_size_stride(arg283_1, (2048, ), (1, ), 'input')
        buf1020 = reinterpret_tensor(buf924, (1, 128, 2048), (262144, 2048, 1), 0); del buf924  # reuse
        # Topologically Sorted Source Nodes: [down_proj_19, hidden_states_149, output_117, hidden_states_155, down_proj_20, hidden_states_157, float_138, pow_69, mean_68, add_289, rsqrt_100, output_120, float_139, add_290, output_121, hidden_states_158], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_32.run(buf960, buf966, buf1012, buf1018, arg283_1, buf1020, 128, 2048, stream=raw_stream0)
        del arg283_1
        assert_size_stride(arg284_1, (6144, 2048), (2048, 1), 'input')
        buf1021 = reinterpret_tensor(buf1017, (128, 6144), (6144, 1), 0); del buf1017  # reuse
        # Topologically Sorted Source Nodes: [mixed_qkv_64], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf1020, arg284_1, buf1021, 3072, 1, 1, stream=raw_stream0)
        del arg284_1
        assert_size_stride(arg288_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf1022 = buf970; del buf970  # reuse
        # Topologically Sorted Source Nodes: [mixed_qkv_64, mixed_qkv_65, conv1d_16, squeeze_16, unsqueeze_138, out_32, out_33], Original ATen: [aten._unsafe_view, aten.transpose, aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_convolution_silu_slice_squeeze_transpose_unsqueeze_2.run(buf1021, arg288_1, buf1022, 786432, stream=raw_stream0)
        del arg288_1
        buf1023 = reinterpret_tensor(buf995, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf995  # reuse
        buf1024 = reinterpret_tensor(buf975, (1, 16, 128, 1), (2048, 1, 16, 2048), 0); del buf975  # reuse
        buf1034 = reinterpret_tensor(buf992, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf992  # reuse
        # Topologically Sorted Source Nodes: [out_33, mixed_qkv_67, split_16, query_129, transpose_219, query_130, mul_449, sum_33, add_292, inv_norm_32, query_131, query_132], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_3.run(buf1022, buf1023, buf1024, buf1034, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg287_1, (16, 2048), (2048, 1), 'input')
        buf1025 = buf986; del buf986  # reuse
        # Topologically Sorted Source Nodes: [a_16], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf1020, arg287_1, buf1025, 8, 1, 1, stream=raw_stream0)
        del arg287_1
        assert_size_stride(arg289_1, (16, ), (1, ), 'input')
        buf1026 = buf974; del buf974  # reuse
        # Topologically Sorted Source Nodes: [exp_96, neg_26], Original ATen: [aten.exp, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_neg_5.run(arg289_1, buf1026, 16, stream=raw_stream0)
        del arg289_1
        assert_size_stride(arg290_1, (16, ), (1, ), 'input')
        buf1027 = buf993; del buf993  # reuse
        # Topologically Sorted Source Nodes: [exp_96, neg_26, a_16, float_141, add_291, softplus_16, g_16, transpose_223, decay_50, cum_decay_16], Original ATen: [aten.exp, aten.neg, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.view, aten.cumsum]
        workspace_16 = workspace_15; del workspace_15  # reuse
        workspace_16.zero_()
        raw_stream0 = get_raw_stream(0)
        triton_spl_fused__to_copy__unsafe_view_add_cumsum_exp_mul_neg_softplus_transpose_view_6.run(buf1026, buf1025, arg290_1, buf1027, workspace_16, 32, 64, stream=raw_stream0)
        del arg290_1
        buf1028 = reinterpret_tensor(buf987, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf987  # reuse
        buf1045 = buf1001; del buf1001  # reuse
        buf1053 = reinterpret_tensor(buf972, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf972  # reuse
        # Topologically Sorted Source Nodes: [exp_99, exp_98, getitem_395, sub_65, exp_100], Original ATen: [aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_slice_sub_7.run(buf1027, buf1028, buf1045, buf1053, 2048, stream=raw_stream0)
        buf1029 = reinterpret_tensor(buf1004, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf1004  # reuse
        # Topologically Sorted Source Nodes: [add_292, inv_norm_32, query_131, query_132, query_134, exp_99, unsqueeze_144, query_135], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_exp_mul_rsqrt_unsqueeze_view_8.run(buf1023, buf1024, buf1028, buf1029, 262144, stream=raw_stream0)
        buf1030 = reinterpret_tensor(buf1023, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf1023  # reuse
        # Topologically Sorted Source Nodes: [last_recurrent_state_48], Original ATen: [aten.zeros]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_zeros_9.run(buf1030, 262144, stream=raw_stream0)
        buf1031 = buf999; del buf999  # reuse
        # Topologically Sorted Source Nodes: [add_292, inv_norm_32, query_131, query_132, query_134, exp_99, unsqueeze_144, query_135, getitem_400, inter_chunk_attn_32, last_recurrent_state_48], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze, aten.select, aten.zeros, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_unsqueeze_view_zeros_10.run(buf1029, buf1030, buf1031, 32, 16, 1, stream=raw_stream0)
        buf1032 = reinterpret_tensor(buf977, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf977  # reuse
        buf1035 = reinterpret_tensor(buf1002, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf1002  # reuse
        # Topologically Sorted Source Nodes: [out_33, mixed_qkv_67, split_16, key_113, transpose_220, key_114, mul_451, sum_34, add_293, inv_norm_33, key_115], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_11.run(buf1022, buf1032, buf1035, 2048, 128, stream=raw_stream0)
        buf1036 = reinterpret_tensor(buf979, (32, 64, 64), (4096, 64, 1), 0); del buf979  # reuse
        # Topologically Sorted Source Nodes: [add_292, inv_norm_32, query_131, query_132, query_134, matmul_171, add_293, inv_norm_33, key_115, key_117, transpose_225], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_mul_rsqrt_transpose_view_12.run(buf1034, buf1035, buf1036, 16, 32, 1, stream=raw_stream0)
        assert_size_stride(arg286_1, (16, 2048), (2048, 1), 'input')
        buf1038 = buf1025; del buf1025  # reuse
        # Topologically Sorted Source Nodes: [b_16], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf1020, arg286_1, buf1038, 8, 1, 1, stream=raw_stream0)
        del arg286_1
        buf1039 = reinterpret_tensor(buf1028, (1, 16, 128), (2048, 128, 1), 0); del buf1028  # reuse
        # Topologically Sorted Source Nodes: [b_16, beta_48, transpose_222, beta_49], Original ATen: [aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_sigmoid_transpose_13.run(buf1038, buf1039, 16, 128, stream=raw_stream0)
        buf1040 = buf1034; del buf1034  # reuse
        buf1046 = reinterpret_tensor(buf1032, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf1032  # reuse
        buf1054 = buf994; del buf994  # reuse
        buf1043 = buf991; del buf991  # reuse
        # Topologically Sorted Source Nodes: [out_33, mixed_qkv_67, split_16, add_293, inv_norm_33, key_115, key_117, unsqueeze_140, k_beta_32, k_beta_33, value_65, transpose_221, value_66, unsqueeze_139, v_beta_32, exp_98, unsqueeze_143, decayed_k_beta_16, getitem_395, sub_65, exp_100, unsqueeze_145, key_118], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.view, aten.unsqueeze, aten._to_copy, aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_exp_mul_rsqrt_silu_slice_split_with_sizes_sub_transpose_unsqueeze_view_14.run(buf1035, buf1039, buf1045, buf1053, buf1022, buf1040, buf1046, buf1054, buf1043, 262144, stream=raw_stream0)
        buf1042 = reinterpret_tensor(buf1008, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf1008  # reuse
        buf1049 = reinterpret_tensor(buf1005, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf1005  # reuse
        # Topologically Sorted Source Nodes: [add_293, inv_norm_33, key_115, key_117, matmul_171, strictly_upper_mask_16, ones_16, pairwise_decay_49, unsqueeze_141, unsqueeze_142, pairwise_decay_48, pairwise_decay_50, intra_chunk_attn_16, unsqueeze_140, k_beta_32, k_beta_33, matmul_170, transpose_224, ut_system_16], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.triu, aten.ones, aten.masked_fill, aten.unsqueeze, aten.sub, aten.exp, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_masked_fill_mul_ones_rsqrt_sub_transpose_triu_unsqueeze_view_15.run(buf1040, buf1035, buf1027, buf1036, buf1042, buf1049, 16, 32, 1, stream=raw_stream0)
        del buf1035
        del buf1040
        # Topologically Sorted Source Nodes: [out_33, mixed_qkv_67, split_16, value_65, transpose_221, value_66, unsqueeze_139, v_beta_32, v_beta_33, new_values_16], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.unsqueeze, aten.mul, aten.linalg_solve_triangular]
        buf1044 = torch.ops.aten.linalg_solve_triangular.default(buf1042, reinterpret_tensor(buf1043, (1, 16, 2, 64, 128), (0, 16384, 8192, 128, 1), 0), upper=False, unitriangular=True)
        assert_tensor_metadata(buf1044, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf1044, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        # Topologically Sorted Source Nodes: [unsqueeze_140, k_beta_32, k_beta_33, exp_98, unsqueeze_143, decayed_k_beta_16, k_cumdecay_16], Original ATen: [aten.unsqueeze, aten.mul, aten.view, aten.exp, aten.linalg_solve_triangular]
        buf1047 = torch.ops.aten.linalg_solve_triangular.default(buf1042, buf1046, upper=False, unitriangular=True)
        assert_tensor_metadata(buf1047, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf1047, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        buf1050 = reinterpret_tensor(buf1042, (1, 16, 64, 128), (131072, 8192, 128, 1), 0); del buf1042  # reuse
        # Topologically Sorted Source Nodes: [getitem_398, getitem_399, matmul_172, v_new_32], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_16.run(buf1047, buf1030, buf1044, buf1050, 32, 16, 1, stream=raw_stream0)
        buf1051 = reinterpret_tensor(buf1036, (16, 64, 128), (8192, 128, 1), 0); del buf1036  # reuse
        # Topologically Sorted Source Nodes: [matmul_171, intra_chunk_attn_16, getitem_401, matmul_174, getitem_398, matmul_172, v_new_32], Original ATen: [aten.view, aten.mul, aten.select, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_mul_select_sub_view_17.run(buf1049, buf1050, buf1051, 32, 16, 1, stream=raw_stream0)
        buf1052 = buf1000; del buf1000  # reuse
        # Topologically Sorted Source Nodes: [getitem_396, exp_101], Original ATen: [aten.select, aten.exp]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_select_18.run(buf1027, buf1052, 32, stream=raw_stream0)
        buf1056 = buf1030; del buf1030  # reuse
        # Topologically Sorted Source Nodes: [add_293, inv_norm_33, key_115, key_117, getitem_396, exp_101, chunk_decay_16, getitem_402, mul_461, getitem_395, sub_65, exp_100, unsqueeze_145, key_118, getitem_403, transpose_226, matmul_175, last_recurrent_state_49], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.select, aten.exp, aten.unsqueeze, aten.slice, aten.sub, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_slice_sub_transpose_unsqueeze_view_19.run(buf1054, buf1050, buf1052, buf1056, 64, 16, 1, stream=raw_stream0)
        buf1057 = reinterpret_tensor(buf1050, (16, 64, 128), (8192, 128, 1), 0); del buf1050  # reuse
        # Topologically Sorted Source Nodes: [getitem_406, inter_chunk_attn_33, getitem_396, exp_101, chunk_decay_16, getitem_402, mul_461, matmul_175, last_recurrent_state_49], Original ATen: [aten.select, aten.view, aten.exp, aten.unsqueeze, aten.mul, aten.add, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_select_unsqueeze_view_20.run(buf1029, buf1056, buf1057, 32, 16, 1, stream=raw_stream0)
        buf1059 = reinterpret_tensor(buf997, (1, 16, 64, 128), (131072, 8192, 128, 1), 0); del buf997  # reuse
        # Topologically Sorted Source Nodes: [getitem_404, getitem_405, matmul_176, v_new_33], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_21.run(buf1047, buf1056, buf1044, buf1059, 32, 16, 1, stream=raw_stream0)
        buf1060 = reinterpret_tensor(buf1007, (16, 64, 128), (8192, 128, 1), 0); del buf1007  # reuse
        # Topologically Sorted Source Nodes: [getitem_407, matmul_178, getitem_404, matmul_176, v_new_33], Original ATen: [aten.select, aten.view, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_22.run(buf1049, buf1059, buf1060, 32, 16, 1, stream=raw_stream0)
        assert_size_stride(arg285_1, (2048, 2048), (2048, 1), 'input')
        buf1062 = buf878; del buf878  # reuse
        # Topologically Sorted Source Nodes: [z_48], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf1020, arg285_1, buf1062, 1024, 1, 1, stream=raw_stream0)
        del arg285_1
        assert_size_stride(arg291_1, (128, ), (1, ), 'input')
        buf1063 = reinterpret_tensor(buf1062, (2048, 128), (128, 1), 0); del buf1062  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_112, setitem_36, inter_chunk_attn_32, matmul_174, add_294, setitem_37, inter_chunk_attn_33, matmul_178, add_296, core_attn_out_113, transpose_228, core_attn_out_115, core_attn_out_116, hidden_states_159, pow_70, variance_16, add_298, rsqrt_103, hidden_states_160, to_209, hidden_states_161, z_48, z_49, z_50, to_210, silu_54, hidden_states_162, core_attn_out_117], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_copy_mean_mul_pow_rsqrt_select_silu_transpose_view_zeros_like_24.run(buf1063, buf1057, buf1060, buf1031, buf1051, arg291_1, 2048, 128, stream=raw_stream0)
        del arg291_1
        assert_size_stride(arg292_1, (2048, 2048), (2048, 1), 'input')
        buf1064 = reinterpret_tensor(buf1020, (128, 2048), (2048, 1), 0); del buf1020  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_112, setitem_36, inter_chunk_attn_32, matmul_174, add_294, setitem_37, inter_chunk_attn_33, matmul_178, add_296, core_attn_out_113, transpose_228, core_attn_out_115, core_attn_out_116, hidden_states_159, pow_70, variance_16, add_298, rsqrt_103, hidden_states_160, to_209, hidden_states_161, z_48, z_49, z_50, to_210, silu_54, hidden_states_162, core_attn_out_117, core_attn_out_118, output_122], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf1063, arg292_1, buf1064, 1024, 1, 1, stream=raw_stream0)
        del arg292_1
        assert_size_stride(arg293_1, (2048, ), (1, ), 'input')
        buf1065 = buf960; del buf960  # reuse
        buf1067 = reinterpret_tensor(buf1063, (1, 128, 2048), (262144, 2048, 1), 0); del buf1063  # reuse
        # Topologically Sorted Source Nodes: [down_proj_19, hidden_states_149, output_117, hidden_states_155, down_proj_20, hidden_states_157, output_122, hidden_states_163, float_142, pow_71, mean_70, add_300, rsqrt_104, output_123, float_143, add_301, output_124, hidden_states_164], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_50.run(buf1065, buf966, buf1012, buf1018, buf1064, arg293_1, buf1067, 128, 2048, stream=raw_stream0)
        del arg293_1
        assert_size_stride(arg294_1, (6144, 2048), (2048, 1), 'input')
        buf1068 = buf1021; del buf1021  # reuse
        # Topologically Sorted Source Nodes: [float_142, pow_71, mean_70, add_300, rsqrt_104, output_123, float_143, add_301, output_124, hidden_states_164, linear_168], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf1067, arg294_1, buf1068, 3072, 1, 1, stream=raw_stream0)
        del arg294_1
        assert_size_stride(arg295_1, (6144, 2048), (2048, 1), 'input')
        buf1070 = reinterpret_tensor(buf1015, (1, 128, 6144), (786432, 6144, 1), 0); del buf1015  # reuse
        # Topologically Sorted Source Nodes: [linear_168, silu_55, linear_169, mul_468], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_26.run(buf1067, arg295_1, buf1068, buf1070, 3072, 1, 1, stream=raw_stream0)
        del arg295_1
        assert_size_stride(arg296_1, (2048, 6144), (6144, 1), 'input')
        buf1071 = reinterpret_tensor(buf1067, (128, 2048), (2048, 1), 0); del buf1067  # reuse
        # Topologically Sorted Source Nodes: [linear_168, silu_55, linear_169, mul_468, down_proj_21], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_27.run(buf1070, arg296_1, buf1071, 1024, 1, 1, stream=raw_stream0)
        del arg296_1
        assert_size_stride(arg297_1, (2048, ), (1, ), 'input')
        buf1073 = reinterpret_tensor(buf966, (1, 128, 2048), (262144, 2048, 1), 0); del buf966  # reuse
        # Topologically Sorted Source Nodes: [down_proj_21, hidden_states_165, float_144, pow_72, mean_71, add_303, rsqrt_105, output_125, float_145, add_304, output_126, hidden_states_166], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_30.run(buf1065, buf1071, arg297_1, buf1073, 128, 2048, stream=raw_stream0)
        del arg297_1
        assert_size_stride(arg298_1, (6144, 2048), (2048, 1), 'input')
        buf1074 = reinterpret_tensor(buf1070, (128, 6144), (6144, 1), 0); del buf1070  # reuse
        # Topologically Sorted Source Nodes: [down_proj_21, hidden_states_165, float_144, pow_72, mean_71, add_303, rsqrt_105, output_125, float_145, add_304, output_126, hidden_states_166, mixed_qkv_68], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf1073, arg298_1, buf1074, 3072, 1, 1, stream=raw_stream0)
        del arg298_1
        assert_size_stride(arg302_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf1075 = buf1022; del buf1022  # reuse
        # Topologically Sorted Source Nodes: [mixed_qkv_68, mixed_qkv_69, conv1d_17, squeeze_17, unsqueeze_146, out_34, out_35], Original ATen: [aten._unsafe_view, aten.transpose, aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_convolution_silu_slice_squeeze_transpose_unsqueeze_2.run(buf1074, arg302_1, buf1075, 786432, stream=raw_stream0)
        del arg302_1
        buf1076 = reinterpret_tensor(buf1056, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf1056  # reuse
        buf1077 = reinterpret_tensor(buf1027, (1, 16, 128, 1), (2048, 1, 16, 2048), 0); del buf1027  # reuse
        buf1087 = reinterpret_tensor(buf1047, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf1047  # reuse
        # Topologically Sorted Source Nodes: [out_35, mixed_qkv_71, split_17, query_137, transpose_231, query_138, mul_472, sum_35, add_306, inv_norm_34, query_139, query_140], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_3.run(buf1075, buf1076, buf1077, buf1087, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg301_1, (16, 2048), (2048, 1), 'input')
        buf1078 = buf1038; del buf1038  # reuse
        # Topologically Sorted Source Nodes: [a_17], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf1073, arg301_1, buf1078, 8, 1, 1, stream=raw_stream0)
        del arg301_1
        assert_size_stride(arg303_1, (16, ), (1, ), 'input')
        buf1079 = buf1026; del buf1026  # reuse
        # Topologically Sorted Source Nodes: [exp_102, neg_27], Original ATen: [aten.exp, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_neg_5.run(arg303_1, buf1079, 16, stream=raw_stream0)
        del arg303_1
        assert_size_stride(arg304_1, (16, ), (1, ), 'input')
        buf1080 = buf1053; del buf1053  # reuse
        # Topologically Sorted Source Nodes: [exp_102, neg_27, a_17, float_147, add_305, softplus_17, g_17, transpose_235, decay_53, cum_decay_17], Original ATen: [aten.exp, aten.neg, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.view, aten.cumsum]
        workspace_17 = workspace_16; del workspace_16  # reuse
        workspace_17.zero_()
        raw_stream0 = get_raw_stream(0)
        triton_spl_fused__to_copy__unsafe_view_add_cumsum_exp_mul_neg_softplus_transpose_view_6.run(buf1079, buf1078, arg304_1, buf1080, workspace_17, 32, 64, stream=raw_stream0)
        del workspace_17
        del arg304_1
        del buf1079
        buf1081 = buf1045; del buf1045  # reuse
        buf1098 = reinterpret_tensor(buf1039, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf1039  # reuse
        buf1106 = reinterpret_tensor(buf1024, (1, 16, 2, 64), (2048, 128, 64, 1), 0); del buf1024  # reuse
        # Topologically Sorted Source Nodes: [exp_105, exp_104, getitem_415, sub_69, exp_106], Original ATen: [aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_slice_sub_7.run(buf1080, buf1081, buf1098, buf1106, 2048, stream=raw_stream0)
        buf1082 = reinterpret_tensor(buf1044, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf1044  # reuse
        # Topologically Sorted Source Nodes: [add_306, inv_norm_34, query_139, query_140, query_142, exp_105, unsqueeze_152, query_143], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_exp_mul_rsqrt_unsqueeze_view_8.run(buf1076, buf1077, buf1081, buf1082, 262144, stream=raw_stream0)
        del buf1077
        buf1083 = reinterpret_tensor(buf1076, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf1076  # reuse
        # Topologically Sorted Source Nodes: [last_recurrent_state_51], Original ATen: [aten.zeros]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_zeros_9.run(buf1083, 262144, stream=raw_stream0)
        buf1084 = buf1060; del buf1060  # reuse
        # Topologically Sorted Source Nodes: [add_306, inv_norm_34, query_139, query_140, query_142, exp_105, unsqueeze_152, query_143, getitem_420, inter_chunk_attn_34, last_recurrent_state_51], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.exp, aten.unsqueeze, aten.select, aten.zeros, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_unsqueeze_view_zeros_10.run(buf1082, buf1083, buf1084, 32, 16, 1, stream=raw_stream0)
        buf1085 = reinterpret_tensor(buf1029, (1, 16, 128, 128), (262144, 128, 2048, 1), 0); del buf1029  # reuse
        buf1088 = reinterpret_tensor(buf1054, (1, 16, 128, 128), (262144, 16384, 128, 1), 0); del buf1054  # reuse
        # Topologically Sorted Source Nodes: [out_35, mixed_qkv_71, split_17, key_120, transpose_232, key_121, mul_474, sum_36, add_307, inv_norm_35, key_122], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum, aten.add, aten.rsqrt]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mul_rsqrt_silu_split_with_sizes_sum_transpose_view_11.run(buf1075, buf1085, buf1088, 2048, 128, stream=raw_stream0)
        buf1089 = reinterpret_tensor(buf1057, (32, 64, 64), (4096, 64, 1), 0); del buf1057  # reuse
        # Topologically Sorted Source Nodes: [add_306, inv_norm_34, query_139, query_140, query_142, matmul_181, add_307, inv_norm_35, key_122, key_124, transpose_237], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_mul_rsqrt_transpose_view_12.run(buf1087, buf1088, buf1089, 16, 32, 1, stream=raw_stream0)
        assert_size_stride(arg300_1, (16, 2048), (2048, 1), 'input')
        buf1091 = buf1078; del buf1078  # reuse
        # Topologically Sorted Source Nodes: [b_17], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf1073, arg300_1, buf1091, 8, 1, 1, stream=raw_stream0)
        del arg300_1
        buf1092 = reinterpret_tensor(buf1081, (1, 16, 128), (2048, 128, 1), 0); del buf1081  # reuse
        # Topologically Sorted Source Nodes: [b_17, beta_51, transpose_234, beta_52], Original ATen: [aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_sigmoid_transpose_13.run(buf1091, buf1092, 16, 128, stream=raw_stream0)
        del buf1091
        buf1093 = buf1087; del buf1087  # reuse
        buf1099 = reinterpret_tensor(buf1085, (1, 16, 2, 64, 128), (262144, 16384, 8192, 128, 1), 0); del buf1085  # reuse
        buf1107 = buf1046; del buf1046  # reuse
        buf1096 = buf1043; del buf1043  # reuse
        # Topologically Sorted Source Nodes: [out_35, mixed_qkv_71, split_17, add_307, inv_norm_35, key_122, key_124, unsqueeze_148, k_beta_34, k_beta_35, value_69, transpose_233, value_70, unsqueeze_147, v_beta_34, exp_104, unsqueeze_151, decayed_k_beta_17, getitem_415, sub_69, exp_106, unsqueeze_153, key_125], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.view, aten.unsqueeze, aten._to_copy, aten.exp, aten.slice, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_exp_mul_rsqrt_silu_slice_split_with_sizes_sub_transpose_unsqueeze_view_14.run(buf1088, buf1092, buf1098, buf1106, buf1075, buf1093, buf1099, buf1107, buf1096, 262144, stream=raw_stream0)
        del buf1075
        del buf1092
        del buf1098
        del buf1106
        buf1095 = reinterpret_tensor(buf1051, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf1051  # reuse
        buf1102 = reinterpret_tensor(buf1031, (1, 16, 2, 64, 64), (131072, 8192, 4096, 64, 1), 0); del buf1031  # reuse
        # Topologically Sorted Source Nodes: [add_307, inv_norm_35, key_122, key_124, matmul_181, strictly_upper_mask_17, ones_17, pairwise_decay_52, unsqueeze_149, unsqueeze_150, pairwise_decay_51, pairwise_decay_53, intra_chunk_attn_17, unsqueeze_148, k_beta_34, k_beta_35, matmul_180, transpose_236, ut_system_17], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.triu, aten.ones, aten.masked_fill, aten.unsqueeze, aten.sub, aten.exp, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_masked_fill_mul_ones_rsqrt_sub_transpose_triu_unsqueeze_view_15.run(buf1093, buf1088, buf1080, buf1089, buf1095, buf1102, 16, 32, 1, stream=raw_stream0)
        del buf1088
        del buf1093
        # Topologically Sorted Source Nodes: [out_35, mixed_qkv_71, split_17, value_69, transpose_233, value_70, unsqueeze_147, v_beta_34, v_beta_35, new_values_17], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.unsqueeze, aten.mul, aten.linalg_solve_triangular]
        buf1097 = torch.ops.aten.linalg_solve_triangular.default(buf1095, reinterpret_tensor(buf1096, (1, 16, 2, 64, 128), (0, 16384, 8192, 128, 1), 0), upper=False, unitriangular=True)
        assert_tensor_metadata(buf1097, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf1097, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        del buf1096
        # Topologically Sorted Source Nodes: [unsqueeze_148, k_beta_34, k_beta_35, exp_104, unsqueeze_151, decayed_k_beta_17, k_cumdecay_17], Original ATen: [aten.unsqueeze, aten.mul, aten.view, aten.exp, aten.linalg_solve_triangular]
        buf1100 = torch.ops.aten.linalg_solve_triangular.default(buf1095, buf1099, upper=False, unitriangular=True)
        assert_tensor_metadata(buf1100, (1, 16, 2, 64, 128), (262144, 16384, 8192, 1, 64), torch.float32, 'torch.ops.aten.linalg_solve_triangular.default')
        assert_alignment(buf1100, 16, 'torch.ops.aten.linalg_solve_triangular.default')
        del buf1099
        buf1103 = reinterpret_tensor(buf1095, (1, 16, 64, 128), (131072, 8192, 128, 1), 0); del buf1095  # reuse
        # Topologically Sorted Source Nodes: [getitem_418, getitem_419, matmul_182, v_new_34], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_16.run(buf1100, buf1083, buf1097, buf1103, 32, 16, 1, stream=raw_stream0)
        buf1104 = reinterpret_tensor(buf1089, (16, 64, 128), (8192, 128, 1), 0); del buf1089  # reuse
        # Topologically Sorted Source Nodes: [matmul_181, intra_chunk_attn_17, getitem_421, matmul_184, getitem_418, matmul_182, v_new_34], Original ATen: [aten.view, aten.mul, aten.select, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_mul_select_sub_view_17.run(buf1102, buf1103, buf1104, 32, 16, 1, stream=raw_stream0)
        buf1105 = buf1052; del buf1052  # reuse
        # Topologically Sorted Source Nodes: [getitem_416, exp_107], Original ATen: [aten.select, aten.exp]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_exp_select_18.run(buf1080, buf1105, 32, stream=raw_stream0)
        del buf1080
        buf1109 = buf1083; del buf1083  # reuse
        # Topologically Sorted Source Nodes: [add_307, inv_norm_35, key_122, key_124, getitem_416, exp_107, chunk_decay_17, getitem_422, mul_484, getitem_415, sub_69, exp_106, unsqueeze_153, key_125, getitem_423, transpose_238, matmul_185, last_recurrent_state_52], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.view, aten.select, aten.exp, aten.unsqueeze, aten.slice, aten.sub, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_rsqrt_select_slice_sub_transpose_unsqueeze_view_19.run(buf1107, buf1103, buf1105, buf1109, 64, 16, 1, stream=raw_stream0)
        del buf1105
        del buf1107
        buf1110 = reinterpret_tensor(buf1103, (16, 64, 128), (8192, 128, 1), 0); del buf1103  # reuse
        # Topologically Sorted Source Nodes: [getitem_426, inter_chunk_attn_35, getitem_416, exp_107, chunk_decay_17, getitem_422, mul_484, matmul_185, last_recurrent_state_52], Original ATen: [aten.select, aten.view, aten.exp, aten.unsqueeze, aten.mul, aten.add, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_bmm_exp_mul_select_unsqueeze_view_20.run(buf1082, buf1109, buf1110, 32, 16, 1, stream=raw_stream0)
        del buf1082
        buf1112 = buf1059; del buf1059  # reuse
        # Topologically Sorted Source Nodes: [getitem_424, getitem_425, matmul_186, v_new_35], Original ATen: [aten.select, aten.view, aten.bmm, aten.sub]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_21.run(buf1100, buf1109, buf1097, buf1112, 32, 16, 1, stream=raw_stream0)
        del buf1097
        del buf1100
        del buf1109
        buf1113 = reinterpret_tensor(buf1049, (16, 64, 128), (8192, 128, 1), 0); del buf1049  # reuse
        # Topologically Sorted Source Nodes: [getitem_427, matmul_188, getitem_424, matmul_186, v_new_35], Original ATen: [aten.select, aten.view, aten.sub, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_bmm_select_sub_view_22.run(buf1102, buf1112, buf1113, 32, 16, 1, stream=raw_stream0)
        del buf1102
        del buf1112
        assert_size_stride(arg299_1, (2048, 2048), (2048, 1), 'input')
        buf1115 = buf1064; del buf1064  # reuse
        # Topologically Sorted Source Nodes: [z_51], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf1073, arg299_1, buf1115, 1024, 1, 1, stream=raw_stream0)
        del arg299_1
        assert_size_stride(arg305_1, (128, ), (1, ), 'input')
        buf1116 = reinterpret_tensor(buf1115, (2048, 128), (128, 1), 0); del buf1115  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_119, setitem_38, inter_chunk_attn_34, matmul_184, add_308, setitem_39, inter_chunk_attn_35, matmul_188, add_310, core_attn_out_120, transpose_240, core_attn_out_122, core_attn_out_123, hidden_states_167, pow_73, variance_17, add_312, rsqrt_108, hidden_states_168, to_221, hidden_states_169, z_51, z_52, z_53, to_222, silu_57, hidden_states_170, core_attn_out_124], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_copy_mean_mul_pow_rsqrt_select_silu_transpose_view_zeros_like_24.run(buf1116, buf1110, buf1113, buf1084, buf1104, arg305_1, 2048, 128, stream=raw_stream0)
        del arg305_1
        del buf1084
        del buf1104
        del buf1110
        assert_size_stride(arg306_1, (2048, 2048), (2048, 1), 'input')
        buf1117 = reinterpret_tensor(buf1073, (128, 2048), (2048, 1), 0); del buf1073  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_119, setitem_38, inter_chunk_attn_34, matmul_184, add_308, setitem_39, inter_chunk_attn_35, matmul_188, add_310, core_attn_out_120, transpose_240, core_attn_out_122, core_attn_out_123, hidden_states_167, pow_73, variance_17, add_312, rsqrt_108, hidden_states_168, to_221, hidden_states_169, z_51, z_52, z_53, to_222, silu_57, hidden_states_170, core_attn_out_124, core_attn_out_125, output_127], Original ATen: [aten.zeros_like, aten.select, aten.view, aten.add, aten.copy, aten.clone, aten._unsafe_view, aten.transpose, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf1116, arg306_1, buf1117, 1024, 1, 1, stream=raw_stream0)
        del arg306_1
        assert_size_stride(arg307_1, (2048, ), (1, ), 'input')
        buf1119 = reinterpret_tensor(buf1116, (1, 128, 2048), (262144, 2048, 1), 0); del buf1116  # reuse
        # Topologically Sorted Source Nodes: [down_proj_21, hidden_states_165, output_127, hidden_states_171, float_148, pow_74, mean_73, add_314, rsqrt_109, output_128, float_149, add_315, output_129, hidden_states_172], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_31.run(buf1065, buf1071, buf1117, arg307_1, buf1119, 128, 2048, stream=raw_stream0)
        del arg307_1
        assert_size_stride(arg308_1, (6144, 2048), (2048, 1), 'input')
        buf1120 = buf1074; del buf1074  # reuse
        # Topologically Sorted Source Nodes: [linear_176], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf1119, arg308_1, buf1120, 3072, 1, 1, stream=raw_stream0)
        del arg308_1
        assert_size_stride(arg309_1, (6144, 2048), (2048, 1), 'input')
        buf1122 = reinterpret_tensor(buf1068, (1, 128, 6144), (786432, 6144, 1), 0); del buf1068  # reuse
        # Topologically Sorted Source Nodes: [linear_176, silu_58, linear_177, mul_491], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_26.run(buf1119, arg309_1, buf1120, buf1122, 3072, 1, 1, stream=raw_stream0)
        del arg309_1
        assert_size_stride(arg310_1, (2048, 6144), (6144, 1), 'input')
        buf1123 = reinterpret_tensor(buf1119, (128, 2048), (2048, 1), 0); del buf1119  # reuse
        # Topologically Sorted Source Nodes: [linear_176, silu_58, linear_177, mul_491, down_proj_22], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_27.run(buf1122, arg310_1, buf1123, 1024, 1, 1, stream=raw_stream0)
        del arg310_1
        assert_size_stride(arg311_1, (2048, ), (1, ), 'input')
        buf1125 = reinterpret_tensor(buf1018, (1, 128, 2048), (262144, 2048, 1), 0); del buf1018  # reuse
        # Topologically Sorted Source Nodes: [down_proj_21, hidden_states_165, output_127, hidden_states_171, down_proj_22, hidden_states_173, float_150, pow_75, mean_74, add_317, rsqrt_110, output_130, float_151, add_318, output_131, hidden_states_174], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_32.run(buf1065, buf1071, buf1117, buf1123, arg311_1, buf1125, 128, 2048, stream=raw_stream0)
        del arg311_1
        assert_size_stride(arg312_1, (4096, 2048), (2048, 1), 'input')
        buf1126 = buf933; del buf933  # reuse
        # Topologically Sorted Source Nodes: [linear_179], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_33.run(buf1125, arg312_1, buf1126, 2048, 1, 1, stream=raw_stream0)
        del arg312_1
        buf1127 = buf934; del buf934  # reuse
        # Topologically Sorted Source Nodes: [linear_179, view_20, chunk_5, float_152, pow_76, mean_75], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_mean_pow_split_view_34.run(buf1126, buf1127, 1024, 256, stream=raw_stream0)
        assert_size_stride(arg313_1, (256, ), (1, ), 'input')
        buf1130 = reinterpret_tensor(buf954, (1, 8, 128, 64), (65536, 8192, 64, 1), 0); del buf954  # reuse
        buf1128 = reinterpret_tensor(buf1130, (1, 8, 128, 32), (65536, 8192, 64, 1), 0)  # alias
        buf1129 = reinterpret_tensor(buf1130, (1, 8, 128, 32), (65536, 8192, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_179, view_20, chunk_5, float_152, pow_76, mean_75, add_319, rsqrt_111, output_132, float_153, add_320, output_133, type_as_57, query_states_11, q_rot_5, x2_10, neg_28, x1_10, cat_22], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_36.run(buf1126, buf1127, arg313_1, buf1128, buf1129, 32768, stream=raw_stream0)
        buf1133 = reinterpret_tensor(buf1012, (1, 8, 128, 256), (262144, 32768, 256, 1), 0); del buf1012  # reuse
        buf1131 = reinterpret_tensor(buf1133, (1, 8, 128, 64), (262144, 32768, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, linear_179, view_20, chunk_5, float_152, pow_76, mean_75, add_319, rsqrt_111, output_132, float_153, add_320, output_133, type_as_57, query_states_11, q_rot_5, cos_9, mul_498, sin_9, mul_499, q_embed_10], Original ATen: [aten.select, aten.cat, aten._to_copy, aten._unsafe_view, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_37.run(buf1126, buf1127, arg313_1, buf161, buf1130, buf165, buf1131, 65536, stream=raw_stream0)
        del buf1128
        del buf1129
        buf1132 = reinterpret_tensor(buf1133, (1, 8, 128, 192), (262144, 32768, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, linear_179, view_20, chunk_5, float_152, pow_76, mean_75, add_319, rsqrt_111, output_132, float_153, add_320, output_133, type_as_57, query_states_11, q_rot_5, cos_9, mul_498, sin_9, mul_499, q_embed_10, q_pass_5, q_embed_11], Original ATen: [aten.select, aten.cat, aten._to_copy, aten._unsafe_view, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_38.run(buf1126, buf1127, arg313_1, buf1132, 196608, stream=raw_stream0)
        del arg313_1
        del buf1127
        assert_size_stride(arg314_1, (512, 2048), (2048, 1), 'input')
        del buf1131
        del buf1132
        buf1134 = reinterpret_tensor(buf1130, (128, 512), (512, 1), 0); del buf1130  # reuse
        # Topologically Sorted Source Nodes: [linear_180], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_39.run(buf1125, arg314_1, buf1134, 256, 1, 1, stream=raw_stream0)
        del arg314_1
        buf1135 = buf942; del buf942  # reuse
        # Topologically Sorted Source Nodes: [linear_180, view_22, float_154, pow_77, mean_76], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_mean_pow_view_40.run(buf1134, buf1135, 256, 256, stream=raw_stream0)
        assert_size_stride(arg315_1, (256, ), (1, ), 'input')
        buf1138 = buf945; del buf945  # reuse
        buf1136 = reinterpret_tensor(buf1138, (1, 2, 128, 32), (16384, 8192, 64, 1), 0)  # alias
        buf1137 = reinterpret_tensor(buf1138, (1, 2, 128, 32), (16384, 8192, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_180, view_22, float_154, pow_77, mean_76, add_321, rsqrt_112, output_134, float_155, add_322, output_135, type_as_58, key_states_10, k_rot_5, x2_11, neg_29, x1_11, cat_23], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_41.run(buf1134, buf1135, arg315_1, buf1136, buf1137, 8192, stream=raw_stream0)
        buf1141 = reinterpret_tensor(buf941, (1, 2, 128, 256), (65536, 32768, 256, 1), 0); del buf941  # reuse
        buf1139 = reinterpret_tensor(buf1141, (1, 2, 128, 64), (65536, 32768, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, cos_9, sin_9, linear_180, view_22, float_154, pow_77, mean_76, add_321, rsqrt_112, output_134, float_155, add_322, output_135, type_as_58, key_states_10, k_rot_5, mul_500, mul_501, k_embed_10], Original ATen: [aten.select, aten.cat, aten._to_copy, aten.unsqueeze, aten._unsafe_view, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_42.run(buf1134, buf1135, arg315_1, buf161, buf1138, buf165, buf1139, 16384, stream=raw_stream0)
        del buf1136
        del buf1137
        del buf1138
        del buf161
        del buf165
        buf1140 = reinterpret_tensor(buf1141, (1, 2, 128, 192), (65536, 32768, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, cos_9, sin_9, linear_180, view_22, float_154, pow_77, mean_76, add_321, rsqrt_112, output_134, float_155, add_322, output_135, type_as_58, key_states_10, k_rot_5, mul_500, mul_501, k_embed_10, k_pass_5, k_embed_11], Original ATen: [aten.select, aten.cat, aten._to_copy, aten.unsqueeze, aten._unsafe_view, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_43.run(buf1134, buf1135, arg315_1, buf1140, 49152, stream=raw_stream0)
        del arg315_1
        del buf1134
        del buf1135
        buf1142 = reinterpret_tensor(buf940, (1, 2, 4, 128, 256), (262144, 131072, 32768, 256, 1), 0); del buf940  # reuse
        # Topologically Sorted Source Nodes: [getitem_441, hidden_states_175, key_states_11], Original ATen: [aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_clone_expand_unsqueeze_44.run(buf1141, buf1142, 262144, stream=raw_stream0)
        del buf1139
        del buf1140
        buf1143 = reinterpret_tensor(buf955, (8, 128, 128), (16384, 128, 1), 0); del buf955  # reuse
        # Topologically Sorted Source Nodes: [matmul_190, getitem_441, hidden_states_175, key_states_11, transpose_244], Original ATen: [aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_45.run(buf1133, buf1142, buf1143, 64, 8, 1, stream=raw_stream0)
        del buf1133
        buf1145 = reinterpret_tensor(buf1113, (1, 8, 128, 128), (131072, 16384, 128, 1), 0); del buf1113  # reuse
        buf1148 = reinterpret_tensor(buf950, (1, 8, 128, 128), (131072, 16384, 128, 1), 0); del buf950  # reuse
        # Topologically Sorted Source Nodes: [mask, full, getitem, matmul_190, attn_weights_20, attn_weights_21, softmax_5, attn_weights_22], Original ATen: [aten.triu, aten.full, aten.unsqueeze, aten.view, aten.mul, aten.add, aten._to_copy, aten._softmax]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__softmax__to_copy_add_full_mul_triu_unsqueeze_view_46.run(buf1143, buf1145, buf1148, 1024, 128, stream=raw_stream0)
        del buf1143
        del buf1145
        assert_size_stride(arg316_1, (512, 2048), (2048, 1), 'input')
        buf1147 = reinterpret_tensor(buf1141, (128, 512), (512, 1), 0); del buf1141  # reuse
        # Topologically Sorted Source Nodes: [linear_181], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_39.run(buf1125, arg316_1, buf1147, 256, 1, 1, stream=raw_stream0)
        del arg316_1
        buf1149 = reinterpret_tensor(buf1125, (1, 2, 4, 128, 256), (262144, 131072, 32768, 256, 1), 0); del buf1125  # reuse
        # Topologically Sorted Source Nodes: [linear_181, view_23, value_states_10, getitem_442, hidden_states_176, value_states_11], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_clone_expand_transpose_unsqueeze_view_47.run(buf1147, buf1149, 262144, stream=raw_stream0)
        del buf1147
        buf1150 = reinterpret_tensor(buf1142, (8, 128, 256), (32768, 256, 1), 0); del buf1142  # reuse
        # Topologically Sorted Source Nodes: [softmax_5, attn_weights_22, attn_output_25, linear_181, view_23, value_states_10, getitem_442, hidden_states_176, value_states_11], Original ATen: [aten._softmax, aten._to_copy, aten.view, aten._unsafe_view, aten.transpose, aten.unsqueeze, aten.expand, aten.clone, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__softmax__to_copy__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_48.run(buf1148, buf1149, buf1150, 128, 8, 1, stream=raw_stream0)
        del buf1148
        buf1151 = reinterpret_tensor(buf1149, (1, 128, 2048), (262144, 2048, 1), 0); del buf1149  # reuse
        # Topologically Sorted Source Nodes: [linear_179, view_20, chunk_5, attn_output_25, transpose_245, attn_output_26, reshape_257, gate_11, sigmoid_23, attn_output_28], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten.transpose, aten.clone, aten.sigmoid, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_clone_mul_sigmoid_split_transpose_view_49.run(buf1150, buf1126, buf1151, 262144, stream=raw_stream0)
        del buf1126
        assert_size_stride(arg317_1, (2048, 2048), (2048, 1), 'input')
        buf1152 = reinterpret_tensor(buf1150, (128, 2048), (2048, 1), 0); del buf1150  # reuse
        # Topologically Sorted Source Nodes: [linear_179, view_20, chunk_5, attn_output_25, transpose_245, attn_output_26, reshape_257, gate_11, sigmoid_23, attn_output_28, attn_output_29], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten.transpose, aten.clone, aten.sigmoid, aten.mul, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_23.run(buf1151, arg317_1, buf1152, 1024, 1, 1, stream=raw_stream0)
        del arg317_1
        assert_size_stride(arg318_1, (2048, ), (1, ), 'input')
        buf1153 = buf1065; del buf1065  # reuse
        buf1155 = buf1151; del buf1151  # reuse
        # Topologically Sorted Source Nodes: [down_proj_21, hidden_states_165, output_127, hidden_states_171, down_proj_22, hidden_states_173, attn_output_29, hidden_states_177, float_156, pow_78, mean_77, add_327, rsqrt_113, output_136, float_157, add_328, output_137, hidden_states_178], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_50.run(buf1153, buf1071, buf1117, buf1123, buf1152, arg318_1, buf1155, 128, 2048, stream=raw_stream0)
        del arg318_1
        del buf1071
        del buf1117
        del buf1123
        del buf1152
        assert_size_stride(arg319_1, (6144, 2048), (2048, 1), 'input')
        buf1156 = reinterpret_tensor(buf1122, (128, 6144), (6144, 1), 0); del buf1122  # reuse
        # Topologically Sorted Source Nodes: [float_156, pow_78, mean_77, add_327, rsqrt_113, output_136, float_157, add_328, output_137, hidden_states_178, linear_183], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf1155, arg319_1, buf1156, 3072, 1, 1, stream=raw_stream0)
        del arg319_1
        assert_size_stride(arg320_1, (6144, 2048), (2048, 1), 'input')
        buf1158 = reinterpret_tensor(buf1120, (1, 128, 6144), (786432, 6144, 1), 0); del buf1120  # reuse
        # Topologically Sorted Source Nodes: [linear_183, silu_59, linear_184, mul_506], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_26.run(buf1155, arg320_1, buf1156, buf1158, 3072, 1, 1, stream=raw_stream0)
        del arg320_1
        del buf1156
        assert_size_stride(arg321_1, (2048, 6144), (6144, 1), 'input')
        buf1159 = reinterpret_tensor(buf1155, (128, 2048), (2048, 1), 0); del buf1155  # reuse
        # Topologically Sorted Source Nodes: [linear_183, silu_59, linear_184, mul_506, down_proj_23], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_27.run(buf1158, arg321_1, buf1159, 1024, 1, 1, stream=raw_stream0)
        del arg321_1
        del buf1158
        assert_size_stride(arg322_1, (2048, ), (1, ), 'input')
        buf1161 = buf1153; del buf1153  # reuse
        # Topologically Sorted Source Nodes: [down_proj_23, hidden_states_179, float_158, pow_79, mean_78, add_330, rsqrt_114, output_138, float_159, add_331, output_139, hidden_states_180], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_51.run(buf1161, buf1159, arg322_1, 128, 2048, stream=raw_stream0)
        del arg322_1
        del buf1159
        buf1162 = empty_strided((128, 248320), (248320, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [down_proj_23, hidden_states_179, float_158, pow_79, mean_78, add_330, rsqrt_114, output_138, float_159, add_331, output_139, hidden_states_180, logits], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_t_view_52.run(buf1161, arg1_1, buf1162, 124160, 1, 1, stream=raw_stream0)
        del arg1_1
        return (reinterpret_tensor(buf1162, (1, 128, 248320), (31784960, 248320, 1), 0), )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((1, 128), (128, 1), device='tnca:0', dtype=torch.int64)
    arg1_1 = rand_strided((248320, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg2_1 = rand_strided((1, 128), (128, 1), device='tnca:0', dtype=torch.int64)
    arg3_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg4_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg5_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg6_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg7_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg8_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg9_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg10_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg11_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg12_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg13_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg14_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg15_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg16_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg17_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg18_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg19_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg20_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg21_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg22_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg23_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg24_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg25_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg26_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg27_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg28_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg29_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg30_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg31_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg32_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg33_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg34_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg35_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg36_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg37_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg38_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg39_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg40_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg41_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg42_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg43_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg44_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg45_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg46_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg47_1 = rand_strided((4096, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg48_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg49_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg50_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg51_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg52_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg53_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg54_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg55_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg56_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg57_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg58_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg59_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg60_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg61_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg62_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg63_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg64_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg65_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg66_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg67_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg68_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg69_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg70_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg71_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg72_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg73_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg74_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg75_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg76_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg77_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg78_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg79_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg80_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg81_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg82_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg83_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg84_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg85_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg86_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg87_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg88_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg89_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg90_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg91_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg92_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg93_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg94_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg95_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg96_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg97_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg98_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg99_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg100_1 = rand_strided((4096, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg101_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg102_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg103_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg104_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg105_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg106_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg107_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg108_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg109_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg110_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg111_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg112_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg113_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg114_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg115_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg116_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg117_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg118_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg119_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg120_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg121_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg122_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg123_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg124_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg125_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg126_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg127_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg128_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg129_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg130_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg131_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg132_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg133_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg134_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg135_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg136_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg137_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg138_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg139_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg140_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg141_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg142_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg143_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg144_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg145_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg146_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg147_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg148_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg149_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg150_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg151_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg152_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg153_1 = rand_strided((4096, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg154_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg155_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg156_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg157_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg158_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg159_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg160_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg161_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg162_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg163_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg164_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg165_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg166_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg167_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg168_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg169_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg170_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg171_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg172_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg173_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg174_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg175_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg176_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg177_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg178_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg179_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg180_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg181_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg182_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg183_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg184_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg185_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg186_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg187_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg188_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg189_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg190_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg191_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg192_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg193_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg194_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg195_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg196_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg197_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg198_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg199_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg200_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg201_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg202_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg203_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg204_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg205_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg206_1 = rand_strided((4096, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg207_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg208_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg209_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg210_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg211_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg212_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg213_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg214_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg215_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg216_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg217_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg218_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg219_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg220_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg221_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg222_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg223_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg224_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg225_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg226_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg227_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg228_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg229_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg230_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg231_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg232_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg233_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg234_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg235_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg236_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg237_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg238_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg239_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg240_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg241_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg242_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg243_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg244_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg245_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg246_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg247_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg248_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg249_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg250_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg251_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg252_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg253_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg254_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg255_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg256_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg257_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg258_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg259_1 = rand_strided((4096, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg260_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg261_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg262_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg263_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg264_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg265_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg266_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg267_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg268_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg269_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg270_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg271_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg272_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg273_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg274_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg275_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg276_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg277_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg278_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg279_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg280_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg281_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg282_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg283_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg284_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg285_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg286_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg287_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg288_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg289_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg290_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg291_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg292_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg293_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg294_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg295_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg296_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg297_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg298_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg299_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg300_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg301_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg302_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg303_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg304_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg305_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg306_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg307_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg308_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg309_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg310_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg311_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg312_1 = rand_strided((4096, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg313_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg314_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg315_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg316_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg317_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg318_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg319_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg320_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg321_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg322_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1, arg123_1, arg124_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg132_1, arg133_1, arg134_1, arg135_1, arg136_1, arg137_1, arg138_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg146_1, arg147_1, arg148_1, arg149_1, arg150_1, arg151_1, arg152_1, arg153_1, arg154_1, arg155_1, arg156_1, arg157_1, arg158_1, arg159_1, arg160_1, arg161_1, arg162_1, arg163_1, arg164_1, arg165_1, arg166_1, arg167_1, arg168_1, arg169_1, arg170_1, arg171_1, arg172_1, arg173_1, arg174_1, arg175_1, arg176_1, arg177_1, arg178_1, arg179_1, arg180_1, arg181_1, arg182_1, arg183_1, arg184_1, arg185_1, arg186_1, arg187_1, arg188_1, arg189_1, arg190_1, arg191_1, arg192_1, arg193_1, arg194_1, arg195_1, arg196_1, arg197_1, arg198_1, arg199_1, arg200_1, arg201_1, arg202_1, arg203_1, arg204_1, arg205_1, arg206_1, arg207_1, arg208_1, arg209_1, arg210_1, arg211_1, arg212_1, arg213_1, arg214_1, arg215_1, arg216_1, arg217_1, arg218_1, arg219_1, arg220_1, arg221_1, arg222_1, arg223_1, arg224_1, arg225_1, arg226_1, arg227_1, arg228_1, arg229_1, arg230_1, arg231_1, arg232_1, arg233_1, arg234_1, arg235_1, arg236_1, arg237_1, arg238_1, arg239_1, arg240_1, arg241_1, arg242_1, arg243_1, arg244_1, arg245_1, arg246_1, arg247_1, arg248_1, arg249_1, arg250_1, arg251_1, arg252_1, arg253_1, arg254_1, arg255_1, arg256_1, arg257_1, arg258_1, arg259_1, arg260_1, arg261_1, arg262_1, arg263_1, arg264_1, arg265_1, arg266_1, arg267_1, arg268_1, arg269_1, arg270_1, arg271_1, arg272_1, arg273_1, arg274_1, arg275_1, arg276_1, arg277_1, arg278_1, arg279_1, arg280_1, arg281_1, arg282_1, arg283_1, arg284_1, arg285_1, arg286_1, arg287_1, arg288_1, arg289_1, arg290_1, arg291_1, arg292_1, arg293_1, arg294_1, arg295_1, arg296_1, arg297_1, arg298_1, arg299_1, arg300_1, arg301_1, arg302_1, arg303_1, arg304_1, arg305_1, arg306_1, arg307_1, arg308_1, arg309_1, arg310_1, arg311_1, arg312_1, arg313_1, arg314_1, arg315_1, arg316_1, arg317_1, arg318_1, arg319_1, arg320_1, arg321_1, arg322_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
