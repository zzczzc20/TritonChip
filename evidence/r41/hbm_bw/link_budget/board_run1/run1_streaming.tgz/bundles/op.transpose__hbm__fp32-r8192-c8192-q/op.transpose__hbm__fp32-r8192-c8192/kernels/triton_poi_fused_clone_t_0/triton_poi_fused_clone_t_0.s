    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, pid.y
    s.movz       s2, #0
    s.shli       s3, s1, #4                      // x16 as a shift
    s.movz       s1, #8192
    s.add        s5, s2, s3                      // the tile origin
    s.rdspecial  s6, arg_base
    s.movz       s7, #1
    s.ld.d       s8, [s6, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s9, #2
    s.movz       s10, #3
    s.ld.d       s11, [s6, #8]                   // out_ptr0: device_ptr64 at arg_base+8
    s.movz       s6, #4
    s.movz       s12, #5
    s.movz       s13, #6
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s16, #9
    s.movz       s17, #10
    s.movz       s18, #11
    s.movz       s19, #12
    s.movz       s20, #13
    s.movz       s21, #14
    s.shli       s22, s4, #4                     // x16 as a shift
    s.movz       s4, #15
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.muli       s23, s22, #8192                 // a runtime tile origin, x8192
    s.shli       s24, s3, #15                    // x32768 as a shift
    s.movz       s3, #0
    s.movz       s25, #32768
    v.iota       v0                              // arange(0, VLEN)
    s.add        s26, s5, s23                    // the tile origin
    v.splat      v1, s1
    s.movz       s1, #1
    v.mul        v2, v0, v1
    s.movz       s5, #2
    s.movz       s23, #2
    v.splat      v0, s26
    s.shli       s27, s5, #15                    // x32768 as a shift
    v.add        v1, v2, v0
    s.movz       s5, #3
    v.ld.gather.w v0, [s8, v1]                   // index is in elements (ISA sec 9.1)
    s.movz       s28, #3
    s.addi       s29, s26, #1
    s.shli       s30, s5, #15                    // x32768 as a shift
    v.splat      v1, s29
    s.movz       s5, #4
    s.movz       s29, #4
    v.add        v3, v2, v1
    s.shli       s31, s5, #15                    // x32768 as a shift
    s.movz       s5, #5
    a.vwrite     a0, s2, v0
    v.ld.gather.w v0, [s8, v3]                   // index is in elements (ISA sec 9.1)
    s.movz       s2, #5
    s.addi       s32, s26, #2
    s.shli       s33, s5, #15                    // x32768 as a shift
    v.splat      v1, s32
    s.movz       s5, #6
    v.add        v3, v2, v1
    s.movz       s32, #6
    s.shli       s34, s5, #15                    // x32768 as a shift
    s.addi       s5, s26, #3
    a.vwrite     a0, s7, v0
    v.ld.gather.w v0, [s8, v3]                   // index is in elements (ISA sec 9.1)
    s.movz       s7, #7
    s.movz       s35, #7
    v.splat      v1, s5
    s.shli       s5, s7, #15                     // x32768 as a shift
    v.add        v3, v2, v1
    s.movz       s7, #8
    s.movz       s36, #8
    s.addi       s37, s26, #4
    s.shli       s38, s7, #15                    // x32768 as a shift
    a.vwrite     a0, s9, v0
    v.ld.gather.w v0, [s8, v3]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s37
    s.movz       s7, #9
    s.movz       s9, #9
    v.add        v3, v2, v1
    s.shli       s37, s7, #15                    // x32768 as a shift
    s.movz       s7, #10
    s.movz       s39, #10
    s.addi       s40, s26, #5
    s.shli       s41, s7, #15                    // x32768 as a shift
    a.vwrite     a0, s10, v0
    v.ld.gather.w v0, [s8, v3]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s40
    s.movz       s7, #11
    v.add        v3, v2, v1
    s.movz       s10, #11
    s.shli       s40, s7, #15                    // x32768 as a shift
    s.addi       s7, s26, #6
    s.movz       s42, #12
    s.movz       s43, #12
    v.splat      v1, s7
    a.vwrite     a0, s6, v0
    v.ld.gather.w v0, [s8, v3]                   // index is in elements (ISA sec 9.1)
    v.add        v3, v2, v1
    s.shli       s6, s42, #15                    // x32768 as a shift
    s.movz       s7, #13
    s.movz       s42, #13
    s.addi       s44, s26, #7
    s.shli       s45, s7, #15                    // x32768 as a shift
    v.splat      v1, s44
    s.movz       s7, #14
    s.movz       s44, #14
    a.vwrite     a0, s12, v0
    v.ld.gather.w v0, [s8, v3]                   // index is in elements (ISA sec 9.1)
    v.add        v3, v2, v1
    s.shli       s12, s7, #15                    // x32768 as a shift
    s.movz       s7, #15
    s.movz       s46, #15
    s.addi       s47, s26, #8
    s.shli       s48, s7, #15                    // x32768 as a shift
    v.splat      v1, s47
    s.addi       s7, s26, #9
    v.add        v4, v2, v1
    a.vwrite     a0, s13, v0
    v.ld.gather.w v0, [s8, v3]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s7
    s.addi       s7, s26, #10
    v.add        v3, v2, v1
    v.splat      v1, s7
    s.addi       s7, s26, #11
    v.add        v5, v2, v1
    v.splat      v1, s7
    s.addi       s7, s26, #12
    v.add        v6, v2, v1
    a.vwrite     a0, s14, v0
    v.ld.gather.w v0, [s8, v4]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s7
    s.addi       s7, s26, #13
    v.add        v4, v2, v1
    s.addi       s13, s26, #14
    s.addi       s14, s26, #15
    s.muli       s26, s22, #4                    // a runtime tile origin, x4
    a.vwrite     a0, s15, v0
    v.ld.gather.w v0, [s8, v3]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s7
    s.add        s7, s11, s26                    // the tile origin
    v.add        v3, v2, v1
    s.add        s11, s7, s24                    // the tile origin
    s.add        s7, s11, s25
    s.add        s15, s11, s27
    s.add        s22, s11, s30
    s.add        s24, s11, s31
    a.vwrite     a0, s16, v0
    v.ld.gather.w v0, [s8, v5]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s13
    s.add        s13, s11, s33
    v.add        v5, v2, v1
    s.add        s16, s11, s34
    a.vwrite     a0, s17, v0
    v.ld.gather.w v0, [s8, v6]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s14
    s.add        s14, s11, s5
    v.add        v6, v2, v1
    a.vwrite     a0, s18, v0
    v.ld.gather.w v0, [s8, v4]                   // index is in elements (ISA sec 9.1)
    s.add        s5, s11, s38
    s.add        s17, s11, s37
    a.vwrite     a0, s19, v0
    v.ld.gather.w v0, [s8, v3]                   // index is in elements (ISA sec 9.1)
    s.add        s18, s11, s41
    s.add        s19, s11, s40
    a.vwrite     a0, s20, v0
    v.ld.gather.w v0, [s8, v5]                   // index is in elements (ISA sec 9.1)
    s.add        s20, s11, s6
    a.vwrite     a0, s21, v0
    v.ld.gather.w v0, [s8, v6]                   // index is in elements (ISA sec 9.1)
    s.add        s6, s11, s45
    s.add        s8, s11, s12
    a.vwrite     a0, s4, v0
    // tile epilogue: 16 rows through the vector unit, as f32 (ISA sec 9B)
    a.vread      v0, a0, s3
    s.add        s3, s11, s48
    v.st.w       [s11, #0], v0
    a.vread      v0, a0, s1
    v.st.w       [s7, #0], v0
    a.vread      v0, a0, s23
    v.st.w       [s15, #0], v0
    a.vread      v0, a0, s28
    v.st.w       [s22, #0], v0
    a.vread      v0, a0, s29
    v.st.w       [s24, #0], v0
    a.vread      v0, a0, s2
    v.st.w       [s13, #0], v0
    a.vread      v0, a0, s32
    v.st.w       [s16, #0], v0
    a.vread      v0, a0, s35
    v.st.w       [s14, #0], v0
    a.vread      v0, a0, s36
    v.st.w       [s5, #0], v0
    a.vread      v0, a0, s9
    v.st.w       [s17, #0], v0
    a.vread      v0, a0, s39
    v.st.w       [s18, #0], v0
    a.vread      v0, a0, s10
    v.st.w       [s19, #0], v0
    a.vread      v0, a0, s43
    v.st.w       [s20, #0], v0
    a.vread      v0, a0, s42
    v.st.w       [s6, #0], v0
    a.vread      v0, a0, s44
    v.st.w       [s8, #0], v0
    a.vread      v0, a0, s46
    v.st.w       [s3, #0], v0
__rctx_next:
    exit
