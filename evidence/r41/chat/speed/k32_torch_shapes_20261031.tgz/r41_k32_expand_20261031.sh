#!/usr/bin/env bash
set -u
export OMP_NUM_THREADS=1 MAX_JOBS=1 CUDA_VISIBLE_DEVICES=
export TNCA_TLM_BINARY="$HOME/r41_vl_reason_dp/build/tnca-chip"
export TNCA_TLM_CONFIG="$HOME/r41_vl_reason_dp/src/tools/performance_harness/systemc/configs/r41-mma-dp.cfg"
for route in base row; do
  for shape in 1_16_64 1_17_64 16_17_128; do
    IFS=_ read -r m n k <<< "$shape"
    unset TNCA_FP8_PACKED_ROW_CHUNKS TNCA_FP8_PACKED_K32
    if [[ $route == base ]]; then export TNCA_FP8_PACKED_ROW_CHUNKS=1; else export TNCA_FP8_PACKED_K32=1; fi
    export TNCA_TLM_OUT="$HOME/r41_k32_expand_${route}_${shape}_tlm"
    cd "$HOME/r41_chat_speed_k64${route}"
    "$HOME/flux-venv/bin/python" -u tools/r41/chat_speed/bench_k32.py --m "$m" --n "$n" --k "$k" --out "$HOME/r41_k32_expand_${route}_${shape}" || echo "FAIL $route $shape"
  done
done
