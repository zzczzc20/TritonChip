    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // out_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // out_ptr3: device_ptr64 at arg_base+24
    s.rdspecial  s1, arg_base
    s.ld.d       s7, [s1, #48]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s8, #256
    s.mul        s9, s1, s8
    s.add        s1, s7, s9                      // this context's own scratch
    s.addi       s7, s1, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s7, #0], s2
    s.movz       s8, #2
    s.st.d       [s7, #8], s8
    s.movz       s8, #16
    s.st.d       [s7, #16], s8
    s.movz       s8, #64
    s.st.d       [s7, #48], s8
    s.movz       s8, #4
    s.st.d       [s7, #56], s8
    .li       s8, #68719476737
    s.st.d       [s7, #88], s8
    .li       s8, #2207613190144
    s.st.d       [s7, #104], s8
    fence.release.device
    td.load      d0, [s7]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s7, #0
    s.movz       s8, #0
    s.movz       s9, #0
    s.movz       s10, #0
    s.movz       s11, #0
    s.movz       s12, #0
    s.movz       s13, #0
    s.movz       s14, #0
    s.movz       s15, #0
    s.movz       s16, #0
    s.movz       s17, #0
    s.movz       s18, #0
    s.movz       s19, #0
    s.movz       s20, #0
    s.movz       s21, #0
    s.movz       s22, #0
    s.muli       s23, s1, #4
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #16
    v.cmp.lt     p1, v0, v1
    s.muli       s24, s4, #64
    s.add        s25, s2, s24
    s.add        s24, s25, s1
    v.splat      v1, s1
    v.iota       v2                              // arange(0, VLEN)
    v.add        v3, v1, v2
    v.movi       v1, #0
    v.cmp.ge     p2, v3, v1
    v.cmpi.lt    p3, v3, #16
    p.and        p4, p2, p3
    v.splat      v1, s4
    v.movi       v2, #0
    v.cmp.ge     p2, v1, v2
    v.cmpi.lt    p3, v1, #2
    p.and        p5, p2, p3
    p.and        p2, p4, p5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s24, #0]
    .li       s24, #4286578688
    v.splat      v2, s24                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cmp.eq    p2, v1, v2
    v.movi       v3, #1
    v.movi       v4, #0
    @p2 v.sel        v5, v3, v4
    v.movi       v3, #0
    v.cmp.eq     p2, v5, v3
    v.movi       v3, #0
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    @p2 v.sel        v7, v5, v6
    v.extract    s24, v7, #0
    v.insert     v3, s24, #0
    s.lshri      s25, s24, #32
    v.insert     v4, s25, #0
    v.movi       v5, #1
    v.movi       v6, #0
    @p2 v.sel        v7, v5, v6
    v.extract    s24, v7, #1
    v.insert     v3, s24, #1
    s.lshri      s25, s24, #32
    v.insert     v4, s25, #1
    v.movi       v5, #1
    v.movi       v6, #0
    @p2 v.sel        v7, v5, v6
    v.extract    s24, v7, #2
    v.insert     v3, s24, #2
    s.lshri      s25, s24, #32
    v.insert     v4, s25, #2
    v.movi       v5, #1
    v.movi       v6, #0
    @p2 v.sel        v7, v5, v6
    v.extract    s24, v7, #3
    v.insert     v3, s24, #3
    s.lshri      s25, s24, #32
    v.insert     v4, s25, #3
    v.movi       v5, #1
    v.movi       v6, #0
    @p2 v.sel        v7, v5, v6
    v.extract    s24, v7, #4
    v.insert     v3, s24, #4
    s.lshri      s25, s24, #32
    v.insert     v4, s25, #4
    v.movi       v5, #1
    v.movi       v6, #0
    @p2 v.sel        v7, v5, v6
    v.extract    s24, v7, #5
    v.insert     v3, s24, #5
    s.lshri      s25, s24, #32
    v.insert     v4, s25, #5
    v.movi       v5, #1
    v.movi       v6, #0
    @p2 v.sel        v7, v5, v6
    v.extract    s24, v7, #6
    v.insert     v3, s24, #6
    s.lshri      s25, s24, #32
    v.insert     v4, s25, #6
    v.movi       v5, #1
    v.movi       v6, #0
    @p2 v.sel        v7, v5, v6
    v.extract    s24, v7, #7
    v.insert     v3, s24, #7
    s.lshri      s25, s24, #32
    v.insert     v4, s25, #7
    v.movi       v5, #1
    v.movi       v6, #0
    @p2 v.sel        v7, v5, v6
    v.extract    s24, v7, #8
    v.insert     v3, s24, #8
    s.lshri      s25, s24, #32
    v.insert     v4, s25, #8
    v.movi       v5, #1
    v.movi       v6, #0
    @p2 v.sel        v7, v5, v6
    v.extract    s24, v7, #9
    v.insert     v3, s24, #9
    s.lshri      s25, s24, #32
    v.insert     v4, s25, #9
    v.movi       v5, #1
    v.movi       v6, #0
    @p2 v.sel        v7, v5, v6
    v.extract    s24, v7, #10
    v.insert     v3, s24, #10
    s.lshri      s25, s24, #32
    v.insert     v4, s25, #10
    v.movi       v5, #1
    v.movi       v6, #0
    @p2 v.sel        v7, v5, v6
    v.extract    s24, v7, #11
    v.insert     v3, s24, #11
    s.lshri      s25, s24, #32
    v.insert     v4, s25, #11
    v.movi       v5, #1
    v.movi       v6, #0
    @p2 v.sel        v7, v5, v6
    v.extract    s24, v7, #12
    v.insert     v3, s24, #12
    s.lshri      s25, s24, #32
    v.insert     v4, s25, #12
    v.movi       v5, #1
    v.movi       v6, #0
    @p2 v.sel        v7, v5, v6
    v.extract    s24, v7, #13
    v.insert     v3, s24, #13
    s.lshri      s25, s24, #32
    v.insert     v4, s25, #13
    v.movi       v5, #1
    v.movi       v6, #0
    @p2 v.sel        v7, v5, v6
    v.extract    s24, v7, #14
    v.insert     v3, s24, #14
    s.lshri      s25, s24, #32
    v.insert     v4, s25, #14
    v.movi       v5, #1
    v.movi       v6, #0
    @p2 v.sel        v7, v5, v6
    v.extract    s24, v7, #15
    v.insert     v3, s24, #15
    s.lshri      s25, s24, #32
    v.insert     v4, s25, #15
    v.movi       v5, #0
    v.extract    s24, v3, #0
    v.extract    s25, v4, #0
    s.shli       s26, s25, #32
    s.or         s25, s24, s26
    s.cmp.ne     s24, s25, s7
    v.insert     v5, s24, #0
    v.extract    s7, v3, #1
    v.extract    s24, v4, #1
    s.shli       s25, s24, #32
    s.or         s24, s7, s25
    s.cmp.ne     s7, s24, s8
    v.insert     v5, s7, #1
    v.extract    s7, v3, #2
    v.extract    s8, v4, #2
    s.shli       s24, s8, #32
    s.or         s8, s7, s24
    s.cmp.ne     s7, s8, s9
    v.insert     v5, s7, #2
    v.extract    s7, v3, #3
    v.extract    s8, v4, #3
    s.shli       s9, s8, #32
    s.or         s8, s7, s9
    s.cmp.ne     s7, s8, s10
    v.insert     v5, s7, #3
    v.extract    s7, v3, #4
    v.extract    s8, v4, #4
    s.shli       s9, s8, #32
    s.or         s8, s7, s9
    s.cmp.ne     s7, s8, s11
    v.insert     v5, s7, #4
    v.extract    s7, v3, #5
    v.extract    s8, v4, #5
    s.shli       s9, s8, #32
    s.or         s8, s7, s9
    s.cmp.ne     s7, s8, s12
    v.insert     v5, s7, #5
    v.extract    s7, v3, #6
    v.extract    s8, v4, #6
    s.shli       s9, s8, #32
    s.or         s8, s7, s9
    s.cmp.ne     s7, s8, s13
    v.insert     v5, s7, #6
    v.extract    s7, v3, #7
    v.extract    s8, v4, #7
    s.shli       s9, s8, #32
    s.or         s8, s7, s9
    s.cmp.ne     s7, s8, s14
    v.insert     v5, s7, #7
    v.extract    s7, v3, #8
    v.extract    s8, v4, #8
    s.shli       s9, s8, #32
    s.or         s8, s7, s9
    s.cmp.ne     s7, s8, s15
    v.insert     v5, s7, #8
    v.extract    s7, v3, #9
    v.extract    s8, v4, #9
    s.shli       s9, s8, #32
    s.or         s8, s7, s9
    s.cmp.ne     s7, s8, s16
    v.insert     v5, s7, #9
    v.extract    s7, v3, #10
    v.extract    s8, v4, #10
    s.shli       s9, s8, #32
    s.or         s8, s7, s9
    s.cmp.ne     s7, s8, s17
    v.insert     v5, s7, #10
    v.extract    s7, v3, #11
    v.extract    s8, v4, #11
    s.shli       s9, s8, #32
    s.or         s8, s7, s9
    s.cmp.ne     s7, s8, s18
    v.insert     v5, s7, #11
    v.extract    s7, v3, #12
    v.extract    s8, v4, #12
    s.shli       s9, s8, #32
    s.or         s8, s7, s9
    s.cmp.ne     s7, s8, s19
    v.insert     v5, s7, #12
    v.extract    s7, v3, #13
    v.extract    s8, v4, #13
    s.shli       s9, s8, #32
    s.or         s8, s7, s9
    s.cmp.ne     s7, s8, s20
    v.insert     v5, s7, #13
    v.extract    s7, v3, #14
    v.extract    s8, v4, #14
    s.shli       s9, s8, #32
    s.or         s8, s7, s9
    s.cmp.ne     s7, s8, s21
    v.insert     v5, s7, #14
    v.extract    s7, v3, #15
    v.extract    s8, v4, #15
    s.shli       s9, s8, #32
    s.or         s8, s7, s9
    s.cmp.ne     s7, s8, s22
    v.insert     v5, s7, #15
    v.movi       v3, #0
    v.cmp.ne     p2, v5, v3
    v.movi       v3, #0
    v.movi       v4, #0
    v.cmp.ne     p3, v3, v4
    p.and        p4, p1, p2
    p.not        p2, p1
    p.and        p5, p2, p3
    p.or         p2, p4, p5
    @p1 v.sel        v3, v1, v2
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.reduce.or  s7, v4
    vf.reduce.max.b v1, v3
    vf.cmp.uo    p2, v3, v3
    v.movi       v2, #1
    v.movi       v3, #0
    @p2 v.sel        v4, v2, v3
    v.reduce.or.b v2, v4
    v.movi       v3, #0
    v.cmp.ne     p2, v2, v3
    .li       s8, #2143289344
    v.splat      v2, s8                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p2 v.sel        v3, v2, v1
    v.movi       v1, #0
    vf.add       v2, v3, v1
    s.shli       s8, s4, #0                      // element offset -> bytes (x1)
    s.add        s9, s3, s8                      // &out_ptr0[...]
    s.st.b       [s9, #0], s7                    // lane 0 of a broadcast is one word
    s.muli       s3, s4, #64
    s.add        s7, s2, s3
    s.add        s2, s7, s23
    v.splat      v3, s1
    v.iota       v4                              // arange(0, VLEN)
    v.add        v5, v3, v4
    v.movi       v3, #0
    v.cmp.ge     p2, v5, v3
    v.cmpi.lt    p3, v5, #16
    p.and        p4, p2, p3
    v.splat      v3, s4
    v.movi       v4, #0
    v.cmp.ge     p2, v3, v4
    v.cmpi.lt    p3, v3, #2
    p.and        p5, p2, p3
    p.and        p2, p4, p5
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v3, [s2, #0]
    v.extract    s1, v2, #0
    v.splat      v2, s1
    vf.sub       v4, v3, v2
    .li       s1, #1069066811
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v3, v4, v2
    vf.fms       v5, v4, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v2, v3                         // ISA 8.8: <= 2**-22 relative
    .li       s1, #1060205080
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v4, v5, v3
    vf.fma       v3, v2, v4, v2                  // 2**t * 2**d
    vf.cmp.o     p2, v3, v3
    @p2 v.sel        v4, v3, v2
    v.movi       v2, #0
    vf.add       v3, v4, v2
    @p1 v.sel        v5, v3, v2
    s.shli       s1, s4, #4                      // x16 as a shift
    v.splat      v2, s1
    v.add        v3, v0, v2
    s.shli       s2, s1, #2                      // element offset -> bytes (x4)
    s.add        s1, s5, s2                      // &out_ptr2[...]
    @p1 v.st.w       [s1, #0], v4
    vf.reduce.add.b v0, v5
    vf.add       v2, v0, v1
    s.shli       s1, s4, #2                      // element offset -> bytes (x4)
    s.add        s2, s6, s1                      // &out_ptr3[...]
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p1, v0, #1
    @p1 v.st.w       [s2, #0], v2
__rctx_next:
    exit
