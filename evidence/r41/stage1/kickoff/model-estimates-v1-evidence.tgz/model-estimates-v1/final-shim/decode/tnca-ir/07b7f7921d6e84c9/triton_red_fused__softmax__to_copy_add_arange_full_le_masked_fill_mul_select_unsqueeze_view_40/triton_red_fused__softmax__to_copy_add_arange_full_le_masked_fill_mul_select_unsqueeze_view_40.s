    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // out_ptr1: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // out_ptr2: device_ptr64 at arg_base+24
    s.rdspecial  s1, arg_base
    s.ld.d       s7, [s1, #48]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s8, #256
    s.mul        s9, s1, s8
    s.add        s1, s7, s9                      // this context's own scratch
    s.addi       s7, s1, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s7, #0], s2
    s.movz       s1, #8
    s.st.d       [s7, #8], s1
    s.movz       s1, #144
    s.st.d       [s7, #16], s1
    s.movz       s1, #288
    s.st.d       [s7, #48], s1
    s.movz       s1, #2
    s.st.d       [s7, #56], s1
    .li       s1, #68719476737
    s.st.d       [s7, #88], s1
    .li       s1, #1108101562368
    s.st.d       [s7, #104], s1
    fence.release.device
    td.load      d0, [s7]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s7, #144
    s.movz       s8, #16
    v.splat      v0, s4
    v.iota       v0                              // arange(0, VLEN)
    s.ld.w       s9, [s3, #0]                    // one element, not a vector
    v.splat      v1, s9
    s.addi       s3, s1, #0
    .li       s9, #4286578688
    v.splat      v2, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v3, #0
    v.mov        v3, v2
for_1:
    s.cmp.ge     s9, s3, s7
    br.nz        s9, endfor_2
    v.splat      v4, s3
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s9, #144
    s.movz       s10, #8
    s.muli       s11, s4, #288
    v.add        v6, v4, v5
    v.movi       v4, #0
    v.splat      v5, s9
    v.splat      v7, s4
    v.movi       v8, #0
    v.splat      v9, s10
    s.muli       s9, s3, #2
    v.cmp.ge     p1, v6, v4
    v.cmp.lt     p2, v6, v5
    v.cmp.ge     p3, v7, v8
    v.cmp.lt     p4, v7, v9
    s.add        s10, s2, s11
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s11, s10, s9
    p.and        p2, p5, p1
    v.splat      v4, s3
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v5, [s11, #0]
    .li       s9, #1031798784
    v.splat      v6, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v7, v4, v0
    v.movi       v4, #0
    v.movi       v8, #144
    v.cmp.le     p1, v7, v1
    @p1 v.sel        v9, v4, v2
    v.cmp.lt     p1, v7, v8
    v.movi       v4, #0
    s.add        s9, s3, s8
    s.movz       s10, #1
    vf.cvt.bf16.f32 v7, v5
    vf.mul       v5, v7, v6
    vf.add       v6, v5, v9
    vf.max.prop  v5, v3, v6
    @p1 v.sel        v6, v5, v3
    v.mov        v4, v6
    v.mov        v3, v4
    s.mov        s3, s9
    br.nz        s10, for_1
endfor_2:
    v.movi       v4, #1
    v.movi       v5, #0
    vf.cmp.uo    p1, v3, v3
    v.movi       v6, #0
    @p1 v.sel        v7, v4, v5
    vf.reduce.max.b v4, v3
    .li       s3, #2143289344
    v.splat      v3, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.reduce.or.b v5, v7
    v.movi       v7, #0
    v.movi       v8, #0
    v.cmp.ne     p1, v5, v6
    @p1 v.sel        v5, v3, v4
    v.movi       v3, #0
    s.addi       s3, s1, #0
    vf.add       v4, v5, v7
    v.mov        v3, v8
for_3:
    s.cmp.ge     s1, s3, s7
    br.nz        s1, endfor_4
    v.splat      v5, s3
    v.iota       v6                              // arange(0, VLEN)
    s.movz       s1, #144
    s.movz       s9, #8
    s.muli       s10, s4, #288
    v.add        v9, v5, v6
    v.movi       v5, #0
    v.splat      v6, s1
    v.splat      v10, s4
    v.movi       v11, #0
    v.splat      v12, s9
    s.muli       s1, s3, #2
    v.cmp.ge     p1, v9, v5
    v.cmp.lt     p2, v9, v6
    v.cmp.ge     p3, v10, v11
    v.cmp.lt     p4, v10, v12
    s.add        s9, s2, s10
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s10, s9, s1
    p.and        p2, p5, p1
    v.splat      v5, s3
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v6, [s10, #0]
    .li       s1, #1031798784
    v.splat      v9, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v10, v5, v0
    v.extract    s1, v4, #0
    .li       s9, #1069066811
    v.splat      v5, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.le     p1, v10, v1
    @p1 v.sel        v11, v8, v2
    v.splat      v12, s1
    .li       s1, #1060205080
    v.splat      v13, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.mul        s1, s4, s7
    v.movi       v14, #144
    v.cmp.lt     p1, v10, v14
    vf.cvt.bf16.f32 v14, v6
    s.add        s9, s3, s1
    v.movi       v6, #0
    s.shli       s10, s9, #2                     // element offset -> bytes (x4)
    v.splat      v15, s1
    vf.mul       v16, v14, v9
    s.add        s1, s5, s10                     // &out_ptr1[...]
    s.add        s9, s3, s8
    s.movz       s10, #1
    v.add        v9, v10, v15
    vf.add       v9, v16, v11
    vf.sub       v10, v9, v12
    vf.mul       v9, v10, v5
    v.exp2.approx v11, v9                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v12, v10, v5, v9                // the exact rounding error of x*log2(e)
    vf.mul       v5, v12, v13
    vf.fma       v9, v11, v5, v11                // 2**t * 2**d
    vf.cmp.o     p2, v9, v9
    @p2 v.sel        v5, v9, v11
    vf.add       v9, v3, v5
    @p1 v.st.w       [s1, #0], v5
    @p1 v.sel        v5, v9, v3
    v.mov        v6, v5
    v.mov        v3, v6
    s.mov        s3, s9
    br.nz        s10, for_3
endfor_4:
    vf.reduce.add.b v0, v3
    s.movz       s1, #1
    s.shli       s2, s4, #2                      // element offset -> bytes (x4)
    vf.add       v1, v0, v7
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v2, s1
    s.add        s1, s6, s2                      // &out_ptr2[...]
    v.cmp.lt     p1, v0, v2
    @p1 v.st.w       [s1, #0], v1
__rctx_next:
    exit
