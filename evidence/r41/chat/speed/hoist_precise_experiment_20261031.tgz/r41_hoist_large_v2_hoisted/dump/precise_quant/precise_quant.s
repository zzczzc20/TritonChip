    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // X: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // Y: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // S: device_ptr64 at arg_base+16
    s.movz       s1, #16
    s.movz       s6, #32
    s.movz       s7, #48
    s.movz       s8, #64
    s.movz       s9, #80
    s.movz       s10, #96
    s.movz       s11, #112
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #16
    v.add        v2, v0, v1
    v.movi       v1, #32
    v.add        v3, v0, v1
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v4, #48
    v.add        v5, v1, v4
    v.movi       v4, #64
    v.add        v6, v1, v4
    v.movi       v4, #80
    v.add        v7, v1, v4
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v4, #96
    v.add        v8, v1, v4
    v.movi       v4, #112
    v.add        v9, v1, v4
    s.shli       s12, s4, #7                     // x128 as a shift
    v.splat      v1, s12
    v.add        v4, v1, v0
    v.add        v0, v1, v2
    s.add        s13, s1, s12
    v.add        v0, v1, v3
    s.add        s1, s6, s12
    v.add        v0, v1, v5
    s.add        s6, s7, s12
    v.add        v0, v1, v6
    s.add        s7, s8, s12
    v.add        v0, v1, v7
    s.add        s8, s9, s12
    v.add        v0, v1, v8
    s.add        s9, s10, s12
    v.add        v0, v1, v9
    s.add        s10, s11, s12
    s.shli       s11, s12, #1                    // element offset -> bytes (x2)
    s.add        s14, s2, s11                    // &X[...]
    v.ld.h       v0, [s14, #0]
    s.shli       s11, s13, #1                    // element offset -> bytes (x2)
    s.add        s14, s2, s11                    // &X[...]
    v.ld.h       v1, [s14, #0]
    s.shli       s11, s1, #1                     // element offset -> bytes (x2)
    s.add        s14, s2, s11                    // &X[...]
    v.ld.h       v2, [s14, #0]
    s.shli       s11, s6, #1                     // element offset -> bytes (x2)
    s.add        s14, s2, s11                    // &X[...]
    v.ld.h       v3, [s14, #0]
    s.shli       s11, s7, #1                     // element offset -> bytes (x2)
    s.add        s14, s2, s11                    // &X[...]
    v.ld.h       v4, [s14, #0]
    s.shli       s11, s8, #1                     // element offset -> bytes (x2)
    s.add        s14, s2, s11                    // &X[...]
    v.ld.h       v5, [s14, #0]
    s.shli       s11, s9, #1                     // element offset -> bytes (x2)
    s.add        s14, s2, s11                    // &X[...]
    v.ld.h       v6, [s14, #0]
    s.shli       s11, s10, #1                    // element offset -> bytes (x2)
    s.add        s14, s2, s11                    // &X[...]
    v.ld.h       v7, [s14, #0]
    vf.cvt.bf16.f32 v8, v0
    vf.cvt.bf16.f32 v0, v1
    vf.cvt.bf16.f32 v1, v2
    vf.cvt.bf16.f32 v2, v3
    vf.cvt.bf16.f32 v3, v4
    vf.cvt.bf16.f32 v4, v5
    vf.cvt.bf16.f32 v5, v6
    vf.cvt.bf16.f32 v6, v7
    vf.abs       v7, v8
    vf.abs       v9, v0
    vf.abs       v10, v1
    vf.abs       v11, v2
    vf.abs       v12, v3
    vf.abs       v13, v4
    vf.abs       v14, v5
    vf.abs       v15, v6
    vf.reduce.max.b v16, v7
    vf.reduce.max.b v7, v9
    vf.reduce.max.b v9, v10
    vf.reduce.max.b v10, v11
    vf.reduce.max.b v11, v12
    vf.reduce.max.b v12, v13
    vf.reduce.max.b v13, v14
    vf.reduce.max.b v14, v15
    vf.max       v15, v16, v7
    vf.max       v7, v9, v10
    vf.max       v9, v11, v12
    vf.max       v10, v13, v14
    vf.max       v11, v15, v7
    vf.max       v7, v9, v10
    vf.max       v9, v11, v7
    .li       s2, #1138753536
    v.splat      v7, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v10, v7                         // ISA 8.8: <= 2**-22 relative
    .li       s2, #1065353216
    v.splat      v11, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v12, v7, v10, v11
    vf.fms       v13, v10, v12, v10
    vf.neg       v12, v13                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v12, v12
    @p1 v.sel        v13, v12, v10
    vf.mul       v10, v9, v13                    // a/y: faithful quotient
    vf.fms       v12, v10, v7, v9
    vf.fms       v14, v12, v13, v10
    vf.neg       v12, v14                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v12, v12
    @p1 v.sel        v13, v12, v10
    v.movi       v10, #0
    vf.cmp.eq    p1, v9, v10
    vf.cmp.ne    p2, v7, v10
    vf.cmp.o     p3, v7, v7
    p.and        p4, p2, p3
    p.and        p2, p1, p4
    v.xor        v12, v9, v7
    .li       s2, #-2147483648
    v.splat      v7, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v9, v12, v7
    @p2 v.sel        v7, v9, v13
    .li       s2, #730643660
    v.splat      v9, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.max.ieee  v12, v7, v9
    v.rcp.approx v9, v12                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v13, v12, v9, v11
    vf.fms       v14, v9, v13, v9
    vf.neg       v13, v14                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v13, v13
    @p1 v.sel        v14, v13, v9
    vf.mul       v9, v8, v14                     // a/y: faithful quotient
    vf.fms       v13, v9, v12, v8
    vf.fms       v15, v13, v14, v9
    vf.neg       v13, v15                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v13, v13
    @p1 v.sel        v14, v13, v9
    vf.cmp.eq    p1, v8, v10
    vf.cmp.ne    p2, v12, v10
    vf.cmp.o     p3, v12, v12
    p.and        p4, p2, p3
    p.and        p2, p1, p4
    v.xor        v9, v8, v12
    .li       s2, #-2147483648
    v.splat      v8, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v13, v9, v8
    @p2 v.sel        v8, v13, v14
    v.rcp.approx v9, v12                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v13, v12, v9, v11
    vf.fms       v14, v9, v13, v9
    vf.neg       v13, v14                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v13, v13
    @p1 v.sel        v14, v13, v9
    vf.mul       v9, v0, v14                     // a/y: faithful quotient
    vf.fms       v13, v9, v12, v0
    vf.fms       v15, v13, v14, v9
    vf.neg       v13, v15                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v13, v13
    @p1 v.sel        v14, v13, v9
    vf.cmp.eq    p1, v0, v10
    vf.cmp.ne    p2, v12, v10
    vf.cmp.o     p3, v12, v12
    p.and        p4, p2, p3
    p.and        p2, p1, p4
    v.xor        v9, v0, v12
    .li       s2, #-2147483648
    v.splat      v0, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v13, v9, v0
    @p2 v.sel        v0, v13, v14
    v.rcp.approx v9, v12                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v13, v12, v9, v11
    vf.fms       v14, v9, v13, v9
    vf.neg       v13, v14                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v13, v13
    @p1 v.sel        v14, v13, v9
    vf.mul       v9, v1, v14                     // a/y: faithful quotient
    vf.fms       v13, v9, v12, v1
    vf.fms       v15, v13, v14, v9
    vf.neg       v13, v15                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v13, v13
    @p1 v.sel        v14, v13, v9
    vf.cmp.eq    p1, v1, v10
    vf.cmp.ne    p2, v12, v10
    vf.cmp.o     p3, v12, v12
    p.and        p4, p2, p3
    p.and        p2, p1, p4
    v.xor        v9, v1, v12
    .li       s2, #-2147483648
    v.splat      v1, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v13, v9, v1
    @p2 v.sel        v1, v13, v14
    v.rcp.approx v9, v12                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v13, v12, v9, v11
    vf.fms       v14, v9, v13, v9
    vf.neg       v13, v14                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v13, v13
    @p1 v.sel        v14, v13, v9
    vf.mul       v9, v2, v14                     // a/y: faithful quotient
    vf.fms       v13, v9, v12, v2
    vf.fms       v15, v13, v14, v9
    vf.neg       v13, v15                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v13, v13
    @p1 v.sel        v14, v13, v9
    vf.cmp.eq    p1, v2, v10
    vf.cmp.ne    p2, v12, v10
    vf.cmp.o     p3, v12, v12
    p.and        p4, p2, p3
    p.and        p2, p1, p4
    v.xor        v9, v2, v12
    .li       s2, #-2147483648
    v.splat      v2, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v13, v9, v2
    @p2 v.sel        v2, v13, v14
    v.rcp.approx v9, v12                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v13, v12, v9, v11
    vf.fms       v14, v9, v13, v9
    vf.neg       v13, v14                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v13, v13
    @p1 v.sel        v14, v13, v9
    vf.mul       v9, v3, v14                     // a/y: faithful quotient
    vf.fms       v13, v9, v12, v3
    vf.fms       v15, v13, v14, v9
    vf.neg       v13, v15                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v13, v13
    @p1 v.sel        v14, v13, v9
    vf.cmp.eq    p1, v3, v10
    vf.cmp.ne    p2, v12, v10
    vf.cmp.o     p3, v12, v12
    p.and        p4, p2, p3
    p.and        p2, p1, p4
    v.xor        v9, v3, v12
    .li       s2, #-2147483648
    v.splat      v3, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v13, v9, v3
    @p2 v.sel        v3, v13, v14
    v.rcp.approx v9, v12                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v13, v12, v9, v11
    vf.fms       v14, v9, v13, v9
    vf.neg       v13, v14                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v13, v13
    @p1 v.sel        v14, v13, v9
    vf.mul       v9, v4, v14                     // a/y: faithful quotient
    vf.fms       v13, v9, v12, v4
    vf.fms       v15, v13, v14, v9
    vf.neg       v13, v15                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v13, v13
    @p1 v.sel        v14, v13, v9
    vf.cmp.eq    p1, v4, v10
    vf.cmp.ne    p2, v12, v10
    vf.cmp.o     p3, v12, v12
    p.and        p4, p2, p3
    p.and        p2, p1, p4
    v.xor        v9, v4, v12
    .li       s2, #-2147483648
    v.splat      v4, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v13, v9, v4
    @p2 v.sel        v4, v13, v14
    v.rcp.approx v9, v12                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v13, v12, v9, v11
    vf.fms       v14, v9, v13, v9
    vf.neg       v13, v14                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v13, v13
    @p1 v.sel        v14, v13, v9
    vf.mul       v9, v5, v14                     // a/y: faithful quotient
    vf.fms       v13, v9, v12, v5
    vf.fms       v15, v13, v14, v9
    vf.neg       v13, v15                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v13, v13
    @p1 v.sel        v14, v13, v9
    vf.cmp.eq    p1, v5, v10
    vf.cmp.ne    p2, v12, v10
    vf.cmp.o     p3, v12, v12
    p.and        p4, p2, p3
    p.and        p2, p1, p4
    v.xor        v9, v5, v12
    .li       s2, #-2147483648
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v13, v9, v5
    @p2 v.sel        v5, v13, v14
    v.rcp.approx v9, v12                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v13, v12, v9, v11
    vf.fms       v11, v9, v13, v9
    vf.neg       v13, v11                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v13, v13
    @p1 v.sel        v11, v13, v9
    vf.mul       v9, v6, v11                     // a/y: faithful quotient
    vf.fms       v13, v9, v12, v6
    vf.fms       v14, v13, v11, v9
    vf.neg       v11, v14                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v11, v11
    @p1 v.sel        v13, v11, v9
    vf.cmp.eq    p1, v6, v10
    vf.cmp.ne    p2, v12, v10
    vf.cmp.o     p3, v12, v12
    p.and        p4, p2, p3
    p.and        p2, p1, p4
    v.xor        v9, v6, v12
    .li       s2, #-2147483648
    v.splat      v6, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v10, v9, v6
    @p2 v.sel        v6, v10, v13
    vf.cvt.f32.e4m3 v9, v8
    v.movi       v10, #24
    v.lshr       v11, v8, v10
    v.movi       v8, #128
    v.and        v12, v11, v8
    v.or         v11, v9, v12                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v9, v0
    v.lshr       v12, v0, v10
    v.and        v0, v12, v8
    v.or         v12, v9, v0                     // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v0, v1
    v.lshr       v9, v1, v10
    v.and        v1, v9, v8
    v.or         v9, v0, v1                      // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v0, v2
    v.lshr       v1, v2, v10
    v.and        v2, v1, v8
    v.or         v1, v0, v2                      // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v0, v3
    v.lshr       v2, v3, v10
    v.and        v3, v2, v8
    v.or         v2, v0, v3                      // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v0, v4
    v.lshr       v3, v4, v10
    v.and        v4, v3, v8
    v.or         v3, v0, v4                      // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v0, v5
    v.lshr       v4, v5, v10
    v.and        v5, v4, v8
    v.or         v4, v0, v5                      // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cvt.f32.e4m3 v0, v6
    v.lshr       v5, v6, v10
    v.and        v6, v5, v8
    v.or         v5, v0, v6                      // f32 -> f8E4M3FN: a NaN keeps its sign
    s.shli       s2, s12, #0                     // element offset -> bytes (x1)
    s.add        s11, s3, s2                     // &Y[...]
    v.st.b       [s11, #0], v11
    s.shli       s2, s13, #0                     // element offset -> bytes (x1)
    s.add        s11, s3, s2                     // &Y[...]
    v.st.b       [s11, #0], v12
    s.shli       s2, s1, #0                      // element offset -> bytes (x1)
    s.add        s1, s3, s2                      // &Y[...]
    v.st.b       [s1, #0], v9
    s.shli       s1, s6, #0                      // element offset -> bytes (x1)
    s.add        s2, s3, s1                      // &Y[...]
    v.st.b       [s2, #0], v1
    s.shli       s1, s7, #0                      // element offset -> bytes (x1)
    s.add        s2, s3, s1                      // &Y[...]
    v.st.b       [s2, #0], v2
    s.shli       s1, s8, #0                      // element offset -> bytes (x1)
    s.add        s2, s3, s1                      // &Y[...]
    v.st.b       [s2, #0], v3
    s.shli       s1, s9, #0                      // element offset -> bytes (x1)
    s.add        s2, s3, s1                      // &Y[...]
    v.st.b       [s2, #0], v4
    s.shli       s1, s10, #0                     // element offset -> bytes (x1)
    s.add        s2, s3, s1                      // &Y[...]
    v.st.b       [s2, #0], v5
    s.shli       s1, s4, #2                      // element offset -> bytes (x4)
    s.add        s2, s5, s1                      // &S[...]
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p1, v0, #1
    @p1 v.st.w       [s2, #0], v7
__rctx_next:
    exit
