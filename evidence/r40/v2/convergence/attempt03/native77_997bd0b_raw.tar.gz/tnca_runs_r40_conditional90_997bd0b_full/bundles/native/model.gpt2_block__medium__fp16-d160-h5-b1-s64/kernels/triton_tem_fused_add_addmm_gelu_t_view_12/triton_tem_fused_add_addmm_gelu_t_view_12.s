    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.rdspecial  s2, arg_base
    s.ld.d       s3, [s1, #48]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s5, #512
    .li       s6, #2147483647
    s.mul        s7, s1, s5
    .li       s1, #2147483647
    s.movz       s5, #1280
    s.movz       s8, #2
    .li       s9, #68719476752
    .li       s10, #8589934592
    s.rdspecial  s11, arg_base
    s.ld.d       s12, [s2, #8]                   // arg_A: device_ptr64 at arg_base+8
    s.add        s13, s3, s7                     // this context's own scratch
    s.rdspecial  s3, role_id
    s.addi       s7, s13, #0                     // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.movz       s13, #512
    .li       s14, #2147483647
    s.mul        s15, s3, s13
    .li       s3, #2147483647
    s.movz       s13, #1280
    s.movz       s16, #2
    .li       s17, #68719476752
    s.ld.d       s18, [s2, #0]                   // in_ptr0: device_ptr64 at arg_base+0
    .li       s19, #8589934592
    s.movz       s20, #0
    s.movz       s20, #0
    s.ld.d       s20, [s2, #16]                  // arg_B: device_ptr64 at arg_base+16
    s.ld.d       s21, [s2, #24]                  // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s22, [s2, #32]                  // in_ptr4: device_ptr64 at arg_base+32
    s.movz       s23, #10
    s.ld.d       s24, [s2, #40]                  // out_ptr1: device_ptr64 at arg_base+40
    s.movz       s2, #0
    s.st.d       [s7, #0], s12
    s.movz       s12, #0
    s.st.d       [s7, #8], s6
    .li       s6, #2576980378
    s.st.d       [s7, #16], s1
    s.movz       s1, #0
    s.cmp.lt     s25, s23, s1
    s.st.d       [s7, #48], s5
    s.movz       s1, #0
    s.sub        s5, s1, s25
    s.movz       s1, #4
    s.st.d       [s7, #56], s8
    s.cmp.lt     s8, s4, s2
    s.movz       s2, #1
    s.st.d       [s7, #88], s9
    s.sub        s9, s12, s8
    s.movz       s8, #0
    s.xor        s12, s4, s9
    s.st.d       [s7, #104], s10
    s.sub        s10, s12, s9
    fence.release.device
    s.mul        s12, s10, s6
    td.load      d0, [s7]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s6, #0
    s.movz       s7, #0
    s.lshri      s25, s12, #32
    s.ld.d       s12, [s11, #48]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.add        s11, s12, s15                   // this context's own scratch
    s.sub        s12, s10, s25
    s.addi       s15, s11, #256                  // TensorMap 1: a tile contiguous down its columns (built once, at entry)
    s.lshri      s11, s12, #1
    s.xor        s12, s9, s5
    s.add        s9, s25, s11
    s.movz       s11, #0
    s.lshri      s25, s9, #3
    s.st.d       [s15, #0], s20
    s.xor        s9, s25, s12
    s.muli       s20, s25, #10
    s.sub        s25, s9, s12
    s.movz       s9, #0
    s.sub        s12, s1, s25
    s.sub        s1, s10, s20
    s.movz       s1, #1
    s.xor        s10, s23, s5
    s.st.d       [s15, #8], s14
    s.min.s      s14, s12, s2
    s.cmp.lt     s12, s4, s6
    s.movz       s6, #0
    s.sub        s20, s10, s5
    s.st.d       [s15, #16], s3
    s.cmp.lt     s3, s14, s8
    s.sub        s5, s11, s12
    s.st.d       [s15, #48], s13
    s.sub        s8, s7, s3
    s.xor        s3, s4, s5
    s.st.d       [s15, #56], s16
    s.xor        s7, s14, s8
    s.sub        s10, s3, s5
    s.st.d       [s15, #88], s17
    s.sub        s3, s7, s8
    s.addi       s7, s9, #0
    s.st.d       [s15, #104], s19
    fence.release.device
    s.cmp.eq     s8, s3, s1
    td.load      d1, [s15]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s6, #0
    s.mov        s7, s10
    br.nz        s8, sdiv_done_1
    s.movz       s6, #0
    s.movz       s8, #31
    s.mov        s7, s6
    s.addi       s6, s8, #0
sdiv_2:
    s.lshr       s8, s10, s6
    s.shli       s9, s1, #1
    s.andi       s11, s8, #1
    s.movz       s8, #0
    s.or         s12, s9, s11
    s.movz       s9, #1
    s.cmp.geu    s11, s12, s3
    s.shl        s13, s9, s6
    s.sub        s9, s8, s11
    s.subi       s8, s6, #1
    s.and        s11, s3, s9
    s.and        s15, s13, s9
    s.sub        s9, s12, s11
    s.or         s11, s7, s15
    s.mov        s1, s9
    s.mov        s7, s11
    s.mov        s6, s8
    s.movz       s8, #0
    s.cmp.ge     s9, s6, s8
    br.nz        s9, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s6, #0
    s.cmp.lt     s7, s4, s3
    .li       s3, #2576980378
    s.sub        s8, s6, s7
    s.movz       s6, #0
    s.xor        s7, s4, s8
    s.movz       s4, #0
    s.sub        s9, s7, s8
    s.movz       s7, #0
    s.mul        s10, s9, s3
    s.cmp.lt     s3, s14, s6
    s.movz       s6, #0
    s.sub        s11, s7, s3
    s.movz       s3, #0
    s.lshri      s7, s10, #32
    s.cmp.lt     s10, s23, s6
    s.xor        s6, s14, s11
    s.xor        s12, s1, s5
    s.sub        s1, s6, s11
    s.sub        s6, s12, s5
    s.sub        s5, s9, s7
    s.add        s12, s25, s6
    s.lshri      s6, s5, #1
    s.movz       s5, #0
    s.add        s13, s7, s6
    s.sub        s6, s5, s10
    s.lshri      s5, s13, #3
    s.movz       s7, #0
    s.muli       s10, s5, #10
    s.movz       s5, #1
    s.xor        s13, s23, s6
    s.addi       s14, s7, #0
    s.cmp.eq     s7, s1, s5
    s.sub        s5, s9, s10
    s.movz       s9, #0
    s.xor        s10, s5, s8
    s.sub        s5, s13, s6
    s.sub        s5, s10, s8
    s.addi       s6, s9, #0
    s.cmp.lt     s8, s5, s4
    s.sub        s4, s3, s8
    s.xor        s3, s5, s4
    s.sub        s5, s3, s4
    s.mov        s14, s5
    br.nz        s7, sdiv_done_3
    s.movz       s3, #0
    s.movz       s7, #31
    s.mov        s14, s3
    s.addi       s3, s7, #0
sdiv_4:
    s.lshr       s7, s5, s3
    s.shli       s8, s6, #1
    s.andi       s9, s7, #1
    s.movz       s7, #0
    s.or         s10, s8, s9
    s.movz       s8, #1
    s.cmp.geu    s9, s10, s1
    s.shl        s13, s8, s3
    s.sub        s8, s7, s9
    s.subi       s7, s3, #1
    s.and        s9, s1, s8
    s.and        s15, s13, s8
    s.sub        s8, s10, s9
    s.or         s9, s14, s15
    s.mov        s6, s8
    s.mov        s14, s9
    s.mov        s3, s7
    s.movz       s7, #0
    s.cmp.ge     s8, s3, s7
    br.nz        s8, sdiv_4
sdiv_done_3:
    s.xor        s1, s4, s11
    s.movz       s3, #16
    s.xor        s4, s14, s1
    .li       s5, #2576980378
    s.sub        s6, s4, s1
    s.mul        s1, s12, s3
    s.mul        s4, s6, s3
    s.movz       s7, #0
    v.splat      v0, s12
    v.splat      v1, s7
    s.andi       s8, s1, #63
    s.mul        s9, s4, s5
    v.splat      v2, s6
    v.splat      v3, s7
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s1
    s.lshri      s5, s9, #32
    v.cmp.ge     p1, v0, v1
    s.sub        s6, s4, s5
    v.splat      v0, s4
    s.lshri      s9, s6, #1
    v.splat      v1, s8
    s.add        s6, s5, s9
    v.cmp.ge     p1, v2, v3
    s.lshri      s5, s6, #7
    v.iota       v2                              // arange(0, VLEN)
    s.muli       s6, s5, #160
    v.iota       v3                              // arange(0, VLEN)
    v.add        v6, v5, v4
    v.add        v5, v0, v4
    v.add        v0, v1, v2
    s.sub        s5, s4, s6
    s.movz       s6, #40
    v.splat      v0, s5
    s.addi       s9, s7, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    v.add        v1, v0, v3
for_5:
    s.cmp.ge     s7, s9, s6
    br.nz        s7, endfor_6
    s.mul        s7, s9, s3
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s10, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s11, s9, s2
    s.movz       s12, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s13, s8                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s14, s7                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s13, s10
    mb.wait      s10
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s13, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s14, s5                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s7                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s14, s13
    mb.wait      s13
    mb.arm       s7, b2, #0, #1                  // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.f16 a0, v56, v48, s7
    mb.wait      s7
    s.mov        s9, s11
    br.nz        s12, for_5
endfor_6:
    s.movz       s2, #0
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s3, #0
    s.add        s5, s2, s4                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s2, s4, #2                      // a runtime tile origin, x2
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s6, s4, #2                      // a runtime tile origin, x2
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s5
    s.add        s5, s3, s1                      // the tile origin
    s.movz       s3, #64
    s.movz       s8, #160
    v.splat      v2, s5
    v.splat      v3, s3
    s.muli       s3, s4, #2                      // a runtime tile origin, x2
    v.add        v4, v0, v1
    v.splat      v0, s8
    s.muli       s8, s1, #320                    // a runtime tile origin, x320
    v.splat      v1, s5
    v.splat      v5, s5
    s.add        s9, s21, s2                     // the tile origin
    s.muli       s2, s1, #320                    // a runtime tile origin, x320
    s.add        s11, s22, s6                    // the tile origin
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v4, v0
    v.cmp.lt     p3, v1, v3
    s.add        s6, s18, s3                     // the tile origin
    s.add        s3, s9, s8                      // the tile origin
    s.add        s8, s11, s2                     // the tile origin
    p.and        p4, p1, p2
    p.and        p1, p3, p2
    s.movz       s2, #0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v0, [s3, #0]
    v.cmp.lt     p3, v5, v3
    p.and        p4, p3, p2
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s9, s4, #2                      // a runtime tile origin, x2
    s.addi       s4, s5, #1
    s.muli       s11, s1, #320                   // a runtime tile origin, x320
    v.splat      v1, s5
    v.splat      v2, s4
    s.add        s1, s24, s9                     // the tile origin
    s.addi       s4, s3, #320                    // row 1
    s.add        s9, s1, s11                     // the tile origin
    s.addi       s1, s5, #1
    s.addi       s11, s5, #1
    v.splat      v4, s1
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v5, [s8, #0]
    a.vread      v6, a0, s2
    vf.cvt.f16.f32 v7, v0
    v.splat      v0, s11
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    s.addi       s1, s8, #320                    // row 1
    s.movz       s2, #1
    s.addi       s11, s5, #1
    s.addi       s12, s9, #320                   // row 1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v1, [s6, #0]
    vf.cvt.f16.f32 v8, v5
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    v.splat      v2, s11
    vf.add       v5, v7, v8
    s.addi       s11, s5, #2
    s.addi       s14, s3, #640                   // row 2
    v.splat      v7, s11
    vf.cvt.f16.f32 v8, v1
    vf.add       v1, v6, v8
    vf.cvt.f32.f16 v6, v1
    vf.cvt.f16.f32 v1, v6
    s.addi       s11, s8, #640                   // row 2
    vf.add       v6, v5, v1
    vf.cvt.f32.f16 v1, v6
    @p3 v.st.h       [s9, #0], v1
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v1, [s4, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s4, s5, #2
    v.splat      v0, s4
    s.addi       s4, s5, #2
    v.splat      v4, s4
    s.movz       s4, #2
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v5, [s1, #0]
    a.vread      v6, a0, s2
    vf.cvt.f16.f32 v8, v1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v1, [s6, #0]
    vf.cvt.f16.f32 v2, v5
    v.cmp.lt     p1, v7, v3
    p.and        p4, p1, p2
    vf.add       v5, v8, v2
    s.addi       s1, s5, #2
    s.addi       s2, s5, #3
    v.splat      v2, s1
    s.addi       s1, s9, #640                    // row 2
    vf.cvt.f16.f32 v7, v1
    v.splat      v1, s2
    s.addi       s2, s3, #960                    // row 3
    vf.add       v8, v6, v7
    vf.cvt.f32.f16 v6, v8
    vf.cvt.f16.f32 v7, v6
    vf.add       v6, v5, v7
    vf.cvt.f32.f16 v5, v6
    @p3 v.st.h       [s12, #0], v5
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s12, s5, #3
    v.splat      v0, s12
    s.addi       s12, s5, #3
    v.splat      v5, s12
    s.addi       s12, s8, #960                   // row 3
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s14, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    s.movz       s14, #3
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s11, #0]
    a.vread      v7, a0, s4
    vf.cvt.f16.f32 v8, v6
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s6, #0]
    vf.cvt.f16.f32 v6, v4
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    vf.add       v1, v8, v6
    s.addi       s4, s5, #3
    s.addi       s11, s5, #4
    v.splat      v4, s4
    s.addi       s4, s9, #960                    // row 3
    vf.cvt.f16.f32 v6, v2
    v.splat      v2, s11
    s.addi       s11, s3, #1280                  // row 4
    vf.add       v8, v7, v6
    vf.cvt.f32.f16 v6, v8
    vf.cvt.f16.f32 v7, v6
    vf.add       v6, v1, v7
    vf.cvt.f32.f16 v1, v6
    @p3 v.st.h       [s1, #0], v1
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s1, s5, #4
    v.splat      v0, s1
    s.addi       s1, s5, #4
    v.splat      v1, s1
    s.addi       s1, s8, #1280                   // row 4
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s2, #0]
    v.cmp.lt     p1, v5, v3
    p.and        p4, p1, p2
    s.movz       s2, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v5, [s12, #0]
    a.vread      v7, a0, s14
    vf.cvt.f16.f32 v8, v6
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s6, #0]
    vf.cvt.f16.f32 v6, v5
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    vf.add       v2, v8, v6
    s.addi       s12, s5, #4
    s.addi       s14, s5, #5
    v.splat      v5, s12
    s.addi       s12, s9, #1280                  // row 4
    vf.cvt.f16.f32 v6, v4
    v.splat      v4, s14
    s.addi       s14, s3, #1600                  // row 5
    vf.add       v8, v7, v6
    vf.cvt.f32.f16 v6, v8
    vf.cvt.f16.f32 v7, v6
    vf.add       v6, v2, v7
    vf.cvt.f32.f16 v2, v6
    @p3 v.st.h       [s4, #0], v2
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s4, s5, #5
    v.splat      v0, s4
    s.addi       s4, s5, #5
    v.splat      v2, s4
    s.addi       s4, s8, #1600                   // row 5
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s11, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.movz       s11, #5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s1, #0]
    a.vread      v7, a0, s2
    vf.cvt.f16.f32 v8, v6
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v5, [s6, #0]
    vf.cvt.f16.f32 v6, v1
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    vf.add       v1, v8, v6
    s.addi       s1, s5, #5
    s.addi       s2, s5, #6
    v.splat      v4, s1
    s.addi       s1, s9, #1600                   // row 5
    vf.cvt.f16.f32 v6, v5
    v.splat      v5, s2
    s.addi       s2, s3, #1920                   // row 6
    vf.add       v8, v7, v6
    vf.cvt.f32.f16 v6, v8
    vf.cvt.f16.f32 v7, v6
    vf.add       v6, v1, v7
    vf.cvt.f32.f16 v1, v6
    @p3 v.st.h       [s12, #0], v1
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s12, s5, #6
    v.splat      v0, s12
    s.addi       s12, s5, #6
    v.splat      v1, s12
    s.addi       s12, s8, #1920                  // row 6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s14, #0]
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.movz       s14, #6
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s4, #0]
    a.vread      v7, a0, s11
    vf.cvt.f16.f32 v8, v6
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s6, #0]
    vf.cvt.f16.f32 v6, v2
    v.cmp.lt     p1, v5, v3
    p.and        p4, p1, p2
    vf.add       v2, v8, v6
    s.addi       s4, s5, #6
    s.addi       s11, s5, #7
    v.splat      v5, s4
    s.addi       s4, s9, #1920                   // row 6
    vf.cvt.f16.f32 v6, v4
    v.splat      v4, s11
    s.addi       s11, s3, #2240                  // row 7
    vf.add       v8, v7, v6
    vf.cvt.f32.f16 v6, v8
    vf.cvt.f16.f32 v7, v6
    vf.add       v6, v2, v7
    vf.cvt.f32.f16 v2, v6
    @p3 v.st.h       [s1, #0], v2
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s1, s5, #7
    v.splat      v0, s1
    s.addi       s1, s5, #7
    v.splat      v2, s1
    s.addi       s1, s8, #2240                   // row 7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s2, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.movz       s2, #7
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s12, #0]
    a.vread      v7, a0, s14
    vf.cvt.f16.f32 v8, v6
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v5, [s6, #0]
    vf.cvt.f16.f32 v6, v1
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    vf.add       v1, v8, v6
    s.addi       s12, s5, #7
    s.addi       s14, s5, #8
    v.splat      v4, s12
    s.addi       s12, s9, #2240                  // row 7
    vf.cvt.f16.f32 v6, v5
    v.splat      v5, s14
    s.addi       s14, s3, #2560                  // row 8
    vf.add       v8, v7, v6
    vf.cvt.f32.f16 v6, v8
    vf.cvt.f16.f32 v7, v6
    vf.add       v6, v1, v7
    vf.cvt.f32.f16 v1, v6
    @p3 v.st.h       [s4, #0], v1
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s4, s5, #8
    v.splat      v0, s4
    s.addi       s4, s5, #8
    v.splat      v1, s4
    s.addi       s4, s8, #2560                   // row 8
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s11, #0]
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.movz       s11, #8
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s1, #0]
    a.vread      v7, a0, s2
    vf.cvt.f16.f32 v8, v6
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s6, #0]
    vf.cvt.f16.f32 v6, v2
    v.cmp.lt     p1, v5, v3
    p.and        p4, p1, p2
    vf.add       v2, v8, v6
    s.addi       s1, s5, #8
    s.addi       s2, s5, #9
    v.splat      v5, s1
    s.addi       s1, s9, #2560                   // row 8
    vf.cvt.f16.f32 v6, v4
    v.splat      v4, s2
    s.addi       s2, s3, #2880                   // row 9
    vf.add       v8, v7, v6
    vf.cvt.f32.f16 v6, v8
    vf.cvt.f16.f32 v7, v6
    vf.add       v6, v2, v7
    vf.cvt.f32.f16 v2, v6
    @p3 v.st.h       [s12, #0], v2
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s12, s5, #9
    v.splat      v0, s12
    s.addi       s12, s5, #9
    v.splat      v2, s12
    s.addi       s12, s8, #2880                  // row 9
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s14, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.movz       s14, #9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s4, #0]
    a.vread      v7, a0, s11
    vf.cvt.f16.f32 v8, v6
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v5, [s6, #0]
    vf.cvt.f16.f32 v6, v1
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    vf.add       v1, v8, v6
    s.addi       s4, s5, #9
    s.addi       s11, s5, #10
    v.splat      v4, s4
    s.addi       s4, s9, #2880                   // row 9
    vf.cvt.f16.f32 v6, v5
    v.splat      v5, s11
    s.addi       s11, s3, #3200                  // row 10
    vf.add       v8, v7, v6
    vf.cvt.f32.f16 v6, v8
    vf.cvt.f16.f32 v7, v6
    vf.add       v6, v1, v7
    vf.cvt.f32.f16 v1, v6
    @p3 v.st.h       [s1, #0], v1
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s1, s5, #10
    v.splat      v0, s1
    s.addi       s1, s5, #10
    v.splat      v1, s1
    s.addi       s1, s8, #3200                   // row 10
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s2, #0]
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.movz       s2, #10
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s12, #0]
    a.vread      v7, a0, s14
    vf.cvt.f16.f32 v8, v6
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s6, #0]
    vf.cvt.f16.f32 v6, v2
    v.cmp.lt     p1, v5, v3
    p.and        p4, p1, p2
    vf.add       v2, v8, v6
    s.addi       s12, s5, #10
    s.addi       s14, s5, #11
    v.splat      v5, s12
    s.addi       s12, s9, #3200                  // row 10
    vf.cvt.f16.f32 v6, v4
    v.splat      v4, s14
    s.addi       s14, s3, #3520                  // row 11
    vf.add       v8, v7, v6
    vf.cvt.f32.f16 v6, v8
    vf.cvt.f16.f32 v7, v6
    vf.add       v6, v2, v7
    vf.cvt.f32.f16 v2, v6
    @p3 v.st.h       [s4, #0], v2
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s4, s5, #11
    v.splat      v0, s4
    s.addi       s4, s5, #11
    v.splat      v2, s4
    s.addi       s4, s8, #3520                   // row 11
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s11, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.movz       s11, #11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s1, #0]
    a.vread      v7, a0, s2
    vf.cvt.f16.f32 v8, v6
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v5, [s6, #0]
    vf.cvt.f16.f32 v6, v1
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    vf.add       v1, v8, v6
    s.addi       s1, s5, #11
    s.addi       s2, s5, #12
    v.splat      v4, s1
    s.addi       s1, s9, #3520                   // row 11
    vf.cvt.f16.f32 v6, v5
    v.splat      v5, s2
    s.addi       s2, s3, #3840                   // row 12
    vf.add       v8, v7, v6
    vf.cvt.f32.f16 v6, v8
    vf.cvt.f16.f32 v7, v6
    vf.add       v6, v1, v7
    vf.cvt.f32.f16 v1, v6
    @p3 v.st.h       [s12, #0], v1
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s12, s5, #12
    v.splat      v0, s12
    s.addi       s12, s5, #12
    v.splat      v1, s12
    s.addi       s12, s8, #3840                  // row 12
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s14, #0]
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.movz       s14, #12
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s4, #0]
    a.vread      v7, a0, s11
    vf.cvt.f16.f32 v8, v6
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s6, #0]
    vf.cvt.f16.f32 v6, v2
    v.cmp.lt     p1, v5, v3
    p.and        p4, p1, p2
    vf.add       v2, v8, v6
    s.addi       s4, s5, #12
    s.addi       s11, s5, #13
    v.splat      v5, s4
    s.addi       s4, s9, #3840                   // row 12
    vf.cvt.f16.f32 v6, v4
    v.splat      v4, s11
    s.addi       s11, s3, #4160                  // row 13
    vf.add       v8, v7, v6
    vf.cvt.f32.f16 v6, v8
    vf.cvt.f16.f32 v7, v6
    vf.add       v6, v2, v7
    vf.cvt.f32.f16 v2, v6
    @p3 v.st.h       [s1, #0], v2
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s1, s5, #13
    v.splat      v0, s1
    s.addi       s1, s5, #13
    v.splat      v2, s1
    s.addi       s1, s8, #4160                   // row 13
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s2, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.movz       s2, #13
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s12, #0]
    a.vread      v7, a0, s14
    vf.cvt.f16.f32 v8, v6
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v5, [s6, #0]
    vf.cvt.f16.f32 v6, v1
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    vf.add       v1, v8, v6
    s.addi       s12, s5, #13
    s.addi       s14, s5, #14
    v.splat      v4, s12
    s.addi       s12, s9, #4160                  // row 13
    vf.cvt.f16.f32 v6, v5
    v.splat      v5, s14
    s.addi       s14, s3, #4480                  // row 14
    vf.add       v8, v7, v6
    vf.cvt.f32.f16 v6, v8
    vf.cvt.f16.f32 v7, v6
    vf.add       v6, v1, v7
    vf.cvt.f32.f16 v1, v6
    @p3 v.st.h       [s4, #0], v1
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s4, s5, #14
    v.splat      v0, s4
    s.addi       s4, s5, #14
    v.splat      v1, s4
    s.addi       s4, s8, #4480                   // row 14
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s11, #0]
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.movz       s11, #14
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s1, #0]
    a.vread      v7, a0, s2
    vf.cvt.f16.f32 v8, v6
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s6, #0]
    vf.cvt.f16.f32 v6, v2
    v.cmp.lt     p1, v5, v3
    p.and        p4, p1, p2
    vf.add       v2, v8, v6
    s.addi       s1, s5, #14
    s.addi       s2, s5, #15
    v.splat      v5, s1
    s.addi       s1, s9, #4480                   // row 14
    s.addi       s15, s3, #4800                  // row 15
    vf.cvt.f16.f32 v6, v4
    v.splat      v4, s2
    vf.add       v8, v7, v6
    vf.cvt.f32.f16 v6, v8
    vf.cvt.f16.f32 v7, v6
    vf.add       v6, v2, v7
    vf.cvt.f32.f16 v2, v6
    s.addi       s2, s5, #15
    s.addi       s3, s8, #4800                   // row 15
    v.splat      v6, s2
    @p3 v.st.h       [s12, #0], v2
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s2, s5, #15
    s.movz       s8, #15
    v.splat      v0, s2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s14, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s4, #0]
    a.vread      v7, a0, s11
    vf.cvt.f16.f32 v8, v2
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s6, #0]
    vf.cvt.f16.f32 v5, v1
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    vf.add       v1, v8, v5
    s.addi       s2, s5, #15
    s.addi       s4, s9, #4800                   // row 15
    v.splat      v4, s2
    vf.cvt.f16.f32 v5, v2
    vf.add       v2, v7, v5
    vf.cvt.f32.f16 v5, v2
    vf.cvt.f16.f32 v2, v5
    vf.add       v5, v1, v2
    vf.cvt.f32.f16 v1, v5
    @p3 v.st.h       [s1, #0], v1
    v.cmp.lt     p1, v6, v3
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v1, [s15, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s3, #0]
    a.vread      v2, a0, s8
    vf.cvt.f16.f32 v5, v1
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v1, [s6, #0]
    vf.cvt.f16.f32 v3, v0
    vf.add       v0, v5, v3
    vf.cvt.f16.f32 v3, v1
    vf.add       v1, v2, v3
    vf.cvt.f32.f16 v2, v1
    vf.cvt.f16.f32 v1, v2
    vf.add       v2, v0, v1
    vf.cvt.f32.f16 v0, v2
    @p3 v.st.h       [s4, #0], v0
__rctx_next:
    exit
