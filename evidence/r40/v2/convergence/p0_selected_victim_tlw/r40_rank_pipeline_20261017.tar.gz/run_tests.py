import itertools,json,subprocess
from pathlib import Path
root=Path.cwd();out=root/'results';out.mkdir(exist_ok=False);records=[]
def run(name,cmd,expect=0):
    result=subprocess.run(cmd,capture_output=True,text=True,timeout=900)
    text=result.stdout+result.stderr;(out/(name+'.log')).write_text(text)
    if result.returncode!=expect:raise RuntimeError(name+' exit '+str(result.returncode)+'\n'+text[-4000:])
    return text
def build(name,select,owner,ranges,policy,churn,source='rtl/nuca/tnca_nuca_slice.v'):
    binary=str(out/(name+'.vvp'))
    args=['iverilog','-g2012','-I','rtl/common','-s','tb_nuca_slice',
          '-Ptb_nuca_slice.SETS=32','-Ptb_nuca_slice.SET_W=5','-Ptb_nuca_slice.WAYS=8','-Ptb_nuca_slice.WAY_W=3',
          '-Ptb_nuca_slice.SYNC_TAG_BANK=1','-Ptb_nuca_slice.BALANCED_VICTIM=1',
          '-Ptb_nuca_slice.MAINTENANCE=1',f'-Ptb_nuca_slice.REGISTER_VICTIM_SELECT={select}',
          f'-Ptb_nuca_slice.REGISTER_VICTIM_OWNER={owner}',f'-Ptb_nuca_slice.DCO_REGISTERED_RANGES={ranges}',
          f'-Ptb_nuca_slice.POLICY={policy}',f'-Ptb_nuca_slice.EPOCH_CHURN={churn}',
          '-o',binary,source,'tb/common/tnca_dram_model.v','tb/nuca/tb_nuca_slice.v']
    run(name+'_build',args);return binary
def traffic(name,select,owner,ranges,policy,churn,seeds,nreq=20000):
    binary=build(name,select,owner,ranges,policy,churn)
    for seed in seeds:
        case=name+'_seed'+str(seed)
        text=run(case,['vvp',binary,f'+nreq={nreq}',f'+seed={seed}','+min_wb=1'])
        assert 'PASS' in text.splitlines() and '\nFAIL' not in text and 'FATAL' not in text,text
        records.append(dict(name=case,status='functional-pass',select=select,owner=owner,ranges=ranges,policy=policy,churn=churn,nreq=nreq))
        (out/'results.json').write_text(json.dumps(records,indent=2)+'\n');print('PASS',case,flush=True)
for ranges,policy in itertools.product((0,1),(0,1,2,46,74)):
    traffic(f'select_range{ranges}_policy{policy}',1,1,ranges,policy,3,(1,7))
for select,churn in ((0,1),(1,1),(1,2),(1,4)):
    traffic(f'epoch_select{select}_churn{churn}',select,1,1,74,churn,(7,),4000)
for latency,stall,full in itertools.product((1,8),(0,1),(0,1)):
    name=f'maint_lat{latency}_stall{stall}_full{full}';binary=str(out/(name+'.vvp'))
    run(name+'_build',['iverilog','-g2012','-I','rtl/common','-s','tb_nuca_maintenance',f'-Ptb_nuca_maintenance.LATENCY={latency}',f'-Ptb_nuca_maintenance.STALL={stall}',f'-Ptb_nuca_maintenance.FULL_TAG={full}','-o',binary,'rtl/nuca/tnca_nuca_slice.v','tb/common/tnca_dram_model.v','tb/nuca/tb_nuca_maintenance.v'])
    text=run(name,['vvp',binary]);assert 'PASS' in text and 'FATAL' not in text and 'FAIL' not in text,text
    records.append(dict(name=name,status='functional-pass'));(out/'results.json').write_text(json.dumps(records,indent=2)+'\n');print('PASS',name,flush=True)
original=(root/'rtl/nuca/tnca_nuca_slice.v').read_text()
for name,needle,churn in [('owner_guard','if (REGISTER_VICTIM_OWNER && owner_epoch_q != dco_owner_epoch)',1),('select_guard','(REGISTER_VICTIM_SELECT && selected_epoch_q != dco_owner_epoch)',4),('rank_guard','if(rank_epoch_q != dco_owner_epoch)',2)]:
    assert original.count(needle)==1
    mutant=out/(name+'.v');mutant.write_text(original.replace(needle,"if (1'b0)" if name in ('owner_guard','rank_guard') else "(1'b0)",1))
    binary=build('mutation_'+name,1,1,1,74,churn,str(mutant))
    text=run('mutation_'+name,['vvp',binary,'+nreq=4000','+seed=7'],1)
    assert 'stale owner classification consumed instead of retried' in text,text
    records.append(dict(name='mutation_'+name,status='expected-failure-detected'));print('MUTATION CAUGHT',name,flush=True)
(out/'results.json').write_text(json.dumps(records,indent=2)+'\n')
print('VICTIM_SELECT_FUNCTIONAL_SCREEN_DONE',flush=True)
