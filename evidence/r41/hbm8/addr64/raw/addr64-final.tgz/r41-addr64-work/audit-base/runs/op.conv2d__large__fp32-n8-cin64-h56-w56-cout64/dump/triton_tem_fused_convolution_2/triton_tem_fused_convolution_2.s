    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    v.movi       v1, #56
    v.movi       v2, #0
    s.rdspecial  s3, arg_base
    v.movi       v3, #1
    v.splat      v4, s2
    v.sub        v5, v2, v1
    v.cmp.lt     p1, v1, v2
    v.add        v6, v4, v0
    s.ld.d       s2, [s3, #0]                    // arg_X: device_ptr64 at arg_base+0
    @p1 v.sel        v4, v5, v1
    v.sub        v5, v2, v6
    v.cmp.lt     p1, v6, v2
    v.movi       v7, #0
    @p1 v.sel        v8, v5, v6
    v.movi       v5, #0
    s.movz       s4, #31
    s.ld.d       s5, [s3, #8]                    // arg_W: device_ptr64 at arg_base+8
    s.ld.d       s6, [s3, #16]                   // out_ptr0: device_ptr64 at arg_base+16
idiv_1:
    v.splat      v9, s4
    v.shl        v10, v5, v3
    v.cmp.lt     p2, v5, v2
    v.lshr       v11, v8, v9
    v.shl        v12, v3, v9
    s.subi       s3, s4, #1
    v.and        v9, v11, v3
    s.movz       s7, #0
    v.or         v11, v10, v9
    v.cmp.geu    p3, v11, v4
    p.or         p4, p2, p3
    v.sub        v9, v11, v4
    @p4 v.sel        v10, v12, v2
    @p4 v.sel        v12, v9, v11
    v.or         v9, v7, v10
    v.mov        v5, v12
    v.mov        v7, v9
    s.mov        s4, s3
    s.cmp.ge     s3, s4, s7
    br.nz        s3, idiv_1
    v.movi       v3, #0
    v.sub        v4, v2, v5
    v.movi       v2, #1
    v.sub        v7, v3, v6
    v.sub        v8, v3, v1
    v.cmp.lt     p2, v6, v3
    v.cmp.lt     p3, v1, v3
    @p1 v.sel        v9, v4, v5
    @p2 v.sel        v4, v7, v6
    @p3 v.sel        v5, v8, v1
    v.movi       v6, #0
    v.movi       v7, #0
    s.movz       s3, #31
idiv_2:
    v.splat      v8, s3
    v.shl        v10, v7, v2
    v.cmp.lt     p1, v7, v3
    v.lshr       v11, v4, v8
    v.shl        v12, v2, v8
    s.subi       s4, s3, #1
    v.and        v8, v11, v2
    s.movz       s7, #0
    v.or         v11, v10, v8
    v.cmp.geu    p4, v11, v5
    p.or         p5, p1, p4
    v.sub        v8, v11, v5
    @p5 v.sel        v10, v12, v3
    @p5 v.sel        v12, v8, v11
    v.or         v8, v6, v10
    v.mov        v7, v12
    v.mov        v6, v8
    s.mov        s3, s4
    s.cmp.ge     s4, s3, s7
    br.nz        s4, idiv_2
    v.sub        v2, v3, v6
    p.xor        p1, p2, p3
    v.movi       v3, #0
    @p1 v.sel        v4, v2, v6
    v.movi       v2, #1
    v.sub        v5, v3, v1
    v.sub        v6, v3, v4
    v.cmp.lt     p1, v4, v3
    v.cmp.lt     p2, v1, v3
    @p1 v.sel        v7, v6, v4
    @p2 v.sel        v6, v5, v1
    v.movi       v5, #0
    v.movi       v8, #0
    s.movz       s3, #31
idiv_3:
    v.splat      v10, s3
    v.shl        v11, v8, v2
    v.cmp.lt     p2, v8, v3
    v.lshr       v12, v7, v10
    v.shl        v13, v2, v10
    s.subi       s4, s3, #1
    v.and        v10, v12, v2
    s.movz       s7, #0
    v.or         v12, v11, v10
    v.cmp.geu    p3, v12, v6
    p.or         p4, p2, p3
    v.sub        v10, v12, v6
    @p4 v.sel        v11, v13, v3
    @p4 v.sel        v13, v10, v12
    v.or         v10, v5, v11
    v.mov        v8, v13
    v.mov        v5, v10
    s.mov        s3, s4
    s.cmp.ge     s4, s3, s7
    br.nz        s4, idiv_3
    v.movi       v2, #0
    v.sub        v5, v3, v8
    v.movi       v3, #1
    v.sub        v6, v2, v4
    v.sub        v7, v2, v1
    v.cmp.lt     p2, v4, v2
    v.cmp.lt     p3, v1, v2
    @p1 v.sel        v10, v5, v8
    @p2 v.sel        v5, v6, v4
    @p3 v.sel        v4, v7, v1
    v.movi       v6, #0
    v.movi       v7, #0
    s.movz       s3, #31
idiv_4:
    v.splat      v8, s3
    v.shl        v11, v7, v3
    v.cmp.lt     p1, v7, v2
    v.lshr       v12, v5, v8
    v.shl        v13, v3, v8
    s.subi       s4, s3, #1
    v.and        v8, v12, v3
    s.movz       s7, #0
    v.or         v12, v11, v8
    v.cmp.geu    p4, v12, v4
    p.or         p5, p1, p4
    v.sub        v8, v12, v4
    @p5 v.sel        v11, v13, v2
    @p5 v.sel        v13, v8, v12
    v.or         v8, v6, v11
    v.mov        v7, v13
    v.mov        v6, v8
    s.mov        s3, s4
    s.cmp.ge     s4, s3, s7
    br.nz        s4, idiv_4
    s.rdspecial  s3, pid.y
    s.rdspecial  s4, arg_base
    v.sub        v3, v2, v6
    s.mul        s7, s3, s1
    s.ld.d       s3, [s4, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    p.xor        p1, p2, p3
    .li       s4, #200704
    v.splat      v2, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v4, v3, v6
    s.rdspecial  s4, role_id
    s.movz       s8, #4160
    v.splat      v3, s7
    v.mul        v5, v4, v2
    s.mul        s9, s4, s8
    v.add        v2, v3, v0
    s.movz       s4, #0
    v.extract    s8, v5, #0
    v.extract    s10, v5, #1
    v.extract    s11, v5, #2
    v.extract    s12, v5, #3
    v.extract    s13, v5, #4
    v.extract    s14, v5, #5
    v.extract    s15, v5, #6
    s.add        s16, s3, s9                     // this context's own scratch
    v.extract    s3, v5, #7
    v.splat      v3, s4
    v.splat      v6, s8
    v.splat      v7, s10
    v.splat      v8, s11
    v.splat      v11, s12
    v.splat      v12, s13
    s.addi       s8, s16, #0
    v.add        v13, v3, v6
    v.add        v6, v3, v7
    v.add        v7, v3, v8
    v.add        v8, v3, v11
    v.add        v11, v3, v12
    s.addi       s9, s8, #64
    s.addi       s10, s8, #128
    s.addi       s11, s8, #192
    s.addi       s12, s8, #256
    v.st.w       [s8, #0], v13
    v.splat      v12, s14
    s.addi       s13, s8, #320
    v.add        v13, v3, v12
    v.st.w       [s9, #0], v6
    v.splat      v6, s15
    s.addi       s9, s8, #384
    s.addi       s14, s8, #448
    v.add        v12, v3, v6
    v.st.w       [s10, #0], v7
    .li       s10, #200704
    v.splat      v6, s3
    v.extract    s3, v5, #8
    v.add        v7, v3, v6
    v.st.w       [s11, #0], v8
    v.extract    s11, v5, #9
    v.splat      v6, s3
    v.extract    s3, v5, #10
    v.add        v8, v3, v6
    v.st.w       [s12, #0], v11
    v.extract    s12, v5, #11
    v.splat      v6, s11
    v.extract    s11, v5, #12
    v.add        v11, v3, v6
    v.st.w       [s13, #0], v13
    v.extract    s13, v5, #13
    v.splat      v6, s3
    v.extract    s3, v5, #14
    s.movz       s15, #576
    v.add        v13, v3, v6
    v.st.w       [s9, #0], v12
    v.movi       v6, #576
    v.extract    s9, v5, #15
    v.splat      v5, s12
    v.mul        v12, v2, v6
    s.addi       s12, s8, #512
    v.add        v6, v3, v5
    v.st.w       [s14, #0], v7
    v.splat      v5, s11
    s.addi       s11, s8, #576
    s.addi       s14, s8, #640
    v.add        v7, v3, v5
    v.st.w       [s12, #0], v8
    v.splat      v5, s13
    s.addi       s12, s8, #704
    s.addi       s13, s8, #768
    v.add        v8, v3, v5
    v.st.w       [s11, #0], v11
    v.splat      v5, s3
    s.addi       s3, s8, #832
    s.addi       s11, s8, #896
    v.add        v11, v3, v5
    s.addi       s15, s8, #960
    v.st.w       [s14, #0], v13
    v.splat      v5, s9
    s.addi       s8, s16, #1024
    s.movz       s9, #36
    v.add        v13, v3, v5
    v.splat      v3, s4
    v.add        v5, v3, v12
    v.st.w       [s12, #0], v6
    s.movz       s12, #1
    v.st.w       [s13, #0], v7
    s.addi       s13, s4, #0
    v.st.w       [s3, #0], v8
    v.st.w       [s11, #0], v11
    v.st.w       [s15, #0], v13
    fence.acq_rel.device
    v.st.w       [s8, #0], v5
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s3, s13, s9
    br.nz        s3, endfor_6
    s.movz       s3, #0
    s.movz       s8, #0
    s.cmp.lt     s11, s13, s3
    s.movz       s3, #4
    s.sub        s14, s8, s11
    s.movz       s8, #0
    s.movz       s11, #0
    s.cmp.lt     s15, s3, s8
    s.xor        s8, s13, s14
    s.sub        s17, s11, s15
    s.sub        s11, s8, s14
    s.xor        s8, s14, s17
    s.lshri      s14, s11, #2
    s.movz       s15, #0
    s.xor        s18, s14, s8
    s.movz       s19, #0
    s.sub        s20, s18, s8
    s.movz       s8, #0
    s.cmp.lt     s18, s20, s15
    s.movz       s15, #0
    s.sub        s21, s19, s18
    .li       s18, #1431655766
    s.xor        s19, s20, s21
    s.cmp.lt     s22, s13, s8
    s.sub        s8, s19, s21
    s.sub        s19, s15, s22
    s.mul        s15, s8, s18
    s.movz       s18, #3
    s.movz       s22, #0
    s.muli       s23, s14, #4
    s.cmp.lt     s14, s18, s22
    s.lshri      s22, s15, #32
    s.sub        s15, s11, s23
    s.xor        s11, s13, s19
    s.movz       s15, #0
    s.sub        s23, s11, s19
    s.sub        s11, s15, s14
    s.lshri      s14, s23, #2
    s.muli       s15, s14, #4
    s.sub        s14, s23, s15
    s.movz       s15, #0
    s.xor        s23, s14, s19
    s.cmp.lt     s14, s3, s15
    s.sub        s15, s23, s19
    s.movz       s19, #0
    s.mul        s23, s15, s1
    s.sub        s15, s8, s22
    s.sub        s24, s19, s14
    s.lshri      s14, s15, #1
    s.xor        s15, s3, s24
    s.add        s19, s22, s14
    s.xor        s14, s21, s11
    s.lshri      s21, s19, #1
    s.xor        s19, s3, s17
    s.muli       s3, s21, #3
    s.sub        s22, s15, s24
    s.movz       s15, #0
    s.movz       s22, #0
    s.cmp.lt     s24, s20, s15
    s.xor        s15, s21, s14
    s.sub        s21, s22, s24
    .li       s22, #1431655766
    s.xor        s24, s20, s21
    s.sub        s20, s15, s14
    s.sub        s14, s24, s21
    s.movz       s15, #0
    s.mul        s24, s14, s22
    s.cmp.lt     s22, s18, s15
    s.sub        s15, s19, s17
    s.sub        s15, s20, s12
    v.movi       v3, #3584
    s.lshri      s17, s24, #32
    v.splat      v5, s15
    s.sub        s15, s14, s17
    v.splat      v6, s23
    s.lshri      s19, s15, #1
    v.add        v7, v5, v10
    s.add        s15, s17, s19
    v.add        v5, v0, v6
    s.lshri      s17, s15, #1
    v.mul        v6, v7, v3
    s.muli       s15, s17, #3
    s.movz       s17, #0
    s.xor        s19, s18, s11
    s.sub        s24, s17, s22
    s.movz       s17, #64
    s.sub        s22, s14, s15
    s.xor        s14, s18, s24
    s.xor        s15, s22, s21
    s.sub        s18, s19, s11
    s.sub        s11, s15, s21
    s.addi       s15, s16, #0
    s.sub        s18, s11, s12
    v.ld.w       v3, [s15, #0]
    v.splat      v8, s18
    v.movi       v11, #64
    v.extract    s15, v6, #0
    v.add        v12, v8, v9
    v.splat      v8, s15
    s.addi       s15, s16, #1088
    v.mul        v13, v12, v11
    s.sub        s18, s8, s3
    s.movz       s3, #0
    v.extract    s8, v13, #0
    s.add        s18, s3, s23                    // the tile origin
    v.splat      v14, s8
    v.iota       v15                             // arange(0, VLEN)
    v.splat      v16, s18
    v.add        v17, v8, v14
    s.addi       s3, s16, #64
    v.add        v8, v15, v16
    v.extract    s8, v6, #1
    v.extract    s18, v13, #1
    v.add        v14, v17, v8
    v.splat      v16, s8
    s.addi       s8, s15, #64
    v.add        v17, v3, v14
    s.sub        s19, s14, s24
    v.splat      v3, s18
    v.st.w       [s15, #0], v17
    s.addi       s14, s16, #128
    v.add        v14, v16, v3
    v.extract    s18, v6, #2
    v.extract    s19, v13, #2
    v.add        v3, v14, v8
    v.splat      v14, s18
    v.splat      v16, s19
    s.addi       s18, s15, #128
    s.addi       s19, s16, #192
    v.add        v17, v14, v16
    v.extract    s21, v6, #3
    s.addi       s22, s15, #192
    v.add        v14, v17, v8
    s.movz       s24, #3584
    v.splat      v16, s21
    v.extract    s21, v13, #3
    v.ld.w       v17, [s3, #0]
    v.splat      v18, s21
    s.addi       s3, s16, #256
    v.extract    s21, v6, #4
    v.add        v19, v16, v18
    v.splat      v16, s21
    v.extract    s21, v13, #4
    v.add        v18, v19, v8
    v.splat      v19, s21
    s.addi       s21, s15, #256
    v.add        v20, v16, v19
    v.add        v16, v20, v8
    v.add        v19, v17, v3
    v.st.w       [s8, #0], v19
    s.addi       s8, s16, #320
    v.ld.w       v3, [s14, #0]
    v.extract    s14, v6, #5
    v.splat      v17, s14
    v.extract    s14, v13, #5
    v.splat      v19, s14
    s.addi       s14, s15, #320
    v.add        v20, v17, v19
    v.add        v17, v20, v8
    v.add        v19, v3, v14
    v.st.w       [s18, #0], v19
    s.addi       s18, s16, #384
    v.ld.w       v3, [s19, #0]
    v.extract    s19, v6, #6
    v.splat      v14, s19
    v.extract    s19, v13, #6
    v.splat      v19, s19
    s.addi       s19, s15, #384
    v.add        v20, v14, v19
    v.add        v14, v20, v8
    v.add        v19, v3, v18
    v.st.w       [s22, #0], v19
    s.addi       s22, s16, #448
    v.ld.w       v3, [s3, #0]
    v.extract    s3, v6, #7
    v.splat      v18, s3
    v.extract    s3, v13, #7
    v.splat      v19, s3
    s.addi       s3, s15, #448
    v.add        v20, v18, v19
    v.add        v18, v20, v8
    v.add        v19, v3, v16
    v.st.w       [s21, #0], v19
    s.addi       s21, s16, #512
    v.ld.w       v3, [s8, #0]
    v.extract    s8, v6, #8
    v.splat      v16, s8
    v.extract    s8, v13, #8
    v.splat      v19, s8
    s.addi       s8, s15, #512
    v.add        v20, v16, v19
    v.add        v16, v20, v8
    v.add        v19, v3, v17
    v.st.w       [s14, #0], v19
    s.addi       s14, s16, #576
    v.ld.w       v3, [s18, #0]
    v.extract    s18, v6, #9
    v.splat      v17, s18
    v.extract    s18, v13, #9
    v.splat      v19, s18
    s.addi       s18, s15, #576
    v.add        v20, v17, v19
    v.add        v17, v20, v8
    v.add        v19, v3, v14
    v.st.w       [s19, #0], v19
    s.addi       s19, s16, #640
    v.ld.w       v3, [s22, #0]
    v.extract    s22, v6, #10
    v.splat      v14, s22
    v.extract    s22, v13, #10
    v.splat      v19, s22
    s.addi       s22, s15, #640
    v.add        v20, v14, v19
    v.add        v14, v20, v8
    v.add        v19, v3, v18
    v.st.w       [s3, #0], v19
    s.addi       s3, s16, #704
    v.ld.w       v3, [s21, #0]
    v.extract    s21, v6, #11
    v.splat      v18, s21
    v.extract    s21, v13, #11
    v.splat      v19, s21
    s.addi       s21, s15, #704
    v.add        v20, v18, v19
    v.add        v18, v20, v8
    v.add        v19, v3, v16
    v.st.w       [s8, #0], v19
    s.addi       s8, s16, #768
    v.ld.w       v3, [s14, #0]
    v.extract    s14, v6, #12
    v.splat      v16, s14
    v.extract    s14, v13, #12
    v.splat      v19, s14
    s.addi       s14, s15, #768
    v.add        v20, v16, v19
    v.add        v16, v20, v8
    v.add        v19, v3, v17
    v.st.w       [s18, #0], v19
    s.addi       s18, s16, #832
    v.ld.w       v3, [s19, #0]
    v.extract    s19, v6, #13
    v.splat      v17, s19
    v.extract    s19, v13, #13
    v.splat      v19, s19
    s.addi       s19, s15, #832
    v.add        v20, v17, v19
    v.add        v17, v20, v8
    v.add        v19, v3, v14
    v.st.w       [s22, #0], v19
    s.addi       s22, s16, #896
    v.ld.w       v3, [s3, #0]
    v.extract    s3, v6, #14
    v.movi       v14, #8
    v.splat      v19, s3
    v.extract    s3, v13, #14
    v.splat      v20, s3
    s.addi       s3, s15, #896
    s.addi       s24, s15, #960
    v.add        v21, v19, v20
    v.add        v19, v21, v8
    v.add        v20, v3, v18
    v.cmp.lt     p1, v4, v14
    v.st.w       [s21, #0], v20
    s.addi       s15, s16, #960
    v.movi       v3, #1
    v.movi       v14, #0
    @p1 v.sel        v18, v3, v14
    v.ld.w       v3, [s8, #0]
    v.extract    s8, v6, #15
    v.movi       v6, #0
    v.splat      v14, s8
    v.extract    s8, v13, #15
    v.movi       v13, #1
    v.splat      v20, s8
    v.cmp.ge     p1, v7, v6
    v.cmp.lt     p2, v7, v1
    v.add        v7, v14, v20
    v.movi       v14, #0
    v.movi       v20, #1
    v.add        v21, v7, v8
    @p1 v.sel        v7, v13, v14
    v.add        v8, v3, v16
    v.movi       v3, #0
    v.st.w       [s14, #0], v8
    v.movi       v8, #1
    @p2 v.sel        v13, v20, v3
    v.cmp.ge     p1, v12, v6
    v.ld.w       v3, [s18, #0]
    v.movi       v6, #0
    v.movi       v14, #1
    v.movi       v16, #0
    @p1 v.sel        v20, v8, v6
    v.cmp.lt     p1, v12, v1
    @p1 v.sel        v6, v14, v16
    v.cmp.lt     p1, v5, v11
    v.add        v5, v3, v17
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s8, #0
    v.st.w       [s19, #0], v5
    s.addi       s14, s16, #1088
    v.extract    s18, v18, #0
    v.ld.w       v3, [s22, #0]
    v.extract    s19, v7, #0
    v.splat      v5, s18
    v.movi       v8, #0
    v.splat      v11, s19
    v.movi       v12, #0
    v.cmp.ne     p2, v5, v8
    v.cmp.ne     p3, v11, v12
    v.add        v5, v3, v19
    p.and        p4, p2, p3
    v.st.w       [s3, #0], v5
    v.extract    s3, v13, #0
    v.movi       v3, #0
    v.splat      v5, s3
    v.ld.w       v8, [s15, #0]
    v.extract    s3, v20, #0
    v.movi       v11, #0
    v.splat      v12, s3
    v.cmp.ne     p2, v5, v3
    p.and        p3, p4, p2
    v.cmp.ne     p2, v12, v11
    p.and        p4, p3, p2
    v.add        v3, v8, v21
    v.extract    s3, v6, #0
    v.st.w       [s24, #0], v3
    fence.acq_rel.device
    v.splat      v3, s3
    v.movi       v5, #0
    s.addi       s3, s16, #1152
    v.extract    s15, v18, #1
    v.cmp.ne     p2, v3, v5
    p.and        p3, p4, p2
    v.extract    s18, v7, #1
    p.and        p2, p3, p1
    v.splat      v3, s15
    v.movi       v5, #0
    v.splat      v8, s18
    v.movi       v11, #0
    v.extract    s15, v13, #1
    v.movi       v12, #0
    v.splat      v14, s15
    v.extract    s15, v20, #1
    v.ld.w       v16, [s14, #0]
    v.cmp.ne     p3, v3, v5
    v.cmp.ne     p4, v8, v11
    p.and        p5, p3, p4
    v.splat      v3, s15
    v.movi       v5, #0
    v.extract    s14, v6, #1
    v.cmp.ne     p3, v14, v12
    p.and        p4, p5, p3
    v.splat      v8, s14
    v.movi       v11, #0
    v.cmp.ne     p3, v3, v5
    p.and        p5, p4, p3
    v.cmp.ne     p3, v8, v11
    p.and        p4, p5, p3
    s.movz       s14, #1
    p.and        p3, p4, p1
    s.addi       s15, s16, #1216
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v3, [s2, v16]              // index is in elements (ISA sec 9.1)
    v.extract    s18, v18, #2
    v.extract    s19, v7, #2
    v.splat      v5, s18
    v.movi       v8, #0
    v.splat      v11, s19
    v.movi       v12, #0
    v.extract    s18, v13, #2
    v.movi       v14, #0
    v.splat      v16, s18
    v.cmp.ne     p2, v5, v8
    v.cmp.ne     p4, v11, v12
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    s.movz       s18, #2
    a.vwrite     a1, s8, v3
    v.ld.w       v3, [s3, #0]
    v.extract    s3, v20, #2
    v.movi       v5, #0
    v.splat      v8, s3
    v.extract    s3, v6, #2
    v.movi       v11, #0
    v.splat      v12, s3
    v.cmp.ne     p2, v8, v5
    p.and        p5, p4, p2
    v.cmp.ne     p2, v12, v11
    p.and        p4, p5, p2
    s.addi       s3, s16, #1280
    p.and        p2, p4, p1
    v.extract    s8, v18, #3
    v.extract    s19, v7, #3
    v.splat      v5, s8
    v.movi       v8, #0
    v.splat      v11, s19
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s8, v13, #3
    v.movi       v14, #0
    v.splat      v16, s8
    v.cmp.ne     p3, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    s.movz       s8, #3
    a.vwrite     a1, s14, v12
    v.ld.w       v3, [s15, #0]
    v.extract    s14, v20, #3
    v.movi       v5, #0
    v.splat      v8, s14
    v.extract    s14, v6, #3
    v.movi       v11, #0
    v.splat      v12, s14
    v.cmp.ne     p3, v8, v5
    p.and        p5, p4, p3
    v.cmp.ne     p3, v12, v11
    p.and        p4, p5, p3
    s.addi       s14, s16, #1344
    p.and        p3, p4, p1
    v.extract    s15, v18, #4
    v.extract    s19, v7, #4
    v.splat      v5, s15
    v.movi       v8, #0
    v.splat      v11, s19
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s15, v13, #4
    v.movi       v14, #0
    v.splat      v16, s15
    v.cmp.ne     p2, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    s.movz       s15, #4
    a.vwrite     a1, s18, v12
    v.ld.w       v3, [s3, #0]
    v.extract    s3, v20, #4
    v.movi       v5, #0
    v.splat      v8, s3
    v.extract    s3, v6, #4
    v.movi       v11, #0
    v.splat      v12, s3
    v.cmp.ne     p2, v8, v5
    p.and        p5, p4, p2
    v.cmp.ne     p2, v12, v11
    p.and        p4, p5, p2
    s.addi       s3, s16, #1408
    p.and        p2, p4, p1
    v.extract    s18, v18, #5
    v.extract    s19, v7, #5
    v.splat      v5, s18
    v.movi       v8, #0
    v.splat      v11, s19
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s18, v13, #5
    v.movi       v14, #0
    v.splat      v16, s18
    v.cmp.ne     p3, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    s.movz       s18, #5
    a.vwrite     a1, s8, v12
    v.ld.w       v3, [s14, #0]
    v.extract    s8, v20, #5
    v.movi       v5, #0
    v.splat      v8, s8
    v.extract    s8, v6, #5
    v.movi       v11, #0
    v.splat      v12, s8
    v.cmp.ne     p3, v8, v5
    p.and        p5, p4, p3
    v.cmp.ne     p3, v12, v11
    p.and        p4, p5, p3
    s.addi       s8, s16, #1472
    p.and        p3, p4, p1
    v.extract    s14, v18, #6
    v.extract    s19, v7, #6
    v.splat      v5, s14
    v.movi       v8, #0
    v.splat      v11, s19
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s14, v13, #6
    v.movi       v14, #0
    v.splat      v16, s14
    v.cmp.ne     p2, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    s.movz       s14, #6
    a.vwrite     a1, s15, v12
    v.ld.w       v3, [s3, #0]
    v.extract    s3, v20, #6
    v.movi       v5, #0
    v.splat      v8, s3
    v.extract    s3, v6, #6
    v.movi       v11, #0
    v.splat      v12, s3
    v.cmp.ne     p2, v8, v5
    p.and        p5, p4, p2
    v.cmp.ne     p2, v12, v11
    p.and        p4, p5, p2
    s.addi       s3, s16, #1536
    p.and        p2, p4, p1
    v.extract    s15, v18, #7
    v.extract    s19, v7, #7
    v.splat      v5, s15
    v.movi       v8, #0
    v.splat      v11, s19
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s15, v13, #7
    v.movi       v14, #0
    v.splat      v16, s15
    v.cmp.ne     p3, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    s.movz       s15, #7
    a.vwrite     a1, s18, v12
    v.ld.w       v3, [s8, #0]
    v.extract    s8, v20, #7
    v.movi       v5, #0
    v.splat      v8, s8
    v.extract    s8, v6, #7
    v.movi       v11, #0
    v.splat      v12, s8
    v.cmp.ne     p3, v8, v5
    p.and        p5, p4, p3
    v.cmp.ne     p3, v12, v11
    p.and        p4, p5, p3
    s.addi       s8, s16, #1600
    p.and        p3, p4, p1
    v.extract    s18, v18, #8
    v.extract    s19, v7, #8
    v.splat      v5, s18
    v.movi       v8, #0
    v.splat      v11, s19
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s18, v13, #8
    v.movi       v14, #0
    v.splat      v16, s18
    v.cmp.ne     p2, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    s.movz       s18, #8
    a.vwrite     a1, s14, v12
    v.ld.w       v3, [s3, #0]
    v.extract    s3, v20, #8
    v.movi       v5, #0
    v.splat      v8, s3
    v.extract    s3, v6, #8
    v.movi       v11, #0
    v.splat      v12, s3
    v.cmp.ne     p2, v8, v5
    p.and        p5, p4, p2
    v.cmp.ne     p2, v12, v11
    p.and        p4, p5, p2
    s.addi       s3, s16, #1664
    p.and        p2, p4, p1
    v.extract    s14, v18, #9
    v.extract    s19, v7, #9
    v.splat      v5, s14
    v.movi       v8, #0
    v.splat      v11, s19
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s14, v13, #9
    v.movi       v14, #0
    v.splat      v16, s14
    v.cmp.ne     p3, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    s.movz       s14, #9
    a.vwrite     a1, s15, v12
    v.ld.w       v3, [s8, #0]
    v.extract    s8, v20, #9
    v.movi       v5, #0
    v.splat      v8, s8
    v.extract    s8, v6, #9
    v.movi       v11, #0
    v.splat      v12, s8
    v.cmp.ne     p3, v8, v5
    p.and        p5, p4, p3
    v.cmp.ne     p3, v12, v11
    p.and        p4, p5, p3
    s.addi       s8, s16, #1728
    p.and        p3, p4, p1
    v.extract    s15, v18, #10
    v.extract    s19, v7, #10
    v.splat      v5, s15
    v.movi       v8, #0
    v.splat      v11, s19
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s15, v13, #10
    v.movi       v14, #0
    v.splat      v16, s15
    v.cmp.ne     p2, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    s.movz       s15, #10
    a.vwrite     a1, s18, v12
    v.ld.w       v3, [s3, #0]
    v.extract    s3, v20, #10
    v.movi       v5, #0
    v.splat      v8, s3
    v.extract    s3, v6, #10
    v.movi       v11, #0
    v.splat      v12, s3
    v.cmp.ne     p2, v8, v5
    p.and        p5, p4, p2
    v.cmp.ne     p2, v12, v11
    p.and        p4, p5, p2
    s.addi       s3, s16, #1792
    p.and        p2, p4, p1
    v.extract    s18, v18, #11
    v.extract    s19, v7, #11
    v.splat      v5, s18
    v.movi       v8, #0
    v.splat      v11, s19
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s18, v13, #11
    v.movi       v14, #0
    v.splat      v16, s18
    v.cmp.ne     p3, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    s.movz       s18, #11
    a.vwrite     a1, s14, v12
    v.ld.w       v3, [s8, #0]
    v.extract    s8, v20, #11
    v.movi       v5, #0
    v.splat      v8, s8
    v.extract    s8, v6, #11
    v.movi       v11, #0
    v.splat      v12, s8
    v.cmp.ne     p3, v8, v5
    p.and        p5, p4, p3
    v.cmp.ne     p3, v12, v11
    p.and        p4, p5, p3
    s.addi       s8, s16, #1856
    p.and        p3, p4, p1
    v.extract    s14, v18, #12
    v.extract    s19, v7, #12
    v.splat      v5, s14
    v.movi       v8, #0
    v.splat      v11, s19
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s14, v13, #12
    v.movi       v14, #0
    v.splat      v16, s14
    v.cmp.ne     p2, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    s.movz       s14, #12
    a.vwrite     a1, s15, v12
    v.ld.w       v3, [s3, #0]
    v.extract    s3, v20, #12
    v.movi       v5, #0
    v.splat      v8, s3
    v.extract    s3, v6, #12
    v.movi       v11, #0
    v.splat      v12, s3
    v.cmp.ne     p2, v8, v5
    p.and        p5, p4, p2
    v.cmp.ne     p2, v12, v11
    p.and        p4, p5, p2
    s.addi       s3, s16, #1920
    p.and        p2, p4, p1
    v.extract    s15, v18, #13
    v.extract    s19, v7, #13
    v.splat      v5, s15
    v.movi       v8, #0
    v.splat      v11, s19
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s15, v13, #13
    v.movi       v14, #0
    v.splat      v16, s15
    v.cmp.ne     p3, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    s.movz       s15, #13
    a.vwrite     a1, s18, v12
    v.ld.w       v3, [s8, #0]
    v.extract    s8, v20, #13
    v.movi       v5, #0
    v.splat      v8, s8
    v.extract    s8, v6, #13
    v.movi       v11, #0
    v.splat      v12, s8
    v.cmp.ne     p3, v8, v5
    p.and        p5, p4, p3
    v.cmp.ne     p3, v12, v11
    p.and        p4, p5, p3
    s.addi       s8, s16, #1984
    p.and        p3, p4, p1
    v.extract    s18, v18, #14
    v.extract    s19, v7, #14
    v.splat      v5, s18
    v.movi       v8, #0
    v.splat      v11, s19
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s18, v13, #14
    v.movi       v14, #0
    v.splat      v16, s18
    v.cmp.ne     p2, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    s.movz       s18, #14
    a.vwrite     a1, s14, v12
    v.ld.w       v3, [s3, #0]
    v.extract    s3, v20, #14
    v.movi       v5, #0
    v.splat      v8, s3
    v.extract    s3, v6, #14
    v.movi       v11, #0
    v.splat      v12, s3
    v.cmp.ne     p2, v8, v5
    p.and        p5, p4, p2
    v.cmp.ne     p2, v12, v11
    p.and        p4, p5, p2
    s.addi       s3, s16, #2048
    p.and        p2, p4, p1
    v.extract    s14, v18, #15
    v.extract    s19, v7, #15
    v.splat      v5, s14
    v.movi       v7, #0
    v.splat      v8, s19
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s14, v13, #15
    v.movi       v12, #0
    v.splat      v13, s14
    v.cmp.ne     p3, v5, v7
    v.cmp.ne     p4, v8, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v13, v12
    p.and        p4, p5, p3
    s.movz       s14, #15
    a.vwrite     a1, s15, v11
    v.ld.w       v3, [s8, #0]
    v.extract    s8, v20, #15
    v.movi       v5, #0
    v.splat      v7, s8
    v.extract    s8, v6, #15
    v.movi       v6, #0
    v.splat      v8, s8
    v.cmp.ne     p3, v7, v5
    p.and        p5, p4, p3
    v.cmp.ne     p3, v8, v6
    p.and        p4, p5, p3
    s.addi       s8, s16, #1024
    p.and        p3, p4, p1
    s.movz       s15, #192
    s.movz       s19, #0
    s.mul        s21, s20, s15
    s.mul        s15, s11, s17
    s.add        s11, s19, s23                   // the tile origin
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s2, v3]               // index is in elements (ISA sec 9.1)
    s.addi       s19, s16, #2112
    s.add        s20, s11, s21                   // the tile origin
    s.addi       s11, s16, #1024
    s.add        s21, s20, s15                   // the tile origin
    s.addi       s15, s19, #64
    v.splat      v3, s21
    s.addi       s20, s21, #1
    a.vwrite     a1, s18, v5
    v.ld.w       v5, [s3, #0]
    v.splat      v6, s20
    s.addi       s3, s16, #1024
    s.addi       s18, s21, #2
    s.addi       s20, s19, #128
    v.splat      v7, s18
    s.addi       s18, s16, #1024
    s.addi       s22, s21, #3
    v.splat      v8, s22
    s.addi       s22, s19, #192
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s2, v5]              // index is in elements (ISA sec 9.1)
    s.addi       s24, s16, #1024
    a.vwrite     a1, s14, v11
    v.ld.w       v5, [s8, #0]
    s.addi       s8, s21, #4
    s.addi       s14, s19, #256
    v.splat      v11, s8
    s.addi       s8, s16, #1024
    v.add        v12, v5, v3
    v.st.w       [s19, #0], v12
    v.ld.w       v3, [s11, #0]
    s.addi       s11, s21, #5
    v.splat      v5, s11
    s.addi       s11, s19, #320
    v.add        v12, v3, v6
    v.st.w       [s15, #0], v12
    s.addi       s15, s16, #1024
    v.ld.w       v3, [s3, #0]
    s.addi       s3, s21, #6
    v.splat      v6, s3
    s.addi       s3, s19, #384
    v.add        v12, v3, v7
    v.st.w       [s20, #0], v12
    s.addi       s20, s16, #1024
    v.ld.w       v3, [s18, #0]
    s.addi       s18, s21, #7
    v.splat      v7, s18
    s.addi       s18, s19, #448
    v.add        v12, v3, v8
    v.st.w       [s22, #0], v12
    s.addi       s22, s16, #1024
    v.ld.w       v3, [s24, #0]
    s.addi       s24, s21, #8
    v.splat      v8, s24
    s.addi       s24, s19, #512
    v.add        v12, v3, v11
    v.st.w       [s14, #0], v12
    s.addi       s14, s16, #1024
    v.ld.w       v3, [s8, #0]
    s.addi       s8, s21, #9
    v.splat      v11, s8
    s.addi       s8, s19, #576
    v.add        v12, v3, v5
    v.st.w       [s11, #0], v12
    s.addi       s11, s16, #1024
    v.ld.w       v3, [s15, #0]
    s.addi       s15, s21, #10
    v.splat      v5, s15
    s.addi       s15, s19, #640
    v.add        v12, v3, v6
    v.st.w       [s3, #0], v12
    s.addi       s3, s16, #1024
    v.ld.w       v3, [s20, #0]
    s.addi       s20, s21, #11
    v.splat      v6, s20
    s.addi       s20, s19, #704
    v.add        v12, v3, v7
    v.st.w       [s18, #0], v12
    s.addi       s18, s16, #1024
    v.ld.w       v3, [s22, #0]
    s.addi       s22, s21, #12
    v.splat      v7, s22
    s.addi       s22, s19, #768
    v.add        v12, v3, v8
    v.st.w       [s24, #0], v12
    s.addi       s24, s16, #1024
    v.ld.w       v3, [s14, #0]
    s.addi       s14, s21, #13
    v.splat      v8, s14
    s.addi       s14, s19, #832
    v.add        v12, v3, v11
    v.st.w       [s8, #0], v12
    s.addi       s8, s16, #1024
    v.splat      v3, s17
    v.ld.w       v11, [s11, #0]
    s.addi       s11, s21, #14
    s.addi       s25, s21, #15
    v.splat      v12, s11
    s.addi       s11, s19, #896
    v.splat      v13, s25
    s.addi       s21, s16, #1024
    s.addi       s25, s19, #960
    v.add        v14, v11, v5
    v.st.w       [s15, #0], v14
    s.addi       s15, s16, #2112
    v.splat      v5, s17
    s.movz       s17, #0
    s.add        s19, s17, s7                    // the tile origin
    v.splat      v11, s19
    s.movz       s17, #0
    s.add        s19, s17, s23                   // the tile origin
    v.add        v14, v15, v11
    v.splat      v11, s19
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s17, #0
    v.cmp.lt     p1, v14, v5
    v.cmp.lt     p2, v11, v3
    v.ld.w       v5, [s3, #0]
    p.and        p3, p2, p1
    v.add        v11, v5, v6
    s.movz       s3, #1
    v.st.w       [s20, #0], v11
    s.addi       s20, s16, #2176
    v.ld.w       v5, [s18, #0]
    s.addi       s18, s19, #1
    v.splat      v6, s18
    v.cmp.lt     p2, v6, v3
    p.and        p4, p2, p1
    v.add        v6, v5, v7
    v.st.w       [s22, #0], v6
    s.addi       s18, s16, #2240
    s.movz       s22, #2
    v.ld.w       v5, [s24, #0]
    s.addi       s23, s19, #2
    v.splat      v6, s23
    v.add        v7, v5, v8
    v.cmp.lt     p2, v6, v3
    v.st.w       [s14, #0], v7
    p.and        p5, p2, p1
    v.ld.w       v5, [s8, #0]
    s.addi       s8, s16, #2304
    s.movz       s14, #3
    v.add        v6, v5, v12
    s.addi       s23, s19, #3
    v.st.w       [s11, #0], v6
    v.splat      v5, s23
    v.ld.w       v6, [s21, #0]
    s.movz       s11, #4
    v.add        v7, v6, v13
    s.addi       s21, s16, #2368
    v.st.w       [s25, #0], v7
    fence.acq_rel.device
    s.addi       s23, s19, #4
    v.splat      v6, s23
    v.ld.w       v7, [s15, #0]
    s.addi       s15, s16, #2432
    s.addi       s23, s19, #5
    s.movz       s24, #5
    v.splat      v8, s23
    s.movz       s23, #6
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s5, v7]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v3
    p.and        p3, p2, p1
    a.vwrite     a2, s17, v11
    v.ld.w       v5, [s20, #0]
    s.addi       s17, s16, #2496
    s.addi       s20, s19, #6
    v.splat      v7, s20
    s.movz       s20, #7
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v11, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v3
    p.and        p4, p2, p1
    a.vwrite     a2, s3, v11
    v.ld.w       v5, [s18, #0]
    s.addi       s3, s16, #2560
    s.addi       s18, s19, #7
    v.splat      v6, s18
    s.movz       s18, #8
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v11, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v8, v3
    p.and        p5, p2, p1
    a.vwrite     a2, s22, v11
    v.ld.w       v5, [s8, #0]
    s.addi       s8, s16, #2624
    s.addi       s22, s19, #8
    v.splat      v8, s22
    s.movz       s22, #9
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v7, v3
    p.and        p3, p2, p1
    a.vwrite     a2, s14, v11
    v.ld.w       v5, [s21, #0]
    s.addi       s14, s16, #2688
    s.addi       s21, s19, #9
    v.splat      v7, s21
    s.movz       s21, #10
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v11, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v3
    p.and        p4, p2, p1
    a.vwrite     a2, s11, v11
    v.ld.w       v5, [s15, #0]
    s.addi       s11, s16, #2752
    s.addi       s15, s19, #10
    v.splat      v6, s15
    s.movz       s15, #11
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v11, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v8, v3
    p.and        p5, p2, p1
    a.vwrite     a2, s24, v11
    v.ld.w       v5, [s17, #0]
    s.addi       s17, s16, #2816
    s.addi       s24, s19, #11
    v.splat      v8, s24
    s.movz       s24, #12
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v7, v3
    p.and        p3, p2, p1
    a.vwrite     a2, s23, v11
    v.ld.w       v5, [s3, #0]
    s.addi       s3, s16, #2880
    s.addi       s23, s19, #12
    v.splat      v7, s23
    s.movz       s23, #13
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v11, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v3
    p.and        p4, p2, p1
    a.vwrite     a2, s20, v11
    v.ld.w       v5, [s8, #0]
    s.addi       s8, s16, #2944
    s.addi       s20, s19, #13
    v.splat      v6, s20
    s.movz       s20, #14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v11, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v8, v3
    p.and        p5, p2, p1
    a.vwrite     a2, s18, v11
    v.ld.w       v5, [s14, #0]
    s.addi       s14, s16, #3008
    s.addi       s18, s19, #14
    v.splat      v8, s18
    s.movz       s18, #15
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v7, v3
    p.and        p3, p2, p1
    a.vwrite     a2, s22, v11
    v.ld.w       v5, [s11, #0]
    s.addi       s11, s16, #3072
    s.addi       s22, s19, #15
    v.movi       v7, #0
    v.splat      v11, s22
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v12, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v3
    p.and        p4, p2, p1
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s19, #0
    a.vwrite     a2, s21, v12
    v.ld.w       v5, [s17, #0]
    s.movz       s17, #0
    s.movz       s21, #0
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v6, [s5, v5]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v8, v3
    p.and        p5, p2, p1
    a.vwrite     a2, s15, v6
    v.ld.w       v5, [s3, #0]
    s.movz       s3, #1
    s.movz       s15, #2
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v6, [s5, v5]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v11, v3
    p.and        p3, p2, p1
    a.vwrite     a2, s24, v6
    v.ld.w       v3, [s8, #0]
    s.movz       s8, #3
    s.movz       s22, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v5, [s5, v3]               // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s23, v5
    v.ld.w       v3, [s14, #0]
    s.movz       s14, #5
    s.movz       s23, #6
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v5, [s5, v3]               // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s20, v5
    v.ld.w       v3, [s11, #0]
    s.movz       s11, #7
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v5, [s5, v3]               // index is in elements (ISA sec 9.1)
    s.movz       s20, #8
    a.vwrite     a2, s18, v5
    a.vread      v3, a1, s17
    a.vread      v5, a2, s21
    a.vread      v6, a2, s3
    v.extract    s3, v3, #0
    v.extract    s17, v3, #1
    v.splat      v8, s3
    v.splat      v11, s17
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s15
    v.extract    s3, v3, #3
    a.vread      v13, a2, s8
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s22
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s14
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s23
    v.extract    s3, v3, #7
    a.vread      v15, a2, s11
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s20
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s8, #9
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s8, #10
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s8, #11
    v.splat      v11, s3
    a.vread      v15, a2, s8
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s8, #12
    v.splat      v12, s3
    a.vread      v14, a2, s8
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s8, #13
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s8, #14
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s8, #15
    v.splat      v3, s3
    a.vread      v11, a2, s8
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #1
    s.movz       s8, #0
    s.movz       s11, #1
    s.movz       s14, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s15, #3
    s.movz       s17, #4
    s.movz       s18, #5
    s.movz       s20, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s21, #7
    s.movz       s22, #8
    s.movz       s23, #1
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s19, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s8
    a.vread      v6, a2, s11
    v.extract    s3, v3, #0
    v.extract    s8, v3, #1
    v.splat      v8, s3
    v.splat      v11, s8
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s14
    v.extract    s3, v3, #3
    a.vread      v13, a2, s15
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s17
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s18
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s20
    v.extract    s3, v3, #7
    a.vread      v15, a2, s21
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s22
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s8, #9
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s8, #10
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s8, #11
    v.splat      v11, s3
    a.vread      v15, a2, s8
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s8, #12
    v.splat      v12, s3
    a.vread      v14, a2, s8
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s8, #13
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s8, #14
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s8, #15
    v.splat      v3, s3
    a.vread      v11, a2, s8
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #2
    s.movz       s8, #0
    s.movz       s11, #1
    s.movz       s14, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s15, #3
    s.movz       s17, #4
    s.movz       s18, #5
    s.movz       s19, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s20, #7
    s.movz       s21, #8
    s.movz       s22, #2
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s23, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s8
    a.vread      v6, a2, s11
    v.extract    s3, v3, #0
    v.extract    s8, v3, #1
    v.splat      v8, s3
    v.splat      v11, s8
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s14
    v.extract    s3, v3, #3
    a.vread      v13, a2, s15
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s17
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s18
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s19
    v.extract    s3, v3, #7
    a.vread      v15, a2, s20
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s21
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s8, #9
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s8, #10
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s8, #11
    v.splat      v11, s3
    a.vread      v15, a2, s8
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s8, #12
    v.splat      v12, s3
    a.vread      v14, a2, s8
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s8, #13
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s8, #14
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s8, #15
    v.splat      v3, s3
    a.vread      v11, a2, s8
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #3
    s.movz       s8, #0
    s.movz       s11, #1
    s.movz       s14, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s15, #3
    s.movz       s17, #4
    s.movz       s18, #5
    s.movz       s19, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s20, #7
    s.movz       s21, #8
    s.movz       s23, #3
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s22, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s8
    a.vread      v6, a2, s11
    v.extract    s3, v3, #0
    v.extract    s8, v3, #1
    v.splat      v8, s3
    v.splat      v11, s8
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s14
    v.extract    s3, v3, #3
    a.vread      v13, a2, s15
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s17
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s18
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s19
    v.extract    s3, v3, #7
    a.vread      v15, a2, s20
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s21
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s8, #9
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s8, #10
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s8, #11
    v.splat      v11, s3
    a.vread      v15, a2, s8
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s8, #12
    v.splat      v12, s3
    a.vread      v14, a2, s8
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s8, #13
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s8, #14
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s8, #15
    v.splat      v3, s3
    a.vread      v11, a2, s8
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #4
    s.movz       s8, #0
    s.movz       s11, #1
    s.movz       s14, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s15, #3
    s.movz       s17, #4
    s.movz       s18, #5
    s.movz       s19, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s20, #7
    s.movz       s21, #8
    s.movz       s22, #4
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s23, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s8
    a.vread      v6, a2, s11
    v.extract    s3, v3, #0
    v.extract    s8, v3, #1
    v.splat      v8, s3
    v.splat      v11, s8
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s14
    v.extract    s3, v3, #3
    a.vread      v13, a2, s15
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s17
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s18
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s19
    v.extract    s3, v3, #7
    a.vread      v15, a2, s20
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s21
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s8, #9
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s8, #10
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s8, #11
    v.splat      v11, s3
    a.vread      v15, a2, s8
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s8, #12
    v.splat      v12, s3
    a.vread      v14, a2, s8
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s8, #13
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s8, #14
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s8, #15
    v.splat      v3, s3
    a.vread      v11, a2, s8
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #5
    s.movz       s8, #0
    s.movz       s11, #1
    s.movz       s14, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s15, #3
    s.movz       s17, #4
    s.movz       s18, #5
    s.movz       s19, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s20, #7
    s.movz       s21, #8
    s.movz       s23, #5
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s22, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s8
    a.vread      v6, a2, s11
    v.extract    s3, v3, #0
    v.extract    s8, v3, #1
    v.splat      v8, s3
    v.splat      v11, s8
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s14
    v.extract    s3, v3, #3
    a.vread      v13, a2, s15
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s17
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s18
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s19
    v.extract    s3, v3, #7
    a.vread      v15, a2, s20
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s21
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s8, #9
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s8, #10
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s8, #11
    v.splat      v11, s3
    a.vread      v15, a2, s8
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s8, #12
    v.splat      v12, s3
    a.vread      v14, a2, s8
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s8, #13
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s8, #14
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s8, #15
    v.splat      v3, s3
    a.vread      v11, a2, s8
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #6
    s.movz       s8, #0
    s.movz       s11, #1
    s.movz       s14, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s15, #3
    s.movz       s17, #4
    s.movz       s18, #5
    s.movz       s19, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s20, #7
    s.movz       s21, #8
    s.movz       s22, #6
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s23, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s8
    a.vread      v6, a2, s11
    v.extract    s3, v3, #0
    v.extract    s8, v3, #1
    v.splat      v8, s3
    v.splat      v11, s8
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s14
    v.extract    s3, v3, #3
    a.vread      v13, a2, s15
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s17
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s18
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s19
    v.extract    s3, v3, #7
    a.vread      v15, a2, s20
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s21
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s8, #9
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s8, #10
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s8, #11
    v.splat      v11, s3
    a.vread      v15, a2, s8
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s8, #12
    v.splat      v12, s3
    a.vread      v14, a2, s8
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s8, #13
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s8, #14
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s8, #15
    v.splat      v3, s3
    a.vread      v11, a2, s8
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #7
    s.movz       s8, #0
    s.movz       s11, #1
    s.movz       s14, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s15, #3
    s.movz       s17, #4
    s.movz       s18, #5
    s.movz       s19, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s20, #7
    s.movz       s21, #8
    s.movz       s23, #7
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s22, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s8
    a.vread      v6, a2, s11
    v.extract    s3, v3, #0
    v.extract    s8, v3, #1
    v.splat      v8, s3
    v.splat      v11, s8
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s14
    v.extract    s3, v3, #3
    a.vread      v13, a2, s15
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s17
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s18
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s19
    v.extract    s3, v3, #7
    a.vread      v15, a2, s20
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s21
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s8, #9
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s8, #10
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s8, #11
    v.splat      v11, s3
    a.vread      v15, a2, s8
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s8, #12
    v.splat      v12, s3
    a.vread      v14, a2, s8
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s8, #13
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s8, #14
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s8, #15
    v.splat      v3, s3
    a.vread      v11, a2, s8
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #8
    s.movz       s8, #0
    s.movz       s11, #1
    s.movz       s14, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s15, #3
    s.movz       s17, #4
    s.movz       s18, #5
    s.movz       s19, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s20, #7
    s.movz       s21, #8
    s.movz       s22, #8
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s23, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s8
    a.vread      v6, a2, s11
    v.extract    s3, v3, #0
    v.extract    s8, v3, #1
    v.splat      v8, s3
    v.splat      v11, s8
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s14
    v.extract    s3, v3, #3
    a.vread      v13, a2, s15
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s17
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s18
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s19
    v.extract    s3, v3, #7
    a.vread      v15, a2, s20
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s21
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s8, #9
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s8, #10
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s8, #11
    v.splat      v11, s3
    a.vread      v15, a2, s8
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s8, #12
    v.splat      v12, s3
    a.vread      v14, a2, s8
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s8, #13
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s8, #14
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s8, #15
    v.splat      v3, s3
    a.vread      v11, a2, s8
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #9
    s.movz       s8, #0
    s.movz       s11, #1
    s.movz       s14, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s15, #3
    s.movz       s17, #4
    s.movz       s18, #5
    s.movz       s19, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s20, #7
    s.movz       s21, #8
    s.movz       s23, #9
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s22, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s8
    a.vread      v6, a2, s11
    v.extract    s3, v3, #0
    v.extract    s8, v3, #1
    v.splat      v8, s3
    v.splat      v11, s8
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s14
    v.extract    s3, v3, #3
    a.vread      v13, a2, s15
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s17
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s18
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s19
    v.extract    s3, v3, #7
    a.vread      v15, a2, s20
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s21
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s8, #9
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s8, #10
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s8, #11
    v.splat      v11, s3
    a.vread      v15, a2, s8
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s8, #12
    v.splat      v12, s3
    a.vread      v14, a2, s8
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s8, #13
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s8, #14
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s8, #15
    v.splat      v3, s3
    a.vread      v11, a2, s8
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #10
    s.movz       s8, #0
    s.movz       s11, #1
    s.movz       s14, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s15, #3
    s.movz       s17, #4
    s.movz       s18, #5
    s.movz       s19, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s20, #7
    s.movz       s21, #8
    s.movz       s22, #10
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s23, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s8
    a.vread      v6, a2, s11
    v.extract    s3, v3, #0
    v.extract    s8, v3, #1
    v.splat      v8, s3
    v.splat      v11, s8
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s14
    v.extract    s3, v3, #3
    a.vread      v13, a2, s15
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s17
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s18
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s19
    v.extract    s3, v3, #7
    a.vread      v15, a2, s20
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s21
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s8, #9
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s8, #10
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s8, #11
    v.splat      v11, s3
    a.vread      v15, a2, s8
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s8, #12
    v.splat      v12, s3
    a.vread      v14, a2, s8
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s8, #13
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s8, #14
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s8, #15
    v.splat      v3, s3
    a.vread      v11, a2, s8
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #11
    s.movz       s8, #0
    s.movz       s11, #1
    s.movz       s14, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s15, #3
    s.movz       s17, #4
    s.movz       s18, #5
    s.movz       s19, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s20, #7
    s.movz       s21, #8
    s.movz       s23, #11
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s22, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s8
    a.vread      v6, a2, s11
    v.extract    s3, v3, #0
    v.extract    s8, v3, #1
    v.splat      v8, s3
    v.splat      v11, s8
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s14
    v.extract    s3, v3, #3
    a.vread      v13, a2, s15
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s17
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s18
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s19
    v.extract    s3, v3, #7
    a.vread      v15, a2, s20
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s21
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s8, #9
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s8, #10
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s8, #11
    v.splat      v11, s3
    a.vread      v15, a2, s8
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s8, #12
    v.splat      v12, s3
    a.vread      v14, a2, s8
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s8, #13
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s8, #14
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s8, #15
    v.splat      v3, s3
    a.vread      v11, a2, s8
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #12
    s.movz       s8, #0
    s.movz       s11, #1
    s.movz       s14, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s15, #3
    s.movz       s17, #4
    s.movz       s18, #5
    s.movz       s19, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s20, #7
    s.movz       s21, #8
    s.movz       s22, #12
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s23, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s8
    a.vread      v6, a2, s11
    v.extract    s3, v3, #0
    v.extract    s8, v3, #1
    v.splat      v8, s3
    v.splat      v11, s8
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s14
    v.extract    s3, v3, #3
    a.vread      v13, a2, s15
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s17
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s18
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s19
    v.extract    s3, v3, #7
    a.vread      v15, a2, s20
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s21
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s8, #9
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s8, #10
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s8, #11
    v.splat      v11, s3
    a.vread      v15, a2, s8
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s8, #12
    v.splat      v12, s3
    a.vread      v14, a2, s8
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s8, #13
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s8, #14
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s8, #15
    v.splat      v3, s3
    a.vread      v11, a2, s8
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #13
    s.movz       s8, #0
    s.movz       s11, #1
    s.movz       s14, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s15, #3
    s.movz       s17, #4
    s.movz       s18, #5
    s.movz       s19, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s20, #7
    s.movz       s21, #8
    s.movz       s23, #13
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s22, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s8
    a.vread      v6, a2, s11
    v.extract    s3, v3, #0
    v.extract    s8, v3, #1
    v.splat      v8, s3
    v.splat      v11, s8
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s14
    v.extract    s3, v3, #3
    a.vread      v13, a2, s15
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s17
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s18
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s19
    v.extract    s3, v3, #7
    a.vread      v15, a2, s20
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s21
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s8, #9
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s8, #10
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s8, #11
    v.splat      v11, s3
    a.vread      v15, a2, s8
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s8, #12
    v.splat      v12, s3
    a.vread      v14, a2, s8
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s8, #13
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s8, #14
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s8, #15
    v.splat      v3, s3
    a.vread      v11, a2, s8
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #14
    s.movz       s8, #0
    s.movz       s11, #1
    s.movz       s14, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s15, #3
    s.movz       s17, #4
    s.movz       s18, #5
    s.movz       s19, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s20, #7
    s.movz       s21, #8
    s.movz       s22, #14
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s23, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s8
    a.vread      v6, a2, s11
    v.extract    s3, v3, #0
    v.extract    s8, v3, #1
    v.splat      v8, s3
    v.splat      v11, s8
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s14
    v.extract    s3, v3, #3
    a.vread      v13, a2, s15
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s17
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s18
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s19
    v.extract    s3, v3, #7
    a.vread      v15, a2, s20
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s21
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s8, #9
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s8, #10
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s8, #11
    v.splat      v11, s3
    a.vread      v15, a2, s8
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s8, #12
    v.splat      v12, s3
    a.vread      v14, a2, s8
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s8, #13
    v.splat      v5, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s8, #14
    v.splat      v6, s3
    a.vread      v13, a2, s8
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s8, #15
    v.splat      v3, s3
    a.vread      v11, a2, s8
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #15
    s.movz       s8, #0
    s.movz       s11, #1
    s.movz       s14, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s15, #3
    s.movz       s17, #4
    s.movz       s18, #5
    s.movz       s19, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s20, #7
    s.movz       s21, #8
    s.movz       s23, #15
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s22, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s8
    a.vread      v6, a2, s11
    v.extract    s3, v3, #0
    v.extract    s8, v3, #1
    v.splat      v8, s3
    v.splat      v11, s8
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v7, a2, s14
    v.extract    s3, v3, #3
    a.vread      v8, a2, s15
    vf.fma       v13, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s17
    v.splat      v12, s3
    vf.fma       v14, v5, v7, v13
    v.extract    s3, v3, #5
    a.vread      v5, a2, s18
    v.splat      v7, s3
    v.extract    s3, v3, #6
    vf.fma       v13, v6, v8, v14
    v.splat      v6, s3
    a.vread      v8, a2, s19
    v.extract    s3, v3, #7
    a.vread      v14, a2, s20
    vf.fma       v15, v12, v11, v13
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s21
    v.splat      v13, s3
    vf.fma       v16, v7, v5, v15
    v.extract    s3, v3, #9
    s.movz       s8, #9
    v.splat      v5, s3
    a.vread      v7, a2, s8
    vf.fma       v15, v6, v8, v16
    v.extract    s3, v3, #10
    s.movz       s8, #10
    v.splat      v6, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v11, v14, v15
    v.extract    s3, v3, #11
    s.movz       s8, #11
    v.splat      v11, s3
    a.vread      v14, a2, s8
    vf.fma       v15, v13, v12, v16
    v.extract    s3, v3, #12
    s.movz       s8, #12
    v.splat      v12, s3
    a.vread      v13, a2, s8
    vf.fma       v16, v5, v7, v15
    v.extract    s3, v3, #13
    s.movz       s8, #13
    v.splat      v5, s3
    a.vread      v7, a2, s8
    vf.fma       v15, v6, v8, v16
    v.extract    s3, v3, #14
    s.movz       s8, #14
    v.splat      v6, s3
    a.vread      v8, a2, s8
    vf.fma       v16, v11, v14, v15
    v.extract    s3, v3, #15
    s.movz       s8, #15
    v.splat      v3, s3
    a.vread      v11, a2, s8
    vf.fma       v14, v12, v13, v16
    s.movz       s3, #0
    s.movz       s8, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s11, #0
    s.movz       s14, #1
    vf.fma       v12, v5, v7, v14
    s.movz       s15, #1
    s.movz       s17, #1
    s.movz       s18, #2
    s.movz       s19, #2
    vf.fma       v5, v6, v8, v12
    s.movz       s20, #2
    s.movz       s21, #3
    s.movz       s22, #3
    s.movz       s24, #3
    vf.fma       v6, v3, v11, v5
    s.movz       s25, #4
    a.vwrite     a3, s23, v6
    a.vread      v3, a0, s3
    a.vread      v5, a3, s8
    s.movz       s3, #4
    s.movz       s8, #4
    vf.add       v6, v3, v5
    s.movz       s23, #5
    a.vwrite     a4, s11, v6
    a.vread      v3, a0, s14
    a.vread      v5, a3, s15
    s.movz       s11, #5
    s.movz       s14, #5
    vf.add       v6, v3, v5
    s.movz       s15, #6
    a.vwrite     a4, s17, v6
    a.vread      v3, a0, s18
    a.vread      v5, a3, s19
    s.movz       s17, #6
    s.movz       s18, #6
    vf.add       v6, v3, v5
    s.movz       s19, #7
    a.vwrite     a4, s20, v6
    a.vread      v3, a0, s21
    a.vread      v5, a3, s22
    s.movz       s20, #7
    s.movz       s21, #7
    vf.add       v6, v3, v5
    s.movz       s22, #8
    a.vwrite     a4, s24, v6
    a.vread      v3, a0, s25
    a.vread      v5, a3, s3
    s.movz       s3, #8
    s.movz       s24, #8
    vf.add       v6, v3, v5
    s.movz       s25, #9
    a.vwrite     a4, s8, v6
    a.vread      v3, a0, s23
    a.vread      v5, a3, s11
    s.movz       s8, #9
    s.movz       s11, #9
    vf.add       v6, v3, v5
    s.movz       s23, #10
    a.vwrite     a4, s14, v6
    a.vread      v3, a0, s15
    a.vread      v5, a3, s17
    s.movz       s14, #10
    s.movz       s15, #10
    vf.add       v6, v3, v5
    s.movz       s17, #11
    a.vwrite     a4, s18, v6
    a.vread      v3, a0, s19
    a.vread      v5, a3, s20
    s.movz       s18, #11
    s.movz       s19, #11
    vf.add       v6, v3, v5
    s.movz       s20, #12
    a.vwrite     a4, s21, v6
    a.vread      v3, a0, s22
    a.vread      v5, a3, s3
    s.movz       s3, #12
    s.movz       s21, #12
    vf.add       v6, v3, v5
    s.movz       s22, #13
    a.vwrite     a4, s24, v6
    a.vread      v3, a0, s25
    a.vread      v5, a3, s8
    s.movz       s8, #13
    s.movz       s24, #13
    vf.add       v6, v3, v5
    s.movz       s25, #14
    a.vwrite     a4, s11, v6
    a.vread      v3, a0, s23
    a.vread      v5, a3, s14
    s.movz       s11, #14
    s.movz       s14, #14
    vf.add       v6, v3, v5
    s.movz       s23, #15
    a.vwrite     a4, s15, v6
    a.vread      v3, a0, s17
    a.vread      v5, a3, s18
    s.movz       s15, #15
    s.movz       s17, #15
    vf.add       v6, v3, v5
    s.movz       s18, #0
    a.vwrite     a4, s19, v6
    a.vread      v3, a0, s20
    a.vread      v5, a3, s3
    s.movz       s3, #0
    s.movz       s19, #1
    vf.add       v6, v3, v5
    s.movz       s20, #1
    a.vwrite     a4, s21, v6
    a.vread      v3, a0, s22
    a.vread      v5, a3, s8
    s.movz       s8, #2
    s.movz       s21, #2
    vf.add       v6, v3, v5
    s.movz       s22, #3
    a.vwrite     a4, s24, v6
    a.vread      v3, a0, s25
    a.vread      v5, a3, s11
    s.movz       s11, #3
    s.movz       s24, #4
    vf.add       v6, v3, v5
    s.movz       s25, #4
    a.vwrite     a4, s14, v6
    a.vread      v3, a0, s23
    a.vread      v5, a3, s15
    s.movz       s14, #5
    s.movz       s15, #5
    vf.add       v6, v3, v5
    s.movz       s23, #6
    a.vwrite     a4, s17, v6
    a.vread      v3, a4, s18
    s.movz       s17, #6
    s.movz       s18, #7
    a.vwrite     a0, s3, v3
    a.vread      v3, a4, s19
    s.movz       s3, #7
    s.movz       s19, #8
    a.vwrite     a0, s20, v3
    a.vread      v3, a4, s8
    s.movz       s8, #8
    s.movz       s20, #9
    a.vwrite     a0, s21, v3
    a.vread      v3, a4, s22
    s.movz       s21, #9
    s.movz       s22, #10
    a.vwrite     a0, s11, v3
    a.vread      v3, a4, s24
    s.movz       s11, #10
    s.movz       s24, #11
    a.vwrite     a0, s25, v3
    a.vread      v3, a4, s14
    s.movz       s14, #11
    s.movz       s25, #12
    a.vwrite     a0, s15, v3
    a.vread      v3, a4, s23
    s.movz       s15, #12
    s.movz       s23, #13
    a.vwrite     a0, s17, v3
    a.vread      v3, a4, s18
    s.movz       s17, #13
    s.movz       s18, #14
    a.vwrite     a0, s3, v3
    a.vread      v3, a4, s19
    s.movz       s3, #14
    s.movz       s19, #15
    a.vwrite     a0, s8, v3
    a.vread      v3, a4, s20
    s.movz       s8, #15
    s.add        s20, s13, s12
    a.vwrite     a0, s21, v3
    a.vread      v3, a4, s22
    s.movz       s21, #1
    a.vwrite     a0, s11, v3
    a.vread      v3, a4, s24
    a.vwrite     a0, s14, v3
    a.vread      v3, a4, s25
    a.vwrite     a0, s15, v3
    a.vread      v3, a4, s23
    a.vwrite     a0, s17, v3
    a.vread      v3, a4, s18
    a.vwrite     a0, s3, v3
    a.vread      v3, a4, s19
    a.vwrite     a0, s8, v3
    s.mov        s13, s20
    br.nz        s21, for_5
endfor_6:
    s.muli       s1, s7, #3136                   // a runtime tile origin, x3136
    v.extract    s2, v10, #0
    s.movz       s3, #56
    s.movz       s5, #3136
    v.extract    s7, v10, #1
    s.movz       s8, #0
    v.splat      v0, s2
    v.splat      v3, s3
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s5
    v.splat      v7, s7
    v.extract    s2, v9, #0
    s.add        s3, s8, s1                      // the tile origin
    v.extract    s1, v9, #1
    v.splat      v8, s2
    v.mul        v11, v0, v3
    v.mul        v0, v5, v6
    v.splat      v5, s3
    v.splat      v6, s1
    v.mul        v12, v7, v3
    v.extract    s1, v4, #0
    v.add        v7, v8, v11
    v.add        v8, v0, v5
    v.splat      v0, s1
    v.splat      v5, s10
    v.add        v11, v7, v8
    v.splat      v7, s4
    v.mul        v13, v0, v5
    s.addi       s1, s16, #3136
    v.movi       v0, #8
    v.add        v14, v6, v12
    v.add        v6, v11, v13
    s.addi       s2, s1, #64
    v.movi       v11, #1
    v.add        v12, v7, v6
    v.movi       v6, #0
    v.movi       v13, #1
    v.movi       v15, #0
    v.st.w       [s1, #0], v12
    v.cmp.lt     p1, v4, v0
    v.extract    s3, v4, #1
    v.add        v0, v14, v8
    v.splat      v12, s3
    v.cmp.lt     p2, v10, v1
    v.movi       v14, #1
    @p1 v.sel        v16, v11, v6
    v.mul        v6, v12, v5
    v.movi       v11, #0
    @p2 v.sel        v12, v13, v15
    v.add        v13, v0, v6
    s.addi       s3, s1, #128
    v.cmp.lt     p1, v9, v1
    v.extract    s4, v10, #2
    v.extract    s5, v9, #2
    v.add        v0, v7, v13
    v.splat      v1, s5
    @p1 v.sel        v6, v14, v11
    v.splat      v11, s4
    v.st.w       [s2, #0], v0
    v.movi       v0, #64
    v.mul        v13, v11, v3
    v.cmp.lt     p1, v2, v0
    v.extract    s2, v10, #3
    v.extract    s4, v10, #4
    v.extract    s5, v10, #5
    v.splat      v0, s2
    v.splat      v2, s4
    v.splat      v11, s5
    v.extract    s2, v9, #3
    v.extract    s4, v9, #4
    v.extract    s5, v9, #5
    v.splat      v14, s2
    v.mul        v15, v0, v3
    v.mul        v0, v2, v3
    v.mul        v2, v11, v3
    v.extract    s2, v4, #2
    v.extract    s7, v4, #3
    v.extract    s8, v4, #4
    v.extract    s9, v4, #5
    v.add        v11, v1, v13
    v.splat      v1, s4
    v.add        v13, v14, v15
    v.splat      v14, s5
    v.add        v15, v1, v0
    v.splat      v0, s2
    v.add        v1, v14, v2
    v.splat      v2, s7
    v.add        v14, v11, v8
    v.extract    s2, v9, #6
    v.mul        v11, v0, v5
    v.add        v0, v13, v8
    v.mul        v13, v2, v5
    v.add        v2, v15, v8
    v.add        v15, v1, v8
    v.add        v1, v14, v11
    v.extract    s4, v10, #6
    v.splat      v11, s2
    v.add        v14, v0, v13
    v.splat      v0, s8
    v.add        v13, v7, v1
    v.add        v1, v7, v14
    v.mul        v14, v0, v5
    s.addi       s2, s1, #192
    s.addi       s5, s1, #256
    v.add        v0, v2, v14
    v.splat      v2, s4
    s.addi       s4, s1, #320
    v.add        v14, v7, v0
    s.addi       s7, s1, #384
    v.st.w       [s3, #0], v13
    v.extract    s3, v10, #7
    v.extract    s8, v9, #7
    v.splat      v0, s3
    v.mul        v13, v2, v3
    v.extract    s3, v4, #6
    v.add        v2, v11, v13
    v.splat      v11, s8
    s.addi       s8, s1, #448
    v.add        v13, v2, v8
    v.st.w       [s2, #0], v1
    v.extract    s2, v10, #8
    v.mul        v1, v0, v3
    v.splat      v0, s2
    v.extract    s2, v9, #8
    v.add        v2, v11, v1
    v.splat      v1, s2
    v.extract    s2, v4, #7
    v.add        v11, v2, v8
    v.st.w       [s5, #0], v14
    v.mul        v2, v0, v3
    v.extract    s5, v4, #8
    v.splat      v0, s9
    v.extract    s9, v9, #9
    v.add        v14, v1, v2
    v.splat      v1, s3
    v.mul        v2, v0, v5
    v.add        v0, v14, v8
    v.mul        v14, v1, v5
    v.add        v1, v15, v2
    v.extract    s3, v10, #9
    v.splat      v2, s9
    v.add        v15, v13, v14
    v.splat      v13, s2
    v.add        v14, v7, v1
    v.add        v1, v7, v15
    v.mul        v15, v13, v5
    s.addi       s2, s1, #512
    s.addi       s9, s1, #576
    v.add        v13, v11, v15
    v.splat      v11, s3
    v.st.w       [s4, #0], v14
    v.extract    s3, v10, #10
    v.extract    s4, v9, #10
    v.splat      v14, s3
    v.mul        v15, v11, v3
    v.extract    s3, v4, #9
    v.add        v11, v7, v13
    v.add        v13, v2, v15
    v.splat      v2, s4
    s.addi       s4, s1, #640
    v.add        v15, v13, v8
    v.st.w       [s7, #0], v1
    v.extract    s7, v10, #11
    v.mul        v1, v14, v3
    v.splat      v13, s7
    v.extract    s7, v9, #11
    v.add        v14, v2, v1
    v.splat      v1, s7
    v.extract    s7, v4, #10
    v.add        v2, v14, v8
    v.st.w       [s8, #0], v11
    v.mul        v11, v13, v3
    v.extract    s8, v4, #11
    v.splat      v13, s5
    v.extract    s5, v9, #12
    v.add        v14, v1, v11
    v.splat      v1, s3
    v.mul        v11, v13, v5
    v.add        v13, v14, v8
    v.mul        v14, v1, v5
    v.add        v1, v0, v11
    v.extract    s3, v10, #12
    v.splat      v0, s5
    v.add        v11, v15, v14
    v.splat      v14, s7
    v.add        v15, v7, v1
    v.add        v1, v7, v11
    v.mul        v11, v14, v5
    s.addi       s5, s1, #704
    s.addi       s7, s1, #768
    v.add        v14, v2, v11
    v.splat      v2, s3
    v.st.w       [s2, #0], v15
    v.extract    s2, v10, #13
    v.extract    s3, v9, #13
    v.splat      v11, s2
    v.mul        v15, v2, v3
    v.extract    s2, v4, #12
    v.add        v2, v7, v14
    v.add        v14, v0, v15
    v.splat      v0, s3
    s.addi       s3, s1, #832
    v.add        v15, v14, v8
    v.st.w       [s9, #0], v1
    v.extract    s9, v10, #14
    v.mul        v1, v11, v3
    v.splat      v11, s9
    v.extract    s9, v9, #14
    v.add        v14, v0, v1
    v.splat      v0, s9
    v.extract    s9, v4, #13
    v.add        v1, v14, v8
    v.st.w       [s4, #0], v2
    v.mul        v2, v11, v3
    v.extract    s4, v4, #14
    v.splat      v11, s8
    v.extract    s8, v9, #15
    v.splat      v9, s2
    v.add        v14, v0, v2
    v.splat      v0, s9
    v.mul        v2, v11, v5
    v.mul        v11, v9, v5
    v.mul        v9, v0, v5
    v.add        v0, v14, v8
    v.add        v14, v13, v2
    v.extract    s2, v10, #15
    v.splat      v2, s8
    v.splat      v10, s4
    v.add        v13, v15, v11
    v.add        v11, v1, v9
    v.mul        v1, v10, v5
    v.add        v9, v7, v14
    v.splat      v10, s2
    v.add        v14, v0, v1
    v.add        v0, v7, v13
    v.add        v1, v7, v11
    v.add        v11, v7, v14
    s.addi       s2, s1, #896
    s.addi       s4, s1, #960
    v.st.w       [s5, #0], v9
    v.mul        v9, v10, v3
    v.extract    s1, v4, #15
    s.movz       s5, #0
    v.add        v3, v2, v9
    v.splat      v2, s1
    s.addi       s1, s16, #3136
    v.add        v4, v3, v8
    v.mul        v3, v2, v5
    v.add        v2, v4, v3
    v.add        v3, v7, v2
    v.st.w       [s7, #0], v0
    v.extract    s7, v16, #0
    v.extract    s8, v12, #0
    v.splat      v0, s7
    v.movi       v2, #0
    v.splat      v4, s8
    v.movi       v5, #0
    v.extract    s7, v6, #0
    v.movi       v7, #0
    v.splat      v8, s7
    v.cmp.ne     p2, v0, v2
    v.cmp.ne     p3, v4, v5
    p.and        p4, p2, p3
    v.cmp.ne     p2, v8, v7
    p.and        p3, p4, p2
    v.st.w       [s3, #0], v1
    p.and        p2, p3, p1
    s.movz       s3, #1
    s.addi       s7, s16, #3200
    v.extract    s8, v16, #1
    v.extract    s9, v12, #1
    v.splat      v0, s8
    v.movi       v1, #0
    v.splat      v2, s9
    v.movi       v4, #0
    v.cmp.ne     p3, v0, v1
    v.cmp.ne     p4, v2, v4
    v.st.w       [s2, #0], v11
    v.extract    s2, v6, #1
    v.movi       v0, #0
    v.splat      v1, s2
    p.and        p5, p3, p4
    s.movz       s2, #2
    v.cmp.ne     p3, v1, v0
    p.and        p4, p5, p3
    s.addi       s8, s16, #3264
    p.and        p3, p4, p1
    v.extract    s9, v16, #2
    v.splat      v0, s9
    v.st.w       [s4, #0], v3
    fence.acq_rel.device
    a.vread      v1, a0, s5
    v.extract    s4, v12, #2
    v.movi       v2, #0
    v.splat      v3, s4
    v.movi       v4, #0
    v.cmp.ne     p4, v0, v2
    v.ld.w       v0, [s1, #0]
    v.extract    s1, v6, #2
    v.movi       v2, #0
    v.splat      v5, s1
    s.movz       s1, #3
    s.addi       s4, s16, #3328
    v.extract    s5, v16, #3
    v.movi       v7, #0
    v.splat      v8, s5
    @p2 v.st.scatter.w [s6, v0], v1
    a.vread      v0, a0, s3
    v.cmp.ne     p2, v3, v4
    p.and        p5, p4, p2
    v.cmp.ne     p2, v5, v2
    p.and        p4, p5, p2
    v.extract    s3, v12, #3
    p.and        p2, p4, p1
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s7, #0]
    v.extract    s3, v6, #3
    v.movi       v4, #0
    v.splat      v5, s3
    s.movz       s3, #4
    s.addi       s5, s16, #3392
    v.extract    s7, v16, #4
    v.movi       v7, #0
    v.splat      v8, s7
    @p3 v.st.scatter.w [s6, v3], v0
    a.vread      v0, a0, s2
    v.cmp.ne     p3, v1, v2
    p.and        p5, p4, p3
    v.cmp.ne     p3, v5, v4
    p.and        p4, p5, p3
    v.extract    s2, v12, #4
    p.and        p3, p4, p1
    v.splat      v1, s2
    v.movi       v2, #0
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s8, #0]
    v.extract    s2, v6, #4
    v.movi       v4, #0
    v.splat      v5, s2
    s.movz       s2, #5
    s.addi       s7, s16, #3456
    v.extract    s8, v16, #5
    v.movi       v7, #0
    v.splat      v8, s8
    @p2 v.st.scatter.w [s6, v3], v0
    a.vread      v0, a0, s1
    v.cmp.ne     p2, v1, v2
    p.and        p5, p4, p2
    v.cmp.ne     p2, v5, v4
    p.and        p4, p5, p2
    v.extract    s1, v12, #5
    p.and        p2, p4, p1
    v.splat      v1, s1
    v.movi       v2, #0
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s4, #0]
    v.extract    s1, v6, #5
    v.movi       v4, #0
    v.splat      v5, s1
    s.movz       s1, #6
    s.addi       s4, s16, #3520
    v.extract    s8, v16, #6
    v.movi       v7, #0
    v.splat      v8, s8
    @p3 v.st.scatter.w [s6, v3], v0
    a.vread      v0, a0, s3
    v.cmp.ne     p3, v1, v2
    p.and        p5, p4, p3
    v.cmp.ne     p3, v5, v4
    p.and        p4, p5, p3
    v.extract    s3, v12, #6
    p.and        p3, p4, p1
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s5, #0]
    v.extract    s3, v6, #6
    v.movi       v4, #0
    v.splat      v5, s3
    s.movz       s3, #7
    s.addi       s5, s16, #3584
    v.extract    s8, v16, #7
    v.movi       v7, #0
    v.splat      v8, s8
    @p2 v.st.scatter.w [s6, v3], v0
    a.vread      v0, a0, s2
    v.cmp.ne     p2, v1, v2
    p.and        p5, p4, p2
    v.cmp.ne     p2, v5, v4
    p.and        p4, p5, p2
    v.extract    s2, v12, #7
    p.and        p2, p4, p1
    v.splat      v1, s2
    v.movi       v2, #0
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s7, #0]
    v.extract    s2, v6, #7
    v.movi       v4, #0
    v.splat      v5, s2
    s.movz       s2, #8
    s.addi       s7, s16, #3648
    v.extract    s8, v16, #8
    v.movi       v7, #0
    v.splat      v8, s8
    @p3 v.st.scatter.w [s6, v3], v0
    a.vread      v0, a0, s1
    v.cmp.ne     p3, v1, v2
    p.and        p5, p4, p3
    v.cmp.ne     p3, v5, v4
    p.and        p4, p5, p3
    v.extract    s1, v12, #8
    p.and        p3, p4, p1
    v.splat      v1, s1
    v.movi       v2, #0
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s4, #0]
    v.extract    s1, v6, #8
    v.movi       v4, #0
    v.splat      v5, s1
    s.movz       s1, #9
    s.addi       s4, s16, #3712
    v.extract    s8, v16, #9
    v.movi       v7, #0
    v.splat      v8, s8
    @p2 v.st.scatter.w [s6, v3], v0
    a.vread      v0, a0, s3
    v.cmp.ne     p2, v1, v2
    p.and        p5, p4, p2
    v.cmp.ne     p2, v5, v4
    p.and        p4, p5, p2
    v.extract    s3, v12, #9
    p.and        p2, p4, p1
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s5, #0]
    v.extract    s3, v6, #9
    v.movi       v4, #0
    v.splat      v5, s3
    s.movz       s3, #10
    s.addi       s5, s16, #3776
    v.extract    s8, v16, #10
    v.movi       v7, #0
    v.splat      v8, s8
    @p3 v.st.scatter.w [s6, v3], v0
    a.vread      v0, a0, s2
    v.cmp.ne     p3, v1, v2
    p.and        p5, p4, p3
    v.cmp.ne     p3, v5, v4
    p.and        p4, p5, p3
    v.extract    s2, v12, #10
    p.and        p3, p4, p1
    v.splat      v1, s2
    v.movi       v2, #0
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s7, #0]
    v.extract    s2, v6, #10
    v.movi       v4, #0
    v.splat      v5, s2
    s.movz       s2, #11
    s.addi       s7, s16, #3840
    v.extract    s8, v16, #11
    v.movi       v7, #0
    v.splat      v8, s8
    @p2 v.st.scatter.w [s6, v3], v0
    a.vread      v0, a0, s1
    v.cmp.ne     p2, v1, v2
    p.and        p5, p4, p2
    v.cmp.ne     p2, v5, v4
    p.and        p4, p5, p2
    v.extract    s1, v12, #11
    p.and        p2, p4, p1
    v.splat      v1, s1
    v.movi       v2, #0
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s4, #0]
    v.extract    s1, v6, #11
    v.movi       v4, #0
    v.splat      v5, s1
    s.movz       s1, #12
    s.addi       s4, s16, #3904
    v.extract    s8, v16, #12
    v.movi       v7, #0
    v.splat      v8, s8
    @p3 v.st.scatter.w [s6, v3], v0
    a.vread      v0, a0, s3
    v.cmp.ne     p3, v1, v2
    p.and        p5, p4, p3
    v.cmp.ne     p3, v5, v4
    p.and        p4, p5, p3
    v.extract    s3, v12, #12
    p.and        p3, p4, p1
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s5, #0]
    v.extract    s3, v6, #12
    v.movi       v4, #0
    v.splat      v5, s3
    s.movz       s3, #13
    s.addi       s5, s16, #3968
    v.extract    s8, v16, #13
    v.movi       v7, #0
    v.splat      v8, s8
    @p2 v.st.scatter.w [s6, v3], v0
    a.vread      v0, a0, s2
    v.cmp.ne     p2, v1, v2
    p.and        p5, p4, p2
    v.cmp.ne     p2, v5, v4
    p.and        p4, p5, p2
    v.extract    s2, v12, #13
    p.and        p2, p4, p1
    v.splat      v1, s2
    v.movi       v2, #0
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s7, #0]
    v.extract    s2, v6, #13
    v.movi       v4, #0
    v.splat      v5, s2
    s.movz       s2, #14
    s.addi       s7, s16, #4032
    v.extract    s8, v16, #14
    v.movi       v7, #0
    v.splat      v8, s8
    @p3 v.st.scatter.w [s6, v3], v0
    a.vread      v0, a0, s1
    v.cmp.ne     p3, v1, v2
    p.and        p5, p4, p3
    v.cmp.ne     p3, v5, v4
    p.and        p4, p5, p3
    v.extract    s1, v12, #14
    p.and        p3, p4, p1
    v.splat      v1, s1
    v.movi       v2, #0
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s4, #0]
    v.extract    s1, v6, #14
    v.movi       v4, #0
    v.splat      v5, s1
    s.movz       s1, #15
    s.addi       s4, s16, #4096
    v.extract    s8, v16, #15
    v.movi       v7, #0
    v.splat      v8, s8
    @p2 v.st.scatter.w [s6, v3], v0
    a.vread      v0, a0, s3
    v.cmp.ne     p2, v1, v2
    p.and        p5, p4, p2
    v.cmp.ne     p2, v5, v4
    p.and        p4, p5, p2
    v.extract    s3, v12, #15
    p.and        p2, p4, p1
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s5, #0]
    v.extract    s3, v6, #15
    v.movi       v4, #0
    v.splat      v5, s3
    @p3 v.st.scatter.w [s6, v3], v0
    a.vread      v0, a0, s2
    v.cmp.ne     p3, v1, v2
    p.and        p5, p4, p3
    v.cmp.ne     p3, v5, v4
    p.and        p4, p5, p3
    p.and        p3, p4, p1
    v.ld.w       v1, [s7, #0]
    @p2 v.st.scatter.w [s6, v1], v0
    a.vread      v0, a0, s1
    v.ld.w       v1, [s4, #0]
    @p3 v.st.scatter.w [s6, v1], v0
__rctx_next:
    exit
