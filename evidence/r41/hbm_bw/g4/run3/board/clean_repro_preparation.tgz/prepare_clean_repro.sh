#!/bin/bash
set -eu
src="$HOME/r41run3/runtime_prepared"
out="$HOME/r41run3/clean_repro_source_20261031"
[ ! -e "$out" ] || { echo 'output already exists'; exit 1; }
mkdir -p "$out"
trap 'rc=$?; printf "%s\n" "$rc" > "$out/exit"' EXIT
nice -n 19 tar -C "$src" --exclude='__pycache__' --exclude='*.pyc' --exclude='.git' --exclude='.pytest_cache' -cf "$out/source.tar" .
sha256sum "$out/source.tar" > "$out/source.sha256"
mkdir "$out/src"
nice -n 19 tar -xf "$out/source.tar" -C "$out/src"
cd "$out/src"
"$HOME/tc_env/torchenv/bin/python" - <<'PY'
import json
from pathlib import Path
from archbench.provenance import software_tree
expected='files:e7b332afffab71a7559a42e3b22fe11572758814fb514c9027e22fd64045ca4f'
actual=software_tree(Path.cwd(),refresh=True)
Path('../software_tree.json').write_text(json.dumps({'schema':'r41-clean-source-check/1','software_tree':actual,'expected':expected,'status':'pass' if actual==expected else 'fail'},indent=2)+'\n')
if actual != expected: raise SystemExit('extracted software identity differs')
PY
