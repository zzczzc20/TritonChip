    s.rdspecial  s1, arg_base
    v.movi       v0, #0
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v1, #0
    s.movz       s3, #11
    v.movi       v2, #0
    v.movi       v3, #0
    v.movi       v4, #0
    v.movi       v5, #1
    v.iota       v6                              // arange(0, VLEN)
    v.shl        v7, v4, v5
    v.cmpi.lt    p1, v6, #1
    s.ld.d       s4, [s2, #0]                    // one element, not a vector
    s.lshri      s2, s4, #32
    s.ld.d       s5, [s1, #8]                    // out_ptr1: device_ptr64 at arg_base+8
    v.insert     v0, s4, #0
    v.insert     v1, s2, #0
    v.extract    s1, v0, #0
    v.extract    s2, v1, #0
    s.shli       s4, s2, #32
    s.or         s2, s1, s4
    s.add        s1, s2, s3
    s.addi       s2, s5, #4
    s.lshri      s3, s1, #32
    v.insert     v2, s1, #0
    v.insert     v3, s3, #0
    @p1 v.st.scatter.w [s5, v7], v2
    @p1 v.st.scatter.w [s2, v7], v3
    exit
    exit
