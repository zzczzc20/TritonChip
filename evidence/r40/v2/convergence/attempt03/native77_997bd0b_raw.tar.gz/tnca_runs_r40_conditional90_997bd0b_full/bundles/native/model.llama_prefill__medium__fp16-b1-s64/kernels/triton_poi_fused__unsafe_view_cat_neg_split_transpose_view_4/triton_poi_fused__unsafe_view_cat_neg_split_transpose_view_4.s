    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #4
    v.add        v4, v1, v0
    v.movi       v0, #0
    v.movi       v1, #0
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    v.movi       v6, #0
    @p1 v.sel        v7, v5, v4
    v.cmp.lt     p2, v4, v0
    v.sub        v5, v1, v4
    v.lshr       v8, v7, v3
    v.cmp.lt     p3, v4, v1
    @p3 v.sel        v3, v5, v4
    v.sub        v5, v2, v8
    v.movi       v7, #15
    v.movi       v9, #63
    @p1 v.sel        v10, v5, v8
    v.and        v5, v3, v7
    s.rdspecial  s1, arg_base
    v.sub        v3, v0, v4
    v.sub        v7, v6, v10
    v.cmp.lt     p1, v10, v6
    v.sub        v8, v1, v5
    @p1 v.sel        v11, v7, v10
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    @p2 v.sel        v7, v3, v4
    v.and        v3, v11, v9
    @p3 v.sel        v9, v8, v5
    v.movi       v5, #6144
    v.sub        v8, v6, v3
    v.cmp.lt     p3, v4, v5
    @p1 v.sel        v4, v8, v3
    v.movi       v3, #16
    v.movi       v5, #64
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.movi       v8, #10
    v.cmp.lt     p1, v3, v1
    v.sub        v11, v1, v3
    v.lshr       v1, v7, v8
    v.movi       v7, #32
    v.cmp.lt     p4, v3, v2
    v.sub        v8, v2, v3
    v.mul        v2, v10, v7
    @p1 v.sel        v10, v11, v3
    v.sub        v10, v0, v1
    v.add        v11, v9, v2
    v.cmp.lt     p1, v5, v6
    @p2 v.sel        v2, v10, v1
    v.movi       v1, #192
    v.sub        v10, v6, v5
    v.mul        v6, v2, v7
    v.mul        v2, v4, v1
    v.movi       v1, #1024
    v.add        v4, v9, v6
    @p4 v.sel        v6, v8, v3
    v.sub        v3, v0, v1
    v.add        v6, v4, v2
    v.cmp.lt     p2, v1, v0
    @p1 v.sel        v0, v10, v5
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v0, [s2, v6]               // index is in elements (ISA sec 9.1)
    @p2 v.sel        v2, v3, v1
    @p3 v.st.scatter.h [s3, v11], v0
__rctx_next:
    exit
