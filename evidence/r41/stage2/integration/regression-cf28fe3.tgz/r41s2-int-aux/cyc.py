#!/usr/bin/env python3
"""cyc.py BASE_LOG NEW_LOG: compare per-case cycles of two bench logs (case = name + occurrence)."""
import re, sys
from collections import Counter
def parse(p):
    out, seen, fails = {}, Counter(), 0
    for line in open(p, errors='replace'):
        m = re.match(r'\s*(.+?)\s+(PASS|FAIL)\s+.*?cycles=(\d+)', line)
        if m:
            seen[m[1]] += 1; out[(m[1], seen[m[1]])] = int(m[3]); fails += m[2] == 'FAIL'
        elif re.search(r'\bFAIL\b', line): fails += 1
    return out, fails
b, _ = parse(sys.argv[1]); n, nf = parse(sys.argv[2])
common = [k for k in n if k in b]
ch = [(k, b[k], n[k]) for k in common if b[k] != n[k]]
sb, sn = sum(b[k] for k in common), sum(n[k] for k in common)
print(f"cases={len(n)} fail_lines={nf} common={len(common)} base={sb} new={sn} delta={sn-sb:+d} ({(sn-sb)/max(sb,1)*100:+.2f}%) changed={len(ch)}")
for k, x, y in sorted(ch, key=lambda t: -abs(t[2]-t[1])/t[1])[:6]:
    print(f"   {k[0]}#{k[1]} {x}->{y} ({(y-x)/x*100:+.1f}%)")
