    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, role_id
    s.movz       s2, #512
    s.rdspecial  s3, arg_base
    s.mul        s5, s1, s2
    s.ld.d       s1, [s3, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s2, arg_base
    s.rdspecial  s3, role_id
    s.movz       s6, #512
    s.add        s7, s1, s5                      // this context's own scratch
    s.ld.d       s1, [s2, #8]                    // arg_A: device_ptr64 at arg_base+8
    s.addi       s5, s7, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    .li       s7, #2147483647
    .li       s8, #2147483647
    s.movz       s9, #128
    s.movz       s10, #2
    .li       s11, #68719476752
    .li       s12, #8589934592
    s.rdspecial  s13, arg_base
    s.mul        s14, s3, s6
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    .li       s6, #2147483647
    .li       s15, #2147483647
    s.ld.d       s16, [s2, #16]                  // arg_B: device_ptr64 at arg_base+16
    s.movz       s17, #16
    s.movz       s18, #128
    s.ld.d       s19, [s2, #24]                  // out_ptr1: device_ptr64 at arg_base+24
    s.movz       s2, #0
    s.movz       s20, #0
    s.movz       s21, #0
    s.st.d       [s5, #0], s1
    s.movz       s1, #0
    s.cmp.lt     s22, s17, s21
    s.st.d       [s5, #8], s7
    s.sub        s7, s1, s22
    s.movz       s1, #2
    s.st.d       [s5, #16], s8
    .li       s8, #68719476752
    .li       s21, #8589934592
    s.st.d       [s5, #48], s9
    s.xor        s9, s17, s7
    s.movz       s22, #0
    s.cmp.lt     s22, s4, s2
    s.st.d       [s5, #56], s10
    s.sub        s2, s20, s22
    s.movz       s10, #1
    s.xor        s20, s4, s2
    s.st.d       [s5, #88], s11
    s.sub        s11, s20, s2
    s.movz       s20, #0
    s.st.d       [s5, #104], s12
    s.lshri      s12, s11, #4
    fence.release.device
    td.load      d0, [s5]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.xor        s5, s2, s7
    s.movz       s2, #0
    s.ld.d       s22, [s13, #32]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.cmp.lt     s13, s4, s2
    s.movz       s2, #0
    s.add        s2, s22, s14                    // this context's own scratch
    s.xor        s14, s12, s5
    s.muli       s22, s12, #16
    s.sub        s12, s14, s5
    s.movz       s5, #0
    s.addi       s14, s2, #256                   // TensorMap 1: a tile contiguous down its columns (built once, at entry)
    s.sub        s2, s9, s7
    s.sub        s2, s10, s12
    s.movz       s7, #0
    s.min.s      s9, s2, s10
    s.sub        s2, s7, s13
    s.cmp.lt     s7, s9, s20
    s.movz       s13, #0
    s.sub        s20, s5, s7
    s.movz       s5, #1
    s.st.d       [s14, #0], s16
    s.xor        s7, s4, s2
    s.sub        s16, s11, s22
    s.movz       s11, #0
    s.sub        s16, s7, s2
    s.st.d       [s14, #8], s6
    s.xor        s6, s9, s20
    s.sub        s7, s6, s20
    s.st.d       [s14, #16], s15
    s.addi       s6, s13, #0
    s.addi       s13, s11, #0
    s.st.d       [s14, #48], s18
    s.cmp.eq     s11, s7, s5
    s.st.d       [s14, #56], s1
    s.st.d       [s14, #88], s8
    s.st.d       [s14, #104], s21
    fence.release.device
    td.load      d1, [s14]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.mov        s6, s16
    br.nz        s11, sdiv_done_1
    s.movz       s1, #0
    s.movz       s5, #31
    s.mov        s6, s1
    s.addi       s1, s5, #0
sdiv_2:
    s.lshr       s5, s16, s1
    s.shli       s8, s13, #1
    s.andi       s11, s5, #1
    s.movz       s5, #0
    s.or         s14, s8, s11
    s.movz       s8, #1
    s.cmp.geu    s11, s14, s7
    s.shl        s15, s8, s1
    s.sub        s8, s5, s11
    s.subi       s5, s1, #1
    s.and        s11, s7, s8
    s.and        s18, s15, s8
    s.sub        s8, s14, s11
    s.or         s11, s6, s18
    s.mov        s13, s8
    s.mov        s6, s11
    s.mov        s1, s5
    s.movz       s5, #0
    s.cmp.ge     s8, s1, s5
    br.nz        s8, sdiv_2
sdiv_done_1:
    s.movz       s1, #0
    s.movz       s5, #0
    s.cmp.lt     s6, s4, s1
    s.movz       s1, #0
    s.sub        s7, s5, s6
    s.movz       s5, #0
    s.xor        s6, s4, s7
    s.movz       s4, #0
    s.sub        s8, s6, s7
    s.cmp.lt     s6, s9, s1
    s.lshri      s1, s8, #4
    s.movz       s11, #0
    s.muli       s14, s1, #16
    s.movz       s1, #0
    s.sub        s15, s4, s6
    s.movz       s4, #0
    s.cmp.lt     s6, s17, s11
    s.sub        s11, s8, s14
    s.xor        s8, s9, s15
    s.xor        s9, s11, s7
    s.xor        s11, s13, s2
    s.sub        s13, s9, s7
    s.sub        s7, s4, s6
    s.cmp.lt     s4, s13, s5
    s.sub        s5, s8, s15
    s.sub        s6, s1, s4
    s.movz       s1, #0
    s.xor        s4, s13, s6
    s.movz       s8, #1
    s.sub        s9, s11, s2
    s.xor        s2, s17, s7
    s.sub        s11, s4, s6
    s.movz       s4, #0
    s.addi       s13, s1, #0
    s.cmp.eq     s1, s5, s8
    s.add        s8, s12, s9
    s.sub        s9, s2, s7
    s.addi       s2, s4, #0
    s.mov        s13, s11
    br.nz        s1, sdiv_done_3
    s.movz       s1, #0
    s.movz       s4, #31
    s.mov        s13, s1
    s.addi       s1, s4, #0
sdiv_4:
    s.lshr       s4, s11, s1
    s.shli       s7, s2, #1
    s.andi       s9, s4, #1
    s.movz       s4, #0
    s.or         s12, s7, s9
    s.movz       s7, #1
    s.cmp.geu    s9, s12, s5
    s.shl        s14, s7, s1
    s.sub        s7, s4, s9
    s.subi       s4, s1, #1
    s.and        s9, s5, s7
    s.and        s16, s14, s7
    s.sub        s7, s12, s9
    s.or         s9, s13, s16
    s.mov        s2, s7
    s.mov        s13, s9
    s.mov        s1, s4
    s.movz       s4, #0
    s.cmp.ge     s7, s1, s4
    br.nz        s7, sdiv_4
sdiv_done_3:
    s.xor        s1, s6, s15
    s.mul        s2, s8, s17
    s.xor        s4, s13, s1
    s.movz       s5, #0
    s.sub        s6, s4, s1
    v.splat      v0, s8
    s.mul        s1, s6, s17
    s.andi       s4, s2, #15
    v.splat      v1, s5
    v.splat      v2, s6
    v.splat      v3, s5
    s.andi       s6, s1, #255
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s2
    v.cmp.ge     p1, v0, v1
    v.splat      v0, s1
    v.splat      v1, s4
    v.cmp.ge     p1, v2, v3
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s6
    v.add        v6, v5, v4
    v.iota       v5                              // arange(0, VLEN)
    v.add        v6, v0, v4
    v.add        v0, v1, v2
    v.add        v0, v3, v5
    s.movz       s7, #4
    s.addi       s8, s5, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s5, s8, s7
    br.nz        s5, endfor_6
    s.mul        s5, s8, s17
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s9, b0, #0, #1                  // 0 arrival(s), 1 operation(s)
    s.add        s11, s8, s10
    s.movz       s12, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s13, s4                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s14, s5                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s13, s9
    mb.wait      s9
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s13, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s14, s6                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s5                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s14, s13
    mb.wait      s13
    mb.arm       s5, b2, #0, #1                  // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.f16 a0, v56, v48, s5
    mb.wait      s5
    s.mov        s8, s11
    br.nz        s12, for_5
endfor_6:
    s.movz       s4, #0
    s.movz       s6, #0
    s.add        s7, s4, s1                      // the tile origin
    s.muli       s4, s1, #2                      // a runtime tile origin, x2
    s.add        s8, s6, s2                      // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s7
    s.movz       s6, #256
    v.splat      v2, s8
    v.splat      v3, s17
    v.add        v4, v0, v1
    v.splat      v0, s6
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v4, v0
    s.add        s6, s3, s4                      // the tile origin
    s.movz       s3, #0
    p.and        p3, p1, p2
    a.vread      v0, a0, s3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s6, #0]
    s.addi       s3, s8, #1
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s4, #0
    v.splat      v2, s3
    s.movz       s3, #1
    v.cmp.lt     p1, v2, v3
    vf.cvt.f16.f32 v2, v1
    p.and        p3, p1, p2
    s.addi       s7, s8, #2
    s.movz       s10, #1
    vf.add       v1, v0, v2
    v.splat      v0, s7
    s.movz       s7, #2
    v.cmp.lt     p1, v0, v3
    vf.cvt.f32.f16 v0, v1
    p.and        p4, p1, p2
    s.addi       s11, s8, #3
    s.movz       s12, #2
    vf.cvt.f16.f32 v1, v0
    v.splat      v0, s11
    s.movz       s11, #3
    a.vwrite     a1, s4, v1
    a.vread      v1, a0, s3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s6, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s3, s8, #4
    s.movz       s4, #3
    v.splat      v0, s3
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #4
    vf.add       v2, v1, v4
    vf.cvt.f32.f16 v1, v2
    vf.cvt.f16.f32 v2, v1
    a.vwrite     a1, s10, v2
    a.vread      v1, a0, s7
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s6, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s7, s8, #5
    s.movz       s10, #4
    v.splat      v0, s7
    vf.cvt.f16.f32 v4, v2
    s.movz       s7, #5
    vf.add       v2, v1, v4
    vf.cvt.f32.f16 v1, v2
    vf.cvt.f16.f32 v2, v1
    a.vwrite     a1, s12, v2
    a.vread      v1, a0, s11
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s6, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s11, s8, #6
    s.movz       s12, #5
    v.splat      v0, s11
    vf.cvt.f16.f32 v4, v2
    s.movz       s11, #6
    vf.add       v2, v1, v4
    vf.cvt.f32.f16 v1, v2
    vf.cvt.f16.f32 v2, v1
    a.vwrite     a1, s4, v2
    a.vread      v1, a0, s3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s6, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s3, s8, #7
    s.movz       s4, #6
    v.splat      v0, s3
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #7
    vf.add       v2, v1, v4
    vf.cvt.f32.f16 v1, v2
    vf.cvt.f16.f32 v2, v1
    a.vwrite     a1, s10, v2
    a.vread      v1, a0, s7
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s6, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s7, s8, #8
    s.movz       s10, #7
    v.splat      v0, s7
    vf.cvt.f16.f32 v4, v2
    s.movz       s7, #8
    vf.add       v2, v1, v4
    vf.cvt.f32.f16 v1, v2
    vf.cvt.f16.f32 v2, v1
    a.vwrite     a1, s12, v2
    a.vread      v1, a0, s11
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s6, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s11, s8, #9
    s.movz       s12, #8
    v.splat      v0, s11
    vf.cvt.f16.f32 v4, v2
    s.movz       s11, #9
    vf.add       v2, v1, v4
    vf.cvt.f32.f16 v1, v2
    vf.cvt.f16.f32 v2, v1
    a.vwrite     a1, s4, v2
    a.vread      v1, a0, s3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s6, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s3, s8, #10
    s.movz       s4, #9
    v.splat      v0, s3
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #10
    vf.add       v2, v1, v4
    vf.cvt.f32.f16 v1, v2
    vf.cvt.f16.f32 v2, v1
    a.vwrite     a1, s10, v2
    a.vread      v1, a0, s7
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s6, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s7, s8, #11
    s.movz       s10, #10
    v.splat      v0, s7
    vf.cvt.f16.f32 v4, v2
    s.movz       s7, #11
    vf.add       v2, v1, v4
    vf.cvt.f32.f16 v1, v2
    vf.cvt.f16.f32 v2, v1
    a.vwrite     a1, s12, v2
    a.vread      v1, a0, s11
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s6, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s11, s8, #12
    s.movz       s12, #11
    v.splat      v0, s11
    vf.cvt.f16.f32 v4, v2
    s.movz       s11, #12
    vf.add       v2, v1, v4
    vf.cvt.f32.f16 v1, v2
    vf.cvt.f16.f32 v2, v1
    a.vwrite     a1, s4, v2
    a.vread      v1, a0, s3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s6, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s3, s8, #13
    s.movz       s4, #12
    v.splat      v0, s3
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #13
    vf.add       v2, v1, v4
    vf.cvt.f32.f16 v1, v2
    vf.cvt.f16.f32 v2, v1
    a.vwrite     a1, s10, v2
    a.vread      v1, a0, s7
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s6, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s7, s8, #14
    s.movz       s10, #13
    v.splat      v0, s7
    vf.cvt.f16.f32 v4, v2
    s.movz       s7, #14
    vf.add       v2, v1, v4
    vf.cvt.f32.f16 v1, v2
    vf.cvt.f16.f32 v2, v1
    a.vwrite     a1, s12, v2
    a.vread      v1, a0, s11
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s6, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s11, s8, #15
    s.movz       s12, #14
    v.splat      v0, s11
    vf.cvt.f16.f32 v4, v2
    s.movz       s11, #15
    .li       s14, #1027024659
    v.splat      v2, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s14, #1061962282
    v.splat      v5, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v6, v1, v4
    .li       s14, #1056964608
    v.splat      v1, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cvt.f32.f16 v4, v6
    vf.cvt.f16.f32 v6, v4
    a.vwrite     a1, s4, v6
    a.vread      v4, a0, s3
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v6, [s6, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.movz       s3, #15
    s.movz       s4, #0
    vf.cvt.f16.f32 v0, v6
    vf.add       v6, v4, v0
    vf.cvt.f32.f16 v0, v6
    vf.cvt.f16.f32 v4, v0
    a.vwrite     a1, s10, v4
    a.vread      v0, a0, s7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s6, #0]
    s.movz       s7, #0
    s.movz       s10, #0
    vf.cvt.f16.f32 v6, v4
    vf.add       v4, v0, v6
    vf.cvt.f32.f16 v0, v4
    vf.cvt.f16.f32 v4, v0
    a.vwrite     a1, s12, v4
    a.vread      v0, a0, s11
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s6, #0]
    s.movz       s6, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s11, #0
    s.movz       s12, #1
    vf.cvt.f16.f32 v6, v4
    vf.add       v4, v0, v6
    vf.cvt.f32.f16 v0, v4
    vf.cvt.f16.f32 v4, v0
    a.vwrite     a1, s3, v4
    a.vread      v0, a1, s4
    a.vread      v4, a1, s7
    a.vread      v6, a1, s10
    a.vread      v7, a1, s6
    vf.mul       v8, v4, v6
    s.movz       s3, #1
    s.movz       s4, #1
    s.movz       s6, #1
    vf.mul       v4, v8, v7
    s.movz       s7, #1
    s.movz       s10, #2
    vf.mul       v6, v4, v2
    vf.add       v4, v0, v6
    vf.mul       v0, v4, v5
    a.vwrite     a2, s11, v0
    a.vread      v0, a1, s12
    a.vread      v4, a1, s3
    a.vread      v6, a1, s4
    a.vread      v7, a1, s6
    vf.mul       v8, v4, v6
    s.movz       s3, #2
    s.movz       s4, #2
    s.movz       s6, #2
    vf.mul       v4, v8, v7
    s.movz       s11, #2
    s.movz       s12, #3
    vf.mul       v6, v4, v2
    vf.add       v4, v0, v6
    vf.mul       v0, v4, v5
    a.vwrite     a2, s7, v0
    a.vread      v0, a1, s10
    a.vread      v4, a1, s3
    a.vread      v6, a1, s4
    a.vread      v7, a1, s6
    vf.mul       v8, v4, v6
    s.movz       s3, #3
    s.movz       s4, #3
    s.movz       s6, #3
    vf.mul       v4, v8, v7
    s.movz       s7, #3
    s.movz       s10, #4
    vf.mul       v6, v4, v2
    vf.add       v4, v0, v6
    vf.mul       v0, v4, v5
    a.vwrite     a2, s11, v0
    a.vread      v0, a1, s12
    a.vread      v4, a1, s3
    a.vread      v6, a1, s4
    a.vread      v7, a1, s6
    vf.mul       v8, v4, v6
    s.movz       s3, #4
    s.movz       s4, #4
    s.movz       s6, #4
    vf.mul       v4, v8, v7
    s.movz       s11, #4
    s.movz       s12, #5
    vf.mul       v6, v4, v2
    vf.add       v4, v0, v6
    vf.mul       v0, v4, v5
    a.vwrite     a2, s7, v0
    a.vread      v0, a1, s10
    a.vread      v4, a1, s3
    a.vread      v6, a1, s4
    a.vread      v7, a1, s6
    vf.mul       v8, v4, v6
    s.movz       s3, #5
    s.movz       s4, #5
    s.movz       s6, #5
    vf.mul       v4, v8, v7
    s.movz       s7, #5
    s.movz       s10, #6
    vf.mul       v6, v4, v2
    vf.add       v4, v0, v6
    vf.mul       v0, v4, v5
    a.vwrite     a2, s11, v0
    a.vread      v0, a1, s12
    a.vread      v4, a1, s3
    a.vread      v6, a1, s4
    a.vread      v7, a1, s6
    vf.mul       v8, v4, v6
    s.movz       s3, #6
    s.movz       s4, #6
    s.movz       s6, #6
    vf.mul       v4, v8, v7
    s.movz       s11, #6
    s.movz       s12, #7
    vf.mul       v6, v4, v2
    vf.add       v4, v0, v6
    vf.mul       v0, v4, v5
    a.vwrite     a2, s7, v0
    a.vread      v0, a1, s10
    a.vread      v4, a1, s3
    a.vread      v6, a1, s4
    a.vread      v7, a1, s6
    vf.mul       v8, v4, v6
    s.movz       s3, #7
    s.movz       s4, #7
    s.movz       s6, #7
    vf.mul       v4, v8, v7
    s.movz       s7, #7
    s.movz       s10, #8
    vf.mul       v6, v4, v2
    vf.add       v4, v0, v6
    vf.mul       v0, v4, v5
    a.vwrite     a2, s11, v0
    a.vread      v0, a1, s12
    a.vread      v4, a1, s3
    a.vread      v6, a1, s4
    a.vread      v7, a1, s6
    vf.mul       v8, v4, v6
    s.movz       s3, #8
    s.movz       s4, #8
    s.movz       s6, #8
    vf.mul       v4, v8, v7
    s.movz       s11, #8
    s.movz       s12, #9
    vf.mul       v6, v4, v2
    vf.add       v4, v0, v6
    vf.mul       v0, v4, v5
    a.vwrite     a2, s7, v0
    a.vread      v0, a1, s10
    a.vread      v4, a1, s3
    a.vread      v6, a1, s4
    a.vread      v7, a1, s6
    vf.mul       v8, v4, v6
    s.movz       s3, #9
    s.movz       s4, #9
    s.movz       s6, #9
    vf.mul       v4, v8, v7
    s.movz       s7, #9
    s.movz       s10, #10
    vf.mul       v6, v4, v2
    vf.add       v4, v0, v6
    vf.mul       v0, v4, v5
    a.vwrite     a2, s11, v0
    a.vread      v0, a1, s12
    a.vread      v4, a1, s3
    a.vread      v6, a1, s4
    a.vread      v7, a1, s6
    vf.mul       v8, v4, v6
    s.movz       s3, #10
    s.movz       s4, #10
    s.movz       s6, #10
    vf.mul       v4, v8, v7
    s.movz       s11, #10
    s.movz       s12, #11
    vf.mul       v6, v4, v2
    vf.add       v4, v0, v6
    vf.mul       v0, v4, v5
    a.vwrite     a2, s7, v0
    a.vread      v0, a1, s10
    a.vread      v4, a1, s3
    a.vread      v6, a1, s4
    a.vread      v7, a1, s6
    vf.mul       v8, v4, v6
    s.movz       s3, #11
    s.movz       s4, #11
    s.movz       s6, #11
    vf.mul       v4, v8, v7
    s.movz       s7, #11
    s.movz       s10, #12
    vf.mul       v6, v4, v2
    vf.add       v4, v0, v6
    vf.mul       v0, v4, v5
    a.vwrite     a2, s11, v0
    a.vread      v0, a1, s12
    a.vread      v4, a1, s3
    a.vread      v6, a1, s4
    a.vread      v7, a1, s6
    vf.mul       v8, v4, v6
    s.movz       s3, #12
    s.movz       s4, #12
    s.movz       s6, #12
    vf.mul       v4, v8, v7
    s.movz       s11, #12
    s.movz       s12, #13
    vf.mul       v6, v4, v2
    vf.add       v4, v0, v6
    vf.mul       v0, v4, v5
    a.vwrite     a2, s7, v0
    a.vread      v0, a1, s10
    a.vread      v4, a1, s3
    a.vread      v6, a1, s4
    a.vread      v7, a1, s6
    vf.mul       v8, v4, v6
    s.movz       s3, #13
    s.movz       s4, #13
    s.movz       s6, #13
    vf.mul       v4, v8, v7
    s.movz       s7, #13
    s.movz       s10, #14
    vf.mul       v6, v4, v2
    vf.add       v4, v0, v6
    .li       s14, #3221225472
    v.splat      v0, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v6, v4, v5
    a.vwrite     a2, s11, v6
    a.vread      v4, a1, s12
    a.vread      v6, a1, s3
    a.vread      v7, a1, s4
    a.vread      v8, a1, s6
    vf.mul       v9, v6, v7
    s.movz       s3, #14
    s.movz       s4, #14
    s.movz       s6, #14
    vf.mul       v6, v9, v8
    s.movz       s11, #14
    s.movz       s12, #15
    .li       s14, #1069066811
    v.splat      v7, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v8, v6, v2
    .li       s14, #1060205080
    v.splat      v6, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v9, v4, v8
    vf.mul       v4, v9, v5
    a.vwrite     a2, s7, v4
    a.vread      v4, a1, s10
    a.vread      v8, a1, s3
    a.vread      v9, a1, s4
    a.vread      v10, a1, s6
    vf.mul       v11, v8, v9
    s.movz       s3, #15
    s.movz       s4, #15
    s.movz       s6, #15
    vf.mul       v8, v11, v10
    s.movz       s7, #15
    s.movz       s10, #0
    vf.mul       v9, v8, v2
    vf.add       v8, v4, v9
    vf.mul       v4, v8, v5
    a.vwrite     a2, s11, v4
    a.vread      v4, a1, s12
    a.vread      v8, a1, s3
    a.vread      v9, a1, s4
    a.vread      v10, a1, s6
    vf.mul       v11, v8, v9
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s3, #0
    s.movz       s4, #1
    s.movz       s6, #1
    vf.mul       v8, v11, v10
    s.movz       s11, #2
    s.movz       s12, #2
    vf.mul       v9, v8, v2
    vf.add       v2, v4, v9
    vf.mul       v4, v2, v5
    a.vwrite     a2, s7, v4
    a.vread      v2, a2, s10
    s.movz       s7, #3
    vf.abs       v4, v2
    s.movz       s10, #3
    vf.mul       v2, v4, v0
    vf.mul       v4, v2, v7
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v2, v7, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v8, v6
    vf.fma       v4, v5, v2, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v2, v4, v5
    a.vwrite     a3, s3, v2
    a.vread      v2, a2, s4
    s.movz       s3, #4
    vf.abs       v4, v2
    s.movz       s4, #4
    vf.mul       v2, v4, v0
    vf.mul       v4, v2, v7
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v2, v7, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v8, v6
    vf.fma       v4, v5, v2, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v2, v4, v5
    a.vwrite     a3, s6, v2
    a.vread      v2, a2, s11
    s.movz       s6, #5
    vf.abs       v4, v2
    s.movz       s11, #5
    vf.mul       v2, v4, v0
    vf.mul       v4, v2, v7
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v2, v7, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v8, v6
    vf.fma       v4, v5, v2, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v2, v4, v5
    a.vwrite     a3, s12, v2
    a.vread      v2, a2, s7
    s.movz       s7, #6
    vf.abs       v4, v2
    s.movz       s12, #6
    vf.mul       v2, v4, v0
    vf.mul       v4, v2, v7
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v2, v7, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v8, v6
    vf.fma       v4, v5, v2, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v2, v4, v5
    a.vwrite     a3, s10, v2
    a.vread      v2, a2, s3
    s.movz       s3, #7
    vf.abs       v4, v2
    s.movz       s10, #7
    vf.mul       v2, v4, v0
    vf.mul       v4, v2, v7
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v2, v7, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v8, v6
    vf.fma       v4, v5, v2, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v2, v4, v5
    a.vwrite     a3, s4, v2
    a.vread      v2, a2, s6
    s.movz       s4, #8
    vf.abs       v4, v2
    s.movz       s6, #8
    vf.mul       v2, v4, v0
    vf.mul       v4, v2, v7
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v2, v7, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v8, v6
    vf.fma       v4, v5, v2, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v2, v4, v5
    a.vwrite     a3, s11, v2
    a.vread      v2, a2, s7
    s.movz       s7, #9
    vf.abs       v4, v2
    s.movz       s11, #9
    vf.mul       v2, v4, v0
    vf.mul       v4, v2, v7
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v2, v7, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v8, v6
    vf.fma       v4, v5, v2, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v2, v4, v5
    a.vwrite     a3, s12, v2
    a.vread      v2, a2, s3
    s.movz       s3, #10
    vf.abs       v4, v2
    s.movz       s12, #10
    vf.mul       v2, v4, v0
    vf.mul       v4, v2, v7
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v2, v7, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v8, v6
    vf.fma       v4, v5, v2, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v2, v4, v5
    a.vwrite     a3, s10, v2
    a.vread      v2, a2, s4
    s.movz       s4, #11
    vf.abs       v4, v2
    s.movz       s10, #11
    vf.mul       v2, v4, v0
    vf.mul       v4, v2, v7
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v2, v7, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v8, v6
    vf.fma       v4, v5, v2, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v2, v4, v5
    a.vwrite     a3, s6, v2
    a.vread      v2, a2, s7
    s.movz       s6, #12
    vf.abs       v4, v2
    s.movz       s7, #12
    vf.mul       v2, v4, v0
    vf.mul       v4, v2, v7
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v2, v7, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v8, v6
    vf.fma       v4, v5, v2, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v2, v4, v5
    a.vwrite     a3, s11, v2
    a.vread      v2, a2, s3
    s.movz       s3, #13
    vf.abs       v4, v2
    s.movz       s11, #13
    vf.mul       v2, v4, v0
    vf.mul       v4, v2, v7
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v2, v7, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v8, v6
    vf.fma       v4, v5, v2, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v2, v4, v5
    a.vwrite     a3, s12, v2
    a.vread      v2, a2, s4
    s.movz       s4, #14
    vf.abs       v4, v2
    s.movz       s12, #14
    vf.mul       v2, v4, v0
    vf.mul       v4, v2, v7
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v2, v7, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v8, v6
    vf.fma       v4, v5, v2, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v2, v4, v5
    a.vwrite     a3, s10, v2
    a.vread      v2, a2, s6
    s.movz       s6, #15
    vf.abs       v4, v2
    s.movz       s10, #15
    vf.mul       v2, v4, v0
    .li       s14, #1065353216
    v.splat      v4, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v5, v2, v7
    .li       s14, #1065353216
    v.splat      v8, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.exp2.approx v9, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v2, v7, v5                 // the exact rounding error of x*log2(e)
    vf.mul       v2, v10, v6
    vf.fma       v5, v9, v2, v9                  // 2**t * 2**d
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v2, v5, v9
    a.vwrite     a3, s7, v2
    a.vread      v2, a2, s3
    s.movz       s3, #0
    vf.abs       v5, v2
    s.movz       s7, #0
    .li       s14, #1065353216
    v.splat      v2, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v9, v5, v0
    vf.mul       v5, v9, v7
    v.exp2.approx v10, v5                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v11, v9, v7, v5                 // the exact rounding error of x*log2(e)
    vf.mul       v5, v11, v6
    vf.fma       v9, v10, v5, v10                // 2**t * 2**d
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v5, v9, v10
    a.vwrite     a3, s11, v5
    a.vread      v5, a2, s4
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s4, #0
    vf.abs       v9, v5
    s.movz       s11, #1
    vf.mul       v5, v9, v0
    vf.mul       v9, v5, v7
    v.exp2.approx v10, v9                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v11, v5, v7, v9                 // the exact rounding error of x*log2(e)
    vf.mul       v5, v11, v6
    vf.fma       v9, v10, v5, v10                // 2**t * 2**d
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v5, v9, v10
    a.vwrite     a3, s12, v5
    a.vread      v5, a2, s6
    s.movz       s6, #1
    vf.abs       v9, v5
    s.movz       s12, #1
    vf.mul       v5, v9, v0
    vf.mul       v0, v5, v7
    v.exp2.approx v9, v0                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v5, v7, v0                 // the exact rounding error of x*log2(e)
    vf.mul       v0, v10, v6
    vf.fma       v5, v9, v0, v9                  // 2**t * 2**d
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v0, v5, v9
    a.vwrite     a3, s10, v0
    a.vread      v0, a3, s3
    a.vread      v5, a3, s7
    vf.sub       v6, v4, v0
    vf.add       v0, v5, v8
    s.movz       s3, #2
    s.movz       s7, #2
    s.movz       s10, #2
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v0, v5, v2
    vf.fms       v0, v5, v7, v5
    vf.neg       v7, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v0, v7, v5
    vf.mul       v5, v6, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s4, v5
    a.vread      v0, a3, s11
    a.vread      v5, a3, s6
    vf.sub       v6, v4, v0
    vf.add       v0, v5, v8
    s.movz       s4, #3
    s.movz       s6, #3
    s.movz       s11, #3
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v0, v5, v2
    vf.fms       v0, v5, v7, v5
    vf.neg       v7, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v0, v7, v5
    vf.mul       v5, v6, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s12, v5
    a.vread      v0, a3, s3
    a.vread      v5, a3, s7
    vf.sub       v6, v4, v0
    vf.add       v0, v5, v8
    s.movz       s3, #4
    s.movz       s7, #4
    s.movz       s12, #4
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v0, v5, v2
    vf.fms       v0, v5, v7, v5
    vf.neg       v7, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v0, v7, v5
    vf.mul       v5, v6, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s10, v5
    a.vread      v0, a3, s4
    a.vread      v5, a3, s6
    vf.sub       v6, v4, v0
    vf.add       v0, v5, v8
    s.movz       s4, #5
    s.movz       s6, #5
    s.movz       s10, #5
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v0, v5, v2
    vf.fms       v0, v5, v7, v5
    vf.neg       v7, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v0, v7, v5
    vf.mul       v5, v6, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s11, v5
    a.vread      v0, a3, s3
    a.vread      v5, a3, s7
    vf.sub       v6, v4, v0
    vf.add       v0, v5, v8
    s.movz       s3, #6
    s.movz       s7, #6
    s.movz       s11, #6
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v0, v5, v2
    vf.fms       v0, v5, v7, v5
    vf.neg       v7, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v0, v7, v5
    vf.mul       v5, v6, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s12, v5
    a.vread      v0, a3, s4
    a.vread      v5, a3, s6
    vf.sub       v6, v4, v0
    vf.add       v0, v5, v8
    s.movz       s4, #7
    s.movz       s6, #7
    s.movz       s12, #7
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v0, v5, v2
    vf.fms       v0, v5, v7, v5
    vf.neg       v7, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v0, v7, v5
    vf.mul       v5, v6, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s10, v5
    a.vread      v0, a3, s3
    a.vread      v5, a3, s7
    vf.sub       v6, v4, v0
    vf.add       v0, v5, v8
    s.movz       s3, #8
    s.movz       s7, #8
    s.movz       s10, #8
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v0, v5, v2
    vf.fms       v0, v5, v7, v5
    vf.neg       v7, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v0, v7, v5
    vf.mul       v5, v6, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s11, v5
    a.vread      v0, a3, s4
    a.vread      v5, a3, s6
    vf.sub       v6, v4, v0
    vf.add       v0, v5, v8
    s.movz       s4, #9
    s.movz       s6, #9
    s.movz       s11, #9
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v0, v5, v2
    vf.fms       v0, v5, v7, v5
    vf.neg       v7, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v0, v7, v5
    vf.mul       v5, v6, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s12, v5
    a.vread      v0, a3, s3
    a.vread      v5, a3, s7
    vf.sub       v6, v4, v0
    vf.add       v0, v5, v8
    s.movz       s3, #10
    s.movz       s7, #10
    s.movz       s12, #10
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v0, v5, v2
    vf.fms       v0, v5, v7, v5
    vf.neg       v7, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v0, v7, v5
    vf.mul       v5, v6, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s10, v5
    a.vread      v0, a3, s4
    a.vread      v5, a3, s6
    vf.sub       v6, v4, v0
    vf.add       v0, v5, v8
    s.movz       s4, #11
    s.movz       s6, #11
    s.movz       s10, #11
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v0, v5, v2
    vf.fms       v0, v5, v7, v5
    vf.neg       v7, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v0, v7, v5
    vf.mul       v5, v6, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s11, v5
    a.vread      v0, a3, s3
    a.vread      v5, a3, s7
    vf.sub       v6, v4, v0
    vf.add       v0, v5, v8
    s.movz       s3, #12
    s.movz       s7, #12
    s.movz       s11, #12
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v0, v5, v2
    vf.fms       v0, v5, v7, v5
    vf.neg       v7, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v0, v7, v5
    vf.mul       v5, v6, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s12, v5
    a.vread      v0, a3, s4
    a.vread      v5, a3, s6
    vf.sub       v6, v4, v0
    vf.add       v0, v5, v8
    s.movz       s4, #13
    s.movz       s6, #13
    s.movz       s12, #13
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v0, v5, v2
    vf.fms       v0, v5, v7, v5
    vf.neg       v7, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v0, v7, v5
    vf.mul       v5, v6, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s10, v5
    a.vread      v0, a3, s3
    a.vread      v5, a3, s7
    vf.sub       v6, v4, v0
    vf.add       v0, v5, v8
    s.movz       s3, #14
    s.movz       s7, #14
    s.movz       s10, #14
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v0, v5, v2
    vf.fms       v0, v5, v7, v5
    vf.neg       v7, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v0, v7, v5
    v.movi       v5, #0
    vf.mul       v7, v6, v0                      // a/y as a refined reciprocal (ISA has no divide)
    .li       s14, #1065353216
    v.splat      v0, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    a.vwrite     a4, s11, v7
    a.vread      v6, a3, s4
    a.vread      v7, a3, s6
    vf.sub       v9, v4, v6
    vf.add       v6, v7, v8
    s.movz       s4, #15
    s.movz       s6, #15
    s.movz       s11, #15
    v.rcp.approx v7, v6                          // ISA 8.8: <= 2**-22 relative
    s.muli       s14, s1, #2                     // a runtime tile origin, x2
    s.muli       s1, s2, #512                    // a runtime tile origin, x512
    s.add        s2, s19, s14                    // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s14, #0
    s.add        s15, s2, s1                     // the tile origin
    s.movz       s1, #0
    vf.fms       v10, v6, v7, v2
    vf.fms       v6, v7, v10, v7
    vf.neg       v10, v6                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v10, v10
    @p1 v.sel        v6, v10, v7
    vf.mul       v7, v9, v6                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s12, v7
    a.vread      v6, a3, s3
    a.vread      v7, a3, s7
    vf.sub       v9, v4, v6
    vf.add       v6, v7, v8
    s.movz       s2, #0
    s.movz       s3, #0
    v.splat      v7, s8
    v.rcp.approx v10, v6                         // ISA 8.8: <= 2**-22 relative
    v.cmp.lt     p1, v7, v3
    p.and        p3, p1, p2
    s.movz       s7, #1
    vf.fms       v7, v6, v10, v2
    vf.fms       v6, v10, v7, v10
    vf.neg       v7, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v6, v7, v10
    vf.mul       v7, v9, v6                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s10, v7
    a.vread      v6, a3, s4
    a.vread      v7, a3, s6
    vf.sub       v9, v4, v6
    vf.add       v4, v7, v8
    s.movz       s4, #1
    s.movz       s6, #1
    s.movz       s10, #1
    v.rcp.approx v6, v4                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v4, v6, v2
    vf.fms       v2, v6, v7, v6
    vf.neg       v4, v2                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v2, v4, v6
    vf.mul       v4, v9, v2                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s11, v4
    a.vread      v2, a1, s14
    a.vread      v4, a2, s1
    a.vread      v6, a4, s2
    a.vread      v7, a4, s3
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.addi       s1, s8, #1
    @p1 v.sel        v2, v8, v7
    v.splat      v6, s1
    vf.add       v7, v2, v0
    v.cmp.lt     p1, v6, v3
    s.addi       s1, s15, #512                   // row 1
    p.and        p4, p1, p2
    vf.mul       v2, v4, v7
    s.movz       s2, #2
    s.movz       s3, #2
    s.movz       s11, #2
    vf.cvt.f32.f16 v4, v2
    s.movz       s12, #2
    @p3 v.st.h       [s15, #0], v4
    a.vread      v2, a1, s7
    a.vread      v4, a2, s4
    a.vread      v6, a4, s6
    a.vread      v7, a4, s10
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.addi       s4, s8, #2
    @p1 v.sel        v2, v8, v7
    v.splat      v6, s4
    vf.add       v7, v2, v0
    v.cmp.lt     p1, v6, v3
    s.addi       s4, s15, #1024                  // row 2
    p.and        p3, p1, p2
    vf.mul       v2, v4, v7
    s.movz       s6, #3
    s.movz       s7, #3
    s.movz       s10, #3
    vf.cvt.f32.f16 v4, v2
    @p4 v.st.h       [s1, #0], v4
    a.vread      v2, a1, s2
    a.vread      v4, a2, s3
    a.vread      v6, a4, s11
    a.vread      v7, a4, s12
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.movz       s1, #3
    @p1 v.sel        v2, v8, v7
    s.addi       s2, s8, #3
    vf.add       v6, v2, v0
    v.splat      v2, s2
    s.addi       s2, s15, #1536                  // row 3
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v4, v6
    p.and        p4, p1, p2
    s.movz       s3, #4
    s.movz       s11, #4
    vf.cvt.f32.f16 v4, v2
    s.movz       s12, #4
    @p3 v.st.h       [s4, #0], v4
    a.vread      v2, a1, s6
    a.vread      v4, a2, s7
    a.vread      v6, a4, s10
    a.vread      v7, a4, s1
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.movz       s1, #4
    @p1 v.sel        v2, v8, v7
    s.addi       s4, s8, #4
    vf.add       v6, v2, v0
    v.splat      v2, s4
    s.addi       s4, s15, #2048                  // row 4
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v4, v6
    p.and        p3, p1, p2
    s.movz       s6, #5
    s.movz       s7, #5
    vf.cvt.f32.f16 v4, v2
    s.movz       s10, #5
    @p4 v.st.h       [s2, #0], v4
    a.vread      v2, a1, s3
    a.vread      v4, a2, s11
    a.vread      v6, a4, s12
    a.vread      v7, a4, s1
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.movz       s1, #5
    @p1 v.sel        v2, v8, v7
    s.addi       s2, s8, #5
    vf.add       v6, v2, v0
    v.splat      v2, s2
    s.addi       s2, s15, #2560                  // row 5
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v4, v6
    p.and        p4, p1, p2
    s.movz       s3, #6
    s.movz       s11, #6
    vf.cvt.f32.f16 v4, v2
    s.movz       s12, #6
    @p3 v.st.h       [s4, #0], v4
    a.vread      v2, a1, s6
    a.vread      v4, a2, s7
    a.vread      v6, a4, s10
    a.vread      v7, a4, s1
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.movz       s1, #6
    @p1 v.sel        v2, v8, v7
    s.addi       s4, s8, #6
    vf.add       v6, v2, v0
    v.splat      v2, s4
    s.addi       s4, s15, #3072                  // row 6
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v4, v6
    p.and        p3, p1, p2
    s.movz       s6, #7
    s.movz       s7, #7
    vf.cvt.f32.f16 v4, v2
    s.movz       s10, #7
    @p4 v.st.h       [s2, #0], v4
    a.vread      v2, a1, s3
    a.vread      v4, a2, s11
    a.vread      v6, a4, s12
    a.vread      v7, a4, s1
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.movz       s1, #7
    @p1 v.sel        v2, v8, v7
    s.addi       s2, s8, #7
    vf.add       v6, v2, v0
    v.splat      v2, s2
    s.addi       s2, s15, #3584                  // row 7
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v4, v6
    p.and        p4, p1, p2
    s.movz       s3, #8
    s.movz       s11, #8
    vf.cvt.f32.f16 v4, v2
    s.movz       s12, #8
    @p3 v.st.h       [s4, #0], v4
    a.vread      v2, a1, s6
    a.vread      v4, a2, s7
    a.vread      v6, a4, s10
    a.vread      v7, a4, s1
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.movz       s1, #8
    @p1 v.sel        v2, v8, v7
    s.addi       s4, s8, #8
    vf.add       v6, v2, v0
    v.splat      v2, s4
    s.addi       s4, s15, #4096                  // row 8
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v4, v6
    p.and        p3, p1, p2
    s.movz       s6, #9
    s.movz       s7, #9
    vf.cvt.f32.f16 v4, v2
    s.movz       s10, #9
    @p4 v.st.h       [s2, #0], v4
    a.vread      v2, a1, s3
    a.vread      v4, a2, s11
    a.vread      v6, a4, s12
    a.vread      v7, a4, s1
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.movz       s1, #9
    @p1 v.sel        v2, v8, v7
    s.addi       s2, s8, #9
    vf.add       v6, v2, v0
    v.splat      v2, s2
    s.addi       s2, s15, #4608                  // row 9
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v4, v6
    p.and        p4, p1, p2
    s.movz       s3, #10
    s.movz       s11, #10
    vf.cvt.f32.f16 v4, v2
    s.movz       s12, #10
    @p3 v.st.h       [s4, #0], v4
    a.vread      v2, a1, s6
    a.vread      v4, a2, s7
    a.vread      v6, a4, s10
    a.vread      v7, a4, s1
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.movz       s1, #10
    @p1 v.sel        v2, v8, v7
    s.addi       s4, s8, #10
    vf.add       v6, v2, v0
    v.splat      v2, s4
    s.addi       s4, s15, #5120                  // row 10
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v4, v6
    p.and        p3, p1, p2
    s.movz       s6, #11
    s.movz       s7, #11
    vf.cvt.f32.f16 v4, v2
    s.movz       s10, #11
    @p4 v.st.h       [s2, #0], v4
    a.vread      v2, a1, s3
    a.vread      v4, a2, s11
    a.vread      v6, a4, s12
    a.vread      v7, a4, s1
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.movz       s1, #11
    @p1 v.sel        v2, v8, v7
    s.addi       s2, s8, #11
    vf.add       v6, v2, v0
    v.splat      v2, s2
    s.addi       s2, s15, #5632                  // row 11
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v4, v6
    p.and        p4, p1, p2
    s.movz       s3, #12
    s.movz       s11, #12
    vf.cvt.f32.f16 v4, v2
    s.movz       s12, #12
    @p3 v.st.h       [s4, #0], v4
    a.vread      v2, a1, s6
    a.vread      v4, a2, s7
    a.vread      v6, a4, s10
    a.vread      v7, a4, s1
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.movz       s1, #12
    @p1 v.sel        v2, v8, v7
    s.addi       s4, s8, #12
    vf.add       v6, v2, v0
    v.splat      v2, s4
    s.addi       s4, s15, #6144                  // row 12
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v4, v6
    p.and        p3, p1, p2
    s.movz       s6, #13
    s.movz       s7, #13
    vf.cvt.f32.f16 v4, v2
    s.movz       s10, #13
    @p4 v.st.h       [s2, #0], v4
    a.vread      v2, a1, s3
    a.vread      v4, a2, s11
    a.vread      v6, a4, s12
    a.vread      v7, a4, s1
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.movz       s1, #13
    @p1 v.sel        v2, v8, v7
    s.addi       s2, s8, #13
    vf.add       v6, v2, v0
    v.splat      v2, s2
    s.addi       s2, s15, #6656                  // row 13
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v4, v6
    p.and        p4, p1, p2
    s.movz       s3, #14
    s.movz       s11, #14
    vf.cvt.f32.f16 v4, v2
    s.movz       s12, #14
    @p3 v.st.h       [s4, #0], v4
    a.vread      v2, a1, s6
    a.vread      v4, a2, s7
    a.vread      v6, a4, s10
    a.vread      v7, a4, s1
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.movz       s1, #14
    @p1 v.sel        v2, v8, v7
    s.addi       s4, s8, #14
    vf.add       v6, v2, v0
    v.splat      v2, s4
    s.addi       s4, s15, #7168                  // row 14
    v.cmp.lt     p1, v2, v3
    vf.mul       v2, v4, v6
    p.and        p3, p1, p2
    s.movz       s6, #15
    s.movz       s7, #15
    vf.cvt.f32.f16 v4, v2
    s.movz       s10, #15
    s.addi       s14, s8, #15
    s.addi       s8, s15, #7680                  // row 15
    @p4 v.st.h       [s2, #0], v4
    a.vread      v2, a1, s3
    a.vread      v4, a2, s11
    a.vread      v6, a4, s12
    a.vread      v7, a4, s1
    vf.neg       v8, v6
    vf.cmp.lt    p1, v4, v5
    vf.mul       v4, v2, v1
    s.movz       s1, #15
    @p1 v.sel        v2, v8, v7
    v.splat      v6, s14
    vf.add       v7, v2, v0
    v.cmp.lt     p1, v6, v3
    p.and        p4, p1, p2
    vf.mul       v2, v4, v7
    vf.cvt.f32.f16 v3, v2
    @p3 v.st.h       [s4, #0], v3
    a.vread      v2, a1, s6
    a.vread      v3, a2, s7
    a.vread      v4, a4, s10
    a.vread      v6, a4, s1
    vf.neg       v7, v4
    vf.cmp.lt    p1, v3, v5
    vf.mul       v3, v2, v1
    @p1 v.sel        v1, v7, v6
    vf.add       v2, v1, v0
    vf.mul       v0, v3, v2
    vf.cvt.f32.f16 v1, v0
    @p4 v.st.h       [s8, #0], v1
__rctx_next:
    exit
