    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.splat      v0, s4
    v.movi       v1, #0
    v.movi       v2, #8
    v.movi       v3, #256
    v.sub        v4, v1, v0
    v.cmp.lt     p1, v0, v1
    v.sub        v5, v1, v3
    @p1 v.sel        v6, v4, v0
    v.movi       v0, #0
    v.movi       v4, #0
    v.lshr       v7, v6, v2
    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    v.sub        v2, v1, v7
    v.cmp.lt     p2, v3, v1
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s5, #32
    s.movz       s6, #16
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v6, #1
    @p2 v.sel        v6, v5, v3
    @p1 v.sel        v3, v2, v7
    s.addi       s7, s2, #0
    s.ld.d       s2, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s8, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    v.mov        v4, v0
for_1:
    s.cmp.ge     s1, s7, s5
    br.nz        s1, endfor_2
    v.movi       v0, #32
    s.mul        s1, s4, s5
    v.splat      v2, s7
    v.mul        v5, v3, v0
    v.movi       v0, #32
    v.add        v6, v2, v1
    v.extract    s9, v5, #0
    s.add        s10, s7, s1
    v.splat      v2, s9
    s.shli       s9, s10, #1                     // element offset -> bytes (x2)
    v.cmp.lt     p1, v6, v0
    v.add        v0, v6, v2
    s.add        s10, s2, s9                     // &in_ptr1[...]
    .li       s9, #1054295293
    v.splat      v2, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v5, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.movi       v0, #0
    v.splat      v7, s1
    s.add        s1, s7, s6
    s.movz       s9, #1
    v.add        v8, v6, v7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v6, [s10, #0]
    vf.cvt.f16.f32 v7, v5
    vf.mul       v5, v7, v2
    vf.cvt.f16.f32 v7, v6
    vf.mul       v6, v7, v2
    vf.mul       v2, v5, v6
    vf.add       v5, v4, v2
    @p1 v.sel        v2, v5, v4
    v.mov        v0, v2
    v.mov        v4, v0
    s.mov        s7, s1
    br.nz        s9, for_1
endfor_2:
    vf.reduce.add.b v0, v4
    v.movi       v1, #0
    s.movz       s1, #1
    s.shli       s2, s4, #2                      // element offset -> bytes (x4)
    vf.add       v2, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.add        s1, s8, s2                      // &out_ptr0[...]
    v.cmp.lt     p1, v0, v1
    @p1 v.st.w       [s1, #0], v2
__rctx_next:
    exit
