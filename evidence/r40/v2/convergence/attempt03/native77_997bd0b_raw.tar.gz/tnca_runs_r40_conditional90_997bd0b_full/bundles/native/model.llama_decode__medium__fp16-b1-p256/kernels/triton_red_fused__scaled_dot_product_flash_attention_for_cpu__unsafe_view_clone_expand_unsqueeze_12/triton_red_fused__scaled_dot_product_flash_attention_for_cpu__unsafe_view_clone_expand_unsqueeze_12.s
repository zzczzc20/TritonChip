    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.splat      v0, s4
    v.movi       v1, #0
    s.rdspecial  s1, arg_base
    v.movi       v2, #5
    v.sub        v3, v1, v0
    v.cmp.lt     p1, v0, v1
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    @p1 v.sel        v4, v3, v0
    s.movz       s3, #1
    v.iota       v3                              // arange(0, VLEN)
    v.lshr       v5, v4, v2
    v.splat      v2, s3
    v.movi       v4, #0
    v.sub        v6, v1, v5
    v.cmp.lt     p2, v3, v2
    v.sub        v2, v4, v0
    @p1 v.sel        v3, v6, v5
    s.ld.d       s3, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.cmp.lt     p1, v0, v4
    @p1 v.sel        v5, v2, v0
    v.movi       v0, #31
    s.movz       s5, #1
    v.movi       v2, #32
    v.and        v6, v5, v0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v5, s5
    v.sub        v7, v1, v2
    v.movi       v8, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.sb v9, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.sub        v10, v4, v2
    s.movz       s2, #0
    v.cmp.lt     p2, v2, v1
    v.sub        v1, v4, v6
    v.cmp.lt     p3, v0, v5
    v.movi       v0, #0
    v.cmp.lt     p4, v2, v4
    s.movz       s5, #257
    s.movz       s6, #16
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v5, #1
    @p2 v.sel        v5, v7, v2
    v.movi       v5, #1
    @p4 v.sel        v5, v10, v2
    @p1 v.sel        v2, v1, v6
    s.addi       s7, s2, #0
    s.ld.d       s2, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.movi       v1, #0
    v.cmp.ne     p1, v9, v8
    s.ld.d       s8, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s9, [s1, #32]                   // out_ptr1: device_ptr64 at arg_base+32
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v5, [s3, v3]               // index is in elements (ISA sec 9.1)
    v.mov        v1, v0
for_1:
    s.cmp.ge     s1, s7, s5
    br.nz        s1, endfor_2
    v.movi       v6, #257
    v.splat      v7, s7
    v.movi       v8, #32
    v.mul        v9, v3, v6
    v.add        v6, v7, v4
    v.movi       v7, #3
    v.extract    s1, v9, #0
    v.movi       v9, #0
    v.splat      v10, s1
    v.extract    s1, v2, #0
    v.movi       v11, #257
    v.add        v12, v6, v10
    v.mul        v10, v6, v8
    v.splat      v8, s1
    v.sub        v13, v9, v3
    v.sub        v14, v9, v7
    v.cmp.lt     p2, v6, v11
    v.cmp.lt     p3, v3, v9
    v.cmp.lt     p4, v7, v9
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v6, [s2, v12]              // index is in elements (ISA sec 9.1)
    s.movz       s1, #32
    v.add        v11, v8, v10
    v.movi       v8, #1
    @p3 v.sel        v10, v13, v3
    @p4 v.sel        v12, v14, v7
    v.movi       v7, #0
    v.movi       v13, #0
    s.movz       s1, #31
idiv_3:
    v.splat      v14, s1
    v.shl        v15, v13, v8
    v.cmp.lt     p5, v13, v9
    v.lshr       v16, v10, v14
    v.shl        v17, v8, v14
    s.subi       s3, s1, #1
    v.and        v14, v16, v8
    s.movz       s10, #0
    v.or         v16, v15, v14
    v.cmp.geu    p6, v16, v12
    p.or         p7, p5, p6
    v.sub        v14, v16, v12
    @p7 v.sel        v15, v17, v9
    @p7 v.sel        v17, v14, v16
    v.or         v14, v7, v15
    v.mov        v13, v17
    v.mov        v7, v14
    s.mov        s1, s3
    s.cmp.ge     s3, s1, s10
    br.nz        s3, idiv_3
    v.extract    s1, v5, #0
    v.sub        v8, v9, v7
    v.splat      v9, s1
    p.xor        p5, p3, p4
    v.movi       v10, #8224
    v.rcp.approx v12, v9                         // ISA 8.8: <= 2**-22 relative
    @p5 v.sel        v13, v8, v7
    .li       s1, #1065353216
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v8, #1
    v.mul        v14, v13, v10
    v.movi       v10, #0
    v.movi       v13, #0
    v.extract    s1, v14, #0
    @p1 v.sel        v14, v8, v10
    v.splat      v8, s1
    v.movi       v10, #1
    v.cmp.eq     p3, v14, v13
    v.add        v13, v11, v8
    v.movi       v8, #0
    v.movi       v11, #0
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.h v14, [s8, v13]             // index is in elements (ISA sec 9.1)
    @p3 v.sel        v13, v10, v8
    v.movi       v8, #0
    s.add        s1, s7, s6
    v.extract    s3, v13, #0
    s.movz       s10, #1
    v.splat      v10, s3
    s.movz       s3, #8224
    v.cmp.ne     p3, v10, v11
    vf.fms       v10, v9, v12, v7
    vf.cvt.f16.f32 v7, v14
    vf.fms       v9, v12, v10, v12
    vf.neg       v10, v9                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v10, v10
    @p4 v.sel        v9, v10, v12
    vf.mul       v10, v6, v9                     // a/y as a refined reciprocal (ISA has no divide)
    @p3 v.sel        v6, v0, v10
    vf.mul       v9, v6, v7
    vf.add       v6, v1, v9
    @p2 v.sel        v7, v6, v1
    v.mov        v8, v7
    v.mov        v1, v8
    s.mov        s7, s1
    br.nz        s10, for_1
endfor_2:
    vf.reduce.add.b v0, v1
    v.movi       v1, #0
    s.movz       s1, #1
    s.shli       s2, s4, #1                      // element offset -> bytes (x2)
    vf.add       v2, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.add        s1, s9, s2                      // &out_ptr1[...]
    vf.cvt.f32.f16 v3, v2
    v.cmp.lt     p1, v0, v1
    @p1 v.st.h       [s1, #0], v3
__rctx_next:
    exit
