    s.rdspecial  s1, arg_base
    s.rdspecial  s2, role_id
    s.ld.d       s3, [s1, #48]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.movz       s1, #768
    s.rdspecial  s4, arg_base
    s.mul        s5, s2, s1
    s.movz       s1, #0
    s.movz       s2, #256
    s.movz       s6, #64
    s.movz       s7, #4
    s.movz       s8, #1
    s.rdspecial  s8, role_id
    s.rdspecial  s9, npid.x
    s.ld.d       s10, [s4, #0]                   // in_ptr0: device_ptr64 at arg_base+0
    s.add        s11, s3, s5                     // this context's own scratch
    s.ld.d       s3, [s4, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.ld.d       s5, [s4, #16]                   // out_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s11, [s4, #24]                  // out_ptr3: device_ptr64 at arg_base+24
__rctx_program:
    s.addi       s4, s1, #0
    s.muli       s12, s8, #1024
    s.muli       s13, s4, #4
    v.movi       v0, #0
    v.movi       v1, #0
    v.splat      v2, s8
    v.splat      v3, s7
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v5, #16
    v.movi       v6, #32
    v.movi       v7, #48
    .li       s14, #4286578688
    v.splat      v8, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v9, #0
    v.movi       v10, #0
    v.movi       v11, #0
    v.movi       v12, #0
    s.add        s14, s10, s12
    v.cmp.ne     p1, v0, v1
    v.cmp.ge     p2, v2, v1
    v.cmp.lt     p3, v2, v3
    v.add        v0, v4, v5
    v.add        v2, v4, v6
    v.add        v3, v4, v7
    p.mov        p4, p1
    p.mov        p5, p1
    p.mov        p6, p1
    p.mov        p7, p1
    v.mov        v9, v8
    v.mov        v10, v8
    v.mov        v11, v8
    v.mov        v12, v8
    p.and        p1, p2, p3
    v.movi       v5, #1
    v.movi       v6, #256
    s.add        s12, s14, s13
for_1:
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v7, [s12, #0]
    v.movi       v13, #0
    v.movi       v14, #0
    v.splat      v15, s4
    v.splat      v16, s4
    v.splat      v17, s4
    v.splat      v18, s4
    v.add        v19, v15, v4
    v.add        v15, v16, v0
    v.add        v16, v17, v2
    v.add        v17, v18, v3
    vf.cmp.eq    p2, v7, v8
    @p2 v.sel        v18, v5, v1
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v20, [s12, #64]
    v.cmp.eq     p2, v18, v1
    @p2 v.sel        v18, v5, v1
    v.extract    s13, v18, #0
    v.extract    s14, v18, #1
    s.lshri      s15, s13, #32
    s.lshri      s16, s14, #32
    v.extract    s17, v18, #2
    v.extract    s18, v18, #3
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v21, [s12, #128]
    vf.cmp.eq    p2, v20, v8
    @p2 v.sel        v22, v5, v1
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v23, [s12, #192]
    v.insert     v13, s13, #0
    v.insert     v14, s15, #0
    s.lshri      s13, s17, #32
    v.insert     v13, s14, #1
    v.insert     v14, s16, #1
    s.lshri      s14, s18, #32
    v.insert     v13, s17, #2
    v.insert     v14, s13, #2
    v.extract    s13, v18, #4
    v.insert     v13, s18, #3
    v.insert     v14, s14, #3
    s.lshri      s14, s13, #32
    v.extract    s15, v18, #5
    v.insert     v13, s13, #4
    v.insert     v14, s14, #4
    s.lshri      s13, s15, #32
    v.extract    s14, v18, #6
    v.insert     v13, s15, #5
    v.insert     v14, s13, #5
    s.lshri      s13, s14, #32
    v.extract    s15, v18, #7
    v.insert     v13, s14, #6
    v.insert     v14, s13, #6
    s.lshri      s13, s15, #32
    v.extract    s14, v18, #8
    v.insert     v13, s15, #7
    v.insert     v14, s13, #7
    s.lshri      s13, s14, #32
    v.extract    s15, v18, #9
    v.insert     v13, s14, #8
    v.insert     v14, s13, #8
    s.lshri      s13, s15, #32
    v.insert     v13, s15, #9
    v.insert     v14, s13, #9
    vf.cmp.eq    p2, v21, v8
    v.extract    s13, v18, #10
    @p2 v.sel        v24, v5, v1
    v.insert     v13, s13, #10
    vf.cmp.eq    p2, v23, v8
    s.lshri      s14, s13, #32
    @p2 v.sel        v25, v5, v1
    v.extract    s13, v18, #11
    v.insert     v14, s14, #10
    s.lshri      s14, s13, #32
    v.extract    s15, v18, #12
    v.insert     v13, s13, #11
    v.insert     v14, s14, #11
    s.lshri      s13, s15, #32
    v.extract    s14, v18, #13
    v.insert     v13, s15, #12
    v.insert     v14, s13, #12
    s.lshri      s13, s14, #32
    v.cmp.eq     p2, v22, v1
    v.extract    s15, v18, #14
    @p2 v.sel        v22, v5, v1
    v.insert     v13, s14, #13
    v.insert     v14, s13, #13
    s.lshri      s13, s15, #32
    v.extract    s14, v18, #15
    v.extract    s16, v22, #0
    v.insert     v13, s15, #14
    v.insert     v14, s13, #14
    v.movi       v18, #0
    v.movi       v26, #0
    s.lshri      s13, s14, #32
    s.lshri      s15, s16, #32
    v.extract    s17, v22, #1
    v.insert     v13, s14, #15
    v.insert     v14, s13, #15
    v.insert     v18, s16, #0
    v.insert     v26, s15, #0
    s.lshri      s13, s17, #32
    v.extract    s14, v22, #2
    v.insert     v18, s17, #1
    v.insert     v26, s13, #1
    s.lshri      s13, s14, #32
    v.extract    s15, v22, #3
    v.insert     v18, s14, #2
    v.insert     v26, s13, #2
    s.lshri      s13, s15, #32
    v.extract    s14, v22, #4
    v.insert     v18, s15, #3
    v.insert     v26, s13, #3
    s.lshri      s13, s14, #32
    v.extract    s15, v22, #5
    v.insert     v18, s14, #4
    v.insert     v26, s13, #4
    s.lshri      s13, s15, #32
    v.extract    s14, v22, #6
    v.insert     v18, s15, #5
    v.insert     v26, s13, #5
    s.lshri      s13, s14, #32
    v.extract    s15, v22, #7
    v.insert     v18, s14, #6
    v.insert     v26, s13, #6
    s.lshri      s13, s15, #32
    v.extract    s14, v22, #8
    v.insert     v18, s15, #7
    v.insert     v26, s13, #7
    s.lshri      s13, s14, #32
    v.extract    s15, v22, #9
    v.insert     v18, s14, #8
    v.insert     v26, s13, #8
    s.lshri      s13, s15, #32
    v.extract    s14, v22, #10
    v.insert     v18, s15, #9
    v.insert     v26, s13, #9
    s.lshri      s13, s14, #32
    v.extract    s15, v22, #11
    v.insert     v18, s14, #10
    v.insert     v26, s13, #10
    s.lshri      s13, s15, #32
    v.extract    s14, v22, #12
    v.insert     v18, s15, #11
    v.insert     v26, s13, #11
    s.lshri      s13, s14, #32
    v.extract    s15, v22, #13
    v.insert     v18, s14, #12
    v.insert     v26, s13, #12
    s.lshri      s13, s15, #32
    v.cmp.eq     p2, v24, v1
    v.extract    s14, v22, #14
    @p2 v.sel        v24, v5, v1
    v.insert     v18, s15, #13
    v.insert     v26, s13, #13
    s.lshri      s13, s14, #32
    v.extract    s15, v22, #15
    v.extract    s16, v24, #0
    v.insert     v18, s14, #14
    v.insert     v26, s13, #14
    v.movi       v22, #0
    v.movi       v27, #0
    s.lshri      s13, s15, #32
    s.lshri      s14, s16, #32
    v.extract    s17, v24, #1
    v.insert     v18, s15, #15
    v.insert     v26, s13, #15
    v.insert     v22, s16, #0
    v.insert     v27, s14, #0
    s.lshri      s13, s17, #32
    v.extract    s14, v24, #2
    v.insert     v22, s17, #1
    v.insert     v27, s13, #1
    s.lshri      s13, s14, #32
    v.extract    s15, v24, #3
    v.insert     v22, s14, #2
    v.insert     v27, s13, #2
    s.lshri      s13, s15, #32
    v.extract    s14, v24, #4
    v.insert     v22, s15, #3
    v.insert     v27, s13, #3
    s.lshri      s13, s14, #32
    v.extract    s15, v24, #5
    v.insert     v22, s14, #4
    v.insert     v27, s13, #4
    s.lshri      s13, s15, #32
    v.extract    s14, v24, #6
    v.insert     v22, s15, #5
    v.insert     v27, s13, #5
    s.lshri      s13, s14, #32
    v.extract    s15, v24, #7
    v.insert     v22, s14, #6
    v.insert     v27, s13, #6
    s.lshri      s13, s15, #32
    v.extract    s14, v24, #8
    v.insert     v22, s15, #7
    v.insert     v27, s13, #7
    s.lshri      s13, s14, #32
    v.extract    s15, v24, #9
    v.insert     v22, s14, #8
    v.insert     v27, s13, #8
    s.lshri      s13, s15, #32
    v.extract    s14, v24, #10
    v.insert     v22, s15, #9
    v.insert     v27, s13, #9
    s.lshri      s13, s14, #32
    v.extract    s15, v24, #11
    v.insert     v22, s14, #10
    v.insert     v27, s13, #10
    s.lshri      s13, s15, #32
    v.extract    s14, v24, #12
    v.insert     v22, s15, #11
    v.insert     v27, s13, #11
    s.lshri      s13, s14, #32
    v.extract    s15, v24, #13
    v.insert     v22, s14, #12
    v.insert     v27, s13, #12
    s.lshri      s13, s15, #32
    v.cmp.eq     p2, v25, v1
    v.extract    s14, v24, #14
    @p2 v.sel        v25, v5, v1
    v.insert     v22, s15, #13
    v.insert     v27, s13, #13
    s.lshri      s13, s14, #32
    v.extract    s15, v24, #15
    v.extract    s16, v25, #0
    v.insert     v22, s14, #14
    v.insert     v27, s13, #14
    v.movi       v24, #0
    v.movi       v28, #0
    s.lshri      s13, s15, #32
    s.lshri      s14, s16, #32
    v.extract    s17, v25, #1
    v.insert     v22, s15, #15
    v.insert     v27, s13, #15
    v.insert     v24, s16, #0
    v.insert     v28, s14, #0
    s.lshri      s13, s17, #32
    v.extract    s14, v25, #2
    v.insert     v24, s17, #1
    v.insert     v28, s13, #1
    s.lshri      s13, s14, #32
    v.extract    s15, v25, #3
    v.insert     v24, s14, #2
    v.insert     v28, s13, #2
    s.lshri      s13, s15, #32
    v.extract    s14, v25, #4
    v.insert     v24, s15, #3
    v.insert     v28, s13, #3
    s.lshri      s13, s14, #32
    v.extract    s15, v25, #5
    v.insert     v24, s14, #4
    v.insert     v28, s13, #4
    s.lshri      s13, s15, #32
    v.extract    s14, v25, #6
    v.insert     v24, s15, #5
    v.insert     v28, s13, #5
    s.lshri      s13, s14, #32
    v.extract    s15, v25, #7
    v.insert     v24, s14, #6
    v.insert     v28, s13, #6
    s.lshri      s13, s15, #32
    v.extract    s14, v25, #8
    v.insert     v24, s15, #7
    v.insert     v28, s13, #7
    s.lshri      s13, s14, #32
    v.extract    s15, v25, #9
    v.insert     v24, s14, #8
    v.insert     v28, s13, #8
    s.lshri      s13, s15, #32
    v.extract    s14, v25, #10
    v.insert     v24, s15, #9
    v.insert     v28, s13, #9
    s.lshri      s13, s14, #32
    v.extract    s15, v25, #11
    v.insert     v24, s14, #10
    v.insert     v28, s13, #10
    s.lshri      s13, s15, #32
    v.extract    s14, v25, #12
    v.insert     v24, s15, #11
    v.insert     v28, s13, #11
    s.lshri      s13, s14, #32
    v.extract    s15, v25, #13
    v.insert     v24, s14, #12
    v.insert     v28, s13, #12
    s.lshri      s13, s15, #32
    v.extract    s14, v14, #0
    v.extract    s16, v25, #14
    v.insert     v24, s15, #13
    v.insert     v28, s13, #13
    v.extract    s13, v13, #0
    s.shli       s15, s14, #32
    s.lshri      s14, s16, #32
    v.extract    s17, v14, #1
    v.extract    s18, v25, #15
    s.or         s19, s13, s15
    v.insert     v24, s16, #14
    v.insert     v28, s14, #14
    v.movi       v25, #0
    v.extract    s13, v13, #1
    s.shli       s14, s17, #32
    s.lshri      s15, s18, #32
    s.cmp.ne     s16, s19, s1
    v.extract    s17, v14, #2
    s.or         s19, s13, s14
    v.insert     v24, s18, #15
    v.insert     v28, s15, #15
    v.insert     v25, s16, #0
    v.extract    s13, v13, #2
    s.shli       s14, s17, #32
    s.cmp.ne     s15, s19, s1
    v.extract    s16, v14, #3
    s.or         s17, s13, s14
    v.insert     v25, s15, #1
    v.extract    s13, v13, #3
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v14, #4
    s.or         s17, s13, s14
    v.insert     v25, s15, #2
    v.extract    s13, v13, #4
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v14, #5
    s.or         s17, s13, s14
    v.insert     v25, s15, #3
    v.extract    s13, v13, #5
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v14, #6
    s.or         s17, s13, s14
    v.insert     v25, s15, #4
    v.extract    s13, v13, #6
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    s.or         s16, s13, s14
    v.insert     v25, s15, #5
    s.cmp.ne     s13, s16, s1
    v.cmp.lt     p2, v19, v6
    v.insert     v25, s13, #6
    vf.max       v9, v9, v7
    v.extract    s13, v13, #7
    vf.max       v10, v10, v20
    v.extract    s14, v14, #7
    vf.max       v11, v11, v21
    s.shli       s15, s14, #32
    vf.max       v12, v12, v23
    v.extract    s14, v14, #8
    s.or         s16, s13, s15
    v.extract    s13, v13, #8
    s.shli       s15, s14, #32
    s.cmp.ne     s14, s16, s1
    v.extract    s16, v14, #9
    s.or         s17, s13, s15
    v.insert     v25, s14, #7
    v.extract    s13, v13, #9
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v14, #10
    s.or         s17, s13, s14
    v.insert     v25, s15, #8
    v.extract    s13, v13, #10
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v14, #11
    s.or         s17, s13, s14
    v.insert     v25, s15, #9
    v.extract    s13, v13, #11
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v14, #12
    s.or         s17, s13, s14
    v.insert     v25, s15, #10
    v.extract    s13, v13, #12
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v14, #13
    s.or         s17, s13, s14
    v.insert     v25, s15, #11
    v.extract    s13, v13, #13
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v14, #14
    s.or         s17, s13, s14
    v.insert     v25, s15, #12
    v.extract    s13, v13, #14
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v14, #15
    v.extract    s17, v26, #0
    s.or         s18, s13, s14
    v.insert     v25, s15, #13
    v.extract    s13, v13, #15
    s.shli       s14, s16, #32
    v.extract    s15, v18, #0
    s.shli       s16, s17, #32
    s.cmp.ne     s17, s18, s1
    v.extract    s18, v26, #1
    s.or         s19, s13, s14
    s.or         s13, s15, s16
    v.insert     v25, s17, #14
    v.movi       v7, #0
    v.extract    s14, v18, #1
    s.shli       s15, s18, #32
    s.cmp.ne     s16, s19, s1
    s.cmp.ne     s17, s13, s1
    v.extract    s13, v26, #2
    s.or         s18, s14, s15
    v.insert     v25, s16, #15
    v.insert     v7, s17, #0
    v.extract    s14, v18, #2
    s.shli       s15, s13, #32
    s.cmp.ne     s13, s18, s1
    v.extract    s16, v26, #3
    s.or         s17, s14, s15
    v.insert     v7, s13, #1
    v.extract    s13, v18, #3
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v26, #4
    s.or         s17, s13, s14
    v.insert     v7, s15, #2
    v.extract    s13, v18, #4
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v26, #5
    s.or         s17, s13, s14
    v.insert     v7, s15, #3
    v.extract    s13, v18, #5
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v26, #6
    s.or         s17, s13, s14
    v.insert     v7, s15, #4
    v.extract    s13, v18, #6
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    s.or         s16, s13, s14
    v.insert     v7, s15, #5
    v.cmp.lt     p3, v15, v6
    p.not        p8, p2
    v.cmp.ne     p2, v25, v1
    s.cmp.ne     s13, s16, s1
    p.or         p9, p4, p2
    v.extract    s14, v18, #7
    v.insert     v7, s13, #6
    p.and        p2, p8, p4
    v.extract    s13, v26, #7
    p.or         p8, p9, p2
    s.shli       s15, s13, #32
    p.mov        p2, p8
    v.extract    s13, v26, #8
    s.or         s16, s14, s15
    v.extract    s14, v18, #8
    s.shli       s15, s13, #32
    s.cmp.ne     s13, s16, s1
    v.extract    s16, v26, #9
    s.or         s17, s14, s15
    v.insert     v7, s13, #7
    v.extract    s13, v18, #9
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v26, #10
    s.or         s17, s13, s14
    v.insert     v7, s15, #8
    v.extract    s13, v18, #10
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v26, #11
    s.or         s17, s13, s14
    v.insert     v7, s15, #9
    v.extract    s13, v18, #11
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v26, #12
    s.or         s17, s13, s14
    v.insert     v7, s15, #10
    v.extract    s13, v18, #12
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v26, #13
    s.or         s17, s13, s14
    v.insert     v7, s15, #11
    v.extract    s13, v18, #13
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v26, #14
    s.or         s17, s13, s14
    v.insert     v7, s15, #12
    v.extract    s13, v18, #14
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v26, #15
    v.extract    s17, v27, #0
    s.or         s18, s13, s14
    v.insert     v7, s15, #13
    v.extract    s13, v18, #15
    s.shli       s14, s16, #32
    v.extract    s15, v22, #0
    s.shli       s16, s17, #32
    s.cmp.ne     s17, s18, s1
    v.extract    s18, v27, #1
    s.or         s19, s13, s14
    s.or         s13, s15, s16
    v.insert     v7, s17, #14
    v.movi       v13, #0
    v.extract    s14, v22, #1
    s.shli       s15, s18, #32
    s.cmp.ne     s16, s19, s1
    s.cmp.ne     s17, s13, s1
    v.extract    s13, v27, #2
    s.or         s18, s14, s15
    v.insert     v7, s16, #15
    v.insert     v13, s17, #0
    v.extract    s14, v22, #2
    s.shli       s15, s13, #32
    s.cmp.ne     s13, s18, s1
    v.extract    s16, v27, #3
    s.or         s17, s14, s15
    v.insert     v13, s13, #1
    v.extract    s13, v22, #3
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v27, #4
    s.or         s17, s13, s14
    v.insert     v13, s15, #2
    v.extract    s13, v22, #4
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v27, #5
    s.or         s17, s13, s14
    v.insert     v13, s15, #3
    v.extract    s13, v22, #5
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v27, #6
    s.or         s17, s13, s14
    v.insert     v13, s15, #4
    v.extract    s13, v22, #6
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    s.or         s16, s13, s14
    v.insert     v13, s15, #5
    v.cmp.lt     p8, v16, v6
    p.not        p9, p3
    v.cmp.ne     p3, v7, v1
    s.cmp.ne     s13, s16, s1
    p.or         p10, p5, p3
    v.extract    s14, v22, #7
    v.insert     v13, s13, #6
    p.and        p3, p9, p5
    v.extract    s13, v27, #7
    p.or         p9, p10, p3
    s.shli       s15, s13, #32
    p.mov        p3, p9
    v.extract    s13, v27, #8
    s.or         s16, s14, s15
    v.extract    s14, v22, #8
    s.shli       s15, s13, #32
    s.cmp.ne     s13, s16, s1
    v.extract    s16, v27, #9
    s.or         s17, s14, s15
    v.insert     v13, s13, #7
    v.extract    s13, v22, #9
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v27, #10
    s.or         s17, s13, s14
    v.insert     v13, s15, #8
    v.extract    s13, v22, #10
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v27, #11
    s.or         s17, s13, s14
    v.insert     v13, s15, #9
    v.extract    s13, v22, #11
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v27, #12
    s.or         s17, s13, s14
    v.insert     v13, s15, #10
    v.extract    s13, v22, #12
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v27, #13
    s.or         s17, s13, s14
    v.insert     v13, s15, #11
    v.extract    s13, v22, #13
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v27, #14
    s.or         s17, s13, s14
    v.insert     v13, s15, #12
    v.extract    s13, v22, #14
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v27, #15
    v.extract    s17, v28, #0
    s.or         s18, s13, s14
    v.insert     v13, s15, #13
    v.extract    s13, v22, #15
    s.shli       s14, s16, #32
    v.extract    s15, v24, #0
    s.shli       s16, s17, #32
    s.cmp.ne     s17, s18, s1
    v.extract    s18, v28, #1
    s.or         s19, s13, s14
    s.or         s13, s15, s16
    v.insert     v13, s17, #14
    v.movi       v7, #0
    v.extract    s14, v24, #1
    s.shli       s15, s18, #32
    s.cmp.ne     s16, s19, s1
    s.cmp.ne     s17, s13, s1
    v.extract    s13, v28, #2
    s.or         s18, s14, s15
    v.insert     v13, s16, #15
    v.insert     v7, s17, #0
    v.extract    s14, v24, #2
    s.shli       s15, s13, #32
    s.cmp.ne     s13, s18, s1
    v.extract    s16, v28, #3
    s.or         s17, s14, s15
    v.insert     v7, s13, #1
    v.extract    s13, v24, #3
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v28, #4
    s.or         s17, s13, s14
    v.insert     v7, s15, #2
    v.extract    s13, v24, #4
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v28, #5
    s.or         s17, s13, s14
    v.insert     v7, s15, #3
    v.extract    s13, v24, #5
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v28, #6
    s.or         s17, s13, s14
    v.insert     v7, s15, #4
    v.extract    s13, v24, #6
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    s.or         s16, s13, s14
    v.insert     v7, s15, #5
    v.cmp.lt     p9, v17, v6
    p.not        p10, p8
    v.cmp.ne     p8, v13, v1
    s.cmp.ne     s13, s16, s1
    p.or         p11, p6, p8
    v.extract    s14, v24, #7
    v.insert     v7, s13, #6
    p.and        p8, p10, p6
    v.extract    s13, v28, #7
    p.or         p10, p11, p8
    s.shli       s15, s13, #32
    p.mov        p8, p10
    v.extract    s13, v28, #8
    s.or         s16, s14, s15
    v.extract    s14, v24, #8
    s.shli       s15, s13, #32
    s.cmp.ne     s13, s16, s1
    v.extract    s16, v28, #9
    s.or         s17, s14, s15
    v.insert     v7, s13, #7
    v.extract    s13, v24, #9
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v28, #10
    s.or         s17, s13, s14
    v.insert     v7, s15, #8
    v.extract    s13, v24, #10
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v28, #11
    s.or         s17, s13, s14
    v.insert     v7, s15, #9
    v.extract    s13, v24, #11
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v28, #12
    s.or         s17, s13, s14
    v.insert     v7, s15, #10
    v.extract    s13, v24, #12
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v28, #13
    s.or         s17, s13, s14
    v.insert     v7, s15, #11
    v.extract    s13, v24, #13
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v28, #14
    s.or         s17, s13, s14
    v.insert     v7, s15, #12
    v.extract    s13, v24, #14
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    v.extract    s16, v28, #15
    s.or         s17, s13, s14
    v.insert     v7, s15, #13
    v.extract    s13, v24, #15
    s.shli       s14, s16, #32
    s.cmp.ne     s15, s17, s1
    s.or         s16, s13, s14
    v.insert     v7, s15, #14
    s.cmp.ne     s13, s16, s1
    p.not        p10, p9
    v.insert     v7, s13, #15
    p.and        p9, p10, p7
    v.cmp.ne     p10, v7, v1
    p.or         p11, p7, p10
    p.or         p10, p11, p9
    p.mov        p4, p2
    p.mov        p2, p10
    p.mov        p5, p3
    p.mov        p6, p8
    p.mov        p7, p2
    s.addi       s12, s12, #256                  // the next iteration's address
    s.add        s4, s4, s6
    s.cmp.lt     s13, s4, s2
    br.nz        s13, for_1
endfor_2:
    v.movi       v0, #1
    v.movi       v1, #0
    vf.cmp.uo    p1, v9, v9
    vf.reduce.max.b v2, v9
    @p1 v.sel        v3, v0, v1
    vf.cmp.uo    p1, v10, v10
    @p1 v.sel        v4, v0, v1
    vf.cmp.uo    p1, v11, v11
    @p1 v.sel        v5, v0, v1
    vf.cmp.uo    p1, v12, v12
    @p1 v.sel        v6, v0, v1
    v.reduce.or.b v7, v3
    v.reduce.or.b v3, v4
    v.reduce.or.b v4, v5
    v.reduce.or.b v5, v6
    .li       s4, #2143289344
    v.splat      v6, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.reduce.max.b v8, v10
    vf.reduce.max.b v9, v11
    vf.reduce.max.b v10, v12
    v.cmp.ne     p1, v7, v1
    @p1 v.sel        v7, v6, v2
    v.cmp.ne     p1, v3, v1
    @p1 v.sel        v2, v6, v8
    v.cmp.ne     p1, v4, v1
    @p1 v.sel        v3, v6, v9
    v.cmp.ne     p1, v5, v1
    @p1 v.sel        v4, v6, v10
    @p4 v.sel        v5, v0, v1
    @p5 v.sel        v6, v0, v1
    @p6 v.sel        v8, v0, v1
    @p7 v.sel        v9, v0, v1
    vf.max.prop  v0, v7, v2
    vf.max.prop  v2, v3, v4
    v.reduce.or  s4, v5
    v.reduce.or  s12, v6
    v.reduce.or  s13, v8
    v.reduce.or  s14, v9
    v.splat      v3, s4
    v.splat      v4, s12
    v.splat      v5, s13
    v.splat      v6, s14
    vf.max.prop  v7, v0, v2
    v.or         v0, v3, v4
    v.or         v2, v5, v6
    v.movi       v3, #0
    s.addi       s4, s1, #0
    v.or         v4, v0, v2
    vf.add       v0, v7, v3
    s.movz       s12, #1
    v.extract    s13, v4, #0
    s.muli       s14, s8, #1024
    s.shli       s15, s8, #0                     // element offset -> bytes (x1)
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v4, s12
    v.splat      v5, s13
    s.mul        s12, s8, s2
    s.movz       s13, #4
    s.muli       s16, s4, #4
    v.splat      v6, s8
    v.splat      v7, s13
    s.add        s13, s4, s12
    v.movi       v8, #0
    v.movi       v9, #0
    v.movi       v10, #0
    v.movi       v11, #0
    s.add        s12, s3, s15                    // &out_ptr0[...]
    s.add        s15, s10, s14
    v.extract    s14, v0, #0
    s.shli       s17, s13, #2                    // element offset -> bytes (x4)
    v.cmp.lt     p1, v2, v4
    v.cmp.ge     p2, v6, v1
    v.cmp.lt     p3, v6, v7
    @p1 v.st.b       [s12, #0], v5
    v.mov        v8, v3
    v.mov        v9, v3
    v.mov        v10, v3
    v.mov        v11, v3
    p.and        p1, p2, p3
    v.splat      v0, s14
    .li       s12, #1069066811
    v.splat      v1, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s12, #1060205080
    v.splat      v2, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s12, s15, s16
    s.add        s13, s5, s17                    // &out_ptr2[...]
for_3:
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s12, #0]
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s12, #64]
    vf.sub       v6, v4, v0
    vf.mul       v4, v6, v1
    v.exp2.approx v7, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v12, v6, v1, v4                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v12, v2
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s12, #128]
    vf.sub       v12, v5, v0
    vf.mul       v5, v12, v1
    v.exp2.approx v13, v5                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v14, v12, v1, v5                // the exact rounding error of x*log2(e)
    vf.mul       v5, v14, v2
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v12, [s12, #192]
    vf.sub       v14, v6, v0
    vf.fma       v6, v7, v4, v7                  // 2**t * 2**d
    vf.mul       v4, v14, v1
    vf.cmp.o     p2, v6, v6
    @p2 v.sel        v15, v6, v7
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v14, v1, v4                 // the exact rounding error of x*log2(e)
    vf.add       v8, v8, v15
    vf.mul       v4, v7, v2
    vf.sub       v7, v12, v0
    v.st.w       [s13, #0], v15
    vf.fma       v12, v13, v5, v13               // 2**t * 2**d
    vf.mul       v5, v7, v1
    vf.cmp.o     p2, v12, v12
    @p2 v.sel        v14, v12, v13
    v.exp2.approx v12, v5                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v13, v7, v1, v5                 // the exact rounding error of x*log2(e)
    vf.add       v9, v9, v14
    vf.mul       v5, v13, v2
    v.st.w       [s13, #64], v14
    vf.fma       v7, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p2, v7, v7
    @p2 v.sel        v4, v7, v6
    vf.add       v10, v10, v4
    v.st.w       [s13, #128], v4
    vf.fma       v4, v12, v5, v12                // 2**t * 2**d
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v5, v4, v12
    vf.add       v11, v11, v5
    v.st.w       [s13, #192], v5
    s.addi       s12, s12, #256                  // the next iteration's address
    s.addi       s13, s13, #256                  // the next iteration's address
    s.add        s4, s4, s6
    s.cmp.lt     s14, s4, s2
    br.nz        s14, for_3
endfor_4:
    vf.reduce.add.b v0, v8
    vf.reduce.add.b v1, v9
    vf.reduce.add.b v2, v10
    vf.reduce.add.b v4, v11
    vf.add       v5, v0, v1
    s.movz       s4, #1
    vf.add       v0, v2, v4
    s.shli       s12, s8, #2                     // element offset -> bytes (x4)
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v2, s4
    s.add        s4, s11, s12                    // &out_ptr3[...]
    vf.add       v4, v5, v0
    v.cmp.lt     p1, v1, v2
    vf.add       v0, v4, v3
    @p1 v.st.w       [s4, #0], v0
__rctx_next:
    s.addi       s4, s8, #2                      // the next program of this context: + 2
    s.cmp.lt     s12, s4, s9
    s.mov        s8, s4
    br.nz        s12, __rctx_program
    exit
