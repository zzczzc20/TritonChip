    s.rdspecial  s1, arg_base
    s.rdspecial  s2, arg_base
    s.ld.d       s3, [s1, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s4, #512
    .li       s5, #2147483647
    s.mul        s6, s1, s4
    .li       s1, #2147483647
    s.movz       s4, #2048
    s.movz       s7, #2
    .li       s8, #68719476752
    .li       s9, #8589934592
    s.rdspecial  s10, arg_base
    s.ld.d       s11, [s2, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.add        s12, s3, s6                     // this context's own scratch
    s.rdspecial  s3, role_id
    s.addi       s6, s12, #0                     // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.movz       s12, #512
    .li       s13, #2147483647
    s.mul        s14, s3, s12
    .li       s3, #2147483647
    s.movz       s12, #2048
    s.movz       s15, #2
    .li       s16, #68719476752
    s.ld.d       s17, [s2, #8]                   // arg_B: device_ptr64 at arg_base+8
    .li       s18, #8589934592
    s.movz       s19, #0
    s.movz       s19, #0
    s.ld.d       s19, [s2, #16]                  // in_ptr2: device_ptr64 at arg_base+16
    s.movz       s20, #176
    s.ld.d       s21, [s2, #24]                  // out_ptr1: device_ptr64 at arg_base+24
    s.movz       s2, #0
    s.movz       s22, #0
    s.cmp.lt     s23, s20, s2
    s.sub        s2, s22, s23
    s.movz       s22, #0
    s.st.d       [s6, #0], s11
    s.xor        s11, s20, s2
    s.sub        s23, s11, s2
    s.movz       s11, #0
    s.st.d       [s6, #8], s5
    .li       s5, #1952257862
    s.st.d       [s6, #16], s1
    s.movz       s1, #32
    s.st.d       [s6, #48], s4
    s.movz       s4, #1
    s.st.d       [s6, #56], s7
    s.movz       s7, #0
    s.st.d       [s6, #88], s8
    s.movz       s8, #0
    s.st.d       [s6, #104], s9
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s6, #0
    s.movz       s9, #0
    s.ld.d       s23, [s10, #32]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.add        s10, s23, s14                   // this context's own scratch
    s.movz       s14, #0
    s.addi       s23, s10, #256                  // TensorMap 1: a tile contiguous down its columns (built once, at entry)
    s.st.d       [s23, #0], s17
    s.movz       s10, #0
    s.st.d       [s23, #8], s13
    s.movz       s13, #1
    s.st.d       [s23, #16], s3
    s.rdspecial  s3, role_id
    s.st.d       [s23, #48], s12
    s.rdspecial  s12, npid.x
    s.st.d       [s23, #56], s15
    s.st.d       [s23, #88], s16
    s.st.d       [s23, #104], s18
    fence.release.device
    td.load      d1, [s23]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
__rctx_program:
    s.cmp.lt     s15, s3, s11
    s.cmp.lt     s16, s3, s8
    s.sub        s17, s22, s15
    s.sub        s15, s7, s16
    s.xor        s16, s3, s17
    s.xor        s18, s17, s2
    s.sub        s23, s16, s17
    s.xor        s16, s3, s15
    s.mul        s17, s23, s5
    s.sub        s24, s16, s15
    s.addi       s16, s14, #0
    s.addi       s25, s10, #0
    s.mov        s16, s24
    s.lshri      s26, s17, #32
    s.sub        s17, s23, s26
    s.lshri      s27, s17, #1
    s.add        s17, s26, s27
    s.lshri      s26, s17, #7
    s.xor        s17, s26, s18
    s.muli       s27, s26, #176
    s.sub        s26, s17, s18
    s.sub        s17, s1, s26
    s.min.s      s18, s17, s4
    s.sub        s17, s23, s27
    s.cmp.lt     s17, s18, s9
    s.sub        s23, s6, s17
    s.xor        s17, s18, s23
    s.sub        s27, s17, s23
    s.cmp.eq     s17, s27, s13
    br.nz        s17, sdiv_done_1
    s.movz       s17, #0
    s.movz       s23, #31
    s.mov        s16, s17
    s.addi       s17, s23, #0
sdiv_2:
    s.lshr       s23, s24, s17
    s.shli       s28, s25, #1
    s.andi       s29, s23, #1
    s.movz       s23, #0
    s.or         s30, s28, s29
    s.movz       s28, #1
    s.cmp.geu    s29, s30, s27
    s.shl        s31, s28, s17
    s.sub        s28, s23, s29
    s.subi       s23, s17, #1
    s.and        s29, s27, s28
    s.and        s32, s31, s28
    s.sub        s28, s30, s29
    s.or         s29, s16, s32
    s.mov        s25, s28
    s.mov        s16, s29
    s.mov        s17, s23
    s.movz       s23, #0
    s.cmp.ge     s28, s17, s23
    br.nz        s28, sdiv_2
sdiv_done_1:
    s.movz       s16, #0
    s.movz       s17, #0
    s.cmp.lt     s23, s3, s16
    .li       s16, #1952257862
    s.sub        s24, s17, s23
    s.movz       s17, #0
    s.xor        s23, s3, s24
    s.movz       s27, #0
    s.sub        s28, s23, s24
    s.movz       s23, #0
    s.mul        s29, s28, s16
    s.cmp.lt     s16, s18, s17
    s.movz       s17, #0
    s.movz       s30, #0
    s.sub        s31, s23, s16
    s.lshri      s16, s29, #32
    s.movz       s23, #0
    s.cmp.lt     s29, s20, s17
    s.xor        s17, s18, s31
    s.xor        s18, s25, s15
    s.sub        s25, s23, s29
    s.sub        s23, s28, s16
    s.sub        s29, s17, s31
    s.lshri      s17, s23, #1
    s.sub        s23, s18, s15
    s.add        s15, s16, s17
    s.movz       s16, #0
    s.lshri      s17, s15, #7
    s.movz       s15, #1
    s.muli       s18, s17, #176
    s.addi       s17, s16, #0
    s.cmp.eq     s16, s29, s15
    s.add        s15, s26, s23
    s.xor        s23, s20, s25
    s.sub        s26, s28, s18
    s.movz       s18, #0
    s.xor        s28, s26, s24
    s.sub        s26, s23, s25
    s.sub        s23, s28, s24
    s.addi       s24, s18, #0
    s.cmp.lt     s18, s23, s27
    s.sub        s25, s30, s18
    s.xor        s18, s23, s25
    s.sub        s23, s18, s25
    s.mov        s17, s23
    br.nz        s16, sdiv_done_3
    s.movz       s16, #0
    s.movz       s18, #31
    s.mov        s17, s16
    s.addi       s16, s18, #0
sdiv_4:
    s.lshr       s18, s23, s16
    s.shli       s26, s24, #1
    s.andi       s27, s18, #1
    s.movz       s18, #0
    s.or         s28, s26, s27
    s.movz       s26, #1
    s.cmp.geu    s27, s28, s29
    s.shl        s30, s26, s16
    s.sub        s26, s18, s27
    s.subi       s18, s16, #1
    s.and        s27, s29, s26
    s.and        s32, s30, s26
    s.sub        s26, s28, s27
    s.or         s27, s17, s32
    s.mov        s24, s26
    s.mov        s17, s27
    s.mov        s16, s18
    s.movz       s18, #0
    s.cmp.ge     s26, s16, s18
    br.nz        s26, sdiv_4
sdiv_done_3:
    s.xor        s16, s25, s31
    s.movz       s18, #16
    s.xor        s23, s17, s16
    .li       s17, #1952257862
    s.sub        s24, s23, s16
    s.mul        s16, s15, s18
    s.mul        s23, s24, s18
    s.movz       s25, #0
    v.splat      v0, s15
    v.splat      v1, s25
    s.andi       s15, s16, #511
    s.mul        s26, s23, s17
    v.splat      v2, s24
    v.splat      v3, s25
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s16
    s.lshri      s17, s26, #32
    v.cmp.ge     p1, v0, v1
    s.sub        s24, s23, s17
    v.splat      v0, s23
    s.lshri      s26, s24, #1
    v.splat      v1, s15
    s.add        s24, s17, s26
    v.cmp.ge     p1, v2, v3
    s.lshri      s17, s24, #11
    v.iota       v2                              // arange(0, VLEN)
    s.muli       s24, s17, #2816
    v.iota       v3                              // arange(0, VLEN)
    v.add        v6, v5, v4
    v.add        v5, v0, v4
    v.add        v0, v1, v2
    s.sub        s17, s23, s24
    s.movz       s24, #64
    v.splat      v0, s17
    s.addi       s26, s25, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    v.add        v1, v0, v3
for_5:
    s.cmp.ge     s25, s26, s24
    br.nz        s25, endfor_6
    s.mul        s25, s26, s18
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s27, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s28, s26, s4
    s.movz       s29, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s30, s15                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s31, s25                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s30, s27
    mb.wait      s27
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s30, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s31, s17                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s32, s25                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s31, s30
    mb.wait      s30
    mb.arm       s25, b2, #0, #1                 // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.f16 a0, v56, v48, s25
    mb.wait      s25
    s.mov        s26, s28
    br.nz        s29, for_5
endfor_6:
    s.muli       s15, s23, #2                    // a runtime tile origin, x2
    s.add        s17, s19, s15                   // the tile origin
    s.muli       s15, s16, #5632                 // a runtime tile origin, x5632
    s.add        s18, s17, s15                   // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s15, #0
    s.movz       s17, #0
    s.add        s24, s17, s16                   // the tile origin
    v.splat      v0, s24
    s.movz       s17, #512
    v.splat      v1, s17
    v.cmp.lt     p1, v0, v1
    s.movz       s17, #0
    s.add        s26, s17, s23                   // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v2, s26
    v.add        v3, v0, v2
    s.movz       s17, #2816
    v.splat      v0, s17
    v.cmp.lt     p2, v3, v0
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s18, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s15, v2
    s.movz       s15, #1
    s.addi       s17, s18, #5632                 // row 1
    s.addi       s26, s24, #1
    v.splat      v0, s26
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s17, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s15, v2
    s.movz       s15, #2
    s.addi       s17, s18, #11264                // row 2
    s.addi       s26, s24, #2
    v.splat      v0, s26
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s17, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s15, v2
    s.movz       s15, #3
    s.addi       s17, s18, #16896                // row 3
    s.addi       s26, s24, #3
    v.splat      v0, s26
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s17, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s15, v2
    s.movz       s15, #4
    s.addi       s17, s18, #22528                // row 4
    s.addi       s26, s24, #4
    v.splat      v0, s26
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s17, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s15, v2
    s.movz       s15, #5
    s.addi       s17, s18, #28160                // row 5
    s.addi       s26, s24, #5
    v.splat      v0, s26
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s17, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s15, v2
    s.movz       s15, #6
    s.movz       s17, #33792
    s.add        s26, s18, s17                   // row 6
    s.addi       s17, s24, #6
    v.splat      v0, s17
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s26, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s15, v2
    s.movz       s15, #7
    s.movz       s17, #39424
    s.add        s26, s18, s17                   // row 7
    s.addi       s17, s24, #7
    v.splat      v0, s17
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s26, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s15, v2
    s.movz       s15, #8
    s.movz       s17, #45056
    s.add        s26, s18, s17                   // row 8
    s.addi       s17, s24, #8
    v.splat      v0, s17
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s26, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s15, v2
    s.movz       s15, #9
    s.movz       s17, #50688
    s.add        s26, s18, s17                   // row 9
    s.addi       s17, s24, #9
    v.splat      v0, s17
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s26, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s15, v2
    s.movz       s15, #10
    s.movz       s17, #56320
    s.add        s26, s18, s17                   // row 10
    s.addi       s17, s24, #10
    v.splat      v0, s17
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s26, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s15, v2
    s.movz       s15, #11
    s.movz       s17, #61952
    s.add        s26, s18, s17                   // row 11
    s.addi       s17, s24, #11
    v.splat      v0, s17
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s26, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s15, v2
    s.movz       s15, #12
    .li       s17, #67584
    s.add        s26, s18, s17                   // row 12
    s.addi       s17, s24, #12
    v.splat      v0, s17
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s26, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s15, v2
    s.movz       s15, #13
    .li       s17, #73216
    s.add        s26, s18, s17                   // row 13
    s.addi       s17, s24, #13
    v.splat      v0, s17
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s26, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s15, v2
    s.movz       s15, #14
    .li       s17, #78848
    s.add        s26, s18, s17                   // row 14
    s.addi       s17, s24, #14
    v.splat      v0, s17
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s26, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s15, v2
    s.movz       s15, #15
    .li       s17, #84480
    s.add        s26, s18, s17                   // row 15
    s.addi       s17, s24, #15
    v.splat      v0, s17
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s26, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s15, v2
    .li       s15, #1065353216
    v.splat      v0, s15                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.muli       s15, s23, #2                    // a runtime tile origin, x2
    s.add        s17, s21, s15                   // the tile origin
    s.muli       s15, s16, #5632                 // a runtime tile origin, x5632
    s.add        s16, s17, s15                   // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s15, #0
    a.vread      v2, a1, s15
    s.movz       s15, #0
    a.vread      v3, a1, s15
    vf.neg       v4, v3
    .li       s15, #1069066811
    v.splat      v3, s15                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v5, v4, v3
    vf.fms       v6, v4, v3, v5                  // the exact rounding error of x*log2(e)
    v.exp2.approx v4, v5                         // ISA 8.8: <= 2**-22 relative
    .li       s15, #1060205080
    v.splat      v5, s15                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v7, v6, v5
    vf.fma       v6, v4, v7, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v7, v6, v4
    vf.add       v4, v7, v0
    v.rcp.approx v6, v4                          // ISA 8.8: <= 2**-22 relative
    .li       s15, #1065353216
    v.splat      v7, s15                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v8, v4, v6, v7
    vf.fms       v4, v6, v8, v6
    vf.neg       v8, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.mul       v6, v2, v4                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s15, #0
    a.vread      v2, a0, s15
    vf.cvt.f32.f16 v4, v2
    vf.cvt.f16.f32 v2, v4
    vf.mul       v4, v6, v2
    vf.cvt.f32.f16 v2, v4
    v.splat      v4, s24
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s16, #0], v2
    s.movz       s15, #1
    a.vread      v2, a1, s15
    s.movz       s15, #1
    a.vread      v4, a1, s15
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s15, #1
    a.vread      v2, a0, s15
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s15, s16, #5632                 // row 1
    s.addi       s17, s24, #1
    v.splat      v4, s17
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s15, #0], v2
    s.movz       s15, #2
    a.vread      v2, a1, s15
    s.movz       s15, #2
    a.vread      v4, a1, s15
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s15, #2
    a.vread      v2, a0, s15
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s15, s16, #11264                // row 2
    s.addi       s17, s24, #2
    v.splat      v4, s17
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s15, #0], v2
    s.movz       s15, #3
    a.vread      v2, a1, s15
    s.movz       s15, #3
    a.vread      v4, a1, s15
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s15, #3
    a.vread      v2, a0, s15
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s15, s16, #16896                // row 3
    s.addi       s17, s24, #3
    v.splat      v4, s17
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s15, #0], v2
    s.movz       s15, #4
    a.vread      v2, a1, s15
    s.movz       s15, #4
    a.vread      v4, a1, s15
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s15, #4
    a.vread      v2, a0, s15
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s15, s16, #22528                // row 4
    s.addi       s17, s24, #4
    v.splat      v4, s17
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s15, #0], v2
    s.movz       s15, #5
    a.vread      v2, a1, s15
    s.movz       s15, #5
    a.vread      v4, a1, s15
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s15, #5
    a.vread      v2, a0, s15
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s15, s16, #28160                // row 5
    s.addi       s17, s24, #5
    v.splat      v4, s17
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s15, #0], v2
    s.movz       s15, #6
    a.vread      v2, a1, s15
    s.movz       s15, #6
    a.vread      v4, a1, s15
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s15, #6
    a.vread      v2, a0, s15
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.movz       s15, #33792
    s.add        s17, s16, s15                   // row 6
    s.addi       s15, s24, #6
    v.splat      v4, s15
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s17, #0], v2
    s.movz       s15, #7
    a.vread      v2, a1, s15
    s.movz       s15, #7
    a.vread      v4, a1, s15
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s15, #7
    a.vread      v2, a0, s15
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.movz       s15, #39424
    s.add        s17, s16, s15                   // row 7
    s.addi       s15, s24, #7
    v.splat      v4, s15
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s17, #0], v2
    s.movz       s15, #8
    a.vread      v2, a1, s15
    s.movz       s15, #8
    a.vread      v4, a1, s15
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s15, #8
    a.vread      v2, a0, s15
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.movz       s15, #45056
    s.add        s17, s16, s15                   // row 8
    s.addi       s15, s24, #8
    v.splat      v4, s15
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s17, #0], v2
    s.movz       s15, #9
    a.vread      v2, a1, s15
    s.movz       s15, #9
    a.vread      v4, a1, s15
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s15, #9
    a.vread      v2, a0, s15
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.movz       s15, #50688
    s.add        s17, s16, s15                   // row 9
    s.addi       s15, s24, #9
    v.splat      v4, s15
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s17, #0], v2
    s.movz       s15, #10
    a.vread      v2, a1, s15
    s.movz       s15, #10
    a.vread      v4, a1, s15
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s15, #10
    a.vread      v2, a0, s15
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.movz       s15, #56320
    s.add        s17, s16, s15                   // row 10
    s.addi       s15, s24, #10
    v.splat      v4, s15
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s17, #0], v2
    s.movz       s15, #11
    a.vread      v2, a1, s15
    s.movz       s15, #11
    a.vread      v4, a1, s15
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s15, #11
    a.vread      v2, a0, s15
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.movz       s15, #61952
    s.add        s17, s16, s15                   // row 11
    s.addi       s15, s24, #11
    v.splat      v4, s15
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s17, #0], v2
    s.movz       s15, #12
    a.vread      v2, a1, s15
    s.movz       s15, #12
    a.vread      v4, a1, s15
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s15, #12
    a.vread      v2, a0, s15
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    .li       s15, #67584
    s.add        s17, s16, s15                   // row 12
    s.addi       s15, s24, #12
    v.splat      v4, s15
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s17, #0], v2
    s.movz       s15, #13
    a.vread      v2, a1, s15
    s.movz       s15, #13
    a.vread      v4, a1, s15
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s15, #13
    a.vread      v2, a0, s15
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    .li       s15, #73216
    s.add        s17, s16, s15                   // row 13
    s.addi       s15, s24, #13
    v.splat      v4, s15
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s17, #0], v2
    s.movz       s15, #14
    a.vread      v2, a1, s15
    s.movz       s15, #14
    a.vread      v4, a1, s15
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s15, #14
    a.vread      v2, a0, s15
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    .li       s15, #78848
    s.add        s17, s16, s15                   // row 14
    s.addi       s15, s24, #14
    v.splat      v4, s15
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s17, #0], v2
    s.movz       s15, #15
    a.vread      v2, a1, s15
    s.movz       s15, #15
    a.vread      v4, a1, s15
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v3, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v5, v3, v4, v3                  // 2**t * 2**d
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v4, v5, v3
    vf.add       v3, v4, v0
    v.rcp.approx v0, v3                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v4, v3, v0, v7
    vf.fms       v3, v0, v4, v0
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v0
    vf.mul       v0, v2, v3                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s15, #15
    a.vread      v2, a0, s15
    vf.cvt.f32.f16 v3, v2
    vf.cvt.f16.f32 v2, v3
    vf.mul       v3, v0, v2
    vf.cvt.f32.f16 v0, v3
    .li       s15, #84480
    s.add        s17, s16, s15                   // row 15
    s.addi       s15, s24, #15
    v.splat      v2, s15
    v.cmp.lt     p1, v2, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s17, #0], v0
__rctx_next:
    s.addi       s15, s3, #2                     // the next program of this context: + 2
    s.cmp.lt     s16, s15, s12
    s.mov        s3, s15
    br.nz        s16, __rctx_program
    exit
