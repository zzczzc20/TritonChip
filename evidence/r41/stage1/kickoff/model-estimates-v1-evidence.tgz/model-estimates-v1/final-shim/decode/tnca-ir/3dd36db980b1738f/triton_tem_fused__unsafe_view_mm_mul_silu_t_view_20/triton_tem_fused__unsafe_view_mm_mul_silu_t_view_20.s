    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.rdspecial  s1, arg_base
    s.ld.d       s6, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s7, #1024
    s.mul        s8, s1, s7
    s.add        s1, s6, s8                      // this context's own scratch
    s.addi       s6, s1, #0                      // TensorMap 0: a tile contiguous down its columns (built once, at entry)
    s.movz       s1, #0
    s.st.d       [s6, #0], s3
    .li       s1, #2147483647
    s.st.d       [s6, #8], s1
    .li       s1, #2147483647
    s.st.d       [s6, #16], s1
    s.movz       s1, #12288
    s.st.d       [s6, #48], s1
    s.movz       s1, #2
    s.st.d       [s6, #56], s1
    .li       s1, #68719476752
    s.st.d       [s6, #88], s1
    .li       s1, #1108101562368
    s.st.d       [s6, #104], s1
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #128
    s.movz       s3, #0
    s.movz       s6, #0
    s.movz       s7, #0
    s.movz       s8, #0
    s.cmp.lt     s9, s1, s8
    s.sub        s8, s7, s9
    s.xor        s7, s1, s8
    s.sub        s9, s7, s8
    s.movz       s7, #1
    s.movz       s9, #0
    s.movz       s10, #0
    s.movz       s11, #0
    s.movz       s12, #0
    s.movz       s13, #0
    s.movz       s14, #0
    s.movz       s15, #1
    s.cmp.lt     s16, s4, s6
    s.sub        s6, s3, s16
    s.xor        s3, s4, s6
    s.sub        s16, s3, s6
    s.lshri      s3, s16, #7
    s.muli       s17, s3, #128
    s.sub        s18, s16, s17
    s.xor        s16, s6, s8
    s.xor        s6, s3, s16
    s.sub        s3, s6, s16
    s.sub        s6, s7, s3
    s.min.s      s8, s6, s7
    s.cmp.lt     s6, s4, s10
    s.sub        s10, s9, s6
    s.cmp.lt     s6, s8, s12
    s.sub        s9, s11, s6
    s.xor        s6, s4, s10
    s.sub        s11, s6, s10
    s.xor        s6, s8, s9
    s.sub        s12, s6, s9
    s.addi       s6, s13, #0
    s.addi       s9, s14, #0
    s.cmp.eq     s13, s12, s15
    s.mov        s6, s11
    br.nz        s13, sdiv_done_1
    s.movz       s13, #0
    s.movz       s14, #31
    s.mov        s6, s13
    s.addi       s13, s14, #0
sdiv_2:
    s.lshr       s14, s11, s13
    s.shli       s15, s9, #1
    s.andi       s16, s14, #1
    s.movz       s14, #0
    s.or         s17, s15, s16
    s.movz       s15, #1
    s.cmp.geu    s16, s17, s12
    s.shl        s18, s15, s13
    s.sub        s15, s14, s16
    s.subi       s14, s13, #1
    s.and        s16, s12, s15
    s.and        s19, s18, s15
    s.sub        s15, s17, s16
    s.or         s16, s6, s19
    s.mov        s9, s15
    s.mov        s6, s16
    s.mov        s13, s14
    s.movz       s14, #0
    s.cmp.ge     s15, s13, s14
    br.nz        s15, sdiv_2
sdiv_done_1:
    s.movz       s6, #0
    s.movz       s11, #0
    s.cmp.lt     s12, s4, s6
    s.movz       s6, #0
    s.sub        s13, s11, s12
    s.movz       s11, #0
    s.xor        s12, s4, s13
    s.movz       s4, #0
    s.sub        s14, s12, s13
    s.cmp.lt     s12, s8, s6
    s.lshri      s6, s14, #7
    s.movz       s15, #0
    s.muli       s16, s6, #128
    s.sub        s6, s4, s12
    s.movz       s4, #0
    s.cmp.lt     s12, s1, s15
    s.xor        s15, s8, s6
    s.sub        s8, s14, s16
    s.movz       s14, #0
    s.xor        s16, s8, s13
    s.xor        s8, s9, s10
    s.sub        s9, s16, s13
    s.sub        s13, s14, s12
    s.cmp.lt     s12, s9, s11
    s.sub        s11, s15, s6
    s.sub        s14, s4, s12
    s.movz       s4, #0
    s.xor        s12, s9, s14
    s.movz       s9, #1
    s.sub        s15, s8, s10
    s.xor        s8, s1, s13
    s.sub        s1, s12, s14
    s.movz       s10, #0
    s.addi       s12, s4, #0
    s.cmp.eq     s4, s11, s9
    s.add        s9, s3, s15
    s.sub        s3, s8, s13
    s.addi       s3, s10, #0
    s.mov        s12, s1
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.movz       s8, #31
    s.mov        s12, s4
    s.addi       s4, s8, #0
sdiv_4:
    s.lshr       s8, s1, s4
    s.shli       s10, s3, #1
    s.andi       s13, s8, #1
    s.movz       s8, #0
    s.or         s15, s10, s13
    s.movz       s10, #1
    s.cmp.geu    s13, s15, s11
    s.shl        s16, s10, s4
    s.sub        s10, s8, s13
    s.subi       s8, s4, #1
    s.and        s13, s11, s10
    s.and        s17, s16, s10
    s.sub        s10, s15, s13
    s.or         s13, s12, s17
    s.mov        s3, s10
    s.mov        s12, s13
    s.mov        s4, s8
    s.movz       s8, #0
    s.cmp.ge     s10, s4, s8
    br.nz        s10, sdiv_4
sdiv_done_3:
    s.xor        s1, s14, s6
    s.movz       s3, #16
    s.xor        s4, s12, s1
    s.movz       s6, #0
    s.sub        s8, s4, s1
    v.splat      v0, s9
    s.mul        s1, s8, s3
    v.splat      v1, s6
    v.splat      v2, s8
    v.splat      v3, s6
    v.iota       v4                              // arange(0, VLEN)
    s.andi       s4, s1, #2047
    v.splat      v5, s1
    v.splat      v6, s4
    v.cmp.ge     p1, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.cmp.ge     p1, v2, v3
    v.add        v1, v5, v4
    v.add        v1, v6, v0
    s.movz       s8, #384
    s.addi       s10, s6, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s6, s10, s8
    br.nz        s6, endfor_6
    s.mul        s6, s10, s3
    s.muli       s11, s6, #2                     // a runtime tile origin, x2
    s.add        s12, s2, s11                    // the tile origin
    v.ld.h       v0, [s12, #0]
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s11, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s12, s4                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s13, s6                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w0, d0, s12, s11
    mb.wait      s11
    s.rdspecial  s6, arg_base
    s.ld.d       s12, [s6, #24]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s6, role_id
    s.movz       s13, #1024
    s.mul        s14, s6, s13
    s.add        s6, s12, s14                    // this context's own scratch
    s.addi       s12, s6, #256                   // 512 bytes of repack scratch
    // repack 16x16 bf16 through memory: there is no v.pack (ISA sec 8.4)
    v.st.h       [s12, #0], v0
    s.addi       s13, s12, #32                   // row 1
    v.st.h       [s13, #0], v0
    s.addi       s13, s12, #64                   // row 2
    v.st.h       [s13, #0], v0
    s.addi       s13, s12, #96                   // row 3
    v.st.h       [s13, #0], v0
    s.addi       s13, s12, #128                  // row 4
    v.st.h       [s13, #0], v0
    s.addi       s13, s12, #160                  // row 5
    v.st.h       [s13, #0], v0
    s.addi       s13, s12, #192                  // row 6
    v.st.h       [s13, #0], v0
    s.addi       s13, s12, #224                  // row 7
    v.st.h       [s13, #0], v0
    s.addi       s13, s12, #256                  // row 8
    v.st.h       [s13, #0], v0
    s.addi       s13, s12, #288                  // row 9
    v.st.h       [s13, #0], v0
    s.addi       s13, s12, #320                  // row 10
    v.st.h       [s13, #0], v0
    s.addi       s13, s12, #352                  // row 11
    v.st.h       [s13, #0], v0
    s.addi       s13, s12, #384                  // row 12
    v.st.h       [s13, #0], v0
    s.addi       s13, s12, #416                  // row 13
    v.st.h       [s13, #0], v0
    s.addi       s13, s12, #448                  // row 14
    v.st.h       [s13, #0], v0
    s.addi       s13, s12, #480                  // row 15
    v.st.h       [s13, #0], v0
    s.addi       s13, s6, #768                   // TensorMap 1: a repacked tile
    s.movz       s6, #0
    s.st.d       [s13, #0], s12
    s.movz       s6, #16
    s.st.d       [s13, #8], s6
    s.movz       s6, #16
    s.st.d       [s13, #16], s6
    s.movz       s6, #32
    s.st.d       [s13, #48], s6
    s.movz       s6, #2
    s.st.d       [s13, #56], s6
    .li       s6, #68719476752
    s.st.d       [s13, #88], s6
    .li       s6, #1108101562368
    s.st.d       [s13, #104], s6
    fence.release.device
    td.load      d1, [s13]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s6, #0
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s12, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s13, s6                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s14, s6                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s13, s12
    mb.wait      s12
    mb.arm       s6, b2, #0, #1                  // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.bf16 a0, v48, v56, s6
    mb.wait      s6
    s.add        s13, s10, s7
    s.mov        s10, s13
    s.movz       s13, #1
    br.nz        s13, for_5
endfor_6:
    s.mul        s2, s9, s3
    s.movz       s3, #0
    v.splat      v0, s7
    v.movi       v1, #1
    v.movi       v2, #0
    s.add        s4, s3, s2                      // the tile origin
    s.movz       s3, #0
    v.splat      v3, s4
    s.add        s7, s3, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s3, #0
    v.cmp.lt     p1, v3, v0
    @p1 v.sel        v3, v1, v2
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v2, s7
    s.addi       s7, s4, #1
    a.vread      v5, a0, s3
    v.extract    s3, v3, #0
    s.movz       s8, #2048
    s.muli       s9, s1, #2                      // a runtime tile origin, x2
    v.splat      v3, s7
    v.splat      v6, s3
    v.movi       v7, #0
    v.add        v8, v1, v2
    v.splat      v1, s8
    vf.cvt.f32.bf16 v2, v5
    v.cmp.lt     p1, v3, v0
    v.movi       v3, #1
    v.cmp.ne     p2, v6, v7
    v.movi       v5, #0
    v.cmp.lt     p3, v8, v1
    s.add        s1, s5, s9                      // the tile origin
    @p1 v.sel        v1, v3, v5
    p.and        p1, p2, p3
    s.movz       s3, #1
    s.addi       s5, s4, #2
    @p1 v.st.h       [s1, #0], v2
    a.vread      v2, a0, s3
    v.extract    s3, v1, #0
    v.movi       v1, #0
    v.splat      v3, s3
    vf.cvt.f32.bf16 v5, v2
    s.movz       s3, #2
    v.cmp.ne     p1, v3, v1
    p.and        p2, p1, p3
    v.splat      v1, s2
    v.splat      v2, s5
    v.add        v3, v1, v4
    v.movi       v1, #1
    v.movi       v3, #0
    v.cmp.lt     p1, v2, v0
    s.addi       s2, s4, #3
    @p1 v.sel        v2, v1, v3
    @p2 v.st.h       [s1, #0], v5
    a.vread      v1, a0, s3
    v.extract    s3, v2, #0
    v.splat      v2, s2
    v.splat      v3, s3
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    vf.cvt.f32.bf16 v7, v1
    v.cmp.lt     p1, v2, v0
    v.cmp.ne     p2, v3, v4
    @p1 v.sel        v1, v5, v6
    p.and        p1, p2, p3
    s.movz       s2, #3
    s.addi       s3, s4, #4
    @p1 v.st.h       [s1, #0], v7
    a.vread      v2, a0, s2
    v.extract    s2, v1, #0
    v.splat      v1, s3
    v.splat      v3, s2
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    vf.cvt.f32.bf16 v7, v2
    v.cmp.lt     p1, v1, v0
    v.cmp.ne     p2, v3, v4
    @p1 v.sel        v1, v5, v6
    p.and        p1, p2, p3
    s.movz       s2, #4
    s.addi       s3, s4, #5
    @p1 v.st.h       [s1, #0], v7
    a.vread      v2, a0, s2
    v.extract    s2, v1, #0
    v.splat      v1, s3
    v.splat      v3, s2
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    vf.cvt.f32.bf16 v7, v2
    v.cmp.lt     p1, v1, v0
    v.cmp.ne     p2, v3, v4
    @p1 v.sel        v1, v5, v6
    p.and        p1, p2, p3
    s.movz       s2, #5
    s.addi       s3, s4, #6
    @p1 v.st.h       [s1, #0], v7
    a.vread      v2, a0, s2
    v.extract    s2, v1, #0
    v.splat      v1, s3
    v.splat      v3, s2
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    vf.cvt.f32.bf16 v7, v2
    v.cmp.lt     p1, v1, v0
    v.cmp.ne     p2, v3, v4
    @p1 v.sel        v1, v5, v6
    p.and        p1, p2, p3
    s.movz       s2, #6
    s.addi       s3, s4, #7
    @p1 v.st.h       [s1, #0], v7
    a.vread      v2, a0, s2
    v.extract    s2, v1, #0
    v.splat      v1, s3
    v.splat      v3, s2
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    vf.cvt.f32.bf16 v7, v2
    v.cmp.lt     p1, v1, v0
    v.cmp.ne     p2, v3, v4
    @p1 v.sel        v1, v5, v6
    p.and        p1, p2, p3
    s.movz       s2, #7
    s.addi       s3, s4, #8
    @p1 v.st.h       [s1, #0], v7
    a.vread      v2, a0, s2
    v.extract    s2, v1, #0
    v.splat      v1, s3
    v.splat      v3, s2
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    vf.cvt.f32.bf16 v7, v2
    v.cmp.lt     p1, v1, v0
    v.cmp.ne     p2, v3, v4
    @p1 v.sel        v1, v5, v6
    p.and        p1, p2, p3
    s.movz       s2, #8
    s.addi       s3, s4, #9
    @p1 v.st.h       [s1, #0], v7
    a.vread      v2, a0, s2
    v.extract    s2, v1, #0
    v.splat      v1, s3
    v.splat      v3, s2
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    vf.cvt.f32.bf16 v7, v2
    v.cmp.lt     p1, v1, v0
    v.cmp.ne     p2, v3, v4
    @p1 v.sel        v1, v5, v6
    p.and        p1, p2, p3
    s.movz       s2, #9
    s.addi       s3, s4, #10
    @p1 v.st.h       [s1, #0], v7
    a.vread      v2, a0, s2
    v.extract    s2, v1, #0
    v.splat      v1, s3
    v.splat      v3, s2
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    vf.cvt.f32.bf16 v7, v2
    v.cmp.lt     p1, v1, v0
    v.cmp.ne     p2, v3, v4
    @p1 v.sel        v1, v5, v6
    p.and        p1, p2, p3
    s.movz       s2, #10
    s.addi       s3, s4, #11
    @p1 v.st.h       [s1, #0], v7
    a.vread      v2, a0, s2
    v.extract    s2, v1, #0
    v.splat      v1, s3
    v.splat      v3, s2
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    vf.cvt.f32.bf16 v7, v2
    v.cmp.lt     p1, v1, v0
    v.cmp.ne     p2, v3, v4
    @p1 v.sel        v1, v5, v6
    p.and        p1, p2, p3
    s.movz       s2, #11
    s.addi       s3, s4, #12
    @p1 v.st.h       [s1, #0], v7
    a.vread      v2, a0, s2
    v.extract    s2, v1, #0
    v.splat      v1, s3
    v.splat      v3, s2
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    vf.cvt.f32.bf16 v7, v2
    v.cmp.lt     p1, v1, v0
    v.cmp.ne     p2, v3, v4
    @p1 v.sel        v1, v5, v6
    p.and        p1, p2, p3
    s.movz       s2, #12
    s.addi       s3, s4, #13
    @p1 v.st.h       [s1, #0], v7
    a.vread      v2, a0, s2
    v.extract    s2, v1, #0
    v.splat      v1, s3
    v.splat      v3, s2
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    vf.cvt.f32.bf16 v7, v2
    v.cmp.lt     p1, v1, v0
    v.cmp.ne     p2, v3, v4
    @p1 v.sel        v1, v5, v6
    p.and        p1, p2, p3
    s.movz       s2, #13
    s.addi       s3, s4, #14
    @p1 v.st.h       [s1, #0], v7
    a.vread      v2, a0, s2
    v.extract    s2, v1, #0
    v.splat      v1, s3
    v.splat      v3, s2
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    vf.cvt.f32.bf16 v7, v2
    v.cmp.lt     p1, v1, v0
    v.cmp.ne     p2, v3, v4
    @p1 v.sel        v1, v5, v6
    p.and        p1, p2, p3
    s.movz       s2, #14
    s.addi       s3, s4, #15
    @p1 v.st.h       [s1, #0], v7
    a.vread      v2, a0, s2
    v.extract    s2, v1, #0
    v.splat      v1, s3
    v.splat      v3, s2
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    vf.cvt.f32.bf16 v7, v2
    v.cmp.lt     p1, v1, v0
    v.cmp.ne     p2, v3, v4
    @p1 v.sel        v0, v5, v6
    p.and        p1, p2, p3
    s.movz       s2, #15
    @p1 v.st.h       [s1, #0], v7
    a.vread      v1, a0, s2
    v.extract    s2, v0, #0
    v.movi       v0, #0
    v.splat      v2, s2
    vf.cvt.f32.bf16 v3, v1
    v.cmp.ne     p1, v2, v0
    p.and        p2, p1, p3
    @p2 v.st.h       [s1, #0], v3
__rctx_next:
    exit
