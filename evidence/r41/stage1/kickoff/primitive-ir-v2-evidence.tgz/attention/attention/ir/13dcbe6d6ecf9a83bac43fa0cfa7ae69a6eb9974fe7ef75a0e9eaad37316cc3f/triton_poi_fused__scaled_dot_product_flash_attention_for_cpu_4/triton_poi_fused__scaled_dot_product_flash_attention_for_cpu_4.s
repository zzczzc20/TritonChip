    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    v.movi       v1, #5
    v.movi       v2, #0
    v.movi       v3, #200
    s.rdspecial  s1, arg_base
    v.splat      v4, s2
    v.sub        v5, v2, v1
    v.cmp.lt     p1, v1, v2
    v.add        v6, v4, v0
    s.ld.d       s3, [s1, #0]                    // in_out_ptr0: device_ptr64 at arg_base+0
    v.movi       v0, #1
    v.sub        v4, v2, v6
    v.cmp.lt     p2, v6, v2
    v.cmp.lt     p3, v6, v3
    @p2 v.sel        v3, v4, v6
    @p1 v.sel        v4, v5, v1
    v.movi       v5, #0
    v.movi       v7, #0
    s.movz       s4, #31
    s.ld.d       s5, [s1, #8]                    // in_ptr0: device_ptr64 at arg_base+8
idiv_1:
    v.splat      v8, s4
    v.shl        v9, v7, v0
    v.cmp.lt     p1, v7, v2
    v.lshr       v10, v3, v8
    v.shl        v11, v0, v8
    s.subi       s1, s4, #1
    v.and        v8, v10, v0
    s.movz       s6, #0
    v.or         v10, v9, v8
    v.cmp.geu    p4, v10, v4
    p.or         p5, p1, p4
    v.sub        v8, v10, v4
    @p5 v.sel        v9, v11, v2
    @p5 v.sel        v11, v8, v10
    v.or         v8, v5, v9
    v.mov        v7, v11
    v.mov        v5, v8
    s.mov        s4, s1
    s.cmp.ge     s1, s4, s6
    br.nz        s1, idiv_1
    v.movi       v0, #0
    v.sub        v3, v2, v7
    v.movi       v2, #1
    v.sub        v4, v0, v6
    v.sub        v5, v0, v1
    v.cmp.lt     p1, v6, v0
    v.cmp.lt     p4, v1, v0
    @p2 v.sel        v8, v3, v7
    @p1 v.sel        v3, v4, v6
    @p4 v.sel        v4, v5, v1
    v.movi       v5, #0
    v.movi       v6, #0
    s.movz       s1, #31
idiv_2:
    v.splat      v7, s1
    v.shl        v9, v6, v2
    v.cmp.lt     p2, v6, v0
    v.lshr       v10, v3, v7
    v.shl        v11, v2, v7
    s.subi       s4, s1, #1
    v.and        v7, v10, v2
    s.movz       s6, #0
    v.or         v10, v9, v7
    v.cmp.geu    p5, v10, v4
    p.or         p6, p2, p5
    v.sub        v7, v10, v4
    @p6 v.sel        v9, v11, v0
    @p6 v.sel        v11, v7, v10
    v.or         v7, v5, v9
    v.mov        v6, v11
    v.mov        v5, v7
    s.mov        s1, s4
    s.cmp.ge     s4, s1, s6
    br.nz        s4, idiv_2
    v.sub        v2, v0, v5
    p.xor        p2, p1, p4
    v.movi       v0, #0
    @p2 v.sel        v3, v2, v5
    v.movi       v2, #1
    v.sub        v4, v0, v1
    v.sub        v5, v0, v3
    v.cmp.lt     p1, v3, v0
    v.cmp.lt     p2, v1, v0
    @p1 v.sel        v6, v5, v3
    @p2 v.sel        v5, v4, v1
    v.movi       v4, #0
    v.movi       v7, #0
    s.movz       s1, #31
idiv_3:
    v.splat      v9, s1
    v.shl        v10, v7, v2
    v.cmp.lt     p2, v7, v0
    v.lshr       v11, v6, v9
    v.shl        v12, v2, v9
    s.subi       s4, s1, #1
    v.and        v9, v11, v2
    s.movz       s6, #0
    v.or         v11, v10, v9
    v.cmp.geu    p4, v11, v5
    p.or         p5, p2, p4
    v.sub        v9, v11, v5
    @p5 v.sel        v10, v12, v0
    @p5 v.sel        v12, v9, v11
    v.or         v9, v4, v10
    v.mov        v7, v12
    v.mov        v4, v9
    s.mov        s1, s4
    s.cmp.ge     s4, s1, s6
    br.nz        s4, idiv_3
    v.sub        v2, v0, v7
    v.mul        v0, v3, v1
    v.movi       v1, #1
    @p1 v.sel        v3, v2, v7
    v.movi       v2, #2
    v.movi       v4, #3
    v.sub        v5, v8, v3
    v.movi       v6, #4
    s.shli       s1, s2, #2                      // element offset -> bytes (x4)
    v.extract    s2, v5, #0
    v.extract    s4, v5, #1
    s.shli       s6, s2, #32
    v.add        v7, v0, v1
    s.ashri      s2, s6, #32
    v.add        v8, v0, v2
    v.add        v9, v0, v4
    v.add        v10, v0, v6
    v.movi       v11, #0
    v.movi       v12, #0
    s.shli       s6, s4, #32
    s.add        s4, s5, s1                      // &in_ptr0[...]
    s.lshri      s7, s2, #32
    v.extract    s8, v5, #2
    s.ashri      s9, s6, #32
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v13, [s4, #0]
    s.shli       s4, s8, #32
    s.lshri      s6, s9, #32
    s.ashri      s8, s4, #32
    s.movz       s4, #5
    s.movz       s4, #1
    s.movz       s4, #2
    s.movz       s4, #3
    s.movz       s4, #4
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v14, [s5, v0]              // index is in elements (ISA sec 9.1)
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s5, v7]               // index is in elements (ISA sec 9.1)
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v7, [s5, v8]               // index is in elements (ISA sec 9.1)
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v8, [s5, v9]               // index is in elements (ISA sec 9.1)
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v9, [s5, v10]              // index is in elements (ISA sec 9.1)
    v.insert     v11, s2, #0
    v.insert     v12, s7, #0
    v.extract    s2, v5, #3
    v.insert     v11, s9, #1
    v.insert     v12, s6, #1
    s.shli       s4, s2, #32
    s.lshri      s2, s8, #32
    v.extract    s5, v5, #4
    s.ashri      s6, s4, #32
    v.insert     v11, s8, #2
    v.insert     v12, s2, #2
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v5, #5
    s.ashri      s7, s2, #32
    v.insert     v11, s6, #3
    v.insert     v12, s4, #3
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v5, #6
    s.ashri      s6, s2, #32
    v.insert     v11, s7, #4
    v.insert     v12, s4, #4
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v5, #7
    s.ashri      s7, s2, #32
    v.insert     v11, s6, #5
    v.insert     v12, s4, #5
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v5, #8
    s.ashri      s6, s2, #32
    v.insert     v11, s7, #6
    v.insert     v12, s4, #6
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v5, #9
    s.ashri      s7, s2, #32
    v.insert     v11, s6, #7
    v.insert     v12, s4, #7
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v5, #10
    s.ashri      s6, s2, #32
    v.insert     v11, s7, #8
    v.insert     v12, s4, #8
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v5, #11
    s.ashri      s7, s2, #32
    v.insert     v11, s6, #9
    v.insert     v12, s4, #9
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v5, #12
    s.ashri      s6, s2, #32
    v.insert     v11, s7, #10
    v.insert     v12, s4, #10
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v5, #13
    s.ashri      s7, s2, #32
    v.insert     v11, s6, #11
    v.insert     v12, s4, #11
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v5, #14
    s.ashri      s6, s2, #32
    v.insert     v11, s7, #12
    v.insert     v12, s4, #12
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v5, #15
    s.ashri      s7, s2, #32
    v.insert     v11, s6, #13
    v.insert     v12, s4, #13
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    s.ashri      s5, s2, #32
    v.insert     v11, s7, #14
    v.insert     v12, s4, #14
    s.lshri      s2, s5, #32
    v.insert     v11, s5, #15
    v.insert     v12, s2, #15
    s.movz       s2, #0
    v.extract    s4, v11, #0
    v.extract    s5, v12, #0
    v.extract    s6, v12, #1
    s.shli       s7, s5, #32
    v.movi       v5, #0
    s.or         s5, s4, s7
    v.extract    s4, v11, #1
    s.shli       s7, s6, #32
    s.cmp.le     s6, s5, s2
    v.extract    s2, v12, #2
    s.or         s5, s4, s7
    s.movz       s4, #0
    v.insert     v5, s6, #0
    v.extract    s6, v11, #2
    s.shli       s7, s2, #32
    s.cmp.le     s2, s5, s4
    v.extract    s4, v12, #3
    s.or         s5, s6, s7
    s.movz       s6, #0
    v.insert     v5, s2, #1
    v.extract    s2, v11, #3
    s.shli       s7, s4, #32
    s.cmp.le     s4, s5, s6
    v.extract    s5, v12, #4
    s.or         s6, s2, s7
    s.movz       s2, #0
    v.insert     v5, s4, #2
    v.extract    s4, v11, #4
    s.shli       s7, s5, #32
    s.cmp.le     s5, s6, s2
    v.extract    s2, v12, #5
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v5, s5, #3
    v.extract    s5, v11, #5
    s.shli       s7, s2, #32
    s.cmp.le     s2, s6, s4
    v.extract    s4, v12, #6
    s.or         s6, s5, s7
    s.movz       s5, #0
    v.insert     v5, s2, #4
    v.extract    s2, v11, #6
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s5
    v.extract    s5, v12, #7
    s.or         s6, s2, s7
    s.movz       s2, #0
    v.insert     v5, s4, #5
    v.extract    s4, v11, #7
    s.shli       s7, s5, #32
    s.cmp.le     s5, s6, s2
    v.extract    s2, v12, #8
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v5, s5, #6
    v.extract    s5, v11, #8
    s.shli       s7, s2, #32
    s.cmp.le     s2, s6, s4
    v.extract    s4, v12, #9
    s.or         s6, s5, s7
    s.movz       s5, #0
    v.insert     v5, s2, #7
    v.extract    s2, v11, #9
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s5
    v.extract    s5, v12, #10
    s.or         s6, s2, s7
    s.movz       s2, #0
    v.insert     v5, s4, #8
    v.extract    s4, v11, #10
    s.shli       s7, s5, #32
    s.cmp.le     s5, s6, s2
    v.extract    s2, v12, #11
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v5, s5, #9
    v.extract    s5, v11, #11
    s.shli       s7, s2, #32
    s.cmp.le     s2, s6, s4
    v.extract    s4, v12, #12
    s.or         s6, s5, s7
    s.movz       s5, #0
    v.insert     v5, s2, #10
    v.extract    s2, v11, #12
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s5
    v.extract    s5, v12, #13
    v.movi       v10, #-1
    s.or         s6, s2, s7
    s.movz       s2, #0
    v.insert     v5, s4, #11
    v.extract    s4, v11, #13
    s.shli       s7, s5, #32
    s.cmp.le     s5, s6, s2
    v.extract    s2, v12, #14
    v.mul        v15, v3, v10
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v5, s5, #12
    v.extract    s5, v11, #14
    s.shli       s7, s2, #32
    s.cmp.le     s2, s6, s4
    v.extract    s4, v12, #15
    v.extract    s6, v15, #0
    s.or         s8, s5, s7
    s.movz       s5, #0
    v.insert     v5, s2, #13
    v.extract    s2, v11, #15
    s.shli       s7, s4, #32
    s.shli       s4, s6, #32
    s.cmp.le     s6, s8, s5
    v.extract    s5, v15, #1
    s.or         s8, s2, s7
    s.movz       s2, #0
    s.ashri      s7, s4, #32
    v.insert     v5, s6, #14
    v.movi       v10, #0
    v.movi       v11, #0
    s.shli       s4, s5, #32
    s.cmp.le     s5, s8, s2
    s.lshri      s2, s7, #32
    v.extract    s6, v15, #2
    s.ashri      s8, s4, #32
    v.insert     v5, s5, #15
    v.insert     v10, s7, #0
    v.insert     v11, s2, #0
    s.shli       s2, s6, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v15, #3
    s.ashri      s6, s2, #32
    v.insert     v10, s8, #1
    v.insert     v11, s4, #1
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v15, #4
    s.ashri      s7, s2, #32
    v.insert     v10, s6, #2
    v.insert     v11, s4, #2
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v15, #5
    s.ashri      s6, s2, #32
    v.insert     v10, s7, #3
    v.insert     v11, s4, #3
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v15, #6
    s.ashri      s7, s2, #32
    v.insert     v10, s6, #4
    v.insert     v11, s4, #4
    s.lshri      s2, s7, #32
    v.insert     v10, s7, #5
    v.insert     v11, s2, #5
    v.movi       v12, #0
    .li       s2, #4286578688
    v.splat      v16, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v17, #0
    s.shli       s2, s5, #32
    .li       s4, #-1
    v.cmp.ne     p1, v5, v17
    s.ashri      s4, s2, #32
    @p1 v.sel        v5, v12, v16
    s.lshri      s2, s4, #32
    v.insert     v10, s4, #6
    v.insert     v11, s2, #6
    vf.add       v17, v13, v5
    v.extract    s2, v15, #7
    v.extract    s4, v15, #8
    s.shli       s5, s2, #32
    s.shli       s2, s4, #32
    s.ashri      s4, s5, #32
    v.extract    s5, v15, #9
    s.lshri      s6, s4, #32
    s.ashri      s7, s2, #32
    v.insert     v10, s4, #7
    v.insert     v11, s6, #7
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v15, #10
    s.ashri      s6, s2, #32
    v.insert     v10, s7, #8
    v.insert     v11, s4, #8
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v15, #11
    s.ashri      s7, s2, #32
    v.insert     v10, s6, #9
    v.insert     v11, s4, #9
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v15, #12
    s.ashri      s6, s2, #32
    v.insert     v10, s7, #10
    v.insert     v11, s4, #10
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v15, #13
    s.ashri      s7, s2, #32
    v.insert     v10, s6, #11
    v.insert     v11, s4, #11
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v15, #14
    s.ashri      s6, s2, #32
    v.insert     v10, s7, #12
    v.insert     v11, s4, #12
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v15, #15
    s.ashri      s7, s2, #32
    v.insert     v10, s6, #13
    v.insert     v11, s4, #13
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    s.ashri      s5, s2, #32
    v.insert     v10, s7, #14
    v.insert     v11, s4, #14
    s.lshri      s2, s5, #32
    v.insert     v10, s5, #15
    v.insert     v11, s2, #15
    s.movz       s2, #0
    v.extract    s4, v10, #0
    v.extract    s5, v11, #0
    v.extract    s6, v11, #1
    s.shli       s7, s5, #32
    v.movi       v5, #0
    s.or         s5, s4, s7
    v.extract    s4, v10, #1
    s.shli       s7, s6, #32
    s.cmp.le     s6, s5, s2
    v.extract    s2, v11, #2
    s.or         s5, s4, s7
    s.movz       s4, #0
    v.insert     v5, s6, #0
    v.extract    s6, v10, #2
    s.shli       s7, s2, #32
    s.cmp.le     s2, s5, s4
    v.extract    s4, v11, #3
    s.or         s5, s6, s7
    s.movz       s6, #0
    v.insert     v5, s2, #1
    v.extract    s2, v10, #3
    s.shli       s7, s4, #32
    s.cmp.le     s4, s5, s6
    v.extract    s5, v11, #4
    s.or         s6, s2, s7
    s.movz       s2, #0
    v.insert     v5, s4, #2
    v.extract    s4, v10, #4
    s.shli       s7, s5, #32
    s.cmp.le     s5, s6, s2
    v.extract    s2, v11, #5
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v5, s5, #3
    v.extract    s5, v10, #5
    s.shli       s7, s2, #32
    s.cmp.le     s2, s6, s4
    v.extract    s4, v11, #6
    s.or         s6, s5, s7
    s.movz       s5, #0
    v.insert     v5, s2, #4
    v.extract    s2, v10, #6
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s5
    v.extract    s5, v11, #7
    s.or         s6, s2, s7
    s.movz       s2, #0
    v.insert     v5, s4, #5
    v.extract    s4, v10, #7
    s.shli       s7, s5, #32
    s.cmp.le     s5, s6, s2
    v.extract    s2, v11, #8
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v5, s5, #6
    v.extract    s5, v10, #8
    s.shli       s7, s2, #32
    s.cmp.le     s2, s6, s4
    v.extract    s4, v11, #9
    s.or         s6, s5, s7
    s.movz       s5, #0
    v.insert     v5, s2, #7
    v.extract    s2, v10, #9
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s5
    v.extract    s5, v11, #10
    s.or         s6, s2, s7
    s.movz       s2, #0
    v.insert     v5, s4, #8
    v.extract    s4, v10, #10
    s.shli       s7, s5, #32
    s.cmp.le     s5, s6, s2
    v.extract    s2, v11, #11
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v5, s5, #9
    v.extract    s5, v10, #11
    s.shli       s7, s2, #32
    s.cmp.le     s2, s6, s4
    v.extract    s4, v11, #12
    s.or         s6, s5, s7
    s.movz       s5, #0
    v.insert     v5, s2, #10
    v.extract    s2, v10, #12
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s5
    v.extract    s5, v11, #13
    s.or         s6, s2, s7
    s.movz       s2, #0
    v.insert     v5, s4, #11
    v.extract    s4, v10, #13
    s.shli       s7, s5, #32
    s.cmp.le     s5, s6, s2
    v.extract    s2, v11, #14
    v.sub        v13, v1, v3
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v5, s5, #12
    v.extract    s5, v10, #14
    s.shli       s7, s2, #32
    s.cmp.le     s2, s6, s4
    v.extract    s4, v11, #15
    v.extract    s6, v13, #0
    s.or         s8, s5, s7
    s.movz       s5, #0
    v.insert     v5, s2, #13
    v.extract    s2, v10, #15
    s.shli       s7, s4, #32
    s.shli       s4, s6, #32
    s.cmp.le     s6, s8, s5
    v.extract    s5, v13, #1
    s.or         s8, s2, s7
    s.movz       s2, #0
    s.ashri      s7, s4, #32
    v.insert     v5, s6, #14
    v.movi       v1, #0
    v.movi       v10, #0
    s.shli       s4, s5, #32
    s.cmp.le     s5, s8, s2
    s.lshri      s2, s7, #32
    v.extract    s6, v13, #2
    s.ashri      s8, s4, #32
    v.insert     v5, s5, #15
    v.insert     v1, s7, #0
    v.insert     v10, s2, #0
    s.shli       s2, s6, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v13, #3
    s.ashri      s6, s2, #32
    v.insert     v1, s8, #1
    v.insert     v10, s4, #1
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v13, #4
    s.ashri      s7, s2, #32
    v.insert     v1, s6, #2
    v.insert     v10, s4, #2
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v13, #5
    s.ashri      s6, s2, #32
    v.insert     v1, s7, #3
    v.insert     v10, s4, #3
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v13, #6
    s.ashri      s7, s2, #32
    v.insert     v1, s6, #4
    v.insert     v10, s4, #4
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    s.ashri      s5, s2, #32
    v.insert     v1, s7, #5
    v.insert     v10, s4, #5
    s.lshri      s2, s5, #32
    v.insert     v1, s5, #6
    v.movi       v11, #0
    v.insert     v10, s2, #6
    v.cmp.ne     p1, v5, v11
    v.extract    s2, v13, #7
    @p1 v.sel        v5, v12, v16
    s.shli       s4, s2, #32
    vf.add       v11, v14, v5
    v.extract    s2, v13, #8
    s.ashri      s5, s4, #32
    s.shli       s4, s2, #32
    s.lshri      s2, s5, #32
    v.extract    s6, v13, #9
    s.ashri      s7, s4, #32
    v.insert     v1, s5, #7
    v.insert     v10, s2, #7
    s.shli       s2, s6, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v13, #10
    s.ashri      s6, s2, #32
    v.insert     v1, s7, #8
    v.insert     v10, s4, #8
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v13, #11
    s.ashri      s7, s2, #32
    v.insert     v1, s6, #9
    v.insert     v10, s4, #9
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v13, #12
    s.ashri      s6, s2, #32
    v.insert     v1, s7, #10
    v.insert     v10, s4, #10
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v13, #13
    s.ashri      s7, s2, #32
    v.insert     v1, s6, #11
    v.insert     v10, s4, #11
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v13, #14
    s.ashri      s6, s2, #32
    v.insert     v1, s7, #12
    v.insert     v10, s4, #12
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v13, #15
    s.ashri      s7, s2, #32
    v.insert     v1, s6, #13
    v.insert     v10, s4, #13
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    s.ashri      s5, s2, #32
    v.insert     v1, s7, #14
    v.insert     v10, s4, #14
    s.lshri      s2, s5, #32
    v.insert     v1, s5, #15
    v.insert     v10, s2, #15
    s.movz       s2, #0
    v.extract    s4, v1, #0
    v.extract    s5, v10, #0
    v.extract    s6, v10, #1
    s.shli       s7, s5, #32
    v.movi       v5, #0
    s.or         s5, s4, s7
    v.extract    s4, v1, #1
    s.shli       s7, s6, #32
    s.cmp.le     s6, s5, s2
    v.extract    s2, v10, #2
    s.or         s5, s4, s7
    s.movz       s4, #0
    v.insert     v5, s6, #0
    v.extract    s6, v1, #2
    s.shli       s7, s2, #32
    s.cmp.le     s2, s5, s4
    v.extract    s4, v10, #3
    s.or         s5, s6, s7
    s.movz       s6, #0
    v.insert     v5, s2, #1
    v.extract    s2, v1, #3
    s.shli       s7, s4, #32
    s.cmp.le     s4, s5, s6
    v.extract    s5, v10, #4
    s.or         s6, s2, s7
    s.movz       s2, #0
    v.insert     v5, s4, #2
    v.extract    s4, v1, #4
    s.shli       s7, s5, #32
    s.cmp.le     s5, s6, s2
    v.extract    s2, v10, #5
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v5, s5, #3
    v.extract    s5, v1, #5
    s.shli       s7, s2, #32
    s.cmp.le     s2, s6, s4
    v.extract    s4, v10, #6
    s.or         s6, s5, s7
    s.movz       s5, #0
    v.insert     v5, s2, #4
    v.extract    s2, v1, #6
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s5
    v.extract    s5, v10, #7
    s.or         s6, s2, s7
    s.movz       s2, #0
    v.insert     v5, s4, #5
    v.extract    s4, v1, #7
    s.shli       s7, s5, #32
    s.cmp.le     s5, s6, s2
    v.extract    s2, v10, #8
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v5, s5, #6
    v.extract    s5, v1, #8
    s.shli       s7, s2, #32
    s.cmp.le     s2, s6, s4
    v.extract    s4, v10, #9
    s.or         s6, s5, s7
    s.movz       s5, #0
    v.insert     v5, s2, #7
    v.extract    s2, v1, #9
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s5
    v.extract    s5, v10, #10
    s.or         s6, s2, s7
    s.movz       s2, #0
    v.insert     v5, s4, #8
    v.extract    s4, v1, #10
    s.shli       s7, s5, #32
    s.cmp.le     s5, s6, s2
    v.extract    s2, v10, #11
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v5, s5, #9
    v.extract    s5, v1, #11
    s.shli       s7, s2, #32
    s.cmp.le     s2, s6, s4
    v.extract    s4, v10, #12
    s.or         s6, s5, s7
    s.movz       s5, #0
    v.insert     v5, s2, #10
    v.extract    s2, v1, #12
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s5
    v.extract    s5, v10, #13
    s.or         s6, s2, s7
    s.movz       s2, #0
    v.insert     v5, s4, #11
    v.extract    s4, v1, #13
    s.shli       s7, s5, #32
    s.cmp.le     s5, s6, s2
    v.extract    s2, v10, #14
    v.sub        v13, v2, v3
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v5, s5, #12
    v.extract    s5, v1, #14
    s.shli       s7, s2, #32
    s.cmp.le     s2, s6, s4
    v.extract    s4, v10, #15
    v.extract    s6, v13, #0
    s.or         s8, s5, s7
    s.movz       s5, #0
    v.insert     v5, s2, #13
    v.extract    s2, v1, #15
    s.shli       s7, s4, #32
    s.shli       s4, s6, #32
    s.cmp.le     s6, s8, s5
    v.extract    s5, v13, #1
    s.or         s8, s2, s7
    s.movz       s2, #0
    s.ashri      s7, s4, #32
    v.insert     v5, s6, #14
    v.movi       v1, #0
    v.movi       v2, #0
    s.shli       s4, s5, #32
    s.cmp.le     s5, s8, s2
    s.lshri      s2, s7, #32
    v.extract    s6, v13, #2
    s.ashri      s8, s4, #32
    v.insert     v5, s5, #15
    v.insert     v1, s7, #0
    v.insert     v2, s2, #0
    s.shli       s2, s6, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v13, #3
    s.ashri      s6, s2, #32
    v.insert     v1, s8, #1
    v.insert     v2, s4, #1
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v13, #4
    s.ashri      s7, s2, #32
    v.insert     v1, s6, #2
    v.insert     v2, s4, #2
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v13, #5
    s.ashri      s6, s2, #32
    v.insert     v1, s7, #3
    v.insert     v2, s4, #3
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v13, #6
    s.ashri      s7, s2, #32
    v.insert     v1, s6, #4
    v.insert     v2, s4, #4
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    s.ashri      s5, s2, #32
    v.insert     v1, s7, #5
    v.insert     v2, s4, #5
    v.movi       v10, #0
    s.lshri      s2, s5, #32
    v.insert     v1, s5, #6
    v.cmp.ne     p1, v5, v10
    v.insert     v2, s2, #6
    @p1 v.sel        v5, v12, v16
    v.extract    s2, v13, #7
    vf.add       v10, v0, v5
    s.shli       s4, s2, #32
    vf.max.prop  v0, v11, v10
    v.extract    s2, v13, #8
    s.ashri      s5, s4, #32
    s.shli       s4, s2, #32
    s.lshri      s2, s5, #32
    v.extract    s6, v13, #9
    s.ashri      s7, s4, #32
    v.insert     v1, s5, #7
    v.insert     v2, s2, #7
    s.shli       s2, s6, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v13, #10
    s.ashri      s6, s2, #32
    v.insert     v1, s7, #8
    v.insert     v2, s4, #8
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v13, #11
    s.ashri      s7, s2, #32
    v.insert     v1, s6, #9
    v.insert     v2, s4, #9
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v13, #12
    s.ashri      s6, s2, #32
    v.insert     v1, s7, #10
    v.insert     v2, s4, #10
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v13, #13
    s.ashri      s7, s2, #32
    v.insert     v1, s6, #11
    v.insert     v2, s4, #11
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v13, #14
    s.ashri      s6, s2, #32
    v.insert     v1, s7, #12
    v.insert     v2, s4, #12
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v13, #15
    s.ashri      s7, s2, #32
    v.insert     v1, s6, #13
    v.insert     v2, s4, #13
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    s.ashri      s5, s2, #32
    v.insert     v1, s7, #14
    v.insert     v2, s4, #14
    s.lshri      s2, s5, #32
    v.insert     v1, s5, #15
    v.insert     v2, s2, #15
    s.movz       s2, #0
    v.extract    s4, v1, #0
    v.extract    s5, v2, #0
    v.extract    s6, v2, #1
    s.shli       s7, s5, #32
    v.movi       v5, #0
    s.or         s5, s4, s7
    v.extract    s4, v1, #1
    s.shli       s7, s6, #32
    s.cmp.le     s6, s5, s2
    v.extract    s2, v2, #2
    s.or         s5, s4, s7
    s.movz       s4, #0
    v.insert     v5, s6, #0
    v.extract    s6, v1, #2
    s.shli       s7, s2, #32
    s.cmp.le     s2, s5, s4
    v.extract    s4, v2, #3
    s.or         s5, s6, s7
    s.movz       s6, #0
    v.insert     v5, s2, #1
    v.extract    s2, v1, #3
    s.shli       s7, s4, #32
    s.cmp.le     s4, s5, s6
    v.extract    s5, v2, #4
    s.or         s6, s2, s7
    s.movz       s2, #0
    v.insert     v5, s4, #2
    v.extract    s4, v1, #4
    s.shli       s7, s5, #32
    s.cmp.le     s5, s6, s2
    v.extract    s2, v2, #5
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v5, s5, #3
    v.extract    s5, v1, #5
    s.shli       s7, s2, #32
    s.cmp.le     s2, s6, s4
    v.extract    s4, v2, #6
    s.or         s6, s5, s7
    s.movz       s5, #0
    v.insert     v5, s2, #4
    v.extract    s2, v1, #6
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s5
    v.extract    s5, v2, #7
    s.or         s6, s2, s7
    s.movz       s2, #0
    v.insert     v5, s4, #5
    v.extract    s4, v1, #7
    s.shli       s7, s5, #32
    s.cmp.le     s5, s6, s2
    v.extract    s2, v2, #8
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v5, s5, #6
    v.extract    s5, v1, #8
    s.shli       s7, s2, #32
    s.cmp.le     s2, s6, s4
    v.extract    s4, v2, #9
    s.or         s6, s5, s7
    s.movz       s5, #0
    v.insert     v5, s2, #7
    v.extract    s2, v1, #9
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s5
    v.extract    s5, v2, #10
    s.or         s6, s2, s7
    s.movz       s2, #0
    v.insert     v5, s4, #8
    v.extract    s4, v1, #10
    s.shli       s7, s5, #32
    s.cmp.le     s5, s6, s2
    v.extract    s2, v2, #11
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v5, s5, #9
    v.extract    s5, v1, #11
    s.shli       s7, s2, #32
    s.cmp.le     s2, s6, s4
    v.extract    s4, v2, #12
    s.or         s6, s5, s7
    s.movz       s5, #0
    v.insert     v5, s2, #10
    v.extract    s2, v1, #12
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s5
    v.extract    s5, v2, #13
    s.or         s6, s2, s7
    s.movz       s2, #0
    v.insert     v5, s4, #11
    v.extract    s4, v1, #13
    s.shli       s7, s5, #32
    s.cmp.le     s5, s6, s2
    v.extract    s2, v2, #14
    v.sub        v10, v4, v3
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v5, s5, #12
    v.extract    s5, v1, #14
    s.shli       s7, s2, #32
    s.cmp.le     s2, s6, s4
    v.extract    s4, v2, #15
    v.extract    s6, v10, #0
    s.or         s8, s5, s7
    s.movz       s5, #0
    v.insert     v5, s2, #13
    v.extract    s2, v1, #15
    s.shli       s7, s4, #32
    s.shli       s4, s6, #32
    s.cmp.le     s6, s8, s5
    v.extract    s5, v10, #1
    s.or         s8, s2, s7
    s.movz       s2, #0
    s.ashri      s7, s4, #32
    v.insert     v5, s6, #14
    v.movi       v1, #0
    v.movi       v2, #0
    s.shli       s4, s5, #32
    s.cmp.le     s5, s8, s2
    s.lshri      s2, s7, #32
    v.extract    s6, v10, #2
    s.ashri      s8, s4, #32
    v.insert     v5, s5, #15
    v.insert     v1, s7, #0
    v.insert     v2, s2, #0
    s.shli       s2, s6, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v10, #3
    s.ashri      s6, s2, #32
    v.insert     v1, s8, #1
    v.insert     v2, s4, #1
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v10, #4
    s.ashri      s7, s2, #32
    v.insert     v1, s6, #2
    v.insert     v2, s4, #2
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v10, #5
    s.ashri      s6, s2, #32
    v.insert     v1, s7, #3
    v.insert     v2, s4, #3
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v10, #6
    s.ashri      s7, s2, #32
    v.insert     v1, s6, #4
    v.insert     v2, s4, #4
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    s.ashri      s5, s2, #32
    v.insert     v1, s7, #5
    v.insert     v2, s4, #5
    v.movi       v4, #0
    s.lshri      s2, s5, #32
    v.insert     v1, s5, #6
    v.cmp.ne     p1, v5, v4
    v.insert     v2, s2, #6
    @p1 v.sel        v4, v12, v16
    v.extract    s2, v10, #7
    vf.add       v5, v7, v4
    s.shli       s4, s2, #32
    vf.max.prop  v4, v0, v5
    v.extract    s2, v10, #8
    s.ashri      s5, s4, #32
    s.shli       s4, s2, #32
    s.lshri      s2, s5, #32
    v.extract    s6, v10, #9
    s.ashri      s7, s4, #32
    v.insert     v1, s5, #7
    v.insert     v2, s2, #7
    s.shli       s2, s6, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v10, #10
    s.ashri      s6, s2, #32
    v.insert     v1, s7, #8
    v.insert     v2, s4, #8
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v10, #11
    s.ashri      s7, s2, #32
    v.insert     v1, s6, #9
    v.insert     v2, s4, #9
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v10, #12
    s.ashri      s6, s2, #32
    v.insert     v1, s7, #10
    v.insert     v2, s4, #10
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v10, #13
    s.ashri      s7, s2, #32
    v.insert     v1, s6, #11
    v.insert     v2, s4, #11
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v10, #14
    s.ashri      s6, s2, #32
    v.insert     v1, s7, #12
    v.insert     v2, s4, #12
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v10, #15
    s.ashri      s7, s2, #32
    v.insert     v1, s6, #13
    v.insert     v2, s4, #13
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    s.ashri      s5, s2, #32
    v.insert     v1, s7, #14
    v.insert     v2, s4, #14
    s.lshri      s2, s5, #32
    v.insert     v1, s5, #15
    v.insert     v2, s2, #15
    s.movz       s2, #0
    v.extract    s4, v1, #0
    v.extract    s5, v2, #0
    v.extract    s6, v2, #1
    s.shli       s7, s5, #32
    v.movi       v0, #0
    s.or         s5, s4, s7
    v.extract    s4, v1, #1
    s.shli       s7, s6, #32
    s.cmp.le     s6, s5, s2
    v.extract    s2, v2, #2
    s.or         s5, s4, s7
    s.movz       s4, #0
    v.insert     v0, s6, #0
    v.extract    s6, v1, #2
    s.shli       s7, s2, #32
    s.cmp.le     s2, s5, s4
    v.extract    s4, v2, #3
    s.or         s5, s6, s7
    s.movz       s6, #0
    v.insert     v0, s2, #1
    v.extract    s2, v1, #3
    s.shli       s7, s4, #32
    s.cmp.le     s4, s5, s6
    v.extract    s5, v2, #4
    s.or         s6, s2, s7
    s.movz       s2, #0
    v.insert     v0, s4, #2
    v.extract    s4, v1, #4
    s.shli       s7, s5, #32
    s.cmp.le     s5, s6, s2
    v.extract    s2, v2, #5
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v0, s5, #3
    v.extract    s5, v1, #5
    s.shli       s7, s2, #32
    s.cmp.le     s2, s6, s4
    v.extract    s4, v2, #6
    s.or         s6, s5, s7
    s.movz       s5, #0
    v.insert     v0, s2, #4
    v.extract    s2, v1, #6
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s5
    v.extract    s5, v2, #7
    s.or         s6, s2, s7
    s.movz       s2, #0
    v.insert     v0, s4, #5
    v.extract    s4, v1, #7
    s.shli       s7, s5, #32
    s.cmp.le     s5, s6, s2
    v.extract    s2, v2, #8
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v0, s5, #6
    v.extract    s5, v1, #8
    s.shli       s7, s2, #32
    s.cmp.le     s2, s6, s4
    v.extract    s4, v2, #9
    s.or         s6, s5, s7
    s.movz       s5, #0
    v.insert     v0, s2, #7
    v.extract    s2, v1, #9
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s5
    v.extract    s5, v2, #10
    s.or         s6, s2, s7
    s.movz       s2, #0
    v.insert     v0, s4, #8
    v.extract    s4, v1, #10
    s.shli       s7, s5, #32
    s.cmp.le     s5, s6, s2
    v.extract    s2, v2, #11
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v0, s5, #9
    v.extract    s5, v1, #11
    s.shli       s7, s2, #32
    s.cmp.le     s2, s6, s4
    v.extract    s4, v2, #12
    s.or         s6, s5, s7
    s.movz       s5, #0
    v.insert     v0, s2, #10
    v.extract    s2, v1, #12
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s5
    v.extract    s5, v2, #13
    s.or         s6, s2, s7
    s.movz       s2, #0
    v.insert     v0, s4, #11
    v.extract    s4, v1, #13
    s.shli       s7, s5, #32
    s.cmp.le     s5, s6, s2
    v.extract    s2, v2, #14
    v.sub        v5, v6, v3
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v0, s5, #12
    v.extract    s5, v1, #14
    s.shli       s7, s2, #32
    s.cmp.le     s2, s6, s4
    v.extract    s4, v2, #15
    v.extract    s6, v5, #0
    s.or         s8, s5, s7
    s.movz       s5, #0
    v.insert     v0, s2, #13
    v.extract    s2, v1, #15
    s.shli       s7, s4, #32
    s.shli       s4, s6, #32
    s.cmp.le     s6, s8, s5
    v.extract    s5, v5, #1
    s.or         s8, s2, s7
    s.movz       s2, #0
    s.ashri      s7, s4, #32
    v.insert     v0, s6, #14
    v.movi       v1, #0
    v.movi       v2, #0
    s.shli       s4, s5, #32
    s.cmp.le     s5, s8, s2
    s.lshri      s2, s7, #32
    v.extract    s6, v5, #2
    s.ashri      s8, s4, #32
    v.insert     v0, s5, #15
    v.insert     v1, s7, #0
    v.insert     v2, s2, #0
    s.shli       s2, s6, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v5, #3
    s.ashri      s6, s2, #32
    v.insert     v1, s8, #1
    v.insert     v2, s4, #1
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v5, #4
    s.ashri      s7, s2, #32
    v.insert     v1, s6, #2
    v.insert     v2, s4, #2
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v5, #5
    s.ashri      s6, s2, #32
    v.insert     v1, s7, #3
    v.insert     v2, s4, #3
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v5, #6
    s.ashri      s7, s2, #32
    v.insert     v1, s6, #4
    v.insert     v2, s4, #4
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    s.ashri      s5, s2, #32
    v.insert     v1, s7, #5
    v.insert     v2, s4, #5
    v.movi       v3, #0
    s.lshri      s2, s5, #32
    v.insert     v1, s5, #6
    v.cmp.ne     p1, v0, v3
    v.insert     v2, s2, #6
    @p1 v.sel        v0, v12, v16
    v.extract    s2, v5, #7
    vf.add       v3, v8, v0
    s.shli       s4, s2, #32
    vf.max.prop  v0, v4, v3
    v.extract    s2, v5, #8
    s.ashri      s5, s4, #32
    s.shli       s4, s2, #32
    s.lshri      s2, s5, #32
    v.extract    s6, v5, #9
    s.ashri      s7, s4, #32
    v.insert     v1, s5, #7
    v.insert     v2, s2, #7
    s.shli       s2, s6, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v5, #10
    s.ashri      s6, s2, #32
    v.insert     v1, s7, #8
    v.insert     v2, s4, #8
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v5, #11
    s.ashri      s7, s2, #32
    v.insert     v1, s6, #9
    v.insert     v2, s4, #9
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v5, #12
    s.ashri      s6, s2, #32
    v.insert     v1, s7, #10
    v.insert     v2, s4, #10
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v5, #13
    s.ashri      s7, s2, #32
    v.insert     v1, s6, #11
    v.insert     v2, s4, #11
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v5, #14
    s.ashri      s6, s2, #32
    v.insert     v1, s7, #12
    v.insert     v2, s4, #12
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v5, #15
    s.ashri      s7, s2, #32
    v.insert     v1, s6, #13
    v.insert     v2, s4, #13
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    s.ashri      s5, s2, #32
    v.insert     v1, s7, #14
    v.insert     v2, s4, #14
    s.lshri      s2, s5, #32
    v.insert     v1, s5, #15
    v.insert     v2, s2, #15
    s.movz       s2, #0
    v.extract    s4, v1, #0
    v.extract    s5, v2, #0
    v.extract    s6, v2, #1
    s.shli       s7, s5, #32
    v.movi       v3, #0
    s.or         s5, s4, s7
    v.extract    s4, v1, #1
    s.shli       s7, s6, #32
    s.cmp.le     s6, s5, s2
    v.extract    s2, v2, #2
    s.or         s5, s4, s7
    s.movz       s4, #0
    v.insert     v3, s6, #0
    v.extract    s6, v1, #2
    s.shli       s7, s2, #32
    s.cmp.le     s2, s5, s4
    v.extract    s4, v2, #3
    s.or         s5, s6, s7
    s.movz       s6, #0
    v.insert     v3, s2, #1
    v.extract    s2, v1, #3
    s.shli       s7, s4, #32
    s.cmp.le     s4, s5, s6
    v.extract    s5, v2, #4
    s.or         s6, s2, s7
    s.movz       s2, #0
    v.insert     v3, s4, #2
    v.extract    s4, v1, #4
    s.shli       s7, s5, #32
    s.cmp.le     s5, s6, s2
    v.extract    s2, v2, #5
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v3, s5, #3
    v.extract    s5, v1, #5
    s.shli       s7, s2, #32
    s.cmp.le     s2, s6, s4
    v.extract    s4, v2, #6
    s.or         s6, s5, s7
    s.movz       s5, #0
    v.insert     v3, s2, #4
    v.extract    s2, v1, #6
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s5
    v.extract    s5, v2, #7
    s.or         s6, s2, s7
    s.movz       s2, #0
    v.insert     v3, s4, #5
    v.extract    s4, v1, #7
    s.shli       s7, s5, #32
    s.cmp.le     s5, s6, s2
    v.extract    s2, v2, #8
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v3, s5, #6
    v.extract    s5, v1, #8
    s.shli       s7, s2, #32
    s.cmp.le     s2, s6, s4
    v.extract    s4, v2, #9
    s.or         s6, s5, s7
    s.movz       s5, #0
    v.insert     v3, s2, #7
    v.extract    s2, v1, #9
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s5
    v.extract    s5, v2, #10
    s.or         s6, s2, s7
    s.movz       s2, #0
    v.insert     v3, s4, #8
    v.extract    s4, v1, #10
    s.shli       s7, s5, #32
    s.cmp.le     s5, s6, s2
    v.extract    s2, v2, #11
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v3, s5, #9
    v.extract    s5, v1, #11
    s.shli       s7, s2, #32
    s.cmp.le     s2, s6, s4
    v.extract    s4, v2, #12
    s.or         s6, s5, s7
    s.movz       s5, #0
    v.insert     v3, s2, #10
    v.extract    s2, v1, #12
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s5
    v.extract    s5, v2, #13
    s.or         s6, s2, s7
    s.movz       s2, #0
    v.insert     v3, s4, #11
    v.extract    s4, v1, #13
    s.shli       s7, s5, #32
    s.cmp.le     s5, s6, s2
    v.extract    s2, v2, #14
    s.or         s6, s4, s7
    s.movz       s4, #0
    v.insert     v3, s5, #12
    v.extract    s5, v1, #14
    s.shli       s7, s2, #32
    s.cmp.le     s2, s6, s4
    v.extract    s4, v2, #15
    s.or         s6, s5, s7
    s.movz       s5, #0
    v.insert     v3, s2, #13
    v.extract    s2, v1, #15
    s.shli       s7, s4, #32
    s.cmp.le     s4, s6, s5
    s.or         s5, s2, s7
    s.movz       s2, #0
    v.insert     v3, s4, #14
    s.cmp.le     s4, s5, s2
    v.movi       v1, #0
    v.insert     v3, s4, #15
    .li       s2, #1069066811
    v.splat      v2, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1060205080
    v.splat      v4, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.ne     p1, v3, v1
    @p1 v.sel        v1, v12, v16
    s.add        s2, s3, s1                      // &in_out_ptr0[...]
    vf.add       v3, v9, v1
    vf.max.prop  v1, v0, v3
    vf.sub       v0, v17, v1
    vf.mul       v1, v0, v2
    v.exp2.approx v3, v1                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v0, v2, v1                  // the exact rounding error of x*log2(e)
    vf.mul       v0, v5, v4
    vf.fma       v1, v3, v0, v3                  // 2**t * 2**d
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v0, v1, v3
    @p3 v.st.w       [s2, #0], v0
__rctx_next:
    exit
