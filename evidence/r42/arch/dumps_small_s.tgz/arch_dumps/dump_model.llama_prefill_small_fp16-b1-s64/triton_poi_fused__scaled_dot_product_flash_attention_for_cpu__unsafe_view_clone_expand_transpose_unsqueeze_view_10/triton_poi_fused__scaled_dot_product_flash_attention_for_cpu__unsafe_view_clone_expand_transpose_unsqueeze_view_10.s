    s.rdspecial  s1, arg_base
    s.movz       s2, #256
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #0
    s.rdspecial  s5, role_id
    s.rdspecial  s6, npid.x
    s.ld.d       s7, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
__rctx_program:
    v.movi       v0, #32
    v.movi       v1, #64
    v.movi       v2, #0
    v.movi       v3, #2048
    v.movi       v4, #2
    v.iota       v5                              // arange(0, VLEN)
    v.movi       v6, #16
    v.movi       v7, #48
    v.movi       v8, #80
    v.movi       v9, #96
    v.movi       v10, #112
    v.sub        v11, v2, v0
    v.sub        v12, v2, v1
    v.sub        v13, v2, v3
    v.sub        v14, v2, v4
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    // tiled element-wise program: 256 lanes as 2 tiles of 128 (1 tensor-engine transfers, one load buffer(s))
    s.mul        s1, s5, s2
    s.addi       s8, s4, #0
    v.add        v15, v5, v6
    v.add        v6, v5, v0
    v.add        v16, v5, v7
    v.add        v7, v5, v1
    v.add        v17, v5, v8
    v.add        v8, v5, v9
    v.add        v9, v5, v10
    @p1 v.sel        v10, v11, v0
    v.cmp.lt     p1, v3, v2
    v.movi       v10, #31
    v.movi       v11, #5
    @p2 v.sel        v18, v12, v1
    v.cmp.lt     p2, v4, v2
    v.movi       v12, #63
    @p1 v.sel        v18, v13, v3
    v.movi       v3, #11
    @p2 v.sel        v13, v14, v4
    v.movi       v4, #1
tiles_1:
    // tile 0 of the iteration: lanes t0 + 0
    s.add        s9, s1, s8
    v.splat      v13, s9
    v.add        v14, v13, v5
    v.add        v18, v13, v15
    v.add        v19, v13, v6
    v.add        v20, v13, v16
    v.add        v21, v13, v7
    v.add        v22, v13, v17
    v.add        v23, v13, v8
    v.add        v24, v13, v9
    v.sub        v13, v2, v14
    v.sub        v25, v2, v18
    v.sub        v26, v2, v19
    v.sub        v27, v2, v20
    v.sub        v28, v2, v21
    v.sub        v29, v2, v22
    v.sub        v30, v2, v23
    v.sub        v31, v2, v24
    v.cmp.lt     p1, v14, v2
    v.cmp.lt     p2, v18, v2
    v.cmp.lt     p3, v19, v2
    v.cmp.lt     p4, v20, v2
    v.cmp.lt     p5, v21, v2
    v.cmp.lt     p6, v22, v2
    v.cmp.lt     p7, v23, v2
    v.cmp.lt     p8, v24, v2
    @p1 v.sel        v32, v13, v14
    @p2 v.sel        v13, v25, v18
    @p3 v.sel        v14, v26, v19
    @p4 v.sel        v18, v27, v20
    @p5 v.sel        v19, v28, v21
    @p6 v.sel        v20, v29, v22
    @p7 v.sel        v21, v30, v23
    @p8 v.sel        v22, v31, v24
    v.lshr       v23, v32, v11
    v.and        v24, v32, v10
    v.lshr       v25, v13, v11
    v.sub        v26, v2, v23
    v.and        v27, v13, v10
    v.and        v28, v14, v10
    @p1 v.sel        v29, v26, v23
    v.and        v23, v18, v10
    v.and        v26, v19, v10
    v.and        v30, v20, v10
    v.and        v31, v21, v10
    v.and        v33, v22, v10
    v.sub        v34, v2, v24
    v.sub        v35, v2, v25
    v.sub        v36, v2, v27
    v.sub        v37, v2, v28
    v.sub        v38, v2, v23
    v.sub        v39, v2, v26
    v.sub        v40, v2, v30
    v.sub        v41, v2, v31
    v.sub        v42, v2, v33
    @p1 v.sel        v43, v34, v24
    v.lshr       v24, v14, v11
    v.lshr       v34, v18, v11
    @p2 v.sel        v44, v35, v25
    v.sub        v25, v2, v24
    @p2 v.sel        v35, v36, v27
    v.lshr       v27, v19, v11
    @p3 v.sel        v36, v25, v24
    v.lshr       v24, v20, v11
    @p3 v.sel        v25, v37, v28
    v.lshr       v28, v21, v11
    v.lshr       v37, v22, v11
    @p4 v.sel        v45, v38, v23
    v.sub        v23, v2, v34
    v.cmp.lt     p9, v29, v2
    @p5 v.sel        v38, v39, v26
    v.sub        v26, v2, v27
    @p4 v.sel        v39, v23, v34
    v.sub        v23, v2, v24
    @p5 v.sel        v34, v26, v27
    v.sub        v26, v2, v28
    @p6 v.sel        v27, v23, v24
    v.sub        v23, v2, v37
    @p7 v.sel        v24, v26, v28
    v.sub        v26, v2, v29
    @p8 v.sel        v28, v23, v37
    v.sub        v23, v2, v44
    v.cmp.lt     p10, v44, v2
    @p9 v.sel        v37, v26, v29
    @p10 v.sel        v26, v23, v44
    @p6 v.sel        v23, v40, v30
    v.sub        v29, v2, v36
    v.and        v30, v37, v12
    v.and        v37, v26, v12
    @p7 v.sel        v26, v41, v31
    v.sub        v31, v2, v39
    v.sub        v40, v2, v30
    v.sub        v41, v2, v37
    @p8 v.sel        v44, v42, v33
    v.lshr       v33, v32, v3
    v.lshr       v32, v13, v3
    v.sub        v13, v2, v34
    @p9 v.sel        v42, v40, v30
    v.lshr       v30, v14, v3
    v.lshr       v14, v18, v3
    v.sub        v18, v2, v33
    v.cmp.lt     p9, v36, v2
    @p9 v.sel        v40, v29, v36
    v.sub        v29, v2, v32
    @p1 v.sel        v36, v18, v33
    v.sub        v18, v2, v30
    @p2 v.sel        v33, v29, v32
    v.sub        v29, v2, v14
    @p3 v.sel        v32, v18, v30
    v.sub        v18, v2, v27
    v.cmp.lt     p1, v39, v2
    v.cmp.lt     p2, v34, v2
    v.cmp.lt     p3, v27, v2
    @p1 v.sel        v30, v31, v39
    v.sub        v31, v2, v24
    @p2 v.sel        v39, v13, v34
    v.sub        v13, v2, v28
    @p3 v.sel        v34, v18, v27
    v.and        v18, v40, v12
    v.and        v27, v30, v12
    v.and        v30, v39, v12
    v.and        v39, v34, v12
    v.sub        v34, v2, v18
    @p10 v.sel        v40, v41, v37
    v.lshr       v37, v19, v3
    v.lshr       v19, v20, v3
    @p4 v.sel        v20, v29, v14
    v.sub        v14, v2, v37
    v.sub        v29, v2, v19
    v.cmp.lt     p4, v24, v2
    @p5 v.sel        v41, v14, v37
    v.cmp.lt     p5, v28, v2
    @p4 v.sel        v14, v31, v24
    @p5 v.sel        v24, v13, v28
    v.sub        v13, v2, v27
    v.and        v28, v14, v12
    v.and        v14, v24, v12
    v.sub        v24, v2, v30
    v.sub        v31, v2, v39
    v.sub        v37, v2, v28
    @p9 v.sel        v46, v34, v18
    v.lshr       v18, v21, v3
    v.lshr       v21, v22, v3
    @p6 v.sel        v22, v29, v19
    v.sub        v19, v2, v18
    v.sub        v29, v2, v21
    v.sub        v34, v2, v14
    @p7 v.sel        v47, v19, v18
    @p1 v.sel        v18, v13, v27
    @p8 v.sel        v13, v29, v21
    v.sub        v19, v2, v36
    v.cmp.lt     p1, v36, v2
    @p2 v.sel        v21, v24, v30
    v.sub        v24, v2, v33
    v.cmp.lt     p2, v33, v2
    @p1 v.sel        v27, v19, v36
    @p2 v.sel        v19, v24, v33
    @p3 v.sel        v24, v31, v39
    v.sub        v29, v2, v32
    v.cmp.lt     p3, v32, v2
    v.lshr       v30, v27, v4
    @p3 v.sel        v27, v29, v32
    v.lshr       v29, v19, v4
    v.sub        v19, v2, v30
    v.lshr       v31, v27, v4
    v.sub        v27, v2, v29
    @p1 v.sel        v32, v19, v30
    v.sub        v19, v2, v31
    @p2 v.sel        v30, v27, v29
    @p4 v.sel        v27, v37, v28
    v.sub        v28, v2, v20
    v.cmp.lt     p1, v20, v2
    @p3 v.sel        v29, v19, v31
    @p1 v.sel        v19, v28, v20
    @p5 v.sel        v20, v34, v14
    v.sub        v14, v2, v41
    v.sub        v28, v2, v22
    v.sub        v31, v2, v47
    v.sub        v33, v2, v13
    v.cmp.lt     p2, v41, v2
    v.cmp.lt     p3, v22, v2
    v.cmp.lt     p4, v47, v2
    v.cmp.lt     p5, v13, v2
    @p2 v.sel        v34, v14, v41
    @p3 v.sel        v14, v28, v22
    @p4 v.sel        v22, v31, v47
    @p5 v.sel        v28, v33, v13
    v.lshr       v13, v19, v4
    v.lshr       v19, v34, v4
    v.lshr       v31, v14, v4
    v.lshr       v14, v22, v4
    v.lshr       v22, v28, v4
    v.sub        v28, v2, v13
    v.sub        v33, v2, v19
    v.sub        v34, v2, v31
    v.sub        v36, v2, v14
    v.sub        v37, v2, v22
    @p1 v.sel        v39, v28, v13
    @p2 v.sel        v13, v33, v19
    @p3 v.sel        v19, v34, v31
    @p4 v.sel        v28, v36, v14
    @p5 v.sel        v14, v37, v22
    v.mul        v22, v32, v0
    v.mul        v31, v30, v0
    v.mul        v30, v29, v0
    v.mul        v29, v39, v0
    v.mul        v32, v13, v0
    v.mul        v13, v19, v0
    v.mul        v19, v28, v0
    v.mul        v28, v14, v0
    v.add        v14, v43, v22
    v.add        v22, v35, v31
    v.add        v31, v25, v30
    v.add        v25, v45, v29
    v.add        v29, v38, v32
    v.add        v30, v23, v13
    v.add        v13, v26, v19
    v.add        v19, v44, v28
    v.mul        v23, v42, v1
    v.mul        v26, v40, v1
    v.mul        v28, v46, v1
    v.mul        v32, v18, v1
    v.mul        v18, v21, v1
    v.mul        v21, v24, v1
    v.mul        v24, v27, v1
    v.mul        v27, v20, v1
    v.add        v20, v14, v23
    v.add        v14, v22, v26
    v.add        v22, v31, v28
    v.add        v23, v25, v32
    v.add        v25, v29, v18
    v.add        v18, v30, v21
    v.add        v21, v13, v24
    v.add        v13, v19, v27
    v.ld.gather.h v19, [s3, v20]                 // index is in elements (ISA sec 9.1)
    s.shli       s10, s9, #2
    s.add        s9, s7, s10
    v.ld.gather.h v20, [s3, v14]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v14, v19
    v.ld.gather.h v19, [s3, v22]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v22, v20
    v.ld.gather.h v20, [s3, v23]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v23, v19
    v.ld.gather.h v19, [s3, v25]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v24, v20
    v.ld.gather.h v20, [s3, v18]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v18, v19
    v.ld.gather.h v19, [s3, v21]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v21, v20
    v.ld.gather.h v20, [s3, v13]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v13, v19
    vf.cvt.f16.f32 v19, v20
    v.st.w       [s9, #0], v14
    v.st.w       [s9, #64], v22
    v.st.w       [s9, #128], v23
    v.st.w       [s9, #192], v24
    v.st.w       [s9, #256], v18
    v.st.w       [s9, #320], v21
    v.st.w       [s9, #384], v13
    v.st.w       [s9, #448], v19
    s.addi       s8, s8, #128
    s.cmp.lt     s9, s8, s2
    br.nz        s9, tiles_1
endtiles_2:
__rctx_next:
    s.addi       s1, s5, #4                      // the next program of this context: + 4
    s.cmp.lt     s8, s1, s6
    s.mov        s5, s1
    br.nz        s8, __rctx_program
    exit
