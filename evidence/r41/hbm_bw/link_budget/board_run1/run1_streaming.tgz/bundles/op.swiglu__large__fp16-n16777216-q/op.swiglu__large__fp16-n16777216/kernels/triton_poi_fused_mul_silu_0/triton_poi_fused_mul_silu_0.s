    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.shli       s2, s4, #4                      // x16 as a shift
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.shli       s4, s2, #1                      // element offset -> bytes (x2)
    .li       s5, #1069066811
    v.splat      v0, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s5, s3, s4                      // &in_ptr0[...]
    .li       s3, #1060205080
    v.splat      v1, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.ld.h       v2, [s5, #0]
    .li       s3, #1065353216
    v.splat      v3, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s3, #1065353216
    v.splat      v4, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s2
    vf.cvt.f16.f32 v7, v2
    s.ld.d       s2, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.add        v2, v6, v5
    vf.neg       v2, v7
    s.add        s3, s2, s4                      // &in_ptr1[...]
    s.ld.d       s2, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    vf.mul       v5, v2, v0
    v.ld.h       v6, [s3, #0]
    s.add        s1, s2, s4                      // &out_ptr0[...]
    v.exp2.approx v8, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v2, v0, v5                  // the exact rounding error of x*log2(e)
    vf.cvt.f16.f32 v0, v6
    vf.mul       v2, v9, v1
    vf.fma       v1, v8, v2, v8                  // 2**t * 2**d
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v2, v1, v8
    vf.add       v1, v2, v3
    v.rcp.approx v2, v1                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v3, v1, v2, v4
    vf.fms       v1, v2, v3, v2
    vf.neg       v3, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v2
    vf.mul       v2, v7, v1                      // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v1, v2, v0
    vf.cvt.f32.f16 v0, v1
    v.st.h       [s1, #0], v0
__rctx_next:
    exit
