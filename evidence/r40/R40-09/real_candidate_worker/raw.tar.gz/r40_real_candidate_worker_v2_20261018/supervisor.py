from pathlib import Path
import json,sys,time,copy
r=Path(__file__).resolve().parent
sys.path[:0]=[str(r),str(r/'python'),str(r/'tools/r40')]
from tnca.autotune import GraphBudget,run_measurement
from archbench.provenance import software_tree
from autotune_candidate_worker import validate_result
out=r/'results';out.mkdir(exist_ok=False)
point=next(p for p in json.loads((r/'spec/r40/suites/existing.json').read_text())['points'] if p['id']=='op.add/tiny/fp16-n1000')
identity=software_tree(refresh=True);launch=json.loads((r/'launch.json').read_text());config=launch['backend_args'];rows=[]
budget=GraphBudget(max_seconds=600,max_candidates=2)
for width in (16,32):
 request=dict(suite='native',point_id=point['id'],point_sha256=point['sha256'],software_tree=identity,backend_args=config,max_block=width,image_sha256=None)
 req=out/f'width{width}.request.json';req.write_text(json.dumps(request,indent=2)+'\n');events=out/f'width{width}.events.json';log=out/f'width{width}.log'
 row=dict(max_block=width,status='not-measured')
 try:
  assert budget.admit(point['id'])
  records=run_measurement([sys.executable,'tools/r40/autotune_candidate_worker.py','--functional-rtl','--request',str(req),'--events',str(events)],budget=budget,result_path=events,log_path=log,cwd=r)
  record=json.loads(events.with_suffix('.raw.json').read_text());row.update(status='functional-worker-pass',device_endpoints=records,raw_record=str(events.with_suffix('.raw.json')))
  # Reuse actual data to ensure source/config/schema corruption fails before ranking.
  info=json.loads(events.with_suffix('.info.json').read_text()); assert all(Path(v['path']).is_relative_to(r) for v in info['module_origins'].values()); assert info['timing_policy']['recursive_tuning'] is False and info['timing_policy']['optional_counter_reads'] is False
  mutants=[]
  bad=copy.deepcopy(record); bad['platform'].setdefault('knobs',{})['TNCA_TUNE']='1'
  try:validate_result(bad,request,functional=True)
  except (ValueError,KeyError,TypeError):mutants.append('recursive_tuning')
  else:raise AssertionError('accepted recursive candidate tuning')
  for field,value in [('software_tree','files:wrong'),('image_sha256','f'*64)]:
   bad=copy.deepcopy(request);bad[field]=value
   try:validate_result(record,bad,functional=True)
   except (ValueError,KeyError,TypeError):mutants.append(field)
   else:raise AssertionError('accepted corrupted '+field)
  bad=copy.deepcopy(record);bad['timings']['device-graph-makespan']['endpoint_records'][0][0]['end']+=1
  try:validate_result(bad,request,functional=True)
  except (ValueError,KeyError,TypeError):mutants.append('raw_endpoint')
  else:raise AssertionError('accepted changed raw endpoint')
  row['refused_mutations']=mutants
 except Exception as error:row.update(status='failed',error=repr(error))
 rows.append(row);(out/'summary.json').write_text(json.dumps(dict(scope='functional worker validation only; original tiny point, not holdout or board acceptance; no winner selection',rows=rows,budget_exceeded=budget.exceeded,software_tree=identity,image_sha256=None,clock_hz=None,required_gate_promotions=[]),indent=2)+'\n')
raise SystemExit(0 if len(rows)==2 and all(row['status']=='functional-worker-pass' and len(row.get('refused_mutations',[]))==4 for row in rows) else 1)
