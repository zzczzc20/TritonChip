from pathlib import Path
import subprocess,concurrent.futures,json,itertools
out=Path('/tmp/r40_balanced_results');out.mkdir(exist_ok=False)
def run(command):
 p=subprocess.run(command,capture_output=True,text=True,timeout=240)
 if p.returncode or 'FATAL' in p.stdout or '\nFAIL' in p.stdout:raise RuntimeError(str(command)+'\n'+p.stdout+p.stderr)
 return p.stdout+p.stderr
def case(cfg):
 sets,ways,pol=cfg;d=out/f's{sets}w{ways}p{pol}';d.mkdir();logs=[]
 for balanced in (0,1):
  image=d/f'b{balanced}.vvp'
  text=run(['iverilog','-g2012','-I','rtl/common','-s','tb_nuca_slice',f'-Ptb_nuca_slice.BALANCED_VICTIM={balanced}','-Ptb_nuca_slice.REGISTER_VICTIM_OWNER=1','-Ptb_nuca_slice.EPOCH_CHURN=1','-Ptb_nuca_slice.DCO_REGISTERED_RANGES=1',f'-Ptb_nuca_slice.POLICY={pol}',f'-Ptb_nuca_slice.SETS={sets}',f'-Ptb_nuca_slice.SET_W={sets.bit_length()-1}',f'-Ptb_nuca_slice.WAYS={ways}',f'-Ptb_nuca_slice.WAY_W={ways.bit_length()-1}','-o',str(image),'rtl/nuca/tnca_nuca_slice.v','tb/common/tnca_dram_model.v','tb/nuca/tb_nuca_slice.v']);(d/f'b{balanced}_compile.log').write_text(text)
  text=run(['vvp',str(image),'+nreq=5000','+seed=7','+min_wb=1']);assert 'PASS' in text.splitlines(),text;(d/f'b{balanced}.log').write_text(text);logs.append(text)
 assert logs[0]==logs[1],('serial/balanced cycle or output difference',cfg)
 print('SERIAL/BALANCED IDENTICAL',cfg,flush=True)
 return dict(sets=sets,ways=ways,policy=pol,seed=7,requests=5000,output_and_cycles_identical=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 results=list(pool.map(case,[(s,w,p) for s,w in ((16,2),(16,4),(32,8)) for p in (0,1,2,46,74)]))
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
