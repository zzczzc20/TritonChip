#!/bin/bash
set -euo pipefail
ROOT="$HOME/r41-accept-p1-v2";OUT="$HOME/r41-accept-p1/sensitivity"
mkdir -p "$OUT/configs"
export ROOT OUT
python3 - <<'PY'
import os,pathlib,json
root=pathlib.Path(os.environ['ROOT']);out=pathlib.Path(os.environ['OUT'])
base={}
for line in (root/'tools/performance_harness/systemc/configs/r40-three-core.cfg').read_text().splitlines():
 if '=' in line and not line.startswith('#'):
  k,v=line.split('=',1);base[k]=int(v)
variants={'base':{},'F01-F02-core':{'scalar_latency':base['scalar_latency']+1},'F03-F08-F09-fma':{'vector_fp_latency':base['vector_fp_latency']+1,'mtx_pipe_cycles':base['mtx_pipe_cycles']+1},'F04-F05-writeback':{'vector_int_latency':base['vector_int_latency']+1,'acc_read_latency':base['acc_read_latency']+1},'F06-dispatch':{'dispatch_cycles':base['dispatch_cycles']+4},'F07-slice':{'lookup_cycles':base['lookup_cycles']+1,'service_cycles':base['service_cycles']+1},'F10-lsu':{'load_latency':base['load_latency']+1},'T2-transfer':{'dma_setup_cycles':base['dma_setup_cycles']+1}}
for name,delta in variants.items():
 values=dict(base,**delta);(out/'configs'/f'{name}.cfg').write_text('\n'.join(f'{k}={v}' for k,v in values.items())+'\n')
(out/'registration.json').write_text(json.dumps(dict(scope='bounded uncalibrated timing sensitivity around integrated image structural families; parameter perturbations are not actual RTL ablations',variants=variants),indent=2)+'\n')
PY
source "$HOME/tc_env/env.sh"
export PYTHONPATH="$ROOT:$ROOT/python:$ROOT/compiler/python:$ROOT/tools/asm:$ROOT/tools/performance_harness/systemc"
export TNCA_BACKEND=systemc-tlm-grid TNCA_PROFILE=core-vrf-sync-v5-x8 TNCA_TLM_BINARY="$HOME/r41-accept-p1/model-build/tnca-chip" TNCA_TLM_MEMORY_BYTES=0x200000000
export TORCH_EXTENSIONS_DIR="$HOME/r41-accept-p1/extensions" OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 TNCA_IEEE_DIV=1
for cfg in "$OUT"/configs/*.cfg; do
 tag=$(basename "$cfg" .cfg)
 export TNCA_TLM_CONFIG="$cfg" TNCA_TLM_OUT="$OUT/$tag/models"
 "$HOME/tc_env/torchenv/bin/python" "$ROOT/tools/performance_harness/fragment_case.py" --out "$OUT/$tag/case" --columns 32 --shapes 17x65x33,128x128x192 --bitwise --require-resident > "$OUT/$tag.log" 2>&1
done
